import {AUDIO_CATEGORIES,AUDIO_SLOTS,AUDIO_PRESETS} from './audio-model.mjs?v=13.0.0-beta.8';

const e=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const disabled=value=>value?' disabled':'';
const selected=value=>value?' selected':'';
const checked=value=>value?' checked':'';
const note=text=>`<p class="ff-note">${e(text)}</p>`;
const icon=name=>`<i class="fa-solid fa-${name}" aria-hidden="true"></i>`;
const section=(title,body)=>`<section class="ff-section"><div class="ff-section-title"><h3>${e(title)}</h3></div>${body}</section>`;
const attrs=key=>`data-ff-audio="${e(key)}" data-ff-key="audio-${e(key)}" data-ff-write`;
const button=(action,label,value='',off=false,extra='')=>`<button type="button" class="ff-button" data-ff-action="${action}" data-ff-value="${e(value)}" data-ff-key="${action}-${e(value)}"${disabled(off)}${extra}>${label}</button>`;
const check=(key,label,value,off=false,hint='')=>`<label class="ff-check"><input type="checkbox" ${attrs(key)}${checked(value)}${disabled(off)}><span>${e(label)}${hint?`<small>${e(hint)}</small>`:''}</span></label>`;
function number(key,label,value,{min=1,max=240,step='any',placeholder='',off=false,unit=''}={}) {
  return `<label class="ff-number"><span>${e(label)}</span><div><input type="number" min="${min}" max="${max}" step="${step}" value="${e(value??'')}" placeholder="${e(placeholder)}" ${attrs(key)}${disabled(off)}>${unit?`<span>${e(unit)}</span>`:''}</div></label>`;
}
function range(key,label,value,{min=0,max=1,step=.05,off=false,local=false,hint=''}={}) {
  const v=Math.round((Number(value)||0)*1000)/1000;
  return `<div class="ff-slider"><div class="ff-slider-label"><label for="ff-audio-${e(key)}">${e(label)}</label><output for="ff-audio-${e(key)}" data-ff-output="audio:${e(key)}">${e(v)}</output></div><input id="ff-audio-${e(key)}" type="range" min="${min}" max="${max}" step="${step}" value="${e(v)}" data-ff-field="audio:${e(key)}" ${local?`data-ff-local="${e(key)}" data-ff-key="local-${e(key)}"`:attrs(key)}${disabled(off)}>${hint?`<small class="ff-hint">${e(hint)}</small>`:''}</div>`;
}
const select=(key,label,value,choices,off)=>`<label class="ff-select-row"><span>${e(label)}</span><select ${attrs(key)}${disabled(off)}>${Object.entries(choices).map(([id,label])=>`<option value="${e(id)}"${selected(value===id)}>${e(label)}</option>`).join('')}</select></label>`;
const disclosure=(key,label,summary,body,prefs,cls='')=>`<details class="ff-audio-details ${cls}" data-ff-audio-open="${e(key)}"${prefs.audioOpen?.includes(key)?' open':''}><summary>${e(label)}${summary?`<small>${e(summary)}</small>`:''}</summary><div class="ff-audio-detail-body">${body}</div></details>`;

export function audioHUDStatus(model) {
  const a=model.audio;
  if(!model.token||!a)return 'Select a token you own to set up wing audio.';
  if(model.cfg.audioEnabled===false)return 'Wing audio is disabled by the GM. Your choices remain saved.';
  if(a.localMuted)return 'Wing audio is muted on this browser, including previews.';
  if(!a.localVolume||!a.worldVolume)return 'Listener or module volume is zero.';
  if(a.status?.error)return `Audio could not play: ${a.status.error}`;
  if(a.status?.blocked)return 'Click Play to allow audio in this browser.';
  if(!a.requestedEnabled)return 'Wing audio is off for this token. You can still audition sounds privately.';
  if(a.audience==='local'&&a.localUserId&&a.localUserId!==globalThis.game?.user?.id)return 'Local audio is assigned to another player. Choose Only me to listen here.';
  if(!model.state?.enabled&&!model.state?.transition?.active&&!model.state?.bitsDeployed&&!(model.state?.bitDeployment>.01))return 'Audio is armed for the next takeoff. Saved sound choices remain available while the wings are off.';
  if(a.status?.message)return a.status.message;
  return a.audience==='nearby'?'Nearby playback follows the token. Listeners fade in at the current loop position.':a.localRespectsRadius?'Private playback follows your listener token and the audible radius.':'Private playback plays only for the selected local listener.';
}

const searchTerm=m=>String(m.search??'').trim().toLowerCase();
const soundMatches=(id,entry,m)=>{const q=searchTerm(m);return !q||q.split(/\s+/).every(term=>`${id} ${entry.label} ${entry.description??''} ${entry.category} ${entry.category==='treatments'?'medkit':''} audio sound volume radius enabled custom mute`.toLowerCase().includes(term));};
const visiblePrefs=(m,key)=>searchTerm(m)?{...m.prefs,audioOpen:[...(m.prefs.audioOpen??[]),key]}:m.prefs;
function soundRow(id,entry,m,off,previewOff,units) {
  const a=m.audio??{},raw=a.requested?.slots?.[id]??{},s=a.slots?.[id]??{};
  const preset=raw.preset??'default',prefix=`slots:${id}:`,label=entry.label??id;
  const category=a.categories?.[entry.category]??{};
  const info=preset==='none'?'No sound':AUDIO_PRESETS[preset]??AUDIO_PRESETS.default;
  if(!searchTerm(m)&&!m.prefs.audioOpen?.includes(`slot:${id}`))return disclosure(`slot:${id}`,label,info,'',m.prefs,'ff-audio-slot');
  let body=note(entry.description??'')+check(`${prefix}enabled`,'Enable this sound',raw.enabled??true,off)
    +`<div class="ff-select-row ff-effect-select-row"><span>Sound</span><button type="button" class="ff-button ff-effect-select" data-ff-action="audioPick" data-ff-value="${e(id)}" data-ff-key="audioPick-${e(id)}" data-ff-audio-picker="${e(id)}" data-ff-write aria-haspopup="dialog" aria-label="Choose sound for ${e(label)}"${disabled(off)}><span>${e(AUDIO_PRESETS[preset]??AUDIO_PRESETS.default)}</span>${icon('chevron-right')}</button></div>`;
  if(preset==='custom')body+=`<label class="ff-audio-file"><span>Audio file path</span><div><input type="text" value="${e(raw.src??'')}" placeholder="sounds/wing-cue.ogg" maxlength="2048" ${attrs(`${prefix}src`)}${disabled(off)}>${button('audioBrowse',icon('folder-open'),id,off,' data-ff-write title="Browse audio files" aria-label="Browse audio files"')}</div></label>${note('Use a file available to your Foundry players. Looped slots work best with seamless loops.')}`;
  body+=range(`${prefix}volume`,'Sound volume',raw.volume??1,{off})
    +number(`${prefix}radius`,'Radius override',raw.radius,{placeholder:s.radius??category.radius??a.radius??20,off,unit:units})
    +`<div class="ff-audio-row-actions">${button('audioPreview',`${icon('play')} Play privately`,id,previewOff||category.worldEnabled===false||preset==='none'||(preset==='custom'&&!raw.src),' data-ff-write')}${button('audioResetSlot','Reset sound',id,off,' data-ff-write')}</div>`;
  return disclosure(`slot:${id}`,label,info,body,visiblePrefs(m,`slot:${id}`),'ff-audio-slot');
}
function categoryCard(id,entry,m,off,previewOff,units) {
  const a=m.audio??{},raw=a.requested?.categories?.[id]??{},c=a.categories?.[id]??{},slots=Object.entries(AUDIO_SLOTS).filter(([,s])=>s.category===id);
  const q=searchTerm(m),categoryMatch=q&&q.split(/\s+/).every(term=>`${id} ${entry.label}`.toLowerCase().includes(term)),matching=q?slots.filter(([slot,s])=>categoryMatch||soundMatches(slot,s,m)):slots;
  if(q&&!matching.length)return '';
  const summary=`${raw.enabled===false?'Muted':'On'} · ${slots.length} ${slots.length===1?'sound':'sounds'}`;
  if(!q&&!m.prefs.audioOpen?.includes(`category:${id}`))return disclosure(`category:${id}`,entry.label??id,summary,'',m.prefs,'ff-audio-category');
  const body=check(`categories:${id}:enabled`,'Enable this category',raw.enabled??true,off)
    +range(`categories:${id}:volume`,'Category volume',raw.volume??entry.volume??1,{off})
    +number(`categories:${id}:radius`,'Category radius',raw.radius,{placeholder:c.radius??a.radius??20,unit:units,off})
    +note(c.worldEnabled===false?'This category is disabled by a module setting. Your choices remain saved.':'Blank radius follows the default. Each sound can override this category’s radius.')
    +button('audioResetCategory','Use category defaults',id,off,' data-ff-write')
    +matching.map(([slot,s])=>soundRow(slot,s,m,off,previewOff,units)).join('');
  return disclosure(`category:${id}`,entry.label??id,summary,body,visiblePrefs(m,`category:${id}`),'ff-audio-category');
}

/** This tab is a control surface only. Sound lifecycle stays with the audio manager. */
export function renderAudioTab(m,off) {
  const a=m.audio??{},r=a.requested??{},units=m.token?.document.parent?.grid?.units||'scene units';
  const previewOff=off||m.cfg.audioEnabled===false||!!a.localMuted||a.localVolume===0||a.worldVolume===0;
  const me=globalThis.game?.user?.id;
  const localOther=a.audience==='local'&&a.localUserId&&a.localUserId!==me;
  let body=section('Animation audio',`<div class="ff-audio-intro">${icon('wave-square')}<div><strong>Living energy. Precise technology.</strong><p>Quiet electrical textures, softened motion and subtle sci-fi detail. Original sounds remain available. Medkit audio has its own opt-in in Ellie’s Medkit dialogue.</p></div></div>${check('enabled','Enable wing and idle-bit audio',a.requestedEnabled??r.enabled??false,off)}${range('volume','Wing audio volume',r.volume??a.volume??.6,{off})}<p class="ff-note" data-ff-audio-status role="status">${e(audioHUDStatus(m))}</p>`);
  body+=section('Who hears wings and idle bits',select('audience','Playback',r.audience??a.audience??'local',{local:localOther?'Only me (currently another player)':'Only me',nearby:'Nearby players'},off)
    +(localOther?`<div class="ff-audio-row-actions">${button('audioClaimLocal','Play locally for me','',off,' data-ff-write')}</div>`:'')
    +number('radius','Default audible radius',r.radius??a.radius??20,{off,unit:units})
    +check('distanceFade','Fade with distance',r.distanceFade??a.distanceFade??true,off,'Gradually gets quieter toward the outer edge.')
    +((r.audience??a.audience??'local')==='local'?check('localRespectsRadius','Use radius for local playback',r.localRespectsRadius??false,off,'Off plays privately regardless of listener distance.'):note('Listeners use their controlled tokens, falling back to their assigned character when nothing is selected.'))
    +note('Distances use this scene’s units. Nearby sound is based on distance, not walls.'));
  body+=section('My listening preferences',`<label class="ff-check"><input type="checkbox" data-ff-local="audioMuted" data-ff-key="local-audioMuted"${checked(a.localMuted??m.cfg.audioMuted)}><span>Mute all animation audio on this browser</span></label>${range('audioLocalVolume','My listening volume',a.localVolume??m.cfg.audioLocalVolume??1,{local:true})}${note('These two controls affect only what you hear. Foundry’s Ambient volume also applies.')}`);
  body+=section('Sound library',`<div class="ff-audio-audition"><span>Private audition</span>${button('audioStop',`${icon('stop')} Stop preview`,'',false)}</div>${note('Click a sound choice to open its selector, then hover or focus a choice to hear it privately. Use its play button on touch screens. Click the choice to save. Preview follows your saved volumes and the GM’s audio switches, and bypasses distance.')}${note('Medkit sounds require Play animation audio in Ellie’s Medkit dialogue. Its sound settings choose each technique’s recordings and patient radius. Treatments are heard near the patient and by the initiating player, with personal mutes and volume respected.')}${Object.entries(AUDIO_CATEGORIES).filter(([id])=>id!=='treatments').map(([id,entry])=>categoryCard(id,entry,m,off,previewOff,units)).join('')}`);
  body+=disclosure('advanced','Playback tuning','Crossfades · movement · cue spacing',number('crossfadeMs','Crossfade duration',r.crossfadeMs??a.crossfadeMs??450,{min:50,max:2000,step:50,off,unit:'ms'})
    +range('movementSensitivity','Full movement sound at',r.movementSensitivity??a.movementSensitivity??3.5,{min:.25,max:12,step:.25,off,hint:'Visible movement in grid spaces per second. Lower values make the travel sound build sooner.'})
    +number('cooldownMs','Cue cooldown',r.cooldownMs??a.cooldownMs??450,{min:100,max:5000,step:50,off,unit:'ms'})
    +note('Movement blends into the idle hum. Condition sounds ease with damage and recovery; pose and reaction cues gently soften the background. Damage and healing take priority over small alignment accents.')
    +note('Alignment accents follow Animate stabilizers in Bits. Each sound keeps its own choice and volume here. A short cooldown limits repeated cues; all choices survive restarting Foundry.'),m.prefs);
  return `<div class="ff-audio-tab">${body}</div>`;
}

/** Convert one narrow DOM field to an API patch; the API applies full validation. */
export function audioFieldPatch(path,input) {
  const parts=path.split(':'),key=parts.at(-1),value=input.type==='checkbox'?input.checked:
    ['audience','preset','src'].includes(key)?String(input.value).trim():input.value.trim()===''?null:Number(input.value);
  const top=['enabled','volume','audience','radius','distanceFade','localRespectsRadius','crossfadeMs','movementSensitivity','cooldownMs'];
  if(parts.length===1&&top.includes(key))return {[key]:value};
  if(parts.length===3) {
    const [group,id]=parts,catalog=group==='categories'?AUDIO_CATEGORIES:group==='slots'?AUDIO_SLOTS:null;
    const fields=group==='slots'?['enabled','volume','radius','preset','src']:['enabled','volume','radius'];
    if(catalog&&Object.hasOwn(catalog,id)&&fields.includes(key))return {[group]:{[id]:{[key]:value}}};
  }
  throw new Error('Unknown audio control.');
}
