import {wingWorkerPool,supportsWingWorker} from './wing-worker-client.mjs?v=13.0.0-beta.8';
import {localPerformance} from './performance.mjs?v=13.0.0-beta.8';

/** A bit renderer's share of the off-thread painter (the wing worker), for
 * bit pictures only: the next picture of a resonant bit already on screen is
 * painted there and installed when it arrives (see BitFrames offload). It
 * joins a painter that is already running rather than starting another. The
 * first picture of a bit, other artwork, reduced motion and any failure paint
 * on this thread exactly as before. */
export class BitPictureLease {
  constructor(bits){this.bits=bits;this.lease=null;this.retryAt=0;this.now=0;this.released=false;}
  /** The offload function for BitRenderer.paint, or null to paint here. */
  offload(cfg,now){
    this.now=now;
    if(this.released||cfg?.renderWorker===false||!supportsWingWorker()){this.release();return null;}
    if(cfg?.reduced)return null;
    if(!this.lease&&now>=this.retryAt){
      this.lease=wingWorkerPool.acquire(()=>{},()=>{this.lease=null;this.retryAt=this.now+30000;this.bits?.forgetPending(this.now);},message=>this.accept(message),{kind:'bits'});
      if(!this.lease)this.retryAt=now+30000;
    }
    const lease=this.lease;
    return lease?.paintBits?jobs=>lease===this.lease&&lease.paintBits(jobs):null;
  }
  accept(message){
    if(this.released||!this.bits)return;
    if(message.lost){this.bits.forgetPending(this.now);return;}
    if(this.bits.install(message.results,this.now))localPerformance.count('bitPicturesInstalled',message.results.length);
  }
  /** Let the painter go; pictures still on their way are painted here. */
  release(){if(this.lease){this.lease.release();this.lease=null;this.bits?.forgetPending(this.now);}}
  destroy(){this.released=true;this.bits=null;if(this.lease){this.lease.release();this.lease=null;}}
}
