/** Yvaelle’s Toolbox v13 · The Heart Turned: what she sees, drawn on one canvas.
 *
 * (13.0.0-beta.5) It is painted. Three paintings (assets/curse, cut by tools/v13/make_art.py) are all of its artwork:
 * her flower as it is (the crystal that is her heart, and its petals of light), her flower turned (the same, dark and
 * thorned, under an eclipse), and one thorned branch. The stage moves them; nothing of the picture is drawn in lines.
 *
 * Six branches come in from the window's edges toward her heart, one for each state (numbered as on the table). Rolled:
 * her own light cuts at them until one is left (the cutting), and that one goes into her heart. Laid on her: one wakes,
 * drains the other five and goes in. Then the dark goes out from her heart through the whole flower and it is turned;
 * she is drawn aside, and the same branch lies between her and "that person" under the state's name, the Spans counted
 * on its thorns.
 *
 * The stage is 1280 × 720 units, fitted inside the window (the veil covers all of it). It keeps its own clock, advanced
 * only by frames it draws, so a hidden tab holds the moment instead of skipping it. Every wait and tween belongs to a
 * generation: cancel() ends them all at once (a minimise, a new curse), and whatever was awaiting them stops there.
 * Nothing here reads Foundry; the view (curse-view.mjs) owns the element, the pointer and when a frame is drawn.
 *
 * (13.0.0-beta.6) Her roll is shown one way, the cutting: beta.3's other three (stalking, creeping, noose) are taken out.
 * A few lines of their drawing are still here behind L.style tests that are never true now.
 * It is played from a seed, so the same curse plays the same on her page and on a watching GM's. Her
 * light goes bad by degrees while it chooses (L.taint). Laid on her, nothing is changed.
 *
 * Its wording can be changed whole (setWords): the GM watching her roll reads "A roll is asked of Yvaelle", "She is
 * made to …", "Waiting for her roll" where she has a button, and Close where she has Minimise. A name the GM made longer
 * is drawn smaller wherever it would not fit. */
import {CURSE_NOW as TAB} from './curse-model.mjs?v=13.0.0-beta.8';   // (beta.2) the states as they are now, with the GM's edits: a live binding
import {curseArt,BONE,MAG,EMB,PI,TAU,lerp,cl,E,N1,F} from './curse-art.mjs?v=13.0.0-beta.8';
import {ART_MAP} from './curse-art-map.mjs?v=13.0.0-beta.8';
/** How her roll is shown (the model's ROLL_STYLES): the cutting alone since 13.0.0-beta.6. */
export const STAGE_STYLES=Object.freeze(['cut']);
/** A small seeded generator (mulberry32). */
const rng32=seed=>{let a=(seed>>>0)||1;return ()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;};};

export const STAGE_W=1280,STAGE_H=720;
/** Thrown into whatever awaited a wait or a tween of a generation that was cancelled. */
export const CANCELLED=Symbol('curse cancelled');
const W=STAGE_W,H=STAGE_H;
/** The paintings' files (assets/curse/<name>.webp). */
export const ART_FILES=Object.freeze(['pure','pure-gem','cursed','cursed-gem','cursed-glow','tie','tie-glow','tie-thorns','tie-bone','order']);
/* the six branches: which state, the side of her it comes from (degrees round her heart, 0 = from the right), which way it bends, where its name sits beside it */
const BR=[{ti:0,ang:-120,way:'U',side:-1,lo:-30},{ti:1,ang:-60,way:'U',side:1,lo:-30},{ti:2,ang:0,way:'M',side:1,lo:-34},{ti:3,ang:60,way:'D',side:1,lo:34},{ti:4,ang:120,way:'D',side:-1,lo:34},{ti:5,ang:180,way:'M',side:-1,lo:-34}],NF=48,SR=262,XC={M:170,D:330,U:492};
/* where she is: large and centred while it chooses; small at the left once it has her (the name takes the middle, they the right) */
const CY0=300,SC0=3.7,PC=[262,348],PS=2.54,BP0=[1086,412],NY=252,DY=282,BR0=54,RX=730;
/* her flower's size on the stage (of its painting's); a branch's: how far out its tip starts, its size, its bend, how much of its end a cut takes, how far out its name sits; where the tie starts in its painting */
const STAIN=false,NICK=112,FS=.7,SX0=70,TK=.54,CUT=380,LAB=300,TIE0=300,RING=[640,352];
/* how the dark's going through her is paced: her crystal first and slowly, then out along her petals, the eclipse last */
const TURN=p=>p<.3?.2*(p/.3):p<.6?.2+.42*((p-.3)/.3):.62+.38*((p-.6)/.4);
const pulse=t=>Math.pow(Math.max(0,Math.sin(t*5.2)),8);
/* how each state ties her to them: what the tie does, what she does, what happens to them */
const WAY={protective:{loop:1,bdx:-10,shape:()=>0},lusty:{helix:1,bdx:-78,sway:7,shape:(u,t)=>(-8+4*Math.sin(t*2))*Math.pow(Math.sin(PI*u),2)},needy:{tug:1,shape:(u,t)=>10*pulse(t)*Math.sin(PI*u)},
  resentful:{tl:1.8,bdx:16,shape:(u,t)=>15*(1-Math.abs(2*u-1))+.5*Math.sin(t*31+u*40)},fearful:{trem:1,edx:-26,esc:.88,br:10,shape:(u,t)=>2.6*N1(t*7+u*5)*Math.sin(PI*u)},intrusive:{fray:1,edy:8,shape:(u,t)=>(11+3*Math.sin(t*1.1))*Math.sin(PI*u)}};
/** The cracks and the stain's reach for one cursed name (drawn fresh for each curse). */
function mkRT(rnd=Math.random){
  const RT=[],WK=Array(41).fill(0);
  for(let j=0;j<11;j++){const x0=-.47+.94*(j+.5*rnd()+.25)/11,top=.2+.4*rnd(),p=[[x0,0]];let xx=x0;const n=3+Math.floor(rnd()*3);for(let i=1;i<=n;i++){xx+=(rnd()-.5)*.02;p.push([xx,-.3+(top+.3)*i/n]);}RT.push({p,d:rnd()*.5});
    if(rnd()<.6){const q=[p[Math.floor(n/2)]],sd=rnd()<.5?1:-1;for(let i=1;i<=2;i++)q.push([q[0][0]+sd*.014*i,q[0][1]+.09*i]);RT.push({p:q,d:.5+rnd()*.3});}
    for(let i=0;i<=40;i++)WK[i]=Math.max(WK[i],Math.exp(-Math.pow((i/40-.5-x0*.92)/.016,2))*top/.6);}
  return [RT,WK];
}
const ANON=Object.freeze({n:'Them',c1:'#6f6a72',c2:'#221d24'});
/** What the stage says, as she reads it. waitRoll / waitRoot: shown in place of her two buttons to someone only watching. */
export const STAGE_WORDS=Object.freeze({ask:'A ROLL IS ASKED OF YOU',laid:'A CURSE IS LAID ON YOU',on:'IT IS ON',near:'NEAREST YOUR HEART',onLaid:'IT IS LAID ON YOU',made:'You are made to',madeLaid:'It is laid on you. You are made to',min:'MINIMISE',waitRoll:'WAITING FOR HER ROLL',waitRoot:'WAITING FOR HER TO LET IT ROOT'});

/** canvas: the element to draw on. beat(name): told as each moment is reached (the tests take their pictures there).
 * (13.0.0-beta.4) cue(name, detail): told at every moment that has a sound (curse-sound.mjs plays them; the stage itself
 * makes none). The names are CURSE_CUES; detail carries what a player needs: {i} which one, {v} how hard, {ms} how long. */
export const CURSE_CUES=Object.freeze(['veil','bed','filament','briar','round','on','strain','release','cut','take','wither','push','edge','hush','prowl','root','creep','lurch','close','notch','cinch',
  'ash','sear','turn','bead','beadStop','scorch','thorn','set','fold','open','strike','latch','drain','out']);
export function createCurseStage(canvas,{beat=null,cue=null,art:base=null,sound:soundInfo=null}={}){
  const x=canvas.getContext('2d'),A=curseArt(x),{briar,thorn,glow,txt,eyebrow,sigil,bead,gemK,wrap}=A;
  const doc=canvas.ownerDocument,NC=doc.createElement('canvas'),NS=doc.createElement('canvas'),nc=NC.getContext('2d'),ns=NS.getContext('2d');
  const K=name=>{try{beat?.(name);}catch{}};
  let HOLD=0;
  /** Everything holds exactly as it is for ms (the moment something lands). */
  const freeze=ms=>{HOLD=Math.max(HOLD,ms);};
  const S=(name,detail)=>{if(name==='notch'||name==='cinch'){L.beatT=now/1000;L.nzT=name==='cinch'?1.08:(detail&&detail.v)||0;flinch(null,.5);}if(cue)try{cue(name,detail??null);}catch{}};
  /** Her flower flinches from a branch (or, with none, just shudders): k how hard. */
  function flinch(f,k){const P=f&&f.pathH,a=P?P.A[P.n]:PI/2;L.recD=[Math.cos(a),Math.sin(a)];L.recT=now/1000;L.recK=k;}
  let Wd={...STAGE_WORDS};const setWords=o=>{Wd={...STAGE_WORDS,...(o??{})};};
  /** The size (px) at which a name in the capitals is no wider than max. */
  const fitCaps=(str,px,ls,max)=>{x.font=F.caps(px);x.letterSpacing=ls+'px';const w=x.measureText(str).width;return w>max?px*max/w:px;};
  /* ── the window: backing size, the stage's scale and where it sits ── */
  const V={cw:W,ch:H,k:1,ox:0,oy:0,x0:0,y0:0,w:W,h:H,nk:0};
  function resize({width,height,pixels=1}){
    const cw=Math.max(1,Math.round(width*pixels)),ch=Math.max(1,Math.round(height*pixels));if(canvas.width!==cw)canvas.width=cw;if(canvas.height!==ch)canvas.height=ch;
    const S=Math.min(width/W,height/H),k=S*pixels;Object.assign(V,{cw,ch,k,S,ox:(width-W*S)/2*pixels,oy:(height-H*S)/2*pixels,x0:-(width-W*S)/2/S,y0:-(height-H*S)/2/S,w:width/S,h:height/S});
    const nk=Math.min(2.5,Math.max(.5,k));if(nk!==V.nk){V.nk=nk;for(const c of [NC,NS]){c.width=Math.ceil(W*nk);c.height=Math.ceil(220*nk);}nameKey='';}
  }
  /** A point of the page (CSS px from the window's corner) on the stage, and back. */
  const toStage=(px,py)=>[px/V.S+V.x0,py/V.S+V.y0],toPage=(sx,sy)=>[(sx-V.x0)*V.S,(sy-V.y0)*V.S];

  /* ── its own clock: waits and tweens run on drawn frames only, and all belong to one generation ── */
  let now=0,gen=0,tw=[],tm=[];
  // (a cancelled wait rejects whoever awaits it; one nobody awaits must not count as an unhandled rejection)
  const quiet=p=>{p.catch(()=>{});return p;};
  function tween(ms,fn,ez=E.io){
    return quiet(new Promise((res,rej)=>{if(!(ms>0)){fn(ez(1));res();return;}fn(ez(0));tw.push({t0:now,ms,fn,ez,res,rej});}));
  }
  const wait=ms=>quiet(new Promise((res,rej)=>tm.push({at:now+ms,res,rej})));
  const later=(ms,fn)=>{tm.push({at:now+ms,res:fn,rej:null});};
  function advance(dt){
    now+=dt;
    if(tm.length){const due=tm.filter(o=>o.at<=now);if(due.length){tm=tm.filter(o=>o.at>now);for(const o of due){try{o.res();}catch(e){if(e!==CANCELLED)console.error(e);}}}}
    for(const o of tw.slice()){const u=Math.min(1,(now-o.t0)/o.ms);o.fn(o.ez(u));if(u>=1){const i=tw.indexOf(o);if(i>=0)tw.splice(i,1);o.res();}}
  }
  /** End everything under way. What awaited it is rejected with CANCELLED; values stay where they were. */
  function cancel(){
    gen++;const a=tw,b=tm;tw=[];tm=[];for(const o of a)o.rej(CANCELLED);for(const o of b)o.rej?.(CANCELLED);for(const k of Object.keys(gates)){gates[k].rej(CANCELLED);delete gates[k];}
  }
  /* ── what she can press: a gate opens when the view says its control was pressed ── */
  const gates={};
  const gate=name=>quiet(new Promise((res,rej)=>{gates[name]={res,rej};}));
  const press=name=>{const g=gates[name];if(!g)return false;delete gates[name];g.res();return true;};
  const waiting=name=>!!gates[name];

  /* ── state ── */
  const L={};let FIL=[],people=[],nameKey='',nameLive=false,DT=.016,LT=0,TT=0;
  const sm=r=>1-Math.pow(1-r,DT*30),nowS=()=>now/1000;
  function reset(){
    Object.assign(L,{cx:640,cy:CY0,sc:SC0,tilt:0,heartIn:0,starIn:0,bitsOut:0,inn:1,ringIn:0,ringA:0,th0:176,th:176,jab:0,fsel:null,e:null,dk:0,turn:0,pose:0,bits:1,nameA:0,front:0,ebA:0,dA:0,tg:0,tgA:0,tgP:null,FB:null,mk:0,
      ask:0,askHot:0,buds:0,cnt:0,span:0,spA:0,set:0,pop:0,kick:0,max:4,all:1,veil:0,head:0,btn:0,hot:0,forced:false,drained:0,bar:0,barBrk:null,barHits:[],dread:0,creep:0,hitT:[],RT:[],WK:[],gf:-1,on:-1,onPop:0,tens:0,hbPh:0,jolt:0,still:0,swell:0,dkO:0,gulps:[],
      minBtn:0,minHot:0,fold:0,fT:[912,45],fS:.09,fA:1,askY:0,wait1:0,wait2:0,taint:0,rk:1,style:'cut',near:0,sway:0,stA:0,onA:0,onI:-1,selA:0,pull:0,back:0,flare:0,gut:0,lastC:0,namesOut:0,rimT:null,sp:0,thS:null,press:0,rr:420,nzT:0,focus:0,hitA:0,crk:0,smT:null,recT:null,recD:null,recK:1,beatT:null,pulT:null,edge:0,edgeQ:0,hbV:0});
    FIL=BR.map((d,j)=>({j,ti:d.ti,e:TAB[d.ti],ang:d.ang,way:d.way,side:d.side,flip:d.side<0?1:-1,lo:d.lo,inn:0,ash:0,snap:0,sx:.5,drop:0,sev:0,rt:0,lurk:0,wind:0,lsT:null,lsFail:0,lsNick:0,CP:null,CN:null,trim:0,frags:null,hit:0,ta:.6,lat:0,dr:0,eat:0,t0:-99,A:0,p:.9,tau:.8,pl:0,plA:0,btA:0,pu:.6,cr:0,crO:0,bt:-99,wth:0,hg:0,TP:null,MP:null,LB:null,pathH:null,pathR:null,ringK:'',pv:null,cl:null,lv:0}));PK='';
    nameKey='';
  }
  const way=()=>(L.e&&WAY[L.e.k])||{};
  const beadPos=t=>{const w=way(),k=L.mk;return [BP0[0]+k*((w.bdx||0)+(w.sway?w.sway*Math.sin(t*1.5):0)-(w.tug?20*pulse(t):0)),BP0[1]];};
  const fpluck=(f,Am,tau,p)=>{f.t0=nowS();f.A=Am;f.tau=tau;f.p=p;f.pl=0;};
  /** The state's name, cursed: cracks climb it from the tie, a dark stain rises through the letters with an ember edge,
   * and each letter jolts as the curse reaches it. fx: how far along the tie the curse has run (stage x).
   * It is painted on its own canvas and kept: repainted only while the curse is still crossing it or a letter is still
   * jolting (and once more as that ends, with the ember steady). After that a frame only copies it. */
  function cursedName(e,NX,Ny,fs,ls,fx,t,al){
    const font=F.caps(fs);x.font=font;x.letterSpacing=ls+'px';const nw=x.measureText(e.n).width,off=NX-640,fxr=fx-off,rl=X0=>cl((fxr-X0)/150);
    const RL=(c,ox,oy,by)=>{for(const r of L.RT){const g=cl(rl(640+r.p[0][0]*nw)*1.6-r.d);if(g<=0)continue;const m=Math.max(1,Math.round((r.p.length-1)*g));c.beginPath();c.moveTo(ox+r.p[0][0]*nw,r.p[0][1]<=-.29?by:oy-r.p[0][1]*fs);for(let i=1;i<=m;i++)c.lineTo(ox+r.p[i][0]*nw,oy-r.p[i][1]*fs);c.stroke();}};
    // the letters' places (the name canvas is centred on 640), and which are still jolting
    nc.setTransform(V.nk,0,0,V.nk,0,0);nc.font=font;nc.letterSpacing=ls+'px';nc.textAlign='left';nc.textBaseline='alphabetic';
    const LT2=[];let p0=640-nw/2+ls/2,live=fxr>-1e4&&fxr<1e4;
    for(let ci=0;ci<e.n.length;ci++){const w0=nc.measureText(e.n[ci]).width,cm=p0+w0/2;if(L.hitT[ci]===undefined&&rl(cm)>0){L.hitT[ci]=t;S('scorch',{i:ci,n:e.n.length});}const ag=L.hitT[ci]!==undefined?t-L.hitT[ci]:9;if(ag<1.05)live=true;LT2.push([p0,ag<1?-3.6*Math.exp(-ag*6.5)*Math.sin(ag*24):0]);p0+=w0;}
    const key=`${e.k}|${fs}|${ls}|${al.toFixed(2)}|${V.nk}`;
    if(live||nameLive||key!==nameKey){
      nameKey=key;nameLive=live;nc.clearRect(0,0,W,220);nc.globalCompositeOperation='source-over';nc.filter='none';nc.fillStyle=`rgba(${BONE},${al})`;
      for(let ci=0;ci<e.n.length;ci++)nc.fillText(e.n[ci],LT2[ci][0],160+LT2[ci][1]);
      const top=()=>{for(let i=0;i<=40;i++){const u=i/40,hx=640-nw/2-20+(nw+40)*u;nc.lineTo(hx,163-fs*rl(hx)*(.02+.03*(.5+.5*N1(u*9+3))+.07*L.WK[i]));}};
      if(STAIN){nc.globalCompositeOperation='source-atop';nc.filter=`blur(${(2.2*V.nk).toFixed(2)}px)`;nc.beginPath();nc.moveTo(640-nw/2-20,200);top();nc.lineTo(640+nw/2+20,200);nc.closePath();nc.fillStyle='rgba(15,9,13,.94)';nc.fill();
      nc.filter=`blur(${(1.1*V.nk).toFixed(2)}px)`;nc.beginPath();top();nc.strokeStyle=`rgba(${EMB},${live?.8+.2*Math.sin(t*2.2):.9})`;nc.lineWidth=3.4;nc.stroke();nc.strokeStyle='rgba(255,150,200,.5)';nc.lineWidth=1;nc.stroke();}
      nc.filter='none';nc.globalCompositeOperation='source-over';
      // its shadow is painted once here, not on every frame
      ns.setTransform(1,0,0,1,0,0);ns.clearRect(0,0,NS.width,NS.height);ns.shadowColor='rgba(0,0,0,.85)';ns.shadowBlur=12*V.nk;ns.shadowOffsetY=3*V.nk;ns.drawImage(NC,0,0);ns.shadowColor='transparent';
    }
    x.drawImage(NS,off,Ny-160,W,220);
  }

  /* ── the paintings (assets/curse): her flower, her flower turned, the thorned branch. Until one has loaded it is not drawn ── */
  const IMG={},AM=ART_MAP,FB=AM.flower,TI=AM.tie,okI=im=>!!im&&im.complete===true&&im.naturalWidth>0;
  const art={base:null,ready:Promise.resolve(),loaded:()=>ART_FILES.filter(n=>okI(IMG[n])).length};
  if(base){art.base=String(base).replace(/\/+$/,'');const ps=[];
    for(const n of ART_FILES){try{const im=doc.createElement('img');im.decoding='async';im.src=`${art.base}/${n}${n==='order'?'.png':'.webp'}`;IMG[n]=im;if(typeof im.decode==='function')ps.push(im.decode().catch(()=>{}));}catch{}}
    art.ready=Promise.all(ps).then(()=>art.loaded());}
  /** The canvas her flower is put together on (what the dark has reached, what it has not, the light running through her). */
  const FC=doc.createElement('canvas'),fc=FC.getContext('2d');FC.width=FB.w;FC.height=FB.h;
  /* The order the dark takes her in (order.png: how far each point of her is from her heart THROUGH her: down the crystal,
   * out along each petal) made once into KM+1 soft masks, "all that is within v of her heart". Nothing in her is wiped across:
   * whatever moves through her (her own pulse of light, the dark) moves along her. No masks (a canvas that will not be
   * read): she is still drawn, and turns by fading. */
  const KM=24,NP=150;let MK=null,TG=null;
  /** The branch all in her colour (a thorn of it is lit by drawing this over it, added). */
  let HOTC=null;function hot(){if(HOTC!==null||!okI(IMG.tie))return HOTC||null;try{const c=doc.createElement('canvas');c.width=TI.w;c.height=TI.h;const g=c.getContext('2d');g.drawImage(IMG.tie,0,0);g.globalCompositeOperation='source-atop';g.fillStyle='rgba(255,36,150,.78)';g.fillRect(0,0,TI.w,TI.h);HOTC=c;}catch{HOTC=false;}return HOTC||null;}
  /** The branch, once for each state, its thorns in that state's colour (the painting's own light and shade kept). */
  let VTC=null;function coloured(){if(VTC!==null||!okI(IMG.tie)||!okI(IMG['tie-bone']))return VTC||null;try{VTC=TAB.map(e=>{const c=doc.createElement('canvas');c.width=TI.w;c.height=TI.h;const g=c.getContext('2d'),m=doc.createElement('canvas');m.width=TI.w;m.height=TI.h;const mg=m.getContext('2d');
      mg.drawImage(IMG['tie-bone'],0,0);mg.globalCompositeOperation='source-in';mg.fillStyle=`rgb(${e.acc})`;mg.fillRect(0,0,TI.w,TI.h);g.drawImage(IMG.tie,0,0);g.globalCompositeOperation='color';g.drawImage(m,0,0);g.globalCompositeOperation='source-over';g.globalAlpha=.38;g.drawImage(m,0,0);g.globalAlpha=1;return c;});}catch{VTC=false;}return VTC||null;}
  /** What burns in the branch, once in each state's own colour (so each of the six is its own). */
  function tints(){if(TG!==null||!okI(IMG['tie-glow']))return TG||null;try{TG=TAB.map(e=>{const c=doc.createElement('canvas');c.width=TI.w;c.height=TI.h;const g=c.getContext('2d');g.drawImage(IMG['tie-glow'],0,0);g.globalCompositeOperation='source-atop';g.fillStyle=`rgba(${e.acc},.72)`;g.fillRect(0,0,TI.w,TI.h);return c;});}catch{TG=false;}return TG||null;}
  let CGK='',CGC=null;function burn(acc){const G=IMG['cursed-glow'];if(!okI(G))return null;if(CGK===acc)return CGC;try{const c=CGC||doc.createElement('canvas');c.width=G.naturalWidth||G.width;c.height=G.naturalHeight||G.height;const g=c.getContext('2d');g.globalCompositeOperation='source-over';g.clearRect(0,0,c.width,c.height);g.drawImage(G,0,0);g.globalCompositeOperation='source-in';g.fillStyle=`rgb(${acc})`;g.fillRect(0,0,c.width,c.height);CGC=c;CGK=acc;}catch{CGC=null;}return CGC;}
  function masks(){
    if(MK!==null||!okI(IMG.order))return MK||null;
    try{const w=AM.order.w,h=AM.order.h,c=doc.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.drawImage(IMG.order,0,0,w,h);const d=g.getImageData(0,0,w,h).data,SOFT=13,out=[];
      for(let k=0;k<=KM;k++){const m=doc.createElement('canvas');m.width=w;m.height=h;const mg=m.getContext('2d'),id=mg.createImageData(w,h),thr=k/KM*(255+SOFT);
        for(let i=0,n=w*h;i<n;i++){const a=(thr-d[i*4])/SOFT;id.data[i*4+3]=a<=0?0:a>=1?255:Math.round(a*a*(3-2*a)*255);}mg.putImageData(id,0,0);out.push(m);}
      MK=out;}catch{MK=false;}
    return MK||null;
  }
  /** fc ← (op) all of her within v of her heart. */
  function reached(v,op='source-over'){
    const f=cl(v)*KM,k=Math.min(KM-1,Math.floor(f)),fr=f-k;fc.globalCompositeOperation=op;fc.globalAlpha=1;fc.drawImage(MK[k],0,0,FB.w,FB.h);if(fr>.004){fc.globalAlpha=fr;fc.drawImage(MK[k+1],0,0,FB.w,FB.h);fc.globalAlpha=1;}
  }
  const wipe=()=>{fc.globalCompositeOperation='source-over';fc.globalAlpha=1;fc.clearRect(0,0,FB.w,FB.h);};
  /** fc ← one painting of her, only between v0 and v1 of her heart. at: where in her box a smaller painting (her crystal) lies. */
  function part(im,v0,v1,at=null){
    wipe();if(v1>=1&&v0<=0){fc.drawImage(im,at?at.x:0,at?at.y:0);return;}
    if(v1>=1){fc.drawImage(im,at?at.x:0,at?at.y:0);reached(v0,'destination-out');return;}
    reached(v1);if(v0>0)reached(v0,'destination-out');fc.globalCompositeOperation='source-in';fc.drawImage(im,at?at.x:0,at?at.y:0);
  }

  /* ── the six ways in: one curve for each branch, from beyond its side of the window to her heart (rebuilt when the window's shape changes) ── */
  let PK='';
  function ways(){
    const key=V.x0+','+V.w;if(key===PK)return;PK=key;const xl=V.x0-80,H0=[640,CY0];
    const L3={U:[[xl,120],[xl+250,190],[486,110]],M:[[xl,330],[xl+280,420],[404,236]],D:[[xl,700],[xl+230,548],[500,560]]};
    for(const f of FIL){const d=L3[f.way].map(q=>f.side<0?q:[1280-q[0],q[1]]);f.pathH=lut(d[0],d[1],d[2],H0,NP);f.ringK='';const xc=f.side<0?XC[f.way]:1280-XC[f.way],yb=V.y0+V.h+90;f.pathC=lut([xc,yb],[xc+(f.side<0?-26:26),590],[lerp(xc,640,.52),f.way==='U'?520:478],H0,NP);}
  }
  /* (the noose) each branch's other way: in from its edge and then ROUND her, on a ring that tightens. Which stretch of the
   * ring each takes (degrees, 0 = right of her, 90 = under her), for the three on her left; the three on her right mirror them */
  const ARC={U:[222,272],M:[183,141],D:[140,94]},NLAB={U:249,M:161,D:117},VAR={U:{u0:70,tk:.94},M:{u0:24,tk:1},D:{u0:118,tk:1.06}};
  function ringWay(f,R){
    const k=Math.round(R)+'|'+PK;if(f.ringK===k)return f.pathR;f.ringK=k;const H=f.pathH,[a0,a1]=ARC[f.way],n=NP,X=new Float32Array(n+1),Y=new Float32Array(n+1),m=Math.round(n*.42);
    const rad=d=>d*PI/180,pt=d=>{const q=rad(d),px=RING[0]+R*Math.cos(q),py=RING[1]+R*Math.sin(q);return [f.side<0?px:1280-px,py];},dir=a1>a0?1:-1,e0=pt(a0),e1=pt(a0+dir*2),tl=Math.hypot(e1[0]-e0[0],e1[1]-e0[1])||1,tx=(e1[0]-e0[0])/tl,ty=(e1[1]-e0[1])/tl;
    const xe=f.side<0?V.x0-80:V.x0+V.w+80,p0=f.way==='U'?[xe,256]:f.way==='M'?[xe,306]:[xe,452],dd=Math.hypot(e0[0]-p0[0],e0[1]-p0[1]),c1=[lerp(p0[0],e0[0],.45),p0[1]],c2=[e0[0]-tx*dd*.34,e0[1]-ty*dd*.34];
    for(let i=0;i<=n;i++){if(i<=m){const u=i/m,w=1-u,b0=w*w*w,b1=3*w*w*u,b2=3*w*u*u,b3=u*u*u;X[i]=b0*p0[0]+b1*c1[0]+b2*c2[0]+b3*e0[0];Y[i]=b0*p0[1]+b1*c1[1]+b2*c2[1]+b3*e0[1];}else{const q=pt(lerp(a0,a1,(i-m)/(n-m)));X[i]=q[0];Y[i]=q[1];}}
    return f.pathR=measure(X,Y,n);
  }
  /** The tie's way: out of her, down under the words, up to them, and its end curled over the top of their portrait. */
  function tieWay(x0,y0,bx,by,r,sh,turn=2.2){const n=96,m=56,X=new Float32Array(n+1),Y=new Float32Array(n+1),e=[bx-r,by],p1=[x0+210,y0-46+sh],p2=[e[0]-46,by+96-sh];for(let i=0;i<=n;i++){if(i<=m){const u=i/m,w=1-u,b0=w*w*w,b1=3*w*w*u,b2=3*w*u*u,b3=u*u*u;X[i]=b0*x0+b1*p1[0]+b2*p2[0]+b3*e[0];Y[i]=b0*y0+b1*p1[1]+b2*p2[1]+b3*e[1];}else{const q=PI+(i-m)/(n-m)*turn;X[i]=bx+r*Math.cos(q);Y[i]=by+r*Math.sin(q);}}return measure(X,Y,n);}
  /** Points → a way: how far along each is, and its heading there. */
  function measure(X,Y,n){
    const A=new Float32Array(n+1),Sx=new Float32Array(n+1);let len=0;for(let i=1;i<=n;i++){len+=Math.hypot(X[i]-X[i-1],Y[i]-Y[i-1]);Sx[i]=len;}
    for(let i=0;i<=n;i++){const a=Math.max(0,i-1),b=Math.min(n,i+1);A[i]=Math.atan2(Y[b]-Y[a],X[b]-X[a]);}return {X,Y,A,S:Sx,n,len};
  }
  /** One way becoming another (w: 0 the first, 1 the second), point for point. */
  function between(P,Q,w){if(w<=0)return P;if(w>=1)return Q;const n=P.n,X=new Float32Array(n+1),Y=new Float32Array(n+1);for(let i=0;i<=n;i++){X[i]=P.X[i]+(Q.X[i]-P.X[i])*w;Y[i]=P.Y[i]+(Q.Y[i]-P.Y[i])*w;}return measure(X,Y,n);}
  /** A cubic curve as n+1 points with how far along each is: {x, y, a (its heading), s, len}. */
  function lut(p0,p1,p2,p3,n){
    const X=new Float32Array(n+1),Y=new Float32Array(n+1);for(let i=0;i<=n;i++){const u=i/n,m=1-u,b0=m*m*m,b1=3*m*m*u,b2=3*m*u*u,b3=u*u*u;X[i]=b0*p0[0]+b1*p1[0]+b2*p2[0]+b3*p3[0];Y[i]=b0*p0[1]+b1*p1[1]+b2*p2[1]+b3*p3[1];}
    return measure(X,Y,n);
  }
  /** Where a curve is at s along it → [x, y, heading] (into o). */
  function along(P,s,o){
    const n=P.n,S=P.S;let i=Math.min(n-1,Math.max(0,Math.floor(s/P.len*n)));while(i<n-1&&S[i+1]<s)i++;while(i>0&&S[i]>s)i--;
    const d=S[i+1]-S[i],u=d>0?cl((s-S[i])/d):0;o[0]=P.X[i]+(P.X[i+1]-P.X[i])*u;o[1]=P.Y[i]+(P.Y[i+1]-P.Y[i])*u;let da=P.A[i+1]-P.A[i];if(da>PI)da-=TAU;else if(da<-PI)da+=TAU;o[2]=P.A[i]+da*u;return o;
  }
  const O3=[0,0,0];
  /** The thorned branch, GROWN along a curve from s0 to s1: its painting laid along the curve in thin slices, fixed to the curve
   * (so a thorn stays where it grew), narrowing to a point at its growing end (so thorns sprout as the end passes them).
   * o: {u0, ks (painting → stage), ky (its thickness), taper (how long the point is), blunt (a cut end), bend(s) (px aside), glow, al} */
  function vine(P,s0,s1,o){
    const im=o.img||(o.glow?IMG['tie-glow']:IMG.tie);if(!(o.img||okI(im))||s1-s0<2||o.al<.01)return;
    const ks=o.ks,tp=o.taper||160,a0=x.globalAlpha,ds=o.fine?2.6:5,wS=ds/ks*(o.fine?1.45:1.7)+1;x.globalAlpha=a0*o.al;if(o.glow||o.lighter)x.globalCompositeOperation='lighter';
    if(o.one){const sm2=(s0+s1)/2,u=o.u0+s0/ks,wd=(s1-s0)/ks;along(P,sm2,O3);const c=Math.cos(O3[2]),sn=Math.sin(O3[2]),ky=o.ky*(o.flip||1);x.save();x.transform(c*ks,sn*ks,-sn*ky,c*ky,O3[0],O3[1]);x.drawImage(im,u,0,wd,TI.h,-wd/2,-TI.cy,wd,TI.h);x.restore();x.globalAlpha=a0;x.globalCompositeOperation='source-over';return;}
    for(let s=Math.max(0,s0);s<s1;s+=ds){
      const rem=s1-s,tk=o.flat?1:o.blunt?Math.min(1,.5+rem/36):Math.min(1,Math.pow(rem/tp,.7)),u=o.u0+s/ks;if(u>TI.w-2)break;const tl=o.tail?Math.min(1,Math.pow(Math.max(0,s-Math.max(0,s0))/o.tail,.8)):1;
      along(P,s,O3);let px=O3[0],py=O3[1],an=O3[2];
      if(o.bend){const b=o.bend(s),b2=o.bend(s+ds);px-=Math.sin(an)*b;py+=Math.cos(an)*b;an+=Math.atan2(b2-b,ds);}
      const c=Math.cos(an),sn=Math.sin(an),ky=o.ky*tk*tl*(o.flip||1);x.save();x.transform(c*ks,sn*ks,-sn*ky,c*ky,px,py);x.drawImage(im,u,0,Math.min(wS,TI.w-u),TI.h,0,-TI.cy,Math.min(wS,TI.w-u),TI.h);x.restore();
    }
    x.globalAlpha=a0;x.globalCompositeOperation='source-over';
  }
  /** How far one branch has come along its way: 0 at the window's edge, 1 with its end in her heart. */
  function reach(f){
    const ns=L.style==='noose'?cl((1-L.rk)/.2):0,cr=f.crO>0?f.cr:0,nc2=L.style==='cut'&&!f.drop?FIL.reduce((n,q)=>n+(q.sev?1:0),0):0,up=L.style==='creep'&&f.crO>0,top=ns>0?1:up?.84:L.style==='cut'?.58:.88;
    let p=f.inn*((L.style==='cut'?.33:.35)+.05*cl(L.edge||0)+.04*nc2+(L.style==='cut'&&!f.drop?.3*cl(L.taint)*(.84+.045*((f.j*7)%5)):0))+.48*Math.max(-.4,Math.min(1,f.plA/22));
    // (the creeping) it draws back to the edge, and comes up from below instead: how high is how near
    if(up){const c=cl(f.crO);p=c<.5?p*(1-2*c):(.3+.54*Math.pow(cr,1.2)+.03*N1(TT*1.5+f.j*7.3)*cl(cr*4)*(1-L.stA))*(2*c-1);}
    p=lerp(p,1,E.io(ns));
    p=Math.min(top,p);if(L.style==='cut'&&!f.drop)p=Math.min(L.raceD!=null?.99:L.drained?1:.94,p+.32*(f.adv||0)*(f.way==='U'?1.38:1));if(f===L.fsel){p=Math.min(top+.34,p+.2*cl(L.swell));p=lerp(p,1,cl(L.dk))*(1-.34*(L.pull||0));p*=1-(L.back||0);}else if(f===L.rvF&&!f.drop)p*=1-.4*(L.pull||0);if(false){p=Math.min(top,p+.2*cl(L.swell));p=lerp(p,1,cl(L.dk))*(1-.34*(L.pull||0));p*=1-(L.back||0);}
    if(f.drop&&!f.sev)p*=1-E.io(cl(f.snap));
    // (the stalking) the six stay out of it: one thorn goes round her instead
    if(f.wlt>0)p*=1-.42*E.io(cl(f.wlt));   // (beta.8) glutted on her light, it shrinks back as it withers
    return p*(1-.45*f.dr)*(1-E.io(cl(f.rt||0)))*(1-cl(L.sp||0));
  }
  /** (the stalking) One long thorn that goes round her, its head where the curse is looking: it prowls, doubles back, darts in
   * at one of the six and draws off. At the last it does not draw off. */
  function serpent(t,al){
    const sp=cl(L.sp||0);if(sp<.02||al<.01||!okI(IMG.tie))return;
    const hf=L.fsel||FIL.find(f=>f.hit)||null,pl=hf?hf.plA:0,dk=L.fsel?cl(L.dk):0,pu=L.pull||0,th=L.thS*PI/180,n=120,m=86,X=new Float32Array(n+1),Y=new Float32Array(n+1);
    const d=Math.max(-34,lerp((SR-78)*.86*cl(pl/22),SR,dk)*(1-.55*pu)-30*pu),a0=th-3.7-.5*pu,a1=th-.24,pt=(a,r)=>[RING[0]+r*Math.cos(a),RING[1]+r*Math.sin(a)];
    for(let i=0;i<=m;i++){const q=pt(a0+(a1-a0)*i/m,SR+7*Math.sin(t*.8+i*.09));X[i]=q[0];Y[i]=q[1];}
    {const q0=[X[m],Y[m]],c=pt(th+.02,SR-d*.12),e=dk>0?[lerp(pt(th+.06,SR-d)[0],RING[0],dk),lerp(pt(th+.06,SR-d)[1],CY0,dk)]:pt(th+.06,SR-d);for(let i=m+1;i<=n;i++){const u=(i-m)/(n-m),w=1-u;X[i]=w*w*q0[0]+2*w*u*c[0]+u*u*e[0];Y[i]=w*w*q0[1]+2*w*u*c[1]+u*u*e[1];}}
    const P=measure(X,Y,n),len=P.len*(1-(L.back||0))*E.io(sp);if(len<8)return;
    const ky=TK*1.08,tipU=TI.tipx-(L.fsel?120*dk*(1-(L.back||0)):0),ks=Math.max(ky,len/(tipU-60)),ag=hf?t-hf.t0:9,wob=hf&&hf.A>.02&&ag>=0?hf.A*Math.exp(-ag/.6):0;
    const bend=s=>{const q=s/len;return q*q*(wob*.7*Math.sin(ag*15-(len-s)*.016)+((hf&&L.still)||pu>.5?4*Math.sin(t*44):0));},o={u0:tipU-len/ks,ks,ky,flip:1,bend,fine:true,flat:true,tail:len*.72,al};
    vine(P,0,len,o);const T=tints(),g=hf?cl(.3+.7*hf.hg):.3;if(g>.03)vine(P,0,len,{...o,glow:true,img:T&&hf?T[hf.ti]:null,al:al*g});
    if(L.fsel&&L.dk>=1&&!(L.back>0)){const u=(t*1.15)%1;vine(P,len*Math.max(0,u-.16),len*u,{...o,tail:0,glow:true,al:al*.95*Math.sin(PI*u)});}
    if(L.fsel&&L.smT!=null&&t-L.smT<.26){const u=(t-L.smT)/.26,a2=x.globalAlpha;x.lineCap='round';for(let i=0;i<10;i++){along(P,Math.max(0,len-i*24),O3);const x0=O3[0],y0=O3[1];along(P,Math.max(0,len-(i+1)*24),O3);x.globalAlpha=a2*al*(1-u)*(1-i/10);x.strokeStyle='rgba(255,36,150,.8)';x.lineWidth=16*(1-i/12);x.beginPath();x.moveTo(x0,y0);x.lineTo(O3[0],O3[1]);x.stroke();x.strokeStyle='rgba(255,226,246,.9)';x.lineWidth=3.5*(1-i/12);x.stroke();}x.globalAlpha=a2;}
  }
  /** One branch: grown to where it has come, swaying a little from its root to its end; lit while the curse is on it. Cut,
   * its end comes away, turning, and falls; what is left stands dead at the window's edge. */
  const CUTK=.62,HEADL=170,EN='255,40,214';
  function branch(f,t,al){
    if(!f.pathH||al<.01)return;let P=L.style==='creep'&&f.crO>=.5&&f.pathC?f.pathC:f.pathH;
    // (the noose) round her, on a ring that tightens with every beat; the one that takes her leaves the ring for her heart
    if(L.style==='noose'&&L.rk<1&&!f.sev){const w=cl((1-L.rk)/.12)*(f===L.fsel?1-E.io(cl(L.dk)):1);if(w>0)P=between(f.pathH,ringWay(f,L.rr-14*f.btA-(L.beatT!=null&&t-L.beatT<.9?13*Math.exp(-(t-L.beatT)*6)*Math.cos((t-L.beatT)*17):0)),w);}
    const pT=reach(f);f.pv=f.pv==null||(f===L.fsel&&L.dk>=1&&!(L.back>0))?pT:f.pv+(pT-f.pv)*sm(f===L.fsel&&L.smT!=null?.95:.55);const ag=t-f.t0,wob=f.A>.02&&ag>=0?f.A*Math.exp(-ag/(f.tau*.7)):0;
    let Lv=f.pv*P.len;if(f.sev){if(f.cl==null)f.cl=f.lv||Lv;Lv=f.cl;}else f.lv=Lv;if(Lv<6)return;
    // it grows: the whole painted branch, small at first, lengthening and thickening as it comes
    const nsW=L.style==='noose'&&!f.sev?cl((1-L.rk)/.12)*(f===L.fsel?1-E.io(cl(L.dk)):1):0,ky=TK*VAR[f.way].tk*(1-.22*nsW)*(f===L.fsel?1+.3*cl(L.swell):1)*(1-.42*cl(f.wlt||0)),tipU=TI.tipx,ks=Math.max(ky,Lv/620),SXf=tipU-Lv/ks,g=Lv/P.len,back=f.sev?1-E.io(cl(f.rt||0)):1;
    const tr=L.tens>0&&!f.drop?1.2*L.tens*(1-L.stA):0,bend=s=>{const q=s/Math.max(60,Lv);return q*q*((L.style==='cut'?24:10)*Math.sin(t*(L.style==='cut'?.95:.7)+f.j*1.7-s*(L.style==='cut'?.0075:.0052))+tr*3*Math.sin(t*.7+f.j*1.7-s*.0052)+(L.style==='cut'?11:2)*Math.sin(t*(L.style==='cut'?1.9:1.3)+f.j*.8-s*(L.style==='cut'?.019:.011))+(L.style==='cut'&&f.lg>.03?34*f.lg*f.flip*Math.sin(PI*1.5*Math.min(1,q)):0)+wob*.8*Math.sin(ag*15-(Lv-s)*.016)+((f.hit&&L.still)||f.plA>9||(f===L.fsel&&L.pull>.5)?4.5*Math.sin(t*44+f.j):0))+(f===L.fsel&&L.dk>0&&L.dk<1?46*(1-L.dk)*L.dk*4*f.flip*Math.sin(PI*Math.min(1,q)):0)+(f===L.fsel&&L.pull>0?78*L.pull*f.flip*Math.sin(PI*Math.min(1,q))*Math.sin(PI*Math.min(1,q)):0)+(L.style==='creep'&&f.crO>=.5?11*Math.sin(s*.011+f.j*2.1)*cl(s/260)*cl((P.len-s)/200):0)+(f.dnA>.05?3.2*f.dnA*Math.sin(t*41+f.j*2)*Math.min(1,q):0)+(f.wlt>0?74*E.io(cl(f.wlt))*f.flip*q*q*Math.sin(PI*.85*Math.min(1,q)):0);};
    const fine=L.style==='noose'&&L.rk<1,dimd=f.hit||f===L.fsel?1:1-.5*Math.max(L.onA*(L.style==='creep'?.5:1),L.focus||0),VC=coloured(),o={u0:SXf,ks,ky,flip:f.flip,bend,fine,flat:true,img:VC?VC[f.ti]:null,al:al*dimd*(f.sev?1-.5*cl(f.wth||0):1)*(1-.6*f.dr)*(1-.66*cl(f.wlt||0))},trim=f.trim||0,Lend=Math.max(10,Lv-trim);
    f.PP=P;
    // the pieces her light has taken off its end: each falls, turning, out of the window
    if(f.frags&&f.frags.length){f.frags=f.frags.filter(fr=>t-fr.t0<.5);for(const fr of f.frags){const q=(t-fr.t0)/.5,ks2=Math.max(ky,fr.Lv/620),o2={...o,u0:tipU-fr.Lv/ks2,ks:ks2,bend:null,al:1-cl((q-.6)/.4)};along(P,(fr.s0+fr.s1)/2,O3);const mx=O3[0],my=O3[1];x.save();x.translate(mx-60*E.out(q)*Math.cos(O3[2])-70*E.out(q)*Math.sin(O3[2])*(fr.dir||1),my-60*E.out(q)*Math.sin(O3[2])+70*E.out(q)*Math.cos(O3[2])*(fr.dir||1)+300*q*q);x.rotate(2.2*q*(fr.dir||1)*(fr.sp||1));x.translate(-mx,-my);vine(P,fr.s0,fr.s1,o2);x.restore();
      }}
    if(!f.sev){const cs=Math.max(20,Math.min(Lend-50,(L.style==='cut'?Lv-(f.go??HEADL):Lv)-(L.style==='cut'?0:CUT*(.5+.5*g))));along(P,cs,O3);{const b=bend(cs);f.CP=[O3[0]-Math.sin(O3[2])*b,O3[1]+Math.cos(O3[2])*b,O3[2]];}along(P,Math.max(20,Lend-NICK),O3);{const b=bend(Math.max(20,Lend-NICK));f.CN=[O3[0]-Math.sin(O3[2])*b,O3[1]+Math.cos(O3[2])*b,O3[2]];}f.cs=cs;}
    if(f.sev){
      const q=cl(f.snap),cut0=Math.max(20,Math.min(Lend-50,(f.limp?0:L.style==='cut'?Lv-(f.go??HEADL):Lv)-(L.style==='cut'?0:CUT*(.5+.5*g)))),whip=E.out(q),cut=cut0*(1-.1*whip*back)*back;
      if(cut>8){vine(P,0,cut,o);along(P,cut,O3);if(L.style==='cut'){const ax=Math.cos(O3[2]),ay=Math.sin(O3[2]),nx=-ay,ny=ax;x.fillStyle='rgb(8,5,9)';x.beginPath();x.moveTo(O3[0]+ax*14+nx*16,O3[1]+ay*14+ny*16);for(let i=0;i<=6;i++){const v=i/6*2-1,dd=(i%2?-9:2)+3*N1(i*3.1+f.j);x.lineTo(O3[0]+ax*dd+nx*16*v*-1,O3[1]+ay*dd+ny*16*v*-1);}x.lineTo(O3[0]+ax*14-nx*16,O3[1]+ay*14-ny*16);x.closePath();x.fill();}const a0=x.globalAlpha;x.globalAlpha=a0*al*(f.limp?0:1);{const cq=1-cl(q*3);glow(O3[0],O3[1],9,.8*cq*back,'255,232,250');}x.globalAlpha=a0;}
      if(q<1){along(P,(cut0+Lend)/2,O3);const mx=O3[0],my=O3[1];const kq=E.out(cl(q*2.2));x.save();x.translate(mx+(f.fl?f.fl[0]:0)*250*kq-30*kq*Math.cos(O3[2])*(f.fl?0:1),my+(f.fl?f.fl[1]:0)*250*kq-30*kq*Math.sin(O3[2])*(f.fl?0:1)+(f.limp?760:f.fl?900:210)*q*q);x.rotate((f.limp?.8:f.fl?1.5:.42)*q*f.flip);x.translate(-mx,-my);vine(P,cut0,Lend,trim>0?{...o,blunt:true,flat:false,al:(f.fl?1:al)*(1-cl((q-.42)/.33))}:{...o,al:(f.fl?1:al)*(1-cl((q-.42)/.33))});x.restore();
        if(q<.6&&!f.limp){along(P,cut0,O3);const u=Math.max(0,(q-.14)/.46),sl=(L.style==='cut'?(40+80*(f.lsE??1))*(f.lsBig?1.3:1):78)*E.out(cl(q*9)),a2=O3[2]+1.15*f.flip,cx2=O3[0],cy2=O3[1],a0=x.globalAlpha,wd=Math.pow(1-u,1.6),ca=Math.cos(a2),sa=Math.sin(a2),bw=1+9*wd,bx=-sa*26,by=ca*26;
          // a blade's stroke: pointed at both ends, thick in the middle, a little curved; its core hot
          for(const [ww,col] of [[bw*1.5*(.35+.65*(f.lsE??1)),`rgba(${EN},${.8*wd})`],[bw*.5*(.35+.65*(f.lsE??1)),`rgba(255,236,250,${.97*wd})`]]){x.globalAlpha=a0;x.fillStyle=col;x.beginPath();x.moveTo(cx2-ca*sl,cy2-sa*sl);x.quadraticCurveTo(cx2+bx-sa*ww,cy2+by+ca*ww,cx2+ca*sl,cy2+sa*sl);x.quadraticCurveTo(cx2+bx+sa*ww,cy2+by-ca*ww,cx2-ca*sl,cy2-sa*sl);x.fill();}x.globalAlpha=a0;}}
      return;
    }
    const eat=f===L.fsel&&L.turn>0?Lv*E.io(cl((L.turn-.04)/.42)):0,trimA=f===L.fsel?trim*(1-cl(L.dk*1.5)):trim,Le=Math.max(10,Lv-trimA);vine(P,eat,Le,eat>0?{...o,tail:110}:trimA>2?{...o,blunt:true,flat:false}:o);
    if(trimA>2&&!f.drop&&f.lsT!=null&&t-f.lsT<.5){along(P,Le,O3);const a0=x.globalAlpha;x.globalAlpha=a0*al*(1-(t-f.lsT)/.5);glow(O3[0],O3[1],12,.5,'255,36,150');glow(O3[0],O3[1],3.6,.8,'255,214,240');x.globalAlpha=a0;}
    // where her light has bitten it: a short scar across the stem (no wider than the stem), hot as it is made, then burning low in the vine's own colour
    if(false){const a0=x.globalAlpha;x.lineCap='round';for(const g of f.gs){const sg=Math.max(20,Math.min(Le-12,Lv-g.off));along(P,sg,O3);const b=bend(sg),gx=O3[0]-Math.sin(O3[2])*b,gy=O3[1]+Math.cos(O3[2])*b,hot=Math.max(0,1-(t-g.t)/.45),an=O3[2]+PI/2+g.ang*.6,ca=Math.cos(an),sa=Math.sin(an),hl=5.5+1.5*g.k;x.globalAlpha=a0*al;glow(gx,gy,9+8*hot,.3+.5*hot,hot>.3?EN:f.e.acc);
        x.strokeStyle='rgba(8,5,9,.95)';x.lineWidth=5.5;x.beginPath();x.moveTo(gx-ca*hl,gy-sa*hl);x.lineTo(gx+ca*hl,gy+sa*hl);x.stroke();x.strokeStyle=hot>.3?`rgba(255,${Math.round(150+90*hot)},252,1)`:`rgba(${f.e.acc},.95)`;x.lineWidth=2.2;x.stroke();}x.globalAlpha=a0;}
    // what burns in it, in its own state's colour: low always, full while the curse is on it
    const T=tints(),gl=f.drop?0:cl((.3+.12*L.hbV)*dimd+.8*f.hg+.5*f.lat*(1-f.dr))*(1-cl((f.wlt||0)*1.5));const eat0=f===L.fsel&&L.turn>0?Lv*E.io(cl((L.turn-.04)/.42)):0;if(gl>.03){vine(P,eat0,Le,{...o,glow:true,img:T?T[f.ti]:null,al:al*gl});if(f.hg>.4)vine(P,eat0,Le,{...o,glow:true,img:null,al:al*.6*(f.hg-.4)});}if(f.lg>.03&&!f.drop){vine(P,eat0,Le,{...o,glow:true,img:T?T[f.ti]:null,al:al*f.lg});f.lg*=1-sm(.1);}
    if(L.style==='noose'&&L.rk<1&&f!==L.fsel){const q2=NLAB[f.way]*PI/180,rl2=L.rr+(f.way==='M'?84:60),mx=RING[0]+rl2*Math.cos(q2);f.MP=[f.side<0?mx:1280-mx,RING[1]+rl2*Math.sin(q2),cl((1-L.rk)/.12)];}else if(f.MP){f.MP[2]*=1-sm(.2);if(f.MP[2]<.01)f.MP=null;}
    if(f===L.fsel&&L.dk>=1&&!(L.back>0)&&!f.drop&&!(L.turn>0)){const u=(t*1.15)%1;vine(P,Lv*Math.max(0,u-.16),Lv*u,{...o,glow:true,img:null,al:al*.95*Math.sin(PI*u)});}
    // (beta.8) laid on her: it drinks her light. Her magenta runs down it from its end, it fills with it, and it is that which withers it
    if(f.dn>0&&!f.drop){const a1=cl(f.dnA||0),burn=cl(f.dn)*(1-cl((f.wlt||0)*1.3));if(a1>.02)for(let k=0;k<3;k++){const u=((t-(f.dnT||0))*1.5+k/3)%1,sc=Le*(1-u*Math.min(1,.35+.9*f.dn));vine(P,Math.max(0,sc-.16*Le),sc,{...o,glow:true,img:null,al:al*a1*.95*Math.sin(PI*u)});}
      if(burn>.03){x.save();x.filter='none';vine(P,Math.max(0,Le*(1-Math.min(1,.2+f.dn))),Le,{...o,glow:true,img:null,al:al*.5*burn*(.8+.2*Math.sin(t*23+f.j))});x.restore();}}
    along(P,Math.max(0,Le-4),O3);f.TP=[O3[0]-Math.sin(O3[2])*bend(Le),O3[1]+Math.cos(O3[2])*bend(Le),O3[2]];
  }
  /** A blade's stroke of her light: pointed at both ends, thick in the middle, a little curved; its core hot. u: 0 as it lands → 1 gone. */
  function blade(cx2,cy2,a2,u,len=104){const a0=x.globalAlpha,wd=Math.pow(1-cl(u),1.6),sl=len*E.out(cl(u*6+.3)),ca=Math.cos(a2),sa=Math.sin(a2),bw=1+13*wd,bx=-sa*len*.3,by=ca*len*.3;for(const [ww,col] of [[bw,`rgba(${EN},${.8*wd})`],[bw*.34,`rgba(255,236,250,${.96*wd})`]]){x.fillStyle=col;x.beginPath();x.moveTo(cx2-ca*sl,cy2-sa*sl);x.quadraticCurveTo(cx2+bx-sa*ww,cy2+by+ca*ww,cx2+ca*sl,cy2+sa*sl);x.quadraticCurveTo(cx2+bx+sa*ww,cy2+by-ca*ww,cx2-ca*sl,cy2-sa*sl);x.fill();}x.globalAlpha=a0;}
  /** A state's name, written the way that state behaves (each letter set on its own): the Protective stands square between
   * two walls; the Lusty sways, warm; the Needy leans and reaches toward who it wants; the Resentful is set crooked and shakes
   * with it; the Fearful trembles, thin, and leans away; the Intrusive spreads and pushes in. toward: +1 or −1, which way "them
   * / her heart" lies from the name. → the width it took. */
  let LAND=1;
  function themed(k,nm,xl,y,size,la,t,toward,acc,big=1,col=BONE,dry=false){
    if(!nm)return 0;const ft=F.caps(size);x.font=ft;x.letterSpacing='0px';x.textAlign='left';x.textBaseline='alphabetic';
    const ls=(k==='protective'?4.2:k==='needy'&&big>1.6?5.5:k==='resentful'?.6:k==='intrusive'?2+3.2*(.5+.5*Math.sin(t*1.9)):k==='fearful'?1.2:2)*big,W=[];let tw=0;for(const ch of nm){const w0=x.measureText(ch).width;W.push(w0);tw+=w0+ls;}tw-=ls;
    if(dry||la<.01)return tw;
    const burst=k==='resentful'?Math.pow(Math.max(0,Math.sin(t*2.3)),10):0,x0=k==='intrusive'&&toward<0?xl-(tw-(tw/(1+0))):xl;let cx=x0,i=0;
    const NL=nm.length;for(const ch of nm){let dx=0,dy=0,rot=0,sh=0,al=la,sc=1;const li=LAND>=1?1:cl((LAND*(NL+3)-i)/3);if(li<=0){cx+=W[i]+ls;i++;continue;}
      if(k==='lusty'){dy=2.6*big*Math.sin(t*2.2+i*.55);rot=.05*Math.sin(t*2.2+i*.55+1.2);}
      else if(k==='needy'){sh=big>1.6?0:-.24*toward;dx=3.2*big*toward*(.5+.5*Math.sin(t*1.7+i*.45));if(big>1.6){sc=.9;dy=-.9*big*Math.sin(i*1.3+t*1.2);}}
      else if(k==='resentful'){sh=-.17;dx=1.6*big*burst*N1(t*37);dy=1.1*big*burst*N1(t*41);}
      else if(k==='fearful'){dx=1.3*big*N1(t*13+i*5);dy=1.3*big*N1(t*11+i*9+3);sh=.16*toward;al=la*(.7+.3*N1(t*5+i*2));sc=.96;}
      else if(k==='intrusive'){dx=(i===(toward>0?nm.length-1:0)?3.5*big*toward*(.5+.5*Math.sin(t*1.9)):0);}
      al*=li;dy-=9*big*.3*(1-E.out(li));x.save();x.translate(cx+W[i]/2+dx,y+dy);if(rot)x.rotate(rot);if(sh)x.transform(1,0,sh,1,0,0);if(sc!==1)x.scale(sc,sc);x.fillStyle=`rgba(${col},${Math.max(0,Math.min(1,al))})`;x.fillText(ch,-W[i]/2,0);
      if(k==='lusty'){x.globalCompositeOperation='lighter';x.fillStyle=`rgba(${acc},${.4*la*(.5+.5*Math.sin(t*2.2+i*.55))})`;x.fillText(ch,-W[i]/2,0);}
      if(k==='resentful'&&burst>.05){x.globalCompositeOperation='lighter';x.fillStyle=`rgba(${acc},${.6*la*burst})`;x.fillText(ch,-W[i]/2,0);}
      x.restore();cx+=W[i]+ls;i++;}
    if(k==='protective'&&big<1.6){}else if(k==='protective'){x.save();x.globalAlpha*=la;x.fillStyle=`rgb(${col})`;const h=size*.86,w=Math.max(2,size*.045);[[x0-13*big/3.6-w,-1],[x0+tw+13*big/3.6,1]].forEach(([bx,d])=>{x.fillRect(bx,y-h,w,h);for(let i=0;i<3;i++){const yy=y-h*(.2+.3*i),xx=d<0?bx:bx+w;x.beginPath();x.moveTo(xx,yy-size*.07);x.lineTo(xx+d*size*.16,yy+size*.02);x.lineTo(xx,yy+size*.07);x.closePath();x.fill();}});x.restore();}else if(false){const sw=300,u0=TI.tipx-sw,hh=size*1.25;for(const bx of [x0-11*big,x0+tw+11*big]){x.save();x.translate(bx,y+size*.16);x.rotate(-PI/2);x.scale(hh/sw,.26*big);x.globalAlpha*=la;x.drawImage(IMG.tie,u0,0,sw,TI.h,0,-TI.cy,sw,TI.h);x.restore();}}
    return tw;
  }
  /** Her own light, cutting: a filament of it whips out from her heart to the branch and severs it there (the blade's stroke
   * is its end). The last time it gutters and falls short. Also: how much her heart flares with it (L.flare). */
  function lashes(C,t){
    let fl=0;
    for(const f of FIL){if(f.lsT==null)continue;const a=t-f.lsT,en=cl(f.lsE??1),te=.06+.06*(1-en),hold=f.lsDud?.1:.06,T=te+hold+.13;if(a<0||a>=T)continue;const tg=(f.lsNick&&!f.lsDud&&f.CN?f.CN:f.CP)||(f.TP?[f.TP[0],f.TP[1]]:null);if(!tg)continue;
      const fz=f.lsFail&&f.lsFail<1?f.lsFail:1,ext=E.out(cl(a/te))*fz,fade=(a<te+hold?1:1-cl((a-te-hold)/.13))*(f.lsDud||fz<1?.75+.25*Math.sin(a*70):1);if(fade<=.01)continue;const thin=1;fl=Math.max(fl,fade*en);
      const dx=tg[0]-C[0],dy=tg[1]-C[1],d=Math.hypot(dx,dy)||1,ov=0,ex=tg[0]+dx/d*ov,ey=tg[1]+dy/d*ov,bow=(.34*d+40)*f.side*((f.lsN||0)%2?-1:1)*(1-.45*cl(a/(te+.05))),jit=(1-en)*9,mx=C[0]+dx*.5-dy/d*bow+jit*N1(t*31+f.j),my=C[1]+dy*.5+dx/d*bow+jit*N1(t*37+f.j*3),N=30,a0=x.globalAlpha,W=(5+15*en)*(f.lsBig?2.1:1);x.lineCap='round';
      const lim=Math.round(N*ext),PX=[C[0]],PY=[C[1]],HW=[.5],GP=[false];
      for(let i=1;i<=lim;i++){const u=i/N,w=1-u;PX.push(w*w*C[0]+2*w*u*mx+u*u*ex);PY.push(w*w*C[1]+2*w*u*my+u*u*ey);HW.push(W*.5*Math.pow(Math.sin(PI*Math.min(1,u*.96+.02)),.62)+.5);{const h=Math.sin(i*12.9898+Math.floor(t*30)*78.233+f.j*3.1)*43758.5453,r=h-Math.floor(h);GP.push(en<.55&&r<(.55-en)*1.1);}}
      const i00=a<te+hold?0:Math.min(lim-1,Math.round(lim*cl((a-te-hold)/.11))),rib=(k,col)=>{x.fillStyle=col;let i=i00;while(i<lim){while(i<lim&&GP[i+1])i++;let j=i;while(j<lim&&!GP[j+1])j++;if(j>i){x.beginPath();for(let q=i;q<=j;q++){const q1=Math.min(lim,q+1),q0=Math.max(0,q-1),tx=PX[q1]-PX[q0],ty=PY[q1]-PY[q0],tl=Math.hypot(tx,ty)||1,h=HW[q]*k*thin*(q===j?.25:1)*(en<.55?(.7+.6*Math.abs(Math.sin(q*2.3+t*40)))*Math.min(1,(q-i+.25)/1.6,(j-q+.25)/1.6):1);if(q===i)x.moveTo(PX[q]-ty/tl*h,PY[q]+tx/tl*h);else x.lineTo(PX[q]-ty/tl*h,PY[q]+tx/tl*h);}for(let q=j;q>=i;q--){const q1=Math.min(lim,q+1),q0=Math.max(0,q-1),tx=PX[q1]-PX[q0],ty=PY[q1]-PY[q0],tl=Math.hypot(tx,ty)||1,h=HW[q]*k*thin*(q===j?.25:1)*(en<.55?(.7+.6*Math.abs(Math.sin(q*2.3+t*40)))*Math.min(1,(q-i+.25)/1.6,(j-q+.25)/1.6):1);x.lineTo(PX[q]+ty/tl*h,PY[q]-tx/tl*h);}x.closePath();x.fill();}i=j+1;}};
      if(lim>=1){x.globalAlpha=a0*(.5+.5*en);x.shadowColor=`rgba(${EN},.9)`;x.shadowBlur=10+14*en;rib(1,`rgba(${EN},.62)`);x.shadowBlur=0;rib(.36,`rgba(255,240,252,${.7+.3*en})`);}
      const px=PX[lim],py=PY[lim];
      x.globalAlpha=a0*fade;glow(px,py,(6+8*en)*(f.lsBig?1.3:1),.5+.3*en,EN);glow(px,py,(2.5+3*en)*(f.lsBig?1.3:1),.95,'255,238,252');
      // where it lands: a stroke across the vine, and light thrown off it. A blow that cannot cut only gutters there.
      if(a>=te&&fz>=1){const u=(a-te)/(hold+.2),va=tg[2]??0;if(f.lsDud){x.globalAlpha=a0*(1-u)*(.5+.5*Math.sin(a*90));glow(tg[0],tg[1],16,.7,EN);x.lineCap='round';x.lineWidth=1.4;for(let i=0;i<4;i++){const an=Math.atan2(-dy,-dx)+(i-1.5)*.5,r0=8+10*u,r1=r0+10+14*en;x.strokeStyle=`rgba(${EN},.8)`;x.beginPath();x.moveTo(tg[0]+Math.cos(an)*r0,tg[1]+Math.sin(an)*r0);x.lineTo(tg[0]+Math.cos(an)*r1,tg[1]+Math.sin(an)*r1);x.stroke();}}else{blade(tg[0],tg[1],va+PI/2+(f.ga||0)+.2*f.flip,u,(26+70*en)*(f.lsBig?1.3:1));x.globalAlpha=a0*(1-u)*(1-u);x.lineCap='round';for(let i=0;i<7;i++){const an=Math.atan2(dy,dx)+(i-3)*.33+.2*N1(i*7+f.j),r0=10+26*u,r1=r0+(18+40*en)*(1-.5*u)*(.6+.4*((i*.37)%1));x.strokeStyle=`rgba(${EN},.9)`;x.lineWidth=1.2+1.6*en;x.beginPath();x.moveTo(tg[0]+Math.cos(an)*r0,tg[1]+Math.sin(an)*r0);x.lineTo(tg[0]+Math.cos(an)*r1,tg[1]+Math.sin(an)*r1);x.stroke();}
          {const ns=f.lsBig?10:5,ue=E.out(cl(u*1.3)),VC2=coloured(),im=VC2?VC2[f.ti]:null,TH=TI.thorns;if(im&&TH&&TH.length){const al0=a0*(1-cl((u-.55)/.45));for(let i=0;i<ns;i++){const th=TH[(i*7+f.j*3+(f.lsN||0)*5)%TH.length],an=Math.atan2(dy,dx)+(i-(ns-1)/2)*.42+.3*N1(i*3+f.j*2),rr=12+(70+60*((i*.43)%1))*ue*(f.lsBig?1.5:1),sx=tg[0]+Math.cos(an)*rr,sy=tg[1]+Math.sin(an)*rr+90*u*u,ro=an+7*u*(i%2?1:-1),sc=(i<3?.62:.4)*(f.lsBig?1.2:1),sw=46,sh=Math.min(TI.h-TI.cy,th[1]+12);x.save();x.globalAlpha=al0;x.translate(sx,sy);x.rotate(ro);x.scale(sc,sc);{const s0=TI.cy+20,hh=Math.max(10,sh-24),w2=34;x.drawImage(im,th[0]-w2/2,s0,w2,hh,-w2/2,-hh/2,w2,hh);}x.restore();}}}}}
      x.globalAlpha=a0;}
    L.flare=fl;
  }
  /** (beta.8) Laid on her: she is forced to defend. A shell of her own light stands round her crystal and the vines throw
   * themselves at it. It is drawn in broken lengths, never a clean line: brightest where it has just been struck, thinner and
   * with more of it missing as she has less; and when she has nothing left its last lengths fly apart. */
  const BARR=en=>[86+38*en,178+30*en];
  function barrier(C,t){
    const b=cl(L.bar||0),brk=L.barBrk!=null?(t-L.barBrk)/.42:-1;if((b<.02&&!(brk>=0&&brk<1))||L.turn>0)return;const en=cl(L.enS??1),[rx,ry]=BARR(en),a0=x.globalAlpha,N=64,HT=L.barHits||[],out=brk>=0?E.out(cl(brk)):0,pres=brk>=0?1-cl(brk):b;
    x.save();x.globalCompositeOperation='lighter';x.lineCap='round';
    // the field itself: nothing at her crystal, a little of her light toward its edge
    if(brk<0){const g=x.createRadialGradient(0,0,.45,0,0,1);g.addColorStop(0,`rgba(${EN},0)`);g.addColorStop(.72,`rgba(${EN},${.03+.05*en})`);g.addColorStop(1,`rgba(${EN},${.1+.12*en})`);x.save();x.translate(C[0],C[1]);x.scale(rx,ry);x.globalAlpha=a0*b;x.fillStyle=g;x.beginPath();x.arc(0,0,1,0,TAU);x.fill();x.restore();}
    for(let i=0;i<N;i++){const a=i/N*TAU,a2=(i+.82)/N*TAU,n=.5+.5*N1(i*1.7+t*2.3),n2=.5+.5*N1(i*.61-t*1.1+9);let hot=0;for(const h of HT){const ag=t-h.t;if(ag<0||ag>.5)continue;let da=Math.abs(a-h.a)%TAU;if(da>PI)da=TAU-da;hot=Math.max(hot,h.k*Math.exp(-ag/.16)*Math.exp(-da*da/.42));}
      const miss=n2<(1-en)*.62&&hot<.2;if(miss&&brk<0)continue;const al=pres*cl((.3+.42*en)*(.4+.6*n)+hot);if(al<.02)continue;const ro=1+.5*out*(.6+.8*n2)+.035*hot,sp=out*(n-.5)*1.4;
      x.globalAlpha=a0*al;x.strokeStyle=`rgba(${EN},1)`;x.lineWidth=1.6+3*en+9*hot;x.beginPath();x.moveTo(C[0]+Math.cos(a+sp)*rx*ro,C[1]+Math.sin(a+sp)*ry*ro);x.lineTo(C[0]+Math.cos(a2+sp)*rx*ro,C[1]+Math.sin(a2+sp)*ry*ro);x.stroke();
      if(hot>.25){x.globalAlpha=a0*al*hot;x.strokeStyle='rgba(255,226,248,1)';x.lineWidth=1+2*hot;x.stroke();}}
    // where it is struck: her light flares there and is thrown off, and the vine's own colour with it
    for(const h of HT){const ag=t-h.t;if(ag<0||ag>.34)continue;const u=ag/.34,px=C[0]+Math.cos(h.a)*rx,py=C[1]+Math.sin(h.a)*ry,nx=Math.cos(h.a)*ry,ny=Math.sin(h.a)*rx,nl=Math.hypot(nx,ny)||1,ox=nx/nl,oy=ny/nl;x.globalAlpha=a0*(1-u);glow(px,py,(30+30*h.k)*(1+.5*u),.6*h.k,EN);glow(px,py,6+5*h.k,.8*(1-u),'255,230,250');
      x.globalAlpha=a0*(1-u)*(1-u);for(let i=0;i<7;i++){const an=Math.atan2(oy,ox)+(i-3)*.36+.25*N1(i*5+h.j),r0=8+52*E.out(u),r1=r0+(18+44*h.k)*(1-.5*u)*(.6+.4*((i*.37)%1));x.strokeStyle=i%3===1?`rgba(${h.acc},.9)`:`rgba(${EN},.9)`;x.lineWidth=1.4+1.8*h.k;x.beginPath();x.moveTo(px+Math.cos(an)*r0,py+Math.sin(an)*r0);x.lineTo(px+Math.cos(an)*r1,py+Math.sin(an)*r1);x.stroke();}}
    x.restore();x.globalAlpha=a0;
  }
  /** Her flower, under the branches. As it is: it floats, and each beat of her heart sends her light out through her petals.
   * As the curse works: it dims, and the cracks of what she will be show through. Turned: the dark goes down her crystal and
   * out along each petal, a hot edge before it; the eclipse comes out from behind her last. */
  function flowerBase(C,fk,t){
    const ox=C[0]-FB.hx*fk,oy=C[1]-FB.hy*fk,dw=FB.w*fk,dh=FB.h*fk,tn=cl(L.taint),ph=cl(L.turn),a0=x.globalAlpha,si=cl(L.starIn),M=masks();
    const put=(al,lighter)=>{if(al<.01)return;x.globalAlpha=a0*al;if(lighter)x.globalCompositeOperation='lighter';x.drawImage(FC,ox,oy,dw,dh);if(lighter)x.globalCompositeOperation='source-over';x.globalAlpha=a0;};
    if(ph<1&&si>.01&&okI(IMG.pure)){
      const dim=(1-.3*tn)*(1-.1*tn*Math.sin(t*2.1))*(1-.4*cl(L.hitA||0))*(1-.28*(L.press||0))*(1-.46*cl(L.gut||0))*(1-.42*cl(L.tire||0));
      const dk=L.calmOn?Math.min(.62,1-dim):0;
      if(M&&(si<1||ph>0||dk>.01)){part(IMG.pure,ph>0?TURN(ph):0,si<1?si*.84:1);if(dk>.01){fc.globalCompositeOperation='source-atop';fc.globalAlpha=dk;fc.fillStyle='rgb(30,12,34)';fc.fillRect(0,0,FB.w,FB.h);fc.globalAlpha=1;fc.globalCompositeOperation='source-over';}put((L.calmOn?1:dim)*cl(si*4));if(dk>.2&&ph<=0){x.globalCompositeOperation='lighter';x.globalAlpha=a0*.22*cl((dk-.2)/.4);x.drawImage(IMG.pure,ox,oy,dw,dh);x.globalCompositeOperation='source-over';x.globalAlpha=a0;}}        // opening: her light runs out from her heart into her petals
      else{x.globalAlpha=a0*dim*si*(M?1:1-ph);x.drawImage(IMG.pure,ox,oy,dw,dh);x.globalAlpha=a0;}
      // each beat of her heart, out through her
      if(M&&ph<=0&&si>=1){const b=((L.hbPh/TAU)%1+1)%1*1.45;if(b<1.12){part(IMG.pure,b-.13,Math.min(1,b));put(.5*(1-.75*tn)*(1-cl((b-.6)/.5))*(1-L.stA),true);}}
    }
    if(ph>0&&okI(IMG.cursed)){
      if(ph<1&&M){const v=TURN(ph);part(IMG.cursed,0,v);put(1);part(IMG.pure,v-.075,Math.min(1,v+.03));if(L.e){fc.globalCompositeOperation='source-atop';fc.globalAlpha=.8;fc.fillStyle=`rgb(${deep(L.e.acc)})`;fc.fillRect(0,0,FB.w,FB.h);fc.globalAlpha=1;}put(.85,true);put(.22*(1-cl((ph-.85)/.15)),true);}
      else{x.globalAlpha=a0*(M?1:ph);x.drawImage(IMG.cursed,ox,oy,dw,dh);x.globalAlpha=a0;}
    }
    // what burns in her: showing through her light as it goes bad; once she is turned, beating with her heart
    if(okI(IMG['cursed-glow'])){const g1=.5*tn*(1-ph)*(.7+.3*Math.sin(t*3.1))*si,g2=ph*(.25+.75*L.hbV)+(L.pulT!=null&&t-L.pulT<1.6?1.1*Math.sin(PI*cl((t-L.pulT)/1.6)):0);
      const BG=L.e&&ph>0?burn(deep(L.e.acc)):null;if(ph>0&&ph<1&&M){part(IMG['cursed-glow'],0,TURN(ph));put(Math.max(g1,.9),true);if(BG){const v=TURN(ph);part(BG,0,v);x.globalCompositeOperation='color';x.globalAlpha=a0*.9;x.drawImage(FC,ox,oy,dw,dh);x.globalCompositeOperation='source-over';x.globalAlpha=a0;part(BG,v-.16,v);put(1,true);put(.8,true);}}
      else if(ph<=0&&M){if(g1>.02){part(IMG['cursed-glow'],0,.56);put(g1,true);}}else if(Math.max(g1,g2)>.02){x.globalCompositeOperation='lighter';x.globalAlpha=a0*Math.max(g1,g2)*(BG&&ph>=1?.3:1);x.drawImage(IMG['cursed-glow'],ox,oy,dw,dh);if(BG&&ph>=1){x.globalAlpha=a0*Math.min(1,.5+.5*Math.max(g1,g2));x.globalCompositeOperation='color';x.globalAlpha=a0*.9;x.drawImage(BG,ox,oy,dw,dh);x.globalCompositeOperation='lighter';x.globalAlpha=a0*Math.min(1,.3+.5*Math.max(g1,g2));x.drawImage(BG,ox,oy,dw,dh);}x.globalCompositeOperation='source-over';x.globalAlpha=a0;}}
  }
  /** Her heart: the crystal, over whatever has reached for it. The dark goes down it from where it was struck. */
  const deep=a=>{const v=a.split(',').map(Number),m=Math.min(...v),M0=Math.max(...v),w=v.map(c=>c-m*.82),M1=Math.max(...w)||1;return w.map(c=>Math.round(c*M0/M1)).join(',');};
  function gem(C,fk,t,acc0){const acc=deep(acc0);
    const ph=cl(L.turn),tn=cl(L.taint),a0=x.globalAlpha,hi=cl(L.heartIn),M=masks(),hs=lerp(.82,1,E.out(hi))*(1+.012*L.hbV*(1-L.stA)),v=Math.max(TURN(ph),L.crk>0?.19*E.out(cl(L.crk)):0);
    const P=IMG['pure-gem'],D=IMG['cursed-gem'],GP=AM.pureGem,GD=AM.cursedGem;
    if(!okI(P)||!okI(D)){x.save();x.translate(C[0],C[1]);gemK(0,0,26*fk*hs,150*fk*hs,ph<.5?1:0,acc,hi,t,.9*tn);x.restore();return;}
    x.save();x.translate(C[0],C[1]);x.scale(hs,hs);const dr=(im,G,al,lighter)=>{if(al<.01)return;x.globalAlpha=a0*al;if(lighter)x.globalCompositeOperation='lighter';x.drawImage(im,(G.x-FB.hx)*fk,(G.y-FB.hy)*fk,G.w*fk,G.h*fk);if(lighter)x.globalCompositeOperation='source-over';};
    const pf=(al,lighter)=>{if(al<.01)return;x.globalAlpha=a0*al;if(lighter)x.globalCompositeOperation='lighter';x.drawImage(FC,-FB.hx*fk,-FB.hy*fk,FB.w*fk,FB.h*fk);if(lighter)x.globalCompositeOperation='source-over';};
    if(ph<=0){const lowE=(L.calmOn||L.drained)&&L.enH!=null?1-cl(L.enS??1):0,gd=(1-.38*cl(L.gut||0))*(1-.34*cl(L.tire||0))*(1-.3*lowE*Math.abs(N1(t*13)));if((L.calmOn||L.drained)&&gd<.98&&M){part(P,0,1,GP);fc.globalCompositeOperation='source-atop';fc.globalAlpha=Math.min(.78,(1-gd)*1.25);fc.fillStyle='rgb(34,14,38)';fc.fillRect(0,0,FB.w,FB.h);fc.globalAlpha=1;fc.globalCompositeOperation='source-over';pf(hi*(1-.2*tn));}else dr(P,GP,hi*(1-.2*tn)*(L.calmOn?1:gd));dr(P,GP,hi*Math.min(.5,.22*L.hbV*(1-.7*tn)+.1*(L.flare||0)),true);if(L.flare>.02)glow(0,0,150*fk+40,.4*L.flare,'255,36,150');}
    const tn2=k=>{if(L.calmOn&&L.e){fc.globalCompositeOperation='source-atop';fc.globalAlpha=k;fc.fillStyle=`rgb(${deep(L.e.acc)})`;fc.fillRect(0,0,FB.w,FB.h);fc.globalAlpha=1;fc.globalCompositeOperation='source-over';}};
    if(ph<=0&&L.crk>0&&M){part(D,0,v,GD);tn2(.4);pf(1);part(P,v-.03,v+.02,GP);tn2(.85);pf(.9,true);}
    else if(ph<=0){}
    else if(ph<1&&M&&v<.34){part(P,v,1,GP);pf(1);part(D,0,v,GD);tn2(.4);pf(1);part(P,v-.04,Math.min(1,v+.03),GP);tn2(.85);pf(.9,true);}
    else{if(!M&&ph<1)dr(P,GP,1-ph);dr(D,GD,M?1:ph);dr(D,GD,.14*L.hbV,true);const BG2=L.e&&(ph>=1||(L.calmOn&&(L.crk||0)>0))?burn(deep(L.e.acc)):null;if(BG2){x.save();x.beginPath();x.rect((GD.x-FB.hx)*fk,(GD.y-FB.hy)*fk,GD.w*fk,GD.h*fk);x.clip();x.globalCompositeOperation='color';x.globalAlpha=a0*.9;x.drawImage(BG2,-FB.hx*fk,-FB.hy*fk,FB.w*fk,FB.h*fk);x.globalCompositeOperation='lighter';x.globalAlpha=a0*(.25+.4*L.hbV);x.drawImage(BG2,-FB.hx*fk,-FB.hy*fk,FB.w*fk,FB.h*fk);x.restore();}}
    x.restore();x.globalAlpha=a0;
    // struck: one breath of what is in the branch, at her heart
    if(L.hitA>.01)glow(C[0],C[1],150*fk+50,.5*L.hitA,'8,5,9');
    if(false){const ba=cl((t-L.rimT)/.08)*(1-cl((ph-.35)/.5));if(ba>.01){glow(C[0],C[1],56,.8*ba,'8,5,9');glow(C[0],C[1],48,.5*ba,acc);sigil(L.e.k,C[0]+2,C[1]+2,42,.95*ba,'8,5,9');sigil(L.e.k,C[0],C[1],42,ba,acc);}}
    if(L.crk>0&&ph<.5){const wa=cl(L.crk)*(1-ph*2);glow(C[0],C[1],46*fk+14,.4*wa,'255,36,150');}
    if(L.calmOn&&L.rimT!=null&&t-L.rimT<.36&&L.fsel&&L.fsel.pathH){const u=(t-L.rimT)/.36,P0=L.fsel.pathH,an0=P0.A[P0.n],a0=x.globalAlpha;x.lineCap='round';x.globalAlpha=a0*(1-u)*(1-u);x.fillStyle=`rgba(${acc},.95)`;for(let i=0;i<5;i++){const an=an0+(i-2)*.17+.1*N1(i*5.3),r0=30+70*E.out(u),r1=r0+(60+190*((i*.61+.2)%1))*(1-.35*u),w=(8-Math.abs(i-2)*1.6)*(1-.5*u),ca=Math.cos(an),sa=Math.sin(an);x.beginPath();x.moveTo(C[0]+ca*r0-sa*w,C[1]+sa*r0+ca*w);x.lineTo(C[0]+ca*r1,C[1]+sa*r1);x.lineTo(C[0]+ca*r0+sa*w,C[1]+sa*r0-ca*w);x.closePath();x.fill();}x.globalAlpha=a0;}
    if(L.calmOn&&L.rimT!=null&&t-L.rimT<.3){const u=(t-L.rimT)/.3;glow(C[0],C[1],170,.26*(1-u),acc);}
    if(L.rimT!=null&&t-L.rimT<.32){const u=(t-L.rimT)/.32;glow(C[0],C[1],26*fk+10,.6*(1-u),acc);glow(C[0],C[1],150*fk+60,.2*(1-u)*(1-u),acc);}
    if(ph<=0&&L.crk>0&&M&&okI(IMG['cursed-glow'])){part(IMG['cursed-glow'],0,.2*E.out(cl(L.crk)));x.globalCompositeOperation='lighter';x.globalAlpha=a0;x.drawImage(FC,C[0]-FB.hx*fk,C[1]-FB.hy*fk,FB.w*fk,FB.h*fk);x.drawImage(FC,C[0]-FB.hx*fk,C[1]-FB.hy*fk,FB.w*fk,FB.h*fk);x.globalCompositeOperation='source-over';}
  }

  /* ── one frame ── */
  const stats={frames:0,ms:0,worst:0};
  function draw(dt){
    const t0=globalThis.performance?.now?.()??0;if(HOLD>0){const u=Math.min(HOLD,dt);HOLD-=u;dt-=u;}advance(dt);const t=now/1000;DT=Math.min(.05,Math.max(.001,t-(LT||t)));LT=t;TT=t;
    // holding still, what it is on, and which branch is lit all ease from one state to the next instead of switching
    L.stA=(L.stA||0)+(L.still-(L.stA||0))*sm(.22);L.onA=(L.onA||0)+((L.on>=0?1:0)-(L.onA||0))*sm(L.on>=0?.3:.14);if(L.on>=0)L.onI=L.on;
    if(L.raceD!=null&&L.raceV)for(const [g,off] of L.raceV){if(g.drop||!g.TP||!g.pathH||g===L.fsel)continue;const d=Math.hypot(g.TP[0]-L.cx,g.TP[1]-L.cy),want=L.raceD+off*Math.sin(PI*cl(L.raceU||0)),da=(d-want)/(.32*g.pathH.len*(g.way==='U'?1.38:1));g.adv=(g.adv||0)+Math.max(-.05,Math.min(.07,da*.6));}
    if(L.creepOn&&!L.still)for(const f of FIL)if(!f.drop&&!f.lunging&&f.cv&&f!==L.fsel)f.adv=Math.min(f.cap??.6,(f.adv||0)+f.cv*DT);
    L.pop*=1-sm(.12);L.jab*=1-sm(.2);L.onPop*=1-sm(.14);L.jolt*=1-sm(.2);L.hbPh+=DT*(3.4+7*L.tens)*(1-L.stA);
    const hb=(Math.pow(.5+.5*Math.sin(L.hbPh),8)+.5*Math.pow(.5+.5*Math.sin(L.hbPh-1.1),10))*(1-L.stA);L.hbV=hb;
    x.setTransform(1,0,0,1,0,0);x.globalAlpha=1;x.globalCompositeOperation='source-over';x.clearRect(0,0,V.cw,V.ch);
    if(L.veil>0){
      x.fillStyle=`rgba(8,5,9,${(.955+.02*L.dread+.015*L.tens)*L.veil})`;x.fillRect(0,0,V.cw,V.ch);
      x.setTransform(V.k,0,0,V.k,V.ox,V.oy);const m=Math.max(1,Math.hypot(V.w,V.h)/Math.hypot(W,H)),g=x.createRadialGradient(640,340,140*m,640,340,780*m);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(.5,`rgba(0,0,0,${.62*cl(L.gut||0)*(1-cl(L.turn))*L.veil})`);g.addColorStop(1,`rgba(0,0,0,${Math.min(1,.5+.4*cl(L.gut||0)*(1-cl(L.turn))+(.3*L.dread+.34*L.tens)*hb)*L.veil})`);x.fillStyle=g;x.fillRect(V.x0,V.y0,V.w,V.h);
    }
    x.setTransform(V.k,0,0,V.k,V.ox,V.oy);
    if(L.all>.01&&L.veil>.01){
      x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';ways();
      // the branches come further in as the curse goes on. The view itself does not move: no going in, no turning; only a
      // short shiver when something is cut or struck
      const live2=1-cl(L.front*1.6);L.edge=(L.edge||0)+(Math.max(.82*cl(L.taint),.18*L.creep)-(L.edge||0))*sm(.05);{const q=Math.floor(cl(L.edge)*4);if(q>(L.edgeQ||0)&&L.veil>.5&&live2>.5)S('edge',{v:q/4});L.edgeQ=q;}
      L.hitA=(L.hitA||0)*(1-sm(.09));
      
      x.save();x.translate(L.jolt*1.1*Math.sin(t*31),L.jolt*.9*Math.cos(t*27));
      // folding into the card or the mark (and growing back out of it): her heart is the pivot and lands on the small gem
      if(L.fold>0){const d=E.io(L.fold),s2=lerp(1,L.fS,d);x.translate(lerp(L.cx,L.fT[0],d),lerp(L.cy,L.fT[1],d));x.scale(s2,s2);x.translate(-L.cx,-L.cy);}
      const A0=(L.fold>0?L.fA:1)*L.all;x.globalAlpha=A0;
      const e=L.e,acc=e?e.acc:MAG,w=way(),pz=L.pose,k=L.sc/SC0,fk=FS*k,ex=((w.edx||0)+(w.trem?1.4*N1(t*8.3):0))*L.mk*pz,ey=(w.edy||0)*L.mk*pz,RC=d=>{const a=t-d-(L.recT??-9);return a>=0&&a<2.2?32*(L.recK||1)*Math.exp(-a*2.6)*Math.cos(a*6.5):0;},rc=RC(0),rcP=RC(.035),bob=3.5*Math.sin(t*.8)*(1-L.stA)*(1-.6*cl(L.turn)),C=[L.cx+ex+rc*(L.recD?L.recD[0]:0),L.cy+ey+rc*(L.recD?L.recD[1]:0)+bob],CP=[L.cx+ex+rcP*(L.recD?L.recD[0]:0),L.cy+ey+rcP*(L.recD?L.recD[1]:0)+bob];
      const tn=L.taint,tcol=(c0,c1)=>c0.map((v,i)=>Math.round(v+(c1[i]-v)*tn)).join(',');
      // (creep) which branch is nearest her heart, named as it changes
      if(L.near===1&&!L.fsel&&pz<=0){let lead=null,cur=null;for(const f of FIL){if(f.drop)continue;if(f.hit)cur=f;if(f.cr>.06&&(!lead||f.cr>lead.cr))lead=f;}
        // (the one named keeps the name until another is clearly past it)
        if(lead&&lead!==cur&&(!cur||lead.cr>cur.cr+.024)){FIL.forEach(q=>q.hit=0);lead.hit=1;L.on=lead.ti;L.onPop=1;S('on',{i:lead.ti});}}
      {let pr=0;for(const f of FIL)if(!f.drop&&f!==L.fsel&&f.pv!=null)pr=Math.max(pr,cl((f.pv-.68)/.16));L.press=(L.press||0)+(pr-(L.press||0))*sm(.3);}
      {const on=L.style==='stalk'&&(L.on>=0||L.fsel||L.sp>.5)&&L.inn>.5?1:0;L.sp=(L.sp||0)+(on-(L.sp||0))*sm(.07);if(L.thS==null)L.thS=L.th;L.thS+=(L.th-L.thS)*sm(.3);}
      L.rr=(L.rr||420)+((228+190*(1-cl(L.nzT||0)))-(L.rr||420))*sm(.4);
      for(const f of FIL){f.hg=(f.hg||0)+((f.hit&&!f.drop?1:0)-(f.hg||0))*sm(f.hit?.16:.08);f.plA=(f.plA||0)+(f.pl-(f.plA||0))*sm(f.pl>(f.plA||0)?.85:.22);const ag=t-f.bt;f.btA=ag>=0&&ag<1.4?Math.exp(-ag*4.5)*(1-Math.exp(-ag*30)):0;}
      // her light, behind her; after, what is in her
      if(L.heartIn>.01){glow(C[0],C[1]+50*fk,430*fk,(.13+.05*hb)*L.heartIn*(1-L.turn)*(1-.4*tn),tcol([255,0,255],[226,20,120]));if(L.turn>0)glow(C[0],C[1]-100*fk,330*fk+40,.2*L.turn,acc);}
      // the tie: out of her, under the word, to them: the same branch, grown along the line between them; the Spans are counted on its thorns
      const B=beadPos(t),TY=B[1],X0=C[0]+52*k,Y0=C[1]+96*k,X1=B[0]-BR0-1,sh=w.shape?w.shape(.5,t)*L.mk*.5:0,TP=pz>0?tieWay(X0,Y0,B[0],TY,BR0+(w.br||0)*L.mk+7,sh,w.loop?lerp(2.2,6.1,L.mk):w.tug?lerp(2.2,3.7,L.mk):w.fray?.5:2.2):null,P=[];if(TP)for(let i=0;i<=NF;i++){along(TP,TP.len*i/NF,O3);P.push([O3[0],O3[1]]);}
      let fx=-1e5;
      if(pz>0&&L.front>0){
        // each state's tie is its own: the Protective's goes all the way round them; the Lusty's is two, twined; the Needy's grips and
        // tugs; the Resentful's bristles and shakes; the Fearful's is stretched thin and trembles; the Intrusive's forks to everyone near
        const kk=e?e.k:'',mk=L.mk,ks=TP.len/(TI.tipx-TIE0),fr=E.io(cl(L.front)),bst=kk==='resentful'?Math.pow(Math.max(0,Math.sin(t*2.3)),10):0,T=tints(),tg=T&&e?T[TAB.indexOf(e)]:null;
        const bendT=kk==='resentful'?(s2=>mk*(1.5+5*bst)*Math.sin(t*38+s2*.05)):kk==='fearful'?(s2=>mk*3.2*N1(t*9+s2*.01)):kk==='needy'?(s2=>mk*7*pulse(t)*Math.sin(PI*cl(s2/TP.len))):null;
        const VC2=coloured(),o={img:VC2&&e?VC2[TAB.indexOf(e)]:null,u0:TIE0,ks,ky:kk==='resentful'?lerp(.24,.31,mk):kk==='fearful'?lerp(.24,.2,mk):.24,flat:false,taper:190,bend:bendT,al:.72},gl=cl(.24+.55*hb+(L.kick&&t-L.kick<.5?Math.exp(-(t-L.kick)*7):0)+.5*bst);
        if(okI(IMG.tie)){
          if(kk==='lusty'&&mk>0){const o2={...o,ky:.27,u0:TIE0+260,ks:TP.len/(TI.tipx-TIE0-260),bend:s2=>mk*17*Math.sin(s2*.021-t*.9)*Math.sin(PI*cl(s2/TP.len)),al:mk};vine(TP,0,fr*TP.len,o2);vine(TP,0,fr*TP.len,{...o2,glow:true,img:tg,al:mk*gl});o.bend=s2=>-mk*9*Math.sin(s2*.021-t*.9)*Math.sin(PI*cl(s2/TP.len));}
          if(kk==='intrusive'&&mk>0&&L.front>=1){for(const j of [-1,1]){along(TP,TP.len*.6,O3);const fxx=O3[0],fyy=O3[1],bx3=B[0]-4,by3=B[1]+j*96*lerp(.4,1,mk),FP=lut([fxx,fyy],[fxx+90,fyy+j*10],[bx3-150,by3+j*30],[bx3-38,by3],40),o3={...o,ky:.3,u0:TIE0+330,ks:FP.len/(TI.tipx-TIE0-330),bend:null,al:mk};vine(FP,0,FP.len*E.io(mk),o3);vine(FP,0,FP.len*E.io(mk),{...o3,glow:true,img:tg,al:mk*gl});}}
          vine(TP,0,fr*TP.len,o);vine(TP,0,fr*TP.len,{...o,glow:true,img:tg,al:gl});}
        else briar(P.slice(0,Math.max(2,Math.round(NF*L.front)+1)),1,.95);
        if(L.front<1){along(TP,fr*TP.len,O3);fx=O3[0];glow(fx,O3[1],20,.5,acc);}else fx=1e5;
        // the Spans: one of its own thorns lit for each
        const TA=TI.thorns.filter(q=>q[0]>TIE0+60&&q[0]<TI.tipx-170&&q[1]>34),nM=Math.max(1,L.max),TS=[];for(let i=0;i<nM;i++){const want=TIE0+60+(TI.tipx-230-TIE0)*(nM>1?i/(nM-1):.5);let best=null;for(const q of TA)if(!TS.includes(q)&&(!best||Math.abs(q[0]-want)<Math.abs(best[0]-want)))best=q;if(best)TS.push(best);}TS.sort((a,b)=>a[0]-b[0]);const nT=Math.max(1,TS.length);
        for(let i=0;i<L.max;i++){const q=TS[i%nT]||[TIE0+200,40],s=TP.len*(.2+.58*(nM>1?i/(nM-1):.5)),g=cl(L.cnt-i);along(TP,s,O3);const px=O3[0],py=O3[1],tx2=px,ty2=py;if(!q)continue;
          const TT2=IMG['tie-thorns'],seg={...o,flat:true,lighter:true,one:true,img:okI(TT2)?TT2:null};
          if(g>0){const pk=g<1?E.out(g):1,fl=g<1?1+.9*Math.sin(PI*g):1;if(false){}else if(!okI(IMG.tie))thorn(px,py+1,PI/2+.1,25*pk);
            glow(tx2,ty2,26*fl,.5*pk,acc);glow(tx2,ty2,11*fl,.9*pk,acc);x.fillStyle=`rgba(255,240,232,${.95*pk})`;x.beginPath();x.moveTo(tx2,ty2-18*fl);x.lineTo(tx2+11.5*fl,ty2);x.lineTo(tx2,ty2+18*fl);x.lineTo(tx2-11.5*fl,ty2);x.closePath();x.strokeStyle='rgba(8,5,9,.95)';x.lineWidth=4;x.stroke();x.fillStyle=`rgba(${acc},${pk})`;x.fill();x.beginPath();x.moveTo(tx2,ty2-8*fl);x.lineTo(tx2+5*fl,ty2);x.lineTo(tx2,ty2+8*fl);x.lineTo(tx2-5*fl,ty2);x.closePath();x.fillStyle=`rgba(255,240,232,${.95*pk})`;x.fill();}
          else if(L.buds>.01||L.spA>.01){const ua=Math.max(L.buds,L.spA);glow(tx2,ty2,20,.9*ua,'8,5,9');x.beginPath();x.moveTo(tx2,ty2-17);x.lineTo(tx2+11,ty2);x.lineTo(tx2,ty2+17);x.lineTo(tx2-11,ty2);x.closePath();x.fillStyle=`rgba(8,5,9,${.95*ua})`;x.fill();x.strokeStyle=`rgba(${acc},${.95*ua})`;x.lineWidth=3.2;x.stroke();}}
      }
      // her flower
      if(L.heartIn>.01||L.starIn>.01)flowerBase(CP,fk,t);
      // the six, one for each state, from the window's edges
      {const ba=L.inn*cl(1.6-pz*1.6);if(ba>.01){const inHer=L.fsel&&L.dk>=1&&L.sp<.5;if(false)for(const f of FIL){const wa=(.05*(f.wg||0)+.08*(f.lg||0))*(1-cl(L.turn*3));if(wa>.004&&f.pathH&&!f.drop){const P0=f.pathH,bx=P0.X[0],by=P0.Y[0],g=x.createRadialGradient(bx,by,40,bx,by,640);g.addColorStop(0,`rgba(${f.e.acc},${wa})`);g.addColorStop(1,`rgba(${f.e.acc},0)`);x.globalCompositeOperation='lighter';x.fillStyle=g;x.fillRect(V.x0,V.y0,V.w,V.h);x.globalCompositeOperation='source-over';if(f.TP&&f.lg>.03){const dx=f.TP[0]-C[0],dy=f.TP[1]-C[1],d=Math.hypot(dx,dy)||1;glow(C[0]+dx/d*70,C[1]+dy/d*70,110,.3*f.lg,f.e.acc);}}}
        for(const f of FIL)if(f!==L.fsel&&f.inn>.01)branch(f,t,ba);if(L.fsel&&(!inHer||L.calmOn))branch(L.fsel,t,ba);serpent(t,ba);x.globalAlpha=A0;}}
      if((L.calmOn||L.drained)&&L.enH!=null&&!(L.turn>0)){L.enS=(L.enS??1)+(Math.pow(Math.max(0,L.enH),.6)-(L.enS??1))*sm(.45);const es=L.enS,pu=.85+.15*Math.sin(t*(3+4*(1-es)));if(es>.02){x.save();x.globalAlpha*=cl(L.heartIn);glow(C[0],C[1],70+260*es,(.1+.3*es)*pu,EN);glow(C[0],C[1],34+96*es,(.14+.3*es)*pu,EN);x.restore();}}
      
      if(L.gaT!=null&&t-L.gaT<.16){const u=(t-L.gaT)/.16,k=u<.45?u/.45:1-(u-.45)/.55;glow(C[0],C[1],150-70*k,.55*k,EN);glow(C[0],C[1],46,.8*k,'255,238,252');}
      lashes(C,t);if(L.heartIn>.01)gem(C,fk,t,acc);barrier(C,t);
      {const ph=cl(L.turn);
      if(false){const P0=L.fsel.pathH,an=P0.A[P0.n],ca=Math.cos(an),sa=Math.sin(an),g=cl((t-L.rimT)/.09),g2=cl((t-L.rimT-.08)/.3),a0=x.globalAlpha,k2=L.sc/SC0,fa=1-.75*cl((ph-.75)/.25);x.lineCap='round';x.lineJoin='round';for(const [lw,col] of [[4,`rgba(8,5,9,.9)`],[1.8,`rgba(${acc},1)`]]){x.globalAlpha=a0*fa;x.strokeStyle=col;x.lineWidth=lw;x.beginPath();x.moveTo(C[0]-ca*46*k2,C[1]-sa*46*k2);const NS=5;for(let i=1;i<=Math.round(NS*g);i++){const u=i/NS,d=-46+96*u+5*N1(i*4.1),j=9*N1(i*2.7+1.3)*(i<NS?1:0);x.lineTo(C[0]+(ca*d-sa*j)*k2,C[1]+(sa*d+ca*j)*k2);}x.stroke();if(false){x.lineWidth=lw*.6;x.beginPath();x.moveTo(C[0],C[1]);const NV=9;for(let i=1;i<=Math.round(NV*g2);i++){const u=i/NV;x.lineTo(C[0]+(i%2?4:-4)*(i<NV?1:0)*k2,C[1]+250*u*k2);}x.stroke();}}x.globalAlpha=a0;}}
      {const ba=L.inn*cl(1.6-pz*1.6)*(1-cl((L.turn-.85)/.15));if(ba>.01&&L.fsel&&L.dk>=1&&L.sp<.5&&!L.calmOn){branch(L.fsel,t,ba);x.globalAlpha=A0;}}
      // each one's name and number, riding beside its branch's end (and holding off from her flower): flared while the curse is
      // on it, struck through once it is cut, eaten letter by letter when devoured
      {const a=L.inn*(1-cl(pz*2));if(a>.01)for(const f of FIL){f.ta+=((f.drop?0:f.hit?1:.6)-f.ta)*sm(.2);if(!f.TP&&!f.LB)continue;if(f===L.fsel&&(L.dk>.5&&!(L.pull>0)))continue;
        if(L.style==='cut'&&L.on===f.ti&&f.hit)f.lbO=(f.lbO||0)+(1-(f.lbO||0))*sm(.2);
        const gone=f.drop?1:0,hot=f.hit&&!gone,nm=f.eat?f.e.n.slice(0,Math.ceil(f.e.n.length*(1-f.dr))):f.e.n,la=a*cl(f.inn*2-1)*(f.eat?.8*(1-.4*f.dr):gone?(1-cl(f.snap*1.5)):hot?1:(L.on>=0&&L.style!=='creep'?(L.style==='noose'?.62:.5):.85))*(1-(f===L.fsel?cl((L.pull||0)*3):(L.focus||0)))*(1-(f.lbO||0))*(L.style==='cut'?1-cl(L.namesOut||0):1);
        if(false){const sa2=a*cl(L.namesOut)*(1-(L.focus||0)*(f===L.fsel?0:1)),sx2=f.TP[0]+Math.cos(f.TP[2])*26,sy2=f.TP[1]+Math.sin(f.TP[2])*26;x.save();x.globalAlpha*=sa2;glow(sx2,sy2,20+8*f.hg,.16+.3*f.hg,f.e.acc);x.restore();sigil(f.e.k,sx2,sy2,24+4*f.hg+6*f.hg*cl(f.adv||0),Math.min(1,sa2*(.9+.2*f.hg)),f.e.acc.split(',').map(v=>Math.round(+v*.7+255*.3)).join(','));}
        // where it sits: off the branch's end, to the outer side; never nearer her heart than LAB
        if(f.TP&&gone&&f.LB&&f.sev){f.LB[1]+=DT*900*cl(f.snap*1.5);}
        if(f.TP&&!gone){let lx=f.TP[0],ly=f.TP[1];if(f.PP){along(f.PP,Math.max(0,(f.lv||0)-(f.way==='U'?150:128)),O3);lx=O3[0];ly=O3[1]+(f.way==='U'?(L.style==='cut'?-52:46):(L.style==='cut'?-54:-30));}
          // (the noose: its end is round the far side of her by then; its name stays out at its own side of the ring)
          if(L.style==='creep'&&f.crO>=.5&&f!==L.fsel){lx=f.TP[0];ly=f.TP[1]-34-(f.way==='D'?30:0);}
          if(L.sp>.02){const q2=f.ang*PI/180;f.MP=[RING[0]+(SR+64)*Math.cos(q2)*1.12,RING[1]+(SR+60)*Math.sin(q2),cl(L.sp)];}
          if(f.MP){const dx=f.MP[0]-RING[0],dy=f.MP[1]-RING[1],d=Math.hypot(dx,dy)||1,w2=f.MP[2];lx=lerp(lx,f.MP[0],w2);ly=lerp(ly,f.MP[1],w2);}const dx=lx-640,dy=ly-CY0,d=Math.hypot(dx,dy)||1;if(d<LAB){lx=640+dx/d*LAB;ly=CY0+dy/d*LAB;}
          lx=Math.max(V.x0+(L.style==='cut'?176:90),Math.min(V.x0+V.w-(L.style==='cut'?176:90),lx));ly=Math.max(L.sp>.5?74:100,Math.min(L.sp>.5?634:612,ly));if(!f.LB)f.LB=[lx,ly];else{f.LB[0]+=(lx-f.LB[0])*sm(.14);f.LB[1]+=(ly-f.LB[1])*sm(.14);}}
        if(la>.01&&nm&&f.LB){const ft=F.caps(fitCaps(f.e.n,(L.style==='creep'&&f.crO>=.5?17:28),2,260));x.font=ft;x.letterSpacing='2px';
          const tw2=x.measureText(f.e.n).width,xl=f.LB[0]-tw2/2+8,ly=f.LB[1];{const a1=x.globalAlpha,cxl=xl+tw2/2-8,wS=tw2+86,sw=300+26*f.ti,kx=wS/sw,kh=.3,T=tints(),u0=TI.tipx-sw-34*((f.ti*3)%5);x.globalAlpha=a1*Math.min(1,la*1.3);glow(cxl,ly-6,tw2*.62+46,.62,'8,5,9');glow(cxl,ly-6,tw2*.4+26,.5,'8,5,9');
            if(okI(IMG.tie)&&!f.eat&&(L.sp>.5||f.MP||(L.style==='creep'&&f.crO>=.5))){const hw=(tw2+70)/2;for(const sd of [-1,1]){x.save();x.translate(cxl,ly+15);x.scale(sd*hw/sw,kh);x.globalAlpha=a1*la*(gone?.5:.95);x.drawImage(IMG.tie,u0,0,sw,TI.h,0,-TI.cy,sw,TI.h);
              if(T&&!gone){x.globalCompositeOperation='lighter';x.globalAlpha=a1*la*cl(.35+.65*f.hg);x.drawImage(T[f.ti],u0,0,sw,TI.h,0,-TI.cy,sw,TI.h);if(f.hg>.3){x.globalAlpha=a1*la*(f.hg-.3);x.drawImage(T[f.ti],u0,0,sw,TI.h,0,-TI.cy,sw,TI.h);}x.globalCompositeOperation='source-over';}x.restore();}}
            x.globalAlpha=a1;if(!gone&&!f.eat&&L.style!=='cut')sigil(f.e.k,xl+Math.max(tw2,themed(f.e.k,f.e.n,0,0,fitCaps(f.e.n,28,2,260),1,t,1,f.e.acc,1,BONE,true))+(f.e.k==='intrusive'?32:f.e.k==='protective'?34:24),ly-9,9.5,la*(.65+.35*f.hg),f.e.acc);}x.save();x.shadowColor='rgba(0,0,0,.95)';x.shadowBlur=9;themed(f.e.k,nm,xl,ly,fitCaps(f.e.n,(L.style==='creep'&&f.crO>=.5?17:28),2,260),la,t,f.side<0?1:-1,f.e.acc,1,L.style==='cut'?BONE.split(',').map((v,i)=>Math.round(+v*.45+(+f.e.acc.split(',')[i])*.55)).join(','):BONE);txt(String(f.ti+1),xl-(f.e.k==='protective'?40:16),ly,F.caps(21),0,BONE,.62*la*(1-f.dr),'right');x.restore();
          }}}
      // them: beads strung on the tie
      if(pz>0){
        if(L.FB)for(const b of L.FB)bead(b.x,BP0[1]+b.dy,b.r,b.p,b.a,0,b.hit);
        if(L.tg>0&&!L.FB){const got=cl((L.front-.9)/.1);
          if(w.fray){const three=[0,1,2].map(j=>people[j]??ANON);for(let j=0;j<3;j++)bead(B[0]-4+(j===1?30:0),B[1]+(j-1)*96*lerp(.4,1,L.mk),j===1?40:32,three[j],L.tg,got,0);txt('ALL WITHIN 15 FT',B[0],B[1]-150,F.sans(11),2.8,BONE,.65*L.tgA);}
          else if(L.tgP){const bx2=lerp(B[0]+90,B[0],E.out(L.tg)),r=BR0+(w.br||0)*L.mk;if(w.br)glow(bx2,B[1],r+34,.55*L.mk,'0,0,0');bead(bx2,B[1],r,L.tgP,1,got,0);
            txt('TOWARD',bx2,B[1]-r-38,F.sans(11),2.8,BONE,.6*L.tgA);txt(L.tgP.n,bx2,B[1]-r-14,F.ital(23),0,BONE,.95*L.tgA);}}}
      // which one it is on, in plain words, under her
      if(L.onA>.02&&L.onI>=0&&pz<=0&&L.turn<.5){const e2=TAB[L.onI],sc2=1,tj=0;x.save();x.setTransform(V.k,0,0,V.k,V.ox,V.oy);x.globalAlpha*=L.onA*(1-cl(L.turn*2));x.translate(640+tj,692+6*(1-L.onA));x.scale(sc2,sc2);x.shadowColor='rgba(0,0,0,.9)';x.shadowBlur=10;txt(L.forced?Wd.onLaid:L.near?Wd.near:Wd.on,0,-36,F.sans(11),2.8,BONE,.62);const rp=fitCaps(e2.n,L.calmOn?40:30,3,540);x.font=F.caps(rp);x.letterSpacing='3px';const tw2=x.measureText(e2.n).width;
        {const mix=BONE.split(',').map((v,i)=>Math.round(+v*.6+(+e2.acc.split(',')[i])*.4)).join(','),tw3=themed(e2.k,e2.n,0,0,rp,1,t,1,e2.acc,1.2,mix,true);themed(e2.k,e2.n,-tw3/2,0,rp,1,t,1,e2.acc,1.2,mix);}txt(String(L.onI+1),-tw2/2-16,0,F.caps(22),0,e2.acc,1,'right');sigil(e2.k,tw2/2+26,-10,9,1,e2.acc);x.strokeStyle=`rgba(${e2.acc},.95)`;x.lineWidth=1.5;x.beginPath();x.moveTo(-tw2/2,11);x.lineTo(tw2/2,11);x.stroke();x.restore();}
      // the word, on the tie between them
      if(e&&L.nameA>.01){const nf=fitCaps(e.n,94,3.4,660),nA=E.out(cl(L.nameA)),kk=e.k,mk=L.mk;x.font=F.caps(nf);x.letterSpacing=(3.4*nf/74)+'px';const nw=x.measureText(e.n).width;
        // its sign, large and faint, behind; a sprig of the thorn beneath, lit in its colour
        const nmv=L.calmOn?E.io(cl((pz-.42)/.58)):1;x.save();x.translate(lerp(640,RX,nmv),lerp(638,NY,nmv));{const st=L.calmOn?(1+.12*(1-E.out(cl(L.nameA))))*(L.calmOn&&pz<=0?.8:lerp(.8,1,nmv)):1;x.scale(st,st);}x.translate(-RX,-NY);
        if(okI(IMG.tie)){const sw=520,u0=TI.tipx-sw,half=(nw*.5+26)*nA,T=tints(),tg=T?T[TAB.indexOf(e)]:null;for(const sd of [-1,1]){x.save();x.translate(RX,NY+30);x.scale(sd*half*.62/sw,.2);x.globalAlpha=A0*cl(L.nameA*2)*(L.calmOn?1-cl(pz*1.5):1);{const VC3=coloured();x.drawImage(VC3?VC3[TAB.indexOf(e)]:IMG.tie,u0,0,sw,TI.h,0,-TI.cy,sw,TI.h);}if(tg){x.globalCompositeOperation='lighter';x.globalAlpha=A0*cl(L.nameA*2)*(.5+.5*hb)*(L.calmOn?1-cl(pz*1.5):1);x.drawImage(tg,u0,0,sw,TI.h,0,-TI.cy,sw,TI.h);}x.restore();}x.globalAlpha=A0;}
        const bst=kk==='resentful'?Math.pow(Math.max(0,Math.sin(t*2.3)),10):0;
        x.save();x.globalAlpha*=cl(L.nameA*3)*(kk==='fearful'?1-.22*mk*(.5+.5*N1(t*6)):1);LAND=L.calmOn?1:cl(L.nameA);
        // (the curse's reach along the name still calls each letter's sound; the name itself is written as its state behaves, in its colour)
        x.save();x.globalAlpha=0;cursedName(e,RX,NY+14*(1-nA),nf,3.4*nf/74,fx,t,1);x.restore();
        {const big=nf/26,mix=BONE.split(',').map((v,i)=>Math.round(+v*.06+(+e.acc.split(',')[i])*.94)).join(','),tw=themed(kk,e.n,0,0,nf,1,t,1,e.acc,big,mix,true);
          if(kk==='resentful'){x.shadowColor='rgba(70,10,6,.95)';x.shadowBlur=0;x.shadowOffsetX=8;x.shadowOffsetY=8;}else{x.shadowColor=`rgba(${e.acc},.6)`;x.shadowBlur=22;}themed(kk,e.n,RX-tw/2,NY+14*(1-nA),nf,1,t,1,e.acc,big,mix);x.shadowOffsetX=kk==='resentful'?4:0;x.shadowColor=kk==='resentful'?'rgba(150,34,16,.98)':'rgba(0,0,0,.9)';x.shadowBlur=kk==='resentful'?0:10;x.shadowOffsetY=kk==='resentful'?4:3;themed(kk,e.n,RX-tw/2,NY+14*(1-nA),nf,1,t,1,e.acc,big,mix);LAND=1;x.shadowBlur=0;x.shadowOffsetY=0;
          }
        x.restore();x.restore();
        if(kk==='lusty'){x.save();x.globalAlpha*=nA*pz;glow(RX,NY-28,nw*.5+60,kk==='lusty'?.1*mk*(.5+.5*Math.sin(t*2.2)):.14*bst,e.acc);x.restore();}

        if(L.calmOn&&!L.forced)txt(String(TAB.indexOf(e)+1),RX,NY-118,F.caps(96),0,e.acc,L.ebA);eyebrow(L.forced?Wd.madeLaid:Wd.made,e.w,e.acc,RX,NY-92,L.ebA);
        const up=L.calmOn&&kk!=='intrusive',ln=wrap(e.d,up?480:L.calmOn?600:740,F.ital(up?20:21));x.save();x.shadowColor='rgba(0,0,0,.9)';x.shadowBlur=8;ln.forEach((s2,i)=>txt(s2,up?RX-30:L.calmOn?RX-50:RX,(up?NY+(ln.length>2?44:58):NY+DY)+i*(up&&ln.length>2?23:28),F.ital(up?(ln.length>2?18:20):21),0,BONE,.84*L.dA));x.restore();const Y2=up?NY+DY-52+Math.max(0,ln.length-2)*14:NY+DY+ln.length*29-14;L.askY=Y2;
        if(L.ask>.01){txt('HOW LONG IT HOLDS',RX,Y2+28,F.sans(11),2.8,BONE,.6*L.ask);txt('Let it root',RX,Y2+60,F.caps(26),3,L.askHot?'255,170,250':'255,120,246',L.ask);x.strokeStyle=`rgba(${MAG},${.7*L.ask})`;x.lineWidth=1;x.beginPath();x.moveTo(RX-58-12*L.askHot,Y2+66);x.lineTo(RX+58+12*L.askHot,Y2+66);x.stroke();}
        if(L.wait2>.01){txt('HOW LONG IT HOLDS',RX,Y2+28,F.sans(10),2.8,BONE,.55*L.wait2);txt(Wd.waitRoot,RX,Y2+54,F.sans(10),2.8,'255,150,248',L.wait2*(.6+.3*Math.sin(t*2.4)));}
        if(L.spA>.01&&L.span>0){const F1=Math.round(80*(1+.16*L.pop));x.font=F.caps(F1);x.letterSpacing='0px';const a=String(L.span),wa=x.measureText(a).width;x.font=F.ital(34);const b=L.span===1?' Span':' Spans',wb=x.measureText(b).width,xs=RX-(wa+wb)/2;
          txt(a,xs,Y2+72,F.caps(F1),0,acc,L.spA,'left');txt(b,xs+wa,Y2+66,F.ital(34),0,BONE,.85*L.spA,'left');if(L.set>0){x.strokeStyle=`rgba(${acc},${.8*L.set*L.spA})`;x.lineWidth=1.2;x.beginPath();x.moveTo(RX-92*L.set,Y2+90);x.lineTo(RX+92*L.set,Y2+90);x.stroke();}}}
      const ha=L.head*cl(1-pz*3)*cl(1-L.dk*3);if(ha>.01){txt(L.forced?Wd.laid:Wd.ask,640,30,F.sans(10),2.8,BONE,.55*ha);txt('The Heart Turned',640,60,F.ital(24),0,BONE,.92*ha);}
      if(L.minBtn>.01){const a=L.minBtn,hx=1196,hy=34,col=L.minHot?'255,170,250':BONE;x.strokeStyle=`rgba(${col},${(.55+.4*L.minHot)*a})`;x.lineWidth=1.4;x.beginPath();x.moveTo(hx+12,hy-4);x.lineTo(hx+26,hy-4);x.stroke();txt(Wd.min,hx,hy,F.sans(10),2.6,col,(.55+.4*L.minHot)*a,'right');txt('ESC',hx,hy+15,F.sans(8),2.4,BONE,.32*a,'right');
        // how loud it is on this page: − quieter (below the quietest: off) · + louder. Only where the page can tell (in Foundry)
        let si=null;try{si=soundInfo?soundInfo():null;}catch{}L.vol=si?1:0;
        if(si){const y=31,n=si.n||5,X0=-164,lit=si.on?si.i+1:0,hot=L.volHot||0,MG='255,170,250';txt(si.on?'SOUND':'SOUND OFF',1112+X0,y+3,F.sans(8),2.2,BONE,.5*a,'right');
          txt('−',1126+X0,y+4,F.sans(15),0,hot<0?MG:BONE,(hot<0?.95:.6)*a,'center');txt('+',1218+X0,y+4,F.sans(15),0,hot>0?MG:BONE,(hot>0?.95:.6)*a,'center');
          for(let i=0;i<n;i++){const bx=1140+X0+i*13,bh=5+2.2*i;if(i<lit){x.fillStyle=`rgba(255,120,236,${.9*a})`;x.fillRect(bx,y+5-bh,8,bh);}else{x.strokeStyle=`rgba(${BONE},${.4*a})`;x.lineWidth=1;x.strokeRect(bx+.5,y+5-bh+.5,7,bh-1);}}}}
      if(L.wait1>.01)txt(Wd.waitRoll,640,694,F.sans(10),2.8,'255,150,248',L.wait1*(.6+.3*Math.sin(t*2.4)));
      if(L.btn>.01){const a=L.btn,y=694,ww=22+12*L.hot;txt('Roll',640,y,F.caps(27),4,L.hot?'255,170,250':BONE,a*(.78+.22*L.hot));x.strokeStyle=`rgba(${MAG},${.75*a})`;x.lineWidth=1;x.beginPath();x.moveTo(640-62-ww,y-8);x.lineTo(640-62,y-8);x.moveTo(640+62,y-8);x.lineTo(640+62+ww,y-8);x.stroke();}
      x.restore();
    }
    const ms=(globalThis.performance?.now?.()??0)-t0;stats.frames++;stats.ms+=(ms-stats.ms)*.1;if(ms>stats.worst)stats.worst=ms;
  }
  /** Which control lies under a point of the stage: 'roll' · 'root' · 'min', or null. */
  function hit(sx,sy){
    if(L.all<.5||L.fold>0)return null;
    if(L.minBtn>.5&&sx>1092&&sx<1240&&sy>10&&sy<60)return 'min';
    if(L.minBtn>.5&&L.vol&&sy>=16&&sy<52){if(sx>918&&sx<986)return 'volDown';if(sx>=986&&sx<1076)return 'volUp';}
    if(L.btn>.5&&Math.abs(sx-640)<120&&Math.abs(sy-688)<26)return 'roll';
    if(L.ask>.5&&Math.abs(sx-RX)<120&&sy>L.askY+32&&sy<L.askY+80)return 'root';
    return null;
  }
  /** Light the control under the pointer (null: none). */
  const hover=name=>{L.hot=name==='roll'?1:0;L.askHot=name==='root'?1:0;L.minHot=name==='min'?1:0;L.volHot=name==='volDown'?-1:name==='volUp'?1:0;};

  /* ── the moments ── */
  /** She appears: her heart, then her flower opening round it; then the six come in from the window's edges. btn: the Roll button too. */
  async function emblemIn(btn,{forced=false,wait:waiting1=false}={}){
    reset();L.forced=forced;S('veil');S('bed',{to:.4,ms:1600});tween(14000,v=>L.creep=.38*v,E.out);tween(700,v=>L.veil=v);await wait(300);tween(600,v=>L.head=v);tween(750,v=>L.heartIn=v,E.out);tween(500,v=>L.minBtn=v);await wait(380);
    tween(1500,v=>L.starIn=v,v=>v<.5?2*v*v:1-Math.pow(-2*v+2,2)/2);for(let i=0;i<6;i++)later(120+i*150,()=>S('filament',{i}));await wait(1250);
    S('briar');L.ringA=1;FIL.forEach((f,i)=>later(i*110,()=>tween(1000,v=>f.inn=v,E.io)));tween(1300,v=>L.ringIn=v);await wait(5*110+900);
    if(btn)await tween(400,v=>L.btn=v);else if(waiting1)await tween(400,v=>L.wait1=v);else await wait(300);K('emblem');
  }
  function crossings(){const Aa=[];for(let lap=0;lap<3;lap++)for(const f of FIL){let d=f.ang;while(d<L.th0+6)d+=360;Aa.push([d+360*lap,f]);}return Aa.sort((a,b)=>a[0]-b[0]);}
  const fwd=(deg,th)=>{let d=deg;while(d<th-1)d+=360;return d;},near=(deg,th)=>deg+360*Math.round((th-deg)/360);
  async function goTo(f,ms,nearest){const d=nearest?near(f.ang,L.th):fwd(f.ang,L.th),th1=L.th;FIL.forEach(q=>q.hit=0);await tween(ms,v=>L.th=lerp(th1,d,v),E.io);f.hit=1;L.on=f.ti;L.onPop=1;L.jab=1;L.gf=(L.gf+1)%4;S('on',{i:f.ti});}
  /** A hold in which everything stops (the breath held): the sound goes down with it. */
  const hush=ms=>{S('hush',{ms});};
  async function cutF(f){f.lsT=nowS();f.lsFail=0;f.lsNick=0;await wait(95);S('cut',{i:f.ti});later(380,()=>{S('wither',{i:f.ti});tween(1100,v=>f.wth=v,E.out);});f.hit=0;f.drop=1;f.sev=1;f.sx=.3+.4*((f.j*.37)%1);L.jolt=.1;tween(220,v=>f.ash=v);tween(560,v=>f.snap=v,E.lin);if(L.style==='cut')later(260,()=>tween(620,v=>f.rt=v,E.io));await wait(L.style==='cut'?150:180);}
  /* ── her roll: the cutting. The result is already known; it plays from a seed, and leaves the
        briar on the one it takes with that filament pulled, for takeE ── */
  /** Its first crossing of a filament after the coil's start, and where the head goes for one without ever unwinding past that start. */
  const lift=deg=>{let d=deg;while(d<L.th0+6)d+=360;return d;};
  const safeFor=f=>{const b=lift(f.ang),c=[b,b+360].filter(d=>d<=L.th0+450);return c.reduce((p,q)=>Math.abs(q-L.th)<Math.abs(p-L.th)?q:p);};
  /** Which filament the head is over now (within a hand's width), or none. */
  const under=()=>{let best=null,bd=1e9;for(const q of FIL){if(q.drop)continue;const dd=Math.abs(((q.ang-L.th)%360+540)%360-180);if(dd<bd){bd=dd;best=q;}}return bd<13?best:null;};
  /** Where a filament crosses the coil now (the noose draws in, so this moves down each filament toward her). */
  const recross=()=>{};
  /** A run of n filaments with no order to it: never the same twice running, the one it will take among them at least
   * `min` times but never last (so the last move is a move), and not so often that it gives itself away. */
  function wander(R,n,tf,min=1){
    const q=[];let last=null;for(let i=0;i<n;i++){const pool=FIL.filter(f=>f!==last);last=pool[Math.floor(R()*pool.length)%pool.length];q.push(last);}
    const other=(a,b)=>{const pool=FIL.filter(f=>f!==tf&&f!==a&&f!==b);return pool[Math.floor(R()*pool.length)%pool.length];};
    if(q[n-1]===tf)q[n-1]=other(q[n-2],null);
    for(let g=0;g<40&&q.filter(f=>f===tf).length<min;g++){const j=Math.floor(R()*(n-1));if(q[j]!==tf&&q[j-1]!==tf&&q[j+1]!==tf)q[j]=tf;}
    for(let j=0,c=0;j<n;j++)if(q[j]===tf&&++c>min+1)q[j]=other(q[j-1],q[j+1]);
    return q;
  }
  async function rollE(target,{style='cut',seed=1}={}){
    const R=rng32(seed);L.style=STAGE_STYLES.includes(style)?style:'cut';tween(300,v=>{L.btn=Math.min(L.btn,1-v);L.wait1=Math.min(L.wait1,1-v);});
    // (in all four her energy goes bad by degrees while it chooses)
    tween(L.style==='cut'?6300:8400,v=>L.taint=v,E.lin);S('bed',{to:1,ms:7000});
    await cutE(target,R);
  }
  /** The cutting: once round fast, then it cuts them away with longer and longer holds, feints at the one it will take,
   * leaves two, and takes the last. About eight and a half seconds. (beta.3: which one is left beside it, and how long it
   * holds over each, differ from one curse to the next.) */
  async function cutE(target,R){
    // (beta.5) The six creep in, with no names on them: each is known by the colour of its thorns and by its sign. One brightens
    // and her light goes for it. The first falls to one stroke. Each after it takes one stroke more, fast, a piece off its end
    // every time, before the stroke that severs it. Going round her once. The last one she cannot cut through at all.
    const order=crossings().slice(0,6).map(c=>c[1]),tf=order.find(f=>f.ti===target),oth0=order.filter(f=>f!==tf),oth=[...oth0.filter(f=>f.side===tf.side&&f.way===tf.way),...oth0.filter(f=>!(f.side===tf.side&&f.way===tf.way))].slice(0,5),light=f=>{FIL.forEach(q=>q.hit=0);f.hit=1;S('on',{i:f.ti});};
    tween(3400,v=>L.tens=.72*v,E.lin);L.on=-1;L.calmOn=1;tween(500,v=>L.namesOut=v);await wait(420);K('r_fast');
    // All six creep in on her at once, each at its own pace, and her light has to choose. A light blow costs her little: it
    // gashes a vine and knocks it back (three gashes and it is through). A heavy blow costs her a great deal and takes a vine
    // off at one stroke: she spends one when a vine has got too near. Which she strikes, and how, has no order to it; the one
    // that will have her is struck and gashed like the rest. Her light runs down with every blow. At the last two come at her
    // together, she has enough for one, and the other goes straight in.
    const sh=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(R()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;},vs=sh(oth.slice()),decoy=vs[4],kinds=sh(['B','wB','www','wwB']).concat([R()<.5?'wB':'wwB']);
    const q=new Map();vs.forEach((f,i)=>q.set(f,kinds[i].split('')));q.set(tf,R()<.55?['w','w']:['w']);const lastB=q.get(decoy).pop(),plan=[];
    for(;;){const live=[...q.keys()].filter(f=>q.get(f).length);if(!live.length)break;let tot=0;const wt=f=>(q.get(f).length+(f===tf?.6:0))*(plan.length<3&&q.get(f)[0]==='B'?3:1)*(plan.length&&plan[plan.length-1][0]===f?1.6:1);for(const f of live)tot+=wt(f);let r=R()*tot,pick=live[0];for(const f of live){r-=wt(f);if(r<=0){pick=f;break;}}plan.push([pick,q.get(pick).shift(),q.get(pick).length===0&&pick!==tf&&pick!==decoy]);}
    {let k=-1;for(let i=plan.length-1;i>=0;i--)if(plan[i][0]===tf){k=i;break;}if(k>=0){const it=plan.splice(k,1)[0];plan.splice(Math.min(plan.length,Math.floor(plan.length*(.68+.3*R()))),0,it);}}plan.push([decoy,lastB,true]);L.planS=plan.map(p=>p[0].ti+p[1]+(p[2]?'!':'')).join(' ');const COST={w:1,B:3.6},total=plan.reduce((a,b)=>a+COST[b[1]],0);let spent=0;const gash=new Map();
    FIL.forEach(f=>{f.hit=0;f.adv=0;f.cv=.07+.16*R();f.cap=.34+.2*R();f.lunging=0;const a1=.3*R();tween(240,v=>{if(!f.lunging&&!f.drop)f.adv=Math.max(f.adv,a1*v);});});L.creepOn=1;L.enH=1;L.en=1;S('strain',{v:.5});await wait(260);
    for(let i=0;i<plan.length;i++){const [f,kind,sever]=plan[i],e=1-spent/total,fin=i===plan.length-1;if(i===0||plan[i-1][0]!==f)S('on',{i:f.ti});
      if(fin){// the last of it: two are left. A breath; both come at her together; she has enough for one
        // the last two are brought level first, the same distance from her heart, and held there for a breath; then they
        // draw back together and go for her together, staying level all the way in (neither is ever plainly ahead)
        {const dd=g=>g.TP?Math.hypot(g.TP[0]-L.cx,g.TP[1]-L.cy):400,sg=R()<.5?1:-1,D1=Math.max(250,(dd(f)+dd(tf))/2);for(const g of [f,tf]){g.lunging=1;}L.raceV=[[f,-10*sg],[tf,10*sg]];L.raceU=0;L.raceD=Math.max(dd(f),dd(tf));tween(300,v=>L.raceD=lerp(L.raceD,D1,v),E.io);
          L.still=1;hush(380);K('r_still');await wait(380);L.still=0;K('r_duel');tween(260,v=>L.tens=.72+.28*v);S('strain',{v:1,last:1});S('edge',{v:1});
          await tween(140,v=>L.raceD=D1+34*v,E.out);const D2=L.raceD;for(const g of [f,tf])g.lg=1;tween(760,v=>{L.raceU=v;L.raceD=D2+(128-D2)*v*v;f.lg=Math.max(f.lg||0,.6);tf.lg=Math.max(tf.lg||0,.6);},E.lin);}
        await wait(620);K('r_race');}
      else if(kind==='B'){S('edge',{v:.4+.5*(1-e)});f.lunging=1;f.lg=.9;const a0=f.adv||0;tween(200,v=>f.adv=a0+(.7-a0)*v,E.out);await wait(150+60*R());}
      if(kind==='B')await strokeF(f,{sever:true,big:true,quick:fin,str:.3+.7*e,off:110+90*R(),gap:fin?0:(R()<.3?70:150+110*R())});
      else{const g=(gash.get(f)||0)+1;gash.set(f,g);await strokeF(f,{sever,part:g/3,str:.22+.5*e,off:90+150*R(),ang:(R()-.5)*1.1,gap:R()<.26?80:140+140*R()});}
      spent+=COST[kind];{const e1=fin?0:1-spent/total;L.enH=e1;const t0=L.tire||0;tween(70,v=>L.tire=t0+((1-e1)-t0)*v);}
      if(i===0)K('r_feint');if(sever&&!L._k1){L._k1=1;K('r_cut');}if(i===Math.floor(plan.length*.6))K('r_last');}
    // she has nothing left, and the other is already on its way in
    L.en=0;L.enH=0;tween(220,v=>L.gut=v);FIL.forEach(g=>g.hit=0);tf.hit=1;L.gf=-1;
  }
  /** One blow of her light on a vine, at the strength she has left. It lands where the vine can be cut. A blow that does not
   * sever leaves a gash (deeper each time) and shakes the vine; the one that severs throws its end clear; one that cannot cut
   * (dud) lands and gutters, and the vine only flares. */
  async function strokeF(f,{sever=false,dud=false,big=false,part=1,gap=110,str=null,quick=false,off=null,ang=0}={}){if(off!=null){f.go=big?(quick?Math.max(off,(f.lv||0)*.36):Math.min(Math.max(off,(f.lv||0)*(.62+.1*(((f.j*.37)%1)))),Math.max(off,(f.lv||0)-270))):off;f.ga=ang;}if(big){L.gaT=nowS();await wait(70);}
    const en=str??L.en??1,te=big?70:60+60*(1-en);f.lsT=nowS();f.lsE=en;if(L.style==='cut'&&!L.fsel)flinch(f,big?.16:.07);f.lsBig=big?1:0;f.lsN=(f.lsN||0)+1;f.lsFail=0;f.lsNick=sever?0:1;f.lsDud=dud?1:0;f.hit=1;await wait(te);f.hitT=nowS();f.hit=0;
    if(dud){S('release',{i:f.ti});f.lg=Math.max(f.lg||0,.75);L.jolt=Math.max(L.jolt,.8);}
    else if(sever){S('cut',{i:f.ti});later(380,()=>{S('wither',{i:f.ti});tween(1100,v=>f.wth=v,E.out);});{const cp=f.CP||[L.cx+200*f.side,L.cy],dx=cp[0]-L.cx,dy=cp[1]-L.cy,d=Math.hypot(dx,dy)||1,sd=(f.lsN||0)%2?-1:1;f.fl=[dx/d*.75-dy/d*.45*sd,dy/d*.75+dx/d*.45*sd];}f.notch=0;f.hit=0;f.drop=1;f.sev=1;f.sx=.3+.4*((f.j*.37)%1);L.ifT=nowS();L.jolt=Math.max(L.jolt,big?2.6:1.4);FIL.forEach(q=>{if(q!==f&&!q.drop){q.t0=nowS();q.A=Math.max(q.A||0,big?6:3);q.tau=.5;}});tween(220,v=>f.ash=v);tween(quick?340:620,v=>f.snap=v,E.lin);later(quick?50:160,()=>tween(quick?280:420,v=>f.rt=v,E.in));freeze(big?80:48);}
    else{S('release',{i:f.ti});f.notch=part;{const lv=f.lv||0,tr=f.trim||0,s1=Math.max(30,lv-tr),s0=Math.max(20,s1-NICK);(f.frags||(f.frags=[])).push({s0,s1,Lv:lv,t0:nowS(),sp:.7+.6*((f.frags.length*.37)%1),dir:(f.lsN||0)%2?-1:1});f.trim=tr+(s1-s0);}f.t0=nowS();f.A=18;f.tau=.45;L.jolt=Math.max(L.jolt,.7);f.adv=Math.max(0,(f.adv||0)-.16);freeze(26);}
    await wait(gap);
  }
  /** Laid on her: no roll. (beta.8) The names go and all six come in on her alike: nothing shows which one was laid on her.
   * She is forced to defend, and a shell of her own light goes up round her crystal. */
  async function strikeE(ti){L.drained=1;L.calmOn=1;L.on=-1;L.enH=1;L.en=1;L.enS=1;L.barHits=[];L.barBrk=null;S('strike');S('bed',{to:.9,ms:3000});tween(500,v=>L.namesOut=v);tween(2600,v=>L.tens=.6*v,E.lin);tween(3600,v=>L.taint=.55*v,E.lin);
    FIL.forEach((q,k)=>{q.hit=0;q.adv=0;q.lunging=1;q.rest=.2+.05*((k*3)%4);tween(620,v=>q.adv=q.rest*v,E.io);});S('strain',{v:.6});later(260,()=>tween(420,v=>L.bar=v,E.out));await wait(760);K('forced');}
  /** Laid on her: all six throw themselves at her shell again and again, in no order, faster as it goes; the one laid on her
   * strikes and is burnt like the rest, so which it is cannot be told. Every blow costs her: the shell shrinks and breaks up,
   * her halo with it, her flower dulls. Every blow costs the vine: her light burns a length off its end and it withers a
   * little more, and a third blow spends it. Four are spent that way. Two are left, each struck twice; a breath; they go for
   * her together. One lands on the last of her shell, breaks it and is spent; the other is the one laid on her, and nothing
   * stands in its way (takeE). The order comes from a seed, so her page and a watching GM's play it alike. */
  async function devourE(ti,seed=977+ti*131){
    const tf=FIL.find(q=>q.ti===ti),R=rng32(seed),sh=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(R()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;},oth=sh(FIL.filter(q=>q!==tf)),decoy=oth[0],spent4=oth.slice(1),EACH=3;
    // each of the six twice and the four that will be spent a third time, shuffled so that none strikes twice running
    let sched=[];for(let tries=0;tries<60;tries++){sched=[...sh(FIL.slice()),...sh([...FIL,...spent4])];let ok=true;for(let i=1;i<sched.length;i++)if(sched[i]===sched[i-1]||(i>1&&sched[i]===sched[i-2])){ok=false;break;}if(ok)break;}
    const TOTAL=sched.length+1;let n=0,at=0;const inside=q=>{if(!q.TP)return false;const [rx,ry]=BARR(cl(L.enS??1));return Math.hypot((q.TP[0]-L.cx)/rx,(q.TP[1]-L.cy)/ry)<=1.04;},cnt=new Map(),lunge=async q=>{q.lg=.9;for(let i=0;i<34&&!inside(q);i++){q.adv=(q.adv||0)+.055;await wait(12);}};K('d_wake');
    const blow=async(q,last)=>{try{
      const k=(cnt.get(q)||0)+1,end=k===EACH;cnt.set(q,k);if(k===1){S('on',{i:q.ti});S('latch',{i:q.ti});}await lunge(q);
      // it lands on her shell
      const tp=q.TP||[L.cx+200*q.side,L.cy],a=Math.atan2((tp[1]-L.cy)/BARR(1)[1],(tp[0]-L.cx)/BARR(1)[0]);n++;const e=last?0:1-n/TOTAL;L.barHits.push({a,t:nowS(),k:.55+.45*(k/EACH),j:q.j,acc:q.e.acc});if(L.barHits.length>24)L.barHits.shift();
      L.enH=e;{const t0=L.tire||0;tween(70,v=>L.tire=t0+((1-e)-t0)*v);}L.jolt=Math.max(L.jolt,end?1.5:.8);flinch(q,end?.12:.06);S(end?'drain':'release',{i:q.ti,v:n/TOTAL});if(end)freeze(34);
      // and her light burns it: a length off its end, and it withers a little more
      {const lv=q.lv||0,tr=q.trim||0,s1=Math.max(30,lv-tr),s0=Math.max(20,s1-36);(q.frags||(q.frags=[])).push({s0,s1,Lv:lv,t0:nowS(),sp:.7+.6*((q.frags.length*.37)%1),dir:k%2?-1:1});q.trim=tr+(s1-s0);}
      q.dnT=nowS();q.dn=k/EACH;q.dnA=1;tween(360,v=>q.dnA=1-v);q.t0=nowS();q.A=16+6*k;q.tau=.42;
      if(last){L.en=0;L.barBrk=nowS();L.bar=0;S('cut',{v:.7});L.jolt=Math.max(L.jolt,2.2);tween(220,v=>L.gut=v);}
      if(!end){const w0=q.wlt||0,a0=q.adv||0;tween(300,v=>q.wlt=w0+(.16*k-w0)*v);tween(170,v=>q.adv=a0+(q.rest-.1-a0)*v,E.out);}
      else{L.gulps.push(nowS());S('wither',{i:q.ti});const w0=q.wlt||0;await tween(820,v=>q.wlt=w0+(1-w0)*v,E.io);q.drop=1;q.sx=.62;tween(520,v=>q.snap=v,E.lin);}
    }catch(e){if(e!==CANCELLED)throw e;}};
    sched.forEach((q,i)=>{later(at,()=>blow(q,false));at+=Math.round(lerp(300,170,i/(sched.length-1))+40*R());});
    await wait(Math.round(at*.22));K('d_latch');await wait(Math.round(at*.33));K('d_feed');await wait(at-Math.round(at*.22)-Math.round(at*.33)+420);
    // two are left. A breath; then both go for her together
    L.still=1;hush(340);K('d_still');await wait(340);L.still=0;S('strain',{v:1,last:1});S('edge',{v:1});tween(240,v=>L.tens=.6+.4*v);
    {const a0=decoy.adv||0,b0=tf.adv||0;await tween(150,v=>{decoy.adv=a0-.12*v;tf.adv=b0-.12*v;},E.out);}
    blow(decoy,true);lunge(tf).catch(e=>{if(e!==CANCELLED)throw e;});for(let i=0;i<60&&L.barBrk==null;i++)await wait(12);K('d_fed');
  }
  /** It has the one: the rest go to ash, it runs down the filament into her heart, her heart turns, and she is drawn aside for the word. */
  async function takeE(ti,o={}){
    const dr=!!L.drained,fast=!!o.fast&&!dr,f=FIL.find(q=>q.ti===ti),sp=fast?.7:1;if(L.style==='cut'){f.gs=null;f.notch=0;}L.fsel=f;L.e=TAB[ti];[L.RT,L.WK]=mkRT();L.hitT=[];f.hit=1;if(f.wlt>0){const w0=f.wlt;tween(110,v=>f.wlt=w0*(1-v));}const calm0=L.style==='cut'&&((!L.forced&&!o.fast)||dr);if(!calm0)L.on=ti;L.still=0;tween(700*sp,v=>L.dread=Math.max(L.dread,v));await wait(fast?260:calm0?0:620);K(o.fast?'f_held':'held');
    // the others fall back the way they came (what was cut is already dead, and goes too)
    if(FIL.some(q=>q!==f&&!q.drop))later(120*sp,()=>S('ash'));S('creep',{on:0});
    FIL.forEach((q,j)=>{if(q===f)return;if(q.drop){if(!(q.rt>0))tween(520*sp,v=>q.rt=v,E.lin);return;}if(calm0)return;later((40+((j*3)%5)*60)*sp,async()=>{try{q.hit=0;q.drop=1;await tween(120*sp,v=>q.ash=v);tween(520*sp,v=>q.snap=v,E.lin);}catch(e){if(e!==CANCELLED)throw e;}});});tween(400,v=>L.btn=Math.min(L.btn,1-v));
    // everything else goes dim. It draws back along its way, then goes in all at once; her heart is struck, she is knocked
    // back and steadies, and for a moment nothing moves
    if(!calm0)tween(300,v=>L.focus=v);await wait((calm0?0:380)*sp);S('take',{i:f.ti});later(calm0?150:320,()=>K(o.fast?'f_snap':'snap'));
    {const calm=calm0,pull=fast?320:460,hold=fast?100:calm?0:170,hit=calm?260:70;S('sear',{ms:pull+hold+hit+200});if(calm){f.lg=1;}await tween(calm?10:pull,v=>L.pull=calm?0:v,v=>{const c=1.7;return 1+(c+1)*Math.pow(v-1,3)+c*Math.pow(v-1,2);});L.still=1;await wait(hold);L.still=0;const d0=L.dk;L.smT=nowS()+.02;{const p0=L.pull;if(calm)f.lg=1;await tween(calm?120:hit,v=>{L.pull=calm?p0*(1-v):1-v;L.dk=lerp(d0,1,v);if(calm)f.lg=1;},calm?(v=>v*v*v):E.in);}L.pull=0;L.dk=1;}
    f.notch=0;f.gs=null;flinch(f,calm0?1.5:1);fpluck(f,L.style==='cut'?14:42,1.2,f.pu);FIL.forEach(q=>{if(q!==f){q.t0=nowS();q.A=Math.max(q.A||0,8);q.tau=.7;}});L.jolt=calm0?9:.3;L.hitA=calm0?.85:.6;if(calm0)tween(50,v=>L.nameA=v,E.lin);L.rimT=nowS();if(false){const q=L.rvF;if(q&&!q.drop){q.hit=0;later(260,()=>{q.drop=1;q.sev=1;q.limp=1;S('ash');tween(430,v=>q.snap=v,E.lin);});later(120,()=>{});later(200,()=>tween(900,v=>q.wth=v,E.out));}}L.crk=.18;tween(240,v=>L.crk=.18+.82*v,E.out);K(o.fast?'f_heart':'heart');freeze(calm0?130:110);await wait(calm0?50:150);
    // and the dark goes through her: down her crystal, out along every petal; the eclipse last. Then one slow beat of what is in her now
    {const t0=L.tens;tween(1400,v=>L.tens=t0*(1-v));}S('turn');S('bed',{to:.3,ms:1800});await tween(fast?1700:calm0?1900:2300,v=>L.turn=v,E.lin);L.pulT=nowS();await wait(calm0?40:200);K(o.fast?'f_turn':'turn');await wait(calm0?0:60);
    if(calm0)await wait(380);tween(900,v=>L.ringA=1-v);tween(520,v=>L.back=v,E.io);{const s0=L.swell;tween(900,v=>L.swell=s0*(1-v));}if(!calm0)later(260,()=>tween(950,v=>L.nameA=v));await tween(1250,v=>{L.pose=v;L.cx=lerp(640,PC[0],v);L.cy=lerp(CY0,PC[1],v);L.sc=lerp(SC0,PS,v);},E.io);
  }
  /** The roll of faith: the people come up on the tie, the light runs along them, slows, and stops on one; the rest fall away. */
  async function faithE(pick){
    const n=people.length,sp=n>1?Math.min(96,420/(n-1)):0;L.FB=people.map((p,i)=>({p,x:BP0[0]-(n-1-i)*sp,a:0,r:Math.min(34,sp*.42||34),hit:0,dy:0}));await tween(400,v=>L.FB.forEach(b=>b.a=v));
    S('bead',{v:0});await wait(420);L.FB[pick].hit=1;S('bead',{v:1});await wait(360);S('beadStop');K('faith');
    const c=L.FB[pick],x0=c.x,r0=c.r;L.FB.forEach(b=>{if(b!==c)tween(520,v=>{b.dy=70*v*v;b.a=1-v;},E.lin);});L.tgP=c.p;await tween(520,v=>{c.x=lerp(x0,BP0[0],v);c.r=lerp(r0,BR0,v);});L.tg=1;L.FB=null;await tween(400,v=>L.tgA=v);
  }
  /** That person comes onto the tie: by the roll of faith (pick ≥ 0 among several), or simply there. */
  async function whoE(them,pick=-1){
    if(way().fray||!them||pick<0||people.length<2){L.tgP=them??null;tween(900,v=>L.tg=v,E.out);tween(700,v=>L.tgA=v);later(380,()=>S('beadStop',{v:.6}));await wait(500);}
    else{await wait(300);await faithE(pick);}
  }
  /** Out of her again: along the tie, under the word, to them. The word is cursed letter by letter as it passes. */
  async function outE(){S('out',{ms:1700});tween(600,v=>L.ebA=v);tween(1700,v=>L.front=v,E.lin);later(900,()=>tween(1000,v=>L.mk=v));later(1000,()=>tween(700,v=>L.dA=v));await wait(1900);K('result');}
  /** "How long it holds": the button. */
  async function askE(max,{wait:idle=false}={}){L.span=0;L.max=max;L.set=0;await tween(450,v=>{if(idle)L.wait2=v;else L.ask=v;});K('ask');}
  /** She let it root: n Spans, counted out as thorns on the tie. */
  async function spansE(n,max){
    L.max=max;L.set=0;tween(260,v=>{L.ask=Math.min(L.ask,1-v);L.wait2=Math.min(L.wait2,1-v);});L.askHot=0;L.kick=nowS();tween(300,v=>L.buds=v);L.spA=1;await wait(420);
    let d=170;for(let i=1;i<=n;i++){L.span=i;L.pop=1;L.kick=nowS();S('thorn',{i,n});await tween(120,v=>L.cnt=i-1+v,E.out);if(i<n){await wait(d);d*=1.36;}}await wait(380);L.pop=1.3;S('set');tween(500,v=>L.buds=1-v);await tween(520,v=>L.set=v);K('span');
  }
  /** Fold all of it into a small gem at a point of the stage (the card's, the mark's). scale: how small it gets there. */
  async function foldE(at,scale,{ms=540,landed=null}={}){
    L.fT=at;L.fS=scale;S('fold');S('bed',{to:0,ms});S('creep',{on:0});const v0=L.veil,h0=L.head,b0=L.minBtn;tween(220,v=>L.minBtn=b0*(1-v));L.fA=1;tween(ms,v=>L.fold=v,E.lin);later(ms*.54,()=>tween(ms*.46,v=>L.fA=1-v));tween(ms,v=>{L.veil=v0*(1-v);L.head=h0*(1-v);});
    await wait(ms*.46);K('fold');await wait(ms*.2);try{landed?.();}catch{}await wait(ms*.48);L.all=0;
  }
  /** It steps aside to the mark once the Spans are set: slower than a minimise, and the dread goes out of the room with it. */
  async function dockE(at,scale,landed){
    L.fT=at;L.fS=scale;S('fold',{v:.6});S('bed',{to:0,ms:1300});const d0=L.dread,b0=L.minBtn;tween(250,v=>L.minBtn=b0*(1-v));tween(900,v=>{L.fold=v;L.fA=cl(1-E.io(v)*1.4);},E.lin);tween(900,v=>L.dread=d0*(1-v));await wait(520);try{landed?.();}catch{}await tween(800,v=>{L.veil=1-v;L.head=1-v;});L.all=0;K('dock');
  }
  /** Minimised part-way through the choosing: skip to the answer. The rest go at once, the briar snaps to the one it was
   * always going to take, and that is held for a beat before it folds away. */
  async function settleE(ti){
    const tf=FIL.find(q=>q.ti===ti);{const b0=L.minBtn;tween(220,v=>L.minBtn=b0*(1-v));}L.jolt=1;L.still=0;S('cut',{v:.7});S('creep',{on:0});
    FIL.forEach(q=>{if(q===tf)return;q.hit=0;q.pl=0;q.lat=0;if(!q.drop){q.drop=1;q.sx=.3+.4*((q.j*.37)%1);}const a0=q.ash,s0=q.snap;tween(200,v=>q.ash=lerp(a0,1,v));tween(520,v=>q.snap=lerp(s0,1,v),E.lin);});
    tf.drop=0;L.sway=0;
    // (beta.3) each way of choosing settles on the one in its own terms: the head goes to it; its briar goes in; the noose bites it
    if(L.style==='noose'&&L.rk<.995){FIL.forEach(q=>q.hit=0);tf.hit=1;L.on=tf.ti;L.onPop=1;L.jab=1;tf.bt=nowS();}
    else if(L.style==='cut')await goTo(tf,220,true);
    else{const th1=L.th,to=safeFor(tf);FIL.forEach(q=>q.hit=0);await tween(220,v=>L.th=lerp(th1,to,v),E.io);tf.hit=1;L.on=tf.ti;L.onPop=1;L.jab=1;}
    if(L.near){L.near=2;FIL.forEach(q=>q.hit=q===tf?1:0);L.on=tf.ti;const c0=tf.cr;tween(220,v=>tf.cr=lerp(c0,Math.max(c0,.9),v));}
    const p0=tf.pl;tween(200,v=>tf.pl=lerp(p0,14,v),E.out);await wait(400);K('settle');
  }
  /** The finished thing, as it stands once it has her (nothing moving in): heart turned, the word cursed, the tie to them. */
  function pose(ti,them,spans=0,max=4){
    reset();const f=FIL.find(q=>q.ti===ti);[L.RT,L.WK]=mkRT();
    Object.assign(L,{veil:0,head:0,heartIn:1,starIn:1,bitsOut:1,fsel:f,e:TAB[ti],dk:1,back:1,turn:1,pose:1,cx:PC[0],cy:PC[1],sc:PS,bits:0,nameA:1,front:1,ebA:1,dA:1,tg:1,tgA:1,tgP:them??null,hitT:Array(24).fill(-9),creep:.38,dread:1,all:1,mk:1,max});
    FIL.forEach(q=>{q.inn=1;if(q===f)q.hit=1;else{q.drop=1;q.ash=1;q.snap=1;}});if(spans)Object.assign(L,{span:spans,cnt:spans,spA:1,set:1});
  }
  /** Open: the small thing grows back into the whole of it. Nothing replays; it is already in her, so it arrives as it is,
   * and the only life in the landing is one shudder down the tie and through the word. */
  async function openE(ti,them,spans,max,at,scale,{forced=false,wait:idle=false}={}){
    pose(ti,them,spans,max);Object.assign(L,{forced,fold:1,fA:0,fT:at,fS:scale,dA:0,spA:0});S('open');S('bed',{to:.3,ms:900});tween(200,v=>L.fA=v);
    tween(760,v=>{L.veil=v;L.head=v;});tween(820,v=>L.fold=1-v,E.lin);later(300,()=>K('grow1'));later(500,()=>K('grow2'));later(400,()=>tween(480,v=>{L.dA=v;if(spans)L.spA=v;}));
    await wait(760);L.kick=nowS();for(let i=0;i<TAB[ti].n.length;i++)later(40+i*42,()=>{L.hitT[i]=TT;});tween(400,v=>L.minBtn=v);if(!spans)await tween(450,v=>{if(idle)L.wait2=v;else L.ask=v;});else await wait(300);K('open');
  }
  /** Go out: the whole view fades (the curse was lifted, or replaced, while it was up). */
  async function fadeE(ms=450){S('bed',{to:0,ms});S('creep',{on:0});const v0=L.veil,a0=L.all;await tween(ms,v=>{L.veil=v0*(1-v);L.all=a0*(1-v);});L.all=0;L.veil=0;}

  reset();
  return {L,V,stats,art,resize,toStage,toPage,draw,hit,hover,cancel,gate,press,waiting,wait,tween,reset,setWords,
    setPeople:list=>{people=Array.isArray(list)?list:[];},get veil(){return L.veil;},get visible(){return L.all>.01&&L.veil>.01;},get posed(){return L.pose>0;},get clock(){return now;},
    emblemIn,rollE,strikeE,devourE,takeE,whoE,outE,askE,spansE,foldE,dockE,settleE,pose,openE,fadeE};
}
