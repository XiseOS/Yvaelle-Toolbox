/** Yvaelle’s Toolbox v11 · Token layer: what her portrait and frame do (pure).
 *
 * Her token acts: the portrait breathes, leans with her bank, glances, is lit
 * by her own wings and nearby light, recoils from blows, warms with healing,
 * shrinks into itself when frightened, fades when she falls, and drains to an
 * outline of its frame when she hides. The frame carries state too: tarnish
 * when badly hurt, warmth after a heal, a flush of the damage colour where she
 * was struck.
 *
 * Port of the approved lab prototype (lab/v11/token/site/token-layer.mjs,
 * sampleTokenLayer) with the same numbers, rewritten to allocate nothing per
 * frame: a Look is created once per token and every sample writes into its
 * fixed slots (Float32Arrays the filter uploads as they are).
 *
 * Rules (unchanged from the lab): only transform, light, tint and masks of
 * HER art, no drawn features; movements stay inside the frame window
 * (≤ 0.06 R ≈ 3 px at 1:1), turns ≤ 6°, portrait scale 0.96–1.01; no squash,
 * no white, no flashes. */
import {FEATURES} from './features.mjs?v=13.0.0-beta.8';
/** The held ghost outline's slow breath at t (s, the page's clock): once she is fully drained it steps at 6 fps.
 * (12.0.0-beta.13) One function for her token layer and for the cloak filter (v11/cloak-filter.mjs), so the outline does not
 * step in strength as a cloak hands her over to the held look: the filter read its breath from the server's clock, wrapped
 * every hour, and her token layer from the page's, so the two were at unrelated points of the breath. */
export const ghostBreath=(t,held=true)=>.88+.12*Math.sin((held?Math.floor(t*6)/6:t)*1.25);

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const easeOut=(x,p=3)=>1-(1-unit(x))**p;
const env=(t,a,i,b,o)=>smooth((t-a)/i)*(1-smooth((t-b)/o));
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const lerp=(a,b,k)=>a+(b-a)*k;

/** The 14 parts, each switchable (from the registry). */
export const TOKEN_PARTS=Object.freeze(Object.fromEntries(FEATURES.get('tokenLayer').parts.map(p=>[p.id,p.name])));
export const ALL_PARTS=Object.freeze(Object.fromEntries(Object.keys(TOKEN_PARTS).map(k=>[k,true])));
export const FRAME_VARIANTS=Object.freeze(['keepsake','vesper','reliquary','filament']);
/** Portrait window radius, as a fraction of the token radius (the frame's band covers the rest). */
export const WINDOW_R=229/256;
/** Damage colours, matched to the wound animations' palettes (0..1). op 0 = a coloured light (screen), 1 = a bruise (multiply). */
const c255=a=>a.map(v=>v/255);
export const DAMAGE_TINT=Object.freeze({
  slashing:{c:c255([240,110,170]),op:0,a:.38,seal:c255([255,214,150])},
  piercing:{c:c255([245,150,175]),op:0,a:.26,seal:null},
  bludgeoning:{c:c255([110,40,96]),op:1,a:.42,seal:null},
  fire:{c:c255([255,124,48]),op:0,a:.36,seal:null},
  cold:{c:c255([104,140,255]),op:0,a:.22,seal:null},
  acid:{c:c255([176,212,70]),op:0,a:.28,seal:null},
  poison:{c:c255([160,190,64]),op:0,a:.26,seal:null},
  force:{c:c255([200,170,255]),op:0,a:.30,seal:null},
  mental:{c:c255([176,100,250]),op:0,a:.30,seal:null},
  void:{c:c255([70,34,110]),op:1,a:.45,seal:null},
  electricity:{c:c255([190,200,255]),op:0,a:.30,seal:null},
});
const GOLD=c255([236,182,104]),WARM=c255([255,196,128]),RIMGOLD=c255([226,146,60]),RIMWARM=c255([236,140,72]),MAGENTA=c255([255,96,236]),COOL=c255([170,184,255]);
const BRUISE_RIM=c255([150,60,130]),BRUISE_RIM2=c255([120,40,100]),FEAR_EDGE=c255([190,120,255]),HIDE_RIM=c255([255,140,236]),REVEAL_BEAD=c255([255,150,236]);
const SHADE_LIGHT=c255([255,214,236]),SHADE_DARK=c255([40,14,40]),FEAR_RING=c255([16,8,30]);
const STARTLE_RIM=c255([170,130,255]),CHEER_BEAD=c255([255,214,150]);

/* ------------------------------------------------------------------ */
/* The Look: fixed slots, written in place                             */
/* ------------------------------------------------------------------ */
export const SLOTS=Object.freeze({shade:3,glow:5,vig:2,rim:6,bead:2});
/** One Look per token, reused every frame. Slot layouts (vec4 each):
 *  shade: dir, a, op(0 soft-light | 1 multiply-side), - · shadeC: r,g,b,-
 *  glow:  kind(0 edge|1 point|2 inner|3 up), x|ang, y|spread, r · glowC: r,g,b,a
 *  vig:   ang, a, op(0 screen|1 multiply), ring · vigC: r,g,b,-
 *  rim:   ang, spread, a, mode(0 add|1 colour) · rimC: r,g,b,-
 *  bead:  ang, a, r, - · beadC: r,g,b,- */
export function createLook(){
  const v=n=>new Float32Array(n*4);
  return {variant:'keepsake',frame:true,
    tok:new Float32Array(4),      // token dx, dy (radii), scale, frame on (1/0)
    por:new Float32Array(4),      // portrait dx, dy, rot, scale
    trot:new Float32Array(4),     // the whole token's (frame's) turn, rad; -, -, -
    col:new Float32Array(4),      // sat, bright, frame brightness, window radius
    tint:new Float32Array(4),     // rgb, a (multiply, cooled)
    mask:new Float32Array(4),     // kind(0 none|1 drain|2 fill), k, ghost alpha, portrait alpha
    frm:new Float32Array(4),      // frame alpha, tarnish, outline alpha, sweep (<0 none)
    shade:v(SLOTS.shade),shadeC:v(SLOTS.shade),glow:v(SLOTS.glow),glowC:v(SLOTS.glow),vig:v(SLOTS.vig),vigC:v(SLOTS.vig),
    rim:v(SLOTS.rim),rimC:v(SLOTS.rim),bead:v(SLOTS.bead),beadC:v(SLOTS.bead),
    n:{shade:0,glow:0,vig:0,rim:0,bead:0}};
}
function reset(L){
  L.tok[0]=0;L.tok[1]=0;L.tok[2]=1;L.tok[3]=L.frame?1:0;
  L.por[0]=0;L.por[1]=0;L.por[2]=0;L.por[3]=1.02;L.trot[0]=0;
  L.col[0]=1;L.col[1]=1;L.col[2]=1;L.col[3]=WINDOW_R;
  L.tint.fill(0);L.mask[0]=0;L.mask[1]=0;L.mask[2]=0;L.mask[3]=1;
  L.frm[0]=1;L.frm[1]=0;L.frm[2]=0;L.frm[3]=-1;
  L.shade.fill(0);L.shadeC.fill(0);L.glow.fill(0);L.glowC.fill(0);L.vig.fill(0);L.vigC.fill(0);L.rim.fill(0);L.rimC.fill(0);L.bead.fill(0);L.beadC.fill(0);
  L.n.shade=L.n.glow=L.n.vig=L.n.rim=L.n.bead=0;
}
const CK=Object.freeze({shade:'shadeC',glow:'glowC',vig:'vigC',rim:'rimC',bead:'beadC'});
const put=(L,k,a,b,c,d,col,ca=0)=>{const i=L.n[k];if(i>=SLOTS[k])return -1;const o=i*4,A=L[k],C=L[CK[k]];A[o]=a;A[o+1]=b;A[o+2]=c;A[o+3]=d;C[o]=col[0];C[o+1]=col[1];C[o+2]=col[2];C[o+3]=ca;L.n[k]=i+1;return i;};
const shade=(L,dir,a,c,op)=>{if(a>.004)put(L,'shade',dir,a,op,0,c);};
const glow=(L,kind,x,y,r,c,a)=>{if(a>.004)put(L,'glow',kind,x,y,r,c,a);};
const vig=(L,ang,c,a,op,ring=0)=>{if(a>.004)put(L,'vig',ang,a,op,ring,c);};
const rim=(L,c,a,ang,spread,mode=0)=>{if(a>.004)put(L,'rim',ang,spread,a,mode,c);};
const bead=(L,ang,c,a,r)=>{if(a>.01)put(L,'bead',ang,a,r,0,c);};

/** Hit recoil: pushed in 60 ms, then a damped return with one small overshoot. */
const recoil=q=>q<0?0:q<.06?easeOut(q/.06,2):Math.exp(-(q-.06)/.17)*Math.cos((q-.06)*TAU/.66);
/** A nervous look: holds, flicks to a side, holds (deterministic in t). */
const fh=n=>{const s=Math.sin(n*91.7+12.3)*43758.5;return s-Math.floor(s);};
function flick(t){const P=1.7,i=Math.floor(t/P),f=t/P-i,h=fh;
  const a=(h(i)-.5)*2,b=(h(i+1)-.5)*2;return lerp(a,b,smooth((f-.72)/.12));}

/** Emote tracks (τ seconds since the emote began), written into one scratch record.
 * With her wings shown only the portrait plays (bow, curious, pray, sigh, shrug,
 * startle: the wings carry the rest). With them off (`full`) all ten play on the
 * portrait AND the frame: its tilt, lift and scale, rim light and pins (the
 * approved wingless lab, lab/v11/wingless/site/token-layer.mjs, same numbers).
 * w (0..1) eases an emote that is giving way back to rest. */
const smoother=x=>{x=unit(x);return x*x*x*(x*(x*6-15)+10);};
const LA_AT=[.28,.78,1.26],LA_AMP=[1,.78,.52];
function bounces(t,at,amp,w){let v=0;for(let k=0;k<at.length;k++){const x=(t-at[k])/w;if(x>0&&x<1){const b=amp[k]*(x<.35?smoother(x/.35):1-smoother((x-.35)/.65));if(b>v)v=b;}}return v;}
const E={dx:0,dy:0,rot:0,scale:0,bright:0,sat:0,shadeDir:0,shadeA:0,liftDir:0,liftA:0,upA:0,upC:null,
  fdx:0,fdy:0,frot:0,fscale:0,frameBright:0,nRim:0,rimC:[null,null,null],rimA:[0,0,0],rimAng:[0,0,0],rimSp:[0,0,0],
  nBead:0,beadAng:[0,0],beadA:[0,0],glowA:0,glowX:0,glowY:0,done:false};
const addRim=(c,a,ang,sp)=>{const i=E.nRim;if(i>=3)return;E.rimC[i]=c;E.rimA[i]=a;E.rimAng[i]=ang;E.rimSp[i]=sp;E.nRim=i+1;};
function emoteTrack(name,t,look,full=false){
  E.dx=E.dy=E.rot=E.scale=E.bright=E.sat=E.shadeA=E.liftA=E.upA=0;E.upC=WARM;E.done=false;
  E.fdx=E.fdy=E.frot=E.fscale=E.frameBright=0;E.nRim=0;E.nBead=0;E.glowA=0;
  const gx=look?.x??-1,gy=look?.y??0;
  switch(name){
    case 'bow':{const k=env(t,0,1.0,1.45,1.3);E.dy=.05*k;E.scale=-.03*k;E.shadeDir=-Math.PI/2;E.shadeA=.26*k;E.done=t>2.8;
      if(full){E.fdy=.03*k;E.fscale=-.02*k;}break;}
    case 'curious':{const k=env(t,0,.6,1.95,.85),take=bump(unit((t-.95)/.32));
      E.rot=-.085*k-.015*take;E.dx=gx*.035*k;E.dy=gy*.02*k;E.liftDir=Math.atan2(gy,gx);E.liftA=.10*k;E.done=t>2.9;
      if(full){E.frot=.06*Math.sign(gx)*k;E.fdx=gx*.012*k;}break;}
    case 'pray':{const k=env(t,0,1.0,2.55,1.05),aura=env(t,.75,.8,2.3,1.0);E.dy=.022*k;E.scale=-.014*k;E.upA=.26*aura;
      addRim(RIMWARM,.22*aura,-Math.PI/2,1.0);addRim(RIMGOLD,.12*aura,Math.PI/2,.8);E.done=t>3.7;
      if(full)E.fdy=.012*k;break;}
    case 'sigh':{const inhale=env(t,0,.5,.5,.45),droop=env(t,.55,.9,1.75,1.4);E.dy=-.016*inhale+.032*droop;E.scale=.006*inhale-.012*droop;E.bright=-.09*droop;E.sat=-.12*droop;E.done=t>3.2;
      if(full){E.fdy=-.01*inhale+.022*droop;E.fscale=-.01*droop;E.frameBright=-.1*droop;}break;}
    case 'shrug':{const up=env(t,0,.3,.62,.38),settle=bump(unit((t-.95)/.75));E.dy=-.03*up+.008*settle;E.rot=.04*up*Math.sin(Math.min(1,t/.62)*Math.PI);E.done=t>1.8;
      if(full){E.fdy=-.03*up+.01*settle;addRim(RIMWARM,.22*up,-Math.PI*.75,.5);addRim(RIMWARM,.22*up,-Math.PI*.25,.5);}break;}
    case 'startle':{const s=unit(t/.11)**.6*(1-smooth((t-.55)/1.45));E.scale=-.025*s;E.bright=.03*s;E.done=t>2.1;
      if(full){const j=unit(t/.08)*(1-smooth((t-.08)/.35));E.dy=-.02*j;E.fscale=-.03*s;E.fdy=-.012*j;addRim(STARTLE_RIM,.3*bump(unit(t/.5)),0,7);}break;}
    // the four the wings carry alone: on the token only when her wings are off
    case 'laugh':{if(!full){E.done=true;break;}
      // Laugh A · Soft chuckle: three easy bounces of the whole token, the face brightens on each
      const e=env(t,0,.3,1.85,.6),B=bounces(t,LA_AT,LA_AMP,.48);
      E.dy=-.012*e-.018*B;E.bright=.025*e+.05*B;E.fdy=-.006*e-.03*B;E.fscale=.006*B;E.liftDir=Math.PI/2;E.liftA=.08*e;
      addRim(RIMWARM,.28*B,-Math.PI*.75,.6);addRim(RIMWARM,.28*B,-Math.PI*.25,.6);addRim(RIMGOLD,.12*e,Math.PI/2,1.4);E.done=t>2.5;break;}
    case 'wave':{if(!full){E.done=true;break;}
      // the frame tilts gently side to side; the portrait follows a beat late
      const e=env(t,0,.35,2.15,.55),w=Math.sin(TAU*unit((t-.1)/2.2)*2.25),w2=Math.sin(TAU*unit((t-.22)/2.2)*2.25);
      E.rot=-.035*w2*e;E.dx=.012*w2*e;E.frot=.075*w*e;E.fdy=-.006*e;E.liftDir=-Math.PI*.25;E.liftA=.08*e;
      addRim(RIMWARM,.2*e*(.6+.4*Math.max(0,w)),-Math.PI*.25,.7);E.done=t>2.8;break;}
    case 'cheer':{if(!full){E.done=true;break;}
      // a warm flare runs round the frame from the crown; she lifts and brightens
      const up=env(t,.05,.3,1.5,.7),fl=bump(unit((t-.18)/1.5)),run=unit((t-.12)/.75);
      E.dy=-.03*up;E.scale=.012*up;E.bright=.07*up;E.sat=.06*up;E.fdy=-.022*up;E.fscale=.012*fl;E.upA=.12*fl;
      addRim(RIMGOLD,.55*fl,0,7);addRim(WARM,.25*fl,-Math.PI/2,1.6);
      if(run>0&&run<1){const a=easeOut(run,2)*Math.PI,ba=.95*bump(run)**.4;E.nBead=2;E.beadAng[0]=-Math.PI/2-a;E.beadAng[1]=-Math.PI/2+a;E.beadA[0]=E.beadA[1]=ba;}
      E.done=t>2.4;break;}
    case 'comfort':{if(!full){E.done=true;break;}
      // she leans toward the ally; warm light on that side
      const k=env(t,0,.7,2.5,.9),sx=gx>=0?1:-1,dir=Math.atan2(gy,gx);
      E.dx=.03*sx*k;E.rot=.05*sx*k;E.dy=.01*k;E.frot=.05*sx*k;E.fdx=.02*gx*k;E.fdy=.02*gy*k;E.liftDir=dir;E.liftA=.16*k;
      addRim(RIMWARM,.34*k*(.85+.15*Math.sin(t*2.4)),dir,1.3);E.glowA=.12*k;E.glowX=Math.cos(dir)*.9;E.glowY=Math.sin(dir)*.9;E.done=t>3.4;break;}
    default:E.done=true;
  }
  return E;
}
/** The portrait's own emotes (wings shown); with her wings off all ten play (EMOTES_FULL). */
export const EMOTES=Object.freeze(['bow','curious','pray','sigh','shrug','startle']);
export const EMOTES_FULL=Object.freeze(['bow','laugh','sigh','shrug','wave','cheer','startle','comfort','curious','pray']);

/**
 * Sample the look for this moment into L (allocates nothing).
 * I: {
 *   t, bank, pitch                 her motion (radians / motion.mjs pitch)
 *   wing:{glow, spread, color}     her wing light: glow ~1 when shown, spread 0..1, colour [r,g,b] 0..1
 *   lights:[{x,y,color,a,r}]       nearby lights, token-local, in token radii (y down)
 *   glance:{x,y,k}                 look direction (unit) and amount
 *   hit:{q,dir:[x,y],type,sev}     q = s since the blow; dir = push direction (unit)
 *   give:{q,gather,fly,n}          she casts a heal: q from cast start
 *   healed:{q,k}                   she is healed
 *   fear, ko, wake, afterglow (0..1), hp (0..1)
 *   emote:{name,tau,look:{x,y}}
 *   hidden:{mode:'hide'|'reveal', q, ghost}   (ghost = owner/GM view)
 * }
 * parts: {partId:bool} (all false when the feature is off). Returns true while something is still moving.
 */
export function sampleTokenLayer(I,parts,L,variant='keepsake'){
  L.variant=variant;L.frame=!!parts.frame;reset(L);
  const t=I.t??0,p=L.por;let moving=false,sat=1,bright=1,tokScale=1,frameBright=1,tarnish=0;
  if(parts.breathe){const b=Math.sin(t*TAU/4.6);p[3]*=1+.007*b;bright*=1+.012*b;moving=true;}
  if(parts.lean){const bk=(I.bank??0)/.21,pt=(I.pitch??0)/.065;p[0]+=.034*bk;p[2]+=.3*(I.bank??0);p[1]+=.018*pt;}
  if(parts.glance&&I.glance?.k>0){const g=I.glance;p[0]+=g.x*.04*g.k;p[1]+=g.y*.028*g.k;p[2]+=g.x*.05*g.k;shade(L,Math.atan2(g.y,g.x),.10*g.k,SHADE_LIGHT,0);}
  // her own wings light her: a magenta rim on both sides (strongest at the shoulders) and a soft light across her face
  const firstEdge=L.n.glow;
  if(parts.wingLight&&I.wing&&(I.wing.glow??0)>.002){const W=I.wing,k=(W.glow??1)*(.72+.28*(W.spread??.5)),c=W.color??MAGENTA,lean=Math.max(-1,Math.min(1,(I.bank??0)/.21));
    glow(L,0,-Math.PI*.75,.9,0,c,.15*k*(1-.35*lean));glow(L,0,-Math.PI*.25,.9,0,c,.15*k*(1+.35*lean));
    shade(L,lean>=0?0:Math.PI,(.05+.10*Math.abs(lean))*Math.min(1,k),c,0);
    rim(L,c,.12*k,-Math.PI*.75,.55);rim(L,c,.12*k,-Math.PI*.25,.55);}
  const edges=L.n.glow;
  if(parts.nearLight&&I.lights)for(let i=0;i<I.lights.length;i++){const l=I.lights[i];if(l.a>.005)glow(L,1,l.x,l.y,l.r??1.2,l.color,l.a);}
  // a blow
  if(I.hit&&I.hit.q>=0&&I.hit.q<3){moving=true;const h=I.hit,q=h.q,sev=h.sev??.4,dx=h.dir?.[0]??-1,dy=h.dir?.[1]??0,r=recoil(q)*(.6+sev);
    // (test.15) a hit moves only her picture inside its ring: her token's outline stays exactly where it is
    if(parts.recoil){p[0]+=dx*.05*r;p[1]+=dy*.05*r;p[2]+=(dx>=0?1:-1)*.045*r;bright*=1-.07*Math.exp(-q/.12)*unit(q/.03);}
    const T=DAMAGE_TINT[h.type];
    if(parts.woundTint&&T){const from=Math.atan2(-dy,-dx),k=unit(q/.05)*Math.exp(-Math.max(0,q-.08)/.42);
      vig(L,from,T.c,T.a*k*(.7+.6*sev),T.op);
      rim(L,T.op===1?BRUISE_RIM:T.c,.75*k,from,.9,1);rim(L,T.op===1?BRUISE_RIM2:T.c,.16*k,from,.7);
      if(T.seal){const s=bump(unit((q-1.35)/.6));if(s>0)rim(L,T.seal,.34*s,from,.5);}}
  }
  // healing she gives: light gathers from her shoulders down the rim to her heart
  if(parts.heal&&I.give&&I.give.q>=0&&I.give.q<6){moving=true;const q=I.give.q,G=I.give.gather??.7,n=I.give.n??2,s=.6+.2*n;
    const gk=env(q,0,G*.8,G+.05,.5),after=smooth((q-G)/.25)*Math.exp(-Math.max(0,q-G-.2)/2.2);
    glow(L,1,0,1.15,1.25,GOLD,.2*gk*s+.08*after);shade(L,Math.PI/2,.16*gk*s,WARM,0);
    const m=unit(q/(G*.95));if(m>0&&m<1){const a=easeOut(m,2)*(Math.PI*.75),ba=.85*bump(m)**.5;bead(L,-Math.PI/2-(Math.PI*.25+a),GOLD,ba,.07);bead(L,-Math.PI/2+(Math.PI*.25+a),GOLD,ba,.07);}
    rim(L,RIMGOLD,.36*gk*s,Math.PI/2,1.2);rim(L,RIMWARM,.22*after,Math.PI/2,2.4);
    const lift=bump(unit((q-G+.05)/.55));p[1]-=.02*lift;p[3]*=1+.006*lift;}
  if(parts.heal&&I.healed&&I.healed.q>=0&&I.healed.q<3){moving=true;const q=I.healed.q,k=(I.healed.k??1)*env(q,0,.35,.9,1.6);
    glow(L,2,0,0,0,WARM,.2*k);rim(L,RIMWARM,.32*k,0,7);bright*=1+.04*k;}
  if(parts.frameStates){
    const hp=I.hp??1;tarnish=Math.max(tarnish,.85*smooth(hp<.4?(.42-hp)/.3:0));
    if(I.healed&&I.healed.q>=0)tarnish*=1-smooth(I.healed.q/.9);
    const ag=I.afterglow??0;if(ag>0){rim(L,RIMWARM,.2*ag,0,7);shade(L,Math.PI/2,.08*ag,WARM,0);}
  }
  if(parts.fear&&I.fear>0){const k=I.fear;moving=true;tokScale*=1-.035*k;sat*=1-.18*k;bright*=1-.07*k;L.tint[0]=COOL[0];L.tint[1]=COOL[1];L.tint[2]=COOL[2];L.tint[3]=.22*k;
    vig(L,0,FEAR_RING,.34*k,1,1);
    p[0]+=.024*k*flick(t);p[2]+=.02*k*flick(t+.4);frameBright*=1-.12*k;
    // the warm wing light is drawn in close: rim light cools
    for(let i=firstEdge;i<edges;i++){const o=i*4;L.glowC[o]=FEAR_EDGE[0];L.glowC[o+1]=FEAR_EDGE[1];L.glowC[o+2]=FEAR_EDGE[2];}}
  if(parts.ko&&I.ko>0){const k=I.ko;sat*=1-.7*k;bright*=1-.34*k;p[3]*=1-.016*k;p[1]+=.02*k;frameBright*=1-.3*k;tarnish=Math.max(tarnish,.45*k);
    for(let i=0;i<L.n.glow;i++)L.glowC[i*4+3]*=1-.85*k;for(let i=0;i<L.n.rim;i++)L.rim[i*4+2]*=1-.85*k;}
  if(parts.ko&&I.wake>0){moving=true;rim(L,RIMWARM,.26*bump(unit(I.wake)),0,7);}
  if(parts.emotes&&I.emote){const em=I.emote,e=emoteTrack(em.name,em.tau,em.look,!!em.full),w=em.w??1;if(!e.done)moving=true;
    if(w>0){
    p[0]+=e.dx*w;p[1]+=e.dy*w;p[2]+=e.rot*w;p[3]*=1+e.scale*w;bright*=1+e.bright*w;sat*=1+e.sat*w;
    shade(L,e.shadeDir,e.shadeA*w,SHADE_DARK,1);shade(L,e.liftDir,e.liftA*w,SHADE_LIGHT,0);
    glow(L,3,0,0,0,e.upC,e.upA*w);if(e.glowA>0)glow(L,1,e.glowX,e.glowY,1.0,WARM,e.glowA*w);
    for(let i=0;i<e.nRim;i++)rim(L,e.rimC[i],e.rimA[i]*w,e.rimAng[i],e.rimSp[i]);
    for(let i=0;i<e.nBead;i++)bead(L,e.beadAng[i],CHEER_BEAD,e.beadA[i]*w,.075);
    // the frame (wings off): tilt, lift and scale of the whole token
    L.tok[0]+=e.fdx*w;L.tok[1]+=e.fdy*w;L.trot[0]+=e.frot*w;tokScale*=1+e.fscale*w;frameBright*=1+e.frameBright*w;}}
  // hiding: the light leaves her face first (centre → rim), passes into the frame and out at the
  // shoulders to the wings; the frame cools to its outline. Revealing runs the other way.
  if(parts.hidden&&I.hidden){const mode=I.hidden.mode,q=I.hidden.q,ghost=I.hidden.ghost!==false;
    if(mode==='hide'&&q>=0){const d=smooth(q/.55),f=smooth((q-.2)/.6);if(q<1.2)moving=true;
      L.mask[0]=1;L.mask[1]=d;L.mask[2]=ghost?.13:0;L.frm[0]=1-f;L.frm[2]=(ghost?.72:0)*f*ghostBreath(t,q>1.2);if(ghost)moving=true;   // (test.2: once drained, the ghost's slow breath steps at 6 fps: ~6 redraws a second held, not ~24)
      const sh=bump(unit((q-.25)/.55));rim(L,HIDE_RIM,.4*sh,-Math.PI*.75,.35);rim(L,HIDE_RIM,.4*sh,-Math.PI*.25,.35);
      sat*=1-.5*d;}
    if(mode==='reveal'&&q>=0){const r=unit(q/.5),f=smooth((q-.15)/.6);if(q<1.2)moving=true;
      if(f<1){L.mask[0]=2;L.mask[1]=f;L.mask[2]=ghost?.13:0;}L.frm[0]=1;L.frm[3]=r<1?easeOut(r,2):-1;L.frm[2]=(ghost?.72:0)*(1-smooth((q-.3)/.5));
      if(r<1){const a=Math.PI*.25+easeOut(r,2)*Math.PI*.75,ba=.9*bump(r)**.4;bead(L,-Math.PI/2-a,REVEAL_BEAD,ba,.08);bead(L,-Math.PI/2+a,REVEAL_BEAD,ba,.08);}
      sat*=lerp(.5,1,f);}
  }
  L.tok[2]=tokScale;L.col[0]=sat;L.col[1]=bright;L.col[2]=frameBright;L.frm[1]=tarnish;
  // (test.8) frame off: the rim lights, beads, tarnish and the hidden outline stay in the look; the filter puts them on
  // the rim of her own token art (v11/token-rim.mjs) and the drawn frame itself is not drawn (tok[3] = 0)
  if(!L.frame)L.frm[0]=0;
  return moving;
}

const SLOT_KEYS=Object.freeze(['shade','glow','vig','rim','bead']),FLAT_KEYS=Object.freeze(['col','tint','mask','frm']);
const ALL_KEYS=Object.freeze(['tok','por','trot','col','tint','mask','frm','shade','shadeC','glow','glowC','vig','vigC','rim','rimC','bead','beadC']);
let dMax=0,dR=1;
const px=(x,y)=>{const v=Math.abs(x-y)*dR;if(v>dMax)dMax=v;},cl=(x,y)=>{const v=Math.abs(x-y)*127.5;if(v>dMax)dMax=v;};
/** How different two looks are (max over the values that move pixels), for skipping redraws a viewer cannot see.
 * Transforms are scaled by `rPx` (her radius in screen pixels) so the answer is in pixels; lights and colours are
 * 0..1 (counted as half-steps of 8-bit colour). Allocates nothing. */
export function lookDelta(A,B,rPx){
  dMax=0;dR=rPx;
  if(A.tok[3]!==B.tok[3]||A.variant!==B.variant)return Infinity;
  for(let i=0;i<3;i++)px(A.tok[i],B.tok[i]);for(let i=0;i<4;i++)px(A.por[i],B.por[i]);px(A.trot[0],B.trot[0]);
  for(let j=0;j<FLAT_KEYS.length;j++){const k=FLAT_KEYS[j];for(let i=0;i<4;i++)cl(A[k][i],B[k][i]);}
  for(let j=0;j<SLOT_KEYS.length;j++){const k=SLOT_KEYS[j];if(A.n[k]!==B.n[k])return Infinity;const a=A[k],b=B[k],ac=A[CK[k]],bc=B[CK[k]];for(let i=0;i<a.length;i++){cl(a[i],b[i]);cl(ac[i],bc[i]);}}
  return dMax;
}
/** Copy a look (into a preallocated one). */
export function copyLook(src,dst){
  dst.variant=src.variant;dst.frame=src.frame;
  for(let j=0;j<ALL_KEYS.length;j++)dst[ALL_KEYS[j]].set(src[ALL_KEYS[j]]);
  for(let j=0;j<SLOT_KEYS.length;j++)dst.n[SLOT_KEYS[j]]=src.n[SLOT_KEYS[j]];return dst;
}
