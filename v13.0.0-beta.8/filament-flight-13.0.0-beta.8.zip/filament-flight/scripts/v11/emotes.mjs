/** Yvaelle’s Toolbox v11 · the emote entry point (api.v11.emote).
 *
 *   api.v11.emote('bow')                     her pinned (or one selected owned) token
 *   api.v11.emote('comfort',{token})         Comfort picks the ally's side by itself
 *   api.v11.emote(token,'laugh')             the older (token, id) order works too
 *
 * The emote is saved on her token, flags.filament-flight.v11Emote = {id,
 * variant, started (the shared server clock), side, ally, key}, as
 * api.wingGesture saves a v7.wingGesture event: every client reads it and
 * draws the same frame (v11/emote-runtime.mjs). variant is 'laugh_a' /
 * 'laugh_b' for Laugh (Settings); side is +1 (ally on her right, as authored)
 * or −1 (mirrored, her left); ally is the token Comfort wraps round or Curious
 * leans toward. Every client then calls Hooks.callAll('filamentFlightEmote',
 * {token, id, variant, side, ally, start, uuid, local}).
 * Settings › Emotes & wheel › Emotes switches the whole feature and each emote. */
import {isOn,partOn,choice} from './features.mjs?v=13.0.0-beta.8';
import {EMOTE_LIST,emoteById,emotePart,emoteVariant,emoteSide,comfortAlly} from '../quick-wheel-model.mjs?v=13.0.0-beta.8';
import {emoteRuntime,EMOTE_FLAG} from './emote-runtime.mjs?v=13.0.0-beta.8';

const ID='filament-flight';
const serverNow=()=>{const t=Number(globalThis.game?.time?.serverTime);return Number.isFinite(t)&&t>0?t:Date.now();};

/** The token an emote plays on: an explicit one, else the quick wheel's (pinned, or the one owned token selected). */
function resolveToken(token,pinned){
  const t=token?.document?token:token?.object??null;if(t)return t;
  return pinned?.()??null;
}
/** Comfort: which side, from the targeted ally or the nearest friendly token beside her. */
export function comfortSideFor(token){
  try{
    const c=token.center,grid=globalThis.canvas?.grid?.size??100;
    const near=(globalThis.canvas?.tokens?.placeables??[]).filter(t=>t!==token&&t.visible!==false&&t.document?.disposition===token.document?.disposition)
      .map(t=>({id:t.id,x:t.center.x,y:t.center.y}));
    const targets=[...(globalThis.game?.user?.targets??[])].filter(t=>t!==token).map(t=>({id:t.id,x:t.center.x,y:t.center.y}));
    const ally=comfortAlly({id:token.id,x:c.x,y:c.y},near,{targets,grid});
    return {side:emoteSide({x:c.x,y:c.y,rotation:token.document?.rotation??0},ally,{size:Math.max(token.w??grid,token.h??grid)}),ally:ally?.id??null};
  }catch{return {side:1,ally:null};}
}
/** Curious: what she looks at: your one target, else the nearest token in sight (6 squares), else straight ahead. */
export function curiousLookFor(token){
  try{
    const c=token.center,grid=globalThis.canvas?.grid?.size??100;
    const near=(globalThis.canvas?.tokens?.placeables??[]).filter(t=>t!==token&&t.visible!==false&&!t.document?.hidden).map(t=>({id:t.id,x:t.center.x,y:t.center.y}));
    const targets=[...(globalThis.game?.user?.targets??[])].filter(t=>t!==token).map(t=>({id:t.id,x:t.center.x,y:t.center.y}));
    return comfortAlly({id:token.id,x:c.x,y:c.y},near,{targets,grid,reach:6})?.id??null;
  }catch{return null;}
}

export function installV11Emotes({getAPI,tokenLayers,pinned,runtime=emoteRuntime}={}){
  const announce=(token,data,local)=>{try{Hooks.callAll('filamentFlightEmote',{token,...data,local});}catch(e){console.error('Yvaelle’s Toolbox | emote hook',e);}};
  async function emote(a,b,c){
    let token,id,opts;
    if(typeof a==='string'){id=a;opts=b??{};token=opts.token;}else{token=a;id=b;opts=c??{};}
    const E=emoteById(id);if(!E)throw new Error(`No emote "${id}". Emotes: ${EMOTE_LIST.map(e=>e.id).join(', ')}.`);
    token=resolveToken(token,pinned);if(!token)throw new Error('Pin her in the HUD, or select her token, first.');
    const doc=token.document;
    if(!isOn('emotes',doc))throw new Error('Emotes are off in Settings › Emotes & wheel.');
    if(!partOn('emotes',emotePart(id),doc))throw new Error(`${E.label} is off in Settings › Emotes & wheel › Emotes.`);
    if(!doc.isOwner)throw new Error('Only her owner (or the GM) can play her emotes.');
    const variant=emoteVariant(id,choice('laughStyle',doc));
    let side=1,ally=null;
    if(E.sided)({side,ally}=opts.side===1||opts.side===-1?{side:opts.side,ally:opts.ally??null}:comfortSideFor(token));
    else if(id==='curious')ally=typeof opts.look==='string'?opts.look:curiousLookFor(token);
    const key=globalThis.foundry?.utils?.randomID?.(12)??Math.random().toString(36).slice(2,14);
    const flag={id,variant,started:serverNow(),side,ally,key};
    // it plays here at once; the saved flag brings it to every other client (the same key: no replay here)
    runtime?.noteFlag(doc,flag,{announce:false});
    announce(token,{id,variant,side,ally,start:flag.started,uuid:doc.uuid},true);
    await doc.setFlag(ID,EMOTE_FLAG,flag);
    return {id,variant,side,via:'flag'};
  }
  /** (test.2 sent emotes over the socket: the saved flag replaces it. Kept so an older client's message is harmless.) */
  function receive(){}
  return Object.freeze({emote,list:()=>EMOTE_LIST.map(e=>({id:e.id,label:e.label,hint:e.hint})),comfortSide:t=>comfortSideFor(t),receive});
}
