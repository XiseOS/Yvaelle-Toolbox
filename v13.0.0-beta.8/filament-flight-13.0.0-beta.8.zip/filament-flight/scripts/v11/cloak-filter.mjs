/** Yvaelle’s Toolbox v11 · Tech cloak: the filter on her meshes.
 *
 * The lab composited her whole figure (token, wings, bits and shadow) in one
 * WebGL pass (lab/v11/cloak/site/cloak-fx.mjs FRAG). In Foundry her pieces are
 * separate meshes on the primary group, sorted between other tokens, so the
 * same shader runs as a PIXI.Filter on EACH of her meshes, with one shared
 * state block (centre, bank, sweep direction, extent, front, time, owner…)
 * written once a frame: every piece computes the same front in her frame, so
 * the sweep crosses all of them as one.
 *
 * The owner/GM ghost behind the front is the classic hidden state:
 *  - kind 1 (a wing layer): a second texture, the same layer painted with the
 *    drain held (v11/shadow-wings.mjs), sampled through the mesh's transform;
 *  - kind 2 (her token): her portrait at 13 % (half saturation) under the
 *    frame's outline at 72 %, exactly the token layer's held hidden look;
 *  - kind 0 (bits, shadows): her own pixels at a ghost strength, lilac.
 * (11.0.0-test.7) The ghost strength (uKind.y) is the alpha the piece is held at once the sweep ends, so
 * the hand-over to plain alpha shows no step: a wing layer's thread ghost at .5 (it was drawn at full
 * strength, then held at .5 on the atlas only, and never on her rig's layers); negative = her own pixels
 * untinted at that strength (the Faint owner view: every piece, wings included, at her token's ghost).
 * (11.0.0-test.8) NOTHING OUTSIDE HER. In test.7 the scanning front, its glow and the shed pixels ran over
 * bare map: her ground shadow (a big soft mesh below a flying token) carried the bright front like any other
 * piece, the glow used her alpha widened by 5 px and amplified, B's panels spilled a whole hex past her outline,
 * and C's drifting pixels were sprites placed from her wing geometry, not from what is drawn. Now:
 *  - every look's output is multiplied by `cover`: this mesh's own input alpha, widened by at most 1.3 scene px
 *    (a rim). Where the mesh drew nothing, the filter writes exactly nothing (premultiplied 0,0,0,0);
 *  - every light (front, glow, fringe, C's shed pixels) is weighted by this mesh's own alpha and by a per-kind
 *    gain (uKind.z: token 1, bits .8, wing layers .5 so stacked layers do not add up, shadows 0: a shadow only fades,
 *    all of it evenly, so no edge crosses the map under her);
 *  - C's shed pixels are drawn in the shader, inside her silhouette (the sprite pool is gone);
 *  - no backdrop: A bends her own pixels only (Foundry's canvas is drawn in several passes; the map behind her
 *    cannot be trusted), and the filter's padding is 3 px (it was 26 px at zoom 1.85).
 * The filter exists only while a sweep or a flicker runs (and, without a token layer, as a static mask on her
 * token while cloaked). */
import {ID} from './features.mjs?v=13.0.0-beta.8';
import {ghostBreath} from './token-layer.mjs?v=13.0.0-beta.8';

export const FRAG=`precision highp float;
varying vec2 vTextureCoord;
uniform sampler2D uSampler;
uniform sampler2D uGhost;
uniform sampler2D uOutline;
uniform vec4 inputSize;
uniform vec4 inputClamp;
uniform vec4 outputFrame;
uniform vec4 uS0;   // centre x, y (px), bank, sweep direction
uniform vec4 uS1;   // extent (px), front, time (s), zoom (px per scene px)
uniform vec4 uS2;   // ghost view (1 owner/detected), variant (0 A, 1 B, 2 C, 3 flicker), tilt, solid (flicker)
uniform vec4 uS3;   // slip, fringe, tremor x, tremor y (px)
uniform vec4 uS4;   // C flicker: shift, split, zone, rate
uniform vec4 uS5;   // C flicker brightness, flicker detail, slip step, fringe alpha scale
uniform vec4 uKind; // kind (0 plain, 1 wing, 2 token), ghost strength (<0: her own pixels, untinted), light gain, outline (0 none, 1 the drawn frame's, 2 her own ring's mask)
uniform vec4 uTexM; // kind 1: global px -> ghost uv (a, b, c, d)
uniform vec4 uTexT; // kind 1: (tx, ty, -, -) · kind 2: token centre x, y, radius, breath
uniform vec4 uTokAx;// kind 2: her token's x and y axes
const vec3 MAG=vec3(.906,.404,.808);
const vec3 TEAL=vec3(.376,.886,.871);
const vec3 LILAC=vec3(.93,.75,.96);
const vec3 LUMA=vec3(.2126,.7152,.0722);
float h21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float vnoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
  return mix(mix(h21(i),h21(i+vec2(1.,0.)),f.x),mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),f.x),f.y);}
vec2 rot(vec2 v,float a){float c=cos(a),s=sin(a);return vec2(c*v.x-s*v.y,s*v.x+c*v.y);}
float hash1(float n){return fract(sin(n*91.7+12.3)*43758.5);}
vec2 uvOf(vec2 P){return (P-outputFrame.xy)*inputSize.zw;}
vec4 herAt(vec2 P){vec2 uv=uvOf(P);if(uv.x<inputClamp.x||uv.y<inputClamp.y||uv.x>inputClamp.z||uv.y>inputClamp.w)return vec4(0.);return texture2D(uSampler,uv);}
vec4 ghostAt(vec2 P){
  if(uS2.x<.5)return vec4(0.);
  if(uKind.x<.5){vec4 v=herAt(P);if(uKind.y<0.)return v*(-uKind.y);vec3 c=v.a>0.?v.rgb/v.a:vec3(0.);float l=dot(c,LUMA);c=mix(vec3(l),c,.5)*.6+LILAC*.4*l;return vec4(c,1.)*v.a*uKind.y;}
  if(uKind.x<1.5){vec2 uv=vec2(uTexM.x*P.x+uTexM.z*P.y+uTexT.x,uTexM.y*P.x+uTexM.w*P.y+uTexT.y);
    if(uv.x<0.||uv.y<0.||uv.x>1.||uv.y>1.)return vec4(0.);return texture2D(uGhost,uv)*uKind.y;}
  vec2 d=P-uTexT.xy;vec2 qt=vec2(dot(d,uTokAx.xy),dot(d,uTokAx.zw))/uTexT.z;
  vec4 v=herAt(P);vec3 c=v.a>0.?v.rgb/v.a:vec3(0.);float l=dot(c,LUMA);c=mix(vec3(l),c,.5);
  float r=length(qt);
  if(uKind.w<1.5){
    vec4 por=vec4(c,1.)*v.a*.13*(uKind.w>.5?1.-smoothstep(.88,.9,r):1.);
    vec4 ol=vec4(0.);if(uKind.w>.5&&r<1.02)ol=texture2D(uOutline,qt*.5+.5)*.72*uTexT.w;
    return ol+por*(1.-ol.a);
  }
  // her own ring: the thin line along her token art's alpha edge (v11/token-rim.mjs), inside her own pixels only
  vec4 por=vec4(c,1.)*v.a*.13;
  float e=r<1.42?texture2D(uOutline,clamp(qt*.5+.5,0.,1.)).g:0.;
  vec4 ol=vec4(LILAC,1.)*e*.5*uTexT.w*step(.004,v.a);   // (.5 = the token layer's held outline on her own ring: .72 × .7)
  return ol+por*(1.-ol.a);
}
// her own alpha round P, 1.3 scene px out: x = the widest (the rim the output may reach), y = a soft field
vec2 coverAt(vec2 P,float a0){float r=1.3*uS1.w;
  float a1=herAt(P+vec2(r,0.)).a,a2=herAt(P-vec2(r,0.)).a,a3=herAt(P+vec2(0.,r)).a,a4=herAt(P-vec2(0.,r)).a;
  return vec2(max(a0,max(max(a1,a2),max(a3,a4))),clamp((a0*.4+(a1+a2+a3+a4)*.15)*1.6,0.,1.));}
void main(){
  vec2 P0=vTextureCoord*inputSize.xy+outputFrame.xy;
  vec2 P=P0-uS3.zw;
  float ang=uS0.z,dirA=uS0.w,E=uS1.x,F=uS1.y,T=uS1.z,Z=uS1.w,V=uS2.y,GN=uKind.z;
  vec2 ql=rot(P-uS0.xy,-ang);
  vec2 D=vec2(cos(dirA),sin(dirA));
  float u=dot(ql,D)/E;
  vec4 H0=herAt(P);
  vec2 cv=coverAt(P,H0.a);
  float fld=cv.y;
  vec4 outc;
  if(GN<.001&&V<2.5){
    /* ---- a shadow (light gain 0): no front, no lines, no light, no edge on the map: the whole shadow thins out evenly with the sweep ---- */
    outc=mix(H0,ghostAt(P),smoothstep(-.75,.75,F));
  }else if(V<.5){
    /* ---- A · refraction edge: a band that bends her own light (never the map) ---- */
    vec2 wq=ql/Z;
    float n1=vnoise(wq*.12+vec2(0.,T*2.2)),n2=vnoise(wq*.12+vec2(7.3,-T*1.7)),n3=vnoise(wq*.04+vec2(T*.5,3.1));
    float s=u-F+(n3-.5)*.06,bw=.10;
    float band=exp(-s*s/(bw*bw));
    float tail=s<0.?exp(s/.14)*.5:0.;
    float wgt=max(band,tail)*smoothstep(.02,.3,fld);
    float lens=-(s/bw)*band*1.7;
    vec2 dL=(D*lens*4.2+(vec2(n1,n2)-.5)*7.*(band+tail))*Z*wgt;
    vec2 d=rot(dL,ang);
    float m=smoothstep(-bw*.55,bw*.4,s);
    vec2 sideV=rot(D,ang)*Z*1.1*band;
    vec4 H=herAt(P+d*1.5);
    H.r=herAt(P+d*1.5+sideV).r;H.b=herAt(P+d*1.5-sideV).b;
    vec4 G=ghostAt(P+d*.5);
    vec4 L=mix(G,H,m);
    float shim=.65+.7*n1;
    float lead=exp(-pow((s-bw*.6)/(bw*.08),2.)),trail=exp(-pow((s+bw*.6)/(bw*.08),2.));
    vec3 glow=(MAG*lead*.55+TEAL*trail*.42)*H0.a*shim;
    float rim=clamp(cv.x-H0.a*.75,0.,1.);
    glow+=mix(TEAL,MAG,smoothstep(-bw,bw,s))*rim*band*.5;
    outc=vec4(L.rgb+glow*GN,L.a);
  }else if(V<1.5){
    /* ---- B · hardlight panels: hexes that turn over and fade, in sequence ---- */
    float Rh=6.4*Z;
    vec2 hp=ql/Rh;
    float cxq=.57735*hp.x-.33333*hp.y,czq=.66667*hp.y,cyq=-cxq-czq;
    float rx=floor(cxq+.5),ry=floor(cyq+.5),rz=floor(czq+.5);
    float ex=abs(rx-cxq),ey=abs(ry-cyq),ez=abs(rz-czq);
    if(ex>ey&&ex>ez)rx=-ry-rz;else if(ey>ez)ry=-rx-rz;else rz=-rx-ry;
    vec2 cc=vec2(1.73205*(rx+rz*.5),1.5*rz),lo=hp-cc;
    float hA=h21(vec2(rx,rz)+.17),hB=h21(vec2(rz,rx)+3.1);
    float uc=dot(cc*Rh,D)/E;
    float k=clamp((F-uc+.03-hA*.12)/.22,0.,1.);
    float kk=k*k*(3.-2.*k),th=kk*3.14159,cth=cos(th),sth=sin(th);
    vec4 L;vec3 glow=vec3(0.);
    if(k<=0.){
      L=H0;
      float pre=clamp((F-uc+.03-hA*.12+.10)/.10,0.,1.);
      L.rgb+=MAG*H0.a*.22*pre*pre*GN;
    }else{
      float axA=dirA+1.5708+(hB-.5)*1.1;
      vec2 ax=vec2(cos(axA),sin(axA)),an=vec2(-ax.y,ax.x);
      float la=dot(lo,an),lb=dot(lo,ax);
      float sc=(1.+.06*sth)*mix(1.,.94,smoothstep(0.,.08,k));
      float ac=max(abs(cth),.0001);
      vec2 src=(an*(la/ac)+ax*lb)/sc;
      float hd=max(abs(src.x),dot(abs(src),vec2(.5,.866)))/.866;
      vec4 G=ghostAt(P);
      L=G;
      if(hd<1.&&k<1.){
        vec4 Hs=herAt(rot((cc+src)*Rh,ang)+uS0.xy);
        vec4 Pn;
        if(cth>0.){Pn=Hs;Pn.rgb*=.6+.4*cth;Pn.rgb+=MAG*Pn.a*.30*sth*GN;}
        else{float ga=clamp(Hs.a*(1.-kk)*1.1,0.,.82)*min(1.,GN*2.);
          vec3 gc=mix(vec3(.18,.05,.16),MAG*.85,.35+.35*sth);
          Pn=vec4(gc*ga,ga);}
        L=Pn+G*(1.-Pn.a)*smoothstep(0.,.5,k);
        float edge=smoothstep(.82,.98,hd)*sth*(.35+.65*step(0.,dot(src,an)*cth));
        float eon=pow(1.-abs(cth),6.);
        float life=sin(3.14159*k);
        glow=(MAG*(.75*edge+1.1*eon)+vec3(1.,.78,.95)*.16*eon)*life*max(Hs.a,H0.a)*GN;
      }
    }
    outc=vec4(L.rgb+glow,L.a);
  }else if(V<2.5){
    /* ---- C · scan dissolve: fine lines, a crisp front that follows her outline, a few shed pixels ---- */
    float pitch=max(2.,1.1*Z);
    float rowF=ql.y/pitch,row=floor(rowF),fr=fract(rowF);
    float hr=h21(vec2(row,7.7)),hb=h21(vec2(floor(row/8.),1.3)),odd=mod(row,2.);
    float along=ql.x/E;
    float cut=F+(hb-.5)*.035+(hr-.5)*.014+(odd-.5)*.03+uS2.z*along;
    float s=u-cut;
    float tick=floor(T*24.);
    float zone=1.-smoothstep(0.,uS4.z,abs(s));
    float glitch=step(uS4.w,h21(vec2(row*.37,tick)))*zone;
    float dxw=(h21(vec2(row,tick+3.))-.5)*uS4.x*Z*glitch;
    vec2 sh=rot(vec2(dxw,0.),ang),ca=rot(vec2(Z*uS4.y,0.),ang)*zone;
    vec4 H=herAt(P+sh);
    H.r=mix(H.r,herAt(P+sh+ca).r,zone);H.b=mix(H.b,herAt(P+sh-ca).b,zone);
    float m=step(0.,s);
    float ahead=(1.-smoothstep(0.,.20,s))*m;
    float lineMask=odd>.5?1.-.5*ahead:1.;
    float behind=(1.-m)*(1.-smoothstep(0.,.07,-s));
    float thin=smoothstep(0.,.25,fr)*smoothstep(1.,.75,fr);
    float linger=(odd<.5?.5:.12)*behind*thin;
    float vis=m*lineMask+linger;
    float fl=1.+uS5.x*zone*m*(h21(vec2(tick,row*.1))-.5)*2.;
    vec4 Hv=H*vis;Hv.rgb*=fl;
    vec4 G=ghostAt(P);
    vec4 L=Hv+G*(1.-vis);   // (the ghost only where she is hidden: never over her still-solid soft edge ahead of the front)
    // the front: one crisp line per row at its cut (about a pixel wide, a short tail behind), on her own pixels;
    // her outline lights a little wider where the front crosses it
    float sp=s*E,wpx=.9*Z+.4;
    float line=sp>=0.?exp(-sp*sp/(wpx*wpx)):exp(sp/(4.*Z))*.55;
    float rim=clamp(cv.x-H0.a*.7,0.,1.);
    vec3 fc=mix(MAG,TEAL,smoothstep(.35,.65,hr))*.8+vec3(.2);
    vec3 glow=fc*line*(H0.a*.85+rim*.9)*(.75+.25*thin);
    float soft=exp(-pow((u-F)/.05,2.));
    glow+=(TEAL*.12+MAG*.07)*soft*H0.a;
    glow+=TEAL*.08*ahead*(1.-odd)*H.a*thin;
    // shed pixels: sparse cells just behind the front that drift back and blink out, only where she was
    float q=max(2.,1.25*Z);
    vec2 gq=ql+D*(T*14.*Z);
    vec2 cell=floor(gq/q);
    vec2 cP=rot((cell+.5)*q-D*(T*14.*Z),ang)+uS0.xy;
    float cu=dot((cell+.5)*q-D*(T*14.*Z),D)/E-F;
    float hc=h21(cell+vec2(3.7,9.1));
    float back=-cu;
    float live=step(.93,hc)*step(0.,back)*(1.-smoothstep(.02,.11,back))*step(.2,fract(hc*57.+T*5.));
    if(live>0.)glow+=mix(MAG,TEAL,step(.5,fract(hc*13.)))*live*herAt(cP).a*.9*uS5.y;
    outc=vec4(L.rgb+glow*GN,L.a);
  }else{
    /* ---- the flicker on a hit while cloaked: back toward solid, a 1 px slip, a faint fringe ---- */
    vec2 Q=P;
    if(uS3.x>.02){float top=-140.*Z,bh=260.*Z/6.,bi=floor((ql.y-top)/bh);
      if(bi>=0.&&bi<6.){float dx=floor((hash1(bi*7.1+uS5.z*3.3)-.5)*2.*1.4*Z*uS3.x+.5);Q+=rot(vec2(dx,0.),ang);}}
    float k=uS2.w;
    vec4 H=herAt(Q)*k;
    vec4 G=ghostAt(P);
    vec4 L=H+G*(1.-H.a);
    vec3 glow=vec3(0.);
    float fr=uS3.y;
    if(fr>.03){float dd=(1.+1.2*fr)*Z*.8;vec2 o=rot(vec2(dd,0.),ang);float A=min(1.,uS5.w*1.6);
      glow+=vec3(1.,.314,.902)*herAt(Q+o).a*.16*fr*A+vec3(.941,.745,.431)*herAt(Q-o).a*.12*fr*A;}
    outc=vec4(L.rgb+glow*GN,L.a);
  }
  // nothing outside her: this mesh's own alpha, widened by 1.3 scene px at most
  gl_FragColor=clamp(outc,0.,1.)*clamp(cv.x*200.,0.,1.);
}`;

/* ------------------------------------------------------------------ */
/* (11.0.0) Nine more looks, in a second program built from the same    */
/* header: D Plumage, E Ink, F Iris, G Starfall, H Ribbons, J Halftone, */
/* L Curtain, M Eclipse, O Aurora (uS2.y = 4 … 12). Same rules as A–C:  */
/* her own pixels only, every light weighted by this mesh's alpha and   */
/* gain, a shadow only thins out. Four of them move her pixels a short   */
/* way (feathers turning, ribbons slipping, dots, streaks): those may    */
/* write inside this mesh's own rectangle where it drew nothing, never   */
/* beyond it (`free`); the others keep the 1.3 px rule.                  */
/* ------------------------------------------------------------------ */
const NEW_LOOKS=`  }else if(V>3.5){
    float p=clamp((F+1.08)/2.16,0.,1.),pe=p*p*(3.-2.*p);
    /* (12.0.0-beta.4) pl: the sweep's progress in time, 0 to 1 at a steady rate (the front F arrives eased, slow at
       both ends; this undoes it). Each look below whose pieces take a while to go (a feather turning, a star going
       out) runs its own front FX over a range wide enough for the first piece to begin after the sweep begins and
       the last piece to FINISH as it ends. Before, they followed F, which stops at her far edge: the pieces of her
       last third were still part way through when the sweep ended, crawled as F slowed, and were cut off there. */
    float pl=acos(clamp(1.-2.*p,-1.,1.))/3.14159265;
    vec2 Dp=vec2(-D.y,D.x);
    vec4 G=ghostAt(P);vec4 L=H0;vec3 glow=vec3(0.);
    const vec3 VIO=vec3(.62,.42,1.);
    if(V<4.5){
      /* ---- D · plumage: her picture in feather-shaped scales; each turns edge-on and is gone, row after row ---- */
      float s=E/5.2;vec2 g=ql/s;float row=floor(g.y);float off=mod(row,2.)*.5;g.x+=off;vec2 id=floor(g),l=fract(g)-.5;vec2 cc=(id+.5-vec2(off,0.))*s;
      float FX=mix(-1.08,1.60,pl);float t=clamp((FX-dot(cc,D)/E+.06-h21(id+.31)*.14)/.5,0.,1.),e=t*t*(3.-2.*t),sx=cos(e*1.5708);
      float fe=sqrt(max(0.,1.-pow(abs(l.y)*2.,2.4)));float hw=.5*sx*mix(1.,fe,smoothstep(0.,.25,t));
      vec4 S=herAt(rot(cc+vec2(l.x/max(sx,.02),l.y)*s,ang)+uS0.xy);
      float inside=mix(1.,1.-smoothstep(hw-.03,hw+.03,abs(l.x)),smoothstep(0.,.06,t));float vis=inside*(1.-smoothstep(.92,1.,t));
      L=S*vis;L.rgb*=1.+.18*sin(3.14159*t);L+=G*(1.-L.a)*smoothstep(.1,.8,t);
      glow=MAG*smoothstep(.45,.95,t)*(1.-smoothstep(.97,1.,t))*(1.-smoothstep(0.,.045,abs(l.x)))*smoothstep(0.,.3,fe)*herAt(rot(cc,ang)+uS0.xy).a*.5;
      free=smoothstep(0.,.05,t)*(1.-step(1.,t));
    }else if(V<5.5){
      /* ---- E · ink: she bleeds away like ink in water; the edge runs soft and dark violet ---- */
      vec2 wq=ql/E;float n=vnoise(wq*3.4+vec2(T*.05,0.))*.6+vnoise(wq*7.1+3.7)*.3+vnoise(wq*15.+9.1)*.1;
      float e=u+(n-.5)*.62,th=mix(-1.50,1.38,pl);
      float k=smoothstep(th-.03,th+.16,e);
      float band=smoothstep(th-.03,th+.07,e)*(1.-smoothstep(th+.07,th+.32,e));
      vec2 fl=rot((vec2(vnoise(wq*4.5+3.),vnoise(wq*4.5+11.))-.5)*E*.07*band,ang);
      vec4 S=(herAt(P+fl)+herAt(P-fl*.5)+herAt(P+fl.yx))/3.;S=mix(H0,S,smoothstep(0.,.4,band));
      vec3 c=S.a>0.?S.rgb/S.a:vec3(0.);c=mix(c,vec3(.16,.06,.26),band*.75);
      L=vec4(c,1.)*S.a*k;L+=G*(1.-L.a)*(1.-k);
    }else if(V<6.5){
      /* ---- F · iris: a hardlight aperture closes over her, inside her own outline; when its blades clear she is gone ---- */
      float a1=smoothstep(0.,.78,p),a2=smoothstep(.78,1.,p);float r=E*1.4*(1.-a1*a1*(3.-2.*a1)*1.02),th=a1*1.1;
      float dist=length(ql),an=atan(ql.y,ql.x)+th,seg=.8975979,la=mod(an,seg)-seg*.5;float edge=r*cos(.4487990)/cos(la);
      float open=1.-smoothstep(edge-1.2*Z,edge+1.2*Z,dist);
      L=H0*open*(1.-a2);
      float ringK=(1.-smoothstep(0.,E*.42,dist-edge))*(1.-open)*(1.-a2);
      vec4 pane=vec4(vec3(.09,.03,.13),1.)*H0.a*.55*ringK;
      L=L+pane*(1.-L.a);L+=G*(1.-L.a)*(1.-open);
      float sa=an+seg*.5-(dist-edge)/E*2.1;float seam=(1.-smoothstep(0.,1.3*Z,abs(mod(sa,seg)-seg*.5)*dist))*(1.-open)*(1.-smoothstep(0.,E*.7,dist-edge));
      float rim=1.-smoothstep(0.,1.5*Z,abs(dist-edge));
      glow=MAG*(seam*.45+rim*.85)*max(H0.a,fld*.6)*(1.-a2)*smoothstep(0.,.06,p);
    }else if(V<7.5){
      /* ---- G · starfall: she draws in to small stars in her own shape, and they go out one by one ---- */
      float s=E/7.5;vec2 g=ql/s,id=floor(g);vec2 hh=vec2(h21(id+.13),h21(id+7.77));vec2 sp=(id+.2+.6*hh)*s;
      float hm=herAt(rot(sp,ang)+uS0.xy).a;
      float FX=mix(-1.12,1.84,pl);float t=clamp((FX-dot(sp,D)/E+.1-h21(id+3.)*.3)/.62,0.,1.);
      float gather=smoothstep(0.,.5,t),gone=smoothstep(.62,1.,t);
      vec2 q=ql-sp;float rr=s*(.85*(1.-gather)+1.6*(1.-smoothstep(0.,.03,t)));/* (beta.4: her whole cell until its turn begins; the disc alone left the cell's corners out from the first frame) */float keep=1.-smoothstep(rr-1.2*Z,rr+1.2*Z,length(q));
      vec4 S=herAt(rot(sp+q/max(1.-gather*.6,.2),ang)+uS0.xy);
      float v=keep*(1.-smoothstep(.45,.55,t));
      L=S*v;L.rgb=mix(L.rgb,MAG*L.a,gather*.5);L+=G*(1.-L.a)*smoothstep(.2,.6,t);
      float tw=.75+.25*sin(T*5.+h21(id+1.7)*20.);float star=hm*smoothstep(.25,.5,t)*(1.-gone)*tw;
      float dq=length(q)/s;float core=exp(-dq*dq*90.);
      float ray=exp(-abs(q.x)/s*26.)*exp(-abs(q.y)/s*5.)+exp(-abs(q.y)/s*26.)*exp(-abs(q.x)/s*5.);
      glow=(mix(MAG,vec3(1.,.82,.98),core)*core*1.1+VIO*ray*.28)*star;
      free=step(.004,star*(core+ray));
    }else if(V<8.5){
      /* ---- H · ribbons: slanted ribbons slip off along their own length, alternate ones the other way, thinning to threads ---- */
      vec2 ax=vec2(.8776,.4794),ay=vec2(-.4794,.8776);float w=E/6.;
      float vv=dot(ql,ay)+sin(dot(ql,ax)/E*4.2)*E*.013;float bnd=floor(vv/w),lv=fract(vv/w)-.5;float dr=mod(bnd,2.)<.5?1.:-1.;
      float FX=mix(-1.50,2.14,pl);float t=clamp((FX-(bnd+.5)*w/E*dot(ay,D)-dot(ql,ax)/E*dot(ax,D)*.35+.08-h21(vec2(bnd,3.))*.2)/.6,0.,1.),e=t*t*t;
      float thin=1.-smoothstep(.1,.8,t);
      vec2 src=ql-ax*(e*E*.55*dr)-ay*(lv*w*(1./max(thin,.05)-1.));
      vec4 S=herAt(rot(src,ang)+uS0.xy);float inb=mix(1.,1.-smoothstep(.5*thin-.03,.5*thin+.03,abs(lv)),smoothstep(0.,.08,t));/* (beta.4: no seams between ribbons that have not begun) */
      L=S*inb*(1.-smoothstep(.9,1.,t));L+=G*(1.-L.a)*smoothstep(.1,.7,t);
      glow=MAG*(1.-smoothstep(0.,.06,abs(abs(lv)-.5*thin)))*S.a*smoothstep(.05,.3,t)*(1.-smoothstep(.8,1.,t))*.45;
      free=smoothstep(0.,.05,t)*(1.-step(1.,t));
    }else if(V<9.5){
      /* ---- J · halftone: she breaks into a screen of dots that shrink away across her ---- */
      float s=E/11.;vec2 g=vec2(.7071*(ql.x-ql.y),.7071*(ql.x+ql.y))/s;vec2 id=floor(g),l=fract(g)-.5;vec2 cg=(id+.5)*s;vec2 cc=vec2(.7071*(cg.x+cg.y),.7071*(cg.y-cg.x));
      float FX=mix(-1.07,1.47,pl);float t=clamp((FX-dot(cc,D)/E+.05)/.5,0.,1.);
      float rad=mix(.80,0.,t*t*(3.-2.*t));vec4 S=herAt(rot(cc,ang)+uS0.xy);
      float dt_=1.-smoothstep(rad-.06,rad+.06,length(l));
      float on=smoothstep(0.,.12,t);
      vec4 Dd=S*dt_;Dd.rgb+=MAG*Dd.a*.25*smoothstep(.5,.95,t);
      L=mix(H0,Dd,on)*(1.-smoothstep(.97,1.,t));L+=G*(1.-L.a)*smoothstep(.15,.7,t);
      free=on*(1.-step(1.,t));
    }else if(V<10.5){
      /* ---- L · curtain: two wing-shaped veils close over her from both sides and meet in a seam that draws shut ---- */
      /* (12.0.0-beta.4) on the sweep's steady clock pl: the veils close over its first 72 %, then the seam draws shut
         at one speed and is gone before the end. Before, both ran on the front eased twice over, so the seam's last
         stretch took over a second and seemed to hang. */
      float xa=abs(dot(ql,D)),yy=clamp(dot(ql,Dp)/(E*1.15),-1.,1.);float c1=smoothstep(0.,.72,pl);
      float hw=E*1.2*(1.-c1)+E*.16*sin(3.14159*c1)*(1.-yy*yy)-E*.05*sin(3.14159*c1)*yy;
      /* (12.0.0-beta.16) the veils' soft edge is 1.2 px either side of hw, so with hw at 0 a line of her, half there, was left
         along the seam until the sweep ended (her real game: 1.8 to 2.2 % of her at the hand-over). They close a little past the middle. */
      hw-=1.3*Z*smoothstep(.6,.72,pl);
      float in_=1.-smoothstep(hw-1.2*Z,hw+1.2*Z,xa);
      L=H0*in_;
      float veil=(1.-in_)*(1.-smoothstep(0.,E*.5,xa-hw))*(1.-smoothstep(.70,.94,pl));
      vec4 vl=vec4(vec3(.11,.05,.17),1.)*H0.a*.5*veil;L=L+vl*(1.-L.a);L+=G*(1.-L.a)*(1.-in_);
      float line=(1.-smoothstep(0.,1.4*Z,abs(xa-hw)))*(1.-smoothstep(.70,.75,pl));
      float seamLen=E*(1.-clamp((pl-.72)/.23,0.,1.));float seam=(1.-smoothstep(0.,1.2*Z,xa))*(1.-smoothstep(seamLen-2.*Z,seamLen,abs(dot(ql,Dp))))*smoothstep(.66,.72,pl)*(1.-smoothstep(.93,.96,pl));
      float rib=(1.-smoothstep(0.,1.*Z,abs(fract((xa-hw)/(E*.12)+.5)-.5)*E*.12))*veil;
      glow=(MAG*(line*.85+seam*.9)+VIO*rib*.22)*max(H0.a,fld*.6);
    }else if(V<11.5){
      /* ---- M · eclipse: a shadow like a moon's crosses her; behind its edge she is gone; a thin corona runs along that edge ---- */
      float RR=E*1.5;vec2 mc=D*(-RR*2.08*(1.-pe))+Dp*(-RR*.25*(1.-pe));float dd=length(ql-mc);
      float inside=1.-smoothstep(RR-1.5*Z,RR+1.5*Z,dd);
      L=H0*(1.-inside);L+=G*(1.-L.a)*inside;
      float pen=smoothstep(RR-E*.5,RR,dd)*inside*(1.-smoothstep(.9,1.,pe));
      vec4 sh=vec4(vec3(.08,.04,.14),1.)*H0.a*.45*pen;L=sh+L*(1.-sh.a);
      float cor=(1.-smoothstep(0.,1.6*Z,abs(dd-RR)))*smoothstep(.02,.1,pe)*(1.-smoothstep(.92,1.,pe));
      glow=mix(MAG,vec3(1.,.8,.97),.3)*cor*.9*max(H0.a,fld*.6);
    }else{
      /* ---- O · aurora: her light is drawn upward in long soft streaks that thin and fade, column after column ---- */
      float colw=max(1.5*Z,E/110.);float cx=floor(ql.x/colw);
      float FX=mix(-1.10,1.83,pl);float t=clamp((FX-u+.08-h21(vec2(cx,1.))*.14)/.75,0.,1.),e=t*t*(3.-2.*t);
      float len=E*.62*e;vec3 acc=vec3(0.);float hit=0.,ws=0.;
      for(int j=0;j<12;j++){float f=float(j)/11.;vec4 S=herAt(rot(ql+vec2(sin(ql.y/E*9.+T*2.)*E*.006*f,len*f),ang)+uS0.xy);float w=(1.-f)*(1.-f);
        vec3 c=S.a>0.?S.rgb/S.a:vec3(0.);c=mix(c,mix(MAG,VIO,f),min(1.,f*1.6+e*.5));acc+=c*S.a*w;hit+=S.a*w;ws+=w;}
      float al=clamp(hit/ws*mix(1.,2.2,smoothstep(0.,.3,t)),0.,1.)*(1.-smoothstep(.55,1.,t));vec3 c=hit>0.?acc/hit:vec3(0.);
      float own=H0.a*(1.-smoothstep(.1,.6,t));
      vec3 hc=H0.a>0.?H0.rgb/H0.a:vec3(0.);
      float aa=max(al,own);L=vec4(mix(c,hc,own>0.?clamp(own/max(aa,.001),0.,1.)*(1.-smoothstep(0.,.5,t)):0.),1.)*aa;L=mix(H0,L,smoothstep(0.,.1,t));L+=G*(1.-L.a)*smoothstep(.2,.8,t);/* (beta.4: exactly her until her column's turn: the streaks' 2.2x gain used to brighten all of her wings the moment the cloak began, and drop back when it ended) */
      free=smoothstep(0.,.05,t)*(1.-step(1.,t));
    }
    outc=vec4(L.rgb+glow*GN,L.a);
`;
/** The second program: the header and the shadow branch of FRAG, the nine new looks, FRAG's flicker. */
export const FRAG2=(()=>{
  const head=FRAG.slice(0,FRAG.indexOf('  }else if(V<.5){')),tail=FRAG.slice(FRAG.indexOf('  }else{\n    /* ---- the flicker'));
  return head.replace('if(GN<.001&&V<2.5){','float free=0.;\n  if(GN<.001&&(V<2.5||V>3.5)){')+NEW_LOOKS+tail.replace('gl_FragColor=clamp(outc,0.,1.)*clamp(cv.x*200.,0.,1.);','gl_FragColor=clamp(outc,0.,1.)*mix(clamp(cv.x*200.,0.,1.),1.,clamp(free,0.,1.));');
})();
/** Which program a variant index runs in (0: A, B, C; 1: the nine added in 11.0.0). The flicker (3) is in both. */
export const familyOf=v=>v>3.5?1:0;
/** Extra room (as a share of her extent) for the looks that move her pixels a short way. */
export const REACH=Object.freeze({4:0,7:0,8:.3,9:.06,12:.34});
/** One state block for all her filters (Float32Arrays shared by reference: written once a frame). */
export function createCloakState(){
  return {s0:new Float32Array(4),s1:new Float32Array([50,-1.08,0,1]),s2:new Float32Array([0,2,0,0]),s3:new Float32Array(4),
    s4:new Float32Array([2,.25,.065,.93]),s5:new Float32Array([.14,1,0,0])};
}

/** The filter's padding at a zoom (px): room for the 1.3 scene px rim and nothing more. */
export const PADDING=Z=>Math.ceil(1.3*(Z||1))+2;
/** Per-kind light gain: stacked wing layers must not add up to a brighter front than her token's; a shadow never glows. */
export const LIGHT_GAIN=Object.freeze({token:1,wing:.5,plain:.5,bits:.8,compact:.8,shadow:0});
/** What apply() saw (the self-check's diagnostic line), kept per blend mode the pass ran with.
 * (11.0.0-test.9) test.8 printed only the very last pass, and on a real table that read "blend 26" (ERASE), "×?".
 * The filter is built with NORMAL and nothing here changes it; a pass with another blend mode is one the host asked
 * for (Foundry can draw a token's mesh a second time with ERASE to cut it out of another layer: it sets the last
 * filter's blend mode for that pass and puts it back). Such a pass must be left alone, so the blend mode is NOT
 * pinned in apply(); the passes are counted per blend mode instead, and each keeps what it was given:
 *   by[blend] = {n, w, h (the pooled input texture, a power of two), fw, fh (the filter frame inside it), res (the
 *   input's resolution: the one really used), own (this filter's own resolution, null = the target's), ms, clear,
 *   kind, gl (the GL blend function of the draw, read once when `probe` > 0)}. */
export const LAST={clear:null,blend:null,res:null,w:0,h:0,by:{},probe:0};
/** Forget the counts (the self-check, before a sweep). */
export function resetLast(probe=0){LAST.by={};LAST.probe=probe;}
let FilterClass=null;
/** The filter class (built from Foundry's PIXI on first use). */
export function cloakFilterClass(PIXI=globalThis.PIXI){
  if(FilterClass)return FilterClass;
  FilterClass=class CloakFilter extends PIXI.Filter{
    /** kind: 'plain' | 'wing' | 'token'; state: createCloakState() (shared). */
    constructor(state,kind='plain',{ghost=.3,gain=null,family=0}={}){
      super(undefined,family?FRAG2:FRAG,{uGhost:PIXI.Texture.EMPTY,uOutline:PIXI.Texture.EMPTY,
        uS0:state.s0,uS1:state.s1,uS2:state.s2,uS3:state.s3,uS4:state.s4,uS5:state.s5,
        uKind:new Float32Array([kind==='wing'?1:kind==='token'?2:0,ghost,gain??(kind==='token'?1:kind==='wing'?.5:.8),0]),uTexM:new Float32Array([0,0,0,0]),uTexT:new Float32Array(4),uTokAx:new Float32Array([1,0,0,1])});
      // (11.0.0-test.6) the shared block is `block`: PIXI.Filter#state is the WebGL render state (blend mode).
      // test.5 overwrote it with this block, so a cloak filter drew WITHOUT blending: alone on a mesh (her wings,
      // bits and shadow) every transparent pixel of its rectangle came out opaque black, over the map.
      // (On her token the token layer's filter runs last and blends, which hid it there.)
      this.kind=kind;this.family=family;this.block=state;this.mesh=null;this.ghostTexture=null;this.outline=null;this.applied=0;
      // (test.8) no backdrop: the filter reads and writes her own pixels only
      this.rim=null;
      this.blendMode=PIXI.BLEND_MODES?.NORMAL??0;
    }
    /** Where her mesh is on the render target, read each pass from its world transform (read only: no change notices). */
    apply(filterManager,input,output,clearMode){
      const m=this.mesh,u=this.uniforms,K=u.uKind,Z=this.block.s1[3]||1;
      // (11.0.0) the looks that move her pixels get room for it, in this mesh's own rectangle
      const reach=this.family?REACH[Math.round(this.block.s2[1])]??0:0;this.padding=PADDING(Z)+(reach?Math.ceil(reach*(this.block.s1[0]||0)):0);
      if(m&&!m.destroyed){
        const wt=m.worldTransform,tex=m.texture,w=tex?.orig?.width??tex?.width??1,h=tex?.orig?.height??tex?.height??1,ax=m.anchor?.x??.5,ay=m.anchor?.y??.5;
        if(this.kind==='wing'){
          const det=wt.a*wt.d-wt.b*wt.c||1e-9,ia=wt.d/det,ib=-wt.b/det,ic=-wt.c/det,id=wt.a/det,itx=(wt.c*wt.ty-wt.d*wt.tx)/det,ity=(wt.b*wt.tx-wt.a*wt.ty)/det;
          // global px → local (texture px from the anchor) → ghost uv
          u.uTexM[0]=ia/w;u.uTexM[1]=ib/h;u.uTexM[2]=ic/w;u.uTexM[3]=id/h;u.uTexT[0]=itx/w+ax;u.uTexT[1]=ity/h+ay;
          if(this.ghostTexture&&u.uGhost!==this.ghostTexture)u.uGhost=this.ghostTexture;
        }else if(this.kind==='token'){
          const lx=(.5-ax)*w,ly=(.5-ay)*h,xl=Math.hypot(wt.a,wt.b)||1,yl=Math.hypot(wt.c,wt.d)||1;
          u.uTexT[0]=wt.a*lx+wt.c*ly+wt.tx;u.uTexT[1]=wt.b*lx+wt.d*ly+wt.ty;u.uTexT[2]=Math.max(1,Math.min(xl*w,yl*h)/2);
          u.uTokAx[0]=wt.a/xl;u.uTokAx[1]=wt.b/xl;u.uTokAx[2]=wt.c/yl;u.uTokAx[3]=wt.d/yl;
          // (12.0.0-beta.13) the held outline's breath, on the clock her token layer breathes by (token-layer.mjs ghostBreath)
          u.uTexT[3]=ghostBreath((globalThis.performance?.now?.()??0)/1000);
          // the drawn frame's outline, or (frame off) the line along her own token art's edge
          const ol=this.outline?.valid!==false&&this.outline?this.outline:null,rm=!ol&&this.rim?.valid!==false&&this.rim?this.rim:null,tx=ol??rm;
          K[3]=ol?1:rm?2:0;if(tx&&u.uOutline!==tx)u.uOutline=tx;
        }
      }
      this.applied++;const bm=this.state.blendMode;LAST.clear=clearMode;LAST.blend=bm;LAST.res=this.resolution;LAST.w=input?.width??0;LAST.h=input?.height??0;
      const rec=LAST.by[bm]??={n:0,gl:null},ff=input?.filterFrame;rec.n++;rec.w=LAST.w;rec.h=LAST.h;rec.fw=ff?.width??0;rec.fh=ff?.height??0;
      rec.res=input?.resolution??input?.baseTexture?.resolution??null;rec.own=this.resolution??null;rec.ms=input?.multisample??input?.framebuffer?.multisample??0;rec.clear=clearMode;rec.kind=this.kind;
      filterManager.applyFilter(this,input,output,clearMode);
      if(LAST.probe>0&&!rec.gl){LAST.probe--;try{const gl=filterManager.renderer.gl;rec.gl=[gl.isEnabled(gl.BLEND)?1:0,gl.getParameter(gl.BLEND_SRC_RGB),gl.getParameter(gl.BLEND_DST_RGB),gl.getParameter(gl.BLEND_SRC_ALPHA),gl.getParameter(gl.BLEND_DST_ALPHA)];}catch{rec.gl=[-1];}}
    }
  };
  return FilterClass;
}
export {ID};
