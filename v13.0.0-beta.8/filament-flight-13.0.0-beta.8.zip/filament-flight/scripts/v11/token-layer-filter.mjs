/** Yvaelle’s Toolbox v11 · Token layer: the one filter pass on her token mesh.
 *
 * Everything the token layer draws happens in this fragment shader, in one
 * pass over her token as Foundry rendered it:
 *  - the portrait moves inside a fixed window (breath, lean, glance, recoil,
 *    emotes), with saturation and brightness;
 *  - light: soft-light shades, her wing light and nearby light (screen), a
 *    cooling tint, damage vignettes, the hidden drain/fill mask;
 *  - the frame: base and tarnish crossfaded, the hidden outline, rim lights
 *    from the glow mask (added, or as colour), the reveal sweep and the
 *    beads that ride the rim.
 * The frame lives inside her token's own circle, so it needs no sprite of its
 * own: it sorts exactly as her token does (under the front wings, over the
 * back ones) and nothing about her token's transform or bounds changes, so
 * Foundry's perception and occlusion never hear of it (the beta.36 lesson).
 * Frame textures are loaded once per style and shared by every token.
 * (11.0.0-test.8) The drawn frame is a choice, off by default: her token art has its own ring. With it off the
 * same rim lights, beads, tarnish and hidden outline are drawn on the rim of her own picture (v11/token-rim.mjs),
 * inside her own pixels, so nothing reads as a second ring. */
import {SLOTS,WINDOW_R} from './token-layer.mjs?v=13.0.0-beta.8';
import {ID} from './features.mjs?v=13.0.0-beta.8';

export const FRAG=`precision highp float;
varying vec2 vTextureCoord;
uniform sampler2D uSampler;
uniform vec4 inputSize;
uniform vec4 inputClamp;
uniform vec4 outputFrame;
uniform sampler2D uBase;
uniform sampler2D uTarnish;
uniform sampler2D uGlowMask;
uniform sampler2D uOutline;
uniform sampler2D uRimMask;
uniform vec4 uRimG;
uniform vec4 uGeo;
uniform vec4 uAxX;
uniform vec4 uAxY;
uniform vec4 uTok;
uniform vec4 uPor;
uniform vec4 uTkR;
uniform vec4 uCol;
uniform vec4 uTint;
uniform vec4 uMask;
uniform vec4 uFrm;
uniform vec4 uShade[${SLOTS.shade}];
uniform vec4 uShadeC[${SLOTS.shade}];
uniform vec4 uGlow[${SLOTS.glow}];
uniform vec4 uGlowC[${SLOTS.glow}];
uniform vec4 uVig[${SLOTS.vig}];
uniform vec4 uVigC[${SLOTS.vig}];
uniform vec4 uRim[${SLOTS.rim}];
uniform vec4 uRimC[${SLOTS.rim}];
uniform vec4 uBead[${SLOTS.bead}];
uniform vec4 uBeadC[${SLOTS.bead}];
const float TAU=6.28318531;
const vec3 LUMA=vec3(.2126,.7152,.0722);
vec3 softLight(vec3 b,vec3 s){
  vec3 d=mix(sqrt(b),((16.0*b-12.0)*b+4.0)*b,step(b,vec3(.25)));
  return mix(b-(1.0-2.0*s)*b*(1.0-b),b+(2.0*s-1.0)*(d-b),step(vec3(.5),s));
}
vec3 setLum(vec3 c,float l){vec3 o=c+(l-dot(c,LUMA));float lo=dot(o,LUMA),mn=min(o.r,min(o.g,o.b)),mx=max(o.r,max(o.g,o.b));
  if(mn<0.0)o=lo+(o-lo)*lo/max(lo-mn,1e-4);if(mx>1.0)o=lo+(o-lo)*(1.0-lo)/max(mx-lo,1e-4);return o;}
float stops3(float t,float a0,float t1,float a1){t=clamp(t,0.0,1.0);return t<t1?mix(a0,a1,t/t1):mix(a1,0.0,(t-t1)/(1.0-t1));}
float turnFrom(float ang,float from){return fract((ang-from)/TAU);}
vec4 sampleArt(vec2 a){
  vec2 P=uGeo.xy+uAxX.xy*(a.x*uGeo.z)+uAxY.xy*(a.y*uGeo.z);
  vec2 uv=(P-outputFrame.xy)*inputSize.zw;
  if(uv.x<inputClamp.x||uv.y<inputClamp.y||uv.x>inputClamp.z||uv.y>inputClamp.w)return vec4(0.0);
  return texture2D(uSampler,uv);
}
void main(){
  vec2 P=vTextureCoord*inputSize.xy+outputFrame.xy,d=P-uGeo.xy;
  vec2 q=vec2(dot(d,uAxX.xy),dot(d,uAxY.xy))/uGeo.z;
  // (the whole token: moved, turned (v11 emotes with her wings off) and scaled)
  vec2 q0=q-uTok.xy;float tc=cos(-uTkR.x),ts=sin(-uTkR.x);
  vec2 qt=vec2(tc*q0.x-ts*q0.y,ts*q0.x+tc*q0.y)/uTok.z;
  float r=length(qt),aa=1.5/uGeo.z,ang=atan(qt.y,qt.x);
  bool framed=uTok.w>0.5&&uGeo.w>0.5;
  // the portrait, moved inside its window
  vec2 pa=qt-uPor.xy;float cr=cos(-uPor.z),sr=sin(-uPor.z);pa=vec2(cr*pa.x-sr*pa.y,sr*pa.x+cr*pa.y)/uPor.w;
  // (test.8) frame off: her own ring (the rim band of her token art, found once per picture) stays still;
  // only the picture inside it moves. band = that rim, edge = the thin line along her art's alpha edge.
  bool own=!framed&&uRimG.y>0.5;float band=0.0,edge=0.0;
  vec4 art;
  if(own){
    // (test.15) inside her own ring the picture moves most at its centre and not at all where it meets the ring, so the
    // moved picture never leaves a sliver of the unmoved one beside it (that read as her token doubled when she was hit)
    float ri=max(.2,uRimG.x-uRimG.z*.5);pa=mix(qt,pa,1.0-smoothstep(.5,1.0,r/ri));
    vec2 m0=qt*.5+.5,m1=pa*.5+.5;vec4 k0=(m0.x<0.0||m0.y<0.0||m0.x>1.0||m0.y>1.0)?vec4(0.0):texture2D(uRimMask,m0);
    float i1=(m1.x<0.0||m1.y<0.0||m1.x>1.0||m1.y>1.0)?0.0:texture2D(uRimMask,m1).b;
    band=k0.r;edge=k0.g;art=mix(sampleArt(qt),sampleArt(pa),k0.b*i1);}
  else art=sampleArt(pa);
  float alpha=art.a;vec3 rgb=alpha>0.0?art.rgb/alpha:vec3(0.0);
  float lum=dot(rgb,LUMA);rgb=mix(vec3(lum),rgb,uCol.x)*uCol.y;
  if(framed)alpha*=1.0-smoothstep(uCol.w-aa,uCol.w+aa,r);
  for(int i=0;i<${SLOTS.shade};i++){vec4 s=uShade[i];if(s.y<.004)continue;
    float u=(dot(qt,vec2(cos(s.x),sin(s.x)))+1.0)*.5;vec3 c=uShadeC[i].rgb;
    if(s.z<.5){vec3 lc=u<.5?mix(vec3(60.0,20.0,60.0)/255.0,vec3(.5),u/.5):mix(vec3(.5),c,(u-.5)/.5);
      float la=u<.5?mix(s.y*.8,0.0,u/.5):mix(0.0,min(1.0,s.y*2.0),(u-.5)/.5);rgb=mix(rgb,softLight(clamp(rgb,0.0,1.0),lc),la);}
    else{float la=max(0.0,(u-.55)/.45)*s.y;rgb=mix(rgb,rgb*c,la);}}
  if(uTint.a>.004)rgb*=mix(vec3(1.0),uTint.rgb,min(1.0,uTint.a*3.0));
  for(int i=0;i<${SLOTS.glow};i++){vec4 g=uGlow[i],gc=uGlowC[i];if(gc.a<.004)continue;float v=0.0;
    if(g.x<.5){vec2 e=vec2(cos(g.y),sin(g.y))*.98;v=stops3(length(qt-e)/(.62*g.z),gc.a*1.6,.4,gc.a*.55);}
    else if(g.x<1.5){v=stops3(length(qt-g.yz)/g.w,gc.a*1.4,.45,gc.a*.5);}
    else if(g.x<2.5){v=mix(gc.a*.35,gc.a*1.2,clamp((r-.3)/.62,0.0,1.0));}
    else{float u=(1.0-qt.y)/1.4;v=u<.6?mix(gc.a*1.3,gc.a*.35,clamp(u,0.0,1.0)/.6):mix(gc.a*.35,0.0,clamp((u-.6)/.4,0.0,1.0));}
    rgb=1.0-(1.0-rgb)*(1.0-clamp(gc.rgb*v,0.0,1.0));}
  for(int i=0;i<${SLOTS.vig};i++){vec4 v=uVig[i];if(v.y<.004)continue;vec3 c=uVigC[i].rgb;
    if(v.w>.5){float t=clamp((r-.45)/.47,0.0,1.0);rgb*=mix(vec3(1.0),1.0-(1.0-c)*v.y,t);}
    else{vec2 e=vec2(cos(v.x),sin(v.x))*1.05;float t=clamp(length(qt-e)/1.25,0.0,1.0);
      if(v.z<.5){float k=t<.55?mix(v.y,v.y*.3,t/.55):mix(v.y*.3,0.0,(t-.55)/.45);rgb=1.0-(1.0-rgb)*(1.0-clamp(c*k,0.0,1.0));}
      else{vec3 c0=1.0-(1.0-c)*min(1.0,v.y);vec3 f=t<.6?mix(c0,mix(c0,vec3(1.0),.6),t/.6):mix(mix(c0,vec3(1.0),.6),vec3(1.0),(t-.6)/.4);rgb*=f;}}}
  if(uMask.x>.5){float r0=uMask.x<1.5?mix(-.4,1.05,uMask.y):mix(1.05,-.45,uMask.y);alpha*=min(1.0,clamp((r-r0)/.35,0.0,1.0)+uMask.z);}
  alpha*=uMask.w;
  if(own&&band>.002){
    // tarnish and the frame's brightness, on her own ring
    vec3 tn=mix(vec3(dot(rgb,LUMA)),rgb,.42)*vec3(.80,.85,.80);rgb=mix(rgb,tn,band*uFrm.y);rgb*=mix(1.0,uCol.z,band);}
  vec4 outc=vec4(clamp(rgb,0.0,1.0)*alpha,alpha);
  if(own){
    float inA=smoothstep(.02,.5,art.a);
    if(uFrm.z>.003){vec4 ol=vec4(.93,.75,.96,1.0)*(edge*inA*uFrm.z*.7);outc=ol+outc*(1.0-ol.a);}
    float gm=band*art.a;
    if(gm>.002)for(int i=0;i<${SLOTS.rim};i++){vec4 rm=uRim[i];if(rm.z<.004)continue;float w=1.0;
      if(rm.y<6.0){float hw=min(.5,rm.y/TAU),dd=turnFrom(ang,rm.x);dd=min(dd,1.0-dd);w=dd<hw*.5?mix(1.0,.55,dd/(hw*.5)):dd<hw?mix(.55,0.0,(dd-hw*.5)/(hw*.5)):0.0;}
      float v=gm*w*min(1.0,rm.z);if(v<.002)continue;
      if(rm.w<.5){outc.rgb+=uRimC[i].rgb*v;outc.a=min(1.0,outc.a+v*(1.0-outc.a));}
      else if(outc.a>.001){vec3 o=outc.rgb/outc.a;outc.rgb=mix(outc.rgb,setLum(uRimC[i].rgb,dot(o,LUMA))*outc.a,v);}}
    // the beads ride her own ring (its mean radius), and stay on her own pixels
    if(inA>.002)for(int i=0;i<${SLOTS.bead};i++){vec4 b=uBead[i];if(b.y<.01)continue;
      vec2 e=vec2(cos(b.x),sin(b.x))*(b.w>0.0?b.w:uRimG.x);float dd=length(qt-e),rg=b.z*3.2;
      float v=(dd<rg?stops3(dd/rg,.55*b.y,.3,.22*b.y):0.0)*inA;vec3 c=uBeadC[i].rgb;
      float core=(1.0-smoothstep(b.z*.45-aa,b.z*.45+aa,dd))*.9*b.y*inA;
      outc.rgb+=c*v+min(c+30.0/255.0,1.0)*core;outc.a=min(1.0,outc.a+(v+core)*(1.0-outc.a));}
  }
  if(framed&&r<1.02){
    vec2 fuv=qt*.5+.5;
    vec4 fc=mix(texture2D(uBase,fuv),texture2D(uTarnish,fuv),uFrm.y);fc.rgb*=uCol.z;
    if(uFrm.w>=0.0){float x=turnFrom(ang,-TAU*.25),span=uFrm.w*.52;
      float dd=min(min(abs(x-.125),abs(x-.875)),min(abs(x-1.125),abs(x+.125)));fc*=smoothstep(0.0,1.0,(span-dd)/.03+.5);}
    fc*=uFrm.x;outc=fc+outc*(1.0-fc.a);
    if(uFrm.z>.003){vec4 ol=texture2D(uOutline,fuv)*uFrm.z;outc=ol+outc*(1.0-ol.a);}
    float gm=texture2D(uGlowMask,fuv).a;
    if(gm>.002)for(int i=0;i<${SLOTS.rim};i++){vec4 rm=uRim[i];if(rm.z<.004)continue;float w=1.0;
      if(rm.y<6.0){float hw=min(.5,rm.y/TAU),dd=turnFrom(ang,rm.x);dd=min(dd,1.0-dd);w=dd<hw*.5?mix(1.0,.55,dd/(hw*.5)):dd<hw?mix(.55,0.0,(dd-hw*.5)/(hw*.5)):0.0;}
      float v=gm*w*min(1.0,rm.z);if(v<.002)continue;
      if(rm.w<.5){outc.rgb+=uRimC[i].rgb*v;outc.a=min(1.0,outc.a+v);}
      else if(outc.a>.001){vec3 o=outc.rgb/outc.a;outc.rgb=mix(outc.rgb,setLum(uRimC[i].rgb,dot(o,LUMA))*outc.a,v);}}
    for(int i=0;i<${SLOTS.bead};i++){vec4 b=uBead[i];if(b.y<.01)continue;
      vec2 e=vec2(cos(b.x),sin(b.x))*(240.5/256.0);float dd=length(qt-e),rg=b.z*3.2;
      float v=dd<rg?stops3(dd/rg,.55*b.y,.3,.22*b.y):0.0;vec3 c=uBeadC[i].rgb;
      float core=(1.0-smoothstep(b.z*.45-aa,b.z*.45+aa,dd))*.9*b.y;
      outc.rgb+=c*v+min(c+30.0/255.0,1.0)*core;outc.a=min(1.0,outc.a+v+core);}
  }
  else if(framed)outc=vec4(0.0);
  gl_FragColor=clamp(outc,0.0,1.0);
}`;

/** Frame artwork, one set per style, loaded once and shared. */
const FRAME_LOOKS=['base','tarnish','glowmask','outline'];
const frameSets=new Map();
const route=path=>{try{return globalThis.foundry?.utils?.getRoute?.(path)??`/${path}`;}catch{return `/${path}`;}};
export function frameTexturePath(variant,look){return route(`modules/${ID}/assets/v11/token/frame_${variant}_${look}.webp`);}
/** The four textures of a frame style: {ready, base, tarnish, glowmask, outline}. Starts loading on first ask. */
export function frameSet(variant,PIXI=globalThis.PIXI){
  let set=frameSets.get(variant);if(set)return set;
  set={ready:false,failed:false};frameSets.set(variant,set);
  const loads=FRAME_LOOKS.map(look=>{
    const tex=PIXI.Texture.from(frameTexturePath(variant,look));set[look]=tex;
    const base=tex.baseTexture;if(base.valid)return Promise.resolve();
    return new Promise((ok,fail)=>{base.once?.('loaded',ok);base.once?.('error',fail);});
  });
  Promise.all(loads).then(()=>{set.ready=true;set.onReady?.();},error=>{set.failed=true;console.warn(`Yvaelle’s Toolbox | v11 frame ${variant} failed to load`,error);});
  return set;
}

/** Make the filter class (PIXI is Foundry's, so it is built on first use). */
let FilterClass=null;
export function tokenLayerFilterClass(PIXI=globalThis.PIXI){
  if(FilterClass)return FilterClass;
  const v=n=>new Float32Array(n*4);
  FilterClass=class TokenLayerFilter extends PIXI.Filter{
    constructor(){
      super(undefined,FRAG,{uBase:PIXI.Texture.EMPTY,uTarnish:PIXI.Texture.EMPTY,uGlowMask:PIXI.Texture.EMPTY,uOutline:PIXI.Texture.EMPTY,uRimMask:PIXI.Texture.EMPTY,uRimG:new Float32Array([.95,0,0,0]),
        uGeo:new Float32Array(4),uAxX:new Float32Array(4),uAxY:new Float32Array(4),uTok:new Float32Array([0,0,1,0]),uPor:new Float32Array([0,0,0,1]),uTkR:new Float32Array(4),
        uCol:new Float32Array([1,1,1,WINDOW_R]),uTint:new Float32Array(4),uMask:new Float32Array([0,0,0,1]),uFrm:new Float32Array([1,0,0,-1]),
        uShade:v(SLOTS.shade),uShadeC:v(SLOTS.shade),uGlow:v(SLOTS.glow),uGlowC:v(SLOTS.glow),uVig:v(SLOTS.vig),uVigC:v(SLOTS.vig),
        uRim:v(SLOTS.rim),uRimC:v(SLOTS.rim),uBead:v(SLOTS.bead),uBeadC:v(SLOTS.bead)});
      this.mesh=null;this.frames=null;this.applied=0;this.rim=null;
    }
    /** (test.8) Her own ring (v11/token-rim.mjs rimTextureOf), or null: the drawn frame is on, or there is no picture yet. */
    setRim(rim){
      if(rim===this.rim)return;this.rim=rim;const u=this.uniforms;
      if(rim?.texture){u.uRimMask=rim.texture;u.uRimG[0]=rim.radius;u.uRimG[1]=1;u.uRimG[2]=rim.thickness;}else{u.uRimMask=PIXI.Texture.EMPTY;u.uRimG[1]=0;}
    }
    /** Copy a sampled Look into the uniforms (no allocation: the arrays are set in place). */
    setLook(L,frames){
      const u=this.uniforms;u.uTok.set(L.tok);u.uPor.set(L.por);if(L.trot)u.uTkR.set(L.trot);u.uCol.set(L.col);u.uTint.set(L.tint);u.uMask.set(L.mask);u.uFrm.set(L.frm);
      u.uShade.set(L.shade);u.uShadeC.set(L.shadeC);u.uGlow.set(L.glow);u.uGlowC.set(L.glowC);u.uVig.set(L.vig);u.uVigC.set(L.vigC);
      u.uRim.set(L.rim);u.uRimC.set(L.rimC);u.uBead.set(L.bead);u.uBeadC.set(L.beadC);
      if(frames!==this.frames){this.frames=frames;if(frames?.ready){u.uBase=frames.base;u.uTarnish=frames.tarnish;u.uGlowMask=frames.glowmask;u.uOutline=frames.outline;}}
      u.uGeo[3]=frames?.ready?1:0;
    }
    /** Where her token is on the render target this frame (its transform already holds her flight pose). */
    apply(filterManager,input,output,clearMode){
      const m=this.mesh,u=this.uniforms;
      if(m&&!m.destroyed){
        const wt=m.worldTransform,tex=m.texture,w=tex?.orig?.width??tex?.width??1,h=tex?.orig?.height??tex?.height??1,ax=m.anchor?.x??.5,ay=m.anchor?.y??.5;
        const lx=(.5-ax)*w,ly=(.5-ay)*h;
        u.uGeo[0]=wt.a*lx+wt.c*ly+wt.tx;u.uGeo[1]=wt.b*lx+wt.d*ly+wt.ty;
        const xl=Math.hypot(wt.a,wt.b)||1,yl=Math.hypot(wt.c,wt.d)||1;
        u.uAxX[0]=wt.a/xl;u.uAxX[1]=wt.b/xl;u.uAxY[0]=wt.c/yl;u.uAxY[1]=wt.d/yl;
        u.uGeo[2]=Math.max(1,Math.min(xl*w,yl*h)/2);
        this.padding=Math.ceil(u.uGeo[2]*.06)+2;
      }
      this.applied++;
      filterManager.applyFilter(this,input,output,clearMode);
    }
  };
  return FilterClass;
}
