/** Keepsake · Settings (v11): the tree of the Settings tab.
 *
 * Section › group › row, with a row's Parts and visual pickers one level
 * down. Every v10 row keeps its v10.0.1 storage: `k` is the stored key and
 * `kind` the v10 KEEPSAKE_GROUPS kind (v7 gem appearance pose feel client
 * world ui prefs theme reactions localQ observerQ sheet action), so
 * KeepsakeSettings.read()/write() bind it exactly where it always was. v11
 * rows come from the feature registry (v11/features.mjs, kind 'v11').
 * `from` is the v10 group a row lived in (search finds it by that name).
 * `fine` rows were ADVANCED and now sit under their group's Finer tuning.
 * Source of truth for the approved design: the v11 settings map
 * (tools/v11/fixtures/settings-map.json is checked against this file). */
import {FEATURES,partKey} from '../v11/features.mjs?v=13.0.0-beta.8';

const pct=v=>Math.round(v*100)+'%',mul=v=>Number(v).toFixed(2)+'×',n1=v=>Number(v).toFixed(1),n2=v=>Number(v).toFixed(2);
const O=(...a)=>a.map(x=>Array.isArray(x)?{id:x[0],label:x[1]}:{id:x,label:x});
const sw=(id,name,desc,scope,def,x={})=>({id,k:id,name,desc,scope,type:'switch',def,...x});
const ch=(id,name,desc,scope,opts,def,x={})=>({id,k:id,name,desc,scope,type:'choice',opts,def,...x});
const sl=(id,name,desc,scope,[min,max,step],def,fmt,x={})=>({id,k:id,name,desc,scope,type:'slider',min,max,step,def,fmt,...x});
const bt=(id,name,desc,label,x={})=>({id,k:id,name,desc,scope:null,type:'button',label,kind:'action',...x});
const keep=(k,name,def)=>({id:k,k,name,type:'switch',def,kind:'client',scope:'me',from:'Keep playing'});
/** A v11 feature row from the registry. */
function v11(id){
  const f=FEATURES.get(id);if(!f)throw new Error('No v11 feature '+id);
  const row={...f,k:f.id,kind:'v11',src:'new'};
  delete row.where;
  if(f.pickers?.length)row.pickers=f.pickers.map(p=>({...p,k:p.id,kind:'v11',scope:p.scope??f.scope}));
  if(f.parts?.length)row.parts=f.parts.map(p=>({...p,k:partKey(f.id,p.id),kind:'v11',scope:p.scope??f.scope}));
  return row;
}

export const ICONS={
  overview:'M4 11l8-7 8 7v9h-5v-6H9v6H4z',
  her:'M12 3l6 6-6 12-6-12zM6 9h12M12 3l-2 6 2 12 2-12z',
  flight:'M3 14c4-1 6-4 9-9 1 4 4 7 9 8M12 5v14M8 21h8',
  combat:'M5 19L19 5M14 5h5v5M5 14l5 5M9 9L5 5',
  healing:'M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10zM9.5 11h5M12 8.5v5',
  emotes:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM8.5 14.5c1 1.2 2.1 1.8 3.5 1.8s2.5-.6 3.5-1.8M9 9.5h.01M15 9.5h.01',
  hud:'M4 4h16v16H4zM4 9h16M9 9v11',
  perf:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6',
  sound:'M5 9v6h4l5 4V5L9 9zM17.5 9a4 4 0 0 1 0 6M19.5 6.5a7.5 7.5 0 0 1 0 11',
  advanced:'M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M16 4v4M10 10v4M18 16v4',
};
const QUALITY=O(['inherit','Default'],['low','Low'],['balanced','Medium'],['high','High']);
const V10=O(['v10','v10'],['classic','Classic']);

export const SECTIONS=[
{id:'overview',name:'Overview',icon:'overview',blurb:'Your character, a feel to start from, and what is new since v10.',special:'overview',groups:[]},

{id:'her',name:'Her',sub:'wings, bits & token',icon:'her',blurb:'How she looks at rest: her wings, the four bits that hold them, and her token.',groups:[
 {id:'wings',name:'Wings',desc:'Light, material and size',rows:[
  sw('wingLightStyle','Soul light','Layered magenta light, tapering ribs and travelling energy · costs more to draw','me',false,{kind:'client',on:'soul',off:'original',from:'Appearance'}),
  sl('wingScale','Wing size','Relative to her token','token',[1,7,.1],3,n1,{kind:'appearance',from:'Size & visibility'}),
  sl('opacity','Wing opacity','How solid the filaments look','token',[0,1,.05],.85,pct,{kind:'appearance',from:'Size & visibility'}),
  sw('gemInteriors','Gemstone interiors','Facets and depth inside each bit’s core','token',true,{kind:'v7',from:'Appearance'}),
  sw('filamentTexture','Textured filaments','Fine grain along the wing ribs','token',true,{kind:'v7',from:'Appearance',parts:[
    sl('filamentStrength','Texture strength','How strong the grain looks','token',[0,1,.05],.5,pct,{kind:'v7',from:'Appearance',fine:true})]}),
  sw('refraction','Refractive light','Light bends through the crystal','token',true,{kind:'v7',from:'Appearance',fine:true}),
  sl('offsetY','Shoulder offset','Where the wings attach','token',[-2,2,.05],0,v=>(v>0?'+':'')+n2(v),{kind:'appearance',from:'Size & visibility',fine:true}),
 ]},
 {id:'bits',name:'Bits',desc:'The four stabilisers around her wings',rows:[
  bt('bitPlacement','Bit placement','Drag the four bits to where they sit around her wings','Arrange',{from:'Bits & glow'}),
  sl('size','Bit size','Relative to the wings','token',[.5,1.5,.05],1,mul,{kind:'gem',fallback:'gemSize',from:'Bits & glow'}),
  sw('glow','Stabilising glow','Light between the bits and her wings','token',true,{kind:'gem',fallback:'gemStabilizingGlow',from:'Bits & glow',parts:[
    sl('glowStrength','Glow strength','How bright that light is','token',[0,1,.05],.6,pct,{kind:'gem',fallback:'gemGlowStrength',from:'Bits & glow'}),
    ch('glowMode','Glow shape','Around each core, or a field between them','token',O(['core','Core'],['field','Field']),'field',{kind:'gem',fallback:'gemGlowMode',from:'Bits & glow'})]}),
  ch('design','Bit design','The housing around each core','token',O(['vanes','Prism spindle'],['shielded','Aegis lens'],['spine','Filament needle']),'vanes',{kind:'gem',fallback:'gemDesign',from:'Bits & glow',fine:true}),
  sl('speed','Bit animation speed','How quickly they move','token',[.25,2,.05],1,mul,{kind:'gem',fallback:'gemAnimationSpeed',from:'Bits & glow',fine:true}),
  sw('expressionEnabled','Expressive bits','The bits react to what she does','token',true,{kind:'gem',fallback:'bitExpressionEnabled',from:'Bit expression',parts:[
    sl('expressionStrength','Strength','How strongly they react','token',[0,1,.05],.45,pct,{kind:'gem',fallback:'bitExpressionStrength',from:'Bit expression'}),
    ch('intent','Attention','Whether they look at what matters','token',O(['off','Off'],['composed','Composed'],['attentive','Attentive']),'composed',{kind:'gem',fallback:'bitIntent',from:'Bit expression'}),
    sl('personality','Personality','Curiosity between tasks','token',[0,1,.05],.35,pct,{kind:'gem',fallback:'bitPersonality',from:'Bit expression',fine:true})]}),
  ch('bitSendOutStyle','Send-out style','How the bits fly out to a task and back','me',O(['classic','Classic'],['mixed','Mixed'],['warp','Seam warp'],['thread','Thread relay'],['sling','Sling'],['flight','Formation']),'mixed',{kind:'client',from:'Looks & library'}),
  ch('formationLibrary','Formation library','Which formations the lists offer','me',O(['refined','Curated'],['all','All'],['classic','Classic']),'refined',{kind:'client',from:'Looks & library',fine:true}),
 ]},
 {id:'token',name:'Her token',desc:'New in v11 · portrait and frame',rows:[v11('tokenLayer')]},
 {id:'wingless',name:'Wingless',desc:'New in v11',rows:[v11('wingless')]},
 {id:'moods',name:'Moods & milestones',desc:'New in v11',rows:[v11('moodWeather'),v11('dieMoods'),v11('heroSpent'),v11('curse')]},
]},

{id:'flight',name:'Flight',sub:'feel, motion & world',icon:'flight',blurb:'How she takes off, moves, warps and meets the map.',groups:[
 {id:'feel',name:'Flight feel',desc:'Weight and height',rows:[
  ch('weight','Weight','Light settles quickly · Heavy carries momentum and slower wingbeats','token',O(['light','Light'],['normal','Normal'],['heavy','Heavy']),'normal',{kind:'feel',from:'Flight feel'}),
  sl('hoverHeight','Hover height','How high her image floats above the square','token',[0,1,.01],.18,n2,{kind:'appearance',from:'Size & visibility'}),
  sw('takeoffElevation','Takeoff sets her elevation','Taking off raises her token’s elevation; landing puts it back','token',false,{kind:'feel',from:'Flight feel',parts:[
    sl('altitude','Flying height','The elevation takeoff gives her','token',[0,120,5],15,v=>v+' ft',{kind:'feel',from:'Flight feel'}),
    sw('heightByMode','Height follows flight mode','Fast flies higher, Glide highest, Wraith skims low','token',true,{kind:'feel',from:'Flight feel'})]}),
  sw('landToGround','Landing sets elevation to 0','Landing or folding her wings brings her token down','token',true,{kind:'feel',from:'Flight feel'}),
  ch('scale','Shrink with height','How much smaller she looks up high','token',O(['off','Off'],['subtle','Subtle'],['normal','Normal'],['dramatic','Dramatic']),'normal',{kind:'feel',from:'Flight feel',fine:true}),
  ch('wingShadow','Ground shadow','The shadow of her wings on the ground','token',O(['off','Off'],['faint','Faint'],['normal','Normal'],['strong','Strong']),'normal',{kind:'feel',from:'Flight feel'}),
  ch('afterimages','Afterimages','Copies trail behind her and rush back when she stops','token',O(['off','Off'],['echo','Echo'],['trail','Trail'],['phase','Phase']),'off',{kind:'feel',from:'Flight feel'}),
  ch('idleGestures','Idle gestures','While she hovers still: stretches, glances and plays with her bits','token',O(['all','All'],['calm','Calm'],['off','Off']),'all',{kind:'feel',from:'Flight feel'}),
 ]},
 {id:'motion',name:'Wing motion',desc:'Gestures, bridges and follow-through',rows:[
  sw('flightManoeuvres','Flight manoeuvres','The wings brake, rise and bank with how she moves','me',true,{kind:'client',from:'Animation',action:bt('demoManoeuvres','See them','','Show me',{from:'Animation'})}),
  sw('wingAnimations','Wing gestures','Small expressive flourishes','token',true,{kind:'v7',from:'Animation'}),
  sw('style','Smooth wing bridges','Blend between poses instead of snapping','token',true,{kind:'pose',cfg:'poseTransitionStyle',on:'flow',off:'classic',from:'Animation',parts:[
    sl('duration','Pose change time','How long a pose change takes','token',[0,3000,50],650,v=>(v/1000).toFixed(2)+' s',{kind:'pose',cfg:'poseDuration',from:'Animation',fine:true}),
    sl('followThrough','Pose follow-through','How long poses settle','token',[0,1,.05],.35,pct,{kind:'pose',cfg:'poseFollowThrough',from:'Animation',fine:true})]}),
  sw('wingFollowThrough','Follow-through','Wing tips trail a moment behind the shoulders','me',false,{kind:'client',from:'Animation'}),
  sw('transitionVariants','Action variation','Each repeat looks a little different','token',true,{kind:'v7',from:'Animation'}),
  sl('wingSpeed','Wingbeat speed','How fast the wings move','token',[.2,3,.1],1,mul,{kind:'appearance',from:'Size & visibility',fine:true}),
 ]},
 {id:'warps',name:'Warps',desc:'Short-range warps',rows:[
  ch('versionWarp','Default warp','Which warp plays unless the wheel picks one','me',O(['threaded','Threaded'],['seam','Seam'],['flicker','Flicker'],['petal','Petal'],['shard','Shard'],['mirror','Mirror'],['flock','Flock'],['starfall','Starfall'],['ribbon','Ribbon seam'],['prism','Prism'],['cloak','Cloak']),'threaded',{kind:'client',from:'Versions'}),
  ch('warpArrival','Warp arrival','How a warp lands','me',O(['pulse','Magenta pulse'],['wisps','Filament wisps']),'pulse',{kind:'client',from:'Animation'}),
  sw('warpBendTokens','Warps bend nearby tokens','The bend also bends other tokens, not just the map','me',false,{kind:'client',from:'Animation'}),
  sl('warpRange','Warp range','How far a warp can reach','gm',[0,120,5],60,v=>v?v+' ft':'Any visible',{kind:'world',from:'Animation'}),
 ]},
 {id:'world',name:'Her and the world',desc:'New in v11',rows:[v11('wallFold'),v11('lightCatch'),v11('wingShadowTokens'),v11('shadowHeight'),v11('shieldStyles'),v11('landingStyles'),v11('decoy')]},
]},

{id:'combat',name:'Combat & damage',sub:'hits, wounds & stealth',icon:'combat',blurb:'What plays when she is hit, missed, hurt, hidden or grabbed.',groups:[
 {id:'moments',name:'Combat moments',desc:'Hits, misses, shields and saves',rows:[
  sw('combatFx','Combat moments','Every moment below · off leaves her motion and wing light only','token',true,{kind:'feel',from:'Combat moments',
    parts:[sl('combatStrength','Strength','How many pieces fly and how brightly they burn','token',[.25,1.5,.05],1,pct,{kind:'feel',from:'Combat moments'}),
      sw('combatHits','Hit shards · light bursts the way the blow pushed','','token',true,{kind:'feel',from:'Combat moments'}),
      sw('combatShatter','Wings shatter on a big hit, then pull together','','token',true,{kind:'feel',from:'Combat moments'}),
      sw('combatShield','Shield sparks where it is struck','','token',true,{kind:'feel',from:'Combat moments'}),
      sw('combatShots','Intercepted shots glance off the bit','','token',true,{kind:'feel',from:'Combat moments'}),
      sw('combatDodge','Dodge copy left where she was','','token',true,{kind:'feel',from:'Combat moments'}),
      sw('combatSaves','Critical-save glints','','token',true,{kind:'feel',from:'Combat moments'}),
      sw('combatLanding','Hard landing chips light off the ground','','token',true,{kind:'feel',from:'Combat moments'})]}),
  ch('missReaction','Ranged misses','A bit darts into the line of fire, or she sidesteps','token',O(['intercept','Intercept'],['sidestep','Sidestep']),'intercept',{kind:'feel',from:'Flight feel'}),
  sw('bruise','Bruised light','A hit knocks the light out of the wing facing the blow','token',true,{kind:'feel',from:'Flight feel'}),
  sw('braceSaves','Braced saves','Her bits brace her for each saving throw','token',true,{kind:'feel',from:'Flight feel'}),
  sw('autoShield','Shield with Raise a Shield','Her wings form a barrier while it is up','token',true,{kind:'feel',from:'Flight feel'}),
 ]},
 {id:'wounds',name:'Wounds',desc:'New in v11 · by damage type',rows:[v11('wounds'),v11('persistent'),v11('dyingStages'),v11('lastLight'),v11('lowHpFatigue')]},
 {id:'stealth',name:'Invisibility',desc:'New in v11',rows:[v11('invisLooks'),v11('invisFlicker'),v11('cloakDepth')]},
 {id:'grapple',name:'Grapple & spells',desc:'New in v11',rows:[v11('grappleEscape'),v11('spellTraditions')]},
 {id:'conditions',name:'Conditions & HP',desc:'Frightened, slowed and the rest',rows:[
  sw('reactionsEnabled','Condition reactions','Wings and bits answer frightened, slowed and more','token',true,{kind:'reactions',from:'Reactions & HP'}),
  sl('effectStrength','Cue strength','How strongly Pulse, Flare and the rest play','me',[0,1,.05],1,pct,{kind:'prefs',from:'Reactions & HP'}),
  sl('holdMs','Timed pose length','How long a timed pose or condition holds','me',[1000,60000,1000],8000,v=>Math.round(v/1000)+' s',{kind:'prefs',from:'Reactions & HP'}),
  sw('temporaryPose','Poses are timed','Pose choices return after a while','me',true,{kind:'prefs',from:'Reactions & HP',fine:true}),
  sw('hpReactions','Automatic HP reactions','Wings wear and tear with her HP','gm',true,{kind:'world',from:'Reactions & HP'}),
 ]},
]},

{id:'healing',name:'Healing & Medkit',sub:'treatment & support',icon:'healing',blurb:'Her treatments, heals and the ways she looks after the party.',groups:[
 {id:'medkit',name:'Medkit',desc:'Treatment and preparation',rows:[
  bt('openMedkit','Ellie’s Medkit','Open the medicine window','Open',{from:'Medical animations'}),
  sw('medkit','Enhanced treatments','Full preparation, results and release','token',true,{kind:'v7',from:'Medical animations'}),
  sw('seamlessActions','Seamless preparation','Bits ready their tools before working','token',true,{kind:'v7',from:'Medical animations'}),
 ]},
 {id:'heals',name:'Heals',desc:'What a heal looks like',rows:[
  sw('autoChrysalis','Chrysalis on great heals','A critical heal or a rescue from dying plays the Chrysalis','token',true,{kind:'feel',from:'Flight feel'}),
  sw('lifeline','Lifeline to dying allies','A pulsing filament from her heart while an ally is dying','token',true,{kind:'feel',from:'Flight feel'}),
 ]},
 {id:'support',name:'Looking after the party',desc:'New in v11',rows:[v11('allyWatch')]},
]},

{id:'emotes',name:'Emotes & wheel',sub:'gestures & shortcuts',icon:'emotes',blurb:'Her ten emotes and the Quick wheel that plays them.',groups:[
 {id:'emotes',name:'Emotes',desc:'New in v11',rows:[v11('emotes')]},
 {id:'wheel',name:'Quick wheel',desc:'New in v11',rows:[v11('nestedWheel'),v11('wheelShortcuts'),v11('fieldMenus'),v11('macroRing'),bt('openKeys','Keys','Set keys for the HUD, Quick wheel and Medkit','Set keys')]},
]},

{id:'hud',name:'HUD & sheet',sub:'this window, her sheet',icon:'hud',blurb:'This window and her character sheet in the Keepsake style.',groups:[
 {id:'sheet',name:'Her character sheet',desc:'Her PF2e sheet in Keepsake dress',rows:[
  ch('sheetMode','Keepsake sheet','Just me: your screen · Everyone: whoever opens her sheet','token',O(['off','Off'],['me','Just me'],['everyone','Everyone']),'off',{kind:'sheet',from:'Her character sheet'}),
  bt('openSheet','Her sheet','Open her character sheet','Open',{from:'Her character sheet'}),
  bt('portraitStudio','Portrait studio','Art for each stage of her HP · her sheet and this HUD','Open',{from:'Her character sheet'}),
  ch('portraitSet','Portrait expressions','How her face follows HP','me',O(['original','Original'],['resolute','Resolute'],['pained','Pained']),'original',{kind:'theme',from:'Appearance'}),
 ]},
 {id:'hudframe',name:'This HUD',desc:'Frame motion and helpers',rows:[
  ch('fm','Frame motion','Corners, cords, moon, petals and her breathing','me',O('Off','Slow','Normal','Lively'),'Normal',{kind:'ui',from:'Your HUD'}),
  sw('petals','Drifting petals','In the header behind her name','me',true,{kind:'ui',from:'Your HUD'}),
  sw('moonClock','Corners keep time','The moon follows its phase; the lily opens at full moon','me',true,{kind:'ui',from:'Your HUD'}),
  sw('heroPetals','Hero Points as petals','A spent one drifts away; a new one falls','me',true,{kind:'ui',from:'Your HUD'}),
  sw('shiftLabels','Shift reveals alternates','Buttons rewrite while Shift is held','me',true,{kind:'ui',from:'Your HUD'}),
  sw('hoverGuide','Hover guide','Explain controls in the status line','me',true,{kind:'ui',from:'Your HUD'}),
  ch('effectLibrary','Effect library','What the Effects tab lists','me',O(['featured','Featured'],['all','All variants']),'featured',{kind:'client',from:'Looks & library'}),
 ]},
]},

{id:'perf',name:'Performance & comfort',short:'Performance',sub:'detail & comfort',icon:'perf',blurb:'Detail on your screen, what others draw, and calmer motion.',groups:[
 {id:'quality',name:'Detail',desc:'Your view and other players’',rows:[
  ch('localQ','My view','Detail on your screen','me',QUALITY,'inherit',{k:'preset',kind:'localQ',from:'Quality & comfort'}),
  ch('observerQ','Other players’ view','The most others will draw of her','token',QUALITY,'inherit',{k:'preset',kind:'observerQ',from:'Quality & comfort'}),
  sw('renderWorker','Paint off the main thread','Smoother canvas on most machines','me',true,{kind:'client',from:'Quality & comfort',fine:true}),
  sw('localEffects','Show effects here','Off hides every Yvaelle’s Toolbox visual on this browser','me',true,{kind:'client',from:'Quality & comfort'}),
 ]},
 {id:'comfort',name:'Comfort',desc:'Motion',rows:[
  sw('reducedMotion','Reduced motion','Hold decorative motion still','me',false,{kind:'client',from:'Quality & comfort'}),
 ]},
 {id:'keep',name:'Keep playing',desc:'While tokens move, or this window is covered',rows:[
  sw('keepSheet','On her sheet','Loops that keep going on her sheet','me',true,{kind:'derived',derived:true,from:'Keep playing',parts:[
    keep('keepPlayingSheetHeart','Heartbeat and HP line · ~0.2 ms a frame',true),keep('keepPlayingSheetPortrait','Portrait breathing and mood',false),
    keep('keepPlayingSheetPetals','Hero Point petals and flowers · ~0.3 ms',false),keep('keepPlayingSheetSky','Moon and stars · ~0.15 ms',false),
    keep('keepPlayingSheetCorners','Corner glints and cords · ~0.2 ms',false)]}),
  sw('keepHud','On this HUD','Loops that keep going on the HUD','me',true,{kind:'derived',derived:true,from:'Keep playing',parts:[
    keep('keepPlayingHudHeart','Heartbeat and HP line · ~0.8 ms',true),keep('keepPlayingHudPortrait','Portrait breathing and mood · ~0.2 ms',false),
    keep('keepPlayingHudPetals','Hero Point petals and flowers · ~2 ms',false),keep('keepPlayingHudSky','Moon and stars · ~0.5 ms',false),
    keep('keepPlayingHudCorners','Corner glints and cords · ~2.5 ms, the most',false)]}),
 ]},
]},

{id:'sound',name:'Sound',sub:'volume & mute',icon:'sound',blurb:'Your volume, and the table’s audio (set by the GM).',groups:[
 {id:'mine',name:'Your sound',desc:'This browser only',rows:[
  sw('audioMuted','Mute for me','Only silences your own browser','me',false,{kind:'client',from:'Sound'}),
  sl('audioLocalVolume','My volume','Wing and treatment sounds here','me',[0,1,.05],.8,pct,{kind:'client',from:'Sound'}),
 ]},
 {id:'table',name:'The table’s sound',desc:'Set by the GM for everyone',rows:[
  sw('audioEnabled','Animation audio','Wings, bits and treatment sounds for everyone','gm',true,{kind:'world',from:'Sound',parts:[
    sl('audioVolume','Master volume','Multiplied by each player’s own volume','gm',[0,1,.05],.7,pct,{kind:'world',from:'Module settings'}),
    sl('audioRadius','Audible radius','How far her sounds carry','gm',[1,240,1],20,v=>v+' ft',{kind:'world',from:'Module settings'}),
    sw('audioDistanceFade','Fade with distance','Softer toward the edge of the radius','gm',true,{kind:'world',from:'Module settings'})]}),
 ]},
 {id:'v12',name:'V12 sounds',desc:'New in v12 · off as it comes',rows:[v11('soundSet')]},
]},

{id:'advanced',name:'Advanced',sub:'versions, experiments',icon:'advanced',blurb:'Earlier looks, test features and the full list of module settings.',groups:[
 {id:'experimental',name:'Experimental',desc:'v11 test features · may change or go',rows:[v11('xTapestry'),v11('xPetals'),v11('xRecap')]},
 {id:'versions',name:'Versions',desc:'v10 or the earlier look, one feature at a time',rows:[
  ch('versionWingMotion','Wing motion','Folded pose, power stroke, tapered wakes · or v9','me',V10,'v10',{kind:'client',from:'Versions'}),
  ch('versionFlightFeel','Flight feel','Weight, momentum and height · or the steady hover','me',V10,'v10',{kind:'client',from:'Versions'}),
  ch('versionGestures','Bit gestures','Readable v10 paths or the small v9 moves','me',V10,'v10',{kind:'client',from:'Versions'}),
  ch('versionCoreStates','Bit core states','Distinct v10 marks or the subtle v9 ones','me',V10,'v10',{kind:'client',from:'Versions'}),
  ch('versionBitOutline','Bit outline','Darker outline for token size, or the original','me',O(['original','Original'],['darker','Darker']),'original',{kind:'client',from:'Versions'}),
  ch('versionFormations','Formation motion','Reworked Tide line or the v9 one','me',V10,'v10',{kind:'client',from:'Versions'}),
  ch('versionScans','Scan look','Brighter v10 scans or the restrained v8.6','me',V10,'v10',{kind:'client',from:'Versions'}),
  ch('versionIris','Iris look','Mechanical blades or the hardlight wire','me',O(['mechanical','Mechanical'],['hardlight','Hardlight']),'mechanical',{kind:'client',from:'Versions'}),
 ]},
 {id:'more',name:'Everything else',desc:'Fine tuning and the table’s defaults',rows:[
  bt('detailed','Detailed tuning','Thirteen panels of fine controls for her token','Open',{from:'Detailed tuning',count:13}),
  bt('allSettings','All module settings','Every world and browser setting, grouped and searchable','Open',{from:'More',count:218}),
  ch('settingsList','Foundry’s settings list','What Configure Settings shows for this module','gm',O(['compact','Compact'],['full','Full list']),'compact',{kind:'world',from:'Module settings'}),
 ]},
]},
];

/** Start from a feel: the same keys and values as v10.0.1 (wingLightStyle keeps its string values). */
export const PRESETS=[
 {id:'cine',name:'Cinematic',desc:'Full detail and every flourish',set:{localQ:'high',fm:'Lively',petals:true,wingLightStyle:'soul'}},
 {id:'bal',name:'Balanced',desc:'The defaults · good on most machines',set:{localQ:'inherit',fm:'Normal',petals:true,wingLightStyle:'original'}},
 {id:'gentle',name:'Gentle',desc:'Calm motion, lighter work for slower PCs',set:{localQ:'low',fm:'Slow',petals:false,wingLightStyle:'original'}},
];

/** Search synonyms (a term also matches these words). */
export const SYNONYMS={invisible:'cloak hidden stealth drain',hidden:'invisible cloak',glow:'light',sound:'audio volume',audio:'sound',wound:'damage hit',damage:'wound persistent',
  heal:'medkit heal',fps:'performance quality',performance:'quality fps detail',keys:'keybind shortcut',frame:'token ring portrait',token:'portrait frame'};

/* ------------------------------------------------------------------ */
/* Index: every row, part, picker and action, with its path            */
/* ------------------------------------------------------------------ */
export const INDEX=new Map(),ORDER=[];
function add(item,sec,grp,parent,role){
  if(!item)return;
  const key=role==='part'&&parent?`${parent.id}/${item.id}`:item.id;
  if(INDEX.has(key))return;
  const rec={key,item,sec,grp,parent,role,scope:item.scope??parent?.scope??null};INDEX.set(key,rec);ORDER.push(rec);
}
for(const sec of SECTIONS)for(const g of sec.groups)for(const r of g.rows){
  add(r,sec,g,null,'row');
  for(const p of r.pickers??[])add(p,sec,g,r,'picker');
  if(r.action)add(r.action,sec,g,r,'action');
  for(const p of r.parts??[])add(p,sec,g,r,'part');
}
export const sectionById=id=>SECTIONS.find(s=>s.id===id)??null;
export const isFeature=r=>!!(r.parts?.length||r.pickers?.length||r.thumb||r.action);
/** Every v10.0.1 Settings-tab control, as [k, kind] pairs bound by this tree (for the migration test). */
export function boundControls(){const out=[];for(const rec of ORDER){const it=rec.item;if(it.kind&&it.kind!=='v11'&&it.kind!=='derived')out.push([it.k,it.kind,it.fallback??it.cfg??null]);}return out;}
