/** Fourteen readable condition designs. Each has a different lattice topology,
 * silhouette or rhythm; all reuse the native wing textures and attachment roots. */
import {CURATED_CONDITION_IDS} from './effect-catalog.mjs?v=13.0.0-beta.8';
import {ease} from './poses.mjs?v=13.0.0-beta.8';
import {cubic} from './wing-art.mjs?v=13.0.0-beta.8';
import {fitEffectPoint,fitOwnedEffectPoint} from './condition-art.mjs?v=13.0.0-beta.8';
const IDS=new Set(Object.values(CURATED_CONDITION_IDS).flat()),TAU=Math.PI*2;
const frac=x=>x-Math.floor(x),root=u=>ease((u-.1)/.36),mix=(a,b,k)=>a.map((x,i)=>x+(b[i]-x)*k);
const quant=x=>Math.round(Math.max(0,Math.min(1.5,x))*20)/20;
const gate={breathing:'instability',roseLattice:'energy',fraying:'breaks',scarStitch:'breaks',recoil:'instability',torsion:'instability',phaseTears:'glitches',memoryEcho:'glitches',corona:'energy',circuit:'arcs',binding:'instability',drain:'energy',unravelling:'breaks',seedRecall:'breaks'};
export const isCuratedCondition=v=>IDS.has(v?.variant?.id);
const fields=new WeakMap();
const field=v=>{const a=v?.variant;if(!IDS.has(a?.id)||!(a.amount>0)||v.gates?.[gate[a.id]]===false||gate[a.id]==='energy'&&!v.energyPulses)return null;
  const t=v.animated===false?0:a.time??0,m=v.gates?.instability===false?0:v.variantMotion??1,frequency=a.frequency??1;
  let f=fields.get(v);if(!f||f.id!==a.id||f.A!==a.amount||f.t!==t||f.m!==m||f.frequency!==frequency){f={id:a.id,A:a.amount,t,m,frequency};fields.set(v,f);}return f;};
/** One optional sampler per synchronous wing frame. Material coordinates repeat
 * across ribs, web ends, sides and held support spans. Reuse their exact root
 * envelope and breathing waves; never retain a map across artwork clocks. Direct
 * point callers keep their ordinary live-profile validation. */
export function curatedConditionParameters(v){
  const f=field(v);return f?{...f,breathingSamples:f.id==='breathing'?new Map():null}:null;
}
function rank(id){let h=2166136261;for(const c of id)h=Math.imul(h^c.charCodeAt(0),16777619);h=Math.imul(h^(h>>>16),0x85ebca6b);return ((h^(h>>>13))>>>0)/4294967296;}
export function curatedConditionPoint(point,u,side,v,parameters){
  const f=parameters===undefined?field(v):parameters;if(!f||u<=.1)return point;
  let breathing=f.breathingSamples?.get(u);
  if(f.breathingSamples&&!breathing){breathing=[Math.sin(f.t*.92-u*.7),Math.sin(f.t*.92-u*3.5),root(u)];f.breathingSamples.set(u,breathing);}
  const {id,A,t,m,frequency}=f,p=[...point],r=breathing?.[2]??root(u),x=p[0]-side*27,y=p[1]+13;
  switch(id){
    case 'breathing':{
      const [breath,curl]=breathing??[Math.sin(t*.92-u*.7),Math.sin(t*.92-u*3.5)];p[0]+=x*A*m*r*.115*breath;p[1]+=A*m*r*(9*curl-y*.022*breath);break;}
    case 'roseLattice':p[0]+=x*.022*A*m*r*Math.sin(t*.55);p[1]+=A*m*r*3*Math.sin(t*.55+u*3);break;
    case 'fraying':p[1]+=A*m*r*(9*u+11*u*u);break;
    case 'scarStitch':{const squeeze=(.5+.5*Math.sin(t*1.35))**2;p[0]-=x*.06*A*m*r*squeeze;p[1]+=6*A*m*r*Math.sin(y*.026)*squeeze;break;}
    case 'recoil':{const q=frac(t*.28*frequency+(side<0?0:.45)),hit=ease(q/.12)*(1-ease((q-.16)/.38));p[0]-=x*.46*A*m*r*hit;p[1]+=26*A*m*r*hit;break;}
    case 'torsion':{const twist=t*1.05+side*.9-u*5.8;p[0]+=side*31*A*m*r*Math.sin(twist)*(y<0?-1:1);p[1]+=16*A*m*r*Math.cos(twist);break;}
    case 'corona':p[0]+=x*.105*A*m*r;p[1]-=12*A*m*r*(.7+.3*Math.sin(t*2-u*5));break;
    case 'circuit':p[0]+=x*.035*A*m*r*Math.sin(t*2.8-u*10);break;
    case 'binding':p[0]-=x*A*r*(.58+.025*m*Math.sin(t*.7));p[1]+=A*r*y*.055;break;
    case 'drain':p[0]-=x*.11*A*r;p[1]+=A*m*r*4*Math.sin(t*.5-u*3);break;
    case 'unravelling':p[0]-=x*.36*A*r;p[1]+=A*r*(-y*.4+84*u);p[0]+=side*5*A*m*r*Math.sin(t*.75+u*3);break;
    case 'seedRecall':{const cluster=side*27+x*.27+side*66*r,vertical=-13+y*.27+8*u;p[0]+=(cluster-p[0])*A*r;p[1]+=(vertical-p[1])*A*r;p[1]+=3*A*m*r*Math.sin(t*.8+u*7);break;}
  }
  return fitOwnedEffectPoint(p);
}

/** Append adjacent spans together. A split is emitted only at a true cut or
 * held displacement; ghosts are similarly batched, avoiding per-segment draws. */
export function curatedConditionPaths(strand,points,side,v){
  const f=field(v);if(!f)return [{...strand,points}];
  if(/^(sigil|gem)-/.test(strand.id))return [{...strand,points:points.map(fitEffectPoint)}];
  const {id,A,t,m,frequency}=f;
  const sliced=['roseLattice','fraying','scarStitch','phaseTears','memoryEcho','circuit','drain','unravelling','seedRecall'].includes(id);
  if(!sliced)return [{...strand,points}];
  const web=/^(web|cross)-/.test(strand.id),rib=strand.id.startsWith('rib-'),edge=strand.id.startsWith('edge-');
  const index=Number(strand.id.split('-')[1])||0,seed=rank(`${v.seed}:${side}:${strand.id}`);
  const out=[],echoes=[];let last=null,ghost=null;
  const append=(dest,p,q,strength,tag,echo=false)=>{
    const s=quant(strength);if(s<=.025){if(echo)ghost=null;else last=null;return;}
    let prev=echo?ghost:last;
    if(prev&&prev.tag===tag&&prev.strength===s&&prev.points.at(-1).every((n,i)=>n===p[i]))prev.points.push(q);
    else{prev={...strand,id:echo?`curated-echo-${strand.id}`:strand.id,points:[p,q],strength:s,tag,...(echo?{echo:true,width:strand.width*.8}:{})};dest.push(prev);}
    if(echo)ghost=prev;else last=prev;
  };
  for(let j=1;j<points.length;j++){
    const p=points[j-1],q=points[j],u=((p[3]??1)+(q[3]??1))*.5,r=root(u);
    let cut=false,dx=0,dy=0,s=strand.strength,tag='whole',copy=0;
    switch(id){
      case 'roseLattice':cut=web&&u>.28&&seed<A*.72;break;
      case 'fraying':{const site=[.56,.69,.77][index%3],damaged=[1,2,5,6,8].includes(index);cut=(web||rib)&&damaged&&u>site&&u<site+.13*A;
        if(u>site+.13&&damaged){dy=(12+4*Math.sin(t*1.15+index))*A*m*r;dx=side*(5+6*Math.sin(t*.95+index))*A*m*r;tag='loose-end';s*=1-.25*A;}break;}
      case 'scarStitch':{const site=[.46,.61,.74][index%3];cut=(rib||web)&&index!==0&&index!==9&&Math.abs(u-site)<.055*A*r;break;}
      case 'phaseTears':{const band=Math.floor(u*6),tick=Math.floor(t*3.2*frequency),active=v.animated!==false&&((tick+band+(side<0?2:0))%5)<2;
        if(active&&u>.18){const direction=(band+tick)%2?1:-1;dx=side*direction*25*A*m*(v.gates?.displacement??1);dy=direction*5*A*m;tag=`phase-${band}`;cut=web&&(tick+index+band)%7===0;}break;}
      case 'memoryEcho':{const cycle=.5+.5*Math.sin(t*1.05*frequency+index*.62+side),selected=(rib&&[1,3,5,7,9].includes(index))||(web&&index%3===0);
        if(selected&&u>.23){dx=side*6*A*m*cycle*r*(v.gates?.displacement??1);dy=-3*A*m*cycle*r;copy=A*cycle*r;tag='following';}
        s*=1-A*(web?.22:0);break;}
      case 'circuit':s*=1-A*(web?.30:0);break;
      case 'drain':{const boundary=.70+.14*Math.sin(t*.85+(side<0?.55:0));cut=u>boundary+(1-A)*.4;
        s*=1-A*(web?.42:.10);break;}
      case 'unravelling':cut=web&&seed<A*.9||rib&&u>(.48+.21*seed)+(1-A)*.4||edge&&u>.54+(1-A)*.5;s*=1-.25*A;break;
      case 'seedRecall':cut=web&&seed<A*.97||rib&&u>.5&&(index%3!==1)||edge&&u>.36+(1-A)*.6;s*=1-A*(web?.8:.5);break;
    }
    if(cut){last=null;ghost=null;continue;}
    const shift=n=>fitEffectPoint([n[0]+dx,n[1]+dy,n[2],n[3]??u]);
    append(out,shift(p),shift(q),s,tag);
    if(copy>.08&&v.gates?.echoes!==false){const shiftGhost=n=>fitEffectPoint([n[0]-side*25*copy*m*(v.gates?.displacement??1),n[1]+12*copy*m,n[2],n[3]??u]);append(echoes,shiftGhost(p),shiftGhost(q),strand.strength*.65*copy,'echo',true);}else ghost=null;
  }
  return [...out,...echoes];
}

export function curatedConditionAccents(side,v,warp,ribs,growth=1){
  const f=field(v);if(!f||growth<=0)return [];
  const {id,A,t,m}=f,out=[];
  const at=(i,u)=>warp([...cubic(ribs[Math.max(0,Math.min(9,i))],u),u]);
  const off=(p,x,y)=>[p[0]+x,p[1]+y,p[2],p[3]];
  const line=(name,points,width,strength,highlight=true)=>{const s=quant(strength);if(s>.025&&points.length>1&&points.every(p=>p[3]<=growth+.00001))out.push({id:`curated-${name}`,points:points.map(fitEffectPoint),width,strength:s,highlight});};
  const taper=(name,points,width,gain)=>{for(let j=0;j<4;j++){const start=Math.floor(j*(points.length-1)/4),end=Math.floor((j+1)*(points.length-1)/4);line(`${name}-${j}`,points.slice(start,end+1),width*[1,.7,.4,.16][j],A*gain*[1,.8,.45,.18][j],false);}};
  const cross=(name,u,lean=0,width=1.2,gain=.8)=>line(name,ribs.map((_,i)=>at(i,Math.max(.04,Math.min(1,u+(i-4.5)*lean)))),width,A*gain);
  const flow=(name,i,u,length=.15,width=1.3,gain=.9)=>{if(u>.03)line(name,Array.from({length:13},(_,k)=>at(i,Math.max(.02,u-length*k/12))),width,A*gain);};
  const rosette=(name,p,rx,ry,turn,petals,gain=.85)=>line(name,Array.from({length:65},(_,k)=>{const a=k/64*TAU,rad=.66+.34*Math.cos(petals*a+turn);return off(p,Math.cos(a)*rx*rad,Math.sin(a)*ry*rad);}),1.05,A*gain);
  switch(id){
    case 'roseLattice':
      for(const [j,i,u] of [[0,1,.64],[1,4,.7],[2,7,.77]]){const p=mix(at(i,u),at(i+1,u),.5),size=(18+3*Math.sin(t*.6+j))*Math.sqrt(A);
        rosette(`rose-${j}`,p,size,size*1.15,t*.4*(j%2?1:-1),4);
        line(`rose-axis-${j}`,[at(i,Math.max(.1,u-.15)),p,at(i+1,Math.min(1,u+.13))],.85,A*.8);
      }break;
    case 'fraying':
      for(const i of [1,2,5,6,8]){const u=[.56,.69,.77][i%3],p=at(i,u),sway=7*Math.sin(t*1.2+i)*m;
        taper(`fray-${i}`,Array.from({length:17},(_,k)=>{const q=k/16;return off(p,side*q*(6+sway),q*24+q*q*10);}),.9,.85);
      }break;
    case 'scarStitch':
      for(const i of [1,2,3,4,5,6,7,8]){const u=[.46,.61,.74][i%3],pull=.55+.45*Math.sin(t*1.35)**2,top=at(i,u-.075),bottom=at(i,u+.075);
        for(const sign of [-1,1])line(`suture-${i}-${sign}`,Array.from({length:9},(_,k)=>{const q=k/8,p=mix(top,bottom,q);return off(p,side*sign*Math.sin(q*TAU)*7*pull*m,0);}),1.15,A*.95);
      }break;
    case 'recoil':
      for(const i of [1,4,7]){const u=.12+.8*frac(t*.28+(side<0?0:.45));flow(`catch-${i}`,i,u,.12,1.2,.6);}break;
    case 'torsion':
      for(let j=0;j<2;j++)cross(`torsion-seam-${j}`,.35+j*.32,.02*Math.sin(t*1.05+j),.8,.4);break;
    case 'phaseTears':
      // The lattice itself supplies the interruption; no unrelated sparks.
      break;
    case 'memoryEcho':
      if(v.gates?.echoes!==false)for(const i of [1,5,9]){const u=.68,p=at(i,u),cycle=.5+.5*Math.sin(t*1.05+i*.62+side);line(`echo-return-${i}`,[off(p,-side*25*A*cycle*m,12*A*cycle*m),p],.65,A*.45,false);}break;
    case 'corona':
      if(v.gates?.arcs!==false)for(const i of [0,1,2,3,4,6,8,9]){const p=at(i,.80),tip=at(i,.985),prev=at(i,.93),len=Math.hypot(tip[0]-prev[0],tip[1]-prev[1])||1,dx=(tip[0]-prev[0])/len,dy=(tip[1]-prev[1])/len;
        const reach=(24+15*(.5+.5*Math.sin(t*1.7+i)))*A,motion=Math.sin(t*1.1+i)*7*m;
        for(let seg=0;seg<3;seg++)line(`corona-${i}-${seg}`,Array.from({length:9},(_,k)=>{const q=(seg+k/8)/3;return [tip[0]+dx*reach*q-dy*motion*q*q,tip[1]+dy*reach*q+dx*motion*q*q,tip[2],.985];}),[1.6,.85,.3][seg],A*[.95,.55,.2][seg]);
        line(`corona-feed-${i}`,[p,tip],1.3,A*.7);
      }break;
    case 'circuit':
      if(v.gates?.arcs!==false){const step=Math.floor(t*3.6),head=(step%6)/6;
        for(let j=0;j<3;j++){const i=(step+j*3)%9,u=.32+.1*((step+j)%5),a=at(i,u),b=at(i+1,u+.045),mid=mix(a,b,.5);
          line(`circuit-branch-${j}`,[at(i,.18),a,off(mid,side*5*m,-5*m),b,at(i+1,.96)],1.7,A*.95);
          rosette(`circuit-node-${j}`,b,3.8,5.5,0,2,.9);
        }
      }break;
    case 'binding':for(let j=0;j<3;j++){cross(`binding-${j}`,.32+j*.24,.025,1.5,.85);cross(`binding-return-${j}`,.32+j*.24,-.025,.9,.65);}break;
    case 'drain':
      for(const i of [0,2,4,6,8,9]){const u=.06+.69*(1-frac(t*.4+i*.113));flow(`drain-${i}`,i,u,.12,1.65,.85);}
      {const p=at(4,.085);line('drain-root',Array.from({length:33},(_,k)=>{const q=k/32,a=q*TAU*1.7+t*.7,rad=1+q*11*A;return off(p,Math.cos(a)*rad,Math.sin(a)*rad*.7);}),1,A*.9);}break;
    case 'unravelling':
      for(const i of [0,1,3,4,6,8,9]){const u=.48+.21*rank(`${v.seed}:${side}:rib-${i}`),p=at(i,u),swing=Math.sin(t*.75+i)*10*m;
        taper(`unravel-${i}`,Array.from({length:25},(_,k)=>{const q=k/24;return off(p,side*(Math.sin(q*Math.PI)*8+q*swing),q*(45+15*Math.sin(t*.5+i)**2));}),.85,.85);
      }break;
    case 'seedRecall':
      for(const [j,i] of [[0,1],[1,4],[2,8]]){const u=.9,p=at(i,u),pulse=.5+.5*Math.sin(t*.9+j*2);
        rosette(`seed-${j}`,p,5+2*pulse,9+2*pulse,t*.3,3,.95);
        for(const sign of [-1,1]){const q=off(p,side*(13+9*(1-pulse))*m,sign*(9+8*(1-pulse))*m);
          line(`seed-recall-${j}-${sign}`,[q,off(mix(q,p,.5),-side*4*m,sign*3*m),p],.75,A*.7);
          line(`seed-fragment-${j}-${sign}`,[off(q,-3,-5),q,off(q,3,2)],1,A*.8,false);
        }
      }break;
  }
  return out;
}
