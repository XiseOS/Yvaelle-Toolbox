/** Warn when this browser runs a different Yvaelle’s Toolbox build than the one installed,
 * and say once per browser when a new version arrives. */
import {VERSION} from './config.mjs?v=13.0.0-beta.8';
const ID='filament-flight';
export function registerVersionCheck(){
  game.settings.register(ID,'lastSeenVersion',{scope:'client',config:false,type:String,default:''});
  Hooks.once('ready',()=>{
    const installed=game.modules.get(ID)?.version;
    if(installed&&installed!==VERSION){
      ui.notifications?.warn(`Yvaelle’s Toolbox ${installed} is installed, but this browser is still running ${VERSION}. Press Ctrl+F5 (Cmd+Shift+R on Mac) to load the new version.`,{permanent:true});
      return;
    }
    let seen='';try{seen=game.settings.get(ID,'lastSeenVersion');}catch{}
    if(seen!==VERSION){
      if(seen)ui.notifications?.info(`Yvaelle’s Toolbox updated to ${VERSION}.`);
      void game.settings.set(ID,'lastSeenVersion',VERSION).catch(()=>{});
    }
  });
}
