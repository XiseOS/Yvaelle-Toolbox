/** Pure, server-clock pose sampling. No timers, documents or renderer dependencies. */
import {handoffDamping} from './wing-handoffs.mjs?v=13.0.0-beta.8';
export const POSES = Object.freeze(['neutral','forwardGuard','cocoon','leftForwardWrap','rightForwardWrap','aggressiveFlare','raised','trailing','collapsed','drooped','crossed']);
/** Settings › Versions › Wing motion. v10: readable folded pose, portrait
 * clearance, a power-stroke wingbeat, smooth reversal swing and tapered wakes.
 * Classic: the v9 behaviour. The worker receives it with versionStyles. */
let wingMotionStyle='v10';
export function setWingMotionStyle(v){wingMotionStyle=v==='classic'?'classic':'v10';}
export function getWingMotionStyle(){return wingMotionStyle;}
export const unit = x => Math.max(0, Math.min(1, x));
export const ease = x => {x=unit(x);return x*x*(3-2*x);};
export const weightsFor = pose => POSES.map(p => p===pose?1:0);
export const mixWeights = (a,b,t) => a.map((v,i)=>v+(b[i]-v)*t);
const zeros=()=>POSES.map(()=>0);
const validWeights=a=>Array.isArray(a)&&a.length===POSES.length&&a.every(v=>Number.isFinite(v)&&v>=0&&v<=1)&&Math.abs(a.reduce((s,v)=>s+v,0)-1)<0.00001;
const validVelocity=a=>Array.isArray(a)&&a.length===POSES.length&&a.every(v=>Number.isFinite(v)&&Math.abs(v)<=1)&&Math.abs(a.reduce((s,v)=>s+v,0))<0.00001;

/** A quintic handoff with one shared, bounded tangent attenuation keeps the
 * weights in the simplex while retaining the derivative of an interrupted pose.
 * With no initial velocity both acceleration and velocity vanish at each end.
 */
function blend(from,to,p,duration,motion,tip=false,targetVelocity=zeros()) {
  if(p>=1||!duration)return {weights:[...to],velocity:[...targetVelocity]};
  if(p<0)return {weights:[...from],velocity:zeros()};
  if(motion?.style!=='flow') {
    const a=ease(p),d=6*p*(1-p)/duration;
    return {weights:mixWeights(from,to,a),velocity:from.map((v,i)=>(to[i]-v)*d+targetVelocity[i]*a)};
  }
  const lag=tip?0.65*motion.followThrough:0,q=p-lag*p*(1-p),dq=(1-lag+2*lag*p)/duration;
  const velocity=motion[tip?'tipVelocity':'velocity']??zeros();
  const tangent=velocity.map(v=>v*duration/(1-lag)),damp=handoffDamping(from,to,tangent),attenuation=Math.exp(-q*damp);
  const q2=q*q,q3=q2*q,q4=q3*q,q5=q4*q,h=10*q3-15*q4+6*q5,dh=30*q2-60*q3+30*q4,g=q-6*q3+8*q4-3*q5,dg=1-18*q2+32*q3-15*q4;
  return {weights:from.map((a,i)=>a+(to[i]-a)*h+g*tangent[i]*attenuation),
    velocity:from.map((a,i)=>((to[i]-a)*dh+(dg-g*damp)*tangent[i]*attenuation)*dq+targetVelocity[i]*h)};
}

/** Extra timing metadata is optional; old saved transitions remain classic. */
export function poseTimingMotion(sample,controls) {
  const bounded=a=>{const scale=Math.max(1,...a.map(Math.abs));return a.map(v=>v/scale);};
  return {style:controls.style,followThrough:controls.style==='flow'?controls.followThrough:0,
    velocity:bounded(sample.velocity??zeros()),tipFrom:[...(sample.tipWeights??sample.weights)],
    tipVelocity:bounded(sample.tipVelocity??sample.velocity??zeros())};
}

export function validatePose(pose) {
  if (!POSES.includes(pose)) throw new Error(`Unknown wing pose ${pose}. Use ${POSES.join(', ')}.`);
  return pose;
}

export function readPoseTiming(raw, temporary=false) {
  if (raw == null) return null;
  const max=temporary?3600000:10000;
  if (typeof raw!=='object' || typeof raw.id!=='string' || !/^[\w-]{1,64}$/.test(raw.id)
    || !Number.isFinite(raw.started) || !Number.isFinite(raw.duration) || raw.duration<0 || raw.duration>max
    || !validWeights(raw.from))
    throw new Error('Invalid saved wing pose timing.');
  const result={id:raw.id,started:raw.started,duration:raw.duration,from:[...raw.from]};
  if(raw.motion!=null) {
    const m=raw.motion;
    if(!['flow','classic'].includes(m.style)||!Number.isFinite(m.followThrough)||m.followThrough<0||m.followThrough>1||
      !validVelocity(m.velocity)||!validVelocity(m.tipVelocity)||!validWeights(m.tipFrom))throw new Error('Invalid saved pose motion.');
    result.motion={style:m.style,followThrough:m.followThrough,velocity:[...m.velocity],tipFrom:[...m.tipFrom],tipVelocity:[...m.tipVelocity]};
  }
  if (temporary) {
    validatePose(raw.pose);
    if (!Number.isFinite(raw.fadeDuration)||raw.fadeDuration<0||raw.fadeDuration>10000) throw new Error('Invalid saved temporary pose fade duration.');
    Object.assign(result,{pose:raw.pose,fadeDuration:raw.fadeDuration});
  }
  return result;
}

export function samplePose(data, now, animate=true, temporary=true, resumeTransition=true) {
  const t=data.poseTransition, o=temporary?data.temporaryPose:null;
  // A cold load restores the committed pose, independent of the previous
  // session's animation timestamp. Temporary overrides retain their deadlines.
  const p=!animate||!t||!t.duration||resumeTransition===false?1:unit((now-t.started)/t.duration);
  const target=weightsFor(data.pose);
  let root=t?blend(t.from,target,p,t.duration,t.motion):{weights:target,velocity:zeros()};
  let tip=t?blend(t.motion?.tipFrom??t.from,target,p,t.duration,t.motion,true):{weights:[...target],velocity:zeros()};
  let pose=data.pose, phase=p<1?'changing':'steady', progress=p, overrideActive=false;
  if (o && now>=o.started) {
    const elapsed=now-o.started, fade=animate?o.fadeDuration:0;
    if (elapsed < o.duration) {
      progress=fade?unit(elapsed/fade):1;
      root=blend(o.from,weightsFor(o.pose),progress,fade,o.motion);
      tip=blend(o.motion?.tipFrom??o.from,weightsFor(o.pose),progress,fade,o.motion,true);
      pose=o.pose; phase=progress<1?'entering':'holding'; overrideActive=true;
    } else if (fade && elapsed < o.duration+fade) {
      const atEnd=blend(o.from,weightsFor(o.pose),unit(o.duration/fade),fade,o.motion);
      const tipEnd=blend(o.motion?.tipFrom??o.from,weightsFor(o.pose),unit(o.duration/fade),fade,o.motion,true);
      const returning=o.motion?{...o.motion,velocity:atEnd.velocity,tipVelocity:tipEnd.velocity}:null;
      progress=unit((elapsed-o.duration)/fade);
      root=blend(atEnd.weights,root.weights,progress,fade,returning,false,root.velocity);
      tip=blend(tipEnd.weights,tip.weights,progress,fade,returning,true,tip.velocity);
      phase='returning'; overrideActive=true;
    }
  }
  return {pose,weights:root.weights,tipWeights:tip.weights,velocity:root.velocity,tipVelocity:tip.velocity,phase,progress,overrideActive};
}
