/** Flight-feel effects (v10 beta.23; reduced in beta.24; reworked in
 * beta.29). Takeoff, landing and travel are motion only. What remains are
 * the combat moments, the flight modes' own restrained touches and the
 * afterimages toggle:
 *  - the wing shield: a band of woven hardlight filament in front of her,
 *    facing whoever attacked her (or her target, or her heading), that weaves
 *    out from her centre as it rises, ripples magenta where hits land and
 *    unravels as it drops (painted in her own frame, see paintShield);
 *  - shards of light on a hit, and her wings shattering and pulling back
 *    (the beta.28 splinters, restored in beta.30);
 *  - the modes: Surge's burst of filament as she sets off and its braking
 *    flare as she rebounds from a stop, Fast Flight's short streak of
 *    afterimages at speed, Wraith's echo that carries on past her stop;
 *  - afterimages: crystal copies of her and her wings (Echo, Trail or Phase;
 *    the beta.28 copy picture, restored in beta.30); when she stops they
 *    rush back into her;
 *  - a dodge (an attack that missed her) leaves one copy where she was.
 * A small deterministic particle simulation in world pixels plus a 2D-canvas
 * painter; the game uploads the painted surface as one texture. Nothing is
 * shared between clients: every screen derives the same moments from the
 * same flight. */

import {paintShieldStyle,liveStyle} from './v12/shield-styles.mjs?v=13.0.0-beta.8';

const TAU=Math.PI*2;
const MAX=220;
export const FX_IMAGES=Object.freeze(['glint','shard']);
const unit=v=>v<0?0:v>1?1:v,smooth=t=>{t=unit(t);return t*t*(3-2*t);},easeOut=t=>1-(1-unit(t))**3;
// Her hardlight: magenta filament with a hot pink core (never white) and gold accents.
const MAGENTA='231,103,206',HOT='255,150,232',GOLD='207,174,118';

function rng(seed){let a=seed>>>0||1;return()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}

/** How each afterimage style lays its copies: seconds between copies, how
 * long each lasts, its strength, how much it grows and how it drifts back
 * along her path (in token sizes per second). */
export const AFTERIMAGE_LOOKS=Object.freeze({
  echo:{every:.07,life:.5,alpha:.42,grow:.06,drift:0},
  trail:{every:.032,life:.26,alpha:.26,grow:.015,drift:0},
  phase:{every:.13,life:.9,alpha:.36,grow:.03,drift:.55}
});

export class FlightFx {
  constructor(seed=1){this.parts=[];this.random=rng(seed);this.anchor={x:0,y:0};}
  get active(){return this.parts.length>0||this.shieldActive;}
  /** The shield is drawn on its own surface in her frame (see paintShield). */
  get shieldActive(){return (this.shield?.amount??0)>.004;}
  clear(){this.parts.length=0;this.shield=null;}
  add(p){if(this.parts.length>=MAX)this.parts.shift();p.age=0;this.parts.push(p);return p;}

  /** Hardlight glints (an image: a critical save's bits letting go). */
  glints(x,y,size,count,spread=1){
    const R=this.random;
    for(let i=0;i<count;i++){
      const a=TAU*R(),r=size*spread*(.4+R()*.9),v=size*(.4+R()*.9);
      this.add({kind:'glint',x:x+Math.cos(a)*r,y:y+Math.sin(a)*r*.75,vx:Math.cos(a)*v*.4,vy:Math.sin(a)*v*.3-size*.5,drag:2.2,
        life:.5+R()*.5,size:(.09+R()*.08)*size,a:1,rot:0,vr:0});
    }
  }
  /** Small magenta sparks with short tails (a hit on the shield, a shot
   * glancing off a bit), thrown about `dir` within `spread` radians. */
  sparks(x,y,size,count,dir=0,spread=Math.PI,speed=1){
    const R=this.random;
    for(let i=0;i<count;i++){
      const a=dir+(R()*2-1)*spread,v=size*(1.4+R()*1.8)*speed;
      this.add({kind:'spark',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v*.82,drag:5.5,life:.28+R()*.22,size:size*(.035+R()*.025),a:.9,rot:0,vr:0});
    }
  }
  /** Small splinters of light thrown out by a hard hit. */
  shards(x,y,size,count,strength=1,dx=0,dy=0){
    const R=this.random;
    for(let i=0;i<count;i++){
      const a=TAU*R(),v=(2.2+R()*2.8)*size*strength;
      this.add({kind:'shard',x,y,vx:Math.cos(a)*v+dx*size*2,vy:Math.sin(a)*v*.6+dy*size*2,drag:3.8,
        life:.45+R()*.45,size:(.07+R()*.05)*size,a:1,rot:a,vr:(R()-.5)*16});
    }
  }
  /** Her wings breaking into splinters that fly out and pull back to where
   * they came from (shatter and reform). Points spread over both wings.
   * (beta.30: the beta.28 look and timing again.) */
  shatterWings(x,y,span,size,count,strength=1){
    const R=this.random;
    for(let i=0;i<count;i++){
      const side=i%2?1:-1,u=.15+R()*.85,ox=x+side*u*span*.48,oy=y+(R()-.6)*span*.55*(1-.4*u);
      const a=Math.atan2(oy-y,ox-x)+(R()-.5)*.9,d=size*(.5+R()*.9)*strength;
      this.add({kind:'reform',x:ox,y:oy,ox,oy,dx:Math.cos(a)*d,dy:Math.sin(a)*d,vx:0,vy:0,drag:0,life:1.1,size:(.06+R()*.06)*size,a:1,rot:a,vr:(R()-.5)*14,additive:true});
    }
  }
  /** A fading copy of her. `img` is her ghost (see liveGhost), drawn `w`
   * wide; it can drift and grow as it fades. `flicker` makes it phase. */
  ghost(x,y,w,rot,img,{alpha=.42,life=.5,grow=.06,vx=0,vy=0,drag=1.5,flicker=0}={}){
    if(!img)return;
    this.add({kind:'ghost',x,y,vx,vy,drag,life,size:w,a:alpha,grow,rot,vr:0,img,flicker});
  }
  /** She stopped: every copy still fading rushes back into her. */
  gather(x,y){for(const p of this.parts)if(p.kind==='ghost'&&!p.home&&!p.keep){p.home={x,y};p.life=Math.min(p.life,p.age+.28);}}
  /** Thin streaks of filament flung out behind her (Surge setting off). */
  streaks(x,y,size,dirX,dirY,count,strength=1){
    const R=this.random,back=Math.atan2(-dirY,-dirX);
    for(let i=0;i<count;i++){
      const a=back+(i/(count-1||1)-.5)*1.1+(R()-.5)*.18,v=size*(2.6+R()*1.6)*strength,o=size*(.18+R()*.12);
      this.add({kind:'streak',x:x+Math.cos(a)*o,y:y+Math.sin(a)*o*.85,vx:Math.cos(a)*v,vy:Math.sin(a)*v*.85,drag:6,life:.34+R()*.12,
        size:size*(.42+R()*.2),a:1,rot:Math.atan2(Math.sin(a)*.85,Math.cos(a)),vr:0});
    }
  }
  /** A thin arc of hardlight (a braking field, the crescent behind a burst):
   * centred on (x,y), facing `angle`, `span` radians wide, growing from r0 to r1. */
  arc(x,y,angle,span,r0,r1,{life=.45,alpha=.6,width=1}={}){
    this.add({kind:'arc',x,y,vx:0,vy:0,drag:0,angle,span,r0,r1,life,a:alpha,size:r1,width,rot:0,vr:0});
  }
  /** A shot that one of her bits intercepts (beta.26): it flies from (x0,y0)
   * to the bit at (x1,y1), landing after `hit` seconds, then glances off to
   * one side (`side` ±1) in a short spray of sparks and fades. */
  shot(x0,y0,x1,y1,hit,size,side=1){
    const a=Math.atan2(y1-y0,x1-x0),g=a+Math.PI+side*1.15;
    this.add({kind:'shot',x:x0,y:y0,x0,y0,x1,y1,hit,gx:Math.cos(g),gy:Math.sin(g),vx:0,vy:0,drag:0,life:hit+.42,size,a:1,rot:a,vr:0});
  }

  step(dt){
    if(!(dt>0))return;dt=Math.min(dt,.05);
    if(this.shield){
      const sh=this.shield;sh.time=(sh.time??0)+dt;
      // (12.0.0-beta.2) when she began to raise it and to lower it, for the shield styles' own timelines
      if(sh.want!==sh.was){if(sh.want===true&&(sh.was===false||sh.was===undefined&&(sh.amount??0)<.3))sh.upAt=sh.time;if(sh.want===false&&sh.was===true)sh.downAt=sh.time;sh.was=sh.want;}
      if(sh.hits){let n=0;for(const h of sh.hits)if((h.age+=dt)<.9)sh.hits[n++]=h;sh.hits.length=n;}
    }
    const parts=this.parts;let n=0,landed=null;
    for(const p of parts){
      p.age+=dt;if(p.age>=p.life)continue;
      const k=Math.exp(-(p.drag??0)*dt);p.vx*=k;p.vy*=k;
      if(p.kind==='reform'){const t=p.age/p.life,o=t<.42?1-(1-t/.42)**3:t<.55?1:1-((t-.55)/.45)**2*(3-2*(t-.55)/.45);p.x=p.ox+p.dx*o;p.y=p.oy+p.dy*o;p.rot+=p.vr*dt*(1-t);}
      else if(p.kind==='shot'){
        if(p.age<p.hit){const u=p.age/p.hit;p.x=p.x0+(p.x1-p.x0)*u;p.y=p.y0+(p.y1-p.y0)*u;}
        else{
          // It glances off the bit: sparks at the point of contact, and the shot skips away.
          if(!p.landed){p.landed=true;(landed??=[]).push(p);}
          const u=p.age-p.hit;p.x=p.x1+p.gx*p.size*2.6*u;p.y=p.y1+p.gy*p.size*2.6*u;p.rot=Math.atan2(p.gy,p.gx)+u*3;
        }
      }
      else if(p.home){const q=1-Math.exp(-14*dt);p.x+=(p.home.x-p.x)*q;p.y+=(p.home.y-p.y)*q;}
      else{p.x+=p.vx*dt;p.y+=p.vy*dt;p.rot=(p.rot??0)+(p.vr??0)*dt;}
      parts[n++]=p;
    }
    parts.length=n;
    // (Sparks are added after the sweep, never while it compacts the list.)
    if(landed)for(const p of landed){this.shards(p.x1,p.y1,p.size,7,.42,p.gx*.8,p.gy*.8);this.glints(p.x1,p.y1,p.size*.45,3,.35);}
  }

  /** The square around everything alive (the shield has its own surface):
   * its centre and half its side (world px), written into `out`. */
  bounds(out={}){
    let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
    for(const p of this.parts){const s=pad(p);if(p.x-s<x0)x0=p.x-s;if(p.x+s>x1)x1=p.x+s;if(p.y-s<y0)y0=p.y-s;if(p.y+s>y1)y1=p.y+s;}
    if(!(x1>=x0&&y1>=y0)){out.x=out.y=out.half=0;return out;}
    out.x=(x0+x1)/2;out.y=(y0+y1)/2;out.half=Math.max(x1-x0,y1-y0)/2;
    return out;
  }

  /** Paint into ctx, mapping world (x,y) to ((x-ox)*k, (y-oy)*k). */
  paint(ctx,images,ox=0,oy=0,k=1){
    // Afterimages first (behind), then the light (added).
    for(const p of this.parts){
      if(p.kind!=='ghost')continue;
      const t=p.age/p.life;let a=p.a*(1-t)**1.5;
      if(p.flicker)a*=1-p.flicker*(.5-.5*Math.cos(p.age*19))*.45;
      if(a<=.004)continue;
      const w=p.size*k*(1+p.grow*t*4);
      ctx.save();ctx.translate((p.x-ox)*k,(p.y-oy)*k);ctx.rotate(p.rot);ctx.globalAlpha=Math.min(1,a);ctx.drawImage(p.img,-w/2,-w/2,w,w);ctx.restore();
    }
    ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
    for(const p of this.parts){
      // (Images set their own alpha below; the drawn light carries its alpha in its colours.)
      ctx.globalAlpha=1;
      switch(p.kind){
        case 'ghost':continue;
        case 'shot':paintShot(ctx,p,ox,oy,k);continue;
        case 'streak':paintStreak(ctx,p,ox,oy,k);continue;
        case 'arc':paintArc(ctx,p,ox,oy,k);continue;
        case 'spark':paintSpark(ctx,p,ox,oy,k);continue;
      }
      const img=images?.[p.kind==='reform'?'shard':p.kind];if(!img)continue;
      const t=p.age/p.life,x=(p.x-ox)*k,y=(p.y-oy)*k;
      let alpha,w,h;
      if(p.kind==='glint'){alpha=p.a*Math.sin(Math.PI*Math.min(1,t*1.15));w=h=p.size*k;}
      else if(p.kind==='reform'){alpha=p.a*Math.min(1,t*12)*(t>.88?(1-t)/.12:1);w=p.size*k*.5;h=p.size*k*1.6;}
      else {alpha=p.a*(1-t)**1.2;w=p.size*k*.5;h=p.size*k*1.6;}
      if(alpha<=.004||w<.3)continue;
      ctx.globalAlpha=Math.min(1,alpha);
      if(p.rot){ctx.save();ctx.translate(x,y);ctx.rotate(p.rot);ctx.drawImage(img,-w/2,-h/2,w,h);ctx.restore();}
      else ctx.drawImage(img,x-w/2,y-h/2,w,h);
    }
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  /** A ripple across the wing shield where a hit lands (dx,dy: the push). */
  shieldHit(dx,dy,strength=1){if(this.shield)(this.shield.hits??=[]).push({age:0,angle:Math.atan2(-dy,-dx),strength});}
}

/** How far a particle's picture reaches from its point (world px). */
function pad(p){return p.kind==='ghost'?p.size*(.5+p.grow*4):p.kind==='shot'?p.size*.62:p.kind==='arc'?p.r1*1.1+4:p.kind==='streak'?p.size*1.2:p.size*2;}

/** A thread of her light along a path: a soft glow, the filament, a hot core. */
function filament(ctx,path,alpha,w){
  if(alpha<=.004)return;
  ctx.strokeStyle=`rgba(${MAGENTA},${.16*alpha})`;ctx.lineWidth=w*5;path();ctx.stroke();
  ctx.strokeStyle=`rgba(${MAGENTA},${.7*alpha})`;ctx.lineWidth=w*1.6;path();ctx.stroke();
  ctx.strokeStyle=`rgba(${HOT},${.55*alpha})`;ctx.lineWidth=w*.6;path();ctx.stroke();
}
function paintStreak(ctx,p,ox,oy,k){
  const t=p.age/p.life,alpha=p.a*Math.sin(Math.PI*Math.min(1,t*1.4+.08))*(1-t);
  const x=(p.x-ox)*k,y=(p.y-oy)*k,L=p.size*k*(.4+.6*easeOut(t*2.5)),c=Math.cos(p.rot),s=Math.sin(p.rot);
  const g=ctx.createLinearGradient(x,y,x-c*L,y-s*L);g.addColorStop(0,`rgba(${HOT},${.8*alpha})`);g.addColorStop(.35,`rgba(${MAGENTA},${.55*alpha})`);g.addColorStop(1,`rgba(${MAGENTA},0)`);
  ctx.strokeStyle=g;ctx.lineWidth=Math.max(.8,p.size*k*.05);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-c*L,y-s*L);ctx.stroke();
}
function paintArc(ctx,p,ox,oy,k){
  const t=p.age/p.life,e=easeOut(t),alpha=p.a*Math.sin(Math.PI*Math.min(1,t*1.25+.05))*(1-t*.4);if(alpha<=.004)return;
  const x=(p.x-ox)*k,y=(p.y-oy)*k,r=(p.r0+(p.r1-p.r0)*e)*k,half=p.span*(.75+.25*e)/2;
  // Fading at both ends: drawn as short pieces that taper toward the tips.
  const n=14;
  for(let i=0;i<n;i++){
    const u0=i/n,u1=(i+1)/n,m=(u0+u1)/2,taper=Math.sin(Math.PI*m)**1.2;
    const a0=p.angle-half+2*half*u0,a1=p.angle-half+2*half*u1;
    filament(ctx,()=>{ctx.beginPath();ctx.ellipse(x,y,r,r*.82,0,a0,a1);},alpha*taper,Math.max(.8,r*.03*p.width));
  }
}
function paintSpark(ctx,p,ox,oy,k){
  const t=p.age/p.life,alpha=p.a*(1-t)**1.3;if(alpha<=.004)return;
  const x=(p.x-ox)*k,y=(p.y-oy)*k,v=Math.hypot(p.vx,p.vy)*k,len=Math.min(p.size*k*6,v*.05+1);
  const c=v>0?p.vx*k/v:0,s=v>0?p.vy*k/v:0;
  ctx.strokeStyle=`rgba(${MAGENTA},${.8*alpha})`;ctx.lineWidth=Math.max(.8,p.size*k*.9);ctx.beginPath();ctx.moveTo(x-c*len,y-s*len);ctx.lineTo(x,y);ctx.stroke();
  ctx.fillStyle=`rgba(${HOT},${.8*alpha})`;ctx.beginPath();ctx.arc(x,y,Math.max(.6,p.size*k*.6),0,TAU);ctx.fill();
}

/** An incoming shot: a short bright dart, its tail fading behind it. After
 * it glances off a bit it dims as it skips away. */
function paintShot(ctx,p,ox,oy,k){
  const a=p.age<p.hit?Math.min(1,p.age/.06):1-(p.age-p.hit)/(p.life-p.hit);if(a<=.01)return;
  const x=(p.x-ox)*k,y=(p.y-oy)*k,len=p.size*k*(p.age<p.hit?.55:.3),c=Math.cos(p.rot),s=Math.sin(p.rot);
  const tx=x-c*len,ty=y-s*len,g=ctx.createLinearGradient(tx,ty,x,y);
  g.addColorStop(0,'rgba(255,238,214,0)');g.addColorStop(.7,`rgba(255,238,214,${.55*a})`);g.addColorStop(1,`rgba(255,250,240,${a})`);
  ctx.save();ctx.globalAlpha=1;ctx.lineCap='round';ctx.strokeStyle=g;ctx.lineWidth=Math.max(1,p.size*k*.045);
  ctx.beginPath();ctx.moveTo(tx,ty);ctx.lineTo(x,y);ctx.stroke();
  const r=Math.max(1.5,p.size*k*.06),h=ctx.createRadialGradient(x,y,0,x,y,r*2.2);h.addColorStop(0,`rgba(255,246,232,${.8*a})`);h.addColorStop(1,'rgba(255,246,232,0)');
  ctx.fillStyle=h;ctx.beginPath();ctx.arc(x,y,r*2.2,0,TAU);ctx.fill();ctx.restore();
}

/* ------------------------------------------------------------ wing shield
 * Woven hardlight in her frame: facing +x from her centre, painted onto a
 * square of half-side `half` (world px) at scale k. The renderer turns and
 * places that square on her every display frame, so it never lags her. */
export const SHIELD_REACH=1.42;
const ARC=new Float64Array(2),DENT=new Float64Array(2),TX=new Float64Array(23),TY=new Float64Array(23),TM=new Float64Array(23),TG=new Float64Array(23);
/** True while the shield is visibly changing (rising, dropping, a hit
 * rippling): the renderer then repaints every display frame. */
export function shieldChanging(sh){
  if(!sh)return false;
  if(Math.abs((sh.amount??0)-(sh.shown??-1))>.002||(sh.hits?.length??0)>0)return true;
  // a shield style: the rotor always turns; the others move while they are raised into place
  return !!sh.style&&sh.style!=='weave'&&(liveStyle(sh.style)||sh.upAt!=null&&(sh.time??0)-sh.upAt<2.1);
}
export function paintShield(ctx,sh,half,k){
  if(sh.style&&sh.style!=='weave')return paintShieldStyle(ctx,sh,half,k);
  const a=unit(sh.amount),t=sh.time??0,R=sh.r*k,c=half*k;if(a<=.004)return;
  const weave=easeOut(a/.85),open=smooth(a),span=1.02*(.55+.45*open);
  const rIn=R*(.8+.12*open),rOut=R*(1+.14*open),hits=sh.hits??[];
  // (Ordinary blending: crossing threads and a ripple stay magenta, never bloom to white.)
  ctx.save();ctx.globalCompositeOperation='source-over';ctx.lineCap='round';ctx.lineJoin='round';
  // A hit dents the weave inward where it lands and the dent rings outward
  // along it; the threads there glow hotter (magenta, never white).
  // (Beta.32: the same numbers as before, kept in scratch arrays instead of
  // ~1,800 small arrays a paint; the shield repaints up to 60 times a second.)
  const dent=(q,r)=>{let d=0,glow=0;for(const h of hits){const g=Math.atan2(Math.sin(q-h.angle),Math.cos(q-h.angle)),e=Math.exp(-h.age*5.5)*(h.strength??1);
    d+=-R*.07*Math.exp(-((g/.3)**2))*Math.sin(h.age*30)*e;glow+=Math.exp(-((Math.abs(g)-h.age*2.4)**2)/.03)*(1-h.age/.9)*(h.strength??1);}
    DENT[0]=r+d;DENT[1]=glow;};
  const P=(q,r)=>[c+Math.cos(q)*r,c+Math.sin(q)*r];
  // The light travelling along the threads (slow), and how far the weave has
  // grown out from her centre line (it weaves out as the shield rises and
  // unravels from the ends as it drops).
  const pulse=((t*.42)%1.6)-.3,reach=weave;
  // A faint field behind the threads.
  {const g=ctx.createRadialGradient(c,c,rIn*.9,c,c,rOut*1.12);g.addColorStop(0,`rgba(${MAGENTA},0)`);g.addColorStop(.5,`rgba(${MAGENTA},${.13*a})`);g.addColorStop(1,`rgba(${MAGENTA},0)`);
    ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(c,c);ctx.arc(c,c,rOut*1.12,-span*reach,span*reach);ctx.closePath();ctx.fill();}
  const thread=(fn,alpha,w)=>{
    // fn(v) sets ARC to [angle, radius] for v in -1..1; drawn in short pieces, each
    // fading toward the ends of the woven band (which grows out from her
    // centre line as `reach`) and brightening under a ripple or the pulse.
    const n=22;
    for(let i=0;i<=n;i++){fn(i/n*2-1);const q=ARC[0];dent(q,ARC[1]);const r=DENT[0];TX[i]=c+Math.cos(q)*r;TY[i]=c+Math.sin(q)*r;TM[i]=q/span;TG[i]=DENT[1];}
    for(let i=0;i<n;i++){
      const x0=TX[i],y0=TY[i],m0=TM[i],g0=TG[i],x1=TX[i+1],y1=TY[i+1],m1=TM[i+1],g1=TG[i+1],m=(m0+m1)/2,e=Math.abs(m);
      const edge=1-smooth((e-reach*.58)/(reach*.42+1e-3));if(edge<=.004)continue;
      const lit=.55+.45*Math.exp(-((m-pulse)**2)/.02)+Math.min(1.6,(g0+g1)*.9);
      const al=alpha*a*edge*Math.min(1.45,lit);if(al<=.004)continue;
      ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x1,y1);
      ctx.strokeStyle=`rgba(${MAGENTA},${.14*al})`;ctx.lineWidth=w*4.5;ctx.stroke();
      ctx.strokeStyle=`rgba(${MAGENTA},${Math.min(1,.62*al)})`;ctx.lineWidth=w*1.4;ctx.stroke();
      ctx.strokeStyle=`rgba(${HOT},${Math.min(.55,.3*al*(1+.5*(g0+g1)))})`;ctx.lineWidth=w*.55;ctx.stroke();
    }
  };
  const w=Math.max(.7,R*.022);
  // The rims: two long threads, the inner one a touch brighter.
  thread(v=>{ARC[0]=v*span*reach;ARC[1]=rIn+(rOut-rIn)*.04*Math.sin(v*9+t*1.3);},.95,w);
  thread(v=>{ARC[0]=v*span*reach;ARC[1]=rOut-(rOut-rIn)*.04*Math.sin(v*8-t*1.1);},.8,w*.9);
  // The weave: threads crossing between the rims on the diagonal, in both directions.
  const K=7,width=span*2/K;
  for(let j=0;j<K;j++){
    const q0=-span+width*(j+.5);
    for(const dir of [1,-1])thread(v=>{ARC[0]=q0+v*width*.62+Math.sin(t*.9+j)*.012;ARC[1]=rIn+(rOut-rIn)*(.5+.5*dir*v);},.5,w*.75);
  }
  // Gold anchors where the weave is tied off at each end.
  if(open>.3){const ga=a*smooth((open-.3)/.5)*.85;
    for(const e of [-1,1]){const q=e*span*reach*.8,r=(rIn+rOut)/2,[x,y]=P(q,r),s=Math.max(1.2,R*.045);
      ctx.fillStyle=`rgba(${GOLD},${ga})`;ctx.beginPath();ctx.moveTo(x,y-s);ctx.lineTo(x+s*.6,y);ctx.lineTo(x,y+s);ctx.lineTo(x-s*.6,y);ctx.closePath();ctx.fill();}}
  ctx.restore();
}

/** Turn this frame's combat moments into effects at her body (x,y). Takeoff,
 * landing and travel make none: they are motion only. */
export function emitFlightEvents(fx,out,events,{size,body,effects=true,wingSpan=0,combat=null}={}){
  if(!effects)return;
  // (beta.35) Her Combat moments settings: a switch for each kind and one
  // strength that scales how many pieces there are and how bright they burn.
  const c=combat??{};if(c.combatFx===false)return;
  const k=Math.min(1.5,Math.max(.25,Number(c.combatStrength)||1)),n=v=>Math.max(1,Math.round(v*k)),on=key=>c[key]!==false;
  const bx=body?.x??out.shadow.x,by=body?.y??out.shadow.y-size*.3-out.rise;
  for(const e of events){
    switch(e.type){
      case 'impact':if(on('combatLanding'))fx.shards(bx,out.shadow.y-size*.15,size,n(5),(.5+.3*(e.strength??1))*k);break;
      case 'shatter':if(wingSpan&&on('combatShatter'))fx.shatterWings(bx,by,wingSpan,size,n(22),(.6+.4*e.strength)*k);break;
      case 'shieldHit':{
        if(!on('combatShield'))break;
        fx.shieldHit(e.dx??0,e.dy??1,(.7+.3*(e.strength??1))*k);
        const sh=fx.shield;if(sh){const q=Math.atan2(-(e.dy??1),-(e.dx??0)),r=sh.r*1.05;fx.sparks(sh.x+Math.cos(q)*r,sh.y+Math.sin(q)*r,size*(out.scale??1),n(5),q,.8,.7*Math.sqrt(k));}
        break;
      }
      case 'hit':if(on('combatHits'))fx.shards(bx,by,size,n(4+6*e.strength),.6*k,e.dx,e.dy);break;
      // A ranged miss taken by a bit: the shot comes in along the line of fire
      // and lands where the bit meets it (see interceptAmount).
      case 'intercept':{
        if(!on('combatShots'))break;
        // (Her bits shrink with her height, so the meeting point does too.)
        const dx=e.dx??0,dy=e.dy??1,u=size*(out.scale??1),r=(e.reach??1.9)*u,ix=bx-dx*r,iy=by-dy*r;
        // It comes in along the line from the attacker: from the edge of their
        // token when they are close, else from a little way out along it.
        let sx=ix-dx*u*2.4,sy=iy-dy*u*2.4;
        const from=e.from;
        if(Number.isFinite(from?.x)&&Number.isFinite(from?.y)){
          const ax=from.x-ix,ay=from.y-iy,d=Math.hypot(ax,ay);
          if(d>1){const len=Math.max(Math.min(d*.5,size*.3),Math.min(d-size*.35,u*2.4));sx=ix+ax/d*len;sy=iy+ay/d*len;}
        }
        fx.shot(sx,sy,ix,iy,(e.hit??.3)*k,u,e.glance??1);break;
      }
      // A critical success on a save: each braced bit glints as it lets go.
      case 'braceRelease':if(on('combatSaves')&&e.outcome==='criticalSuccess'&&e.points){const u=size*(out.scale??1);for(const [px,py] of e.points)fx.glints(bx+px*u,by+py*u,u*.32,n(3),.45*k);}break;
    }
  }
}

/** The flight modes' own touches (beta.29), restrained and tied to a real
 * moment: Surge throws a burst of filament behind her as she sets off and
 * meets a braking flare as she rebounds from a stop; Fast Flight leaves a
 * short streak of copies at speed; Wraith's echo carries on past her stop
 * and fades. `character` is the mode's (blended) character. */
export function emitModeEffects(fx,state,out,events,character,{size,body,img=null,rot=0,dt=0,speed=0,dirX=0,dirY=0}){
  const c=character??{},u=size*(out.scale??1),bx=body.x,by=body.y;
  for(const e of events){
    if(e.type==='burst'&&c.burstFx>.05){
      const k=c.burstFx*(e.strength??1);
      fx.streaks(bx,by,u,e.dx,e.dy,7,.9+.3*k);
      fx.arc(bx-e.dx*u*.3,by-e.dy*u*.3,Math.atan2(-e.dy,-e.dx),1.3,u*.45,u*.85,{life:.45,alpha:.62*k,width:1.2});
    }
    // Surge: at the far point of her slide she meets a braking flare of
    // hardlight in front of her and rebounds from it.
    if(e.type==='overshoot'&&c.rebound>.05)
      fx.arc(bx+e.dx*u*.3,by+e.dy*u*.3,Math.atan2(e.dy,e.dx),1.7,u*.48,u*.8,{life:.55,alpha:.85*c.rebound*Math.min(1,.5+e.dist*2),width:1.35});
    if(e.type==='stop'){
      const k=e.strength??0;
      if(c.echo>.05&&img&&k>.06){
        // The echo carries on the way she was going (about a token) and slows as it fades.
        const v=2.4*u;
        fx.ghost(bx,by,size*(state.wingScale??3.5)*(out.scale??1),rot,img,{alpha:.75*c.echo*Math.min(1,.6+k*1.5),life:1.05,grow:.01,vx:e.dx*v,vy:e.dy*v,drag:1.7,flicker:.6});
        const last=fx.parts.at(-1);if(last?.kind==='ghost')last.keep=true;
      }
    }
  }
  // Fast Flight: a short streak of copies just behind her while she is at speed.
  if(c.streak>.05&&img&&speed>2.4){
    state.streakClock=(state.streakClock??0)+dt;
    if(state.streakClock>=.04){state.streakClock=0;
      const k=Math.min(1,(speed-2.4)/2)*c.streak;
      fx.ghost(bx,by,size*(state.wingScale??3.5)*(out.scale??1),rot,img,{alpha:.3*k,life:.24,grow:0});
      const last=fx.parts.at(-1);if(last?.kind==='ghost')last.keep=true;}
  }else state.streakClock=0;
}

/** Afterimages: while she moves, lay copies of her in the chosen style; when
 * she stops they rush back into her; a dodge leaves one where she was. */
export function emitAfterimages(fx,state,{x,y,size,rot,img,speed,dt,style,events=[],dirX=0,dirY=0}){
  if(!img)return;
  for(const e of events){
    if(e.type==='dodge')fx.ghost(x-(e.dx??0)*size*.05,y-(e.dy??0)*size*.05,size,rot,img,{alpha:.5,life:.7,grow:.02});
    if(e.type==='stop'&&style&&style!=='off')fx.gather(x,y);
  }
  const look=AFTERIMAGE_LOOKS[style];
  if(!look||speed<1){state.ghostClock=0;return;}
  state.ghostClock=(state.ghostClock??0)+dt;
  if(state.ghostClock<look.every)return;state.ghostClock=0;
  const k=Math.min(1,(speed-1)/2.5);
  fx.ghost(x,y,size,rot,img,{alpha:look.alpha*(.5+.5*k),life:look.life,grow:look.grow,vx:-dirX*look.drift*size,vy:-dirY*look.drift*size,drag:1.2});
}

/* ------------------------------------------------------------ her copies
 * Afterimages, the dodge copy and the modes' echoes are built from her live
 * wings (the wing renderer's own layers, exactly as they are drawn now) with
 * her portrait at their centre, softly faded at its edge. A copy is taken at
 * most every 0.2 s into a small ring of canvases (a copy alive on screen is
 * never repainted under it). The portrait is loaded as soon as she flies, so
 * the first dodge already has its copy. */
const portraits=new Map();
/** Start loading her portrait for copies (same-origin or CORS art only: a
 * tainted picture would poison the effects texture). Null until loaded. */
export function ghostPortrait(src){
  if(!src||!globalThis.Image)return null;
  let rec=portraits.get(src);
  if(!rec){
    rec={img:null};portraits.set(src,rec);if(portraits.size>24)portraits.delete(portraits.keys().next().value);
    const img=new Image();img.decoding='async';img.crossOrigin='anonymous';
    img.onerror=()=>{rec.failed=true;};img.onload=()=>{rec.img=img;};img.src=src;
  }
  return rec.img;
}
const RING=8,GHOST_SIZE=320;
/** Her copy now, from the wing renderer `renderer` (its layer surfaces and
 * art size), her portrait and the wing width in token sizes. `memory` is
 * per-token storage. Returns a canvas to draw `token size × wingScale` wide,
 * or null when no copy can be made yet. */
export function liveGhost(memory,renderer,src,wingScale=3.5,now=0,{doc=globalThis.document}={}){
  if(!doc)return null;
  // (The token renderer keeps its wing painter as `rig`.)
  const rig=renderer?.layerRecords?renderer:renderer?.rig,portrait=ghostPortrait(src),layers=rig?.layerRecords,S=rig?.size;
  const ready=Array.isArray(layers)&&S>0&&layers.some(l=>l.hasContent&&l.surface?.width>1);
  if(!ready&&!portrait)return null;
  const ring=memory.ghostRing??={canvases:[],next:0,at:-Infinity,last:null};
  if(ring.last&&now-ring.at<200&&ring.wingScale===wingScale)return ring.last;
  let c=ring.canvases[ring.next];
  if(!c){c=doc.createElement('canvas');c.width=c.height=GHOST_SIZE;ring.canvases[ring.next]=c;}
  const g=c.getContext('2d');if(!g)return null;
  g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.clearRect(0,0,GHOST_SIZE,GHOST_SIZE);
  const k=GHOST_SIZE/(S||GHOST_SIZE);
  const drawLayers=front=>{if(!ready)return;for(const l of layers){if(!l.hasContent||!(l.surface?.width>1)||!!l.front!==front)continue;const v=l.viewport??{x:0,y:0,width:l.surface.width,height:l.surface.height};
    try{g.drawImage(l.surface,v.x*k,v.y*k,v.width*k,v.height*k);}catch{}}};
  drawLayers(false);
  if(portrait){
    const d=GHOST_SIZE/Math.max(1,wingScale),r=d/2,cx=GHOST_SIZE/2,cy=GHOST_SIZE/2;
    const p=ring.portraitMask??=doc.createElement('canvas');p.width=p.height=Math.ceil(d);
    const pg=p.getContext('2d');pg.globalCompositeOperation='source-over';pg.clearRect(0,0,p.width,p.height);
    pg.drawImage(portrait,0,0,d,d);
    // A soft edge instead of a ring, and a faint wash of her light.
    pg.globalCompositeOperation='destination-in';const m=pg.createRadialGradient(r,r,r*.55,r,r,r);m.addColorStop(0,'rgba(0,0,0,.85)');m.addColorStop(1,'rgba(0,0,0,0)');pg.fillStyle=m;pg.fillRect(0,0,d,d);
    pg.globalCompositeOperation='source-atop';pg.fillStyle=`rgba(${MAGENTA},.28)`;pg.fillRect(0,0,d,d);
    g.drawImage(p,cx-r,cy-r);
  }
  drawLayers(true);
  ring.last=c;ring.at=now;ring.wingScale=wingScale;ring.next=(ring.next+1)%RING;
  return c;
}

/** Her ghost for afterimages and the dodge copy (beta.30: the beta.28 look
 * again): her wing silhouette as soft magenta light with her portrait (washed
 * magenta) in a pale ring at its centre, sized for `wingScale`. Built once per
 * portrait; null until loaded. The runtime calls it as soon as she flies, so
 * the first dodge of a session already has its copy. */
const ghosts=new Map();
let wingSil=null;
export function ghostImage(src,wingScale=3.5,{wingsSrc=null,doc=globalThis.document}={}){
  if(!src||!doc)return null;
  const key=`${src}|${Math.round(wingScale*20)}`;
  let rec=ghosts.get(key);
  if(!rec){
    rec={canvas:null};ghosts.set(key,rec);if(ghosts.size>24)ghosts.delete(ghosts.keys().next().value);
    // Same-origin or CORS-enabled art only: a tainted picture would poison the
    // effects texture uploaded to the GPU. Other art simply has no copies.
    const img=new Image();img.decoding='async';img.crossOrigin='anonymous';
    img.onerror=()=>{rec.failed=true;};
    img.onload=()=>{rec.portrait=img;};
    img.src=src;
  }
  if(wingsSrc&&!wingSil){wingSil={img:new Image(),ok:false};wingSil.img.onload=()=>{wingSil.ok=true;};wingSil.img.onerror=()=>{wingSil.failed=true;};wingSil.img.src=wingsSrc;}
  if(!rec.canvas&&rec.portrait&&(!wingSil||wingSil.ok||wingSil.failed)){
    const S=320,c=doc.createElement('canvas');c.width=c.height=S;const g=c.getContext('2d');if(!g)return null;
    if(wingSil?.ok){
      // Her wing silhouette, recoloured to soft magenta light.
      const w=doc.createElement('canvas');w.width=w.height=S;const wg=w.getContext('2d');
      wg.drawImage(wingSil.img,0,0,S,S);wg.globalCompositeOperation='source-in';wg.fillStyle='rgba(231,103,206,.7)';wg.fillRect(0,0,S,S);
      g.drawImage(w,0,0);
    }
    const d=S/Math.max(1,wingScale),r=d/2;
    g.save();g.beginPath();g.arc(S/2,S/2,r-1,0,TAU);g.clip();g.drawImage(rec.portrait,S/2-r,S/2-r,d,d);
    g.globalCompositeOperation='source-atop';g.fillStyle='rgba(231,103,206,.5)';g.fillRect(0,0,S,S);g.restore();
    g.strokeStyle='rgba(255,214,255,.8)';g.lineWidth=2;g.beginPath();g.arc(S/2,S/2,r-1,0,TAU);g.stroke();
    rec.canvas=c;
  }
  return rec.canvas;
}
