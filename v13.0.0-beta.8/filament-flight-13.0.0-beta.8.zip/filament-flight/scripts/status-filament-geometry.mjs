/** Bounded material-space FX primitives shared by the three status families. */
import {cubic} from './wing-art.mjs?v=13.0.0-beta.8';
import {growthPaths} from './flight-dynamics.mjs?v=13.0.0-beta.8';
export const FX_TAU=Math.PI*2;
export const fxUnit=n=>Math.max(0,Math.min(1,Number.isFinite(n)?n:0));
export const fxMix=(a,b,t)=>a+(b-a)*t;
export const fxCycle=(t,rate=1,offset=0)=>.5-.5*Math.cos(t*rate+offset);
export function ribPoint(ribs,index,u){
  u=fxUnit(u);const rib=ribs[Math.max(0,Math.min(ribs.length-1,index))];
  const points=rib?.statusPoints;
  if(points?.length){
    for(let i=1;i<points.length;i++){
      const a=points[i-1],b=points[i],lo=a[2]??(i-1)/(points.length-1),hi=b[2]??i/(points.length-1);
      if(u>=Math.min(lo,hi)&&u<=Math.max(lo,hi)&&hi!==lo){const q=(u-lo)/(hi-lo);return [fxMix(a[0],b[0],q),fxMix(a[1],b[1],q),u];}
    }
    const p=points.reduce((best,p)=>Math.abs((p[2]??1)-u)<Math.abs((best[2]??1)-u)?p:best,points[0]);return [p[0],p[1],u];
  }
  return [...cubic(rib,u),u];
}
export function createOriginalStatusBuilder(id,side,visual,warp,ribs,growth=1){
  const paths=[];
  const at=(rib,u)=>ribPoint(ribs,rib,u);
  const add=(name,points,width=1,strength=.7,extra={})=>{
    if(paths.length>=8||points.length<2||strength<=.012)return;
    const sampled=points.length<=32?points:Array.from({length:32},(_,i)=>points[Math.round(i*(points.length-1)/31)]);
    if(sampled.some(p=>!p.every(Number.isFinite)))return;
    const us=sampled.map(p=>p[2]??1),lo=Math.min(...us),hi=Math.max(...us);
    const smooth=q=>{q=fxUnit(q);return q*q*(3-2*q);};
    const reveal=hi-lo<.00001?smooth((growth-lo)/.1):1;
    const clipped=hi-lo<.00001?(reveal>0?[sampled]:[]):growthPaths(sampled,growth);
    for(const part of clipped){
      if(paths.length>=8)break;
      const posed=part.map(warp);
      if(posed.length<2||posed.some(p=>!p.every(Number.isFinite)))continue;
      paths.push({id:`status-fx-${id}-${name}`,points:posed,width:Math.max(.25,Math.min(3,width)),strength:Math.min(1.3,strength*reveal),statusAccent:true,conditionAccent:true,material:'status-fx',...extra});
    }
  };
  const rail=(rib,lo,hi,offset=0,wave=0,time=0)=>Array.from({length:23},(_,i)=>{
    const q=i/22,p=at(rib,fxMix(lo,hi,q)),bell=Math.sin(q*Math.PI);
    p[0]+=(offset+wave*Math.sin(q*FX_TAU+time))*bell;return p;
  });
  const bridge=(from,to,u,drop=0,bend=0)=>{
    const a=at(from,u),b=at(to,u);
    return Array.from({length:23},(_,i)=>{const q=i/22,w=Math.sin(q*Math.PI);return [fxMix(a[0],b[0],q)+bend*w,fxMix(a[1],b[1],q)+drop*w,u];});
  };
  return {paths,at,add,rail,bridge,finish:()=>paths};
}
