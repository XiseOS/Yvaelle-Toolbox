import {effectiveScanMethods,normalizeScanMethods,SCAN_METHOD_IDS} from './v84-scan-methods.mjs?v=13.0.0-beta.8';
import {forceDelete,deleteKey,isDeletion,deletes} from './forced-delete.mjs?v=13.0.0-beta.8';
import {ID,runtimeConfiguration} from './config.mjs?v=13.0.0-beta.8';
import {normalizeFlag,resolveRenderState} from './state.mjs?v=13.0.0-beta.8';
import {BIT_IDS,BIT_KEY,OUTCOMES,EASINGS,EFFECTS,FORMATIONS,animationOptions,compileSequence,eventState,isFinished,ease,sampleSequence} from './bit-sequences.mjs?v=13.0.0-beta.8';
import {BitActionRenderer,actionHardware,actionContext,actionBitPresence,actionSnapshotAt,sourceTransform,toWorld,tokenVisualPose} from './bit-action-renderer.mjs?v=13.0.0-beta.8';

import {treatmentOptions,validTreatment,treatmentFinishTime,treatmentOutcomeDuration,validTreatmentRelease,captureTreatmentRelease,TREATMENT_RELEASE_MS} from './hardlight-treatment.mjs?v=13.0.0-beta.8';
import {localPerformance} from './performance.mjs?v=13.0.0-beta.8';
import {compactWingHandoff} from './compact-bit-renderer.mjs?v=13.0.0-beta.8';
import {prewarmCompactFlow} from './compact-bit-formations.mjs?v=13.0.0-beta.8';
import {qualityConfiguration} from './quality.mjs?v=13.0.0-beta.8';
import {ALLOCATION_FLAG,readAllocations,allocationGroups,allocationPresence,formationStations,stationList,setDestinations,chooseAvailable,deploymentSelection,validateGroupPatch,defaultGroup} from './bit-allocations.mjs?v=13.0.0-beta.8';
import {TOKEN_EFFECT_IDS,tokenEffectChoices,tokenEffectDefinition} from './token-effects.mjs?v=13.0.0-beta.8';
import {sampleGroupFormation} from './bit-group-motion.mjs?v=13.0.0-beta.8';
import {isProjectedEffect} from './projected-effect-programs.mjs?v=13.0.0-beta.8';
import {visibleProjectionFocus} from './projection-context.mjs?v=13.0.0-beta.8';
import {BIT_GESTURES,captureBehaviourPose,captureGestureLayout,validGestureLayout} from './bit-behaviour.mjs?v=13.0.0-beta.8';
import {BIT_CORE_STATES,captureCoreActivity} from './bit-core-states.mjs?v=13.0.0-beta.8';
import {validScanMechanism} from './bit-scan-mechanism.mjs?v=13.0.0-beta.8';
import {TREATMENT_CORE_CHANNELS,treatmentCoreVelocity} from './treatment-core-motion.mjs?v=13.0.0-beta.8';
import {formationFlowState,rebaseFormationFlow} from './bit-formation-flow.mjs?v=13.0.0-beta.8';
import {bitLanternInFrame} from './bit-lantern.mjs?v=13.0.0-beta.8';
import {summonFormationOptions,toggleSummonFlow,chooseSummonFormation} from './bit-summon-formations.mjs?v=13.0.0-beta.8';
import {BIT_TOOL_LABELS,BIT_TOOL_MODES,toolPoint,scanRadiusPixels,scanRegionGeometry,normalizeToolLight,validBitUtility,instrumentActivitySignature,toolIntentFingerprint} from './v8-tool-model.mjs?v=13.0.0-beta.8';
import {bitToolDestinations,scanArrivalTimes,areaSurveyCellIds} from './v8-scan-choreography.mjs?v=13.0.0-beta.8';
import {DEFAULT_SCAN_SPEED,scanSpeed,normalizeScanSpeed,retimeScanEvent,pauseScanBit,resumedScanOffset,sampleScanClock} from './v82-scan-clock.mjs?v=13.0.0-beta.8';
import {planSceneBitRoute} from './v8-scene-routing.mjs?v=13.0.0-beta.8';
import {normalizeScanMode,normalizeExaminationMovement,taskEditInput,taskEditFingerprint,taskPausePose} from './v88-task-lifecycle.mjs?v=13.0.0-beta.8';
import {scanTokenVisible} from './v82-scene-scan-context.mjs?v=13.0.0-beta.8';
import {guardScanSample} from './v88-scan-walls.mjs?v=13.0.0-beta.8';
import {LANTERN_DEFAULTS} from './lantern-model.mjs?v=13.0.0-beta.8';

const EMPTY_BIT_EVENTS=Object.freeze([]);
const FLAG='bitAnimations',PATH=`flags.${ID}.${FLAG}`;
const ALLOCATION_PATH=`flags.${ID}.${ALLOCATION_FLAG}`;
/** (12.0.0-beta.4) A landing's recall of her bits, waiting for her wings: {id (the landing transition), at, duration, owner}. */
const LAND_FLAG='landBits',LAND_EARLY=30,REST_FLAG='landBitsRest';
const clone=v=>structuredClone(v),id=()=>globalThis.foundry?.utils?.randomID?.(16)??Math.random().toString(36).slice(2);
const LIGHT_INTENT_FIELDS=['lightEnabled','lightWithBits','lightIntensity','lightBright','lightDim','lightAppearance','lightVisualReactions','lanternArtwork'];
const sameValue=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
function lightIntentFields(flight={}){
  const fields=Object.fromEntries(LIGHT_INTENT_FIELDS.map(key=>[key,{present:Object.hasOwn(flight,key),value:flight[key]}]));
  for(const key of Object.keys(LANTERN_DEFAULTS))fields[`lantern.${key}`]={present:Object.hasOwn(flight.lantern??{},key),value:flight.lantern?.[key]};
  return fields;
}
/** An optical edit has a narrow inverse only when its original command did
 * not change destinations, deployment intent, or any scheduled work. Runtime
 * lantern epochs are deliberately absent from that inverse. */
function lightCommandInverse(before,after){
  if(!sameValue(before.record,after.record)||!sameValue(before.events,after.events)||
    !sameValue(before.flight.bitsDeployed,after.flight.bitsDeployed)||!sameValue(before.flight.gemMotion,after.flight.gemMotion))return null;
  const old=lightIntentFields(before.flight),next=lightIntentFields(after.flight);
  const fields=Object.keys(old).filter(key=>!sameValue(old[key],next[key]));
  return fields.length?Object.fromEntries(fields.map(key=>[key,{before:old[key],after:next[key]}])):null;
}
function allocationChanges(before,after,path=ALLOCATION_PATH,out={}){
  for(const key of new Set([...Object.keys(before??{}),...Object.keys(after??{})])){
    if(!/^[\w-]+$/.test(key))continue;
    if(!Object.hasOwn(after??{},key)){forceDelete(out,path,key);continue;}
    const value=after[key];
    if(value&&typeof value==='object'&&!Array.isArray(value))allocationChanges(before?.[key],value,`${path}.${key}`,out);
    else out[`${path}.${key}`]=value;
  }return out;
}
const finite=n=>Number.isFinite(n);
const CORE_CHANNELS=new Set(['encase','open','charge','guard','settle','scan','brace','align','rest','conduct']);
const validPoint=p=>p&&['source','target','world'].includes(p.space)&&finite(p.x)&&finite(p.y)&&Math.abs(p.x)<=1000000&&Math.abs(p.y)<=1000000;
const validStations=v=>Array.isArray(v)&&v.length>0&&v.length<=4&&v.every(b=>BIT_IDS.includes(b))&&new Set(v).size===v.length;
const validMap=(v,predicate)=>v===undefined||v&&typeof v==='object'&&!Array.isArray(v)&&Object.entries(v).every(([k,p])=>BIT_IDS.includes(k)&&predicate(p));
const validCoreBlend=t=>(t.weights===undefined||t.weights&&typeof t.weights==='object'&&!Array.isArray(t.weights)&&Object.entries(t.weights).every(([state,weight])=>Object.hasOwn(BIT_CORE_STATES,state)&&!['idle','auto'].includes(state)&&finite(weight)&&weight>=0&&weight<=1)&&Object.values(t.weights).reduce((sum,weight)=>sum+weight,0)<=1+1e-9)&&(t.coreChannels===undefined||t.coreChannels&&typeof t.coreChannels==='object'&&!Array.isArray(t.coreChannels)&&Object.entries(t.coreChannels).every(([channel,weight])=>CORE_CHANNELS.has(channel)&&finite(weight)&&weight>=0&&weight<=1))&&(t.settleProgress===undefined||finite(t.settleProgress)&&t.settleProgress>=0&&t.settleProgress<=1);
const validVelocity=v=>v&&finite(v.x)&&finite(v.y)&&Math.abs(v.x)<=1000000&&Math.abs(v.y)<=1000000;
const validUtilityReentry=v=>v&&finite(v.at)&&finite(v.duration)&&v.duration>=0&&v.duration<=10000&&validVelocity(v.from)&&(v.fromRotation===undefined||finite(v.fromRotation))&&(v.fromDepth===undefined||finite(v.fromDepth));
const validScanClock=v=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).every(k=>['at','elapsed','speed'].includes(k))&&finite(v.at)&&v.at>=0&&finite(v.elapsed)&&v.elapsed>=0&&finite(v.speed)&&v.speed>=.25&&v.speed<=1.5;
const validScanPause=v=>finite(v)&&v>=0||v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).every(k=>['at','elapsed'].includes(k))&&finite(v.at)&&v.at>=0&&finite(v.elapsed)&&v.elapsed>=0;
const validTaskPause=v=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).every(k=>['positions','rotations','depths'].includes(k))&&v.positions&&v.rotations&&v.depths&&validMap(v.positions,validVelocity)&&validMap(v.rotations,finite)&&validMap(v.depths,finite);
const validRoute=v=>v&&Array.isArray(v.points)&&v.points.length>=2&&v.points.length<=160&&v.points.every(validVelocity)&&finite(v.length)&&v.length>=0&&v.length<=10000000&&Array.isArray(v.lengths)&&v.lengths.length===v.points.length&&v.lengths.every(finite)&&Array.isArray(v.corners)&&v.corners.length<=24&&v.corners.every(n=>Number.isInteger(n)&&n>=0&&n<v.points.length);
const validCoreActivity=t=>t&&Object.keys(t).every(key=>['state','amount','progress','weights','coreChannels','settleProgress','examination'].includes(key))&&Object.hasOwn(BIT_CORE_STATES,t.state)&&!['idle','auto'].includes(t.state)&&finite(t.amount)&&t.amount>=0&&t.amount<=1&&finite(t.progress)&&t.progress>=0&&t.progress<=1&&validCoreBlend(t)&&(t.examination===undefined||validScanMechanism(t.examination));
const validCoreVelocity=v=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).every(key=>TREATMENT_CORE_CHANNELS.includes(key))&&Object.values(v).every(value=>finite(value)&&Math.abs(value)<=1000);
const validPresence=p=>p&&typeof p==='object'&&!Array.isArray(p)&&Object.keys(p).every(k=>['alpha','scale'].includes(k))&&finite(p.alpha)&&p.alpha>=0&&p.alpha<=1&&finite(p.scale)&&p.scale>=0&&p.scale<=1;
const validGroup=g=>{if(g===undefined)return true;try{const {transition,...patch}=g;validateGroupPatch(patch);return transition===undefined||transition&&typeof transition.fromProgram==='string'&&finite(transition.started)&&finite(transition.duration)&&transition.duration>=0&&transition.duration<=10000;}catch{return false;}};
function validTrack(t){
  if(!t||!['move','wait','formation','glow','effect','return','rotate','gesture','core','tool'].includes(t.type)||!finite(t.at)||t.at<0||t.at>600000||!finite(t.duration)||t.duration<0||t.duration>60000||
    t.bits!=null&&!validStations(t.bits)||!Object.hasOwn(EASINGS,t.easing??'smooth'))return false;
  if(t.type==='move'&&(!validPoint(t.to)||!finite(t.arc)||Math.abs(t.arc)>5||t.path!==undefined&&(!Array.isArray(t.path)||t.path.length>16||!t.path.every(validPoint))))return false;
  if(t.type==='formation'&&(!validPoint(t.to)||!FORMATIONS.includes(t.formation)||!finite(t.radius)||t.radius<.05||t.radius>8||!finite(t.turns)||Math.abs(t.turns)>20))return false;
  if(t.type==='glow'&&(!finite(t.strength)||t.strength<0||t.strength>4||t.color!=null&&!/^#[\da-f]{6}$/i.test(t.color)||!['core','field'].includes(t.mode??'core')))return false;
  if(t.type==='gesture'&&(!Object.hasOwn(BIT_GESTURES,t.gesture)||!finite(t.energy)||t.energy<0||t.energy>1))return false;
  if(t.type==='core'&&(!Object.hasOwn(BIT_CORE_STATES,t.state)||t.state==='auto'||!finite(t.amount)||t.amount<0||t.amount>1))return false;
  if(t.type==='tool'&&(!['lens','probe','plate','spark','none'].includes(t.tool)||!finite(t.amount)||t.amount<0||t.amount>1))return false;
  if(t.type==='rotate'&&(!finite(t.angle)||Math.abs(t.angle)>7200))return false;
  if(t.type==='effect'&&(!EFFECTS.includes(t.effect)||!finite(t.strength)||t.strength<0||t.strength>3))return false;
  if(t.effect==='sprite'&&(typeof t.asset!=='string'||t.asset.length>300||! /^(modules|worlds|systems|icons)\/[\w /().-]+\.(png|webp|jpg|jpeg|svg)$/i.test(t.asset)||t.asset.split('/').includes('..')||!finite(t.size)||t.size<.05||t.size>8||!finite(t.angle)||Math.abs(t.angle)>7200))return false;
  return true;
}
export function readBitActions(raw){
  if(!raw||raw.version!==1||!Array.isArray(raw.events)||raw.events.length>16)return [];
  return raw.events.filter(e=>e&&typeof e.id==='string'&&e.id.length<=64&&typeof e.owner==='string'&&typeof e.session==='string'&&
    ['queued','running','returning'].includes(e.status)&&['treatment','sequence','escort','utility'].includes(e.kind)&&
    (e.conditionPausedAt===undefined||finite(e.conditionPausedAt)&&e.conditionPausedAt>=0&&e.status==='returning')&&validStations(e.bits)&&(e.formationBits===undefined||validStations(e.formationBits)&&e.bits.every(b=>e.formationBits.includes(b)))&&validGroup(e.group)&&(e.escortCountMode===undefined||['configured','reserved'].includes(e.escortCountMode))&&(e.originScale===undefined||Array.isArray(e.originScale)&&e.originScale.length===2&&e.originScale.every(v=>finite(v)&&v>0&&v<=20))&&(e.deployedBits===undefined||Array.isArray(e.deployedBits)&&e.deployedBits.length<=4&&e.deployedBits.every(b=>BIT_IDS.includes(b)))&&
    finite(e.created)&&finite(e.expires)&&e.expires>=e.created&&(e.sequence?.audio===undefined||typeof e.sequence.audio==='boolean')&&(e.sequence?.gesture===undefined||Object.hasOwn(BIT_GESTURES,e.sequence.gesture))&&
    (['escort','utility'].includes(e.kind)||finite(e.conditionPausedAt)||e.expires-e.created<=620000)&&finite(e.priority)&&e.priority>=0&&e.priority<=1000&&
    finite(e.returnDuration)&&e.returnDuration>=0&&e.returnDuration<=10000&&finite(e.travelDuration)&&e.travelDuration>=0&&e.travelDuration<=10000&&
    (e.status==='queued'||finite(e.started))&&(e.status!=='returning'||finite(e.returnAt))&&
    (e.finishAt==null||finite(e.finishAt))&&(e.outcome==null||OUTCOMES.includes(e.outcome))&&
    validMap(e.origins,p=>Array.isArray(p)&&p.length>=2&&p.length<=4&&p.every(finite))&&validMap(e.returnFrom,p=>p&&finite(p.x)&&finite(p.y))&&
    validMap(e.originsWorld,p=>p&&finite(p.x)&&finite(p.y))&&validMap(e.originDepths,finite)&&validMap(e.originPresence,validPresence)&&
    (e.gestureLayout===undefined||validGestureLayout(e.gestureLayout,e.bits))&&validMap(e.returnVelocities,validVelocity)&&validMap(e.originVelocities,validVelocity)&&
    validMap(e.originRotations,v=>finite(v)&&Math.abs(v)<=Math.PI)&&
    validMap(e.originTools,t=>t&&['lens','probe','plate','spark','travel'].includes(t.type)&&finite(t.amount)&&t.amount>=0&&t.amount<=1&&finite(t.progress)&&t.progress>=0&&t.progress<=1&&(t.variation===undefined||finite(t.variation)&&t.variation>=0&&t.variation<=3))&&
    validMap(e.originCoreStates,validCoreActivity)&&
    (e.originCoreVelocities===undefined||e.kind==='treatment'&&validMap(e.originCoreVelocities,validCoreVelocity))&&
    (e.returnCoreStates===undefined||e.kind==='treatment'&&e.status==='returning'&&validMap(e.returnCoreStates,validCoreActivity))&&
    (e.returnCoreVelocities===undefined||e.kind==='treatment'&&e.status==='returning'&&validMap(e.returnCoreVelocities,validCoreVelocity))&&
    validMap(e.returnTools,t=>t&&['lens','probe','plate','spark','travel'].includes(t.type)&&finite(t.amount)&&t.amount>=0&&t.amount<=1&&finite(t.progress))&&
    validMap(e.returnDepths,finite)&&validMap(e.returnRotations,finite)&&validMap(e.returnGlows,p=>p&&finite(p.strength)&&p.strength>=0&&p.strength<=4)&&
    (e.target==null||typeof e.target==='string'&&e.target.length<=64)&&
    (e.kind!=='utility'||validBitUtility(e.utility,e.formationBits??e.bits,e.target))&&
    (e.scanMethodHold===undefined||e.kind==='utility'&&validMap(e.scanMethodHold,h=>h&&typeof h==='object'&&Object.keys(h).every(k=>['visit','method'].includes(k))&&typeof h.visit==='string'&&h.visit.length>0&&h.visit.length<=128&&SCAN_METHOD_IDS.includes(h.method)))&&
    (e.utilityRevision===undefined||e.kind==='utility'&&Number.isInteger(e.utilityRevision)&&e.utilityRevision>=0&&e.utilityRevision<=2147483647)&&
    (e.scanClock===undefined||e.kind==='utility'&&e.utility.mode!=='parkLight'&&validScanClock(e.scanClock))&&
    (e.taskPausedAt===undefined||e.kind==='utility'&&e.utility.mode!=='parkLight'&&e.status!=='returning'&&finite(e.taskPausedAt)&&e.taskPausedAt>=0&&validTaskPause(e.taskPausedPose))&&
    (e.scanCoverageTotal===undefined||e.kind==='utility'&&e.utility.mode==='areaScan'&&Number.isInteger(e.scanCoverageTotal)&&e.scanCoverageTotal>=0&&e.scanCoverageTotal<=4096)&&
    (e.scanPending===undefined||e.kind==='utility'&&e.utility.mode==='areaScan'&&typeof e.scanPending==='boolean')&&
    (e.scanUnreachable===undefined||e.kind==='utility'&&e.utility.mode==='areaScan'&&Array.isArray(e.scanUnreachable)&&e.scanUnreachable.length<=4096&&new Set(e.scanUnreachable).size===e.scanUnreachable.length&&e.scanUnreachable.every(id=>typeof id==='string'&&id.length>0&&id.length<=128))&&
    (e.scanCoverage===undefined||e.kind==='utility'&&e.utility.mode==='areaScan'&&Array.isArray(e.scanCoverage)&&e.scanCoverage.length<=4096&&new Set(e.scanCoverage).size===e.scanCoverage.length&&e.scanCoverage.every(id=>typeof id==='string'&&id.length>0&&id.length<=128))&&
    validMap(e.scanOffsets,v=>finite(v)&&v>=0)&&validMap(e.scanStartElapsed,v=>finite(v)&&v>=0)&&validMap(e.scanPausedAt,validScanPause)&&validMap(e.scanPausedElapsed,v=>finite(v)&&v>=0)&&
    (e.yieldedBits===undefined||e.kind==='utility'&&validStations(e.yieldedBits)&&e.yieldedBits.every(bit=>(e.formationBits??e.bits).includes(bit))&&(e.status==='queued'||e.yieldedBits.every(bit=>!e.bits.includes(bit))))&&
    (e.utilityReentries===undefined||e.kind==='utility'&&validMap(e.utilityReentries,validUtilityReentry))&&validMap(e.returnUtilityPoints,validVelocity)&&
    validMap(e.travelRoutes,validRoute)&&validMap(e.returnRoutes,validRoute)&&(e.utilityStarted===undefined||e.kind==='utility'&&finite(e.utilityStarted)&&e.utilityStarted>=0)&&
    validTreatment(e.treatment)&&(e.returnTreatment===undefined||e.kind==='treatment'&&e.status==='returning'&&validTreatmentRelease(e.returnTreatment,e.bits))&&
    (['treatment','escort','utility'].includes(e.kind)||e.sequence&&Array.isArray(e.sequence.tracks)&&e.sequence.tracks.length<=96&&e.sequence.tracks.every(validTrack)&&finite(e.sequence.duration)&&e.sequence.duration<=600000))
    .map(clone);
}
const overlaps=(a,b)=>a.some(id=>b.includes(id));
function protectTreatmentResultLifetime(event){
  const end=event.finishAt+treatmentOutcomeDuration(event)+(event.returnDuration??800)+1000;
  event.expires=Math.max(event.expires,end);
  // Active actions no longer participate in FIFO ordering. Keep the retained
  // bounded record valid even when a long-running treatment resolves late.
  event.created=Math.max(event.created,event.expires-620000);
}
/** Pure scheduler: reservations belong only to active events; queued actions
 * acquire bits in descending priority, stable FIFO within each priority. */
export function scheduleActions(events,now){
  const next=events.filter(e=>!isFinished(e,now)),busy=new Set(next.filter(e=>e.status!=='queued').flatMap(e=>e.bits));
  for(const e of next.filter(e=>e.status==='queued').sort((a,b)=>b.priority-a.priority||a.created-b.created)){
    const blockers=next.filter(other=>other!==e&&other.status!=='queued'&&overlaps(other.bits,e.bits));
    if(blockers.some(other=>other.kind!=='escort'||other.status==='returning'||other.priority>=e.priority))continue;
    for(const escort of blockers){escort.bits=escort.bits.filter(bit=>!e.bits.includes(bit));for(const bit of e.bits)busy.delete(bit);}
    if(e.bits.some(id=>busy.has(id)))continue;
    e.status='running';if(e.kind==='utility'&&finite(e.utilityStarted))e.started=e.utilityStarted;else e.started=now;for(const bit of e.bits)busy.add(bit);
    if(e.requestedOutcome){e.outcome=e.requestedOutcome;e.finishAt=treatmentFinishTime(e,now);protectTreatmentResultLifetime(e);delete e.requestedOutcome;}
  }
  return next.filter(e=>e.bits.length);
}

/** Only command edges write flags. Render frames never mutate saved flight
 * configuration or emit per-frame document/socket messages. */
export class BitAnimationRuntime {
  constructor(service,{now=()=>Number(globalThis.game?.time?.serverTime)||Date.now(),makeRenderer=token=>new BitActionRenderer(token)}={}){
    this.service=service;this.manager=service.manager;this.now=now;this.makeRenderer=makeRenderer;this.session=id();
    this.recordCache=new WeakMap();this.renderers=new Map();this.handles=new Map();this.definitions=new Map();this.pending=new Set();this.documents=new Map();this.lastMaintenance=0;this.stopped=false;
    this.commandUndos=new WeakMap();this.commandScopes=new WeakSet();
  }
  /** One local command, one undo. Live choreography clocks and game-system
   * results are never replayed. A new treatment makes the old undo unavailable. */
  commandSnapshot(doc){
    const record=this.allocation(doc),events=this.records(doc).filter(e=>!isFinished(e,this.now())),raw=doc.getFlag(ID,'flight')??{};
    const fields=['bitsDeployed','gemMotion','lightEnabled','lightWithBits','lightIntensity','lightBright','lightDim','lightAppearance','lightVisualReactions','lanternArtwork','lantern'];
    const flight=Object.fromEntries(fields.filter(key=>Object.hasOwn(raw,key)).map(key=>[key,clone(raw[key])]));
    return {record,events,flight,signature:instrumentActivitySignature(events),fingerprint:toolIntentFingerprint(record,events,flight)};
  }
  async commandScope(doc,label,task){
    this.commandScopes??=new WeakSet();this.commandUndos??=new WeakMap();
    if(this.commandScopes.has(doc))return task();
    this.commandScopes.add(doc);const before=this.commandSnapshot(doc);
    try{
      const result=await task(),after=this.commandSnapshot(doc);
      if(before.fingerprint!==after.fingerprint){
        if(before.signature===after.signature)this.commandUndos.set(doc,{label,sceneId:doc.parent.id,before,afterFingerprint:after.fingerprint,signature:after.signature,lightInverse:lightCommandInverse(before,after)});
        else this.commandUndos.delete(doc);
        globalThis.Hooks?.callAll?.('filamentFlightBitsChanged',doc,this.getState(doc));
      }
      return result;
    }catch(error){if(this.commandSnapshot(doc).fingerprint!==before.fingerprint)this.commandUndos.delete(doc);throw error;}
    finally{this.commandScopes.delete(doc);}
  }
  commandQueue(doc,label,task){return this.service.enqueue(doc,()=>this.commandScope(doc,label,task));}
  undoState(doc){
    const undo=this.commandUndos?.get(doc);if(!undo)return {available:false,label:'Undo last bit command',reason:null};
    const current=this.commandSnapshot(doc);
    const light=undo.lightInverse?lightIntentFields(current.flight):null;
    const reason=doc.parent?.id!==undo.sceneId?'The scene changed.':light?
      Object.entries(undo.lightInverse).some(([key,field])=>!sameValue(light[key],field.after))?'That light choice changed since the command.':null:
      current.signature!==undo.signature?'A treatment or animation has changed since that command.':
      current.fingerprint!==undo.afterFingerprint?'The instruments changed since that command.':null;
    return {available:!reason,label:`Undo ${undo.label}`,reason};
  }
  toolTarget(doc,input){
    if(typeof input==='string'&&input.includes('.Token.'))input=input.split('.Token.').at(-1);
    const target=this.target(doc,input);
    if(!scanTokenVisible(target.object,{scene:doc.parent,source:doc.object}))throw new Error('Choose a visible creature to examine or illuminate.');
    return target;
  }
  freeToolBits(doc,record,events,input=1){
    const now=this.now(),blocked=new Set(events.filter(e=>e.status==='queued'||e.status==='returning'||e.kind!=='escort'||now<e.started+e.travelDuration).flatMap(e=>e.bits));
    if(Array.isArray(input)){
      const bits=stationList(input);if(bits.some(bit=>blocked.has(bit)))throw new Error('A selected instrument is busy. Stop its job or select an available bit.');return bits;
    }
    if(!Number.isInteger(input)||input<1||input>4)throw new Error('Choose one to four instruments.');
    const free=BIT_IDS.filter(bit=>['home','retracted'].includes(record.bits[bit].location)&&!blocked.has(bit));
    const sorted=[...free.filter(bit=>record.bits[bit].location==='home'),...free.filter(bit=>record.bits[bit].location==='retracted')];
    if(sorted.length<input)throw new Error(`Only ${sorted.length} instruments are available. Stop a job, recall a group, or choose its diamonds explicitly.`);
    return sorted.slice(0,input);
  }
  /** Locator reads reuse bodies already placed by the renderer. Only a newly
   * issued command or a headless canvas needs the pure geometry fallback. */
  toolCapture(doc,record,events,now){
    const originsWorld={},originRotations={},missing=[],action=this.renderers.get(doc.object),local=this.manager.states?.get(doc.object),home=local?.snapshot?.compactBits?local.renderer?.compact?.bits:local?.renderer?.rig?.bits;
    if(doc.object?.visible===false||doc.object?.isVisible===false)return {originsWorld,originRotations};
    for(const bit of BIT_IDS){
      const event=events.find(e=>e.status!=='queued'&&e.bits.includes(bit)),key=BIT_KEY[bit];
      if(event?.target){const target=globalThis.canvas?.tokens?.get(event.target);if(!scanTokenVisible(target,{scene:doc.parent}))continue;}
      if(!event&&record.bits[bit].location==='retracted')continue;
      const renderer=event?action?.bits:home,position=renderer?.records?.has(key)?renderer.placements?.get(bit):null;
      const recent=!event||finite(action?.lastPositionTimes?.get(event.id))&&now-action.lastPositionTimes.get(event.id)>=0&&now-action.lastPositionTimes.get(event.id)<100;
      if(position&&recent&&finite(position.x)&&finite(position.y)&&position.alpha!==0){
        originsWorld[bit]={x:position.x,y:position.y};originRotations[bit]=(position.angle??0)+(renderer.records.get(key)?.frame?.bit?.part?.hardware?.angle??0);
      }else missing.push(bit);
    }
    if(missing.length){
      const captured=this.captureWorld(doc,missing,events,now,{behaviour:true});Object.assign(originsWorld,captured.originsWorld);
      Object.assign(originRotations,captured.originRotations);
    }
    return {originsWorld,originRotations};
  }
  getToolState(source){
    const doc=source?.document??source,now=this.now(),events=this.records(doc).filter(e=>!isFinished(e,now)),record=this.allocation(doc),owned=doc.isOwner===true;
    const visible=e=>!e.target||scanTokenVisible(globalThis.canvas?.tokens?.get(e.target),{scene:doc.parent});
    const utilities=events.filter(e=>e.kind==='utility'&&visible(e)),captured=owned?this.toolCapture(doc,record,events,now):null;
    // Latest guarded wall status per job (v88 guardScanSample state.status).
    const wallStates=this.renderers?.get?.(doc.object)?.scanWallStates,wallStatus=e=>e.status==='running'&&e.taskPausedAt==null?wallStates?.get?.(e.id)?.status??null:null;
    const tasks=utilities.map(e=>({id:e.id,kind:e.utility.mode,mode:e.utility.mode,name:BIT_TOOL_LABELS[e.utility.mode],bits:[...e.bits],target:e.target??null,center:e.utility.center?{...e.utility.center}:null,region:e.utility.region?clone(e.utility.region):null,scanMethods:e.utility.mode==='parkLight'?null:effectiveScanMethods(e.utility.scanMethods),
      scanSpeed:e.utility.mode==='parkLight'?null:scanSpeed(e.scanClock?.speed??e.utility.scanSpeed??1),scanMode:e.utility.mode==='areaScan'?normalizeScanMode(e.utility.scanMode):null,paused:e.taskPausedAt!=null,editable:e.status!=='returning',coveredCells:e.scanCoverage?.length??0,totalCells:e.scanCoverageTotal??null,scanPending:e.scanPending===true,unreachableCells:e.scanUnreachable?.length??0,wallWaiting:wallStatus(e)?.pending?.length??0,wallReason:wallStatus(e)?.reason??null,radiusFeet:e.utility.radiusFeet??null,radiusPixels:e.utility.radiusPixels??null,followSource:e.utility.followSource===true,status:e.status,phase:e.taskPausedAt!=null?'paused':e.scanPending?'waiting':eventState(e,now).phase,light:e.utility.light?clone(e.utility.light):null,assignedBits:[...(e.formationBits??e.bits)],yieldedBits:[...(e.yieldedBits??[])],workingCount:e.status==='queued'?0:e.bits.length}));
    const available=BIT_IDS.filter(bit=>!events.some(e=>e.bits.includes(bit)&&(e.status==='queued'||e.status==='returning'||e.kind!=='escort'||now<e.started+e.travelDuration))&&['home','retracted'].includes(record.bits[bit].location));
    const sources=BIT_IDS.map(bit=>{
      const event=events.find(e=>e.status!=='queued'&&e.bits.includes(bit)),shown=event&&visible(event),position=captured?.originsWorld?.[bit];
      return {id:bit,status:event?'busy':record.bits[bit].location,label:event?shown?(event.kind==='utility'?BIT_TOOL_LABELS[event.utility.mode]:event.kind==='treatment'?'Treating a creature':'Assigned instrument'):'Assigned instrument':record.bits[bit].location==='home'?'With Ellie':'Retracted',
        ...(position&&(!event||shown)?{position:{...position},x:position.x,y:position.y,angle:captured.originRotations?.[bit]??0}:{}),...(shown&&event.target?{target:event.target}:{})};
    });
    return {scanMethods:effectiveScanMethods(doc.getFlag?.(ID,'v8Tools')?.scanMethods),scanSpeed:scanSpeed(doc.getFlag?.(ID,'v8Tools')?.scanSpeed??DEFAULT_SCAN_SPEED),examinationMovement:doc.getFlag?.(ID,'v8Tools')?.examinationMovement==='classic'?'classic':'deliberate',tasks,jobs:tasks,available,sources,undo:owned?this.undoState(doc):{available:false,label:'Undo last bit command',reason:null}};
  }
  previewTool(source,input={},options={}){
    const doc=this.document(source);this.assertPowered(doc);
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['kind','mode','bits','point','center','target','light','seed','weighty','guard','sources','radiusFeet','radiusPixels','version','sceneId','followSource','event','scanSpeed','region','scanMethods','scanMode'].includes(key)))throw new Error('Unknown instrument tool option.');
    const kind=input.kind??input.mode;if(![...BIT_TOOL_MODES,'dispatch'].includes(kind))throw new Error('Choose an area scan, creature scan, parked light, or dispatch.');
    const events=this.records(doc).filter(e=>!isFinished(e,this.now())),record=this.allocation(doc);this.controller(events);
    const bits=options.editing?stationList(input.bits):this.freeToolBits(doc,record,events,input.bits??(kind==='parkLight'?1:record.preferredCount));
    if(kind==='parkLight'&&bits.length!==1)throw new Error('Each parked light uses one physical instrument.');
    const regionGeometry=input.region===undefined?null:scanRegionGeometry(input.region,bits.length,doc.parent,globalThis.canvas?.dimensions);
    if(regionGeometry&&(kind!=='areaScan'||input.followSource))throw new Error('A drawn scan region belongs to a placed area scan.');
    const target=input.target!=null?this.toolTarget(doc,input.target):null,point=regionGeometry?.center??input.point??input.center;
    if(input.followSource!==undefined&&(typeof input.followSource!=='boolean'||kind!=='areaScan'))throw new Error('Only an area scan can follow Ellie.');
    if(kind==='areaScan'&&(target||point==null&&!input.followSource)||['creatureScan','dispatch'].includes(kind)&&(!target||point!=null)||kind==='parkLight'&&!!target===(point!=null))throw new Error('Choose an area point or a creature appropriate to this tool.');
    const center=point!=null?toolPoint(point):null;
    if(center&&!game.user?.isGM&&globalThis.canvas?.visibility?.testVisibility?.(center,{tolerance:0,object:null})===false)throw new Error('Choose a scene point you can see.');
    const seed=input.seed??Math.floor(Math.random()*0x100000000);
    if(!Number.isInteger(seed)||seed<0||seed>0xffffffff)throw new Error('The scan seed must be a bounded integer.');
    if(input.weighty!==undefined&&typeof input.weighty!=='boolean')throw new Error('Weighty travel must be true or false.');
    const now=this.now(),snapshot=this.state(doc,true),capture=this.captureWorld(doc,bits,events,now,{behaviour:true,velocity:true}),hardware=actionHardware(snapshot,now),transform=sourceTransform(doc.object,snapshot,this.manager);
    const radiusFeet=regionGeometry?.radiusFeet??(input.followSource||options.editing&&kind==='areaScan'?input.radiusFeet??bits.length*5:bits.length*5),radiusPixels=regionGeometry?.radiusPixels??scanRadiusPixels(bits.length,doc.parent,globalThis.canvas?.dimensions,radiusFeet);
    if(!options.editing&&!regionGeometry&&!input.followSource&&input.radiusFeet!==undefined&&input.radiusFeet!==bits.length*5)throw new Error('A fixed scan covers five feet of radius per instrument.');
    const scanMode=kind==='areaScan'?normalizeScanMode(input.scanMode):null;
    if(input.scanMode!==undefined&&kind!=='areaScan')throw new Error('Survey once belongs to area scanning.');
    if(input.followSource&&scanMode==='once')throw new Error('Following scans keep searching. Place a region for a single survey.');
    const weighty=input.weighty??doc.getFlag(ID,'v8Tools')?.weightedTravel??runtimeConfiguration().v8WeightedTravel!==false;
    const speed=normalizeScanSpeed(input.scanSpeed??doc.getFlag(ID,'v8Tools')?.scanSpeed??DEFAULT_SCAN_SPEED),scanMethods=normalizeScanMethods(input.scanMethods??doc.getFlag(ID,'v8Tools')?.scanMethods??{});
    const utility={version:1,mode:kind,sceneId:doc.parent.id,seed,weighty,...(scanMode?{scanMode}:{}),...(options.editing&&kind==='areaScan'&&!regionGeometry&&!input.followSource&&radiusFeet!==bits.length*5?{customRadius:true}:{}),...(kind==='creatureScan'?{examinationMovement:snapshot.v8Motion?.examinationMovement??'deliberate'}:{}),...(center?{center}:{}),...(regionGeometry?{region:regionGeometry.region}:{}),...(input.followSource?{followSource:true}:{}),...(kind==='parkLight'?{light:normalizeToolLight(input.light)}:{scanMethods,scanSpeed:speed,radiusFeet,radiusPixels})};
    const event=kind==='dispatch'?this.escortEvent(doc,target.id,bits,record,now,capture):{id:'thought-preview',name:BIT_TOOL_LABELS[kind],kind:'utility',utility,created:now,expires:Number.MAX_SAFE_INTEGER,started:now,status:'running',target:target?.id??null,bits:[...bits],priority:15,travelDuration:900,returnDuration:900,...capture};
    if(kind==='dispatch')event.formationBits=BIT_IDS.filter(bit=>bits.includes(bit)||record.bits[bit].location===target.id&&!events.some(e=>e.kind!=='escort'&&e.status!=='queued'&&e.bits.includes(bit)));
    this.planEventRoutes(doc,event,now);
    return {version:1,kind,bits,sceneId:doc.parent.id,...(scanMode?{scanMode}:{}),...(center?{point:center}:{}),...(target?{target:target.id}:{}),seed,weighty,...(regionGeometry?{region:regionGeometry.region}:{}),...(input.followSource?{followSource:true}:{}),event,
      ...(kind==='parkLight'?{light:normalizeToolLight(input.light)}:kind==='dispatch'?{}:{scanMethods,scanSpeed:speed,radiusFeet,radiusPixels}),
      sources:bits.map(bit=>({id:bit,...capture.originsWorld[bit],position:{...capture.originsWorld[bit]},angle:transform.angle+(hardware[bit]?.hardware?.angle??0)+(capture.originRotations?.[bit]??0),scale:(hardware[bit]?.hardware?.scale??1)*transform.width/600,hardware:clone(hardware[bit])})),guard:{revision:record.revision,activitySignature:instrumentActivitySignature(events),intent:toolIntentFingerprint(record,events,doc.getFlag(ID,'flight')??{})}};
  }
  startTool(source,input={}){
    const doc=this.document(source),initial=this.previewTool(doc,input);
    return this.commandQueue(doc,BIT_TOOL_LABELS[initial.kind].toLowerCase(),async()=>{
      this.document(doc);this.assertPowered(doc);const now=this.now(),record=this.allocation(doc);let events=this.records(doc).filter(e=>!isFinished(e,now));this.controller(events);
      if(input.guard&&(input.sceneId!==doc.parent.id||input.guard.revision!==record.revision||input.guard.activitySignature!==instrumentActivitySignature(events)||input.guard.intent!==toolIntentFingerprint(record,events,doc.getFlag(ID,'flight')??{})))throw new Error('The instruments changed during the preview. Preview this action again.');
      const plan=this.previewTool(doc,{...input,seed:initial.seed});
      // Numeric simultaneous commands choose again inside the serialized queue.
      // A concrete preview always retains its explicit station identities.
      if(!Array.isArray(input.bits)&&!input.guard)plan.bits=this.freeToolBits(doc,record,events,input.bits??(plan.kind==='parkLight'?1:record.preferredCount));
      const captured=this.captureWorld(doc,plan.bits,events,now,{behaviour:true,velocity:true});
      if(plan.kind==='dispatch')return this.assignNow(doc,this.toolTarget(doc,plan.target),plan.bits,record,events,now,captured);
      const detached=this.detach(doc,events,plan.bits,now,{cancelActions:false});events=detached.events;
      const utility={version:1,mode:plan.kind,sceneId:doc.parent.id,seed:plan.seed,weighty:plan.weighty,...(plan.kind==='areaScan'?{scanMode:plan.scanMode}:{}),...(plan.kind==='creatureScan'?{examinationMovement:plan.event.utility.examinationMovement}:{}),
        ...(plan.point?{center:plan.point,elevation:Number(doc.elevation)||0,level:typeof doc._source?.level==='string'?doc._source.level:null}:{}),
        ...(plan.region?{region:plan.region}:{}),...(plan.followSource?{followSource:true}:{}),...(plan.kind==='parkLight'?{light:plan.light}:{scanMethods:plan.scanMethods??effectiveScanMethods(),scanSpeed:plan.scanSpeed??DEFAULT_SCAN_SPEED,radiusFeet:plan.radiusFeet,radiusPixels:plan.radiusPixels})};
      const event={id:id(),name:BIT_TOOL_LABELS[plan.kind],kind:'utility',utility,utilityRevision:0,sequence:null,owner:game.user.id,session:this.session,created:now,expires:Number.MAX_SAFE_INTEGER,started:now,status:'running',target:plan.target??null,bits:plan.bits,priority:15,travelDuration:900,returnDuration:900,...captured};
      events.push(event);events=this.reconcile(doc,events,record,now);const handle=this.createHandle(doc,event);
      try{await this.write(doc,events,detached.cancelled,record);return handle;}catch(error){this.settle(event,'error',error.message);throw error;}
    });
  }
  /** A local proposal does not stop, move or reserve the live instruments. */
  previewEdit(source,patch={}){
    const doc=this.document(source);this.assertPowered(doc);
    if(typeof patch?.id!=='string'||!patch.id||patch.id.length>64)throw new Error('Choose the running task to edit.');
    const events=this.records(doc);this.controller(events);
    const event=events.find(e=>e.id===patch.id&&e.kind==='utility'&&e.status!=='returning');
    if(!event)throw new Error('That instrument task is no longer editable.');
    if(event.target&&!scanTokenVisible(globalThis.canvas?.tokens?.get(event.target),{scene:doc.parent}))throw new Error('This task’s target is no longer visible. Return its instruments before choosing a new task.');
    const plan=this.previewTool(doc,taskEditInput(event,patch),{editing:true});
    plan.event.id=event.id;
    return {...plan,edit:{id:event.id,fingerprint:taskEditFingerprint(event)}};
  }
  edit(source,input){
    const doc=this.document(source);
    if(!input||typeof input!=='object'||Array.isArray(input)||!input.edit||Object.keys(input.edit).some(k=>!['id','fingerprint'].includes(k))||typeof input.edit.id!=='string'||typeof input.edit.fingerprint!=='string')throw new Error('Preview the task edit before confirming it.');
    const plan=clone(input);
    return this.commandQueue(doc,'task destination edit',async()=>{
      this.document(doc);this.assertPowered(doc);const now=this.now(),events=this.records(doc);this.controller(events);
      const event=events.find(e=>e.id===plan.edit.id&&e.kind==='utility'&&e.status!=='returning');
      if(plan.sceneId!==doc.parent.id||!event||taskEditFingerprint(event)!==plan.edit.fingerprint)throw new Error('This task changed during the preview. Preview its edit again.');
      const patch={id:event.id};for(const key of ['kind','bits','target','region','radiusFeet','followSource','light','scanMode'])if(Object.hasOwn(plan,key))patch[key]=plan[key];
      if(plan.point&&!plan.region&&!plan.target&&!plan.followSource)patch.point=plan.point;
      const next=this.previewEdit(doc,patch),captured=this.captureWorld(doc,event.status==='queued'?[]:event.bits,events,now,{behaviour:true,velocity:true});
      const wasPaused=event.taskPausedAt!=null,pausedPose=wasPaused?clone(event.taskPausedPose):null;
      event.utility={...next.event.utility,...(next.point?{elevation:Number(doc.elevation)||0,level:typeof doc._source?.level==='string'?doc._source.level:null}:{})};
      event.target=next.target??null;event.started=now;event.utilityStarted=now;event.utilityRevision=(event.utilityRevision??0)+1;
      Object.assign(event,captured);
      for(const key of ['scanClock','scanOffsets','scanStartElapsed','scanPausedAt','scanPausedElapsed','scanMethodHold','scanCoverage','scanCoverageTotal','scanPending','scanUnreachable','utilityReentries','travelRoutes'])delete event[key];
      if(event.yieldedBits?.length&&event.utility.mode!=='parkLight'){
        event.scanPausedAt=Object.fromEntries(event.yieldedBits.map(bit=>[bit,{at:now,elapsed:0}]));event.scanPausedElapsed=Object.fromEntries(event.yieldedBits.map(bit=>[bit,0]));
      }
      if(wasPaused){event.taskPausedAt=now;event.taskPausedPose=pausedPose;}
      await this.write(doc,events);return this.getToolState(doc);
    });
  }
  setPaused(source,paused,options={}){
    const doc=this.document(source);
    if(typeof paused!=='boolean'||!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>k!=='id')||typeof options.id!=='string'||!options.id||options.id.length>64)throw new Error('Choose a scan job ID and a pause state.');
    return this.commandQueue(doc,paused?'pausing scan':'resuming scan',async()=>{
      this.document(doc);const now=this.now(),events=this.records(doc);this.controller(events);
      const event=events.find(e=>e.id===options.id&&e.kind==='utility'&&e.utility.mode!=='parkLight'&&e.status!=='returning');
      if(!event)throw new Error('That scan is no longer running.');
      if((event.taskPausedAt!=null)===paused)return this.getToolState(doc);
      if(paused){
        const snapshot=this.state(doc,true),hardware=actionHardware(snapshot,now),target=event.target?globalThis.canvas?.tokens?.get(event.target):null,context=actionContext(doc.object,target,snapshot,event,this.manager,hardware,now),renderer=this.renderers.get(doc.object);
        const sample=renderer?renderer.sample(event,snapshot,this.manager,now,hardware,{readOnly:true}).sample:sampleSequence(event,now,context);
        event.taskPausedPose=taskPausePose(sample,context);event.taskPausedAt=now;
      }else{
        const elapsed=sampleScanClock(event,now),delta=Math.max(0,now-event.taskPausedAt),speed=scanSpeed(event.scanClock?.speed??event.utility.scanSpeed);
        event.started+=delta;if(finite(event.utilityStarted))event.utilityStarted+=delta;
        for(const reentry of Object.values(event.utilityReentries??{}))reentry.at+=delta;
        delete event.taskPausedAt;delete event.taskPausedPose;
        event.scanClock={at:now,elapsed,speed};
      }
      await this.write(doc,events);return this.getToolState(doc);
    });
  }
  setExaminationMovement(source,value){
    const doc=this.document(source),movement=normalizeExaminationMovement(value);
    return this.commandQueue(doc,'examination movement',async()=>{
      this.document(doc);if(doc.getFlag(ID,'v8Tools')?.examinationMovement!==movement){const events=this.records(doc),current=doc.getFlag(ID,'v8Tools')?.examinationMovement==='classic'?'classic':'deliberate';for(const event of events)if(event.kind==='utility'&&event.utility.mode==='creatureScan'&&!event.utility.examinationMovement)event.utility.examinationMovement=current;await this.write(doc,events,[],null,{[`flags.${ID}.v8Tools.examinationMovement`]:movement});}
      return this.getToolState(doc);
    });
  }
  /** Observe acquisition edges, never assume elapsed time means coverage.
   * A withdrawn/blocked pass is retried on the continuing itinerary. Only new
   * completed cell identities are serialized, at most once per exposure. */
  observeSurvey(doc,event,now){
    if(event.utility?.mode!=='areaScan'||event.utility.scanMode!=='once'||event.status!=='running'||event.taskPausedAt!=null)return false;
    this.surveyObservations??=new WeakMap();let jobs=this.surveyObservations.get(doc);if(!jobs)this.surveyObservations.set(doc,jobs=new Map());
    let seen=jobs.get(event.id);if(!seen||seen.started!==event.started){seen={started:event.started,pending:new Map()};jobs.set(event.id,seen);}
    const snapshot=this.state(doc,true),hardware=actionHardware(snapshot,now),context=actionContext(doc.object,null,snapshot,event,this.manager,hardware,now),renderer=this.renderers.get(doc.object);
    // A wall edit (door opened) may make refused cells reachable again.
    const revision=context.scanWalls?.revision??'open';let reopened=false;if(seen.revision!==revision){seen.pending.clear();seen.refused=new Map();reopened=seen.revision!==undefined&&!!event.scanUnreachable?.length;seen.revision=revision;}
    let sample=renderer?renderer.sample(event,snapshot,this.manager,now,hardware,{readOnly:true}).sample:sampleSequence(event,now,context);
    if(!renderer&&context.scanWalls){const guarded=guardScanSample(sample,event,context,now,seen.wallState);sample=guarded.sample;seen.wallState=guarded.state;}
    const covered=new Set(event.scanCoverage??[]);
    for(const bit of seen.pending.keys())if(!event.bits.includes(bit))seen.pending.delete(bit);
    const sources=new Map();for(const effect of sample.effects??[])if(effect.mode==='areaScan')for(const channel of effect.channels??[])for(const source of channel.sources??[{id:channel.id,gridCellId:channel.gridCellId}])if(source.gridCellId)sources.set(source.id,source.gridCellId);
    for(const bit of event.bits){
      const phase=sample.phases?.[bit],completed=sample.completedCells?.[bit],pending=seen.pending.get(bit);
      if(pending&&completed&&pending.ordinal===completed.ordinal&&pending.maximum>=.65&&(completed.gridCellIds??[completed.gridCellId??completed.id]).includes(pending.cell))covered.add(pending.cell);
      const cell=sources.get(bit);
      if(phase?.phase==='scanning'&&cell){
        if(pending?.ordinal===phase.ordinal&&pending.cell===cell)pending.maximum=Math.max(pending.maximum,phase.progress??0);
        else if((phase.progress??1)<=.25)seen.pending.set(bit,{ordinal:phase.ordinal,cell,maximum:phase.progress??0});
        else seen.pending.delete(bit);
      }else seen.pending.delete(bit);
    }
    let changed=covered.size!==(event.scanCoverage?.length??0);if(changed)event.scanCoverage=[...covered].slice(0,4096);
    // Cells the wall guard refused on two separate visit attempts (a full lap
    // in a large field) are unreachable for this viewer; covered wins.
    seen.refused??=new Map();
    for(const {cells=[],attempt}of sample.scanWallStatus?.refused??[])for(const cell of cells){let tries=seen.refused.get(cell);if(!tries)seen.refused.set(cell,tries=new Set());if(tries.size<4)tries.add(String(attempt));}
    const unreachable=new Set(reopened?[]:(event.scanUnreachable??[]).filter(id=>!covered.has(id)));
    for(const [cell,tries]of seen.refused)if(tries.size>=2&&!covered.has(cell))unreachable.add(cell);
    if(reopened||unreachable.size!==(event.scanUnreachable?.length??0)){event.scanUnreachable=[...unreachable].slice(0,4096);changed=true;}
    const expected=areaSurveyCellIds(event,context),pending=(sample.scanWallStatus?.pending?.length??0)>0;
    if(event.scanCoverageTotal!==expected.length){event.scanCoverageTotal=expected.length;changed=true;}
    if((event.scanPending??false)!==pending){event.scanPending=pending;changed=true;}
    if(!event.yieldedBits?.length&&expected.length&&expected.every(id=>covered.has(id)||unreachable.has(id))){this.beginReturn(doc,event,now);event.completion=unreachable.size?'survey-partial':'survey-complete';jobs.delete(event.id);return true;}
    return changed;
  }
  /** Command-edge rate changes rebase work time while leaving physical
   * departure, return and medicine clocks independent. */
  setScanSpeed(source,value,options={}){
    const doc=this.document(source),speed=normalizeScanSpeed(value);
    if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>k!=='id')||options.id!==undefined&&(typeof options.id!=='string'||!options.id||options.id.length>64))throw new Error('Choose a scan job ID to change its speed.');
    return this.commandQueue(doc,'scan speed',async()=>{
      this.document(doc);const now=this.now(),events=this.records(doc);this.controller(events);let matched=false;
      for(let i=0;i<events.length;i++){
        const event=events[i];if(!options.id||event.kind!=='utility'||event.utility.mode==='parkLight'||event.status==='returning'||event.id!==options.id)continue;
        const target=event.target?globalThis.canvas?.tokens?.get(event.target):null,snapshot=this.state(doc,true);
        const context=actionContext(doc.object,target,snapshot,event,this.manager,actionHardware(snapshot,now),now);
        events[i]=retimeScanEvent(event,now,speed,{arrivalTimes:scanArrivalTimes(event,context)});matched=true;
      }
      if(options.id&&!matched)throw new Error('That scan is no longer running.');
      await this.write(doc,events,[],null,options.id?{}:{[`flags.${ID}.v8Tools.scanSpeed`]:speed});
      // Rate edits intentionally preserve a continuing optical inverse. A
      // broader older recovery cannot yet restore the same job clock safely.
      const undo=this.commandUndos?.get(doc);if(options.id&&undo&&!undo.lightInverse)this.commandUndos.delete(doc);
      return this.getToolState(doc);
    });
  }
  /** A style edit retains any visible pass, then applies on its next visit.
   * Physical routes and work clocks remain untouched. */
  setScanMethods(source,patch){
    const doc=this.document(source);normalizeScanMethods(patch);
    patch=clone(patch);
    return this.commandQueue(doc,'scanning styles',async()=>{
      this.document(doc);const now=this.now(),events=this.records(doc);this.controller(events);
      const scanMethods=normalizeScanMethods(patch,{defaults:effectiveScanMethods(doc.getFlag(ID,'v8Tools')?.scanMethods)});
      const snapshot=this.state(doc,true),hardware=actionHardware(snapshot,now),renderer=this.renderers.get(doc.object);
      for(const event of events){
        if(event.kind!=='utility'||event.utility.mode==='parkLight'||event.status==='returning')continue;
        const target=event.target?globalThis.canvas?.tokens?.get(event.target):null,context=actionContext(doc.object,target,snapshot,event,this.manager,hardware,now);
        const sample=renderer?renderer.sample(event,snapshot,this.manager,now,hardware,{readOnly:true}).sample:sampleSequence(event,now,context),hold={};
        for(const bit of event.bits){
          const phase=sample.phases?.[bit];if(!['scanning','settling','closing'].includes(phase?.phase)||!phase.scanVisit||!SCAN_METHOD_IDS.includes(phase.method))continue;
          hold[bit]={visit:String(phase.scanVisit),method:phase.method};
        }
        event.utility={...event.utility,scanMethods:clone(scanMethods)};
        if(Object.keys(hold).length)event.scanMethodHold=hold;else delete event.scanMethodHold;
      }
      await this.write(doc,events,[],null,{[`flags.${ID}.v8Tools.scanMethods`]:scanMethods});return this.getToolState(doc);
    });
  }
  async assignNow(doc,patient,bits,record,events,now,captured){
    const detached=this.detach(doc,events,bits,now,{cancelActions:false}),location=patient===doc?'home':patient.id;events=detached.events;
    record=setDestinations(record,bits,location);record.groups[location]??=defaultGroup(this.state(doc,true));
    const groupBits=BIT_IDS.filter(bit=>record.bits[bit].location===location),existing=events.filter(e=>e.kind==='escort'&&e.status==='running'&&e.target===patient.id),groupCapture=this.captureWorld(doc,groupBits,events,now);
    Object.assign(groupCapture.originsWorld,captured.originsWorld);Object.assign(groupCapture.originDepths,captured.originDepths);
    if(captured.originPresence)Object.assign(groupCapture.originPresence??={},captured.originPresence);
    events=events.filter(e=>!existing.includes(e));const event=location==='home'?this.localTransfer(doc,bits,record,now,captured):this.escortEvent(doc,patient.id,groupBits,record,now,groupCapture);
    events.push(event);events=this.reconcile(doc,events,record,now);const handle=this.createHandle(doc,event);await this.write(doc,events,[...detached.cancelled,...existing.map(event=>({event,reason:'group-updated'}))],record);return handle;
  }
  stopTool(source,input){
    const doc=this.document(source),options=typeof input==='string'?{id:input}:input??{};
    if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>!['id','bits'].includes(k))||options.id!==undefined&&(typeof options.id!=='string'||options.id.length>64))throw new Error('Choose a job ID or its instrument IDs to stop.');
    const bits=options.bits===undefined?null:stationList(options.bits);
    return this.commandQueue(doc,'instrument job',async()=>{
      this.document(doc);this.assertPowered(doc);const events=this.records(doc);this.controller(events);
      for(const event of events)if(event.kind==='utility'&&(!options.id||event.id===options.id)&&(!bits||overlaps(event.bits,bits)))this.beginReturn(doc,event,this.now(),'job-stopped');
      await this.write(doc,events.filter(e=>e.status!=='finished'));return this.getToolState(doc);
    });
  }
  undoCommand(source){
    const doc=this.document(source);
    return this.service.enqueue(doc,async()=>{
      this.document(doc);this.assertPowered(doc);const status=this.undoState(doc);if(!status.available)throw new Error(status.reason??'There is no bit command to undo.');
      const undo=this.commandUndos.get(doc),now=this.now(),before=undo.before;let events=this.records(doc);this.controller(events);
      if(undo.lightInverse){
        const patch={},absent=[];
        for(const [path,field]of Object.entries(undo.lightInverse)){
          const [key,child]=path.split('.');
          if(child){patch.lantern??={};patch.lantern[child]=field.before.present?clone(field.before.value):clone(LANTERN_DEFAULTS[child]);}
          else patch[key]=field.before.present?clone(field.before.value):null;
          if(!field.before.present)absent.push(path);
        }
        // Commit semantic choices through today's lifecycle, rather than
        // replaying yesterday's gathered formation or old optical envelopes.
        await this.service.commit(doc,patch,{restoreLightPresence:absent});
        if(this.commandUndos.get(doc)===undo)this.commandUndos.delete(doc);
        globalThis.Hooks?.callAll?.('filamentFlightBitsChanged',doc,this.getState(doc));return this.getToolState(doc);
      }
      const record=clone(before.record),current=this.allocation(doc),capture=this.captureWorld(doc,BIT_IDS,events,now,{behaviour:true,velocity:true});
      const cancelled=events.filter(e=>['utility','escort'].includes(e.kind)).map(event=>({event:clone(event),reason:'command-undone'}));
      events=events.filter(e=>!['utility','escort'].includes(e.kind));record.revision=current.revision+1;
      for(const bit of BIT_IDS)record.bits[bit].revision=record.revision;
      const restored=[];
      for(const previous of before.events.filter(e=>e.kind==='utility'&&e.status!=='returning')){
        if(previous.target)this.toolTarget(doc,previous.target);
        const event={...clone(previous),id:id(),owner:game.user.id,session:this.session,started:now,created:now,expires:Number.MAX_SAFE_INTEGER,status:'running',...this.captureWorld(doc,previous.bits,this.records(doc),now,{behaviour:true,velocity:true})};
        if(event.utility.mode!=='parkLight'&&event.scanClock?.speed!=null)event.utility.scanSpeed=event.scanClock.speed;
        delete event.returnAt;delete event.returnFrom;delete event.scanClock;delete event.scanOffsets;delete event.scanPausedAt;delete event.scanPausedElapsed;delete event.scanStartElapsed;if(event.taskPausedAt!=null)event.taskPausedAt=now;restored.push(event);events.push(event);
      }
      const work=new Set([...restored,...events.filter(e=>!['utility','escort'].includes(e.kind))].flatMap(e=>e.bits)),returning=BIT_IDS.filter(bit=>!work.has(bit));
      if(returning.length)events.push(this.localTransfer(doc,returning,record,now,capture,900));
      events=this.reconcile(doc,events,record,now);
      const raw=doc.getFlag(ID,'flight')??{},fields=new Set([...Object.keys(before.flight),...['bitsDeployed','gemMotion','lightEnabled','lightWithBits','lightIntensity','lightBright','lightDim','lightAppearance','lightVisualReactions','lanternArtwork','lantern']]);
      const currentFlight=Object.fromEntries([...fields].filter(key=>Object.hasOwn(raw,key)).map(key=>[key,raw[key]]));
      const restoredFlight=clone(before.flight);
      if(before.flight.lantern||raw.lantern){
        const saved=before.flight.lantern??{},intent=Object.fromEntries(Object.entries(LANTERN_DEFAULTS).map(([key,fallback])=>[key,clone(Object.hasOwn(saved,key)?saved[key]:fallback)]));
        // A destination recovery can also reverse a light toggle. Keep its
        // current envelope or capture a fresh reversal; never resurrect the
        // optical timestamps stored with the old destination snapshot.
        const fresh={...raw.lantern,...this.service.prepareLanternPatch(doc,intent,{now})};
        for(const key of Object.keys(LANTERN_DEFAULTS))if(!Object.hasOwn(saved,key))delete fresh[key];
        restoredFlight.lantern=fresh;
      }
      await this.write(doc,events,cancelled,record,allocationChanges(currentFlight,restoredFlight,`flags.${ID}.flight`));if(this.commandUndos.get(doc)===undo)this.commandUndos.delete(doc);
      globalThis.Hooks?.callAll?.('filamentFlightBitsChanged',doc,this.getState(doc));return this.getToolState(doc);
    });
  }
  document(input){
    const doc=input?.document??input;this.service.assertOwned(doc);
    if(doc.parent?.id!==globalThis.canvas?.scene?.id||!globalThis.canvas?.ready)throw new Error('Animate a token in the current scene.');
    return doc;
  }
  state(doc,allowCached=false){
    const now=this.now(),shared=allowCached?this.manager.states?.get(doc.object):null;
    const prepared=snapshot=>{
      const initial=this.prepareSnapshot(doc,snapshot,now);let result=initial;
      if(result.lantern?.weight===undefined)result=this.manager?.lantern?.decorate?.(doc.object,result,now)??result;
      if(result.lantern?.weight>0&&doc.object?.mesh)result=bitLanternInFrame(result,sourceTransform(doc.object,result,this.manager).angle);
      return this.retainPreparation(initial,result);
    };
    if(shared?.snapshot&&Math.abs(now-shared.snapshotAt)<50)return prepared(shared.snapshot);
    const raw=doc.getFlag(ID,'flight');this.stateCache??=new WeakMap();let cached=this.stateCache.get(doc);
    if(!allowCached||!cached||cached.raw!==raw){cached={raw,data:normalizeFlag(raw,now)};this.stateCache.set(doc,cached);}
    const snapshot=resolveRenderState(cached.data,runtimeConfiguration(),now,this.manager.context?.(doc)??{});
    return prepared(snapshot);
  }
  records(doc,mutable=true){
    const raw=doc?.getFlag?.(ID,FLAG);if(!doc)return [];if(mutable)return readBitActions(raw);
    let cached=this.recordCache.get(doc);
    if(!cached||cached.raw!==raw){cached={raw,events:readBitActions(raw)};this.recordCache.set(doc,cached);}
    return cached.events;
  }
  allocation(doc,snapshot=null,mutable=true){
    this.allocationCache??=new WeakMap();const raw=doc?.getFlag?.(ID,ALLOCATION_FLAG),flight=doc?.getFlag?.(ID,'flight'),actions=doc?.getFlag?.(ID,FLAG);
    let cached=this.allocationCache.get(doc);
    if(!cached||cached.raw!==raw||cached.flight!==flight||cached.actions!==actions){cached={raw,flight,actions,value:readAllocations(raw,snapshot??this.state(doc,true),this.records(doc,false))};this.allocationCache.set(doc,cached);}
    return mutable?clone(cached.value):cached.value;
  }
  getState(input){
    const doc=input?.document??input,now=this.now(),events=this.records(doc,false).filter(e=>!isFinished(e,now)),record=this.allocation(doc),describe=e=>({id:e.id,name:e.name,kind:e.kind,status:e.status,bits:[...e.bits],priority:e.priority,target:e.target??null,outcome:e.outcome??null,
      phase:eventState(e,now).phase,gesture:e.sequence?.gesture??null});
    const escort=events.find(e=>e.kind==='escort'&&e.status!=='returning'&&!isFinished(e,this.now()));
    const assignment=escort?{id:escort.id,target:escort.target,count:escort.bits.length,program:escort.group?.program??this.state(doc,true).gems.soloProgram,status:escort.status}:null;
    const allocations=BIT_IDS.map(id=>{const event=events.find(e=>e.status!=='queued'&&e.bits.includes(id))??events.find(e=>e.bits.includes(id)),phase=event?eventState(event,now).phase:'idle';return {id,...record.bits[id],activity:phase==='travel'?'travelling':phase==='holding'||phase==='finishing'?event.kind:phase,eventId:event?.id??null,actionTarget:event?.target??null,actionKind:event?.kind??null};});
    const formationAnimated=this.state(doc,true).gems.animated!==false;
    const groups=allocationGroups(record).map(g=>{const borrowed=g.bits.filter(b=>events.some(e=>e.kind!=='escort'&&e.status!=='queued'&&e.bits.includes(b)));return {...g,currentProgram:formationFlowState(g.program,now,g.flow,formationAnimated).program,presentBits:g.bits.filter(b=>!borrowed.includes(b)),presentCount:g.bits.length-borrowed.length,borrowedBits:borrowed,status:borrowed.length?'working':allocations.filter(b=>g.bits.includes(b.id)).some(b=>b.activity==='travelling')?'travelling':'settled'};});
    const {outBits,remoteBits}=allocationPresence(record,events,doc.id);
    return {version:2,revision:record.revision,preferredCount:record.preferredCount,randomOnSummon:record.randomOnSummon,homeGroup:clone(record.groups.home),allocations,groups,outBits,remoteBits,
      available:allocations.filter(b=>['home','retracted'].includes(b.location)&&['idle','escorting'].includes(b.activity)).map(b=>b.id),
      retracted:allocations.filter(b=>b.location==='retracted').map(b=>b.id),assignment,active:events.filter(e=>e.status!=='queued').map(describe),queued:events.filter(e=>e.status==='queued').map(describe),busy:events.length>0};
  }
  register(name,definition){
    if(typeof name!=='string'||!/^[a-zA-Z][\w.-]{0,63}$/.test(name))throw new Error('Animation names must start with a letter and use 1–64 letters, numbers, dots, hyphens or underscores.');
    const sequence=compileSequence(definition);this.definitions.set(name,sequence);return name;
  }
  createHandle(doc,event){
    let resolve;const done=new Promise(r=>resolve=r),record={doc,event,resolve,done};this.handles.set(event.id,record);
    const handle=Object.freeze({id:event.id,done,
      finish:result=>this.finish(doc,event.id,result),cancel:reason=>this.cancel(doc,event.id,reason),
      get status(){return record.result?.status??record.event.status;}});
    record.handle=handle;return handle;
  }
  settle(e,status,reason){
    const h=this.handles.get(e.id);if(!h)return;
    h.result={id:e.id,status,outcome:e.outcome??null,reason:reason??e.reason??null};h.resolve(h.result);this.handles.delete(e.id);
  }
  capture(doc,bits){
    const local=this.manager.states?.get(doc.object),snapshot={...this.state(doc),bitWingBlend:local?.blend},hardware=actionHardware(snapshot,this.now(),{destination:true}),renderers=local?.renderer;
    const handoff=compactWingHandoff(snapshot),compact=handoff.active?handoff.compact>0:snapshot.compactBits,renderer=compact?renderers?.compact:renderers?.rig;
    const deployed=snapshot.rendering.active&&snapshot.bitDeployment>.01&&snapshot.gems.style!=='hidden';
    const origins={},deployedBits=[];
    for(const station of bits){
      const side=station.startsWith('left')?-1:1,index=station.endsWith('Lower')?1:0;
      const active=deployed&&(snapshot.bitCount?.values?.[BIT_IDS.indexOf(station)]??1)>.01;
      if(active)deployedBits.push(station);
      origins[station]=active?[...(renderer?.baseBits?.get(BIT_KEY[station])?.part.points[0]??renderer?.bits?.frames?.records?.get(BIT_KEY[station])?.bit?.part.points[0]??hardware[station].points[0])]:[side*27,-23+index*18,-28,.92];
    }
    const transform=sourceTransform(doc.object,snapshot,this.manager),size=Math.max(doc.object.w,doc.object.h);
    return {origins,deployed:deployedBits.length>0,deployedBits,originScale:[transform.width/size,transform.height/size]};
  }
  /** Capture the displayed world position, not the home station, when ownership
   * transfers between an escort and a treatment. No token flags are mutated. */
  captureWorld(doc,bits,events=[],now=this.now(),{behaviour=false,velocity=behaviour,velocityDelta=8,coreVelocity=false}={}){
    const originRotations={},originTools={},originCoreStates={},originVelocities={},originCoreVelocities={};
    const captureWork=(bit,rotation,tool,activity)=>{
      originRotations[bit]=Math.atan2(Math.sin(rotation??0),Math.cos(rotation??0));
      if(tool&&['lens','probe','plate','spark','travel'].includes(tool.type)&&finite(tool.amount))originTools[bit]={type:tool.type,amount:Math.max(0,Math.min(1,tool.amount)),progress:Math.max(0,Math.min(1,tool.progress??0)),...(finite(tool.variation)?{variation:Math.max(0,Math.min(3,tool.variation))}:{})};
      const core=captureCoreActivity(activity);
      if(core)originCoreStates[bit]=core;
    };
    const snapshot=this.state(doc,true),hardware=actionHardware(snapshot,now),originsWorld={},originDepths={},originPresence={},base=this.capture(doc,bits);
    const transform=sourceTransform(doc.object,snapshot,this.manager),samples=new Map(),contexts=new Map(),futureSamples=new Map(),delta=Math.max(.25,Math.min(8,Number(velocityDelta)||8));
    let homeNow,homeNext;
    for(const bit of bits){
      // Maintenance removes completed returns before expanding escorts or
      // launching queued work. Their final displayed endpoint still owns the
      // handoff; falling back to the home station would send the bit twice.
      const event=events.find(e=>e.status!=='queued'&&e.bits.includes(bit)&&!isFinished(e,now))??
        this.records(doc,false).find(e=>e.status==='returning'&&e.bits.includes(bit)&&isFinished(e,now));
      if(event){
        if(event.kind==='utility'&&event.target&&!scanTokenVisible(globalThis.canvas?.tokens?.get(event.target),{scene:doc.parent})){
          const known=this.renderers.get(doc.object)?.lastPositions?.get(event.id)?.[bit]??event.originsWorld?.[bit];originsWorld[bit]=known?{...known}:toWorld(base.origins[bit],transform);originDepths[bit]=event.originDepths?.[bit]??1;originPresence[bit]={alpha:1,scale:1};
          if(velocity)originVelocities[bit]={x:0,y:0};if(behaviour)captureWork(bit,event.originRotations?.[bit],null,null);continue;
        }
        if(!samples.has(event.id)){
          const target=event.target?globalThis.canvas?.tokens?.get(event.target):null;
          const context=actionContext(doc.object,target,snapshot,event,this.manager,hardware,now);
          const renderer=this.renderers.get(doc.object);
          contexts.set(event.id,context);
          samples.set(event.id,renderer?renderer.sample(event,snapshot,this.manager,now,hardware).sample:sampleSequence(event,now,context));
        }
        const sample=samples.get(event.id);originsWorld[bit]={...sample.positions[bit]};originDepths[bit]=sample.depths?.[bit]??1;
        if(velocity){
          if(!futureSamples.has(event.id)){
            const target=event.target?globalThis.canvas?.tokens?.get(event.target):null,nextSnapshot=actionSnapshotAt(snapshot,now,delta),nextHardware=actionHardware(nextSnapshot,now+delta);
            const context=actionContext(doc.object,target,nextSnapshot,event,this.manager,nextHardware,now+delta),renderer=this.renderers.get(doc.object);
            futureSamples.set(event.id,renderer?renderer.sample(event,nextSnapshot,this.manager,now+delta,nextHardware,{readOnly:true}).sample:sampleSequence(event,now+delta,context));
          }
          const next=futureSamples.get(event.id)?.positions?.[bit],current=sample.positions[bit];
          if(current&&next)originVelocities[bit]={x:(next.x-current.x)*1000/delta,y:(next.y-current.y)*1000/delta};
          const nextCore=futureSamples.get(event.id)?.coreStates?.[bit];
          if(coreVelocity&&sample.coreStates?.[bit]&&nextCore)originCoreVelocities[bit]=treatmentCoreVelocity(sample.coreStates[bit],nextCore,delta/1000);
        }
        // Physical presence belongs to every transfer capture, independently
        // of optional gesture/tool capture. Reversing a still-visible return
        // must not hide and shrink the instrument for a new deployment.
        const presence=actionBitPresence(event,bit,sample.state,contexts.get(event.id),now);
        // Condition grounding owns opacity separately from the withdrawal
        // fade. Capture its deployment input; the renderer applies the same
        // current condition once to both sides of this command edge.
        originPresence[bit]={alpha:sample.conditionBits?.[bit]?.conditionGround>0?presence.deployment:presence.alpha,scale:presence.scale};
        if(presence.alpha>.999&&presence.scale>.999&&!base.deployedBits.includes(bit)){base.deployedBits.push(bit);base.deployed=true;}
        if(behaviour)captureWork(bit,sample.rotations?.[bit],sample.tools?.[bit],sample.coreStates?.[bit]);
      }else {
        const renderer=this.manager.states?.get(doc.object)?.renderer,home=snapshot.compactBits?renderer?.compact?.bits:renderer?.rig?.bits;
        const shown=home?.records?.has(BIT_KEY[bit])?home.placements?.get(bit):null;
        originsWorld[bit]=shown&&Number.isFinite(shown.x)&&Number.isFinite(shown.y)?{x:shown.x,y:shown.y}:toWorld(base.origins[bit],transform);
        originDepths[bit]=behaviour&&finite(shown?.z)?shown.z/24:shown?.front!==undefined?(shown.front?1:-1):(base.origins[bit]?.[2]??-1)>=0?1:-1;
        if(velocity&&base.deployedBits.includes(bit)){
          homeNow??=actionHardware(snapshot,now,{destination:true});
          // Sample the same underlying geometry twice. Subtracting a cached
          // displayed position would turn its normal paint delay into velocity.
          const nextSnapshot=actionSnapshotAt(snapshot,now,delta);
          homeNext??=actionHardware(nextSnapshot,now+delta,{destination:true});
          const first=homeNow[bit]?.points?.[0],second=homeNext[bit]?.points?.[0];
          if(first&&second){const a=toWorld(first,transform),b=toWorld(second,transform);originVelocities[bit]={x:(b.x-a.x)*1000/delta,y:(b.y-a.y)*1000/delta};}
        }
        if(behaviour){
          const visibleHardware=home?.records?.get(BIT_KEY[bit])?.frame?.bit?.part?.hardware??actionHardware(snapshot,now,{destination:true})[bit]?.hardware;
          captureWork(bit,(shown?.angle??transform.angle)+(visibleHardware?.angle??0)-transform.angle-(hardware[bit]?.hardware?.angle??0),visibleHardware?.tool,visibleHardware?.resonance?.coreState);
        }
      }
    }
    return {...base,...(behaviour?{deployed:base.deployedBits.length>0}:{}),originsWorld,originDepths,...(Object.keys(originPresence).length?{originPresence}:{}),...(behaviour?{originRotations,originTools,originCoreStates}:{}),...(velocity?{originVelocities}:{}),...(Object.keys(originCoreVelocities).length?{originCoreVelocities}:{})};
  }
  /** Freeze physical lane ownership at the command edge. The sampler follows
   * the charge's live visual frame without choosing new lanes every frame. */
  captureGesture(doc,event,events,now,captured=this.captureWorld(doc,event.bits,events,now,{behaviour:true})){
    const {originVelocities,...pose}=captured,target=event.target?globalThis.canvas?.tokens?.get(event.target):null,charge=target?.mesh?target:doc.object;
    const frame=tokenVisualPose(charge,this.manager),size=Math.max(charge.w,charge.h),snapshot=this.state(doc,true),hardware=actionHardware(snapshot,now);
    const gestureLayout=captureGestureLayout(event.bits,pose.originsWorld,{x:frame.x,y:frame.y},size,{rotation:frame.angle,depths:pose.originDepths,velocities:originVelocities});
    const sourceRotation=sourceTransform(doc.object,snapshot,this.manager).angle;
    gestureLayout.sourceRotation=finite(sourceRotation)?sourceRotation:0;
    gestureLayout.orientations=Object.fromEntries(event.bits.map(station=>{const angle=hardware[station]?.hardware?.angle;return [station,finite(angle)?angle:0];}));
    return {...pose,gestureLayout};
  }
  /** A Token, TokenDocument, token id or token UUID ("Scene.x.Token.y"). */
  target(doc,input){
    let patient=input?.document??input;
    if(typeof input==='string'){
      if(input.includes('.')){try{patient=globalThis.fromUuidSync?.(input)??null;}catch{patient=null;}patient=patient?.document??patient;}
      else patient=globalThis.canvas?.tokens?.get(input)?.document??doc.parent?.tokens?.get(input)??null;
    }
    if(!patient?.id||patient.parent!==doc.parent||patient.parent.tokens?.get(patient.id)!==patient)throw new Error('Choose a placed target token in the same scene.');
    if(!game.user?.isGM&&(patient.hidden||patient.object?.visible===false))throw new Error('Choose a visible target token.');
    return patient;
  }
  controller(events){
    if(events.some(e=>e.owner!==game.user.id&&game.users?.get(e.owner)?.active))throw new Error('Another owner is directing these bits. Use Return all bits to take control safely.');
  }
  /** Transfer physical ownership at its currently displayed location. Cancelling
   * one station in a macro cancels that action and returns its other stations. */
  detach(doc,events,bits,now,{cancelActions=true,preserveOthers=false,preserveUtilities=false}={}){
    const cancelled=[];
    for(const event of events){
      if(!overlaps(event.bits,bits)&&!(event.kind==='utility'&&overlaps(event.yieldedBits??[],bits)))continue;
      if(event.kind==='utility'&&preserveUtilities)continue;
      if(event.kind!=='escort'&&!cancelActions)continue;
      const remaining=event.bits.filter(b=>!bits.includes(b));
      if(event.kind==='utility'){
        const yielded=(event.yieldedBits??[]).filter(bit=>!bits.includes(bit));
        if(yielded.length)event.yieldedBits=yielded;else delete event.yieldedBits;
        if(remaining.length&&event.status!=='returning'){
          const capture=this.captureWorld(doc,remaining,events,now,{behaviour:true});event.bits=remaining;
          event.formationBits=(event.formationBits??[...remaining,...bits]).filter(bit=>!bits.includes(bit));this.resizeUtility(event);
          event.utilityReentries=Object.fromEntries(remaining.map(bit=>[bit,{at:now,duration:900,from:capture.originsWorld[bit],fromRotation:capture.originRotations?.[bit]??0,fromDepth:capture.originDepths?.[bit]??1}]));
          continue;
        }
        if(!remaining.length&&yielded.length){event.status='queued';event.bits=[...yielded];event.formationBits=[...yielded];this.resizeUtility(event);continue;}
      }
      // A selected-only HUD command borrows exact identities without cancelling
      // the treatment or returning its unselected partners. Its handle stays live.
      if(preserveOthers&&remaining.length){event.bits=remaining;this.resizeUtility(event);continue;}
      cancelled.push({event:clone(event),reason:'redirected'});
      if(event.kind!=='escort'&&remaining.length){this.beginReturn(doc,event,now,'redirected');event.bits=remaining;this.resizeUtility(event);}
      else event.bits=remaining;
      if(!remaining.length)event.status='finished';
    }
    return {events:events.filter(e=>e.status!=='finished'),cancelled};
  }
  escortEvent(doc,target,bits,record,now,captured={},options={}){
    return {id:id(),name:'Remote formation',kind:'escort',escortCountMode:'reserved',sequence:null,owner:game.user.id,session:this.session,
      created:now,expires:Number.MAX_SAFE_INTEGER,started:now,status:'running',target,bits:[...bits],priority:5,travelDuration:options.travelDuration??650,
      returnDuration:options.returnDuration??800,weighty:doc.getFlag(ID,'v8Tools')?.weightedTravel??runtimeConfiguration().v8WeightedTravel!==false,group:clone(record.groups[target]??defaultGroup(this.state(doc,true))),...captured};
  }
  resizeUtility(event){
    if(event.kind!=='utility'||event.utility.mode==='parkLight'||event.utility.followSource||event.utility.region)return;
    const count=Math.max(1,(event.formationBits??event.bits).length),ratio=count*5/event.utility.radiusFeet;
    event.utility={...event.utility,radiusFeet:count*5,radiusPixels:event.utility.radiusPixels*ratio};
  }
  yieldUtilities(events,bits){
    for(const event of events){
      if(event.kind!=='utility'||event.status!=='running'||!overlaps(event.bits,bits))continue;
      event.formationBits??=[...event.bits];event.utilityStarted??=event.started;
      const yielded=event.bits.filter(bit=>bits.includes(bit));
      if(event.utility.mode!=='parkLight')for(const bit of yielded){const pause=pauseScanBit(event,this.now(),bit);(event.scanPausedAt??={})[bit]=pause;(event.scanPausedElapsed??={})[bit]=pause.elapsed;}
      event.yieldedBits=[...new Set([...(event.yieldedBits??[]),...yielded])];
      const remaining=event.bits.filter(bit=>!bits.includes(bit));
      if(remaining.length)event.bits=remaining;
      else{event.status='queued';event.bits=[...event.yieldedBits];}
    }
    return events;
  }
  routesEnabled(doc){return doc.getFlag?.(ID,'v8Tools')?.obstacleRoutes??runtimeConfiguration().v8ObstacleRoutes===true;}
  /** Native collision and visibility work belongs exclusively to command
   * preflight. Serialized routes contain geometry, never wall identifiers. */
  planEventRoutes(doc,event,now=this.now()){
    if(!this.routesEnabled(doc)||event.status==='queued'||event.kind==='treatment'||event.sequence?.gesture)return;
    const snapshot=this.state(doc,true),target=event.target?globalThis.canvas?.tokens?.get(event.target):null,context=actionContext(doc.object,target,snapshot,event,this.manager,actionHardware(snapshot,now),now);
    if(event.status==='returning'){
      event.returnRoutes=Object.fromEntries(event.bits.map(bit=>[bit,planSceneBitRoute(event.returnFrom?.[bit]??context.origins[bit],context.returns[bit],{source:doc})]));
      return;
    }
    const destinations=event.kind==='utility'?bitToolDestinations(event,context):sampleSequence({...event,travelDuration:0,started:now-1},now,context).positions;
    event.travelRoutes=Object.fromEntries(event.bits.map(bit=>[bit,planSceneBitRoute(event.originsWorld?.[bit]??context.origins[bit],destinations[bit],{source:doc})]));
  }
  restoreUtilityClaims(doc,events,now){
    let changed=false;
    for(const event of events){
      if(event.kind!=='utility'||!event.yieldedBits?.length||event.status==='returning')continue;
      const ready=event.yieldedBits.filter(bit=>!events.some(other=>other!==event&&other.status!=='queued'&&other.bits.includes(bit)&&!isFinished(other,now)));
      if(!ready.length)continue;
      const captured=this.captureWorld(doc,ready,events.filter(other=>other!==event),now,{behaviour:true,velocity:true});
      event.utilityReentries??={};
      if(event.taskPausedAt!=null){const snapshot=this.state(doc,true),hardware=actionHardware(snapshot,now),transform=sourceTransform(doc.object,snapshot,this.manager);for(const bit of ready){event.taskPausedPose.positions[bit]={...captured.originsWorld[bit]};event.taskPausedPose.rotations[bit]=(captured.originRotations?.[bit]??0)+transform.angle+(hardware[bit]?.hardware?.angle??0);event.taskPausedPose.depths[bit]=captured.originDepths?.[bit]??1;}}
      for(const bit of ready){
        event.utilityReentries[bit]={at:now,duration:900,from:captured.originsWorld[bit],fromRotation:captured.originRotations?.[bit]??0,fromDepth:captured.originDepths?.[bit]??1};
        if(event.utility.mode!=='parkLight'){(event.scanOffsets??={})[bit]=resumedScanOffset(event,now,bit);delete event.scanPausedAt?.[bit];delete event.scanPausedElapsed?.[bit];}
      }
      event.yieldedBits=event.yieldedBits.filter(bit=>!ready.includes(bit));
      if(event.status==='queued'){event.bits=ready;event.status='running';event.started=event.utilityStarted??event.started;}
      else event.bits=(event.formationBits??BIT_IDS).filter(bit=>event.bits.includes(bit)||ready.includes(bit));
      if(!event.yieldedBits.length)delete event.yieldedBits;
      changed=true;
    }
    return changed;
  }
  /** Reconcile desired remote groups only at command/action edges. Groups are
   * never recomputed by writing flags on an animation frame. */
  reconcile(doc,events,record,now){
    const busy=new Set(events.filter(e=>e.kind!=='escort'||e.status==='returning').filter(e=>e.status!=='queued').flatMap(e=>e.bits));
    for(const group of allocationGroups(record).filter(g=>g.target)){
      const wanted=group.bits.filter(b=>!busy.has(b));if(!wanted.length)continue;
      const escorts=events.filter(e=>e.kind==='escort'&&e.status==='running'&&e.target===group.target&&!e.localTransfer);
      let event=escorts[0];
      if(!event){event=this.escortEvent(doc,group.target,wanted,record,now,{...this.captureWorld(doc,wanted,events,now),deployedBits:[...wanted]},{travelDuration:0});events.push(event);}
      else {
        const changed=wanted.length!==event.bits.length||wanted.some((b,i)=>b!==event.bits[i]);
        if(changed){
          const added=wanted.filter(b=>!event.bits.includes(b)),completed=this.records(doc,false).filter(e=>e.status==='returning'&&isFinished(e,now));
          const arrived=added.length&&event.bits.every(b=>wanted.includes(b))&&added.every(b=>completed.some(e=>e.bits.includes(b)));
          if(arrived){const captured=this.captureWorld(doc,added,events,now);Object.assign(event.originsWorld??={},captured.originsWorld);Object.assign(event.originDepths??={},captured.originDepths);if(captured.originPresence)Object.assign(event.originPresence??={},captured.originPresence);event.bits=wanted;}
          else {const captured=this.captureWorld(doc,wanted,events,now);Object.assign(event,captured,{bits:wanted,started:now,travelDuration:650,deployedBits:[...wanted]});}
        }
        else event.bits=wanted;
        event.group=clone(record.groups[group.target]);
      }
      for(const duplicate of escorts.slice(1))duplicate.status='finished';
    }
    return events.filter(e=>e.status!=='finished'&&e.bits.length);
  }
  assign(source,target,input={}){
    const doc=this.document(source),patient=this.target(doc,target),opts=animationOptions({priority:5,...input,bits:input.bits??1});
    if(input.requireAvailable!==undefined&&typeof input.requireAvailable!=='boolean')throw new Error('Require available must be true or false.');
    return this.commandQueue(doc,'sending instruments',async()=>{
      this.document(doc);this.assertPowered(doc);this.target(doc,patient);const now=this.now();let events=this.records(doc).filter(e=>e.expires>now&&!isFinished(e,now)),record=this.allocation(doc);
      this.controller(events);
      const bits=Array.isArray(input.bits)?stationList(input.bits):chooseAvailable(record,input.bits??1,{events});
      if(input.requireAvailable===true&&events.some(e=>overlaps(e.bits,bits)&&(e.status==='queued'||e.status==='returning'||e.kind!=='escort'||now<e.started+e.travelDuration)))
        throw new Error('One or more selected bits are moving or busy. Wait for them, or change your selection.');
      const captured=this.captureWorld(doc,bits,events,now),detached=this.detach(doc,events,bits,now);events=detached.events;
      const location=patient===doc?'home':patient.id;record=setDestinations(record,bits,location);
      record.groups[location]??=defaultGroup(this.state(doc,true));
      if(input.program!==undefined)record.groups[location]={...record.groups[location],...validateGroupPatch({program:input.program})};
      const groupBits=BIT_IDS.filter(b=>record.bits[b].location===location),existing=events.filter(e=>e.kind==='escort'&&e.status==='running'&&e.target===patient.id);
      const groupCapture=this.captureWorld(doc,groupBits,events,now);
      // Existing members keep their own displayed positions as the group changes
      // count, while the newly sent members start at their captured positions.
      Object.assign(groupCapture.originsWorld,captured.originsWorld);Object.assign(groupCapture.originDepths,captured.originDepths);
      if(captured.originPresence)Object.assign(groupCapture.originPresence??={},captured.originPresence);
      events=events.filter(e=>!existing.includes(e));
      let event;
      if(location==='home')event=this.localTransfer(doc,bits,record,now,captured,opts.returnDuration);
      else event=this.escortEvent(doc,patient.id,groupBits,record,now,groupCapture,opts);
      events.push(event);events=this.reconcile(doc,events,record,now);
      const handle=this.createHandle(doc,event);
      try{await this.write(doc,events,[...detached.cancelled,...existing.map(event=>({event,reason:'group-updated'}))],record);return handle;}
      catch(error){this.settle(event,'error',error.message);throw error;}
    });
  }
  localTransfer(doc,bits,record,now,captured,duration=650){
    return {...this.escortEvent(doc,doc.id,bits,record,now,captured),localTransfer:true,status:'returning',returnAt:now,returnDuration:duration,
      returnFrom:captured.originsWorld,returnDepths:captured.originDepths,returnRotations:{},expires:now+duration+1000};
  }
  /** Only explicit retraction releases a light request. A working/queued bit
   * cannot keep an otherwise empty home constellation armed after that choice. */
  manualLightChanges(doc,record,events,bits,now,{force=false}={}){
    if(!force&&!bits.some(id=>record.bits[id]?.location==='home'))return {};
    const reserved=new Set(events.filter(event=>event.status==='queued'||!event.localTransfer&&
      !(event.kind==='escort'&&event.target===doc.id)).flatMap(event=>event.bits));
    if(!force&&BIT_IDS.some(id=>record.bits[id]?.location==='home'&&!bits.includes(id)&&!reserved.has(id)))return {};
    return this.service.manualBitLightChanges?.(doc,now)??{};
  }
  /** An explicit destination command supersedes an older reservation. */
  async relocate(doc,bits,location,record,events,now,{duration=650,preferredCount,preserveOthers=false,manualLightIntent=false}={}){
    const lightChanges=manualLightIntent?(location==='retracted'?this.manualLightChanges(doc,record,events,bits,now):
      this.service.ordinaryBitSummonLightChanges?.(doc,now)??{}):{};
    const captured=this.captureWorld(doc,bits,events,now);
    if(location==='home'&&manualLightIntent)this.prepareSummonFormation(doc,record,bits,now,events);
    const detached=this.detach(doc,events,bits,now,{preserveOthers});events=detached.events;
    record=setDestinations(record,bits,location);if(preferredCount!==undefined)record.preferredCount=preferredCount;
    if(location!=='retracted')record.groups[location]??=defaultGroup(this.state(doc,true));
    events.push(this.localTransfer(doc,bits,record,now,captured,duration));events=this.reconcile(doc,events,record,now);
    await this.write(doc,events,detached.cancelled,record,lightChanges);return this.getState(doc);
  }
  assertPowered(doc) {
    const response=this.state(doc,true).conditionResponse;
    if(response?.bits&&['falling','fallen'].includes(response.collapse?.phase))throw new Error('The bits are unpowered. They remain where they fell until their owner recovers.');
  }
  toggle(source,station){
    const doc=this.document(source);stationList([station]);
    return this.commandQueue(doc,'instrument command',async()=>{
      this.document(doc);this.assertPowered(doc);const events=this.records(doc).filter(e=>!isFinished(e,this.now())),record=this.allocation(doc);this.controller(events);
      const awayAction=events.some(e=>e.status!=='queued'&&e.kind!=='escort'&&e.target!==doc.id&&e.bits.includes(station));
      const location=record.bits[station].location==='home'&&!awayAction?'retracted':'home';
      return this.relocate(doc,[station],location,record,events,this.now(),{manualLightIntent:true});
    });
  }
  recall(source,input={}){
    const doc=this.document(source);if(input.retract!==undefined&&typeof input.retract!=='boolean')throw new Error('Retract must be true or false.');
    if(input.only!==undefined&&!['out','remote','retracted'].includes(input.only))throw new Error('Unknown selected-bit scope.');
    if(input.preserveOthers!==undefined&&typeof input.preserveOthers!=='boolean')throw new Error('Preserve others must be true or false.');
    return this.commandQueue(doc,'recalling instruments',async()=>{
      this.document(doc);this.assertPowered(doc);const record=this.allocation(doc),now=this.now(),events=this.records(doc).filter(event=>!isFinished(event,now));
      let bits=input.bits?stationList(input.bits):BIT_IDS.filter(b=>!['home','retracted'].includes(record.bits[b].location));
      if(input.only){const presence=allocationPresence(record,events,doc.id),scope=input.only==='out'?presence.outBits:input.only==='remote'?presence.remoteBits:BIT_IDS.filter(id=>!presence.outBits.includes(id));bits=bits.filter(id=>scope.includes(id));}
      this.controller(events);if(!bits.length)return this.getState(doc);
      return this.relocate(doc,bits,input.retract?'retracted':'home',record,events,now,{...input,manualLightIntent:true});
    });
  }
  /** Global HUD command. Evaluate the current document inside its command queue
   * so a rapid click or a treatment starting concurrently cannot use stale UI
   * state. A temporary reservation counts as out even if its saved home is
   * retracted. The local count/diamond APIs intentionally remain independent. */
  toggleAll(source,input={}){
    const doc=this.document(source);
    if(input.count!==undefined&&(!Number.isInteger(input.count)||input.count<1||input.count>4))throw new Error('Choose one to four instruments.');
    return this.commandQueue(doc,'deploying instruments',async()=>{
      this.document(doc);this.assertPowered(doc);const now=this.now(),events=this.records(doc).filter(e=>!isFinished(e,now)),record=this.allocation(doc);
      if(allocationPresence(record,events,doc.id).outBits.length)return this.retractAllNow(doc,record,events,now,{manualLightIntent:true});
      return this.deploymentNow(doc,{enabled:true,count:input.count??record.preferredCount,manualLightIntent:true});
    });
  }
  retractAll(source){
    const doc=this.document(source);return this.commandQueue(doc,'retracting instruments',()=>{
      this.document(doc);const now=this.now();return this.retractAllNow(doc,this.allocation(doc),this.records(doc).filter(e=>!isFinished(e,now)),now,{manualLightIntent:true});
    });
  }
  async retractAllNow(doc,record,events,now,{duration=650,extraChanges={},animate=true,manualLightIntent=false,bits=BIT_IDS}={}){
    bits=BIT_IDS.filter(id=>bits.includes(id));
    this.assertPowered(doc);const outBits=allocationPresence(record,events,doc.id).outBits.filter(id=>bits.includes(id)),captured=animate&&outBits.length?this.captureWorld(doc,outBits,events,now):null;
    const lightChanges=manualLightIntent?this.manualLightChanges(doc,record,events,bits,now,{force:bits.length===BIT_IDS.length}):{};
    // Cancel queued actions too: they must not launch again after "Retract all".
    // Explicit global commands take control like returnAll; old task completions
    // cannot restore a remote destination after this command has replaced it.
    const detached=bits.length?this.detach(doc,events,bits,now):{events,cancelled:[]};
    if(bits.length)record=setDestinations(record,bits,'retracted');events=detached.events;
    if(captured)events.push(this.localTransfer(doc,outBits,record,now,captured,duration));
    await this.write(doc,events,detached.cancelled,record,{...extraChanges,...lightChanges});return this.getState(doc);
  }
  /** Landing owns one explicit choice for this command. Keep preserves exact
   * assignments; normal landing uses the same clean recall as Retract all. */
  async landBitsNow(doc,flightChanges,{keepBits,snapshot,cfg,now,duration,hold=0,transitionId=null}){
    const response=snapshot.conditionResponse;
    if(response?.bits&&['falling','fallen'].includes(response.collapse?.phase))return doc.update(flightChanges);
    const record=this.allocation(doc,snapshot);
    // (a recall left waiting by an earlier landing is over, whatever this one does)
    if(doc.getFlag?.(ID,LAND_FLAG))forceDelete(flightChanges,`flags.${ID}`,LAND_FLAG);
    if(keepBits){
      // Legacy instruments inferred their visibility from open wings. Freeze
      // their existing destinations before closing those wings, without
      // altering an established allocation record or interrupting any action.
      return doc.update({...(!doc.getFlag(ID,ALLOCATION_FLAG)?{[ALLOCATION_PATH]:record}:{}),...flightChanges});
    }
    const events=this.records(doc).filter(e=>e.expires>now&&!isFinished(e,now));
    // Landing retracts idle, escorting and returning bits. Instruments still
    // doing a job (treatment, sequence, scan, parked light, including bits
    // lent from a job) finish it first and then come back to Ellie.
    const working=new Set(events.filter(e=>e.kind!=='escort'&&!e.localTransfer&&e.status!=='returning').flatMap(e=>[...e.bits,...(e.yieldedBits??[])]));
    // (12.0.0-beta.4) Her wings close at the end of her descent (and a landing style recalls them later still), but
    // her bits used to be recalled the moment she began to land: gone 2 to 3 s before her wings. Now they stay out
    // with her wings through the descent and are recalled as the wings close. The recall is the same one, begun
    // `hold` ms later: it waits in a flag, so any owner's browser finishes it if this one goes away.
    const animated=cfg.bitTransitions&&cfg.transitions&&!cfg.reduced&&!!globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id;
    if(hold>=120&&transitionId&&animated&&allocationPresence(record,events,doc.id).outBits.some(id=>!working.has(id))){
      delete flightChanges[deleteKey(`flags.${ID}`,LAND_FLAG)[0]];
      await doc.update({...flightChanges,[`flags.${ID}.${LAND_FLAG}`]:{id:transitionId,at:Math.round(now+hold),duration:Math.round(Math.max(200,duration)),owner:globalThis.game?.user?.id??null}});
      this.maintenanceCache?.delete(doc);
      this.kickLanding(doc,hold+4);
      return this.getState(doc);
    }
    return this.retractAllNow(doc,record,events,now,{
      bits:BIT_IDS.filter(id=>!working.has(id)),
      duration:cfg.bitTransitions&&cfg.transitions&&!cfg.reduced?duration:0,
      animate:!!globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id,
      manualLightIntent:true,
      extraChanges:{...flightChanges,...(working.size?{[`flags.${ID}.${REST_FLAG}`]:{at:Math.round(now)}}:{[`flags.${ID}.flight.bitsDeployed`]:false})}
    });
  }
  /** (12.0.0-beta.14) Wake the recall a landing left waiting, and keep at it until it has been made or dropped. One timer
   * used to do this, once: if a maintenance pass was still running at that moment, or the server clock read a few
   * milliseconds short of the recall's time, nothing recalled her bits until some later pass happened by (her real game,
   * beta.13 report: Power down's bits stayed 1 s after her wings, the flag still on her token). Now it tries again:
   * after the time that is left, or shortly if a pass is running, for up to 3 s past the recall's time. */
  kickLanding(doc,wait=0,tries=0){
    setTimeout(()=>{
      if(this.stopped)return;let land=null;try{land=doc.getFlag?.(ID,LAND_FLAG);}catch{}
      if(!land||!finite(land.at)||doc.parent?.tokens?.get(doc.id)!==doc)return;
      const left=land.at-LAND_EARLY-this.now();
      if(left>0)return this.kickLanding(doc,Math.min(left+2,2000),tries);
      if(tries>=60)return;
      this.maintenanceCache?.delete(doc);
      if(!this.pending.has(doc.uuid))void this.maintain(doc);
      this.kickLanding(doc,50,tries+1);
    },Math.max(0,wait));
  }
  /** (12.0.0-beta.4) The recall a landing left waiting for her wings (see landBitsNow). Called from maintain(), inside
   * the token's queue. Returns true when it wrote (the caller starts over on the next pass).
   * Whoever landed her recalls them; another owner does only if that browser has gone or is 1.5 s late. A landing
   * that is no longer the current one (she took off again, her wings were opened) drops the recall. */
  async finishLanding(doc,land,now,candidates=[]){
    const flight=doc.getFlag?.(ID,'flight'),drop=()=>doc.update(forceDelete({},`flags.${ID}`,LAND_FLAG)).then(()=>true);
    if(!land||!finite(land.at)||!flight||flight.mode!=='grounded'||flight.enabled!==false||flight.transition?.id!==land.id)return drop();
    if(now<land.at-LAND_EARLY)return false;   // (beta.14: a few ms early is the same moment; the clocks of a timer and of the server differ by that much)
    const owner=land.owner===game.user.id?game.user:game.users?.get(land.owner);
    if(land.owner!==game.user.id&&!((!owner?.active||now>land.at+1500)&&(candidates[0]?.id??game.user.id)===game.user.id))return false;
    try{
      const record=this.allocation(doc),events=this.records(doc).filter(e=>e.expires>now&&!isFinished(e,now)),cfg=runtimeConfiguration();
      const working=new Set(events.filter(e=>e.kind!=='escort'&&!e.localTransfer&&e.status!=='returning').flatMap(e=>[...e.bits,...(e.yieldedBits??[])]));
      const left=land.at+(land.duration??650)-now;
      await this.retractAllNow(doc,record,events,now,{
        bits:BIT_IDS.filter(id=>!working.has(id)),
        duration:cfg.bitTransitions&&cfg.transitions&&!cfg.reduced&&left>60?Math.max(200,left):0,
        animate:!!globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id,
        manualLightIntent:true,
        extraChanges:{...forceDelete({},`flags.${ID}`,LAND_FLAG),...(working.size?{[`flags.${ID}.${REST_FLAG}`]:{at:Math.round(now)}}:{[`flags.${ID}.flight.bitsDeployed`]:false})}
      });
      return true;
    }catch(error){this.manager.report?.(error);return drop();}
  }
  /** (12.1.0-beta.1) She landed while some of her bits were at work (holding a decoy, a parked light, a scan): those
   * finish first. When the last of them is free and she is still down with her wings away, they go in too, as on every
   * other landing; they used to come back and hover round her on the ground. Dropped without doing anything if she has
   * taken off again or her bits were sent out or put away by hand since. Called from maintain(), inside the token's queue. */
  async finishLandingRest(doc,rest,now){
    const drop=async()=>{try{await doc.update(forceDelete({},`flags.${ID}`,REST_FLAG));}catch{}return false;};
    try{
      const flight=doc.getFlag(ID,'flight');
      if(!rest||!finite(rest.at)||!flight||flight.enabled||flight.airborne||!flight.bitsDeployed||(flight.bitTransition?.started??0)>rest.at+50)return drop();
      const events=this.records(doc).filter(e=>e.expires>now&&!isFinished(e,now));
      if(events.some(e=>e.kind!=='escort'&&!e.localTransfer))return false;   // still at work (or on its way back): wait
      const record=this.allocation(doc),cfg=runtimeConfiguration();
      await this.retractAllNow(doc,record,events,now,{bits:[...BIT_IDS],duration:cfg.bitTransitions&&cfg.transitions&&!cfg.reduced?650:0,
        animate:!!globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id,manualLightIntent:true,
        extraChanges:{...forceDelete({},`flags.${ID}`,REST_FLAG),[`flags.${ID}.flight.bitsDeployed`]:false}});
      return true;
    }catch(error){this.manager.report?.(error);return drop();}
  }
  gather(source){
    const doc=this.document(source);return this.commandQueue(doc,'gathering instruments',()=>{
      this.document(doc);this.assertPowered(doc);const now=this.now(),events=this.records(doc).filter(e=>!isFinished(e,now)),record=this.allocation(doc);
      const {remoteBits}=allocationPresence(record,events,doc.id);
      if(!remoteBits.length)return this.getState(doc);
      return this.relocate(doc,remoteBits,'home',record,events,now);
    });
  }
  setDeployment(source,input={}){
    const doc=this.document(source);
    if(input.enabled!==undefined&&typeof input.enabled!=='boolean')throw new Error('Enabled must be true or false.');
    return this.commandQueue(doc,'deployment change',()=>this.deploymentNow(doc,{...input,manualLightIntent:true}));
  }
  /** Takeoff or deliberate wing opening may fill vacant home slots, but is not a recall command. Keep
   * remote groups and action reservations intact, and write wings + destinations
   * together so observers never receive an intermediate wings-only state. */
  async deployForTakeoff(doc,flightChanges,{data,snapshot,cfg,now,duration}){
    const response=snapshot.conditionResponse;
    if(cfg.controlGems===false||cfg.wingRenderer==='atlas'||data.gemMotion.enabled===false||data.gemMotion.style==='hidden'||
      response?.bits&&['falling','fallen'].includes(response.collapse?.phase)||
      !globalThis.canvas?.ready||doc.parent?.id!==canvas.scene?.id)return doc.update(flightChanges);
    let record=this.allocation(doc,snapshot);
    const events=this.records(doc).filter(e=>e.expires>now&&!isFinished(e,now));
    // Another active owner keeps control of their action stream. Taking off
    // must still work without trying to acquire or cancel those instruments.
    if(events.some(e=>e.owner!==game.user.id&&game.users?.get(e.owner)?.active))return doc.update(flightChanges);
    const reserved=new Set(events.filter(e=>!e.localTransfer).flatMap(e=>e.bits));
    const home=BIT_IDS.filter(b=>record.bits[b].location==='home');
    const bits=BIT_IDS.filter(b=>record.bits[b].location==='retracted'&&!reserved.has(b))
      .slice(0,Math.max(0,record.preferredCount-home.length));
    if(!bits.length)return doc.update(flightChanges);
    flightChanges={...flightChanges,...this.service.ordinaryBitSummonLightChanges?.(doc,now)};
    const captured=this.captureWorld(doc,bits,events,now);
    this.prepareSummonFormation(doc,record,bits,now,events);
    // Only an in-progress local recall can be redirected here. Its currently
    // displayed positions become the new origins, including partial recalls.
    const detached=this.detach(doc,events,bits,now,{preserveOthers:true});
    record=setDestinations(record,bits,'home');
    detached.events.push(this.localTransfer(doc,bits,record,now,captured,
      cfg.bitTransitions&&cfg.transitions&&!cfg.reduced?duration:0));
    return this.write(doc,detached.events,detached.cancelled,record,flightChanges);
  }
  async deploymentNow(doc,input={}, {extraChanges={}}={}){
    this.document(doc);this.assertPowered(doc);const now=this.now();let record=this.allocation(doc),events=this.records(doc).filter(e=>!isFinished(e,now));this.controller(events);
    const count=input.count??record.preferredCount;if(!Number.isInteger(count)||count<1||count>4)throw new Error('Choose one to four instruments.');
    const anyHome=BIT_IDS.some(b=>record.bits[b].location==='home'),enabled=input.enabled??anyHome;
    const selected=input.bits?stationList(input.bits):null,desired=deploymentSelection(record,enabled?count:0);
    const changes=selected?selected.map(id=>[id,enabled?'home':'retracted']):[...desired.home.map(id=>[id,'home']),...desired.retracted.map(id=>[id,'retracted'])];
    const retracting=changes.filter(([id,location])=>location==='retracted'&&record.bits[id].location==='home').map(([id])=>id);
    const summoning=changes.some(([id,location])=>location==='home'&&record.bits[id].location!=='home'),
      lightChanges=input.manualLightIntent?(summoning?this.service.ordinaryBitSummonLightChanges?.(doc,now)??{}:
        this.manualLightChanges(doc,record,events,retracting,now,{force:input.enabled===false&&!selected})):{};
    const bits=changes.filter(([id,location])=>record.bits[id].location!==location).map(([id])=>id),captured=bits.length?this.captureWorld(doc,bits,events,now):null;
    if(input.enabled===true)this.prepareSummonFormation(doc,record,changes.filter(([,location])=>location==='home').map(([id])=>id),now,events);
    const detached=bits.length?this.detach(doc,events,bits,now):{events,cancelled:[]};events=detached.events;
    for(const location of ['home','retracted']){const ids=changes.filter(([id,l])=>l===location&&bits.includes(id)).map(([id])=>id);if(ids.length)record=setDestinations(record,ids,location);}
    record.preferredCount=count;
    if(bits.length)events.push(this.localTransfer(doc,bits,record,now,captured,input.duration??650));
    events=this.reconcile(doc,events,record,now);await this.write(doc,events,detached.cancelled,record,{...extraChanges,...lightChanges});return this.getState(doc);
  }
  /** A public count edit owns one saved update for preference, sampled flight
   * transition and destinations. The live deployment path performs its normal
   * power/controller/route checks before that update; off-scene edits retain
   * their saved-state-only authority and create no local action. */
  async commitFlightCount(doc,patch,changes,{manualLightIntent=true}={}){
    const motion=patch.gemMotion??{};
    if(!Object.hasOwn(motion,'count')||!doc.getFlag(ID,ALLOCATION_FLAG)&&!Object.hasOwn(changes,ALLOCATION_PATH))return false;
    const record=this.allocation(doc),count=Number.isInteger(motion.count)?motion.count:record.preferredCount,
      enabled=motion.enabled===false||motion.style==='hidden'?false:patch.bitsDeployed??motion.enabled;
    // The prepared destination record below owns this field. Retaining an
    // earlier implicit-record object would overwrite its new destinations.
    changes={...changes};delete changes[ALLOCATION_PATH];
    if(globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id)
      await this.deploymentNow(doc,{count,...(typeof enabled==='boolean'?{enabled}:{}),manualLightIntent:manualLightIntent&&enabled===false},{extraChanges:changes});
    else{
      const anyHome=BIT_IDS.some(id=>record.bits[id].location==='home'),desired=deploymentSelection(record,(enabled??anyHome)?count:0);
      let next=record;for(const location of ['home','retracted'])if(desired[location].length)next=setDestinations(next,desired[location],location);
      next.preferredCount=count;await doc.update({...allocationChanges(doc.getFlag(ID,ALLOCATION_FLAG),next),...changes});this.observe(doc);
    }
    return true;
  }
  setGroup(source,group,input={}){
    const doc=this.document(source),patch=validateGroupPatch(input);let key=group?.document?.id??group?.id??group;
    if(key!=='home')key=this.target(doc,key).id;
    if(patch.effect?.id&&!TOKEN_EFFECT_IDS.includes(patch.effect.id))throw new Error('Choose an effect from bits.getEffects().');
    return this.commandQueue(doc,'formation change',()=>this.setGroupNow(doc,key,patch));
  }
  async setGroupNow(doc,key,patch){
      this.document(doc);const now=this.now(),record=this.allocation(doc),events=this.records(doc);this.controller(events);
      const previous=record.groups[key]??defaultGroup(this.state(doc,true));
      record.groups[key]={...previous,...patch,behaviour:{...previous.behaviour,...patch.behaviour},flow:{...previous.flow,...patch.flow},effect:{...previous.effect,...patch.effect}};
      if(patch.flow||patch.program)record.groups[key].flow.epoch=now;
      if(patch.program&&!patch.flow)record.groups[key].flow.enabled=false;
      if(patch.personality!==undefined&&!patch.behaviour?.frequency)record.groups[key].behaviour.frequency=patch.personality<.2?'composed':patch.personality>.7?'expressive':'attentive';
      if(record.groups[key].effect.enabled&&(!previous.effect?.enabled||record.groups[key].effect.id!==previous.effect?.id))record.groups[key].effect.started=now;
      if(['program','radius','personality','passive','behaviour','flow'].some(k=>patch[k]!==undefined&&patch[k]!==previous[k])){
        const stations=BIT_IDS.filter(b=>record.bits[b].location===key&&!events.some(e=>e.status!=='queued'&&e.kind!=='escort'&&e.bits.includes(b)));
        const cfg=runtimeConfiguration();
        record.groups[key].transition=this.formationTransition(doc,previous,stations,now,cfg.reduced||cfg.bitTransitions===false||cfg.transitions===false?0:850,key);
        if(!patch.flow&&!patch.program)record.groups[key]=rebaseFormationFlow(record.groups[key],now,this.state(doc,true).gems.animated!==false);
      }
      if(key!=='home'&&record.groups[key].transition?.started===now)for(const event of events)if(event.kind==='escort'&&event.target===key&&event.status==='running')event.travelDuration=0;
      record.revision++;const next=this.reconcile(doc,events,record,now);
      const names={program:'soloProgram',radius:'soloRadius',personality:'personality',internalState:'coreState',passive:'passiveEffects'};
      const flightChanges=key==='home'?Object.fromEntries(Object.entries(patch).filter(([k])=>names[k]).map(([k,v])=>[`flags.${ID}.flight.gemMotion.${names[k]}`,v])):{};
      await this.write(doc,next,[],record,flightChanges);return this.getState(doc);
  }
  prepareSummonFormation(doc,record,bits,now,events=[]){
    if(!record.randomOnSummon||!bits.some(id=>record.bits[id]?.location==='retracted'&&!events.some(event=>event.status!=='queued'&&!event.localTransfer&&event.bits.includes(id))))return;
    const previous=record.groups.home,snapshot=this.state(doc,true);
    const program=chooseSummonFormation(previous,now,summonFormationOptions(snapshot));
    const stations=formationStations(record,this.records(doc,false)),cfg=runtimeConfiguration();
    record.groups.home={...previous,program,flow:{...previous.flow,epoch:now},
      transition:this.formationTransition(doc,previous,stations,now,cfg.reduced||cfg.bitTransitions===false||cfg.transitions===false?0:650)};
  }
  setSummonFormation(source,input={}){
    const doc=this.document(source);
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>key!=='random')||typeof input.random!=='boolean')throw new Error('Random summon formation must be true or false.');
    return this.commandQueue(doc,'summon formation change',async()=>{
      this.document(doc);const record=this.allocation(doc),events=this.records(doc);this.controller(events);
      record.randomOnSummon=input.random;record.revision++;
      await this.write(doc,events,[],record);return this.getState(doc);
    });
  }
  toggleSummonFormation(source,mode='random'){
    const doc=this.document(source);if(!['random','flow'].includes(mode))throw new Error('Choose random or flow formation mode.');
    return this.commandQueue(doc,'summon formation change',async()=>{
      this.document(doc);const record=this.allocation(doc);
      if(mode==='flow')return this.setGroupNow(doc,'home',validateGroupPatch({flow:toggleSummonFlow(record.groups.home,summonFormationOptions(this.state(doc,true)))}));
      const events=this.records(doc);this.controller(events);record.randomOnSummon=!record.randomOnSummon;record.revision++;
      await this.write(doc,events,[],record);return this.getState(doc);
    });
  }
  setEffect(source,group,input={}){return this.setGroup(source,group,{effect:input});}
  async start(source,target,kind,sequence,input={}){
    const doc=this.document(source),opts=animationOptions({...input,bits:input.bits==='pair'?2:input.bits}),patient=target?this.target(doc,target):null;
    if(kind==='treatment'&&!patient)throw new Error('Treatment needs a target token.');
    return this.service.enqueue(doc,async()=>{
      this.document(doc);const now=this.now(),record=this.allocation(doc);let events=this.records(doc).filter(e=>e.expires>now&&!isFinished(e,now));
      const sourceState=this.state(doc,true),conditionResponse=sourceState.conditionResponse;
      if(conditionResponse?.bits&&['falling','fallen'].includes(conditionResponse.collapse?.phase))throw new Error('Ellie’s bits are unpowered while she is unconscious.');
      if(events.length>=12)throw new Error('Twelve bit animations are already queued; return the bits or wait.');this.controller(events);
      const byCount=!Array.isArray(input.bits),bits=byCount?chooseAvailable(record,opts.bits.length,{events,target:patient?.id,treatment:kind==='treatment',sourceId:doc.id}):opts.bits;
      if(sequence?.tracks.some(t=>t.bits?.some(b=>!bits.includes(b))))throw new Error('Every station named by a sequence step must also be reserved in options.bits.');
      const blocked=events.filter(e=>e.kind!=='escort'&&e.status!=='queued'&&overlaps(e.bits,bits));
      if(blocked.length&&opts.conflict==='reject')throw new Error('The requested bits are busy.');
      if(blocked.some(e=>e.priority>opts.priority)&&opts.conflict==='replace')throw new Error('A higher-priority animation owns those bits.');
      const enhancedTreatment=kind==='treatment'&&sourceState.v7?.enabled&&sourceState.v7?.medkit&&input.enhanced!==false;
      const captured=this.captureWorld(doc,bits,events,now,{behaviour:!!sequence?.gesture||enhancedTreatment,velocity:!!sequence?.gesture||enhancedTreatment,velocityDelta:enhancedTreatment?.25:8,coreVelocity:enhancedTreatment}),cancelled=[];
      // Dedicated decorative directions yield to Medicine, like escorts.
      // Custom macro sequences retain their explicit queue/replace contract.
      const canYield=kind==='treatment'&&blocked.length&&blocked.every(e=>(e.kind==='utility'||e.sequence?.gesture)&&e.priority<opts.priority)&&opts.conflict!=='reject';
      const yieldUtility=canYield&&blocked.some(e=>e.kind==='utility');
      if(yieldUtility)events=this.yieldUtilities(events,bits);
      const yieldGesture=canYield&&blocked.some(e=>e.sequence?.gesture);
      // Low-priority escort reservations yield only the borrowed identities.
      // Other groups and unused members remain exactly where they were sent.
      if(!blocked.length||opts.conflict==='replace'||yieldGesture){
        const detached=this.detach(doc,events,bits,now,{cancelActions:opts.conflict==='replace'||!!yieldGesture,preserveUtilities:!!yieldUtility});events=detached.events;cancelled.push(...detached.cancelled);
      }
      const event={id:id(),name:kind==='treatment'?'Treatment':sequence.name,kind,sequence:sequence??null,owner:game.user.id,session:this.session,
        created:now,expires:now+opts.timeout,started:now,status:'queued',target:patient?.id??null,bits,priority:opts.priority,travelDuration:opts.travelDuration,
        returnDuration:opts.returnDuration,...captured,...(kind==='treatment'?{treatment:treatmentOptions({...input,enhanced:!!enhancedTreatment})}:{})};
      if(sequence?.gesture){Object.assign(event,this.captureGesture(doc,event,events,now,captured));delete event.originVelocities;}
      events=scheduleActions([...events,event],now);const handle=this.createHandle(doc,event);
      try{await this.write(doc,events,cancelled,record,kind==='treatment'?this.service.v7WingBridgeChanges?.(normalizeFlag(doc.getFlag(ID,'flight'),now),sourceState,now,'softShelter')??{}:{});return handle;}catch(error){this.settle(event,'error',error.message);throw error;}
    });
  }
  gesture(source,name,options={}){
    if(!Object.hasOwn(BIT_GESTURES,name))throw new Error(`Choose ${Object.values(BIT_GESTURES).map(g=>g.label).join(', ')}.`);
    const doc=this.document(source),record=this.allocation(doc),requested=options.group??'home',key=requested==='home'?'home':this.target(doc,requested).id,group=record.groups[key]??defaultGroup(this.state(doc,true));
    const events=this.records(doc,false),assigned=BIT_IDS.filter(b=>record.bits[b].location===key),present=assigned.filter(b=>!events.some(e=>e.kind!=='escort'&&e.status!=='queued'&&e.bits.includes(b)));
    if(assigned.length&&!present.length&&!Array.isArray(options.bits))throw new Error('This group is working; wait for its current action or cancel it.');
    if(Number.isInteger(options.bits)&&present.length&&options.bits>present.length)throw new Error(`Only ${present.length} free instruments are in this group.`);
    const bits=Array.isArray(options.bits)?options.bits:present.length?present.slice(0,options.bits??present.length):chooseAvailable(record,options.bits??record.preferredCount,{events});
    const definition=BIT_GESTURES[name],sequence=compileSequence({name:definition.label,steps:[{type:'gesture',gesture:name,duration:options.duration??definition.duration,energy:options.energy??group.behaviour?.energy??.65}]});
    sequence.gesture=name;sequence.audio=options.audio??group.behaviour?.audio??false;
    if(typeof sequence.audio!=='boolean')throw new Error('Gesture audio must be true or false.');
    return this.start(doc,options.target??(key==='home'?doc:key),'sequence',sequence,{...options,bits,priority:options.priority??35,conflict:options.conflict??'queue',returnDuration:options.returnDuration??1000});
  }
  treat(source,target,options={}){return this.start(source,target,'treatment',null,{priority:100,...options,bits:options.bits??2});}
  play(source,definition,options={}){
    let sequence=typeof definition==='string'?this.definitions.get(definition):compileSequence(definition);
    if(!sequence)throw new Error(`Unknown registered bit animation: ${definition}.`);
    if(sequence.duration>=(options.timeout??120000))options={...options,timeout:Math.min(600000,sequence.duration+10000)};
    return this.start(source,options.target,'sequence',clone(sequence),options);
  }
  formationTransition(doc,group,stations,now,duration=650,target='home'){
    const transition={fromProgram:group.program,started:now,duration};
    if(!stations.length)return transition;
    const snapshot=this.state(doc,true),cfg=snapshot.gems;
    let wingFromPoses;
    if(target==='home'&&!snapshot.compactBits){
      const hardware=actionHardware(snapshot,now,{destination:true});
      wingFromPoses=stations.flatMap(station=>{const p=hardware[station]?.points?.[0],h=hardware[station]?.hardware;return p?[{station,x:p[0],y:p[1],z:p[2],angle:h?.angle??0,scale:h?.scale??1,brightness:1}]:[];});
    }
    let poses=sampleGroupFormation(stations,group,cfg,now,snapshot,{lanternHome:target==='home'});
    const later=sampleGroupFormation(stations,group,cfg,now+8,snapshot,{lanternHome:target==='home'}),fromVelocities=poses.map(p=>{const q=later.find(q=>q.station===p.station)??p;return {station:p.station,...Object.fromEntries(['x','y','z','angle','scale','brightness'].map(k=>[k,k==='angle'?Math.atan2(Math.sin(q[k]-p[k]),Math.cos(q[k]-p[k]))/.008:(q[k]-p[k])/.008]))};});
    // A slider or library choice can interrupt an in-flight dispatch. Capture
    // what is displayed rather than restarting at the old ideal station.
    if(target!=='home'){
      const patient=globalThis.canvas?.tokens?.get(target),events=this.records(doc,false),event=events.find(e=>e.kind==='escort'&&e.target===target&&e.status==='running');
      if(patient?.mesh&&event&&now<event.started+event.travelDuration){
        const capture=this.captureWorld(doc,stations,events,now),pose=tokenVisualPose(patient,this.manager),c=Math.cos(pose.angle),sin=Math.sin(pose.angle),scale=Math.max(patient.w,patient.h)*3.5/600;
        poses=poses.map(p=>{const world=capture.originsWorld[p.station];if(!world)return p;const x=world.x-pose.x,y=world.y-pose.y;
          return {...p,x:(x*c+y*sin)/scale,y:(-x*sin+y*c)/scale+15,z:capture.originDepths[p.station]??p.z};});
      }
    }
    return {...transition,fromVelocities,...(wingFromPoses?{wingFromPoses}:{}),fromCount:stations.length,fromStations:[...stations],fromPoses:poses.map(captureBehaviourPose)};
  }
  async write(doc,events,cancelled=[],allocations=null,extraChanges={}){
    // Preflight against the proposed destination record, not the still-saved
    // home record. This also gives previews and confirmed commands identical
    // paths while a changed door can refuse confirmation safely.
    if(this.routesEnabled(doc)){
      const now=this.now(),previous=new Map(this.records(doc,false).map(event=>[event.id,event]));
      for(const event of events){
        const old=previous.get(event.id),fresh=event.status==='running'&&event.kind!=='treatment'&&(!old||event.started!==old.started),returning=this.commandScopes?.has(doc)&&event.status==='returning'&&(!old||old.status!=='returning'||event.returnAt!==old.returnAt);
        if(!fresh&&!returning)continue;
        const oldState=this.state(doc,true),snapshot=allocations?{...oldState,bitAllocationState:allocations,bitReservationEvents:events}:oldState;
        const original=this.state;this.state=()=>snapshot;
        try{this.planEventRoutes(doc,event,now);}finally{this.state=original;}
      }
    }
    {
      const old=this.allocation(doc),previousEvents=this.records(doc,false),now=this.now();
      const before=formationStations(old,previousEvents),after=formationStations(allocations??old,events);
      if(before.join('|')!==after.join('|')){
        allocations??=clone(old);
        const returns=events.filter(e=>e.status==='returning'&&e.bits.some(b=>after.includes(b)&&!before.includes(b)));
        const duration=returns.length?Math.max(1,...returns.map(e=>Math.min(10000,e.returnAt+e.returnDuration-now))):650;
        allocations.groups.home.transition=this.formationTransition(doc,old.groups.home,before,now,duration);
        // Re-anchor Flow under this blend so no client solves a long slot
        // schedule for the new station set inside a render frame.
        allocations.groups.home=rebaseFormationFlow(allocations.groups.home,now,this.state(doc,true).gems.animated!==false);
      }
      // Destination membership begins when returns launch, not when maintenance
      // eventually removes them. Remaining instruments slide into the enlarged
      // layout while their partners are still travelling.
      for(const event of events){
        if(event.kind!=='escort'||event.status!=='running'||event.localTransfer)continue;
        const record=allocations??old,previous=previousEvents.find(e=>e.id===event.id);
        const beforeRemote=formationStations(old,previousEvents,event.target),afterRemote=formationStations(record,events,event.target);
        event.formationBits=afterRemote;
        if(previous&&record.groups[event.target]&&beforeRemote.join('|')!==afterRemote.join('|')){
          allocations??=clone(old);
          const returns=events.filter(e=>e.status==='returning'&&e.bits.some(b=>afterRemote.includes(b)&&!beforeRemote.includes(b)));
          const duration=returns.length?Math.max(1,...returns.map(e=>Math.min(10000,e.returnAt+e.returnDuration-now))):650;
          const group=allocations.groups[event.target];
          group.transition=this.formationTransition(doc,previous.group??old.groups[event.target],beforeRemote,now,duration,event.target);
          Object.assign(group,rebaseFormationFlow(group,now,this.state(doc,true).gems.animated!==false));
          event.group=clone(group);event.travelDuration=0;
        }
      }
      if(allocations){
        const occupied=new Set(['home',...Object.values(allocations.bits).map(b=>b.location).filter(l=>l!=='retracted')]);
        allocations.groups=Object.fromEntries(Object.entries(allocations.groups).filter(([key])=>occupied.has(key)));
      }
    }
    await doc.update({[PATH]:{version:1,events},...(allocations?allocationChanges(doc.getFlag(ID,ALLOCATION_FLAG),allocations):{}),...extraChanges});
    for(const {event,reason}of cancelled)this.settle(event,'cancelled',reason);
    // The updateToken hook normally observed this exact flag object already
    // (and announced it). Observe again only when that did not happen.
    if(this.recordCache.get(doc)?.raw!==doc.getFlag?.(ID,FLAG))this.observe(doc);
    this.prewarmFormations(doc,events);return events;
  }
  /** Prepare the destination's exact Flow ordering at command edges, including
   * medical borrowing and returning. Render frames still own the live poses. */
  prewarmFormations(doc,events){
    const now=this.now(),snapshot=this.state(doc,true),cfg=snapshot.gems,record=this.allocation(doc,snapshot,false);
    for(const group of allocationGroups(record)){
      const stations=formationStations(record,events,group.id);if(!stations.length)continue;
      prewarmCompactFlow(stations.length,group.program??cfg.soloProgram,now/1000*(cfg.speed??1),{
        stations,flow:group.flow,now,flowClockRate:cfg.animated===false?0:cfg.speed??1,
        radius:group.radius??cfg.soloRadius,strength:cfg.strength,animated:cfg.animated,v7:cfg.v7??snapshot.v7,
        personality:group.effect?.enabled?0:group.personality??cfg.personality,
        passiveEffects:group.effect?.enabled?false:group.passive!==false,
        behaviour:group.effect?.enabled?{enabled:false}:group.behaviour??cfg.behaviour});
    }
  }
  beginReturn(doc,event,now,reason=null){
    if(event.status==='queued'){event.status='finished';event.reason=reason??'cancelled';this.settle(event,'cancelled',event.reason);return;}
    if(event.status==='returning')return;
    const token=doc.object,snapshot=this.state(doc);
    try{
      const renderer=this.renderers.get(token),deleted=event.target?this.deletedTargets?.get(event.target):null,lost=reason==='target-deleted'&&!deleted||event.kind==='utility'&&event.target&&!scanTokenVisible(globalThis.canvas?.tokens?.get(event.target),{scene:doc.parent}),target=lost?null:event.target?globalThis.canvas?.tokens?.get(event.target)??deleted:null;
      const known=lost?(renderer?.lastPositions?.get(event.id)??event.originsWorld??{}):null;
      const sample=lost?{positions:Object.fromEntries(event.bits.map(bit=>[bit,{...(known[bit]??{x:Number(doc.x)+token.w/2,y:Number(doc.y)+token.h/2})}])),rotations:event.originRotations??{},depths:event.originDepths??{},tools:{},glows:{}}:renderer&&!deleted?renderer.sample(event,snapshot,this.manager,now).sample:sampleSequence(event,now,actionContext(token,target,snapshot,event,this.manager,actionHardware(snapshot,now),now));
      const release=reason==='target-deleted'?undefined:captureTreatmentRelease(sample);if(release)event.returnTreatment=release;else delete event.returnTreatment;
      event.returnFrom=reason==='target-deleted'&&!deleted&&renderer?.lastPositions?.has(event.id)?clone(renderer.lastPositions.get(event.id)):sample.positions;
      event.returnFrom=Object.fromEntries(Object.entries(event.returnFrom??{}).filter(([station,p])=>event.bits.includes(station)&&p&&finite(p.x)&&finite(p.y)));
      event.returnDepths=Object.fromEntries(Object.entries(sample.depths??{}).filter(([station,v])=>event.bits.includes(station)&&finite(v)));
      event.returnRotations=Object.fromEntries(Object.entries(sample.rotations??{}).filter(([station,v])=>event.bits.includes(station)&&finite(v)));
      event.returnTools=Object.fromEntries(Object.entries(sample.tools??{}).filter(([station,t])=>event.bits.includes(station)&&t&&finite(t.amount)&&t.amount>=0&&t.amount<=1));
      if(event.kind==='treatment'&&snapshot.v7?.enabled!==false&&snapshot.v7?.medkit===true&&event.treatment?.enhanced!==false)
        event.returnCoreStates=Object.fromEntries(event.bits.flatMap(station=>{const activity=captureCoreActivity(sample.coreStates?.[station]);return activity?[[station,activity]]:[];}));
      else {delete event.returnCoreStates;delete event.returnCoreVelocities;}
      event.returnGlows=Object.fromEntries(Object.entries(sample.glows??{}).filter(([station,g])=>event.bits.includes(station)&&g&&finite(g.strength)).map(([station,g])=>[station,{...g,strength:Math.max(0,Math.min(4,g.strength))}]));
      if(!lost&&(event.sequence?.gesture||event.kind==='utility')){
        const delta=8,nextSnapshot=actionSnapshotAt(snapshot,now,delta),nextHardware=actionHardware(nextSnapshot,now+delta),next=renderer&&!deleted?renderer.sample(event,nextSnapshot,this.manager,now+delta,nextHardware,{readOnly:true}).sample:sampleSequence(event,now+delta,actionContext(token,target,nextSnapshot,event,this.manager,nextHardware,now+delta));
        event.returnVelocities=Object.fromEntries(event.bits.flatMap(station=>{const a=sample.positions[station],b=next.positions[station];if(!a||!b)return [];const velocity={x:(b.x-a.x)*1000/delta,y:(b.y-a.y)*1000/delta};return validVelocity(velocity)?[[station,velocity]]:[];}));
      }else if(!lost&&event.kind==='treatment'&&snapshot.v7?.enabled!==false&&snapshot.v7?.medkit===true&&event.treatment?.enhanced!==false){
        // Momentum is optional: a failed look-ahead must never discard the
        // displayed stations or medical field already captured above.
        try{
          const delta=.25,nextSnapshot=actionSnapshotAt(snapshot,now,delta),next=renderer&&!deleted?renderer.sample(event,nextSnapshot,this.manager,now+delta,null,{readOnly:true}).sample:sampleSequence(event,now+delta,actionContext(token,target,nextSnapshot,event,this.manager,actionHardware(nextSnapshot,now+delta),now+delta));
          event.returnVelocities=Object.fromEntries(event.bits.flatMap(station=>{const a=sample.positions[station],b=next.positions[station];if(!a||!b)return [];const velocity={x:(b.x-a.x)*1000/delta,y:(b.y-a.y)*1000/delta};return validVelocity(velocity)?[[station,velocity]]:[];}));
          event.returnCoreVelocities=Object.fromEntries(event.bits.flatMap(station=>sample.coreStates?.[station]&&next.coreStates?.[station]?[[station,treatmentCoreVelocity(sample.coreStates[station],next.coreStates[station],delta/1000)]]:[]));
        }catch{delete event.returnVelocities;delete event.returnCoreVelocities;}
      }
    }catch{event.returnFrom={};delete event.returnTreatment;}
    delete event.taskPausedAt;delete event.taskPausedPose;
    event.status='returning';event.returnAt=now;event.reason=reason;event.expires=now+event.returnDuration+1000;
    // A suspended browser can resume after the entire original action bound.
    // Keep its captured return valid instead of letting the flag reader drop
    // it immediately. Returning events no longer need their FIFO timestamp;
    // the original started clock and displayed poses remain unchanged.
    event.created=Math.max(event.created,event.expires-620000);
  }
  finish(source,animationId,result={}){
    const degree=['criticalFailure','failure','success','criticalSuccess'];
    const doc=this.document(source),outcome=typeof result==='number'?degree[result]:typeof result==='string'?result:result?.outcome??'success';if(!OUTCOMES.includes(outcome))return Promise.reject(new Error('Unknown treatment outcome.'));
    const handle=this.handles.get(animationId),done=handle?.done;
    const operation=this.service.enqueue(doc,async()=>{
      this.document(doc);const now=this.now(),events=this.records(doc),event=events.find(e=>e.id===animationId);
      if(!event)return {status:'completed',outcome};
      if(event.status==='returning')return;
      if(event.status==='queued')event.requestedOutcome=outcome;
      else if(event.kind==='treatment'){event.outcome=outcome;event.finishAt=treatmentFinishTime(event,now);protectTreatmentResultLifetime(event);}
      else this.beginReturn(doc,event,now);
      await this.write(doc,events);
    });
    return operation.then(()=>done??{status:'completed',outcome});
  }
  cancel(source,animationId,reason='cancelled'){
    const doc=this.document(source),done=this.handles.get(animationId)?.done;
    const operation=this.service.enqueue(doc,async()=>{
      this.document(doc);const now=this.now(),events=this.records(doc),event=events.find(e=>e.id===animationId);if(!event)return;
      this.beginReturn(doc,event,now,String(reason??'cancelled').slice(0,100));await this.write(doc,events.filter(e=>e.status!=='finished'));
    });
    return operation.then(()=>done??{status:'cancelled',reason});
  }
  returnAll(source){
    const doc=this.document(source);return this.commandQueue(doc,'returning all instruments',async()=>{
      this.document(doc);this.assertPowered(doc);const now=this.now(),events=this.records(doc);let record=this.allocation(doc);
      const remote=BIT_IDS.filter(b=>!['home','retracted'].includes(record.bits[b].location));if(remote.length)record=setDestinations(record,remote,'home');
      for(const group of Object.values(record.groups))if(group.effect)group.effect.enabled=false;
      for(const event of events){this.beginReturn(doc,event,now,'recalled');event.owner=game.user.id;event.session=this.session;}
      await this.write(doc,events.filter(e=>e.status!=='finished'),[],record);return {returning:events.filter(e=>e.status==='returning').length};
    });
  }
  observe(doc){
    this.recordCache.delete(doc);this.invalidateState(doc);this.allocationCache?.delete(doc);
    if(doc.parent?.id!==globalThis.canvas?.scene?.id)return;
    for(const [token,renderer] of this.renderers)if(token.destroyed||token.document===doc&&token!==doc.object){renderer.destroy();this.renderers.delete(token);}
    const events=this.records(doc,false),byId=new Map(events.map(e=>[e.id,e]));
    for(const h of [...this.handles.values()])if(h.doc===doc){
      const event=byId.get(h.event.id);if(event)h.event=event;
      else this.settle(h.event,h.event.reason?'cancelled':'completed',h.event.reason);
    }
    const token=doc.object;
    if((events.length||this.homeEffect(doc)||doc.getFlag?.(ID,REST_FLAG))&&token?.mesh){this.documents.set(doc.uuid,doc);this.stopped=false;this.startTicker();}
    else {this.documents.delete(doc.uuid);this.renderers.get(token)?.destroy();this.renderers.delete(token);}
    Hooks.callAll('filamentFlightBitsChanged',doc,this.getState(doc));
  }
  assignments(doc,now=this.now(),snapshot=null){
    const events=this.records(doc,false).filter(e=>e.status!=='queued'&&!isFinished(e,now)&&e.expires>now);
    const record=this.allocation(doc,snapshot,false),reserved=events.flatMap(e=>e.bits),hidden=[...new Set([...reserved,...BIT_IDS.filter(b=>record.bits[b].location!=='home')])],support={},returnSupport={};
    const treatment=events.find(e=>e.kind==='treatment');
    if(treatment){
      const amount=treatment.status==='returning'?1-ease((now-treatment.returnAt)/Math.max(1,treatment.returnDuration)):ease((now-treatment.started)/Math.max(1,treatment.travelDuration));
      const arriving=new Set(events.filter(e=>e.kind==='escort'&&e.status==='returning'&&e.reason==='supporting-treatment').flatMap(e=>e.bits));
      const available=BIT_IDS.filter((b,i)=>(!hidden.includes(b)||arriving.has(b))&&(snapshot?.bitCount?.values?.[i]??1)>.01);
      if(available.length===1)(arriving.has(available[0])?returnSupport:support)[available[0]]={amount,x:0,y:-54,bothWings:true};
      else for(let i=0;i<Math.min(2,available.length);i++){const station=available[i];(arriving.has(station)?returnSupport:support)[station]={amount,x:i===0?-145:145,y:15};}
    }
    return {hidden,reserved,support,returnSupport,active:events.length>0||!!doc.getFlag?.(ID,ALLOCATION_FLAG),record};
  }
  prepareSnapshot(doc,snapshot,now){
    this.snapshotCache??=new WeakMap();const raw=doc.getFlag?.(ID,ALLOCATION_FLAG),actions=doc.getFlag?.(ID,FLAG),v8Preferences=doc.getFlag?.(ID,'v8Tools'),config=runtimeConfiguration(),enabled=config.enabled,revision=this.preparationRevision(doc),cached=this.snapshotCache.get(snapshot);
    const v8Motion={examinationMovement:v8Preferences?.examinationMovement==='classic'?'classic':'deliberate',weightedTravel:typeof v8Preferences?.weightedTravel==='boolean'?v8Preferences.weightedTravel:config.v8WeightedTravel!==false,obstacleRoutes:typeof v8Preferences?.obstacleRoutes==='boolean'?v8Preferences.obstacleRoutes:config.v8ObstacleRoutes===true,workingPosture:typeof v8Preferences?.workingPosture==='boolean'?v8Preferences.workingPosture:config.v8WorkingPosture!==false};
    if(cached?.doc===doc&&cached.now===now&&cached.raw===raw&&cached.actions===actions&&cached.v8Preferences===v8Preferences&&cached.enabled===enabled&&cached.revision===revision&&Object.entries(v8Motion).every(([key,value])=>cached.result.v8Motion?.[key]===value))return cached.result;
    if(cached?.doc===doc&&cached.base)snapshot=cached.base;
    const a=this.assignments(doc,now,snapshot);if(!a.active){const result={...snapshot,v8Motion,bitReservationEvents:EMPTY_BIT_EVENTS},memo={doc,now,raw,actions,v8Preferences,enabled,revision,result,base:snapshot};this.snapshotCache.set(snapshot,memo);this.snapshotCache.set(result,memo);return result;}
    const collapse=snapshot.conditionResponse?.collapse,down=snapshot.conditionResponse?.bits&&collapse?.id&&['falling','fallen'].includes(collapse.phase),captured=down?new Set(collapse.bits):null;
    const home=BIT_IDS.filter(b=>a.record.bits[b].location==='home'&&(!captured||captured.has(b))),freeHome=formationStations(a.record,this.records(doc,false)).filter(b=>!captured||captured.has(b)),group=a.record.groups.home,active=home.length>0&&config.enabled;
    const progress=group.transition?.duration>0?Math.min(1,Math.max(0,(now-group.transition.started)/group.transition.duration)):1;
    const effect=group.effect?.enabled&&(group.effect.strength??1)>0?group.effect:null;
    let projected=null;
    if(effect&&isProjectedEffect(effect.id)&&doc.object?.mesh){
      const token=doc.object,transform=sourceTransform(token,snapshot,this.manager),pose=tokenVisualPose(token,this.manager),size=Math.max(token.w,token.h),c=Math.cos(transform.angle),sn=Math.sin(transform.angle),dx=pose.x-transform.x,dy=pose.y-transform.y;
      const movement=this.manager?.states?.get(token)?.kinematics,cachedMotion=this.renderers?.get(token)?.projectionMotion?.get('home-token-field');
      projected={id:effect.id,strength:effect.strength??1,clock:snapshot.effective?.reducedMotion||snapshot.gems.animated===false?0:now/1000,elapsed:Math.min(1200,Math.max(0,now-(effect.started??now-1200))),scaleX:size*6/transform.width,scaleY:size*6/transform.height,angle:transform.angle,originX:(dx*c+dy*sn)/transform.width*600,originY:(-dx*sn+dy*c)/transform.height*600+15,
        focus:visibleProjectionFocus(token,pose),motion:cachedMotion?{x:cachedMotion.dx,y:cachedMotion.dy,amount:cachedMotion.amount}:{x:movement?.vx??0,y:movement?.vy??-1,amount:Math.min(1,(movement?.speed??0)/3.5)}};
    }
    const result={...snapshot,v8Motion,bitsDeployed:active,bitDeployment:active?1:0,compactBits:active&&!snapshot.rendering.wingsActive,
      rendering:{...snapshot.rendering,active:!!(snapshot.rendering.wingsActive||snapshot.rendering.flightActive||active),bitsActive:active},
      gems:{...snapshot.gems,enabled:active,style:active&&snapshot.gems.style==='hidden'?'choreographed':snapshot.gems.style,soloProgram:group.program,soloRadius:group.radius,personality:effect?0:group.personality,coreState:group.internalState,passiveEffects:effect?false:group.passive,behaviour:effect?{...group.behaviour,enabled:false}:group.behaviour,
        glowStrength:effect&&snapshot.gems.glow?Math.min(3,(snapshot.gems.glowStrength??.4)*(1+.8*effect.strength)):snapshot.gems.glowStrength},
      bitProjectedEffect:projected,bitFormationFlow:group.flow,bitFormationNow:now,
      bitActivity:effect&&group.internalState==='auto'?{state:tokenEffectDefinition(effect.id)?.state??'idle',amount:1}:snapshot.bitActivity,
      bitCount:{...snapshot.bitCount,count:home.length,values:BIT_IDS.map(b=>home.includes(b)?1:0),formationWeights:[1,2,3,4].map(n=>n===Math.max(1,freeHome.length)?1:0)},
      bitAllocationState:a.record,bitReservationEvents:this.records(doc,false),bitHomeStations:freeHome,bitVisibleHomeStations:home.filter(b=>!a.reserved.includes(b)),bitFormationTransition:group.transition&&progress<1?{...group.transition,progress}:null,
      bitSequenceActive:a.reserved.length>0,bitActionAssignments:{hidden:captured?[...new Set([...a.hidden,...BIT_IDS.filter(b=>!captured.has(b))])]:a.hidden,support:snapshot.rendering.wingsActive!==false&&snapshot.rendering.active?a.support:{},returnSupport:snapshot.rendering.wingsActive!==false&&snapshot.rendering.active?a.returnSupport:{}}};
    const memo={doc,now,raw,actions,v8Preferences,enabled,revision,result,base:snapshot};this.snapshotCache.set(snapshot,memo);this.snapshotCache.set(result,memo);return result;
  }
  /** Light/lantern decorators only add resolved optical fields. Keep their
   * prepared identity so a downstream renderer does not rebuild assignments
   * or discard those fields. The original base still owns invalidation. */
  retainPreparation(prepared,decorated){
    const memo=this.snapshotCache?.get(prepared);
    if(memo&&decorated!==prepared)this.snapshotCache.set(decorated,{...memo,result:decorated});
    return decorated;
  }
  preparationRevision(doc){return this.preparationRevisions?.get(doc)??0;}
  startTicker(){
    if(this.ticker||!globalThis.canvas?.app?.ticker)return;// After the manager (-10) has placed this frame's home bits, before wing
    // light (-20) and lantern (-21) read the final positions.
    this.ticker=canvas.app.ticker;this.ticker.add(this.tick,this,-11);
  }
  homeEffect(doc){const record=this.allocation(doc,null,false);return (record.groups.home?.effect?.enabled||this.renderers.get(doc.object)?.hasHomeFieldTail?.(this.now()))&&BIT_IDS.some(b=>record.bits[b].location==='home');}
  tick(){
    if(this.stopped||!globalThis.canvas?.ready)return;
    const now=this.now(),cfg=runtimeConfiguration(),measure=localPerformance.active?localPerformance.beginStage():null;let active=false,renderChanged=false;
    const maintenanceDue=now-this.lastMaintenance>=100;
    try{
    for(const doc of this.documents.values()){
      const token=doc.object;
      // One document's invalid saved state (normalizeFlag/readAllocations
      // throw) must never escape: an exception here would stop PIXI's ticker
      // and freeze the whole canvas. Report it once and drop that document
      // until its flags change again.
      try{
      const events=this.records(doc,false),homeEffect=this.homeEffect(doc);if(!token)continue;
      if(!events.length&&!homeEffect&&!this.renderers.get(token)?.handingBack?.()){
        // (12.1.0-beta.1) bits that were at work when she landed have just come free: one more pass puts them away (finishLandingRest)
        if(doc.getFlag?.(ID,REST_FLAG)){if(maintenanceDue&&doc.isOwner&&!this.pending.has(doc.uuid))void this.maintain(doc,now);continue;}
        // A home field switched off with no jobs: release its last frame
        // rather than leaving the field meshes frozen on the canvas.
        if(this.renderers.has(token)){this.renderers.get(token).destroy();this.renderers.delete(token);renderChanged=true;}
        this.documents.delete(doc.uuid);continue;
      }
      active=true;
      const allocation=this.allocation(doc,null,false);
      const valid=events.flatMap(e=>{
        if(e.expires<=now)return [];if(!isFinished(e,now))return [e];
        const remote=e.status==='returning'?e.bits.filter(b=>!['home','retracted'].includes(allocation.bits[b].location)):[];
        return remote.length?[{...e,bits:remote}]:[];
      });
      // Beta.34: a bit handed back home stays drawn here for a few frames
      // while the home renderer takes it, so it is never absent for a frame.
      const handingBack=!valid.some(e=>e.status!=='queued')&&!homeEffect&&!!this.renderers.get(token)?.handingBack?.();
      if((valid.some(e=>e.status!=='queued')||homeEffect||handingBack)&&cfg.enabled&&(cfg.performanceComponents?.treatment!==false||valid.some(e=>['escort','utility'].includes(e.kind))||homeEffect&&cfg.performanceComponents?.fields!==false)&&token.mesh&&!token.destroyed){
        // Keep shared-clock action maintenance alive in a background tab, but
        // no hidden treatment needs geometry, canvas paint or texture uploads.
        // Retain its resources so visibility resumes without rebuilding them.
        if(globalThis.document?.hidden===true)renderChanged=!!this.renderers.get(token)?.suspend?.()||renderChanged;
        else try{let r=this.renderers.get(token);if(!r){r=this.makeRenderer(token);this.renderers.set(token,r);}
          const snapshot=this.state(doc,true);
          // With every bit assigned remotely, Ellie need not have a wing rig.
          // Reuse the normalized flag object in that case, too: a fresh sampled
          // snapshot defeats qualityConfiguration's identity cache each tick.
          const qualityData=this.manager.states?.get(token)?.data??this.stateCache?.get(doc)?.data??snapshot;
          const tokenCfg=qualityConfiguration(cfg,qualityData);
          renderChanged=r.update(valid,snapshot,this.manager,tokenCfg,now)!==false||renderChanged;}
        catch(error){this.manager.report?.(error);this.renderers.get(token)?.destroy();this.renderers.delete(token);}
      }else{renderChanged=this.renderers.has(token)||renderChanged;this.renderers.get(token)?.destroy();this.renderers.delete(token);}
      if(maintenanceDue&&doc.isOwner&&!this.pending.has(doc.uuid))void this.maintain(doc,now);
      }catch(error){
        this.manager.report?.(error);
        const renderer=token?this.renderers.get(token):null;
        if(renderer){try{renderer.destroy();}catch{}this.renderers.delete(token);renderChanged=true;}
        this.documents.delete(doc.uuid);
      }
    }
    if(maintenanceDue)this.lastMaintenance=now;
    try{this.manager.parkedLights?.updateFromRuntime?.(this.manager,cfg,now,{notify:true});}catch(error){this.manager.report?.(error);}
    if(!active&&this.manager.parkedLights?.fading?.())active=true;
    if(renderChanged&&canvas.primary)canvas.primary.renderDirty=true;
    if(!active){this.ticker?.remove(this.tick,this);this.ticker=null;}
    }finally{if(measure!==null)localPerformance.endStage('treatment',measure);}
  }
  /** Called once by the elected condition writer. Work stops immediately, but
   * its physical instruments stay reserved and visible throughout the fall. */
  conditionChanged(source,{unconscious}={},now=this.now()){
    const doc=source?.document??source;
    return this.service.enqueue(doc,async()=>{
      if(!doc?.isOwner)return;
      const events=this.records(doc),record=this.allocation(doc);let changed=false;
      for(const event of events){
        if(unconscious&&event.kind!=='escort'){
          if(event.status==='queued'){event.status='finished';this.settle(event,'cancelled','unconscious');changed=true;continue;}
          this.beginReturn(doc,event,now,'unconscious');
          event.conditionPausedAt=now;event.expires=Number.MAX_SAFE_INTEGER;
          this.settle(event,'cancelled','unconscious');changed=true;
        }else if(!unconscious&&event.conditionPausedAt!=null){
          delete event.conditionPausedAt;event.returnAt=now;event.returnDuration=Math.max(2100,event.returnDuration??800);
          event.created=now;event.expires=now+event.returnDuration+1000;changed=true;
        }
      }
      if(changed)await this.write(doc,events.filter(e=>e.status!=='finished'),[],record);
    });
  }
  invalidateState(doc){this.stateCache?.delete(doc);this.maintenanceCache?.delete(doc);this.preparationRevisions??=new WeakMap();this.preparationRevisions.set(doc,this.preparationRevision(doc)+1);}
  refreshFormation(source){
    const doc=source?.document??source;this.maintenanceCache?.delete(doc);this.stateCache?.delete(doc);
    if(!this.records(doc,false).some(e=>e.kind==='escort'&&e.status==='running'))return Promise.resolve();
    return this.maintain(doc,this.now());
  }
  async syncFlightControls(doc,patch={}, {manualLightIntent=true,skipDeployment=false}={}){
    // Called inside FlightAPI's existing document queue; never enqueue again.
    const motion=patch.gemMotion??{},hasRecord=!!doc.getFlag?.(ID,ALLOCATION_FLAG);
    if(!hasRecord)return;
    if(!skipDeployment&&(patch.bitsDeployed!==undefined||motion.enabled!==undefined||motion.style==='hidden'||motion.count!==undefined)){
      let record=this.allocation(doc);const enabled=motion.enabled===false||motion.style==='hidden'?false:patch.bitsDeployed??motion.enabled,
        count=Number.isInteger(motion.count)?motion.count:record.preferredCount;
      if(globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id)
        await this.deploymentNow(doc,{count,...(typeof enabled==='boolean'?{enabled}:{}),manualLightIntent:manualLightIntent&&enabled===false});
      else {
        // The API also accepts placed tokens outside the viewed scene. Update
        // their saved home destinations without creating local transfer work.
        const anyHome=BIT_IDS.some(id=>record.bits[id].location==='home'),desired=deploymentSelection(record,(enabled??anyHome)?count:0);
        for(const location of ['home','retracted'])if(desired[location].length)record=setDestinations(record,desired[location],location);
        record.preferredCount=count;
        await doc.update(allocationChanges(doc.getFlag(ID,ALLOCATION_FLAG),record));this.observe(doc);
      }
    }
    const fields={soloProgram:'program',soloRadius:'radius',personality:'personality',coreState:'internalState',passiveEffects:'passive'},groupPatch={};
    for(const [field,key] of Object.entries(fields))if(motion[field]!==undefined&&motion[field]!==null)groupPatch[key]=motion[field];
    if(Object.keys(groupPatch).length){
      const record=this.allocation(doc),previous=record.groups.home,now=this.now(),events=this.records(doc),stations=BIT_IDS.filter(b=>record.bits[b].location==='home'&&!events.some(e=>e.status!=='queued'&&e.bits.includes(b)));
      const cfg=runtimeConfiguration(),transition=['program','radius','personality','passive'].some(k=>groupPatch[k]!==undefined&&groupPatch[k]!==previous[k])?this.formationTransition(doc,previous,stations,now,cfg.reduced||cfg.bitTransitions===false||cfg.transitions===false?0:850):null;
      Object.assign(previous,validateGroupPatch(groupPatch));
      if(groupPatch.program){previous.flow={...previous.flow,enabled:false,epoch:now};}
      if(groupPatch.personality!==undefined)previous.behaviour={...previous.behaviour,frequency:groupPatch.personality<.2?'composed':groupPatch.personality>.7?'expressive':'attentive'};
      if(transition){previous.transition=transition;if(!groupPatch.program)Object.assign(previous,rebaseFormationFlow(previous,now,this.state(doc,true).gems.animated!==false));}record.revision++;
      await this.write(doc,this.records(doc),[],record);
    }
  }
  maintain(doc,now=this.now(),restoring=false){
    this.maintenanceCache??=new WeakMap();
    const raw=doc.getFlag?.(ID,FLAG),flight=doc.getFlag?.(ID,'flight'),cached=this.maintenanceCache.get(doc);
    if(!restoring&&cached&&cached.raw===raw&&cached.flight===flight&&now<cached.next)return Promise.resolve();
    this.pending.add(doc.uuid);
    // Non-elected owners still need a periodic re-check (the controller can
    // leave), but not a queued pass on every 100 ms runtime maintenance tick.
    const idle=()=>{const land=doc.getFlag?.(ID,LAND_FLAG);this.maintenanceCache.set(doc,{raw:doc.getFlag?.(ID,FLAG),flight:doc.getFlag?.(ID,'flight'),next:Math.min(now+(doc.getFlag?.(ID,REST_FLAG)?250:1000),land?.at-LAND_EARLY>now?land.at-LAND_EARLY:land?now:Infinity)});};
    return this.service.enqueue(doc,async()=>{
      if(!doc.isOwner||doc.parent?.tokens?.get(doc.id)!==doc)return idle();
      let events=this.records(doc),changed=false,record=this.allocation(doc);
      const lost=BIT_IDS.filter(b=>!['home','retracted'].includes(record.bits[b].location)&&!doc.parent.tokens?.get(record.bits[b].location));
      if(lost.length){record=setDestinations(record,lost,'home');changed=true;}
      // An online user can lose token ownership or be deleted entirely. Such
      // a former controller cannot write, so it must not block the remaining
      // authorized owners from returning work or preserving remote escorts.
      const authorized=user=>!!user&&(user.isGM||doc.testUserPermission?.(user,'OWNER')||user.id===game.user.id&&doc.isOwner);
      const eventOwner=ownerId=>ownerId===game.user.id?game.user:game.users?.get(ownerId);
      const controller=events.find(e=>{const owner=eventOwner(e.owner);return owner?.active&&authorized(owner);})?.owner;
      const users=game.users?.contents??(game.users?.values?[...game.users.values()]:[...(game.users??[])]);
      const candidates=users.filter(u=>u.active&&authorized(u)).sort((a,b)=>a.id.localeCompare(b.id));
      // (12.0.0-beta.4) her bits' recall at the end of a landing, when her wings close
      const land=doc.getFlag?.(ID,LAND_FLAG);
      if(land&&await this.finishLanding(doc,land,now,candidates)){this.maintenanceCache.delete(doc);return;}
      // (12.1.0-beta.1) bits that were at work when she landed go in once they are free
      const rest=doc.getFlag?.(ID,REST_FLAG);if(rest&&(controller??candidates[0]?.id??game.user.id)===game.user.id&&await this.finishLandingRest(doc,rest,now)){this.maintenanceCache.delete(doc);return;}
      if((controller??candidates[0]?.id??game.user.id)!==game.user.id)return idle();
      for(const event of events){
        if(event.returnTreatment&&(event.conditionPausedAt!=null||now-event.returnAt>=Math.min(TREATMENT_RELEASE_MS,event.returnDuration))){delete event.returnTreatment;changed=true;}
        if(event.conditionPausedAt!=null)continue;
        const owner=eventOwner(event.owner);
        const ownerActive=owner?.active&&authorized(owner),canClean=ownerActive?event.owner===game.user.id:(candidates[0]?.id??event.owner)===game.user.id;
        if(!canClean)continue;
        const persistent=['escort','utility'].includes(event.kind),targetDoc=event.target?doc.parent.tokens?.get(event.target):null;
        const targetGone=event.target&&!targetDoc||event.kind==='utility'&&(event.utility.sceneId!==doc.parent.id||targetDoc&&!scanTokenVisible(targetDoc.object,{scene:doc.parent,source:event.utility.mode==='parkLight'?doc.object:undefined})),stale=restoring&&!persistent&&event.owner===game.user.id&&event.session!==this.session;
        const offline=!owner||owner.active===false,revoked=owner?.active&&!authorized(owner);
        if(event.kind==='utility'&&event.utility.scanMode==='once')changed=this.observeSurvey(doc,event,now)||changed;
        if(isFinished(event,now)){this.settle(event,event.reason?'cancelled':'completed');event.status='finished';changed=true;continue;}
        if(persistent&&!targetGone&&(offline||revoked||restoring)){event.owner=game.user.id;event.session=this.session;changed=true;}
        if(targetGone||stale||(offline||revoked)&&!persistent||now>=event.expires){
          if(targetGone){const affected=BIT_IDS.filter(b=>record.bits[b].location===event.target);if(affected.length)record=setDestinations(record,affected,'home');}
          if(event.status!=='returning'){
            this.beginReturn(doc,event,now,targetGone?'target-deleted':stale?'session-restored':revoked?'owner-permission-changed':offline?'owner-disconnected':'timeout');changed=true;
          }
        }else if(event.status==='running'&&((event.kind==='treatment'&&event.finishAt!=null&&now>=event.finishAt+treatmentOutcomeDuration(event))||(event.kind==='sequence'&&now>=event.started+event.sequence.duration))){
          this.beginReturn(doc,event,now);changed=true;
        }
      }
      changed=this.restoreUtilityClaims(doc,events,now)||changed;
      const queued=new Set(events.filter(e=>e.status==='queued').map(e=>e.id)),launchSources=queued.size?events.map(clone):null,beforeLength=events.length;events=scheduleActions(events,now);changed ||= events.length!==beforeLength||events.some(e=>e.status==='running'&&queued.has(e.id));
      for(const event of events)if(event.status==='running'&&queued.has(event.id))Object.assign(event,event.sequence?.gesture?this.captureGesture(doc,event,launchSources.filter(e=>e.id!==event.id),now):this.captureWorld(doc,event.bits,launchSources.filter(e=>e.id!==event.id),now,{behaviour:event.kind==='treatment'&&this.state(doc,true).v7?.medkit===true,velocity:event.kind==='treatment'&&this.state(doc,true).v7?.medkit===true,velocityDelta:.25,coreVelocity:event.kind==='treatment'&&this.state(doc,true).v7?.medkit===true}));
      // Reconcile edits only escorts, and only for remote groups; other passes
      // need no serialization (this runs about once a second per owner).
      const remoteGroups=allocationGroups(record).some(g=>g.target),escorts=list=>JSON.stringify(list.filter(e=>e.kind==='escort'));
      const beforeReconcile=remoteGroups?escorts(events):null,beforeCount=events.length;events=this.reconcile(doc,events,record,now);
      changed ||= events.length!==beforeCount||remoteGroups&&escorts(events)!==beforeReconcile;
      const observations=this.surveyObservations?.get(doc);if(observations){const live=new Set(events.filter(event=>event.kind==='utility'&&event.utility.scanMode==='once'&&event.status!=='returning').map(event=>event.id));for(const key of observations.keys())if(!live.has(key))observations.delete(key);}
      if(changed)await this.write(doc,events,[],record);
      // Paused work has no live clock deadline. A returning treatment follows
      // only its return clock, not its already-completed outcome animation.
      const deadlines=events.filter(e=>e.conditionPausedAt==null).flatMap(e=>[e.expires,e.status==='returning'?e.returnAt+e.returnDuration:Infinity,e.returnTreatment?e.returnAt+Math.min(TREATMENT_RELEASE_MS,e.returnDuration):Infinity,e.status==='running'&&e.kind==='treatment'&&e.finishAt!=null?e.finishAt+treatmentOutcomeDuration(e):Infinity,e.kind==='sequence'&&e.status==='running'?e.started+e.sequence.duration:Infinity]);
      this.maintenanceCache.set(doc,{raw:doc.getFlag?.(ID,FLAG),flight:doc.getFlag?.(ID,'flight'),next:Math.min(land?.at-LAND_EARLY>now?land.at-LAND_EARLY:land?now:Infinity,now+(events.some(e=>e.kind==='utility'&&e.utility.scanMode==='once'&&e.status==='running'&&e.taskPausedAt==null)?500:1000),...deadlines)});
    }).catch(error=>this.manager.report?.(error)).finally(()=>this.pending.delete(doc.uuid));
  }
  rebuild(){
    this.stopped=false;for(const r of this.renderers.values())r.destroy();this.renderers.clear();this.documents.clear();
    for(const token of canvas.tokens?.placeables??[])if(this.records(token.document).length||token.document.getFlag?.(ID,ALLOCATION_FLAG)){this.observe(token.document);if(token.document.isOwner)void this.maintain(token.document,this.now(),true);}
  }
  deleteToken(doc){
    // Only a still-drawable object can anchor the return sample; a destroyed
    // one has no mesh and would resample around Ellie (a teleport). Without
    // it, beginReturn starts from the renderer's last displayed positions.
    this.deletedTargets??=new Map();if(doc.object&&!doc.object.destroyed&&doc.object.mesh)this.deletedTargets.set(doc.id,doc.object);const recoveries=[];
    this.documents.delete(doc.uuid);
    this.renderers.get(doc.object)?.destroy();this.renderers.delete(doc.object);
    for(const h of [...this.handles.values()])if(h.doc===doc)this.settle(h.event,'cancelled','source-deleted');
    for(const token of canvas.tokens?.placeables??[])if(token.document.isOwner&&this.records(token.document).some(e=>e.target===doc.id)){this.maintenanceCache?.delete(token.document);recoveries.push(this.maintain(token.document));}
    void Promise.allSettled(recoveries).finally(()=>this.deletedTargets?.delete(doc.id));
  }
  removeToken(token){this.renderers.get(token)?.destroy();this.renderers.delete(token);}
  /** Canvas teardown. Escorts (saved destinations) and utility jobs persist.
   * This session's own treatments/sequences lose their caller, so they begin
   * an ordinary animated return from the pose still displayed now, before the
   * renderers are destroyed; nothing snaps home and no job is cancelled. */
  clear(reason='scene-changed'){
    this.stopped=true;this.ticker?.remove(this.tick,this);this.ticker=null;
    const now=this.now(),transient=e=>!['escort','utility'].includes(e.kind)&&e.owner===game.user.id&&e.session===this.session&&e.status!=='returning';
    const returns=new Map();
    for(const doc of new Set([...[...this.handles.values()].map(h=>h.doc),...this.documents.values()])){
      if(!doc?.isOwner)continue;
      try{
        const live=this.records(doc).filter(transient);if(!live.length)continue;
        const captured=new Map();
        for(const event of live){const before=JSON.stringify(event);try{this.beginReturn(doc,event,now,reason);}catch{event.status='finished';}captured.set(event.id,{before,event});}
        returns.set(doc,captured);
      }catch(error){this.manager.report?.(error);}
    }
    for(const r of this.renderers.values())r.destroy();this.renderers.clear();
    this.documents.clear();this.deletedTargets?.clear();
    for(const h of [...this.handles.values()])this.settle(h.event,'cancelled',reason);
    for(const [doc,captured] of returns)void this.service.enqueue(doc,async()=>{
      // A queued command may have changed an event meanwhile; such an event
      // starts its return from the saved state instead of the captured pose.
      const events=this.records(doc).flatMap(event=>{
        const entry=captured.get(event.id);if(!entry||!transient(event))return [event];
        if(JSON.stringify(event)===entry.before)return entry.event.status==='finished'?[]:[entry.event];
        try{this.beginReturn(doc,event,now,reason);}catch{return [];}
        return event.status==='finished'?[]:[event];
      });
      await doc.update({[PATH]:{version:1,events}});
    }).catch(()=>{});
  }
  publicAPI(guard=fn=>fn){return Object.freeze({
    previewEdit:guard((source,patch)=>this.previewEdit(source,patch)),edit:guard((source,plan)=>this.edit(source,plan)),setPaused:guard((source,paused,options)=>this.setPaused(source,paused,options)),setExaminationMovement:guard((source,value)=>this.setExaminationMovement(source,value)),
    setScanMethods:guard((source,patch)=>this.setScanMethods(source,patch)),setScanSpeed:guard((source,speed,options)=>this.setScanSpeed(source,speed,options)),getToolState:guard(source=>this.getToolState(source)),previewTool:guard((source,options)=>this.previewTool(source,options)),startTool:guard((source,options)=>this.startTool(source,options)),stopTool:guard((source,options)=>this.stopTool(source,options)),undo:guard(source=>this.undoCommand(source)),
    assign:guard((source,target,options)=>this.assign(source,target,options)),
    gesture:guard((source,name,options)=>this.gesture(source,name,options)),getGestures:()=>Object.entries(BIT_GESTURES).map(([id,g])=>({id,...g})),
    treat:guard((source,target,options)=>this.treat(source,target,options)),play:guard((source,sequence,options)=>this.play(source,sequence,options)),
    register:guard((name,sequence)=>this.register(name,sequence)),unregister:name=>this.definitions.delete(name),
    toggle:guard((source,station)=>this.toggle(source,station)),recall:guard((source,options)=>this.recall(source,options)),
    toggleAll:guard((source,options)=>this.toggleAll(source,options)),retractAll:guard(source=>this.retractAll(source)),gather:guard(source=>this.gather(source)),
    setDeployment:guard((source,options)=>this.setDeployment(source,options)),setGroup:guard((source,group,options)=>this.setGroup(source,group,options)),
    setSummonFormation:guard((source,options)=>this.setSummonFormation(source,options)),toggleSummonFormation:guard((source,mode)=>this.toggleSummonFormation(source,mode)),
    setEffect:guard((source,group,options)=>this.setEffect(source,group,options)),
    getEffects:()=>tokenEffectChoices(),getAnimations:()=>[...this.definitions.keys()],getState:guard(source=>this.getState(source)),returnAll:guard(source=>this.returnAll(source)),
    cancel:guard((source,id,reason)=>this.cancel(source,id,reason)),finish:guard((source,id,result)=>this.finish(source,id,result)),stations:[...BIT_IDS]});}
}
