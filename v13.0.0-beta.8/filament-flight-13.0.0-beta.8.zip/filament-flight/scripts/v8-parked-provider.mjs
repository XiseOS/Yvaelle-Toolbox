import {sampleBitTool} from './v8-scan-choreography.mjs?v=13.0.0-beta.8';
import {tokenVisualPose} from './bit-action-renderer.mjs?v=13.0.0-beta.8';

/** Native illumination follows the canonical displayed station. Offscreen
 * tools use the SAME pure sampler, without constructing artwork or textures. */
export function parkedLightEmitters(manager,token,snapshot,now){
  if(!token?.mesh)return [];
  const events=snapshot?.bitReservationEvents??manager.bits?.records?.(token.document,false)??[];
  const renderer=manager.bits?.renderers?.get(token),source=tokenVisualPose(token,manager),size=Math.max(token.w,token.h,1);
  const emitters=[];
  for(const event of events){
    if(event.kind!=='utility'||event.utility?.mode!=='parkLight'||event.status!=='running'||event.expires<=now)continue;
    const target=event.target?globalThis.canvas?.tokens?.get?.(event.target):null;
    if(event.target&&!target?.mesh)continue;
    const context={source,target:target?tokenVisualPose(target,manager):event.utility.center,size,
      targetSize:target?Math.max(target.w,target.h):size,transform:{angle:source.angle},snapshot};
    const frame=sampleBitTool(event,now,context),fresh=renderer?.lastPositionTimes?.get(event.id)===now;
    for(const id of event.bits){
      const position=fresh?renderer.lastPositions.get(event.id)?.[id]:frame.positions[id];
      if(!position)continue;
      emitters.push({id,event,...position,arrived:frame.phases?.[id]?.phase==='illuminating'||frame.phases?.[id]==='illuminating',
        strength:1,targetToken:target??undefined});
    }
  }
  return emitters;
}
