/** Extended condition choreography. Art stays in wing-local coordinates and
 * uses the same pose warp, growth clipping and textures as the main lattice.
 * Every treatment is deterministic; no timers, filters or persistent sprites. */
import {hash} from './conditions.mjs?v=13.0.0-beta.8';
import {ease} from './poses.mjs?v=13.0.0-beta.8';
import {cubic} from './wing-art.mjs?v=13.0.0-beta.8';
import {fitEffectPoint} from './condition-art.mjs?v=13.0.0-beta.8';

const TAU=Math.PI*2,frac=x=>x-Math.floor(x),root=u=>ease((u-.1)/.34);
const qink=x=>Math.round(Math.max(0,Math.min(1.5,x))*20)/20;
const blend=(a,b,k)=>a.map((n,i)=>n+(b[i]-n)*k);
const bell=(u,c,w)=>Math.exp(-(((u-c)/w)**2));
const ID_GATE=Object.freeze({aurora:null,roseLattice:null,scarStitch:'breaks',emberFray:'breaks',
  pendulum:'instability',interference:'instability',spectralShear:'glitches',memoryEcho:'glitches',
  roseEngine:'arcs',lightningWeave:'arcs',sealedHalo:'instability',hush:null,
  fallingScript:'breaks',seedRecall:'breaks'});
export const EXPANDED_CONDITION_IDS=Object.freeze(Object.keys(ID_GATE));
const cache=new WeakMap();
function field(v,side){
  const a=v?.variant,id=a?.id;
  if(!Object.hasOwn(ID_GATE,id)||!(a.amount>0)||ID_GATE[id]&&v.gates?.[ID_GATE[id]]===false)return null;
  const time=v.animated===false?0:(a.time??0),motion=v.gates?.instability===false?0:(v.variantMotion??1);
  let c=cache.get(v);
  if(!c||c.id!==id||c.time!==time||c.amount!==a.amount||c.motion!==motion||c.seed!==v.seed||c.frequency!==a.frequency){
    c={id,time,amount:a.amount,motion,seed:v.seed,frequency:a.frequency,sides:new Map()};cache.set(v,c);
  }
  if(!c.sides.has(side)){
    const phase=(hash(`${v.seed}:condition:${side}`)/4294967295)*TAU;
    c.sides.set(side,{id,A:a.amount,t:time,m:motion,f:a.frequency??1,phase,
      swing:Math.sin(time*.82+side*.85),breath:.5+.5*Math.sin(time*.62+phase),
      shearFront:.18+.65*frac(time*.23*(a.frequency??1)+(side<0?.18:0)),
      seams:[.42,.61,.77].map((u,i)=>({u:u+.026*Math.sin(time*.7+i*2+phase),rib:[2,5,7][i]}))});
  }
  return c.sides.get(side);
}

export function expandedConditionPoint(point,u,side,v){
  const f=field(v,side);if(!f||u<=.1)return point;
  const {id,A,t,m,phase,swing,breath}=f,p=[...point],r=root(u),x=p[0]-side*27,y=p[1]+13;
  switch(id){
    case 'aurora':{
      const wave=Math.sin(t*.55-u*4.5+y*.006+phase);
      p[0]+=side*5*A*m*r*wave;p[1]+=3.4*A*m*r*Math.cos(t*.55-u*4.5);break;}
    case 'roseLattice':{
      const opening=Math.sin(t*.64-u*3+phase);
      p[0]+=x*.018*A*m*r*opening;p[1]+=2*A*m*r*Math.sin(t*.64+u*5);break;}
    case 'scarStitch':{
      const pull=bell(u,.59,.22)*(.6+.4*Math.sin(t*.95+phase)**2);
      p[0]-=x*.035*A*m*r*pull;p[1]+=3*A*m*r*pull*Math.sin(y*.018);break;}
    case 'emberFray':p[1]+=A*m*r*u*(4+5*u);p[0]+=side*A*m*r*2*Math.sin(t*.8+u*8+phase);break;
    case 'pendulum':{
      // Rotation about the shoulder dies away at the root. Opposed phases keep
      // the two wings correcting each other instead of wobbling in unison.
      const angle=.055*A*m*r*swing,co=Math.cos(angle),si=Math.sin(angle);
      p[0]=side*27+x*co-y*si;p[1]=-13+x*si+y*co;
      p[0]-=x*.075*A*m*r*Math.sin(t*.82+side*.85-u*2.4);break;}
    case 'interference':{
      const packet=bell(u,.51+.22*Math.sin(t*.42+phase),.25);
      p[0]+=side*A*m*r*packet*6.5*(Math.sin(t*2.1-u*12)+Math.sin(t*2.34+u*10))*.5;
      p[1]+=A*m*r*packet*5*Math.sin(t*2.34-u*7+phase);break;}
    case 'roseEngine':p[0]+=x*A*m*r*(.018+.035*breath);p[1]-=3.5*A*m*r*breath;break;
    case 'lightningWeave':p[0]+=x*.022*A*m*r*Math.sin(t*1.7-u*8+phase);break;
    case 'sealedHalo':p[0]-=x*A*r*(.28+.025*m*breath);p[1]+=y*.035*A*r;break;
    case 'hush':p[0]-=x*.17*A*r;p[1]+=A*m*r*3*Math.sin(t*.36+u*2);break;
    case 'fallingScript':{
      const target=[side*27+x*.54,-13+y*(y<0?.58:.62)+u*34];
      p[0]+=(target[0]-p[0])*A*r;p[1]+=(target[1]-p[1])*A*r;
      p[0]+=side*2.4*A*m*r*Math.sin(t*.65+u*6+phase);break;}
    case 'seedRecall':{
      const gathering=.5+.5*Math.sin(t*.55+phase),fold=A*r*(.43+.12*gathering*m);
      p[0]-=x*fold;p[1]+=(-y*.30+u*22)*fold;break;}
  }
  return fitEffectPoint(p);
}

/** Return null when the caller should use its existing path pipeline. Cuts
 * split polylines rather than joining across missing spans. Constant section
 * offsets also prevent diagonal bridges across a displaced slice. */
export function expandedConditionPaths(strand,points,side,v){
  const f=field(v,side);if(!f)return null;
  const {id,A,t,m,phase,shearFront,seams}=f,rib=strand.id.startsWith('rib-');
  const major=['rib-0','rib-4','rib-9'].includes(strand.id)||strand.id.startsWith('edge-');
  const web=/^(web|cross)-/.test(strand.id),index=Number(strand.id.split('-')[1])||0;
  const rank=(hash(`${v.seed}:${side}:extended:${strand.id}`)>>>0)/4294967295;
  const sliced=['scarStitch','emberFray','spectralShear','memoryEcho','hush','fallingScript','seedRecall'].includes(id);
  if(!sliced)return [{...strand,points}];
  const out=[],extras=[];let last=null;
  const repair=Math.max(0,...(v.reactions??[]).filter(b=>b.kind==='heal'||b.kind==='reform').map(b=>b.progress*1.22));
  const append=(p,q,s,tag)=>{
    if(s<=.025){last=null;return;}
    if(last&&last.tag===tag&&last.strength===s&&last.points.at(-1).every((n,i)=>n===p[i]))last.points.push(q);
    else{last={...strand,points:[p,q],strength:s,tag};out.push(last);}
  };
  for(let i=1;i<points.length;i++){
    const p=points[i-1],q=points[i],u=((p[3]??1)+(q[3]??1))*.5,r=root(u),section=Math.floor(u*9);
    let cut=false,dx=0,dy=0,s=strand.strength,tag='plain';
    switch(id){
      case 'scarStitch':{
        const seam=seams.find(k=>(rib?index===k.rib:web&&Math.abs(index+.5-k.rib)<1)&&Math.abs(u-k.u)<.030*A*r);
        cut=!!seam&&!major;
        if(!cut&&seams.some(k=>Math.abs(u-k.u)<.07&&Math.abs(index-k.rib)<1.2))s*=1+.5*A;break;}
      case 'emberFray':{
        const end=.66+.24*rank;
        cut=!major&&u>end&&Math.sin(u*39+rank*11)>1-.95*A;
        if(u>end)s*=1-.58*A*ease((u-end)/.25);break;}
      case 'spectralShear':{
        const height=(p[1]+q[1])*.5,band=Math.floor((height+u*34+250)/42);
        const life=frac(t*.23*f.f+band*.17),gain=Math.sin(Math.PI*life)**2;
        const active=Math.abs(u-shearFront)<.15&&!major;
        if(active){dx=side*(band%2?1:-1)*13*A*m*r*gain*(v.gates?.displacement??1);dy=(band%2?1:-1)*2.2*A*m*r*gain;tag=`shear-${band}`;
          cut=web&&Math.abs(u-shearFront)<.022*A&&gain>.5;
          if(!cut&&rib&&v.gates?.echoes!==false)extras.push({...strand,id:`spectral-edge-${strand.id}`,echo:true,
            points:[p,q].map(n=>fitEffectPoint([n[0]-dx*.52,n[1]-dy*.52,n[2],n[3]])),width:strand.width*.48,strength:qink(.24*A*gain)});
        }break;}
      case 'memoryEcho':{
        const front=.14+.8*frac(t*.19*f.f+(side<0?.23:0)),gain=bell(u,front,.12)*A*r;
        if(!major&&gain>.04){dx=side*6*m*gain*(v.gates?.displacement??1);dy=-2*m*gain;tag=`memory-${section}`;
          if((rib||web&&index%3===0)&&v.gates?.echoes!==false)extras.push({...strand,id:`memory-copy-${strand.id}`,echo:true,
            points:[p,q].map(n=>fitEffectPoint([n[0]-side*10*m*gain,n[1]+6*m*gain,n[2],n[3]])),width:strand.width*.6,strength:qink(strand.strength*.42*gain)});
        }break;}
      case 'hush':{
        const boundary=.69+.055*Math.sin(t*.42+phase);
        cut=!major&&u>boundary&&rank<A*.62;
        s*=1-A*(major?.12:.26+.4*ease((u-.28)/.65));break;}
      case 'fallingScript':{
        cut=!major&&(web?rank<A*(.35+.48*r):u>.58+.25*rank&&section%3===1);
        s*=1-A*(major?.22:.28+.2*u);break;}
      case 'seedRecall':{
        const life=frac(t*.14+rank),tail=.48+.32*rank;
        cut=!major&&((web&&u>tail&&rank<A*.8)||(rib&&u>tail&&section%3===0));
        if(!major&&u>tail){const pull=A*m*r*Math.sin(Math.PI*life)**2;dx=-side*10*pull;dy=7*pull;tag=`seed-fragment-${section}`;s*=1-.45*A*life;}break;}
    }
    if(cut&&u<repair)cut=false;
    if(cut){last=null;continue;}
    const shift=n=>fitEffectPoint([n[0]+dx,n[1]+dy,n[2],n[3]??u]);
    append(shift(p),shift(q),qink(s),tag);
  }
  return [...out,...extras];
}

export function expandedConditionAccents(side,v,warp,ribs,growth=1){
  const f=field(v,side);if(!f||growth<=0)return [];
  const {id,A,t,m,phase,breath,seams}=f,out=[];
  const at=(i,u)=>warp([...cubic(ribs[Math.max(0,Math.min(ribs.length-1,i))],u),u]);
  const line=(name,points,width,strength)=>{
    const ink=qink(strength);if(ink<=.025||points.length<2||points.some(p=>p[3]>growth+.00001))return;
    // Narrow pale cores separate active energy from the saturated magenta web.
    // Broken threads and ghosts remain magenta, so the wing never washes out.
    const highlight=!['emberFray','spectralShear','memoryEcho','hush','fallingScript'].includes(id);
    out.push({id:`expanded-${name}`,points:points.map(fitEffectPoint),width,strength:ink,highlight});
  };
  const spark=(name,p,strength,size=1.5)=>{
    const ink=qink(strength);if(v.gates?.sparks===false||ink<=.025||p[3]>growth+.00001)return;
    out.push({id:`expanded-${name}`,star:true,points:[fitEffectPoint(p)],width:size,strength:ink});
  };
  // All decorative offsets retain the original growth distance and depth.
  const offset=(p,x,y)=>[p[0]+x,p[1]+y,p[2],p[3]];
  const run=(name,i,u,length,strength,width=.85)=>{
    if(u<=.04||u>growth)return;
    line(name,Array.from({length:11},(_,j)=>at(i,Math.max(.04,u-j*length/10))),width,strength);
  };
  const join=(name,i,j,u,w,strength,width=.62)=>{
    const a=at(i,u),b=at(j,u),points=Array.from({length:15},(_,k)=>{
      const q=k/14,p=blend(a,b,q);return offset(p,side*w*Math.sin(Math.PI*q),w*.24*Math.sin(TAU*q));
    });line(name,points,width,strength);
  };
  const rose=(name,i,u,radius,strength,turn=0,petals=4)=>{
    const p=at(i,u),prev=at(i,Math.max(.01,u-.035)),next=at(i,Math.min(1,u+.035)),len=Math.hypot(next[0]-prev[0],next[1]-prev[1])||1;
    const tx=(next[0]-prev[0])/len,ty=(next[1]-prev[1])/len;
    for(let j=0;j<petals;j++)line(`${name}-petal-${j}`,Array.from({length:13},(_,k)=>{
      const q=k/12,angle=turn+j*TAU/petals+(q-.5)*.65,rad=Math.sin(Math.PI*q)*radius;
      const x=Math.cos(angle)*rad,y=Math.sin(angle)*rad*.74;
      return offset(p,tx*x-ty*y,ty*x+tx*y);
    }),.68,strength);
    spark(`${name}-heart`,p,strength*.65,1.25);
  };
  switch(id){
    case 'aurora':
      // Three travelling silk curtains are woven through the ribs, never filled.
      for(let j=0;j<3;j++){
        const life=frac(t*.075+j/3),u=.16+.73*life,gain=A*Math.sin(Math.PI*life)*.56;
        const pts=[];for(let k=0;k<=36;k++){
          const ri=k/4,i=Math.min(8,Math.floor(ri)),q=ri-i,pu=Math.max(.08,Math.min(.97,u+.043*Math.sin(ri*.85-t*.65+j)));
          pts.push(blend(at(i,pu),at(i+1,pu),q));
        }
        line(`aurora-veil-${j}`,pts,.85,gain);line(`aurora-thread-${j}`,pts.map(p=>offset(p,side*1.5*m,-2*m)),.38,gain*.42);
      }break;
    case 'roseLattice':
      for(const [j,i,u] of [[0,1,.58],[1,4,.67],[2,7,.72]]){
        const opening=.7+.3*Math.sin(t*.64+j*1.7+phase),gain=A*(.45+.25*opening);
        join(`rose-arch-${j}`,i,i+2,u,10*opening*m,gain);
        join(`rose-arch-return-${j}`,i,i+2,u,-10*opening*m,gain*.65);
        rose(`rose-window-${j}`,i+1,u,(8+4*opening)*m,gain,Math.PI*.25,4);
        run(`rose-vein-${j}`,i+1,.18+.73*frac(t*.1+j*.31),.12,gain,.65);
      }break;
    case 'scarStitch':
      for(let j=0;j<seams.length;j++){
        const {u,rib:i}=seams[j],tension=.55+.45*Math.sin(t*.95+j*1.5)**2;
        for(let k=0;k<4;k++){
          const start=at(i,Math.max(.11,u-.065+k*.023)),end=at(i,Math.min(.98,u+.065-k*.023));
          const middle=blend(start,end,.5),spread=side*(3.5+3*tension)*m*(k%2?1:-1);
          line(`scar-suture-${j}-${k}`,[start,offset(middle,spread,-2*m),end],.7,A*.82);
        }
        spark(`scar-lock-${j}`,at(i,u),A*tension*.65,1.35);
      }break;
    case 'emberFray':
      if(v.gates?.sparks!==false)for(const i of [1,3,5,6,8]){
        const life=frac(t*.15+i*.193),u=.72+.15*Math.sin(i*2.4)**2,p=at(i,u),fade=Math.sin(Math.PI*life);
        const pts=Array.from({length:15},(_,k)=>{const q=k/14;return offset(p,
          side*(6+12*life)*q*m+Math.sin(q*Math.PI+t*.7+i)*2*m,life*10+q*(13+16*life));});
        line(`ember-fray-${i}`,pts,.43,A*.68*fade);
        spark(`ember-cinder-${i}`,pts.at(-1),A*.38*fade,1.1);
      }break;
    case 'pendulum':
      for(const [j,i] of [[0,1],[1,4],[2,7]]){
        const life=frac(t*.14+j*.28),u=.26+.61*(.5+.5*Math.sin(t*.82+j*.6+side*.85)),gain=A*(.4+.3*Math.sin(Math.PI*life));
        join(`pendulum-bow-${j}`,i,i+2,u,9*Math.sin(t*.82+j+side)*m,gain,.65);
        run(`pendulum-correction-${j}`,i+1,.14+.79*(1-life),.15,gain,.8);
      }break;
    case 'interference':
      for(let j=0;j<2;j++){
        const points=[];for(let k=0;k<=40;k++){
          const ri=k/5,i=Math.min(8,Math.floor(ri)),q=ri-i,u=.54+(j?1:-1)*.115*Math.sin(ri*.85+t*.8+phase);
          points.push(blend(at(i,u),at(i+1,u),q));
        }line(`interference-weft-${j}`,points,.85,A*.65);
      }
      for(const i of [1,4,7]){const u=.54+.10*Math.sin(t*.8+i*.85+phase);rose(`interference-node-${i}`,i,u,3.5*m,A*.38,t*.25,2);}break;
    case 'spectralShear':
      for(let j=0;j<3;j++){
        const u=f.shearFront+(j-1)*.035;if(u<=.13||u>.93)continue;
        const i=1+j*3,p=at(i,u),shift=side*(j%2?1:-1)*8*A*m*(v.gates?.displacement??1);
        line(`spectral-seam-${j}`,[offset(at(i,u-.045),shift,-2*m),offset(p,shift,0),at(i+1,u+.02)],.52,A*.65);
      }break;
    case 'memoryEcho':
      if(v.gates?.echoes!==false)for(let j=0;j<3;j++){
        const life=frac(t*.19*f.f+j*.31),u=.2+.65*life,i=1+j*3,fade=Math.sin(Math.PI*life);
        const points=Array.from({length:13},(_,k)=>{const pu=Math.max(.1,u-k*.01),p=at(i,pu);return offset(p,-side*(7+life*6)*m,life*7*m);});
        line(`memory-trace-${j}`,points,.54,A*.42*fade);
        line(`memory-return-${j}`,[points[0],at(i,u)],.38,A*.3*fade);
      }break;
    case 'roseEngine':
      if(v.gates?.arcs!==false)for(const [j,i,u] of [[0,1,.59],[1,4,.69],[2,7,.76]]){
        const cycle=frac(t*.24+j/3),charge=Math.sin(Math.PI*cycle)**2;
        rose(`engine-${j}`,i,u,(10+4*charge)*m,A*(.62+.3*charge),t*.38*(side<0?-1:1)+j,5);
        for(const ri of [i,Math.min(9,i+1)])run(`engine-outflow-${j}-${ri}`,ri,u+(1-u)*cycle,.15,A*.75*Math.sin(Math.PI*cycle),1.05);
        join(`engine-spoke-${j}`,Math.max(0,i-1),Math.min(9,i+1),u,5*m,A*.4,.45);
      }break;
    case 'lightningWeave':
      if(v.gates?.arcs!==false)for(let j=0;j<4;j++){
        const life=frac(t*.32+j*.247),u=.15+.74*life,gain=A*Math.sin(Math.PI*life)*.75,pts=[];
        for(let k=0;k<10;k++){const p=at(k,Math.min(.99,u+(k%2?.025:-.025)));pts.push(p);
          if(k<9){const q=at(k+1,Math.min(.99,u+(k%2?-.025:.025))),mid=blend(p,q,.5);pts.push(offset(mid,side*(k%2?-1:1)*3*m,2*m));}}
        line(`lightning-shuttle-${j}`,pts,.8,gain);
        const i=j*2+1;run(`lightning-warp-${j}`,i,u,.09,gain,.85);spark(`lightning-junction-${j}`,at(i,u),gain*.6,1.25);
      }break;
    case 'sealedHalo':
      for(const [j,u] of [[0,.43],[1,.74]]){
        const pts=[];for(let k=0;k<=36;k++){
          const ri=k/4,i=Math.min(8,Math.floor(ri)),q=ri-i,pu=u+.045*Math.sin(ri*Math.PI/9+t*.25+j);
          pts.push(blend(at(i,pu),at(i+1,pu),q));
        }
        line(`sealed-cuff-${j}`,pts,.82,A*.7);
        const p=at(4,u);line(`sealed-clasp-${j}`,[[0,-5],[3,0],[0,5],[-3,0],[0,-5]].map(([x,y])=>offset(p,x*m,y*m)),.6,A*.7);
        join(`sealed-diagonal-${j}`,1,8,u,j?-6:6,A*.35,.42);
      }break;
    case 'hush':
      for(const i of [0,3,6,9]){
        const life=frac(t*.11+i*.113),u=.16+.55*(1-life),gain=A*Math.sin(Math.PI*life)*.42;
        run(`hush-inflow-${i}`,i,u,.065,gain,.52);
      }
      // A broken near-root crescent makes the inward flow legible at low light.
      line('hush-crescent',[0,1,2,3,4].map(i=>at(i,.18+.012*Math.sin(t*.3+i))),.44,A*.28);break;
    case 'fallingScript':
      if(v.gates?.sparks!==false)for(let j=0;j<7;j++){
        const life=frac(t*.105+j*.143),i=j%3===0?1:j%3===1?5:8,u=.45+j*.054,p=at(i,u),fade=Math.sin(Math.PI*life);
        const drift=side*Math.sin(t*.45+j)*4*m,drop=(10+life*34)*m,scale=3.5+2*life;
        // Seven light, disconnected calligraphic fragments descend independently.
        const shape=j%2?[[0,-1],[.2,-.25],[-.5,.3],[.45,.2],[0,1.2]]:[[-.5,-.7],[.4,-.5],[0,0],[.35,.7],[-.3,1]];
        line(`falling-script-${j}`,shape.map(([x,y])=>offset(p,drift+x*scale,drop+y*scale)),.5,A*.64*fade);
      }break;
    case 'seedRecall':
      for(const [j,i,u] of [[0,1,.54],[1,5,.60],[2,8,.66]]){
        const life=frac(t*.14+j*.31),gather=Math.sin(Math.PI*life)**2,p=at(i,u);
        rose(`seed-${j}`,i,u,(2.5+2*gather)*m,A*.7,t*.12,3);
        for(const sign of [-1,1]){
          const length=(8+19*(1-gather))*m,q=offset(p,side*length,sign*length*.42);
          line(`seed-thread-${j}-${sign}`,[q,offset(blend(q,p,.5),-side*3*m,sign*3*m),p],.4,A*.48*gather);
          line(`seed-shard-${j}-${sign}`,[offset(q,-side*2,sign*4),q,offset(q,side*3,-sign*1.5)],.55,A*.55*(1-gather*.45));
        }
      }break;
  }
  return out;
}
