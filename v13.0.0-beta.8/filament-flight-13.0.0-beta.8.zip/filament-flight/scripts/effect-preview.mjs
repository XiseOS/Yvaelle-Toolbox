import {frameGeometry,paintLayers,LAYER_NAMES} from './wing-rig.mjs?v=13.0.0-beta.8';
import {drawFrame} from './wing-art.mjs?v=13.0.0-beta.8';
import {sampleEffectPreview} from './effect-picker-model.mjs?v=13.0.0-beta.8';
import {bitAssets} from './bit-assets.mjs?v=13.0.0-beta.8';
import {BitFrames,separateBits} from './bit-renderer.mjs?v=13.0.0-beta.8';
import {applyBitWaveDirections} from './bit-wave-direction.mjs?v=13.0.0-beta.8';
import {previewQualityConfiguration} from './quality.mjs?v=13.0.0-beta.8';
import {medicalPreviewPatient,paintMedicalPreviewPatient,releaseMedicalPreviewPatient} from './medical-preview-patient.mjs?v=13.0.0-beta.8';

/** One small local canvas; no PIXI textures, scene meshes, lights or document writes. */
export class EffectPreview {
  constructor(surface,model,onImage=()=>{}) {
    this.surface=surface;this.context=surface.getContext('2d');
    if(!this.context)throw new Error('Your browser could not create a 2D preview canvas.');
    const doc=surface.ownerDocument;
    this.bits=new BitFrames({makeCanvas:()=>doc.createElement('canvas')});
    this.resolution={low:384,medium:512,high:768}[previewQualityConfiguration(model.cfg).rigQuality]??512;
    const make=()=>{const c=doc.createElement('canvas');c.width=c.height=this.resolution;return c;};
    this.layers=Object.fromEntries(LAYER_NAMES.map(k=>[k,make()]));this.atlas=make();
    this.contexts=Object.fromEntries(Object.entries(this.layers).map(([k,c])=>[k,c.getContext('2d')]));
    this.model=model;this.frames=0;this.waveState=new Map();
    this.releaseBitAssets=bitAssets.acquire(()=>{if(!this.destroyed)onImage();});
    const src=model.token?.document.texture?.src;
    if(src) {
      const img=this.image=new doc.defaultView.Image();
      img.onload=()=>{if(!this.destroyed){this.imageReady=true;onImage();}};
      img.onerror=()=>{if(!this.destroyed){this.imageReady=false;onImage();}};
      img.src=src;
    }
  }

  draw(preview,elapsed) {
    if(this.destroyed)return;
    const cfg=previewQualityConfiguration(preview.cfg),snapshot=sampleEffectPreview({...preview,cfg},elapsed),v=snapshot.visual.profile,opts=snapshot.options;
    const f=this.context,size=this.surface.width,time=cfg.reduced?0:elapsed;
    // The backdrop is opaque, so it also replaces the clear.
    f.globalAlpha=1;f.drawImage(this.backdrop(size),0,0);
    // Fit token and wings together, including saved offsets, without cropping tips.
    const scale=opts.wingScale,extent=snapshot.structureAnimation?.artworkExtent??1,fitScale=scale*extent;
    const portrait=medicalPreviewPatient(this.surface,this.model.token,null,{x:0,y:0},{align:'anchor',targetSize:100}),bounds=portrait?.bounds;
    this.portraitAvailable=!!portrait;
    const x0=Math.min(-.5,bounds?bounds.x/100:0,opts.offsetX-fitScale/2),x1=Math.max(.5,bounds?(bounds.x+bounds.width)/100:0,opts.offsetX+fitScale/2);
    const y0=Math.min(-.5,bounds?bounds.y/100:0,opts.offsetY-fitScale/2),y1=Math.max(.5,bounds?(bounds.y+bounds.height)/100:0,opts.offsetY+fitScale/2);
    const unit=(size-40)/Math.max(x1-x0,y1-y0),tx=size/2-(x0+x1)*unit/2,ty=size/2-(y0+y1)*unit/2;
    const width=scale*unit,wx=tx+opts.offsetX*unit-width/2,wy=ty+opts.offsetY*unit-width/2;
    // Wing layers are composited at `width` pixels of this fixed backing store,
    // so more layer pixels are discarded (devicePixelRatio cannot add any).
    // Paint at that size in 64 px steps, never above the quality setting.
    const resolution=this.resolution=Math.min({low:384,medium:512,high:768}[cfg.rigQuality]??512,Math.max(256,Math.ceil(width/64)*64));
    if(this.atlas.width!==resolution)this.atlas.width=this.atlas.height=resolution;
    const pad=extent>1?Math.ceil(resolution*(extent-1)*.6/32)*32:0;
    const viewports=pad?Object.fromEntries(LAYER_NAMES.map(key=>[key,{x:-pad,y:-pad,width:resolution+pad*2,height:resolution+pad*2}])):null;
    for(const layer of Object.values(this.layers))if(layer.width!==resolution+pad*2)layer.width=layer.height=resolution+pad*2;
    const opacity=snapshot.rendering.active?opts.opacity*snapshot.effective.intensity:0;
    const phase=cfg.reduced||!cfg.wingbeats?0:time/1000*opts.wingSpeed/2.4*Math.PI*2;
    const rig=snapshot.rendering.renderer==='rig';
    const blend=rig?(cfg.wingRenderer==='rig'||snapshot.gems.rigRequired||snapshot.structureAnimation?.rigRequired||!cfg.energyPulses?1:Math.max(snapshot.visual.rigMix,Math.min(1,(1-Math.min(snapshot.poseAnimation.weights[0],snapshot.poseAnimation.tipWeights[0]))*5))):0;
    if(blend<1&&opacity) {
      drawFrame(this.atlas.getContext('2d'),Math.floor(phase/(2*Math.PI)*48)/48*2*Math.PI,resolution);
      f.globalAlpha=opacity*(1-blend)*Math.min(1,v.energy)*(1-.3*v.damage);f.drawImage(this.atlas,wx,wy,width,width);
    }
    if(rig&&opacity) {
      const {wings,bits}=separateBits(frameGeometry(snapshot.poseAnimation.weights,phase,v,snapshot));
      applyBitWaveDirections(bits,this.waveState,snapshot,time);
      this.bits.update(bits,cfg.bitQuality);
      paintLayers(this.contexts,wings,resolution,v,undefined,viewports);
      f.globalAlpha=opacity*blend*(v.renderOpacity??Math.min(1,v.energy));
      for(const k of LAYER_NAMES.filter(k=>!cfg.foregroundWings||k.endsWith('Rear'))){f.drawImage(this.layers[k],wx-pad/resolution*width,wy-pad/resolution*width,width*(1+pad*2/resolution),width*(1+pad*2/resolution));this.bits.drawLayer(f,k,wx,wy,width,width,f.globalAlpha);}
    }
    f.globalAlpha=1;
    if(portrait){f.save();f.translate(tx,ty);f.scale(unit/100,unit/100);paintMedicalPreviewPatient(f,portrait);f.restore();}
    else if(!this.model.token&&this.imageReady) {
      const img=this.image,ratio=img.naturalWidth/img.naturalHeight||1;
      const iw=ratio>=1?unit:unit*ratio,ih=ratio>=1?unit/ratio:unit;
      f.drawImage(img,tx-iw/2,ty-ih/2,iw,ih);
    } else {
      f.fillStyle='#211d2e';f.strokeStyle='#81718c';f.lineWidth=1.5;f.beginPath();f.arc(tx,ty,unit*.46,0,Math.PI*2);f.fill();f.stroke();
      f.fillStyle='#e9dfee';f.font=`${Math.max(13,unit*.23)}px system-ui`;f.textAlign='center';f.textBaseline='middle';
      f.fillText((this.model.token?.document.name??'Y').slice(0,1),tx,ty);
    }
    if(rig&&cfg.foregroundWings&&opacity) {
      f.globalAlpha=opacity*blend*(v.renderOpacity??Math.min(1,v.energy))*cfg.foregroundOpacity;
      for(const k of ['leftFront','rightFront']){f.drawImage(this.layers[k],wx-pad/resolution*width,wy-pad/resolution*width,width*(1+pad*2/resolution),width*(1+pad*2/resolution));this.bits.drawLayer(f,k,wx,wy,width,width,f.globalAlpha);}
    }
    f.globalAlpha=1;this.frames++;this.lastSnapshot=snapshot;
    return snapshot;
  }
  /** Gradient and grid are fixed per canvas size; paint them once. */
  backdrop(size) {
    if(this.background?.width===size)return this.background;
    const c=this.background??=this.surface.ownerDocument.createElement('canvas');c.width=c.height=size;
    const g=c.getContext('2d'),bg=g.createRadialGradient(size/2,size*.46,20,size/2,size/2,size*.7);
    bg.addColorStop(0,'#281c34');bg.addColorStop(1,'#0d0c14');g.fillStyle=bg;g.fillRect(0,0,size,size);
    g.strokeStyle='#ffffff08';g.lineWidth=1;
    for(let i=32;i<size;i+=48){g.beginPath();g.moveTo(i,0);g.lineTo(i,size);g.moveTo(0,i);g.lineTo(size,i);g.stroke();}
    return c;
  }
  destroy() {
    if(this.destroyed)return;this.destroyed=true;releaseMedicalPreviewPatient(this.surface);
    this.bits?.clear();this.bits=null;
    this.waveState?.clear();this.waveState=null;
    this.releaseBitAssets?.();this.releaseBitAssets=null;
    if(this.image){this.image.onload=this.image.onerror=null;this.image.src='';this.image=null;}
    for(const c of [...Object.values(this.layers??{}),this.atlas,this.background])if(c)c.width=c.height=1;
    this.layers={};this.contexts={};this.atlas=this.background=null;this.context=null;this.surface.width=this.surface.height=1;this.surface=null;this.model=null;
  }
}
