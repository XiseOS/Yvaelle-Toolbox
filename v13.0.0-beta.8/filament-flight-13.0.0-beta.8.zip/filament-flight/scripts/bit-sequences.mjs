/** Serializable, bounded choreography. This module has no Foundry dependencies. */
import {treatmentPhase,sampleTreatment,treatmentUpgradeEnabled,sampleTreatmentRelease} from './hardlight-treatment.mjs?v=13.0.0-beta.8';
import {sampleTreatmentTransit,treatmentTransitionVariant} from './hardlight-v7-medkit.mjs?v=13.0.0-beta.8';
import {sampleGroupFormation,sampleInstrumentTransit} from './bit-group-motion.mjs?v=13.0.0-beta.8';
import {BIT_GESTURES,sampleWorkGesture,sampleGestureReturn,gestureOrientation} from './bit-behaviour.mjs?v=13.0.0-beta.8';
import {BIT_CORE_STATES} from './bit-core-states.mjs?v=13.0.0-beta.8';
import {transitionTreatmentCore} from './treatment-core-motion.mjs?v=13.0.0-beta.8';
import {sampleCompactCurrents} from './compact-bit-formations.mjs?v=13.0.0-beta.8';
import {sampleBitTool} from './v8-scan-choreography.mjs?v=13.0.0-beta.8';
import {sampleWeightedTransit} from './v8-motion.mjs?v=13.0.0-beta.8';
export const BIT_IDS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);
export const BIT_KEY=Object.freeze({leftUpper:'left-gem-0',rightUpper:'right-gem-0',leftLower:'left-gem-1',rightLower:'right-gem-1'});
export const OUTCOMES=Object.freeze(['success','criticalSuccess','failure','criticalFailure']);
export const FORMATIONS=Object.freeze(['constellation','line','ring','arc','orbit']);
export const EFFECTS=Object.freeze(['none','diagnostic','lattice','stitch','pulse','sprite']);
const number=(v,d,min,max,label)=>{v=v??d;if(!Number.isFinite(v)||v<min||v>max)throw new Error(`${label} must be ${min}–${max}.`);return v;};
export const unit=n=>Math.max(0,Math.min(1,n));
export const ease=n=>{n=unit(n);return n*n*(3-2*n);};
export const EASINGS=Object.freeze({smooth:ease,linear:unit,easeIn:n=>unit(n)**2,easeOut:n=>1-(1-unit(n))**2});
export function chooseBits(input=2){
  if(Number.isInteger(input)&&input>=1&&input<=4)return BIT_IDS.slice(0,input);
  if(!Array.isArray(input)||!input.length||input.length>4||new Set(input).size!==input.length||input.some(id=>!BIT_IDS.includes(id)))throw new Error('Choose 1–4 bits or a list of unique bit station names.');
  return [...input];
}
function point(p={}){
  if(!p||typeof p!=='object'||Array.isArray(p))throw new Error('A destination must be a point.');
  const space=p.space??p.target??'target';if(!['source','target','world'].includes(space))throw new Error('Point space must be source, target or world.');
  return {space,x:number(p.x,0,-1000000,1000000,'Point x'),y:number(p.y,0,-1000000,1000000,'Point y')};
}
/** Compile nesting once when a macro submits it, never in the render loop. */
export function compileSequence(input){
  const obj=Array.isArray(input)?{steps:input}:input;
  if(!obj||typeof obj!=='object'||!Array.isArray(obj.steps)||!obj.steps.length)throw new Error('An animation needs a non-empty steps array.');
  const tracks=[];let count=0;
  const visit=(steps,start,depth=0,inherited=null)=>{
    if(depth>5)throw new Error('Animation nesting is limited to five levels.');
    let cursor=start;
    for(const raw of steps){
      if(++count>96)throw new Error('An animation is limited to 96 steps.');
      if(!raw||typeof raw!=='object')throw new Error('Invalid animation step.');
      const bits=raw.bits===undefined?inherited:chooseBits(raw.bits);
      if(raw.type==='parallel'){
        if(!Array.isArray(raw.steps)||!raw.steps.length)throw new Error('Parallel needs steps.');
        cursor=Math.max(...raw.steps.map(s=>visit(Array.isArray(s)?s:[s],cursor,depth+1,bits)));continue;
      }
      if(raw.type==='repeat'){
        const times=number(raw.times,1,1,12,'Repeat count');if(!Number.isInteger(times)||!Array.isArray(raw.steps))throw new Error('Repeat needs an integer count and steps.');
        for(let n=0;n<times;n++)cursor=visit(raw.steps,cursor,depth+1,bits);continue;
      }
      if(!['move','wait','formation','glow','effect','return','rotate','gesture','core','tool'].includes(raw.type))throw new Error(`Unknown animation step: ${raw.type}.`);
      const step={type:raw.type,at:cursor,duration:number(raw.duration,raw.type==='wait'?500:800,0,60000,'Step duration'),bits};
      step.easing=raw.easing??'smooth';if(!Object.hasOwn(EASINGS,step.easing))throw new Error('Unknown easing; choose smooth, linear, easeIn or easeOut.');
      if(raw.type==='move'){
        step.to=point(raw.to);step.arc=number(raw.arc,.2,-5,5,'Travel arc');
        if(raw.path!==undefined){if(!Array.isArray(raw.path)||raw.path.length>16)throw new Error('A path accepts at most 16 points.');step.path=raw.path.map(point);}
      }
      if(raw.type==='formation'){
        step.formation=raw.formation??'constellation';if(!FORMATIONS.includes(step.formation))throw new Error('Unknown bit formation.');
        step.to=point(raw.to);step.radius=number(raw.radius,.6,.05,8,'Formation radius');step.turns=number(raw.turns,1,-20,20,'Orbit turns');
      }
      if(raw.type==='gesture'){
        step.gesture=raw.gesture??'inspect';if(!Object.hasOwn(BIT_GESTURES,step.gesture))throw new Error('Unknown instrument gesture.');
        step.energy=number(raw.energy,.65,0,1,'Gesture energy');
      }
      if(raw.type==='core'){step.state=raw.state??'open';if(!Object.hasOwn(BIT_CORE_STATES,step.state)||step.state==='auto')throw new Error('Choose an explicit core state.');step.amount=number(raw.amount,1,0,1,'Core activity');}
      if(raw.type==='tool'){step.tool=raw.tool??'lens';if(!['lens','probe','plate','spark','none'].includes(step.tool))throw new Error('Unknown hardlight tool.');step.amount=number(raw.amount,.65,0,1,'Tool energy');}
      if(raw.type==='rotate')step.angle=number(raw.angle,0,-7200,7200,'Angle in degrees');
      if(raw.type==='glow'){
        step.strength=number(raw.strength,1,0,4,'Glow strength');if(raw.color!==undefined&&!/^#[\da-f]{6}$/i.test(raw.color))throw new Error('Use a six-digit hex glow colour.');step.color=raw.color??null;
        step.mode=raw.mode??'core';if(!['core','field'].includes(step.mode))throw new Error('Glow mode must be core or field.');
      }
      if(raw.type==='effect'){
        step.effect=raw.effect??'pulse';if(!EFFECTS.includes(step.effect))throw new Error('Unknown bit effect.');step.strength=number(raw.strength,1,0,3,'Effect strength');
        if(step.effect==='sprite'){
          if(typeof raw.asset!=='string'||raw.asset.length>300||! /^(modules|worlds|systems|icons)\/[\w /().-]+\.(png|webp|jpg|jpeg|svg)$/i.test(raw.asset)||raw.asset.split('/').includes('..'))throw new Error('Sprite assets must be a local modules/, worlds/, systems/ or icons/ image path.');
          step.asset=raw.asset;step.size=number(raw.size,1,.05,8,'Sprite size');step.angle=number(raw.angle,0,-7200,7200,'Sprite angle');
        }
      }
      tracks.push(step);cursor+=step.duration;
      if(cursor>600000)throw new Error('An animation cannot exceed ten minutes.');
    }
    return cursor;
  };
  const duration=visit(obj.steps,0);
  return {name:String(obj.name??'Custom animation').slice(0,60),tracks,duration};
}
export function animationOptions(input={}){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Animation options must be an object.');
  const conflict=input.conflict??'queue';if(!['queue','replace','reject'].includes(conflict))throw new Error('conflict must be queue, replace or reject.');
  return {bits:chooseBits(input.bits),priority:number(input.priority,50,0,1000,'Priority'),conflict,
    timeout:number(input.timeout,120000,1000,600000,'Timeout'),travelDuration:number(input.travelDuration,900,0,10000,'Travel duration'),
    returnDuration:number(input.returnDuration,800,0,10000,'Return duration')};
}
export function isFinished(event,now){if(event.conditionPausedAt!=null)return false;return event.status==='returning'?now>=event.returnAt+event.returnDuration:event.status==='finished';}
export function eventState(event,now){
  if(event.conditionPausedAt!=null)now=Math.min(now,event.conditionPausedAt);
  if(event.status==='queued')return {phase:'queued',progress:0};
  if(event.status==='returning')return {phase:'returning',progress:ease((now-event.returnAt)/Math.max(1,event.returnDuration))};
  const age=Math.max(0,now-event.started);
  if(event.kind==='utility')return {phase:age<event.travelDuration?'travel':event.utility.mode==='parkLight'?'illuminating':'examining',progress:ease(age/Math.max(1,event.travelDuration))};
  if(event.kind==='escort')return {phase:age<event.travelDuration?'travel':'escorting',progress:ease(age/Math.max(1,event.travelDuration))};
  if(event.kind==='treatment'){
    if(event.treatment)return treatmentPhase(event,now);
    if(event.finishAt!=null&&now>=event.finishAt)return {phase:'finishing',progress:ease((now-event.finishAt)/650)};
    return {phase:age<event.travelDuration?'travel':'holding',progress:ease(age/Math.max(1,event.travelDuration))};
  }
  return {phase:'playing',progress:unit(age/Math.max(1,event.sequence.duration))};
}
const mix=(a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});
function resolvePoint(p,context){
  if(p.space==='world')return {x:p.x,y:p.y};
  const base=p.space==='target'?context.target:context.source;
  return {x:base.x+p.x*context.size,y:base.y+p.y*context.size};
}
function formation(name,i,count,center,radius,clock=0){
  let angle=-Math.PI/2+(count===1?0:i/count*Math.PI*2);
  if(name==='line')return {x:center.x+(i-(count-1)/2)*radius,y:center.y};
  if(name==='arc')angle=-Math.PI*.85+(count===1?.5:i/(count-1))*Math.PI*.7;
  if(name==='constellation')return {x:center.x+(i%2?1:-1)*radius*.7,y:center.y+(i<2?-.15:.7)*radius};
  if(name==='orbit')angle+=clock;
  return {x:center.x+Math.cos(angle)*radius,y:center.y+Math.sin(angle)*radius*.7};
}
function travel(from,to,t,arc,size){const p=mix(from,to,t);p.y-=Math.sin(Math.PI*t)*arc*size;return p;}
/** Sample world-space positions; offsets in source/target space use source token size. */
export function sampleSequence(event,now,context){
  const state=eventState(event,now);
  // Active tools supply every field themselves. Do not prepare four discarded
  // default instruments before delegating the current display sample.
  if(event.kind==='utility'&&state.phase!=='queued'&&state.phase!=='returning')return {...sampleBitTool(event,now,context,state),utility:event.utility};
  const positions={},glows={},rotations={},effects=[],intents=[],focuses=[],depths={},coreStates={},tools={};
  for(const id of event.bits){positions[id]={...(context.origins[id]??context.source)};glows[id]={strength:1,color:null,mode:'core'};rotations[id]=event.sequence?.gesture?event.originRotations?.[id]??0:0;}
  if(state.phase==='queued')return {positions:{},glows,rotations,effects,intents,state};
  if(state.phase==='returning'){
    const medical=event.kind==='treatment'&&event.treatment&&treatmentUpgradeEnabled(context,event.treatment),variant=treatmentTransitionVariant(event,context.snapshot?.v7?.transitionVariants!==false);
    for(const id of event.bits){
      const from=event.returnFrom?.[id]??positions[id],to=context.returns[id]??context.source,reduced=context.snapshot?.effective?.reducedMotion;
      const weighty=context.snapshot?.v8Motion?.weightedTravel??event.utility?.weighty??event.weighty??false;
      const weighted=!medical&&!event.sequence?.gesture&&(weighty||event.returnRoutes?.[id])?sampleWeightedTransit(from,to,unit((now-event.returnAt)/Math.max(1,event.returnDuration)),{index:BIT_IDS.indexOf(id),size:context.size,duration:event.returnDuration,enabled:weighty,reduced,route:event.returnRoutes?.[id]}):null;
      positions[id]=medical?sampleTreatmentTransit(from,to,unit((now-event.returnAt)/Math.max(1,event.returnDuration)),{index:event.bits.indexOf(id),size:context.size,reduced,variant,returning:true,progressIsLinear:true,duration:event.returnDuration,fromVelocity:event.returnVelocities?.[id],sideBoundary:context.target.x}):event.sequence?.gesture?sampleGestureReturn(from,to,(now-event.returnAt)/Math.max(1,event.returnDuration),event.returnDuration,{fromVelocity:event.returnVelocities?.[id],toVelocity:context.returnVelocities?.[id],movingTarget:true,reduced}):weighted?{x:weighted.x,y:weighted.y}:sampleInstrumentTransit(from,to,state.progress,{index:BIT_IDS.indexOf(id),arc:.16,size:context.size,reduced});
      const fromRotation=event.returnRotations?.[id]??0,toRotation=context.returnRotations?.[id]??0;
      rotations[id]=fromRotation+Math.atan2(Math.sin(toRotation-fromRotation),Math.cos(toRotation-fromRotation))*state.progress+(weighted?.bank??0);
      const fromDepth=event.returnDepths?.[id]??event.originDepths?.[id]??-1;
      depths[id]=fromDepth+((context.returnDepths?.[id]??-1)-fromDepth)*state.progress;
      const before=event.returnGlows?.[id]??glows[id],after=context.returnGlows?.[id]??context.returnGlow??{strength:1,mode:'core',color:null};
      glows[id]={...before,strength:before.strength+(after.strength-before.strength)*state.progress,
        ...(state.progress>=1?after:{})};
    }
    for(const id of event.bits){
      const tool=event.returnTools?.[id];if(tool)tools[id]={...tool,amount:tool.amount*(1-ease(state.progress/.42))};
      const targetCore={state:'settling',amount:.6,progress:state.progress},duration=Math.max(.001,Math.min(240,event.returnDuration)/1000);
      const age=(Math.min(now,event.conditionPausedAt??now)-event.returnAt)/1000;
      coreStates[id]=event.kind==='treatment'&&(event.treatment?medical:treatmentUpgradeEnabled(context,event.treatment))?
        transitionTreatmentCore(event.returnCoreStates?.[id],targetCore,age/duration,{velocity:event.returnCoreVelocities?.[id],duration}):targetCore;
    }
    const release=event.kind==='treatment'?sampleTreatmentRelease(event,now,context):null;if(release)effects.push(release);
    return {positions,glows,rotations,effects,intents,depths,state,coreStates,tools,...(event.kind==='utility'?{utility:event.utility}:{}),...(release?{effectScale:(context.targetSize??context.size)*release.scale/context.size}: {})};
  }
  const age=Math.max(0,now-event.started);
  if(event.kind==='escort'){
    const cfg=context.snapshot?.gems??{},group=event.group??{};
    const stations=event.formationBits??event.bits,points=sampleGroupFormation(stations,group,cfg,now,context.snapshot);
    const angle=context.targetRotation??0,c=Math.cos(angle),s=Math.sin(angle),scale=(context.targetSize??context.size)*3.5/600,depths={};
    for(let i=0;i<event.bits.length;i++){
      const id=event.bits[i],p=points[stations.indexOf(id)],x=p.x*scale,y=(p.y-15)*scale,to={x:context.target.x+x*c-y*s,y:context.target.y+x*s+y*c};
      const weighty=context.snapshot?.v8Motion?.weightedTravel??event.weighty??false,weighted=weighty||event.travelRoutes?.[id]?sampleWeightedTransit(positions[id],to,unit(age/Math.max(1,event.travelDuration)),{index:BIT_IDS.indexOf(id),size:context.size,duration:event.travelDuration,enabled:weighty,reduced:context.snapshot?.effective?.reducedMotion,route:event.travelRoutes?.[id]}):null;
      positions[id]=weighted?{x:weighted.x,y:weighted.y}:sampleInstrumentTransit(positions[id],to,state.progress,{index:BIT_IDS.indexOf(id),arc:.2,size:context.size,reduced:context.snapshot?.effective?.reducedMotion});
      rotations[id]=p.angle+angle-(context.transform?.angle??0)-(context.orientations?.[id]??0)+(weighted?.bank??0);
      depths[id]=(event.originDepths?.[id]??-1)*(1-state.progress)+p.z*state.progress;
      glows[id]={strength:cfg.glow===false?0:(cfg.glowStrength??.4)*(p.expression?.energy??1),color:null,mode:cfg.glowMode??'core'};
      if(state.phase==='escorting'&&p.intent){
        const [tx,ty,tz]=p.intent.target,x=(tx??0)*scale,y=((ty??15)-15)*scale;
        intents.push({station:id,...positions[id],z:p.z,intent:{...p.intent,target:[context.target.x+x*c-y*s,context.target.y+x*s+y*c,tz]}});
      }
      if(state.phase==='escorting'&&p.focus){
        const [tx,ty,tz]=p.focus.target,x=(tx??0)*scale,y=((ty??15)-15)*scale;
        focuses.push({station:id,focus:{...p.focus,target:[context.target.x+x*c-y*s,context.target.y+x*s+y*c,tz]}});
      }
    }
    return {positions,glows,rotations,effects,intents,focuses,depths,state,tools:state.phase==='escorting'?Object.fromEntries(points.filter(p=>p.tool).map(p=>[p.station,p.tool])):Object.fromEntries(event.bits.map(id=>[id,{type:'travel',amount:.22*Math.sin(Math.PI*state.progress),progress:state.progress}])),coreStates:state.phase==='escorting'?Object.fromEntries(points.filter(p=>p.activity).map(p=>[p.station,p.activity])):Object.fromEntries(event.bits.map(id=>[id,{state:'encased',amount:Math.sin(Math.PI*state.progress)*.45,progress:state.progress}]))};
  }
  if(event.kind==='treatment'){
    if(event.treatment)return sampleTreatment(event,now,context,state,{positions,glows,rotations,effects});
    for(let i=0;i<event.bits.length;i++){
      const id=event.bits[i],destination=formation('constellation',i,event.bits.length,context.target,context.size*.60);
      destination.y+=Math.sin(age/1050+i*Math.PI)*context.size*.025;
      positions[id]=travel(positions[id],destination,state.phase==='travel'?state.progress:1,.55,context.size);
      glows[id].strength=state.phase==='travel'?1:1.6;
    }
    if(state.phase!=='travel')effects.push({effect:state.phase==='finishing'?(event.outcome==='success'||event.outcome==='criticalSuccess'?'stitch':'pulse'):'diagnostic',strength:1,progress:state.progress},
      ...(state.phase==='holding'?[{effect:'lattice',strength:.65,progress:(age/3500)%1}]:[]));
    return {positions,glows,rotations,effects,state};
  }
  for(const step of event.sequence.tracks){
    if(age<step.at)continue;
    const ids=(step.bits??event.bits).filter(id=>event.bits.includes(id)),p=(EASINGS[step.easing]??ease)((age-step.at)/Math.max(1,step.duration));
    if(step.type==='gesture'){
      const dedicated=!!event.sequence?.gesture,frameRotation=context.targetRotation??0,capturedRotation=event.gestureLayout?.rotation??frameRotation;
      const supporting=dedicated&&event.target===context.sourceId&&context.snapshot?.rendering?.wingsActive!==false&&!context.snapshot?.compactBits;
      const gesture=sampleWorkGesture(step.gesture,ids,unit((age-step.at)/Math.max(1,step.duration)),positions,context.target,context.targetSize??context.size,{energy:step.energy,reduced:context.snapshot?.effective?.reducedMotion,layout:dedicated?event.gestureLayout:null,rotation:frameRotation,originDepths:event.originDepths,duration:step.duration,supporting});
      Object.assign(positions,gesture.positions);Object.assign(glows,gesture.glows);Object.assign(coreStates,gesture.coreStates);Object.assign(tools,gesture.tools);
      for(const intent of gesture.intents){const previous=intents.findIndex(p=>p.station===intent.station);if(previous>=0)intents.splice(previous,1);intents.push(intent);}
      for(const id of ids){
        if(event.sequence?.gesture){
          // Dedicated directions inherit the displayed orientation and close
          // existing tools before preparing their own. Ordinary custom tracks
          // retain their original rotation and activity semantics.
          const frameDelta=Math.atan2(Math.sin(frameRotation-capturedRotation),Math.cos(frameRotation-capturedRotation)),basis=(context.transform?.angle??0)+(context.orientations?.[id]??0);
          const origin=(event.originRotations?.[id]??0)+(event.gestureLayout?.sourceRotation??context.transform?.angle??0)+(event.gestureLayout?.orientations?.[id]??context.orientations?.[id]??0)+frameDelta;
          const aim=frameRotation+gesture.rotations[id],handoff=ease(p/.35);
          rotations[id]=gestureOrientation(origin,aim,p)-basis;
          const tool=event.originTools?.[id],remaining=tool?.amount*(1-handoff);
          if(remaining>0&&!(tools[id]?.amount>remaining))tools[id]={...tool,amount:remaining};
          const core=event.originCoreStates?.[id];
          if(core&&p<.19)coreStates[id]={...core,amount:core.amount*(1-ease(p/.19))};
          else if(core&&coreStates[id])coreStates[id]={...coreStates[id],amount:coreStates[id].amount*ease((p-.19)/.16)};
        }else rotations[id]+=gesture.rotations[id];
        depths[id]=gesture.depths[id]??event.originDepths?.[id]??-.8;
      }
      const paths=sampleCompactCurrents(gesture.intents).map(v=>({points:v.points.map(q=>[(q[0]-context.target.x)/context.size*100,(q[1]-context.target.y)/context.size*100]),plane:v.points.at(-1)?.[2]<0?'rear':'front',alpha:v.strength,width:v.width,highlight:v.highlight}));
      if(paths.length)effects.push({effect:'token-field',id:'gesture',strength:1,color:'#ff62df',paths,bounds:{x:-130,y:-130,width:260,height:260},effectScale:1});
    }
    if(step.type==='core'&&age<=step.at+step.duration)for(const id of ids)coreStates[id]={state:step.state,amount:step.amount*Math.sin(Math.PI*p)**2,progress:p};
    if(step.type==='tool'&&age<=step.at+step.duration)for(const id of ids)if(step.tool!=='none')tools[id]={type:step.tool,amount:step.amount*Math.sin(Math.PI*p)**2,progress:p};
    if(step.type==='move')for(const id of ids){
      const path=[positions[id],...(step.path??[]).map(p=>resolvePoint(p,context)),resolvePoint(step.to,context)];
      const t=p*(path.length-1),segment=Math.min(path.length-2,Math.floor(t));
      positions[id]=travel(path[segment],path[segment+1],t-segment,step.arc,context.size);
    }
    if(step.type==='formation')for(let i=0;i<ids.length;i++){
      const to=formation(step.formation,i,ids.length,resolvePoint(step.to,context),step.radius*context.size,p*step.turns*Math.PI*2);
      positions[ids[i]]=mix(positions[ids[i]],to,p);
    }
    if(step.type==='return')for(const id of ids)positions[id]=travel(positions[id],context.returns[id]??context.source,p,.16,context.size);
    if(step.type==='rotate')for(const id of ids)rotations[id]+=(step.angle*Math.PI/180-rotations[id])*p;
    if(step.type==='glow')for(const id of ids)glows[id]={strength:glows[id].strength+(step.strength-glows[id].strength)*p,color:step.color,mode:step.mode};
    if(step.type==='effect'&&age<=step.at+step.duration)effects.push({effect:step.effect,strength:step.strength,progress:p,...(step.asset?{asset:step.asset,size:step.size,angle:step.angle}:{})});
  }
  return {positions,glows,rotations,effects,intents,depths,state,coreStates,tools};
}
