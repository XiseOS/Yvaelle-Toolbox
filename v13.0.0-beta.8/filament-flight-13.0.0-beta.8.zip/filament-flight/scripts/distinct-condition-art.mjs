/** Twenty-one independent v3.2 lattice treatments. All geometry is local to the
 * existing four wing layers. No filters, particles, document writes or textures.
 * Frame-wide timing is cached; untouched strands keep their original arrays. */
import {DISTINCT_CONDITION_IDS} from './effect-catalog.mjs?v=13.0.0-beta.8';
import {ease} from './poses.mjs?v=13.0.0-beta.8';
import {cubic} from './wing-art.mjs?v=13.0.0-beta.8';
import {fitEffectPoint} from './condition-art.mjs?v=13.0.0-beta.8';

const CATEGORY=new Map(Object.entries(DISTINCT_CONDITION_IDS).flatMap(([category,ids])=>ids.map(id=>[id,category])));
const GATES={irisWindows:'energy',pleatedFan:'instability',chainLace:'energy',loadBridges:'breaks',veilDelamination:'breaks',stressBlisters:'breaks',wanderingFocus:'instability',tipChase:'instability',alternatingBow:'instability',topologySwap:'glitches',polygonCompile:'glitches',rotatingTiles:'glitches',acceleratorLoops:'arcs',parallelRails:'arcs',edgeCombs:'arcs',groundTethers:'instability',shutterSlits:'energy',weightedDroplets:'instability',residualHorizon:'breaks',hangingLace:'breaks',foldedReliquary:'breaks'};
const TAU=Math.PI*2,frac=x=>x-Math.floor(x),unit=x=>Math.max(0,Math.min(1,x));
const root=u=>ease((u-.10)/.37),mix=(a,b,k)=>a.map((x,i)=>x+(b[i]-x)*k);
const phasePulse=(phase,a=.16,b=.57,c=.93)=>ease(phase/a)*(1-ease((phase-b)/(c-b)));
const quant=x=>Math.round(Math.max(0,Math.min(1.5,x))*16)/16;
const prepared=new WeakMap(),metadataCache=new Map();
const POINT_IDS=new Set(['irisWindows','pleatedFan','stressBlisters','wanderingFocus','tipChase','groundTethers','weightedDroplets','residualHorizon','hangingLace','foldedReliquary']);
export const isDistinctCondition=v=>CATEGORY.has(v?.variant?.id);
function params(v){
  const a=v?.variant,id=a?.id,gate=GATES[id];
  if(!CATEGORY.has(id)||!(a.amount>0)||v.gates?.[gate]===false||gate==='energy'&&v.energyPulses===false&&v.animated!==false)return null;
  const t=v.animated===false?0:(a.time??0),A=a.amount,m=v.variantMotion??1,frequency=a.frequency??1;
  const cached=prepared.get(v);if(cached&&cached.t===t&&cached.id===id&&cached.A===A&&cached.m===m&&cached.frequency===frequency)return cached;
  const f={id,t,A,m,frequency};
  // Bounded phase tables avoid repeated trigonometry for every sampled vertex.
  if(id==='pleatedFan')f.fold=Array.from({length:10},(_,i)=>phasePulse(frac(t*.145-i*.059)));
  if(id==='chainLace')f.links=Array.from({length:10},(_,i)=>.5+.5*Math.sin(t*1.17+i*Math.PI));
  if(id==='irisWindows')f.iris=[0,1,2].map(i=>({x:102+i*13,y:-88+i*91,rx:17+9*(.5+.5*Math.sin(t*.92+i*1.3)),ry:22+10*(.5+.5*Math.sin(t*.92+i*1.3))}));
  if(id==='wanderingFocus')f.focus=[145+25*Math.cos(t*.86),28+85*Math.sin(t*.63)];
  if(id==='polygonCompile')f.compile=phasePulse(frac(t*.16*frequency));
  prepared.set(v,f);return f;
}
function meta(id){
  let v=metadataCache.get(id);if(v)return v;
  const [kind,a,b]=id.split('-');v={kind,index:Number(a)||0,row:Number(b)||0,rib:kind==='rib',web:kind==='web'||kind==='cross',edge:kind==='edge'};
  if(metadataCache.size<512)metadataCache.set(id,v);return v;
}
function pushPath(out,strand,points,strength=strand.strength,extra={}){
  if(points.length<2||strength<=.025)return;
  out.push({...strand,...extra,points,strength:quant(strength)});
}
const bounded=p=>fitEffectPoint(p);

/** Shoulder roots remain fixed. Structural, not merely emissive, changes. */
export function distinctConditionPoint(point,u,side,v){
  const f=params(v);if(!f||u<=.10||!POINT_IDS.has(f.id))return point;
  const {id,A,t,m}=f,r=root(u),p=[...point],x=Math.abs(p[0])-27,y=p[1]+13,k=A*r;
  switch(id){
    case 'irisWindows': {
      // Move the surrounding strands away from real lenticular negative space.
      for(const o of f.iris){const dx=Math.abs(p[0])-o.x,dy=p[1]-o.y,d=Math.hypot(dx/o.rx,dy/o.ry);
        if(d<1.5&&d>.001){const gain=(1-ease((d-.45)/1.05))*k*.45;p[0]+=side*dx*gain;p[1]+=dy*gain;}}
      break;}
    case 'pleatedFan': {
      const angle=Math.atan2(y,Math.max(12,x)),band=Math.min(9,Math.max(0,(angle+1.35)/2.85*9)),index=Math.min(8,Math.floor(band)),q=band-index,fold=(f.fold[index]+(f.fold[index+1]-f.fold[index])*ease(q))*k*m;
      p[0]-=side*x*.25*fold;p[1]+=Math.sin(angle)*12*fold;p[2]-=35*fold;break;}
    case 'stressBlisters': {
      for(const [j,c] of [[0,-96],[1,28],[2,143]]){const dx=x-(77+j*11),dy=y-c,d=Math.hypot(dx/40,dy/34),vent=phasePulse(frac(t*.19+j*.27));
        if(d<1.8&&d>.001){const bump=(1-ease(d/1.8))*vent*k*m;p[0]+=side*dx*.55*bump;p[1]+=dy*.68*bump;p[2]-=16*bump;}}
      break;}
    case 'wanderingFocus': {
      const dx=Math.abs(p[0])-f.focus[0],dy=p[1]-f.focus[1],d=Math.hypot(dx/90,dy/95),pull=(1-ease(d))*k*m*.56;
      p[0]-=side*dx*pull;p[1]-=dy*pull;p[2]-=18*pull;break;}
    case 'tipChase': {
      const angle=Math.atan2(y,Math.max(5,x)),front=1.55*Math.sin(t*1.1),dist=(angle-front)/.34,crest=Math.exp(-dist*dist)*Math.sin(t*2.2-angle*1.6)*A*m*ease((u-.58)/.40);
      p[0]+=side*29*crest;p[1]+=17*crest*Math.sin(angle);break;}
    case 'groundTethers': p[1]+=k*(17+12*m*(.5+.5*Math.sin(t*.8+u*2)))*u;p[0]-=side*x*.12*k;break;
    case 'weightedDroplets': {
      const weight=(.5+.5*Math.cos(y*.037+x*.016))*(.7+.3*m*Math.sin(t*.8-y*.01));
      p[1]+=31*k*weight*u;p[0]-=side*x*.065*k;break;}
    case 'residualHorizon': {
      const target=[side*(27+x*.92),-13+u*23+Math.sin(u*9-t*.73)*3*m,-22,p[3]];
      p[0]+=(target[0]-p[0])*k;p[1]+=(target[1]-p[1])*k;break;}
    case 'hangingLace': {
      const target=[side*(27+23*Math.sin(u*Math.PI)+x*.16+7*m*Math.sin(t*.72+u*2)*u),-13+u*205+Math.abs(y)*.13,-22,p[3]];
      p[0]+=(target[0]-p[0])*k;p[1]+=(target[1]-p[1])*k;break;}
    case 'foldedReliquary': {
      // One angular envelope per wing, not several compact seed clusters.
      const fwidth=37+3*m*Math.sin(t*.67),height=62,angle=Math.atan2(y,x),q=(angle+1.45)/2.95;
      const tx=side*(27+45*u+fwidth*(1-Math.abs(2*q-1))*u),ty=-13+height*u*(q-.17);
      p[0]+=(tx-p[0])*k;p[1]+=(ty-p[1])*k;break;}
  }
  return bounded(p);
}

/** No per-segment fragments are emitted unless a genuine aperture/cut needs
 * one. Most treatments return one path per existing strand, at most two. */
export function distinctConditionPaths(strand,points,side,v){
  const f=params(v);if(!f)return null;
  const {id,A,m,t}=f,info=meta(strand.id),out=[];
  if(!info.rib&&!info.web&&!info.edge)return [{...strand,points}];
  // Match paintLayers' tenth-step strength quantization: invisible runs need
  // no depth splitting, comparison, bounds expansion or alpha-zero strokes.
  const whole=(pts=points,gain=1)=>{const strength=strand.strength*gain;return Math.round(strength*10)<=0?[]:[{...strand,points:pts,strength}];};
  if(id==='chainLace'&&info.web){
    if(info.kind==='cross')return whole(points,1-A);
    const a=points[0],b=points.at(-1),c=mix(a,b,.5),size=(5+6*f.links[info.index])*A,axis=info.row%2?1:-1;
    const link=[a,[c[0]+side*size,c[1]-size*.65*axis,c[2],c[3]],b,[c[0]-side*size,c[1]+size*.65*axis,c[2],c[3]],a];
    return whole(link.map(bounded),.65+.35*A);
  }
  if(id==='loadBridges'){
    if(info.rib&&[2,5,7].includes(info.index)){
      const mid=Math.floor(points.length*.51),a=points[Math.max(0,mid-3)],b=points[Math.min(points.length-1,mid+5)],sag=A*(22+7*m*Math.sin(t*.88+info.index));
      pushPath(out,strand,points.slice(0,mid-2));pushPath(out,strand,points.slice(mid+5));
      const bridge=Array.from({length:17},(_,j)=>{const q=j/16,p=mix(a,b,q);p[1]+=4*q*(1-q)*sag;return bounded(p);});
      pushPath(out,strand,bridge,strand.strength*.9,{id:`distinct-catenary-${info.index}`,width:.7});return out;
    }
    return whole(points,info.web?1-.48*A:1);
  }
  if(id==='veilDelamination'&&info.web){
    const peel=phasePulse(frac(t*.125))*A*m;
    return whole(points.map(p=>{const u=p[3]??.5,free=ease((u-.28)/.50),dx=side*22*peel*free,dy=29*peel*free,z=-24*peel*free;return bounded([p[0]+dx,p[1]+dy,p[2]+z,u]);}),1-.16*peel);
  }
  if(id==='alternatingBow'&&(info.rib||info.web)){
    const bend=(info.index%2?1:-1)*(0.35+.65*Math.sin(t*1.02))*A*m;
    return whole(points.map(p=>{const u=p[3]??.5,arc=Math.sin(Math.PI*u)*root(u);return bounded([p[0]+side*22*bend*arc,p[1]+11*bend*arc,p[2],u]);}));
  }
  if(id==='topologySwap'&&info.web){
    const shift=phasePulse(frac(t*.17*f.frequency-info.row*.037))*A*m*(v.gates?.displacement??1),sign=info.index%2?1:-1;
    return whole(points.map((p,j)=>{const q=j/(points.length-1),k=ease(q)*shift;return bounded([p[0]+side*sign*14*k,p[1]+sign*(19+info.index*2)*k,p[2],p[3]]);}));
  }
  if(id==='polygonCompile'&&(info.rib||info.edge)){
    const n=points.length-1,steps=3,compile=f.compile*A*m*(v.gates?.displacement??1);
    return whole(points.map((p,j)=>{const q=j/n*steps,index=Math.min(steps-1,Math.floor(q)),from=Math.round(index*n/steps),to=Math.round((index+1)*n/steps),chord=mix(points[from],points[to],q-index);return bounded(mix(p,chord,compile));}));
  }
  if(id==='rotatingTiles'&&info.web){
    const turn=phasePulse(frac(t*.14*f.frequency-info.index*.069-info.row*.033))*A*m*Math.PI*.5,mid=mix(points[0],points.at(-1),.5),sin=Math.sin(turn),cos=Math.cos(turn);
    return whole(points.map(p=>{const dx=p[0]-mid[0],dy=p[1]-mid[1];return bounded([mid[0]+dx*cos-dy*sin,mid[1]+dx*sin+dy*cos,p[2],p[3]]);}));
  }
  if(id==='parallelRails'&&info.web){
    if(info.kind==='cross')return whole(points,1-A);
    const align=phasePulse(frac(t*.20))*A*m,first=points[0],last=points.at(-1);
    return whole(points.map((p,j)=>{const q=j/(points.length-1),target=[first[0]+(last[0]-first[0])*q,first[1]+4*q,p[2],p[3]];return bounded(mix(p,target,align));}));
  }
  if(id==='hangingLace'&&info.web)return whole(points,1-.85*A);
  if(id==='foldedReliquary'&&info.web)return whole(points,1-.72*A);
  if(id==='residualHorizon'&&info.web)return whole(points,1-.89*A);
  if(id==='shutterSlits'&&info.web){
    const open=.18+.23*(.5+.5*Math.sin(t*.73-info.index*.39));
    const keep=info.row%3===0||frac(info.row*.21+t*.045)<open;
    return whole(points,keep?1:1-.94*A);
  }
  if(id==='irisWindows'||id==='stressBlisters'){
    let run=[];
    for(const p of points){let inside=false;
      if(id==='irisWindows'&&info.web)inside=f.iris.some(o=>((Math.abs(p[0])-o.x)/o.rx)**2+((p[1]-o.y)/o.ry)**2<A*A*.80);
      if(id==='stressBlisters'&&(info.web||info.rib))inside=[0,1,2].some(j=>{const vent=phasePulse(frac(t*.19+j*.27)),rx=13*vent*A,ry=11*vent*A;return rx>.2&&((Math.abs(p[0])-104-j*11)/rx)**2+((p[1]+13-(-96+j*119))/ry)**2<1;});
      if(inside){pushPath(out,strand,run);run=[];}else run.push(p);
    }
    pushPath(out,strand,run);return out;
  }
  return whole();
}

export function distinctConditionAccents(side,v,warp,ribs,growth=1,context=null){
  const f=params(v);if(!f||growth<=0)return [];
  const {id,A,m,t}=f,out=[],detail=v.effectDetail??'high';
  const at=(i,u)=>warp([...cubic(ribs[Math.max(0,Math.min(9,i))],u),u]);
  const off=(p,x,y,z=0)=>[p[0]+x,p[1]+y,p[2]+z,p[3]];
  const line=(name,points,width=.7,gain=.7,highlight=true)=>{
    if(gain*A<=.025||points.length<2||points.some(p=>(p[3]??1)>growth+.000001))return;
    const sampled=detail==='low'&&points.length>16?points.filter((_,i)=>i%2===0||i===points.length-1):points;
    out.push({id:`distinct-${id}-${name}`,points:sampled.map(bounded),width,strength:quant(A*gain),highlight});
  };
  const ellipse=(name,p,rx,ry,rotation=0,gain=.7,open=1)=>{
    const c=Math.cos(rotation),s=Math.sin(rotation),points=[];
    for(let j=0;j<=24;j++){const q=j/24*TAU*open,x=Math.cos(q)*rx,y=Math.sin(q)*ry;points.push(off(p,x*c-y*s,x*s+y*c));}
    line(name,points,.65,gain);
  };
  const curve=(a,b,sag,count=16)=>Array.from({length:count+1},(_,j)=>{const q=j/count,p=mix(a,b,q);p[1]+=4*q*(1-q)*sag;return p;});
  const controllerFeed=(target,index=0)=>{
    const p=context?.controllers?.[index]?.points?.[0];if(!p)return;
    line(`support-${index}`,[p,target],.5,.22,false);
  };
  switch(id){
    case 'irisWindows':
      for(const [i,o] of f.iris.entries()){
        const rx=o.rx*A,ry=o.ry*A;
        // Two pointed lens arcs, never a rosette or radial star.
        for(const sign of [-1,1])line(`lens-${i}-${sign}`,Array.from({length:25},(_,j)=>{const q=j/24;return warp([o.x+rx*sign*Math.sin(Math.PI*q),o.y+ry*(q*2-1),.62]);}),.8,.80);
      }break;
    case 'pleatedFan':
      for(const i of [1,3,5,7,9])line(`hinge-${i}`,Array.from({length:17},(_,j)=>at(i,.20+j*.048)),.65,.25+.45*f.fold[i]);
      break;
    case 'chainLace':
      for(const i of [1,4,7]){const a=at(i,.83),b=at(i+1,.83),c=mix(a,b,.5),d=(5+6*f.links[i])*A;
        line(`clasp-${i}`,[a,off(c,side*d,-d),b,off(c,-side*d,d),a],.85,.85);}
      break;
    case 'loadBridges':
      for(const i of [2,5,7]){const a=at(i-1,.56),b=at(i+1,.66);line(`load-${i}`,curve(a,b,17+8*m*Math.sin(t*.88+i)),.75,.8);}
      controllerFeed(at(5,.57),0);break;
    case 'veilDelamination': {
      const peel=phasePulse(frac(t*.125))*m,pts=[];
      for(let i=0;i<10;i++){const p=at(i,.88);pts.push(off(p,side*22*peel,29*peel,-24*peel));}
      line('free-selvedge',pts,.7,.8);
      for(const i of [0,4,9]){const p=at(i,.88);line(`attachment-${i}`,[p,off(p,side*22*peel,29*peel,-24*peel)],.5,.55);}
      break;}
    case 'stressBlisters':
      for(let j=0;j<3;j++){
        const vent=phasePulse(frac(t*.19+j*.27)),rx=20+12*vent,ry=16+14*vent;
        line(`vent-${j}`,Array.from({length:25},(_,k)=>{const q=k/24*TAU*.78;return warp([104+j*11+rx*Math.cos(q),-109+j*119+ry*Math.sin(q),.70]);}),.65,.45+.4*vent);
      }break;
    case 'wanderingFocus': {
      const p=warp([f.focus[0],f.focus[1],.6]);
      for(const i of [0,3,6,9]){const a=at(i,.8);line(`focus-tangent-${i}`,curve(a,p,(i-4)*3),.55,.45);}
      ellipse('focus-boundary',p,6,18,Math.sin(t*.52)*.5,.6,.75);break;}
    case 'tipChase': {
      const q=(.5+.5*Math.sin(t*1.1))*8,i=Math.floor(q),p=mix(at(i,.95),at(i+1,.95),q-i);
      line('leading-brace',[at(i,.87),off(p,side*9,0),at(i+1,.87)],1,.85);break;}
    case 'alternatingBow':
      for(let i=0;i<9;i+=2){const a=at(i,.57),b=at(i+1,.57),k=(.35+.65*Math.sin(t*1.02))*m;
        line(`bow-hold-${i}`,curve(a,b,11*k),.55,.55);}
      break;
    case 'topologySwap':
      for(const i of [1,4,7]){const q=phasePulse(frac(t*.17*f.frequency-i*.037)),a=at(i,.58),b=at(Math.min(9,i+2),.66);
        line(`address-${i}`,[a,off(mix(a,b,.5),side*13*q,0),b],.65,.25+.45*q);}
      break;
    case 'polygonCompile':
      for(const i of [0,4,9]){const p=at(i,.66),size=3+4*f.compile;
        line(`compile-bracket-${i}`,[off(p,-size,5),off(p,-size,-5),off(p,size,-5)],.75,.3+.55*f.compile);}
      break;
    case 'rotatingTiles':
      for(const [i,u] of [[1,.55],[4,.71],[7,.60]]){
        const p=at(i,u),turn=phasePulse(frac(t*.14*f.frequency-i*.069))*Math.PI*.5*m,cos=Math.cos(turn),sin=Math.sin(turn);
        line(`cell-${i}`,[[-8,-6],[8,-6],[8,6],[-8,6],[-8,-6]].map(([x,y])=>off(p,x*cos-y*sin,x*sin+y*cos)),.65,.65);
      }break;
    case 'acceleratorLoops':
      for(const [i,u] of [[1,.57],[4,.73],[7,.65]]){
        const p=at(i,Math.max(.12,Math.min(.94,u+.075*m*Math.sin(t*.9+i)))),rx=14,ry=31,rotation=side*(.35+i*.055),angle=t*1.65+i*2.1;
        ellipse(`track-${i}`,p,rx,ry,rotation,.58);
        const pts=[];for(let j=0;j<10;j++){const q=angle-j*.055,x=rx*Math.cos(q),y=ry*Math.sin(q);pts.push(off(p,x*Math.cos(rotation)-y*Math.sin(rotation),x*Math.sin(rotation)+y*Math.cos(rotation)));}
        line(`charge-${i}`,pts,1.3,.92);
      }break;
    case 'parallelRails': {
      const charge=phasePulse(frac(t*.20));
      for(const i of [1,3,5,7,9]){const a=at(i,.64),b=at(i,.94),outlet=off(b,side*(9+17*charge),4);
        line(`outlet-${i}`,[a,[b[0],a[1]+4,b[2],b[3]],outlet],.7,.5+.35*charge);}
      break;}
    case 'edgeCombs':
      for(let i=0;i<9;i++){
        const a=at(i,.96),b=at(i+1,.96),dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy)||1;
        const teeth=detail==='low'?1:detail==='medium'?2:3;
        for(let j=0;j<teeth;j++){const q=(j+.5)/teeth,p=mix(a,b,q),gain=.5+.5*Math.sin(t*1.5-i*.45-j*.2),span=4+13*gain;
          line(`tooth-${i}-${j}`,[p,off(p,-dy/length*span*side,dx/length*span*side)],.55,.35+.5*gain);}
      }break;
    case 'groundTethers':
      for(const i of [1,4,8]){
        const a=at(i,.78),b=off(at(i,.39),side*15,48),pull=.5+.5*Math.sin(t*.8+i*.3);
        line(`restraint-${i}`,curve(a,b,9+5*pull),.7,.65);
        line(`anchor-${i}`,[off(b,-5,-3),b,off(b,5,-3)],.75,.75);
      }break;
    case 'shutterSlits':
      for(const u of [.35,.55,.75,.91]){
        const q=.03+.06*(.5+.5*Math.sin(t*.73+u*5)),a=at(1,u),b=at(8,u);
        line(`shutter-${u}`,[a,at(4,Math.min(1,u+q)),b,at(4,Math.max(.05,u-q)),a],.55,.7);
      }break;
    case 'weightedDroplets':
      for(const [i,u] of [[1,.58],[3,.73],[6,.53],[8,.8]]){
        const p=at(i,u),size=4+2*Math.sin(t*.8+i);
        line(`drop-${i}`,Array.from({length:25},(_,j)=>{const q=j/24*TAU;return off(p,Math.sin(q)*size*(.65-.35*Math.cos(q)),(1-Math.cos(q))*size*1.6);}),.65,.8);
        line(`weighted-span-${i}`,[at(i,Math.max(.1,u-.075)),p],.65,.65);
      }break;
    case 'residualHorizon':
      for(const sign of [-1,1])line(`horizon-${sign}`,Array.from({length:29},(_,j)=>{const u=j/28,p=at(4,u);return off(p,0,sign*(1+3*Math.sin(Math.PI*u))*A);}),.7,.8);
      break;
    case 'hangingLace':
      // Three large elongated closed loops, not many articulated lozenges.
      for(let j=0;j<3;j++){
        const p=[side*(38+j*12),-2,-22,.95],sway=Math.sin(t*.72+j*.7)*6*m;
        line(`pendant-${j}`,Array.from({length:37},(_,i)=>{const q=i/36*TAU,drop=(1-Math.cos(q))*.5;return off(p,side*Math.sin(q)*(11+j*4)+sway*drop,drop*(145+j*25));}),.75,.7);
      }break;
    case 'foldedReliquary': {
      const p=[side*84,13,-22,.85],open=3+4*m*(.5+.5*Math.sin(t*.67));
      line('envelope',[[0,-34],[24+open,0],[0,45],[-12,0],[0,-34]].map(([x,y])=>off(p,side*x,y)),.9,.86);
      line('seam',[[0,-34],[open,10],[0,45]].map(([x,y])=>off(p,side*x,y)),.6,.65);
      break;}
  }
  return out;
}
