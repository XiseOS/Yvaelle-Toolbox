import {ID,VERSION} from './config.mjs?v=13.0.0-beta.8';
import {BIT_ATLAS,BIT_HD} from './bit-animation.mjs?v=13.0.0-beta.8';

/** Shared CPU cache for three SD atlases and up to 24 lazy HD track pages. It is leased
 * by live rigs/previews and releases images and scratch surfaces after the last
 * consumer closes. No PIXI textures, playback timers or video elements. */
export class BitAssetCache {
  constructor({retired=false,makeImage=()=>globalThis.Image?new Image():null,makeCanvas=()=>globalThis.document?.createElement('canvas'),route=p=>globalThis.foundry?.utils?.getRoute?.(p)??`/${p}`,clock=()=>globalThis.performance?.now?.()??Date.now()}={}){
    this.retired=retired;this.makeImage=makeImage;this.makeCanvas=makeCanvas;this.route=route;this.clock=clock;this.records=new Map();this.pages=new Map();this.failedPages=new Set();this.views=new Map();this.leases=new Set();this.listeners=new Set();this.revision=0;
  }
  acquire(onReady){const lease={};this.leases.add(lease);if(onReady)this.listeners.add(onReady);let released=false;
    return ()=>{if(released)return;released=true;this.leases.delete(lease);if(onReady)this.listeners.delete(onReady);if(!this.leases.size)this.clear();};
  }
  peek(design){return this.records.get(design)?.ready?this.records.get(design).image:null;}
  get(design){
    if(this.retired)return null;
    if(!BIT_ATLAS.designs.includes(design))return null;
    const existing=this.records.get(design);if(existing)return existing.ready?existing.image:null;
    if(!this.leases.size)return null;
    const image=this.makeImage();if(!image)return null;
    const record={image,ready:false,failed:false};this.records.set(design,record);
    const finish=ready=>{
      image.onload=image.onerror=null;
      if(this.records.get(design)!==record)return;
      record.ready=ready;record.failed=!ready;this.revision++;
      for(const callback of [...this.listeners]){try{callback();}catch{}}
    };
    image.onload=()=>finish((image.naturalWidth??image.width)===BIT_ATLAS.width*BIT_ATLAS.columns&&(image.naturalHeight??image.height)===BIT_ATLAS.height*BIT_ATLAS.rows);
    image.onerror=()=>finish(false);image.decoding='async';
    image.src=this.route(`modules/${ID}/assets/bits/${design}.webp`);
    return null;
  }
  getPage(design,row){
    if(this.retired)return null;
    if(!BIT_ATLAS.designs.includes(design)||!Number.isInteger(row)||row<0||row>=BIT_HD.tracks.length||!this.leases.size)return null;
    const key=`${design}/${row}`,now=this.clock(),existing=this.pages.get(key);
    if(existing){existing.used=now;return existing.ready?existing.image:null;}
    if(this.failedPages.has(key))return null;
    if(this.pages.size>=BIT_HD.maxPages){
      // Recently used or pending tracks are pinned. When many tokens need more
      // than the budget, their existing SD artwork remains available without
      // repeatedly evicting/reloading active HD tracks.
      const idle=[...this.pages.entries()].filter(([,r])=>r.ready&&now-r.used>BIT_HD.retainMs).sort((a,b)=>a[1].used-b[1].used)[0];
      if(!idle)return null;
      idle[1].image.onload=idle[1].image.onerror=null;idle[1].image.src='';this.pages.delete(idle[0]);
    }
    const image=this.makeImage();if(!image)return null;
    const record={image,ready:false,used:now};this.pages.set(key,record);
    const finish=ready=>{
      image.onload=image.onerror=null;if(this.pages.get(key)!==record)return;
      if(ready)record.ready=true;else{this.pages.delete(key);this.failedPages.add(key);image.src='';}
      this.revision++;for(const cb of [...this.listeners]){try{cb();}catch{}}
    };
    image.onload=()=>finish((image.naturalWidth??image.width)===BIT_HD.width*BIT_HD.columns&&(image.naturalHeight??image.height)===BIT_HD.height*BIT_HD.rows);
    image.onerror=()=>finish(false);image.decoding='async';
    image.src=this.route(`modules/${ID}/assets/bits/hd/${design}/${BIT_HD.tracks[row]}.webp`)+`?v=${VERSION}`;
    return null;
  }
  prepare(h){
    if(this.retired||!h?.animation?.layers)return null;
    const rows=new Set(h.animation.layers.map(l=>l.row));
    rows.add(BIT_ATLAS.components.energy);
    if(h.suspendedCore)rows.add(BIT_ATLAS.components.core);
    if(h.shutters)rows.add(BIT_ATLAS.components.shutters);
    if(h.metalHighlights&&h.highlightStrength>0)rows.add(BIT_ATLAS.components.sheen);
    const pages=new Map([...rows].map(row=>[row,this.getPage(h.design,row)]));
    if([...pages.values()].some(v=>!v))return null;
    return {width:BIT_HD.width,height:BIT_HD.height,frame:(row,index)=>({image:pages.get(row),
      x:index%BIT_HD.columns*BIT_HD.width,y:Math.floor(index/BIT_HD.columns)*BIT_HD.height})};
  }
  forQuality(quality='high'){
    if(quality!=='high')return this;
    if(!this.views.has(quality))this.views.set(quality,{get:design=>this.get(design),prepare:h=>this.prepare(h),scratch:(w,h)=>this.scratch(w,h)});
    return this.views.get(quality);
  }
  scratch(width=BIT_ATLAS.width,height=BIT_ATLAS.height){
    const hd=width===BIT_HD.width&&height===BIT_HD.height;
    if(!hd&&(width!==BIT_ATLAS.width||height!==BIT_ATLAS.height))return null;
    const key=hd?'hdSurface':'surface';if(this[key])return this[key];
    const canvas=this.makeCanvas();if(!canvas)return null;
    canvas.width=width;canvas.height=height;
    const context=canvas.getContext('2d');if(!context)return null;
    context.imageSmoothingEnabled=true;context.imageSmoothingQuality='high';
    return this[key]={canvas,context};
  }
  retry(){for(const [key,record] of this.records)if(record.failed){record.image.src='';this.records.delete(key);}this.failedPages.clear();this.revision++;}
  clear(){
    for(const record of [...this.records.values(),...this.pages.values()]){record.image.onload=record.image.onerror=null;record.image.src='';}
    this.records.clear();this.pages.clear();this.failedPages.clear();
    for(const key of ['surface','hdSurface']){if(this[key])this[key].canvas.width=this[key].canvas.height=1;this[key]=null;}
    this.revision++;
  }
}
// v4 procedural cores have no frame-atlas dependency. Keep the cache interface
// for older integrations while preventing requests for archived frame files.
export const bitAssets=new BitAssetCache({retired:true});
