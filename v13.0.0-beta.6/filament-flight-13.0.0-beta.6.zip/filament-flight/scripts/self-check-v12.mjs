/** Self-check (12.0.0-beta.4): the V12 part, one sub-section per v12 area.
 *
 * Like the V11 part, each sub-section plays the feature through the module's
 * own entry points and reads what the screen and the stage tree really show:
 *  - Setup: the four warps, the shield and landing styles and the thirteen
 *    cloak looks are registered; the wing sets are gone and a saved one is
 *    ignored; no landing is left waiting to recall her bits.
 *  - Warps: Flock, Starfall, Ribbon seam and Prism, three squares out and
 *    back: she arrives, the look plays for its own length, the warp layer is
 *    released, her wings never drop out for a frame.
 *  - Shield styles: Weave, Scale mail, Rotor and Wing wrap raised and
 *    lowered with her wings out; Scale mail and Rotor again with her wings
 *    away and her bits out.
 *  - Landing: each landing style from her flying height. Her wings and her
 *    bits are timed apart: the bits must stay out with her wings through the
 *    descent and go in as the wings close (beta.3 recalled them at the start
 *    of the descent, 2 to 3 s before the wings).
 *  - Cloaks: all thirteen looks on and off with her on the ground (the
 *    screen is still there, so it can be measured), four of them again in
 *    flight. Her presence on screen (against the same view without her) is
 *    read every frame: a look whose last pieces are still showing when its
 *    sweep ends is cut off there, and one that changes her the moment it
 *    begins or ends pops. Both are measured and judged.
 *  - Wheel (12.0.0-beta.5): the baked previews load for every warp, shield
 *    style, landing style and cloak, the right one plays on each gem, and a
 *    light left from the wheel is called back from the same gem.
 *  - Decoy (12.0.0-beta.6): her bits cast one, it stands (no repaint), its
 *    look is changed, it is struck and comes apart, her bits come home; then
 *    a decoy warp leaves her copy where she stood.
 *  - Sounds (12.0.0-beta.7): the v12 sound set's files are there; switched off
 *    nothing of it is asked for; switched on, a cloak, a Flock warp, a Scale
 *    mail shield and a cast decoy each ask for their own sound.
 *  - Cost: frames and the module's own time with each shield style held up,
 *    during two cloak sweeps and a warp, against her idle hover.
 * Real changes: her position (the warps), her shield flag, her cloak flag,
 * the three v12 pickers on her token, her flight state. Each is put back by
 * the part, and the run's final RESTORE rewrites every flag as it was.
 *
 * Every line is short: a PASS/CHECK/FAIL per item and a few numbers. */
import {ID} from './config.mjs?v=13.0.0-beta.6';
import {V11_KEYS,resolveV11,isOn,writeV11} from './v11/features.mjs?v=13.0.0-beta.6';
import {WARP_LOOKS} from './warp-looks.mjs?v=13.0.0-beta.6';
import {WARP_LOOKS_V12} from './v12/warp-looks.mjs?v=13.0.0-beta.6';
import {SHIELD_STYLES} from './v12/shield-styles.mjs?v=13.0.0-beta.6';
import {LANDING_STYLES,isRecall} from './v12/landing-recall.mjs?v=13.0.0-beta.6';
import {LOOKS,LOOK_NAMES,CLOAK,DRAIN} from './v11/invis.mjs?v=13.0.0-beta.6';
import {ScreenPresence} from './self-check-v11.mjs?v=13.0.0-beta.6';
import * as WM from './quick-wheel-model.mjs?v=13.0.0-beta.6';
import {SOUND_SLOTS,SOUND_PARTS,soundStats,SOUND_STYLE_DIRS,soundStyleOf} from './v12/sound-set.mjs?v=13.0.0-beta.6';
import {AUDIO_SLOTS} from './audio-model.mjs?v=13.0.0-beta.6';

export const V12_SCENARIOS=Object.freeze([
  ['v12setup','V12 · Setup','the four warps, the shield and landing styles and the 13 cloak looks are registered; the wing sets are gone; nothing left waiting'],
  ['v12warps','V12 · Warps','Flock, Starfall, Ribbon seam and Prism: 3 squares out and back each (other players see them)'],
  ['v12shields','V12 · Shield styles','Weave, Scale mail, Rotor and Wing wrap raised and lowered; Scale mail and Rotor again with her wings away'],
  ['v12landing','V12 · Landing','each landing style from her flying height: her wings and her bits timed apart (they must go in together)'],
  ['v12cloaks','V12 · Cloaks','all 13 looks on and off on the ground, four again in flight: a look that sticks, is cut off or pops is measured on screen'],
  ['v12wheel','V12 · Wheel','the animation previews load for every warp, shield style, landing style and cloak and play on their gems; a light is left and called back from its gem'],
  ['v12decoy','V12 · Decoy','her bits cast a decoy 3 squares away: it stands, changes look, is struck and comes apart; a decoy warp: she warps away and her copy stays; a second cast decoy, the menus on the map shown once, her bits called home from under it (other players see all of it)'],
  ['v12sounds','V12 · Sounds','the v12 sound set: the files of both styles are fetched; then with V12 sounds switched on for her a Flock warp, a Scale mail shield, a quick cloak and a cast decoy are played (other players see them; they are heard only where her sounds are on)'],
  ['v12perf','V12 · Cost','frames and module time with each shield style up, during two cloak sweeps and a warp, against her idle hover']
]);
export const V12_IDS=Object.freeze(V12_SCENARIOS.map(([id])=>id));
export const V12_HEAD=Object.freeze({v12setup:'V12 SETUP',v12warps:'V12 WARPS',v12shields:'V12 SHIELD STYLES',v12landing:'V12 LANDING',v12cloaks:'V12 CLOAKS',v12wheel:'V12 WHEEL',v12decoy:'V12 DECOY',v12sounds:'V12 SOUNDS',v12perf:'V12 COST'});
export const V12_LIMITS=Object.freeze({v12setup:20000,v12warps:110000,v12shields:120000,v12landing:140000,v12cloaks:300000,v12wheel:70000,v12decoy:120000,v12sounds:90000,v12perf:120000});
/** The flag a landing leaves while her bits wait for her wings (bit-actions.mjs). */
const LAND_FLAG='landBits';

const f0=n=>Number.isFinite(n)?String(Math.round(n)):'?',f1=n=>Number.isFinite(n)?(Math.round(n*10)/10).toFixed(1):'?',f2=n=>Number.isFinite(n)?(Math.round(n*100)/100).toFixed(2):'?';
const pct=n=>Number.isFinite(n)?`${(Math.round(n*1000)/10).toFixed(1)}%`:'?';
const stateOf=ctx=>ctx.manager?.states?.get?.(ctx.token)??null;
const median=a=>{if(!a.length)return 0;const s=[...a].sort((x,y)=>x-y);return s[Math.floor(s.length/2)];};
const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:NaN;
const flightFlag=ctx=>{try{return ctx.doc.getFlag?.(ID,'flight')??null;}catch{return null;}};
/** Put a v11-registry value on her token for the part, and back after it. */
async function setFor(ctx,res,key,value){
  const before=(()=>{try{return resolveV11(ctx.doc)[key];}catch{return undefined;}})();
  if(before===value)return;
  await writeV11(key,value,ctx.doc);
  if(!res.v12Put?.has(key)){(res.v12Put??=new Set()).add(key);res.restore(async()=>{try{if(resolveV11(ctx.doc)[key]!==before)await writeV11(key,before,ctx.doc);}catch{}});}
}
/** She is flying, settled, with her bits out (the part's restore puts the bits back as they were). */
async function flyingWithBits(ctx,res,H){
  await H.ensureFlying(ctx);ctx.check();
  if(!Object.keys(H.bitsDrawn(ctx)).length){
    try{await H.call.bitsOn(ctx,true);}catch{}
    if(!res.v12Bits){res.v12Bits=true;res.restore(async()=>{try{await H.call.bitsOn(ctx,false);await H.sleep(500);}catch{}});}
    await H.sleep(1400);
  }
  await H.settle(ctx,{timeout:1500});
}

/* ================================================================ 1. SETUP */
async function v12setup(ctx,res,H){
  const doc=ctx.doc,bad=[];let v={};try{v=resolveV11(doc);}catch(e){bad.push(`the registry does not resolve (${String(e?.message??e).slice(0,40)})`);}
  const warps=Object.keys(WARP_LOOKS_V12),lost=warps.filter(k=>!WARP_LOOKS[k]);
  res.lines.push(`warps: ${warps.map(k=>`${WARP_LOOKS[k]?.label??k} ${f1(WARP_LOOKS[k]?.duration)} s`).join(' · ')} · her warp ${String(H.setting('versionWarp')??'?')}`);
  if(lost.length)bad.push(`warp look(s) not registered: ${lost.join(', ')}`);
  const need=[['shieldStyles','shieldStyle',SHIELD_STYLES],['landingStyles','landingStyle',LANDING_STYLES]],rows=[];
  for(const [feat,pick,ids] of need){
    const has=V11_KEYS.has(feat)&&V11_KEYS.has(pick),opts=V11_KEYS.get(pick)?.item?.opts?.map(o=>o.id)??[];
    if(!has)bad.push(`${feat} is not in the registry`);else if(ids.some(id=>!opts.includes(id)))bad.push(`${pick} lacks ${ids.filter(id=>!opts.includes(id)).join(', ')}`);
    rows.push(`${pick} ${v[pick]??'?'} (${v[feat]===false?'switched off':'on'}; ${opts.length} choices)`);
  }
  res.lines.push(`${rows.join(' · ')} · cloak looks ${LOOKS.length}: invisible ${v.invisSpell??'?'}, skin ${v.invisSkin??'?'}, from the ${v.invisSweep??'?'}`);
  if(LOOKS.length!==13)bad.push(`${LOOKS.length} cloak looks (13 expected)`);
  // (12.0.0-beta.5) Cloak depth and the cloak warp
  if(V11_KEYS.has('cloakDepth')){const inv=ctx.manager?.v11?.invisibility;
    res.lines.push(`cloak depth ${v.cloakDepth===false?'switched off':'on'}: speed ${v.cloakSpeed??'?'} (${f1(inv?.speed?.(doc))} s) · a different look each time ${v['cloakDepth.cloakRotate']?'on':'off'} · an attack breaks her Fade ${v['cloakDepth.cloakAttack']?'on':'off'} · cloak warp ${String(H.setting('versionWarp'))==='cloak'?'is her default warp':'available'}`);
    if(typeof inv?.speed!=='function'||typeof inv?.noteAttack!=='function')bad.push('the invisibility runtime lacks Cloak depth');}
  else bad.push('cloakDepth is not in the registry');
  if(V11_KEYS.has('decoy'))res.lines.push(`decoy ${v.decoy===false?'switched off':'on'}: new ones look ${v.decoyLook??'?'} · one standing now: ${ctx.api?.decoy?.active?.(ctx.token)?'yes':'no'}`);
  else bad.push('decoy is not in the registry');
  if(V11_KEYS.has('soundSet'))res.lines.push(`v12 sounds ${v.soundSet===true?'ON':'off (as it comes)'} for her · ${SOUND_SLOTS.filter(id=>AUDIO_SLOTS[id]).length}/${SOUND_SLOTS.length} sounds registered`);
  else bad.push('the v12 sound set is not in the registry');
  if(SOUND_SLOTS.some(id=>!AUDIO_SLOTS[id]))bad.push('a sound of the v12 set is not a registered sound');
  // the wing sets (beta.1) were taken out in beta.4: no key, and a value saved by beta.1–3 changes nothing
  const saved=(()=>{try{return doc.getFlag?.(ID,'v11')?.wingSet;}catch{return undefined;}})();
  const gone=!V11_KEYS.has('wingSets')&&!V11_KEYS.has('wingSet')&&!('wingSet' in v);
  res.lines.push(`wing sets: ${gone?'gone':'STILL REGISTERED'}${saved?` · a saved set ("${saved}") is on her token and is ignored`:''}`);
  if(!gone)bad.push('the wing sets are still registered');
  // nothing waiting from an earlier landing
  const land=(()=>{try{return doc.getFlag?.(ID,LAND_FLAG);}catch{return null;}})(),fl=flightFlag(ctx);
  const live=land&&fl?.mode==='grounded'&&fl?.transition?.id===land.id&&H.now()<land.at+3000;
  res.lines.push(`a landing waiting to recall her bits: ${land?(live?'yes (she is landing now)':'YES, left over'):'none'}`);
  if(land&&!live)bad.push('a landing left its bit recall behind');
  if(bad.length)H.verdict(res,'FAIL',`v12 setup: ${bad.join('; ')}`);
  else H.verdict(res,'PASS',`the v12 features are registered: ${warps.length} warps, ${SHIELD_STYLES.length} shield styles, ${LANDING_STYLES.length} landing styles, ${LOOKS.length} cloak looks; no wing sets`);
}

/* ================================================================ 2. WARPS */
async function v12warps(ctx,res,H){
  const dir=H.freeDirection(ctx,3);if(!dir){res.skipped='no free spot 3 squares from her';return;}
  const range=Number(H.setting('warpRange'));if(range>0&&range<15){res.skipped=`warp range is ${range} ft (needs 15)`;return;}
  if(typeof H.warpTo!=='function'){res.skipped='no warp in this build';return;}
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1500});
  const home={x:ctx.doc.x,y:ctx.doc.y},c0={x:home.x+ctx.token.w/2,y:home.y+ctx.token.h/2};
  res.restore(async()=>{if(ctx.doc.x!==home.x||ctx.doc.y!==home.y){await ctx.doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(200);}});
  const near=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y)<ctx.grid*.6,bad=[],slow=[];
  for(const look of Object.keys(WARP_LOOKS_V12)){
    ctx.check();const L=WARP_LOOKS[look],name=L?.label??look,want=Number(L?.duration)||2;ctx.progress(`V12 warps: ${name}…`);
    const rec=ctx.recorder;rec.begin({overlay:{points:[c0,dir.toCenter]},ink:true});await H.sleep(250);
    const legs=[];
    for(const [to,goal] of [[dir.toCenter,dir.to],[c0,home]]){
      const at=H.now()-rec.t0;let err=null;
      try{await H.warpTo(ctx.token,to,{style:'wings',look});}catch(e){err=String(e?.message??e).slice(0,50);}
      const ok=!err&&await H.waitUntil(()=>near(ctx.doc,goal),6000,()=>H.sleep(40)),arrived=H.now()-rec.t0-at;
      await H.sleep(Math.max(900,want*1000+500-arrived));ctx.check();
      legs.push({at,end:H.now()-rec.t0,ok,arrived,err});
    }
    const frames=rec.end(),ref=H.stats(frames.filter(f=>f.t<legs[0].at).map(f=>f.ink??f.wing??0)).med||1;
    // the look on the warp layer: how long it was drawn in each leg, and that the layer is empty again after
    const shown=legs.map(l=>{const fs=frames.filter(f=>f.t>=l.at&&f.t<l.end&&(f.ov??0)>.0015);return fs.length?(fs.at(-1).t-l.at)/1000:0;});
    const left=frames.at(-1)?.ov??0;
    // her wings (on the board or as her copy on the warp layer) must not drop out for 1–3 frames
    const seen=frames.map(f=>Math.max((f.ink??f.wing??0)/ref,Math.min(1,(f.ov??0)*12)));let gaps=0;
    for(let i=1;i<seen.length;i++)if(seen[i-1]>=.25&&seen[i]<.03)for(let j=i;j<Math.min(seen.length-1,i+3);j++)if(seen[j+1]>=.25){gaps++;break;}
    const fs=H.frameStats(frames.filter(f=>f.t>=legs[0].at));
    res.lines.push(`${name.padEnd(12)} out ${legs[0].ok?`${f2(legs[0].arrived/1000)} s`:`NO${legs[0].err?` (${legs[0].err})`:''}`} · back ${legs[1].ok?`${f2(legs[1].arrived/1000)} s`:`NO${legs[1].err?` (${legs[1].err})`:''}`} · drawn ${f1(shown[0])}/${f1(shown[1])} s of ${f1(want)} · layer after ${left>.0015?'STILL DRAWN':'empty'} · wing gaps ${gaps} · frames ${f1(fs.med)}/${f1(fs.p95)}/${f0(fs.max)} ms`);
    if(!legs[0].ok||!legs[1].ok)bad.push(`${name}: she ${!legs[0].ok?'did not arrive':'did not come back'}`);
    else{
      if(Math.max(...shown)<=0)bad.push(`${name}: nothing was drawn on the warp layer`);
      else if(Math.min(...shown)<want*.6||Math.max(...shown)>want+1.2)slow.push(`${name} drew for ${f1(shown[0])}/${f1(shown[1])} s (its length is ${f1(want)} s)`);
      if(left>.0015)bad.push(`${name}: the warp layer was still drawn after it ended`);
      if(gaps)bad.push(`${name}: her wings dropped out for a frame ${gaps} time(s)`);
    }
    if(ctx.doc.x!==home.x||ctx.doc.y!==home.y){await ctx.doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(250);}
  }
  // (12.0.0-beta.5) the cloak warp: nothing on the warp layer; her cloak sweeps her away here and brings her back there
  const inv=ctx.manager?.v11?.invisibility,st=()=>inv?.status?.(ctx.token)??{};
  if(inv?.cloak&&isOn('invisLooks',ctx.doc)!==false&&st().phase==='solid'){
    ctx.check();ctx.progress('V12 warps: Cloak…');const legs=[];
    for(const [to,goal] of [[dir.toCenter,dir.to],[c0,home]]){
      const t0=H.now(),seen=new Set();let err=null,movedAt=null,hidAt=null;
      const run=H.warpTo(ctx.token,to,{style:'wings',look:'cloak'}).catch(e=>{err=String(e?.message??e).slice(0,50);});
      const done=await H.waitUntil(()=>{const s=st();seen.add(s.phase);if(hidAt==null&&s.phase==='held')hidAt=H.now()-t0;if(movedAt==null&&near(ctx.doc,goal))movedAt=H.now()-t0;return movedAt!=null&&s.phase==='solid'&&!s.filters;},9000,H.nextFrame);
      await run;legs.push({ok:done&&!err,err,movedAt,hidAt,total:H.now()-t0,seen:[...seen]});await H.sleep(500);
    }
    res.lines.push(`${'Cloak'.padEnd(12)} out ${legs[0].ok?`hidden ${f2(legs[0].hidAt/1000)} s, moved ${f2(legs[0].movedAt/1000)} s, back ${f2(legs[0].total/1000)} s`:`NO${legs[0].err?` (${legs[0].err})`:''}`} · back ${legs[1].ok?`${f2(legs[1].total/1000)} s`:`NO${legs[1].err?` (${legs[1].err})`:''}`} · phases ${legs[0].seen.join('>')}`);
    for(const l of legs){
      if(!l.ok){bad.push(`Cloak warp: she ${l.movedAt==null?'did not arrive':'did not come back solid'}`);break;}
      if(l.hidAt==null||l.movedAt<l.hidAt-40){bad.push('Cloak warp: she was moved before her cloak had closed over her');break;}
    }
    if(st().flag?.fade)bad.push('Cloak warp left her Fade on');
    if(ctx.doc.x!==home.x||ctx.doc.y!==home.y){await ctx.doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(250);}
  }else res.lines.push('Cloak        not played (invisibility looks are off, or she is cloaked already)');
  if(bad.length)H.verdict(res,'FAIL',`warps: ${bad.join('; ')}`);
  else H.verdict(res,'PASS','every warp takes her there and back, plays, and leaves nothing behind');
  if(slow.length)H.verdict(res,'CHECK',`warp length: ${slow.join('; ')}`);
}

/* ================================================================ 3. SHIELD STYLES */
async function v12shields(ctx,res,H){
  const doc=ctx.doc;if(!V11_KEYS.has('shieldStyle')){res.skipped='no shield styles in this build';return;}
  const raised0=doc.getFlag?.(ID,'wingShield')===true,S=()=>stateOf(ctx),surface=()=>S()?.feelFxRenderer?.shield?.mesh??null;
  res.restore(async()=>{try{if((doc.getFlag?.(ID,'wingShield')===true)!==raised0)await H.call.shield(ctx,raised0);}catch{}});
  await setFor(ctx,res,'shieldStyles',true);
  await flyingWithBits(ctx,res,H);
  if((S()?.feelShield??0)>.05){await H.call.shield(ctx,false);await H.sleep(1800);}
  const bad=[],odd=[];
  /** Raise and lower once; what the runtime and the surface did. */
  const play=async(style,label)=>{
    ctx.check();ctx.progress(`V12 shield styles: ${label}…`);
    await setFor(ctx,res,'shieldStyle',style);await H.sleep(250);
    const rec=ctx.recorder;rec.begin({ink:true});await H.sleep(150);
    const upAt=H.now()-rec.t0;await H.call.shield(ctx,true);
    let drawn=0,as=null,n=0;const end=H.now()+1900;
    while(H.now()<end){await H.nextFrame();n++;const m=surface();if(m&&m.visible!==false&&m.renderable!==false&&(m.alpha??1)>.02)drawn++;as=S()?.feelFx?.shield?.style??as;}
    const downAt=H.now()-rec.t0;await H.call.shield(ctx,false);await H.sleep(1900);
    const frames=rec.end(),up=frames.filter(f=>f.t>=upAt&&f.t<downAt),peak=Math.max(0,...up.map(f=>f.shield??0)),after=frames.at(-1)?.shield??0,fs=H.frameStats(up);
    const still=surface()?.visible===true&&(surface()?.alpha??1)>.02;
    // (Wing wrap draws her wings itself: her own wing layers hand over to it in one frame, by design; only moves count there)
    return {style,peak,after,drawn:n?drawn/n:0,as,fs,still,pops:H.findPops(frames,ctx.grid,style==='wingwrap'?{alphaKinds:false}:{})};
  };
  for(const style of SHIELD_STYLES){
    const r=await play(style,style);
    res.lines.push(`${style.padEnd(9)} wings out: up to ${f2(r.peak)} · surface drawn ${f0(r.drawn*100)}% of the time as ${r.as??'-'} · after lowering ${f2(r.after)}${r.still?' (surface STILL shown)':''} · frames ${f1(r.fs.med)}/${f1(r.fs.p95)}/${f0(r.fs.max)} ms`);
    if(r.peak<.5)bad.push(`${style} did not rise (peak ${f2(r.peak)})`);
    else{if(r.drawn<.3)bad.push(`${style}: its surface was not drawn`);if(r.as&&r.as!==style)bad.push(`${style} was painted as ${r.as}`);
      if(r.after>.05||r.still)odd.push(`${style} was still ${f2(r.after)} up 1.9 s after lowering`);}
    H.popVerdicts(res,r.pops,{name:style==='wingwrap'?' (wingwrap, moves only)':` (${style})`});
  }
  // wings away, bits out: Scale mail and Rotor still rise; the weave and Wing wrap need her wings
  ctx.check();ctx.progress('V12 shield styles: with her wings away…');
  let away=false;
  try{
    if(ctx.service?.transition)await ctx.service.transition('landing',doc,{keepBits:true});else await ctx.api.land(ctx.token,{keepBits:true});
    away=await H.waitUntil(()=>{const s=H.call.state(ctx);return s&&!s.airborne&&!s.transition?.active&&!(S()?.feelState?.alt>.3);},10000,()=>H.sleep(100));
    await H.sleep(900);
  }catch(e){res.lines.push(`(wings away: ${String(e?.message??e).slice(0,60)})`);}
  const bitsOut=Object.keys(H.bitsDrawn(ctx)).length;
  if(!away)odd.push('she did not land with her bits kept, so the wings-away case was not played');
  else if(!bitsOut)res.lines.push('wings away: her bits did not stay out after the landing, so Scale mail and Rotor have nothing to stand on (not played)');
  else for(const style of ['scalemail','rotor','weave']){
    const r=await play(style,`${style}, wings away`),expect=style!=='weave';
    res.lines.push(`${style.padEnd(9)} wings away (${bitsOut} bit(s) out): up to ${f2(r.peak)} · surface drawn ${f0(r.drawn*100)}% of the time${expect?'':' (the weave needs her wings: not expected to rise)'}`);
    if(expect&&(r.peak<.5||r.drawn<.3))bad.push(`${style} did not rise with her wings away (peak ${f2(r.peak)}, drawn ${f0(r.drawn*100)}%)`);
    if(!expect&&r.peak>=.5&&r.drawn>=.3)odd.push('the weave rose with her wings away');
  }
  if(bad.length)H.verdict(res,'FAIL',`shield styles: ${bad.join('; ')}`);
  else H.verdict(res,'PASS',`all four shield styles rise and lower${away&&bitsOut?'; Scale mail and Rotor rise with her wings away':''}`);
  if(odd.length)H.verdict(res,'CHECK',`shield styles: ${odd.join('; ')}`);
}

/* ================================================================ 4. LANDING */
async function v12landing(ctx,res,H){
  const doc=ctx.doc;if(!V11_KEYS.has('landingStyle')){res.skipped='no landing styles in this build';return;}
  await setFor(ctx,res,'landingStyles',true);
  const bad=[],odd=[],S=()=>stateOf(ctx);let judged=0;
  for(const style of LANDING_STYLES){
    ctx.check();ctx.progress(`V12 landing: ${style}…`);
    await setFor(ctx,res,'landingStyle',style);
    await flyingWithBits(ctx,res,H);
    const alt0=S()?.feelState?.alt,rec=ctx.recorder;rec.begin({ink:true});await H.sleep(350);
    const landAt=H.now()-rec.t0;let recall=null,waited=false,tr=null;
    await H.call.land(ctx);
    const watch=()=>{const f=flightFlag(ctx);tr??=f?.transition?.kind==='landing'?{...f.transition}:null;const r=S()?.snapshot?.formation?.recall;if(r?.style)recall=r.style;
      try{if(doc.getFlag?.(ID,LAND_FLAG))waited=true;}catch{}};
    const down=await H.waitUntil(()=>{watch();const s=H.call.state(ctx);return s&&!s.airborne&&!s.transition?.active&&!(S()?.feelState?.alt>.3);},12000,H.nextFrame);
    const t1=H.now();while(H.now()-t1<900){await H.nextFrame();watch();}
    const frames=rec.end(),L=frames.filter(f=>f.t>=landAt),pre=frames.filter(f=>f.t<landAt);
    const ink=f=>f.ink??f.wing??0,ref=median(pre.map(ink)),bitsOf=f=>Object.entries(f.tr??{}).filter(([k,v])=>k.startsWith('bit:')&&(v?.[2]??0)>.05).length,bits0=median(pre.map(bitsOf));
    let wingsLast=null,bitsLast=null;for(const f of L){if(ref>0&&ink(f)>=ref*.12)wingsLast=f;if(bitsOf(f)>0)bitsLast=f;}
    const downAt=L.find(f=>Number.isFinite(f.alt)&&f.alt<=Math.max(.5,(alt0||0)*.05)),sec=f=>f?(f.t-landAt)/1000:NaN;
    const tw=sec(wingsLast),tb=sec(bitsLast),gap=tw-tb,left=(()=>{try{return !!doc.getFlag?.(ID,LAND_FLAG);}catch{return false;}})(),dep=flightFlag(ctx)?.bitsDeployed;
    const want=isRecall(style),applied=!want||tr?.recall===style;
    res.lines.push(`${style.padEnd(9)} from ${f1(alt0)} ft: down ${f2(sec(downAt))} s · bits in ${bits0?`${f2(tb)} s`:'(none were out)'} · wings away ${f2(tw)} s${bits0?` · bits ${Math.abs(gap)<.05?'with':gap>0?`${f2(gap)} s before`:`${f2(-gap)} s after`} her wings`:''} · landing ${f2((tr?.duration??0)/1000)} s${tr?.foldMs?` (fold ${f2(tr.foldMs/1000)})`:''}${want?` · recall ${applied?(recall===style?'played':'NOT seen'):'not applied'}`:''} · bits waited ${waited?'yes':'no'}${left?' · recall flag LEFT':''}`);
    if(!down){bad.push(`${style}: she did not finish landing`);continue;}
    if(left)bad.push(`${style}: the waiting bit recall was left on her token`);
    if(dep===true&&bits0&&!bitsOf(L.at(-1)??{}))odd.push(`${style}: her bits are in but still marked deployed`);
    if(want&&!applied)odd.push(`${style} was not applied (reduced motion, the atlas renderer or landing folding off put the classic landing back)`);
    else if(want&&recall!==style)bad.push(`${style}: its recall was not played by the wing rig`);
    if(!wingsLast)odd.push(`${style}: her wings were not drawn during the landing`);
    else if(bits0){judged++;
      if(!bitsLast)bad.push(`${style}: her bits vanished the moment she began to land`);
      else if(gap>1)bad.push(`${style}: her bits were in ${f2(gap)} s before her wings closed`);
      else if(gap>.6)odd.push(`${style}: her bits were in ${f2(gap)} s before her wings closed`);
      else if(gap<-.5)odd.push(`${style}: her bits stayed ${f2(-gap)} s after her wings were away`);}
    H.popVerdicts(res,H.findPops(frames,ctx.grid),{name:` (${style})`});
  }
  if(bad.length)H.verdict(res,'FAIL',`landing: ${bad.join('; ')}`);
  else if(!judged)H.verdict(res,'CHECK','landing: her bits were never out, so their timing against her wings was not measured');
  else H.verdict(res,'PASS',`her bits go in with her wings on every landing (${judged} of ${LANDING_STYLES.length} measured)`);
  if(odd.length)H.verdict(res,'CHECK',`landing: ${odd.join('; ')}`);
}

/* ================================================================ 5. CLOAKS */
/** One half of a cloak (on or off) read from the screen: samples [t ms, presence 0..1 of her solid self, phase]. */
function readHalf(samples,endAt,on,before){
  if(samples.length<8||endAt==null)return {ok:false};
  const win=(a,b)=>samples.filter(s=>s[0]>=a&&s[0]<b).map(s=>s[1]);
  const pre=mean(win(endAt-260,endAt-20)),post=mean(win(endAt+140,endAt+520)),tail=win(endAt+140,endAt+520);
  const noise=median(tail.slice(1).map((v,i)=>Math.abs(v-tail[i])))||0;
  // what was still showing (on) or still missing (off) when the look handed over
  const cut=on?pre-post:post-pre;
  // the first frames after it began, against her just before
  // (within 90 ms of the command: a look that changes all of her as its filter goes on or comes off; a fast look's own first steps are later than that)
  const first=samples.filter(s=>s[0]<=90).slice(0,4).map(s=>s[1]),pop=Number.isFinite(before)&&first.length?Math.max(...first.map(v=>Math.abs(v-before))):NaN;
  const lim=Math.max(.04,noise*6),moved=samples.find(s=>Math.abs(s[1]-before)>lim),settled=[...samples].reverse().find(s=>s[0]<endAt&&Math.abs(s[1]-post)>lim);
  return {ok:true,len:endAt/1000,cut,pop,noise,from:moved?moved[0]/1000:NaN,to:settled?settled[0]/1000:NaN,post};
}
async function v12cloaks(ctx,res,H){
  const inv=ctx.manager?.v11?.invisibility,doc=ctx.doc;if(!inv?.cloak||!inv.status){res.skipped='no invisibility runtime in this build';return;}
  const st=()=>inv.status(ctx.token)??{};
  if(isOn('invisLooks',doc)===false){res.skipped='Invisibility looks are switched off for her';return;}
  const solid=async()=>{if(st().flag?.on||(st().phase&&st().phase!=='solid')){try{inv.cloak(ctx.token,false,{});}catch{}await H.waitUntil(()=>st().phase==='solid'&&!st().filters,7000,()=>H.sleep(100));}};
  res.restore(solid);
  const bad=[],odd=[],blind=[];let measured=0;
  /** Play looks on and off; judge=true where the screen holds still enough (she is on the ground). */
  const pass=async(label,looks,judge)=>{
    if(st().phase!=='solid'){res.lines.push(`${label}: skipped (she is ${st().phase??'not tracked'}: a cloak or invisibility is on)`);return;}
    const P=new ScreenPresence(ctx),screen=await P.start();
    if(!screen){blind.push(label);judge=false;}else measured+=looks.length;
    const tot=screen?(P.solid.token||0)+(P.solid.rest||0)||1:1,read=async()=>{if(!screen){await H.nextFrame();return null;}const s=await P.share();return s?((s.token??0)*(P.solid.token||0)+(s.rest??0)*(P.solid.rest||0))/tot:null;};
    res.lines.push(screen?`${label} (her presence on screen against the same view without her; cut = what was still showing when a look ended, or still missing when she came back; pop = the jump as it began):`
      :`${label} (the screen cannot be read here: ${P.note}; each look is played and its phases followed, nothing is measured):`);
    for(const look of looks){
      ctx.check();const name=LOOK_NAMES[look]??look;ctx.progress(`V12 cloaks: ${name} (${label})…`);
      const out={};
      for(const on of [true,false]){
        const classic=look==='classic',len=(classic?(on?DRAIN.hide:DRAIN.reveal)*DRAIN.done:inv.speed?.(doc)??CLOAK.sweep)*1000,goal=on?'held':'solid';
        const pre=[];for(let i=0;i<4;i++){const v=await read();if(v!=null)pre.push(v);}
        const before=mean(pre),samples=[],t0=H.now();let endAt=null,played=false;
        try{inv.cloak(ctx.token,on,on?{look}:{});}catch(e){bad.push(`${name}: ${String(e?.message??e).slice(0,50)}`);break;}
        while(H.now()-t0<len+2200){
          const v=await read(),s=st(),t=H.now()-t0;if(v!=null)samples.push([t,v,s.phase]);
          if(s.phase==='sweep'||s.phase==='drain')played=true;
          if(endAt==null&&t>120&&s.phase===goal)endAt=t;
          if(endAt!=null&&t>endAt+560)break;
        }
        out[on?'on':'off']={...readHalf(samples,endAt,on,before),len:endAt!=null?endAt/1000:NaN,played,reached:endAt!=null,variant:st().flag?.variant??null};
        await H.sleep(120);
      }
      const A=out.on,B=out.off;if(!A||!B)continue;
      const half=(r,word)=>!r.reached?`${word} NEVER settled`:!r.ok?`${word} ${f1(r.len)} s`:`${word} ${f1(r.len)} s, moves ${f1(r.from)}–${f1(r.to)} s, cut ${pct(r.cut)}, pop ${pct(r.pop)}`;
      res.lines.push(`  ${name.padEnd(16)} ${half(A,'on')} · ${half(B,'off')}${A.variant&&A.variant!==look?` · PLAYED AS ${A.variant}`:''}`);
      if(!A.reached||!B.reached){bad.push(`${name} did not ${!A.reached?'finish cloaking':'come back'}`);continue;}
      if(!A.played||!B.played)bad.push(`${name} did not play (${!A.played?'on':'off'})`);
      // (beta.6) each half lasts as long as her speed says: a length left over from a cloak warp or a broken Fade cut them short
      if(look!=='classic'){const want=inv.speed?.(doc)??CLOAK.sweep;for(const [r,word] of [[A,'cloaking'],[B,'coming back']])if(r.len<want*.8)bad.push(`${name} ${word} took ${f1(r.len)} s where ${f1(want)} s was set`);}
      if(A.variant&&A.variant!==look)bad.push(`${name} was played as ${LOOK_NAMES[A.variant]??A.variant}`);
      // a jump as a look begins is judged in flight too (it is over within a few frames: her wing beat does not reach it)
      if(!judge){for(const [r,word] of [[A,'cloaking'],[B,'coming back']])if(r.ok&&r.pop>Math.max(.08,r.noise*12))odd.push(`${name} ${word} (${label}): she changed by ${pct(r.pop)} the moment it began`);continue;}
      for(const [r,word] of [[A,'cloaking'],[B,'coming back']]){
        // (on the ground the screen holds still: with every piece finishing, the hand-over moves her by well under 1 %;
        // the looks as they were before beta.4 left 1.2 to 7.4 % of her to be cut off)
        if(!r.ok)continue;const floor=Math.max(.012,r.noise*8);
        if(r.cut>floor*2)bad.push(`${name} ${word}: ${pct(r.cut)} of her ${word==='cloaking'?'was still showing when it ended and was cut off':'was still missing when it ended and popped in'}`);
        else if(r.cut>floor)odd.push(`${name} ${word}: ${pct(r.cut)} of her changed at the hand-over`);
        if(r.pop>Math.max(.06,r.noise*12))odd.push(`${name} ${word}: she changed by ${pct(r.pop)} the moment it began`);
      }
    }
    await solid();
  };
  // in flight first (her wings, bits and shadow are part of it; the beat of her wings moves the numbers, so nothing is judged from them)
  await flyingWithBits(ctx,res,H);
  await pass('in flight',['c','plumage','aurora','classic'],false);
  // (12.0.0-beta.5) Cloak depth: her speed, a different look each time, an attack breaking her Fade
  if(V11_KEYS.has('cloakDepth')&&typeof inv.speed==='function'&&st().phase==='solid'){
    ctx.check();ctx.progress('V12 cloaks: cloak depth…');
    const until=async(goal,ms)=>{const t0=H.now();const ok=await H.waitUntil(()=>st().phase===goal&&!st().filters,ms,H.nextFrame);return ok?(H.now()-t0)/1000:NaN;};
    await setFor(ctx,res,'cloakDepth',true);
    // speed: Swift is 1.4 s each way
    await setFor(ctx,res,'cloakSpeed','swift');const want=inv.speed(doc);
    inv.cloak(ctx.token,true,{look:'c'});const up=await until('held',want*1000+2500);inv.cloak(ctx.token,false,{});const dn=await until('solid',want*1000+2500);
    await setFor(ctx,res,'cloakSpeed','normal');
    // rotation: two Fades in a row wear two different looks
    const api=ctx.api,worn=[];
    if(api?.v11?.fade){
      await setFor(ctx,res,'cloakDepth.cloakRotate',true);await setFor(ctx,res,'cloakSpeed','swift');
      for(let i=0;i<2;i++){await api.v11.fade(true,{token:ctx.token});await H.sleep(120);worn.push(st().flag?.variant??'?');await until('held',5000);await api.v11.fade(false,{token:ctx.token});await until('solid',5000);}
      await setFor(ctx,res,'cloakDepth.cloakRotate',false);await setFor(ctx,res,'cloakSpeed','normal');
    }
    // an attack: her own attack roll while she is faded brings her straight back; a secret roll does not
    let hit='-';
    if(api?.v11?.fade&&typeof inv.noteAttack==='function'){
      await setFor(ctx,res,'cloakDepth.cloakAttack',true);
      await api.v11.fade(true,{token:ctx.token});await until('held',5000);
      const msg=x=>({flags:{pf2e:{context:{type:'attack-roll'}}},speaker:{token:ctx.token.id??doc.id},whisper:[],blind:false,...x});
      const secret=inv.noteAttack(msg({whisper:['someone']})),shown=inv.noteAttack(msg({})),back=await until('solid',4000);
      hit=`a secret roll ${secret?'BROKE it':'left her faded'} · an open roll ${shown?`broke it, solid again in ${f2(back)} s`:'did NOT break it'}`;
      if(secret)bad.push('a secret attack roll broke her Fade');if(!shown||!(back<2.5))bad.push('her attack did not break her Fade');
      if(st().flag?.fade)bad.push('her Fade stayed switched on after the attack');
      await setFor(ctx,res,'cloakDepth.cloakAttack',false);await solid();
    }
    await setFor(ctx,res,'cloakSpeed','normal');
    res.lines.push(`cloak depth: Swift ${f2(up)} s on, ${f2(dn)} s off (${f1(want)} s each expected) · two Fades with "a different look each time": ${worn.join(' then ')||'-'} · ${hit}`);
    if(!(Math.abs(up-want)<.6)||!(Math.abs(dn-want)<.6))bad.push(`the Swift cloak took ${f2(up)}/${f2(dn)} s (expected ${f1(want)} s)`);
    if(worn.length===2&&(worn[0]===worn[1]||worn.includes('?')))bad.push(`two Fades in a row wore ${worn.join(' and ')} with rotation on`);
  }
  // then on the ground with her wings away: the screen holds still, every look, judged
  ctx.check();ctx.progress('V12 cloaks: landing her…');
  await H.call.land(ctx);
  const down=await H.waitUntil(()=>{const s=H.call.state(ctx);return s&&!s.airborne&&!s.transition?.active&&!(stateOf(ctx)?.feelState?.alt>.3);},12000,()=>H.sleep(100));
  await H.sleep(1200);
  if(!down)odd.push('she did not land, so the looks were not measured on the ground');
  else await pass('on the ground',LOOKS.filter(k=>k!=='classic').concat('classic'),true);
  if(bad.length)H.verdict(res,'FAIL',`cloaks: ${bad.join('; ')}`);
  else if(down&&!blind.includes('on the ground'))H.verdict(res,'PASS',`every cloak look plays as itself, finishes before its sweep ends and hands over cleanly (${LOOKS.length} looks)`);
  else H.verdict(res,'PASS',`every cloak look played as itself and settled (${LOOKS.length} looks)`);
  if(blind.length)odd.push(`the screen could not be read ${blind.join(' or ')}, so a look that sticks or is cut off was not measured`);
  if(odd.length)H.verdict(res,'CHECK',`cloaks: ${odd.join('; ')}`);
}

/* ================================================================ 6. WHEEL */
async function v12wheel(ctx,res,H){
  const qw=ctx.api?.quickWheel,doc=ctx.doc;if(!qw?.open||!qw.instance){res.skipped='no quick wheel in this build';return;}
  if(isOn('nestedWheel',null)===false){res.skipped='the nested wheel is off (Settings › Emotes & wheel)';return;}
  if(qw.instance()){res.skipped='the wheel is open';return;}
  await flyingWithBits(ctx,res,H);
  res.restore(()=>{try{qw.close();}catch{}});
  if(!qw.open()||!qw.instance()){H.verdict(res,'FAIL','the quick wheel did not open (pin her or select her token)');return;}
  const w=qw.instance(),host=w.host,bad=[],odd=[];w.save=()=>{};res.restore(()=>{try{delete w.save;}catch{}});
  await H.waitUntil(()=>w.root?.classList.contains('open'),1500);
  if(typeof host?.previewOf!=='function'||typeof host?.preview!=='function'){H.verdict(res,'FAIL','this wheel has no animation previews');try{qw.close();}catch{}return;}
  // 1. every kind's strip loads when first asked for, and holds every choice
  const kinds={warp:['threaded','seam','flicker',...Object.keys(WARP_LOOKS),'cloak'],shield:[...SHIELD_STYLES],landing:[...LANDING_STYLES],cloak:[...LOOKS]},rows=[];
  for(const [kind,ids] of Object.entries(kinds)){
    ctx.check();const t0=H.now();host.preview(ids[0],kind);
    const ok=await H.waitUntil(()=>!!host.preview(ids[0],kind),6000,()=>H.sleep(50)),ms=H.now()-t0;
    if(!ok){bad.push(`the ${kind} previews did not load`);rows.push(`${kind} NOT loaded`);continue;}
    const got=ids.map(id=>[id,host.preview(id,kind)]),lost=got.filter(([,p])=>!p).map(([id])=>id),ns=got.filter(([,p])=>p).map(([,p])=>p.n);
    rows.push(`${kind} ${ids.length-lost.length}/${ids.length} in ${f0(ms)} ms (${Math.min(...ns)}–${Math.max(...ns)} frames)`);
    if(lost.length)bad.push(`no ${kind} preview for ${lost.join(', ')}`);
  }
  res.lines.push(`previews: ${rows.join(' · ')}`);
  // 2. which gem plays which
  let v={};try{v=resolveV11(doc);}catch{}
  const key=slot=>{const p=host.previewOf(slot);return p?`${p.kind}:${p.id}`:'none';};
  const shows=[['warp flock',key({action:'warp',value:'flock'}),'warp:flock'],['shield',key({action:'shield'}),`shield:${v.shieldStyles!==false?v.shieldStyle:'weave'}`],
    ['fade',key({action:'fade'}),v.invisLooks===false?'none':`cloak:${v.invisSkin}`],['land',key({action:'flight'}),`landing:${v.landingStyles!==false?v.landingStyle:'classic'}`],['light',key({action:'light'}),'none']];
  res.lines.push(`on the gems: ${shows.map(([n,got])=>`${n} → ${got}`).join(' · ')}`);
  for(const [n,got,want] of shows)if(got!==want)bad.push(`the ${n} gem shows ${got} (expected ${want})`);
  // 3. the plaque's cameo draws while such a gem is pointed at
  let cameo='-';
  try{
    const door=w.doors?['actions','her','bits']:['her','light'];let it=null,lvl=null;
    for(const d of door){if(!(w.mainItems??[]).some(i=>i.cat===d))continue;w.enter(d);await H.nextFrame();await H.sleep(140);
      it=(w.subItems??[]).find(i=>(i.kind==='leaf'||i.kind==='lane')&&i.slot&&host.previewOf(i.slot));if(it){lvl=d;break;}w.back();await H.sleep(160);}
    if(!it)cameo='no gem with a preview on her rings (nothing to point at)';
    else{
      w.setPick(it);const t0=H.now();let ink=0;
      while(H.now()-t0<2500&&!ink){await H.nextFrame();try{const c=w.cameo,d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;for(let i=3;i<d.length;i+=16)if(d[i]>8)ink++;}catch{ink=-1;break;}}
      const shown=w.root?.classList.contains('emo');
      cameo=`${it.slot.action}${it.slot.value?` ${it.slot.value}`:''} on ${lvl}: ${ink>0?`drawn after ${f0(H.now()-t0)} ms`:ink<0?'could not be read':'NOT drawn'}${shown?'':' · the plaque did not make room for it'}`;
      if(ink===0||!shown)bad.push(`the preview was not shown for the ${it.slot.action} gem`);
      w.setPick(null);w.back();await H.sleep(160);
    }
  }catch(e){cameo=`error ${String(e?.message??e).slice(0,60)}`;bad.push(`pointing at a gem failed: ${String(e?.message??e).slice(0,50)}`);}
  res.lines.push(`cameo: ${cameo} · key tapped twice repeats the last action: ${typeof w.again==='function'?'yes':'NO'}`);
  if(typeof w.again!=='function')bad.push('the wheel has no double-tap');
  // 4. Leave a light, then the same gem calls it back
  const bits=H.call.bits(ctx),dir=H.freeDirection(ctx,2),slot={action:'parkLight',value:'point'},other={action:'parkLight',value:'target'};
  const out=()=>{try{return (ctx.api.getBitToolState?.(ctx.token)?.tasks??[]).filter(t=>t.mode==='parkLight'&&t.editable!==false).length;}catch{return 0;}};
  if(!bits?.startTool||!dir)res.lines.push(`Leave a light: not played (${!dir?'no free spot 2 squares from her':'this build has no bit tools'})`);
  else{
    ctx.check();ctx.progress('V12 wheel: leaving a light and calling it back…');
    let handle=null,err=null;try{handle=await bits.startTool(doc,{kind:'parkLight',point:{...dir.toCenter},bits:1});}catch(e){err=String(e?.message??e).slice(0,70);}
    res.restore(async()=>{try{if(out())await bits.stopTool(doc,handle?.id?{id:handle.id}:undefined);await H.waitUntil(()=>!H.call.bitState(ctx)?.busy,5000,()=>H.sleep(100));}catch{}});
    if(err){res.lines.push(`Leave a light: could not start (${err})`);odd.push(`a light could not be left: ${err}`);}
    else{
      await H.sleep(2300);
      const d1=host.describe(slot)??{},d1o=host.describe(other)??{},free=WM.unavailable(slot,WM.context({...host.state(),bitsOut:false}));
      let ran=null;try{await host.run(slot);}catch(e){ran=String(e?.message??e).slice(0,60);}
      const back=await H.waitUntil(()=>!out()&&!H.call.bitState(ctx)?.busy,7000,()=>H.sleep(100));await H.sleep(500);
      const d2=host.describe(slot)??{};
      res.lines.push(`Leave a light: left ${out()||back?'yes':'NO'} · its gem then reads "${d1.label}" (${d1.active?'lit':'NOT lit'}${free?`, greyed: ${free}`:''}) · the target gem "${d1o.label}" · pressed: ${ran??(back?'the light came back':'the light did NOT come back')} · after "${d2.label}"`);
      if(!/Call the light/.test(d1.label??'')||!d1.active)bad.push('the gem did not turn into "Call the light back" while its light was out');
      if(free)bad.push(`the gem was greyed while its light was out (${free})`);
      if(/Call the light/.test(d1o.label??''))bad.push('the target gem offered to call back a light left at a point');
      if(ran||!back)bad.push(`the light was not called back${ran?` (${ran})`:''}`);
      if(back&&!/Leave a light/.test(d2.label??''))bad.push('the gem did not go back to "Leave a light"');
    }
  }
  try{delete w.save;qw.close();}catch{}await H.sleep(350);
  if(bad.length)H.verdict(res,'FAIL',`wheel: ${bad.join('; ')}`);
  else H.verdict(res,'PASS','the wheel previews every warp, shield style, landing style and cloak, and a light left from it is called back from the same gem');
  if(odd.length)H.verdict(res,'CHECK',`wheel: ${odd.join('; ')}`);
}

/* ================================================================ 7. DECOY */
async function v12decoy(ctx,res,H){
  const D=ctx.api?.decoy,rt=ctx.manager?.v12?.decoy,doc=ctx.doc,token=ctx.token;if(!D?.place||!rt){res.skipped='no Decoy in this build';return;}
  if(isOn('decoy',doc)===false){res.skipped='the Decoy is switched off for her';return;}
  if(doc.getFlag?.(ID,'decoy')){res.skipped='a decoy of hers is standing';return;}
  const dir=H.freeDirection(ctx,3);if(!dir){res.skipped='no free spot 3 squares from her';return;}
  const range=Number(H.setting('warpRange')),canWarp=!(range>0&&range<15)&&!ctx.paused;
  await flyingWithBits(ctx,res,H);
  const home={x:doc.x,y:doc.y},c0={x:home.x+token.w/2,y:home.y+token.h/2},bad=[],odd=[];
  const st=()=>D.status(token),tasks=()=>{try{return (ctx.api.getBitToolState?.(token)?.tasks??[]).filter(t=>t.mode==='parkLight').map(t=>t.id);}catch{return [];}};
  res.restore(async()=>{try{const f=doc.getFlag?.(ID,'decoy');if(f){await rt.clear(doc,f);}await H.waitUntil(()=>!H.call.bitState(ctx)?.busy,5000,()=>H.sleep(100));}catch{}
    if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(200);}});
  const until=(test,ms)=>H.waitUntil(test,ms,H.nextFrame),mesh=()=>rt.records.get(token)?.mesh??null,shown=()=>{const m=mesh();return !!m&&m.visible!==false&&(m.alpha??0)>.3;};
  const quiet=async ms=>{const p0=rt.stats.paints;await H.sleep(ms);return rt.stats.paints-p0;};
  // 1. cast by her bits
  ctx.progress('V12 decoy: her bits cast it…');let err=null,t0=H.now();
  try{await D.place(token,{kind:'cast',point:{...dir.toCenter},look:'hardlight'});}catch(e){err=String(e?.message??e).slice(0,80);}
  if(err){res.lines.push(`cast: could not be made (${err})`);bad.push(`a decoy could not be cast: ${err}`);}
  else if(!(await until(()=>st()?.ready||!st(),4500))||!st()){
    // (her picture is copied from her token's texture: a screen without one cannot draw a decoy, and the module ends it by itself)
    const cleared=await until(()=>!doc.getFlag?.(ID,'decoy'),6000),homeBits=await H.waitUntil(()=>!H.call.bitState(ctx)?.busy,7000,()=>H.sleep(100));
    res.lines.push(`cast ${dir.name}: her picture could not be copied on this screen, so no decoy can be drawn here · the module ended it by itself: ${cleared?'yes':'NO'} · bits home ${homeBits?'yes':'NO'}`);
    if(!cleared||!homeBits)H.verdict(res,'FAIL','decoy: a decoy that could not be drawn was not ended (her bits stay out)');
    else H.verdict(res,'CHECK','decoy: nothing could be drawn here (no picture of her to copy on this screen); the module ended it and called her bits home');
    return;
  }else{
    const stood=await until(()=>st()?.phase==='stand'&&shown(),4000),born=(H.now()-t0)/1000,s1=st()??{},jobs=s1.jobs??[],held=tasks().filter(id=>jobs.includes(id)).length;
    const still=await quiet(900);
    const p1=rt.stats.paints;const to=await D.setLook(token);const swapped=await until(()=>st()?.phase==='stand'&&st()?.mix>.99,3000),swapPaints=rt.stats.paints-p1,still2=await quiet(700);
    await D.setLook(token,'hardlight');await until(()=>st()?.phase==='stand'&&st()?.mix<.01,3000);
    const t1=H.now();await D.strike(token);const tore=await until(()=>st()?.phase==='end',1500),gone=await until(()=>!doc.getFlag?.(ID,'decoy')&&!rt.records.get(token),5000),endS=(H.now()-t1)/1000;
    const homeBits=await H.waitUntil(()=>!tasks().some(id=>jobs.includes(id))&&!H.call.bitState(ctx)?.busy,7000,()=>H.sleep(100));
    res.lines.push(`cast ${dir.name}: standing ${stood?`after ${f2(born)} s`:'NO'} as ${s1.look??'?'} · ${jobs.length} bit(s) at its corners (${held} held) · paints while it stands ${still} · to ${to??'?'}: ${swapped?`${swapPaints} paints, then ${still2}`:'did NOT settle'} · struck: ${tore?'tore':'NO tear'}, gone ${gone?`after ${f2(endS)} s`:'NOT'} · bits home ${homeBits?'yes':'NO'} · ticker ${rt.ticking?'STILL RUNNING':'stopped'}`);
    if(!stood)bad.push('the cast decoy did not appear');
    if(!jobs.length||held!==jobs.length)bad.push(`her bits were not holding its corners (${held} of ${jobs.length})`);
    if(still>1||still2>1)odd.push(`a standing decoy was repainted (${still} and ${still2} times in under a second)`);
    if(to!=='normal'||!swapped)bad.push('its look did not change to normal');else if(swapPaints<2)odd.push('the change of look was not animated');
    if(!tore||!gone)bad.push('it did not come apart and clear when struck');
    if(!homeBits)bad.push('her bits did not come home when it ended');
    if(gone&&rt.ticking)bad.push('the decoy ticker kept running with no decoy');
  }
  // 2. a decoy warp: she warps away and her copy stays
  if(!canWarp)res.lines.push('decoy warp: not played (the game is paused or her warp range is under 15 ft)');
  else if(!bad.length){
    ctx.check();ctx.progress('V12 decoy: a decoy warp…');await H.settle(ctx,{timeout:1500});let e2=null;
    const near=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y)<ctx.grid*.6;
    try{await D.place(token,{kind:'warp',point:{...dir.toCenter},look:'normal'});}catch(e){e2=String(e?.message??e).slice(0,80);}
    const there=!e2&&await H.waitUntil(()=>near(doc,dir.to),8000,()=>H.sleep(50));await H.sleep(2200);
    const s2=st()??{},stays=Math.hypot((s2.x??1e9)-c0.x,(s2.y??1e9)-c0.y)<ctx.grid*.25,drawn=shown();
    await D.dismiss(token);const gone2=await until(()=>!doc.getFlag?.(ID,'decoy')&&!rt.records.get(token),5000);
    res.lines.push(`decoy warp: ${e2?`could not be made (${e2})`:`she arrived ${there?'yes':'NO'} · her copy ${stays?'stayed where she stood':'is NOT where she stood'}, ${drawn?'drawn':'NOT drawn'}, as ${s2.look??'?'} · dismissed: gone ${gone2?'yes':'NO'}`}`);
    if(e2)bad.push(`a decoy warp could not be made: ${e2}`);else{if(!there)bad.push('she did not arrive from the decoy warp');if(!stays||!drawn)bad.push('her copy did not stay where she stood');if(!gone2)bad.push('the dismissed decoy did not clear');}
    if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(250);}
  }
  // 3. her bits called home from under a cast decoy: it comes apart by itself
  if(!bad.length&&typeof ctx.api.stopBitTool==='function'){
    ctx.check();ctx.progress('V12 decoy: her bits called home…');await H.settle(ctx,{timeout:1500});
    await H.waitUntil(()=>!H.call.bitState(ctx)?.busy,6000,()=>H.sleep(100));let e3=null;
    try{await D.place(token,{kind:'cast',point:{...dir.toCenter},look:'hardlight'});}catch(e){e3=String(e?.message??e).slice(0,80);}
    if(e3)res.lines.push(`bits called home: not played (${e3})`);
    else{
      const stood=await until(()=>st()?.phase==='stand'&&shown(),4000),jobs=st()?.jobs??[];await H.sleep(900);
      // (12.0.0-beta.13) the menus on the map: one under her decoy (and none for the bits holding it), there while shown, gone after
      const FM=ctx.api.fieldMenus;
      if(stood&&FM?.show&&isOn('fieldMenus',null)!==false){
        const list=FM.list?.()??[],mine=list.filter(m=>m.token===token.id),dm=mine.find(m=>m.kind==='decoy'),extra=mine.filter(m=>m.kind==='task'&&jobs.includes(m.task)).length;
        FM.show(true);await H.sleep(350);const drawn=globalThis.document?.querySelectorAll?.('.ff-fm-layer .ff-fm').length??0,onScreen=[...(globalThis.document?.querySelectorAll?.('.ff-fm-layer .ff-fm[data-kind="decoy"]')??[])].some(e=>e.style.visibility!=='hidden');
        FM.show(false);await H.sleep(450);   // (they fold away over a quarter of a second)
        const left=globalThis.document?.querySelectorAll?.('.ff-fm-layer').length??0;
        res.lines.push(`menus on the map: her decoy’s ${dm?`yes (${dm.buttons.map(b=>b.label).join(' · ')})`:'NO'} · menus for the bits holding it ${extra} · drawn ${drawn}${onScreen?'':' (off screen)'} · left on the page after ${left}`);
        if(!dm)bad.push('her decoy has no menu on the map');if(extra)bad.push('the bits holding her decoy got menus of their own');if(dm&&!drawn)bad.push('the menus were not drawn');if(left)bad.push('the menus stayed on the page after they were put away');
      }
      for(const id of jobs)try{await ctx.api.stopBitTool(token,{id});}catch{}
      const t3=H.now(),gone3=await until(()=>!doc.getFlag?.(ID,'decoy')&&!rt.records.get(token),7000);
      res.lines.push(`bits called home: standing ${stood?'yes':'NO'} · ${jobs.length} bit(s) called back · the decoy ${gone3?`came apart by itself after ${f2((H.now()-t3)/1000)} s`:'STAYED'}`);
      if(!gone3)bad.push('a cast decoy stayed after her bits were called home');
      await H.waitUntil(()=>!H.call.bitState(ctx)?.busy,7000,()=>H.sleep(100));
    }
  }
  res.lines.push(`decoys made ${rt.stats.made} · paints ${rt.stats.paints} · ended ${rt.stats.ended}`);
  if(bad.length)H.verdict(res,'FAIL',`decoy: ${bad.join('; ')}`);
  else H.verdict(res,'PASS','a decoy is cast by her bits, stands without repainting, changes look, comes apart when struck and sends her bits home, and comes apart by itself when her bits are called home; a decoy warp leaves her copy where she stood');
  if(odd.length)H.verdict(res,'CHECK',`decoy: ${odd.join('; ')}`);
}

/* ================================================================ 8. SOUNDS */
async function v12sounds(ctx,res,H){
  const doc=ctx.doc,token=ctx.token;if(!V11_KEYS.has('soundSet')){res.skipped='no v12 sound set in this build';return;}
  const bad=[],odd=[],asked=()=>({...soundStats.asked}),more=(a,b,slot)=>(b[slot]??0)-(a[slot]??0);
  // 1. the registry and the files
  let ok=0;const missing=[];
  await Promise.all(SOUND_SLOTS.map(async id=>{const s=AUDIO_SLOTS[id];if(!s){missing.push(`${id} (no slot)`);return;}
    // (12.0.0-beta.10) two styles: the slot's own file (Classics) and its namesake in each other style's folder
    for(const dir of [s.directory??'refined',...Object.values(SOUND_STYLE_DIRS)]){const url=`modules/${ID}/assets/audio/${dir}/${s.file}.ogg`;
      try{const r=await fetch(url,{method:'HEAD',cache:'no-store'});if(r.ok)ok++;else missing.push(`${dir}/${s.file}.ogg (${r.status})`);}catch(e){missing.push(`${dir}/${s.file}.ogg (${String(e?.message??e).slice(0,30)})`);}}}));
  const files=SOUND_SLOTS.length*(1+Object.keys(SOUND_STYLE_DIRS).length);
  let hers=false;try{hers=doc.getFlag?.(ID,'audio')?.enabled===true;}catch{}
  const v0=resolveV11(doc),table=(()=>{try{return H.setting('audioEnabled')!==false;}catch{return true;}})();
  res.lines.push(`sound set: ${SOUND_SLOTS.length} sounds in ${1+Object.keys(SOUND_STYLE_DIRS).length} styles · files found ${ok}/${files}${missing.length?` · MISSING ${missing.slice(0,4).join(', ')}`:''} · V12 sounds ${v0.soundSet===true?'ON':'off'} for her (as found) · style ${soundStyleOf(doc)} · her sounds ${hers?'on':'off'}${table?'':' · the table’s animation audio is OFF'}`);
  if(missing.length)bad.push(`${missing.length} sound file(s) of the set are missing`);
  // 2. switched off, nothing of the set is asked for
  const inv=ctx.manager?.v11?.invisibility,st=()=>inv?.status?.(token)??{},solid=async()=>{if(inv&&(st().flag?.on||(st().phase&&st().phase!=='solid'))){try{inv.cloak(token,false,{});}catch{}await H.waitUntil(()=>st().phase==='solid'&&!st().filters,7000,()=>H.sleep(100));}};
  res.restore(solid);
  const quickCloak=async()=>{if(!inv?.cloak||(st().phase&&st().phase!=='solid')||isOn('invisLooks',doc)===false)return false;
    if(inv.cloak(token,true,{look:'c',T:1.1})===false)return false;const up=await H.waitUntil(()=>st().phase==='held',4000,H.nextFrame);
    inv.cloak(token,false,{T:1.1});await H.waitUntil(()=>st().phase==='solid'&&!st().filters,4000,H.nextFrame);return up;};
  // (she flies with her bits out for all of it: her cloak, her shield style and a cast decoy need her wings or her bits)
  await flyingWithBits(ctx,res,H);
  await setFor(ctx,res,'soundSet',false);await H.sleep(150);
  ctx.progress('V12 sounds: switched off…');
  let a0=asked();const playedOff=await quickCloak();const quiet=SOUND_SLOTS.every(s=>more(a0,asked(),s)===0);
  res.lines.push(`switched off: a quick cloak ${playedOff?'played':'could not be played here'} · sounds of the set asked for: ${quiet?'none':'SOME'}`);
  if(!quiet)bad.push('a sound of the set was asked for while V12 sounds is off');
  // 3. switched on, each family asks for its own
  await setFor(ctx,res,'soundSet',true);for(const p of Object.values(SOUND_PARTS))await setFor(ctx,res,`soundSet.${p}`,true);await H.sleep(150);
  const got=[];const want=(label,slots,a,b)=>{const miss=slots.filter(sl=>more(a,b,sl)<1);got.push(`${label} ${miss.length?`NOT ASKED (${miss.join(', ')})`:slots.join(' + ')}`);if(miss.length)bad.push(`${label}: ${miss.join(', ')} was not asked for`);};
  // a cloak
  ctx.check();ctx.progress('V12 sounds: a cloak…');a0=asked();
  if(await quickCloak())want('cloak',['cloakOnQuick','cloakOffQuick'],a0,asked());else got.push('cloak not played (a cloak or invisibility is on, or the looks are off)');
  // a warp
  const dir=H.freeDirection(ctx,3),range=Number(H.setting('warpRange'));
  const home={x:doc.x,y:doc.y},c0={x:home.x+token.w/2,y:home.y+token.h/2};
  res.restore(async()=>{try{const f=doc.getFlag?.(ID,'decoy');if(f)await ctx.manager?.v12?.decoy?.clear(doc,f);}catch{}
    if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(200);}});
  if(dir&&!(range>0&&range<15)&&typeof H.warpTo==='function'&&!ctx.paused){
    ctx.check();ctx.progress('V12 sounds: a Flock warp…');a0=asked();
    try{await H.warpTo(token,dir.toCenter,{style:'wings',look:'flock'});}catch{}
    await H.waitUntil(()=>Math.hypot(doc.x-dir.to.x,doc.y-dir.to.y)<ctx.grid*.6,6000,()=>H.sleep(40));await H.sleep(1700);
    want('warp',['warpFlock'],a0,asked());
    if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(300);}
  }else got.push('warp not played (no free spot, the game is paused, or her warp range is under 15 ft)');
  // a shield style
  if(V11_KEYS.has('shieldStyle')&&H.call?.shield){
    ctx.check();ctx.progress('V12 sounds: a Scale mail shield…');
    const raised0=doc.getFlag?.(ID,'wingShield')===true;res.restore(async()=>{try{if((doc.getFlag?.(ID,'wingShield')===true)!==raised0)await H.call.shield(ctx,raised0);}catch{}});
    await setFor(ctx,res,'shieldStyles',true);await setFor(ctx,res,'shieldStyle','scalemail');
    if(raised0){await H.call.shield(ctx,false);await H.sleep(1800);}
    a0=asked();await H.call.shield(ctx,true);await H.sleep(1500);const b=asked();await H.call.shield(ctx,false);await H.sleep(1500);
    if(more(a0,b,'flightShieldScalemail')>0)got.push('shield flightShieldScalemail');
    else if(!hers)got.push('shield: not asked for (a shield’s sound is chosen only where her sounds are on)');
    else{got.push('shield NOT ASKED (flightShieldScalemail)');bad.push('shield: flightShieldScalemail was not asked for');}
  }
  // a cast decoy
  const D=ctx.api?.decoy;
  if(D?.place&&dir&&isOn('decoy',doc)!==false&&!doc.getFlag?.(ID,'decoy')){
    ctx.check();ctx.progress('V12 sounds: a decoy…');await H.waitUntil(()=>!H.call.bitState(ctx)?.busy,5000,()=>H.sleep(100));a0=asked();let err=null;
    try{await D.place(token,{kind:'cast',point:{...dir.toCenter},look:'hardlight'});}catch(e){err=String(e?.message??e).slice(0,60);}
    if(err)got.push(`decoy not played (${err})`);
    else{await H.waitUntil(()=>D.status(token)?.phase==='stand',4000,H.nextFrame);await D.setLook(token);await H.sleep(600);await D.dismiss(token);
      await H.waitUntil(()=>!doc.getFlag?.(ID,'decoy'),5000,H.nextFrame);want('decoy',['decoyCast','decoyLook','decoyBreak'],a0,asked());
      await H.waitUntil(()=>!H.call.bitState(ctx)?.busy,7000,()=>H.sleep(100));}
  }else got.push('decoy not played');
  res.lines.push(`switched on: ${got.join(' · ')}`);
  res.lines.push(`landing styles: their sound is chosen by her sound player as her wings go, so only where her sounds are on${hers?'':' (they are off: not played here)'} · asked for so far this session: ${Object.entries(soundStats.asked).map(([k,n])=>`${k} ${n}`).join(', ')||'none'}`);
  if(bad.length)H.verdict(res,'FAIL',`sounds: ${bad.join('; ')}`);
  else H.verdict(res,'PASS',`the v12 sound set is complete (${ok} files), silent while it is switched off, and each effect asks for its own sound while it is on${hers?'':' (her sounds are off, so none of it was heard)'}`);
  if(odd.length)H.verdict(res,'CHECK',`sounds: ${odd.join('; ')}`);
}

/* ================================================================ 9. COST */
async function v12perf(ctx,res,H){
  const doc=ctx.doc,MS=ctx.opts.v12PerfMs??2600,inv=ctx.manager?.v11?.invisibility,S=()=>stateOf(ctx);
  await setFor(ctx,res,'shieldStyles',true);
  await flyingWithBits(ctx,res,H);
  const raised0=doc.getFlag?.(ID,'wingShield')===true;
  res.restore(async()=>{try{if((doc.getFlag?.(ID,'wingShield')===true)!==raised0)await H.call.shield(ctx,raised0);}catch{}});
  if((S()?.feelShield??0)>.05){await H.call.shield(ctx,false);await H.sleep(1800);}
  const rows=[],row=async(name,load=null,{pre=null,post=null}={})=>{ctx.check();try{await pre?.();}catch(e){res.lines.push(`(${name}: ${String(e?.message??e).slice(0,50)})`);return;}
    const r=await H.measureLoad(ctx,`V12 ${name}`,MS,load);r.name=name;rows.push(r);try{await post?.();}catch{}};
  await row('idle hover');
  for(const style of SHIELD_STYLES)await row(`shield ${style}`,null,{pre:async()=>{await setFor(ctx,res,'shieldStyle',style);await H.sleep(200);await H.call.shield(ctx,true);await H.sleep(1700);},post:async()=>{await H.call.shield(ctx,false);await H.sleep(1700);}});
  const st=()=>inv?.status?.(ctx.token)?.phase;
  if(inv?.cloak&&st()==='solid'&&isOn('invisLooks',doc)!==false){
    res.restore(async()=>{if(st()!=='solid'){try{inv.cloak(ctx.token,false,{});}catch{}await H.waitUntil(()=>st()==='solid',7000,()=>H.sleep(100));}});
    for(const look of ['plumage','aurora'])await row(`cloak ${look}`,async()=>{inv.cloak(ctx.token,true,{look});},{post:async()=>{await H.waitUntil(()=>st()==='held',3500,()=>H.sleep(100));inv.cloak(ctx.token,false,{});await H.waitUntil(()=>st()==='solid',7000,()=>H.sleep(100));}});
  }
  const dir=H.freeDirection(ctx,3),range=Number(H.setting('warpRange'));
  if(dir&&typeof H.warpTo==='function'&&!(range>0&&range<15)&&!ctx.paused){
    const home={x:doc.x,y:doc.y},c0={x:home.x+ctx.token.w/2,y:home.y+ctx.token.h/2};
    res.restore(async()=>{if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(200);}});
    await row('warp flock',async()=>{await H.warpTo(ctx.token,dir.toCenter,{style:'wings',look:'flock'});},{post:async()=>{await H.sleep(900);await H.warpTo(ctx.token,c0,{style:'wings',look:'flock'});await H.sleep(2600);if(doc.x!==home.x||doc.y!==home.y)await doc.update({x:home.x,y:home.y},{animate:false});await H.settle(ctx,{timeout:1500});}});
  }
  const base=rows[0];if(!base){res.lines.push('no rows measured');return;}
  res.lines.push('ms med/p95/max · module ms/frame (top part) · Δmean ms against idle');
  for(const r of rows){const d=r===base?'base':`${r.mean-base.mean>=0?'+':''}${f1(r.mean-base.mean)}`,top=r.stages?.[0];
    res.lines.push(`${r.name.padEnd(17)} ${f1(r.fs.med)}/${f1(r.fs.p95)}/${f0(r.fs.max)} · ${r.mod==null?'-':f2(r.mod)}${top?` (${top[0]} ${f2(top[1])})`:''} · ${d}${r.err?` · ${r.err}`:''}`);}
  // a v12 look may cost a little while it plays; it must not cost much, and nothing once it is over
  const heavy=rows.slice(1).filter(r=>r.mean-base.mean>Math.max(2.5,base.mean*.35));
  if(heavy.length)H.verdict(res,'CHECK',`frames longer than idle by: ${heavy.map(r=>`${r.name} +${f1(r.mean-base.mean)} ms`).join(', ')}`);
  ctx.check();const after=await H.measureLoad(ctx,'V12 idle again',Math.min(MS,2000));
  res.lines.push(`${'idle again'.padEnd(17)} ${f1(after.fs.med)}/${f1(after.fs.p95)}/${f0(after.fs.max)} · ${after.mod==null?'-':f2(after.mod)} · ${after.mean-base.mean>=0?'+':''}${f1(after.mean-base.mean)}`);
  if(after.mean-base.mean>Math.max(1.5,base.mean*.2))H.verdict(res,'CHECK',`frames stayed ${f1(after.mean-base.mean)} ms longer after the v12 looks ended`);
  if(!res.verdicts.length)H.verdict(res,'PASS',`the v12 looks cost little while they play and nothing after: worst ${rows.slice(1).map(r=>[r.name,r.mean-base.mean]).sort((a,b)=>b[1]-a[1]).slice(0,1).map(([k,v])=>`${k} ${v>=0?'+':''}${f1(v)} ms`)[0]??'-'}`);
}

export const V12_RUN=Object.freeze({v12setup,v12warps,v12shields,v12landing,v12cloaks,v12wheel,v12decoy,v12sounds,v12perf});

/* ---------------------------------------------------------------- RESTORE: what the V12 part may leave behind */
export function v12Residue(ctx){
  const out=[];if(!ctx.token)return out;
  try{if(ctx.doc.getFlag?.(ID,'decoy'))out.push('a decoy');}catch{}
  try{if(ctx.doc.getFlag?.(ID,LAND_FLAG))out.push('a landing waiting to recall her bits');}catch{}
  return out;
}
