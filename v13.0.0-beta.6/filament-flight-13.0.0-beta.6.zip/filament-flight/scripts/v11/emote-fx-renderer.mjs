/** Yvaelle’s Toolbox v11 · Emotes: the soft lights (PIXI), made only while an emote plays.
 *
 * What the lab painted with canvas gradients ('lighter'), as additive meshes:
 *  - each bit's focus (a small core of light under it) and glow;
 *  - the wing light (Cheer, Laugh B, Pray): each wing layer drawn once more,
 *    additively, from the texture it already has (no repaint, no upload);
 *  - Pray's light where her wing tips meet, and a low glow over her;
 *  - Comfort's warmth round the ally.
 * The pictures are painted once per page (paintEmoteTexture, shared with the
 * render harness) and uploaded once. Nothing exists until the first emote;
 * between emotes every mesh is hidden; nothing touches her token. */
import {ID} from '../config.mjs?v=13.0.0-beta.6';
import {effectMeshClass,placeBehind,setMeshTransform} from '../renderer.mjs?v=13.0.0-beta.6';
import {EMOTE_TINTS} from './emote-apply.mjs?v=13.0.0-beta.6';

/** The gradients (normalised: the mesh's alpha carries the strength). */
export const EMOTE_TEXTURES=Object.freeze({
  // a bit's focus core (lab: 0 → a, .45 → .32a, 1 → 0), white (tinted)
  focus:{size:64,inner:0,stops:[[0,[255,255,255],1],[.45,[255,255,255],.32],[1,[255,255,255],0]]},
  // a bit's glow (lab: 0 → a, .35 → .35a, 1 → 0), white (tinted)
  glow:{size:64,inner:0,stops:[[0,[255,255,255],1],[.35,[255,255,255],.35],[1,[255,255,255],0]]},
  // Pray: where the tips meet (lab R 34, at k = 1)
  auraTip:{size:96,inner:0,stops:[[0,[255,214,160],.30],[.35,[240,150,190],.14],[1,[200,60,190],0]]},
  // Pray: the low glow over her (lab: from r 10 to 92)
  auraBody:{size:128,inner:10/92,stops:[[0,[235,160,150],.07],[1,[190,40,170],0]]},
  // Comfort: warmth round the ally (lab: from .4 R to R)
  warmRing:{size:128,inner:.4,stops:[[0,[240,170,110],0],[.75,[236,150,120],.10],[1,[230,120,190],0]]},
});
/** Paint one of the pictures on a 2D context (size × size, centred). */
export function paintEmoteTexture(g,kind){
  const T=EMOTE_TEXTURES[kind],S=T.size,R=S/2;
  g.clearRect(0,0,S,S);
  const gr=g.createRadialGradient(R,R,T.inner*R,R,R,R);
  for(const [at,c,a] of T.stops)gr.addColorStop(at,`rgba(${c[0]},${c[1]},${c[2]},${a})`);
  g.fillStyle=gr;g.fillRect(0,0,S,S);
}
const textures=new Map();
function textureOf(kind){
  let t=textures.get(kind);if(t&&!t.baseTexture?.destroyed)return t;
  const c=document.createElement('canvas');c.width=c.height=EMOTE_TEXTURES[kind].size;paintEmoteTexture(c.getContext('2d'),kind);
  t=PIXI.Texture.from(c);textures.set(kind,t);return t;
}
const ADD=()=>globalThis.PIXI?.BLEND_MODES?.ADD??1;
const rgb=c=>(Math.round(c[0]*255)<<16)|(Math.round(c[1]*255)<<8)|Math.round(c[2]*255);
const TINT={focus:rgb(EMOTE_TINTS.focus),focusWarm:rgb(EMOTE_TINTS.focusWarm),glow:rgb(EMOTE_TINTS.glow),glowWarm:rgb(EMOTE_TINTS.glowWarm)};
const STATIONS=['leftUpper','rightUpper','leftLower','rightLower'];

export class EmoteFx{
  constructor(token){this.token=token;this.meshes=[];this.bitFocus=[];this.bitGlow=[];this.bitSil=[];this.bitRim=[];this.byStation={};this.wing=new Map();this.shown=false;
    this.collect=(r)=>{const b=r.frame?.bit;if(!b)return;const st=b.station??`${b.left?'left':'right'}${b.id?.endsWith('0')?'Upper':'Lower'}`;this.byStation[st]=r;};}
  make(kind,name){
    const Mesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
    const m=new Mesh({name:`${ID}.${this.token.id}.emote.${name}`,texture:kind?textureOf(kind):PIXI.Texture.EMPTY},Shader);
    m.anchor.set(.5);m.eventMode='none';m.interactive=false;m.visible=false;m.alpha=0;m.blendMode=ADD();
    canvas.primary.addChild(m);this.meshes.push(m);return m;
  }
  ensure(){
    if(this.ready)return;this.ready=true;
    for(let i=0;i<4;i++){this.bitFocus[i]=this.make('focus',`focus${i}`);this.bitGlow[i]=this.make('glow',`glow${i}`);
      // the focused bit's dark hairline silhouette (behind it) and tinted rim (over it), from the bit's own picture
      const sil=this.bitSil[i]=this.make(null,`sil${i}`);sil.blendMode=globalThis.PIXI?.BLEND_MODES?.NORMAL??0;sil.tint=0x160614;this.bitRim[i]=this.make(null,`rim${i}`);}
    this.auraTip=this.make('auraTip','auraTip');this.auraBody=this.make('auraBody','auraBody');this.warm=this.make('warmRing','warm');this.warm2=this.make('warmRing','warm2');
  }
  /** One frame. rig: her WingRigRenderer (bits, layers); G: emoteGlows(); P: positions
   * {tip:{x,y}, body:{x,y}, ally:{x,y}|null}; source: her token mesh; alpha: her rig's alpha (with the veil's bits share);
   * fx: the invisibility veil's share for effects off her meshes (test.3: these meshes carry no cloak filter, so a
   * sweep, a drain or being held hides them through it; 1 when she is plainly visible). */
  update(rig,G,P,source,alpha,fx=1){
    this.ensure();this.shown=true;
    // bits: under each bit, at its depth
    const bits=rig.bits,placements=bits?.placements,by=this.byStation;
    for(let i=0;i<4;i++)by[STATIONS[i]]=null;bits?.records?.forEach?.(this.collect);
    for(let i=0;i<4;i++){
      const st=STATIONS[i],g=G.bits[i],p=placements?.get(st),f=this.bitFocus[i],w=this.bitGlow[i],rec=by[st];
      const vis=p?Math.min(1,(p.alpha??alpha))*fx:0,fa=g.focusA*vis,ga=p?g.glowA*vis:0,order=this.orderOf(rec);
      this.put(f,p,fa,g.focusR,g.warm?TINT.focusWarm:TINT.focus,source,order+.0002);
      this.put(w,p,ga,g.glowR,g.warm?TINT.glowWarm:TINT.glow,source,order+.0003);
      // lab: a dark silhouette (.55 fk) one hairline out, and a tinted rim (.42 fk) at 1.06 of the bit
      const mesh=rec?(rec.meshes?.front?.visible?rec.meshes.front:rec.meshes?.rear):null,fk=g.fk??0;
      this.copyBit(this.bitSil[i],mesh,rec,.55*fk*vis,1.08,null,source,order+.0001);
      this.copyBit(this.bitRim[i],mesh,rec,.42*fk*vis,1.06,g.warm?TINT.focusWarm:TINT.focus,source,order-.0002);
    }
    // the wing light: each layer once more, additively, from its own texture
    const glowK=Math.min(1,G.glow);
    for(const layer of rig.layerRecords??[]){
      let m=this.wing.get(layer.key);
      if(glowK>.003&&layer.mesh?.visible&&layer.hasContent){
        if(!m||m.texture!==layer.texture){if(m){m.parent?.removeChild(m);m.destroy({children:true,texture:false,baseTexture:false});this.meshes.splice(this.meshes.indexOf(m),1);}
          m=this.make(null,`wing.${layer.key}`);m.texture=layer.texture;this.wing.set(layer.key,m);}
        const L=layer.mesh;
        if(m.anchor.x!==L.anchor.x||m.anchor.y!==L.anchor.y)m.anchor.set(L.anchor.x,L.anchor.y);
        if(m.x!==L.x||m.y!==L.y)m.position.set(L.x,L.y);if(m.rotation!==L.rotation)m.rotation=L.rotation;
        if(m.scale.x!==L.scale.x||m.scale.y!==L.scale.y)m.scale.set(L.scale.x,L.scale.y);
        const a=glowK*Math.min(1,L.alpha/Math.max(.001,alpha||1))*fx;if(m.alpha!==a)m.alpha=a;m.visible=a>.003;
        placeBehind(m,source,(layer.front?(layer.left?-.12:-.13):(layer.left?.22:.21))-.0004);
      }else if(m&&m.visible)m.visible=false;
    }
    // Pray: a warm light where the tips meet, and a low glow over her
    const A=G.aura;
    this.put(this.auraTip,P.tip,A.k*A.br*alpha*fx,A.R,0xffffff,source,-.2);
    this.put(this.auraBody,P.body,A.k*alpha*fx,A.bodyR,0xffffff,source,-.2);
    // Comfort: warmth round the ally, under her wings
    this.put(this.warm,P.ally,P.ally?G.warm.k*alpha*fx:0,G.warm.R,0xffffff,source,.25);
    // (test.5) a Comfort to her other side fading out beneath this one: its warmth stays round its own ally
    this.put(this.warm2,P.ally2,P.ally2?(G.warm.k2??0)*alpha*fx:0,G.warm.R,0xffffff,source,.25);
  }
  put(m,p,a,R,tint,source,order){
    if(!p||!(a>.003)||!(R>.5)){if(m.visible)m.visible=false;return;}
    setMeshTransform(m,p.x,p.y,0,R*2,R*2);if(m.alpha!==a)m.alpha=a;if(m.tint!==tint)m.tint=tint;if(!m.visible)m.visible=true;
    placeBehind(m,source,order);
  }
  /** The bit's own depth (as the bit renderer sorts it). */
  orderOf(r){const b=r?.frame?.bit;if(!b)return .2;return ((b.front??0)>(b.rear??0)?(b.left?-.12:-.13):(b.left?.22:.21))-.001;}
  /** A copy of the bit's mesh (its texture, place, turn and size × k). */
  copyBit(m,src,r,a,k,tint,source,order){
    if(!src||!r?.texture||!(a>.01)||!src.visible){if(m.visible)m.visible=false;return;}
    if(m.texture!==r.texture)m.texture=r.texture;
    if(m.x!==src.x||m.y!==src.y)m.position.set(src.x,src.y);if(m.rotation!==src.rotation)m.rotation=src.rotation;
    const sx=src.scale.x*k,sy=src.scale.y*k;if(m.scale.x!==sx||m.scale.y!==sy)m.scale.set(sx,sy);
    if(tint!=null&&m.tint!==tint)m.tint=tint;if(m.alpha!==a)m.alpha=a;if(!m.visible)m.visible=true;placeBehind(m,source,order);
  }
  hide(){if(!this.shown)return;this.shown=false;for(const m of this.meshes)if(m.visible)m.visible=false;}
  destroy(){for(const m of this.meshes)if(!m.destroyed){m.parent?.removeChild(m);m.destroy({children:true,texture:false,baseTexture:false});}this.meshes.length=0;this.wing.clear();this.ready=false;}
}
