/** Yvaelle’s Toolbox v11 · Emotes: the approved phrases (pure, allocation-free).
 *
 * Port of the approved lab emotes (lab/v11/emotes/site/emotes.mjs; Laugh A and
 * B and `stillAt` from lab/v11/fixes; Comfort's mirror from lab/v11/refine)
 * with the same numbers, rewritten to write into a preallocated frame: the
 * caller makes a frame once (createEmoteFrame) and every sample overwrites it.
 *
 * An emote is a pure function of τ, the seconds since it started. Nothing here
 * keeps state or reads a clock, so every client that reads the same token flag
 * {id, started, side} draws the same frame. Every envelope returns to zero by
 * `duration`, so she lands exactly back in her normal state.
 *
 * A frame (all in her own frame; + x = her right, + y = down the map):
 *   pose[11], tip[11]   target pose weights (POSES order) blended over hers;
 *                       the tips use the phrase sampled `lag` s earlier
 *   ch[18], hasCh       V7 expression channels, left 0-8, right 9-17 (lift,
 *                       spread, fold, camber, roll, twist, lower, upper, depth)
 *   rotL, rotR, hasRot  whole-wing turn about each shoulder (rad, + = tips up)
 *   wrapK, squeeze      Comfort: the (side's) wing wraps round the ally
 *   still, stillAt      the wingbeat stops and settles at phase stillAt (turns)
 *   beat                multiplier on the wingbeat rate
 *   bank, dx, dy        her tilt (rad) and body offset (token sizes)
 *   glow                extra wing light; aura (Pray's light), warm (Comfort)
 *   bits[4]             0 left upper, 1 right upper, 2 left lower, 3 right lower:
 *                       ox, oy (offset, token sizes), spin, dim, glow, focus,
 *                       mix toward tx, ty (her frame) | the ally (ally, slot) |
 *                       a line above her (line, slot); lean toward what she looks at
 *   side                +1 as authored (ally on her right), −1 mirrored */
import {POSES} from '../poses.mjs?v=13.0.0-beta.6';

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const smoother=x=>{x=unit(x);return x*x*x*(x*(x*6-15)+10);};
const easeOut=x=>1-(1-unit(x))**3;
/** Rise over [a,a+i], hold, fall over [b,b+o]. */
const env=(t,a,i,b,o,f=smoother)=>f((t-a)/i)*(1-f((t-b)/o));
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
/** Calm laugh bounces: each a quick lift (35 %) and a soft fall (65 %). */
function bounces(t,at,amp,w){let v=0;for(let k=0;k<at.length;k++){const x=(t-at[k])/w;if(x>0&&x<1){const b=amp[k]*(x<.35?smoother(x/.35):1-smoother((x-.35)/.65));if(b>v)v=b;}}return v;}
const LA_AT=Object.freeze([.28,.78,1.26]),LA_AMP=Object.freeze([1,.78,.52]),LB_AT=Object.freeze([.42,.92,1.42]),LB_AMP=Object.freeze([1,.88,.5]);
/** Ripple order round her: upper-left, upper-right, lower-right, lower-left. */
const RIPPLE=Object.freeze([0,1,3,2]);
const isLeft=i=>i%2===0,isUpper=i=>i<2;

const NP=POSES.length;
const P=Object.freeze(Object.fromEntries(POSES.map((p,i)=>[p,i])));
export const EMOTE_NP=NP;

/* ------------------------------------------------------------ frames */
// (prev: the bit's gather belongs to an emote fading out beneath a new one; the runtime marks it, and the bit keeps that one's ally)
function bitRec(){return {ox:0,oy:0,spin:0,dim:0,glow:0,focus:0,mix:0,tx:0,ty:0,ally:false,line:false,slot:0,lean:0,prev:false};}
/** One frame, made once and overwritten by every sample. */
export function createEmoteFrame(){
  return {id:'',side:1,pose:new Float64Array(NP),tip:new Float64Array(NP),hasTip:false,ch:new Float64Array(18),hasCh:false,
    rotL:0,rotR:0,hasRot:false,wrapK:0,squeeze:0,hasWrap:false,still:0,stillAt:0,beat:1,bank:0,dx:0,dy:0,glow:0,aura:0,hasAura:false,warm:0,
    bits:[bitRec(),bitRec(),bitRec(),bitRec()]};
}
function clearBit(b){b.ox=b.oy=b.spin=b.dim=b.glow=b.focus=b.mix=b.tx=b.ty=b.lean=0;b.ally=b.line=b.prev=false;b.slot=0;}
export function clearEmoteFrame(F){
  F.id='';F.side=1;F.pose.fill(0);F.tip.fill(0);F.hasTip=false;F.ch.fill(0);F.hasCh=false;F.rotL=F.rotR=0;F.hasRot=false;F.wrapK=F.squeeze=0;F.hasWrap=false;
  F.still=0;F.stillAt=0;F.beat=1;F.bank=F.dx=F.dy=F.glow=F.aura=F.warm=0;F.hasAura=false;
  for(let i=0;i<4;i++)clearBit(F.bits[i]);
  return F;
}
const both=(F,k,v)=>{F.ch[k]+=v;F.ch[9+k]+=v;F.hasCh=true;};
const left=(F,k,v)=>{F.ch[k]+=v;F.hasCh=true;},right=(F,k,v)=>{F.ch[9+k]+=v;F.hasCh=true;};
const rot=(F,L,R)=>{F.rotL=L;F.rotR=R;F.hasRot=true;};

/* ------------------------------------------------------------ the phrases */
function bow(t,F){
  // in 0–1.0 (slow, deliberate), held 0.45 s, rises a touch slower than it fell
  const k=env(t,0,1.0,1.45,1.3),down=env(t,.08,.95,1.4,1.3);
  F.pose[P.forwardGuard]=.58*k;F.pose[P.drooped]=.42*k;
  both(F,8,1.4*k);both(F,0,-.8*down);both(F,7,-.6*down);
  F.still=env(t,0,.6,1.6,1.1);F.dy=.045*down;
  for(let i=0;i<4;i++){const b=F.bits[i],d=env(t,.12+(i%2)*.05+(isUpper(i)?0:.12),.95,1.45+(isUpper(i)?.1:0),1.2);
    b.ox=(isLeft(i)?1:-1)*.07*d;b.oy=(isUpper(i)?.16:.06)*d;b.spin=(isLeft(i)?.5:-.5)*d;b.focus=.45*d;}
}
// v11 fixes · Laugh redone: warm, gentle, rhythmic (≈2 bounces/s, not a flutter).
function laughA(t,F){
  const e=env(t,0,.3,1.85,.6),B=bounces(t,LA_AT,LA_AMP,.48);
  F.pose[P.raised]=.16*e+.1*B;
  both(F,0,.38*e+1.2*B);both(F,7,.55*B);both(F,1,.12*e);
  rot(F,.07*B,.07*B);F.still=.45*e;F.stillAt=.22;F.beat=1-.4*e;F.dy=-.004*e-.013*B;
  for(let i=0;i<4;i++){const bt=F.bits[i],d=RIPPLE[i]*.07,b=bounces(t-d,LA_AT,LA_AMP,.48),ee=env(t,d,.3,1.85,.6);
    bt.oy=-.02*ee-.075*b;bt.spin=.1*Math.sin(t*TAU*.9+i*1.3)*ee;bt.focus=.3*ee;}
}
function laughB(t,F){
  const e=env(t,0,.22,2.0,.6),inhale=env(t,0,.2,.34,.18),B=bounces(t,LB_AT,LB_AMP,.5);
  F.pose[P.raised]=.1*inhale+.12*e+.12*B;
  both(F,0,.25*inhale+.3*e+1.35*B);both(F,7,.6*B);both(F,1,.3*B);
  rot(F,.085*B,.085*B);F.still=.5*e;F.stillAt=.22;F.beat=1-.45*e;
  F.bank=.045*Math.sin(TAU*unit((t-.38)/1.7))*e;F.glow=.06*B;F.dy=-.006*inhale-.015*B;
  for(let i=0;i<4;i++){const bt=F.bits[i],d=RIPPLE[i]*.09,b=bounces(t-d,LB_AT,LB_AMP,.5),ee=env(t,d,.3,2.0,.6),ph=TAU*(t*.8)+RIPPLE[i]*TAU/4;
    bt.oy=-.08*b-.012*ee;bt.ox=.012*Math.cos(ph)*ee;bt.glow=.35*b;bt.spin=.12*Math.sin(ph)*ee;bt.focus=.35*ee;}
}
function sigh(t,F){
  const inhale=env(t,0,.5,.5,.45),droop=env(t,.55,.9,1.75,1.4,smooth);
  F.pose[P.raised]=.16*inhale;F.pose[P.drooped]=.62*droop;F.pose[P.trailing]=.12*droop;
  both(F,0,.5*inhale-.6*droop);both(F,3,.5*droop);
  F.beat=1-.7*droop;F.still=.35*droop;F.dy=-.01*inhale+.04*droop;
  for(let i=0;i<4;i++){const b=F.bits[i],d=env(t,.65+i*.06,.9,1.75+i*.07,1.3,smooth);b.oy=-.03*inhale+.1*d;b.dim=.28*d;b.spin=(isLeft(i)?-.25:.25)*d;}
}
function shrug(t,F){
  const up=env(t,0,.3,.62,.38,easeOut),settle=bump(unit((t-.95)/.75))*.5;
  F.pose[P.raised]=.55*up;F.pose[P.drooped]=.12*settle;
  both(F,0,1.8*up);both(F,7,.6*up);
  F.still=.6*env(t,0,.2,.9,.6);F.bank=.06*env(t,.05,.3,.62,.5);F.dy=-.035*up+.012*settle;
  for(let i=0;i<4;i++){const b=F.bits[i],u=env(t,.04+(i>1?.06:0),.3,.66+(i>1?.06:0),.38,easeOut);
    b.oy=-.13*u+.03*bump(unit((t-1.0-i*.04)/.6));b.spin=(isLeft(i)?-.3:.3)*u;b.focus=.45*u;}
}
function wave(t,F){
  const raise=env(t,0,.55,2.05,.7),w=Math.sin((t-.45)*TAU*1.55)*env(t,.4,.3,1.85,.4,smooth);
  right(F,0,1.2*raise);right(F,7,1.4*raise+.8*w);right(F,1,.3*raise);right(F,4,.6*w);
  rot(F,-.03*raise,.42*raise+.17*w);F.still=.85*raise;F.bank=-.05*raise;
  const b1=F.bits[1],b3=F.bits[3];
  b1.glow=.55*raise*(.6+.4*Math.max(0,w));b1.spin=.6*w;b1.focus=.7*raise;
  b3.oy=-.05*raise;b3.spin=.3*w;
}
function cheer(t,F){
  const up=env(t,0,.32,1.15,1.0,easeOut),pulse=bump(unit((t-.35)/.5));
  F.pose[P.aggressiveFlare]=.45*up;F.pose[P.raised]=.42*up;
  both(F,1,1.6*up);both(F,0,1.2*up+.5*pulse);both(F,7,.8*up);
  F.still=.7*up;F.glow=.22*up+.12*pulse;F.dy=-.04*up;
  for(let i=0;i<4;i++){const b=F.bits[i],q=unit((t-.18-i*.07)/.85),u=env(t,.1+i*.05,.3,1.1,.9,easeOut);
    b.spin=TAU*smoother(q);b.oy=-.12*u;b.ox=(isLeft(i)?-1:1)*.05*u;b.glow=.35*bump(q);b.focus=.75*u;}
}
function startle(t,F){
  const snap=unit(t/.11)**.6*(1-smoother((t-.55)/1.45)),tr=Math.sin(t*TAU*13)*env(t,.08,.05,.18,.4,smooth);
  F.pose[P.collapsed]=.5*snap;F.pose[P.crossed]=.12*snap;
  both(F,2,1.2*snap);both(F,0,.4*tr);
  rot(F,.03*tr,-.03*tr);F.still=snap;F.dy=-.035*bump(unit(t/.5));
  for(let i=0;i<4;i++){const b=F.bits[i],s2=unit((t-.02)/.1)**.6*(1-smoother((t-.6-i*.06)/1.3));
    b.mix=.55*s2;b.tx=isLeft(i)?-.18:.18;b.ty=isUpper(i)?-.22:.18;b.spin=.4*tr;b.focus=.4*s2;}
}
// Written for an ally on her RIGHT; sampleEmote mirrors the whole frame for an ally on her left.
function comfort(t,F){
  const k=env(t,0,1.1,2.25,1.15),squeeze=bump(unit((t-1.15)/1.0))*.5;
  F.pose[P.forwardGuard]=.28*k;F.wrapK=k;F.squeeze=squeeze;F.hasWrap=true;
  F.still=.9*k;F.bank=.08*k;F.dx=.03*k;F.warm=k;
  for(let i=0;i<4;i++){const b=F.bits[i],g=env(t,.35+i*.08,.9,2.2-i*.05,1.0,smooth);
    if(i===1||i===3){b.mix=.85*g;b.ally=true;b.slot=i===1?0:1;b.glow=.45*g;b.spin=.15*g;b.focus=.75*g;}else b.glow=.15*g;}
}
function curious(t,F){
  const k=env(t,0,.6,1.95,.85),take=bump(unit((t-.95)/.32));
  left(F,0,.9*k);left(F,7,.9*k);left(F,4,.4*k);right(F,0,-.4*k);right(F,6,.4*k);
  rot(F,.14*k,-.08*k);F.still=.55*k;F.bank=-.2*k-.04*take;F.dx=-.03*k;
  for(let i=0;i<4;i++){const b=F.bits[i],g=env(t,.18+i*.09,.6,1.9+i*.05,.8);b.lean=g*(1+.25*take);b.spin=-.2*g;b.focus=.7*g;}
}
function pray(t,F){
  const k=env(t,0,1.0,2.55,1.05),aura=env(t,.75,.8,2.3,1.0,smooth);
  F.pose[P.forwardGuard]=.95*k;F.tip[P.forwardGuard]=.4*k;F.tip[P.raised]=.55*k;F.hasTip=true;
  F.still=k;F.glow=.1*aura;F.aura=aura;F.hasAura=true;
  for(let i=0;i<4;i++){const b=F.bits[i],g=env(t,.25+i*.1,.85,2.45-i*.06,1.0);b.mix=g;b.line=true;b.slot=i;b.glow=.3*aura;b.focus=.65*g;}
}

const def=(label,duration,lag,sample,x={})=>Object.freeze({label,duration,lag,sample,sided:false,...x});
/** The phrases by variant id ('laugh' plays laugh_a or laugh_b: emoteVariant). */
export const EMOTE_DEFS=Object.freeze({
  bow:def('Bow',2.9,.2,bow),
  laugh_a:def('Laugh · A · Soft chuckle',2.5,.12,laughA),
  laugh_b:def('Laugh · B · Bright laugh',2.7,.16,laughB),
  sigh:def('Sigh',3.2,.32,sigh),
  shrug:def('Shrug',1.8,.1,shrug),
  wave:def('Wave',2.8,.14,wave),
  cheer:def('Cheer',2.4,.12,cheer),
  startle:def('Startle',2.1,.03,startle),
  comfort:def('Comfort',3.4,.25,comfort,{sided:true,ally:true}),
  curious:def('Curious',2.8,.18,curious,{look:true}),
  pray:def('Pray',3.6,.3,pray),
});
/** The variant an emote id plays ('laugh' → 'laugh_a' unless the picker says B). */
export function emotePhrase(variant){return EMOTE_DEFS[variant]?variant:variant==='laugh'?'laugh_a':null;}
export function emoteDuration(variant){return EMOTE_DEFS[emotePhrase(variant)]?.duration??0;}

/** Mirror a frame left↔right in place (her own frame): the expression channels
 * and the whole-wing turns swap sides, bits swap 0↔1 and 2↔3 with their
 * sideways offsets and spin negated, bank and sideways drift flip, and `side`
 * tells the renderer which wing does the one-sided work (Comfort's wrap).
 * Poses are symmetric, so they pass through. */
export function mirrorEmoteFrame(F){
  const c=F.ch;for(let k=0;k<9;k++){const a=c[k];c[k]=c[9+k];c[9+k]=a;}
  const r=F.rotL;F.rotL=F.rotR;F.rotR=r;F.bank=-F.bank;F.dx=-F.dx;F.side=-F.side;
  swapBits(F.bits[0],F.bits[1]);swapBits(F.bits[2],F.bits[3]);
  return F;
}
const BIT_KEYS=['ox','oy','spin','dim','glow','focus','mix','tx','ty','ally','line','slot','lean'];
function swapBits(a,b){
  for(let j=0;j<BIT_KEYS.length;j++){const k=BIT_KEYS[j],v=a[k];a[k]=b[k];b[k]=v;}
  a.ox=-a.ox;a.tx=-a.tx;a.spin=-a.spin;b.ox=-b.ox;b.tx=-b.tx;b.spin=-b.spin;
}

/** Sample a phrase at τ seconds into F (G: a scratch frame for the lagged tips).
 * side −1 mirrors a `sided` phrase. Returns false (F cleared) when τ is outside it. */
export function sampleEmote(variant,tau,side,F,G){
  clearEmoteFrame(F);
  const id=emotePhrase(variant),E=id&&EMOTE_DEFS[id];
  if(!E||!(tau>=0)||tau>=E.duration)return false;
  F.id=id;E.sample(tau,F);
  if(!F.hasTip){
    // the tips follow through: the phrase's pose `lag` seconds earlier
    if(E.lag){clearEmoteFrame(G);E.sample(Math.max(0,tau-E.lag),G);F.tip.set(G.pose);}
    else F.tip.set(F.pose);
  }
  if(E.sided&&side<0)mirrorEmoteFrame(F);
  return true;
}

/** Scale a frame toward her normal state (w = 1 as played, 0 = nothing): a
 * release, a yield to a combat moment, a fade under a new emote. Every channel
 * is an offset from neutral, so scaling eases her straight back. */
export function scaleEmoteFrame(F,w){
  if(w>=1)return F;
  if(!(w>0))w=0;
  for(let i=0;i<NP;i++){F.pose[i]*=w;F.tip[i]*=w;}
  for(let i=0;i<18;i++)F.ch[i]*=w;
  F.rotL*=w;F.rotR*=w;F.wrapK*=w;F.squeeze*=w;F.still*=w;F.beat=1-(1-F.beat)*w;
  F.bank*=w;F.dx*=w;F.dy*=w;F.glow*=w;F.aura*=w;F.warm*=w;
  for(let i=0;i<4;i++){const b=F.bits[i];b.ox*=w;b.oy*=w;b.spin*=w;b.dim*=w;b.glow*=w;b.focus*=w;b.mix*=w;b.lean*=w;}
  return F;
}
/** Add G (already scaled) into F: an emote fading out under the next one. */
export function addEmoteFrame(F,G){
  for(let i=0;i<NP;i++){F.pose[i]+=G.pose[i];F.tip[i]+=G.tip[i];}
  for(let i=0;i<18;i++)F.ch[i]+=G.ch[i];
  F.hasCh=F.hasCh||G.hasCh;F.hasRot=F.hasRot||G.hasRot;F.rotL+=G.rotL;F.rotR+=G.rotR;
  if(G.wrapK>F.wrapK){F.wrapK=G.wrapK;F.squeeze=G.squeeze;F.side=G.side;}F.hasWrap=F.hasWrap||G.hasWrap;
  if(G.still>F.still)F.stillAt=G.stillAt;F.still=Math.min(1,F.still+G.still);F.beat*=G.beat;
  F.bank+=G.bank;F.dx+=G.dx;F.dy+=G.dy;F.glow+=G.glow;F.aura+=G.aura;F.hasAura=F.hasAura||G.hasAura;F.warm+=G.warm;
  for(let i=0;i<4;i++){const a=F.bits[i],b=G.bits[i];
    a.ox+=b.ox;a.oy+=b.oy;a.spin+=b.spin;a.dim+=b.dim;a.glow+=b.glow;a.focus=Math.max(a.focus,b.focus);a.lean+=b.lean;
    if(b.mix>a.mix){a.mix=b.mix;a.tx=b.tx;a.ty=b.ty;a.ally=b.ally;a.line=b.line;a.slot=b.slot;a.prev=b.prev;}}
  return F;
}
/** Blend a target pose over her current weights (POSES order) into out:
 * w·(1 − Σtarget) + target. Σtarget = 0 leaves them as they are. */
export function blendEmotePose(weights,target,out){
  let sum=0;for(let i=0;i<NP;i++)sum+=target[i];
  if(sum>1)sum=1;
  if(sum<=1e-6){for(let i=0;i<NP;i++)out[i]=weights[i];return out;}
  for(let i=0;i<NP;i++)out[i]=weights[i]*(1-sum)+target[i];
  return out;
}

/* ------------------------------------------------------------ sync and timing */
/** τ (seconds) of a saved emote at the shared server clock `now` (ms). */
export function emoteTau(flag,now){return flag&&Number.isFinite(flag.started)?(now-flag.started)/1000:NaN;}
/** Is the saved emote still playing at `now` (ms)? */
export function emotePlaying(flag,now){const tau=emoteTau(flag,now);return tau>=0&&tau<emoteDuration(flag?.variant??flag?.id);}
/** A saved emote, checked: {id, variant, started, side, ally, key} or null. */
export function readEmoteFlag(raw){
  if(!raw||typeof raw!=='object')return null;
  const variant=typeof raw.variant==='string'?raw.variant:raw.id;
  if(!emotePhrase(variant)||!Number.isFinite(raw.started))return null;
  return {id:typeof raw.id==='string'?raw.id:variant,variant:emotePhrase(variant),started:raw.started,side:raw.side===-1?-1:1,
    ally:typeof raw.ally==='string'&&raw.ally?raw.ally:null,key:typeof raw.key==='string'?raw.key:String(raw.started)};
}
