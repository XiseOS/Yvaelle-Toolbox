/** Routines (v10 beta): the prototype scenes, played around the real token
 * and the real bits. Each one is drawn on a light layer above the map on every
 * connected screen; the owner starts it and only the owner writes anything
 * (a specimen note, the resting flag). Iris, Specimen, Maintenance,
 * Watch Out! and the resting Searchlights live here; Flicker is a warp look. */
import {createOverlay} from './overlay-layer.mjs?v=13.0.0-beta.6';
import {liveBitPositions} from './bit-renderer.mjs?v=13.0.0-beta.6';
import {playCue,stopCue} from './sound-cues.mjs?v=13.0.0-beta.6';
import {versionSetting} from './v10-versions.mjs?v=13.0.0-beta.6';
import {CHRYSALIS,CONSTELLATION,BRIDGE,BRIDGE_MOVE_AT,drawChrysalis,drawConstellation,drawBridge,registerLifelines} from './set-pieces.mjs?v=13.0.0-beta.6';
const ID='filament-flight';
// Ellie's hardlight (the Mechanical iris palette): soft magenta, pale core,
// dusk plum and gold. NEON keeps the legacy Hardlight iris look.
const TAU=Math.PI*2,MAG=[231,103,206],HOT=[255,222,246],VIO=[120,64,132],RED=[255,40,80],NEON=[255,0,255],NEON_HOT=[255,214,255];
// the Mechanical iris keeps Ellie's softer hardlight and gold
const IRIS_MAG=[231,103,206],IRIS_HOT=[255,222,246],GOLD=[207,174,118];
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const ease=t=>t*t*(3-2*t),easeOut=t=>1-(1-t)**3,easeIn=t=>t*t*t;
const lerp=(a,b,t)=>a+(b-a)*t;
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${clamp(a)})`;
const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};

export const ROUTINES=Object.freeze({
  iris:{name:'Mechanical iris',hint:'The bits meet in front of her target, unfold an aperture of filament blades and read it in coded light.',needs:'target',duration:7400},
  specimen:{name:'Specimen in light',hint:'Two bits hold a layered light copy of her target with your note, present it, then file it away.',needs:'target',duration:8800},
  maintenance:{name:'Maintenance',hint:'One bit holds another steady, one reads its seams, one fits a part; they swap roles and test.',needs:null,duration:12000},
  watchOut:{name:'Watch Out!',hint:'A bit darts to an ally, unfolds a warning toward the threat and the wings brace.',needs:'allyThreat',duration:5400},
  chrysalis:CHRYSALIS,constellation:CONSTELLATION,bridge:BRIDGE,
  searchlights:{name:'Resting searchlights',hint:'While she rests, the bits range out around her, each holding to sweep its light across its own area before moving on. Toggle on or off.',needs:null,duration:Infinity}
});

/* ---------------------------------------------------------------- layer */
let layer=null,ticker=null;const active=new Set();const images=new Map();
function view(){return globalThis.canvas?.app?.view??null;}
const overlay=createOverlay('ff-routine-layer');
function ensureLayer(){const L=overlay.ensure();layer=L?.el??null;return L;}
function projector(r,dpr){
  const wt=canvas.stage.worldTransform,sx=r.width/(canvas.app.renderer.screen.width||r.width);
  return {pt:p=>{const q=wt.apply(p);return {x:q.x*sx*dpr,y:q.y*sx*dpr};},scale:wt.a*sx*dpr};
}
const tokenOf=uuid=>{try{return uuid?fromUuidSync(uuid)?.object??null:null;}catch{return null;}};
const centerOf=t=>t?.center??{x:t.x+t.w/2,y:t.y+t.h/2};
function art(src){if(!src)return null;let img=images.get(src);if(!img){img=new Image();img.decoding='async';img.src=src;images.set(src,img);}return img.complete&&img.naturalWidth?img:null;}
const reducedMotion=()=>{try{return !!game.settings.get(ID,'reducedMotion');}catch{return false;}};

function glint(f,x,y,r,c=MAG,a=1){
  if(a<=.01)return;const g=f.createRadialGradient(x,y,0,x,y,r*3);g.addColorStop(0,rgba(c,a*.6));g.addColorStop(1,rgba(c,0));
  f.fillStyle=g;f.beginPath();f.arc(x,y,r*3,0,TAU);f.fill();
  f.fillStyle=rgba([255,240,255],a);f.beginPath();
  f.moveTo(x,y-r*1.7);f.lineTo(x+r*.3,y-r*.3);f.lineTo(x+r*1.7,y);f.lineTo(x+r*.3,y+r*.3);f.lineTo(x,y+r*1.7);f.lineTo(x-r*.3,y+r*.3);f.lineTo(x-r*1.7,y);f.lineTo(x-r*.3,y-r*.3);f.closePath();f.fill();
}
function thread(f,x1,y1,x2,y2,{a=.6,w=1.2,bend=0,dash=null,offset=0,color=MAG}={}){
  if(a<=.01)return;const mx=(x1+x2)/2-(y2-y1)*bend,my=(y1+y2)/2+(x2-x1)*bend;
  f.save();f.globalCompositeOperation='lighter';f.lineCap='round';
  if(dash){f.setLineDash(dash);f.lineDashOffset=offset;}
  f.strokeStyle=rgba(color,a*.35);f.lineWidth=w*3.5;f.beginPath();f.moveTo(x1,y1);f.quadraticCurveTo(mx,my,x2,y2);f.stroke();
  f.strokeStyle=rgba(color,a);f.lineWidth=w;f.stroke();f.strokeStyle=rgba(HOT,a*.7);f.lineWidth=w*.35;f.stroke();
  f.restore();
}
/** Where the real bits are on screen right now (fallback: four wing stations). */
function bitsOn(fx,P){
  const live=liveBitPositions(fx.token);
  if(live.length)return live.map(b=>({...P.pt(b),angle:b.angle,station:b.station}));
  const c=centerOf(fx.token),G=fx.size;
  return [[-.8,-.55],[.8,-.55],[-.7,.45],[.7,.45]].map(([x,y],i)=>({...P.pt({x:c.x+x*G,y:c.y+y*G}),angle:0,station:i}));
}
/** A presented specimen's picture must be an ordinary image path or web
 * address (the sender must own the token, checked by the socket handler). */
function safeImage(src){if(typeof src!=='string'||!src||src.length>512)return false;
  try{const u=new URL(src,location.href);return /^https?:$/.test(u.protocol);}catch{return false;}}
/** A name this player could read on the board anyway, else null. */
function readableName(t){const doc=t?.document;if(!doc)return null;const modes=globalThis.CONST?.TOKEN_DISPLAY_MODES??{};
  return doc.isOwner||[modes.ALWAYS??50,modes.HOVER??20].includes(doc.displayName)?(doc.name??t.name??null):null;}
const nearest=(list,p)=>list.reduce((b,q)=>!b||Math.hypot(q.x-p.x,q.y-p.y)<Math.hypot(b.x-p.x,b.y-p.y)?q:b,null);

/* ---------------------------------------------------------------- play */
/** Play a routine on this screen (every client runs this from the socket). */
export function playRoutine({id,uuid,opts={},start=Date.now()}){
  if(!Object.hasOwn(ROUTINES,id))return null;
  const spec=ROUTINES[id],token=tokenOf(uuid);if(!spec||!token)return null;
  for(const old of active)if(old.uuid===uuid&&old.id===id)active.delete(old);
  const fx={id,uuid,token,opts,start:performance.now()-Math.max(0,Math.min(600,Date.now()-start)),size:Math.max(token.w,token.h)||canvas.grid.size,mem:{}};
  if(opts.target){const t=tokenOf(opts.target);fx.target=t;fx.src=t?.document?.texture?.src;art(fx.src);}
  // a filed specimen presented again carries its own picture and name
  if(id==='specimen'&&safeImage(opts.img)){fx.src=opts.img;art(fx.src);}
  if(opts.ally)fx.ally=tokenOf(opts.ally);if(opts.threat)fx.threat=tokenOf(opts.threat);
  active.add(fx);startTicker();
  if(!opts.silent)playCue(token,`routine_${id}`);
  return fx;
}
export function stopRoutine(uuid,id){for(const fx of [...active])if(fx.uuid===uuid&&(!id||fx.id===id)){active.delete(fx);stopCue(fx.token,`routine_${fx.id}`);}}
function startTicker(){if(ticker)return;ticker=()=>frame();canvas.app.ticker.add(ticker);}
function stopTicker(){if(ticker){canvas.app?.ticker?.remove(ticker);ticker=null;}overlay.release();}
let lastDraw=0;
function frame(){
  // Every routine, resting searchlights included, draws at display rate so
  // its light stays on the bits that carry it.
  lastDraw=performance.now();
  const L=ensureLayer();if(!L){stopTicker();return;}
  const f=L.el.getContext('2d');f.setTransform(1,0,0,1,0,0);f.clearRect(0,0,L.el.width,L.el.height);
  if(!active.size){stopTicker();return;}
  const P=projector(L.r,L.dpr),now=performance.now(),reduced=reducedMotion();
  for(const fx of [...active]){
    const t=(now-fx.start)/1000,spec=ROUTINES[fx.id];
    if(t*1000>=spec.duration||!fx.token||fx.token.destroyed){active.delete(fx);continue;}
    if(!fx.token.visible)continue;
    try{f.save();DRAW[fx.id](f,P,fx,t,reduced);}catch(e){console.warn('Yvaelle’s Toolbox | routine',fx.id,e);active.delete(fx);}finally{f.restore();}
  }
}

/* ---------------------------------------------------------------- 1. iris */
function drawIris(f,P,fx,t,reduced){
  const mech=versionSetting('versionIris')!=='hardlight',MAGc=mech?IRIS_MAG:NEON,HOTc=mech?IRIS_HOT:NEON_HOT;
  const E=centerOf(fx.token),T=fx.target?centerOf(fx.target):{x:E.x+fx.size*3,y:E.y},G=fx.size*P.scale;
  const Cw={x:lerp(E.x,T.x,.6),y:lerp(E.y,T.y,.6)},C=P.pt(Cw),Tp=P.pt(T),TG=(fx.target?Math.max(fx.target.w,fx.target.h):fx.size)*P.scale;
  const bits=bitsOn(fx,P),reach=easeOut(seg(t,0,1.1))*(1-ease(seg(t,6.4,7.2)));
  const unfold=ease(seg(t,1.1,2.0))*(1-ease(seg(t,5.9,6.5))),open=ease(seg(t,2.0,2.8))*(1-ease(seg(t,5.4,6.0)))*(reduced?1:.85+.15*Math.sin(t*3));
  f.globalCompositeOperation='lighter';
  // every real bit threads light to the instrument point
  bits.forEach((b,i)=>{const x=lerp(b.x,C.x,reach),y=lerp(b.y,C.y,reach);thread(f,b.x,b.y,x,y,{color:MAGc,a:.65*Math.min(1,reach*3),w:Math.max(1,G*.012),bend:i%2?.12:-.12});
    if(reach>0&&reach<1)glint(f,x,y,G*.03,MAGc,.9);});
  if(unfold>0){
    if(mech)drawIrisAperture(f,C,G,unfold,open,reduced?0:t);
    else{
      const R=G*.36*unfold,N=8,ap=lerp(G*.03,G*.2,open),rot=(reduced?0:t*.6)+open*.9;
      for(let k=0;k<N;k++){
        const a0=rot+k*TAU/N,a1=a0+TAU/N*1.35,p1=[C.x+Math.cos(a0)*R,C.y+Math.sin(a0)*R],p2=[C.x+Math.cos(a1)*R,C.y+Math.sin(a1)*R],q=[C.x+Math.cos(a0+1.1)*ap,C.y+Math.sin(a0+1.1)*ap];
        f.beginPath();f.moveTo(...p1);f.quadraticCurveTo(C.x+Math.cos(a0+.7)*R*.8,C.y+Math.sin(a0+.7)*R*.8,...q);f.lineTo(...p2);f.closePath();
        f.fillStyle=rgba([120,0,170],.18*unfold);f.fill();f.strokeStyle=rgba(MAGc,.9*unfold);f.lineWidth=Math.max(1,G*.01);f.stroke();
        f.strokeStyle=rgba(HOTc,.6*unfold);f.lineWidth=Math.max(.6,G*.006);f.beginPath();f.moveTo(...p1);f.lineTo(...q);f.stroke();}
      f.strokeStyle=rgba(HOTc,.9*unfold);f.lineWidth=Math.max(1,G*.01);f.beginPath();f.arc(C.x,C.y,ap,0,TAU);f.stroke();
      f.strokeStyle=rgba(MAGc,.7*unfold);f.lineWidth=Math.max(1.2,G*.014);f.beginPath();f.arc(C.x,C.y,R,0,TAU);f.stroke();
      const lens=f.createRadialGradient(C.x,C.y,0,C.x,C.y,ap);lens.addColorStop(0,rgba(HOTc,.55*open));lens.addColorStop(1,rgba(MAGc,.12*open));f.fillStyle=lens;f.beginPath();f.arc(C.x,C.y,ap,0,TAU);f.fill();
    }
  }
  const exam=ease(seg(t,2.8,3.2))*(1-ease(seg(t,5.2,5.6)));
  if(exam>0&&fx.target){
    const ang=Math.atan2(Tp.y-C.y,Tp.x-C.x),nx=-Math.sin(ang),ny=Math.cos(ang);
    const g=f.createLinearGradient(C.x,C.y,Tp.x,Tp.y);g.addColorStop(0,rgba(MAGc,.4*exam));g.addColorStop(1,rgba(MAGc,.08*exam));
    f.fillStyle=g;f.beginPath();f.moveTo(C.x+nx*G*.05,C.y+ny*G*.05);f.lineTo(Tp.x+nx*TG*.5,Tp.y+ny*TG*.5);f.lineTo(Tp.x-nx*TG*.5,Tp.y-ny*TG*.5);f.lineTo(C.x-nx*G*.05,C.y-ny*G*.05);f.closePath();f.fill();
    f.save();f.beginPath();f.arc(Tp.x,Tp.y,TG*.5,0,TAU);f.clip();
    for(let k=0;k<7;k++){const y=Tp.y-TG*.5+(((reduced?0:t*.7)+k/7)%1)*TG;f.fillStyle=rgba(MAGc,.45*exam*(k%2?.6:1));f.fillRect(Tp.x-TG*.5,y,TG,Math.max(1.5,TG*.03));}
    const sx=Tp.x-TG*.5+(((reduced?.4:t*.9))%1)*TG;f.fillStyle=rgba(HOTc,.6*exam);f.fillRect(sx,Tp.y-TG*.5,Math.max(1,TG*.02),TG);f.restore();
    if(!reduced)for(let k=0;k<5;k++){const p=((t*1.4+k/5)%1);glint(f,lerp(Tp.x,C.x,p),lerp(Tp.y,C.y,p)+Math.sin(k*2+t*4)*G*.1*(1-p),G*.015,MAGc,.8*exam);}
  }
  const click=Math.exp(-Math.pow((t-1.1)*9,2));if(click>.02)bits.forEach(b=>glint(f,lerp(b.x,C.x,.98),lerp(b.y,C.y,.98),G*.02,MAGc,click));
}

/** A real mechanical iris: steel blades, each the segment of the housing cut by
 * a line tangent to the aperture, overlap into a turning polygon that opens and
 * closes. Gold bezel ticks, hardlight blade edges and a lens in the opening. */
function drawIrisAperture(f,C,G,unfold,open,t){
  const N=7,R=G*.42*(.35+.65*unfold),ap=R*lerp(.06,.58,open),rot=t*.35+open*1.4-(1-unfold)*1.2,w=Math.max(1,G*.01);
  f.save();f.globalCompositeOperation='source-over';
  // housing disc behind the blades
  f.fillStyle=`rgba(24,16,30,${.55*unfold})`;f.beginPath();f.arc(C.x,C.y,R*1.08,0,TAU);f.fill();
  f.beginPath();f.arc(C.x,C.y,R,0,TAU);f.clip();
  const half=Math.acos(Math.min(.999,ap/R));
  for(let k=0;k<N;k++){
    const th=rot+k*TAU/N,cx=Math.cos(th),sy=Math.sin(th);
    f.beginPath();f.arc(C.x,C.y,R*1.02,th-half,th+half);f.closePath();
    f.fillStyle=`rgba(${k%2?'74,66,90':'60,53,74'},${.92*unfold})`;f.fill();
    // the chord is the blade's working edge: steel lip, then hardlight
    const s=Math.sqrt(Math.max(0,R*R-ap*ap)),tx=C.x+cx*ap,ty=C.y+sy*ap;
    f.beginPath();f.moveTo(tx+sy*s,ty-cx*s);f.lineTo(tx-sy*s,ty+cx*s);
    f.strokeStyle=`rgba(205,214,226,${.55*unfold})`;f.lineWidth=w*1.4;f.stroke();
    f.strokeStyle=rgba(IRIS_MAG,.85*unfold);f.lineWidth=w*.7;f.stroke();
  }
  f.restore();
  // lens light in the opening
  f.save();f.globalCompositeOperation='lighter';
  const lens=f.createRadialGradient(C.x,C.y,0,C.x,C.y,ap*1.1);lens.addColorStop(0,rgba(IRIS_HOT,.6*open));lens.addColorStop(.6,rgba(IRIS_MAG,.32*open));lens.addColorStop(1,rgba(IRIS_MAG,0));
  f.fillStyle=lens;f.beginPath();f.arc(C.x,C.y,ap*1.1,0,TAU);f.fill();f.restore();
  // steel bezel with gold ticks that turn against the blades
  f.save();f.globalCompositeOperation='source-over';f.lineCap='round';
  f.strokeStyle=`rgba(26,18,32,${.8*unfold})`;f.lineWidth=w*4.2;f.beginPath();f.arc(C.x,C.y,R,0,TAU);f.stroke();
  f.strokeStyle=`rgba(190,200,214,${.85*unfold})`;f.lineWidth=w*1.6;f.stroke();
  f.strokeStyle=rgba(GOLD,.9*unfold);f.lineWidth=w*1.1;
  for(let k=0;k<12;k++){const a=-rot*.5+k*TAU/12,l=k%3?.06:.12;f.beginPath();f.moveTo(C.x+Math.cos(a)*R*1.04,C.y+Math.sin(a)*R*1.04);f.lineTo(C.x+Math.cos(a)*R*(1.04+l),C.y+Math.sin(a)*R*(1.04+l));f.stroke();}
  f.restore();
  f.save();f.globalCompositeOperation='lighter';f.strokeStyle=rgba(IRIS_MAG,.55*unfold);f.lineWidth=w;f.beginPath();f.arc(C.x,C.y,R*1.2,0,TAU);f.stroke();f.restore();
}

/* ---------------------------------------------------------------- 2. specimen */
const hologram=new Map();
function tinted(img){
  let c=hologram.get(img);if(c)return c;c=document.createElement('canvas');const s=256;c.width=c.height=s;const g=c.getContext('2d');
  // a light copy: her target's own picture in magenta luminance, keeping its detail
  g.filter='grayscale(1) contrast(1.25) brightness(1.15)';g.drawImage(img,0,0,s,s);g.filter='none';
  g.globalCompositeOperation='multiply';g.fillStyle='#ee8ed9';g.fillRect(0,0,s,s);
  g.globalCompositeOperation='destination-in';g.drawImage(img,0,0,s,s);g.globalCompositeOperation='source-over';hologram.set(img,c);return c;
}
function drawSpecimen(f,P,fx,t,reduced){
  const E=centerOf(fx.token),G=fx.size*P.scale,Hw={x:E.x+fx.size*1.35,y:E.y-fx.size*1.05},present=ease(seg(t,4.8,5.5))*(1-ease(seg(t,7.0,7.6))),fold=ease(seg(t,7.6,8.4));
  const H=P.pt(Hw),cy=H.y-present*G*.2,s=G*.42*(1+present*.4)*(1-fold*.85);
  const bits=bitsOn(fx,P),left=nearest(bits,{x:H.x-s,y:cy}),right=nearest(bits.filter(b=>b!==left),{x:H.x+s,y:cy})??left;
  const on=ease(seg(t,.2,.8))*(1-ease(seg(t,7.4,7.9)));
  f.globalCompositeOperation='lighter';
  if(on>0&&left){thread(f,left.x,left.y,H.x-s*1.15,cy,{a:.7*on,w:Math.max(1,G*.012),bend:.15});thread(f,right.x,right.y,H.x+s*1.15,cy,{a:.7*on,w:Math.max(1,G*.012),bend:-.15});
    const halo=f.createRadialGradient(H.x,cy,0,H.x,cy,s*1.9);halo.addColorStop(0,rgba(MAG,.2*on));halo.addColorStop(1,rgba(MAG,0));f.fillStyle=halo;f.beginPath();f.arc(H.x,cy,s*1.9,0,TAU);f.fill();}
  const img=art(fx.src),build=seg(t,.8,3.2),turn=reduced?1:Math.cos(t*.9);
  if(img&&on>0&&fold<1){const hc=tinted(img);
    for(let k=0;k<4;k++){const r=clamp(build*4-k);if(r<=0)continue;const depth=(k-1.5)*.12;
      f.save();f.translate(H.x+depth*s*(reduced?0:Math.sin(t*.9))*.8,cy-depth*s*.3);f.scale(Math.max(.08,Math.abs(turn))*Math.sign(turn||1),1);
      f.beginPath();f.rect(-s,-s,2*s,2*s*r);f.clip();f.beginPath();f.arc(0,0,s,0,TAU);f.clip();
      f.globalCompositeOperation=k===3?'source-over':'lighter';f.globalAlpha=clamp((k===3?.62:.16)*on*(1-fold));f.drawImage(hc,-s,-s,2*s,2*s);f.restore();}
    f.globalCompositeOperation='lighter';
    f.save();f.beginPath();f.arc(H.x,cy,s,0,TAU);f.clip();
    for(let k=0;k<9;k++){const y=cy-s+(k+.5)*2*s/9;f.fillStyle=rgba(VIO,.18*on);f.fillRect(H.x-s,y,2*s,Math.max(1,s*.02));}f.restore();
    f.strokeStyle=rgba(MAG,.7*on*(1-fold));f.lineWidth=Math.max(1,G*.012);f.beginPath();f.arc(H.x,cy,s,0,TAU);f.stroke();
    f.strokeStyle=rgba(GOLD,.75*on*(1-fold));f.lineWidth=Math.max(.6,G*.005);f.beginPath();f.arc(H.x,cy,s*1.06,0,TAU);f.stroke();
    if(build>0&&build<1){f.fillStyle=rgba(HOT,.85);f.fillRect(H.x-s*1.1,cy-s+2*s*build,s*2.2,Math.max(1,G*.008));}
  }
  if(present>0){const b=reduced?.5:.5+.5*Math.sin(t*2.4);f.strokeStyle=rgba(GOLD,(.25+.3*b)*present);f.lineWidth=Math.max(.8,G*.007);f.beginPath();f.arc(H.x,cy,s*1.18,0,TAU);f.stroke();}
  if(fold>0&&fold<1){const q=easeIn(seg(t,7.6,8.6)),Ep=P.pt(E);glint(f,lerp(H.x,Ep.x,q),lerp(cy,Ep.y,q),G*.04*(1.4-q),MAG,1);}
  // the note, typed in
  const label=String(fx.opts.note||fx.opts.name||'Specimen').slice(0,90),chars=Math.floor(label.length*seg(t,3.2,4.8)),la=on*(1-fold);
  if(chars>0&&la>0){f.globalCompositeOperation='source-over';f.globalAlpha=la;const px=Math.max(11,G*.14)*(1+present*.2);f.font=`italic ${px}px Georgia, serif`;const w=f.measureText(label).width;
    const y=cy+s*1.3;f.fillStyle='rgba(20,10,18,.82)';f.fillRect(H.x-w/2-px*.6,y,w+px*1.2,px*1.6);f.strokeStyle=rgba(GOLD,.6);f.lineWidth=1;f.strokeRect(H.x-w/2-px*.6+.5,y+.5,w+px*1.2,px*1.6);
    f.fillStyle='#f6e6f1';f.fillText(label.slice(0,chars),H.x-w/2,y+px*1.15);f.globalAlpha=1;}
}

/* ---------------------------------------------------------------- 3. maintenance */
function drawMaintenance(f,P,fx,t,reduced){
  const G=fx.size*P.scale,bits=bitsOn(fx,P),n=bits.length;if(n<2)return;
  const round=t<6?0:1,rt=t-(round?6:.6),order=round?[3,2,0,1]:[0,1,2,3],pick=k=>bits[order[k]%n];
  const held=pick(0),holder=pick(1),insp=n>2?pick(2):holder,fit=n>3?pick(3):holder;
  const on=ease(seg(t,.4,1))*(1-ease(seg(t,11.2,11.9)))*(t>5.5&&t<6.3?1-Math.sin(Math.PI*seg(t,5.5,6.3)):1);
  f.globalCompositeOperation='lighter';const w=Math.max(.8,G*.008);
  if(t<10.2){
    // the holder clamps the held bit with two braces
    const dx=held.x-holder.x,dy=held.y-holder.y,l=Math.hypot(dx,dy)||1,nx=-dy/l*G*.04,ny=dx/l*G*.04;
    thread(f,holder.x+nx,holder.y+ny,held.x+nx,held.y+ny,{a:.75*on,w});thread(f,holder.x-nx,holder.y-ny,held.x-nx,held.y-ny,{a:.75*on,w});
    // the inspector reads along the held bit's seam
    const sy=((reduced?.4:rt*.7)%1+1)%1,seamX=held.x-G*.12+G*.24*sy;
    f.fillStyle=rgba(MAG,.16*on);f.beginPath();f.moveTo(insp.x-G*.01,insp.y);f.lineTo(seamX-G*.02,held.y-G*.03);f.lineTo(seamX+G*.02,held.y-G*.03);f.lineTo(insp.x+G*.01,insp.y);f.fill();
    f.fillStyle=rgba(HOT,.75*on);f.fillRect(seamX-w*.3,held.y-G*.05,w*.6,G*.1);
    if(!reduced&&(rt*3.1)%1<.25)glint(f,seamX,held.y+(hash(Math.floor(rt*3.1))-.5)*G*.06,G*.012,MAG,.9*on);
    // the fitter carries a part in and seats it
    const fitIn=ease(seg(rt,1.8,2.8)),fitBack=ease(seg(rt,3.4,4.2)),px=lerp(fit.x,held.x,fitIn*.92),py=lerp(fit.y,held.y,fitIn*.92);
    if(rt>.2&&rt<3.6){const r=G*.025;f.fillStyle=rgba(MAG,.95*on);f.beginPath();f.moveTo(px-r,py);f.lineTo(px,py-r*.65);f.lineTo(px+r,py);f.lineTo(px,py+r*.65);f.closePath();f.fill();f.strokeStyle=rgba(HOT,.9*on);f.lineWidth=w*.4;f.stroke();
      thread(f,fit.x,fit.y,px,py,{a:.5*(1-fitBack)*on,w:w*.6,dash:[G*.02,G*.03],offset:-t*G*.2});}
    const click=Math.exp(-Math.pow((rt-2.85)*10,2));if(click>.02)glint(f,held.x,held.y,G*.03,MAG,click);
  }else{
    // test movement: a ring of light runs through every bit
    const k=seg(t,10.2,11.4);for(let i=0;i<n;i++){const a=bits[i],b=bits[(i+1)%n];thread(f,a.x,a.y,b.x,b.y,{a:.6*Math.sin(Math.PI*k),w,bend:.18});}
    const i=Math.floor(k*n*2)%n;glint(f,bits[i].x,bits[i].y,G*.03,MAG,Math.sin(Math.PI*k));
  }
}

/* ---------------------------------------------------------------- 4. watch out */
function drawWatchOut(f,P,fx,t,reduced){
  const G=fx.size*P.scale,A=fx.ally?P.pt(centerOf(fx.ally)):null,T=fx.threat?P.pt(centerOf(fx.threat)):null;if(!A||!T)return;
  const AG=Math.max(fx.ally.w,fx.ally.h)*P.scale,TG=Math.max(fx.threat.w,fx.threat.h)*P.scale;
  const bits=bitsOn(fx,P),home=fx.mem.home??=nearest(bits,T)??bits[0];
  const dx=T.x-A.x,dy=T.y-A.y,dl=Math.hypot(dx,dy)||1,u=[dx/dl,dy/dl],guard={x:A.x+u[0]*AG*.85,y:A.y+u[1]*AG*.85};
  f.globalCompositeOperation='lighter';
  const snap=seg(t,.3,.6),go=ease(seg(t,.6,1.4)),back=ease(seg(t,4.6,5.4));
  if(t<1.0)glint(f,home.x,home.y,G*.035,MAG,Math.sin(Math.PI*snap));
  // the bit's light darts out to stand guard, then home
  let bx=lerp(home.x,guard.x,go)-(guard.y-home.y)*.2*Math.sin(Math.PI*go),by=lerp(home.y,guard.y,go)+(guard.x-home.x)*.2*Math.sin(Math.PI*go);
  if(back>0){bx=lerp(guard.x,home.x,back);by=lerp(guard.y,home.y,back)-G*.3*Math.sin(Math.PI*back);}
  if(t>.6&&t<5.4){glint(f,bx,by,G*.04,MAG,1);if(go<1&&go>0)thread(f,home.x,home.y,bx,by,{a:.35*(1-go),w:Math.max(1,G*.01)});}
  const warn=ease(seg(t,1.4,2.0))*(1-ease(seg(t,4.0,4.6)));
  if(warn>0){
    f.save();f.translate(bx,by);f.rotate(Math.atan2(u[1],u[0]));
    for(let k=0;k<3;k++){const p=reduced?.3:((t*1.4+k/3)%1),x=G*(.28+k*.28+p*.15),h=G*(.22+k*.11)*warn;f.strokeStyle=rgba(MAG,(.95-k*.22)*warn*(1-p*.6));f.lineWidth=Math.max(1.5,G*(.045-k*.009));
      f.beginPath();f.moveTo(x-G*.1,-h);f.lineTo(x+G*.07,0);f.lineTo(x-G*.1,h);f.stroke();}
    f.restore();
    thread(f,bx,by,T.x-u[0]*TG*.5,T.y-u[1]*TG*.5,{a:.35*warn,w:Math.max(1,G*.01),dash:[G*.04,G*.08],offset:reduced?0:-t*G*.5});
    const a0=Math.atan2(u[1],u[0]);f.lineCap='round';
    f.strokeStyle=rgba(MAG,.85*warn);f.lineWidth=Math.max(3,AG*.06);f.beginPath();f.arc(A.x,A.y,AG*.64,a0-warn,a0+warn);f.stroke();
    f.strokeStyle=rgba(GOLD,.9*warn);f.lineWidth=Math.max(1,AG*.02);f.stroke();
    f.strokeStyle=rgba(RED,.8*warn*(reduced?1:.75+.25*Math.sin(t*6)));f.lineWidth=Math.max(2,TG*.04);f.beginPath();f.arc(T.x,T.y,TG*.56,0,TAU);f.stroke();
  }
}

/* ---------------------------------------------------------------- 5. resting searchlights */
function drawSearchlights(f,P,fx,t,reduced){
  const G=fx.size*P.scale,bits=bitsOn(fx,P),mem=fx.mem;mem.prev??={};mem.ang??={};
  // Speeds and turn rates are tuned per 30 Hz step; scale them by real time.
  const dt=Math.max(1,Math.min(100,(t-(mem.t??t-1/30))*1000)),k30=dt/(1000/30);mem.t=t;
  const fade=ease(seg(t,0,1.2))*(fx.stopping?1-ease(seg(t,fx.stopping,fx.stopping+1)):1);
  if(fx.stopping&&t>fx.stopping+1){active.delete(fx);return;}
  f.globalCompositeOperation='lighter';
  bits.forEach((b,i)=>{
    const key=b.station??i,prev=mem.prev[key];mem.prev[key]={x:b.x,y:b.y};
    // while a bit travels its light leads the way; while it holds, the light
    // sweeps slowly back and forth across the ground outward from Ellie
    const E=P.pt(centerOf(fx.token)),out=Math.atan2(b.y-E.y,b.x-E.x),speed=prev?Math.hypot(b.x-prev.x,b.y-prev.y)/k30:0;
    mem.still??={};mem.still[key]=speed>.6?0:(mem.still[key]??0)+k30;
    let target=out+(reduced?0:.75*Math.sin(t*.45+i*1.9)+.25*Math.sin(t*1.13+i));
    if(speed>.6&&prev)target=Math.atan2(b.y-prev.y,b.x-prev.x);
    const cur=mem.ang[key]??target,rate=1-(1-(speed>.6?.07:.035))**k30;const a=cur+Math.atan2(Math.sin(target-cur),Math.cos(target-cur))*rate;mem.ang[key]=a;
    const dwell=reduced?.5:.5+.5*Math.sin(t*.6+i*2.1),focus=clamp((dwell-.6)/.4),len=G*(1.9-.5*focus),wid=.42-.18*focus;
    f.save();f.translate(b.x,b.y);f.rotate(a);
    const g=f.createLinearGradient(0,0,len,0);g.addColorStop(0,rgba(MAG,(.22+.14*focus)*fade));g.addColorStop(.7,rgba(MAG,(.08+.06*focus)*fade));g.addColorStop(1,rgba(MAG,0));
    f.fillStyle=g;f.beginPath();f.moveTo(0,0);f.lineTo(len,-len*wid);f.quadraticCurveTo(len*1.2,0,len,len*wid);f.closePath();f.fill();
    const pool=f.createRadialGradient(len*.75,0,0,len*.75,0,len*.45);pool.addColorStop(0,rgba(HOT,(.10+.12*focus)*fade));pool.addColorStop(1,rgba(MAG,0));f.fillStyle=pool;f.beginPath();f.arc(len*.75,0,len*.45,0,TAU);f.fill();
    f.restore();glint(f,b.x,b.y,G*.02,MAG,.7*fade);
  });
}
const DRAW={iris:drawIris,specimen:drawSpecimen,maintenance:drawMaintenance,watchOut:drawWatchOut,searchlights:drawSearchlights,chrysalis:drawChrysalis,constellation:drawConstellation,bridge:drawBridge};

/* ---------------------------------------------------------------- starting (owner) */
function emit(msg){game.socket?.emit(`module.${ID}`,msg);return playRoutine(msg);}
const docOf=token=>token?.document??token;
function requireOwner(token){if(!docOf(token)?.isOwner)throw new Error('Pin a character you own to run a routine.');}
/** beta.7: a routine that needs a token no longer stops at "Target one token
 * first". With exactly one target it uses that; otherwise it asks you to click
 * the token on the canvas (or target it with T). Esc or 45 s cancels. */
let picking=null;
export function pickToken(prompt,{exclude=[]}={}){
  const skip=t=>!t||exclude.some(x=>x===t||x?.document===t.document);
  const targets=[...(game.user?.targets??[])].filter(t=>!skip(t));
  if(targets.length===1)return Promise.resolve(targets[0]);
  picking?.(null);
  const note=ui.notifications?.info?.(`${prompt} · Esc cancels`,{permanent:true});
  return new Promise(resolve=>{
    let done=false;
    const finish=token=>{if(done)return;done=true;picking=null;
      try{canvas.stage?.off?.('pointerdown',onDown);}catch{}
      Hooks.off('targetToken',hook);document.removeEventListener('keydown',onKey,true);clearTimeout(timer);
      try{if(note)ui.notifications?.remove?.(note);}catch{}
      if(!token)ui.notifications?.info?.('Cancelled');
      resolve(token??null);};
    const onDown=event=>{
      let p=null;try{p=event?.getLocalPosition?.(canvas.tokens)??null;}catch{}
      p??=canvas.mousePosition;if(!p)return;
      const hit=(canvas.tokens?.placeables??[]).filter(t=>t.visible&&!skip(t)&&t.bounds?.contains?.(p.x,p.y)).sort((a,b)=>(b.zIndex??0)-(a.zIndex??0))[0];
      if(!hit)return;
      try{hit.setTarget?.(true,{releaseOthers:true,groupSelection:false});}catch{}
      finish(hit);
    };
    const hook=Hooks.on('targetToken',(user,token,on)=>{if(user===game.user&&on&&!skip(token))finish(token);});
    const onKey=event=>{if(event.key==='Escape'){event.stopPropagation();finish(null);}};
    document.addEventListener('keydown',onKey,true);
    try{canvas.stage?.on?.('pointerdown',onDown);}catch{}
    const timer=setTimeout(()=>finish(null),45000);
    picking=finish;
  });
}

/** Click a spot on the canvas (within the warp range, if one is set). */
export function pickPoint(prompt){
  picking?.(null);
  const note=ui.notifications?.info?.(`${prompt} · Esc cancels`,{permanent:true});
  return new Promise(resolve=>{
    let done=false;
    const finish=p=>{if(done)return;done=true;picking=null;try{canvas.stage?.off?.('pointerdown',onDown);}catch{}
      document.removeEventListener('keydown',onKey,true);clearTimeout(timer);try{if(note)ui.notifications?.remove?.(note);}catch{}
      if(!p)ui.notifications?.info?.('Cancelled');resolve(p??null);};
    const onDown=event=>{let p=null;try{p=event?.getLocalPosition?.(canvas.tokens)??null;}catch{}p??=canvas.mousePosition;if(!p)return;finish({x:p.x,y:p.y});};
    const onKey=event=>{if(event.key==='Escape'){event.stopPropagation();finish(null);}};
    document.addEventListener('keydown',onKey,true);try{canvas.stage?.on?.('pointerdown',onDown);}catch{}
    const timer=setTimeout(()=>finish(null),45000);picking=p=>finish(p);
  });
}
/** Start a routine for everyone. Options: target (token) for iris/specimen,
 * note for specimen; ally and threat for watchOut. */
export async function startRoutine(token,id,options={}){
  const spec=ROUTINES[id];if(!spec)throw new Error('Unknown routine.');requireOwner(token);
  if(id==='searchlights')return toggleSearchlights(token,options.on);
  if(id==='watchOut')return envoyWatchOut(token,options);
  const opts={};
  // present a filed specimen again: no target needed, nothing new is filed
  if(id==='specimen'&&options.present){const p=options.present;
    emit({type:'routine',id,uuid:docOf(token).uuid,opts:{img:String(p.img??''),name:String(p.name??'').slice(0,90),note:String(p.note??'').slice(0,90)},start:Date.now()});return true;}
  if(spec.needs==='point'){const to=options.to??await pickPoint('Click where the bridge reaches');if(!to)return false;
    const from={x:token.center?.x??token.x+token.w/2,y:token.center?.y??token.y+token.h/2};opts.from=from;opts.to=to;
    // a bridge spans open ground within the warp range; it does not pass walls
    let range=60;try{range=Number(game.settings.get(ID,'warpRange'))||0;}catch{}
    const feet=Math.hypot(to.x-from.x,to.y-from.y)/(canvas.grid?.size||100)*(canvas.scene?.grid?.distance??5);
    if(range&&feet>range+.01){ui.notifications?.warn?.(`Bridge: beyond ${range} ft`);return false;}
    try{const backend=CONFIG.Canvas?.polygonBackends?.move;if(backend?.testCollision?.(from,to,{type:'move',mode:'any'})){ui.notifications?.warn?.('Bridge: a wall is in the way');return false;}}catch{}
    emit({type:'routine',id,uuid:docOf(token).uuid,opts,start:Date.now()});
    // she walks across once the span is laid (the owner moves the token)
    setTimeout(()=>{try{if(token.destroyed||!docOf(token)?.parent)return;let x=to.x-token.w/2,y=to.y-token.h/2;const snapped=token.getSnappedPosition?.({x,y});if(snapped){x=snapped.x;y=snapped.y;}
      void docOf(token).update({x,y}).catch(e=>ui.notifications?.error(`Bridge: ${e?.message??e}`));}catch{}},BRIDGE_MOVE_AT*1000);
    return true;}
  if(spec.needs==='target'){const target=options.target??await pickToken(id==='specimen'?'Click the token to hold in light':id==='chrysalis'?'Click the patient':'Click the token for the iris to read',{exclude:[token]});
    if(!target)return false;opts.target=docOf(target).uuid;
    if(id==='specimen'){opts.note=String(options.note??'').slice(0,90)||await askNote(target);if(opts.note===null)return false;opts.name=readableName(target)??'';
      if(await fileSpecimen(token,target,opts.note))ui.notifications?.info?.('Specimen filed · find it in HUD › Effects › Specimens');}}
  emit({type:'routine',id,uuid:docOf(token).uuid,opts,start:Date.now()});
  return true;
}
async function askNote(target){
  const name=readableName(target)??'Specimen';
  try{const value=await foundry.applications.api.DialogV2.prompt({window:{title:'Specimen note'},
    content:`<label style="display:grid;gap:6px">Your note<input name="note" type="text" maxlength="90" value="${String(name).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}" autofocus></label>`,
    ok:{label:'Hold it in light',callback:(event,button)=>button.form.elements.note.value},rejectClose:false});
    return value==null?null:String(value).trim().slice(0,90)||name;}catch{return name;}
}
/* Specimens live on her actor (beta.7), so the gallery follows her from
 * scene to scene. Older ones filed on a scene token are merged in and moved
 * over the next time one is filed or deleted. */
function specimenHome(token){const doc=docOf(token),actor=doc?.actorId?game.actors?.get(doc.actorId):null;return actor?.isOwner?actor:doc;}
function readSpecimens(token){
  const doc=docOf(token),home=specimenHome(token),seen=new Set(),out=[];
  for(const s of [...(home?.getFlag?.(ID,'specimens')??[]),...(home!==doc?doc?.getFlag?.(ID,'specimens')??[]:[])])
    if(s&&Number.isFinite(s.at)&&!seen.has(s.at)){seen.add(s.at);out.push(s);}
  return out.sort((a,b)=>b.at-a.at).slice(0,24);
}
async function writeSpecimens(token,list){
  const doc=docOf(token),home=specimenHome(token);
  await home.setFlag(ID,'specimens',list.slice(0,24));
  if(home!==doc&&doc?.getFlag?.(ID,'specimens')&&doc.isOwner)await doc.unsetFlag(ID,'specimens');
}
async function fileSpecimen(token,target,note){
  try{const list=readSpecimens(token);list.unshift({name:readableName(target)??'',img:docOf(target)?.texture?.src??'',note,at:Date.now()});
    await writeSpecimens(token,list);return true;}catch(e){console.warn('Yvaelle’s Toolbox | specimen not saved',e);ui.notifications?.warn?.('The specimen could not be filed.');return false;}
}
/** Filed specimens, newest first (at most 24). */
export function listSpecimens(token){try{return structuredClone(readSpecimens(token));}catch{return [];}}
/** Remove one filed specimen by its filing time. */
export async function deleteSpecimen(token,at){
  requireOwner(token);const list=readSpecimens(token).filter(s=>s.at!==at);
  await writeSpecimens(token,list);return list.length;
}
/** Envoy "Watch Out!": posts the action (if she has it) and plays the cue for everyone. */
export async function envoyWatchOut(token,{ally,threat}={}){
  requireOwner(token);
  const targets=[...(game.user?.targets??[])].filter(t=>t!==token);
  const friendly=t=>t.document.disposition===token.document.disposition;
  threat??=targets.find(t=>!friendly(t))??targets[0];
  threat??=await pickToken('Click the threat',{exclude:[token,ally].filter(Boolean)});
  if(!threat)return false;
  const near=list=>list.sort((a,b)=>Math.hypot(a.center.x-threat.center.x,a.center.y-threat.center.y)-Math.hypot(b.center.x-threat.center.x,b.center.y-threat.center.y))[0];
  // the ally: a second target if there is one, else the nearest friendly token to the threat, else ask
  ally??=targets.find(t=>t!==threat&&friendly(t))??targets.find(t=>t!==threat)??
    near(canvas.tokens.placeables.filter(t=>t!==token&&t!==threat&&t.visible&&friendly(t)));
  ally??=await pickToken('Click the ally to warn',{exclude:[token,threat]});
  if(!ally)return false;
  const action=token.actor?.items?.find(i=>i.slug==='watch-out'||/^watch out!?$/i.test(i.name));
  try{if(action?.toMessage)await action.toMessage(undefined,{create:true});
    else await ChatMessage.create({speaker:ChatMessage.getSpeaker({token:token.document}),content:`<p><strong>Watch Out!</strong> ${foundry.utils?.escapeHTML?.(token.name)??token.name} warns <strong>${foundry.utils?.escapeHTML?.(readableName(ally)??'an ally')??'an ally'}</strong> about <strong>${foundry.utils?.escapeHTML?.(readableName(threat)??'a threat')??'a threat'}</strong>.</p>`});}catch(e){console.warn('Yvaelle’s Toolbox | Watch Out! message',e);}
  emit({type:'routine',id:'watchOut',uuid:token.document.uuid,opts:{ally:docOf(ally).uuid,threat:docOf(threat).uuid},start:Date.now()});
  try{const api=game.modules.get(ID)?.api;if(api?.getState?.(token)?.enabled)setTimeout(()=>api.flare?.(token,{strength:.8}),550);}catch{}
  return true;
}
/** Resting searchlights persist on the token, so late joiners see them too. */
export async function toggleSearchlights(token,on){
  const doc=docOf(token),next=!!(on??!doc.getFlag(ID,'restLights')),bits=game.modules.get(ID)?.api?.bits;
  // The bits range out into the Wide search formation while the searchlights
  // are on, and go back to the formation they had when they are turned off.
  const current=doc.getFlag(ID,'bitAllocations')?.groups?.home?.program??null;
  try{
    if(next&&current!=='search'){await doc.setFlag(ID,'restLightsPrev',current??'orbit');await bits?.setGroup?.(token,'home',{program:'search'});}
    if(!next&&current==='search'){const prev=doc.getFlag(ID,'restLightsPrev');await bits?.setGroup?.(token,'home',{program:prev&&prev!=='search'?prev:'orbit'});}
  }catch(e){console.warn('Yvaelle’s Toolbox | searchlight formation',e);}
  await doc.setFlag(ID,'restLights',next);return next;
}
function syncSearchlights(doc,change=false){
  const token=doc?.object;if(!token)return;const want=!!doc.getFlag(ID,'restLights'),running=[...active].find(fx=>fx.uuid===doc.uuid&&fx.id==='searchlights');
  if(want&&!running)playRoutine({id:'searchlights',uuid:doc.uuid,opts:{silent:!change}});
  if(!want&&running&&!running.stopping){running.stopping=(performance.now()-running.start)/1000;playCue(token,'routine_searchlights');}
}
export function registerRoutines(){
  try{registerLifelines();}catch(e){console.warn('Yvaelle’s Toolbox | lifelines',e);}
  Hooks.on('canvasReady',()=>{active.clear();for(const t of canvas.tokens?.placeables??[])syncSearchlights(t.document);});
  Hooks.on('updateToken',(doc,change)=>{if(change?.flags?.[ID]&&('restLights' in change.flags[ID]||'-=restLights' in change.flags[ID]))syncSearchlights(doc,true);});
}
