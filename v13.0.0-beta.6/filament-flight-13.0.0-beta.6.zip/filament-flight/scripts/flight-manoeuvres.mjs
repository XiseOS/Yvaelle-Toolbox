/** Flight manoeuvres: purely visual, client-local wing reactions to the
 * token's rendered motion while she is airborne. Nothing here writes a
 * document, sends a socket message or starts a timer; every client derives the
 * same gestures from the same animated token. Four gestures:
 *  - bank:    the wing rig rolls into a curving path (heading rate)
 *  - brake:   a straight-line stop flares the wings forward and quickens the beat
 *  - pivot:   a turn in place / reversal leaves the wings behind, then they swing through
 *  - descent: falling elevation (or a landing) raises the wings and slows the beat
 * All smoothing is exponential in dt (or an exact damped-spring step), so the
 * result does not depend on the display frame rate. All outputs are bounded.
 *
 * With Flight feel on (beta.24) the manoeuvres ride on the flight itself: they
 * read her flown velocity and her visible climb and descent (not the instant
 * elevation change of real height), the flight mode sets how much each gesture
 * shows, the flight feel keeps the wingbeat pace, and its moments add
 * gestures of their own: the wings rise as she gathers for takeoff and when
 * she stretches, and flare wide when combat starts. The wings stay fixed to
 * her body: with flight feel they never roll, trail or swing round on their
 * own (her whole body carries the momentum, wings and all).
 */
import {POSES,getWingMotionStyle} from './poses.mjs?v=13.0.0-beta.6';
import {flightFeelEnabled} from './flight-feel-runtime.mjs?v=13.0.0-beta.6';

export const MANOEUVRE = Object.freeze({
  bankMax:0.35,        // radians (~20°) of rig roll at a tight turn
  bankSign:-1,         // a clockwise (screen) turn rolls the rig counter-clockwise, as in the prototype
  bankTurn:2.2,        // rad/s of heading change for ~76% of bankMax (tanh knee)
  bankSpeed:[0.25,1.25],// grid spaces/s: bank fades in across this speed band
  brakeAccel:2,        // grid spaces/s² of deceleration before a stop counts as braking
  brakeGain:0.16,       // flare drive per grid space/s of speed shed
  brakeDecay:3,        // 1/s, drive release
  pivotFrequency:8,    // rad/s natural frequency of the lagging wings
  pivotDamping:0.5,    // under-damped: ~16% swing-through
  lagMax:0.55,         // radians the wings may trail behind a new heading/facing
  reversal:1.75,       // radians of heading change inside the window that counts as a reversal
  reversalKick:0.45,   // radians of lag a reversal produces (classic: applied at once)
  reversalSwing:6.2,   // rad/s v10: the same reversal as a spring impulse, peaking ~0.42 rad after ~0.15 s
  reversalWindow:0.6,  // seconds a heading may be missing (passing through a stop)
  descentGain:0.45,    // raise drive per grid unit of elevation lost
  descentDecay:1.4,    // 1/s
  climbGain:0.3,climbDecay:1.6,
  poseCap:0.6          // flare/raise never take more than this share of the pose weights
});

const unit=x=>x>0?x<1?x:1:0;
const clamp=(x,lo,hi)=>x<lo?lo:x>hi?hi:x;
const finite=(x,fallback=0)=>Number.isFinite(x)?x:fallback;
const smoothstep=x=>{x=unit(x);return x*x*(3-2*x);};
const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
const approach=(current,target,dt,rate)=>current+(target-current)*(1-Math.exp(-rate*dt));

export const NO_MANOEUVRE=Object.freeze({bank:0,flare:0,lagRotation:0,raise:0,beatScale:1,active:false});

export function createManoeuvreState(){
  return {bank:0,flare:0,raise:0,lag:0,lagVelocity:0,brake:0,descent:0,climb:0,hold:0,feelBeat:false,
    speed:null,heading:null,headingAge:Infinity,headingSweep:0,kickAge:Infinity,facing:null};
}

/** Exact under-damped spring step towards zero: frame-rate independent. */
function springStep(x,v,dt,w,z){
  if(!x&&!v)return [0,0];
  const wd=w*Math.sqrt(1-z*z),e=Math.exp(-z*w*dt),c=Math.cos(wd*dt),s=Math.sin(wd*dt);
  const b=(v+z*w*x)/wd;
  const nx=e*(x*c+b*s),nv=e*((b*wd-z*w*x)*c-(x*wd+z*w*b)*s);
  return Math.abs(nx)<1e-5&&Math.abs(nv)<1e-4?[0,0]:[nx,nv];
}

/** The pure sampler. `state` is caller-owned memory from createManoeuvreState().
 * input: {vx,vy,speed,accel?,heading,headingRate,elevationRate,facing?,airborne,dt,active,reset,motionReset}
 *  speed/velocity in grid spaces per second, headingRate in rad/s (screen, y down),
 *  elevationRate in grid units per second (negative = descending), airborne 0..1.
 *  `active` false eases everything out; `reset` clears immediately (teleport/warp);
 *  `motionReset` forgets velocity history (no brake from a reset tracker).
 * Returns {bank,flare,lagRotation,raise,beatScale,active}. */
export function stepManoeuvre(state,input={}){
  const M=MANOEUVRE;
  if(input.reset){Object.assign(state,createManoeuvreState(),{facing:Number.isFinite(input.facing)?input.facing:null});return NO_MANOEUVRE;}
  const dt=clamp(finite(input.dt),0,0.1);
  const gate=input.active===false?0:unit(input.airborne===true?1:input.airborne===false?0:finite(input.airborne));
  const speed=Math.max(0,finite(input.speed,Math.hypot(finite(input.vx),finite(input.vy))));
  const headingRate=finite(input.headingRate);
  if(input.motionReset){state.speed=null;state.heading=null;state.headingSweep=0;state.headingAge=Infinity;}
  // Flight feel (beta.24): the mode's share of each gesture, and its moments.
  const share=input.share??null,bankShare=finite(share?.bankRoll,1),flareShare=finite(share?.flare,1),raiseShare=finite(share?.raise,1),whipShare=finite(share?.whip,1);
  state.feelBeat=!!input.feelBeat;
  // With flight feel the wings stay fixed to her: they change shape (flare,
  // rise) but never roll, trail or swing round on their own.
  const rigid=!!input.rigid;
  if(rigid){state.bank=0;state.lag=0;state.lagVelocity=0;state.headingSweep=0;}
  const cue=input.cue;
  if(cue&&gate>0){
    if(cue.flare)state.brake=Math.min(1,state.brake+cue.flare*flareShare);
    if(cue.raise)state.descent=Math.min(1.2,state.descent+cue.raise);
    if(cue.whip&&!rigid)state.lagVelocity=clamp(state.lagVelocity+cue.whip*whipShare,-20,20);
  }
  state.hold=approach(state.hold??0,unit(finite(input.hold))*gate,dt>0?dt:0,6);
  if(dt<=0)return output(state);

  // Bank: roll into a curving path, fading in with speed.
  const speedGate=smoothstep((speed-M.bankSpeed[0])/(M.bankSpeed[1]-M.bankSpeed[0]));
  const bankTarget=rigid?0:gate*M.bankSign*M.bankMax*Math.tanh(headingRate/M.bankTurn)*speedGate*bankShare;
  state.bank=approach(state.bank,bankTarget,dt,Math.abs(bankTarget)>Math.abs(state.bank)?7:3.5);

  // Brake: speed shed on a straight line (turning corners also lose |v|).
  const accel=Number.isFinite(input.accel)?input.accel:state.speed==null?0:(speed-state.speed)/dt;
  state.speed=speed;
  const straight=1-smoothstep(Math.abs(headingRate)/1.6);
  const impulse=accel< -M.brakeAccel?-accel*dt*M.brakeGain*straight*gate*flareShare:0;
  state.brake=Math.min(1,state.brake*Math.exp(-M.brakeDecay*dt)+impulse);
  // (A mode can hold the wings partly flared: Surge coiled, ready to burst.)
  state.holdFlare=approach(state.holdFlare??0,unit(finite(input.holdFlare))*gate,dt,4);
  const flareTarget=Math.max(state.brake*gate,state.holdFlare);
  state.flare=approach(state.flare,flareTarget,dt,flareTarget>state.flare?14:5);

  // Pivot: the wings keep their old orientation, then a spring swings them through.
  const facing=input.facing;
  if(Number.isFinite(facing)){
    if(state.facing!=null&&!rigid){const df=wrap(facing-state.facing);if(df)state.lag-=df*gate;}
    state.facing=facing;
  }
  const heading=input.heading;
  state.headingAge+=dt;state.kickAge+=dt;
  if(Number.isFinite(heading)&&speed>0.15){
    if(state.heading!=null&&state.headingAge<=M.reversalWindow)state.headingSweep+=wrap(heading-state.heading);
    state.heading=heading;state.headingAge=0;
  }
  state.headingSweep*=Math.exp(-3*dt);
  if(!rigid&&Math.abs(state.headingSweep)>M.reversal&&state.kickAge>M.reversalWindow){
    // v10: an impulse, so the wings whip round and swing back instead of
    // jumping ~25° in one frame. Classic keeps the instant displacement.
    if(getWingMotionStyle()==='classic')state.lag-=Math.sign(state.headingSweep)*M.reversalKick*gate;
    else state.lagVelocity-=Math.sign(state.headingSweep)*M.reversalSwing*gate;
    state.headingSweep=0;state.kickAge=0;
  }
  state.lag=clamp(state.lag,-M.lagMax,M.lagMax);
  [state.lag,state.lagVelocity]=springStep(state.lag,state.lagVelocity,dt,M.pivotFrequency,M.pivotDamping);
  state.lag=clamp(state.lag,-M.lagMax,M.lagMax);state.lagVelocity=clamp(state.lagVelocity,-20,20);

  // Descent: integrate elevation lost (frame-rate independent impulse), decay slowly.
  const elevationRate=finite(input.elevationRate);
  state.descent=Math.min(1.2,state.descent*Math.exp(-M.descentDecay*dt)+Math.max(0,-elevationRate)*dt*M.descentGain*gate*raiseShare);
  state.climb=Math.min(1,state.climb*Math.exp(-M.climbDecay*dt)+Math.max(0,elevationRate)*dt*M.climbGain*gate);
  const raiseTarget=Math.max(Math.min(1,state.descent)*gate,state.hold);
  state.raise=approach(state.raise,raiseTarget,dt,raiseTarget>state.raise?6:2.5);

  // Settle tiny values so an idle token reports an exactly neutral result.
  for(const key of ['bank','flare','raise','brake','descent','climb','hold','holdFlare'])if(Math.abs(state[key]??0)<1e-4)state[key]=0;
  return output(state);
}

function output(state){
  // With flight feel the wingbeat pace is the feel's (it already quickens for
  // a stop or a climb and eases in a descent): no second speed-up here.
  const beatScale=state.feelBeat?1:clamp(1+0.6*state.flare-0.45*state.raise+0.15*state.climb,0.5,1.7);
  const active=!!(state.bank||state.flare||state.raise||state.lag||state.climb);
  return active?{bank:state.bank,flare:state.flare,lagRotation:state.lag,raise:state.raise,beatScale,active}:NO_MANOEUVRE;
}

/** Give `a` and `b` of the weight to two target poses (a+b<=1) without leaving the simplex. */
function toward(weights,ia,a,ib,b){
  if(!(a>0)&&!(b>0))return weights;
  const keep=1-a-b;
  return weights.map((v,i)=>v*keep+(i===ia?a:0)+(i===ib?b:0));
}
const FLARE=POSES.indexOf('aggressiveFlare'),RAISED=POSES.indexOf('raised');

/** Landing raise is a pure function of the saved transition's progress, so
 * every client agrees without any local history. */
export function landingRaise(transition,progress,active){
  if(!active||transition?.kind!=='landing'||!(transition.fromFlight>transition.toFlight))return 0;
  const p=unit(progress),up=smoothstep(p/0.2),down=smoothstep((p-0.55)/0.45);
  return up*(1-down);
}

/** Resolve a sampled manoeuvre into render-state changes. Additive and capped:
 * an explicit (non-neutral) pose, a temporary pose or a condition keeps priority.
 * raw: stepManoeuvre output (or null). Returns null when nothing applies. */
export function resolveManoeuvre(raw,{config,airborne=1,arrest=0,collapse=0,frozen=false,posesEnabled=false,
  weights,tipWeights,condition='normal',transition=null,progress=1,transitionActive=false}={}){
  if(!raw||config?.flightManoeuvres===false||config?.reduced||frozen)return null;
  const strength=unit(airborne)*(1-unit(arrest))*(1-unit(collapse));
  const landing=landingRaise(transition,progress,transitionActive)*(1-unit(arrest));
  if(!(strength>0)&&!(landing>0))return null;
  const bank=finite(raw.bank)*strength,lag=finite(raw.lagRotation)*strength;
  const flare=unit(raw.flare)*strength,raise=Math.max(unit(raw.raise)*strength,landing);
  const beatScale=clamp(1+(finite(raw.beatScale,1)-1)*strength-0.3*landing,0.5,1.7);
  const result={bank,flare,lagRotation:lag,raise,beatScale,
    rotation:bank+lag,
    // Narrow slightly while banked; widen as the wings flare against a stop.
    width:1-0.07*unit(Math.abs(bank)/MANOEUVRE.bankMax)+0.1*flare,
    // Asymmetric squash for the existing per-side sweep (drops/compresses the wing the roll dips).
    asymmetry:0.4*clamp(bank/MANOEUVRE.bankMax,-1,1),
    weights,tipWeights};
  const usable=posesEnabled&&config?.wingRenderer!=='atlas'&&Array.isArray(weights)&&weights.length===POSES.length;
  if(usable&&(flare>0||raise>0)){
    const conditionGate=condition&&condition!=='normal'?0.5:1;
    const pose=(w)=>{
      // Only the neutral share can be borrowed; flare and raise together never exceed the cap.
      const cap=MANOEUVRE.poseCap*unit(w[0])*conditionGate,a=flare*cap,b=raise*cap,total=a+b,fit=total>cap?cap/total:1;
      return toward(w,FLARE,a*fit,RAISED,b*fit);
    };
    result.weights=pose(weights);
    result.tipWeights=Array.isArray(tipWeights)&&tipWeights.length===POSES.length?pose(tipWeights):tipWeights;
  }
  if(!result.rotation&&result.width===1&&result.beatScale===1&&result.weights===weights)return null;
  return result;
}

/** The wing rig's extra roll for this frame. Drag previews never manoeuvre. */
export function manoeuvreRotation(s,snapshot){
  return s?.previewOf?0:finite(snapshot?.manoeuvre?.rotation);
}
export function manoeuvreWidth(s,snapshot){
  return s?.previewOf?1:finite(snapshot?.manoeuvre?.width,1);
}

/* ------------------------------------------------------------ demo (beta.7)
 * Manoeuvres are automatic, so they are easy to miss. A demo plays them in
 * place on this screen only, feeding the same sampler with a scripted path;
 * the token never moves. With Flight feel Classic: a curve each way (bank), a
 * dash that stops dead (brake), a reversal (pivot) and a drop in height
 * (descent). With Flight feel v10 the wings are fixed to her and never roll
 * or swing round, so the demo shows what v10 flight really does (beta.29):
 * two dashes that stop (the wings flare forward to brake), then a drop in
 * height (they rise and the beat slows). */
export const MANOEUVRE_DEMO_DURATION=6.2;
const demos=new WeakMap();
export function startManoeuvreDemo(token){const doc=token?.document??token;if(!doc)return false;demos.set(doc,{t:0,heading:0,step:0});return true;}
export function manoeuvreDemoActive(token){const d=demos.get(token?.document??token);return !!d&&d.t<MANOEUVRE_DEMO_DURATION;}
function demoInputRigid(demo,dt){
  const t=demo.t+=dt;
  let speed=0,elevationRate=0;
  if(t<.55)speed=4.5;                          // a dash…
  else if(t<.67)speed=4.5*(1-(t-.55)/.12);     // …that stops: brake
  else if(t<1.9)speed=0;
  else if(t<2.45)speed=4.5;                    // again
  else if(t<2.57)speed=4.5*(1-(t-2.45)/.12);
  else if(t<3.5)speed=0;
  else if(t<4.6)elevationRate=-2.6;            // drop: descent
  return {speed,vx:speed,vy:0,heading:0,headingRate:0,elevationRate};
}
function demoInput(demo,dt){
  const t=demo.t+=dt;
  let speed=0,rate=0,elevationRate=0,flip=false;
  if(t<1.2){speed=3;rate=2.6;}                 // bank into a curve
  else if(t<2.3){speed=3;rate=-2.6;}           // and the other way
  else if(t<2.8){speed=4.5;}                   // a straight dash…
  else if(t<2.92){speed=4.5*(1-(t-2.8)/.12);}  // …that stops dead: brake
  else if(t<3.6){speed=0;}
  else if(t<3.75){speed=2.5;}                  // set off…
  else if(t<3.95){speed=2.5;flip=demo.step<1;} // …and turn straight back: pivot
  else if(t<4.4){speed=0;}
  else if(t<5.5){elevationRate=-2.6;}          // drop: descent
  if(flip){demo.heading+=Math.PI;demo.step=1;}
  demo.heading+=rate*dt;
  return {speed,vx:Math.cos(demo.heading)*speed,vy:Math.sin(demo.heading)*speed,heading:demo.heading,headingRate:rate,elevationRate};
}

/** Runtime adapter: read one rendered token and advance its manoeuvre memory.
 * Uses the existing per-frame kinematics (trackMovement) plus the rendered
 * elevation and facing. Returns the stepManoeuvre output (stored as s.manoeuvre). */
export function sampleTokenManoeuvre(s,token,config,dt){
  const memory=s.manoeuvreMemory??=createManoeuvreState();
  const source=s.source,k=s.kinematics??{},snapshot=s.snapshot;
  const facing=finite(source?.rotation);
  const enabled=config.flightManoeuvres!==false&&!config.reduced&&!token.isPreview&&!s.previewOf;
  const reset=!enabled||s.manoeuvreReset===true||memory.source!==source;
  s.manoeuvreReset=false;memory.source=source;
  const rendered=finite(source?.elevation,finite(token.document?.elevation));
  const units=finite(globalThis.canvas?.scene?.grid?.distance??globalThis.canvas?.dimensions?.distance,5)||5;
  if(reset){memory.elevation=rendered;stepManoeuvre(memory,{reset:true,facing});memory.epoch=k.epoch;return s.manoeuvre=NO_MANOEUVRE;}
  const motionReset=memory.epoch!==k.epoch;memory.epoch=k.epoch;
  const step=Number.isFinite(dt)&&dt>0&&dt<=0.25?dt:0;
  const dz=Number.isFinite(memory.elevation)?rendered-memory.elevation:0;memory.elevation=rendered;
  const r=snapshot?.rendering;
  const airborne=r&&r.wingsActive&&r.flightActive?unit(r.flightFactor):0;
  const demo=demos.get(token.document);
  if(demo){
    if(demo.t<MANOEUVRE_DEMO_DURATION&&airborne>0&&step>0){
      // (v10: the same rule as her flight: the wings never roll or swing round.)
      const rigid=flightFeelEnabled(),d=rigid?demoInputRigid(demo,step):demoInput(demo,step);
      return s.manoeuvre=stepManoeuvre(memory,{...d,facing:memory.facing??facing,airborne,dt:step,active:true,motionReset:false,rigid,share:rigid?s.feelShare??null:null});}
    if(demo.t>=MANOEUVRE_DEMO_DURATION||airborne<=0)demos.delete(token.document);
  }
  // Flight feel on: ride on her flight. Her flown velocity (token sizes/s,
  // converted to grid spaces), her visible climb or descent (ft/s), the
  // mode's share of each gesture and the feel's moments since last frame.
  const f=s.feelState&&!s.feelState.sleeping&&s.feel?s.feelState:null;
  const cue=s.feelCue??null;s.feelCue=null;
  if(f){
    const grid=finite(globalThis.canvas?.grid?.size,0)||Math.max(token.w||100,token.h||100),ratio=Math.max(token.w||grid,token.h||grid)/grid;
    // Her body's own motion (momentum included), not the token's.
    const vx=(f.bvx??f.vx)*ratio,vy=(f.bvy??f.vy)*ratio,speed=Math.hypot(vx,vy),ax=(f.bax??f.ax)*ratio,ay=(f.bay??f.ay)*ratio;
    const along=speed>.05?(ax*vx+ay*vy)/speed:0,turn=speed>.25?(vx*ay-vy*ax)/(speed*speed):0;
    return s.manoeuvre=stepManoeuvre(memory,{vx,vy,speed,accel:along,heading:speed>.05?Math.atan2(vy,vx):undefined,headingRate:clamp(turn,-6,6),
      elevationRate:finite(f.altV)/units,facing,airborne,dt:step,active:airborne>0,motionReset,
      feelBeat:true,rigid:true,share:s.feelShare??null,cue,hold:s.feelHold??0,holdFlare:s.feelFlareHold??0});
  }
  return s.manoeuvre=stepManoeuvre(memory,{vx:k.vx,vy:k.vy,speed:k.speed,heading:k.heading,headingRate:finite(k.turn)*4,
    elevationRate:step?dz/units/step:0,facing,airborne,dt:step,active:airborne>0,motionReset});
}
