import {mixWeights,weightsFor} from './poses.mjs?v=13.0.0-beta.6';
const GUARD=weightsFor('forwardGuard');
import {ID} from './config.mjs?v=13.0.0-beta.6';
import {AtlasRenderer, isShown, placeBehind, isOnScreen,setMeshTransform,effectMeshClass} from './renderer.mjs?v=13.0.0-beta.6';
import {CUE_SLOTS} from './conditions.mjs?v=13.0.0-beta.6';
import {bitRestVisible} from './bit-collapse.mjs?v=13.0.0-beta.6';
import {LAYER_NAMES, frameGeometry, paintLayers} from './wing-rig.mjs?v=13.0.0-beta.6';
import {TrailRenderer,wingTransform} from './trails.mjs?v=13.0.0-beta.6';
import {bitAssets} from './bit-assets.mjs?v=13.0.0-beta.6';
import {BitRenderer,separateBits} from './bit-renderer.mjs?v=13.0.0-beta.6';
import {CompactBitRenderer,compactWingHandoff,compactBitTransform} from './compact-bit-renderer.mjs?v=13.0.0-beta.6';
import {wingPhase} from './wing-phase.mjs?v=13.0.0-beta.6';
import {readBitIntentTarget} from './bit-intent.mjs?v=13.0.0-beta.6';
import {layerGlow,stableLayerViewport,sameLayerPixels} from './render-regions.mjs?v=13.0.0-beta.6';
import {wingWorkerPool,supportsWingWorker,wingFrameInput} from './wing-worker-client.mjs?v=13.0.0-beta.6';
import {v7SemanticGems,v7SemanticIdentity} from './v7-artwork-identity.mjs?v=13.0.0-beta.6';
import {localPerformance} from './performance.mjs?v=13.0.0-beta.6';
import {WingEffectTransition} from './wing-effect-transition.mjs?v=13.0.0-beta.6';
import {applyBitWaveDirections,acquireBitWaveDirections} from './bit-wave-direction.mjs?v=13.0.0-beta.6';
import {lanternArtworkIdentity} from './runtime-activity.mjs?v=13.0.0-beta.6';
import {bitLanternInFrame} from './bit-lantern.mjs?v=13.0.0-beta.6';
import {v7WingRigRequired} from './v7-wing-material.mjs?v=13.0.0-beta.6';
import {bruiseSpots,bruiseKey,paintBruise} from './bruised-light.mjs?v=13.0.0-beta.6';
import {displayHold} from './repaint-cadence.mjs?v=13.0.0-beta.6';
import {damageRuntime} from './v11/damage-runtime.mjs?v=13.0.0-beta.6';
import {healRuntime} from './v11/heal-runtime.mjs?v=13.0.0-beta.6';
import {invisHooks,veilAlphaOf} from './v11/invis-hooks.mjs?v=13.0.0-beta.6';
import {emoteRuntime} from './v11/emote-runtime.mjs?v=13.0.0-beta.6';
import {worldRuntime} from './v11/world-runtime.mjs?v=13.0.0-beta.6';

const RESOLUTION={low:384,medium:512,high:768};

const BIT_EXTENT_KEYS=['leftUpperX','leftUpperY','rightUpperX','rightUpperY','leftLowerX','leftLowerY','rightLowerX','rightLowerY'];

/** Animation progress is frame input, not a new command. Invalidating the
 * worker for each progress sample forced every deployment onto the UI thread. */
export function bitTransitionIdentity(transition){
  if(!transition)return null;
  const {id,started,duration,from,to}=transition;
  return {id,started,duration,from,to};
}

/** Per-viewer v10 wing options ride on the visual profile so the worker sees them too.
 * The profile's copy of the condition response (~7 KB, read by nothing that
 * paints) stays out of the frame signature and the worker message. */
function withWingStyle(visual,config,wingScale){
  const soul=config.wingLightStyle==='soul',follow=config.wingFollowThrough===true;
  // Portrait radius in artwork units (600 = the wing frame), for v10 face clearance.
  const portrait=config.foregroundWings&&Number.isFinite(wingScale)&&wingScale>0?Math.round(3000/wingScale)/10:0;
  return soul||follow||portrait||visual.conditionResponse!==undefined?{...visual,...(soul?{lightStyle:'soul'}:{}),...(follow?{followThrough:1}:{}),...(portrait?{portraitRadius:portrait}:{}),conditionResponse:undefined}:visual;
}
export class WingRigRenderer {
  constructor(token,quality='medium') {
    this.token=token;this.quality=quality;this.size=RESOLUTION[quality]??512;this.layers={};this.layerRecords=[];this.contexts={};this.viewports={};this.failedBitQuality=null;this.workerEpoch=0;this.workerSequence=0;
    const waves=acquireBitWaveDirections(token);this.waveState=waves.memory;this.releaseWaves=waves.release;
    const EffectMesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
    this.releaseBitAssets=bitAssets.acquire();
    try {
      for (const key of LAYER_NAMES) {
        const layer=this.layers[key]={key,front:key.endsWith('Front'),left:key.startsWith('left')};
        this.layerRecords.push(layer);
        const surface=layer.surface=document.createElement('canvas');surface.width=surface.height=1;
        layer.context=surface.getContext('2d');
        if (!layer.context) throw new Error('A 2D canvas is needed for filament poses. Select Original atlas in the module settings.');
        this.contexts[key]=layer.context;
        layer.texture=PIXI.Texture.from(surface,{mipmap:PIXI.MIPMAP_MODES?.OFF??0});
        layer.mesh=new EffectMesh({name:`${ID}.${token.id}.${key}`,texture:layer.texture},Shader);
        const mesh=layer.mesh;mesh.anchor.set(0.5);mesh.eventMode='none';mesh.interactive=false;mesh.visible=false;mesh.alpha=0;
        canvas.primary.addChild(mesh);
      }
    } catch(error) {this.destroy();throw error;}
  }

  update(s,snapshot,config,now,opacity=1) {
    localPerformance.recordQuality(config);
    if(this.paintBackend)localPerformance.recordRenderPath(this.paintBackend);
    const source=s.source,token=this.token,profile=snapshot.visual.profile,transform=wingTransform(s,snapshot);
    // The handoff starts on the display frame of the change (not the next
    // texture slot), so the eased opacity below never shows the new look first.
    const handoff=this.effectHandoff??=new WingEffectTransition();
    const effectChanging=handoff.update(snapshot,config,now);
    const alpha=source.alpha*s.opts.opacity*transform.presence*snapshot.effective.intensity*opacity*handoff.opacity(profile,now);
    // This transient field gate must travel with the worker request as well as
    // the synchronous painter. Including it in both identities below cancels
    // an in-flight powered frame when collapse begins, without rewriting the
    // user's component switches or invalidating every recovery sample.
    const fieldsSuppressed=snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse.mix>.01;
    const components=fieldsSuppressed?{...config.performanceComponents,fields:false}:config.performanceComponents;
    let bitRadius=3;for(const key of BIT_EXTENT_KEYS)bitRadius=Math.max(bitRadius,Math.abs(snapshot.gems[key]??0));
    const bitExtent=bitRadius*100+120;
    const extent=bitExtent/600*Math.max(transform.width,transform.height)*1.42;
    const shown=isShown(token,source)&&alpha>0&&(isOnScreen(transform.x,transform.y,extent,extent)||bitRestVisible(snapshot,isOnScreen))&&!(components?.wings===false&&components?.bits===false);
    this.shown=shown;this.current={snapshot,config,transform,source,alpha,now};
    // Context switches are commands, not animation samples. Reject a queued
    // ground cradle immediately on takeoff (and a queued transition on
    // settlement), even when the next artwork slot has not arrived yet.
    const mounting=snapshot.lantern?.mounting,bridge=snapshot.lantern?.mountingTransition;
    const mountingKey=`${mounting??''}|${bridge?.started??''}|${bridge?.to??''}`;
    if(this.lanternMountingKey!==undefined&&this.lanternMountingKey!==mountingKey){
      this.workerEpoch++;this.workerLease?.cancel();this.workerSemantic=null;this.signature=undefined;this.lastSlot=undefined;
    }
    this.lanternMountingKey=mountingKey;
    // A fully transparent rig needs no geometry or texture uploads. Retain the
    // last frame and attachments so visibility can resume without rebuilding.
    if (!shown) {this.sleep();return;}
    const wingEvent=snapshot.requested?.v7?.wingGesture,wingElapsed=now-(wingEvent?.started??now);
    const wingChanging=!!snapshot.v7?.wingMotion?.active&&(!wingEvent||wingEvent.releaseOnly||wingElapsed<wingEvent.enter||wingElapsed>=wingEvent.enter+wingEvent.hold);
    // (v11) an emote playing on her (v11/emote-runtime.mjs): null almost always (one Map lookup)
    const emote=emoteRuntime.active.size?emoteRuntime.wing(token,now,transform):null;
    const changing=!!emote||wingChanging||(['changing','entering','returning'].includes(snapshot.poseAnimation.phase)&&snapshot.poseMotion.enabled&&config.advancedPoses)||snapshot.structureAnimation?.active||snapshot.structureAnimation?.poseActive||effectChanging;
    const fps=changing?Math.max(config.rigFPS,config.poseFPS??config.rigFPS):config.rigFPS;
    // Beta.29: repaint on whole display frames. A time slot (24 fps on a
    // 60 Hz canvas) held pictures for 2,3,2,3 frames and the beat juddered;
    // an even hold (every frame at 60, every 2nd at 30) stays steady.
    const slot=this.displayFrame(now),hold=this.displayHold(fps);
    if (this.lastSlot===undefined || slot-this.lastSlot>=hold || slot<this.lastSlot) {
      // Bruised light (beta.26): where a hit has knocked the light out of her
      // wings this frame. Every layer painted from here on is finished with it.
      const spots=!config.reduced&&s.feel?.bruise?.length?bruiseSpots(s.feel.bruise):null;
      this.bruise=spots;this.bruiseKey=bruiseKey(spots);
      // Frame comparison itself belongs inside the cap; attachments still update
      // every ticker below. This avoids serializing the same state at display FPS.
      const styled=withWingStyle(profile,config,s.opts?.wingScale),settled=!changing&&!snapshot.formation.active;
      // Flight feel: the panes bend with how hard she is working.
      const flexed=s.feelFlex?{...styled,flightFlex:s.feelFlex}:styled;
      // v11: wounds, persistent damage, dying, mood and fatigue (scripts/v11/damage-runtime.mjs); untouched when nothing shows.
      const damaged0=damageRuntime.wingVisual(token,flexed,{moving:!config.reduced});
      // v11 (phase 3a): heals, spell traditions, Hero Points, level-up ribs (v11/heal-runtime.mjs); untouched when nothing shows.
      const healed=healRuntime.wingVisual(token,damaged0);
      // (v11) an emote: the shoulder turn and Comfort's wrap ride on the visual profile, to the off-thread painter too
      const emoted=emote?emoteRuntime.visual(emote,healed):healed;
      // (v11) her wings and the world: a wing folds near a wall, the light nearby tints her (v11/world-runtime.mjs); untouched when neither shows.
      const damaged=worldRuntime.wingVisual(token,emoted,s,transform,config,now);
      // (v11) shadow wings, last: while she is invisible or hidden the light drains from her filaments, and from all of the above (v11/invis-runtime.mjs)
      const drain=invisHooks.drain?.(token,now)??null,drained=drain?{...damaged,v11Drain:drain}:damaged;
      // (test.21) while her portrait is see-through (hidden, ghost kept) the wing strands that pass behind it are cleared, so they do not show through her
      // (test.22: the hole is her token as drawn, in the wings' own space, so her wing offsets, scale and stretch are followed; test.21 assumed none)
      let behind=null;
      if(invisHooks.through?.(token)&&transform.width>1&&transform.height>1){
        const kx=600/transform.width,ky=600/transform.height,ts=transform.size??Math.max(token.w,token.h),R=Math.max(ts,(Number(source.width)||0)*(s.altScale??1),(Number(source.height)||0)*(s.altScale??1))*.52;
        behind=[Math.round(-(s.opts?.offsetX??0)*ts*kx),Math.round(15-(s.opts?.offsetY??0)*ts*ky),Math.round(R*kx/2)*2,Math.round(R*ky/2)*2];
      }
      const visual=behind?{...drained,v11Behind:behind}:drained;
      // Wing shield: the wings sweep forward into the guard pose while it is raised.
      // (12.0.0-beta.2: not for Wing wrap, whose own copy of her wings folds about her instead)
      const guard=s.feelShield>.01&&s.shieldStyle!=='wingwrap'?Math.round(s.feelShield*.45*20)/20:0;
      const guarded=guard?mixWeights(snapshot.poseAnimation.weights,GUARD,guard):snapshot.poseAnimation.weights,{formation,movement}=snapshot;
      if(guard)snapshot={...snapshot,poseAnimation:{...snapshot.poseAnimation,weights:guarded,tipWeights:mixWeights(snapshot.poseAnimation.tipWeights,GUARD,guard)}};
      // (v11) an emote's pose blends over hers (its tips in the emote's own record, set on the painter's input below)
      const weights=emote?emoteRuntime.weights(emote,guarded,snapshot.poseAnimation.tipWeights):guarded;
      // Legacy toggle keeps its original wing/hover easing. Bits alone use that
      // same existing blend to deploy from (or retract to) the back roots.
      const freeBits=snapshot.gems.style==='choreographed'||(snapshot.gems.style==='classic'&&snapshot.gems.rigRequired);
      const stabilizerDeployment=formation.explicit||!freeBits||config.reduced||s.blend>.995?1:s.blend<.002?0:s.blend;
      const moving=visual.lightStyle==='soul'||(freeBits&&snapshot.gems.animated&&snapshot.gems.strength>0&&!config.reduced&&visual.animated!==false)||
        (visual.dynamic??(visual.animated&&(visual.glitch>0||visual.instability>0)))||!!emote||!!snapshot.movement?.modeAnimated||!!(snapshot.structureAnimation?.animated&&snapshot.structureAnimation?.rigRequired)||snapshot.bitSequenceActive||!!snapshot.v7?.wingMotion?.active;
      const phase=wingPhase(s,snapshot,config,now);
      if(visual.v11dmg)damageRuntime.holdPhase(token,visual,phase);
      // Animated artwork (its clock is in the signature) or a new beat phase
      // repaints anyway: skip serializing the frame signature for those.
      const repaint=moving||!!visual.v11dmg?.anim||!!visual.v11heal?.anim||phase!==this.phase||effectChanging||handoff.dirty||this.cropPending||this.bits?.hasPendingResize;
      const signature=repaint?null:JSON.stringify({weights,tipWeights:snapshot.poseAnimation.tipWeights,workingPosture:snapshot.workingPosture,gems:moving||changing?snapshot.gems:v7SemanticGems(snapshot.gems),v9:snapshot.v9,bitAssets:bitAssets.revision,bitQuality:config.bitQuality,
        structureAnimation:snapshot.structureAnimation,bitActionAssignments:snapshot.bitActionAssignments,intentTarget:snapshot.intentTarget,bitProjectedEffect:snapshot.bitProjectedEffect,lantern:lanternArtworkIdentity(snapshot),
        ...(snapshot.lantern?.active?{lightAppearance:snapshot.lightAppearance,lightIntensity:snapshot.effective?.intensity}:{}),
        flightProfile:snapshot.flightProfile,movementProfile:movement.profile,bitDeployment:snapshot.bitDeployment,bitCount:snapshot.bitCount,bitHomeStations:snapshot.bitHomeStations,bitFormationTransition:snapshot.bitFormationTransition,wingBitHandoff:snapshot.wingBitHandoff,
        ...visual,time:moving?visual.time:0,effectTime:moving?visual.effectTime:0,formation:{growth:formation.growth,fold:formation.fold},
        movement:movement.sweep?{sweep:movement.sweep,bank:movement.bank,flowX:movement.flowX,flowY:movement.flowY}:null,stabilizerDeployment,
        formationGlow:config.formationGlow&&formation.growth<1,components});
      if (repaint || signature!==this.signature) {
        const flight={...snapshot,formationGlow:config.formationGlow,stabilizerDeployment};
        if(emote)emoteRuntime.flight(emote,flight);
        // Commands are painted synchronously so the first frame is never stale.
        // Look changes that a running effect handoff blends from what is on
        // screen (and any change while the rig waits to reappear) go to the worker.
        const semantic=JSON.stringify({gems:v7SemanticGems(snapshot.gems),v7:v7SemanticIdentity(snapshot.v7),v9:snapshot.v9,pose:snapshot.poseAnimation.pose,workingPosture:snapshot.workingPosture?.amount>0?{active:true,side:snapshot.workingPosture.side}:null,
          structure:snapshot.structureAnimation?.id,cues:CUE_SLOTS.map(key=>snapshot.cues?.[key]?.id??null),hidden:snapshot.bitActionAssignments?.hidden,bitHomeStations:snapshot.bitHomeStations,bitTransition:bitTransitionIdentity(snapshot.bitTransition),bitCountTransition:snapshot.bitCount?.transition?.id,
          lanternMounting:snapshot.lantern?.mounting,
          ...(snapshot.lantern?.active?{lightAppearance:snapshot.lightAppearance,lightIntensity:snapshot.effective?.intensity}:{}),
          formation:snapshot.formation?.id,quality:config.bitQuality,components,reduced:config.reduced,wingbeats:config.wingbeats,
          pulses:config.energyPulses,renderer:config.renderWorker});
        const look=JSON.stringify({requested:snapshot.requested,condition:snapshot.visual.condition,effect:snapshot.visual.effectStyle,
          variant:visual.variant?{id:visual.variant.id,condition:visual.variant.condition,activeCondition:visual.variant.activeCondition}:null,gates:visual.gates});
        const changed=semantic!==this.workerSemantic,lookChanged=look!==this.workerLook;
        if(changed||lookChanged){this.workerEpoch++;this.workerLease?.cancel();this.workerSemantic=semantic;this.workerLook=look;}
        if(!this.workerLease&&now>=(this.workerRetryAt??0)&&config.renderWorker!==false&&supportsWingWorker()){
          this.workerLease=wingWorkerPool.acquire((frame,input,timing)=>this.acceptWorkerFrame(frame,input,timing),()=>{
            this.workerFailed=true;this.workerLease=null;this.workerRetryAt=(this.current?.now??now)+30000;this.signature=null;this.bits?.forgetPending(this.current?.now);
          },message=>this.acceptBitPictures(message));
          this.workerFailed=!this.workerLease;
          if(this.workerFailed)this.workerRetryAt=now+30000;
        }
        const canDefer=this.signature!==undefined&&(!changed||this.awaitingFrame)&&(!lookChanged||effectChanging||this.awaitingFrame)&&this.workerLease&&config.renderWorker!==false&&this.failedBitQuality!==config.bitQuality&&!invisHooks.mainThread?.(token);
        if(canDefer){
          localPerformance.recordRenderPath('wing-worker');
          const sequence=++this.workerSequence;
          this.workerLease.submit({epoch:this.workerEpoch,sequence,size:this.size,weights,phase,visual,flight:wingFrameInput(flight),components,now,settled,handoff:handoff.request(visual,now)});
          handoff.dirty=false;
          this.workerSubmitted=(this.workerSubmitted??0)+1;localPerformance.count('workerFramesSubmitted');
        }else{
          localPerformance.recordRenderPath('wing-main-thread');
          const started=localPerformance.active?localPerformance.beginStage():null;
          const destination=frameGeometry(weights,phase,visual,flight,this.geometryCache??={});
          const blended=handoff.paint(destination,visual,now,input=>frameGeometry(input.weights,input.phase,input.visual,input.flight)),geometry=blended.geometry;
          if(started!==null)localPerformance.endStage('geometry',started);
          localPerformance.count('geometryBuilds');
          this.paintGeometry(geometry,snapshot,config,blended.visual,now,settled);
          this.paintBackend='wing-main-thread';
        }
        this.signature=signature;this.phase=phase;
      }
      // Layers that were not repainted this slot still show the bruise as it
      // was (or need it lifted): bring them up to date.
      this.composeBruises();
      this.lastSlot=slot;
    }
    // Sprite movement is never limited by the texture animation frame rate.
    // After sleeping, stale layers stay hidden until the first new frame lands.
    // (11.0.0-test.7) her invisibility veil reaches the layers actually drawn: up to test.6 it only reached the
    // atlas sprite (faded out under the rig), so held her rig's wings stayed at full strength for everyone who
    // could see her token, only their pattern changed (1 = untouched: one Map lookup while she is visible)
    const veil=veilAlphaOf(token,'wings');
    for (const layer of this.layerRecords) {
      const {mesh,front,left}=layer;
      const visible=shown&&layer.hasContent&&components?.wings!==false&&!this.awaitingFrame;if(mesh.visible!==visible)mesh.visible=visible;
      setMeshTransform(mesh,transform.x,transform.y,transform.angle,
        transform.width*(layer.viewport?.width??this.size)/this.size,transform.height*(layer.viewport?.height??this.size)/this.size);
      // Flight feel: a shattered wing fades while its splinters fly (bits stay).
      const opacity=alpha*veil*(s.feelWingAlpha??1)*(front&&config.foregroundWings?config.foregroundOpacity:1);if(mesh.alpha!==opacity)mesh.alpha=opacity;
      // Same elevation and sort layer as the token: only local front/back order changes.
      placeBehind(mesh,source,front&&config.foregroundWings?(left?-0.12:-0.13):(left?0.22:0.21));
    }
    // (test.3) while Last light carries her, her bits are holding her up: the unconscious response does not drop them
    if(this.bits)this.bits.conditionContext=healRuntime.carries(token)?null:{response:snapshot.conditionResponse,now};
    // (Which bits are showing at their stations, for the flight feel's next
    // frame: only those can fly out to take a shot.)
    if(components?.bits===false||snapshot.wingBitHandoff===0||this.awaitingFrame)this.bits?.hide();else if(this.bits)s.feelBitsDrawn=this.bits.place(transform,source,alpha*veilAlphaOf(token,'bits'),config);
    // (v11) an emote's soft lights: the bits' focus and glow, the wing light, Pray's light, Comfort's warmth
    // (they carry no cloak filter: under a sweep they follow its front, and only a faint trace stays on the owner's ghost)
    if(emote)emoteRuntime.draw(emote,this,transform,source,alpha*veilAlphaOf(token,'bits'),veilAlphaOf(token,'fx'));
  }

  /** Display frames seen by this rig, and the measured display frame time. */
  displayFrame(now){
    const dt=now-(this.frameAt??now);
    if(dt>0&&dt<100)this.frameMs=this.frameMs?this.frameMs+(dt-this.frameMs)*.1:dt;
    if(dt>0||this.frameAt===undefined)this.frameCount=(this.frameCount??0)+1;
    this.frameAt=now;return this.frameCount;
  }
  /** Display frames each painted picture is held for: 1 at the display rate,
   * otherwise an even whole number (30 fps on 60 Hz = every second frame). */
  displayHold(fps){return displayHold(fps,this.frameMs);}

  viewport(layer,viewport){
    if(layer.viewport&&viewport.x===layer.viewport.x&&viewport.y===layer.viewport.y&&viewport.width===layer.viewport.width&&viewport.height===layer.viewport.height)return;
    if(layer.surface.width!==viewport.width||layer.surface.height!==viewport.height){
      layer.surface.width=viewport.width;layer.surface.height=viewport.height;
      layer.texture.baseTexture.resource?.resize?.(viewport.width,viewport.height);
      layer.texture.baseTexture.setRealSize?.(viewport.width,viewport.height);
    }
    layer.viewport=viewport;this.viewports[layer.key]=viewport;
    layer.mesh.anchor.set((this.size/2-viewport.x)/viewport.width,(this.size/2-viewport.y)/viewport.height);
  }
  upload(layer){
    layer.texture.baseTexture.update();localPerformance.count('wingTextureUploads');
    localPerformance.count('wingUploadPixels',layer.surface.width*layer.surface.height);
  }
  /** A layer has just been painted (main thread or worker): while a bruise
   * lasts, keep an unbruised copy of it and paint the bruise over the shown
   * surface; then upload. Without a bruise this is a plain upload. */
  finishLayer(layer){
    const key=this.bruiseKey??'';
    if(key&&layer.hasContent!==false&&layer.surface.width>1){
      const clean=layer.clean??=document.createElement('canvas');
      if(clean.width!==layer.surface.width||clean.height!==layer.surface.height){clean.width=layer.surface.width;clean.height=layer.surface.height;}
      const g=clean.getContext('2d');g.clearRect(0,0,clean.width,clean.height);g.drawImage(layer.surface,0,0);
      paintBruise(layer.context,this.bruise,this.size,layer.viewport);
    }else layer.clean=null;
    layer.composedKey=key;
    this.upload(layer);
  }
  /** Bring layers that were not repainted up to date with the bruise: redraw
   * each from its unbruised copy with the current spots (or none, once the
   * light is back), so the bruise never builds up on itself. */
  composeBruises(){
    const key=this.bruiseKey??'';
    for(const layer of this.layerRecords){
      if((layer.composedKey??'')===key)continue;
      if(!layer.hasContent){layer.clean=null;layer.composedKey=key;continue;}
      // (Not painted yet, or resized for a paint still to come: that paint finishes it.)
      if(layer.surface.width<2||layer.clean&&(layer.clean.width!==layer.surface.width||layer.clean.height!==layer.surface.height))continue;
      const g=layer.context;
      if(layer.clean){g.clearRect(0,0,layer.surface.width,layer.surface.height);g.drawImage(layer.clean,0,0);}
      else if(key){const clean=layer.clean=document.createElement('canvas');clean.width=layer.surface.width;clean.height=layer.surface.height;clean.getContext('2d').drawImage(layer.surface,0,0);}
      if(key)paintBruise(g,this.bruise,this.size,layer.viewport);else layer.clean=null;
      layer.composedKey=key;this.upload(layer);
    }
  }
  paintBits(bits,snapshot,config,{offload=false}={}){
    if(config.performanceComponents?.fields!==false&&!(snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse.mix>.01))applyBitWaveDirections(bits,this.waveState,snapshot,this.current?.now??0);
    if(!snapshot.bitSequenceActive)this.baseBits=bits;
    if(config.performanceComponents?.bits===false){this.bits?.hide();return true;}
    // A transient failure (lost context, canvas allocation) retries with
    // backoff 1s,2s,4s…30s; six failures at one detail stay on the fallback.
    const retryNow=this.current?.now??0;
    if(this.failedBitQuality===config.bitQuality){if(this.bitFailures>=6||retryNow<this.bitRetryAt)return false;this.failedBitQuality=null;}
    try{
      // Bits that arrive with an off-thread wing frame are painted by that
      // worker too (resonant bits already on screen); everything else, and
      // every synchronous frame, paints here exactly as before.
      const lease=offload&&config.renderWorker!==false&&!config.reduced?this.workerLease:null;
      if(bits.size){this.bits??=new BitRenderer(this.token);this.bits.conditionContext={response:snapshot.conditionResponse,now:this.current?.now};
        this.bits.paint(bits,config.bitQuality,this.current?.now,{offload:lease?.paintBits?jobs=>lease===this.workerLease&&lease.paintBits(jobs):null});}
      else{this.bits?.destroy();this.bits=null;}
      this.bitFailures=0;return true;
    }catch(error){
      this.bits?.destroy();this.bits=null;this.failedBitQuality=config.bitQuality;
      this.bitFailures=(this.bitFailures??0)+1;this.bitRetryAt=retryNow+Math.min(30000,1000*2**(this.bitFailures-1));
      if(this.bitFailures===1)console.warn('Yvaelle’s Toolbox: detailed bit rendering unavailable; using the wing-layer fallback.',error);return false;
    }
  }
  /** Filters copy: the input is also the displayed origin of an effect handoff. */
  paintGeometry(geometry,snapshot,config,visual,now=0,settled=true){
    this.awaitingFrame=false;
    const components=config.performanceComponents;
    if(components?.fields===false||snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse.mix>.01){
      const filtered={};
      for(const key of LAYER_NAMES)filtered[key]=geometry[key].filter(part=>!(/^(support-|intent-exchange)/.test(part.id))).map(part=>part.hardware&&part.hardware.glow!=null?{...part,hardware:{...part.hardware,glow:null}}:part);
      geometry=filtered;
    }
    const split=separateBits(geometry);
    if(this.paintBits(split.bits,snapshot,config))geometry=split.wings;
    if(components?.bits===false){const filtered={};for(const key of LAYER_NAMES)filtered[key]=geometry[key].filter(part=>!part.hardware&&!(/^(gem|sigil)-/.test(part.id)));geometry=filtered;}
    if(components?.wings===false)return;
    const started=localPerformance.active?localPerformance.beginStage():null,glow=layerGlow(visual),changed=[];
    for(const layer of this.layerRecords){
      const parts=geometry[layer.key],hasContent=parts.length>0;
      const viewport=stableLayerViewport(parts,this.size,glow,layer,now,settled,snapshot.structureAnimation?.artworkExtent??1);
      if(layer.hasContent===undefined||layer.hasContent!==hasContent||viewport!==layer.viewport||hasContent&&(layer.glow!==glow||!sameLayerPixels(layer.parts,parts))){
        this.viewport(layer,viewport);changed.push(layer.key);
      }
      layer.parts=parts;layer.glow=glow;layer.hasContent=hasContent;
    }
    this.cropPending=this.layerRecords.some(layer=>layer.cropPending);
    if(changed.length){paintLayers(this.contexts,geometry,this.size,visual,undefined,this.viewports,changed);for(const key of changed)this.finishLayer(this.layers[key]);}
    if(invisHooks.painted)invisHooks.painted(this,geometry,visual,changed);
    if(started!==null)localPerformance.endStage('wingPaint',started);
  }
  acceptWorkerFrame(frame,input,timing){
    if(this.destroyed||!this.shown||frame.epoch!==this.workerEpoch){localPerformance.count('workerFramesRejectedByRig');return;}
    const {snapshot,config}=this.current;
    const started=localPerformance.active?localPerformance.beginStage():null;
    try{
      if(!this.paintBits(new Map(frame.bits),snapshot,config,{offload:true})){
        // The synchronous wing-layer fallback still contains physical artwork.
        this.workerEpoch++;this.workerLease?.cancel();this.signature=null;return;
      }
      if(config.performanceComponents?.wings!==false)for(const result of frame.layers){
        const layer=this.layers[result.key];this.viewport(layer,result.viewport);
        layer.context.clearRect(0,0,layer.surface.width,layer.surface.height);
        layer.context.drawImage(result.bitmap,0,0);layer.hasContent=result.hasContent;layer.parts=null;this.finishLayer(layer);
      }
      this.cropPending=frame.cropPending;this.awaitingFrame=false;
      if(input)this.effectHandoff?.remember({input,visual:input.handoff?.paint??input.visual});
      this.workerCompleted=(this.workerCompleted??0)+1;localPerformance.count('workerFramesCompleted');
      localPerformance.count('workerGeometryMs',frame.geometryMs);localPerformance.count('workerPaintMs',frame.paintMs);
      this.paintBackend='wing-worker';localPerformance.recordRenderPath('wing-worker');
      if(localPerformance.active&&timing?.captureId===localPerformance.captureId)localPerformance.observe('workerInstallAgeMs',localPerformance.now()-timing.queuedAt);
    }catch(error){
      this.workerLease?.release();this.workerLease=null;this.workerFailed=true;this.workerRetryAt=(this.current?.now??0)+30000;this.signature=null;this.bits?.forgetPending(this.current?.now);
      console.warn('Yvaelle’s Toolbox: off-thread painting unavailable; returning to the compatible renderer.',error);
    }
    finally{if(started!==null)localPerformance.endStage('workerInstall',started);}
  }

  /** Resonant bit pictures painted by the worker (see paintBits). */
  acceptBitPictures(message){
    if(this.destroyed||!this.bits)return;
    if(message.lost){this.bits.forgetPending(this.current?.now);return;}
    const started=localPerformance.active?localPerformance.beginStage():null;
    try{if(this.bits.install(message.results,this.current?.now))localPerformance.count('bitPicturesInstalled',message.results.length);}
    finally{if(started!==null)localPerformance.endStage('bitInstall',started);}
  }
  /** Hidden or off screen. The worker semantic survives, so coming back costs one
   * worker frame rather than a main-thread paint; the stale layers and bits stay
   * hidden until that frame (or a main-thread paint) lands. */
  sleep(){
    for(const layer of this.layerRecords)if(layer.mesh.visible!==false)layer.mesh.visible=false;
    this.bits?.hide();this.workerLease?.cancel();this.effectHandoff?.clear();
    if(emoteRuntime.active.size)emoteRuntime.recOf(this.token)?.fx?.hide();
    // Every call (a frame may already be in flight): a new epoch makes the
    // worker resend every layer, and the next shown slot always repaints.
    this.workerEpoch++;this.awaitingFrame=true;this.lastSlot=undefined;if(this.signature!==undefined)this.signature=null;
  }
  hide(){this.shown=false;this.sleep();}

  destroy() {
    this.destroyed=true;this.workerEpoch++;this.workerLease?.release();this.workerLease=null;
    if(emoteRuntime.active.size){const rec=emoteRuntime.recOf(this.token);if(rec?.fx){rec.fx.destroy();rec.fx=null;}}
    this.bits?.destroy();this.bits=null;
    this.releaseBitAssets?.();this.releaseBitAssets=null;
    this.releaseWaves?.();this.releaseWaves=null;
    for (const layer of Object.values(this.layers??{})) {
      const mesh=layer.mesh;
      if (mesh&&!mesh.destroyed) {mesh.parent?.removeChild(mesh);mesh.destroy({children:true,texture:false,baseTexture:false});}
      layer.texture?.destroy(true);
      if (layer.surface) layer.surface.width=layer.surface.height=1;
    }
    this.layers={};this.layerRecords=[];this.contexts={};this.geometryCache=null;this.baseBits=null;this.current=null;this.effectHandoff?.clear();this.effectHandoff=null;
  }
}

/** Compatible classic energy gems retain the original atlas and assets. Posed
 * wings and configurable stabilizers use the rig, with the existing crossfade.
 */
export class PoseRenderer extends AtlasRenderer {
  constructor(token,textures,report=()=>{},bitRuntime=null) {super(token,textures);this.report=report;this.bitRuntime=bitRuntime;}

  /** Only completed artwork is exposed to drag ghosts. The live renderer owns
   * all textures and keeps its ordinary quality, phase and upload schedule. */
  *previewMeshes(){
    yield ['wings',this.wings];yield ['shadow',this.shadow];
    for(const layer of this.rig?.layerRecords??[])yield [`rig.${layer.key}`,layer.mesh];
    for(const [id,record]of this.rig?.bits?.records??[])for(const [depth,mesh]of Object.entries(record.meshes))yield [`rig.bit.${id}.${depth}`,mesh];
    for(const [id,record]of this.compact?.bits?.records??[])for(const [depth,mesh]of Object.entries(record.meshes))yield [`compact.bit.${id}.${depth}`,mesh];
    for(const [depth,layer]of Object.entries(this.compact?.currents?.layers??{}))yield [`compact.current.${depth}`,layer.mesh];
  }

  /** Sleep without discarding expensive bit and wing textures. Resume uses the
   * ordinary update path and current clock, never a backlog of hidden frames. */
  suspend(){
    if(this.wings.visible!==false)this.wings.visible=false;if(this.shadow.visible!==false)this.shadow.visible=false;if(this.wingShadow?.visible)this.wingShadow.visible=false;
    worldRuntime.shadowOnTokens(this.token,null,null);
    this.rig?.hide();this.compact?.hide();
    // A dormant token never reaches the trail's own idle release.
    this.trails?.destroy();
  }

  update(s,snapshot,config,now) {
    snapshot=this.bitRuntime?.prepareSnapshot(this.token.document,snapshot,now)??snapshot;
    if(s.wingClock&&snapshot.rendering.wingsActive===false)s.wingClock.wingsActive=false;
    const handoff=compactWingHandoff(snapshot,s.blend);
    // Resolve the owner's shared attention before either rendering route can
    // return. During a wing handoff each route converts the same world point
    // through its own scale/offset, rather than reusing the other's frame.
    const target=readBitIntentTarget(this.token.document),visibleTarget=target?.mesh&&!target.document?.hidden&&isShown(target,target.mesh)?target:null;
    const focused=(value,compact)=>{
      if(!visibleTarget&&!value.lantern?.active)return value;
      const t=compact?compactBitTransform(s.source??this.token.mesh,this.token,value,s):wingTransform(s,value);
      let next=value;
      if(value.lantern?.active)next=bitLanternInFrame(value,t.angle);
      if(!visibleTarget)return next;
      const dx=visibleTarget.mesh.x-t.x,dy=visibleTarget.mesh.y-t.y,c=Math.cos(t.angle),sn=Math.sin(t.angle);
      return {...next,intentTarget:[(dx*c+dy*sn)/t.width*600,(-dx*sn+dy*c)/t.height*600+15]};
    };
    if(snapshot.compactBits&&!handoff.active){
      if(this.wings.visible!==false)this.wings.visible=false;if(this.shadow.visible!==false)this.shadow.visible=false;if(this.wingShadow?.visible){this.wingShadow.visible=false;worldRuntime.shadowOnTokens(this.token,null,null);}this.rig?.hide();this.trails?.destroy();this.trails=null;
      this.updateCompact(s,focused(snapshot,true),config,now);
      return;
    }
    if(handoff.active){
      if(handoff.compact>0)this.updateCompact(s,focused({...snapshot,compactBits:true,bitWingBlend:s.blend,bitDeployment:snapshot.bitDeployment*handoff.compact,wingBitHandoff:undefined},true),config,now);
      else this.compact?.hide();
      // Legacy toggle flags commit their destination immediately. Continue the
      // old wing renderer while its local opacity eases down, then hand the
      // same stations to the compact route after they pass behind the token.
      snapshot={...snapshot,compactBits:false,bitWingBlend:s.blend,wingBitHandoff:handoff.wing};
    }else this.compact?.hide();
    snapshot=focused(snapshot,false);
    const blend=snapshot.rendering.renderer!=='rig'?0:
      config.wingRenderer==='rig'||v7WingRigRequired(snapshot.v7)||snapshot.gems.rigRequired||snapshot.structureAnimation?.rigRequired||!config.energyPulses||(snapshot.movement.trailEnabled&&snapshot.movement.moving)?1:
      Math.max(snapshot.visual.rigMix,snapshot.formation.rigMix,Math.min(1,snapshot.movement.sweep*6),Math.min(1,(1-Math.min(snapshot.poseAnimation.weights[0],snapshot.poseAnimation.tipWeights[0]))*5));
    super.update(s,snapshot,config,now,{atlas:snapshot.rendering.renderer!=='rig'||this.failedQuality===config.rigQuality||blend<1,deferWingAlpha:true});
    this.updateTrails(s,snapshot,config,now);
    const energyAlpha=this.pendingWingAlpha*(Math.min(1,snapshot.visual.profile.energy)*(1-0.3*snapshot.visual.profile.damage));
    if (snapshot.rendering.renderer!=='rig') {
      if(this.wings.alpha!==energyAlpha)this.wings.alpha=energyAlpha;
      this.rig?.destroy();this.rig=null;this.failedQuality=null;return;
    }
    if (this.failedQuality===config.rigQuality) {if(this.wings.alpha!==energyAlpha)this.wings.alpha=energyAlpha;return;}
    try {
      if (this.rig?.quality!==config.rigQuality) {this.rig?.destroy();this.rig=null;}
      this.rig??=new WingRigRenderer(this.token,config.rigQuality);
      this.rig.update(s,snapshot,config,now,blend);
      const blendedAlpha=energyAlpha*(1-blend);if(this.wings.alpha!==blendedAlpha)this.wings.alpha=blendedAlpha;
      const visible=this.wings.visible&&blend<1;if(this.wings.visible!==visible)this.wings.visible=visible;
    } catch(error) {
      if(this.wings.alpha!==energyAlpha)this.wings.alpha=energyAlpha;
      this.rig?.destroy();this.rig=null;this.failedQuality=config.rigQuality;
      this.trails?.destroy();this.trails=null;
      this.report(new Error(`Wing poses could not render; the original wings will load as a fallback. ${error.message}`));
    }
  }

  updateCompact(s,snapshot,config,now){
    // Retry a failure with backoff (1s,2s,4s… ≤30s); give up only after six
    // consecutive failures at this detail. A success clears the record.
    const failed=this.compactFailed;
    if(failed?.quality===config.bitQuality&&(failed.count>=6||now<failed.retryAt))return;
    try{
      this.compact??=new CompactBitRenderer(this.token);
      this.compact.update(s,snapshot,config,now);
      if(failed)this.compactFailed=null;
    }catch(error){
      this.compact?.destroy();this.compact=null;
      const count=failed?.quality===config.bitQuality?failed.count+1:1;
      if(count===1||count===6)this.report(new Error(`Compact bits could not render${count===6?' after repeated retries':''}. ${error.message}`));
      this.compactFailed={quality:config.bitQuality,count,retryAt:now+Math.min(30000,1000*2**(count-1))};
    }
  }

  updateTrails(s,snapshot,config,now) {
    if(this.failedQuality===config.rigQuality){this.trails?.destroy();this.trails=null;return;}
    if(!snapshot.movement.trailEnabled){this.trails?.destroy();this.trails=null;this.trailFailure=null;return;}
    if(this.trailFailure===config.rigQuality)return;
    try{this.trails??=new TrailRenderer(this.token);this.trails.update(s,snapshot,config,now);}
    catch(error){this.trails?.destroy();this.trails=null;this.trailFailure=config.rigQuality;this.report(new Error(`Flight trails could not render; wing effects remain available. ${error.message}`));}
  }
  resetTrails(){this.trails?.clear();}

  destroy() {this.compact?.destroy();this.compact=null;this.trails?.destroy();this.trails=null;this.rig?.destroy();this.rig=null;super.destroy();}
}
