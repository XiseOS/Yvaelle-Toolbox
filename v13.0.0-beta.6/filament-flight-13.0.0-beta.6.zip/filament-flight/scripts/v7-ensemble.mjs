/** V7 cosmetic preferences and shared wing animation identity.
 * Stored as an additive v7 member of schemaVersion 2. No actor reads, timers,
 * frame writes or random choices: all clients sample the same saved episode. */
import {readWingGesture,sampleWingGesture,WING_GESTURES} from './v7-wing-motion.mjs?v=13.0.0-beta.6';
const unit=n=>Math.max(0,Math.min(1,n));
const finite=n=>typeof n==='number'&&Number.isFinite(n);
const object=n=>n&&typeof n==='object'&&!Array.isArray(n);
const boolKeys=Object.freeze(['enabled','gemInteriors','filamentTexture','refraction','formations','medkit','transitionVariants','wingAnimations','seamlessActions']);
const strengthKeys=Object.freeze(['gemStrength','filamentStrength','refractionStrength']);
/** Retired cosmetic fields are ignored only while reading saved flags/Looks.
 * New actions cannot set them. Physical wing deployment presence is unrelated. */
export const LEGACY_V7_ASPECT_FIELDS=Object.freeze(['lunarEnabled','lunar','lunarTransition','presenceEnabled','presenceStrength','presence','presenceTransition']);
export const V7_DEFAULTS=Object.freeze({enabled:true,gemInteriors:true,gemStrength:.58,filamentTexture:true,filamentStrength:.48,refraction:true,refractionStrength:.42,formations:true,medkit:true,transitionVariants:true,wingAnimations:true,seamlessActions:true});
const resolvedKeys=Object.freeze([...boolKeys,...strengthKeys]);
const worldKeys=Object.freeze(Object.fromEntries(resolvedKeys.map(key=>[key,`v7${key[0].toUpperCase()}${key.slice(1)}`])));
const bool=(name,hint)=>({name,hint,scope:'world',config:true,type:Boolean,default:true});
const number=(name,hint,value)=>({name,hint,scope:'world',config:true,type:Number,default:value,range:{min:0,max:1,step:.05}});
export function v7SettingDefinitions(){return {
  v7Enabled:bool('V7 ensemble enhancements','Enable the V7 appearance, formation and treatment additions. Disable for the classic 6.6.7 visual routes; saved V7 choices are retained.'),
  v7GemInteriors:bool('V7 · layered gemstone interiors','Translucent inner filaments, separate reflected layers and gentle internal parallax. Keeps the existing gemstone, housing and metal highlights.'),
  v7GemStrength:number('V7 · gemstone interior detail','Strength of the layered interior. Zero retains the earlier gemstone treatment.',V7_DEFAULTS.gemStrength),
  v7FilamentTexture:bool('V7 · textured wing filaments','Selected wing ribs gain fine braided strands and visible local tension, without changing the wing outline.'),
  v7FilamentStrength:number('V7 · filament texture strength','Amount of internal strand texture and material response.',V7_DEFAULTS.filamentStrength),
  v7Refraction:bool('V7 · refractive magenta light','Soft, evolving gemstone refractions enrich the existing circular and lantern light. Preserves scene-light radii, walls and colour.'),
  v7RefractionStrength:number('V7 · refraction strength','Restrained moving concentrations of magenta light. Zero retains the earlier decorative appearance.',V7_DEFAULTS.refractionStrength),
  v7Formations:bool('V7 · companion formation library','Eight additional count-specific formation families with local work phases. Disable to use the earlier catalogue and preserve saved choices.'),
  v7Medkit:bool('V7 · treatment animation library','Allow the V7 medkit animation additions and their preparation and release choreography. Existing styles remain available.'),
  v7TransitionVariants:bool('V7 · seamless action variations','Use several deterministic, bounded handoff shapes between compatible actions. A variation is chosen once per action and shared by every viewer.'),
  v7WingAnimations:bool('V7 · wing gesture library','Allow the manually activated wing gestures and their smooth entry and release bridges. Existing poses and wingbeats remain available.'),
  v7SeamlessActions:bool('V7 · action preparation and release','Add restrained automatic wing preparation and release bridges to flight, pose and light actions. Manual wing gestures retain priority.'),
};}
export function normalizeV7Preferences(raw){
  if(raw==null)return null;
  if(!object(raw))throw new Error('V7 preferences must be an object.');
  const out={};
  for(const key of boolKeys){const value=raw[key]??null;if(value!==null&&typeof value!=='boolean')throw new Error(`V7 ${key} must be true, false or inherit.`);out[key]=value;}
  for(const key of strengthKeys){const value=raw[key]??null;if(value!==null&&(!finite(value)||value<0||value>1))throw new Error(`V7 ${key} must be between zero and one, or inherit.`);out[key]=value;}
  out.mode=raw.mode??null;if(out.mode!==null&&!['enhanced','classic'].includes(out.mode))throw new Error('V7 mode must be enhanced, classic or inherit.');
  out.wingGesture=readWingGesture(raw.wingGesture);
  return out;
}
export function validateV7Patch(input){
  if(!object(input))throw new Error('V7 preferences must be an object.');
  const allowed=[...boolKeys,...strengthKeys,'mode','wingGesture'],out={};
  for(const [key,value]of Object.entries(input)){if(!allowed.includes(key))throw new Error(`Unknown V7 preference ${key}.`);out[key]=value;}
  normalizeV7Preferences(out);
  return out;
}
export function v7PreferencesPatch(input,{before=null}={}){
  const out=validateV7Patch(input);
  normalizeV7Preferences({...normalizeV7Preferences(before),...out});
  return out;
}
export function sampleV7Appearance(preferences,cfg={},now=0){
  const prefs=preferences??{},resolved={};
  for(const key of resolvedKeys)resolved[key]=prefs[key]??cfg[worldKeys[key]]??V7_DEFAULTS[key];
  resolved.enabled=resolved.enabled&&prefs.mode!=='classic';
  const reduced=cfg.reduced===true||cfg.reducedMotion===true;
  if(!resolved.enabled)for(const key of boolKeys)resolved[key]=false;
  resolved.materialPhase=reduced?0:Math.max(0,Number(now)||0)/1000;
  const signatureOff=WING_GESTURES[prefs.wingGesture?.name]?.v9===true&&cfg.v9SignatureCraft!==true;
  resolved.wingMotion=sampleWingGesture(prefs.wingGesture,now,{reduced:reduced||!resolved.enabled||!resolved.wingAnimations||signatureOff});
  resolved.wingDetail=cfg.rigQuality??'medium';
  resolved.episodeKey=String(prefs.wingGesture?.started??0);
  resolved.appearanceRevision=`${prefs.mode??'inherit'}:${resolved.episodeKey}`;
  return resolved;
}
export const V7_TRANSITION_VARIANTS=Object.freeze(['soft-lift','ribbon-settle','depth-breath','measured-fan']);
function hash(seed){let n=2166136261;for(const c of String(seed)){n^=c.charCodeAt(0);n=Math.imul(n,16777619);}return n>>>0;}
/** Deterministic per-action choice. The seed can be a saved command id or the
 * formation-flow epoch/cycle: identical across clients and frame sampling. */
export function v7TransitionVariant(seed,kind='formation'){return V7_TRANSITION_VARIANTS[hash(`${kind}:${seed}`)%V7_TRANSITION_VARIANTS.length];}
export function sampleV7TransitionAccent(progress,{seed='',kind='formation',index=0,count=4,side=1,strength=1}={}){
  const p=unit(progress),envelope=Math.sin(Math.PI*p)**2*unit(strength),variant=v7TransitionVariant(seed,kind),phase=count===1?0:index/(count-1),sign=side<0?-1:side>0?1:0;
  if(variant==='soft-lift')return {x:sign*1.8*envelope,y:-(4+phase*1.5)*envelope,z:.12*envelope,angle:sign*.018*envelope,variant};
  if(variant==='ribbon-settle')return {x:sign*(2+phase)*envelope,y:Math.sin(Math.PI*p*2)*(2+phase)*envelope,z:-.10*envelope,angle:sign*.03*Math.sin(Math.PI*p*2)*envelope,variant};
  if(variant==='depth-breath')return {x:sign*.9*envelope,y:(phase-.5)*3*envelope,z:(index%2?1:-1)*.18*envelope,angle:-sign*.025*envelope,variant};
  return {x:sign*(3+phase)*envelope,y:(index%2?1:-1)*2*envelope,z:.07*envelope,angle:sign*.04*envelope,variant};
}
