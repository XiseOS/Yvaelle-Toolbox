import {CONDITION_IDS,stylePatch,settingKey} from './effect-catalog.mjs?v=13.0.0-beta.6';
export {CONDITION_IDS};
export const EFFECT_STYLES=Object.freeze(['original','animated']);
export function validateEffectStyle(style) {
  if(style!==null&&!EFFECT_STYLES.includes(style))throw new Error('Effect style must be original, animated, or null for the default.');
  return style;
}
export const effectStylePatch=raw=>stylePatch(raw);
const worldChoice=(cfg,group,key)=>cfg[settingKey(group,key)]==='default'?null:cfg[settingKey(group,key)];
/** Existing saved explicit styles outrank new world defaults. None is an opt-out. */
export function resolveEffectStyle(data,condition,config) {
  const choice=data.effectStyles?.[condition]??data.effectStyle??worldChoice(config,'condition',condition)??'animated';
  return choice==='none'?'none':config.enhancedConditions?choice:'original';
}
export function resolveReactionStyle(data,kind,config,conditionStyle) {
  const choice=data.reactionStyles?.[kind]??worldChoice(config,'reaction',kind)??(conditionStyle==='original'?'original':'animated');
  return choice==='none'?'none':config.enhancedConditions?choice:'original';
}
