import {paintTokenEffect} from './token-effects.mjs?v=13.0.0-beta.6';
import {V7_MEDICAL_WORK_SPECS,v7TreatmentWorkGeometry,isV7Treatment,classicTreatmentStyle} from './v7-medical-work.mjs?v=13.0.0-beta.6';
import {sampleBitMedicalArtwork,bitMedicalArtworkBounds} from './v7-medical-artwork.mjs?v=13.0.0-beta.6';

export const V7_MEDKIT_TECHNIQUES=V7_MEDICAL_WORK_SPECS;
export {v7TreatmentWorkGeometry,isV7Treatment,classicTreatmentStyle};
const TAU=Math.PI*2,clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,Number(v)||0));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v);},mix=(a,b,p)=>a+(b-a)*p;

/** Four repeatable approach gestures selected once by action identity. The
 * bell has zero value and velocity at both ends, so changing the accent never
 * breaks an inherited origin or the first scan/work station. */
export function treatmentTransitionVariant(event,enabled=true){
  if(!enabled||event?.treatment?.variation===false)return 0;
  let hash=2166136261;for(const char of String(event?.id??event?.started??'medical')){hash^=char.charCodeAt(0);hash=Math.imul(hash,16777619);}
  return (hash>>>0)%4;
}
export const TREATMENT_TRANSITION_NAMES=Object.freeze(['Gentle lift','Low clearance','Measured arch','Soft stepped rise']);
export function sampleTreatmentTransit(from,to,progress,{index=0,size=100,reduced=false,variant=0,returning=false,fromVelocity=null,duration=900,progressIsLinear=false,sideBoundary}={}){
  const p=clamp(progress);if(p<=0)return {x:from.x,y:from.y};if(p>=1)return {x:to.x,y:to.y};
  const q=progressIsLinear?smooth(p):p,amount=Math.max(0,Number(size)||100),bell=Math.sin(Math.PI*q)**2;
  if(reduced)return {x:mix(from.x,to.x,q),y:mix(from.y,to.y,q)};
  const v=clamp(Math.round(variant)||0,0,3),lane=Math.floor(index/2),side=index%2?1:-1;
  const heights=[.31,.18,.43,.27],bend=heights[v]+lane*.035;
  const shape=v===3?bell*(.85+.15*Math.cos(TAU*q)):bell;
  // Keep the route on its assigned horizontal interpolation. Variation is in
  // height, easing and preparation, never an unwanted left/right station swap.
  const accent=v===1?side*.025*amount*bell*(returning?-1:1):0;
  const result={x:mix(from.x,to.x,q)+accent,y:mix(from.y,to.y,q)-shape*amount*bend};
  if(progressIsLinear&&fromVelocity){
    const seconds=Math.max(.001,(Number(duration)||900)/1000),span=Math.hypot(to.x-from.x,to.y-from.y),corridor=Math.max(amount*.18,span*.32);
    for(const axis of ['x','y']){
      const tangent=(Number(fromVelocity[axis])||0)*seconds;let bound=corridor;
      if(axis==='x'&&Number.isFinite(sideBoundary)){
        const a=from.x-sideBoundary,b=to.x-sideBoundary;
        if(a*b>0&&tangent*a<0)bound=Math.min(bound,Math.max(.001,Math.min(Math.abs(a),Math.abs(b))*.35));
      }
      const damp=Math.max(0,Math.abs(tangent)/bound-1);
      // Initial velocity is retained exactly. Excess motion decays inside a
      // fixed corridor; the tangent reaches zero at the live destination.
      result[axis]+=p*(1-p)**2*tangent*Math.exp(-p*damp);
    }
  }
  return result;
}

export const sampleV7MedkitTreatment=sampleBitMedicalArtwork;
export const v7MedkitBounds=bitMedicalArtworkBounds;
export function paintV7MedkitTreatment(ctx,effect,{plane='front'}={}){const frame=sampleV7MedkitTreatment(effect);if(!frame)return false;paintTokenEffect(ctx,frame,{plane});return true;}
