/** Yvaelle’s Toolbox v13 · The Heart Turned: where the curse meets Foundry.
 *
 * Everything shared is one record on her actor (flags.filament-flight.curse, see curse-model.mjs). There are no socket
 * messages: the GM writes the record, her player's page sees her actor change and shows it, and fills in her rolls.
 *
 *   The GM         a key of their own (Configure Controls › Curse wheel; none is set as it comes) opens the wheel round
 *                  the pointer (curse-wheel.mjs). Laying a curse writes the record. Later the GM's page says, in one small
 *                  note, what she rolled and for how long; the wheel's strip shows what is on her, with −1 Span and Lift.
 *   Her player     the page of the first connected player who owns her shows it (curse-view.mjs): the full view, the
 *                  card, the mark. With no player of hers connected, the GM's own page shows it instead, so a GM alone
 *                  in a world sees exactly what she would.
 *   Everyone else  nothing at all.
 *
 * Time: a Span is an hour of the world's clock. The mark counts down as the clock runs and the curse ends by itself when
 * it runs out (the GM's page lifts it; her own, if no GM is connected). A table that does not run the clock uses −1 Span.
 *
 * Switches (Settings › Her › Moods & milestones › The Heart Turned): the whole thing (the GM's, for the world) · Arrive
 * minimised · Blur the game behind it · The mark opens when pressed (hers, on her page) · the
 * GM's note. Off, the wheel does not open and nothing is shown; a record already on her is left as it is.
 *
 * (13.0.0-beta.2)
 *   The states' texts   the GM's edits (names, verbs, texts) are kept in the world setting beside who is cursed, read by
 *                       every page at start and whenever it changes (curse-edit.mjs is the editor).
 *   Watching            a GM who ticked Watch her roll (the bar under the wheel; kept for this browser) and is not the
 *                       one showing it gets a second view of the same kind, driven by her record: it waits where she
 *                       has a button and goes on when her roll, then her Spans, arrive on her actor.
 *   Her sheet           her Keepsake sheet shows the curse among the conditions on her (to her owner and the GM);
 *                       pressing it opens the full view on the page that shows it, and the finished picture on a GM's.
 *   Trouble             anything that goes wrong in any of it is kept (the last thirty) for the module's own check.
 *
 * (13.0.0-beta.4)
 *   Its sound           off as it comes (a part of the feature, kept for this browser). The stage raises a named cue at
 *                       each moment that has a sound; the view passes it here; curse-sound.mjs plays it on this page
 *                       only, through Foundry's own Sound class. With the switch off nothing of it is loaded. A dry
 *                       run (the module's check) is silent: its cues are only written down. */
import {ID,isOn,partOn,partKey,writeV11,choice} from '../v11/features.mjs?v=13.0.0-beta.6';
import {CURSE_KEY,CURSE_FLAG,CURSE_NOW,CURSE_TITLE,newCurse,readCurse,rollCurse,faithPick,rollStyle,rootCurse,burnSpan,curseOver,curseStage,presenterOf,peopleList,stateIndex,stateOf,stateEdits,setCurseStates,spansLeft,spanWord,markLine,namesSomeone,dieOf} from './curse-model.mjs?v=13.0.0-beta.6';
import {CurseView} from './curse-view.mjs?v=13.0.0-beta.6';
import {CurseWheel} from './curse-wheel.mjs?v=13.0.0-beta.6';
import {CurseEditor} from './curse-edit.mjs?v=13.0.0-beta.6';
import {gemSVG} from './curse-art.mjs?v=13.0.0-beta.6';
import {createCurseSound,foundryCurseAudio,CURSE_VOLUMES,CURSE_VOLUME_ORDER,CURSE_SOUND_FILES} from './curse-sound.mjs?v=13.0.0-beta.6';

export const CURSE_WORLD='curseWorld',CURSE_CLIENT='curseClient',CURSE_BINDING='curseWheel';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const G=()=>globalThis.game;
/** What the stage says to a GM who watches her roll. */
export const watchWords=name=>{const N=String(name||'her').toUpperCase();return {ask:`A ROLL IS ASKED OF ${N}`,laid:`A CURSE IS LAID ON ${N}`,on:'IT IS ON',near:'NEAREST HER HEART',onLaid:'IT IS LAID ON HER',made:'She is made to',madeLaid:'It is laid on her. She is made to',min:'CLOSE',waitRoll:'WAITING FOR HER ROLL',waitRoot:'WAITING FOR HER TO LET IT ROOT'};};

export class CurseRuntime{
  /** pinned: () → the token pinned in this page's HUD (who is cursed, until the GM chooses someone). */
  constructor({pinned=()=>null,doc=globalThis.document,win=globalThis.window}={}){
    this.pinned=pinned;this.doc=doc;this.win=win;this.view=null;this.wheel=null;this.actorId=null;this.known=new Map();this.chosen=null;this.wasOn=true;this.lastNote=null;this.stats={laid:0,rolled:0,rooted:0,lifted:0,notes:0,watched:0};
    this.watcher=null;this.watchId=null;this.waiters=[];this.editor=null;this.errors=[];this.statesKey='{}';this.sheetWas=true;this.cueLog=null;this.snd=null;this.sndAudio=null;this.sndWas=false;
  }
  enabled(){try{return isOn(CURSE_KEY,null)!==false;}catch{return true;}}
  part(id){try{return partOn(CURSE_KEY,id,null);}catch{return false;}}
  now(){const t=G()?.time?.worldTime;return Number.isFinite(t)?t:0;}
  rng(){try{const f=globalThis.CONFIG?.Dice?.randomUniform;if(typeof f==='function'){const v=f();if(v>=0&&v<1)return v;}}catch{}return Math.random();}
  /* ───────── settings and the key (the init hook) ───────── */
  register(){
    const S=G()?.settings;if(!S?.register)return this;
    S.register(ID,CURSE_WORLD,{name:'The Heart Turned · who is cursed',scope:'world',config:false,type:Object,default:{actor:'',states:{}}});
    S.register(ID,CURSE_CLIENT,{name:'The Heart Turned · this browser',scope:'client',config:false,type:Object,default:{die:4,pin:'',pos:null}});
    const K=G()?.keybindings;
    if(K?.register){const typing=context=>!!context?.event?.target?.closest?.('input,textarea,select,[contenteditable="true"]');
      K.register(ID,CURSE_BINDING,{name:'Curse wheel (GM)',hint:'Tap to open the curse wheel round the pointer: lay one of her six states on her, or let her roll for it. Tap again (or Escape) to close it. Only the GM has this key. No key is assigned by default: set yours here.',
        editable:[],uneditable:[],restricted:true,repeat:false,onDown:context=>{if(typing(context))return false;this.toggleWheel();return true;}});}
    return this;
  }
  setting(key){try{return G()?.settings?.get?.(ID,key)??{};}catch{return {};}}
  async save(key,patch){try{const cur=this.setting(key);await G().settings.set(ID,key,{...cur,...patch});return true;}catch(e){this.trouble('saving '+key,e);return false;}}
  /** Something went wrong somewhere in it: kept (the last thirty) for the module's own check, and said once in the console. */
  trouble(where,e){
    const msg=String(e?.message??e).slice(0,200);try{console.warn('Yvaelle’s Toolbox · The Heart Turned ·',where,e);}catch{}
    this.errors.push({at:Date.now(),where:String(where).slice(0,80),msg,stack:String(e?.stack??'').split('\n').slice(1,3).map(l=>l.trim()).join(' | ').slice(0,240)});if(this.errors.length>30)this.errors.shift();
  }
  /** The world's edits to the states are read again; every surface that shows a name or a text is written again if they changed. */
  applyStates(){
    let edits={};try{edits=stateEdits(this.setting(CURSE_WORLD)?.states);}catch{}const key=JSON.stringify(edits);if(key===this.statesKey)return false;this.statesKey=key;setCurseStates(edits);
    try{this.view?.statesChanged();this.watcher?.statesChanged();if(this.wheel?.open)this.wheel.fillStrip();this.refreshSheetChips();}catch(e){this.trouble('showing the edited states',e);}
    return true;
  }
  /* ───────── hooks ───────── */
  install(){
    const H=globalThis.Hooks;if(!H?.on)return this;
    H.once('ready',()=>{try{this.wasOn=this.enabled();this.sheetWas=this.wasOn&&this.part('curseSheet');this.applyStates();for(const a of G()?.actors??[])this.remember(a);this.rescan(false);this.sndWas=this.sounding();void this.warmSound();}catch(e){this.trouble('starting',e);}});
    // (her record is read from her actor itself on every change of hers, not from the change's own shape, which differs between
    // Foundry versions for a deletion; an actor with no curse now and none before costs two look-ups)
    H.on('updateActor',(actor,changes,options,userId)=>{if(!this.known.has(actor.id)&&actor?.flags?.[ID]?.[CURSE_FLAG]==null)return;try{this.actorChanged(actor,userId);}catch(e){this.trouble('her actor changed',e);}});
    H.on('deleteActor',actor=>{this.known.delete(actor.id);if(actor.id===this.actorId)this.rescan(false);});
    H.on('updateWorldTime',()=>{try{this.timeChanged();}catch(e){this.trouble('the clock moved',e);}});
    H.on('userConnected',()=>{try{this.rescan(false);}catch(e){this.trouble('a user connected',e);}});
    // (the card and the mark sit beside Foundry's sidebar: they follow its edge when it is opened or closed)
    H.on('collapseSidebar',()=>{if(this.view?.card||this.view?.mark)this.win?.setTimeout?.(()=>this.view?.replace(),320);});
    for(const hook of ['filamentFlightSettingsChanged','clientSettingChanged','updateSetting'])H.on(hook,()=>{try{this.settingsChanged();}catch(e){this.trouble('a setting changed',e);}});
    return this;
  }
  record(actor){try{return readCurse(actor?.getFlag?.(ID,CURSE_FLAG)??actor?.flags?.[ID]?.[CURSE_FLAG]??null);}catch{return null;}}
  remember(actor){const r=this.record(actor);if(r)this.known.set(actor.id,r);else this.known.delete(actor.id);return r;}
  users(actor){return (G()?.users?.contents??[...(G()?.users??[])]).map(u=>({id:u.id,active:!!u.active,isGM:!!u.isGM,owner:(()=>{try{return !!actor.testUserPermission(u,'OWNER');}catch{return false;}})()}));}
  presenter(actor){return presenterOf(this.users(actor));}
  iPresent(actor){return !!actor&&this.presenter(actor)===G()?.user?.id;}
  ensureView(){return this.view??=new CurseView({host:this.viewHost(),doc:this.doc,win:this.win});}
  ensureWatcher(actor){const words=watchWords(actor?.name);if(!this.watcher)this.watcher=new CurseView({host:this.watchHost(),doc:this.doc,win:this.win,watch:true,words});else this.watcher.words=words;return this.watcher;}
  /** Find the curse this page is to show (her player's page, or the GM's when she has no player here) and give it to the view. */
  rescan(fresh=false){
    const g=G();if(!g?.ready&&!g?.actors)return;let mine=null;
    if(this.enabled())for(const a of g.actors??[]){const r=this.record(a);if(!r||!this.iPresent(a))continue;if(!mine||a.id===this.actorId)mine={a,r};}
    if(mine){this.actorId=mine.a.id;this.ensureView().sync(mine.r,{fresh});}else{this.actorId=null;this.view?.sync(null);}
    // (her player left while the GM watched: this page shows it itself now, so the watching view steps aside)
    if(this.watchId&&this.watchId===this.actorId){const id=this.watchId;this.watchId=null;this.watcher?.sync(null);this.settle(id,null);}
  }
  actorChanged(actor,userId){
    const was=this.known.get(actor.id)??null,cur=this.record(actor);if(JSON.stringify(was)===JSON.stringify(cur))return;
    if(cur)this.known.set(actor.id,cur);else this.known.delete(actor.id);
    this.rescan(true);this.watchSync(actor,was,cur);this.observe(actor,was,cur,userId);
    if(this.wheel?.open)this.wheel.fillStrip();
  }
  /* ───────── a GM who watches (beta.2) ───────── */
  /* ───────── its sound (beta.4, curse-sound.mjs) ───────── */
  /** Is the sound on on this page (off as it comes). */
  sounding(){return this.enabled()&&this.part('curseSound');}
  soundLevel(){try{return CURSE_VOLUMES[choice(partKey(CURSE_KEY,'curseVolume'),null)]??1;}catch{return 1;}}
  /** For the control in her full view: is it on, which step of how many. */
  soundInfo(){let k='normal';try{k=choice(partKey(CURSE_KEY,'curseVolume'),null)??'normal';}catch{}const i=CURSE_VOLUME_ORDER.indexOf(k);return {on:!!this.sounding(),i:i<0?3:i,n:CURSE_VOLUME_ORDER.length};}
  /** One step quieter (−1) or louder (+1) on this page. Below the quietest it is switched off; up from off it comes on at the quietest. */
  async soundStep(d){
    try{const s=this.soundInfo();
      if(!s.on){if(d>0){await writeV11(partKey(CURSE_KEY,'curseVolume'),CURSE_VOLUME_ORDER[0]);await this.setPart('curseSound',true);void this.warmSound();}return this.soundInfo();}
      const j=s.i+(d>0?1:-1);
      if(j<0){try{this.snd?.stop?.(200);}catch{}await this.setPart('curseSound',false);return this.soundInfo();}
      await writeV11(partKey(CURSE_KEY,'curseVolume'),CURSE_VOLUME_ORDER[Math.min(s.n-1,j)]);try{this.player().hear('tick');}catch{}
      return this.soundInfo();
    }catch(e){this.trouble('changing how loud it is',e);return null;}
  }
  /** Where a recording is fetched from. */
  soundSrc(f){let base=`modules/${ID}/assets/audio/curse`;try{base=globalThis.foundry?.utils?.getRoute?.(base)??base;}catch{}return `${base}/${f}.ogg`;}
  player(){
    if(!this.snd){
      this.sndAudio=foundryCurseAudio({base:this.soundSrc('x').slice(0,-6),trouble:(where,e)=>this.trouble(where,e)});
      this.snd=createCurseSound({audio:this.sndAudio,on:()=>this.sounding(),bed:()=>this.part('curseBed'),level:()=>this.soundLevel()});
    }
    return this.snd;
  }
  /** The recordings are fetched and decoded ahead of the first curse (only with the sound on: off, nothing is loaded at all). */
  warmSound(){if(!this.sounding())return Promise.resolve(null);return this.player().warm().catch(e=>{this.trouble('loading the sounds',e);return null;});}
  /** A moment of her view that has a sound. cueLog: for the tests and the harness, told of every one whether it is played or not. */
  sound(name,detail=null){
    try{this.cueLog?.(name,detail);}catch{}
    try{if(this.snd||this.sounding()){if(name==='veil'||name==='open')void this.warmSound();this.player().cue(name,detail);}}catch(e){this.trouble('the sound of '+name,e);}
  }
  /** One of its sounds by itself, whether the switch is on or not (to try them): api.curse.hear('cut'). → did it play */
  async hear(name,detail=null){try{const p=this.player();await p.warm();return p.hear(name,detail);}catch(e){this.trouble('hearing '+name,e);return false;}}
  /** (beta.3) How her roll is shown on this page: one of the four she picked (Settings), or nothing: each curse takes its own. */
  /** (beta.4) How the curse round her is drawn: the dial, the wreath, or the briar of the first betas. */
  /** (13.0.0-beta.5) Where its paintings are (assets/curse), as an address the page can fetch. */
  artBase(){let base=`modules/${ID}/assets/curse`;try{base=globalThis.foundry?.utils?.getRoute?.(base)??base;}catch{}return base;}
  /** Watch her roll: a part of the feature kept for this browser (Settings, or the tick on the bar under the wheel). */
  watching(){return this.part('curseWatch');}
  async setPart(id,on){try{await writeV11(partKey(CURSE_KEY,id),!!on);return true;}catch(e){this.trouble('switching '+id,e);return false;}}
  /** Her record changed and this page is a GM's that does not show it: start the watcher's view for a curse laid just now
   * (if Watch is ticked), feed it what she rolled, end it when the curse is gone. */
  watchSync(actor,was,cur){
    const g=G();if(!g?.user?.isGM)return;const end=()=>{if(this.watchId===actor.id){this.watcher?.sync(null);this.settle(actor.id,null);this.watchId=null;}};
    if(!cur||!this.enabled()||this.iPresent(actor)){end();return;}
    if(!was||was.id!==cur.id){this.settle(actor.id,null);if(!this.watching()||this.reduced()){end();return;}this.watchId=actor.id;this.stats.watched++;this.ensureWatcher(actor).sync(cur,{fresh:true});return;}
    if(this.watchId===actor.id){this.watcher.sync(cur);this.settle(actor.id,cur);}
  }
  /** What a watcher waits for has come (or never will: the curse was lifted or replaced). */
  settle(actorId,cur){
    const keep=[];for(const w of this.waiters){if(w.actor!==actorId){keep.push(w);continue;}if(!cur||cur.id!==w.id)w.res(null);else if(w.test(cur))w.res(w.make(cur));else keep.push(w);}this.waiters=keep;
  }
  watchHost(){
    const rec=()=>this.record(G()?.actors?.get?.(this.watchId));
    const until=(id,test,make)=>new Promise(res=>{const r=rec();if(!r||r.id!==id){res(null);return;}if(test(r)){res(make(r));return;}this.waiters.push({actor:this.watchId,id,test,make,res});});
    return {roll:id=>until(id,r=>!!r.k,r=>({record:r,die:null,pick:faithPick(r)})),
      root:id=>until(id,r=>r.spans!==null,r=>({record:r,spans:r.spans})),
      now:()=>this.now(),prefs:()=>({startMin:false,blur:this.part('curseBlur'),markOpen:false,reduced:this.reduced()}),pos:()=>this.setting(CURSE_CLIENT)?.pos??null,savePos(){},
      trouble:(where,e)=>this.trouble('watching · '+where,e),sound:(name,detail)=>this.sound(name,detail),soundInfo:()=>this.soundInfo(),soundStep:d=>this.soundStep(d),art:()=>this.artBase(),
      done:r=>{const a=G()?.actors?.get?.(this.watchId);if(a&&r?.k&&this.part('curseGmNote'))this.resultNote(a,r);}};
  }
  /** The GM's note once all of it is known: "Yvaelle is cursed · Fearful · 3 Spans · toward Gate Warden". */
  resultNote(actor,cur){
    const e=stateOf(cur.k);if(!e||cur.spans===null)return null;const who=!namesSomeone(cur.k)?'all within 15 ft':cur.toward?`toward ${cur.toward.n}`:'';
    return this.note(`${actor.name} · ${e.n}`,`${cur.spans} ${spanWord(cur.spans)}${who?' · '+who:''}`,e.acc,`${actor.name} is cursed`);
  }
  settingsChanged(){
    if(!G()?.ready)return;this.applyStates();const on=this.enabled(),sh=on&&this.part('curseSheet');
    {const snd=this.sounding();if(snd!==this.sndWas){this.sndWas=snd;if(snd)void this.warmSound();else this.snd?.stop();}}
    if(sh!==this.sheetWas){this.sheetWas=sh;if(sh){for(const id of this.known.keys()){try{const a=G().actors?.get?.(id);if(a?.sheet?.rendered)a.sheet.render(false);}catch{}}}else this.refreshSheetChips();}
    if(on!==this.wasOn){this.wasOn=on;if(!on){this.wheel?.destroy();this.editor?.close();if(this.watchId){this.watcher?.sync(null);this.settle(this.watchId,null);this.watchId=null;}}this.rescan(false);this.refreshSheetChips();}
    else if(this.view?.mode==='mark')this.view.fillMark();
  }
  /** The world's clock moved: the Spans left change, and a curse that has run out is lifted by one page only. */
  timeChanged(){
    this.view?.timeChanged();this.watcher?.timeChanged();if(this.wheel?.open)this.wheel.fillStrip();this.refreshSheetChips();
    const g=G(),now=this.now(),gm=g?.users?.activeGM??null;
    for(const [id,r] of this.known){if(!curseOver(r,now))continue;const a=g?.actors?.get?.(id);if(!a)continue;
      if(gm?gm.isSelf:this.iPresent(a))void this.lift(a,{quiet:true});}
  }
  /* ───────── the GM's small note ───────── */
  /** A GM who is not the one showing it is told once what she rolled, and once for how long. */
  observe(actor,was,cur,userId){
    const g=G();if(!g?.user?.isGM||!cur||!this.enabled()||!this.part('curseGmNote')||this.iPresent(actor))return;
    // (a GM watching it happen needs no note about it: the watcher's view says the same, and leaves the last note itself)
    if(this.watchId===actor.id&&this.watcher?.mode==='full'&&!this.watcher.looking)return;
    const same=was&&was.id===cur.id,e=cur.k?stateOf(cur.k):null;if(!e)return;
    const who=!namesSomeone(cur.k)?'all within 15 ft':cur.toward?`toward ${cur.toward.n}`:'';
    if(cur.spans!==null&&(!same||was.spans===null))this.resultNote(actor,cur);
    else if(cur.spans===null&&(!same||!was.k)&&!(cur.forced&&cur.by===g.user.id))this.note(`${actor.name} · ${e.n}`,`${who||'she has rolled'} · Spans not yet rolled`,e.acc,cur.forced?`Laid on ${actor.name}`:`${actor.name} rolled`);
  }
  note(title,line,acc,head){
    const d=this.doc;if(!d?.body)return null;this.stats.notes++;this.lastNote?.remove();const c=d.createElement('div');this.lastNote=c;c.className='ff-cu-chip ff-cu-gmnote';c.style.setProperty('--ffcu-ac',acc?`rgb(${acc})`:'#ff78f6');
    c.innerHTML=`<svg class="ff-cu-gem" width="16" height="24" viewBox="-8 -11 16 24" aria-hidden="true"><path d="M0-10 5 0 0 12-5 0Z" fill="#120c10" stroke="#5a4650"/><path class="ff-cu-core" d="M0-3 1.6 0 0 4-1.6 0Z"/></svg><div>${head?`<div class="ff-cu-k">${esc(head)}</div>`:''}<div class="ff-cu-n">${esc(title)}</div><div class="ff-cu-m">${esc(line)}</div></div>`;
    const a=this.ensureView().anchor();c.style.right=a.right+'px';c.style.top=a.top+'px';d.body.appendChild(c);void c.offsetWidth;c.classList.add('ff-cu-on');
    const go=()=>{c.classList.remove('ff-cu-on');this.win.setTimeout(()=>c.remove(),600);};c.addEventListener('click',go);this.win.setTimeout(go,6500);return c;
  }
  /* ───────── who is cursed, and who it can be about ───────── */
  /** The actor the GM curses: the one chosen (the top of the wheel's strip), else the character pinned in this page's HUD, else the one selected token's. */
  her(){
    const g=G(),id=this.setting(CURSE_WORLD)?.actor;if(id){const a=g?.actors?.get?.(id);if(a)return a;}
    const base=t=>{const doc=t?.document??t;return doc?.baseActor??(doc?.actorId?g?.actors?.get?.(doc.actorId):null)??null;};
    try{const a=base(this.pinned?.());if(a)return a;}catch{}
    const sel=globalThis.canvas?.tokens?.controlled??[];if(sel.length===1){const a=base(sel[0]);if(a)return a;}
    return null;
  }
  /** Make the selected token's character the one who is cursed (kept for the world). */
  useSelected(){
    const g=G(),sel=globalThis.canvas?.tokens?.controlled??[];if(sel.length!==1){globalThis.ui?.notifications?.info?.('Select her token (one token), then click here.');return null;}
    const doc=sel[0].document,a=doc?.baseActor??(doc?.actorId?g?.actors?.get?.(doc.actorId):null);if(!a)return null;void this.save(CURSE_WORLD,{actor:a.id});this.chosen=a.id;return a.name;
  }
  /** The people the strip offers: the tokens the GM has selected or targeted, then the other player characters. Never her. */
  people(){
    const g=G(),her=this.chosenActor(),out=[];
    const tok=t=>{const doc=t?.document,a=t?.actor;if(!doc||!a)return;const linked=!!doc.actorLink;if(linked&&a.id===her?.id)return;out.push({id:linked?a.uuid:doc.uuid,n:doc.name||a.name,img:doc.texture?.src||a.img||''});};
    try{for(const t of globalThis.canvas?.tokens?.controlled??[])tok(t);for(const t of g?.user?.targets??[])tok(t);}catch{}
    try{for(const a of g?.actors??[])if(a.type==='character'&&a.hasPlayerOwner&&a.id!==her?.id)out.push({id:a.uuid,n:a.name,img:a.img||''});}catch{}
    return peopleList(out);
  }
  chosenActor(){const g=G();if(this.chosen){const a=g?.actors?.get?.(this.chosen);if(a)return a;}return this.her();}
  /* ───────── laying, rolling, lifting ───────── */
  async write(actor,record){await actor.update({[`flags.${ID}.${CURSE_FLAG}`]:record});return record;}
  /* ───────── her Keepsake sheet (beta.2) ───────── */
  /** The curse as a chip among the conditions on her, for her sheet's header (dress.mjs asks for it at every render). Her
   * owner and the GM only; nothing where there is no curse. */
  sheetChip(actor,doc=this.doc){
    try{
      if(!this.enabled()||!this.part('curseSheet')||!actor?.isOwner)return null;const rec=this.record(actor);if(!rec||curseOver(rec,this.now()))return null;
      const b=doc.createElement('button');b.type='button';b.className='ffks-cchip ffks-curse named';b.dataset.ffCurse=actor.id;this.fillChip(b,rec);
      b.addEventListener('click',ev=>{ev.preventDefault();ev.stopPropagation();try{this.showFor(actor);}catch(e){this.trouble('her sheet’s mark was pressed',e);}});return b;
    }catch(e){this.trouble('her sheet’s mark',e);return null;}
  }
  fillChip(b,rec){
    const now=this.now(),e=rec.k?stateOf(rec.k):null,n=spansLeft(rec,now);b.style.setProperty('--ffcu-ac',e?`rgb(${e.acc})`:'#ff78f6');b.classList.toggle('ffks-curse-ask',!e);
    b.innerHTML=`${gemSVG(10,15)}<span class="nm">${e?esc(e.n):'A roll is asked'}</span>${n!==null?`<span class="v">${n}</span>`:''}`;
    const tip=e?`${CURSE_TITLE} · ${e.n} · ${markLine(rec,now)}. Made to ${e.w}: ${e.d}`:`${CURSE_TITLE} · a roll is asked of her`;b.title=tip;b.setAttribute('aria-label',tip);
  }
  /** The clock moved, or a text was edited: the chips on open sheets are written again (one that has run out goes). */
  refreshSheetChips(){
    for(const b of this.doc?.querySelectorAll?.('.ffks-curse[data-ff-curse]')??[]){const a=G()?.actors?.get?.(b.dataset.ffCurse),rec=a&&this.enabled()&&this.part('curseSheet')?this.record(a):null;if(!rec||curseOver(rec,this.now()))b.remove();else this.fillChip(b,rec);}
  }
  /** Her sheet's mark was pressed: the full view on the page that shows it; on a GM's page that does not, the finished picture as it stands. */
  showFor(actor){
    if(!actor)return false;
    if(this.actorId===actor.id&&this.view){const m=this.view.mode;if(m==='card'||m==='mark'){void this.view.open(m);return true;}return m==='full';}
    if(!G()?.user?.isGM)return false;const rec=this.record(actor);if(!rec?.k)return false;
    this.watchId=actor.id;const w=this.ensureWatcher(actor);if(w.mode==='full')return true;if(w.rec?.id!==rec.id)w.sync(rec,{fresh:false});else w.rec=rec;void w.look();return true;
  }
  /* ───────── the states' editor (beta.2) ───────── */
  /** Open (or close) the editor of the six states' names and texts. GM only. */
  edit(){
    const g=G();if(!g?.user?.isGM){globalThis.ui?.notifications?.warn?.('Only the GM edits the states.');return false;}
    this.editor??=new CurseEditor({doc:this.doc,win:this.win,host:{edits:()=>this.setting(CURSE_WORLD)?.states??{},
      save:async edits=>{const ok=await this.save(CURSE_WORLD,{states:stateEdits(edits)});if(!ok)return false;this.applyStates();const n=Object.keys(stateEdits(edits)).length;this.note('The six states',n?`${n} of them changed from the table`:'as the table has them',null,'Saved for the world');return true;}}});
    return this.editor.toggle();
  }
  /** The GM lays a curse. state: 0 to 5 (or a state's key) lays that one; null lets her roll. toward: a person, or none (the roll of faith). */
  async lay({state=null,toward=null,people=null,die=4,actor=null}={}){
    const g=G();if(!g?.user?.isGM)return {ok:false,why:'Only the GM lays a curse.'};if(!this.enabled())return {ok:false,why:'The Heart Turned is switched off (Settings › Her › Moods & milestones).'};
    const a=actor??this.chosenActor();if(!a)return {ok:false,why:'Nobody is chosen to curse: select her token, then click the top of the strip.'};
    const ti=typeof state==='string'?stateIndex(state):state,rec=newCurse({state:Number.isInteger(ti)&&ti>=0&&ti<6?ti:null,toward,people:people??this.people(),die:dieOf(die),by:g.user.id,faith:()=>this.rng()});
    try{await this.write(a,rec);}catch(e){this.trouble('laying a curse',e);return {ok:false,why:'It could not be written on her actor: '+String(e?.message??e).slice(0,80)};}
    this.stats.laid++;return {ok:true,name:a.name,local:this.presenter(a)===g.user.id,id:rec.id,watching:this.presenter(a)!==g.user.id&&this.watching()&&!this.reduced()};
  }
  async lift(actor=this.chosenActor(),{quiet=false}={}){
    if(!actor||!this.record(actor))return false;try{await actor.unsetFlag(ID,CURSE_FLAG);this.stats.lifted++;return true;}catch(e){if(!quiet)this.trouble('lifting',e);return false;}
  }
  async burn(actor=this.chosenActor()){
    const cur=this.record(actor),next=burnSpan(cur);if(!next)return false;if(curseOver(next,this.now()))return this.lift(actor);try{await this.write(actor,next);return true;}catch(e){this.trouble('burning a Span',e);return false;}
  }
  viewHost(){
    const actor=()=>G()?.actors?.get?.(this.actorId)??null;
    return {
      roll:async id=>{const a=actor(),cur=this.record(a);if(!a||!cur||cur.id!==id)return null;const out=rollCurse(cur,()=>this.rng());await this.write(a,out.record);this.stats.rolled++;return out;},
      root:async id=>{const a=actor(),cur=this.record(a);if(!a||!cur||cur.id!==id||!cur.k)return null;const out=cur.spans!==null?{record:cur,spans:cur.spans}:rootCurse(cur,this.now(),()=>this.rng());if(cur.spans===null){await this.write(a,out.record);this.stats.rooted++;}return out;},
      now:()=>this.now(),
      prefs:()=>({startMin:this.part('curseStartMin'),blur:this.part('curseBlur'),markOpen:this.part('curseMarkOpen'),reduced:this.reduced()}),
      pos:()=>this.setting(CURSE_CLIENT)?.pos??null,savePos:p=>{void this.save(CURSE_CLIENT,{pos:{right:Math.round(p.right),top:Math.round(p.top)}});},
      trouble:(where,e)=>this.trouble(where,e),sound:(name,detail)=>this.sound(name,detail),soundInfo:()=>this.soundInfo(),soundStep:d=>this.soundStep(d),art:()=>this.artBase()
    };
  }
  reduced(){try{if(G()?.settings?.get?.(ID,'reducedMotion'))return true;}catch{}try{return !!this.win?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;}catch{return false;}}
  /* ───────── the wheel ───────── */
  wheelHost(){
    return {her:()=>{const a=this.chosenActor();return a?{name:a.name,img:a.img||''}:null;},people:()=>this.people(),active:()=>this.record(this.chosenActor()),now:()=>this.now(),
      send:o=>this.lay(o),lift:()=>this.lift(),burn:()=>this.burn(),useSelected:()=>this.useSelected(),
      gm:()=>({...this.setting(CURSE_CLIENT),watch:this.watching()}),edit:()=>this.edit(),
      saveGm:p=>{const c=this.setting(CURSE_CLIENT),die=dieOf(p.die),pin=String(p.pin??'');if(c?.die!==die||(c?.pin??'')!==pin)void this.save(CURSE_CLIENT,{die,pin});if(typeof p.watch==='boolean'&&p.watch!==this.watching())void this.setPart('curseWatch',p.watch);}};
  }
  /** Where the pointer is on the page (Foundry keeps it for the canvas), else the window's middle. */
  pointer(){
    try{const c=globalThis.canvas,p=c?.mousePosition;if(c?.ready&&p&&c.clientCoordinatesFromCanvas){const q=c.clientCoordinatesFromCanvas(p);if(Number.isFinite(q?.x)&&Number.isFinite(q?.y))return {x:q.x,y:q.y};}}catch{}
    return {x:(this.win?.innerWidth??1280)/2,y:(this.win?.innerHeight??720)/2};
  }
  /** Open the wheel round the pointer (or at a point of the page), or close it. GM only. */
  toggleWheel(x=null,y=null){
    const g=G();if(!g?.user?.isGM){globalThis.ui?.notifications?.warn?.('The curse wheel is the GM’s.');return false;}
    if(!this.enabled()){globalThis.ui?.notifications?.info?.('The Heart Turned is switched off (Settings › Her › Moods & milestones).');return false;}
    this.wheel??=new CurseWheel({host:this.wheelHost(),doc:this.doc,win:this.win});const p=Number.isFinite(x)&&Number.isFinite(y)?{x,y}:this.pointer();return this.wheel.toggle(p.x,p.y);
  }
  /* ───────── for the module's own check (beta.2) ───────── */
  /** A view of the same kind fed from memory: nothing is written on her actor, no chat line, and nobody else sees it.
   * state: 0 to 5 lays that one on her, else it is rolled. watch: the GM's watching kind.
   * → {view, errors, record(), finish() (roll and root it in memory), start() (as if laid just now), end()} */
  dry({state=null,watch=false,people=null,die=4}={}){
    const errors=[],cues=[],roll=()=>this.rng();let rec=newCurse({state,people:people??this.people(),die,by:G()?.user?.id??'',faith:roll});
    const host={roll:async()=>{const out=rollCurse(rec,roll);if(out)rec=out.record;return out;},root:async()=>{const out=rootCurse(rec,this.now(),roll);if(out)rec=out.record;return out;},
      now:()=>this.now(),prefs:()=>({startMin:false,blur:this.part('curseBlur'),markOpen:true,reduced:this.reduced()}),pos:()=>this.setting(CURSE_CLIENT)?.pos??null,savePos(){},done(){},
      trouble:(where,e)=>{errors.push(`${where}: ${String(e?.message??e).slice(0,120)}`);},
      // (a dry run is silent: its cues are only written down, for the check to read)
      sound:name=>{if(cues.length<4000)cues.push(String(name));},art:()=>this.artBase()};
    const view=new CurseView({host,doc:this.doc,win:this.win,watch,words:watch?watchWords(this.chosenActor()?.name):null});
    return {view,errors,cues,record:()=>rec,finish:()=>{if(!rec.k)rec=rollCurse(rec,roll).record;if(rec.spans===null)rec=rootCurse(rec,this.now(),roll).record;return rec;},
      start:()=>view.sync(rec,{fresh:true}),end:()=>view.sync(null)};
  }
  /** game.modules.get('filament-flight').api.curse */
  api(){
    return Object.freeze({
      open:(x,y)=>this.toggleWheel(x,y),
      // toward: a person {id, n, img}, or just a name
      lay:(state,o={})=>this.lay({...o,toward:typeof o.toward==='string'?{n:o.toward}:o.toward,state}),ask:(o={})=>this.lay({...o,toward:typeof o.toward==='string'?{n:o.toward}:o.toward,state:null}),lift:()=>this.lift(),burn:()=>this.burn(),
      state:()=>this.record(this.chosenActor()),her:()=>this.chosenActor()?.name??null,states:()=>CURSE_NOW.map(e=>({key:e.k,name:e.n,verb:e.w,text:e.d})),edit:()=>this.edit(),watch:on=>{if(typeof on==='boolean')void this.setPart('curseWatch',on);return typeof on==='boolean'?on:this.watching();},errors:()=>this.errors.map(e=>({...e})),
      minimise:()=>this.view?.minimise(),show:()=>this.showFor(this.chosenActor()),
      // (beta.4) hear('cut') plays one of its sounds, whether the switch is on or not · sounds() says what is loaded
      hear:(name,detail)=>this.hear(name,detail),sounds:()=>({on:this.sounding(),bed:this.part('curseBed'),level:this.soundLevel(),files:[...CURSE_SOUND_FILES],loaded:this.sndAudio?.loaded()??[],failed:this.sndAudio?.failed()??[],...(this.snd?.status()??{})}),
      status:()=>({enabled:this.enabled(),presenting:this.actorId,view:this.view?.status()??null,watching:this.watching(),watcher:this.watcher?.status()??null,errors:this.errors.length,wheel:!!this.wheel?.open,stage:curseStage(this.record(this.chosenActor())),left:spansLeft(this.record(this.chosenActor()),this.now())}),
      stats:()=>({...this.stats,view:this.view?{...this.view.stats}:null,wheel:this.wheel?{...this.wheel.stats}:null})});
  }
}
