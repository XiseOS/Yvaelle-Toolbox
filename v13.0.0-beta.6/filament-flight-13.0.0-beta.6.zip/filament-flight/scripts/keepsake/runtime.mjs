/** Keepsake runtime: a very small template renderer for the Keepsake HUD.
 * Templates use {{holes}}, <sc-for list as>, <sc-if value> and on* handlers
 * whose values are functions from the component's renderVals(). Rendering
 * patches the live DOM in place, so ambient animations keep running and only
 * changed attributes or text are touched. No Foundry globals. */
import {timed} from './timings.mjs?v=13.0.0-beta.6';
const HOLE=/\{\{(.*?)\}\}/g;
const EVENT_MAP={click:'click',mouseenter:'mouseenter',mouseleave:'mouseleave',focus:'focus',blur:'blur',input:'input',change:'change',keydown:'keydown',keyup:'keyup',mousemove:'mousemove',pointerdown:'pointerdown'};
const KS=Symbol('keepsake');

export class DCLogic {
  constructor(props={}){this.props=props;this.state={};this._host=null;}
  setState(patch){
    const next=typeof patch==='function'?patch(this.state):patch;
    if(!next)return;Object.assign(this.state,next);this._host?.schedule();
  }
  forceUpdate(){this._host?.schedule();}
}

function look(scope,path){
  path=path.trim();
  if(path==='true')return true;if(path==='false')return false;
  if(/^-?\d/.test(path))return Number(path);
  const parts=path.split('.');
  for(let i=scope.length-1;i>=0;i--){
    const frame=scope[i];
    if(frame&&typeof frame==='object'&&parts[0] in frame){let v=frame[parts[0]];for(const p of parts.slice(1))v=v==null?v:v[p];return v;}
  }
  return undefined;
}
const single=str=>{const m=/^\s*\{\{(.*?)\}\}\s*$/.exec(str);return m?m[1]:null;};
const interp=(str,scope)=>str.replace(HOLE,(m,p)=>{const v=look(scope,p);return v==null||v===false?'':String(v);});

/** Build a light virtual tree for this render. */
function build(node,scope,out){
  if(node.nodeType===3){const t=interp(node.nodeValue,scope);if(t)out.push({text:t});return;}
  if(node.nodeType!==1)return;
  const tag=node.localName.toLowerCase();
  if(tag==='sc-for'){
    const list=look(scope,(node.getAttribute('list')??'').replace(/[{}]/g,''))??[];const as=node.getAttribute('as')??'item';
    const kids=[...node.childNodes];
    (Array.isArray(list)?list:[]).forEach((item,index)=>{const frame={[as]:item,$index:index};for(const ch of kids)build(ch,scope.concat([frame]),out);});
    return;
  }
  if(tag==='sc-if'){
    if(look(scope,(node.getAttribute('value')??'').replace(/[{}]/g,'')))for(const ch of node.childNodes)build(ch,scope,out);
    return;
  }
  const v={tag:node.localName,ns:node.namespaceURI,attrs:{},on:{},children:[]};
  for(const at of node.attributes){
    const name=at.name;
    if(/^on/i.test(name)){const ev=EVENT_MAP[name.slice(2).toLowerCase()];const path=single(at.value);if(ev&&path){const fn=look(scope,path);if(typeof fn==='function')v.on[ev]=fn;}continue;}
    if(name.startsWith('hint-'))continue;
    v.attrs[name]=interp(at.value,scope);
  }
  const kids=node.content?node.content.childNodes:node.childNodes;
  for(const ch of kids)build(ch,scope,v.children);
  out.push(v);
}

function create(doc,v){
  if(v.text!==undefined)return doc.createTextNode(v.text);
  const el=v.ns&&v.ns!=='http://www.w3.org/1999/xhtml'?doc.createElementNS(v.ns,v.tag):doc.createElement(v.tag);
  for(const [k,val] of Object.entries(v.attrs))setAttr(el,k,val);
  el[KS]={on:v.on};
  if(!('data-ks-foreign' in v.attrs))for(const ch of v.children)el.appendChild(create(doc,ch));
  if(v.tag==='input'&&'value' in v.attrs)el.value=v.attrs.value;
  return el;
}
function setAttr(el,k,val){
  try{if(k==='href'&&el.namespaceURI==='http://www.w3.org/2000/svg')el.setAttribute('href',val);else el.setAttribute(k,val);}catch{}
}
function same(el,v){
  if(v.text!==undefined)return el.nodeType===3;
  return el.nodeType===1&&el.localName===v.tag&&(el.namespaceURI??null)===(v.ns??null);
}
/* ---- Feel (menus pass, beta.32) ----------------------------------------
 * Three small things the renderer does so every Keepsake surface answers on
 * the next frame and moves the same way:
 *  - a picked choice (segmented button, switch, list option, category) lights
 *    at once and stays lit while its save is on the way: the next renders keep
 *    the picked look until the real value arrives or a few seconds pass;
 *  - menus, scrims and pop-overs leave with a short fade instead of vanishing;
 *  - a list marked data-ks-stagger eases its items in when its key changes.
 * Reduced motion skips the motion; Frame motion Off keeps fades only. */
const HOLD=Symbol('ks-hold'),LEAVING=new WeakSet(),HOLD_MS=4000;
const CHOICE='.seg2,.seg,.feel,.sw,.tag.cat,.opt,.copt,.mk-switch,[data-ks-choice]';
const EXIT='.menu,.scrim,.pop,[data-ks-exit]';
const motionOf=el=>{
  const win=el?.ownerDocument?.defaultView;
  if(win?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches)return 'none';
  return el?.closest?.('.fm-off')?'fade':'full';
};
const live=parent=>LEAVING.has(parent)?[...parent.childNodes].filter(n=>!n[HOLD]?.leaving):parent.childNodes;
function leave(el){
  const parent=el.parentNode,mode=motionOf(el);
  if(mode==='none'||typeof el.animate!=='function'){el.remove();return;}
  el[HOLD]={leaving:true};LEAVING.add(parent);el.style.pointerEvents='none';
  const isMenu=el.matches?.('.menu,.pop,[data-ks-exit]');
  const frames=mode==='full'&&isMenu?[{opacity:1},{opacity:0,transform:'translateY(-3px) scale(.985)'}]:[{opacity:1},{opacity:0}];
  let done=false;const end=()=>{if(done)return;done=true;el.remove();};
  try{const a=el.animate(frames,{duration:isMenu?120:110,easing:'cubic-bezier(.4,0,1,1)',fill:'forwards'});a.finished.then(end,end);}catch{end();}
  setTimeout(end,400);
}
/** Light a picked choice now, before its handler's work (and any save) is done. */
function optimistic(btn){
  if(!btn||btn.disabled||btn.getAttribute('aria-disabled')==='true')return;
  const until=performance.now()+HOLD_MS,mark=(el,cls)=>{const prev=el.getAttribute('class')??'';if(prev===cls)return;el[HOLD]={cls,prev:el[HOLD]?.prev??prev,until};el.setAttribute('class',cls);};
  const has=el=>el.classList.contains('on');
  const toggled=c=>{const l=c.split(/\s+/).filter(Boolean);const i=l.indexOf('on');if(i>=0)l.splice(i,1);else l.push('on');return l.join(' ');};
  if(btn.matches('.sw,.mk-switch,[data-ks-choice=toggle]')){
    mark(btn,toggled(btn.getAttribute('class')??''));return;
  }
  if(has(btn))return;
  const base=btn.classList[0],group=btn.parentElement;if(!base||!group)return;
  // a lone button that only looks like a segment (Arrange…) is an action, not a choice
  if(![...group.children].some(sib=>sib!==btn&&sib.classList.contains(base)))return;
  for(const sib of group.children)if(sib!==btn&&sib.classList.contains(base)&&has(sib))mark(sib,toggled(sib.getAttribute('class')));
  mark(btn,toggled(btn.getAttribute('class')??''));
}
/** The class a render should write, given any optimistic hold on the element. */
function heldClass(el,want){
  const h=el[HOLD];if(!h||h.leaving)return want;
  if(want===h.cls||want!==h.prev||performance.now()>h.until){el[HOLD]=null;return want;}
  return h.cls;
}
function stagger(root){
  for(const el of root?.querySelectorAll?.('[data-ks-stagger]')??[]){
    const key=el.getAttribute('data-ks-stagger');if(el._ksStagger===key)continue;
    const first=el._ksStagger===undefined;el._ksStagger=key;if(first&&!el.hasAttribute('data-ks-stagger-first'))continue;
    const mode=motionOf(el);if(mode==='none')continue;
    let i=0;for(const ch of el.children){if(i>=14)break;if(!ch.getClientRects?.().length)continue;
      try{ch.animate(mode==='full'?[{opacity:0,transform:'translateY(5px)'},{opacity:1,transform:'none'}]:[{opacity:0},{opacity:1}],{duration:170,delay:i*16,easing:'cubic-bezier(.2,.8,.2,1)',fill:'backwards'});}catch{}
      i++;}
  }
}

function patch(parent,vlist){
  const doc=parent.ownerDocument;let i=0;
  for(;i<vlist.length;i++){
    const v=vlist[i],el=live(parent)[i];
    if(!el){parent.appendChild(create(doc,v));continue;}
    if(!same(el,v)){
      if(el.nodeType===1&&el.matches?.(EXIT)){parent.insertBefore(create(doc,v),el);leave(el);}
      else parent.replaceChild(create(doc,v),el);
      continue;}
    if(v.text!==undefined){if(el.nodeValue!==v.text)el.nodeValue=v.text;continue;}
    const old=el.attributes;
    for(let a=old.length-1;a>=0;a--){const n=old[a].name;if(!(n in v.attrs))el.removeAttribute(n);}
    for(const [k,raw] of Object.entries(v.attrs)){const val=k==='class'&&el[HOLD]?heldClass(el,raw):raw;if(el.getAttribute(k)!==val)setAttr(el,k,val);}
    if(el.localName==='input'&&'value' in v.attrs&&el.value!==v.attrs.value&&el.ownerDocument.activeElement!==el&&el.getRootNode()?.activeElement!==el)el.value=v.attrs.value;
    if(el.localName==='input'&&el.type==='range'&&'value' in v.attrs&&el.value!==v.attrs.value&&!el.matches(':active'))el.value=v.attrs.value;
    el[KS]={on:v.on};
    // foreign islands (classic tuning) are filled after render; never patch their children
    if(!('data-ks-foreign' in v.attrs))patch(el,v.children);
  }
  for(let kids=live(parent);kids.length>i;kids=live(parent)){
    const n=kids[kids.length-1];
    if(n.nodeType===1&&n.matches?.(EXIT))leave(n);else parent.removeChild(n);
  }
}

const handlerOf=(el,type)=>el?.[KS]?.on?.[type];
const pathTo=(event,stop)=>{const path=[];for(let n=event.target;n&&n!==stop.parentNode;n=n.parentNode){if(n.nodeType===1)path.push(n);if(n===stop)break;}return path;};

/** Mount a component into a container (an element or a shadow root). */
export class KeepsakeHost {
  constructor(container,{template,component,afterRender=null,onError=null}){
    this.container=container;this.template=template;this.component=component;this.afterRender=afterRender;this.onError=onError;
    this.pending=false;this.destroyed=false;this.listeners=new AbortController();
    component._host=this;
    const {signal}=this.listeners,root=container;
    const fire=(type,event,el)=>{const fn=handlerOf(el,type);if(!fn)return false;try{fn(event);}catch(e){this.onError?.(e);}return true;};
    for(const type of ['click','input','change','keydown','keyup','mousemove','pointerdown'])
      root.addEventListener(type,event=>{for(const el of pathTo(event,this.rootElement??root)){
        if(type==='click'&&handlerOf(el,'click')&&el.matches?.(CHOICE)){try{optimistic(el);this.holdCheck();}catch{}}
        if(fire(type,event,el)&&type==='click')break;}},{signal});
    root.addEventListener('focusin',event=>{const el=event.target;fire('focus',event,el);},{signal});
    root.addEventListener('focusout',event=>{const el=event.target;fire('blur',event,el);},{signal});
    root.addEventListener('mouseover',event=>{
      for(const el of pathTo(event,this.rootElement??root)){if(el.contains(event.relatedTarget))continue;fire('mouseenter',event,el);}
    },{signal});
    root.addEventListener('mouseout',event=>{
      for(const el of pathTo(event,this.rootElement??root)){if(el.contains(event.relatedTarget))continue;fire('mouseleave',event,el);}
    },{signal});
  }
  get rootElement(){return this.container.querySelector?.(':scope > .ks-root')??null;}
  /** An optimistic choice that never hears back puts itself right after the hold. */
  holdCheck(){clearTimeout(this.holdTimer);this.holdTimer=setTimeout(()=>this.schedule(),HOLD_MS+60);}
  schedule(){if(this.pending||this.destroyed)return;this.pending=true;queueMicrotask(()=>{this.pending=false;this.render();});}
  render(){
    if(this.destroyed)return;
    try{
      const tag=this.label??'render',vals=timed(tag+':values',()=>this.component.renderVals()),out=[];
      timed(tag+':build',()=>{for(const ch of this.template.content.childNodes)build(ch,[vals],out);});
      timed(tag+':patch',()=>{patch(this.container,out.filter(v=>v.text===undefined||v.text.trim()));stagger(this.container);});
      if(this.afterRender)timed(tag+':after',()=>this.afterRender(this.rootElement,vals));
    }catch(e){this.onError?.(e);}
  }
  setTemplate(template,component){this.template=template;if(component){this.component._host=null;this.component=component;component._host=this;}this.render();}
  destroy(){this.destroyed=true;clearTimeout(this.holdTimer);this.listeners.abort();this.component._host=null;}
}

export function compileTemplate(doc,html){const t=doc.createElement('template');t.innerHTML=html;return t;}
