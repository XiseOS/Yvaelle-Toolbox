// Ellie's Medkit — opens the Medkit built into Yvaelle’s Toolbox 10.
// Select the healer, target the patient, then run this macro.
// No Advanced Macros or GM Bridge macro is needed any more.
const api = game.modules.get("filament-flight")?.api;
if (typeof api?.medkit === "function") await api.medkit();
else ui.notifications.error("Yvaelle’s Toolbox 10 or later is needed for the built-in Medkit.");
