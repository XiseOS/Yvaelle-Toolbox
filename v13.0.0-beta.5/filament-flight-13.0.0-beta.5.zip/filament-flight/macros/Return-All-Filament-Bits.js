(async () => {
  // Select the token whose assigned bits should return to their saved formation.
  const flight = game.modules.get("filament-flight")?.api;
  const token = canvas.tokens.controlled[0];
  if (!token) return ui.notifications.warn("Select a token first.");
  if (!flight?.bits?.returnAll) return ui.notifications.warn("Enable Yvaelle’s Toolbox first.");
  await flight.bits.returnAll(token);
})().catch(error => ui.notifications.error(error.message));
