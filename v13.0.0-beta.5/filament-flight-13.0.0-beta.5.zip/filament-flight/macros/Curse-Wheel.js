// Macro type: Script. For the GM. Opens the curse wheel round the pointer (or closes it): lay one of her six states on
// her, or let her roll for it. The same as the key in Configure Controls › Yvaelle’s Toolbox › Curse wheel (GM).
const toolbox = game.modules.get("filament-flight")?.api;
if (!toolbox?.curse?.open) {
  ui.notifications.error("Enable Yvaelle’s Toolbox v13.0.0-beta.1 or later first.");
} else {
  toolbox.curse.open();
}
