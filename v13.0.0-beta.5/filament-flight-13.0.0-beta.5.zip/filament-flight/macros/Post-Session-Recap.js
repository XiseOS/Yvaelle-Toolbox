// Macro type: Script. Her player (or the GM) runs it at the end of a session.
// Posts the Keepsake session recap card for the pinned character (experimental:
// Settings › Advanced › Experimental › Recap card, the GM's switch).
// Hold Shift to save the share-size image instead.
const v11 = game.modules.get("filament-flight")?.api?.v11;
if (!v11?.recap) {
  ui.notifications.error("This needs Yvaelle’s Toolbox 11.0.0-test.3 or later.");
} else {
  try {
    if (event?.shiftKey) await v11.recap.image();
    else await v11.recap.post();
  } catch (e) {
    ui.notifications.warn(e.message ?? String(e));
  }
}
