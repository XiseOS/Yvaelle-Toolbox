// Macro type: Script. Select one or more owned tokens, then run.
// Lights a circle of light carried by her bits, or douses whatever light is on (as the HUD's Light button).
const flight = game.modules.get("filament-flight")?.api;
if (!flight?.toggleLightMode) {
  ui.notifications.error("Enable Yvaelle’s Toolbox v8.8 or later first.");
} else {
  await flight.toggleLightMode();
}
