// Macro type: Script. Select your token, then run. Re-running focuses the same HUD.
const flight = game.modules.get("filament-flight")?.api;
if (!flight?.openHUD) {
  ui.notifications.error("Enable Yvaelle’s Toolbox v1.5.0 or later first.");
} else {
  await flight.openHUD();
}
