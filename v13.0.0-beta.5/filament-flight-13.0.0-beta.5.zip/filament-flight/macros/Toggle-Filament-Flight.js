// Macro type: Script. Select your token, then run. Run again to land.
// Takes off and lands with the full sequence, as the HUD's Take off button does.
const flight = game.modules.get("filament-flight")?.api;
const tokens = (canvas.tokens?.controlled ?? []).filter(t => t.document.isOwner && !t.isPreview);
if (!flight?.toggleFlight) {
  ui.notifications.error("Enable the Yvaelle’s Toolbox module first.");
} else if (!tokens.length) {
  ui.notifications.warn("Select a token you own first.");
} else {
  await Promise.allSettled(tokens.map(token => flight.toggleFlight(token)));
}
