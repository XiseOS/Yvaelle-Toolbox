// Macro type: Script. Opens (or closes) Photo mode for the pinned character
// (experimental: Settings › Advanced › Experimental › Photo mode). Esc leaves it.
const v11 = game.modules.get("filament-flight")?.api?.v11;
if (!v11?.photo) {
  ui.notifications.error("This needs Yvaelle’s Toolbox 11.0.0-test.3 or later.");
} else {
  try { await v11.photo.open(); } catch (e) { ui.notifications.warn(e.message ?? String(e)); }
}
