// Macro type: Script. Run before reinstalling 6.6.7, preferably between actions.
// GM: world tokens and actor prototypes. Player: owned documents.
// Self-contained; no dependency on installed module files.
(async () => {
  const createV700Compatibility = (function createV700Compatibility(){
  const ID='filament-flight';
  const plain=value=>value&&typeof value==='object'&&!Array.isArray(value);
  const copy=value=>value===undefined?undefined:structuredClone(value);
  const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const safeKey=key=>!['__proto__','prototype','constructor'].includes(key)&&!key.includes('.');
  function cleanModuleFlags(raw){
    const value=copy(raw);let repairFieldsRemoved=0;
    const remove=(object,key)=>{if(plain(object)&&Object.hasOwn(object,key)){delete object[key];repairFieldsRemoved++;}};
    if(plain(value)){
      const flight=value.flight;
      for(const key of ['fromVelocity','fromBeamVelocity','fromReachVelocity'])remove(flight?.lantern,key);
      remove(flight?.modeTransition,'velocity');remove(flight?.structureTransition,'velocity');
      for(const [id,sample]of Object.entries(flight?.structurePoseTransition?.from??{}))if(safeKey(id))remove(sample,'velocity');
      if(Array.isArray(value.bitAnimations?.events))for(const event of value.bitAnimations.events){remove(event,'returnCoreStates');remove(event,'returnCoreVelocities');remove(event,'originCoreVelocities');}
    }
    return {value,changed:!same(raw,value),counts:{repairFieldsRemoved}};
  }
  function changes(before,after,prefix,out={}){
    if(same(before,after))return out;
    if(plain(before)&&plain(after)){
      for(const key of new Set([...Object.keys(before),...Object.keys(after)])){
        if(!safeKey(key))continue;
        if(!Object.hasOwn(after,key))out[`${prefix}.-=${key}`]=null;
        else changes(before[key],after[key],`${prefix}.${key}`,out);
      }
    }else out[prefix]=copy(after);
    return out;
  }
  function planDocument(raw,{prefix=`flags.${ID}`}={}){
    const result=cleanModuleFlags(raw);return {...result,changes:changes(raw,result.value,prefix)};
  }
  const entries=collection=>Array.isArray(collection)?collection:Array.isArray(collection?.contents)?collection.contents:typeof collection?.values==='function'?[...collection.values()]:[];
  const moduleOf=doc=>doc?.flags?.[ID]??(doc?.getFlag?.(ID,'flight')==null?undefined:{flight:doc.getFlag(ID,'flight')});
  const owned=(doc,user)=>user?.isGM===true||doc?.isOwner===true||doc?.testUserPermission?.(user,'OWNER')===true;
  async function run({game:app=globalThis.game,dryRun=false}={}){
    if(!app?.user)throw new Error('Open a Foundry world before preparing rollback.');
    if(typeof dryRun!=='boolean')throw new Error('Rollback dryRun must be a boolean.');
    const report={version:'7.0.0',archive:'Filament-Flight-v7-Foundry-v14.zip',dryRun,repairFieldsRemoved:0,documentsChanged:0,tokensScanned:0,actorsScanned:0,prototypesChanged:0,skipped:0,errors:[]};
    const apply=async(doc,patch,count)=>{
      if(!Object.keys(patch).length)return false;
      try{if(!dryRun)await doc.update(patch);report.documentsChanged++;report.repairFieldsRemoved+=count;return true;}
      catch(error){report.errors.push({document:doc.uuid??doc.id??doc.name,message:String(error?.message??error)});return false;}
    };
    const seen=new Set();
    for(const scene of entries(app.scenes))for(const token of entries(scene.tokens)){
      if(seen.has(token))continue;seen.add(token);report.tokensScanned++;
      if(!owned(token,app.user)){report.skipped++;continue;}
      const plan=planDocument(moduleOf(token));await apply(token,plan.changes,plan.counts.repairFieldsRemoved);
    }
    for(const actor of entries(app.actors)){
      report.actorsScanned++;if(!owned(actor,app.user)){report.skipped++;continue;}
      const direct=planDocument(moduleOf(actor)),prototype=planDocument(moduleOf(actor.prototypeToken),{prefix:`prototypeToken.flags.${ID}`});
      const patch={...direct.changes,...prototype.changes},hadPrototype=Object.keys(prototype.changes).length>0;
      if(await apply(actor,patch,direct.counts.repairFieldsRemoved+prototype.counts.repairFieldsRemoved)&&hadPrototype)report.prototypesChanged++;
    }
    return report;
  }
  return {cleanModuleFlags,planDocument,run};
});
  const compatibility = (function createV667Compatibility(){
  const ID='filament-flight',MEDKIT='ellieMedkitBitAnimationOptions';
  const classicFormations=['orbit','drift','weave','curious','escort','social','vigil','atelier','shelter','lanterns','relay','patrol','curiousCompanions','quietExchange','attentiveEscort','livingWorkshop'];
  const newFormations=['nightbloom','prismArc','velvetCourt','tensionWeft','lilyVigil','foldedLetter','pearlCanopy','resonantMeasure'];
  const treatmentFallbacks={capillaryBridge:'vascular',irisPatch:'compression',segmentedCradle:'splint',lymphaticCircuit:'vascular',fibrilRepair:'suture',tissueLens:'precision',pulseReservoir:'pulseHalo',petalSanctuary:'membrane',threadbind:'mendingVeil',crystalCast:'lattice',wingSuture:'suture'};
  // Bit-group fields added after 6.6.7, mapped to the nearest field it knows.
  const fieldFallbacks={threadbind:'mendingVeil',crystalCast:'intercept',wingSuture:'mendingVeil'};
  const oldPrograms=new Set(classicFormations),newPrograms=new Set(newFormations);
  const plain=value=>value&&typeof value==='object'&&!Array.isArray(value);
  const copy=value=>value===undefined?undefined:structuredClone(value);
  const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const counts=()=>({formationsMapped:0,flowPoolsFiltered:0,flowTransitionsCleared:0,treatmentsMapped:0,fieldsMapped:0,audioProfilesMapped:0,v7FieldsRemoved:0,looksConverted:0});
  const sum=(into,from)=>{for(const [key,value]of Object.entries(from))into[key]=(into[key]??0)+value;return into;};
  const fallback=id=>Object.hasOwn(treatmentFallbacks,id)?treatmentFallbacks[id]:id;
  const safeKey=key=>!['__proto__','prototype','constructor'].includes(key)&&!key.includes('.');
  function cleanFlow(flow,report){
    if(!plain(flow)||!Array.isArray(flow.pool))return;
    const pool=[...new Set(flow.pool.filter(id=>oldPrograms.has(id)))].slice(0,16);
    if(!same(pool,flow.pool)){flow.pool=pool;report.flowPoolsFiltered++;}
  }
  function cleanGroup(group,report){
    if(!plain(group))return;
    const replaced=newPrograms.has(group.program);
    if(replaced){group.program='orbit';report.formationsMapped++;}
    if(plain(group.effect)&&Object.hasOwn(fieldFallbacks,group.effect.id)){group.effect.id=fieldFallbacks[group.effect.id];report.fieldsMapped++;}
    const removedNewFlow=Array.isArray(group.flow?.pool)&&group.flow.pool.some(id=>newPrograms.has(id));
    cleanFlow(group.flow,report);
    // A captured V7 route cannot be interpreted as a classic movement. The
    // intended destinations and bit membership stay exactly as the user set.
    if(plain(group.transition)&&(replaced||removedNewFlow||newPrograms.has(group.transition.fromProgram)||newPrograms.has(group.transition.toProgram))){delete group.transition;report.flowTransitionsCleared++;}
  }
  function cleanTreatment(spec,report){
    if(!plain(spec))return;
    const style=fallback(spec.style);if(style!==spec.style){spec.style=style;report.treatmentsMapped++;}
    for(const key of ['enhanced','variation'])if(Object.hasOwn(spec,key)){delete spec[key];report.v7FieldsRemoved++;}
  }
  /** Only known cosmetic compatibility fields change. Flight.v7 is safe for
   * the old normalizer to ignore and retained for a later return to v7. */
  function cleanModuleFlags(raw){
    const repaired=createV700Compatibility().cleanModuleFlags(raw),value=repaired.value,report=counts();report.v7FieldsRemoved+=repaired.counts.repairFieldsRemoved;if(!plain(value))return {value,changed:false,counts:report};
    const flight=value.flight;
    if(plain(flight?.gemMotion)&&newPrograms.has(flight.gemMotion.soloProgram)){flight.gemMotion.soloProgram='orbit';report.formationsMapped++;}
    for(const [id,group]of Object.entries(value.bitAllocations?.groups??{}))if(safeKey(id))cleanGroup(group,report);
    if(Array.isArray(value.bitAnimations?.events))for(const event of value.bitAnimations.events){
      if(!plain(event))continue;
      cleanGroup(event.group,report);cleanTreatment(event.treatment,report);
      if(Object.hasOwn(event,'returnTreatment')){delete event.returnTreatment;report.v7FieldsRemoved++;}
    }
    return {value,changed:!same(raw,value),counts:report};
  }
  function cleanMedkitOptions(raw){
    const value=copy(raw),report=counts();if(!plain(value))return {value,changed:false,counts:report};
    const selected=value.style;cleanTreatment(value,report);
    if(plain(value.audioProfiles)){
      // Preserve an existing classic sound profile. When several new styles
      // share a fallback, prefer the currently selected new profile first.
      const names=Object.keys(value.audioProfiles).sort((a,b)=>Number(b===selected)-Number(a===selected));
      for(const name of names)if(Object.hasOwn(treatmentFallbacks,name)){
        const to=fallback(name);if(!Object.hasOwn(value.audioProfiles,to))value.audioProfiles[to]=copy(value.audioProfiles[name]);
        delete value.audioProfiles[name];report.audioProfilesMapped++;
      }
    }
    return {value,changed:!same(raw,value),counts:report};
  }
  function cleanLooks(raw){
    const value=copy(raw),report=counts();if(!plain(value))return {value,changed:false,counts:report};
    for(const entry of Object.values(value)){
      const look=entry?.look;if(!plain(look))continue;let changed=false;
      // Version-1 looks enforce a cosmetic key whitelist in 6.6.7. Keeping
      // this otherwise valid new member would hide the whole saved look.
      if(Object.hasOwn(look,'v7')){delete look.v7;report.v7FieldsRemoved++;changed=true;}
      if(plain(look.gemMotion)&&newPrograms.has(look.gemMotion.soloProgram)){look.gemMotion.soloProgram='orbit';report.formationsMapped++;changed=true;}
      if(changed)report.looksConverted++;
    }
    return {value,changed:!same(raw,value),counts:report};
  }
  /** Minimal dotted changes preserve unrelated concurrent document channels.
   * Action arrays must be replaced as arrays; numeric dotted writes would
   * change Foundry's array data shape. Nothing changes action destinations. */
  function changes(before,after,prefix,out={}){
    if(same(before,after))return out;
    if(plain(before)&&plain(after)){
      for(const key of new Set([...Object.keys(before),...Object.keys(after)])){
        if(!safeKey(key))continue;
        if(!Object.hasOwn(after,key))out[`${prefix}.-=${key}`]=null;
        else changes(before[key],after[key],`${prefix}.${key}`,out);
      }
    }else out[prefix]=copy(after);
    return out;
  }
  function planDocument(moduleFlags,{prefix=`flags.${ID}`}={}){
    const result=cleanModuleFlags(moduleFlags);return {...result,changes:changes(moduleFlags,result.value,prefix)};
  }
  const entries=collection=>Array.isArray(collection)?collection:Array.isArray(collection?.contents)?collection.contents:typeof collection?.values==='function'?[...collection.values()]:[];
  const moduleOf=doc=>{
    if(doc?.flags?.[ID]!=null)return doc.flags[ID];
    const flight=doc?.getFlag?.(ID,'flight');return flight==null?undefined:{flight};
  };
  const medkitOf=doc=>doc?.flags?.world?.[MEDKIT]??doc?.getFlag?.('world',MEDKIT);
  const owned=(doc,user)=>user?.isGM===true||doc?.isOwner===true||doc?.testUserPermission?.(user,'OWNER')===true;
  /** Explicitly invoked future user action. GM: all accessible world tokens,
   * actor prototypes and known preferences. Player: owned equivalents and
   * their own User preference. Personal looks remain client-local. */
  async function run({game:app=globalThis.game,dryRun=false,localLooks=true}={}){
    if(!app?.user)throw new Error('Open a Foundry world before preparing rollback.');
    if(typeof dryRun!=='boolean'||typeof localLooks!=='boolean')throw new Error('Rollback dryRun and localLooks must be booleans.');
    const report={version:'6.6.7',archive:'Filament-Flight-v6.6.7-Foundry-v14.zip',dryRun,...counts(),tokensScanned:0,actorsScanned:0,usersScanned:0,documentsChanged:0,tokensChanged:0,actorsChanged:0,usersChanged:0,prototypesChanged:0,localLooksChanged:false,skipped:0,errors:[],reminders:['Run this before installing the unchanged Filament-Flight-v6.6.7-Foundry-v14.zip. It also works after installation.','Personal saved looks are local to each player’s browser; other players should run this macro for their own looks.']};
    const apply=async(doc,patch,kind,statistics)=>{
      if(!Object.keys(patch).length)return;
      try{
        if(!dryRun)await doc.update(patch);
        report.documentsChanged++;report[`${kind}Changed`]++;sum(report,statistics);
      }catch(error){report.errors.push({document:doc.uuid??doc.id??doc.name??kind,message:String(error?.message??error)});}
    };
    const seen=new Set();
    for(const scene of entries(app.scenes))for(const token of entries(scene.tokens)){
      if(seen.has(token))continue;seen.add(token);report.tokensScanned++;
      if(!owned(token,app.user)){report.skipped++;continue;}
      const plan=planDocument(moduleOf(token));await apply(token,plan.changes,'tokens',plan.counts);
    }
    for(const actor of entries(app.actors)){
      report.actorsScanned++;if(!owned(actor,app.user)){report.skipped++;continue;}
      const direct=planDocument(moduleOf(actor)),prototype=planDocument(moduleOf(actor.prototypeToken),{prefix:`prototypeToken.flags.${ID}`}),medkit=cleanMedkitOptions(medkitOf(actor));
      const patch={...direct.changes,...prototype.changes,...(medkit.changed?changes(medkitOf(actor),medkit.value,`flags.world.${MEDKIT}`):{})},stats=sum(sum({...direct.counts},prototype.counts),medkit.counts),hadPrototype=Object.keys(prototype.changes).length>0,before=report.documentsChanged;
      await apply(actor,patch,'actors',stats);if(hadPrototype&&report.documentsChanged>before)report.prototypesChanged++;
    }
    for(const user of entries(app.users)){
      report.usersScanned++;
      if(!app.user.isGM&&user.id!==app.user.id){report.skipped++;continue;}
      const raw=medkitOf(user),medkit=cleanMedkitOptions(raw);await apply(user,medkit.changed?changes(raw,medkit.value,`flags.world.${MEDKIT}`):{},'users',medkit.counts);
    }
    if(localLooks&&app.settings?.get){
      try{
        const raw=app.settings.get(ID,'lookPresets'),looks=cleanLooks(raw);
        if(looks.changed){if(!dryRun)await app.settings.set(ID,'lookPresets',looks.value);report.localLooksChanged=true;sum(report,looks.counts);}
      }catch(error){report.errors.push({document:'Personal flight looks',message:String(error?.message??error)});}
    }
    return report;
  }
  return {classicFormations:[...classicFormations],newFormations:[...newFormations],treatmentFallbacks:{...treatmentFallbacks},fieldFallbacks:{...fieldFallbacks},cleanModuleFlags,cleanMedkitOptions,cleanLooks,planDocument,run};
})();
  try {
    const report = await compatibility.run({game});
    console.info('Yvaelle’s Toolbox compatibility preparation', report);
    const reminder = " Other players should run this macro for their personal Looks.";
    const message = report.errors.length ? `Compatibility preparation recorded ${report.errors.length} errors; review the console before installing the rollback ZIP.` : `Prepared ${report.documentsChanged} documents before installing the rollback ZIP: ${report.archive}.${reminder}`;
    ui.notifications[report.errors.length ? 'warn' : 'info'](message);
    return report;
  } catch (error) {
    console.error('Yvaelle’s Toolbox compatibility preparation', error);
    ui.notifications.error(String(error?.message ?? error));
    return null;
  }
})();
