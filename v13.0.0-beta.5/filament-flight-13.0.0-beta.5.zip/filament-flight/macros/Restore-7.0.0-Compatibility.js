// Macro type: Script. Run before reinstalling 7.0.0, preferably between actions.
// GM: world tokens and actor prototypes. Player: owned documents.
// Self-contained; no dependency on installed module files.
(async () => {
  const compatibility = (function createV700Compatibility(){
  const ID='filament-flight';
  const plain=value=>value&&typeof value==='object'&&!Array.isArray(value);
  const copy=value=>value===undefined?undefined:structuredClone(value);
  const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const safeKey=key=>!['__proto__','prototype','constructor'].includes(key)&&!key.includes('.');
  function cleanModuleFlags(raw){
    const value=copy(raw);let repairFieldsRemoved=0;
    const remove=(object,key)=>{if(plain(object)&&Object.hasOwn(object,key)){delete object[key];repairFieldsRemoved++;}};
    if(plain(value)){
      const flight=value.flight;
      for(const key of ['fromVelocity','fromBeamVelocity','fromReachVelocity'])remove(flight?.lantern,key);
      remove(flight?.modeTransition,'velocity');remove(flight?.structureTransition,'velocity');
      for(const [id,sample]of Object.entries(flight?.structurePoseTransition?.from??{}))if(safeKey(id))remove(sample,'velocity');
      if(Array.isArray(value.bitAnimations?.events))for(const event of value.bitAnimations.events){remove(event,'returnCoreStates');remove(event,'returnCoreVelocities');remove(event,'originCoreVelocities');}
    }
    return {value,changed:!same(raw,value),counts:{repairFieldsRemoved}};
  }
  function changes(before,after,prefix,out={}){
    if(same(before,after))return out;
    if(plain(before)&&plain(after)){
      for(const key of new Set([...Object.keys(before),...Object.keys(after)])){
        if(!safeKey(key))continue;
        if(!Object.hasOwn(after,key))out[`${prefix}.-=${key}`]=null;
        else changes(before[key],after[key],`${prefix}.${key}`,out);
      }
    }else out[prefix]=copy(after);
    return out;
  }
  function planDocument(raw,{prefix=`flags.${ID}`}={}){
    const result=cleanModuleFlags(raw);return {...result,changes:changes(raw,result.value,prefix)};
  }
  const entries=collection=>Array.isArray(collection)?collection:Array.isArray(collection?.contents)?collection.contents:typeof collection?.values==='function'?[...collection.values()]:[];
  const moduleOf=doc=>doc?.flags?.[ID]??(doc?.getFlag?.(ID,'flight')==null?undefined:{flight:doc.getFlag(ID,'flight')});
  const owned=(doc,user)=>user?.isGM===true||doc?.isOwner===true||doc?.testUserPermission?.(user,'OWNER')===true;
  async function run({game:app=globalThis.game,dryRun=false}={}){
    if(!app?.user)throw new Error('Open a Foundry world before preparing rollback.');
    if(typeof dryRun!=='boolean')throw new Error('Rollback dryRun must be a boolean.');
    const report={version:'7.0.0',archive:'Filament-Flight-v7-Foundry-v14.zip',dryRun,repairFieldsRemoved:0,documentsChanged:0,tokensScanned:0,actorsScanned:0,prototypesChanged:0,skipped:0,errors:[]};
    const apply=async(doc,patch,count)=>{
      if(!Object.keys(patch).length)return false;
      try{if(!dryRun)await doc.update(patch);report.documentsChanged++;report.repairFieldsRemoved+=count;return true;}
      catch(error){report.errors.push({document:doc.uuid??doc.id??doc.name,message:String(error?.message??error)});return false;}
    };
    const seen=new Set();
    for(const scene of entries(app.scenes))for(const token of entries(scene.tokens)){
      if(seen.has(token))continue;seen.add(token);report.tokensScanned++;
      if(!owned(token,app.user)){report.skipped++;continue;}
      const plan=planDocument(moduleOf(token));await apply(token,plan.changes,plan.counts.repairFieldsRemoved);
    }
    for(const actor of entries(app.actors)){
      report.actorsScanned++;if(!owned(actor,app.user)){report.skipped++;continue;}
      const direct=planDocument(moduleOf(actor)),prototype=planDocument(moduleOf(actor.prototypeToken),{prefix:`prototypeToken.flags.${ID}`});
      const patch={...direct.changes,...prototype.changes},hadPrototype=Object.keys(prototype.changes).length>0;
      if(await apply(actor,patch,direct.counts.repairFieldsRemoved+prototype.counts.repairFieldsRemoved)&&hadPrototype)report.prototypesChanged++;
    }
    return report;
  }
  return {cleanModuleFlags,planDocument,run};
})();
  try {
    const report = await compatibility.run({game});
    console.info('Yvaelle’s Toolbox compatibility preparation', report);
    const reminder = "";
    const message = report.errors.length ? `Compatibility preparation recorded ${report.errors.length} errors; review the console before installing the rollback ZIP.` : `Prepared ${report.documentsChanged} documents before installing the rollback ZIP: ${report.archive}.${reminder}`;
    ui.notifications[report.errors.length ? 'warn' : 'info'](message);
    return report;
  } catch (error) {
    console.error('Yvaelle’s Toolbox compatibility preparation', error);
    ui.notifications.error(String(error?.message ?? error));
    return null;
  }
})();
