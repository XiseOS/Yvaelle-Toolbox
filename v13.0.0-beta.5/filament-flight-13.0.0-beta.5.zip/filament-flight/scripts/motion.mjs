export const FLOAT_STYLES=Object.freeze({hover:'Classic hover',breath:'Breathing suspension',drift:'Astral drift',orbit:'Resonant orbit',levitate:'Rise and settle',pendulum:'Pendulum sway',heartbeat:'Heartbeat lift',wander:'Wander',still:'Still suspension'});
export const DEFAULTS = Object.freeze({
  wingScale:3.5, hoverHeight:0.20, bobHeight:0.045,
  tiltDegrees:12, wingSpeed:1, opacity:0.95,
  offsetX:0, offsetY:0, shadow:true,floatStyle:'hover',floatSpeed:1,floatSway:0.03,modeIdleStrength:1
});
export const LIMITS={wingScale:[1,7],hoverHeight:[0,1],bobHeight:[0,0.3],tiltDegrees:[0,35],
  wingSpeed:[0.2,3],opacity:[0,1],offsetX:[-2,2],offsetY:[-2,2],floatSpeed:[0.25,2],floatSway:[0,0.15],modeIdleStrength:[0,2]};
export function options(input={}) {
  const out={...DEFAULTS};
  for(const [k,[lo,hi]] of Object.entries(LIMITS)) {
    if(typeof input?.[k]==='number' && Number.isFinite(input[k]))
      out[k]=Math.min(hi,Math.max(lo,input[k]));
  }
  if(typeof input?.shadow==='boolean')out.shadow=input.shadow;
  if(typeof input?.floatStyle==='string'&&Object.hasOwn(FLOAT_STYLES,input.floatStyle))out.floatStyle=input.floatStyle;
  return out;
}
const fcycle=(t,p)=>((t/p)%1+1)%1,fsmooth=t=>t*t*(3-2*t);
function fkeys(p,keys){for(let i=1;i<keys.length;i++)if(p<=keys[i][0]){const [a,v]=keys[i-1],[b,w]=keys[i];return v+(w-v)*fsmooth((p-a)/(b-a));}return keys.at(-1)[1];}
// Rise and settle: a slow rise, a held hang, a settle that dips past the
// bottom and rebounds. Heartbeat: two quick lifts, then a long sink. (y in
// units of the vertical motion setting; both loop continuously.)
const LEVITATE=[[0,-1],[.4,1],[.5,1.04],[.62,1],[.88,-1.2],[1,-1]];
const HEARTBEAT=[[0,-1],[.09,.55],[.15,.35],[.27,1],[1,-1]];
/** Cosmetic, server-clock suspension. No movement of the TokenDocument.
 * x is sideways sway, y the rise and fall, roll a lean (a share of the
 * movement tilt) for the styles that sway: each style is its own hover. */
export function sampleFloat(opts,time,reduced=false) {
  const style=opts.floatStyle??'hover';
  if(reduced||style==='still')return {x:0,y:0,roll:0};
  const t=time*(opts.floatSpeed??1),a=opts.bobHeight??0,s=opts.floatSway??0.03,W=Math.PI*2;
  switch(style){
    case 'breath': {const p=(1-Math.cos(t*W/5.4))/2;return {x:0,y:1.4*a*(2*fsmooth(p)-1),roll:0};}
    case 'drift': {const x=.7*Math.sin(t*W/7)+.3*Math.sin(t*W/11),v=(.7/7*Math.cos(t*W/7)+.3/11*Math.cos(t*W/11))/(.7/7+.3/11);
      return {x:1.3*s*x,y:1.3*a*(.65*Math.sin(t*W/4.8)+.35*Math.sin(t*W/7.6)),roll:.45*v};}
    case 'orbit': return {x:1.25*s*Math.sin(t*W/5.2),y:1.2*a*Math.cos(t*W/5.2),roll:.45*Math.cos(t*W/5.2)};
    case 'levitate': return {x:0,y:1.8*a*fkeys(fcycle(t,6),LEVITATE),roll:0};
    case 'pendulum': {const q=Math.sin(t*W/4.4);return {x:2*s*q,y:1.5*a*(1.2*q*q-.6),roll:-.5*q};}
    case 'heartbeat': return {x:0,y:1.3*a*fkeys(fcycle(t,2.6),HEARTBEAT),roll:0};
    case 'wander': {
      // Lazy repositioning about her spot: three slow, unrelated drifts.
      const P=[9.7,5.3,3.1],K=[.55,.3,.15],ph=[0,1,2];let x=0,v=0;
      for(let i=0;i<3;i++){x+=K[i]*Math.sin(t*W/P[i]+ph[i]);v+=K[i]/P[i]*Math.cos(t*W/P[i]+ph[i]);}
      return {x:2.2*s*x,y:1.2*a*(.6*Math.sin(t*W/6.1)+.4*Math.sin(t*W/3.7+.5)),roll:.55*v/(.55/9.7+.3/5.3+.15/3.1)};
    }
    default:return {x:0,y:Math.sin(t*W/2.4)*a,roll:0};
  }
}
const TAU=Math.PI*2;
const cycle=(time,period)=>((time/period)%1+1)%1;
const wave=(time,period)=>Math.sin(cycle(time,period)*TAU);
const quintic=p=>p*p*p*(p*(p*6-15)+10);
// These plateaus are deliberate: Sentinel holds an altitude before a gentle
// correction; Surge gathers, rises and releases. Both remain C2 continuous.
const SENTINEL_LEVELS=[[0,-.3],[.16,-.3],[.31,.38],[.57,.38],[.76,-.3],[1,-.3]];
const SURGE_LEVELS=[[0,-.55],[.18,-.55],[.43,.9],[.59,.9],[.86,-.55],[1,-.55]];
function keyed(p,keys){
  for(let i=1;i<keys.length;i++)if(p<=keys[i][0]){
    const [a,v]=keys[i-1],[b,w]=keys[i];return v+(w-v)*quintic((p-a)/(b-a));
  }
  return keys.at(-1)[1];
}
function modeTrace(mode,t){
  switch(mode){
    case 'grounded':return {x:0,y:0,roll:0,pitch:0};
    case 'fly':return {x:wave(t,5.6),y:.8*wave(t,2.8),roll:.27*wave(t+1.4,5.6),pitch:.2*wave(t+.7,2.8)};
    case 'fast':return {x:.22*wave(t,1.8),y:.2*wave(t+.2,1.25),roll:.19+.075*wave(t+.45,1.8),pitch:-.65+.1*wave(t,1.25)};
    case 'glide':return {x:1.35*wave(t,10.5),y:.45*wave(t+2.625,10.5),roll:-.3*wave(t,10.5),pitch:-.12+.06*wave(t+2.625,10.5)};
    case 'surge':{
      const gather=keyed(cycle(t,3.7),SURGE_LEVELS);
      return {x:.26*wave(t,3.7),y:gather,roll:.22*wave(t+.45,3.7),pitch:-.28-.38*(gather+.55)/1.45};
    }
    case 'sentinel':return {x:.18*wave(t,8),y:1.5*keyed(cycle(t,6.4),SENTINEL_LEVELS),roll:.12*wave(t+2,8),pitch:.06*wave(t,6.4)};
    case 'wraith':return {x:1.65*wave(t,7.6),y:1.2*wave(t+1.9,3.8),roll:.4*wave(t+1.9,7.6),pitch:.32*wave(t,3.8)};
    default:return {x:0,y:wave(t,2.4),roll:0,pitch:0};
  }
}
/** Sample the SAME idle paths used by the token renderer and native preview.
 * Translation is in token sizes; roll in radians and pitch a scale fraction.
 * The selected floating style supplies its rhythm; mode motion supplies a
 * distinct path and posture. Strength zero restores the exact chosen style.
 * No phase is stored or restarted: interrupted modeWeights blend on the clock.
 */
export function sampleModeFloat(opts,time,profile=null,reduced=false){
  const floating=sampleFloat(opts,time,reduced),still=reduced||opts.floatStyle==='still';
  if(still)return {x:0,y:0,roll:0,pitch:0};
  const strength=Math.max(0,Math.min(2,opts.modeIdleStrength??1));
  const weights=profile?.modeWeights;
  const tiltR=(opts.tiltDegrees??0)*Math.PI/180;
  if(!strength||!weights)return {...floating,roll:(floating.roll??0)*tiltR,pitch:0};
  // The chosen path retains its full amplitude. Mode character is a bounded
  // secondary gesture, never a replacement or a second amplitude reduction.
  const bob=opts.bobHeight??0,sway=opts.floatSway??.03;
  const t=time*(opts.floatSpeed??1),trace={x:0,y:0,roll:0,pitch:0};let total=0,airborne=0;
  for(const [mode,weight] of Object.entries(weights))if(weight>0){
    total+=weight;if(mode!=='grounded')airborne+=weight;
    if(mode==='hover'||mode==='grounded')continue;
    const p=modeTrace(mode,t);
    for(const key of ['x','y','roll','pitch'])trace[key]+=p[key]*weight;
  }
  if(!total)return {...floating,roll:(floating.roll??0)*tiltR,pitch:0};
  const accent=.45*strength,tilt=(opts.tiltDegrees??0)*Math.PI/180;
  const motionGate=Math.min(1,Math.max(bob/DEFAULTS.bobHeight,sway/DEFAULTS.floatSway));
  return {
    x:floating.x*airborne+trace.x*sway*accent,
    y:floating.y*airborne+trace.y*bob*accent,
    roll:trace.roll*tilt*strength*motionGate+(floating.roll??0)*tilt*airborne,
    pitch:trace.pitch*.05*strength*Math.min(1,bob/DEFAULTS.bobHeight)
  };
}
export function smooth(current,target,dt,rate) {
  return current+(target-current)*(1-Math.exp(-rate*dt));
}
export function motion(s,{x,y,size,dt,time,on=true,reduced=false,forceBlend=null,
  flightFactor=1,flightActive,allowHover=true,allowBank=true,allowPitch=true,transitions=true,profile=null,movementEpoch=null}) {
  // A hitch (long frame) or a new movement epoch (teleport, elevation jump,
  // resume) is not travel: forget the last position, and on a new epoch the
  // velocity, but let the tilt ease out instead of snapping level.
  const hitch=!Number.isFinite(dt)||dt>.25||dt<0,epochChanged=movementEpoch!=null&&s.motionEpoch!==undefined&&s.motionEpoch!==movementEpoch;
  if(movementEpoch!=null)s.motionEpoch=movementEpoch;
  if(hitch||epochChanged){s.lastX=x;s.lastY=y;if(epochChanged)s.vx=s.vy=0;}
  if(!Number.isFinite(dt))dt=0;
  dt=Math.min(0.08,Math.max(0.001,dt));
  let dx=x-(s.lastX??x),dy=y-(s.lastY??y);
  s.lastX=x;s.lastY=y;
  // Teleports and an unfocused browser resuming are not movement banks.
  if(Math.hypot(dx,dy)>size*1.8)dx=dy=0;
  // A hitch has no usable displacement: hold the velocity for that frame.
  if(!hitch){const vx=dx/(size*dt),vy=dy/(size*dt);s.vx=smooth(s.vx??0,vx,dt,9);s.vy=smooth(s.vy??0,vy,dt,9);}else{s.vx??=0;s.vy??=0;}
  s.blend=forceBlend!=null?forceBlend:transitions?smooth(s.blend??0,on?1:0,dt,on?8:10):(on?1:0);
  const bank = reduced||!allowBank?0:Math.max(-1,Math.min(1,s.vx/3.5))*s.opts.tiltDegrees*Math.PI/180*(profile?.bank??1);
  s.rawBank=smooth(s.rawBank??s.bank??0,bank,dt,8);
  if(!allowBank||reduced)s.rawBank=0;
  // A subtle pitch/squash makes north/south movement visible as well.
  s.rawPitch=smooth(s.rawPitch??s.pitch??0,reduced||!allowPitch?0:Math.max(-1,Math.min(1,s.vy/4))*0.065*(profile?.pitch??1),dt,8);
  if(!allowPitch||reduced)s.rawPitch=0;
  const floating=sampleModeFloat(s.opts,time,profile,reduced),bob=floating.y;
  s.floatY=bob;
  // Resting gestures settle as actual travel takes over; movement banking and
  // pitch remain independently gated. This never changes token coordinates.
  const idle=allowHover?1/(1+Math.hypot(s.vx,s.vy)*.7):0;
  s.idleBank=allowBank?floating.roll*idle:0;s.idlePitch=allowPitch?floating.pitch*idle:0;
  s.flightFactor=forceBlend!=null?flightFactor:smooth(s.flightFactor??flightFactor,flightFactor,dt,8);
  // The wing envelope and token suspension are independent in v4. Calls that
  // omit flightActive retain the original combined deployment behavior.
  const motionBlend=flightActive===undefined?s.blend:1;
  s.motionBlend=motionBlend;
  s.lift=allowHover?-(s.opts.hoverHeight+bob)*size*motionBlend*s.flightFactor:0;
  s.swayX=allowHover?floating.x*size*motionBlend*s.flightFactor:0;
  s.bank=(s.rawBank+s.idleBank)*motionBlend*s.flightFactor;
  s.pitch=(s.rawPitch+s.idlePitch)*s.flightFactor;
  return s;
}

/** Apply visual motion only while PIXI/Foundry calculate transforms.
 * Local token values are always restored in finally, including on errors.
 * Both entry points are wrapped so render and canvas/occlusion bounds agree.
 *
 * Beta.36: the lifted pose stays in the transform's matrix between calls.
 * Writing her pose and then her own values back through PIXI's setters
 * marked the transform changed twice on every call, so each of the many
 * reads of her mesh in one frame (render, Foundry's canvas transform and
 * bounds, its occlusion tests) recomputed her bounds again, and Foundry,
 * seeing an occludable token's bounds change while she moved, asked for
 * another occlusion refresh each time: about forty a frame. Now her values
 * go back without a change notice, the matrix keeps her pose, and the
 * transform is marked changed only when her pose or Foundry's own values
 * really changed: at most once a frame. Her token's x, y, rotation and
 * scale still read as Foundry set them. */
let transforming=0;
/** True while her token's transform is being computed with her pose applied
 * (diagnostics: a perception request made then comes from her pose). */
export const inMotionTransform=()=>transforming>0;
export function installMotion(mesh,state) {
  const installed=[];let alive=true,depth=0;
  // PIXI v7 transform internals (ObservablePoint _x/_y, Transform _rotation,
  // _localID). Anything else keeps the earlier set-and-restore behaviour.
  const tr=mesh.transform;
  const quiet=!!(tr&&tr.position===mesh.position&&tr.scale===mesh.scale&&'_x' in tr.position&&'_y' in tr.position&&
    '_x' in tr.scale&&'_y' in tr.scale&&'_rotation' in tr&&Number.isFinite(tr._localID)&&typeof tr.updateSkew==='function');
  // The pose now in the matrix: the transform ID it was written at, Foundry's
  // values under it and the shown values.
  let shown=null;
  try {
    for(const name of ['updateTransform','updateCanvasTransform']) {
      const original=mesh[name];
      if(typeof original!=='function')continue;
      const own=Object.getOwnPropertyDescriptor(mesh,name);
      const wrapper=function(...args) {
        if(!alive||depth||this!==mesh)return original.apply(this,args);
        const x=this.x,y=this.y,rotation=this.rotation,sx=this.scale.x,sy=this.scale.y;
        // Flight feel: smaller with height, squashed on takeoff and landing.
        const k=state.altScale??1;
        const ex=x+(state.swayX??0),ey=y+state.lift,er=rotation+state.bank,
          esx=k!==1||state.squashX!==undefined?sx*k*(state.squashX??1):sx,
          esy=sy*k*(state.squashY??1)*(1+state.pitch*(state.motionBlend??state.blend));
        if(quiet){
          const s=shown;
          if(s&&s.id===tr._localID&&s.x===x&&s.y===y&&s.r===rotation&&s.sx===sx&&s.sy===sy&&
            s.ex===ex&&s.ey===ey&&s.er===er&&s.esx===esx&&s.esy===esy){
            depth++;transforming++;try{return original.apply(this,args);}finally{depth--;transforming--;}
          }
          depth++;transforming++;
          try {
            const id=tr._localID;
            this.x=ex;this.y=ey;
            if(this.rotation!==er)this.rotation=er;else if(s&&s.er!==er)tr.updateSkew();
            this.scale.x=esx;this.scale.y=esy;
            // (Shown values equal to Foundry's own: no setter fired, yet the
            // matrix still holds the previous pose.)
            if(tr._localID===id&&s)tr._localID++;
            return original.apply(this,args);
          } finally {
            tr.position._x=x;tr.position._y=y;tr._rotation=rotation;tr.scale._x=sx;tr.scale._y=sy;
            shown={id:tr._localID,x,y,r:rotation,sx,sy,ex,ey,er,esx,esy};
            depth--;transforming--;
          }
        }
        depth++;transforming++;
        try {
          this.x=ex;this.y=ey;this.rotation=er;
          if(k!==1||state.squashX!==undefined)this.scale.x=esx;
          this.scale.y=esy;
          return original.apply(this,args);
        } finally {
          this.x=x;this.y=y;this.rotation=rotation;this.scale.x=sx;this.scale.y=sy;depth--;transforming--;
        }
      };
      Object.defineProperty(mesh,name,{value:wrapper,writable:true,configurable:true});
      installed.push({name,own,wrapper});
    }
    if(!installed.length)throw new Error('No supported token transform methods.');
  } catch(error) {
    alive=false;
    for(const {name,own} of installed) {
      if(own)Object.defineProperty(mesh,name,own);else delete mesh[name];
    }
    throw error;
  }
  return ()=>{
    alive=false;
    // The matrix still shows her last pose: have PIXI rebuild it from
    // Foundry's own values on the next transform update.
    if(quiet&&shown&&!mesh.destroyed)try{tr.updateSkew();}catch{}
    shown=null;
    for(const {name,own,wrapper} of installed) {
      // Preserve wrappers installed by another module after this one.
      if(mesh[name]!==wrapper)continue;
      if(own)Object.defineProperty(mesh,name,own);else delete mesh[name];
    }
  };
}
