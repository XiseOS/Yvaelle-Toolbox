/** Bruised light (v10 beta.26): a hit knocks the light out of the wing facing
 * the blow, where it was struck, and the light flows back in from her root
 * over a few seconds, with a brighter front where it returns.
 *
 * The flight feel says where and how much (out.bruise: directions in her own
 * frame, fixed at the moment of the blow; spot sizes in wing-frame widths, see
 * bruiseAmount); this turns that into spots and paints them over a finished
 * wing layer: the filaments under a spot fade (they are not darkened, the
 * light simply goes out of them), then a band of light lies along the edge of
 * the spot nearest her root as that edge recedes outward. Pure 2D canvas work
 * on the layer's own surface; the renderer keeps an unbruised copy of each
 * layer while a bruise lasts, so nothing compounds. */

/** The feel's bruise records → spots in her wing frame (u,v: offsets from
 * her body centre in wing-frame widths; r likewise). */
export function bruiseSpots(list){
  if(!list?.length)return null;
  const out=[];
  for(const b of list){
    const reach=b.reach??.3;
    out.push({u:(b.lx??0)*reach,v:(b.ly??0)*reach,r:b.r,amount:b.amount,front:b.front});
  }
  return out;
}
/** A key that changes only when the spots visibly change. */
export function bruiseKey(spots){
  if(!spots?.length)return '';
  let key='';
  for(const p of spots)key+=`${Math.round(p.u*200)},${Math.round(p.v*200)},${Math.round(p.r*400)},${Math.round(p.amount*50)},${Math.round(p.front*20)};`;
  return key;
}
/** Paint the spots over a layer's surface. `size`: the full wing frame in
 * pixels; `viewport`: the layer's crop of that frame ({x,y}), if any. */
export function paintBruise(ctx,spots,size,viewport=null){
  if(!spots?.length)return;
  const ox=viewport?.x??0,oy=viewport?.y??0;
  ctx.save();
  ctx.globalAlpha=1;
  // The light goes out of the filaments under each spot.
  ctx.globalCompositeOperation='destination-out';
  for(const p of spots){
    if(!(p.r>0)||!(p.amount>0))continue;
    const x=size/2+p.u*size-ox,y=size/2+p.v*size-oy,R=Math.max(1,p.r*size);
    const g=ctx.createRadialGradient(x,y,0,x,y,R);
    g.addColorStop(0,`rgba(0,0,0,${.9*p.amount})`);g.addColorStop(.75,`rgba(0,0,0,${.8*p.amount})`);g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g;ctx.fillRect(x-R,y-R,R*2,R*2);
  }
  // Where it is coming back, the filaments along the spot's edge nearest her
  // root shine: a crescent, thickest toward her body and thinning to nothing
  // at the far edge (two circles touching there).
  ctx.globalCompositeOperation='source-atop';
  for(const p of spots){
    const R=p.r*size;if(!(p.front>.01)||R<6)continue;
    const x=size/2+p.u*size-ox,y=size/2+p.v*size-oy,band=Math.max(4,size*.03);
    const d=Math.hypot(p.u,p.v),dx=d>1e-6?p.u/d:1,dy=d>1e-6?p.v/d:0,Ro=R+band*.5,shift=Math.min(band*1.2,Ro*.45);
    const g=ctx.createRadialGradient(x+dx*shift,y+dy*shift,Ro-shift,x,y,Ro);
    g.addColorStop(0,'rgba(255,214,246,0)');g.addColorStop(.55,`rgba(255,226,250,${p.front})`);g.addColorStop(1,'rgba(255,214,246,0)');
    ctx.fillStyle=g;ctx.fillRect(x-Ro,y-Ro,Ro*2,Ro*2);
  }
  ctx.restore();
}
