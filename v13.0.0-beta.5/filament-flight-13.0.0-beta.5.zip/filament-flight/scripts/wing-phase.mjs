const TAU=Math.PI*2,LOOP_MS=2400;
const wrap=turns=>((turns%1)+1)%1;

/** One bounded local clock shared by the atlas, posed wings and trail anchors.
 * Restore from the saved phase once; thereafter speed changes alter frequency,
 * not the phase of all elapsed flight time. No timers or document writes. */
export function wingPhase(state,snapshot,config,now) {
  const enabled=!config.reduced&&!!config.wingbeats;
  // Flight feel scales the beat rate with effort (harder climbs, held glides).
  const speed=(Number.isFinite(state.opts?.wingSpeed)?state.opts.wingSpeed:1)*(Number.isFinite(state.feelRate)?state.feelRate:1);
  const started=snapshot.started;
  let clock=state.wingClock;
  // The manager retains this clock while a visible wing field retracts. A
  // reversal is a new deployment command, not a new beat. Once the wings have
  // actually disappeared, a subsequent activation may start a fresh clock.
  const wingsActive=snapshot.rendering?.wingsActive!==false;
  const continueVisible=clock&&clock.started!==started&&clock.wingsActive!==false&&wingsActive;
  if(!clock||clock.started!==started&&!continueVisible){
    clock=state.wingClock={started,at:now,speed,enabled,
      turns:enabled?wrap((now-started)*speed/LOOP_MS):0,wingsActive};
  }else {
    const elapsed=now-clock.at;
    // A paused/hidden browser resumes its last local phase instead of taking
    // an enormous integration step. Wingbeats re-enabled from a still pose
    // begin at that same held pose.
    if(!enabled)clock.turns=0;
    else if(clock.enabled&&elapsed>0&&elapsed<=250)
      clock.turns=wrap(clock.turns+elapsed*(clock.speed+speed)/2/LOOP_MS);
    clock.at=now;clock.speed=speed;clock.enabled=enabled;clock.started=started;clock.wingsActive=wingsActive;
  }
  return enabled?clock.turns*TAU:0;
}
