/** Flight characters (v10 beta.24): what each flight mode means for how
 * she moves. The classic look is the base (a float, and a slight tilt toward
 * the way she moves); the mode sets its character:
 *
 *   lean       (kept at 1: the tilt follows the mode's classic bank share)
 *   omega      how lively her body is (rad/s): high gets up to speed and
 *              stops quickly, low builds slowly and coasts on
 *   zeta       how much she swings past a stop and comes back (1 settles
 *              without swinging past; lower swings further, never wobbles)
 *   tether     how far (in token sizes) her body may swing from the token
 *   dip        how much her weight settles when she stops
 *   beat       how fast her wings beat;  glide: how readily they hold on long flights
 *   bitLoose   how loosely her bits follow
 *   height     her height in this mode, as a share of her chosen flying height
 *              (Hover and Fly at it, Fast higher, Glide highest, Sentinel lower,
 *              Wraith skimming low)
 *   hum        the pitch of her energy hum (and how it lifts with speed)
 *   bankRoll, flare, raise, whip  how much the wing manoeuvres show: rolling
 *              into curves, flaring at a stop, rising in a descent, swinging round
 *
 * beta.29: Foundry moves her token at the same speed in every mode, so the
 * mode's character has to come from how she follows it, not how fast it goes:
 *   omegaStop  how lively she is once the token slows (omega is for setting
 *              off): Fast is quick off the mark but slides far; Surge snaps
 *              back from a springy stop; Sentinel brakes harder than she starts
 *   kvGo       how closely she keeps pace while travelling (below 1 she trails
 *              her token: Glide builds slowly, Wraith drifts behind)
 *   burst      a leap ahead as she sets off (token sizes): Surge, a touch for Fast
 *   weave      a sinuous side-to-side drift while she travels (Wraith)
 *   leanMul    how hard she leans into the move (on top of the classic share)
 *   glideAfter seconds of cruising before the wings ease into a glide
 *   hold, holdRest, holdEvery, holdEveryRest  the wings held wide open between
 *              single beats (Glide), while cruising and at rest, and how often
 *              a beat comes
 *   stopFlare, stopRaise  the wings brake at a stop: flare forward / rise
 *   post       her bits posted a little wider while she holds (Sentinel)
 *   phase, echo, streak, burstFx, rebound  restrained mode effects: Wraith's
 *              wings phase while she travels and an echo of her carries on
 *              past a stop; Fast leaves a short streak of afterimages at speed;
 *              Surge throws a burst of filament as she sets off and a braking
 *              flare when she rebounds from a stop
 *   restW, restH, moveW, moveH  her wing silhouette at rest and travelling
 *              (width and height of the wings): Hover small, Glide flat and
 *              fully spread, Fast a narrow lance, Wraith thin and tall
 *   restRaise, moveRaise  wings half-raised like a guard (Sentinel)
 *   restFlare, moveFlare  wings held partly flared, taut and coiled (Surge)
 *   alpha      how solid the wings are (Wraith thin and translucent)
 *   sway       a slow side-to-side sway at rest (Glide)
 *   pulse      a gather, lift and release at rest, every few seconds (Surge)
 *
 * Pure data and pure functions: the game and the preview recorder share them.
 * During a mode change the numbers blend by the existing mode weights. */

const clamp=(v,a,b)=>v<a?a:v>b?b:v;

// bankRoll, flare, raise and whip are the mode's share of the wing manoeuvres
// (rolling into curves, flaring at a stop, rising in a descent, swinging round).
const base={lean:1,tether:1,omega:7,zeta:.62,dip:.5,beat:1,glide:.6,bitLoose:1,height:1,hum:1,humLift:.035,stopSound:1,
  bankRoll:1,flare:1,raise:1,whip:1,
  omegaStop:7,kvGo:1,burst:0,weave:0,leanMul:1,glideAfter:1.2,hold:0,holdRest:0,holdEvery:2.4,holdEveryRest:1.8,stopFlare:0,stopRaise:0,post:1,
  phase:0,echo:0,streak:0,burstFx:0,rebound:0,
  restW:1,restH:1,moveW:1,moveH:1,restRaise:0,moveRaise:0,restFlare:0,moveFlare:0,alpha:1,sway:0,pulse:0};
const character=(label,stop,patch)=>Object.freeze({label,stop,...base,omegaStop:patch.omega??base.omega,...patch});

export const FLIGHT_CHARACTERS=Object.freeze({
  grounded:character('Grounded','—',{omega:14,zeta:1,tether:.3,dip:.1,glide:0,height:0,stopSound:0}),
  // Gentle and close: keeps right with her token, eases to a stop without
  // passing it and settles with a soft dip.
  hover:character('Hover','Stays close, eases in and settles softly',{omega:9,omegaStop:10,zeta:1,kvGo:.93,tether:.6,leanMul:.8,bankRoll:.8,flare:.8,dip:.55,glide:.2,beat:1.75,height:.6,restW:.8,restH:.8,moveW:.82,moveH:.82}),
  // The everyday flight: a little momentum, a short slide past and back.
  fly:character('Fly','Slides a little past, leans back and settles',{omega:7,omegaStop:6.2,zeta:.6,tether:1.05}),
  // Quick off the mark, a hard lean, then slides well past and swings back.
  fast:character('Fast Flight','Quick off the mark, hard lean, slides well past and swings back',{omega:9.5,omegaStop:3.3,zeta:.44,tether:1.65,burst:.22,leanMul:1.65,bankRoll:1.2,flare:1.3,whip:1.1,dip:.6,glide:.3,bitLoose:1.3,height:4/3,hum:1.06,humLift:.05,stopSound:1.2,stopFlare:.25,streak:1,beat:1.45,restW:.86,restH:1.08,moveW:.7,moveH:1.08}),
  // Slow to build, wings held wide with few beats, a long coast and a wide arc.
  glide:character('Glide','Slow to build, coasts a long way on held wings and rises to a stop',{omega:3.3,omegaStop:2.5,zeta:.88,kvGo:.93,tether:1.3,leanMul:.85,bankRoll:1.35,flare:.6,raise:1.25,dip:.3,beat:1.1,glide:1,glideAfter:.35,hold:1,holdRest:1,holdEvery:2.6,holdEveryRest:2.6,bitLoose:1.4,height:2,hum:.94,humLift:.025,stopSound:.7,stopRaise:.55,restW:1.2,restH:.82,moveW:1.26,moveH:.78,sway:.05}),
  // Bursts ahead of her token, then a springy stop: past, back and settle.
  surge:character('Surge','Bursts ahead, then rebounds from a springy stop',{omega:13,omegaStop:7.2,zeta:.3,tether:1.3,burst:.55,leanMul:1.35,bankRoll:1,flare:1.25,whip:1.2,dip:1,beat:1,glide:.1,bitLoose:1.2,height:1,hum:1.03,humLift:.05,stopSound:1.3,stopFlare:.6,burstFx:1,rebound:1,pulse:1,restFlare:.6,moveFlare:.35,moveW:.86,moveH:1.04}),
  // Planted: brakes harder than she starts, stops short and holds still.
  sentinel:character('Sentinel','Brakes hard, stops short and holds, bits posted',{omega:11,omegaStop:14,zeta:1,kvGo:.8,tether:.6,leanMul:.8,bankRoll:.5,flare:1.1,raise:.7,whip:.6,dip:.25,beat:.7,glide:.2,bitLoose:.55,height:2/3,hum:.97,humLift:.02,stopSound:.9,stopFlare:.35,post:1.12,restRaise:.95,moveRaise:.6,restW:.86,restH:1.1,moveW:.86,moveH:1.06}),
  // Drifts behind her token on a sinuous path and eases in; an echo of her
  // carries on past the stop and fades.
  wraith:character('Wraith','Drifts behind on a sinuous path, eases in; her echo carries on',{omega:4.2,omegaStop:4.4,zeta:.93,kvGo:.85,tether:1.3,weave:.075,bankRoll:1.2,flare:.5,raise:1.3,whip:1.35,dip:.2,beat:.75,glide:.5,bitLoose:1.5,height:1/3,hum:.98,humLift:.03,stopSound:.6,phase:1,echo:1,alpha:.66,restW:.74,restH:1.14,moveW:.7,moveH:1.18})
});
const NUMERIC=Object.keys(base).filter(k=>typeof base[k]==='number');

/** One character blended by mode weights ({hover:.3, fly:.7, ...}). Discrete
 * choices (poses, stop effect) come from the strongest mode. */
const cache=new Map();
export function blendCharacter(weights,mode='hover'){
  if(!weights)return FLIGHT_CHARACTERS[mode]??FLIGHT_CHARACTERS.hover;
  let key='',top=null,best=-1;
  for(const k in weights){const w=weights[k];if(w>.001){key+=`${k}${Math.round(w*50)}|`;if(w>best){best=w;top=k;}}}
  if(!top)return FLIGHT_CHARACTERS[mode]??FLIGHT_CHARACTERS.hover;
  if(best>.999)return FLIGHT_CHARACTERS[top]??FLIGHT_CHARACTERS.hover;
  let out=cache.get(key);if(out)return out;
  out={...(FLIGHT_CHARACTERS[top]??FLIGHT_CHARACTERS.hover)};let total=0;
  for(const k of NUMERIC)out[k]=0;
  for(const m in weights){const w=weights[m],c=FLIGHT_CHARACTERS[m];if(!c||!(w>0))continue;total+=w;for(const k of NUMERIC)out[k]+=c[k]*w;}
  if(total>0)for(const k of NUMERIC)out[k]/=total;
  if(cache.size>128)cache.clear();cache.set(key,Object.freeze(out));return out;
}

/** Her flying height for a mode: the chosen height times the mode's share
 * (rounded to whole feet; never below 1 ft while airborne). */
export const HEIGHT_LIMIT=120;
export function modeAltitude(altitude,mode){
  const h=(FLIGHT_CHARACTERS[mode]??FLIGHT_CHARACTERS.fly).height;
  if(!(altitude>0)||!(h>0))return 0;
  return Math.min(HEIGHT_LIMIT,Math.max(1,Math.round(altitude*h)));
}
/** The highest she can fly in a mode (the chosen height tops out at 120 ft). */
export function modeCeiling(mode){return modeAltitude(HEIGHT_LIMIT,mode)||HEIGHT_LIMIT;}
/** The chosen (base) height that gives `feet` in `mode`. */
export function baseAltitude(feet,mode){
  const h=(FLIGHT_CHARACTERS[mode]??FLIGHT_CHARACTERS.fly).height;
  return h>0?Math.min(HEIGHT_LIMIT,Math.round(feet/h)):feet;
}

/* ------------------------------------------------------------ hover patterns
 * The floating styles are her hover animations. Each one is a whole way of
 * holding herself up, not only a path: it decides how much each wingbeat
 * lifts her, how her wingbeat paces, whether her wings breathe wider, and
 * whether she leans with the drift. The path itself (x, y and roll) is
 * sampled by sampleFloat in motion.mjs; this adds the wing side. */
export const HOVER_PATTERNS=Object.freeze({
  hover:{label:'Classic hover',hint:'Each downstroke lifts her; a steady rise and fall.',strokeBob:1,rate:1},
  breath:{label:'Breathing suspension',hint:'A slow inhale lifts her and opens the wings; the exhale lets her sink.',strokeBob:.3,rate:.9},
  drift:{label:'Astral drift',hint:'A dreamy wandering drift; she leans the way she drifts.',strokeBob:.35,rate:.85},
  orbit:{label:'Resonant orbit',hint:'She circles a small orbit, banking around it.',strokeBob:.4,rate:.9},
  levitate:{label:'Rise and settle',hint:'She rises on quick strokes, hangs with the wings held, then settles with a little bounce.',strokeBob:.5,rate:1},
  pendulum:{label:'Pendulum sway',hint:'She swings side to side in a shallow arc, tilting with the swing.',strokeBob:.3,rate:.9},
  heartbeat:{label:'Heartbeat lift',hint:'Two quick wingbeats lift her, then a long, slow sink.',strokeBob:.25,rate:1},
  wander:{label:'Wander',hint:'She lazily drifts about her spot, leaning into each little repositioning.',strokeBob:.3,rate:.9},
  still:{label:'Still suspension',hint:'Rock steady; only the wings move.',strokeBob:0,rate:.9}
});
const cyc=(t,p)=>((t/p)%1+1)%1;
const smooth=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
/** The wing side of a hover pattern at time t (seconds, already scaled by the
 * floating speed): wing width, wingbeat pace and stroke lift. */
export function sampleHoverWings(style,t,out=null){
  const p=HOVER_PATTERNS[style]??HOVER_PATTERNS.hover;
  let width=1,rate=p.rate;
  if(style==='breath'){const q=(1-Math.cos(t*Math.PI*2/5.4))/2;width=1+.07*q;rate*=.75+.5*Math.max(0,Math.sin(t*Math.PI*2/5.4));}
  else if(style==='levitate'){const q=cyc(t,6);rate*=q<.4?1.3:q<.62?.5:.85;width=q>=.4&&q<.62?1.04:1;}
  else if(style==='heartbeat'){const q=cyc(t,2.6);rate*=q<.32?1.9:.55;}
  else if(style==='still')width=1+.02*Math.sin(t*Math.PI*2/4);
  // (A caller sampling every frame may pass an object to fill.)
  if(out){out.width=width;out.rate=rate;out.strokeBob=p.strokeBob;return out;}
  return {width,rate,strokeBob:p.strokeBob};
}
export {smooth as hoverSmooth};
