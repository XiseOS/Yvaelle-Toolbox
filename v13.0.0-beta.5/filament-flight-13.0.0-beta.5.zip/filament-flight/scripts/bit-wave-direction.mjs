/** Quiet intent cues for detached instruments' existing stabilization fans.
 * Angles describe full two-dimensional bearings in the owner's token frame,
 * never a restricted upward cone or a spinning housing's temporary frame.
 * The caller retains at most one tiny sample per visible instrument. There is
 * no clock, document state, socket message or rendering dependency here. */
export const BIT_WAVE_MAX_ANGLE=Math.PI; // Normalized angle representation; no directional cone.
export const BIT_WAVE_MAX_RATE=12*Math.PI/180; // 12 degrees per second, eased.
export const BIT_WAVE_RESPONSE=1.2; // seconds, first-order response.
export const BIT_WAVE_STATIONS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);

const liveMemories=new WeakMap();
/** Home and action routes share physical instrument history. Hiding a home
 * instrument while it works elsewhere must not restart its fan's bearing.
 * Leases keep teardown independent; the last renderer releases all samples. */
export function acquireBitWaveDirections(owner){
  let record=liveMemories.get(owner);
  if(!record){record={memory:new Map(),leases:0};liveMemories.set(owner,record);}
  record.leases++;let released=false;
  return {memory:record.memory,release(){
    if(released)return;released=true;
    if(--record.leases===0){record.memory.clear();liveMemories.delete(owner);}
  }};
}

const finite=(n,fallback=0)=>Number.isFinite(Number(n))?Number(n):fallback;
const unit=n=>Math.max(0,Math.min(1,finite(n)));
const point=(p,fallback=[0,0])=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1])?p:fallback;
const wrap=angle=>Math.atan2(Math.sin(angle),Math.cos(angle));
const bearing=(from,to)=>{if(!to)return null;const x=to[0]-from[0],y=to[1]-from[1];return Math.hypot(x,y)>1e-6?Math.atan2(x,-y):null;};

/** Each instrument faces its own valid work point or active partner. Idle
 * instruments face their charge from their actual position, so their fans
 * naturally differ. Coincident focus falls back to charge, then a known stable
 * bearing; no zero-length vector can suddenly flip an established direction. */
export function bitWaveIntentAngle({position=[0,0],intent=null,charge=[0,15],target=null,focus=null,previous=null}={}){
  const from=point(position),home=point(charge,null),active=unit(intent?.amount)>.001?intent?.target:null;
  return bearing(from,focus?.kind==='lantern'?point(focus.target,null):null)??bearing(from,point(target,null))??bearing(from,point(active,null))??bearing(from,point(focus?.target??focus,null))??bearing(from,home)??(Number.isFinite(previous?.angle)?wrap(previous.angle):0);
}

/** Pure, rate-limited step. Unobserved gaps consume at most 250ms: returning
 * to a hidden canvas catches up gently instead of replaying missed motion.
 * Paused time freezes exactly; a stateless/backward sample starts at its cue.
 * First appearance/replay starts at the appropriate actual bearing. Reduced
 * motion and disabled animation hold each instrument's existing bearing. */
export function sampleBitWaveDirection(options={}){
  const time=finite(options.now),previous=options.previous;
  const continuing=previous&&Number.isFinite(previous.angle)&&Number.isFinite(previous.time)&&time>=previous.time;
  const desired=bitWaveIntentAngle({...options,previous:continuing?previous:null});
  let angle=desired;
  if(continuing&&(options.reduced||options.animated===false))angle=previous.angle;
  else if(continuing){
    const elapsed=Math.min(.25,Math.max(0,(time-previous.time)/1000));
    const from=previous.angle,delta=wrap(desired-from);
    const change=delta*(1-Math.exp(-elapsed/BIT_WAVE_RESPONSE)),limit=BIT_WAVE_MAX_RATE*elapsed;
    angle=elapsed===0?from:wrap(from+Math.max(-limit,Math.min(limit,change)));
  }
  return {angle,time,direction:[Math.sin(angle),-Math.cos(angle)]};
}

/** Renderer-owned maps use stable station identities, never event IDs. */
export function updateBitWaveDirection(memory,id,options={}){
  const stored=memory?.get(id),previous=stored&&finite(options.now)>=stored.time?stored:null;
  const sample=sampleBitWaveDirection({...options,previous});
  memory?.set(id,sample);return sample;
}

export function retainBitWaveDirections(memory,ids){
  if(!memory)return;const present=new Set(ids);
  for(const id of memory.keys())if(!present.has(id))memory.delete(id);
}

/** Apply the same physical fan controller at the last shared painter boundary.
 * Wing contours keep their existing currents; only the housing's local fan
 * faces attention. Worker and synchronous frames use the owner's same memory.
 * Focus metadata never changes positions, tools, currents or activity energy. */
export function applyBitWaveDirections(bits,memory,snapshot,now){
  for(const bit of bits.values()){
    const part=bit.part,h=part.hardware;
    if(!h?.glow||h.glowMode!=='field'||!(h.glow.strength>0))continue;
    const station=bit.station??`${bit.left?'left':'right'}${part.id==='gem-0'?'Upper':'Lower'}`;
    const wave=updateBitWaveDirection(memory,station,{position:part.points[0],intent:h.intent,focus:h.focus,
      target:h.focus?.kind==='lantern'?h.focus.target:snapshot.intentTarget??h.workTarget,now,animated:snapshot.gems?.animated,
      reduced:!!snapshot.effective?.reducedMotion});
    part.hardware={...h,glow:{...h.glow,direction:wave.direction}};
  }
  retainBitWaveDirections(memory,BIT_WAVE_STATIONS);return bits;
}

/** Undo an action's temporary housing rotation before its renderer reapplies
 * it. The wave keeps its own focus bearing while a flourish may roll. */
export function rotateBitWaveDirection(direction,angle=0){
  const c=Math.cos(angle),s=Math.sin(angle),[x,y]=direction;
  return [x*c-y*s,x*s+y*c];
}

/** Detached action positions/intents are world points. The caller supplies the
 * same owner/source frame throughout travel, work and return; recipient rotation
 * affects target coordinates without rebasing the fan. Undo temporary placement so
 * a rolling housing cannot sweep the fan. Whole owner rotation stays natural.
 * The hardware painter already handles its own local shell angle. */
export function updateWorldBitWaveDirection(memory,id,{position,charge,intent=null,focus=null,target=null,frameAngle=0,placementAngle=frameAngle,...options}={}){
  const local=p=>{const x=p?.x??p?.[0],y=p?.y??p?.[1];return Number.isFinite(x)&&Number.isFinite(y)?rotateBitWaveDirection([x-finite(position?.x),y-finite(position?.y)],-frameAngle):null;};
  const goal=target?local(target):null,home=local(charge);
  const localIntent=intent?.target?{...intent,target:local(intent.target)}:null,localFocus=focus?.target?{...focus,target:local(focus.target)}:null;
  const sample=updateBitWaveDirection(memory,id,{...options,position:[0,0],charge:home,intent:localIntent,focus:localFocus,target:goal});
  return {...sample,direction:rotateBitWaveDirection(sample.direction,frameAngle-placementAngle)};
}
