/** Actual native four-cell blocks. Geometry comes from the square/hex scene
 * polygons; no cosmetic rectangle is substituted for a missing native cell. */
const indexes=new WeakMap(),vertexCache=new WeakMap(),sharedIndexes=[];
const SHARED_INDEX_LIMIT=12;
/** Polygon vertices rounded to 1e-5 px, as integers, once per cell. */
function roundedVertices(cell){
  let v=vertexCache.get(cell);if(v)return v;
  const polygon=cell.polygon??[];v=new Float64Array(polygon.length*2);
  for(let i=0;i<polygon.length;i++){v[i*2]=Math.round(polygon[i].x*1e5);v[i*2+1]=Math.round(polygon[i].y*1e5);}
  vertexCache.set(cell,v);return v;
}
/** Two cells are adjacent when they share an undirected polygon edge (both
 * rounded endpoints). Numeric comparison; no per-edge string keys. */
function adjacent(a,b){
  const x=roundedVertices(a),y=roundedVertices(b),n=x.length>>1,m=y.length>>1;
  for(let i=0;i<n;i++){
    const k=((i+1)%n)*2,ax=x[i*2],ay=x[i*2+1],bx=x[k],by=x[k+1];
    for(let j=0;j<m;j++){
      const l=((j+1)%m)*2,cx=y[j*2],cy=y[j*2+1],dx=y[l],dy=y[l+1];
      if(ax===cx&&ay===cy&&bx===dx&&by===dy||ax===dx&&ay===dy&&bx===cx&&by===cy)return true;
    }
  }
  return false;
}
const rowKey=cell=>Number.isFinite(cell.offset?.i)?cell.offset.i:cell.center.y;
const columnKey=cell=>Number.isFinite(cell.offset?.j)?cell.offset.j:cell.center.x;
export function cooperativeBlockIndex(cells){
 let index=indexes.get(cells);if(index)return index;
 // Fractional owner movement produces fresh native roster arrays even when
 // their exact ordered cell objects are unchanged. Reuse only that identical
 // geometry; a changed native cell, shape, or scene cannot hit this cache.
 for(let i=sharedIndexes.length-1;i>=0;i--){
  const entry=sharedIndexes[i];if(entry.cells.length!==cells.length||entry.cells[0]!==cells[0]||entry.cells.at(-1)!==cells.at(-1))continue;
  if(!entry.cells.every((cell,j)=>cell===cells[j]))continue;
  index=entry.index;indexes.set(cells,index);sharedIndexes.splice(i,1);sharedIndexes.push(entry);return index;
 }
 const sourceRows=new Map();for(const cell of cells){const key=rowKey(cell),row=sourceRows.get(key)??[];row.push(cell);sourceRows.set(key,row);}
 const rows=[...sourceRows.entries()].sort((a,b)=>a[0]-b[0]).map(([key,cells])=>({key,cells:cells.sort((a,b)=>a.center.x-b.center.x),columns:new Map(cells.map(cell=>[columnKey(cell),cell]))})),candidates=[],byCell=new Map(),blockRows=[];
 for(let r=0;r<rows.length-1;r++){
  const top=rows[r],bottom=rows[r+1],blocks=[];
  for(let j=0;j<top.cells.length-1;j++){
   const a=top.cells[j],b=top.cells[j+1],c=bottom.columns.get(columnKey(b)),d=bottom.columns.get(columnKey(a));if(!c||!d||!adjacent(a,b)||!adjacent(b,c)||!adjacent(c,d)||!adjacent(d,a))continue;
   // Clockwise ordering preserves connected pairs and L-shaped trios when a
   // borrowed instrument shortens the four-cell exposure.
   const group=[a,b,c,d],block={cells:group,x:group.reduce((sum,c)=>sum+c.center.x,0)/4,y:group.reduce((sum,c)=>sum+c.center.y,0)/4};candidates.push(block);blocks.push(block);
   for(const cell of group){const list=byCell.get(cell.id)??[];list.push(block);byCell.set(cell.id,list);}
  }
  if(blocks.length){blocks.sort((a,b)=>a.x-b.x);const ys=blocks.map(block=>block.y),minY=Math.min(...ys),maxY=Math.max(...ys);blockRows.push({blocks,minY,maxY,y:(minY+maxY)/2});}
 }
 blockRows.sort((a,b)=>a.y-b.y);index={candidates,byCell,rows:blockRows,maxDeviation:Math.max(0,...blockRows.map(row=>(row.maxY-row.minY)/2))};indexes.set(cells,index);if(sharedIndexes.length>=SHARED_INDEX_LIMIT)sharedIndexes.shift();sharedIndexes.push({cells,index});return index;
}
export function prefersCooperativeBlock(seed,ordinal=0){if(ordinal===0)return !!((Number(seed)||0)&1);let n=(Number(seed)||0)^Math.imul(ordinal+1,0x9e3779b1);n=Math.imul(n^n>>>16,0x45d9f3b);return !!((n^n>>>16)&1);}
/** Exact nearest-block lookup with row/column lower bounds. Large following
 * fields touch nearby indexed candidates, not every cell on every frame. */
export function nearestCooperativeBlock(index,target,used=new Set()){
 const {rows,maxDeviation}=index;let lo=0,hi=rows.length;while(lo<hi){const mid=(lo+hi)>>1;if(rows[mid].y<target.y)lo=mid+1;else hi=mid;}
 let above=lo-1,below=lo,best=Infinity,chosen=null;
 const rowBound=i=>i<0||i>=rows.length?Infinity:Math.max(0,Math.abs(rows[i].y-target.y)-maxDeviation)**2;
 while(above>=0||below<rows.length){
  const a=rowBound(above),b=rowBound(below);if(Math.min(a,b)>best)break;const row=a<=b?rows[above--]:rows[below++],dy=Math.max(0,row.minY-target.y,target.y-row.maxY);if(dy*dy>best)continue;
  const blocks=row.blocks;let lo=0,hi=blocks.length;while(lo<hi){const mid=(lo+hi)>>1;if(blocks[mid].x<target.x)lo=mid+1;else hi=mid;}let left=lo-1,right=lo;
  const columnBound=i=>i<0||i>=blocks.length?Infinity:(blocks[i].x-target.x)**2+dy*dy;
  while(left>=0||right<blocks.length){const a=columnBound(left),b=columnBound(right);if(Math.min(a,b)>best)break;const block=a<=b?blocks[left--]:blocks[right++];if(block.cells.some(cell=>used.has(cell.id)))continue;const distance=(block.x-target.x)**2+(block.y-target.y)**2;if(distance<best){best=distance;chosen=block.cells;}}
 }
 return chosen;
}
