/** One small, persisted world-space resting pose per instrument. Randomness is
 * seeded by the shared episode ID, never by a frame or a viewer. */
const finite=Number.isFinite;
const unit=x=>Math.max(0,Math.min(1,x));
const ease=x=>{x=unit(x);return x*x*(3-2*x);};
const mix=(a,b,t)=>a+(b-a)*t;
const angleMix=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
function random(seed){let h=2166136261;for(const c of seed)h=Math.imul(h^c.charCodeAt(0),16777619);return()=>{h+=0x6D2B79F5;let t=h;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
export function makeBitRestPoses(id,bits,captured={}){
  const out={},scale=finite(captured.scale)&&captured.scale>0?captured.scale:100,k=scale/100;
  for(const bit of bits){
    const p=captured.originsWorld?.[bit];if(!finite(p?.x)||!finite(p?.y))continue;
    const r=random(`${id}:${bit}`),side=r()<.5?-1:1;
    out[bit]={x:p.x+(r()-.5)*32*k,y:p.y+(26+r()*28)*k,angle:side*(.65+r()*.9),
      startAngle:finite(captured.originAngles?.[bit])?captured.originAngles[bit]:0,
      scale:finite(captured.originScales?.[bit])&&captured.originScales[bit]>0?captured.originScales[bit]:scale*3.5/600,
      delay:Math.round(r()*140),duration:Math.round(600+r()*190),arc:(5+r()*8)*k,sway:(r()-.5)*18*k};
  }
  return out;
}
export function readBitRestPoses(raw,bits){
  const out={};for(const bit of bits){const p=raw?.[bit];if(!p||!['x','y','angle','startAngle','scale','delay','duration','arc','sway'].every(k=>finite(p[k])))continue;
    if(p.scale<=0||p.scale>100||p.delay<0||p.delay>200||p.duration<100||p.duration>950)continue;
    out[bit]=Object.fromEntries(['x','y','angle','startAngle','scale','delay','duration','arc','sway'].map(k=>[k,p[k]]));}
  return out;
}
export function sampleBitRest(point,collapse,id,now,{reduced=false}={}){
  const rest=collapse.restsWorld?.[id],origin=collapse.originsWorld?.[id];if(!rest||!origin)return null;
  const recovering=collapse.phase==='recovering',p=reduced?1:unit((now-collapse.started-rest.delay)/rest.duration);
  const amount=recovering?collapse.mix:collapse.phase==='fallen'?1:ease(p);
  const from=recovering?point:origin;
  // The fall arcs down; the recovery is the fall played backwards, lifting
  // each bit off the floor on a gentle arc as it returns to its station.
  const lift=reduced?0:recovering?Math.sin(Math.PI*unit(amount))*1.4:p>0&&p<1?Math.sin(Math.PI*p):0;
  const targetAngle=finite(point.angle)?point.angle:0;
  return {x:mix(from.x,rest.x,amount)+lift*rest.sway,y:mix(from.y,rest.y,amount)-lift*rest.arc,
    z:mix(recovering?(point.z??1):(collapse.originDepths?.[id]??point.z??1),1,amount),
    angleAbsolute:recovering?angleMix(targetAngle,rest.angle,amount):angleMix(rest.startAngle,rest.angle,amount)+lift*.35,
    restingScale:rest.scale,conditionGround:amount,glowMultiplier:1-.98*amount,conditionMotion:1-amount};
}
/** Preserve ordinary token visibility permission checks at call sites; this
 * only broadens screen culling to four already-visible physical instruments. */
export function bitRestVisible(snapshot,onScreen){
  const response=snapshot?.conditionResponse,c=response?.collapse;
  if(!response?.bits||!c||c.phase==='awake')return false;
  return Object.values(c.restsWorld??{}).some(p=>onScreen(p.x,p.y,100,100))||c.phase==='falling'&&Object.values(c.originsWorld??{}).some(p=>onScreen(p.x,p.y,100,100));
}
