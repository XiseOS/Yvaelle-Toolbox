/** One serializable virtual work clock, independent of departure/return clocks.
 * Rebase at a setting change; no ticker history, timers or document writes. */
export const DEFAULT_SCAN_SPEED=.6;
export function scanSpeed(value=DEFAULT_SCAN_SPEED){return Math.max(.25,Math.min(1.5,Number.isFinite(value)?value:DEFAULT_SCAN_SPEED));}
export function normalizeScanSpeed(value){if(!Number.isFinite(value)||value<.25||value>1.5)throw new Error('Scan speed must be .25–1.5.');return value;}
export function sampleScanClock(event={},now=0){
  now=Math.min(Number.isFinite(now)?now:0,event.conditionPausedAt??Infinity,event.taskPausedAt??Infinity);
  const beginning=(event.started??0)+(event.travelDuration??900),clock=event.scanClock;
  const at=Math.max(beginning,Number.isFinite(clock?.at)?clock.at:beginning),elapsed=Number.isFinite(clock?.elapsed)?Math.max(0,clock.elapsed):0;
  return Math.max(0,elapsed+(now-at)*scanSpeed(clock?.speed??event.utility?.scanSpeed??1));
}
export function rebaseScanClock(event,now,speed){return {at:Math.min(now,event.taskPausedAt??Infinity),elapsed:sampleScanClock(event,now),speed:scanSpeed(speed)};}
export function retimeScanEvent(event,now,speed,{arrivalTimes={}}={}){
  const next={...event,scanClock:rebaseScanClock(event,now,speed)},starts={...event.scanStartElapsed};
  for(const [id,arrival] of Object.entries(arrivalTimes))if(Number.isFinite(arrival)&&arrival>Math.min(now,event.taskPausedAt??Infinity))starts[id]=sampleScanClock(next,arrival);
  if(Object.keys(starts).length)next.scanStartElapsed=starts;
  return next;
}
/** A paused bit stores its virtual timestamp so later speed changes cannot
 * reconstruct its old pause using the new rate. Legacy numeric pauses work
 * until the first speed rebase; prefer {at,elapsed} in persisted jobs. */
export function scanBitClock(event,now,id){
  const paused=event.scanPausedAt?.[id],at=typeof paused==='number'?paused:paused?.at;
  const captured=event.scanPausedElapsed?.[id];
  const elapsed=Number.isFinite(captured)?captured:Number.isFinite(paused?.elapsed)?paused.elapsed:sampleScanClock(event,at==null?now:Math.min(now,at));
  return Math.max(0,elapsed-Math.max(0,event.scanOffsets?.[id]??0));
}
export function pauseScanBit(event,now,id){return {at:now,elapsed:sampleScanClock(event,now)};}
export function resumedScanOffset(event,now,id){
  const paused=event.scanPausedAt?.[id],captured=event.scanPausedElapsed?.[id];if(paused==null&&!Number.isFinite(captured))return Math.max(0,event.scanOffsets?.[id]??0);
  const elapsed=Number.isFinite(captured)?captured:typeof paused==='object'&&Number.isFinite(paused.elapsed)?paused.elapsed:sampleScanClock(event,paused);
  return Math.max(0,event.scanOffsets?.[id]??0)+Math.max(0,sampleScanClock(event,now)-elapsed);
}
