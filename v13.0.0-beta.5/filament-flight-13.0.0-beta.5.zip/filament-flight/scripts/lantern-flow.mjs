/** Decorative density for the lantern's existing native coloration pass.
 * Its source-centred coordinate field never rotates with the cone. Aiming
 * reveals another part of that softly evolving field, rather than turning an
 * image. Neither this sampler nor the fragment can change native light reach. */
export const LANTERN_FLOW_COMMON_UNIFORMS=Object.freeze(['ffLanternFlowGain']);
export const LANTERN_FLOW_UNIFORMS=Object.freeze([...LANTERN_FLOW_COMMON_UNIFORMS,'ffLanternFlowPhase','ffLanternFlowDetail','ffLanternFlowOffset','ffLanternFlowDisruption','ffLanternFlowRecovery']);
export const LANTERN_FLOW_PERIOD=96;
export const LANTERN_FLOW_SETTLE=.20;
export const LANTERN_FLOW_OFFSET_LIMIT=.024;
const TAU=Math.PI*2,finite=(value,fallback)=>Number.isFinite(value)?value:fallback;
const clamp=(value,min=0,max=1)=>Math.min(max,Math.max(min,value));
const modulo=(value,period)=>(value%period+period)%period;
const shortest=value=>modulo(value+Math.PI,TAU)-Math.PI;
const uncomment=source=>source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,part=>part.replace(/[^\n]/g,' '));

/** One fixed-size memory per native source. Offset storage stays stable for
 * Pixi's upload cache; the angle residual is a bounded lag, not accumulated
 * velocity. Exact exponential integration of a linear heading segment avoids
 * a different response at 30, 60 or 144 display frames per second. */
export function createLanternFlowMotion(){return {clock:null,angle:0,residual:0,offset:new Float32Array(2)};}
export function stepLanternFlowMotion(memory,options={}){
  const clock=finite(options.clock,0),angle=modulo(finite(options.angle,0),360)*Math.PI/180;
  if(!memory||!(memory.offset instanceof Float32Array)||memory.offset.length!==2)memory=createLanternFlowMotion();
  const active=options.enabled!==false&&!options.reduced&&options.localEffects!==false;
  const reset=()=>{memory.clock=clock;memory.angle=angle;memory.residual=0;memory.offset.fill(0);return memory;};
  if(!active||memory.clock===null||clock<memory.clock||clock-memory.clock>.5)return reset();
  const dt=clock-memory.clock;
  // Repeated shader hooks at one display time must not add a second turn
  // impulse or advance the integrator. The next accepted display time will
  // include the complete shortest change from the last accepted bearing.
  if(dt===0)return memory;
  const delta=shortest(angle-memory.angle),decay=Math.exp(-dt/LANTERN_FLOW_SETTLE);
  const target=clamp(delta*LANTERN_FLOW_SETTLE/dt,-.35,.35);
  memory.residual=memory.residual*decay+target*(1-decay);
  const magnitude=LANTERN_FLOW_OFFSET_LIMIT*clamp(memory.residual/.35,-1,1);
  if(magnitude===0)memory.offset.fill(0);
  else{memory.offset[0]=-Math.sin(angle)*magnitude;memory.offset[1]=Math.cos(angle)*magnitude;}
  memory.clock=clock;memory.angle=angle;
  return memory;
}

export function lanternFlowUniforms(options={},memory=createLanternFlowMotion()){
  const effects=options.appearanceEffects??{},strength=clamp(finite(options.strength,1)),enabled=options.localEffects!==false;
  return {ffLanternFlowGain:clamp(finite(effects.gain,1),.12,1),
    ffLanternFlowPhase:options.reduced||!enabled?0:modulo(finite(options.clock,0),LANTERN_FLOW_PERIOD)*TAU/LANTERN_FLOW_PERIOD,
    ffLanternFlowDetail:enabled?Math.sqrt(strength)*clamp(finite(effects.detail,1)):0,
    ffLanternFlowOffset:memory.offset,
    ffLanternFlowDisruption:clamp(finite(effects.disruption,0)),ffLanternFlowRecovery:clamp(finite(effects.recovery,0))};
}

// This arithmetic hash avoids texture access and the expensive trigonometric
// corner hash often used by procedural shaders. Quintic interpolation keeps
// the evolving volume's value and derivative smooth at every noise-cell edge.
const functions=`
float ffLanternFlowHash(vec3 p){
  p=fract(p*vec3(0.1031,0.1030,0.0973));
  p+=dot(p,p.yxz+33.33);
  return fract((p.x+p.y)*p.z);
}
float ffLanternFlowNoise(vec3 p){
  vec3 cell=floor(p),f=fract(p);
  vec3 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float lower=mix(mix(ffLanternFlowHash(cell),ffLanternFlowHash(cell+vec3(1.0,0.0,0.0)),u.x),
    mix(ffLanternFlowHash(cell+vec3(0.0,1.0,0.0)),ffLanternFlowHash(cell+vec3(1.0,1.0,0.0)),u.x),u.y);
  float upper=mix(mix(ffLanternFlowHash(cell+vec3(0.0,0.0,1.0)),ffLanternFlowHash(cell+vec3(1.0,0.0,1.0)),u.x),
    mix(ffLanternFlowHash(cell+vec3(0.0,1.0,1.0)),ffLanternFlowHash(cell+vec3(1.0,1.0,1.0)),u.x),u.y);
  return mix(lower,upper,u.z);
}
float ffLanternFlowDensity(vec2 point,float phase){
  // All time harmonics are integers: the quiet 96-second phase wrap is
  // continuous. Independent volume evolution makes currents form and dissolve
  // instead of sliding a fixed patch of noise through the cone.
  float evolve=1.25*sin(phase*5.0)+0.75*cos(phase*3.0);
  vec2 travel=vec2(0.55*sin(phase*3.0),0.55*cos(phase*2.0));
  vec2 warp=vec2(ffLanternFlowNoise(vec3(point*2.25+travel,evolve+1.7)),
    ffLanternFlowNoise(vec3(point*2.25-travel,evolve-2.3)))-0.5;
  float broad=ffLanternFlowNoise(vec3(point*4.3+warp*1.2+travel,evolve));
  float soft=ffLanternFlowNoise(vec3(point*7.1-warp*0.65-travel*0.6,evolve+4.1));
  return broad*0.78+soft*0.22;
}
`;

/** The native main/depth guard is intentionally narrow. Only its existing
 * coloration output receives a restrained achromatic density multiplier;
 * native magenta, source alpha, wall polygon and visibility remain native. */
export function lanternFlowFragment(fragment,layer='coloration'){
  if(typeof fragment!=='string')return null;
  const inspected=uncomment(fragment),mains=[...inspected.matchAll(/\bvoid\s+main\s*\(\s*(?:void\s*)?\)\s*\{/g)],outputs=[...inspected.matchAll(/\bgl_FragColor\s*=\s*([^;]+);/g)];
  if(mains.length!==1||outputs.length!==1||inspected.includes('uniform float ffLanternFlowGain'))return null;
  const main=mains[0],output=outputs[0],bodyStart=main.index+main[0].length;
  const declaration=/\bfloat\s+depth\s*=[^;]+;/g.exec(inspected.slice(bodyStart,output.index));
  if(!declaration)return null;
  const gainAt=bodyStart+declaration.index+declaration[0].length;
  const color=layer==='coloration',uniforms='uniform float ffLanternFlowGain;\n'+(color?'uniform float ffLanternFlowPhase;\nuniform float ffLanternFlowDetail;\nuniform vec2 ffLanternFlowOffset;\nuniform float ffLanternFlowDisruption;\nuniform float ffLanternFlowRecovery;\n'+functions:'');
  let finalOutput=fragment.slice(output.index,output.index+output[0].length);
  if(color)finalOutput=`vec4 ffLanternFlowOutput=${fragment.slice(inspected.indexOf('=',output.index)+1,output.index+output[0].length-1)};
  if(ffLanternFlowDetail>0.0){
    vec2 ffLanternFlowPoint=(vUvs-vec2(0.5))*2.0+ffLanternFlowOffset;
    float ffLanternFlowCloud=ffLanternFlowDensity(ffLanternFlowPoint,ffLanternFlowPhase);
    float ffLanternFlowTaper=smoothstep(0.045,0.20,ffLanternRadius)*(1.0-smoothstep(0.72,0.99,ffLanternRadius));
    float ffLanternFlowResponse=1.0-ffLanternFlowDisruption*0.30;
    float ffLanternFlowShade=(ffLanternFlowCloud-0.49)*(1.25+0.12*ffLanternFlowRecovery);
    float ffLanternFlowGlow=1.0+ffLanternFlowTaper*ffLanternFlowDetail*ffLanternFlowShade*ffLanternFlowResponse;
    ffLanternFlowOutput.rgb=clamp(ffLanternFlowOutput.rgb*clamp(ffLanternFlowGlow,0.60,1.40),vec3(0.0),vec3(1.0));
  }
  gl_FragColor=ffLanternFlowOutput;`;
  return fragment.slice(0,main.index)+uniforms+fragment.slice(main.index,gainAt)+'\n  depth*=ffLanternFlowGain;\n'+fragment.slice(gainAt,output.index)+finalOutput+fragment.slice(output.index+output[0].length);
}

// CPU reference for deterministic coordinate, wrap and smoothness tests. This
// is not used in the render loop; the shader evaluates its own noise on GPU.
const fract=value=>value-Math.floor(value),mix=(a,b,t)=>a+(b-a)*t;
function hash(point){
  const p=point.map((value,index)=>fract(value*[.1031,.1030,.0973][index]));
  const dot=p[0]*(p[1]+33.33)+p[1]*(p[0]+33.33)+p[2]*(p[2]+33.33);
  return fract((p[0]+dot+p[1]+dot)*(p[2]+dot));
}
function noise(point){
  const cell=point.map(Math.floor),f=point.map(fract),u=f.map(v=>v*v*v*(v*(v*6-15)+10));
  const at=(x,y,z)=>hash([cell[0]+x,cell[1]+y,cell[2]+z]);
  return mix(mix(mix(at(0,0,0),at(1,0,0),u[0]),mix(at(0,1,0),at(1,1,0),u[0]),u[1]),
    mix(mix(at(0,0,1),at(1,0,1),u[0]),mix(at(0,1,1),at(1,1,1),u[0]),u[1]),u[2]);
}
export function sampleLanternFlowDensity(point,phase=0,offset=[0,0]){
  const p=[point[0]+offset[0],point[1]+offset[1]],evolve=1.25*Math.sin(phase*5)+.75*Math.cos(phase*3),travel=[.55*Math.sin(phase*3),.55*Math.cos(phase*2)];
  const warp=[noise([p[0]*2.25+travel[0],p[1]*2.25+travel[1],evolve+1.7])-.5,noise([p[0]*2.25-travel[0],p[1]*2.25-travel[1],evolve-2.3])-.5];
  return .78*noise([p[0]*4.3+warp[0]*1.2+travel[0],p[1]*4.3+warp[1]*1.2+travel[1],evolve])+
    .22*noise([p[0]*7.1-warp[0]*.65-travel[0]*.6,p[1]*7.1-warp[1]*.65-travel[1]*.6,evolve+4.1]);
}
