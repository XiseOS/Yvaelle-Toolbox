/** Refined formation library (v10).
 * Ten families, each with its own silhouette and rhythm so they read apart at
 * token size: a ring, stepping posts, a figure eight, low pendulums, a comet
 * chase, petals, a tide line, a breathing spiral, perched watch and star hops.
 * Samplers share the classic contract: (count, index, seconds) -> [x, y, depth, tilt]
 * in rig units around the token centre; depth > 0 passes in front of Ellie. */
const TAU=Math.PI*2;
const unit=n=>Math.max(0,Math.min(1,n));
const ease=n=>{n=unit(n);return n*n*(3-2*n);};
const entry=(name,description)=>Object.freeze({name,description});
const family=(name,counts)=>Object.freeze({name,refined:true,counts:Object.freeze(Object.fromEntries(counts.map((c,i)=>[i+1,entry(...c)])))});

export const REFINED_BIT_PROGRAMS=Object.freeze({
  halo:family('Halo',[
    ['Lone satellite','One instrument circles her on a wide, tilted ring, passing in front and behind.'],
    ['Twin satellites','Two instruments hold opposite sides of the ring as it turns.'],
    ['Triad ring','Three evenly spaced instruments turn the ring together, breathing slightly wider and closer.'],
    ['Full halo','Four instruments keep a square on the turning ring, a calm crown around her.']]),
  sentinel:family('Sentinel posts',[
    ['Night round','One sentinel holds a post, then steps a quarter turn to the next and settles again.'],
    ['Paired posts','Two sentinels hold opposite posts and step around together.'],
    ['Three posts','Three sentinels hold a triangle and rotate it one post at a time.'],
    ['Four corners','Four sentinels hold a diamond, pause, then step a quarter turn as one.']]),
  lemniscate:family('Figure eight',[
    ['Infinity','One instrument traces a wide figure eight through her, crossing in front then behind.'],
    ['Chasing loops','Two instruments chase each other around the same figure eight.'],
    ['Woven eight','Three instruments share the eight, evenly spaced, weaving in front and behind her.'],
    ['Full weave','Four instruments run the eight in a steady procession.']]),
  pendulum:family('Pendulums',[
    ['Censer','One instrument hangs below her and swings in a slow arc.'],
    ['Paired censers','Two hanging instruments swing in opposition.'],
    ['Three bells','Three hang in a row and swing in a rippling wave.'],
    ['Chime','Four hang low and swing in a travelling wave, like wind chimes.']]),
  comet:family('Comet',[
    ['Comet','One instrument sweeps a wide looping path with a short trail of light.'],
    ['Comet and tail','A leader sweeps the loop with a follower close behind.'],
    ['Little procession','Three follow one line around a three-lobed path.'],
    ['Long tail','Four fly nose to tail around a looping rosette.']]),
  petals:family('Lily petals',[
    ['Lily trace','One instrument traces a slow five-petal lily around her, petal by petal, as the bloom turns.'],
    ['Twin lily','Two instruments glide around a six-petal lily on opposite sides.'],
    ['Trefoil lily','Three instruments glide around a six-petal lily, evenly spaced, passing in front of her and behind.'],
    ['Full lily','Four instruments trace an eight-petal lily in procession as the bloom slowly turns.']]),
  tide:family('Tide line',[
    ['Buoy','One instrument rides a gentle swell, drifting side to side.'],
    ['Two buoys','Two ride the same swell, rising and falling one after the other.'],
    ['Wave crest','Three across her ride a travelling wave.'],
    ['Long swell','Four across her rise and fall as a wave passes along the line.']]),
  spiral:family('Spiral breath',[
    ['Inhale','One instrument spirals in close, then out wide again.'],
    ['Double helix','Two spiral in and out on opposite sides.'],
    ['Triple spiral','Three spiral in to a tight ring and open again, like a breath.'],
    ['Deep breath','Four draw in close around her and expand outward together.']]),
  perch:family('Perched watch',[
    ['Lookout','One instrument perches near a wing tip and turns to scan now and then.'],
    ['Wing-tip lookouts','Two perch on the upper wing tips, taking turns to look around.'],
    ['Three lookouts','Three perch on wing tips, one occasionally hopping up for a better view.'],
    ['Four lookouts','All four perch on the wing tips; one at a time scans and settles.']]),
  constellation:family('Constellation',[
    ['Wandering star','One instrument hops between points around her, resting at each.'],
    ['Twin stars','Two hop between their own points on their own rhythm.'],
    ['Three stars','Three hop independently, so the shape keeps changing.'],
    ['Constellation','Four hop between star points on different rhythms, never quite repeating.']]),
  wingTrace:family('Wing trace',[
    ['Wing tracer','One instrument glides along the edge of one wing, rests, then slips behind her to trace the other wing.'],
    ['Paired tracers','One instrument rides each wing outline, mirrored, steadying both wings.'],
    ['Three tracers','Two trace the wings while the third holds her centre line.'],
    ['Wing stabilizers','Two instruments ride each wing outline, keeping the filaments steady.']]),
  heartline:family('Heartline',[
    ['Pulse marker','One instrument rides a heartbeat line beneath her, rising with each beat.'],
    ['Paired beat','Two hold the line under her; the beat passes from one to the other.'],
    ['Three-lead','Three hold the line; a heartbeat spike runs through them left to right.'],
    ['Full trace','Four hold a monitor line under her and a steady heartbeat runs through them.']]),
  crown:family('Crown of light',[
    ['Crown jewel','One instrument rests above her head, bobbing with her breath.'],
    ['Twin jewels','Two sit in a shallow arc above her and trade places slowly.'],
    ['Three-point crown','Three form an arc over her head that breathes wider and closer.'],
    ['Full crown','Four form a crown above her that turns a little and breathes.']]),
  search:family('Wide search',[
    ['Lone searcher','One instrument ranges well away from her, holds to search, then moves on.'],
    ['Searching pair','Two range out on opposite sides, each holding to search before moving on.'],
    ['Three searchers','Three spread into their own sectors and search them, never crowding each other.'],
    ['Four searchers','Four spread far apart around her, each searching its own quarter in its own time.']]),
});

export const REFINED_BIT_PROGRAM_IDS=Object.freeze(Object.keys(REFINED_BIT_PROGRAMS));

const ring=(a,rx,ry,cy=-8)=>[rx*Math.cos(a),cy+ry*Math.sin(a)];
function halo(count,i,t){
  const q=t*.32+i*TAU/count,rx=124+7*Math.sin(t*.45),ry=80+5*Math.sin(t*.45+1);
  const [x,y]=ring(q,rx,ry);return [x,y,Math.sin(q),.1*Math.cos(q)];
}
function sentinel(count,i,t){
  const posts=Math.max(4,count),step=TAU/posts,P=3.4,phase=t/P,n=Math.floor(phase),u=ease((phase-n-.68)/.32);
  const a=-Math.PI/2+i*TAU/count+(n+u)*step,lift=Math.sin(Math.PI*u)*10,sway=(1-u)*.18*Math.sin(t*1.7+i);
  const [x,y]=ring(a,128,98,-6);return [x,y-lift,Math.sin(a),sway];
}
function lemniscate(count,i,t){
  const s=t*.4+i*TAU/count,d=1+Math.sin(s)**2,A=176;
  return [A*Math.cos(s)/d,-6+A*1.05*Math.sin(s)*Math.cos(s)/d,Math.sin(s),.14*Math.cos(2*s)];
}
function pendulum(count,i,t){
  const pivots={1:[0],2:[-74,74],3:[-104,0,104],4:[-138,-48,48,138]}[count],px=pivots[i],L=count===1?210:198;
  const th=.42*Math.sin(t*1.05-i*.75),pivotY=-128;
  return [px+L*Math.sin(th),pivotY+L*Math.cos(th),.7*Math.cos(t*1.05-i*.75),th*.8];
}
function comet(count,i,t){
  const th=t*.42-i*.3,r=132+30*Math.cos(3*th);
  return [1.12*r*Math.cos(th),-6+.74*r*Math.sin(th),Math.sin(th),.12*Math.sin(3*th)];
}
function petals(count,i,t){
  // beta.30 lily bloom: every bit glides along one smooth flower outline
  // around her. Each petal is a soft teardrop lobe with a rounded tip and a
  // rounded base (no cusp, no snap); the bits are spaced evenly along it, so
  // the petals open in turn around her. The bloom is tilted in depth: low
  // petals pass in front of her, high ones behind. It turns slowly, a little
  // faster with fewer bits. Unhurried: about 2.7 s a petal, easing at the tips.
  const N={1:5,2:6,3:6,4:8}[count],per=2.7,w=TAU/(N*per),turn=t*(count===1?.05:count===2?.035:.022);
  // spaced around the bloom and offset within a petal, so the petals open
  // in turn (never all at her face at once)
  const ph=w*t+i*TAU/count+i*TAU/(N*count),q=N*ph-.45*Math.sin(N*ph),th=q/N+turn,s=.5+.5*Math.cos(q),r=62+92*s*s;
  return [r*Math.cos(th),-8+.74*r*Math.sin(th),Math.sin(th)*(.55+.45*s),.12*Math.sin(q)];
}
let formationMotion='v10';
export function setFormationMotion(v){formationMotion=v==='classic'?'classic':'v10';}
export function getFormationMotion(){return formationMotion;}
function tide(count,i,t){
  if(formationMotion==='classic'){const xs={1:[0],2:[-62,62],3:[-104,0,104],4:[-138,-46,46,138]}[count],drift=count===1?90*Math.sin(t*.28):10*Math.sin(t*.2+i),x=xs[i]+drift,ph=t*1.1-x/72;return [x,96+26*Math.sin(ph),.85,.2*Math.cos(ph)];}
  const xs={1:[0],2:[-62,62],3:[-104,0,104],4:[-138,-46,46,138]}[count];
  // instruments ride a travelling swell under her, drifting along it so each traces a stretch of wave
  const drift=count===1?90*Math.sin(t*.28):30*Math.sin(t*.31+i*1.7);
  const x=xs[i]+drift,ph=t*1.6-x/34;
  return [x,98+16*Math.sin(ph),.85,.2*Math.cos(ph)];
}
function spiral(count,i,t){
  const breath=.5-.5*Math.cos(t*.5),r=88+70*breath,a=t*(.55+.25*(1-breath))+i*TAU/count;
  return [r*Math.cos(a),-8+.8*r*Math.sin(a),Math.sin(a),.12*(breath-.5)];
}
function perch(count,i,t){
  const tips={1:[[150,-112]],2:[[-150,-112],[150,-112]],3:[[-150,-112],[150,-112],[0,128]],4:[[-150,-112],[150,-112],[-140,112],[140,112]]}[count][i];
  const P=6.5,turn=Math.floor(t/P)%count,local=(t%P)/P,active=turn===i?Math.sin(Math.PI*unit((local-.15)/.6)):0;
  const hop=count===3&&i===2?0:active*14;
  return [tips[0]+2*Math.sin(t*.9+i),tips[1]-hop+2*Math.cos(t*.7+i),tips[1]>0?.6:-.6,active*.9*Math.sin(t*2.2)];
}
const STAR=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
function constellation(count,i,t){
  const pts=Array.from({length:5},(_,k)=>{const a=STAR(i*17+k*3.1)*TAU,r=100+45*STAR(i*29+k*7.7);return [r*Math.cos(a),-8+.78*r*Math.sin(a),Math.sin(a)];});
  const P=4.4+i*.85,ph=t/P+STAR(i*5),n=Math.floor(ph),u=ease((ph-n-.62)/.38);
  const a=pts[n%5],b=pts[(n+1)%5],arc=Math.sin(Math.PI*u)*22;
  return [a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u-arc,a[2]+(b[2]-a[2])*u,.25*Math.sin(Math.PI*u)];
}
// --- v10 beta additions: shapes that belong to her ---
const WING_TH0=-Math.PI*.15;
function wingLobe(side,u){
  const th=WING_TH0+u*TAU,cx=side*96,cy=-30,r=56+24*Math.cos(2*th-0.6);
  return [cx+side*r*Math.cos(th)*1.05,cy-r*Math.sin(th)*1.25,-.2+.6*Math.sin(th),side*.18*Math.cos(th)];
}
// Lobe progress that leaves and reaches the shoulder at rest (no stop-jerk).
const glide=u=>u-Math.sin(TAU*u)/TAU;
function wingTrace(count,i,t){
  // a lobe around each wing: up the leading edge to the tip, down the trailing edge, back to the shoulder
  const side=count===3&&i===2?0:(count===1?-1:(i%2?1:-1));
  if(side===0)return [0,-118+8*Math.sin(t*1.3),-.4,.08*Math.sin(t)];
  if(count===1){
    // Trace one wing, rest, then glide across behind her to the other wing.
    const lobe=6.6,rest=.9,cross=1.9,half=lobe+rest+cross,k=Math.floor(t/half),local=t-k*half,s=k%2?1:-1;
    if(local<lobe)return wingLobe(s,glide(local/lobe));
    const [x0,y0,z0,a0]=wingLobe(s,0);
    if(local<lobe+rest)return [x0,y0,z0,a0];
    const u=(local-lobe-rest)/cross,e=ease(u),arc=Math.sin(Math.PI*u);
    return [x0*(1-2*e),y0-30*arc,z0-.55*arc,a0*(1-2*e)];
  }
  const lane=count===4?Math.floor(i/2):0,speed=.13,raw=(t*speed+lane*.5+i*.02)%1;
  const hold=.14,u=raw<hold?0:glide((raw-hold)/(1-hold));// pause at the shoulder before each pass
  return wingLobe(side,u);
}
const heartBlip=k=>-5*Math.exp(-((k+2.4)**2)*1.1)+5*Math.exp(-((k+.9)**2)*3)-30*Math.exp(-(k**2)*1.6)+9*Math.exp(-((k-.9)**2)*3)-8*Math.exp(-((k-2.4)**2)*1.1);
function heartline(count,i,t){
  // each instrument writes its own beat: a slow pass to the right with a P-QRS-T blip,
  // then a quick slide back along the baseline. Beats are staggered so the pulse travels.
  // The beat is an eased pulse (a soft rise, a firm crest, a settling dip) and
  // the return is a low loop that leaves and rejoins the line at its own pace.
  const xs={1:[0],2:[-74,74],3:[-112,0,112],4:[-150,-50,50,150]}[count],x0=xs[i],W=count===1?74:46;
  const beat=count===1?2.3:1.6,p=(t/beat+i*.18)%1,write=count===1?.64:.7,v=2*W/write;
  let x,y=0,z=.8;
  if(p<write){const u=p/write;x=x0-W+2*W*u;
    // blip centred on the pass, pinned to the baseline at both ends
    y=heartBlip((u-.5)*7)-heartBlip(-3.5)*(1-u)-heartBlip(3.5)*u;}
  else{
    // Cubic Hermite from (+W, +v) back to (-W, +v): a smooth turn at both ends.
    const T=1-write,u=(p-write)/T,u2=u*u,u3=u2*u,h00=2*u3-3*u2+1,h10=u3-2*u2+u,h01=-2*u3+3*u2,h11=u3-u2;
    x=x0+W*h00+v*T*h10-W*h01+v*T*h11;y=12*Math.sin(Math.PI*u);z=.8-.5*Math.sin(Math.PI*u);}
  return [x,104+y,z,y*.004];
}
function crown(count,i,t){
  const breath=.5-.5*Math.cos(t*.6),spread={1:0,2:.62,3:1.05,4:1.35}[count];
  const turn=(count===1?.5:.3)*Math.sin(t*.22),a=-Math.PI/2+turn+(count===1?0:(i/(count-1)-.5)*spread*(1+.22*breath));
  const r=140+14*breath,bob=5*Math.sin(t*1.2+i*1.3);
  return [r*Math.cos(a)*1.08,-14+r*Math.sin(a)*.95+bob,-.6,.15*Math.cos(a)];
}
/* Wide search (used by Resting searchlights): each bit owns a sector around
 * her, travels deliberately to a spot in it, holds there for a few seconds
 * while its light searches, then moves to another. The spots come from a
 * fixed hash, so every client sees the same path. */
const hash1=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s);};
function searchSpot(count,i,k){
  const sector=TAU/count,centre=(count===4?-3*Math.PI/4:-Math.PI/2)+(count===1?0:i*sector)+(count===2?Math.PI/2:0),
    a=centre+(hash1(i*97+k*13.7)-.5)*Math.min(1.5,sector*.62),r=158+80*hash1(i*31+k*7.3);
  return [r*Math.cos(a)*1.12,-10+r*Math.sin(a)*.86,a];
}
function search(count,i,t){
  const P=7.2,travel=2.3,local=t+i*P*.37,k=Math.floor(local/P),u=local/P-k,m=ease(Math.min(1,u*P/travel));
  const [x0,y0]=searchSpot(count,i,k-1),[x1,y1,a]=searchSpot(count,i,k),bob=4*Math.sin(t*1.1+i*1.7)*(1-.6*Math.sin(Math.PI*m));
  return [x0+(x1-x0)*m,y0+(y1-y0)*m+bob,Math.sin(a)*.7,.12*Math.sin(t*.5+i)];
}
export const REFINED_SAMPLERS=Object.freeze({halo,sentinel,lemniscate,pendulum,comet,petals,tide,spiral,perch,constellation,wingTrace,heartline,crown,search});
