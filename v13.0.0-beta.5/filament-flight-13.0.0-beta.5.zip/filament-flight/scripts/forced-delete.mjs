/** Forced deletion of a document field (beta.34). Foundry v14 replaced the
 * `-=key` syntax with a `foundry.data.operators.ForcedDeletion` value at the
 * plain path (the old form warns from v14 and goes in v16). Writers use
 * deleteKey(); readers use isDeletion()/deletes(), which understand both. */
const operator=()=>{try{return globalThis.foundry?.data?.operators?.ForcedDeletion??null;}catch{return null;}};
/** [key, value] that deletes `name` under the dotted `path` ('' for top level). */
export function deleteKey(path,name){
  const C=operator(),base=path?`${path}.`:'';
  return C?[`${base}${name}`,new C()]:[`${base}-=${name}`,null];
}
/** Put the deletion of `path.name` into a dotted change object; returns it. */
export function forceDelete(out,path,name){const [k,v]=deleteKey(path,name);out[k]=v;return out;}
/** Is this change value a v14 forced deletion? */
export function isDeletion(value){const C=operator();return !!(value&&typeof value==='object'&&(C&&value instanceof C||value.constructor?.name==='ForcedDeletion'));}
/** Does a change object (nested level) delete `name`, in either form? */
export function deletes(obj,name){return !!obj&&(Object.hasOwn(obj,`-=${name}`)||Object.hasOwn(obj,name)&&isDeletion(obj[name]));}
/** Is a dotted change key/value pair the deletion of `path.name`, in either form? */
export function deletesPath(key,value,path,name){return key===`${path}.-=${name}`||key===`${path}.${name}`&&isDeletion(value);}
