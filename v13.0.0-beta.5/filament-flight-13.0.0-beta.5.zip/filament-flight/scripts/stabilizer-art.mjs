import {WING_COLOR} from './wing-art.mjs?v=13.0.0-beta.5';
import {paintAnimatedBit} from './bit-painter.mjs?v=13.0.0-beta.5';
import {paintResonantBit} from './bit-resonance.mjs?v=13.0.0-beta.5';
import {paintBitEnergy} from './bit-energy.mjs?v=13.0.0-beta.5';

// Small machined pieces, drawn as rigid beveled solids. Reuse the existing
// capped wing canvases: no image downloads, additional textures or ticker.
const HULL=[[0,-23],[5,-18],[8,-5],[6,14],[0,22],[-6,14],[-8,-5],[-5,-18]];
const PANEL=[[0,-19],[3.5,-15],[5.3,-4],[4.1,12],[0,17],[-4.1,12],[-5.3,-4],[-3.5,-15]];
const SLOT=[[-1.8,-12],[0,-15],[1.8,-12],[1.8,6],[0,10],[-1.8,6]];
export const STABILIZER_SHAPES=Object.freeze({original:HULL,
  vanes:[[0,-25],[4,-21],[6,-10],[5,15],[0,23],[-5,15],[-6,-10],[-4,-21]],
  shielded:[[0,-22],[7,-16],[10,-3],[8,13],[0,21],[-8,13],[-10,-3],[-7,-16]],
  spine:[[0,-27],[4,-19],[5,-8],[4,15],[0,26],[-4,15],[-5,-8],[-4,-19]]});

// Field aiming is synchronous, including the worker and previews. Reuse a
// numeric scratch buffer instead of allocating one object for every contour
// segment, for every instrument, on every artwork frame. It holds numbers
// only; no rig, token or contour references survive a sample. Each realm has
// its own buffer. Doubling keeps growth bounded by the largest supplied shape.
let fieldCandidates=new Float64Array(256*4);

/** Aim at the nearest segment of this wing's support contour. The field stays
 * local to the housing; its reach never grows with the distance to the wing.
 * Contours are the visible primary wing spans, including condition/Reform
 * deformation, but exclude decorative echoes. Neighboring normals blend for
 * a stable aim. No render objects or timers are kept between frames. */
export function stabilizerField(part,contours,side,strength) {
  const [center]=part.points;
  const material=contours.some(path=>path.supportReference);
  let nearest=null,best=Infinity,count=0;
  for(const path of contours)for(let i=1;i<path.length;i++) {
    const reference=path.supportReference,a=path[i-1],b=path[i],ra=reference?.[i-1]??a,rb=reference?.[i]??b,dx=rb[0]-ra[0],dy=rb[1]-ra[1],length=dx*dx+dy*dy;
    const t=length?Math.max(0,Math.min(1,((center[0]-ra[0])*dx+(center[1]-ra[1])*dy)/length)):0;
    const x=a[0]+dx*t-center[0],y=a[1]+dy*t-center[1];
    const z=ra[2]+(rb[2]-ra[2])*t-center[2],rx=ra[0]+dx*t-center[0],ry=ra[1]+dy*t-center[1],distance=rx*rx+ry*ry+.15*z*z;
    const liveX=reference?a[0]+(b[0]-a[0])*t-center[0]:x,liveY=reference?a[1]+(b[1]-a[1])*t-center[1]:y;
    const refLength=reference?Math.sqrt(rx*rx+ry*ry):0,liveLength=reference?Math.sqrt(liveX*liveX+liveY*liveY):0;
    // A flap may cross the emitter. Retain the material-facing normal through
    // that crossing rather than allowing a tiny vector to flip the whole field.
    const aimX=reference&&refLength>.01?rx/refLength*.75+(liveLength>.01?liveX/liveLength*.25:0):x,aimY=reference&&refLength>.01?ry/refLength*.75+(liveLength>.01?liveY/liveLength*.25:0):y;
    if(count+4>fieldCandidates.length){const grown=new Float64Array(fieldCandidates.length*2);grown.set(fieldCandidates);fieldCandidates=grown;}
    fieldCandidates[count++]=aimX;fieldCandidates[count++]=aimY;fieldCandidates[count++]=distance;fieldCandidates[count++]=Math.sqrt(length);
    if(distance<best){best=distance;nearest=[aimX,aimY];}
  }
  if(!nearest)return null;
  // Blend neighboring contour normals instead of abruptly choosing a different
  // edge at a fold. This is deterministic geometry, with no per-client lag state.
  let x=0,y=0;
  for(let i=0;i<count;i+=4) {
    const px=fieldCandidates[i],py=fieldCandidates[i+1],d=material?Math.sqrt(px*px+py*py):Math.hypot(px,py),w=Math.exp(-(fieldCandidates[i+2]-best)/144)*Math.min(24,fieldCandidates[i+3]);
    if(d>.01){x+=px/d*w;y+=py/d*w;}
  }
  const length=Math.hypot(x,y),open=Math.max(0,Math.min(1,part.hardware.open));
  const fallback=Math.hypot(...nearest);
  return {direction:length>.01?[x/length,y/length]:fallback>.01?nearest.map(v=>v/fallback):[-side,0],strength:strength*open*open*(3-2*open)};
}

/** Animated local support currents follow actual wing geometry. Energy spans
 * are bounded and curved; they do not physically tether or pull the wings.
 * Ordinary rig paths retain depth splitting, colour, quality and batching. */
export function stabilizerCurrents(part,contours,side,flight){
  const h=part.hardware,r=h?.resonance??{},field=h?.glow;
  if(!h||h.glowMode!=='field'||!field||field.strength<=0||h.power<=0)return [];
  const center=part.points[0],clock=r.phase??0,phase=clock+.65*((r.fieldRate??1)-1)*Math.sin(clock*.41),focus=r.focus??0,motion=r.motion??0;
  let nearest=null,distance=Infinity;
  for(const path of contours)for(let i=1;i<path.length;i++){
    const reference=path.supportReference,a=reference?.[i-1]??path[i-1],b=reference?.[i]??path[i],dx=b[0]-a[0],dy=b[1]-a[1],ll=dx*dx+dy*dy;
    const t=ll?Math.max(0,Math.min(1,((center[0]-a[0])*dx+(center[1]-a[1])*dy)/ll)):0;
    const x=a[0]+dx*t,y=a[1]+dy*t,d=(x-center[0])**2+(y-center[1])**2;
    if(d<distance){distance=d;nearest={path,index:i,t};}
  }
  // A freely positioned controller can energize a remote part of its wing.
  // Keep the contour span compact rather than hiding the field when the owner
  // moves the bit away; no beam, rope or physical attachment is introduced.
  if(!nearest)return [];
  const {path,index,t}=nearest,cumulative=[0];
  for(let i=1;i<path.length;i++)cumulative.push(cumulative[i-1]+Math.hypot(path[i][0]-path[i-1][0],path[i][1]-path[i-1][1]));
  const total=cumulative.at(-1),at=cumulative[index-1]+(cumulative[index]-cumulative[index-1])*t;
  if(total<3)return [];
  const style=flight.gems.fieldStyle??r.fieldStyle??'contour',half=(style==='aegis'?42:style==='weave'?36:29)+focus*8+motion*5;
  const start=Math.max(0,at-half),end=Math.min(total,at+half),length=end-start;
  const base=field.strength*Math.min(1,h.power)*part.strength;
  if(base<.002||length<3)return [];
  const sample=(u,offset=0)=>{
    const d=start+Math.max(0,Math.min(1,u))*length;
    let k=1;while(k<cumulative.length-1&&cumulative[k]<d)k++;
    const a=path[k-1],b=path[k],l=cumulative[k]-cumulative[k-1],v=l?(d-cumulative[k-1])/l:0;
    const x=a[0]+(b[0]-a[0])*v,y=a[1]+(b[1]-a[1])*v,z=(a[2]??0)+((b[2]??0)-(a[2]??0))*v;
    const dx=(b[0]-a[0])/(l||1),dy=(b[1]-a[1])/(l||1);
    const reference=path.supportReference,ra=reference?.[k-1]??a,rb=reference?.[k]??b,rdx=rb[0]-ra[0],rdy=rb[1]-ra[1];
    const sign=(-rdy*(center[0]-ra[0])+rdx*(center[1]-ra[1]))>=0?1:-1;
    return [x-dy*offset*sign,y+dx*offset*sign,z,.92];
  };
  const paths=[],add=(kind,points,width,strength,highlight=false)=>paths.push({id:`support-${part.id}-${kind}`,points,width,strength:base*strength,highlight});
  const wrap=n=>(n%1+1)%1;
  if(style==='weave'){
    for(const lane of [-1,1]){
      const points=Array.from({length:27},(_,i)=>{const u=i/26;return sample(u,5+lane*(2.2+focus)*Math.sin(u*Math.PI*3-phase*.9)*Math.sin(Math.PI*u));});
      add(`weave-${lane}`,points,.64,.8);
    }
    for(let j=0;j<4;j++){
      const u=wrap(phase*.115+j/4),alpha=Math.sin(Math.PI*u);
      const points=Array.from({length:8},(_,i)=>{const v=i/7;return sample(Math.max(0,Math.min(1,u+(v-.5)*.14)),5+(v-.5)*5.5*Math.sin(Math.PI*u));});
      add(`weft-${j}`,points,.48,.58*alpha);
    }
  }else if(style==='aegis'){
    for(let lane=0;lane<2;lane++)add(`aegis-edge-${lane}`,Array.from({length:27},(_,i)=>{const u=i/26;return sample(u,(3+lane*8)*Math.sin(Math.PI*u));}),.62,.65);
    for(let j=0;j<4;j++){
      const u=wrap(phase*.08+j/4),alpha=Math.sin(Math.PI*u);
      const points=Array.from({length:11},(_,i)=>{const v=i/10;return sample(u+(v-.5)*.16,3+8*Math.sin(Math.PI*v)*Math.sin(Math.PI*u));});
      add(`aegis-brace-${j}`,points,.58,.95*alpha);
    }
  }else{
    for(let lane=0;lane<3;lane++){
      const flow=wrap(phase*.115+lane/3),offset=2.5+flow*8;
      const points=Array.from({length:27},(_,i)=>{const u=i/26;return sample(u,offset*Math.sin(Math.PI*u));});
      add(`crescent-${lane}`,points,.62,(.34+.62*Math.sin(Math.PI*flow)));
    }
  }
  // Separate counterflowing scan fronts make the support animation legible
  // against steady filaments; their intensity eases at both span ends.
  for(let j=0;j<2;j++){
    const scanPhase=phase*.12+.04*motion*Math.sin(phase*.43);
    const u=wrap(scanPhase*(j?-1:1)+j*.53),alpha=Math.sin(Math.PI*u);
    const points=Array.from({length:9},(_,i)=>{const v=Math.max(0,Math.min(1,u+(i/8-.5)*.17));return sample(v,4.3*Math.sin(Math.PI*v));});
    add(`scan-${j}`,points,.92,1.7*alpha,true);
  }
  return paths;
}

/** Pick the lit housing faces using their outward normals, including rolled
 * and upside-down bits. A broad feathered bloom and a narrow rim read as field
 * emitters, not a ray between the bit and a wing. */
function fieldFaces(project,direction,hull=HULL) {
  const points=hull.map(project),faces=[];let weight=0,origin=[0,0];
  for(let i=0;i<points.length;i++) {
    const a=points[i],b=points[(i+1)%points.length],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);
    const facing=Math.max(0,(dy*direction[0]-dx*direction[1])/length);
    if(facing<.05)continue;
    const w=length*facing*facing*facing;
    origin[0]+=(a[0]+b[0])*.5*w;origin[1]+=(a[1]+b[1])*.5*w;weight+=w;
    faces.push({a,b,facing});
  }
  return {faces,origin:origin.map(v=>v/weight)};
}

/** The housing stays intact through filament glitches; only its internal core
 * flickers. Position/orientation are supplied by independent choreography. */
export function paintStabilizer(ctx,part,assets) {
  if(paintResonantBit(ctx,part))return;
  if(paintAnimatedBit(ctx,part,assets))return;
  const [[cx,cy]]=part.points,{angle,scale,roll=0,open=1,power=1}=part.hardware;
  const h=part.hardware,design=h.design??'original',hull=STABILIZER_SHAPES[design]??HULL;
  const cos=Math.cos(angle),sin=Math.sin(angle),aspect=.88+.12*Math.cos(roll);
  const project=([x,y])=>[cx+scale*(x*aspect*cos-y*sin),cy+scale*(x*aspect*sin+y*cos)];
  const trace=points=>{ctx.beginPath();points.map(project).forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));};
  const fill=(points,color)=>{trace(points);ctx.closePath();ctx.fillStyle=color;ctx.fill();};
  const line=(points,color,width=.55)=>{trace(points);ctx.lineWidth=width*scale;ctx.strokeStyle=color;ctx.stroke();};
  const shift=(points,x,y)=>points.map(p=>[p[0]+x,p[1]+y]);
  ctx.save();ctx.globalAlpha=part.strength;
  const energy=pass=>{ctx.save();ctx.translate(cx,cy);ctx.rotate(angle);ctx.scale(scale,scale);paintBitEnergy(ctx,part,pass);ctx.restore();};
  if(h.glowMode!=='field')energy('back');
  const field=part.hardware.glow;
  const fieldPower=h.glowMode==='field'?(field?.strength??0)*Math.max(0,Math.min(1,power)):0;
  const facing=fieldPower>.001?fieldFaces(project,field.direction,hull):null;
  if(facing) {
    const [nx,ny]=field.direction,[x,y]=facing.origin;
    ctx.save();ctx.globalAlpha=part.strength*fieldPower;
    // The near edge glows into a small, soft pool. The metal covers its rear
    // falloff, leaving the wing-facing surface visibly brighter.
    ctx.translate(x+nx*scale*4,y+ny*scale*4);
    ctx.transform(nx*scale*17,ny*scale*17,-ny*scale*21,nx*scale*21,0,0);
    const bloom=ctx.createRadialGradient(0,0,0,0,0,1);
    bloom.addColorStop(0,'rgba(255,0,255,0.75)');
    bloom.addColorStop(.3,'rgba(255,0,255,0.32)');
    bloom.addColorStop(.68,'rgba(255,0,255,0.075)');
    bloom.addColorStop(1,'rgba(255,0,255,0)');
    ctx.fillStyle=bloom;ctx.beginPath();ctx.arc(0,0,1,0,2*Math.PI);ctx.fill();ctx.restore();
  }
  // Undercut, satin shell and separate raised bevels give readable thickness.
  fill(shift(hull,2.2,2.6),'#080b12');
  const a=project([-8,-5]),b=project([8,5]),metal=ctx.createLinearGradient(...a,...b);
  metal.addColorStop(0,'#263442');metal.addColorStop(.28,'#7e90a2');
  metal.addColorStop(.48+.04*Math.sin(roll),'#4d6073');metal.addColorStop(1,'#162232');
  fill(hull,metal);
  if(design==='original'){
    fill([[0,-23],[5,-18],[8,-5],[6,14],[0,22],[1,15],[4.4,11],[5.3,-4],[3.5,-15]],'#182333');
    fill([[0,-23],[-5,-18],[-8,-5],[-6,14],[0,22],[-1,15],[-4.1,12],[-5.3,-4],[-3.5,-15]],'#98aabd');
  }else{
    const inner=hull.map(([x,y])=>[x*.73,y*.82]);
    for(let i=0;i<hull.length;i++)fill([hull[i],hull[(i+1)%hull.length],inner[(i+1)%hull.length],inner[i]],i<4?'#1b2939':'#8a9fb2');
  }
  const top=project([0,-19]),bottom=project([0,17]),plate=ctx.createLinearGradient(...top,...bottom);
  plate.addColorStop(0,'#8093a5');plate.addColorStop(.32,'#526579');plate.addColorStop(1,'#263747');
  const panel=design==='original'?PANEL:hull.map(([x,y])=>[x*.64,y*.77]);
  fill(panel,plate);
  if(design==='original')fill([[0,-19],[3.5,-15],[5.3,-4],[4.1,12],[0,17],[0,-19]],'#354354');
  else fill(panel.map(([x,y])=>[Math.max(0,x),y]),'#354354');
  // Two compact slotted rails open a few pixels as each back-mounted bit deploys.
  for(const side of [-1,1]) {
    const x=side*((design==='shielded'?8.7:design==='spine'?4.8:6.3)+2.2*open);
    const rail=design==='vanes'?[[x,-20],[x+side*3,-11],[x+side*2.8,12],[x-side*.5,20],[x-side*.8,-6]]:
      [[x,-12],[x+side*2.8,-7],[x+side*2.4,11],[x-side*.8,15],[x-side*1,-7]];
    fill(shift(rail,1.5,1.5),'#0b111c');fill(rail,side<0?'#76879a':'#303e51');
    line([[x,-8],[x+side*.8,-4],[x+side*.45,8]],'#b0c1cf',.5);
    for(const y of [-3,1,5])line([[x-side*.2,y],[x+side*1.45,y+.4]],'#101927',.8);
  }
  if(design==='shielded')for(const side of [-1,1]){
    fill([[side*2,-15],[side*6,-12],[side*7,5],[side*3,11]],side<0?'#8397a9':'#243444');
    line([[side*3,-13],[side*5,-10],[side*5.8,3]],'#b3c4cd',.45);
  }
  if(design==='spine')for(const y of [-15,-6,3,12])for(const side of [-1,1]){
    const plate=[[side*1.7,y-2],[side*6.8,y-4],[side*8.2,y+2],[side*3.2,y+4]];
    fill(shift(plate,.8,1.2),'#090f18');fill(plate,side<0?'#889bab':'#34485a');
    line([plate[0],plate[1],plate[2]],'#adbbc7',.4);
  }
  // Reflected highlights follow a fixed oblique light direction as the rigid
  // housing rotates. No added bloom, scene lighting or blinking texture.
  if(h.metalHighlights&&h.highlightStrength>0){
    const shine=h.highlightStrength,light=[-.65,-.76],rim=hull.map(project);
    for(let i=0;i<rim.length;i++){
      const p=rim[i],q=rim[(i+1)%rim.length],dx=q[0]-p[0],dy=q[1]-p[1],length=Math.hypot(dx,dy);
      const reflection=Math.max(0,(dy*light[0]-dx*light[1])/length);
      ctx.globalAlpha=part.strength*shine*(.12+.66*reflection**5);
      ctx.beginPath();ctx.moveTo(...p);ctx.lineTo(...q);ctx.lineWidth=.8*scale;ctx.strokeStyle='#e1e9ee';ctx.stroke();
    }
    const strip=.5+.27*Math.sin(angle*1.3+roll*2.8),start=project([-7,0]),end=project([7,0]);
    const spec=ctx.createLinearGradient(...start,...end);
    spec.addColorStop(0,'rgba(220,232,240,0)');spec.addColorStop(Math.max(0,strip-.18),'rgba(220,232,240,0)');
    spec.addColorStop(strip,'rgba(220,232,240,0.65)');spec.addColorStop(Math.min(1,strip+.13),'rgba(220,232,240,0)');spec.addColorStop(1,'rgba(220,232,240,0)');
    ctx.globalAlpha=part.strength*shine;fill(panel,spec);
    ctx.globalAlpha=part.strength;
  }
  fill(shift(SLOT,.7,1),'#131a26');fill(SLOT,'#141221');
  const core=Math.max(.06,Math.min(1,power));
  ctx.globalAlpha=part.strength*core;
  line([[0,-13],[0,7]],'rgba(255,0,255,0.14)',8);
  const coreShape=[[-.85,-11],[0,-12.5],[.85,-11],[.85,5],[0,7.5],[-.85,5]];
  const turn=h.suspendedCore?(h.coreAngle??0):0,c=Math.cos(turn),s=Math.sin(turn);
  const turnCore=points=>points.map(([x,y])=>[x*c-(y+2)*s,x*s+(y+2)*c-2]);
  if(h.suspendedCore){
    // A separate dark cradle and pale bearing read as a component inside the shell.
    ctx.globalAlpha=part.strength;
    fill(turnCore([[-2.4,-11],[0,-15],[2.4,-11],[2.4,6],[0,10],[-2.4,6]]),'#0a101b');
    line(turnCore([[-2.5,-8],[-2.5,4],[0,8],[2.5,4],[2.5,-8]]),'#b3c4d2',.55);
    ctx.globalAlpha=part.strength*core;
  }
  if(h.desync>0){
    ctx.globalAlpha=part.strength*core*h.desync*.45;
    fill(shift(turnCore(coreShape),3.2*h.desync,-1.4*h.desync),WING_COLOR);
    ctx.globalAlpha=part.strength*core;
  }
  fill(turnCore(coreShape),WING_COLOR);
  if(h.repair>0){
    const y=-10+16*(h.scan??0);
    ctx.globalAlpha=part.strength*h.repair*.75;
    line(turnCore([[-2,y],[2,y]]),'#ffbaff',.85);
  }
  ctx.globalAlpha=part.strength;
  if(h.shutters){
    // Two overlapping machined leaves close to a narrow, retained core slit.
    const aperture=Math.max(0,Math.min(1,h.aperture??1)),gap=.23+2.5*aperture;
    for(const side of [-1,1]){
      const leaf=[[side*gap,-11],[side*(gap+2.7),-9],[side*(gap+2.6),6],[side*gap,8]];
      fill(shift(leaf,.55,.65),'#060b13');fill(leaf,side<0?'#708699':'#25374a');
      line([[side*gap,-10],[side*gap,7]],side<0?'#b9c9d5':'#718a9f',.4);
    }
  }
  ctx.globalAlpha=part.strength*core;
  // Indicators stay on the hardware itself; the optional field has no tether.
  for(const side of [-1,1])line([[side*3.5,10],[side*2.8,13]],WING_COLOR,1.05);
  ctx.globalAlpha=part.strength;
  line([[-3,-14],[-4.9,-3],[-3.7,10]],'#d2dce3',.6);
  line([[.7,-20],[3,-17]],'#a0b3c4',.8);
  line([[-2,17],[0,19.5],[2,17]],'#859aae',.55);
  // Tiny recessed fasteners distinguish the plates from luminous crystals.
  for(const y of [-16,13])fill([[-.65,y-.65],[.65,y-.65],[.65,y+.65],[-.65,y+.65]],'#101723');
  if(facing)for(const {a,b,facing:brightness} of facing.faces) {
    ctx.globalAlpha=part.strength*fieldPower*brightness;
    ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);
    ctx.strokeStyle='rgba(255,0,255,0.2)';ctx.lineWidth=3.2*scale;ctx.stroke();
    ctx.strokeStyle=WING_COLOR;ctx.lineWidth=.9*scale;ctx.stroke();
  }
  energy('front');
  ctx.restore();
}
