/** Yvaelle’s Toolbox v12 · Decoy: the model (pure; no Foundry, no canvas).
 *
 * A decoy is a copy of her standing at a spot. Two ways to make one:
 *   warp   she warps away and the copy stays where she stood
 *   cast   her bits fly to a spot and cast the copy between them
 * and two looks, switchable while it stands:
 *   hardlight  plainly a projection: her picture in magenta light, scan lines, a slight flicker
 *   normal     her picture as it is (only her owner and the GM see the small mark under it)
 * It ends when it is dismissed or struck: it tears sideways and comes apart.
 *
 * One synced flag on her token says all of it, so every client draws the same decoy:
 *   flags.filament-flight.decoy = {id, kind, x, y, look, lookFrom, lookAt, at, jobs, lift, end}
 * x, y: the decoy's ground centre (scene px). at / lookAt / end.at: server ms (at may lie a little ahead: a cast
 * decoy appears as her bits arrive). lift: how far above its ground centre her copy hovers (px, negative = up;
 * her bits hold their corners round the hovering figure, not round its shadow).
 * jobs: the ids of the parked-bit jobs that hold her bits at its corners (cast). */
export const DECOY_FLAG='decoy';
export const DECOY_KINDS=Object.freeze(['warp','cast']);
export const DECOY_LOOKS=Object.freeze(['hardlight','normal']);
/** Seconds: appearing, a change of look, the whole end, and the tear that opens the end. */
export const DECOY_T=Object.freeze({born:.45,swap:.32,end:.75,tear:.3});
/** A cast decoy appears this long after her bits set off (ms): they take 0.9 s to reach their corners. */
export const DECOY_CAST_DELAY=700;
/** Her bits' corners round a cast decoy, in token sizes from the middle of her copy (the lower pair a little further: her wings hang lower than they rise). */
export const DECOY_CORNERS=Object.freeze([[-.95,-.9],[.95,-.9],[-.95,1.0],[.95,1.0]].map(Object.freeze));
const unit=x=>x<0?0:x>1?1:x,smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const finite=n=>Number.isFinite(n);
export const lookOf=v=>DECOY_LOOKS.includes(v)?v:'hardlight';
export const kindOf=v=>DECOY_KINDS.includes(v)?v:'cast';
/** A hash in [0,1) of two small integers (the bands of a look change, the cells of a break-up). */
export const h2=(a,b)=>{const x=Math.sin(a*127.1+b*311.7+.5)*43758.5453;return x-Math.floor(x);};

/** Is this a decoy flag this build can draw? */
export function validDecoy(f){
  return !!f&&typeof f==='object'&&typeof f.id==='string'&&f.id.length>0&&f.id.length<=64&&DECOY_KINDS.includes(f.kind)&&DECOY_LOOKS.includes(f.look)
    &&finite(f.x)&&finite(f.y)&&finite(f.at)&&(f.lift==null||finite(f.lift)&&Math.abs(f.lift)<=2000)&&(f.end==null||typeof f.end==='object'&&finite(f.end.at))&&(f.jobs==null||Array.isArray(f.jobs)&&f.jobs.length<=4&&f.jobs.every(j=>typeof j==='string'&&j.length<=64));
}
/** A new decoy's flag. */
export function decoyFlag({id,kind='cast',x,y,look='hardlight',now,jobs=[],lift=0,delay=0}){
  return {id:String(id),kind:kindOf(kind),x:Math.round(x),y:Math.round(y),look:lookOf(look),lookFrom:lookOf(look),lookAt:Math.round(now)-DECOY_T.swap*1000-1,at:Math.round(now+(delay>0?delay:0)),jobs:[...jobs].slice(0,4),lift:finite(lift)?Math.round(lift):0,end:null};
}
/** The flag after its look is changed at `now` (the same look again: unchanged). A change in the middle of another starts from the look it was leaving. */
export function withLook(flag,look,now){
  look=lookOf(look);if(!flag||flag.look===look||flag.end)return flag;
  return {...flag,lookFrom:flag.look,look,lookAt:Math.round(now)};
}
/** The flag once it is ended at `now` (already ending: unchanged). why: dismiss | blow | replaced. */
export function withEnd(flag,now,why='dismiss'){
  if(!flag||flag.end)return flag;
  return {...flag,end:{at:Math.round(now),why:['dismiss','blow','replaced'].includes(why)?why:'dismiss'}};
}
/** Where a decoy is at `now`:
 *   born  0..1 as it appears · mix 0 (hardlight) .. 1 (normal) · end 0..1 through its break-up
 *   phase born | stand | swap | end | gone · moving: does it need painting every frame? */
export function decoyState(flag,now){
  if(!validDecoy(flag))return {born:0,mix:0,end:1,phase:'gone',moving:false};
  const age=(now-flag.at)/1000,born=unit(age/DECOY_T.born);
  const to=flag.look==='normal'?1:0,from=flag.lookFrom==='normal'?1:0,p=finite(flag.lookAt)?unit((now-flag.lookAt)/1000/DECOY_T.swap):1,mix=from+(to-from)*smooth(p);
  if(flag.end){const end=unit((now-flag.end.at)/1000/DECOY_T.end);return {born:1,mix,end,phase:end>=1?'gone':'end',moving:end<1};}
  const phase=born<1?'born':p<1&&from!==to?'swap':'stand';
  return {born,mix,end:0,phase,moving:phase!=='stand'};
}
/** Has the break-up finished (the flag may be cleared and her bits called home)? */
export const decoyOver=(flag,now)=>!!flag?.end&&now-flag.end.at>=DECOY_T.end*1000;
/** The world points her bits hold round a cast decoy (count of them: as many as she has free, at most four). */
export function decoyCorners(x,y,size,count=4,lift=0){
  return DECOY_CORNERS.slice(0,Math.max(0,Math.min(4,count))).map(([cx,cy])=>({x:Math.round(x+cx*size),y:Math.round(y+cy*size+(finite(lift)?lift:0))}));
}
/** During a change of look the change runs through her in bands: is band i already in the normal look at mix m? */
export const bandNormal=(i,m)=>h2(i,7)<m;
/** The cells a decoy comes apart into: {x, y, s (cell px in the picture), ox, oy (from its centre), r, r2 (two hashes)}. */
export function decoyCells(w,h,step=30){
  const out=[];step=Math.max(8,step);
  for(let y=0,j=0;y<h;y+=step,j++)for(let x=0,i=0;x<w;x+=step,i++)out.push({x,y,s:step,ox:x+step/2-w/2,oy:y+step/2-h/2,r:h2(i,j),r2:h2(i+31,j+17)});
  return out;
}
/** A cell's place q (0..1) of the way through the drift: offset from where it sat, and how much of it is left. */
export function cellDrift(c,q){
  q=unit(q);const L=Math.hypot(c.ox,c.oy)+.01,e=1-(1-q)**3,d=e*(14+c.r*42);
  return {dx:c.ox/L*d+(c.r2-.5)*26*q,dy:c.oy/L*d-q*10,alpha:1-q};
}
