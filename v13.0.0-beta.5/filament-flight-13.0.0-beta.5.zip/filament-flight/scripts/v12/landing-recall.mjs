/** Landing styles (12.0.0-beta.3): what her wings do once she is down.
 * The landing itself is unchanged: the same descent, the same wingbeats, the
 * same touch-down. With a style chosen, her wings stay out through all of it
 * and settle, and only then are they recalled, by the wing rig itself:
 *  - Power down: they tear sideways, fall shut to a line of light at her
 *    shoulders, the line draws in under her and goes out.
 *  - Fold away:  they close like a fan, strip after strip from the bottom,
 *    each snapping shut, then draw in to her shoulders.
 *  - Reel in:    her filaments let go of each other and run back into her
 *    shoulders, rib by rib, a point of light at the end of each.
 * Pure numbers only: this file is also loaded by the wing paint worker. */
export const LANDING_STYLES=Object.freeze(['classic','powerdown','foldaway','reelin']);
/** How long each recall lasts, and how long her wings rest after touch-down before it starts (ms). */
export const RECALL_MS=Object.freeze({powerdown:1100,foldaway:1400,reelin:1450}),SETTLE_MS=450;
export const isRecall=style=>Object.hasOwn(RECALL_MS,style);
const unit=x=>x<0?0:x>1?1:x,seg=(t,a,b)=>unit((t-a)/(b-a)),sm=x=>{x=unit(x);return x*x*(3-2*x);},bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const easeBack=x=>{x=unit(x);const c=1.5;return 1+(c+1)*(x-1)**3+c*(x-1)**2;};
const h1=(a,b=0)=>{const s=Math.sin(a*127.1+b*311.7)*43758.5453;return s-Math.floor(s);};

/** The timing of a landing with a recall: `descent` is how long the unchanged landing lasts (ms; 0 without Flight feel). */
export function recallTiming(style,descent,flightMs){
  const recall=RECALL_MS[style],settle=descent>0?SETTLE_MS:0;
  return {duration:Math.round(descent+settle+recall),foldMs:recall,recall:style,...(descent>0?{descentMs:Math.round(descent),flightMs:Math.round(Math.min(flightMs,descent))}:{})};
}
/** Her formation p of the way through a recall (0..1): how grown, how folded and how present her wings are. */
export function recallFormation(style,p){
  if(style==='reelin')return {growth:1-seg(p,0,.92),fold:0,presence:1-sm(seg(p,.9,1))};
  if(style==='foldaway')return {growth:1-sm(seg(p,.74,1)),fold:0,presence:1-sm(seg(p,.84,1))};
  return {growth:1,fold:0,presence:1-sm(seg(p,.93,1))};
}
/** Where a point of her wing sits across the fan: 0 at the top rib … 1 at the bottom one (her art's own coordinates). */
const across=p=>unit((Math.atan2(p[1]+13,p[0]-27)+.98)/2.33);
/** Fold away: how far shut the strip through source point `p` is. Strips close from the bottom, each with a snap. */
export function stripShut(P,p){const order=1-across(p),k=seg(P,0,.8);return easeBack(seg(k,order*.55,order*.55+.34));}
/** Wrap a wing's warp for a recall. `open` is the warp as it stands; `shut()` builds the fully folded one (Fold away only). */
export function recallWarp(recall,side,open,shut){
  const P=recall.p;
  if(recall.style==='foldaway'){const closed=shut();
    return p=>{const c=stripShut(P,p),a=open(p);if(c===0)return a;const b=closed(p);return a.map((v,i)=>v+(b[i]-v)*c);};}
  if(recall.style==='powerdown'){
    const R=open([27,-13,0,0]),gl=bump(seg(P,0,.3)),col=seg(P,.24,.52)**3,ln=sm(seg(P,.56,.95)),seed=Math.floor(P*40);
    return p=>{const q=open(p).slice();
      if(gl>.01){const band=Math.floor((q[1]+320)/24);if(h1(band,seed+7)<.42)q[0]+=(h1(band,seed+3)-.5)*2*gl*46;}
      if(col>0)q[1]=R[1]+(q[1]-R[1])*(1-col*.975);
      if(ln>0)q[0]=R[0]+(q[0]-R[0])*(1-ln);
      return q;};}
  return open;
}
/** Reel in: how much of strand `id` is still out when her wings as a whole are `growth` grown. Webs and edges let go
 * first; then her ribs run home one after another, from the outside ribs inward by turns. */
export function strandGrowth(id,growth){
  const R=1-growth;if(R<=0)return 1;
  const m=/^rib-(\d+)$/.exec(id);
  if(m){const i=+m[1],ord=i%2?i/10:(9-i)/10,start=.18+ord*.5;return 1-sm(seg(R,start,start+.32));}
  let n=0;for(let i=0;i<id.length;i++)n=n*31+id.charCodeAt(i)|0;const start=h1(n&1023)*.2;
  return 1-sm(seg(R,start,start+.22));
}
/** The lights a recall adds: [material point or null, strength, width]. Reel in: the end of each rib still running
 * home. Power down: her shoulder, as the line draws in and goes out (null point = her wing root). */
export function recallLights(recall,growth,ribs){
  const out=[];
  if(recall.style==='reelin'){for(let i=0;i<ribs.length;i++){const g=strandGrowth(`rib-${i}`,growth);if(g>.02&&g<.985)out.push([i,g,1,3]);}}
  else if(recall.style==='powerdown'){const a=sm(seg(recall.p,.44,.6))*(1-sm(seg(recall.p,.86,1)));if(a>.02)out.push([null,0,a,3.4]);}
  return out;
}

/** (12.0.0-beta.4) When a landing recalls her bits: {hold, duration} in ms from the landing's start.
 * Her wings close in the last foldMs of a landing (a style recalls them in its last `recall` ms), so her bits wait
 * for that moment and are recalled over it (a style: over its first three quarters, the bits are in before the last
 * of her wings). A landing without a wing sequence, or one whose fold is the whole landing, recalls them at once
 * over `base`, as every landing did before. */
export function landingBitTiming(transition,base){
  const t=transition,fold=t&&t.kind==='landing'&&t.wings&&t.foldMs>0&&t.duration>t.foldMs?t.foldMs:0;
  return fold?{hold:t.duration-fold,duration:t.recall?Math.round(fold*.75):fold}:{hold:0,duration:base};
}
