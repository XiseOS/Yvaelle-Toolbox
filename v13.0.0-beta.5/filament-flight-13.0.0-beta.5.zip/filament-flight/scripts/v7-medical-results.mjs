/** Local repair endings for the eight bit-performed V7 treatments.
 *
 * The work painter owns the source-to-patient contact. These paths complete or
 * release that same small repair site; they never invent a separate machine,
 * enclosure or success aura. Coordinates are patient-local (100 = one token).
 */
import {V7_MEDICAL_WORK_SPECS,sampleV7MedicalSite,sampleV7FinishingSite,v7MedicalCompletionProgress} from './v7-medical-work.mjs?v=13.0.0-beta.5';
const TAU = Math.PI * 2;
const clamp = (n, a = 0, b = 1) => Math.max(a, Math.min(b, Number.isFinite(n) ? n : 0));
const smooth = n => { n = clamp(n); return n * n * (3 - 2 * n); };
const mix = (a, b, p) => a + (b - a) * p;
const PINK = '#ff49d5', PEARL = '#ffcbe9', ICE = '#badfff', WHITE = '#fff0fc', GOLD = '#eecaad';
const outcomes = Object.freeze(['criticalFailure', 'failure', 'success', 'criticalSuccess']);
export const V7_MEDICAL_RESULT_STYLES = Object.freeze([
  'capillaryBridge', 'irisPatch', 'segmentedCradle', 'lymphaticCircuit',
  'fibrilRepair', 'tissueLens', 'pulseReservoir', 'petalSanctuary'
]);
const styles = new Set(V7_MEDICAL_RESULT_STYLES);
// Three patient-local units of guard remain outside every authored point.
const bounds = Object.freeze({ x: -27, y: -19, width: 54, height: 50 });
export function v7MedicalResultBounds(effect) {
  return styles.has(typeof effect === 'string' ? effect : effect?.style) ? { ...bounds } : null;
}

export function sampleV7MedicalResult(effect = {}) {
  const { style, outcome } = effect;
  const p = clamp(effect.progress), strength = clamp(effect.strength ?? 1, 0, 2);
  const valid = styles.has(style) && outcomes.includes(outcome);
  const envelope = valid && p > 0 && p < 1 ? smooth(p / .14) * smooth((1 - p) / .19) : 0;
  const gain = strength * envelope;
  const count = clamp(effect.emitters?.length || effect.count || 1, 1, 4);
  const frame = {
    effect: 'token-field', id: `medical-result-${style}`, color: '#ff00ff',
    strength: gain, count, paths: [],
    bounds: v7MedicalResultBounds(effect), phase: 'finishing', outcome,
    medicalOutcome: true, localRepair: true
  };
  if (!valid || effect.phase !== 'finishing' || !gain) return frame;
  const quality = effect.detail === 'low' ? 0 : effect.detail === 'high' ? 2 : 1;
  const steps = quality === 0 ? 8 : quality === 2 ? 16 : 12;
  // Reduced motion fixes all point geometry; only the common fade progresses.
  const q = effect.animated === false ? .62 : smooth(p);
  const good = outcome === 'success' || outcome === 'criticalSuccess';
  const critical = outcome === 'criticalSuccess', stopped = outcome === 'criticalFailure';
  const fixedProgress = effect.animated === false ? .62 : p;
  const seat = v7MedicalCompletionProgress(fixedProgress), release = smooth(fixedProgress / .78);
  const time = effect.animated === false ? V7_MEDICAL_WORK_SPECS[style].period : Math.max(0, Number(effect.clock) || 0);
  const site = good && effect.animated !== false ? sampleV7FinishingSite(style,count,time,fixedProgress) : sampleV7MedicalSite(style,count,time);
  const point = p => [p.x * 100, p.y * 100];
  const add = (points, {
    alpha = .8, width = .85, closed = false, fill = 0, tint = PINK,
    fillTint = tint, highlight = false, glow = false, role = 'result-local-repair', plane = 'front'
  } = {}) => {
    if (points.length < 2 || alpha <= 0) return;
    frame.paths.push({ points, alpha: clamp(alpha * gain), width, closed,
      fill: clamp(fill * gain, 0, .14), tint, fillTint, highlight,
      glow: glow && quality > 0, role, plane });
  };
  const line = (a, b, o) => add([a, b], o);
  const curve = (fn, o = {}) => {
    const n = o.steps ?? steps;
    const points = new Array(n + 1);
    for (let i = 0; i <= n; i++) points[i] = fn(i / n);
    add(points, o);
  };
  const bezier = (a, b, c, d) => u => {
    const v = 1 - u;
    return [v ** 3 * a[0] + 3 * v * v * u * b[0] + 3 * v * u * u * c[0] + u ** 3 * d[0],
      v ** 3 * a[1] + 3 * v * v * u * b[1] + 3 * v * u * u * c[1] + u ** 3 * d[1]];
  };
  const cubic = (a, b, c, d, o) => curve(bezier(a, b, c, d), o);
  const seal = (point, tangent = [0, 1], alpha = .82) => {
    const normal = [-tangent[1], tangent[0]], size = 2.3;
    line([point[0] - normal[0] * size, point[1] - normal[1] * size],
      [point[0] + normal[0] * size, point[1] + normal[1] * size],
      { alpha, width: 1.35, tint: stopped ? GOLD : PEARL, highlight: good,
        role: stopped ? 'result-safety-stop' : 'result-seated-join' });
  };
  const verify = (route, { delay = 0, ...o } = {}) => {
    if (!critical) return;
    const proofAlpha = smooth((q - .25 - delay) / .25) * .68;
    curve(route, { alpha: proofAlpha, tint: ICE, width: .65, role: 'result-verification', ...o });
    const packetGain = smooth((q - .28 - delay) / .13);
    if (packetGain <= 0) return;
    const head = smooth((q - .29 - delay) / .54), tail = Math.max(0, head - .23);
    curve(u => route(mix(tail, head, u)), { steps: 5, alpha: packetGain * .98,
      tint: WHITE, width: 2, highlight: true, glow: true,
      role: 'result-verification-packet', ...o });
  };
  const splitRoute = (route, gap = .12, o = {}) => {
    curve(u => route(u * (.5 - gap)), o);
    curve(u => route(.5 + gap + u * (.5 - gap)), o);
  };
  // Identical corner-authored cubic edges to the work painter's care film.
  // A result seats the film already being laid, instead of replacing it with
  // an unrelated capsule. The leading edge comes from the shared work site.
  const filmEdges = (left,right,top,bottom,bow = 0) => {
    const x=(left+right)/2,w=(right-left)/2,y=(top+bottom)/2,h=(bottom-top)/2;
    const a=[left,top],b=[right,top],c=[right,bottom],d=[left,bottom];
    return [bezier(a,[x-w*.5,top-bow],[x+w*.5,top-bow],b),
      bezier(b,[right+2,y-h*.5],[right+2,y+h*.5],c),
      bezier(c,[x+w*.5,bottom+bow],[x-w*.5,bottom+bow],d),
      bezier(d,[left-2,y+h*.5],[left-2,y-h*.5],a)];
  };
  const filmOutline = edges => edges.flatMap(edge=>Array.from({length:(quality?4:3)+1},(_,i)=>edge(i/(quality?4:3))));
  const localAxis = endpoints => u=>[mix(endpoints[0][0],endpoints[1][0],u),mix(endpoints[0][1],endpoints[1][1],u)];
  const shifted = (v,offset)=>[v[0]+Math.sign(v[0])*offset,v[1]];
  const joinedPoint = (v)=>[v[0]*(site.contraction??(1-seat*.75)),v[1]];
  const stitchRoute = stitch => {
    const convert = v => good ? joinedPoint(point(v)) : shifted(point(v),release*3);
    return bezier(convert(stitch.start),convert(stitch.controlA),convert(stitch.controlB),convert(stitch.end));
  };

  if (style === 'capillaryBridge') {
    const gap = good ? mix(5, .8, seat) : mix(5, stopped ? 5.7 : 8, release);
    for (const s of [-1, 1]) cubic([s * gap, -10], [s * (gap + 1), -1], [s * (gap - .8), 13], [s * gap, 22],
      { alpha: good ? .55 : .32, width: .65, tint: PEARL });
    // The infused tissue resolves into three short joined capillary seams.
    for (let i = 0; i < 3; i++) {
      const y = -4 + i * 10, route = bezier([-gap, y - 2], [-gap * .4, y + 1], [gap * .4, y - 1], [gap, y + 2]);
      if (good) { curve(route, { alpha: .66 + seat * .24, width: 1.1, highlight: true }); seal([0, y], [0, 1], seat * .68); }
      else { const opened = stopped ? .17 : .2 + .16 * release; splitRoute(route, opened, { alpha: .66 - .21 * release, width: .75, tint: PEARL });
        if (stopped) { seal(route(.5 - opened)); seal(route(.5 + opened)); } }
    }
    if (good) curve(u => [.4 * Math.sin(u * Math.PI), mix(-10, 22, u)], { alpha: seat * .65, width: 1.05, highlight: true });
    verify(u => [.4 * Math.sin(u * Math.PI), mix(-10, 22, u)]);
  } else if (style === 'irisPatch') {
    const gap = site.gap * 100 * (good ? 1-seat : 1) + (good ? 0 : release*3);
    for (const s of [-1, 1]) {
      cubic([s*gap,-10],[s*(gap+2),0],[s*(gap+1),13],[s*gap,22],
        { alpha: .70, width: good ? 1.35 : .85, highlight: good, tint: PEARL,role:'result-pressure-margin' });
    }
    const seam = u => point(site.seam(u));
    if(good)add(filmOutline(filmEdges(-gap-2,gap+2,-9,21,2)),{closed:true,fill:.045,alpha:.30,tint:PINK,width:.65});
    if (good) curve(seam, { alpha: seat * .88, width: 1.15, highlight: true });
    else { splitRoute(seam, stopped ? .11 : .16 + release * .11, { alpha: .42, width: .65, tint: PEARL });
      if (stopped) { seal([-gap, 6]); seal([gap, 6]); } }
    verify(seam);
  } else if (style === 'segmentedCradle') {
    // These exact held ends become the aligned ends. The support strips sit
    // at the same two axis fractions as the bit-operated work painter.
    const ends=site.endpoints.map((v,i)=>{
      const a=point(v),b=point(site.alignedEndpoints[i]);return good?[mix(a[0],b[0],seat),mix(a[1],b[1],seat)]:a;
    }),axis=localAxis(ends),angle=Math.atan2(ends[1][1]-ends[0][1],ends[1][0]-ends[0][0]);
    const tangent=[Math.cos(angle),Math.sin(angle)];
    for (const u of [.28, .72]) {
      const [x,y]=axis(u),tr=([a,b])=>[x+a*Math.cos(angle)-b*Math.sin(angle),y+a*Math.sin(angle)+b*Math.cos(angle)];
      cubic(tr([-2,-7]),tr([3,-4]),tr([3,4]),tr([-2,7]),{alpha:.76,width:1.6,tint:PEARL,highlight:good});
      if(stopped)seal(axis(u),tangent);
    }
    if (good) { curve(axis, { alpha: .8, width: 1.15, highlight: true,role:'result-seated-axis' });
      for (const u of [.28, .72]) seal(axis(u), tangent, seat * .8); }
    else splitRoute(axis, stopped ? .1 : .1 + .16 * release, { alpha: .57, width: .75, tint: PEARL });
    verify(axis);
  } else if (style === 'lymphaticCircuit') {
    // The washed surface is local and soft, with outward impurity withdrawal.
    const wash = bezier([-15, -4], [-7, -3], [7, 15], [15, 16]);
    if (good) {
      curve(wash, { alpha: .82, width: 1.05, highlight: true });
      for (const offset of [-2.8, 2.8]) curve(u => { const at = wash(u); return [at[0], at[1] + offset * Math.sin(u * Math.PI)]; },
        { alpha: seat * .52, width: .6, tint: PEARL });
      for (const u of [.24, .74]) { const [x, y] = wash(u); cubic([x - 2.1, y + 1.4], [x - .8, y + 2.1], [x + .6, y + 2], [x + 2.1, y + 1.2], { alpha: seat * .73, width: .85, highlight: true }); }
    } else {
      splitRoute(wash, stopped ? .12 : .13 + .13 * release, { alpha: .57, width: .75, tint: PEARL });
      for (let i = 0; i < 3; i++) {
        const at = wash(.22 + i * .26), x = at[0] + (i % 2 ? 1 : -1) * release * 2, y = at[1] - release * (stopped ? 2 : 5);
        line([x - .9, y], [x + .9, y + .7], { alpha: .66 - release * .14, width: .8, tint: stopped ? GOLD : PEARL, role: 'result-returning-impurity' });
      }
      if (stopped) seal(wash(.5), [Math.SQRT1_2, Math.SQRT1_2]);
    }
    verify(wash);
  } else if (style === 'fibrilRepair') {
    // Stitch row count, rotation, anchors and control points are all authored
    // by the same site that moves the needles. No second diagonal seam exists.
    for (let i = 0; i < site.stitches.length; i++) {
      const stitch=site.stitches[i],route=stitchRoute(stitch),built=stitch.progress;
      if(built<=0)continue;
      if (good) {
        curve(u=>route(u*built),{alpha:.86*built,width:1.15,highlight:true,role:'result-seated-stitch'});
        const a=route(0);if(built>.95)line(a,[a[0]+1.1,a[1]+1.3],{alpha:.82,width:1.1,tint:GOLD,role:'result-seated-join'});
      } else {
        // An unjoined row retains the real material anchors and opens locally.
        splitRoute(u=>route(u*built),stopped?.12:.14+.08*release,{alpha:.64-release*.12,width:.75,tint:PEARL,role:'result-unjoined-stitch'});
        if (stopped && (i === 0 || i === site.stitches.length - 1)) {
          seal(route(.38*built),[.955,-.296]);seal(route(.62*built),[.955,-.296]);
        }
      }
      verify(u=>route(u*built),{delay:i*.012});
    }
    if(!frame.paths.length){
      const at=point(site.needleContact);
      if(stopped)seal(at,[.955,-.296]);
      else line([at[0]-.7,at[1]],[at[0]+.7,at[1]+(good?0:1.1)],{alpha:.38,width:.6,tint:PEARL,role:good?'result-active-contact':'result-released-contact'});
    }
  } else if (style === 'tissueLens') {
    const built=Math.max(site.materialProgress,good?seat:0),trace=u=>point(site.trace(u*built));
    if(good)curve(trace,{alpha:.86,width:1.35,highlight:true,role:'result-seated-trace'});
    else {
      splitRoute(trace,stopped?.1:.12+.07*release,{alpha:.68-release*.14,width:.8,tint:PEARL,role:'result-unjoined-trace'});
      if(stopped){seal(trace(.4),[.65,.76]);seal(trace(.6),[.65,.76]);}
      else line([-4-release,2],[-1-release,4],{alpha:.48,width:.65,tint:PEARL,role:'result-released-contact'});
    }
    verify(trace);
  } else if (style === 'pulseReservoir') {
    const amplitude = good ? mix(1.15, .82, seat) : mix(1, stopped ? .62 : 1.3, release);
    const wave = u => [mix(-12, 12, u), 6 + Math.sin(u * TAU) * 5.8 * amplitude];
    if (good) {
      curve(wave, { alpha: .9, width: 1.25, highlight: true });
      // A smaller inward cadence seats the same central contact softly.
      cubic([-5, 6], [-2.8, 3.6], [2.8, 8.4], [5, 6], { alpha: seat * .61, width: .7, tint: PEARL });
    } else {
      splitRoute(wave, stopped ? .13 : .16 + .07 * release, { alpha: .73 - .12 * release, width: .85, tint: PEARL });
      if (stopped) { seal(wave(.37), [1, 0]); seal(wave(.63), [1, 0]); }
      else cubic([-2.5, 8 + release], [-1, 10 + release], [1, 10 + release], [2.5, 8 + release], { alpha: .37, tint: PEARL, width: .7 });
    }
    verify(wave);
  } else if (style === 'petalSanctuary') {
    const top=point(site.corners[0]),right=point(site.corners[1]),targetBottom=site.corners[2].y*100;
    const endY=good?mix(site.filmEdge[0].y*100,targetBottom,seat):site.filmEdge[0].y*100;
    const height=Math.max(0,(endY-top[1])/2),bow=Math.min(2,height*.2)*(good?1-seat:1);
    const edges=filmEdges(top[0],right[0],top[1],endY,bow),leadingEdge=bezier([top[0],endY],[top[0]*.5,endY+2],[right[0]*.5,endY+2],[right[0],endY]);
    if (good) {
      add(filmOutline(edges),{closed:true,fill:.075,alpha:.72,tint:PEARL,width:.8,role:'result-seated-dressing'});
      curve(leadingEdge,{alpha:.85*seat,width:1.25,highlight:true,role:'result-bonded-film-edge'});
    } else {
      // The deposited film keeps its real top/corner anchors while its two
      // unbonded leading-edge halves disengage. It never becomes an enclosure.
      for(const index of [0,1,3])curve(edges[index],{alpha:.56-release*.12,width:.75,tint:PEARL,role:'result-released-film'});
      const gap=stopped?.1:.12+.08*release;
      splitRoute(leadingEdge,gap,{alpha:.68-release*.14,width:.85,tint:PEARL,role:'result-unbonded-film-edge'});
      if(stopped){seal(leadingEdge(.5-gap),[1,0]);seal(leadingEdge(.5+gap),[1,0]);}
    }
    verify(leadingEdge);
  }
  return frame;
}
