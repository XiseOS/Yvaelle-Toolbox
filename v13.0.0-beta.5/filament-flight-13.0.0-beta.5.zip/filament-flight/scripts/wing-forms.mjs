/** Compatibility for saved v7.7 form preferences. Only the original wing
 * remains available; removed forms never supply geometry or actor reactions. */
export const FORM_IDS=Object.freeze(['original']);
export const WING_FORMS=Object.freeze({original:'Original wings'});
export const WING_FORM_DESCRIPTIONS=Object.freeze({original:'Ellie’s original filament wing structure.'});
export const WING_FORM_GROUPS=Object.freeze({});
export const WING_FORM_GROUP_LABELS=Object.freeze({});
export function validateWingForm(id){
  if(id!=='original')throw new Error('Only the original wings are available.');
  return 'original';
}
export function readSavedWingForm(id){
  if(id!=null&&typeof id!=='string')throw new Error('Invalid saved wing form.');
  return 'original';
}
export function sampleWingForm(){return null;}
