/** Finite, local menu motion. No scene writes, frame loop, canvas clone or input lock. */
const finite=(value,fallback)=>Number.isFinite(value)?value:fallback;
const reduce=win=>{try{return Boolean(win?.matchMedia?.('(prefers-reduced-motion: reduce)').matches);}catch{return false;}};

export function hudMotionOptions(model={}) {
  const theme=model.prefs?.theme??model.theme??{};
  return {enabled:theme.motion!==false&&!model.cfg?.reduced&&!model.cfg?.reducedMotion&&!reduce(globalThis.window),strength:Math.max(0,Math.min(1,finite(theme.motionStrength,.75)))};
}

export function createHUDMotion(options={}) {return new HUDMotion(options);}

export class HUDMotion {
  constructor(options={}) {this.active=new Map();this.bindings=new Set();this.disclosures=new WeakMap();this.destroyed=false;this.configure(options);}
  configure({enabled=true,strength=.75}={}) {
    this.enabled=enabled!==false;this.strength=Math.max(0,Math.min(1,finite(strength,.75)));
    if(!this.enabled||!this.strength)this.cancel();return this;
  }
  canAnimate(element) {return !this.destroyed&&this.enabled&&this.strength>0&&element?.isConnected!==false&&!element?.ownerDocument?.hidden&&!reduce(element?.ownerDocument?.defaultView)&&typeof element?.animate==='function';}
  sample(element) {
    try {const style=element.ownerDocument?.defaultView?.getComputedStyle?.(element);return {opacity:style?.opacity??'1',transform:style?.transform??'none'};}catch{return {opacity:1,transform:'none'};}
  }
  stop(element) {const record=this.active.get(element);if(record)record.settle(false);}
  animate(element,frames,{duration=190,easing='cubic-bezier(.2,.75,.25,1)',finish}={}) {
    this.stop(element);
    if(!this.canAnimate(element)){finish?.();return Promise.resolve(false);}
    let animation,resolve,watchdog;
    const result=new Promise(done=>{resolve=done;});
    const record={settle:completed=>{
      if(this.active.get(element)!==record)return;
      this.active.delete(element);clearTimeout(watchdog);animation.onfinish=null;animation.oncancel=null;
      try{animation.cancel();}catch{}finish?.();resolve(completed);
    }};
    try{animation=element.animate(frames,{duration:duration*(.7+.3*this.strength),easing,fill:'both'});}
    catch{finish?.();resolve(false);return result;}
    this.active.set(element,record);animation.onfinish=()=>record.settle(true);animation.oncancel=()=>record.settle(false);
    // Some embedded browser surfaces pause the compositor timeline while a
    // dialog closes. A finite deadline guarantees cleanup and never loops.
    watchdog=setTimeout(()=>record.settle(false),duration*(.7+.3*this.strength)+120);
    return result;
  }
  enter(element,{kind='page',direction=1,from}={}) {
    if(!element)return Promise.resolve(false);
    const interrupted=this.active.has(element)?this.sample(element):null,s=this.strength,d=direction<0?-1:1;
    const vertical=['flight','settings','back','disclosure'].includes(kind);
    const shift=(kind==='group'?18:kind==='library'?9:12)*s;
    const transform=vertical?`translateY(${(kind==='back'?-1:1)*shift}px)`:`translateX(${d*shift}px)`;
    return this.animate(element,[from??interrupted??{opacity:.28,transform},{opacity:1,transform:'none'}],{duration:kind==='group'?210:190});
  }
  exit(element,{kind='page',direction=1}={}) {
    if(!element)return Promise.resolve(false);
    const start=this.sample(element),distance=(direction<0?-1:1)*8*this.strength;
    return this.animate(element,[start,{opacity:0,transform:['settings','back','disclosure'].includes(kind)?`translateY(${-distance}px)`:`translateX(${-distance}px)`}],{duration:110});
  }
  /** Reuse the outgoing DOM as an inert, short-lived layer. The incoming
   * controls are live immediately; cancelling removes the old layer at once. */
  swipe(element,outgoing,{direction=1,from,outgoingFrame,host}={}) {
    if(!element||!outgoing||element===outgoing||!host||!this.canAnimate(element))return this.enter(element,{kind:'group',direction,from});
    const rect=element.getBoundingClientRect(),base=host.getBoundingClientRect(),document=element.ownerDocument;
    const clip=document.createElement('div');clip.className='ff-motion-outgoing';clip.setAttribute('aria-hidden','true');clip.inert=true;
    Object.assign(clip.style,{position:'absolute',left:`${rect.left-base.left+host.scrollLeft}px`,top:`${rect.top-base.top+host.scrollTop}px`,width:`${rect.width}px`,height:`${Math.max(rect.height,outgoing.getBoundingClientRect?.().height??0)}px`,overflow:'hidden',pointerEvents:'none',zIndex:'4'});
    // IDs must remain unique while old controls are briefly visible.
    outgoing.removeAttribute?.('id');outgoing.removeAttribute?.('data-ff-motion');for(const node of outgoing.querySelectorAll?.('[id],[data-ff-motion]')??[]){node.removeAttribute('id');node.removeAttribute('data-ff-motion');}
    outgoing.inert=true;Object.assign(outgoing.style,{width:`${rect.width}px`,margin:'0'});clip.append(outgoing);host.append(clip);
    const d=direction<0?-1:1,distance=Math.max(24,rect.width)*(.45+.55*this.strength);
    const previous=outgoingFrame??{opacity:1,transform:'none'};
    const leave=this.animate(outgoing,[previous,{opacity:0,transform:`translateX(${-d*distance}px)`}],{duration:235,finish:()=>clip.remove()});
    const enter=this.animate(element,[from??{opacity:.35,transform:`translateX(${d*distance}px)`},{opacity:1,transform:'none'}],{duration:235});
    return Promise.all([leave,enter]);
  }
  feedback(element,{kind='press'}={}) {
    if(!element)return Promise.resolve(false);
    const s=this.strength;
    return this.animate(element,kind==='arrival'?[{opacity:.55,transform:`scale(${1-.13*s})`},{opacity:1,transform:`scale(${1+.08*s})`,offset:.55},{opacity:1,transform:'none'}]:[{transform:'none'},{transform:`scale(${1-.035*s})`,offset:.35},{transform:'none'}],{duration:kind==='arrival'?290:150});
  }
  fold(element,open,{fromHeight}={}) {
    if(!element)return Promise.resolve(false);
    const start=fromHeight??element.getBoundingClientRect?.().height??0;
    this.stop(element);const original={height:element.style.height,overflow:element.style.overflow};
    element.hidden=false;element.style.height='auto';const natural=element.getBoundingClientRect?.().height??0;
    element.style.overflow='hidden';
    return this.animate(element,[{height:`${open?fromHeight??0:start}px`,opacity:open?.25:1},{height:`${open?natural:0}px`,opacity:open?1:0}],{duration:190,finish:()=>{Object.assign(element.style,original);element.hidden=!open;}});
  }
  /** Animate native details without replacing its controls or delaying a click. */
  toggleDisclosure(details,open=!details.open) {
    const existing=this.disclosures.get(details),start=details.getBoundingClientRect?.().height??0;
    this.stop(details);
    const restore=existing?.restore??{height:details.style.height,overflow:details.style.overflow,boxSizing:details.style.boxSizing};
    const state={open,restore};this.disclosures.set(details,state);
    const clean=()=>{if(this.disclosures.get(details)!==state)return;details.open=open;Object.assign(details.style,restore);this.disclosures.delete(details);};
    if(!this.canAnimate(details)){clean();return Promise.resolve(false);}
    // Measure both destinations synchronously; native toggle events coalesce to
    // the final state. Closing stays open while its visible content contracts.
    details.style.height='auto';details.open=open;
    const end=details.getBoundingClientRect?.().height??start;
    details.open=true;details.style.overflow='hidden';details.style.boxSizing='border-box';
    return this.animate(details,[{height:`${start}px`},{height:`${end}px`}],{duration:190,finish:clean});
  }
  bindDisclosures(root,{signal}={}) {
    if(!root?.addEventListener||this.destroyed)return ()=>{};
    const click=event=>{
      const summary=event.target?.closest?.('summary'),details=summary?.parentElement;
      if(!summary||details?.tagName!=='DETAILS'||!root.contains(details)||event.defaultPrevented)return;
      if(event.target.closest?.('button,a,input,select,textarea'))return;
      event.preventDefault();const pending=this.disclosures.get(details);
      void this.toggleDisclosure(details,!(pending?.open??details.open));
    };
    const document=root.ownerDocument,visibility=()=>{if(document.hidden)this.cancel();};
    let media;try{media=document.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)');}catch{}
    const preference=()=>{if(media?.matches)this.cancel();};
    const clean=()=>{root.removeEventListener('click',click);document?.removeEventListener('visibilitychange',visibility);media?.removeEventListener?.('change',preference);signal?.removeEventListener?.('abort',clean);this.bindings.delete(clean);};
    root.addEventListener('click',click);document?.addEventListener('visibilitychange',visibility);media?.addEventListener?.('change',preference);signal?.addEventListener?.('abort',clean,{once:true});this.bindings.add(clean);
    if(signal?.aborted)clean();return clean;
  }
  cancel() {for(const record of [...this.active.values()])record.settle(false);}
  destroy() {this.destroyed=true;this.cancel();for(const clean of [...this.bindings])clean();}
}
