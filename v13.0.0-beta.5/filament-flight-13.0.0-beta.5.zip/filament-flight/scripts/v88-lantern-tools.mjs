/** Saved tools contain only the explicit player choice. Moving subjects are
 * resolved locally and never publish coordinates or write a flag each frame. */
export const LIGHT_PRESET_LABELS=Object.freeze({closeWork:'Close work',travel:'Travel',search:'Search'});
export const LIGHT_PRESET_DEFAULTS=Object.freeze({
  closeWork:Object.freeze({width:100,bright:5,dim:10,intensity:.45}),
  travel:Object.freeze({width:90,bright:15,dim:30,intensity:.65}),
  search:Object.freeze({width:35,bright:25,dim:60,intensity:.8})
});
const PRESET_RANGES=Object.freeze({width:[15,180],bright:[0,120],dim:[0,120],intensity:[0,1]});
const id=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(value);
const plain=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
const heading=value=>((value%360)+360)%360;
const finitePoint=p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y)&&Math.abs(p.x)<=1e7&&Math.abs(p.y)<=1e7;
const subjectOrigin=token=>token?.document?.getLightOrigin?.({x:token.x,y:token.y})??token?.center;

export function lightPresetId(value){
  if(typeof value!=='string'||!Object.hasOwn(LIGHT_PRESET_DEFAULTS,value))throw new Error('Choose Close work, Travel or Search.');
  return value;
}
export function normalizeLightPreset(value){
  if(!plain(value)||Object.keys(value).length!==4||Object.keys(value).some(key=>!Object.hasOwn(PRESET_RANGES,key)))throw new Error('A light preset needs width, bright, dim and intensity.');
  const out={};
  for(const [key,[min,max]]of Object.entries(PRESET_RANGES)){
    if(!Number.isFinite(value[key])||value[key]<min||value[key]>max)throw new Error(`Light preset ${key} must be between ${min} and ${max}.`);
    out[key]=value[key];
  }
  if(out.dim<out.bright)throw new Error('A light preset dim distance must include its bright distance.');
  return out;
}
export function normalizeLightPresets(value){
  if(value==null)return null;
  if(!plain(value)||Object.keys(value).some(key=>!Object.hasOwn(LIGHT_PRESET_DEFAULTS,key)))throw new Error('Invalid saved light presets.');
  return Object.fromEntries(Object.entries(value).map(([key,preset])=>[key,preset===null?null:normalizeLightPreset(preset)]));
}
export function lightPreset(settings,presetId){
  presetId=lightPresetId(presetId);
  const saved=normalizeLightPresets(settings?.presets);
  return {...(saved?.[presetId]??LIGHT_PRESET_DEFAULTS[presetId])};
}
/** Both native light modes retain their own enable state and magenta colour.
 * Width belongs to the directional mode; distances and brightness apply to
 * whichever mode is currently active and are ready for the next mode switch. */
export function lightPresetPatch(settings,presetId){
  const preset=lightPreset(settings,presetId);
  return {lantern:preset,lightBright:preset.bright,lightDim:preset.dim,lightIntensity:preset.intensity};
}
export function saveLightPresetPatch(settings,presetId,current){
  presetId=lightPresetId(presetId);
  const preset=normalizeLightPreset(current??Object.fromEntries(Object.keys(PRESET_RANGES).map(key=>[key,settings?.[key]])));
  return {presets:{...normalizeLightPresets(settings?.presets),[presetId]:preset}};
}
export function resetLightPresetPatch(settings,presetId){
  presetId=lightPresetId(presetId);
  // A null slot explicitly replaces a recursively merged Foundry flag.
  return {presets:{...normalizeLightPresets(settings?.presets),[presetId]:null}};
}

export function normalizeLanternLock(value){
  if(value===null)return null;
  if(!plain(value)||!['point','token'].includes(value.type)||!id(value.sceneId)||Object.keys(value).some(key=>!['type','sceneId','tokenId','x','y'].includes(key)))throw new Error('Invalid lantern subject lock.');
  if(value.type==='point'){
    if(!finitePoint(value)||value.tokenId!=null)throw new Error('A lantern point lock needs a finite point in its scene.');
    return {type:'point',sceneId:value.sceneId,tokenId:null,x:value.x,y:value.y};
  }
  if(!id(value.tokenId)||value.x!=null||value.y!=null)throw new Error('A lantern token lock needs its scene and token identity.');
  // Explicit nulls prevent obsolete fields surviving Foundry's nested merge.
  return {type:'token',sceneId:value.sceneId,tokenId:value.tokenId,x:null,y:null};
}
export function lanternSubjectVisible(token,{scene=globalThis.canvas?.scene,source}={}){
  const doc=token?.document;
  if(!token||!doc||token===source||token.destroyed||token.isPreview||token._original||doc.hidden||doc.parent!==scene||scene?.tokens?.get?.(doc.id)!==doc)return false;
  if(!token.mesh||token.mesh.visible===false||token.mesh.renderable===false||token.visible===false||token.renderable===false||token.isVisible===false||token.detectionFilter)return false;
  return token.isVisible===true||token.visible===true;
}
export function lanternLockForSubject(source,subject,{scene=globalThis.canvas?.scene,tokens=globalThis.canvas?.tokens}={}){
  source=source?.object??source;
  if(!globalThis.canvas?.ready||!source?.document?.isOwner||source.document.hidden||source.document.parent!==scene||scene?.tokens?.get?.(source.id)!==source.document||source.destroyed||source.isPreview)throw new Error('Choose your owned lantern token in the current scene.');
  let token;
  if(typeof subject==='string')token=tokens?.get?.(subject)??scene.tokens?.get?.(subject)?.object;
  else if(subject?.document||subject?.object)token=subject.object??subject;
  if(token){
    if(!lanternSubjectVisible(token,{scene,source}))throw new Error('Choose a currently visible token in this scene.');
    return normalizeLanternLock({type:'token',sceneId:scene.id,tokenId:token.id});
  }
  if(!plain(subject)||Object.keys(subject).some(key=>!['x','y'].includes(key))||!finitePoint(subject))throw new Error('Choose a visible token or a finite canvas point.');
  if(!globalThis.game?.user?.isGM&&globalThis.canvas?.visibility?.testVisibility?.(subject,{tolerance:0,object:null})===false)throw new Error('Choose a canvas point you can see.');
  return normalizeLanternLock({type:'point',sceneId:scene.id,x:subject.x,y:subject.y});
}
/** Never read a hidden subject's position: loss of visibility retains the
 * last safe world heading, including when the subject moves out of sight. */
export function resolveLanternLock(source,lock,{scene=globalThis.canvas?.scene,tokens=globalThis.canvas?.tokens,fallbackAngle=0}={}){
  source=source?.object??source;
  const fallback=heading(Number.isFinite(fallbackAngle)?fallbackAngle:0);
  if(!lock)return {angle:fallback,status:'none'};
  if(!scene||source?.document?.parent!==scene||lock.sceneId!==scene.id)return {angle:fallback,status:'unavailable'};
  let point;
  if(lock.type==='point')point=lock;
  else{
    const token=tokens?.get?.(lock.tokenId)??scene.tokens?.get?.(lock.tokenId)?.object;
    if(!lanternSubjectVisible(token,{scene,source}))return {angle:fallback,status:'unavailable'};
    point=token.center;
  }
  const origin=subjectOrigin(source);
  if(!finitePoint(origin)||!finitePoint(point)||Math.hypot(point.x-origin.x,point.y-origin.y)<4)return {angle:fallback,status:'unavailable'};
  return {angle:heading(Math.atan2(point.y-origin.y,point.x-origin.x)*180/Math.PI),status:'tracking'};
}
