/** Categories organize the shared condition-animation library; assignments stay independent. */
export const CONDITION_IDS=Object.freeze(['normal','damaged','unstable','glitching','overdrive','suppressed','collapsed']);
export const REACTION_IDS=Object.freeze(['damage','critical','heal','flare','pulse','stutter','reform']);
export const CURATED_CONDITION_IDS=Object.freeze({normal:Object.freeze(['breathing','roseLattice']),damaged:Object.freeze(['fraying','scarStitch']),unstable:Object.freeze(['recoil','torsion']),glitching:Object.freeze(['phaseTears','memoryEcho']),overdrive:Object.freeze(['corona','circuit']),suppressed:Object.freeze(['binding','drain']),collapsed:Object.freeze(['unravelling','seedRecall'])});
export const LEGACY_ANIMATED_CONDITIONS=Object.freeze({damaged:'legacyDamaged',overdrive:'legacyOverdrive'});
export const legacyAnimationCategory=id=>Object.keys(LEGACY_ANIMATED_CONDITIONS).find(key=>LEGACY_ANIMATED_CONDITIONS[key]===id)??null;
export const isLegacyAnimated=(_condition,id)=>legacyAnimationCategory(id)!==null;
export const ADVANCED_CONDITION_IDS=Object.freeze(['threadSlip','faultRepair','standingWaves','energyStarvation','surgeRouting','phaseSeparation']);
/** V3.2 additions are separate from existing defaults; saved artwork never changes. */
export const DISTINCT_CONDITION_IDS=Object.freeze({
  normal:Object.freeze(['irisWindows','pleatedFan','chainLace']),
  damaged:Object.freeze(['loadBridges','veilDelamination','stressBlisters']),
  unstable:Object.freeze(['wanderingFocus','tipChase','alternatingBow']),
  glitching:Object.freeze(['topologySwap','polygonCompile','rotatingTiles']),
  overdrive:Object.freeze(['acceleratorLoops','parallelRails','edgeCombs']),
  suppressed:Object.freeze(['groundTethers','shutterSlits','weightedDroplets']),
  collapsed:Object.freeze(['residualHorizon','hangingLace','foldedReliquary'])
});
/** V5.3 additions are optional; every existing assignment and default stays intact. */
export const V53_CONDITION_IDS=Object.freeze({
  normal:Object.freeze(['shuttleWeave','capillaryBloom']),
  damaged:Object.freeze(['hingedFractures','splinterCages']),
  unstable:Object.freeze(['pressureSeesaw','travelingKinks']),
  glitching:Object.freeze(['scanlineHold','checksumGaps']),
  overdrive:Object.freeze(['inductionSpirals','vectorVanes']),
  suppressed:Object.freeze(['ratchetLocks','capillaryRetreat']),
  collapsed:Object.freeze(['spentSpindles','unstrungRibs'])
});
export const DEFAULT_CONDITION_ART=Object.freeze(Object.fromEntries(Object.entries(CURATED_CONDITION_IDS).map(([key,ids])=>[key,ids[0]])));
const curated=new Set([...Object.values(CURATED_CONDITION_IDS).flat(),...ADVANCED_CONDITION_IDS,...Object.values(DISTINCT_CONDITION_IDS).flat(),...Object.values(V53_CONDITION_IDS).flat()]);
const entry=(id,label,description,controls=['strength','speed'],gate=null)=>Object.freeze({id,label,description,controls:Object.freeze(controls),gate,
  ...(controls.length>1?{recommended:curated.has(id),legacy:!curated.has(id)}:{})});
export const CONDITION_EFFECTS=Object.freeze({
  normal:Object.freeze([
    entry('shuttleWeave','Shuttle weave','A fine shuttle travels across the ribs, tightening each crossing into a small woven passage before releasing it.',['strength','speed'],'energyPulses'),
    entry('capillaryBloom','Capillary bloom','Fine branching channels grow from the ribs, open into tiny forked terminals and recede in a slow wave.',['strength','speed'],'energyPulses'),
    entry('irisWindows','Lenticular windows','Three smooth lens-shaped apertures open in the actual web; delicate rims hold each opening without petals or rotating roses.',['strength','speed'],'energyPulses'),
    entry('pleatedFan','Pleated fan','Narrow fan panels hinge successively through depth, opening and closing like a finely articulated instrument.',['strength','speed'],'filamentInstability'),
    entry('chainLace','Linked lozenges','The wing web becomes rows of connected diamond links, each quietly opening and closing in alternating rhythm.',['strength','speed'],'energyPulses'),
    entry('standingWaves','Harmonic standing waves','Fixed nodes anchor alternating filament antinodes as they resonate in opposing phases; fine energy knots remain at the stationary junctions.',['strength','speed'],'energyPulses'),
    entry('breathing','Filament breathing','The whole lattice opens in a slow fan-shaped breath, with a soft curl passing through its tips.',['strength','speed'],'filamentInstability'),
    entry('starlit','Starlit filaments','Tiny constellations awaken along the web, joined by delicate threads.',['strength','speed'],'energyPulses'),
    entry('harmonics','Harmonic currents','Opposing fine currents pass through the ribs and quietly meet at the wing web.',['strength','speed'],'energyPulses'),
    entry('aurora','Silken aurora','Three fine curtains of light travel through the wing lattice with a slow, soft drift.',['strength','speed'],'energyPulses'),
    entry('roseLattice','Rose-window lace','Open lattice windows replace dense webbing with three articulated gothic roses, gently turning in place.',['strength','speed'],'energyPulses')]),
  damaged:Object.freeze([
    entry('hingedFractures','Hinged fractures','Outer filament spans hinge away from three broken joints while slender pivot tethers keep their alignment.',['strength','speed'],'filamentBreaks'),
    entry('splinterCages','Splinter cages','Small open wire cages hold separated fragments in place, flexing as the broken lattice tries to settle.',['strength','speed'],'filamentBreaks'),
    entry('loadBridges','Catenary bridges','Failed structural spans transfer their load onto long sagging bridges which settle under tension, without stitching the gaps.',['strength','speed'],'filamentBreaks'),
    entry('veilDelamination','Delaminating veil','The actual web peels away from its ribs as one delicate sheet, then reattaches progressively from its inner edge.',['strength','speed'],'filamentBreaks'),
    entry('stressBlisters','Stress blisters','Three local pressure pockets bow the filaments outward, vent through open elliptical rims and settle.',['strength','speed'],'filamentBreaks'),
    entry('faultRepair','Fault propagation','A fault travels through neighboring strands, followed by a precise repair front that stitches their connections back together.',['strength','speed'],'filamentBreaks'),
    entry('legacyDamaged','Damaged · original animated','The earlier animated damage treatment: fractured filament spans, loose ends, subtle instability and drifting embers.',['strength','speed']),
    entry('fraying','Severed tassels','Three clear tears split the outer web; loose threads sag and sway from the broken ends.',['strength','speed'],'filamentBreaks'),
    entry('fissures','Travelling fissures','Cracks open through the lattice with bright, split edges.',['strength','speed'],'filamentBreaks'),
    entry('scarStitch','Luminous sutures','Wide breaks are laced with visible crossing sutures that tighten, release and hold the damaged wing together.',['strength','speed'],'filamentBreaks'),
    entry('emberFray','Ember fray','Fine outer threads separate into drifting, fading embers while the main wing scaffold stays intact.',['strength','speed'],'filamentBreaks')]),
  unstable:Object.freeze([
    entry('pressureSeesaw','Pressure seesaw','Upper and lower lobes alternately inflate and compress through depth, visibly trading their structural load.',['strength','speed'],'filamentInstability'),
    entry('travelingKinks','Travelling kinks','A concentrated angular bend travels down each rib, leaving a brief correcting fold behind it.',['strength','speed'],'filamentInstability'),
    entry('wanderingFocus','Wandering focus','A misplaced tension focus wanders within each wing, drawing nearby filaments into a moving concave lens.',['strength','speed'],'filamentInstability'),
    entry('tipChase','Perimeter pursuit','An edge-led correction travels from tip to tip, with each outer lobe overshooting and handing the correction onward.',['strength','speed'],'filamentInstability'),
    entry('alternatingBow','Alternating bow','Separate rib bundles bow to opposing sides, hold their tension, then exchange their bowed states.',['strength','speed'],'filamentInstability'),
    entry('threadSlip','Thread slip','Separate bundles slip lengthwise out of register, tension their connecting threads, then weave smoothly back into alignment.',['strength','speed'],'filamentInstability'),
    entry('recoil','Asymmetric recoil','One wing buckles inward while the other catches up, then both recover.',['strength','speed','frequency'],'filamentInstability'),
    entry('tremor','Filament tremor','Small, irregular tremors travel through separate filament bundles.',['strength','speed'],'filamentInstability'),
    entry('torsion','Torsion drift','A pronounced corkscrew rolls along each wing, turning the fan inward and outward in opposing phases.',['strength','speed'],'filamentInstability'),
    entry('pendulum','Counterbalance','The wings swing through opposing corrections as bowed threads and returning currents steady the lattice.',['strength','speed'],'filamentInstability'),
    entry('interference','Interference weave','Two fine wavefronts cross through a localized disturbance, forming moving interference knots.',['strength','speed'],'filamentInstability')]),
  glitching:Object.freeze([
    entry('scanlineHold','Scanline hold','A narrow moving scan band catches filament strips behind it, then releases them through a precise recovery edge.',['strength','speed','frequency'],'filamentGlitches'),
    entry('checksumGaps','Checksum gaps','Ordered missing dashes interrupt the lattice in staggered groups while small diamond checks reconnect the surviving spans.',['strength','speed','frequency'],'filamentGlitches'),
    entry('topologySwap','Crossed addresses','Web strands temporarily connect to the wrong neighbouring rib; a travelling correction restores their endpoints.',['strength','speed','frequency'],'filamentGlitches'),
    entry('polygonCompile','Polygon recompilation','Curved filaments resolve into coarse angular segments, pause as an incomplete reconstruction, then recover their smooth curves.',['strength','speed','frequency'],'filamentGlitches'),
    entry('rotatingTiles','Cell misorientation','Individual web cells pivot a quarter turn out of register and lock back, leaving the main ribs in place.',['strength','speed','frequency'],'filamentGlitches'),
    entry('phaseSeparation','Phase separation','Alternating bundles separate into translucent displaced phases, then converge strand by strand along a travelling reunion seam.',['strength','speed','frequency'],'filamentGlitches'),
    entry('phaseTears','Phase tears','Moving sectors vanish; torn edges slide sideways before reconnecting.',['strength','speed','frequency'],'filamentGlitches'),
    entry('desync','Desynchronised echoes','Misregistered copies drag behind strands, snap apart and realign.',['strength','speed','frequency'],'filamentGlitches'),
    entry('refraction','Prismatic slip','Narrow filament bands split into two fine offset images, then ease back into alignment.',['strength','speed','frequency'],'filamentGlitches'),
    entry('spectralShear','Spectral shear','A travelling band shears alternating lattice slices apart; fine spectral seams guide them back.',['strength','speed','frequency'],'filamentGlitches'),
    entry('memoryEcho','Memory echoes','Separated rib bundles leave long, smooth afterimages that drift away and catch up with the main lattice.',['strength','speed','frequency'],'filamentGlitches')]),
  overdrive:Object.freeze([
    entry('inductionSpirals','Induction spirals','Three contained spiral induction fields wind outward from the ribs, feeding energy back along their supporting branches.',['strength','speed'],'overdriveArcs'),
    entry('vectorVanes','Vector vanes','Fine chevron vanes unfold along the outer ribs and align into directed energetic slipstreams.',['strength','speed'],'overdriveArcs'),
    entry('acceleratorLoops','Filament accelerators','Elongated racetrack loops thread through the wing surface; small contained charges lap each circuit.',['strength','speed'],'overdriveArcs'),
    entry('parallelRails','Parallel discharge rails','Webbing aligns into an ordered array of parallel rails with long needle-fine outlets, then relaxes back to lace.',['strength','speed'],'overdriveArcs'),
    entry('edgeCombs','Contour combs','A moving comb of fine perpendicular energy teeth travels around each wing contour, concentrating output at its edges.',['strength','speed'],'overdriveArcs'),
    entry('surgeRouting','Surge routing','Concentrated charges leave each stabilizer, branch through the wing lattice and disperse into fine outward currents.',['strength','speed'],'overdriveArcs'),
    entry('legacyOverdrive','Overdrive · original animated','The earlier animated overdrive treatment: surging rib currents, small branching arcs and bright travelling nodes.',['strength','speed']),
    entry('corona','Corona surge','Long, tapering streams follow the wing curves and carry excess energy beyond the tips.',['strength','speed'],'energyPulses'),
    entry('circuit','Circuit cascade','Branching charges jump between web nodes and race along the ribs.',['strength','speed'],'overdriveArcs'),
    entry('convergence','Convergent charge','Paired currents gather at web junctions before releasing along alternate ribs.',['strength','speed'],'energyPulses'),
    entry('roseEngine','Rose engine','Three rotating filament rosettes gather energy and release staggered charges toward the wing tips.',['strength','speed'],'overdriveArcs'),
    entry('lightningWeave','Lightning loom','Four fine shuttles of angular energy weave between the ribs, feeding bright local junctions.',['strength','speed'],'overdriveArcs')]),
  suppressed:Object.freeze([
    entry('ratchetLocks','Ratchet locks','Paired angular locks pinch narrow sections of the lattice and release one measured step at a time.',['strength','speed'],'energyPulses'),
    entry('capillaryRetreat','Capillary retreat','Energy withdraws from the outer lace through narrow branching return paths while the ribs hold a quiet scaffold.',['strength','speed'],'energyPulses'),
    entry('groundTethers','Grounded tethers','Three bowed edge-to-anchor tethers draw the wing downward under restraint, holding tension without encircling cuffs.',['strength','speed'],'filamentInstability'),
    entry('shutterSlits','Shutter slits','Angular shutters close portions of the web into narrow ordered slits, opening only briefly before sealing again.',['strength','speed'],'energyPulses'),
    entry('weightedDroplets','Weighted light','Small hanging drops of condensed energy draw individual strands into heavy, slow-settling curves.',['strength','speed'],'filamentInstability'),
    entry('energyStarvation','Energy starvation','Light retreats from the tips to the shoulder roots, leaving faint outlines; a deliberate restart reconstructs the illuminated lattice outward.',['strength','speed'],'energyPulses'),
    entry('binding','Binding lattice','Crossed bands cinch the wings into a restrained, compressed shape.',['strength','speed'],'filamentInstability'),
    entry('drain','Rootward drain','Outer filaments recede as their energy flows inward to the shoulder roots.',['strength','speed'],'energyPulses'),
    entry('sealedHalo','Sealed lattice','Two curved energy cuffs and small diamond seals restrain the compressed wing lattice.',['strength','speed'],'filamentInstability'),
    entry('hush','Quiet withdrawal','Outer webbing dims and withdraws while sparse, fine currents retreat toward a broken root crescent.',['strength','speed'],'energyPulses')]),
  collapsed:Object.freeze([
    entry('spentSpindles','Spent spindles','Loose filament spans wind into two elongated open spools beside the shoulders, with a slow residual unwind.',['strength','speed'],'filamentBreaks'),
    entry('unstrungRibs','Unstrung ribs','Disconnected ribs hang separately from their roots, with staggered soft swings and a few slack cross ties.',['strength','speed'],'filamentBreaks'),
    entry('residualHorizon','Residual horizon','The complete lattice flattens into a narrow suspended horizon; a small fold of residual tension travels along it.',['strength','speed'],'filamentBreaks'),
    entry('hangingLace','Hanging lace','The intact wing lattice relaxes into long closed hanging loops, swaying gently without shedding fragments.',['strength','speed'],'filamentBreaks'),
    entry('foldedReliquary','Folded reliquary','The intact web folds into a compact angular pocket beside each shoulder, with quiet sequential opening along its seams.',['strength','speed'],'filamentBreaks'),
    entry('unravelling','Unravelling','A broken upper scaffold sheds fine threads that peel away and dissolve below.',['strength','speed'],'filamentBreaks'),
    entry('remnants','Shattered remnants','Angular pieces of the lattice separate and slowly fall away.',['strength','speed'],'filamentBreaks'),
    entry('fallingScript','Falling script','A weakened scaffold sheds small calligraphic fragments that drift downward and dissolve.',['strength','speed'],'filamentBreaks'),
    entry('seedRecall','Dormant seeds','The lattice contracts into three suspended seed clusters beside each shoulder, gathering short fragments around their cores.',['strength','speed'],'filamentBreaks')])
});
const reactionEntry=(id,label,description)=>entry(id,label,description,['strength']);
export const REACTION_EFFECTS=Object.freeze({
  damage:Object.freeze([reactionEntry('recoilWave','Recoil current','A brief inward recoil releases a delicate correcting current along individual ribs.'),reactionEntry('impact','Impact recoil','A sharp inward kick settles quickly, releasing one short ripple.'),reactionEntry('fracture','Fracture flash','Short cracks split the ribs at the impact front, then close.')]),
  critical:Object.freeze([reactionEntry('overload','Overload cascade','A compressed charge gathers inward, then releases along three staggered groups of filaments.'),reactionEntry('rupture','Rupture','A forceful wing recoil tears open sections and scatters their fragments.'),reactionEntry('shock','Shock cascade','Three forceful crests sweep through the ribs in succession, each trailed by a fainter echo.')]),
  heal:Object.freeze([reactionEntry('mending','Mending current','Slender currents reconnect adjacent filaments as they travel toward the tips.'),reactionEntry('stitch','Filament stitching','Fine cross-stitches draw neighbouring ribs closed behind a current that runs from root to tip.'),reactionEntry('bloom','Restoration bloom','Star-shaped knots unfold along the ribs and reconnect their filaments.')]),
  flare:Object.freeze([reactionEntry('ignition','Tip ignition','A precise charge climbs the ribs and ignites each tip in sequence.'),reactionEntry('fan','Fan burst','The ribs fan outward and cast a long arc of light through their tips.'),reactionEntry('crown','Crown ignition','Upper ribs lift and ignite in succession, each tip flaring into small crown tines.')]),
  pulse:Object.freeze([reactionEntry('resonance','Resonance pulse','The wing lattice draws inward, releases a contained crest from shoulder to tip, then settles.'),reactionEntry('heartbeat','Double heartbeat','Two gentle outward beats are separated by a clear pause.'),reactionEntry('orbit','Orbiting mote','A bright mote orbits each wing, leaving a short curved filament wake.')]),
  stutter:Object.freeze([reactionEntry('phaseSlip','Controlled stutter','Three brief, held misalignments interrupt narrow filament bands, then quietly reconnect. Strength controls the slip; duration controls its timing.'),reactionEntry('skip','Frame skip','Small patches briefly hold an offset, jump and realign while the main ribs stay visible.'),reactionEntry('static','Static interference','Fine, broken interference marks crawl across the filament web.')]),
  reform:Object.freeze([reactionEntry('rethread','Rethread','The lattice unravels in from the tips to her shoulders, leaving a faint scaffold, then rebuilds from shoulder to tip behind paired fine currents.'),reactionEntry('weave','Root weaving','Paired threads twist around each rib, unweaving it in from the tips and weaving it back out from her shoulders.'),reactionEntry('recall','Fragment recall','The lattice loosens into drifting pieces, which then converge and lock back into place.')])
});
export function effectCatalog(){return structuredClone({conditions:CONDITION_EFFECTS,reactions:REACTION_EFFECTS});}
export const CONDITION_CATEGORY_LABELS=Object.freeze({normal:'Normal',damaged:'Damaged',unstable:'Unstable',glitching:'Glitching',overdrive:'Overdrive',suppressed:'Suppressed',collapsed:'Collapsed'});
const conditionIndex=new Map(Object.entries(CONDITION_EFFECTS).flatMap(([category,entries])=>entries.map(entry=>[entry.id,Object.freeze({...entry,category,sourceCondition:category,categoryLabel:CONDITION_CATEGORY_LABELS[category]})])));
export const conditionEffectCategory=id=>conditionIndex.get(id)?.category??null;
export const conditionEffectCategoryLabel=id=>conditionIndex.get(id)?.categoryLabel??null;
export const conditionEffectGroups=()=>CONDITION_IDS.map(id=>({id,label:CONDITION_CATEGORY_LABELS[id],entries:CONDITION_EFFECTS[id].map(entry=>conditionIndex.get(entry.id))}));
export const variant=(group,key,id)=>group==='reaction'?REACTION_EFFECTS[key]?.find(e=>e.id===id)??null:CONDITION_IDS.includes(key)?conditionIndex.get(id)??null:null;
let labelIndex=null;// (beta.37) built once: each call used to flatten every effect
export const styleLabel=id=>({original:'Original / subtle',animated:'Animated / v2',none:'None (no extra effect)'})[id]??(labelIndex??=(()=>{const m=new Map();for(const x of Object.values({...CONDITION_EFFECTS,...REACTION_EFFECTS}).flat())if(!m.has(x.id))m.set(x.id,x.label);return m;})()).get(id)??id;
export const settingKey=(group,key)=>`${group==='reaction'?'reaction':'condition'}Effect_${key}`;
export function stylePatch(raw,group='condition') {
  const ids=group==='reaction'?REACTION_IDS:CONDITION_IDS;
  if(!raw||typeof raw!=='object'||Array.isArray(raw))throw new Error(`Pass ${group} effects as an object.`);
  const out={};
  for(const [key,value] of Object.entries(raw)){
    if(!ids.includes(key))throw new Error(`Unknown ${group} effect: ${key}.`);
    if(value!==null&&!['original','animated','none'].includes(value)&&!variant(group,key,value))throw new Error(`Invalid ${key} effect: ${value}. Choose an effect from the ${group==='condition'?'condition animation library':'selected reaction'}.`);
    out[key]=value;
  }
  return out;
}
export function tuningPatch(raw,group='condition') {
  const ids=group==='reaction'?REACTION_IDS:CONDITION_IDS,keys=group==='reaction'?['strength']:['strength','speed','frequency'];
  if(!raw||typeof raw!=='object'||Array.isArray(raw))throw new Error('Pass effect tuning as an object.');
  const out={};
  for(const [id,values] of Object.entries(raw)){
    if(!ids.includes(id))throw new Error(`Unknown ${group} tuning: ${id}.`);
    if(values===null){out[id]=null;continue;}
    if(!values||typeof values!=='object'||Array.isArray(values))throw new Error('Effect tuning must be an object or null.');
    out[id]={};
    for(const [k,v] of Object.entries(values)){
      if(!keys.includes(k)||v!==null&&(!Number.isFinite(v)||v<(k==='strength'?0:.25)||v>(k==='strength'?1:2)))throw new Error(`Invalid effect tuning: ${k}. Strength is 0–1; speed and frequency are 0.25–2.`);
      out[id][k]=v;
    }
  }
  return out;
}
export const resolveTuning=(data,key,group='condition')=>Object.fromEntries((group==='reaction'?['strength']:['strength','speed','frequency']).map(k=>[k,data?.[group==='reaction'?'reactionTuning':'effectTuning']?.[key]?.[k]??1]));
export function effectSettingDefinitions(){
  return Object.fromEntries(['condition','reaction'].flatMap(group=>Object.entries(group==='condition'?CONDITION_EFFECTS:REACTION_EFFECTS).map(([key,entries])=>[settingKey(group,key),{
    name:`${group==='condition'?'Condition':'Reaction'} effect: ${key}`,hint:'Default for tokens using module settings. Token-specific choices take priority; feature switches still apply.',scope:'world',config:true,type:String,default:'default',
    choices:Object.fromEntries([['default',group==='condition'?'Recommended condition style':'Follow condition style'],['original','Original / subtle'],['animated',group==='condition'?'Animated (compatibility alias)':'Animated'],['none','None (extra effect only)'],...(group==='condition'?[...conditionIndex.values()]:[...entries]).sort((a,b)=>Number(!!b.recommended)-Number(!!a.recommended)).map(x=>[x.id,`${x.categoryLabel?`${x.categoryLabel} · `:''}${x.legacy?'Legacy · ':''}${x.label}`])])
  }])));
}
