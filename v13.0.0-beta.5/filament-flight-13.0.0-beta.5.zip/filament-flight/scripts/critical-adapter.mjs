/** PF2e v14 applyDamage observer. It never edits arguments, dice, actors or chat.
 * Critical qualification uses the damage roll's degreeOfSuccess === 3 plus one
 * observed, positive applied HP/temp-HP update. Overlapping/ambiguous calls are
 * deliberately left as ordinary damage; explicit critical flares remain usable.
 */
export class CriticalAdapter {
  constructor(onCritical,report=()=>{}) {this.onCritical=onCritical;this.report=report;this.calls=new Map();this.installed=null;this.reason='Not initialized';}
  reportError(error) {try {this.report(error);}catch {/* VFX reporting must never affect PF2e damage. */}}
  install(Type) {
    if(this.installed)return;
    let prototype=Type?.prototype;
    while(prototype&&!Object.hasOwn(prototype,'applyDamage'))prototype=Object.getPrototypeOf(prototype);
    const original=prototype?.applyDamage;
    if(typeof original!=='function'){this.reason='PF2e applyDamage is unavailable';return;}
    const own=Object.getOwnPropertyDescriptor(prototype,'applyDamage'),adapter=this;
    const installation={prototype,own,alive:true};
    function wrapper(...args) {
      if(!installation.alive)return original.apply(this,args);
      let context;
      try {context=adapter.begin(this,args[0]);}catch(error){adapter.reportError(error);}
      const finish=success=>{try {if(context)adapter.finish(context,success);}catch(error){adapter.reportError(error);}};
      let result;
      try {result=original.apply(this,args);}catch(error){finish(false);throw error;}
      if(!result?.then){finish(false);return result;}
      return result.then(value=>{finish(true);return value;},error=>{finish(false);throw error;});
    }
    try {
      Object.defineProperty(prototype,'applyDamage',{value:wrapper,writable:true,configurable:true});
      this.installed={...installation,wrapper,installation};this.reason='PF2e applied-damage observer';
    }catch(error){this.reason='The damage method could not be observed';this.reportError(error);}
  }
  begin(actor,input) {
    const key=actor?.uuid;if(!key)return null;
    const calls=this.calls.get(key)??new Set();
    const critical=!!(input?.damage&&typeof input.damage==='object'&&Number.isFinite(input.damage.total)&&input.damage.options?.degreeOfSuccess===3);
    const context={key,actor,critical,ambiguous:calls.size>0,events:[],alive:true};
    for(const c of calls)c.ambiguous=true;
    calls.add(context);this.calls.set(key,calls);return context;
  }
  observe(actor,before,after,options,userId,event) {
    const calls=this.calls.get(actor?.uuid);if(!calls?.size||userId!==game.user.id)return;
    const loss=Math.max(0,before.value-after.value)+Math.max(0,before.temp-after.temp);
    for(const context of calls)context.events.push({eligible:before.max===after.max&&loss>0&&options.damageTaken>0&&
      typeof options.finePowder==='boolean'&&!options.damageUndo,event});
  }
  finish(context,success) {
    const calls=this.calls.get(context.key);calls?.delete(context);if(!calls?.size)this.calls.delete(context.key);
    if(!context.alive||!success||!context.critical||context.ambiguous||context.events.length!==1||!context.events[0].eligible)return;
    try {void Promise.resolve(this.onCritical(context.actor,context.events[0].event)).catch(error=>this.reportError(error));}catch(error){this.reportError(error);}
  }
  uninstall() {
    const installed=this.installed;
    if(installed){installed.installation.alive=false;if(installed.prototype.applyDamage===installed.wrapper)Object.defineProperty(installed.prototype,'applyDamage',installed.own);}
    for(const calls of this.calls.values())for(const c of calls)c.alive=false;
    this.calls.clear();this.installed=null;this.reason='Disabled';
  }
  status(){return {available:!!this.installed,reason:this.reason,source:'damage roll + applied HP update',ambiguousCalls:'ordinary damage'};}
}
