/** Local preferences and owner-selected observer caps never change choreography. */
export const QUALITY_PRESETS=Object.freeze({
  inherit:Object.freeze({}),custom:Object.freeze({}),
  high:Object.freeze({wingDetail:'high',bitDetail:'high',textureFPS:60,transitionFPS:60,trails:'high',treatment:'high',effectDetail:'high'}),
  balanced:Object.freeze({wingDetail:'medium',bitDetail:'medium',textureFPS:30,transitionFPS:30,trails:'medium',treatment:'standard',effectDetail:'medium'}),
  low:Object.freeze({wingDetail:'low',bitDetail:'low',textureFPS:30,transitionFPS:30,trails:'low',treatment:'low',effectDetail:'low'})
});
export const QUALITY_FIELDS=Object.freeze({wingDetail:['low','medium','high'],bitDetail:['low','medium','high'],textureFPS:[12,60],transitionFPS:[12,60],trails:['off','low','medium','high'],treatment:['low','standard','high'],effectDetail:['low','medium','high']});
export function qualityProfile(input={},{owner=false,strict=true}={}){
  if(!input||typeof input!=='object'||Array.isArray(input)){if(strict)throw new Error('Quality must be a profile object.');input={};}
  const out={preset:'inherit'};
  for(const [key,value]of Object.entries(input)){
    if(key==='ownerId'&&owner){if(value===null||typeof value==='string'&&value.length<=128)out.ownerId=value;else if(strict)throw new Error('Invalid quality owner.');continue;}
    if(key==='preset'){if(Object.hasOwn(QUALITY_PRESETS,value))out.preset=value;else if(strict)throw new Error('Choose inherit, high, balanced, low or custom quality.');continue;}
    const range=QUALITY_FIELDS[key];
    if(!range){if(strict)throw new Error(`Unknown quality option: ${key}.`);continue;}
    if(value===null){out[key]=null;continue;}
    const valid=typeof range[0]==='number'?Number.isFinite(value)&&value>=range[0]&&value<=range[1]:range.includes(value);
    if(valid)out[key]=value;else if(strict)throw new Error(`Invalid quality ${key}.`);
  }
  return out;
}
export function qualityValues(profile={}){
  const p=qualityProfile(profile,{owner:true,strict:false});
  return {...QUALITY_PRESETS[p.preset],...Object.fromEntries(Object.entries(p).filter(([k,v])=>Object.hasOwn(QUALITY_FIELDS,k)&&v!==null))};
}
export function mergeQuality(previous,patch){
  const valid=qualityProfile(patch),before=qualityProfile(previous,{owner:true,strict:false});
  if(!Object.hasOwn(patch,'preset'))return qualityProfile({...qualityProfile(before,{strict:false}),...patch});
  const seed=valid.preset==='custom'?qualityValues(before):{};
  return qualityProfile({...seed,...patch});
}
const lower=(a,b,order)=>order[Math.min(order.indexOf(a),order.indexOf(b))];
const DETAIL=['low','medium','high'],TRAIL=['off',...DETAIL],TREATMENT=['low','standard','high'];
const cache=new WeakMap(),derived=new WeakMap();
// Only quality inputs produce the cached quality override. Other setting
// changes replace the runtime configuration through its registered onChange.
const qualityKeys=['rigQuality','bitQuality','rigFPS','poseFPS','localTrails','trailQuality','treatmentDetail','effectDetail'];
const profileKeys=['preset','ownerId',...Object.keys(QUALITY_FIELDS)];
const snapshotValues=(input,keys)=>keys.map(key=>input?.[key]);
const same=(input,keys,before)=>{for(let i=0;i<keys.length;i++)if(!Object.is(input?.[keys[i]],before[i]))return false;return true;};
const valid=(config,data,saved)=>same(config,qualityKeys,saved.inputs)&&same(config.localQuality,profileKeys,saved.local)&&same(data.observerQuality,profileKeys,saved.observer);
export function qualityConfiguration(config,data={},viewerId=globalThis.game?.user?.id){
  if(config._qualityData===data&&config._qualityUser===viewerId){
    const origin=derived.get(config);if(!origin||valid(origin.config,data,origin))return config;config=origin.config;
  }
  let records=cache.get(config);if(!records){records=new WeakMap();cache.set(config,records);}
  const saved=records.get(data);if(saved&&saved.viewerId===viewerId&&valid(config,data,saved))return saved.value;
  const local=qualityValues(config.localQuality),observer=qualityProfile(data.observerQuality??{},{owner:true,strict:false});
  const cap=observer.ownerId&&observer.ownerId===viewerId?{}:qualityValues(observer);
  const values={wingDetail:config.rigQuality??'medium',bitDetail:config.bitQuality??'high',textureFPS:config.rigFPS??60,
    transitionFPS:config.poseFPS??60,trails:config.localTrails===false?'off':config.trailQuality??config.rigQuality??'medium',treatment:config.treatmentDetail??'high',effectDetail:config.effectDetail??'high',...local};
  for(const [key,value]of Object.entries(cap))values[key]=typeof value==='number'?Math.min(values[key],value):lower(values[key],value,key==='trails'?TRAIL:key==='treatment'?TREATMENT:DETAIL);
  // An explicit personal trails switch is authoritative even over High presets.
  if(config.localTrails===false)values.trails='off';
  const value={...config,rigQuality:values.wingDetail,bitQuality:values.bitDetail,rigFPS:values.textureFPS,poseFPS:values.transitionFPS,
    trailQuality:values.trails,localTrails:values.trails!=='off',treatmentDetail:values.treatment,effectDetail:values.effectDetail,
    quality:{...values,observerLimited:!!Object.keys(cap).length,observerOwnerId:observer.ownerId??null}};
  Object.defineProperties(value,{_qualityData:{value:data},_qualityUser:{value:viewerId}});
  const record={viewerId,value,config,inputs:snapshotValues(config,qualityKeys),local:snapshotValues(config.localQuality,profileKeys),observer:snapshotValues(data.observerQuality,profileKeys)};
  records.set(data,record);derived.set(value,record);return value;
}

// Private rehearsal uses this browser's quality choice. A token's owner-selected
// observer cap belongs to its shared scene representation, never to a personal
// preview. Resolve once before choosing painter detail, raster size or cadence.
const privatePreviewData=Object.freeze({});
export function previewQualityConfiguration(config){
  return qualityConfiguration(derived.get(config)?.config??config,privatePreviewData);
}
