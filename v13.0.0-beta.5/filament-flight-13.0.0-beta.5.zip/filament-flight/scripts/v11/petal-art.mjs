/** Yvaelle’s Toolbox v11 · the six milestone petals (pure SVG strings, from the lab's petals.js).
 *
 * Each is drawn base at 0,0, tip up, about 13 units long: a touch shorter than
 * a Hero petal (14.5 × 1.05), so set in the five gaps of the Nytheris (behind
 * the Hero whorl) they read as a second, inner ring and never as Hero Points.
 * Each variety has its own silhouette AND colour, so it reads at corner size
 * and without colour. Gradient ids carry a prefix (the HUD's shadow root, her
 * sheet and the chat each hold their own copy of the defs). */
const G='M0-2.6l.75 1.85L2.6 0 .75.75 0 2.6-.75.75-2.6 0-.75-.75z';
export const GLINT=G;
export const petalDefs=(p='mp')=>`<linearGradient id="${p}-hundred" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#c94fae"/><stop offset=".55" stop-color="#ec9bd9"/><stop offset="1" stop-color="#ffe3f4"/></linearGradient>
<linearGradient id="${p}-dawn" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#2a1024"/><stop offset=".45" stop-color="#7a2a52"/><stop offset=".8" stop-color="#e3a98a"/><stop offset="1" stop-color="#f8e2c4"/></linearGradient>
<linearGradient id="${p}-gild" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#1e140f"/><stop offset="1" stop-color="#3a2817"/></linearGradient>
<linearGradient id="${p}-gild-edge" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f3d79c"/><stop offset=".5" stop-color="#cfae76"/><stop offset="1" stop-color="#8a6d45"/></linearGradient>
<linearGradient id="${p}-grace" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#f3d2e8"/><stop offset=".6" stop-color="#fbf1e4"/><stop offset="1" stop-color="#fffaf2"/></linearGradient>
<linearGradient id="${p}-feather" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#c9bde0"/><stop offset="1" stop-color="#f3eef8"/></linearGradient>
<linearGradient id="${p}-standing" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#e6a37c"/><stop offset=".35" stop-color="#f2c9d8"/><stop offset="1" stop-color="#fbe4ec"/></linearGradient>`;
const ART={
  'hundredfold':p=>`<path d="M0 0C-4.7 -3.8 -4.6 -10.4 0 -13.2C4.6 -10.4 4.7 -3.8 0 0Z" fill="url(#${p}-hundred)" stroke="#8e2038" stroke-width=".6"/><path d="M0 -1.6V-11.4" stroke="#fff3fb" stroke-width=".45" stroke-opacity=".75" fill="none"/><path d="M0 -2.6C-1.6 -3.6 1.6 -5 0 -6.2S-1.6 -8.6 0 -9.8" stroke="#fff3fb" stroke-width=".5" fill="none" stroke-linecap="round"/>`,
  'second-dawn':p=>`<path d="M0 0C-3.6 -4.6 -3.5 -10 -1.3 -13.5L0 -12.1L1.3 -13.5C3.5 -10 3.6 -4.6 0 0Z" fill="url(#${p}-dawn)" stroke="#8e2038" stroke-width=".6" stroke-linejoin="round"/><path d="M0 -1.8V-10.6" stroke="#f8e2c4" stroke-width=".4" stroke-opacity=".5" fill="none"/><path transform="translate(0 -14.6) scale(.34)" d="${G}" fill="#fff1d6"/>`,
  'fifth-ring':p=>`<path d="M0 0C-3.1 -4.8 -3.1 -10 0 -14C3.1 -10 3.1 -4.8 0 0Z" fill="url(#${p}-gild)" stroke="url(#${p}-gild-edge)" stroke-width=".8"/><path d="M0 -1.6C-1.8 -4.6 -1.8 -9 0 -11.8C1.8 -9 1.8 -4.6 0 -1.6Z" fill="none" stroke="#cfae76" stroke-width=".32" stroke-opacity=".7"/>${[3.4,5.2,7,8.8,10.6].map(y=>`<circle cy="${-y}" r=".42" fill="#f3d79c"/>`).join('')}`,
  'saving-grace':p=>`<path d="M0 0C-3.9 -4.2 -3.9 -9.6 -.9 -12.4Q0 -11.6 .9 -12.4C3.9 -9.6 3.9 -4.2 0 0Z" fill="url(#${p}-grace)" stroke="#e767ce" stroke-width=".6"/><path d="M0 -1.6V-9.8M0 -5.2L-1.6 -7.4M0 -5.2L1.6 -7.4" stroke="#c84fae" stroke-width=".4" stroke-opacity=".7" fill="none" stroke-linecap="round"/><path transform="translate(0 -14.2) scale(.62)" d="${G}" fill="#f3d79c" stroke="#8a6d45" stroke-width=".5"/>`,
  'unfallen':p=>`<path d="M0 0C-3.9 -3.6 -4.3 -9.4 -1 -13.6C2.4 -11.4 3.4 -5.4 0 0Z" fill="url(#${p}-feather)" stroke="#6b3b6b" stroke-width=".6" stroke-linejoin="round"/><path d="M0 -.8C-.2 -5 -.5 -9.4 -1 -13" stroke="#6b3b6b" stroke-width=".45" fill="none" stroke-linecap="round"/><path d="M-.2 -3.4L-2.4 -4.8M-.35 -5.8L-2.8 -7.2M-.55 -8.2L-2.6 -9.8M-.75 -10.6L-1.9 -11.8" stroke="#6b3b6b" stroke-width=".35" stroke-opacity=".7" fill="none" stroke-linecap="round"/>`,
  'all-standing':p=>`<path d="M0 0C-4.3 -3.6 -5 -9 -2.7 -12.4C-1.6 -13.6 -.4 -13 0 -11.4C.4 -13 1.6 -13.6 2.7 -12.4C5 -9 4.3 -3.6 0 0Z" fill="url(#${p}-standing)" stroke="#a3243f" stroke-width=".6" stroke-linejoin="round"/><path d="M0 -1.6V-10.4M0 -4.6C-1.2 -6 -1.8 -7.6 -1.8 -9.4M0 -4.6C1.2 -6 1.8 -7.6 1.8 -9.4" stroke="#a3243f" stroke-width=".4" stroke-opacity=".55" fill="none" stroke-linecap="round"/>`
};
export const PETAL_COLORS=Object.freeze({'hundredfold':'#e767ce','second-dawn':'#e3a98a','fifth-ring':'#cfae76','saving-grace':'#fbf1e4','unfallen':'#c9bde0','all-standing':'#f2c9d8'});
/** One petal's drawing (base at 0,0, tip up). */
export const petalArt=(id,p='mp')=>ART[id]?.(p)??'';
/** The five gaps of the open flower, in pin order. */
export const SLOTS=Object.freeze([-36,36,-108,108,180]);
export const PETAL_SCALE=.88;
/** Where pin i sits as the flower opens (open 1) or closes to her bud by day (0). */
export function slotTransform(i,open=1){
  const o=Math.max(0,Math.min(1,open)),a=SLOTS[i%5]*(.3+.7*o),k=PETAL_SCALE*(.82+.18*o);
  return {angle:a,scale:k,css:`rotate(${a.toFixed(1)}deg) scale(${k.toFixed(3)})`};
}
/** The inner whorl as SVG (its own <g>s; the caller supplies the defs). */
export function whorl(ids,{open=1,prefix='mp',cls='mp'}={}){
  return ids.slice(0,5).map((id,i)=>`<g class="${cls} ${cls}-${id}" data-ms="${id}" style="transform:${slotTransform(i,open).css}">${petalArt(id,prefix)}</g>`).join('');
}
/** A single petal in its own small svg (cards, herbarium, recap). */
export const petalIcon=(id,{w=12,h=16,prefix='mp',defs=true}={})=>`<svg width="${w}" height="${h}" viewBox="-6 -15.5 12 16.5" aria-hidden="true">${defs?`<defs>${petalDefs(prefix)}</defs>`:''}${petalArt(id,prefix)}</svg>`;

/* ------------------------------------------------------------------ */
/* The Nytheris as the corners draw it, for the recap card and image  */
/* ------------------------------------------------------------------ */
export const HERO_PETAL='M0 0C-3.4 -5 -2.8 -11 0 -14.5C2.8 -11 3.4 -5 0 0Z';
export const OPEN_ANGLES=Object.freeze([0,72,144,-144,-72]);
/** The flower's inner SVG (centred at 0,0, about 30 units across): Hero
 * petals (lit = how many), the milestone whorl in the gaps, the gem. */
export function flowerInner({lit=5,pinned=[],prefix='mp',sw=.7,gem=3.2}={}){
  const ms=whorl(pinned,{prefix});
  const hero=OPEN_ANGLES.map((a,i)=>`<g transform="rotate(${a})"${i<lit?'':' opacity=".16"'}><path d="${HERO_PETAL}" transform="scale(1.05)"/><path d="M0 -3V-12" fill="none" stroke="#a3243f" stroke-width="${Math.min(.5,sw*.75)}" opacity=".8"/></g>`).join('');
  return `<defs>${petalDefs(prefix)}<radialGradient id="${prefix}-gem" cx=".42" cy=".38" r=".7"><stop offset="0" stop-color="#f7b6e8"/><stop offset=".55" stop-color="#e767ce"/><stop offset="1" stop-color="#c2449f"/></radialGradient></defs>
<g class="ms-whorl">${ms.replace(/style="transform:([^"]+)"/g,(m,t)=>`transform="${t.replace(/deg/g,'').replace(/,\s*/g,' ')}"`)}</g><g fill="#efe4d4" fill-opacity=".94" stroke="#8e2038" stroke-width="${sw}">${hero}</g><circle r="${gem}" fill="url(#${prefix}-gem)"/>`;
}
/** A standalone flower SVG (w×h px). */
export const flowerSVG=({size=30,rotate=-12,...o}={})=>`<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="-17 -17 34 34" aria-hidden="true"><g transform="rotate(${rotate})">${flowerInner(o)}</g></svg>`;
