/** Yvaelle’s Toolbox v11 · Shadow wings: the classic drain of her filaments.
 *
 * Going invisible (or Hidden/Undetected) the light drains out along every
 * filament from root to tip and slips off the tips; her owner and the GM keep
 * a ghost outline (a dark hairline under a cool lilac line on the edge, the
 * ribs and web far fainter, a slow glint travelling the outline). Coming back
 * it rekindles from her shoulders outward, a bead leading each rib.
 *
 * Port of the approved lab (lab/canvas2/site/v11-fx.mjs shadowFx) as two pure
 * steps the wing painter runs on the main thread and in its worker alike:
 *  - drainGeometry(layers, drain): splits each strand at the front into lit
 *    runs (painted as before) and ghost/bead/tip parts (marked `v11`);
 *  - paintV11Parts(ctx, key, parts, visual): paints those parts.
 * The drain rides on the visual profile as visual.v11Drain = {mode, F, ghost,
 * hot} (F = front in wing radii; held: F = 3, hot false), so the painter's own
 * change detection repaints only when the front moves. No globals. */

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${a<0?0:a>1?1:a})`;
const hash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return ((h>>>0)%10007)/10007;};

export const R_MAX=262;
/** The wing root in art units (wing-rig.mjs ROOT; kept here so the worker needs no cycle). */
const ROOT=[27,-13];
export const HELD=Object.freeze({mode:'hide',F:3,ghost:1,hot:false});
const GHOST=Object.freeze({edge:{w:1.55,a:.62,dark:.32,halo:.11},rib:{w:.95,a:.24,dark:0,halo:0},web:{w:.7,a:.08,dark:0,halo:0}});
const GH_CORE=[238,190,246],GH_BLOOM=[214,92,214],HOT_CORE=[255,222,252],HOT_BLOOM=[255,96,236];
const CLASSES=Object.freeze(['web','rib','edge']);

/** 1 = lit (normal filament), 0 = drained. j = the strand's lag. */
const litAt=(r,j,f)=>{const d=f.F-j-r;return f.mode==='hide'?(d>0?0:1):(d>0?1:0);};
const lagCache=new Map();
export const strandLag=id=>{let v=lagCache.get(id);if(v===undefined){v=id.startsWith('rib-')?(+id.slice(4))*.016:id.startsWith('edge-')?.05+(+id.slice(5))*.01:.04+hash(id)*.16;lagCache.set(id,v);}return v;};
export const ghostClass=id=>id?.startsWith('edge-')?'edge':id?.startsWith('rib-')?'rib':/^(web|cross)-/.test(id??'')?'web':null;
const rOf=(p,sx)=>Math.hypot(p[0]-sx*ROOT[0],p[1]-ROOT[1])/R_MAX;

function splitStrand(s,sx,f){
  const j=strandLag(s.id),pts=s.points,runs=[];let cur=null,prevR=0;
  for(let i=0;i<pts.length;i++){
    const p=pts[i],r=rOf(p,sx),l=litAt(r,j,f);
    if(cur&&cur.lit!==l){
      const a=pts[i-1],thr=f.F-j,k=Math.abs(r-prevR)>1e-6?unit((thr-prevR)/(r-prevR)):.5;
      const m=[a[0]+(p[0]-a[0])*k,a[1]+(p[1]-a[1])*k];
      cur.points.push(m);runs.push(cur);cur={lit:l,points:[m]};
    }
    if(!cur)cur={lit:l,points:[]};
    cur.points.push(p);prevR=r;
  }
  if(cur)runs.push(cur);
  return runs;
}

/** (11.0.0-test.2) How much of her light the drain leaves (1 = all, 0 = none, the ghost keeps a
 * faint share): what the v11 damage strokes (embers, frost, glints, bit glows) are painted at, so a
 * wound or persistent damage fades with the wings instead of floating over a drained silhouette. */
export function drainLit(drain){
  if(!drain)return 1;
  const k=unit((drain.F-.1)/1.05),lit=drain.mode==='hide'?1-k:k;
  return Math.max(lit,Math.max(0,Math.min(1,drain.ghost??1))*.3);
}
/** Split her wing layers at the drain front. Returns new layer arrays (the cached body is never touched). */
export function drainGeometry(layers,drain){
  if(!drain||!layers)return layers;
  const f=drain,gA=Math.max(0,Math.min(1,f.ghost??1)),out={};
  const settle=f.mode==='hide'?smooth((f.F-.15)/.6)*.55+.45:1;
  for(const key of Object.keys(layers)){
    const list=layers[key];if(!Array.isArray(list)){out[key]=list;continue;}
    const sx=key.startsWith('left')?-1:1,front=key.endsWith('Front'),keep=[];
    for(const s of list){
      if(s.hardware||s.v11){keep.push(s);continue;}
      const pts=s.points;if(!pts?.length){keep.push(s);continue;}
      if(s.star){if(litAt(rOf(pts[0],sx),.05,f))keep.push(s);continue;}
      const cls=ghostClass(s.id);
      if(!cls){if(litAt(rOf(pts[0],sx),.05,f))keep.push(s);continue;}
      const runs=splitStrand(s,sx,f);
      for(const r of runs){if(r.points.length<2)continue;
        if(r.lit)keep.push(r.points.length===pts.length?s:{...s,points:r.points});
        else if(gA>0)keep.push({id:`v11g-${s.id}`,v11:'ghost',cls,front,width:GHOST[cls].w,strength:Math.round(gA*settle*40)/40,ga:gA,settle,points:r.points});}
      // the bead: where the front crosses this rib (rear layers only)
      if(f.hot&&cls==='rib'&&!front){const thr=f.F-strandLag(s.id);
        if(thr>-.02&&thr<1.02){let best=null,bd=9;for(const p of pts){const d=Math.abs(rOf(p,sx)-thr);if(d<bd){bd=d;best=p;}}
          if(best&&bd<.06)keep.push({id:`v11b-${s.id}`,v11:'bead',width:1,strength:Math.round(thr*200)/200,thr,sx,points:pts,at:best});}}
      // as each bead leaves its tip on the way out: a small glint that fades
      if(f.hot&&f.mode==='hide'&&cls==='rib'&&!front){const k=(f.F-strandLag(s.id)-1)/.18;
        if(k>0&&k<1)keep.push({id:`v11t-${s.id}`,v11:'tip',width:1,strength:Math.round(bump(k)*.75*40)/40,points:[pts[pts.length-1]]});}
    }
    out[key]=keep;
  }
  return out;
}

/** Paint the drain's own parts on one layer (art units: the painter's transform is already set). */
export function paintV11Parts(ctx,key,parts,visual){
  if(!parts.length)return;
  const f=visual?.v11Drain??HELD,t=Number(visual?.time)||0,front=key.endsWith('Front');
  const breathe=.88+.12*Math.sin(t*1.25);
  for(const cls of CLASSES){const G=GHOST[cls];let n=0,gA=0,settle=1;
    ctx.beginPath();
    for(const s of parts){if(s.v11!=='ghost'||s.cls!==cls)continue;n++;gA=s.ga;settle=s.settle;const P=s.points;for(let i=0;i<P.length;i++)i?ctx.lineTo(P[i][0],P[i][1]):ctx.moveTo(P[i][0],P[i][1]);}
    if(!n)continue;
    // (a dark hairline under the silhouette keeps contrast on a busy map)
    if(G.dark){ctx.lineWidth=G.w*2.6;ctx.strokeStyle=`rgba(14,5,16,${G.dark*gA*settle})`;ctx.stroke();}
    if(G.halo){ctx.lineWidth=G.w*5;ctx.strokeStyle=rgba(GH_BLOOM,G.halo*gA*breathe);ctx.stroke();}
    ctx.lineWidth=G.w;ctx.strokeStyle=rgba(GH_CORE,G.a*gA*breathe*settle*(front?.85:1));ctx.stroke();
  }
  // a slow glint that travels the outline (about once every 5 s)
  if(!front){const side=key.startsWith('left')?0:.5,loop=((t*.2+side)%1.25);
    for(const s of parts){if(s.v11!=='ghost'||s.cls!=='edge')continue;const idx=+s.id.slice(10),n=s.points.length;if(!Number.isFinite(idx)||n<2)continue;
      let started=false;
      for(let i=0;i<n;i++){const pos=(idx+i/(n-1))/7,d=Math.abs(pos-loop);if(d<.045){const p=s.points[i];if(!started){ctx.beginPath();ctx.moveTo(p[0],p[1]);started=true;}else ctx.lineTo(p[0],p[1]);}}
      if(started){const gA=s.ga;ctx.lineWidth=4;ctx.strokeStyle=rgba(GH_BLOOM,.1*gA);ctx.stroke();ctx.lineWidth=1.6;ctx.strokeStyle=rgba([250,230,255],.42*gA);ctx.stroke();}}}
  // the travelling light at the front: a short hot run along each rib with a bead
  for(const b of parts){if(b.v11!=='bead')continue;
    const tipFade=1-smooth((b.thr-.9)/.12),a=(f.mode==='hide'?.9:1)*tipFade;if(a<.01)continue;
    let started=false;
    for(const p of b.points){const d=rOf(p,b.sx)-b.thr;if(f.mode==='hide'?(d>=0&&d<.1):(d<=0&&d>-.12)){if(!started){ctx.beginPath();ctx.moveTo(p[0],p[1]);started=true;}else ctx.lineTo(p[0],p[1]);}}
    if(started){ctx.lineWidth=7;ctx.strokeStyle=rgba(HOT_BLOOM,.16*a);ctx.stroke();ctx.lineWidth=2.6;ctx.strokeStyle=rgba(HOT_BLOOM,.42*a);ctx.stroke();ctx.lineWidth=1.3;ctx.strokeStyle=rgba(HOT_CORE,.85*a);ctx.stroke();}
    const p=b.at,r=1.6,gr=ctx.createRadialGradient(p[0],p[1],0,p[0],p[1],r*4);gr.addColorStop(0,rgba(HOT_BLOOM,.5*a));gr.addColorStop(1,rgba(HOT_BLOOM,0));
    ctx.fillStyle=gr;ctx.fillRect(p[0]-r*4,p[1]-r*4,r*8,r*8);ctx.fillStyle=rgba(HOT_CORE,a);ctx.beginPath();ctx.arc(p[0],p[1],r*.8,0,TAU);ctx.fill();
  }
  for(const s of parts){if(s.v11!=='tip')continue;const p=s.points[0],a=s.strength,r=1.5;if(a<.01)continue;
    ctx.fillStyle=rgba(HOT_CORE,a);ctx.beginPath();ctx.moveTo(p[0],p[1]-r*2);ctx.lineTo(p[0]+r*.35,p[1]);ctx.lineTo(p[0],p[1]+r*2);ctx.lineTo(p[0]-r*.35,p[1]);ctx.closePath();ctx.fill();
    const gr=ctx.createRadialGradient(p[0],p[1],0,p[0],p[1],r*4);gr.addColorStop(0,rgba(HOT_BLOOM,.35*a));gr.addColorStop(1,rgba(HOT_BLOOM,0));ctx.fillStyle=gr;ctx.fillRect(p[0]-r*4,p[1]-r*4,r*8,r*8);}
}
