/** Yvaelle’s Toolbox v11 · Invisibility: the model (pure, no Foundry globals).
 *
 * Four looks, chosen by where her invisibility comes from:
 *   classic  the drain: the light leaves every filament root → tip, her
 *            portrait drains to its frame outline (the v11 lab's shadow wings)
 *   a        tech cloak A · refraction edge
 *   b        tech cloak B · hardlight panels
 *   c        tech cloak C · scan dissolve (gentler v11-refine flicker)
 * Sources, strongest first:
 *   skin     an effect whose slug or name matches /invisibility[- ]skin/i (her augment)
 *   fade     the manual Fade (quick wheel, api.v11.fade)
 *   spell    the Invisible condition from anything else
 *   hidden   the Hidden or Undetected conditions (always the classic look)
 * A tech cloak sweeps a front across her (token, wings, bits, shadow) in her
 * own frame, from one of four sides; uncloaking runs it back. Every client
 * computes the same front from one token flag {on, start, dir, variant}
 * (start = game.time.serverTime): no per-frame network traffic.
 *
 * Who sees what (Foundry's own visibility always applies first; nothing here
 * can show her to someone Foundry hides her from):
 *   owner    her owner or a GM: what Settings › Invisibility › "What you see of her while hidden"
 *            picks (test.7): faint (her own look at her token's ghost strength, default), gone
 *            (as others), threads (the classic lilac outline, up to test.6)
 *   detected Foundry draws her to this player through a detection mode
 *            (see invisibility, tremorsense…): they keep the ghost too, so a
 *            sense never loses her
 *   other    everyone else: nothing behind the front. */

export const LOOKS=Object.freeze(['classic','a','b','c','plumage','ink','iris','starfall','ribbons','halftone','curtain','eclipse','aurora']);
/** Display names (the settings pickers and the wheel's Fade gem). */
export const LOOK_NAMES=Object.freeze({classic:'Classic drain',a:'Refraction',b:'Hardlight panels',c:'Scan dissolve',plumage:'Plumage',ink:'Ink',iris:'Iris',starfall:'Starfall',ribbons:'Ribbons',halftone:'Halftone',curtain:'Curtain',eclipse:'Eclipse',aurora:'Aurora'});
export const DIRS=Object.freeze(['left','right','top','bottom']);
export const SKIN_RE=/invisibility[- ]skin/i;
export const CLOAK_FLAG='v11Cloak';
/** The front: a 3.8 s eased sweep that overshoots her edges by 8 % each side. */
export const CLOAK=Object.freeze({sweep:3.8,over:1.08});
/** (12.0.0-beta.5) Cloak depth: how long a cloak's sweep takes (s), by her speed choice. Normal is the length it always had. */
export const CLOAK_SPEEDS=Object.freeze({slow:5.5,normal:CLOAK.sweep,quick:2.4,swift:1.4});
/** A cloak warp's sweep and an attack's flourish: short, whatever her speed. */
export const CLOAK_QUICK=Object.freeze({warp:1.1,flourish:.85});
/** The length of a flag's sweep (s): its own T when it carries one (a speed other than normal), else the standard 3.8 s.
 * Every client reads it from the synced flag, so they all run the same front. */
export const sweepOf=flag=>{const T=Number(flag?.T);return T>=.4&&T<=10?T:CLOAK.sweep;};
/** The looks a rotating Fade steps through (every cloak look; the Classic drain is not one). */
export const ROTATION=Object.freeze(['c','a','b','plumage','ink','iris','starfall','ribbons','halftone','curtain','eclipse','aurora']);
export const nextLook=prev=>ROTATION[(ROTATION.indexOf(prev)+1)%ROTATION.length];
/** The classic drain's timing (lab/canvas2 v11-fx.mjs SH). */
export const DRAIN=Object.freeze({hide:2.0,reveal:1.9,done:1.05});
/** C's signal flicker, toned down in the v11 refine (refine/cloak FLICKER). */
export const FLICKER=Object.freeze({shift:2.0,split:.25,zone:.065,rate:.93,bright:.14});
export const FLICKER_V10=Object.freeze({shift:5.0,split:.6,zone:.14,rate:.86,bright:.30});
const SIDE=.21;
/** Sweep directions in her frame: the front travels along dirA (radians, y down); tilt slants C's scan lines. */
export const DIRECTIONS=Object.freeze({
  left:Object.freeze({dirA:SIDE,tilt:0}),
  right:Object.freeze({dirA:Math.PI-SIDE,tilt:0}),
  top:Object.freeze({dirA:Math.PI/2,tilt:.06}),
  bottom:Object.freeze({dirA:-Math.PI/2,tilt:.06}),
});
export const VARIANT_INDEX=Object.freeze({a:0,b:1,c:2,plumage:4,ink:5,iris:6,starfall:7,ribbons:8,halftone:9,curtain:10,eclipse:11,aurora:12});   // (3 is the flicker)

const unit=x=>x<0?0:x>1?1:x;
const lerp=(a,b,k)=>a+(b-a)*k;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const sine=x=>.5-.5*Math.cos(Math.PI*unit(x));
export const isCloak=look=>Object.prototype.hasOwnProperty.call(VARIANT_INDEX,look);

/* ------------------------------------------------------------------ */
/* Sources and looks                                                    */
/* ------------------------------------------------------------------ */
/** Does an item or effect (slug or name) read as her invisibility skin? */
export function isSkin(item){
  if(!item)return false;
  const s=item.slug??item.system?.slug??'',n=item.name??'';
  return SKIN_RE.test(String(s))||SKIN_RE.test(String(n));
}
/** Which source is active, from what her actor carries: {invisible, hidden, undetected, skin, fade} → source or null. */
export function activeSource({invisible=false,hidden=false,undetected=false,skin=false,fade=false}={}){
  if(skin)return 'skin';
  if(fade)return 'fade';
  if(invisible)return 'spell';
  if(hidden||undetected)return 'hidden';
  return null;
}
/** The look a source plays. choices: {invisLooks, invisSpell, invisSkin} from the registry.
 * Looks off → 'none' (the token layer's own hidden drain is all that plays). Hidden/Undetected: always classic. */
export function lookFor(source,choices={}){
  if(!source)return null;
  if(choices.invisLooks===false)return 'none';
  if(source==='hidden')return 'classic';
  const pick=source==='spell'?choices.invisSpell??'classic':choices.invisSkin??'c';
  return LOOKS.includes(pick)?pick:source==='spell'?'classic':'c';
}
export const dirOf=d=>DIRECTIONS[d]?d:'left';

/* ------------------------------------------------------------------ */
/* The front (flag sync)                                                */
/* ------------------------------------------------------------------ */
/** Where the front is at `now` (ms, server time) for a flag {on,start,dir,variant}.
 * f is normalised to her extent along the sweep: −over = her leading edge (all solid),
 * +over = her far edge (all cloaked). Behind the front (u < f) she is cloaked.
 * phase: solid | cloaking | cloaked | uncloaking; q = progress through the sweep. */
export function frontAt(flag,now,T=sweepOf(flag),O=CLOAK.over,out={f:-O,q:1,phase:'solid',moving:false}){
  if(!flag||!Number.isFinite(flag.start)){out.f=-O;out.q=1;out.phase='solid';out.moving=false;return out;}
  const q=Math.max(0,(now-flag.start)/(T*1000));out.q=q;out.moving=q<1;
  if(flag.on){out.f=lerp(-O,O,sine(q));out.phase=q<1?'cloaking':'cloaked';}
  else{out.f=lerp(O,-O,sine(q));out.phase=q<1?'uncloaking':'solid';}
  return out;
}
/** The flag for turning the cloak on or off at `now`. A sweep still running is
 * reversed from where it is (the front never jumps): start is moved back so the
 * eased curve continues from the same point. */
export function nextFlag(prev,on,now,{dir='left',variant='c',src='skin',T:want=null}={},T=CLOAK.sweep){
  // (uncloaking runs back the way it came: the same side and look as the cloak, whatever the settings say now)
  const keep=!on&&prev,look=keep?prev.variant:variant;
  // (12.0.0-beta.5) its length: the one asked for; else coming back takes as long as going did, and a new cloak the standard length
  const Tp=prev?sweepOf(prev):T,Tn=Number(want)>0?Number(want):keep?Tp:T;
  let start=now;
  if(prev&&Number.isFinite(prev.start)&&!!prev.on!==!!on){
    // (12.0.0-beta.4: the Classic drain is not a sweep that turns round: its reveal begins at her root again)
    const q=(now-prev.start)/(Tp*1000);
    if(q>=0&&q<1&&look!=='classic'&&prev.variant!=='classic')start=now-(1-q)*Tn*1000;
  }else if(prev&&!!prev.on===!!on&&Number.isFinite(prev.start))return {...prev};
  // (12.0.0-beta.4) 'classic' is kept: the manual Fade with the Classic drain as her look plays the drain itself, timed
  // from this flag like a sweep. Before, it was turned into 'c' here, so choosing Classic drain played the Scan dissolve.
  return {on:!!on,start:Math.round(start),dir:dirOf(keep?prev.dir:dir),variant:look==='classic'||isCloak(look)?look:'c',src:keep?prev.src??src:src,...(Math.abs(Tn-CLOAK.sweep)>1e-6?{T:Tn}:{})};
}
/** (12.0.0-beta.12) The first three looks (Refraction, Hardlight panels, Scan dissolve) draw everything off one front.
 * Each needs the front to run a little past her far edge before all of it is done: `u` in units of her extent (the part
 * of the look that trails the front) plus `px` scene px (what is sized in pixels: a hex, the scan line's tail). */
export const RUN_OUT=Object.freeze([Object.freeze({u:.10,px:1.3}),Object.freeze({u:.31,px:8}),Object.freeze({u:.20,px:10})]);
/** How much further those looks' front must travel than the shared one (a factor on it, 1 or more), so that it clears
 * her TOKEN at both ends. E is the extent the shader is given (px), tokenExtent her token's own half extent along the
 * sweep (px), Z the zoom. In flight her wings set E and the token is well inside: the factor is 1 (nothing changes).
 * On the ground, swept from the top or bottom, E was .9 of her token's half height, so the front stopped short of her
 * far edge; and on a map with a small grid the pixel-sized parts are large against her. */
export function runOut(variant,E,tokenExtent,Z=1,O=CLOAK.over){
  const r=RUN_OUT[variant];if(!r||!(E>0)||!(tokenExtent>0)||!(O>0))return 1;
  const k=(tokenExtent+r.px*(Z>0?Z:1))/E+r.u;return k>O?k/O:1;
}
/** Her half extent along the sweep direction (px), from axis-aligned bounds rectangles
 * [{x,y,width,height}] (her real meshes) and her centre and bank. Allocates nothing. */
export function extentAlong(rects,cx,cy,bank,dirA,fallback=50){
  const a=dirA+bank,dx=Math.cos(a),dy=Math.sin(a);let e=0;
  for(let i=0;i<rects.length;i++){const r=rects[i];if(!r||!(r.width>0)||!(r.height>0))continue;
    const x0=r.x-cx,y0=r.y-cy,x1=x0+r.width,y1=y0+r.height;
    const p=Math.max(Math.abs(x0*dx+y0*dy),Math.abs(x1*dx+y0*dy),Math.abs(x0*dx+y1*dy),Math.abs(x1*dx+y1*dy));if(p>e)e=p;}
  return e>1?e:fallback;
}

/* ------------------------------------------------------------------ */
/* The classic drain                                                    */
/* ------------------------------------------------------------------ */
/** The drain front (distance from the wing root / wing radius) q seconds after it began. */
export function drainFront(mode,q){
  if(mode==='hide')return lerp(-.08,1.28,smooth(q/DRAIN.hide)**1.15);
  return lerp(-.04,1.28,smooth(q/DRAIN.reveal)**.85);
}
/** How hidden her token and shadow are (0..1) during the classic drain. */
export function drainHid(mode,F){return mode==='hide'?smooth((F+.02)/.35):1-smooth((F+.02)/.3);}
/** How drained a bit is (0..1): a bit sits about half way out (i = its index). */
export function bitDrained(mode,F,i=0){const rb=.55+.05*i;return mode==='hide'?smooth((F-rb)/.18):1-smooth((F-rb+.05)/.2);}

/* ------------------------------------------------------------------ */
/* Who sees what                                                        */
/* ------------------------------------------------------------------ */
/** (11.0.0-test.7) What her owner or a GM sees of her while hidden (Settings › Invisibility, this browser):
 *   faint    her normal wings, bits, shadow and effects at the strength of her token's own owner ghost
 *            (no thread repaint; measured in WebGL from the token layer's held look, all four frames:
 *            0.135–0.140 of her solid alpha, so 0.14)
 *   gone     exactly what other players see (nothing)
 *   threads  the drained ghost outline (the look up to test.6) */
export const OWNER_VIEWS=Object.freeze(['faint','gone','threads']);
export const TOKEN_GHOST=.14;
export const ownerViewOf=v=>OWNER_VIEWS.includes(v)?v:'faint';
/** owner | faint | detected | other. (Foundry decides first whether she is drawn at all.)
 * ownerView applies to her owner and the GM only: a sense that finds her (detected) keeps the outline. */
export function viewOf({isOwner=false,isGM=false,detected=false,ownerView='threads'}={}){
  if(isOwner||isGM){const v=ownerViewOf(ownerView);return v==='gone'?'other':v==='faint'?'faint':'owner';}
  return detected?'detected':'other';
}
/** Does this view keep a ghost behind the front (and while cloaked)? */
export const keepsGhost=view=>view==='owner'||view==='detected'||view==='faint';
/** Is the ghost the drained thread outline (her wings repainted with the drain held)? Faint keeps her own pattern. */
export const threadGhost=view=>view==='owner'||view==='detected';
/** Her alpha multipliers while cloaked/drained for a view: wings (default), bits, shadow, fx. */
export function veilAlpha(view,hid,kind){
  if(view==='faint')return 1-hid*(1-TOKEN_GHOST);
  const g=keepsGhost(view);
  if(kind==='bits')return 1-hid*(g?.7:1);
  if(kind==='shadow')return 1-hid*(g?.75:1);
  // (test.3) her phase 3 effects off her wings (heal strokes, the lent bit, emote lights, turn glow, glints, shadow copies)
  if(kind==='fx')return 1-hid*(g?.85:1);
  return 1-hid*(g?.5:1);
}
/** The cloak filter's ghost strength behind the front for a piece (kind wing|bits|shadow|compact|token), as the
 * filter's uKind.y: positive = the lilac ghost (threads views), negative = her own pixels at that strength (faint).
 * Equal to veilAlpha held, so the hand-over from the filter to plain alpha at the end of a sweep shows no step. */
export function filterGhost(view,kind){
  if(view==='faint')return -TOKEN_GHOST;
  return kind==='shadow'?.25:kind==='bits'||kind==='compact'?.3:.5;
}

/* ------------------------------------------------------------------ */
/* Flicker on hit                                                       */
/* ------------------------------------------------------------------ */
/** The strain envelope after a hit (s): a quick rise, two soft wavers, a slow thinning. */
export const FLICK=Object.freeze([[0,0],[.09,.9],[.2,.58],[.33,1],[.47,.72],[.64,.84],[1.0,.5],[1.75,0]].map(Object.freeze));
export const FLICK_LEN=1.8;
function keys(K,q){if(q<=K[0][0])return K[0][1];for(let i=1;i<K.length;i++)if(q<K[i][0]){const a=K[i-1],b=K[i],k=(q-a[0])/(b[0]-a[0]);return a[1]+(b[1]-a[1])*smooth(k);}return K[K.length-1][1];}
/** Severity of a blow from the HP she lost (0..1): 14 of 88 ≈ .72, 6 of 88 ≈ .31. */
export function hitSeverity(lost,max){return lost>0&&max>0?Math.max(.2,Math.min(1,lost/max*4.5)):0;}
/** The flicker's strength q s after a hit of severity sev (0..1). */
export function flickerAt(q,sev){return q<0||q>=FLICK_LEN?0:Math.min(1,keys(FLICK,q)*(.55+.6*sev));}
/** How solid she shows during a flicker (lab ivAlpha): owner/GM .2 → .68 at the peak;
 * others nothing, or a faint glimpse (a third of the strength) with the GM option. */
export function flickerSolid(view,fl,othersGlimpse=false){
  if(view==='faint')return (.68-TOKEN_GHOST)*fl/.8;
  if(keepsGhost(view))return (.68-.2)*fl/.8;
  return othersGlimpse?.2*fl:0;
}
/** How strongly the fringe and slip show for a view (others at half, only with the GM option). */
export const flickerDetail=(view,othersGlimpse=false)=>keepsGhost(view)?1:othersGlimpse?.5:0;
/** The 1 px slip on the first ~0.28 s (the augment losing its lock). */
export const slipAt=(q,fl)=>q<.28?(1-q/.28)*fl:0;
/** The hardlight fringe while she strains. */
export const fringeAt=(q,fl)=>fl*(.55+.45*Math.sin(q*9.5));
/** The tremor in her hover (px at 1:1): shown as an offset inside the filter, never on her transform. */
export const tremorAt=(t,fl)=>.6*fl*Math.sin(t*23);
