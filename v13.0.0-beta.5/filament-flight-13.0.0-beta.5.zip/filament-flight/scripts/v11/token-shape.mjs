/** Yvaelle’s Toolbox v11 · Her token's shape profile (11.0.0-test.9).
 *
 * One measured description of her token as it is really drawn, used by everything that used to assume "a round
 * token of a fixed size": the token layer (what moves, where rim lights and beads sit), the cloak (the thin ghost
 * outline), the wingless damage marks, and the self-check's masks.
 *
 *   measureShape(rgba, N)      pure: from an N×N straight-alpha copy of her token art →
 *     cover      share of the texture her art covers          bounds   her art's box inside the texture (0..1)
 *     centre     her art's centre (0..1)                      fill     her art's share of its own box
 *     edge[]     the distance from the TEXTURE centre to her art's outer edge, per angle (ANGLES of them,
 *                half-texture units: 1 = the middle of a side), so non-round art works
 *     shape      round | rounded (a rounded square) | square | irregular (a cut-out) | empty
 *     border     {found, thickness (radii, the median), per[] (thickness per angle), uniform (share of angles
 *                that agree), inset, colour [r,g,b], brightness, source: art | fallback | manual | foundry-ring}
 *     portrait   the share of her art that lies inside the border
 *   shapeMask(rgba, N, profile) the mask the filters sample (R the border band, G a thin line along her art's edge,
 *                B the picture inside the border), following the measured edge and the per-angle thickness
 *   manualShape(opts)          a profile and mask from the Manual setting (round or square, border thickness and
 *                inset as % of her radius), or her art's own edge with a border forced
 *   shapeTextureOf(tex, opts)  mask + profile as a PIXI texture, cached per base texture and override
 *                (measured once per picture on first ask: about a millisecond for 128×128; nothing per frame)
 *   tokenShape(token, opts)    the profile plus how her token is drawn now (grid size, mesh size, texture scale,
 *                fit, anchor, rotation, mirror, the flight's height shrink, Foundry's dynamic ring)
 *   describeShape(profile)     "round · border 5% at 0.90 · art fills 96%" (how far her art reaches across the picture)
 *
 * The border is found as in test.8 (walking inward from her art's alpha edge, the depth where the colour changes
 * most), now also per angle, so a border whose thickness varies is followed. No border found: a band of 10 % of her
 * radius along her art's own edge. Foundry's dynamic token ring is not part of the picture: with it on, the band is
 * a plain circle (source foundry-ring). */
export const SHAPE_N=128,ANGLES=96;
const DEFAULT_T=.10,MIN_T=.04,MAX_T=.20,TAU=Math.PI*2;
const sm=(a,b,x)=>{x=(x-a)/(b-a);x=x<0?0:x>1?1:x;return x*x*(3-2*x);};
const median=a=>{const s=[...a].sort((x,y)=>x-y);return s.length?s[s.length>>1]:0;};

/** Chamfer distance (3-4) to the nearest transparent pixel, in pixels. */
export function distanceInside(alpha,N){
  const d=new Float32Array(N*N),BIG=1e6;
  for(let i=0;i<N*N;i++)d[i]=alpha[i]>127?BIG:0;
  const at=(x,y)=>x<0||y<0||x>=N||y>=N?0:d[y*N+x];
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){const i=y*N+x;if(!d[i])continue;
    d[i]=Math.min(d[i],at(x-1,y)+3,at(x,y-1)+3,at(x-1,y-1)+4,at(x+1,y-1)+4);}
  for(let y=N-1;y>=0;y--)for(let x=N-1;x>=0;x--){const i=y*N+x;if(!d[i])continue;
    d[i]=Math.min(d[i],at(x+1,y)+3,at(x,y+1)+3,at(x+1,y+1)+4,at(x-1,y+1)+4);}
  for(let i=0;i<N*N;i++)d[i]/=3;
  return d;
}
/** r(θ) of a superellipse of exponent p and half-size 1 (p = 2 a circle, p → ∞ a square). */
const superR=(th,p)=>{const c=Math.abs(Math.cos(th)),s=Math.abs(Math.sin(th));return p===Infinity?1/Math.max(c,s):1/Math.pow(Math.pow(c,p)+Math.pow(s,p),1/p);};
const ANGLE_OF=i=>i*TAU/ANGLES;
/** Linear lookup in a per-angle table. */
export function atAngle(table,ang){let f=((ang%TAU)+TAU)%TAU/TAU*table.length;const i=Math.floor(f)%table.length,j=(i+1)%table.length;f-=Math.floor(f);return table[i]*(1-f)+table[j]*f;}

/** Measure her token art. rgba: N×N, straight alpha. */
export function measureShape(rgba,N=SHAPE_N){
  const R=N/2,alpha=new Uint8Array(N*N);let inside=0,x0=N,y0=N,x1=-1,y1=-1,sx=0,sy=0;
  for(let i=0;i<N*N;i++){const a=alpha[i]=rgba[i*4+3];if(a>127){inside++;const x=i%N,y=(i/N)|0;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;sx+=x+.5;sy+=y+.5;}}
  const edge=new Float32Array(ANGLES),per=new Float32Array(ANGLES).fill(DEFAULT_T);
  if(!inside)return {n:N,cover:0,bounds:{x:0,y:0,w:0,h:0},centre:{x:.5,y:.5},fill:0,edge,own:new Float32Array(ANGLES),shape:'empty',exponent:2,fit:1,solidity:0,
    border:{found:false,thickness:DEFAULT_T,per,uniform:0,inset:0,colour:[128,128,128],brightness:.5,source:'fallback',radius:1-DEFAULT_T/2},portrait:0};
  const cx=sx/inside,cy=sy/inside,bw=x1-x0+1,bh=y1-y0+1;
  // the outer edge per angle: from the texture's centre (the filters' frame) and from her art's own centre (its shape)
  const ray=(ox,oy,th)=>{const dx=Math.cos(th),dy=Math.sin(th);let last=0;for(let r=0;r<N*1.5;r+=.5){const x=Math.floor(ox+dx*r),y=Math.floor(oy+dy*r);if(x<0||y<0||x>=N||y>=N)break;if(alpha[y*N+x]>127)last=r+.5;}return last;};
  const own=new Float32Array(ANGLES);let om=0;
  for(let i=0;i<ANGLES;i++){edge[i]=ray(R,R,ANGLE_OF(i))/R;own[i]=ray(cx,cy,ANGLE_OF(i));om+=own[i];}
  om/=ANGLES;
  // shape: the superellipse that fits her own outline best (about her art's centre, sized to her box)
  const hx=bw/2,hy=bh/2;let best=Infinity,exponent=2;
  for(const p of [2,2.6,3.5,5,8,Infinity]){let e=0;for(let i=0;i<ANGLES;i++){const th=ANGLE_OF(i),c=Math.cos(th),s=Math.sin(th),
      // an axis-aligned superellipse with half-sizes hx, hy
      k=p===Infinity?1/Math.max(Math.abs(c)/hx,Math.abs(s)/hy):1/Math.pow(Math.pow(Math.abs(c)/hx,p)+Math.pow(Math.abs(s)/hy,p),1/p);
      e+=((own[i]-k)/Math.max(1,k))**2;}
    e=Math.sqrt(e/ANGLES);if(e<best-1e-4){best=e;exponent=p;}}
  // how much of the fitted outline her art fills (a cut-out with arms or a weapon leaves gaps)
  let poly=0;for(let i=0;i<ANGLES;i++){const j=(i+1)%ANGLES;poly+=.5*own[i]*own[j]*Math.sin(TAU/ANGLES);}
  const solidity=Math.min(1,inside/Math.max(1,poly));
  const shape=best>.075||solidity<.86?'irregular':exponent<=2.6?'round':exponent===Infinity?'square':'rounded';
  // the border: the depth from her art's edge where the colour steps most (all angles together, then per angle)
  const d=distanceInside(alpha,N),BINS=32,rr=Math.min(hx,hy)||R;
  const stepAt=(pick)=>{const sum=new Float64Array(BINS*3),cnt=new Float64Array(BINS);
    for(let i=0;i<N*N;i++){if(alpha[i]<=127||!pick(i))continue;const b=Math.floor(d[i]/R*100);if(b>=BINS)continue;cnt[b]++;sum[b*3]+=rgba[i*4];sum[b*3+1]+=rgba[i*4+1];sum[b*3+2]+=rgba[i*4+2];}
    // (a straight edge gives whole-pixel depths: a bin no pixel falls in takes the one before it)
    for(let b=1;b<BINS;b++)if(!cnt[b]&&cnt[b-1]){cnt[b]=cnt[b-1];sum[b*3]=sum[b*3-3];sum[b*3+1]=sum[b*3-2];sum[b*3+2]=sum[b*3-1];}
    const mean=b=>cnt[b]>0?[sum[b*3]/cnt[b],sum[b*3+1]/cnt[b],sum[b*3+2]/cnt[b]]:null;let top=0,at=-1;
    for(let b=Math.round(MIN_T*100);b<=Math.round(MAX_T*100);b++){const o=[mean(b-2),mean(b-1)],n=[mean(b+1),mean(b+2)];if(o.includes(null)||n.includes(null))continue;
      let j=0;for(let c=0;c<3;c++)j+=Math.abs((o[0][c]+o[1][c])/2-(n[0][c]+n[1][c])/2);if(j>top){top=j;at=b;}}
    return {top,at};};
  const all=stepAt(()=>true),found=all.top>=36,T=found?Math.max(MIN_T,Math.min(MAX_T,(all.at+.5)/100)):DEFAULT_T;
  // per angle (twelve sectors about her art's centre, then spread over the angles): a border whose thickness varies
  const SECT=12,sect=new Float32Array(SECT).fill(T);let agree=0;
  if(found){const sectorOf=new Uint8Array(N*N);for(let y=0;y<N;y++)for(let x=0;x<N;x++){let a=Math.atan2(y+.5-cy,x+.5-cx);if(a<0)a+=TAU;sectorOf[y*N+x]=Math.min(SECT-1,Math.floor(a/TAU*SECT));}
    // (a sector counts only when its own step is clear: at least half as strong as her whole border's; then a 3-sector median, so one odd sector cannot dent the band)
    const raw=new Float32Array(SECT).fill(T);
    for(let k=0;k<SECT;k++){const s=stepAt(i=>sectorOf[i]===k);if(s.top>=Math.max(30,all.top*.5)&&s.at>=0){raw[k]=Math.max(MIN_T,Math.min(MAX_T,(s.at+.5)/100));if(Math.abs(raw[k]-T)<=Math.max(.02,T*.35))agree++;}}
    let lo=1,hi=0;for(let k=0;k<SECT;k++){sect[k]=median([raw[(k+SECT-1)%SECT],raw[k],raw[(k+1)%SECT]]);if(sect[k]<lo)lo=sect[k];if(sect[k]>hi)hi=sect[k];}
    if(hi-lo<.03){sect.fill(T);agree=SECT;}
    for(let i=0;i<ANGLES;i++){const f=i/ANGLES*SECT-.5,a=((Math.floor(f)%SECT)+SECT)%SECT,b=(a+1)%SECT,u=f-Math.floor(f);per[i]=sect[a]*(1-u)+sect[b]*u;}
  }else per.fill(T);
  // the band's colour and mean radius, the portrait's share
  let rs=0,rn=0,cr=0,cg=0,cb=0,inner=0;
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){const i=y*N+x;if(alpha[i]<=127)continue;const t=found?atAngle(per,Math.atan2(y+.5-cy,x+.5-cx)):T;
    if(d[i]/R<t){rs+=Math.hypot(x+.5-R,y+.5-R)/R;rn++;cr+=rgba[i*4];cg+=rgba[i*4+1];cb+=rgba[i*4+2];}else inner++;}
  const colour=rn?[Math.round(cr/rn),Math.round(cg/rn),Math.round(cb/rn)]:[128,128,128];
  return {n:N,cover:inside/(N*N),bounds:{x:x0/N,y:y0/N,w:bw/N,h:bh/N},centre:{x:cx/N,y:cy/N},fill:inside/(bw*bh),edge,own,shape,exponent,fit:best,solidity,
    border:{found,thickness:T,per,uniform:found?agree/SECT:0,inset:0,colour,brightness:(colour[0]*.2126+colour[1]*.7152+colour[2]*.0722)/255,source:found?'art':'fallback',radius:rn?rs/rn:1-T/2},
    portrait:inside?inner/inside:0,half:rr/R};
}
/** The mask the filters sample, from her art and its profile: R band, G edge line, B the picture inside the border, A 255. */
export function shapeMask(rgba,N,profile){
  const R=N/2,alpha=new Uint8Array(N*N);for(let i=0;i<N*N;i++)alpha[i]=rgba[i*4+3];
  const d=distanceInside(alpha,N),data=new Uint8ClampedArray(N*N*4),B=profile.border,cx=profile.centre.x*N,cy=profile.centre.y*N,vary=B.found&&B.source==='art'&&B.uniform<.999;
  const inset=B.inset||0;
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){const i=y*N+x,o=i*4;data[o+3]=255;if(!alpha[i])continue;
    const dr=d[i]/R,a=alpha[i]/255,T=(vary?atAngle(B.per,Math.atan2(y+.5-cy,x+.5-cx)):B.thickness)+inset;
    const inBand=B.thickness>0?(1-sm(T-.012,T+.012,dr))*(inset>0?sm(inset-.012,inset+.012,dr):1):0;
    data[o]=Math.round(255*a*inBand);
    data[o+2]=Math.round(255*a*(B.thickness>0?sm(T-.012,T+.012,dr):1));
    data[o+1]=Math.round(255*a*(1-sm(.008,.028,dr)));}
  return data;
}
/** A synthetic picture of a plain shape (the Manual setting, Foundry's dynamic ring, a picture that cannot be read). */
export function plainPicture(N=SHAPE_N,shape='round',size=1){
  const rgba=new Uint8ClampedArray(N*N*4),R=N/2;
  for(let y=0;y<N;y++)for(let x=0;x<N;x++){const u=(x+.5-R)/R,v=(y+.5-R)/R,r=shape==='square'?Math.max(Math.abs(u),Math.abs(v)):Math.hypot(u,v),o=(y*N+x)*4;rgba[o]=rgba[o+1]=rgba[o+2]=128;rgba[o+3]=r<=size?255:0;}
  return rgba;
}
/** The Manual setting → {profile, data}. opts: {shape: round | square | art, border (radii), inset (radii)}; rgba: her art (for `art`). */
export function manualShape(opts={},rgba=null,N=SHAPE_N){
  const shape=opts.shape==='square'?'square':opts.shape==='art'&&rgba?'art':'round';
  const src=shape==='art'?rgba:plainPicture(N,shape),p=measureShape(src,N),t=Math.max(0,Math.min(.4,Number(opts.border)));
  const T=Number.isFinite(t)?t:DEFAULT_T,inset=Math.max(0,Math.min(.3,Number(opts.inset)||0));
  p.border={...p.border,found:T>0,thickness:T,per:new Float32Array(ANGLES).fill(T),uniform:1,inset,source:'manual',radius:Math.max(0,meanEdge(p)-inset-T/2)};
  if(shape!=='art')p.shape=shape;
  p.portrait=Math.max(0,1-(T+inset)*2);
  return {profile:p,data:shapeMask(src,N,p)};
}
const meanEdge=p=>{let s=0;for(let i=0;i<p.edge.length;i++)s+=p.edge[i];return s/p.edge.length;};
/** Her measured art → {profile, data} (Automatic). */
export function autoShape(rgba,N=SHAPE_N){const profile=measureShape(rgba,N);return {profile,data:shapeMask(rgba,N,profile)};}
/** A plain circular band: Foundry's dynamic ring (drawn by Foundry round the picture), or a picture that cannot be read. */
export function plainShape(source='fallback',N=SHAPE_N,T=DEFAULT_T){
  const src=plainPicture(N,'round'),p=measureShape(src,N);p.border={...p.border,found:source==='foundry-ring',thickness:T,per:new Float32Array(ANGLES).fill(T),uniform:1,source,radius:1-T/2};
  p.fallback=source==='fallback';return {profile:p,data:shapeMask(src,N,p)};
}
/** Where the border band's middle is at an angle (radii from the texture's centre): where the beads ride. */
export function bandRadiusAt(profile,ang){
  if(!profile?.edge)return .95;const B=profile.border,e=atAngle(profile.edge,ang),t=(B.per?atAngle(B.per,ang):B.thickness)||DEFAULT_T;
  return Math.max(.05,e-(B.inset||0)-t/2);
}
/** One line for people: "round · border 5% at 0.90 · art fills 96%". */
export function describeShape(p){
  if(!p)return 'not measured yet';if(p.shape==='empty')return 'no picture';
  const B=p.border,pc=v=>`${Math.round(v*100)}%`,name={round:'round',rounded:'rounded square',square:'square',irregular:'cut-out'}[p.shape]??p.shape;
  const src=B.source==='manual'?' (manual)':B.source==='foundry-ring'?' (Foundry’s dynamic ring)':B.source==='fallback'?' (none found: a plain band)':'';
  const border=B.thickness>0?`border ${pc(B.thickness)}${B.found&&B.source==='art'&&B.uniform<.75?' (varies)':''} at ${B.radius.toFixed(2)}${src}`:'no border (manual)';
  // (how far her art reaches across the picture: the larger side of its box; both sides when they differ)
  const w=p.bounds.w,h=p.bounds.h,fills=Math.abs(w-h)>.04?`${pc(w)}×${pc(h)}`:pc(Math.max(w,h));
  return `${name} · ${border} · art fills ${fills}`;
}

/* ------------------------------------------------------------------ in Foundry */
const cache=new WeakMap();let plains=null;
const keyOf=o=>!o||o.mode!=='manual'?(o?.ring?'ring':'auto'):`m:${o.shape}:${o.border}:${o.inset}`;
function toTexture(made,PIXI,N){
  const c=globalThis.document.createElement('canvas');c.width=c.height=N;const ctx=c.getContext('2d');
  const img=ctx.createImageData(N,N);img.data.set(made.data);ctx.putImageData(img,0,0);
  const texture=PIXI.Texture.from(c,{mipmap:PIXI.MIPMAP_MODES?.OFF??0}),p=made.profile,B=p.border;
  return {texture,profile:p,thickness:B.thickness,radius:B.radius,found:B.found,fallback:!!p.fallback,cover:p.cover};
}
/** Her token texture's mask and profile: {texture, profile, thickness, radius, found, fallback, cover}.
 * opts: {mode: auto | manual, shape, border, inset, ring (Foundry's dynamic ring is on)}. Cached per base texture and override. */
export function shapeTextureOf(tex,opts=null,PIXI=globalThis.PIXI){
  if(!PIXI?.Texture?.from||!globalThis.document?.createElement)return null;
  const N=SHAPE_N,key=keyOf(opts),base=tex?.baseTexture;
  const plain=k=>{try{return (plains??={})[k]??=toTexture(k==='ring'?plainShape('foundry-ring'):plainShape('fallback'),PIXI,N);}catch{return null;}};
  if(key==='ring')return plain('ring');
  if(!base||typeof base!=='object'){if(key.startsWith('m:')&&opts.shape!=='art'){try{return (plains??={})[key]??=toTexture(manualShape(opts,null,N),PIXI,N);}catch{return null;}}return plain('fallback');}
  let per=cache.get(base);if(!per){per=new Map();cache.set(base,per);}
  const fk=`${key}|${tex.frame?`${tex.frame.x},${tex.frame.y},${tex.frame.width},${tex.frame.height}`:''}`;const hit=per.get(fk);if(hit)return hit;
  let rec=null;
  try{
    let rgba=null;const src=base.resource?.source;
    if(src&&base.valid!==false){
      const c=globalThis.document.createElement('canvas');c.width=c.height=N;const ctx=c.getContext('2d',{willReadFrequently:true});
      const f=tex.frame,sw=src.videoWidth||src.naturalWidth||src.width,k=sw/(base.width||sw||1);
      if(f&&f.width>0&&f.height>0)ctx.drawImage(src,f.x*k,f.y*k,f.width*k,f.height*k,0,0,N,N);else ctx.drawImage(src,0,0,N,N);
      rgba=ctx.getImageData(0,0,N,N).data;
    }
    if(key.startsWith('m:'))rec=toTexture(manualShape(opts,rgba,N),PIXI,N);
    else if(rgba){const made=autoShape(rgba,N);if(made.profile.cover>.02)rec=toTexture(made,PIXI,N);}
  }catch{rec=null;}
  if(!rec)rec=key.startsWith('m:')?(()=>{try{return toTexture(manualShape({...opts,shape:opts.shape==='art'?'round':opts.shape},null,N),PIXI,N);}catch{return null;}})():plain('fallback');
  if(rec)per.set(fk,rec);return rec;
}
/** Is Foundry's dynamic token ring drawn round her picture? */
export function hasFoundryRing(token){
  try{const d=token?.document;return !!(token?.hasDynamicRing??d?.ring?.enabled);}catch{return false;}
}
/** The Manual setting's values → opts for shapeTextureOf (pct strings from the pickers). */
export function fitOptions({mode='auto',shape='round',border='10',inset='0'}={},ring=false){
  if(mode==='manual')return {mode:'manual',shape:['round','square','art'].includes(shape)?shape:'round',border:(Number(border)||0)/100,inset:(Number(inset)||0)/100};
  return ring?{mode:'auto',ring:true}:null;
}
/** How her token is drawn now (read on ask, never per frame). `flight`: her flight state (the height shrink), if any. */
export function drawnShape(token,flight=null){
  const d=token?.document,m=token?.mesh,tex=m?.texture,grid=globalThis.canvas?.grid?.size||globalThis.canvas?.dimensions?.size||100,num=(v,f)=>Number.isFinite(Number(v))?Number(v):f;
  const sx=num(m?.scale?.x,1),sy=num(m?.scale?.y,1),tw=num(tex?.orig?.width??tex?.width,0),th=num(tex?.orig?.height??tex?.height,0);
  return {grid:{w:num(d?.width,1),h:num(d?.height,1),size:grid},
    mesh:{w:Math.abs(sx)*tw,h:Math.abs(sy)*th},texture:{w:tw,h:th,src:d?.texture?.src??null},
    scale:{x:num(d?.texture?.scaleX,1),y:num(d?.texture?.scaleY,1)},fit:d?.texture?.fit??null,
    anchor:{x:num(m?.anchor?.x??d?.texture?.anchorX,.5),y:num(m?.anchor?.y??d?.texture?.anchorY,.5)},
    rotation:num(d?.rotation,0),mirror:{x:sx<0||num(d?.texture?.scaleX,1)<0,y:sy<0||num(d?.texture?.scaleY,1)<0},
    heightScale:num(flight?.altScale,1),foundryRing:hasFoundryRing(token)};
}
/** api.v11.tokenShape(token): her art's measured profile and how she is drawn. */
export function tokenShape(token,opts=null,flight=null){
  const drawn=drawnShape(token,flight),o=opts??(drawn.foundryRing?{mode:'auto',ring:true}:null),rec=shapeTextureOf(token?.mesh?.texture??null,o),p=rec?.profile??null;
  if(!p)return {drawn,measured:false,text:'not measured (no canvas here)'};
  // her art's real size on the canvas (scene px): the mesh rectangle times her art's box inside the picture
  const art={w:drawn.mesh.w*p.bounds.w,h:drawn.mesh.h*p.bounds.h};
  return {drawn,measured:true,fallback:!!p.fallback,mode:o?.mode==='manual'?'manual':'auto',shape:p.shape,cover:p.cover,bounds:p.bounds,centre:p.centre,fill:p.fill,edge:Array.from(p.edge),
    border:{...p.border,per:Array.from(p.border.per)},portrait:p.portrait,art,text:describeShape(p)};
}

/* ------------------------------------------------------------------ the detector against pictures it must get right */
/** Synthetic token pictures, measured (the self-check prints this; tools/v11/test-token-shape.mjs asserts more).
 * → [{name, ok, got}] */
export function shapeSelfTest(N=SHAPE_N){
  const R=N/2,pic=(depth,ring=.1,flat=false)=>{const d=new Uint8ClampedArray(N*N*4);
    for(let y=0;y<N;y++)for(let x=0;x<N;x++){const u=(x+.5-R)/R,v=(y+.5-R)/R,k=depth(u,v),o=(y*N+x)*4;if(!(k>0))continue;const g=!flat&&k<ring;d[o]=g?214:70;d[o+1]=g?170:60;d[o+2]=g?90:110;d[o+3]=255;}return d;};
  const round=o=>(u,v)=>o-Math.hypot(u,v),square=h=>(u,v)=>h-Math.max(Math.abs(u),Math.abs(v));
  const cut=(u,v)=>Math.max(.34-Math.hypot(u,v*1.1),.09-Math.hypot(Math.max(0,Math.abs(u)-.55),v+.1),.05-Math.hypot(u-.42,Math.max(0,Math.abs(v)-.8)));
  const near=(a,b,t=.03)=>Math.abs(a-b)<=t,out=[],add=(name,p,ok)=>out.push({name,ok:!!ok,got:describeShape(p)});
  let p=measureShape(pic(round(.96),.1),N);add('round with a ring',p,p.shape==='round'&&p.border.found&&near(p.border.thickness,.1));
  p=measureShape(pic(square(.92),.1),N);add('square with a border',p,p.shape==='square'&&p.border.found&&near(p.border.thickness,.1)&&atAngle(p.edge,Math.PI/4)>1.2);
  p=measureShape(pic(cut,.1,true),N);add('borderless cut-out',p,p.shape==='irregular'&&!p.border.found);
  p=measureShape(pic((u,v)=>.5-Math.hypot(u+.2,v-.1),.08),N);add('art with a transparent margin',p,p.shape==='round'&&near(p.bounds.w,.5)&&near(p.centre.x,.4,.02)&&p.border.found);
  // a 2×2 token and a scaled one are the same picture drawn larger or smaller: the picture is measured at any size
  for(const [name,M] of [['2×2 token (a larger picture)',192],['scaled 0.8 (a smaller picture)',96],['scaled 1.3',160]]){
    const r=M/2,d=new Uint8ClampedArray(M*M*4);for(let y=0;y<M;y++)for(let x=0;x<M;x++){const k=.96-Math.hypot((x+.5-r)/r,(y+.5-r)/r),o=(y*M+x)*4;if(!(k>0))continue;const g=k<.1;d[o]=g?214:70;d[o+1]=g?170:60;d[o+2]=g?90:110;d[o+3]=255;}
    p=measureShape(d,M);add(name,p,p.shape==='round'&&p.border.found&&near(p.border.thickness,.1));}
  // rotated a quarter turn and mirrored: a border thicker on one side stays found, the thick side moves with the picture
  const base=pic(round(.96),.1),lop=new Uint8ClampedArray(base);for(let y=0;y<N;y++)for(let x=0;x<N;x++){const u=(x+.5-R)/R,v=(y+.5-R)/R,k=.96-Math.hypot(u,v),o=(y*N+x)*4;if(k>0&&k<.11+.05*v/Math.max(.2,Math.hypot(u,v))){lop[o]=214;lop[o+1]=170;lop[o+2]=90;}else if(k>0){lop[o]=70;lop[o+1]=60;lop[o+2]=110;}}
  const turn=new Uint8ClampedArray(N*N*4);for(let y=0;y<N;y++)for(let x=0;x<N;x++)turn.set(lop.subarray((x*N+(N-1-y))*4,(x*N+(N-1-y))*4+4),(y*N+x)*4);
  const p0=measureShape(lop,N);p=measureShape(turn,N);
  add('rotated and mirrored',p,p.shape==='round'&&p.border.found&&near(p.border.thickness,p0.border.thickness,.011)&&Math.abs(atAngle(p.border.per,0)-atAngle(p.border.per,Math.PI))>.03&&atAngle(p0.border.per,Math.PI/2)>atAngle(p0.border.per,-Math.PI/2)+.03);
  return out;
}
