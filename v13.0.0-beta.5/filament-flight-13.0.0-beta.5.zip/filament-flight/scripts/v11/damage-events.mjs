/** Yvaelle’s Toolbox v11 · Damage events (pure: no Foundry globals at import).
 *
 * What a PF2e chat message or actor update says about her, in the terms the
 * wounds, persistent damage and dying stages use:
 *  - the damage type of a blow (from the damage roll aimed at her, or the
 *    applied-damage message): the type of the largest non-persistent share;
 *  - which wound look that type wears (11 looks; spirit shares void's;
 *    anything else is the soft generic mark);
 *  - persistent-damage types (the 16 looks, any other name → the fallback),
 *    with a colour for the fallback from PF2e's own --color-border-<type>, or
 *    a stable hash of the name;
 *  - dying value and recovery checks (the flat-check message's outcome).
 *
 * Every client reads the same messages and the same actor data, so every
 * client derives the same thing. */

/** The 11 wound looks (the registry's chips, lower-cased). */
export const WOUND_LOOKS=Object.freeze(['slashing','piercing','bludgeoning','fire','cold','electricity','acid','poison','force','mental','void']);
/** The 16 persistent looks (lab order) and the registry part that switches each. */
export const PERSIST_LOOKS=Object.freeze(['bleed','fire','poison','acid','cold','electricity','sonic','mental','force','vitality','void','spirit','slashing','piercing','bludgeoning','precision']);
const cap=s=>s[0].toUpperCase()+s.slice(1);
/** Registry part id for a persistent look (bludgeoning has its own part since
 * 11.0.0-test.2; any type without a look of its own is the Fallback part's). */
const PP=new Map(),WP=new Map();
export function persistPart(look){let v=PP.get(look);if(!v){v=look==='fallback'?'persistFallback':'persist'+cap(look);PP.set(look,v);}return v;}
/** Registry part id for a wound look ('other' → woundOther). */
export function woundPart(look){let v=WP.get(look);if(!v){v=look==='other'?'woundOther':'wound'+cap(look);WP.set(look,v);}return v;}

/** Which persistent types v11 draws for her token, from resolveV11(doc)'s
 * frozen values: null when the feature is off, else type → bool (cached per
 * values object, so a frame's lookup is one WeakMap read). The v10 art uses
 * it to step aside (condition-response.mjs withoutV11Persistent). */
const PF=new WeakMap();
export function v11PersistFilter(values){
  if(!values||!values.persistent)return null;
  let f=PF.get(values);
  if(!f){const memo=new Map();f=type=>{let v=memo.get(type);if(v===undefined){v=!!values['persistent.'+persistPart(persistLookOf(type))];memo.set(type,v);}return v;};PF.set(values,f);}
  return f;
}
const ALIASES=Object.freeze({positive:'vitality',negative:'void',electric:'electricity',electrical:'electricity',lightning:'electricity',
  physical:'bludgeoning',blunt:'bludgeoning',slash:'slashing',pierce:'piercing',psychic:'mental',necrotic:'void',radiant:'vitality'});
/** A damage type slug, lower-cased and de-aliased ('' if none). Unknown names pass through. */
export function normaliseType(raw){
  const s=typeof raw==='string'?raw:raw?.type??raw?.damageType??raw?.slug??'';
  const k=String(s).toLowerCase().trim().replace(/\s+/g,'-');
  if(!/^[a-z][a-z0-9-]{0,39}$/.test(k))return '';
  return ALIASES[k]??k;
}
/** Which wound look a damage type wears: one of WOUND_LOOKS, or 'other'. */
export function woundLookOf(type){
  const t=normaliseType(type);
  if(WOUND_LOOKS.includes(t))return t;
  if(t==='spirit')return 'void';
  return 'other';
}
/** Which persistent look a type wears: one of PERSIST_LOOKS or 'fallback'. */
export function persistLookOf(type){const t=normaliseType(type);return PERSIST_LOOKS.includes(t)?t:'fallback';}

/* ---------------- the type of a blow ---------------- */
/** Damage instances of a PF2e damage roll: [{type,total,persistent}]. */
function instancesOf(roll){
  const out=[];
  const list=roll?.instances??roll?.terms?.[0]?.rolls??null;
  if(Array.isArray(list))for(const i of list){
    const type=normaliseType(i?.type??i?.options?.flavor??i?.damageType);if(!type)continue;
    out.push({type,total:Number(i?.total)||0,persistent:!!(i?.persistent||i?.options?.evaluatePersistent)});
  }
  if(!out.length){const type=normaliseType(roll?.options?.damageType??roll?.type);if(type)out.push({type,total:Number(roll?.total)||0,persistent:false});}
  return out;
}
/** The type of the largest non-persistent share of a damage roll (ties: the first). '' when none. */
export function blowType(rolls){
  const totals=new Map();let firstPersistent='';
  for(const roll of Array.isArray(rolls)?rolls:[rolls])for(const i of instancesOf(roll)){
    if(i.persistent){firstPersistent||=i.type;continue;}
    totals.set(i.type,(totals.get(i.type)??0)+Math.max(0,i.total));
  }
  let best='',bt=-1;for(const [type,v] of totals)if(v>bt){best=type;bt=v;}
  return best||firstPersistent;
}
const lastId=u=>String(u??'').split('.').pop();
/** A PF2e chat message aimed at her that carries a damage type:
 * {type, tokens:[token ids], actors:[actor ids or uuids], applied:boolean} or null. */
export function readDamageMessage(message){
  try{
    const f=message?.flags?.pf2e,ctx=f?.context;
    const applied=!!f?.appliedDamage;
    if(!applied&&!(ctx&&['damage-roll','damage-taken'].includes(ctx.type)))return null;
    if(applied&&(f.appliedDamage.isHealing||f.appliedDamage.isReverted))return null;
    const type=blowType(message.rolls??[])||normaliseType(ctx?.damageType??f?.appliedDamage?.type??'');
    if(!type)return null;
    const tokens=[ctx?.target?.token,...(Array.isArray(ctx?.targets)?ctx.targets.map(x=>x?.token):[])].filter(Boolean).map(lastId);
    const actors=[ctx?.target?.actor,f?.appliedDamage?.uuid,...(Array.isArray(ctx?.targets)?ctx.targets.map(x=>x?.actor):[])].filter(Boolean).map(String);
    if(applied&&message.speaker?.token)tokens.push(String(message.speaker.token));
    return {type,tokens,actors,applied};
  }catch{return null;}
}

/* ---------------- recovery checks and dying ---------------- */
const strings=list=>Array.isArray(list)?list.filter(o=>typeof o==='string'):list instanceof Set?[...list].filter(o=>typeof o==='string'):[];
/** A PF2e recovery check (the flat check rolled while dying): {outcome:'success'|'failure'|'criticalSuccess'|'criticalFailure', actor, token} or null. */
export function readRecoveryCheck(message){
  try{
    const ctx=message?.flags?.pf2e?.context;if(!ctx)return null;
    const options=strings(ctx.options),domains=strings(ctx.domains);
    const recovery=ctx.type==='recovery-check'||(ctx.type==='flat-check'&&(ctx.slug==='recovery'||ctx.identifier==='recovery'||domains.includes('recovery-check')||options.some(o=>/^check:(slug|identifier|statistic):recovery$|recovery-check/.test(o))||/recovery/i.test(String(message.flavor??ctx.title??''))));
    if(!recovery)return null;
    const outcome=['criticalSuccess','success','failure','criticalFailure'].includes(ctx.outcome)?ctx.outcome:null;if(!outcome)return null;
    return {outcome,success:outcome==='success'||outcome==='criticalSuccess',actor:message.speaker?.actor??ctx.actor??null,token:message.speaker?.token??null};
  }catch{return null;}
}
/** Dying value (0..3; more than 3 reads as 3) from the actor's data. */
export function dyingValue(actor){
  const d=actor?.system?.attributes?.dying;const v=Number(typeof d==='object'?d?.value:d);
  return Number.isFinite(v)?Math.max(0,Math.min(3,Math.round(v))):0;
}
/** The stage a dying value shows (each stage a registry part): 0 none, 1 huddle, 2 embers, 3 a bit out. */
export function dyingStage(value,parts=null){
  const v=Math.max(0,Math.min(3,Math.round(Number(value)||0)));
  if(!parts)return v;
  // A stage whose part is off shows the stage below it (the look builds up stage by stage).
  for(let s=v;s>0;s--)if(parts['dying'+s]!==false)return s;
  return 0;
}

/* ---------------- colours for any type ---------------- */
/** PF2e's own damage colours (src/styles/_colors.scss, `.damage` scope: --color-border-<type>). */
export const PF2E_DAMAGE_COLOR=Object.freeze({acid:'#007300',bleed:'#99001a',cold:'#2f2fa6',electricity:'#b8860b',fire:'#a62f00',force:'#6300aa',mental:'#191970',poison:'#5b7332',sonic:'#008b8b',spirit:'#5a5585',vitality:'#ffffe0',void:'#00001f',
  chaotic:'#a600a6',evil:'#4b0082',good:'#9d730a',lawful:'#402600'});
function hexRgb(h){
  h=String(h).trim();
  const m=/^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/.exec(h);if(m)return [+m[1],+m[2],+m[3]];
  h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');
  if(!/^[0-9a-f]{6}/i.test(h))return null;return [0,2,4].map(i=>parseInt(h.slice(i,i+2),16));
}
function rgbToHsl([r,g,b]){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h/=6;}return [h*360,s,l];}
function hslToRgb(h,s,l){h=((h%360)+360)%360/360;const f=n=>{const k=(n+h*12)%12,a=s*Math.min(l,1-l);return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1))));};return [f(0),f(8),f(4)];}
/** FNV-1a of a name. */
export function nameHash(name){let x=2166136261;for(const ch of String(name).toLowerCase()){x^=ch.charCodeAt(0);x=Math.imul(x,16777619)>>>0;}return x>>>0;}
/** Tint for any type name: PF2e's colour if it has one (css: the computed
 * --color-border-<type>, else the known table), hue kept and lightened to read
 * on her light; otherwise a stable hue from the name, steered away from her
 * own magenta. {rgb, core, hue, from}. */
export function tintForType(name,css=null){
  const src=(css&&hexRgb(css))?css:PF2E_DAMAGE_COLOR[normaliseType(name)];let h,s;
  if(src){[h,s]=rgbToHsl(hexRgb(src));s=Math.max(.45,Math.min(.7,s));}
  else{h=nameHash(name)%360;s=.58;}
  if(Math.abs(((h-305+540)%360)-180)<28)h+=60;     // not her magenta
  return {rgb:hslToRgb(h,s,.66),core:hslToRgb(h,s*.6,.88),hue:Math.round(((h%360)+360)%360),from:src?'PF2e colour':'name hash'};
}
/** PF2e's computed --color-border-<type> on this page ('' if none). Read once per type.
 * (11.0.0-test.7) probe:false never touches the page's styles: a blow of a type not read yet takes the
 * known table or the name hash (a type PF2e does not know has no colour of its own to read; one it knows is read
 * at load, or at the next idle moment if it was added later). test.6 read it on the frame
 * of the blow itself, with a probe element appended to the page: a style recalculation of all of Foundry's
 * page, a long frame right when her bits were letting go of the previous wound (the self-check's homebrew
 * "starfire" pop: the bits' eased dim stepped over the stalled frame). */
const cssCache=new Map();let warmSet=null;
export function pf2eTypeColor(type,doc=globalThis.document,{probe=true}={}){
  if(cssCache.has(type))return cssCache.get(type);
  if(!probe){
    // a type PF2e does not know (a homebrew name in a roll) has no PF2e colour to find: no probe at all
    const known=globalThis.CONFIG?.PF2E?.damageTypes;if(!known||!Object.hasOwn(known,type)){cssCache.set(type,'');return '';}
    warmTypeColors([type],doc);return '';}
  readTypeColors([type],doc);return cssCache.get(type)??'';
}
function readTypeColors(types,doc){
  let root=null,el=null;
  try{
    if(doc?.documentElement&&globalThis.getComputedStyle){
      root=getComputedStyle(doc.documentElement);
      for(const type of types){let v=root.getPropertyValue(`--color-border-${type}`).trim();
        if(!v&&doc.body){if(!el){el=doc.createElement('span');el.className='damage';el.style.display='none';doc.body.append(el);}v=getComputedStyle(el).getPropertyValue(`--color-border-${type}`).trim();}
        cssCache.set(type,v);}
    }
  }catch{}
  try{el?.remove();}catch{}
  for(const type of types)if(!cssCache.has(type))cssCache.set(type,'');
}
/** Read these types' colours at an idle moment, all with one probe (one style recalculation). */
export function warmTypeColors(types,doc=globalThis.document){
  const want=(types??[]).filter(t=>t&&!cssCache.has(t));if(!want.length)return;
  const first=!warmSet;warmSet??=new Set();for(const t of want)warmSet.add(t);if(!first)return;
  const run=()=>{const list=[...warmSet];warmSet=null;readTypeColors(list,doc);};
  try{if(typeof globalThis.requestIdleCallback==='function')globalThis.requestIdleCallback(run,{timeout:1500});else setTimeout(run,50);}catch{run();}
}
