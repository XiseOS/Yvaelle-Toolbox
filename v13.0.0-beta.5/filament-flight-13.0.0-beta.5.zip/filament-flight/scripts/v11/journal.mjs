/** Yvaelle’s Toolbox v11 · her journal (pure: no Foundry globals at import).
 *
 * The record the experimental extras share: the Memory tapestry weaves its
 * moments, the milestone petals are earned from it, and the session recap
 * sums a session of it. It lives on her actor (flags.filament-flight.journal)
 * and only grows while one of those extras is on (journal-runtime.mjs).
 *
 *   {v:1,
 *    sessions:[{n, start, last, scenes:{name:count}, from, to, healed, allies:[ids],
 *               taken, lowest, max, hero, heroMax, crits, saves, allyFalls, combats, hp:[[sec,hp]]}],
 *    moments:[{id, s, k, t, d, at, x, m, ts, saved?}],     newest last, at most MAX_MOMENTS
 *    totals:{heal, healHP, fall, crit, hero, level},          every moment ever, even trimmed ones
 *    milestones:{id:{ts, s}},
 *    pinned:[milestone ids] (at most 5: the flower has five gaps),
 *    flags:{recovered}}
 *
 * Moment kinds (the tapestry's five threads): heal (given), fall (survived),
 * crit, hero (a Hero Point spent), level (a level gained).
 * Everything here is a plain function of the journal and what happened, so
 * it is tested on its own (tools/v11/test-extras.mjs). */

export const JOURNAL_FLAG='journal';
export const KINDS=Object.freeze(['heal','fall','crit','hero','level']);
export const MAX_MOMENTS=400;
export const MAX_SESSIONS=60;
export const MAX_HP_SAMPLES=160;
/** A new session begins after this long without anything happening. */
export const SESSION_GAP_MS=5*3600*1000;
export const PIN_CAP=5;

/** The six milestone petals, in the herbarium's order. */
export const MILESTONES=Object.freeze([
  {id:'hundredfold',name:'Hundredfold',when:'100 HP healed',note:'Her hundredth hit point given back. A broad rose petal with a filament woven through its vein.'},
  {id:'second-dawn',name:'Second Dawn',when:'First recovery from dying',note:'Night at the base, first light at the tip; notched where the dark broke.'},
  {id:'fifth-ring',name:'Fifth Ring',when:'Level 5',note:'Enamel and gilt, like the level gem: five beads for five levels along a gold rib.'},
  {id:'saving-grace',name:'Saving Grace',when:'A natural 20 that saved an ally',note:'Ivory edged in her magenta, crowned with the glint the d20 made.'},
  {id:'unfallen',name:'Unfallen',when:'First fall survived',note:'A petal that is half a feather: one smooth edge, one edge of barbs, for the day her wings held.'},
  {id:'all-standing',name:'All Standing',when:'A session where no ally fell',note:'A twin-lobed wildflower petal, warm at the heart: everyone she came with went home.'}
]);
export const MILESTONE_IDS=Object.freeze(MILESTONES.map(m=>m.id));
export const milestoneById=id=>MILESTONES.find(m=>m.id===id)??null;

const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const str=(v,max=120)=>typeof v==='string'?v.slice(0,max):'';
const clamp01=v=>Math.max(0,Math.min(1,num(v,0)));

/** An empty journal. */
export function createJournal(){
  return {v:1,sessions:[],moments:[],totals:{heal:0,healHP:0,fall:0,crit:0,hero:0,level:0},milestones:{},pinned:[],flags:{}};
}
/** A journal read from a flag, made whole and safe (anything odd is dropped). */
export function readJournal(raw){
  const J=createJournal();if(!raw||typeof raw!=='object')return J;
  if(Array.isArray(raw.sessions))for(const s of raw.sessions)if(s&&Number.isFinite(Number(s.n)))J.sessions.push(cleanSession(s));
  J.sessions.sort((a,b)=>a.n-b.n);
  if(Array.isArray(raw.moments))for(const m of raw.moments){const c=cleanMoment(m);if(c)J.moments.push(c);}
  J.moments.sort((a,b)=>a.ts-b.ts);
  for(const k of Object.keys(J.totals))J.totals[k]=Math.max(0,num(raw.totals?.[k]));
  if(raw.milestones&&typeof raw.milestones==='object')for(const id of MILESTONE_IDS){const m=raw.milestones[id];if(m&&typeof m==='object')J.milestones[id]={ts:num(m.ts),s:num(m.s,0)};}
  if(Array.isArray(raw.pinned))J.pinned=[...new Set(raw.pinned.filter(id=>J.milestones[id]))].slice(0,PIN_CAP);
  if(raw.flags&&typeof raw.flags==='object')J.flags={recovered:!!raw.flags.recovered};
  return J;
}
function cleanSession(s){
  return {n:num(s.n),start:num(s.start),last:num(s.last??s.start),scenes:s.scenes&&typeof s.scenes==='object'?{...s.scenes}:{},from:str(s.from,60),to:str(s.to,60),
    healed:num(s.healed),allies:Array.isArray(s.allies)?[...new Set(s.allies.map(String))].slice(0,24):[],taken:num(s.taken),lowest:s.lowest==null?null:num(s.lowest),max:num(s.max),
    hero:num(s.hero),heroMax:num(s.heroMax),crits:num(s.crits),saves:num(s.saves),allyFalls:num(s.allyFalls),combats:num(s.combats),
    hp:Array.isArray(s.hp)?s.hp.filter(p=>Array.isArray(p)&&p.length===2).map(([t,h])=>[num(t),num(h)]):[],level:num(s.level),name:str(s.name,60)};
}
function cleanMoment(m){
  if(!m||typeof m!=='object'||!KINDS.includes(m.k))return null;
  const out={id:str(m.id,40)||`m${num(m.ts).toString(36)}`,s:num(m.s,1),k:m.k,t:str(m.t),d:str(m.d,160),at:str(m.at,90),x:clamp01(m.x??.5),m:clamp01(m.m??.4),ts:num(m.ts)};
  if(m.saved)out.saved=true;if(m.nat20)out.nat20=true;
  return out;
}

/* ------------------------------------------------------------------ */
/* Sessions                                                            */
/* ------------------------------------------------------------------ */
export const currentSession=J=>J.sessions.at(-1)??null;
/** The session `now` belongs to: the last one, unless nothing has happened
 * for SESSION_GAP_MS (or `fresh` asks for a new one). Mutates J; returns
 * {session, began, closed} (closed: the session that just ended, if any). */
export function ensureSession(J,now,{fresh=false,gap=SESSION_GAP_MS,date='',max=0,level=0,hp=null}={}){
  const last=currentSession(J);
  if(last&&!fresh&&now-last.last<gap){last.last=Math.max(last.last,now);if(date)last.to=date;return {session:last,began:false,closed:null};}
  const s=cleanSession({n:(last?.n??0)+1,start:now,last:now,from:date,to:date,max,level,lowest:null,hp:hp==null?[]:[[0,hp]]});
  J.sessions.push(s);
  if(J.sessions.length>MAX_SESSIONS)J.sessions.splice(0,J.sessions.length-MAX_SESSIONS);
  return {session:s,began:true,closed:last??null};
}
export function sessionByN(J,n){return J.sessions.find(s=>s.n===n)??null;}
/** The name a session goes by: its own, else the scene most of it happened in. */
export function sessionName(s){
  if(!s)return '';if(s.name)return s.name;
  let best='',bn=0;for(const [k,v] of Object.entries(s.scenes??{}))if(v>bn){best=k;bn=v;}
  return best||`Session ${s.n}`;
}
/** Her HP through the session (a sample whenever it changes; thinned to MAX_HP_SAMPLES). */
export function sampleHp(s,now,hp,max){
  if(!s||!Number.isFinite(hp))return;
  if(Number.isFinite(max)&&max>0)s.max=max;
  const t=Math.max(0,Math.round((now-s.start)/1000)),last=s.hp.at(-1);
  if(last&&last[1]===hp)return;
  if(last&&last[0]===t)last[1]=hp;else s.hp.push([t,hp]);
  if(s.lowest==null||hp<s.lowest)s.lowest=hp;
  if(s.hp.length>MAX_HP_SAMPLES){
    // keep the first, the last and the lowest; thin the rest by half
    const low=s.hp.reduce((a,b)=>b[1]<a[1]?b:a);
    s.hp=s.hp.filter((p,i)=>i===0||i===s.hp.length-1||p===low||i%2===0);
  }
}

/* ------------------------------------------------------------------ */
/* Moments                                                             */
/* ------------------------------------------------------------------ */
let seq=0;
/** Where on its pick a moment's knot sits: spread by the golden ratio, so
 * neighbouring threads never stack their knots. */
export const knotX=i=>.2+((i*.618)%1)*.6;
/** Record a moment in the current session (mutates J; returns the moment). */
export function addMoment(J,moment,now){
  if(!KINDS.includes(moment?.k))throw new Error(`Unknown moment kind: ${moment?.k}`);
  const s=currentSession(J)??ensureSession(J,now).session;
  const m=cleanMoment({...moment,s:s.n,ts:now,id:moment.id??`m${now.toString(36)}${(seq++%1296).toString(36).padStart(2,'0')}`,
    x:moment.x??(moment.k==='level'?.5:knotX(J.totals.heal+J.totals.fall+J.totals.crit+J.totals.hero+J.totals.level))});
  J.moments.push(m);J.totals[m.k]++;
  if(J.moments.length>MAX_MOMENTS)J.moments.splice(0,J.moments.length-MAX_MOMENTS);
  s.last=Math.max(s.last,now);
  if(moment.scene)s.scenes[moment.scene]=(s.scenes[moment.scene]??0)+1;
  return m;
}
/** A heal she gave: amount is the HP restored to others; targets [{id,name,from0}]. */
export function noteHeal(J,{amount,targets=[],source='',actions=0,nat20=false,crit=false,at='',scene=''},now){
  const given=Math.max(0,Math.round(num(amount)));if(!given||!targets.length)return null;
  const s=currentSession(J)??ensureSession(J,now).session;
  s.healed+=given;for(const t of targets)if(t?.id&&!s.allies.includes(String(t.id)))s.allies.push(String(t.id));
  J.totals.healHP+=given;
  const names=targets.map(t=>t.name).filter(Boolean),raised=targets.find(t=>t.from0);
  const who=names.length===1?names[0]:names.length===2?`${names[0]} and ${names[1]}`:`${names.length} allies`;
  const t=raised?`${raised.name}, back on their feet`:targets.length>2?`Everyone, at once`:`${who}, mended`;
  const how=[source||'Healing',actions?`${actions} action${actions>1?'s':''}`:'',crit?'critical':'',`+${given} HP${targets.length>1?` to ${targets.length} allies`:''}`].filter(Boolean).join(' · ');
  const saved=!!(raised&&nat20);
  const m=addMoment(J,{k:'heal',t,d:how,at,scene,m:Math.min(1,given/40),saved,nat20},now);
  return m;
}
/** A critical success of hers. saved: it brought an ally up from 0. */
export function noteCrit(J,{label='',check='',nat20=false,detail='',saved=false,ally='',at='',scene=''},now){
  const s=currentSession(J)??ensureSession(J,now).session;s.crits++;if(saved)s.saves++;
  const t=saved&&ally?`Saved ${ally} on a 20`:nat20?`${label||'A check'} on a natural 20`:`${label||'A check'}, perfectly`;
  const d=[check||label||'Check',nat20?'natural 20':'critical',detail].filter(Boolean).join(' · ');
  return addMoment(J,{k:'crit',t,d,at,scene,saved,nat20},now);
}
/** A crit already woven turns out to have saved an ally (a heal right after a natural 20). */
export function markSaved(J,momentId,ally=''){
  const m=J.moments.find(x=>x.id===momentId);if(!m||m.saved)return m??null;
  m.saved=true;if(m.k==='crit'&&ally)m.t=`Saved ${ally} on a 20`;
  const s=sessionByN(J,m.s);if(s&&m.k==='crit')s.saves++;
  return m;
}
export function noteHero(J,{left=null,detail='',at='',scene=''},now){
  const s=currentSession(J)??ensureSession(J,now).session;s.hero++;
  return addMoment(J,{k:'hero',t:detail||'A Hero Point spent',d:['Hero Point',left==null?'':`${left} left`].filter(Boolean).join(' · '),at,scene},now);
}
export function noteLevel(J,{level,hpGain=0,at='',scene=''},now){
  const s=currentSession(J)??ensureSession(J,now).session;s.level=Math.max(s.level,num(level));
  return addMoment(J,{k:'level',t:`Level ${level}`,d:hpGain>0?`+${hpGain} max HP`:'A new rib of light',at,scene},now);
}
/** A fall she survived: from the sky (ft known or not), or down to 0 HP and back up. */
export function noteFall(J,{ft=0,hp=null,kind='sky',at='',scene=''},now){
  const t=kind==='down'?'Down, and up again':ft>0?`Fell ${ft} ft, and rose`:'Knocked from the air';
  const d=[kind==='down'?'Dropped to 0 HP':ft>0?`Fell ${ft} ft`:'A fall',hp!=null?`${hp} HP left`:'',kind==='down'?'back on her feet':'her wings held'].filter(Boolean).join(' · ');
  return addMoment(J,{k:'fall',t,d,at,scene,x:.48},now);
}
export function noteDamage(J,{amount},now){
  const s=currentSession(J)??ensureSession(J,now).session;s.taken+=Math.max(0,Math.round(num(amount)));s.last=Math.max(s.last,now);
}
export function noteAllyFell(J,now){const s=currentSession(J)??ensureSession(J,now).session;s.allyFalls++;}
export function noteCombat(J,now){const s=currentSession(J)??ensureSession(J,now).session;s.combats++;}

/* ------------------------------------------------------------------ */
/* Milestones                                                          */
/* ------------------------------------------------------------------ */
/** Which milestones J (and her level) have earned that are not yet marked.
 * closed: a session that has just ended (All Standing is judged on it). */
export function detectMilestones(J,{level=0,closed=null}={}){
  const has=id=>!!J.milestones[id],out=[];
  if(!has('hundredfold')&&J.totals.healHP>=100)out.push('hundredfold');
  if(!has('second-dawn')&&J.flags.recovered)out.push('second-dawn');
  if(!has('fifth-ring')&&num(level)>=5)out.push('fifth-ring');
  if(!has('saving-grace')&&J.moments.some(m=>m.saved&&m.nat20))out.push('saving-grace');
  if(!has('unfallen')&&J.totals.fall>=1)out.push('unfallen');
  if(!has('all-standing')&&closed&&allStanding(closed))out.push('all-standing');
  return out;
}
/** A session where she fought and no ally fell. */
export const allStanding=s=>!!s&&s.combats>0&&s.allyFalls===0;
/** Mark milestones as earned (mutates J). New ones are pinned while the flower has a gap. */
export function earn(J,ids,now){
  const s=currentSession(J);const got=[];
  for(const id of ids){if(J.milestones[id]||!MILESTONE_IDS.includes(id))continue;J.milestones[id]={ts:now,s:s?.n??0};got.push(id);
    if(J.pinned.length<PIN_CAP&&!J.pinned.includes(id))J.pinned.push(id);}
  return got;
}
/** Pin or unpin a milestone (at most five). Returns the new pinned list, or throws. */
export function togglePin(J,id){
  if(!J.milestones[id])throw new Error('That petal has not grown yet.');
  if(J.pinned.includes(id)){J.pinned=J.pinned.filter(x=>x!==id);return J.pinned;}
  if(J.pinned.length>=PIN_CAP)throw new Error('The flower has five gaps: unpin one first.');
  J.pinned=[...J.pinned,id];return J.pinned;
}
/** The petals the flower shows, in its gap order. */
export const flowerPetals=J=>J.pinned.filter(id=>J.milestones[id]).slice(0,PIN_CAP);

/* ------------------------------------------------------------------ */
/* Recap                                                               */
/* ------------------------------------------------------------------ */
const RANK={heal:2,crit:3,fall:4,level:2,hero:1};
/** The moment that stands for a session: a save on a 20, else a fall survived,
 * a raising heal, the biggest heal, a level, a crit, a Hero Point. */
export function highlightOf(moments){
  let best=null,score=-1;
  for(const m of moments){
    const sc=(m.saved?100:0)+(m.nat20?10:0)+RANK[m.k]*10+(m.k==='heal'?m.m*15:0)+(/back on their feet/.test(m.t)?20:0)+m.ts/1e15;
    if(sc>score){score=sc;best=m;}
  }
  return best;
}
/** A sentence for the highlight. */
export function highlightLine(m){
  if(!m)return '';
  if(m.k==='crit'&&m.saved)return `${m.t}: ${m.d.split(' · ')[0]}, and they were back up.`;
  if(m.k==='heal')return `${m.t}. ${m.d.split(' · ').at(-1)}.`;
  if(m.k==='fall')return `${m.t}. ${m.d.split(' · ').slice(1).join(', ')}.`.replace(/\.\./,'.');
  if(m.k==='level')return `${m.t}: ${m.d}.`;
  return `${m.t}. ${m.d}.`;
}
/** '21 Gozran'…'22 Gozran' → '21–22 Gozran' (the same month is said once). */
export function dateSpan(a,b){if(!a||!b||a===b)return a||b||'';const x=a.split(' '),y=b.split(' ');
  if(x.length>1&&x.length===y.length&&x.slice(1).join(' ')===y.slice(1).join(' '))return `${x[0]}–${b}`;return `${a}–${b}`;}
const fmtDur=ms=>{const m=Math.max(0,Math.round(ms/60000)),h=Math.floor(m/60);return h?`${h} h ${m%60} m`:`${m} m`;};
/** Everything the recap card shows for session n (default: the current one).
 * hero: her Hero Points now {value,max}; level: her level now. */
export function recapOf(J,n=null,{hero=null,level=0,hp=null}={}){
  const s=n==null?currentSession(J):sessionByN(J,n);if(!s)return null;
  const moments=J.moments.filter(m=>m.s===s.n);
  const high=highlightOf(moments);
  const petals=MILESTONE_IDS.filter(id=>J.milestones[id]?.s===s.n);
  const heroMax=num(hero?.max,s.heroMax)||Math.max(s.hero,3);
  const heroKept=hero?Math.max(0,num(hero.value)):Math.max(0,heroMax-s.hero);
  const max=s.max||num(hp?.max)||Math.max(1,...s.hp.map(p=>p[1]));
  const end=s.hp.at(-1)?.[1]??num(hp?.value,max);
  return {n:s.n,name:sessionName(s),from:s.from,to:s.to,dates:dateSpan(s.from,s.to),
    duration:fmtDur(s.last-s.start),healed:s.healed,allies:s.allies.length,taken:s.taken,lowest:s.lowest??end,max,end,
    hero:s.hero,heroMax,heroKept,crits:s.crits,saves:s.saves,allyFalls:s.allyFalls,combats:s.combats,allStanding:allStanding(s),
    threads:moments.length,counts:Object.fromEntries(KINDS.map(k=>[k,moments.filter(m=>m.k===k).length])),
    highlight:high?{line:highlightLine(high),at:high.at,k:high.k,id:high.id}:null,petals,level:num(level)||s.level,
    hp:s.hp.length?s.hp.map(([t,h])=>[t,h]):[[0,end]],span:Math.max(1,Math.round((s.last-s.start)/1000))};
}
/** The heartbeat line through a session as an SVG path in a w×h box
 * (her HP high is up). Returns {d, low:{x,y}, end:{x,y}, top}. */
export function heartbeatPath(hp,span,max,w,h){
  const pts=hp.length?hp:[[0,max]],M=Math.max(1,max),T=Math.max(1,span,pts.at(-1)[0]);
  const y=v=>4+(1-Math.max(0,Math.min(M,v))/M)*(h-10),x=t=>t/T*w,f=n=>Math.round(n*10)/10;
  let d=`M0 ${f(y(pts[0][1]))}`,low=pts[0];
  for(let i=1;i<pts.length;i++){const [t0,h0]=pts[i-1],[t1,h1]=pts[i];if(h1<low[1])low=pts[i];
    const x0=x(t0),x1=x(t1);d+=h0===h1?`L${f(x1)} ${f(y(h1))}`:`C${f(x0+(x1-x0)*.55)} ${f(y(h0))} ${f(x0+(x1-x0)*.45)} ${f(y(h1))} ${f(x1)} ${f(y(h1))}`;}
  const last=pts.at(-1);if(x(last[0])<w)d+=`L${w} ${f(y(last[1]))}`;
  return {d,low:{x:f(x(low[0])),y:f(y(low[1]))},end:{x:w,y:f(y(last[1]))},top:f(y(M))};
}

/* ------------------------------------------------------------------ */
/* Tapestry layout                                                     */
/* ------------------------------------------------------------------ */
export const ROMAN=n=>{if(!(n>0)||n>3999)return String(n);const V=[[1000,'m'],[900,'cm'],[500,'d'],[400,'cd'],[100,'c'],[90,'xc'],[50,'l'],[40,'xl'],[10,'x'],[9,'ix'],[5,'v'],[4,'iv'],[1,'i']];let s='';for(const [v,r] of V)while(n>=v){s+=r;n-=v;}return s;};
/** Which sessions the loom shows unfolded: the newest `open` sessions; older
 * ones fold to a single gold band each (unless listed in `unfold`). */
export function foldPlan(J,{open=3,unfold=[]}={}){
  const ns=[...new Set(J.moments.map(m=>m.s))].sort((a,b)=>b-a);
  return ns.map((n,i)=>({n,folded:i>=open&&!unfold.includes(n),count:J.moments.filter(m=>m.s===n).length}));
}
