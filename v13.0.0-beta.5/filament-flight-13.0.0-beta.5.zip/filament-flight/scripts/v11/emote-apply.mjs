/** Yvaelle’s Toolbox v11 · Emotes: what a frame does to her (pure, allocation-free).
 *
 * The same steps as the approved lab hooks (lab/v11/emotes/site/emote-fx.mjs,
 * with refine's Comfort mirror), in the module's own units:
 *   emoteFeel      the flight feel: wingbeat rate, the beat settling still,
 *                  her tilt and body offset (before composeFeel)
 *   emotePose      pose weights and tips blended over hers
 *   emoteChannels  V7 expression channels added to hers
 *   emoteGeometry  the wings turned at the shoulder and Comfort's wrap, in the
 *                  wing picture's own units, in place (inside frameGeometry,
 *                  so the off-thread painter draws the same)
 *   placeEmoteBit  a bit's offset, turn, gather (ally, line, target) and lean
 *   emoteGlows     the soft lights: each bit's focus and glow, Pray's light,
 *                  Comfort's warmth round the ally
 * Precedence (emoteGate) decides how much of the emote plays this frame. */

const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
/** Her shoulder in the wing picture (art units, right wing; the left is mirrored). */
export const EMOTE_ROOT=Object.freeze([27,-13]);
const ART=600;

/* ------------------------------------------------------------ precedence */
/** What wins when an emote meets the rest of her life, strongest first.
 * stop    she falls (unconscious, dying, a wing collapse): it ends at once (0.25 s)
 * yield   a combat moment needs her (a hit or wound, a dodge, a save brace, a shot
 *         taken by a bit, her shield raised, a shatter): it gives way (0.2 s) and ends
 * release she moves, takes off or lands: it eases back (0.45 s) and ends
 * fade    a new emote starts: the old one fades out (0.35 s) beneath it
 * Below an emote: a wing gesture saved by hand (held back to 35 % while it plays)
 * and her idle gestures (paused). */
export const EMOTE_PRECEDENCE=Object.freeze([
  Object.freeze({id:'stop',fade:.25,why:'unconscious, dying or a wing collapse'}),
  Object.freeze({id:'yield',fade:.2,why:'a hit, a dodge, a save, a shot taken, the shield, a shatter'}),
  Object.freeze({id:'release',fade:.45,why:'she moves, takes off or lands'}),
  Object.freeze({id:'fade',fade:.35,why:'a new emote starts'})]);
export const EMOTE_FADES=Object.freeze(Object.fromEntries(EMOTE_PRECEDENCE.map(p=>[p.id,p.fade])));
/** How much of a manual wing gesture still shows while an emote plays at weight w. */
export const GESTURE_UNDER_EMOTE=.35;
/** The strongest reason this frame to end an emote ('stop' | 'yield' | 'release' | null).
 * s: {ko, collapse, hit, dodge, save, intercept, shield, shatter, moved, mode} */
export function emoteGate(s){
  if(!s)return null;
  if(s.ko||s.collapse>.02)return 'stop';
  if(s.hit||s.dodge||s.save||s.intercept||s.shield>.05||s.shatter)return 'yield';
  if(s.moved||s.mode==='takeoff'||s.mode==='landing')return 'release';
  return null;
}
/** The weight of an emote ended `since` seconds ago for `reason` (1 → 0). */
export function emoteEndWeight(reason,since){
  const d=EMOTE_FADES[reason];if(!d)return 1;
  return 1-smooth(since/d);
}

/* ------------------------------------------------------------ flight feel */
/** The flight feel's output for this frame (before composeFeel). Returns her
 * wing clock's turns, nudged toward the phrase's still point. travel 0..1: how
 * much she is flying along a path (the beat keeps going while she travels). */
export function emoteFeel(F,out,size=100,turns=0,dt=1/30,travel=0){
  const keep=1-unit(travel);
  const still=unit(F.still)*keep,beat=1-(1-F.beat)*keep;
  out.beatRate=(out.beatRate??1)*beat*(1-still);
  if(still>0){
    // (the lab nudges 18 % of `still` per 1/30 s frame: the same, at any frame rate)
    const d=(((F.stillAt-turns+1.5)%1)-.5),k=1-(1-Math.min(1,still*.18))**Math.max(0,dt*30);
    turns=((turns+d*k)%1+1)%1;
  }
  out.bank=(out.bank??0)+F.bank;out.dy=(out.dy??0)+F.dy*size;out.dx=(out.dx??0)+F.dx*size;
  return turns;
}
/** Spin, dim and swell onto the feel's bit records (out.bits, FEEL_STATIONS order). */
export function emoteFeelBits(F,bits){
  if(!bits)return;
  for(let i=0;i<4;i++){const o=bits[i],B=F.bits[i];if(!o)continue;
    if(B.spin)o.spin=(o.spin||0)+B.spin;
    if(B.dim)o.dim=Math.min(.9,(o.dim||0)+B.dim);
    o.emoScale=1+.35*unit(B.focus);}
}

/* ------------------------------------------------------------ pose and channels */
/** The phrase's V7 channels added to hers (base may be null) into out[18].
 * keep: how much of a gesture saved by hand still shows under the emote. */
export function emoteChannels(F,base,out,keep=1){
  for(let i=0;i<18;i++)out[i]=(base?(Number(base[i])||0)*keep:0)+F.ch[i];
  return out;
}

/* ------------------------------------------------------------ wing geometry */
/** The wing-picture state the painter needs (made once per token, overwritten
 * each frame; it rides on the visual profile to the off-thread painter).
 * ax, ay: the ally in art units (her frame); Ra: the ally's radius in art units. */
export function createEmoteGeometryState(){return {on:true,rotL:0,rotR:0,hasRot:false,wrapK:0,squeeze:0,side:1,ax:0,ay:0,Ra:0,hasAlly:false,
  hasAlt:false,alt:{wrapK:0,squeeze:0,side:-1,ax:0,ay:0,Ra:0}};}
/** wrap (optional, test.5): {main:{k,squeeze,side}, alt:{k,squeeze,side,ax,ay,Ra}|null}: each Comfort's own wrap,
 * when one fades out beneath a Comfort to the other side (each wing eases on its own; without it the one wrap
 * would jump to the other wing). */
export function emoteGeometryState(F,E,ally,wrap=null){
  E.on=true;E.rotL=F.rotL;E.rotR=F.rotR;E.hasRot=F.hasRot&&(Math.abs(F.rotL)>1e-4||Math.abs(F.rotR)>1e-4);
  const w=wrap?.main;
  E.wrapK=F.hasWrap?(w?w.k:F.wrapK):0;E.squeeze=w?w.squeeze:F.squeeze;E.side=(w?w.side:F.side)<0?-1:1;
  E.hasAlly=!!ally;if(ally){E.ax=ally.ax;E.ay=ally.ay;E.Ra=ally.Ra;}
  const a=wrap?.alt;E.hasAlt=!!a&&F.hasWrap&&a.k>.001;
  if(E.hasAlt){const o=E.alt;o.wrapK=a.k;o.squeeze=a.squeeze;o.side=a.side<0?-1:1;o.ax=a.ax;o.ay=a.ay;o.Ra=a.Ra;}
  return E;
}
/** Map px → art units of the wing picture (her frame), for transform {x,y,angle,width,height}. */
export function toArt(transform,x,y,out){
  const dx=x-transform.x,dy=y-transform.y,c=Math.cos(-transform.angle),s=Math.sin(-transform.angle),lx=dx*c-dy*s,ly=dx*s+dy*c;
  out.ax=lx*ART/transform.width;out.ay=ly*ART/transform.height+15;return out;
}
function rotateAbout(p,ox,oy,c,s){const x=p[0]-ox,y=p[1]-oy;p[0]=ox+x*c-y*s;p[1]=oy+x*s+y*c;}
/** Comfort: the wing's fan narrows into a sheaf aimed at the ally, its upper ribs
 * passing over them and its lower curls under them; past the ally's centre the
 * tips curl back in round their far side. Polar blend, so the lattice keeps its
 * shape. (Authored for the right wing: x is mirrored in and out for the left.) */
function wrapPoint(p,m,k,ax,ay,Ra,squeeze){
  const r0x=EMOTE_ROOT[0],r0y=EMOTE_ROOT[1],px=p[0]*m,dx=px-r0x,dy=p[1]-r0y,r=Math.hypot(dx,dy),u=unit(r/265);
  const th=Math.atan2(dy,dx),phi=Math.max(-1.4,Math.min(1.4,th-.05));
  const dA=Math.hypot(ax-r0x,ay-r0y),aim=Math.atan2(ay-r0y,ax-r0x);
  const half=Math.asin(Math.min(.95,Ra*1.3/dA));              // the ally's half-width seen from her shoulder
  const past=smooth((r-dA*.9)/(dA*.6));
  const target=aim+phi*(half/1.05)*(1+.25*past)-phi*.62*past*(1+.2*squeeze);
  const inner=1-smooth(Math.abs(phi)/.75),th2=th+(target-th)*k*smooth(u/.08),r2=r*(1+k*.06-k*.42*inner*smooth((u-.2)/.5));
  p[0]=(r0x+r2*Math.cos(th2))*m;p[1]=r0y+r2*Math.sin(th2);
}
const LEFT=['leftRear','leftFront'],RIGHT=['rightRear','rightFront'];
// (a few strands share a point with another (a spark on its light): each point moves once per pass)
let stamp=0;
/** Turn the wings at the shoulder, then wrap (Comfort), in place. The bits (parts
 * with hardware) are left to placeEmoteBit, as the lab places them. Returns wings. */
export function emoteGeometry(wings,E){
  if(!E?.on||!wings)return wings;
  if(E.hasRot)for(const key in wings){
    const left=key.startsWith('left'),a=left?E.rotL:-E.rotR;if(Math.abs(a)<1e-4)continue;
    const ox=left?-EMOTE_ROOT[0]:EMOTE_ROOT[0],oy=EMOTE_ROOT[1],c=Math.cos(a),s=Math.sin(a),parts=wings[key];
    const st=++stamp;
    for(let j=0;j<parts.length;j++){const part=parts[j];if(part.hardware)continue;const pts=part.points;for(let q=0;q<pts.length;q++){const p=pts[q];if(p.e11===st)continue;p.e11=st;rotateAbout(p,ox,oy,c,s);}}
  }
  if(E.wrapK>.001&&E.hasAlly)wrapWing(wings,E);
  // (test.5) a Comfort to the other side fading out beneath this one: its own wing eases back on its own
  if(E.hasAlt&&E.alt.side!==(E.side<0?-1:1))wrapWing(wings,E.alt);
  return wings;
}
function wrapWing(wings,W){
  const m=W.side<0?-1:1,ax=W.ax*m,keys=m>0?RIGHT:LEFT;
  const st=++stamp;
  for(let n=0;n<2;n++){const parts=wings[keys[n]];if(!parts)continue;
    for(let j=0;j<parts.length;j++){const part=parts[j];if(part.hardware)continue;const pts=part.points;for(let q=0;q<pts.length;q++){const p=pts[q];if(p.e11===st)continue;p.e11=st;wrapPoint(p,m,W.wrapK,ax,W.ay,W.Ra,W.squeeze);}}}
}

/* ------------------------------------------------------------ bits */
/** Where the frame's bits go, beyond the feel's own offsets (made once per token).
 * ally {x,y} map px or null; look {x,y} map px or null; base: her token size in px
 * (unscaled); t: the phrase clock for the ally stations' slow drift. */
// (test.5) side: the playing emote's side (null: the frame's own); prevAlly, prevSide: the ally and side of an emote
// fading out beneath it, for the bits still gathered for that one (B.prev) — they no longer leap to the new ally
export function createEmoteBitContext(){return {on:false,F:null,ally:null,look:null,allyAt:{x:0,y:0},lookAt:{x:0,y:0},base:100,t:0,side:null,prevAlly:null,prevSide:null};}
/** One bit (index i: 0 left upper, 1 right upper, 2 left lower, 3 right lower),
 * already at its station plus the feel's offsets: raw {x,y} in map px, moved in
 * place. transform: the wing transform {x,y,angle,width,height,size}. */
export function placeEmoteBit(raw,i,left,X,transform,c=Math.cos(transform.angle),s=Math.sin(transform.angle)){
  const F=X.F;if(!X.on||!F)return raw;const B=F.bits[i],u=transform.size||X.base;
  if(F.hasRot){const a=left?F.rotL:-F.rotR;
    if(Math.abs(a)>1e-4){
      const ax=(left?-EMOTE_ROOT[0]:EMOTE_ROOT[0])/ART*transform.width,ay=(EMOTE_ROOT[1]-15)/ART*transform.height;
      const ox=transform.x+ax*c-ay*s,oy=transform.y+ax*s+ay*c,ca=Math.cos(a),sa=Math.sin(a),x=raw.x-ox,y=raw.y-oy;
      raw.x=ox+x*ca-y*sa;raw.y=oy+x*sa+y*ca;}}
  if(B.ox||B.oy){raw.x+=(B.ox*c-B.oy*s)*u;raw.y+=(B.ox*s+B.oy*c)*u;}
  if(B.mix){
    let tx,ty;
    const al=B.prev?X.prevAlly??X.ally:X.ally??X.prevAlly;
    if(B.ally&&al){
      // stations on the ally's far side: upper-outer and lower-outer (mirrored for a left ally)
      const sd=B.prev?X.prevSide??F.side:X.side??F.side;
      const a0=(B.slot===0?-1.05:.55)+.12*Math.sin(X.t*1.3+B.slot*2),ang=sd<0?Math.PI-a0:a0,R=.62*X.base;
      tx=al.x+R*Math.cos(ang);ty=al.y+R*Math.sin(ang);
    }else{
      const lx=B.line?0:B.tx,ly=B.line?-.66-B.slot*.105:B.ty;
      tx=transform.x+(lx*c-ly*s)*u;ty=transform.y+(lx*s+ly*c)*u;
    }
    raw.x+=(tx-raw.x)*B.mix;raw.y+=(ty-raw.y)*B.mix;
  }
  if(B.lean&&X.look){const dx=X.look.x-raw.x,dy=X.look.y-raw.y,d=Math.hypot(dx,dy)||1,m=B.lean*Math.min(.24*X.base,d*.22);raw.x+=dx/d*m;raw.y+=dy/d*m;}
  return raw;
}

/* ------------------------------------------------------------ soft lights */
/** Colours (0..1) of the lab's lights. */
export const EMOTE_TINTS=Object.freeze({focus:Object.freeze([255/255,150/255,236/255]),focusWarm:Object.freeze([240/255,190/255,140/255]),
  glow:Object.freeze([255/255,140/255,236/255]),glowWarm:Object.freeze([240/255,190/255,130/255])});
/** Pray's light sits where her wing tips meet (art units): measured on the lab's rig, the tips
 * meet at −217 at the full light and sink to −202 as it fades (≈ −201 − 16·√k). */
export function prayTipArt(k,out){out.ax=0;out.ay=-201-16*Math.sqrt(unit(k));return out;}
/** The lights for this frame, written into G (made by createEmoteGlows):
 * G.bits[i]: {focusR, focusA, glowR, glowA, warm} round each placed bit (px, alpha 0..1);
 * G.aura: {k, tipX, tipY, R} Pray; G.warm: {k, x, y, R} round the ally (Comfort).
 * base: her token size in px; alt: her height scale (altScale); vis[i]: each bit's alpha. */
export function createEmoteGlows(){
  const b=()=>({focusR:0,focusA:0,glowR:0,glowA:0,fk:0,warm:false});
  return {bits:[b(),b(),b(),b()],aura:{k:0,br:1,R:34,bodyR:92},warm:{k:0,R:70},glow:0};
}
export function emoteGlows(F,G,base=100,alt=1,vis=null,t=0){
  const warm=F.warm>.0001;
  for(let i=0;i<4;i++){const B=F.bits[i],o=G.bits[i],v=vis?vis[i]:1,fk=unit(B.focus);o.warm=warm;o.fk=fk>.01?fk:0;
    o.focusR=fk>.01?.07*base*alt*(.6+.4*fk):0;o.focusA=fk>.01?.5*fk*v*.8:0;
    o.glowR=B.glow>.01?.13*base*alt:0;o.glowA=B.glow>.01?.3*B.glow:0;}
  G.aura.k=F.hasAura?unit(F.aura):0;G.aura.br=.92+.08*Math.sin(t*2.1);G.aura.R=.34*base;G.aura.bodyR=.92*base;
  G.warm.k=unit(F.warm);G.warm.R=.7*base;G.glow=Math.max(0,F.glow);
  return G;
}
