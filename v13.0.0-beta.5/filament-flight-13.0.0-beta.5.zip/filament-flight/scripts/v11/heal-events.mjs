/** Yvaelle’s Toolbox v11 · Healing and the bits' jobs: what PF2e says (pure).
 *
 * No Foundry globals at import time, so the tests read the same functions.
 * Everything here reads data every client already has (chat messages and
 * actor/item data), so every client derives the same moments:
 *
 *  - readSpellCast(message)   a spell cast: who, its tradition, its actions
 *                             (1–3), healing or not, targets;
 *  - readEscape(message)      the Escape action ("action:escape") and its outcome;
 *  - readNatural(message)     a d20 that came up 20 or 1;
 *  - heroPointsSpent          from an updateActor change. */

export const TRADITIONS=Object.freeze(['arcane','divine','occult','primal']);
const strings=list=>Array.isArray(list)?list.filter(o=>typeof o==='string'):list instanceof Set?[...list].filter(o=>typeof o==='string'):[];
const lastId=u=>String(u??'').split('.').pop();
const num=v=>{const n=Number(v);return Number.isFinite(n)?n:null;};

/** Options of a PF2e message (context.options, origin.rollOptions). */
export function messageOptions(message){
  const f=message?.flags?.pf2e??{};
  return [...strings(f.context?.options),...strings(f.origin?.rollOptions)];
}
/** The token id and actor id a message speaks for. */
export function speakerOf(message){
  const s=message?.speaker??{};
  return {token:s.token?lastId(s.token):null,actor:s.actor?lastId(s.actor):null};
}
/** Target token ids of a message (context.target, context.targets, or the targets passed in). */
export function targetsOf(message,fallback=[]){
  const ctx=message?.flags?.pf2e?.context??{},out=[];
  const add=u=>{const id=lastId(u);if(id&&!out.includes(id))out.push(id);};
  if(ctx.target?.token)add(ctx.target.token);
  if(Array.isArray(ctx.targets))for(const t of ctx.targets)if(t?.token)add(t.token);
  if(!out.length)for(const t of fallback??[])add(typeof t==='string'?t:t?.id??t?.document?.id);
  return out;
}

/** A spell's tradition: the casting's own (flags.pf2e.casting.tradition),
 * else the spell's trait list, else its traditions (the first one). '' if none. */
export function traditionOf(message,item=null){
  const f=message?.flags?.pf2e??{};
  const own=String(f.casting?.tradition??'').toLowerCase();if(TRADITIONS.includes(own))return own;
  const opts=messageOptions(message);
  for(const o of opts){const m=/^(?:item|spell|origin:item):(?:trait|tradition):(arcane|divine|occult|primal)$/.exec(o);if(m)return m[1];}
  const sys=item?.system??null;
  for(const list of [sys?.traits?.value,sys?.traits?.traditions,sys?.traditions?.value])for(const t of strings(list))if(TRADITIONS.includes(t))return t;
  return '';
}
/** How many actions a cast took (1..3; 2 when it cannot tell). */
export function actionsOf(message,item=null){
  const f=message?.flags?.pf2e??{};
  for(const v of [f.casting?.actions,f.origin?.actions,f.context?.actions])if(num(v)>=1&&num(v)<=3)return num(v);
  for(const o of messageOptions(message)){
    const m=/^(?:item|spell|origin:item):(?:cast:actions|actions|time|cost:actions)(?::|-)(\d)$/.exec(o)??/^action:cost:(\d)$/.exec(o);
    if(m){const n=+m[1];if(n>=1&&n<=3)return n;}
  }
  const time=item?.system?.time?.value??item?.system?.actions?.value;
  const n=num(String(time??'').match(/[123]/)?.[0]);
  return n??2;
}
const HEAL_SLUGS=new Set(['heal','soothe','heal-companion','life-link','stabilize','vitality-lash','breath-of-life','rejuvenating-flames','field-of-life','healing-plaster','spirit-link','lay-on-hands','healers-blessing','healing-well']);
/** Is this a healing spell (healing trait, or a known healing slug)? */
export function isHealing(message,item=null){
  const opts=messageOptions(message);
  if(opts.some(o=>/^(?:item|spell|origin:item):trait:healing$/.test(o)||o==='healing'))return true;
  const traits=strings(item?.system?.traits?.value);if(traits.includes('healing'))return true;
  const slug=item?.slug??item?.system?.slug??message?.flags?.pf2e?.origin?.slug??null;
  return !!(slug&&HEAL_SLUGS.has(String(slug)));
}
/** A spell cast message: {caster:{token,actor}, tradition, actions, healing, targets, slug, item} or null.
 * `item` is the spell (PF2e: message.item), passed in by the runtime. */
export function readSpellCast(message,item=null,{targets=[]}={}){
  try{
    const f=message?.flags?.pf2e;if(!f)return null;
    const origin=f.origin??{},ctx=f.context??{};
    const spell=origin.type==='spell'||!!f.casting||ctx.type==='spell-cast'||item?.type==='spell';
    if(!spell)return null;
    // the cast itself, not its damage/attack/save rolls (those follow as their own messages)
    if(ctx.type&&!['spell-cast','spell-card'].includes(ctx.type))return null;
    return {caster:speakerOf(message),tradition:traditionOf(message,item),actions:actionsOf(message,item),healing:isHealing(message,item),
      targets:targetsOf(message,targets),slug:item?.slug??origin.slug??null,item:origin.uuid??null};
  }catch{return null;}
}
const OUTCOMES=['criticalSuccess','success','failure','criticalFailure'];
/** Her Escape attempt: {outcome, success, actor, token} or null. */
export function readEscape(message){
  try{
    const ctx=message?.flags?.pf2e?.context;if(!ctx)return null;
    const opts=messageOptions(message);
    if(!opts.includes('action:escape')&&ctx.slug!=='escape'&&!strings(ctx.domains).includes('escape'))return null;
    const outcome=OUTCOMES.includes(ctx.outcome)?ctx.outcome:null;if(!outcome)return null;
    return {outcome,success:outcome==='success'||outcome==='criticalSuccess',...speakerOf(message)};
  }catch{return null;}
}
/** The natural result of the first d20 rolled (the kept one with advantage), or null. */
export function naturalD20(rolls){
  for(const roll of Array.isArray(rolls)?rolls:[rolls]){
    const dice=roll?.dice??roll?.terms?.filter?.(t=>t&&t.faces)??[];
    for(const d of dice){
      if(Number(d?.faces)!==20)continue;
      const res=(d.results??[]).filter(r=>r&&r.active!==false&&!r.discarded);
      if(res.length)return Number(res[0].result);
    }
  }
  return null;
}
/** A d20 check by someone whose natural roll was 20 or 1: {nat:20|1, token, actor} or null.
 * (Damage rolls and flat checks for recovery are not die moods.) */
export function readNatural(message){
  try{
    if(!message?.rolls?.length)return null;
    const ctx=message.flags?.pf2e?.context;
    if(ctx&&['damage-roll','damage-taken'].includes(ctx.type))return null;
    const n=naturalD20(message.rolls);if(n!==20&&n!==1)return null;
    return {nat:n,...speakerOf(message)};
  }catch{return null;}
}
/** Hero Points spent in an updateActor change (before → after): how many, or 0. */
export function heroPointsSpent(before,changes){
  const next=num(changes?.system?.resources?.heroPoints?.value);
  if(next===null||before===null||before===undefined)return 0;
  return Math.max(0,Number(before)-next);
}

/** Is she grabbed or restrained (her Escape plays only then)? conditions: Set/array of slugs. */
export const heldBy=conds=>{const c=conds instanceof Set?conds:new Set(conds??[]);return c.has('grabbed')||c.has('restrained');};

/* ---------------- the lent bit's flag ---------------- */
