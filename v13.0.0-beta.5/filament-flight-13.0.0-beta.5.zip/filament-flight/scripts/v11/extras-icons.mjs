/** Yvaelle’s Toolbox v11 · the extras' line icons (the lab's Keepsake icon grammar:
 * 24×24, stroke 1.5, a .28 tint under the silhouette, secondary strokes at .5,
 * the four-point glint as the only filled accent). Pure strings. */
const G='M0-2.6l.75 1.85L2.6 0 .75.75 0 2.6-.75.75-2.6 0-.75-.75z';
const glint=(x,y,s)=>`<path transform="translate(${x} ${y}) scale(${s})" d="${G}" fill="currentColor" stroke="none"/>`;
const tint=d=>`<path d="${d}" fill="currentColor" fill-opacity=".28" stroke="none"/><path d="${d}"/>`;
const half=d=>`<path d="${d}" stroke-opacity=".5"/>`;
export const XI={
  heal:'<path d="M3.4 20.4c2.8-.3 4.3-2.1 4.7-4.5.5-2.9 2.8-4.2 5-3.4 1.8.7 1.9 3.1.2 3.5-1.6.4-2.3-1.4-1.3-3.1l4-5.6"/>'+glint(18.4,4.8,.9),
  fall:tint('M4.6 4.6c4.4.4 7.6 2.8 9 6.6-2.1-.2-3.8.2-5 1.2.3-2.6-1.2-5.4-4-7.8z')+'<path d="M16 8.2v6.4"/><path d="M13.8 12.6l2.2 2.2 2.2-2.2"/>'+half('M3.6 19.6h16.8')+'<path d="M9.4 17.4c1.8-1.3 3.7-1.9 5.4-1.6"/>',
  crit:tint('M12 2.4l2.3 7.3 7.3 2.3-7.3 2.3-2.3 7.3-2.3-7.3L2.4 12l7.3-2.3z'),
  hero:tint('M12 21C8 16.4 7.6 10.2 12 3c4.4 7.2 4 13.4 0 18z')+half('M12 18.6V9.4'),
  level:tint('M7.5 5h9l3 4.2L12 19.5 4.5 9.2z')+half('M4.5 9.2h15M10 5l-1.2 4.2L12 19.5l3.2-10.3L14 5'),
  tapestry:'<path d="M3.4 4.4h17.2"/><circle cx="2.6" cy="4.4" r=".9" fill="currentColor" stroke="none"/><circle cx="21.4" cy="4.4" r=".9" fill="currentColor" stroke="none"/>'+tint('M6 4.4h12v13.4l-3 2.4-3-2.4-3 2.4-3-2.4z')+half('M8.6 8.6c1.1-.8 2.3-.8 3.4 0s2.3.8 3.4 0M8.6 15c1.1-.8 2.3-.8 3.4 0s2.3.8 3.4 0')+glint(12,11.8,.78),
  milestone:tint('M10.5 20.4C6.9 16.4 6.5 10.9 10.5 4.4c4 6.5 3.6 12 0 16z')+half('M10.5 18V9.8')+glint(18.2,6.4,1.15)+glint(18.6,13.6,.62),
  recap:'<path d="M6.5 3.5H15l4 4v11.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 19V5a1.5 1.5 0 0 1 1.5-1.5z"/><path d="M7.6 11.2h2.6l1.1-2.4 1.6 4.8 1.1-2.4h2.4"/>'+half('M7.8 15.6h8.4M7.8 18h5'),
  session:'<path d="M5 4.5h14M5 19.5h14"/>'+half('M7 8h10M7 12h10M7 16h6')+glint(18,16,.8),
  fold:'<path d="M5 9l7-5 7 5M5 15l7 5 7-5"/>'+half('M5 12h14'),
  unfold:'<path d="M5 5l7 5 7-5M5 19l7-5 7 5"/>'+half('M5 12h14'),
  share:'<path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"/>',
  close:'<path d="M6 6l12 12M18 6L6 18"/>',
  eye:'<path d="M2.5 12s3.5-6.5 9.5-6.5 9.5 6.5 9.5 6.5-3.5 6.5-9.5 6.5S2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.6"/>'
};
export const xicon=(k,cls='ffx-ic',sw=1.5)=>`<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${XI[k]??''}</svg>`;
