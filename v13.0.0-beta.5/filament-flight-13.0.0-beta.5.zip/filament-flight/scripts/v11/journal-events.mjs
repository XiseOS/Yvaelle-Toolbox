/** Yvaelle’s Toolbox v11 · what a PF2e chat message or actor update means for her
 * journal (pure: no Foundry globals at import; tested in tools/v11/test-extras.mjs).
 *
 *  - readCheck: a d20 check of hers (attack, spell attack, skill, save): its
 *    label, degree of success and whether the die showed a natural 20;
 *  - readHealing: a healing roll of hers (Heal, Treat Wounds, Battle Medicine,
 *    any roll PF2e marks as healing): its total and source;
 *  - readFall: falling damage aimed at her (the flavour or roll options say so);
 *  - diffActor: her HP, Hero Points, level and dying value before → after. */

const CHECKS=new Set(['attack-roll','spell-attack-roll','skill-check','saving-throw','check']);
const ctxOf=m=>m?.flags?.pf2e?.context??null;
const flavorOf=m=>String(m?.flavor??'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
/** The first d20's natural result in a roll (or null). */
export function naturalD20(roll){
  try{
    const dice=roll?.dice??roll?.terms?.filter?.(t=>t?.faces)??[];
    for(const d of dice)if(Number(d.faces)===20){const r=(d.results??[]).find(x=>x.active!==false)??d.results?.[0];if(r)return Number(r.result);}
  }catch{}
  return null;
}
/** A check's label: the item or action name, else PF2e's own flavour heading. */
function labelOf(m,ctx){
  const item=m?.flags?.pf2e?.origin?.name??ctx?.item?.name??m?.item?.name;
  if(item)return String(item).slice(0,40);
  const t=flavorOf(m).split(/ [·:-] |\(/)[0].trim();
  return t.slice(0,40);
}
/** A check of hers: {type, label, outcome, crit, nat20} or null. */
export function readCheck(m){
  const ctx=ctxOf(m);if(!ctx||!CHECKS.has(ctx.type))return null;
  if(ctx.isReroll===undefined&&ctx.type==='check'&&/initiative|flat/i.test(String(ctx.domains??'')))return null;
  if(Array.isArray(ctx.domains)&&ctx.domains.some(d=>/initiative|flat-check/.test(d)))return null;
  const roll=m?.rolls?.[0];const nat=naturalD20(roll);
  const outcome=String(ctx.outcome??'');
  const kind={'attack-roll':'Strike','spell-attack-roll':'Spell attack','skill-check':'Skill check','saving-throw':'Saving throw'}[ctx.type]??'Check';
  return {type:ctx.type,kind,label:labelOf(m,ctx)||kind,outcome,crit:outcome==='criticalSuccess',nat20:nat===20,reroll:!!ctx.isReroll,target:ctx.target?.actor??null};
}
/** A healing roll of hers: {total, source} or null. */
export function readHealing(m){
  const ctx=ctxOf(m),rolls=Array.isArray(m?.rolls)?m.rolls:[];if(!rolls.length)return null;
  const flavor=flavorOf(m);
  const healingRoll=rolls.find(r=>{
    try{if(r?.kinds?.has?.('healing'))return true;}catch{}
    if(Array.isArray(r?.kinds)&&r.kinds.includes('healing'))return true;
    if(r?.options?.healing||r?.options?.damageType==='healing')return true;
    const inst=r?.instances??[];if(inst.some?.(i=>i?.kinds?.has?.('healing')||i?.type==='healing'||i?.type==='vitality'&&ctx?.options?.includes?.('healing')))return true;
    return false;
  });
  const traitHealing=Array.isArray(ctx?.options)&&ctx.options.some(o=>o==='item:trait:healing'||o==='healing');
  const textHealing=(ctx?.type==='damage-roll'||!ctx)&&/\bheal(ing|s)?\b|treat wounds|battle medicine|\bmend/i.test(flavor);
  if(!healingRoll&&!(ctx?.type==='damage-roll'&&traitHealing)&&!textHealing)return null;
  const r=healingRoll??rolls[0];const total=Math.max(0,Math.round(Number(r?.total)||0));
  const source=(m?.flags?.pf2e?.origin?.name??ctx?.item?.name??(flavor.match(/treat wounds|battle medicine|heal|soothe|lay on hands|medkit/i)?.[0]??'Healing'));
  const actions=Number(ctx?.options?.find?.(o=>/^item:cast:actions:\d$/.test(o))?.split(':').pop())||0;
  return {total,source:String(source).replace(/^./,c=>c.toUpperCase()).slice(0,40),actions,crit:/critical/i.test(String(ctx?.outcome??''))||r?.options?.degreeOfSuccess===3};
}
/** Falling damage aimed at her: {ft} (0 when the distance isn't said) or null. */
export function readFall(m,herId){
  const ctx=ctxOf(m);const flavor=flavorOf(m);
  const opts=Array.isArray(ctx?.options)?ctx.options:[];
  const aimed=!herId||ctx?.target?.actor?.endsWith?.(herId)||m?.speaker?.actor===herId||m?.flags?.pf2e?.appliedDamage?.uuid?.includes?.(herId);
  if(!aimed)return null;
  if(!(/\bfall(ing)?\b/i.test(flavor)||opts.includes('falling')||/arrest a fall/i.test(flavor)))return null;
  const ft=Number(flavor.match(/(\d+)\s*(?:ft|feet|foot)/i)?.[1])||0;
  return {ft,arrest:/arrest a fall/i.test(flavor)};
}
const n=(v)=>Number.isFinite(Number(v))?Number(v):null;
/** Her numbers from an actor (or its update diff merged on top). */
export function actorNumbers(actor){
  const a=actor?.system??{};
  return {hp:n(a.attributes?.hp?.value),max:n(a.attributes?.hp?.max),hero:n(a.resources?.heroPoints?.value),heroMax:n(a.resources?.heroPoints?.max),
    level:n(a.details?.level?.value),dying:n(a.attributes?.dying?.value)??0};
}
/** What changed between two snapshots of her numbers. */
export function diffActor(before,after){
  const out={};if(!before||!after)return out;
  if(before.hp!=null&&after.hp!=null&&after.hp!==before.hp)out.hp={from:before.hp,to:after.hp,delta:after.hp-before.hp};
  if(before.hero!=null&&after.hero!=null&&after.hero<before.hero)out.heroSpent=before.hero-after.hero;
  if(before.level!=null&&after.level!=null&&after.level>before.level)out.level={from:before.level,to:after.level};
  if(before.dying>0&&after.dying===0&&(after.hp??0)>0)out.recovered=true;
  if(before.hp>0&&after.hp===0)out.down=true;
  if(before.hp===0&&after.hp>0)out.up=true;
  return out;
}
