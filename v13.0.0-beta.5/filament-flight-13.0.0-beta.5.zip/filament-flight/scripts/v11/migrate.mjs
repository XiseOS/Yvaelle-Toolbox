/** Yvaelle’s Toolbox v11 · settings migration (pure).
 *
 * The v11 Settings overhaul changes where a setting is SHOWN, never where it
 * is STORED: every row keeps its v10.0.1 key and read/write path, so no value
 * moves. Only saved navigation state is remapped here:
 *  - old group ids (the groups pressed onto Home, the remembered open group,
 *    HUD routes such as {group}, detail:'stabilizers' and 'bits-placement')
 *    map to `section/group` through ROUTES;
 *  - the groups pressed onto Home become the sections pinned to Home. They are
 *    written to a NEW key (keepsakeUI.pinnedSections), once; the old
 *    pressedSettings list is left as it was, so going back to 10.0.1 finds it;
 *  - the saved Simple/Everything level maps to "open every Finer tuning". */

/** Old group ids and routes → `section/group` (or `section/group#row`). */
export const ROUTES=Object.freeze({appearance:'her/wings',sheet:'hud/sheet',animation:'flight/motion',medical:'healing/medkit',size:'her/wings',bits:'her/bits',expression:'her/bits',
  reactions:'combat/conditions',feel:'flight/feel',combat:'combat/moments',quality:'perf/quality',sound:'sound/mine',looks:'her/bits',versions:'advanced/versions',hud:'hud/hudframe',keep:'perf/keep',
  stabilizers:'her/bits','bits-placement':'her/bits#bitPlacement'});
export const SECTION_IDS=Object.freeze(['overview','her','flight','combat','healing','emotes','hud','perf','sound','advanced']);
export const PIN_CAP=4;

/** Where an old group id or route goes: {section, group, row} or null. New ids pass through. */
export function routeFor(id){
  if(typeof id!=='string'||!id)return null;
  const target=ROUTES[id]??(id.includes('/')?id:SECTION_IDS.includes(id)?id:null);
  if(!target)return null;
  const [path,row=null]=target.split('#'),[section,group=null]=path.split('/');
  return SECTION_IDS.includes(section)?{section,group,row}:null;
}
/** The sections pinned to Home, from the v10 pressedSettings list (old group ids). Order kept, duplicates dropped, capped. */
export function pinsFromPressed(pressed){
  const out=[];
  for(const id of Array.isArray(pressed)?pressed:[]){const r=routeFor(id);if(r&&r.section!=='overview'&&!out.includes(r.section))out.push(r.section);}
  return out.slice(-PIN_CAP);
}
/** One-time migration of the HUD preferences object (keepsakeUI). Returns a patch, or null when nothing is to do. */
export function migrateUI(ui){
  if(!ui||typeof ui!=='object')return null;
  if(Array.isArray(ui.pinnedSections))return null;
  return {pinnedSections:pinsFromPressed(ui.pressedSettings??['bits','looks'])};
}
/** The v10 saved detail level: Everything opens every Finer tuning by default. */
export const finerOpenFromLevel=level=>level==='Everything'||level==='advanced';
/** The pinned sections, read safely (migrating on the fly when never written). */
export function pinnedSections(ui){
  const p=Array.isArray(ui?.pinnedSections)?ui.pinnedSections:pinsFromPressed(ui?.pressedSettings??['bits','looks']);
  return p.filter(id=>SECTION_IDS.includes(id)&&id!=='overview').slice(-PIN_CAP);
}
