/** Yvaelle’s Toolbox v11 · Healing and the bits' jobs on her WINGS (pure, worker-safe).
 *
 * Port of the approved lab strokes (lab/canvas canvas-fx.mjs, lab/v11/liked
 * liked-fx.mjs) to the module's wing rig. It runs inside frameGeometry
 * (healGeometry: the occult edge ripple) and paintLayers
 * (healPaint: tinted currents and glints over a layer, art units), on the main
 * thread or in the wing worker, from one small serialisable state:
 *
 *   visual.v11heal = {
 *     ops:[{k, s, ...}],   moments playing now (s = seconds since the moment began)
 *        k:'divine'|'arcane'|'primal'|'occult'   a spell tradition's response
 *        k:'hero'                                 a Hero Point spent
 *     anim                 true while any op plays (the renderer repaints)
 *   }
 * With no state there is nothing to do. */
const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const easeOut=(x,p=3)=>1-(1-unit(x))**p;
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const env=(t,a,ain,b,bout)=>smooth((t-a)/ain)*(1-smooth((t-b)/bout));
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${a<0?0:a>1?1:a})`;

/* ---------- palette (lab canvas-fx PAL) ---------- */
export const PAL=Object.freeze({
  magenta:{bloom:[255,96,236],core:[255,222,252]},
  gold:{bloom:[214,170,96],core:[255,226,164]},
  ice:{bloom:[110,140,255],core:[200,220,255]},
  verdant:{bloom:[118,168,72],core:[198,228,136]},
  violet:{bloom:[164,92,255],core:[214,180,255]},
  rose:{bloom:[244,96,206],core:[255,214,244]},
  rosegold:{core:[255,228,198],bloom:[240,160,120]},
});
/** Spell response timing: it starts at s=0 and lasts SPELL_SPAN seconds. */
export const SPELL_SPAN=1.5;

/* ---------- strand helpers (art units, as the rig emits them) ---------- */
function strand(wings,side,id){for(const k of [side+'Rear',side+'Front'])for(const s of wings[k]??[])if(s.id===id)return {s,key:k};return null;}
function pointAtU(points,u){for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i];if((a[3]-u)*(b[3]-u)<=0&&a[3]!==b[3]){const k=(u-a[3])/(b[3]-a[3]);return a.map((x,j)=>x+(b[j]-x)*k);}}return u<=points[0][3]?points[0]:points[points.length-1];}
function sliceU(points,u0,u1){const out=[];for(let i=0;i<points.length;i++){const u=points[i][3];if(u>=u0&&u<=u1)out.push(points[i]);}
  if(u0>0&&u0<1)out.unshift(pointAtU(points,u0));if(u1>0&&u1<1)out.push(pointAtU(points,u1));return out;}
function pointAtF(points,f){const n=points.length-1,x=Math.max(0,Math.min(n,f*n)),i=Math.min(n-1,Math.floor(x)),k=x-i;return points[i].map((v,j)=>v+(points[i+1][j]-v)*k);}
/** A tinted current (the module's v10 reaction-current recipe: bloom 6.5w/2.8w + core) in any colour. */
function current(ctx,points,width,s,tint,bloom=1){
  if(points.length<2||s<.01)return;
  ctx.beginPath();for(let i=0;i<points.length;i++){const p=points[i];if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);}
  const b=tint.bloom,c=tint.core;
  ctx.lineWidth=width*6.5;ctx.strokeStyle=rgba(b,.18*s*bloom);ctx.stroke();
  ctx.lineWidth=width*2.8;ctx.strokeStyle=rgba(b,.42*s);ctx.stroke();
  ctx.lineWidth=Math.max(1.7,width*1.35);ctx.strokeStyle=rgba(c,s);ctx.stroke();
}
/** The rig's star glint (a thin four-point diamond), tinted. */
function star(ctx,x,y,r,a,tint,flat=.45){
  if(a<.01)return;
  const g=ctx.createRadialGradient(x,y,0,x,y,r*3.8);g.addColorStop(0,rgba(tint.bloom,a*.7));g.addColorStop(1,rgba(tint.bloom,0));
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r*3.8,0,TAU);ctx.fill();
  ctx.fillStyle=rgba(tint.core,a);
  ctx.beginPath();ctx.moveTo(x,y-r*2);ctx.lineTo(x+r*flat,y);ctx.lineTo(x,y+r*2);ctx.lineTo(x-r*flat,y);ctx.closePath();ctx.fill();
  ctx.beginPath();ctx.moveTo(x-r*1.3,y);ctx.lineTo(x,y+r*flat*.6);ctx.lineTo(x+r*1.3,y);ctx.lineTo(x,y-r*flat*.6);ctx.closePath();ctx.fill();
}
const sideOf=key=>key.startsWith('left')?'left':'right';

/* ===================== spell traditions (lab canvas-fx 3) ===================== */
const UP=['rib-0','rib-1','rib-2','rib-3','rib-4'],LOW=['rib-6','rib-7','rib-8','rib-9'];
function paintDivine(ctx,key,wings,s){
  const side=sideOf(key),q=s/SPELL_SPAN;if(q<0||q>1.1)return;
  const glow=env(s,0,.35,SPELL_SPAN-.5,.5);
  for(const id of UP){const r=strand(wings,side,id);if(r)current(ctx,sliceU(r.s.points,.25,1),.9,.3*glow*(id==='rib-0'?1.3:1),PAL.gold,1.6);}
  for(let n=0;n<2;n++)for(let j=0;j<UP.length;j++){
    const r=strand(wings,side,UP[j]);if(!r)continue;const h=easeOut((q-.05-n*.32-j*.05)/.6)*1.2;if(h<=0||h>=1.2)continue;
    current(ctx,sliceU(r.s.points,Math.max(0,h-.28),Math.min(1,h)),1.3,1.05*bump(h/1.2)*(n?.65:1),PAL.gold);
  }
  for(let j=0;j<LOW.length;j++){
    const r=strand(wings,side,LOW[j]);if(!r)continue;const h=1-easeOut((q-.12-j*.06)/.65)*1.2;if(h>=1||h<=-.2)continue;
    current(ctx,sliceU(r.s.points,Math.max(0,h),Math.min(1,h+.22)),1,.7*bump((1-h)/1.2),PAL.gold);
  }
  const r0=strand(wings,side,'rib-0');if(r0){const p=r0.s.points[r0.s.points.length-1];star(ctx,p[0],p[1],2.6,.95*bump(unit((q-.35)/.6)),PAL.gold);}
}
const ARC_SEG=(()=>{const out=[];const pairs=[[1,2,.42],[2,3,.5],[3,4,.58],[1,2,.66],[2,3,.74],[5,6,.45],[6,7,.55],[7,8,.62],[4,5,.5],[6,7,.75],[3,4,.82],[8,9,.48]];
  pairs.forEach(([a,b,u],k)=>{out.push({a:`rib-${a}`,b:`rib-${b}`,ua:u,ub:u+.1,at:k*.065,diag:false});out.push({a:`rib-${a}`,b:`rib-${b}`,ua:u+.1,ub:u-.06,at:k*.065+.03,diag:true});});return out;})();
function paintArcane(ctx,key,wings,s){
  const side=sideOf(key);if(s<0||s>SPELL_SPAN+.2)return;
  for(const seg of ARC_SEG){
    const ra=strand(wings,side,seg.a),rb=strand(wings,side,seg.b);if(!ra||!rb)continue;
    const lt=s-seg.at-(side==='right'?.03:0);if(lt<0)continue;
    const a=lt<.05?lt/.05:Math.exp(-(lt-.05)*(seg.diag?5:3.4));if(a<.02)continue;
    const A=pointAtU(ra.s.points,seg.ua),B=pointAtU(rb.s.points,seg.ub);
    current(ctx,[A,B],.55,.9*a,PAL.ice,.5);
    if(!seg.diag){star(ctx,A[0],A[1],1.5,a,PAL.ice,.3);if(lt<.25)star(ctx,B[0],B[1],1.2,a*.8,PAL.ice,.3);}
  }
  const r=strand(wings,side,'rib-3');if(r){const p=pointAtU(r.s.points,.92);star(ctx,p[0],p[1],2.4,bump(unit((s-1.05)/.35)),PAL.ice,.25);}
}
const PRIM=[['edge-2',.35,70,1],['edge-2',.75,62,-1],['edge-3',.5,58,1],['edge-4',.3,74,-1],['edge-4',.7,66,1],['edge-0',.55,56,-1],['edge-5',.45,50,1],['rib-9',.98,58,-1]];
function tendril(origin,heading,len,curl,steps=30,seed=0){
  const pts=[[origin[0],origin[1],0,0]];let x=origin[0],y=origin[1],h=heading;
  for(let i=1;i<=steps;i++){const s=i/steps;h+=curl*(.01+.62*s**4)+.085*Math.sin(s*7.5+seed);x+=Math.cos(h)*len/steps;y+=Math.sin(h)*len/steps;pts.push([x,y,0,s]);}
  return pts;
}
function paintPrimal(ctx,key,wings,s){
  const side=sideOf(key),sx=side==='left'?-1:1;if(s<0||s>SPELL_SPAN+.1)return;
  for(let k=0;k<PRIM.length;k++){const [id,f,len,cs]=PRIM[k];
    const r=strand(wings,side,id);if(!r)continue;
    const p=pointAtF(r.s.points,f),h=Math.atan2(p[1]-20,p[0]-sx*120)+cs*sx*.25;
    const grow=easeOut((s-k*.045)/.62),back=smooth((s-SPELL_SPAN+.55)/.5),reach=grow*(1-back);if(reach<=.02)continue;
    const curl=cs*sx*1.1,full=tendril(p,h,len,curl,30,k*1.7);
    const n=Math.max(2,Math.round(full.length*reach)),pts=full.slice(0,n);
    current(ctx,pts,.55,.9,PAL.verdant,.8);
    const need=.38+.08;if(reach>=need){const bi=Math.round(full.length*.38),b0=full[bi],b1=full[bi+1],bh=Math.atan2(b1[1]-b0[1],b1[0]-b0[0])-cs*sx*.42;
      const br=tendril(b0,bh,len*.36,-curl*1.15,18,k+.38*7),bn=Math.max(2,Math.round(br.length*unit((reach-need)/(1-need)*1.4)));
      current(ctx,br.slice(0,bn),.42,.75,PAL.verdant,.6);}
    if(grow<1&&!back){const tip=pts[pts.length-1];star(ctx,tip[0],tip[1],1,.7,PAL.verdant,.7);}
  }
}
const OCC_E=['edge-0','edge-1','edge-2','edge-3','edge-4','edge-5','edge-6'];
function displaced(points,amp,phase,t,spatial=3.2,speed=1.9){
  const n=points.length,out=new Array(n);
  for(let i=0;i<n;i++){const p=points[i],a=points[Math.max(0,i-1)],b=points[Math.min(n-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy)||1,f=i/(n-1||1),d=amp*Math.sin(TAU*(f*spatial-t*speed)+phase);
    out[i]=[p[0]-dy/l*d,p[1]+dx/l*d,p[2],p[3]];}
  return out;
}
const occultK=s=>env(s,0,.25,SPELL_SPAN-.45,.45);
function paintOccult(ctx,key,wings,s){
  const side=sideOf(key),e=occultK(s);if(e<=.01)return;
  for(const [g,ph,off] of [[0,Math.PI*.6,1],[1,-Math.PI*.6,-1]]){
    for(const id of OCC_E){const r=strand(wings,side,id);if(!r)continue;const idx=+id.slice(5);
      const pts=displaced(r.s.points,6.5*e,idx*1.3+ph,s+g*.13,2.4,1.4),sx=(side==='left'?-1:1)*off*5*e;
      for(const p of pts){p[0]+=sx;p[1]-=off*2*e;}
      current(ctx,pts,.55,(g?.38:.5)*e*(.75+.25*Math.sin(s*9+g*2)),PAL.violet,.6);
    }
  }
}


/* ===================== Hero Point spent (lab liked-fx 3) ===================== */
export const HERO_SPAN=2.2;
const HERO_RIBS=['rib-0','rib-2','rib-4','rib-6','rib-9'];
function paintHero(ctx,key,wings,q){
  if(q<0||q>2)return;const side=sideOf(key);
  const qi=q/.62;if(qi>0&&qi<1.05)for(let j=0;j<HERO_RIBS.length;j++){const r=strand(wings,side,HERO_RIBS[j]);if(!r)continue;const k=unit(qi-j*.035),head=1-easeOut(k,2);
    current(ctx,sliceU(r.s.points,Math.max(0,head-.02),Math.min(1,head+.26)),1.15,.95*bump(k)**.6,PAL.rosegold,1.1);}
  const qo=(q-.8)/.62;if(qo>0&&qo<1.25)for(let j=0;j<HERO_RIBS.length;j++){const r=strand(wings,side,HERO_RIBS[j]);if(!r)continue;const k=unit(qo-j*.03),head=easeOut(k,2)*1.08;
    current(ctx,sliceU(r.s.points,Math.max(0,head-.28),Math.min(1,head)),1.2,.92*(1-smooth((k-.75)/.25)),PAL.rosegold,1.15);
    const tk=(qo-j*.03-.82)/.4;if(tk>0&&tk<1){const p=r.s.points[r.s.points.length-1];star(ctx,p[0],p[1],1.7,.8*bump(tk),PAL.rosegold);}}
}


/* ===================== the rig's hooks ===================== */
/** Is there anything to draw? */
export const healActive=H=>!!(H&&H.ops?.length);
/** frameGeometry: the occult edge ripple. Returns new layer arrays where it changes any (the rig's cache is never touched). */
export function healGeometry(wings,H){
  if(!healActive(H))return wings;
  const out={...wings},touched=new Set();
  const layer=k=>{if(!touched.has(k)){out[k]=out[k].slice();touched.add(k);}return out[k];};
  for(const o of H.ops??[])if(o.k==='occult'){const e=occultK(o.s);if(e<=0)continue;
    for(const k of ['leftRear','rightRear','leftFront','rightFront']){const L=layer(k);
      for(let i=0;i<L.length;i++){const s=L[i];if(!s.id?.startsWith('edge-')||!s.points)continue;const idx=+s.id.slice(5);L[i]={...s,points:displaced(s.points,3.2*e,idx*1.3,o.s)};}}}
  return out;
}
/** paintLayers: this layer's strokes (art transform already set). */
export function healPaint(ctx,key,wings,H){
  if(!healActive(H))return;
  if(!key.endsWith('Rear')||!H.ops)return;
  for(const o of H.ops){
    switch(o.k){
      case 'divine':paintDivine(ctx,key,wings,o.s);break;
      case 'arcane':paintArcane(ctx,key,wings,o.s);break;
      case 'primal':paintPrimal(ctx,key,wings,o.s);break;
      case 'occult':paintOccult(ctx,key,wings,o.s);break;
      case 'hero':paintHero(ctx,key,wings,o.s);break;
    }
  }
}
/** The visual profile's own levers (energy, the module's heal burst) for the ops playing now. */
// (test.5) The divine burst is a cue for her wing's heal line only (its progress and amount). It carries
// strength and envelope 0: the gem choreography reads a burst's light from those, and without them its heal
// channel was NaN, the gems' support strokes got NaN points, the wing layers' crop went NaN and her wings
// vanished (for the 30 s the off-thread painter takes to retry). The gems keep their own light, as before.
export function healVisualLevers(visual,H){
  if(!H?.ops?.length)return visual;
  let energy=0,bursts=null;
  for(const o of H.ops){
    if(o.k==='divine'){energy+=.18*env(o.s,0,.4,SPELL_SPAN-.5,.5);const q=o.s/SPELL_SPAN;if(q>0&&q<1)(bursts??=[]).push({kind:'heal',progress:q,amount:.55,strength:0,envelope:0});}
    else if(o.k==='arcane')energy-=.08*env(o.s,0,.1,SPELL_SPAN-.3,.3);
  }
  if(!energy&&!bursts)return visual;
  const v={...visual,energy:(visual.energy??1)+energy,animated:true};
  if(bursts)v.bursts=[...(visual.bursts??[]),...bursts];
  return v;
}
