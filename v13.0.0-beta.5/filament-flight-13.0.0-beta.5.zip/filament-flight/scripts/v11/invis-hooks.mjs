/** Yvaelle’s Toolbox v11 · Invisibility: the few places the wing painter asks about her.
 *
 * The renderers (pose-renderer.mjs, renderer.mjs) import only this small
 * registry; the invisibility runtime (v11/invis-runtime.mjs) fills it in.
 * Every hook is optional and returns the "nothing to do" answer when unset, so
 * a token that is not invisible costs one property read a frame. */
export const invisHooks={
  /** (token, now) → visual.v11Drain for her wings ({mode,F,ghost,hot}) or null. */
  drain:null,
  /** (token, kind 'bits'|'shadow'|'wings') → alpha multiplier (1 = untouched). */
  alpha:null,
  /** (token) → true while her portrait is see-through on this screen (hidden, with a ghost kept): her rear wing layers are cleared behind it. */
  through:null,
  /** (token) → true while a sweep runs: paint her wings on this thread (the ghost needs the geometry). */
  mainThread:null,
  /** (rig, wingGeometry, visual, changedKeys) → after the rig painted its layers on this thread. */
  painted:null,
};
export const veilAlphaOf=(token,kind)=>invisHooks.alpha?invisHooks.alpha(token,kind):1;
