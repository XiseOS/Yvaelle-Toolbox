import {hash} from './conditions.mjs?v=13.0.0-beta.5';
import {sampleV7LightRefraction} from './v7-light-refraction.mjs?v=13.0.0-beta.5';

const TAU=Math.PI*2,SPEED=.16;
export const LIGHT_APPEARANCE_PERIOD=TAU/SPEED;
const finite=(value,fallback=0)=>Number.isFinite(value)?value:fallback;
const unit=value=>Math.min(1,Math.max(0,finite(value)));
const modulo=(value,period)=>(value%period+period)%period;
const smooth=value=>{value=unit(value);return value*value*(3-2*value);};

/** The native light remains mechanically stable. Only its already-clipped
 * layer output responds to the same resolved channels as the wings. Phases
 * are deterministic, bounded and intentionally slow; no event polling,
 * documents, sockets or per-token history are needed. */
export function sampleLightAppearance(snapshot={},config={},now=0,{seed='flight'}={}){
  const appearance=snapshot.lightAppearance??snapshot.light?.appearance??snapshot.requested?.lightAppearance??config.lightAppearance??'animated';
  const reactions=snapshot.lightVisualReactions??snapshot.light?.visualReactions??snapshot.requested?.lightVisualReactions??config.lightVisualReactions??true;
  const permitted=config.localEffects!==false&&!config.reduced&&snapshot.effective?.reducedMotion!==true&&config.effectsEnabled!==false;
  const animated=permitted&&appearance==='animated',reactive=permitted&&reactions;
  const phase=permitted?modulo(finite(now)/1000-.26,LIGHT_APPEARANCE_PERIOD)*SPEED+(hash(seed)%1009)/1009*TAU:0;
  const visual=snapshot.visual??{},profile=visual.profile?.variant?visual.semanticProfile??visual.profile:visual.profile??visual.semanticProfile??{};
  // Appearance opt-outs and the wing channel gates remain authoritative. The
  // semantic profile retains HP severity when authored wing art owns geometry.
  const conditions=reactive&&config.visualConditions!==false&&visual.effectStyle!=='none';
  const intensity=unit(finite(snapshot.effective?.intensity,1)),strength=intensity*unit(finite(snapshot.requested?.effectTuning?.[visual.condition]?.strength,1));
  const damage=conditions&&config.filamentBreaks!==false?unit(profile.damage)*strength:0;
  const instability=conditions&&config.filamentInstability!==false?unit(profile.instability)*strength:0;
  const glitch=conditions&&config.filamentGlitches!==false?unit(Math.min(finite(config.glitchLimit,1),finite(profile.glitch)))*strength:0;
  const suppression=conditions?unit(1-finite(profile.energy,1))*strength:0;
  const response=snapshot.conditionResponse,collapseResponse=reactive&&response?.wings?unit(response.collapse?.mix):0;
  const collapse=Math.max(conditions?unit(profile.collapse)*strength:0,collapseResponse*intensity);
  const recovery=reactive&&response?.wings&&response.collapse?.phase==='recovering'?smooth(response.collapse?.progress):
    conditions?unit(visual.profile?.healing??visual.profile?.reformation?.lift):0;
  // Overlapping soft pulses produce irregular dips, never binary flashing.
  // The fastest cycle is almost eight seconds, with a broad rise and fall.
  const uneven=(.5+.5*Math.sin(phase*3+.4))*(.5+.5*Math.sin(phase*5+1.8));
  const dip=(damage*.065+instability*.055+glitch*.20)*uneven*(1-recovery*.6);
  const base=1-Math.max(collapse*.80,suppression*.34);
  const gain=permitted?Math.max(.12,Math.min(1,base-dip)):1;
  const legacyEnabled=animated&&intensity>0||reactive&&Math.max(damage,instability,glitch,suppression,collapse,recovery)>0;
  const refraction=sampleV7LightRefraction(snapshot,config,now,{seed});
  return {enabled:legacyEnabled||refraction.enabled,legacyEnabled,refraction,animated,phase,detail:animated?intensity:0,gain,
    disruption:reactive?unit(Math.max(damage*.45,instability*.6,glitch)*(1-recovery*.65)):0,recovery};
}
