/** Cached topology for one team of at most four native scan cells.
 * Only index relationships are cached: returned boundary vertices borrow the
 * caller's exact current coordinates, including moving native-grid frames. */
export const LINKED_SCAN_BOUNDARY_LIMIT=128;
const cache=new Map(),EPS=1e-7,MAX_CELLS=4,MAX_VERTICES=64;
let builds=0,hits=0;
const point=value=>Array.isArray(value)?{x:value[0],y:value[1]}:value;
const valid=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
const q=n=>Math.round(n*1e6)/1e6;
const keyPoint=p=>`${q(p.x)}:${q(p.y)}`;
function topology(polygons,vertices,origin){
  const at=vertices.map(p=>({x:p.x-origin.x,y:p.y-origin.y})),segments=[],vertexGroups=new Map();
  at.forEach((p,i)=>{const key=keyPoint(p);if(!vertexGroups.has(key))vertexGroups.set(key,i);});
  const representative=i=>vertexGroups.get(keyPoint(at[i]));
  let cursor=0;
  for(const polygon of polygons){for(let i=0;i<polygon.length;i++)segments.push([cursor+i,cursor+(i+1)%polygon.length]);cursor+=polygon.length;}
  const boundary=new Map();
  for(const [ai,bi] of segments){
    const a=at[ai],b=at[bi],dx=b.x-a.x,dy=b.y-a.y,length2=dx*dx+dy*dy;if(length2<EPS*EPS)continue;
    const cuts=[{i:representative(ai),t:0},{i:representative(bi),t:1}];
    for(let i=0;i<at.length;i++){
      const p=at[i],cross=Math.abs((p.x-a.x)*dy-(p.y-a.y)*dx),t=((p.x-a.x)*dx+(p.y-a.y)*dy)/length2;
      if(t>EPS&&t<1-EPS&&cross<=EPS*Math.sqrt(length2))cuts.push({i:representative(i),t});
    }
    cuts.sort((a,b)=>a.t-b.t);const unique=cuts.filter((v,i)=>i===0||Math.abs(v.t-cuts[i-1].t)>EPS);
    for(let i=1;i<unique.length;i++){
      const a=unique[i-1].i,b=unique[i].i;if(a===b)continue;const key=a<b?`${a}:${b}`:`${b}:${a}`;
      if(boundary.has(key))boundary.delete(key);else boundary.set(key,[a,b]);
    }
  }
  const edges=[...boundary.values()],adjacent=new Map();
  edges.forEach(([a,b],i)=>{for(const p of [a,b]){const list=adjacent.get(p)??[];list.push(i);adjacent.set(p,list);}});
  const remaining=new Set(edges.map((_,i)=>i)),loops=[];
  while(remaining.size){
    const first=remaining.values().next().value,[start,next]=edges[first],loop=[start,next];remaining.delete(first);let previous=start,current=next;
    for(let n=0;n<edges.length&&current!==start;n++){
      const candidates=(adjacent.get(current)??[]).filter(i=>remaining.has(i));if(!candidates.length)break;
      // A rare corner-only contact can have four incident exterior edges.
      // Continue the smallest turn to retain separate coherent outlines.
      const incoming=Math.atan2(at[current].y-at[previous].y,at[current].x-at[previous].x);
      candidates.sort((i,j)=>{
        const other=i=>edges[i][0]===current?edges[i][1]:edges[i][0],angle=i=>Math.abs(Math.atan2(Math.sin(Math.atan2(at[other(i)].y-at[current].y,at[other(i)].x-at[current].x)-incoming),Math.cos(Math.atan2(at[other(i)].y-at[current].y,at[other(i)].x-at[current].x)-incoming)));
        return angle(i)-angle(j)||i-j;
      });
      const index=candidates[0],edge=edges[index],to=edge[0]===current?edge[1]:edge[0];remaining.delete(index);loop.push(to);previous=current;current=to;
    }
    loops.push(loop);
  }
  const outlines=loops.map(loop=>{
    const closed=loop.at(-1)===loop[0],points=closed?loop.slice(0,-1):loop.slice();
    const simplified=points.filter((index,i)=>{
      if(!closed&&(i===0||i===points.length-1))return true;
      const a=at[points[(i+points.length-1)%points.length]],b=at[index],c=at[points[(i+1)%points.length]],cross=(b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x),scale=Math.hypot(b.x-a.x,b.y-a.y)+Math.hypot(c.x-b.x,c.y-b.y);
      return Math.abs(cross)>EPS*Math.max(1,scale)||(b.x-a.x)*(c.x-b.x)+(b.y-a.y)*(c.y-b.y)<0;
    });
    if(closed&&simplified.length)simplified.push(simplified[0]);return simplified;
  });
  return {edges:outlines.flatMap(loop=>loop.slice(1).map((b,i)=>[loop[i],b])),loops:outlines};
}
export function linkedScanBoundary(input){
  const polygons=(Array.isArray(input)?input:[]).slice(0,MAX_CELLS).map(p=>(Array.isArray(p)?p:[]).slice(0,MAX_VERTICES).map(point).filter(valid)).filter(p=>p.length>=3),vertices=polygons.flat();
  if(!vertices.length)return {edges:[],loops:[],perimeter:0,origin:{x:0,y:0},key:''};
  const origin=vertices[0],key=JSON.stringify(polygons.map(p=>p.map(v=>[q(v.x-origin.x),q(v.y-origin.y)])));let shape=cache.get(key);
  if(!shape){shape=topology(polygons,vertices,origin);if(cache.size>=LINKED_SCAN_BOUNDARY_LIMIT)cache.delete(cache.keys().next().value);cache.set(key,shape);builds++;}else hits++;
  const edges=shape.edges.map(([a,b])=>({a:vertices[a],b:vertices[b],length:Math.hypot(vertices[b].x-vertices[a].x,vertices[b].y-vertices[a].y)}));
  return {edges,loops:shape.loops.map(loop=>loop.map(i=>vertices[i])),perimeter:edges.reduce((n,e)=>n+e.length,0),origin,key};
}
export function linkedScanBoundaryCacheInfo(){return {size:cache.size,builds,hits,limit:LINKED_SCAN_BOUNDARY_LIMIT};}
export function clearLinkedScanBoundaryCache(){cache.clear();builds=0;hits=0;}
