/** Physical instruments face their work. Fine optical sweeps can cross the
 * portrait without making the entire metal housing chase each light stripe. */
const difference=(from,to)=>Math.atan2(Math.sin(to-from),Math.cos(to-from));
const limit=(value,bound)=>Math.max(-bound,Math.min(bound,value));
const point=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
export const SCAN_FACING_SPEED=.68;
export const SCAN_ACQUISITION_FACING_SPEED=1.05;
export const SCAN_RELOCATION_FACING_SPEED=1.9;
export const SCAN_RELOCATION_FACING_ACCELERATION=4;
export const SCAN_RELOCATION_FACING_JERK=24;
export const SCAN_FACING_ACCELERATION=1.8;
export const SCAN_FACING_JERK=7.2;

export function scanPurposeTargets(sample,event,context){
  if(sample.scanRelocating)return {};
  const targets={},deliberate=(tool,ctx)=>tool?.utility?.mode==='creatureScan'&&
    (tool.utility.examinationMovement??ctx?.snapshot?.v8Motion?.examinationMovement??'deliberate')!=='classic';
  if(deliberate(event,context)&&point(context.target))for(const id of Object.keys(sample.positions??{}))targets[id]=context.target;
  for(const surface of sample.encounterSurfaces??[]){
    if(!deliberate(surface.event,surface.context)||!point(surface.context?.target))continue;
    for(const id of surface.event.bits??[])if(sample.positions?.[id])targets[id]=surface.context.target;
  }
  // A station may examine the upper, side or lower part of a portrait. This
  // purpose is supplied by the physical itinerary, never by a light stripe.
  for(const [id,purpose]of Object.entries(sample.scanPurpose??{}))if(targets[id]&&point(purpose?.target))targets[id]=purpose.target;
  return targets;
}

/** A bounded angular drive with gradual acceleration changes. Its clock is
 * local to the displayed body; repeated captures never integrate it twice. */
export function stepScanFacing(previous,{heading,initialHeading=heading,now,paused=false,acquiring=false,tracking=false}={}){
  if(!Number.isFinite(heading))heading=previous?.heading??0;
  if(!previous||!Number.isFinite(previous.now)||now<previous.now)return {heading:Number.isFinite(initialHeading)?initialHeading:heading,velocity:0,acceleration:0,target:heading,now};
  if(paused)return {heading:initialHeading,velocity:0,acceleration:0,target:heading,now};
  if(now===previous.now)return {...previous};
  const dt=Math.max(0,Math.min(100,now-previous.now))/1000,steps=Math.max(1,Math.ceil(dt*120)),step=dt/steps;
  let angle=previous.heading,velocity=previous.velocity??0,acceleration=previous.acceleration??0;
  const relocating=tracking||previous.relocating&&Math.abs(velocity)>SCAN_FACING_SPEED;
  const accelerationLimit=relocating?SCAN_RELOCATION_FACING_ACCELERATION:SCAN_FACING_ACCELERATION;
  const jerkLimit=relocating?SCAN_RELOCATION_FACING_JERK:SCAN_FACING_JERK;
  const target=angle+difference(angle,heading),rawPace=difference(previous.target??previous.heading,heading)/Math.max(.001,dt);
  const speed=tracking?SCAN_RELOCATION_FACING_SPEED:acquiring?SCAN_ACQUISITION_FACING_SPEED:SCAN_FACING_SPEED;
  // Large, authored relocations and full circuits have a continuous moving
  // aim. Follow its pace while retaining the same bounded acceleration/jerk.
  // A changed destination remains a turn instruction, not angular momentum.
  const pace=Math.abs(rawPace)<(tracking?speed*1.75:.25)?limit(rawPace,speed):0;
  for(let i=0;i<steps;i++){
    const desiredVelocity=limit((target-angle)*(relocating?1.8:2.5)+pace,speed);
    const desiredAcceleration=limit((desiredVelocity-velocity)*(relocating?8:5),accelerationLimit);
    const nextAcceleration=acceleration+limit(desiredAcceleration-acceleration,jerkLimit*step);
    const nextVelocity=velocity+(acceleration+nextAcceleration)*step/2;
    angle+=(velocity+nextVelocity)*step/2;velocity=nextVelocity;acceleration=nextAcceleration;
  }
  return {heading:angle,velocity,acceleration,target,now,relocating};
}
