/** The Keepsake sheet's icon set (assets/keepsake/sheet-icons.svg): loaded
 * once and placed in the page, so every sheet can use <use href="#i-…">. */
const ID='filament-flight';
/** The module's version (for cache-busting what it fetches). */
export const moduleVersion=()=>{try{return globalThis.game?.modules?.get?.(ID)?.version??'';}catch{return '';}};
export const moduleRoute=path=>{try{return globalThis.foundry?.utils?.getRoute?.(`modules/${ID}/${path}`)??`/modules/${ID}/${path}`;}catch{return `/modules/${ID}/${path}`;}};
let loading=null,text=null;
export function loadSprite(){
  return loading??=fetch(`${moduleRoute('assets/keepsake/sheet-icons.svg')}?v=${encodeURIComponent(moduleVersion())}`)
    .then(r=>{if(!r.ok)throw new Error(`Keepsake sheet icons missing (${r.status})`);return r.text();})
    .then(t=>{text=t;return t;}).catch(e=>{loading=null;console.warn('Yvaelle’s Toolbox | Keepsake sheet icons:',e);return '';});
}
/** Put the sprite into a document (or shadow root) once. */
export async function ensureSprite(target=globalThis.document?.body){
  if(!target)return false;
  const doc=target.ownerDocument??target;
  if((target.querySelector?.('#ffks-sprite'))||(target===doc.body&&doc.getElementById?.('ffks-sprite')))return true;
  const t=text??await loadSprite();if(!t)return false;
  if(target.querySelector?.('#ffks-sprite'))return true;
  const holder=doc.createElement('div');holder.id='ffks-sprite';holder.setAttribute('aria-hidden','true');
  holder.style.cssText='position:absolute;width:0;height:0;overflow:hidden';holder.innerHTML=t;
  target.append(holder);return true;
}
export const spriteText=()=>text;
/** An icon element (stroke icons take the text colour). */
export function icon(doc,id,cls=''){
  const ns='http://www.w3.org/2000/svg',svg=doc.createElementNS(ns,'svg'),use=doc.createElementNS(ns,'use');
  svg.setAttribute('class',`ffks-ic ${cls}`.trim());svg.setAttribute('aria-hidden','true');use.setAttribute('href',`#i-${id}`);svg.append(use);return svg;
}
export const iconHTML=(id,cls='')=>`<svg class="ffks-ic ${cls}" aria-hidden="true"><use href="#i-${id}"></use></svg>`;
