/** Keepsake sheet: the sheet answers what she does (beta.34).
 *
 * PF2e redraws the whole sheet after almost every click (a quantity, an
 * invest, an equip, a pip), so nothing survives to animate. Each redraw is
 * compared with the last one instead, and only what changed moves:
 *  - a quantity that changed bumps; a control that switched (invest, equip,
 *    carry, toggles) pops; a pip that came on or went off pops;
 *  - a new row slides in; when rows come or go, the ones that moved glide to
 *    their new places (transform only, so it costs nothing to lay out);
 *  - PF2e's own expand/collapse of a row's description runs at 0.2s here
 *    instead of 0.4s.
 * All of it is 120-250ms, in her palette, and off with reduced motion. */

const memo=new WeakMap();   // app -> {rows:Map(key -> signature), tops:Map(key -> offsetTop), pips:Map}
const reduced=root=>{
  let r=false;try{r=!!game.settings.get('filament-flight','reducedMotion');}catch{}
  return r||!!root.ownerDocument.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
};
const keyOf=li=>{const id=li.dataset.itemId??li.dataset.subitemId??null;return id?`${li.closest('.tab[data-tab]')?.dataset.tab??''}:${li.dataset.subitemId?'s':''}${id}`:null;};
const sigOf=li=>{
  const d=li.querySelector(':scope > .data')??li;
  const q=d.querySelector(':scope > .quantity > span:not(a)')?.textContent?.trim()??'';
  const c=[...(d.querySelector(':scope > .item-controls')?.children??[])].map(x=>x.className).join('|');
  return {q,c};
};
const rowsOf=root=>root.querySelectorAll('.sheet-content > .tab li[data-item-id], .sheet-content > .tab li[data-subitem-id]');
const shownRowsOf=root=>root.querySelectorAll('.sheet-content > .tab.active li[data-item-id], .sheet-content > .tab.active li[data-subitem-id]');

/** Before the new look settles: mark what changed since the last redraw (CSS plays it once). */
export function markChanges(app,root){
  if(!root||reduced(root))return;
  const m=memo.get(app);
  const rows=new Map(),pips=new Map();
  for(const li of rowsOf(root)){const k=keyOf(li);if(k)rows.set(k,{li,...sigOf(li)});}
  for(const t of root.querySelectorAll('[data-condition] .pips, .ffks-track .pips, [data-resource] .pips, .pips[data-resource]')){
    const k=t.closest('[data-condition]')?.dataset.condition??t.closest('[data-resource]')?.dataset.resource??null;if(!k)continue;
    pips.set(k,[...t.children].map(i=>i.classList.contains('on')||/\bfa-solid\b/.test(i.className)));
  }
  if(m){
    for(const [k,r] of rows){
      const was=m.rows.get(k);
      if(!was){if(m.rows.size){r.li.classList.add('ffks-new');if(!r.li.querySelector(':scope > .data'))r.li.classList.add('ffks-nodata');}continue;}
      if(was.q!==r.q)r.li.querySelector(':scope > .data > .quantity > span:not(a)')?.classList.add('ffks-bump');
      if(was.c!==r.c){
        const now=r.c.split('|'),then=was.c.split('|'),ctl=[...(r.li.querySelector(':scope > .data > .item-controls')?.children??[])];
        now.forEach((cls,i)=>{if(cls!==then[i])ctl[i]?.classList.add('ffks-pop');});
      }
    }
    for(const [k,on] of pips){
      const was=m.pips.get(k);if(!was)continue;
      const els=[...(root.querySelector(`[data-condition="${k}"] .pips, [data-resource="${k}"] .pips, .pips[data-resource="${k}"]`)?.children??[])];
      on.forEach((v,i)=>{if(v!==was[i])els[i]?.classList.add(v?'ffks-pop':'ffks-unpop');});
    }
  }
  memo.set(app,{rows:new Map([...rows].map(([k,r])=>[k,{q:r.q,c:r.c}])),pips,tops:m?.tops??new Map(),changed:!!m&&(m.rows.size!==rows.size||[...rows.keys()].some(k=>!m.rows.has(k)))});
}

/** In the frame, once the new layout exists: rows that moved because rows came or went glide over. */
export function glideRows(app,root){
  const m=memo.get(app);if(!m||!root)return;
  const tops=new Map();
  for(const li of shownRowsOf(root)){const k=keyOf(li);if(k)tops.set(k,li.offsetTop);}
  if(m.changed&&!reduced(root)){
    for(const li of shownRowsOf(root)){
      const k=keyOf(li),was=m.tops.get(k),now=tops.get(k);
      if(was==null||now==null)continue;const dy=was-now;
      if(Math.abs(dy)<1||Math.abs(dy)>240)continue;
      li.animate([{transform:`translateY(${dy}px)`},{transform:'none'}],{duration:220,easing:'cubic-bezier(.2,.7,.2,1)'});
    }
  }
  m.tops=tops;m.changed=false;
}

/** PF2e animates a row's description open and shut with GSAP over 0.4s: on the Keepsake sheet, 0.2s. */
let patched=false;
export function quickSummaries(){
  const g=globalThis.gsap;if(patched||!g?.to||!g?.fromTo)return;patched=true;
  const ours=t=>{const e=t?.jquery?t[0]:t;return e instanceof Element&&e.classList.contains('item-summary')&&!!e.closest('.ffks');};
  // (the same vars object, only quicker: GSAP and PF2e keep their own references to it)
  const tune=v=>{if(v&&typeof v==='object'){v.duration=Math.min(Number(v.duration)||.4,.2);v.ease??='power2.out';}return v;};
  const to=g.to.bind(g),fromTo=g.fromTo.bind(g);
  g.to=function(t,vars,...rest){try{if(ours(t))vars=tune(vars);}catch{}return to(t,vars,...rest);};
  g.fromTo=function(t,from,vars,...rest){try{if(ours(t))vars=tune(vars);}catch{}return fromTo(t,from,vars,...rest);};
}
