/** Keepsake sheet: the window's own chrome.
 *
 *  - Every header button (PF2e's, Foundry's and the ones other modules add)
 *    becomes a small round Keepsake icon with its name as a tooltip. The
 *    button itself stays the same element, so its click (and anything else
 *    a module hung on it) still works; only what it shows changes.
 *  - The title always keeps room to drag the window by, and a grip in the
 *    bottom right corner resizes it above the frame's art. Both work by
 *    themselves (Foundry's own handle stays, under the grip), so the window
 *    moves and resizes whatever the header holds.
 * Undone by undoChrome() when the Keepsake sheet is switched off. */

const NS='http://www.w3.org/2000/svg';
/** Icons, drawn on a 20 unit grid in one line weight. */
const P={
  dice:'<path d="M10 2.6l6.4 3.7v7.4L10 17.4l-6.4-3.7V6.3z"/><path d="M10 5.6l3.9 6.8H6.1z"/><path d="M3.6 6.3 10 5.6l6.4.7M6.1 12.4l-2.5 1.3M13.9 12.4l2.5 1.3M10 17.4v-0"/>',
  mask:'<path d="M3.2 6.2c3.3-1.7 10.3-1.7 13.6 0 0 5.2-2.6 9.3-6.8 9.8C5.8 15.5 3.2 11.4 3.2 6.2z"/><path d="M6.3 9c.9-.8 2.1-.8 2.9 0M10.8 9c.9-.8 2.1-.8 2.9 0M8.6 12.6c.9.5 1.9.5 2.8 0"/>',
  share:'<path d="M9 5.5H4.2v10.3h10.3V11"/><path d="M11.6 3.6h4.8v4.8M16.4 3.6l-6.6 6.6"/>',
  sliders:'<path d="M3.5 6.5h13M3.5 13.5h13"/><circle cx="7.2" cy="6.5" r="1.9" class="k"/><circle cx="12.8" cy="13.5" r="1.9" class="k"/>',
  gallery:'<path d="M6 4.2h10.3v8.6"/><rect x="3.7" y="6.8" width="10" height="9" rx=".6"/><path d="M4.6 14.6l2.8-3.2 2 2 1.5-1.6 2 2.4"/><circle cx="10.9" cy="9.3" r=".9" class="f"/>',
  halo:'<ellipse cx="10" cy="5.6" rx="5.6" ry="2"/><path d="M10 9.6l1.1 2.6 2.6 1.1-2.6 1.1L10 17l-1.1-2.6-2.6-1.1 2.6-1.1z"/><path d="M15.6 10.5v2.4M14.4 11.7h2.4"/>',
  sound:'<path d="M3.4 8h2.9l3.9-3.4v10.8L6.3 12H3.4z"/><path d="M13 7.4c1.2 1.5 1.2 3.7 0 5.2M15.3 5.4c2.3 2.7 2.3 6.5 0 9.2"/>',
  token:'<circle cx="10" cy="10" r="6.6"/><circle cx="10" cy="8.3" r="2"/><path d="M6.6 14.6c.7-1.9 1.9-2.9 3.4-2.9s2.7 1 3.4 2.9"/>',
  proto:'<circle cx="10" cy="10" r="7" stroke-dasharray="2.2 1.8"/><circle cx="10" cy="8.4" r="1.9"/><path d="M6.9 14.3c.7-1.8 1.8-2.7 3.1-2.7s2.4.9 3.1 2.7"/>',
  sheet:'<path d="M5 2.8h6.8l3.3 3.3v11.1H5z"/><path d="M11.6 2.8v3.5h3.5M7.4 9.8h5.2M7.4 12.6h5.2M7.4 15h3"/>',
  creature:'<circle cx="8" cy="6.8" r="2.6"/><path d="M3.2 16.4c.6-3.1 2.5-4.7 4.8-4.7.9 0 1.7.2 2.4.6"/><circle cx="14.3" cy="13.7" r="1.7"/><path d="M14.3 10.6v1.4M14.3 15.4v1.4M11.2 13.7h1.4M16 13.7h1.4M12.1 11.5l1 1M15.5 14.9l1 1M12.1 15.9l1-1M15.5 12.5l1-1"/>',
  close:'<path d="M5.6 5.6l8.8 8.8M14.4 5.6l-8.8 8.8"/>',
  id:'<path d="M8 3.6 6.4 16.4M13.6 3.6 12 16.4M4.2 7.6h12.4M3.4 12.4h12.4"/>',
  eye:'<path d="M2.4 10S5.3 4.9 10 4.9 17.6 10 17.6 10 14.7 15.1 10 15.1 2.4 10 2.4 10z"/><circle cx="10" cy="10" r="2.3"/>',
  art:'<rect x="3.4" y="3.4" width="13.2" height="13.2" rx="1"/><path d="M4.6 14.8l3.6-4 2.6 2.6 2-2 2.6 3"/><circle cx="12.9" cy="7.2" r="1.3"/>',
  import:'<path d="M10 3.4v8.8M6.6 8.9 10 12.3l3.4-3.4"/><path d="M3.8 13.4v3.2h12.4v-3.2"/>',
  bookmark:'<path d="M5.6 3.2h8.8v13.6L10 13.4l-4.4 3.4z"/>',
  bolt:'<path d="M11.2 2.8 5.2 11h4.2l-1 6.2 6-8.2h-4.2z"/>',
  sync:'<path d="M15.6 8.2A6 6 0 0 0 5 6.2M4.4 11.8A6 6 0 0 0 15 13.8"/><path d="M4.6 3.4v3h3M15.4 16.6v-3h-3"/>',
  user:'<circle cx="10" cy="7" r="3"/><path d="M4.2 16.6c.8-3.4 3-5.1 5.8-5.1s5 1.7 5.8 5.1"/>',
  lock:'<rect x="4.6" y="9" width="10.8" height="8" rx="1.6"/><path d="M6.9 9V6.6a3.1 3.1 0 0 1 6.2 0V9"/><path d="M10 12.2v1.8"/>',
  unlock:'<rect x="4.6" y="9" width="10.8" height="8" rx="1.6"/><path d="M6.9 9V6.6a3.1 3.1 0 0 1 6-1.1"/><path d="M10 12.2v1.8"/>'
};
/** Which icon a button gets: by its class first, then by its label (other modules' classes vary). */
const BY_CLASS={close:'close','configure-sheet':'sheet','configure-token':'token','configure-creature':'creature','document-id-link':'id','share-image':'eye',
  'pf2e-rpg-numbers':'dice',visage:'mask','share-media':'share',gallery:'gallery','effects-halo':'halo',sounds:'sound','import':'import','export':'import'};
const BY_LABEL=[[/rpg|numbers|#s\b/i,'dice'],[/visage|mask|disguise/i,'mask'],[/share/i,'share'],[/galler/i,'gallery'],[/halo|aura/i,'halo'],
  [/sound|audio|music|voice/i,'sound'],[/prototype/i,'proto'],[/^token$|token\s*(art|image)?$/i,'token'],[/^sheet$/i,'sheet'],[/^close$/i,'close'],
  [/^configure$|settings|config/i,'sliders'],[/art|image|portrait|picture/i,'art'],[/import|export|download/i,'import'],[/journal|bio|notes?/i,'bookmark'],
  [/sync|refresh|reload/i,'sync'],[/effect|spell|macro|action/i,'bolt'],[/actor|character|player/i,'user']];
const CORE=['ffks-lock','close','configure-sheet','configure-token','configure-creature','document-id-link','share-image','ffks-swap'];

const orig=new WeakMap(),banded=new WeakSet();
const textOf=a=>[...a.childNodes].filter(n=>n.nodeType===3||(n.nodeType===1&&n.tagName!=='I'&&!n.classList?.contains('ffks-mini-ic'))).map(n=>n.textContent).join(' ').replace(/\s+/g,' ').trim();
function iconKey(a,label){
  for(const c of a.classList)if(BY_CLASS[c])return BY_CLASS[c];
  for(const [re,k] of BY_LABEL)if(re.test(label))return k;
  return null;
}
function svgIcon(doc,key){
  const s=doc.createElementNS(NS,'svg');s.setAttribute('viewBox','0 0 20 20');s.setAttribute('aria-hidden','true');s.setAttribute('class','ffks-mini-ic');
  s.innerHTML=P[key];return s;
}

/** Her header's buttons as mini icons. Cheap to run on every render (done ones are skipped). */
export function miniButtons(root){
  const head=root?.querySelector?.(':scope > .window-header');if(!head)return;
  const doc=root.ownerDocument;
  for(const a of head.querySelectorAll(':scope > .header-button, :scope > .header-control, :scope > a.control, :scope > button.header-control')){
    if(a.dataset.ffksMini)continue;
    const label=textOf(a)||a.getAttribute('aria-label')||a.dataset.tooltip||a.title||'';
    orig.set(a,{nodes:[...a.childNodes],tooltip:a.getAttribute('data-tooltip'),aria:a.getAttribute('aria-label'),dir:a.getAttribute('data-tooltip-direction')});
    const key=iconKey(a,label),fa=a.querySelector(':scope > i[class*="fa"]');
    const lab=doc.createElement('span');lab.className='ffks-mini-label';lab.textContent=label;
    let ic;
    if(key)ic=svgIcon(doc,key);
    else if(fa&&/\bfa-[a-z]/.test(fa.className)){ic=fa.cloneNode(true);ic.classList.add('ffks-mini-ic','fa-fw');}
    else{ic=doc.createElement('span');ic.className='ffks-mini-ic ffks-mini-init';ic.textContent=(label.match(/[\p{L}\p{N}#]/u)?.[0]??'•').toUpperCase();}
    a.replaceChildren(ic,lab);
    a.dataset.ffksMini=key??(fa?'fa':'initial');
    a.classList.add('ffks-mini',CORE.some(c=>a.classList.contains(c))?'ffks-mini-core':'ffks-mini-mod');
    if(label){if(!a.getAttribute('data-tooltip'))a.setAttribute('data-tooltip',label);if(!a.getAttribute('aria-label'))a.setAttribute('aria-label',label);
      if(!a.getAttribute('data-tooltip-direction'))a.setAttribute('data-tooltip-direction','DOWN');}
    if(a.tagName==='A'&&!a.hasAttribute('role'))a.setAttribute('role','button');
    if(!a.hasAttribute('tabindex')&&a.tagName==='A')a.setAttribute('tabindex','0');
  }
}

/** The grip and the free band at the top: move and resize, whatever Foundry's own handles do. */
export function grips(app,root,min){
  if(!root||root.querySelector(':scope > .ffks-grip'))return;
  const doc=root.ownerDocument,W=doc.defaultView??globalThis;
  const grip=doc.createElement('div');grip.className='ffks-grip';grip.setAttribute('aria-hidden','true');grip.title='Drag to resize';
  grip.innerHTML='<svg viewBox="0 0 20 20"><path d="M17 7.5 7.5 17M17 12.2 12.2 17M17 16.4l-.6.6"/></svg>';
  root.append(grip);
  const follow=(e,move)=>{
    e.preventDefault();e.stopPropagation();
    const pos={...(app.position??{})},x0=e.clientX,y0=e.clientY;let raf=0,last=null;
    const scale=Number(pos.scale)||1;
    try{grip.setPointerCapture?.(e.pointerId);}catch{}
    root.classList.add(move?'ffks-moving':'ffks-resizing');
    const step=()=>{raf=0;if(!last)return;const dx=(last.clientX-x0)/(move?1:scale),dy=(last.clientY-y0)/(move?1:scale);
      try{
        if(move)app.setPosition?.({left:Math.round(pos.left+dx),top:Math.max(0,Math.round(pos.top+dy))});
        else app.setPosition?.({width:Math.max(min.width,Math.round(pos.width+dx)),height:Math.max(min.height,Math.round(pos.height+dy))});
      }catch{}};
    const mv=ev=>{last=ev;if(!raf)raf=W.requestAnimationFrame(step);};
    const up=()=>{W.removeEventListener('pointermove',mv);W.removeEventListener('pointerup',up);W.removeEventListener('pointercancel',up);
      if(raf){W.cancelAnimationFrame(raf);step();}root.classList.remove('ffks-moving','ffks-resizing');};
    W.addEventListener('pointermove',mv);W.addEventListener('pointerup',up);W.addEventListener('pointercancel',up);
  };
  grip.addEventListener('pointerdown',e=>{if(e.button===0)follow(e,false);});
  // the band above the header (the frame's top edge) moves the window too
  if(banded.has(root))return;banded.add(root);
  root.addEventListener('pointerdown',e=>{
    if(e.button!==0||e.target!==root||!root.classList.contains('ffks'))return;
    const r=root.getBoundingClientRect(),h=root.querySelector(':scope > .window-header')?.getBoundingClientRect();
    if(e.clientY-r.top<=Math.max(24,(h?.bottom??r.top+56)-r.top))follow(e,true);
  });
}

/** Back to the plain buttons and handles. */
export function undoChrome(root){
  if(!root)return;
  root.querySelector(':scope > .ffks-grip')?.remove();root.querySelector(':scope > .window-header > .ffks-lock')?.remove();root.classList.remove('ffks-locked');
  for(const a of root.querySelectorAll(':scope > .window-header .ffks-mini')){
    const o=orig.get(a);if(o)a.replaceChildren(...o.nodes);
    for(const [k,v] of [['data-tooltip',o?.tooltip],['aria-label',o?.aria],['data-tooltip-direction',o?.dir]]){if(v==null)a.removeAttribute(k);else a.setAttribute(k,v);}
    a.classList.remove('ffks-mini','ffks-mini-core','ffks-mini-mod');delete a.dataset.ffksMini;
  }
}

/** While she scrolls, clicks or types in the sheet its ambient loops hold
 * still for a moment (CSS: .ffks-busy), so every frame goes to what she is doing. */
const busied=new WeakSet();
export function busyWatch(root){
  if(!root||busied.has(root))return;busied.add(root);
  const W=root.ownerDocument.defaultView??globalThis;let t=0;
  const on=()=>{if(!root.classList.contains('ffks-busy'))root.classList.add('ffks-busy');W.clearTimeout(t);t=W.setTimeout(()=>root.classList.remove('ffks-busy'),1400);};
  // (scrolling and typing only: a click doesn't restyle the window)
  for(const e of ['wheel','keydown'])root.addEventListener(e,on,{passive:true,capture:true});
  root.addEventListener('scroll',on,{passive:true,capture:true});
}

/** The title bar's lock: on, the sheet can't be resized and always opens at the size and place it
 * was locked at (kept for this user on this browser, across sessions). */
export function lockButton(root,{locked,onToggle}){
  const head=root?.querySelector?.(':scope > .window-header');if(!head)return;
  let b=head.querySelector(':scope > .ffks-lock');
  const tip=locked?'Size locked: it opens at this size and place. Click to unlock':'Lock the size (and where it opens)';
  if(!b){
    const doc=root.ownerDocument;b=doc.createElement('a');b.className='header-button control ffks-lock ffks-mini ffks-mini-core';b.dataset.ffksMini='lock';
    b.setAttribute('role','button');b.setAttribute('tabindex','0');b.setAttribute('data-tooltip-direction','DOWN');
    b.append(svgIcon(doc,'lock'));
    b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();b.__toggle?.();});
    b.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();b.__toggle?.();}});
    b.addEventListener('pointerdown',e=>e.stopPropagation());
    const close=head.querySelector(':scope > .header-button.close');close?close.before(b):head.append(b);
  }
  b.__toggle=onToggle;
  b.classList.toggle('on',!!locked);root.classList.toggle('ffks-locked',!!locked);
  b.setAttribute('data-tooltip',tip);b.setAttribute('aria-label',tip);b.setAttribute('aria-pressed',String(!!locked));
  b.querySelector('svg.ffks-mini-ic').innerHTML=P[locked?'lock':'unlock'];
}
