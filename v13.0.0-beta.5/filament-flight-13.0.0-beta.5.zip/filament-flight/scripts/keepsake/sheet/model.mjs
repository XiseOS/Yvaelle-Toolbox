/** Keepsake sheet (v10 beta.27): the pure parts. Which fields each tab can
 * hide, how the remaining ones re-pack, the dying stage, her portrait stage
 * and the rank letters. No Foundry globals here; everything comes in as
 * arguments, so these can be checked on their own. */

export const SHEET_MODES=Object.freeze(['off','me','everyone']);

/** PF2e's primary tabs (their data-tab ids), with the Keepsake names and icons. */
export const SHEET_TABS=Object.freeze([
  ['character','Character','tab-character'],['actions','Actions','tab-actions'],['inventory','Inventory','tab-inventory'],
  ['spellcasting','Spells','tab-spells'],['crafting','Crafting','tab-crafting'],['proficiencies','Proficiencies','tab-proficiencies'],
  ['feats','Feats','tab-feats'],['effects','Effects','tab-effects'],['biography','Biography','tab-biography'],['pfs','Society','tab-pfs']
]);

/** What each tab can switch off: [key, label, icon]. The Character tab can't be hidden itself. */
export const SHEET_FIELDS=Object.freeze({
  character:[['ancestry','Ancestry','ft-ancestry'],['heritage','Heritage','ft-heritage'],['background','Background','ft-background'],['class','Class','ft-class'],
    ['deity','Deity','d-holy'],['archetype','Archetypes','ft-archetype'],['attributes','Attributes','attr-str'],['speeds','Movement','st-speed'],
    ['languages','Languages','st-languages'],['traits','Traits and size','ft-heritage'],['gender','Gender & pronouns','b-attitude'],['age','Age','ui-hourglass'],
    ['ethnicity','Ethnicity','ft-ancestry'],['nationality','Nationality','b-orgs']],
  actions:[['toggles','Options','ui-sparkle'],['strikes','Strikes','sec-weapons'],['handling','Draw, stow and grip','ui-use'],['ammo','Ammunition','it-arrows'],
    ['actionlist','Actions','sub-encounter'],['reactions','Reactions','sub-encounter'],['free','Free actions','ui-use']],
  inventory:[['coins','Coins','coin-gp'],['wealth','Total wealth','sec-treasure'],['search','Search','ui-search'],['bulk','Bulk','b-weight'],
    ['invested','Invested','ui-gem'],['pricecol','Price column','coin-gp'],['bulkcol','Bulk column','b-weight'],['emptysec','Empty sections','sec-containers']],
  spellcasting:[['cantrips','Cantrips','s-cantrip'],['focuspool','Focus pool','s-focus'],['rituals','Rituals','s-ritual'],['emptyranks','Empty ranks','s-slot']],
  crafting:[['abilities','Daily crafting','ui-reload'],['formulas','Known formulas','ui-book']],
  proficiencies:[['lores','Lores','sk-lore'],['attacks','Attacks','sec-weapons'],['defences','Defences','st-ac'],['spellprof','Spellcasting','tab-spells'],['classdcs','Class DCs','st-classdc']],
  feats:[['features','Class features','ft-feature'],['bonusfeats','Bonus feats','ft-bonus'],['emptyslots','Empty slots','ui-create']],
  effects:[['palette','Add-condition tiles','ui-plus'],['conditions','Conditions','c-frightened'],['effectlist','Effects','tab-effects'],['intercessions','Divine intercessions','d-holy']],
  biography:[['appearance','Appearance','b-appearance'],['backstory','Backstory','b-backstory'],['birthplace','Birthplace','b-birthplace'],['height','Height','b-height'],
    ['weight','Weight','b-weight'],['attitude','Attitude','b-attitude'],['beliefs','Beliefs','b-beliefs'],['likes','Likes','b-likes'],['dislikes','Dislikes','b-dislikes'],
    ['catchphrases','Catchphrases','b-quote'],['edicts','Edicts','b-edicts'],['anathema','Anathema','b-anathema'],['allies','Allies','b-allies'],
    ['enemies','Enemies','b-enemies'],['organizations','Organizations','b-orgs'],['campaign','Campaign notes','b-notes']],
  pfs:[]
});

/** The sidebar's sections that can be switched off. */
/** Fields in her header that can be hidden (beta.34). */
export const HEAD_FIELDS=Object.freeze([['xp','XP and XP bar']]);
export const SIDE_FIELDS=Object.freeze([['temp','Temporary HP'],['dying','Dying and wounded'],['stamina','Stamina'],['shield','Shield'],['saves','Saves'],
  ['perception','Perception'],['senses','Senses'],['initiative','Initiative'],['resources','Resources'],['iwr','Resist · weak · immune']]);

/** Biography fields that take the full width. */
export const WIDE_BIO=Object.freeze(['appearance','backstory','campaign']);

/** Keys are "tab.field", "side.field" or "tab.<tabId>". */
export const fieldKey=(scope,key)=>`${scope}.${key}`;
export function isHidden(hidden,scope,key){return !!hidden?.[fieldKey(scope,key)];}
/** Toggle one or several keys; returns a new object (never mutates). */
export function toggleHidden(hidden,keys){
  const out={...(hidden&&typeof hidden==='object'?hidden:{})};
  for(const k of Array.isArray(keys)?keys:[keys]){if(out[k])delete out[k];else out[k]=1;}
  return out;
}
/** Only real keys survive (the stored object is user data). */
export function cleanHidden(hidden){
  const ok=new Set();
  for(const [tab,list] of Object.entries(SHEET_FIELDS))for(const [k] of list)ok.add(fieldKey(tab,k));
  for(const [k] of SIDE_FIELDS)ok.add(fieldKey('side',k));
  for(const [k] of HEAD_FIELDS)ok.add(fieldKey('head',k));
  for(const [t] of SHEET_TABS)if(t!=='character')ok.add(fieldKey('tab',t));
  const out={};for(const [k,v] of Object.entries(hidden&&typeof hidden==='object'?hidden:{}))if(v&&ok.has(k))out[k]=1;
  return out;
}

/** Identity tiles on a six-column grid: rows of three; a short last row
 * stretches to fill it, and four make two pairs. spanN is the narrow
 * layout's (two per row, a lone last one takes the row). */
export function identitySpans(n){
  n=Math.max(0,n|0);const spans=new Array(n).fill(2),r=n%3;
  if(n===4)spans.fill(3);
  else if(r===1&&n>1){for(let i=n-4;i<n;i++)spans[i]=3;}
  else if(r===1)spans[n-1]=6;
  else if(r===2){spans[n-2]=3;spans[n-1]=3;}
  return spans.map((span,i)=>({span,spanN:n%2===1&&i===n-1?6:3}));
}
/** Equal shares of a twelve-column row; narrow: pairs, a lone last one takes the row. */
export function shareSpans(n){
  n=Math.max(0,n|0);if(!n)return [];
  const span=n<=4?12/n:n<=6?4:3;
  return Array.from({length:n},(_,i)=>({span,spanN:n%2===1&&i===n-1?12:6}));
}
/** Biography: wide fields take the row; short ones pair up, and a short one
 * left alone between wide ones (or at the end) stretches across. */
export function bioSpans(keys,wide=WIDE_BIO){
  const out=keys.map(k=>({key:k,wide:wide.includes(k),span:wide.includes(k)?2:1}));
  let run=[];const close=()=>{if(run.length%2===1)run[run.length-1].span=2;run=[];};
  for(const b of out){if(b.wide)close();else run.push(b);}close();
  return out;
}

/** Dying: still at 0; each step closer to death (doomed counts) beats weaker. */
export function dyingStage({dying=0,doomed=0,max=4}={}){
  dying=Number(dying)||0;doomed=Number(doomed)||0;max=Number(max)||4;
  const dmax=Math.max(1,max-doomed);
  if(dying<=0)return '';
  if(dying>=dmax)return 'dyx';
  return 'dy'+Math.max(1,Math.min(3,4-(dmax-dying)));
}

/** PF2e ranks 0..4 as one letter. */
export const RANK_LETTERS=Object.freeze(['U','T','E','M','L']);
export const rankLetter=r=>RANK_LETTERS[Math.max(0,Math.min(4,Number(r)||0))];

/** Her portrait's HP stages (as in the HUD), thresholds in percent. */
export const PORTRAIT_STAGES=Object.freeze(['healthy','light','wounded','severe','critical','unconscious']);
export const PORTRAIT_STAGE_NAMES=Object.freeze({healthy:'Healthy',light:'Lightly hurt',wounded:'Wounded',severe:'Badly hurt',critical:'Critical',unconscious:'Unconscious'});
export const DEFAULT_THRESHOLDS=Object.freeze({light:70,severe:35,critical:15});
export function cleanThresholds(th){
  const n=(v,d)=>{v=Number(v);return Number.isFinite(v)?v:d;};
  let light=Math.max(2,Math.min(99,n(th?.light,70))),severe=Math.max(1,Math.min(light-1,n(th?.severe,35))),critical=Math.max(0,Math.min(severe-1,n(th?.critical,15)));
  return {light,severe,critical};
}
export function portraitStage({hp=null,max=null,unconscious=false}={},th=DEFAULT_THRESHOLDS){
  th=cleanThresholds(th);
  if(unconscious)return 'unconscious';
  if(!Number.isFinite(hp)||!Number.isFinite(max)||max<=0)return 'healthy';
  if(hp<=0)return 'unconscious';
  const p=hp/max*100,mid=(th.light+th.severe)/2;
  return p>th.light?'healthy':p>mid?'light':p>th.severe?'wounded':p>th.critical?'severe':'critical';
}
/** An empty stage borrows the nearest healthier one, else the nearest worse one. */
export function resolveStage(slots,stage){
  const i=PORTRAIT_STAGES.indexOf(stage);if(i<0)return null;
  for(let j=i;j>=0;j--)if(slots?.[PORTRAIT_STAGES[j]])return PORTRAIT_STAGES[j];
  for(let j=i+1;j<PORTRAIT_STAGES.length;j++)if(slots?.[PORTRAIT_STAGES[j]])return PORTRAIT_STAGES[j];
  return null;
}
/** The portrait settings stored on her actor, cleaned. */
export const PORTRAIT_MODES=Object.freeze(['keepsake','one','stages']);
export const PORTRAIT_SET_IDS=Object.freeze(['original','resolute','pained']);
export function cleanPortrait(raw){
  const r=raw&&typeof raw==='object'?raw:{},str=v=>typeof v==='string'&&v.length<2048?v:'';
  const stages={};for(const k of PORTRAIT_STAGES){const v=str(r.stages?.[k]);if(v)stages[k]=v;}
  const num=(v,d,a,b)=>{v=Number(v);return Number.isFinite(v)?Math.max(a,Math.min(b,v)):d;};
  return {mode:PORTRAIT_MODES.includes(r.mode)?r.mode:'keepsake',set:PORTRAIT_SET_IDS.includes(r.set)?r.set:'original',
    one:{src:str(r.one?.src),fx:num(r.one?.fx,50,0,100),fy:num(r.one?.fy,20,0,100),zoom:num(r.one?.zoom,100,100,200),mood:r.one?.mood!==false},
    stages,th:cleanThresholds(r.th),sheet:r.sheet!==false,hud:r.hud!==false};
}
/** The module's Keepsake art for a stage and expression set. */
export function keepsakeArt(stage,set='original',root='modules/filament-flight/assets/hud/'){
  if(stage==='unconscious')return `${root}v611/portrait-unconscious.webp`;
  if(set==='original'||stage==='healthy')return `${root}v611/portrait-${stage}.webp`;
  return `${root}v62/${set}-${stage}.webp`;
}
/** Which image her portrait shows, and how it is framed. */
export function portraitView(cfg,state,{actorImg='',root}={}){
  const c=cleanPortrait(cfg),stage=portraitStage(state,c.th);
  if(c.mode==='one'){const src=c.one.src||actorImg;return {mode:'one',stage,src,pos:`${c.one.fx}% ${c.one.fy}%`,zoom:c.one.zoom/100,mood:c.one.mood};}
  if(c.mode==='stages'){const use=resolveStage(c.stages,stage);
    if(use)return {mode:'stages',stage,src:c.stages[use],pos:'50% 20%',zoom:1,mood:use!==stage,borrowed:use!==stage?use:null};
    return {mode:'stages',stage,src:actorImg,pos:'50% 20%',zoom:1,mood:true,borrowed:null,empty:true};}
  return {mode:'keepsake',stage,src:keepsakeArt(stage,c.set,root),pos:'62% 18%',zoom:1,mood:false,keepsake:true};
}

/** Condition chips for the header: the conditions on her, in PF2e's own order. */
export const VALUED_CONDITIONS=Object.freeze(['clumsy','doomed','drained','dying','enfeebled','frightened','sickened','slowed','stunned','stupefied','wounded']);
export const PALETTE_CONDITIONS=Object.freeze(['frightened','fleeing','sickened','confused','stunned','slowed','quickened','fatigued','drained','doomed',
  'wounded','dying','unconscious','paralyzed','petrified','prone','off-guard','grabbed','blinded','dazzled']);
export const CONDITION_ICONS=Object.freeze({frightened:'c-frightened',fleeing:'c-fleeing',sickened:'c-sickened',confused:'c-confused',stunned:'c-stunned',
  slowed:'c-slowed',quickened:'c-quickened',fatigued:'c-fatigued',drained:'c-drained',doomed:'c-doomed',wounded:'c-wounded',dying:'c-dying',
  unconscious:'c-unconscious',paralyzed:'c-paralyzed',petrified:'c-petrified',prone:'c-prone','off-guard':'c-offguard',grabbed:'c-grabbed',
  blinded:'c-blinded',dazzled:'c-dazzled',deafened:'c-deafened',clumsy:'c-clumsy',enfeebled:'c-enfeebled',stupefied:'c-stupefied',
  restrained:'c-restrained',immobilized:'c-immobilized',hidden:'c-hidden',invisible:'c-invisible',concealed:'c-concealed',undetected:'c-hidden',
  observed:'c-observed',unnoticed:'c-hidden',controlled:'c-controlled',encumbered:'b-weight',broken:'c-broken',friendly:'c-friendly',helpful:'c-friendly',
  hostile:'c-hostile',unfriendly:'c-hostile',indifferent:'c-friendly',fascinated:'c-fascinated',persistent:'c-bleed','persistent-damage':'c-bleed',
  'cursebound':'c-doomed','malevolence':'c-doomed'});
export const conditionIcon=slug=>CONDITION_ICONS[slug]??'c-generic';
/** The good ones (green chips). */
export const GOOD_CONDITIONS=Object.freeze(['quickened','friendly','helpful']);

/** A short, friendly tooltip for a header chip. */
export function chipTip(name,value,valued,max){
  if(valued)return `${name} ${value}: click to raise${max?`; past ${max} it ends`:''} · right-click to lower`;
  return `${name}: click or right-click to end`;
}
