/** Hero petals falling (beta.28): keyframes for the Web Animations API.
 *
 * A new Hero Point is one of the Nytheris's own petals (the flower in the top
 * left corner): it tugs, lets go and floats down to its place, and the flower
 * grows it back once it has landed. A spent one lifts as the breeze takes it
 * and floats the whole way down to the bottom, fading only at the end.
 *
 * Both fall like a leaf: lazy side to side swings that slow at each end,
 * rocking into them and turning in the air so you see its edge.
 *
 * Positions are offsets in pixels (y down). No DOM or Foundry globals. */

const TAU=Math.PI*2;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const smooth=t=>t*t*(3-2*t);
const r1=v=>Math.round(v*10)/10,r2=v=>Math.round(v*100)/100,r3=v=>Math.round(v*1000)/1000;

/** A cubic Bézier, sampled by arc length so the petal's speed is ours to set. */
function curve(p0,p1,p2,p3,n=240){
  const at=t=>{const u=1-t,a=u*u*u,b=3*u*u*t,c=3*u*t*t,d=t*t*t;return {x:a*p0.x+b*p1.x+c*p2.x+d*p3.x,y:a*p0.y+b*p1.y+c*p2.y+d*p3.y};};
  const pts=[at(0)],len=[0];
  for(let i=1;i<=n;i++){const p=at(i/n),q=pts[i-1];pts.push(p);len.push(len[i-1]+Math.hypot(p.x-q.x,p.y-q.y));}
  const total=len[n];
  /** point and unit tangent at fraction s (0..1) of the length */
  const point=s=>{
    const L=clamp(s,0,1)*total;let i=1;while(i<n&&len[i]<L)i++;
    const a=pts[i-1],b=pts[i],w=(L-len[i-1])/((len[i]-len[i-1])||1),dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1;
    return {x:lerp(a.x,b.x,w),y:lerp(a.y,b.y,w),tx:dx/d,ty:dy/d};
  };
  return {point,total};
}

/** The sway across the path at fall progress v (0..1): lazy swings, rocking
 * into them and turning in the air (its edge to you as it swoops through). */
function sway(v,{amp,cycles,phase=0,rock=26,turn=60}){
  const env=Math.pow(Math.sin(Math.PI*clamp(v,0,1)),.7),phi=TAU*cycles*v+phase,s=Math.sin(phi),c=Math.cos(phi);
  return {q:amp*env*s,rot:-rock*env*s,ry:turn*env*c,env,s};
}
/** How far along the path it is at v: it hangs at the end of each swing and
 * swoops through the middle (pace sets the slow start and end). */
function progress({cycles,phase=0,pace,hang=.55,n=400}){
  const acc=[0];let sum=0;
  for(let j=1;j<=n;j++){
    const v=(j-.5)/n,env=Math.pow(Math.sin(Math.PI*v),.7),phi=TAU*cycles*v+phase;
    sum+=pace(v)*(1+hang*env*Math.cos(2*phi))/n;acc.push(sum);
  }
  return v=>{const x=clamp(v,0,1)*n,i=Math.min(n-1,Math.floor(x));return lerp(acc[i],acc[i+1],x-i)/sum;};
}

/** One keyframe. Its turning in the air (ry across, rx along) is drawn flat,
 * as the petal narrowing: a small petal turned in 3D is drawn blurred. */
function frame(u,{x,y,rot=0,ry=0,rx=0,scale=1,opacity=1}){
  const sx=scale*Math.cos(ry*Math.PI/180),sy=scale*Math.cos(rx*Math.PI/180);
  return {offset:r3(u),transform:`translate(${r2(x)}px, ${r2(y)}px) rotate(${r2(rot)}deg) scale(${r3(sx)}, ${r3(sy)})`,opacity:r3(opacity)};
}

/** Running total of a profile over 0..1, scaled to end at 1. */
function cumulative(f,n=600){
  const acc=[0];let sum=0;
  for(let j=1;j<=n;j++){sum+=Math.max(0,f((j-.5)/n))/n;acc.push(sum);}
  return v=>{const x=clamp(v,0,1)*n,i=Math.min(n-1,Math.floor(x));return sum?lerp(acc[i],acc[i+1],x-i)/sum:clamp(v,0,1);};
}
const wrap=a=>{a=((a+180)%360+360)%360-180;return a===-180?180:a;};

/** A new Hero Point. One of the Nytheris's own petals tugs on the flower and
 * lets go (flowerPetalCycle, below); this petal takes over right where it is.
 * It drops, then falls like a leaf with the breeze behind it: lazy side to
 * side swings, longer towards its place than back, slow at each end and
 * quick through the middle, rocking into them and turning in the air. The
 * breeze and the swings die away as it nears its place, and it floats down
 * into it, righting itself, at the angle its place is swaying to.
 * x, y: where it lets go (its centre, from the centre of its place), angle:
 * its angle then (0 = tip up), toAngle: the angle it lands at. The element's
 * transform origin is the petal's centre. */
export function petalArrival({x,y,angle=0,toAngle=0,steps=170}){
  const H=Math.max(40,-y),W=Math.abs(x);
  const duration=Math.round(clamp((H+W*.45+60)/62,4.4,6.4)*1000),secs=duration/1000;
  const start=.08,cycles=Math.max(1.25,(1-start)*secs/2.2),amp=clamp(W*.1+H*.12,20,42);
  const a0=wrap(angle),turn=wrap(toAngle-a0);
  // the breeze takes it once it has dropped, and dies away as it nears its place
  const breeze=cumulative(v=>smooth(clamp((v-.06)/.16,0,1))*(1-smooth(clamp((v-.5)/.34,0,1))));
  // the swings grow once it's falling and die away as it settles
  const swing=v=>smooth(clamp((v-start)/.22,0,1))*Math.pow(1-smooth(clamp((v-.66)/.34,0,1)),.9);
  const phase=v=>TAU*cycles*Math.max(0,v-start)/(1-start);
  // it drops as it lets go, then floats down (slowest at the end of each swing) and comes to rest
  const down=cumulative(v=>smooth(clamp(v/.04,0,1))*(1+1.4*(1-smooth(clamp((v-.04)/.12,0,1))))
    *(1+.55*swing(v)*Math.cos(2*phase(v)))*(1-smooth(clamp((v-.82)/.18,0,1))));
  // a flutter as it comes away
  const flutter=v=>smooth(clamp(v/.05,0,1))*(1-smooth(clamp((v-.1)/.2,0,1)));
  const frames=[];
  for(let i=0;i<=steps;i++){
    const v=i/steps,ph=phase(v),s=Math.sin(ph),c=Math.cos(ph),e=swing(v),A=amp*e;
    const rot=a0+turn*smooth(clamp((v-.04)/.8,0,1))-24*e*s+10*Math.sin(TAU*secs*v/1.1)*flutter(v);
    frames.push(frame(v,{x:x*(1-breeze(v))+A*s,y:y*(1-down(v))-.22*A*s*s,rot,
      ry:46*Math.sin(TAU*secs*v/.85)*flutter(v)+55*e*c,rx:10*e*Math.sin(ph/2),scale:1+.1*Math.pow(Math.sin(Math.PI*v),1.2)}));
  }
  return {keyframes:frames,duration,easing:'linear'};
}

/** The flower's side of a new Hero Point: its petal tugs once or twice and
 * lets go (gone at once, as the falling petal takes over where it is), stays
 * away while that petal falls (`away` ms), then grows back from its base with
 * a little unfurling turn. pull: how far it slides out as it comes loose, in
 * the flower's own units. For its individual rotate, translate and scale. */
export function flowerPetalCycle({away,pull={x:0,y:0},loosen=PETAL_LOOSEN_MS,wait=PETAL_REGROW_WAIT_MS,regrow=PETAL_REGROW_MS}){
  const total=loosen+away+wait+regrow,frames=[];
  const k=(ms,{rot=0,px=0,py=0,scale=1,opacity=1}={},easing)=>frames.push({offset:r3(clamp(ms/total,0,1)),rotate:`${r1(rot)}deg`,translate:`${r3(px)}px ${r3(py)}px`,scale:`${r3(scale)}`,opacity:r3(opacity),...(easing?{easing}:{})});
  for(let i=0;i<=12;i++){
    const w=i/12,p=smooth(clamp((w-.55)/.45,0,1));
    k(loosen*w,{rot:8*Math.sin(3*Math.PI*w)*Math.sqrt(Math.sin(Math.PI*w))*(.55+.45*w),px:pull.x*p,py:pull.y*p});
  }
  k(loosen,{px:pull.x,py:pull.y,opacity:0});
  const back=loosen+away+wait;
  k(back,{scale:.1,rot:-14,opacity:0},'cubic-bezier(.25,.6,.35,1)');
  k(back+regrow*.32,{scale:.62,rot:-5},'cubic-bezier(.3,.5,.4,1)');
  k(back+regrow*.72,{scale:1.06,rot:2},'ease-in-out');
  k(total);
  return {keyframes:frames,duration:total,easing:'linear'};
}
/** A petal that let go but never landed: it grows back now. */
export function flowerPetalRegrow(regrow=PETAL_REGROW_MS){
  return {keyframes:[{offset:0,scale:'.1',rotate:'-14deg',opacity:0,easing:'cubic-bezier(.25,.6,.35,1)'},{offset:.32,scale:'.62',rotate:'-5deg',opacity:1,easing:'cubic-bezier(.3,.5,.4,1)'},
    {offset:.72,scale:'1.06',rotate:'2deg',opacity:1,easing:'ease-in-out'},{offset:1,scale:'1',rotate:'0deg',opacity:1}],duration:regrow,easing:'linear'};
}

/** The angle a petal in her row sways to, `t` ms into its sway (-7° to 7°
 * and back, ease-in-out each way, like the CSS). */
export function rowSwayAngle(t,duration=5600){
  const p=(((t%duration)+duration)%duration)/duration,e=EASE_IN_OUT(p<.5?p*2:p*2-1);
  return p<.5?-7+14*e:7-14*e;
}
function cubicBezier(x1,y1,x2,y2){
  const cx=3*x1,bx=3*(x2-x1)-cx,ax=1-cx-bx,cy=3*y1,by=3*(y2-y1)-cy,ay=1-cy-by;
  const X=t=>((ax*t+bx)*t+cx)*t,Y=t=>((ay*t+by)*t+cy)*t,dX=t=>(3*ax*t+2*bx)*t+cx;
  return x=>{let t=clamp(x,0,1);for(let i=0;i<8;i++){const d=dX(t);if(Math.abs(d)<1e-6)break;t=clamp(t-(X(t)-x)/d,0,1);}return Y(t);};
}
const EASE_IN_OUT=cubicBezier(.42,0,.58,1);

/** A spent petal: it lifts, then floats down `fall` px, drifting aside. */
export function petalLeaving({fall=300,drift=-.26,speed=78,steps=110}){
  fall=Math.max(60,fall);
  const lift={x:3,y:-11};
  const p0=lift,p3={x:fall*drift,y:fall},p1={x:lift.x+fall*drift*.05,y:lift.y+fall*.38},p2={x:p3.x-fall*drift*.25,y:p3.y-fall*.34};
  const path=curve(p0,p1,p2,p3);
  const duration=Math.round(clamp((path.total+11)/speed,3.4,8)*1000);
  const amp=clamp(path.total*.075,12,40),cycles=Math.max(1.5,Math.round(path.total/190*2)/2+.25),b1=.11;
  const along=progress({cycles,phase:Math.PI,hang:.42,pace:v=>.38+.62*smooth(clamp(v/.24,0,1))});
  const frames=[];let last=null;
  for(let i=0;i<=steps;i++){
    const u=i/steps;
    if(u<=b1){
      // the breeze takes it: a lift, a tilt and a shiver
      const w=u/b1,e=smooth(w);
      frames.push(frame(u,{x:lift.x*e,y:lift.y*Math.sin(Math.PI/2*w),rot:16*e+4*Math.sin(TAU*1.5*w)*(1-w)}));
      continue;
    }
    const v=(u-b1)/(1-b1),p=path.point(along(v)),f=sway(v,{amp,cycles,phase:Math.PI});
    // at the end of each swing it lifts a little before it swoops back
    const rise=-.12*amp*f.env*f.s*f.s;
    last={x:p.x-p.ty*f.q+p.tx*rise,y:p.y+p.tx*f.q+p.ty*rise,rot:16+70*smooth(v)+f.rot,ry:f.ry};
    frames.push(frame(u,{...last,rx:10*f.env*Math.sin(TAU*cycles*v*.5),scale:1+.12*Math.sin(Math.PI*Math.min(1,v/.7))-.14*smooth(v),opacity:v<.66?1:1-smooth((v-.66)/.34)}));
  }
  return {keyframes:frames,duration,easing:'linear'};
}

/** The longest either can take (for code that waits on them), and the
 * cross-fade as a new petal hands over to the one in the row. */
export const PETAL_MAX_MS=8000,PETAL_HANDOVER_MS=320;
/** A new petal: how long its flower petal tugs before it lets go, and how it grows back after. */
export const PETAL_LOOSEN_MS=650,PETAL_REGROW_WAIT_MS=120,PETAL_REGROW_MS=1300;
