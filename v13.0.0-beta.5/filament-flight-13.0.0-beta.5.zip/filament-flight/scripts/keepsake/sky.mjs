/** The Keepsake keeps the world's time (v10 beta.26). From the game's world
 * clock: the moon's phase (for the crescent in the top right corner), night
 * or day (the Nytheris in the top left opens at night) and how near the moon
 * is to full (the lunar lily in the bottom right opens fully then).
 *
 * PF2e's world clock gives a real calendar date, so the moon keeps the true
 * phase for that date. Other systems count the world time from the start of
 * 1970. No Foundry globals are needed when `game` is passed in. */

const SYNODIC=29.530588853;
// The new moon of 6 January 2000, 18:14 UTC, in days after 1 January 1970.
const NEW_MOON=10962.7597;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;

export const PHASE_NAMES=Object.freeze(['New moon','Waxing crescent','First quarter','Waxing gibbous','Full moon','Waning gibbous','Last quarter','Waning crescent']);
export const phaseName=p=>PHASE_NAMES[Math.floor((((p+1/16)%1)+1)%1*8)%8];

/** {phase (0 new, .5 full), hour (0..24), night (0 day … 1 night), fromFull (days)} */
export function worldSky(game=globalThis.game){
  let ms=null,hour=null;
  // PF2e: the world clock's date (a Luxon DateTime): the true moon for that date.
  try{const dt=game?.pf2e?.worldClock?.worldTime,t=dt?.toMillis?.();if(Number.isFinite(t)){ms=t;if(Number.isFinite(dt.hour))hour=dt.hour+(Number(dt.minute)||0)/60;}}catch{}
  const seconds=Number(game?.time?.worldTime)||0;
  if(ms===null)ms=seconds*1000;
  if(hour===null){try{const c=game?.time?.components;if(Number.isFinite(c?.hour))hour=c.hour+(Number(c.minute)||0)/60;}catch{}}
  if(hour===null)hour=((ms/3600000)%24+24)%24;
  const days=ms/86400000,phase=(((days-NEW_MOON)/SYNODIC)%1+1)%1;
  // Night from dusk to dawn, with two hours' twilight either side.
  const night=hour>=20||hour<5?1:hour>=18?(hour-18)/2:hour<7?1-(hour-5)/2:0;
  return {phase,hour,night:clamp(night,0,1),fromFull:Math.abs(phase-.5)*SYNODIC};
}

/** How open the lunar lily is `fromFull` days from the full moon: fully
 * within a day of it, closing over the next day and a bit. */
export const lilyOpen=fromFull=>clamp(1-(fromFull-1)/1.2,0,1);
/** A short key that changes only when the corners would visibly change (the
 * moon by about a fortieth of its month, the Nytheris and the lily by a
 * fortieth of their opening): the HUD redraws for the clock only then. */
export function skyKey(game=globalThis.game){
  const s=worldSky(game);
  return `${Math.round(s.phase*240)}|${Math.round(s.night*40)}|${Math.round(lilyOpen(s.fromFull)*40)}`;
}

/** The lit part of the moon at `phase` as an SVG path: a disc of radius r at
 * (cx,cy) cut by the terminator (lit on the right while waxing). */
export function moonPath(phase,cx,cy,r){
  const p=((phase%1)+1)%1,k=Math.cos(p*Math.PI*2),ex=Math.abs(k)*r,f=n=>Math.round(n*100)/100;
  const top=`${f(cx)} ${f(cy-r)}`,bottom=`${f(cx)} ${f(cy+r)}`;
  // Waxing: limb on the right, then back up the terminator (bulging right for a crescent).
  if(p<.5)return `M${top}A${f(r)} ${f(r)} 0 0 1 ${bottom}A${f(ex)} ${f(r)} 0 0 ${k>0?0:1} ${top}Z`;
  return `M${top}A${f(r)} ${f(r)} 0 0 0 ${bottom}A${f(ex)} ${f(r)} 0 0 ${k>0?1:0} ${top}Z`;
}

/** The Nytheris petals at `open` (0 by day: a bud of five petals fanned
 * upwards, each one still its own; 1 at night: the open five-point star):
 * each petal's rotation (deg) and width/height scale. */
const OPEN=[0,72,144,-144,-72],BUD=[0,26,52,-52,-26];
export function nytherisPetals(open){
  const o=clamp(open,0,1);
  return OPEN.map((a,k)=>({angle:BUD[k]+(a-BUD[k])*o,sx:.8+.2*o,sy:1.06-.06*o}));
}
