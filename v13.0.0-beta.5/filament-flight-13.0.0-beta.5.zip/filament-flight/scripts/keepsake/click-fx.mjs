/** Keepsake click glint (beta.35): every click on her sheet, the Keepsake HUD and the
 * Medkit answers with a short glint, after the press the CSS already plays (:active).
 *
 *  - One listener on the document (pointer down, up and cancel, and keyboard clicks),
 *    nothing on the controls themselves; the HUD's shadow root is read through
 *    composedPath, so PF2e redrawing the sheet after a click doesn't matter.
 *  - The glint is drawn in one fixed layer over the page, cut to the control's own
 *    shape (its border-radius or clip-path) and to what of it can be seen (the scrollers
 *    it sits in), so it never lays anything out and never spills past its edge.
 *  - Sized for the control actually seen: an invisible layer PF2e lays over a row (the
 *    skill's d20) glints as the row it covers; a turning control keeps its own size;
 *    the bloom is at most about three times the box's height (beta.36).
 *  - A bloom from where she pressed and a thin hard-light sheen across, gold, or
 *    magenta for things that switch (tabs, toggles, invest, equip). 160-280ms,
 *    transform and opacity only, so the compositor plays it.
 *  - Nothing exists between clicks: no element, no animation, no timer.
 *  - Off with the browser's reduced motion and the module's Reduced motion. */

const ID='filament-flight';
const SHEET=['button','a[data-action]','a.item-control','.item-controls > a','a.roll-icon','.quantity > a','.toggles button',
  'nav a.item','.sub-nav a','label.ffks-check','input[type=checkbox]','.ffks-ibtn','.ffks-tile','.ffks-coinface','li.attribute.ffks-coin','.ffks-track',
  '.ffks-cpt','.ffks-cchip','.ffks-idchip','.header-button','.ffks-mini','.tag[data-action]','h4.name > a','[data-action=toggle-summary]',
  '.pips','.ffks-rkwrap','[role=button]','summary'].join(',');
const SHEET_ROW=['li[data-item-id]','li[data-subitem-id]','li.strike','li.ffks-skill','.proficiencies-list > li','.feats-list li.slot',
  '.inventory-list li','.actions-list > li'].join(',');
const HUD=['.tile','.feel','.tag','.act','.btn','.charm','.coin','.bit','.pip','.field','.seg2','.seg','.opt','.copt','.crow','.grow','.more',
  '.x','.tab','.lnk','.sw','.notch','.cond','.sealbtn','.taskwrap','button','[role=button]','.mk-card','.mk-close','.mk-ask-btn','.mk-act',
  '.mk-back','.mk-party-btn','.mk-sound','.mk-mini','.mk-switch'].join(',');
// things that switch glint magenta
const SWITCH=['.tab','nav a.item','.sub-nav a','[data-action*=toggle]','input[type=checkbox]','label.ffks-check','.sw','.seg','.seg2',
  '.opt','.copt','.cond','.ffks-cpt','[data-action*=equip]','[data-action*=invest]','[data-action*=carry]','.pips','.mk-switch'].join(',');
const FIELD=/^(INPUT|SELECT|TEXTAREA)$/;
const MAX=6;   // glints at once (fast clicking only ever shows the last few)

const installed=new WeakSet();
let press=null, live=0;

const reduced=win=>{
  let r=false;try{r=!!game.settings.get(ID,'reducedMotion');}catch{}
  return r||!!win?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
};

/** The control (or, failing one, the row) a pointer event landed on, if it is on a Keepsake surface. */
function targetOf(e){
  const path=e.composedPath?.()??[];
  let surface=null;
  for(const n of path){
    if(!(n instanceof Element))continue;
    if(n.classList.contains('ffks')&&n.classList.contains('window-app')){surface='sheet';break;}
    if(n.classList.contains('ks-host')||n.classList.contains('mk-host')||n.id==='filament-flight-hud'||n.classList.contains('ks-root')){surface='hud';break;}
  }
  if(!surface)return null;
  const first=path[0];
  if(first instanceof Element&&FIELD.test(first.tagName)&&!(first.type==='checkbox'||first.type==='radio'||first.type==='button'||first.type==='submit'))return null;
  const sel=surface==='sheet'?SHEET:HUD;
  let row=null;
  for(const n of path){
    if(!(n instanceof Element))continue;
    if(n.classList.contains('window-app')||n.classList.contains('ks-host')||n.classList.contains('mk-host'))break;
    if(n.matches(sel)){if(n.matches(':disabled, .disabled, [aria-disabled=true]'))return null;return {el:n,row:false};}
    if(!row&&surface==='sheet'&&n.matches(SHEET_ROW))row=n;
  }
  return row?{el:row,row:true}:null;
}

function layerOf(doc){
  let l=doc.getElementById('ffks-glints');
  if(!l){
    l=doc.createElement('div');l.id='ffks-glints';l.setAttribute('aria-hidden','true');
    l.style.cssText='position:fixed;inset:0;z-index:2147483000;pointer-events:none;contain:strict;overflow:hidden';
    doc.body.append(l);
  }
  return l;
}

/** The element whose box the eye sees for a control. PF2e lays some controls over a whole row as an
 * invisible layer (a skill's d20 covers its card, opacity 0): the glint belongs to the row it covers,
 * cut to that row's own shape. */
function visualOf(el,win){
  for(let e=el,i=0;e&&i<3;e=e.parentElement,i++){
    const cs=win.getComputedStyle(e);
    if(+cs.opacity>0.05&&cs.visibility!=='hidden')return {el:e,cs};
    if(e.parentElement?.matches?.('.window-app, .ks-root'))break;
  }
  return {el,cs:win.getComputedStyle(el)};
}

/** The box she sees: its layout size about the centre the page draws it at. A control that is turning
 * (PF2e's d20 spins while hovered) keeps its own size, not the box around its turned corners. */
function boxOf(el,cs){
  const r=el.getBoundingClientRect();
  const m=/^matrix\(([^)]+)\)/.exec(cs.transform||'');
  const k=m?m[1].split(',').map(Number):null;
  if(!k||Math.abs(k[1])<1e-3&&Math.abs(k[2])<1e-3)return {l:r.left,t:r.top,w:r.width,h:r.height,rot:0};
  const sx=Math.hypot(k[0],k[1]),sy=Math.hypot(k[2],k[3]);
  const w=(el.offsetWidth??r.width)*sx,h=(el.offsetHeight??r.height)*sy;
  const cx=r.left+r.width/2,cy=r.top+r.height/2;
  return {l:cx-w/2,t:cy-h/2,w,h,rot:Math.atan2(k[1],k[0])};
}

/** What of the box can be seen: cut by every scroller and clipped box it sits in (the glint layer is
 * fixed over the page, so a row half under a list's edge mustn't glint over the header beside it). */
function visibleOf(el,win,b){
  let L=b.l,T=b.t,R=b.l+b.w,B=b.t+b.h;
  for(let e=el.parentElement??el.getRootNode()?.host;e&&e!==el.ownerDocument.documentElement;e=e.parentElement??e.getRootNode()?.host){
    const cs=win.getComputedStyle(e);
    if(cs.overflowX!=='visible'||cs.overflowY!=='visible'||/paint|strict|content/.test(cs.contain)){
      const q=e.getBoundingClientRect();
      L=Math.max(L,q.left);T=Math.max(T,q.top);R=Math.min(R,q.right);B=Math.min(B,q.bottom);
    }
    if(e.classList.contains('window-app')||e.classList.contains('ks-root'))break;
  }
  return {L:Math.max(L,0),T:Math.max(T,0),R:Math.min(R,win.innerWidth),B:Math.min(B,win.innerHeight)};
}

/** The glint itself: read the control once, then build and play (no read after a write). */
function glint(target,x,y,{row=false}={}){
  const doc=target.ownerDocument,win=doc.defaultView;
  if(live>=MAX||reduced(win))return;
  const {el,cs}=visualOf(target,win);
  const b=boxOf(el,cs);
  if(b.w<4||b.h<4)return;
  const v=visibleOf(el,win,b);
  if(v.R-v.L<2||v.B-v.T<2)return;
  const magenta=target.matches(SWITCH)||target.matches('.on, .active, [aria-pressed=true]')||el.matches('.on, .active, [aria-pressed=true]');
  const cx=b.l+b.w/2,cy=b.t+b.h/2;
  x=Number.isFinite(x)?Math.min(Math.max(x,b.l),b.l+b.w):cx;y=Number.isFinite(y)?Math.min(Math.max(y,b.t),b.t+b.h):cy;
  // the bloom is sized for the box: it reaches the farthest corner of a small control, and on a wide
  // card or row it stays a glow about three times the box's height (never a flood across the row)
  const far=Math.hypot(Math.max(x-b.l,b.l+b.w-x),Math.max(y-b.t,b.t+b.h-y));
  const D=Math.round(Math.max(8,Math.min(far*2,Math.min(b.w,b.h)*3,row?140:220)));
  const [c1,c2]=magenta?['rgba(243,193,223,.5)','rgba(231,103,206,.24)']:['rgba(242,214,160,.5)','rgba(226,162,86,.2)'];
  // a window on what can be seen of it, then the control's own shape inside
  const win0=doc.createElement('div');
  win0.style.cssText=`position:absolute;left:0;top:0;width:${v.R-v.L}px;height:${v.B-v.T}px;transform:translate(${v.L}px,${v.T}px);overflow:hidden;contain:strict`;
  const shape=doc.createElement('div');
  shape.style.cssText=`position:absolute;left:${b.l-v.L}px;top:${b.t-v.T}px;width:${b.w}px;height:${b.h}px;`
    +(b.rot?`transform:rotate(${b.rot}rad);`:'')
    +`border-radius:${cs.borderRadius};overflow:hidden;contain:strict;`+(cs.clipPath&&cs.clipPath!=='none'?`clip-path:${cs.clipPath};`:'');
  // (the press point in the shape's own frame: unturned about its centre)
  let px=x-cx,py=y-cy;
  if(b.rot){const c=Math.cos(-b.rot),s=Math.sin(-b.rot);[px,py]=[px*c-py*s,px*s+py*c];}
  px+=b.w/2;py+=b.h/2;
  const bloom=doc.createElement('div');
  bloom.style.cssText=`position:absolute;left:${px-D/2}px;top:${py-D/2}px;width:${D}px;height:${D}px;border-radius:50%;`
    +`background:radial-gradient(circle closest-side,${c1} 0,${c2} 45%,transparent 100%);opacity:0;will-change:transform,opacity`;
  const sheen=doc.createElement('div');
  sheen.style.cssText=`position:absolute;inset:0;opacity:0;will-change:transform,opacity;`
    +`background:linear-gradient(105deg,transparent 34%,${magenta?'rgba(243,193,223,.3)':'rgba(233,207,156,.32)'} 47%,${magenta?'rgba(231,103,206,.18)':'rgba(231,103,206,.14)'} 53%,transparent 66%)`;
  shape.append(bloom,sheen);win0.append(shape);layerOf(doc).append(win0);live++;
  // (the bloom opens fast and holds its glow a moment before it goes; the sheen crosses once)
  const a=bloom.animate([{transform:'scale(.2)',opacity:.9},{transform:'scale(.78)',opacity:.72,offset:.45},{transform:'scale(1)',opacity:0}],{duration:row?240:280,easing:'cubic-bezier(.2,.7,.3,1)'});
  sheen.animate([{transform:'translateX(-70%)',opacity:0},{opacity:1,offset:.4},{transform:'translateX(70%)',opacity:0}],{duration:row?220:260,easing:'cubic-bezier(.3,.6,.3,1)'});
  const done=()=>{win0.remove();live--;};
  a.finished.then(done,done);
}

function onPointer(e){
  if(e.type==='pointerdown'){
    if(e.button!==0||!e.isPrimary){press=null;return;}
    const t=targetOf(e);press=t?{...t,id:e.pointerId}:null;return;
  }
  if(e.type==='pointerup'){
    const p=press;press=null;
    if(!p||p.id!==e.pointerId||!p.el.isConnected)return;
    // (released over the same control: that's a click)
    if(!(e.composedPath?.()??[]).includes(p.el))return;
    glint(p.el,e.clientX,e.clientY,p);return;
  }
  if(e.type==='pointercancel'){press=null;return;}
  // a click from the keyboard (Enter, Space): from the middle
  if(e.type==='click'&&e.detail===0){const t=targetOf(e);if(t&&!t.row)glint(t.el,NaN,NaN,t);}
}

/** Once per document. */
export function installClickFx(doc=globalThis.document){
  if(!doc||installed.has(doc))return;installed.add(doc);
  for(const t of ['pointerdown','pointerup','pointercancel','click'])doc.addEventListener(t,onPointer,{capture:true,passive:true});
}
