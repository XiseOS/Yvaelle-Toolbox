/** Ellie's Medkit window sounds (v10 beta.18): small, quiet interface sounds
 * heard only by you. They play on Foundry's Interface volume, stay silent
 * when wing audio is muted on this browser, and the speaker button in the
 * Medkit's title row turns them off (remembered for your user). */
const ROOT='modules/filament-flight/assets/audio/medkit-ui',KEY='ellieMedkitUiSounds',ID='filament-flight';
export const MEDKIT_SOUNDS=Object.freeze(['open','close','flip','flip-back','choose','toggle-on','toggle-off','screen','seal','ask']);
const last=new Map();

/** Off unless turned on (beta.24): sounds are opt-in everywhere. */
export function uiSoundsOn(){try{return globalThis.game?.user?.getFlag?.('world',KEY)===true;}catch{return false;}}
export async function setUiSounds(on){try{await game.user.setFlag('world',KEY,!!on);}catch(error){console.warn('Yvaelle’s Toolbox | Medkit sounds preference',error);}}

/** Play one Medkit sound locally. Repeats within 70 ms are dropped. */
export function playMedkitSound(name,{volume=.55,force=false}={}){
  if(!MEDKIT_SOUNDS.includes(name))return;
  if(!force&&!uiSoundsOn())return;
  try{if(game.settings.get(ID,'audioMuted'))return;}catch{}
  const now=globalThis.performance?.now?.()??Date.now();
  if(now-(last.get(name)??-1e9)<70)return;last.set(name,now);
  const Helper=globalThis.foundry?.audio?.AudioHelper??globalThis.AudioHelper;
  try{const played=Helper?.play?.({src:`${ROOT}/medkit-${name}.ogg`,volume,autoplay:true,loop:false,channel:'interface'},false);played?.catch?.(()=>{});}
  catch(error){console.warn('Yvaelle’s Toolbox | Medkit sound',error);}
}
