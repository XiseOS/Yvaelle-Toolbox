/** Keepsake timings (beta.34): how long each step of a HUD render or tab
 * switch takes, kept in a small ring and mirrored as performance.measure
 * entries ("ff:<step>") for the browser's profiler. Long tasks are noted
 * with the steps that ran inside them, so the self-check can name what a
 * long task was. Cheap enough to stay on: one performance.now per step. */
const LOG=[],LONG=[],MAX=600;
let observing=false;
const now=()=>globalThis.performance?.now?.()??Date.now();
function watchLongTasks(){
  if(observing)return;observing=true;
  try{new PerformanceObserver(list=>{for(const e of list.getEntries()){LONG.push({at:e.startTime,ms:e.duration});if(LONG.length>60)LONG.shift();}}).observe({type:'longtask',buffered:true});}catch{}
}
export function record(name,ms,start=now()-ms){
  watchLongTasks();
  LOG.push({name,ms,at:start});if(LOG.length>MAX)LOG.splice(0,LOG.length-MAX);
  try{performance.measure?.('ff:'+name,{start,duration:ms});}catch{}
}
/** Time fn() as a step; returns fn's result. */
export function timed(name,fn){const t=now();try{return fn();}finally{record(name,now()-t,t);}}
/** Steps and long tasks since `since` (ms on the page clock). */
export function keepsakeTimings({since=0,top=10}={}){
  watchLongTasks();
  const steps=new Map();
  for(const e of LOG)if(e.at>=since){const s=steps.get(e.name)??{name:e.name,n:0,total:0,max:0};s.n++;s.total+=e.ms;s.max=Math.max(s.max,e.ms);steps.set(e.name,s);}
  const list=[...steps.values()].sort((a,b)=>b.total-a.total).slice(0,top).map(s=>({...s,total:+s.total.toFixed(1),max:+s.max.toFixed(1)}));
  const longTasks=LONG.filter(l=>l.at>=since).map(l=>{
    const inside=new Map();for(const e of LOG)if(e.at<l.at+l.ms&&e.at+e.ms>l.at)inside.set(e.name,(inside.get(e.name)??0)+e.ms);
    return {at:Math.round(l.at),ms:Math.round(l.ms),steps:[...inside].sort((a,b)=>b[1]-a[1]).slice(0,4).map(([n,ms])=>`${n} ${ms.toFixed(0)}`)};});
  return {steps:list,longTasks};
}
export function formatTimings(t){
  const s=t.steps.map(x=>`${x.name} ${x.total}ms/${x.n}`).join(', ')||'none';
  const l=t.longTasks.map(x=>`${x.ms}ms[${x.steps.join('; ')||'no Keepsake step'}]`).join(' ')||'none';
  return `steps ${s} · long tasks ${l}`;
}
