/** The Keepsake heartbeat (v10 beta.27): the beat on her HP line follows her
 * hit points and the PF2e conditions on her, in the Keepsake HUD and on the
 * Keepsake sheet alike.
 *
 *   her state               the beat
 *   hit points              steady when above half, quicker below, quickest
 *                           in the last quarter (as before)
 *   frightened 1-4          quicker with each step, a sharper spike; from 2 a
 *                           second beat on the line and a slight tremor
 *   fleeing                 frantic: three beats, fastest, trembling
 *   quickened / slowed      a little quicker / slower with each step
 *   fatigued                slower and weaker
 *   drained                 weaker with each step
 *   sickened, confused      uneven: beats out of time and of uneven strength
 *   wounded                 a small flutter after each beat
 *   stunned                 the light stops for a moment each time round
 *   doomed                  a dark shadow beat follows each one
 *   persistent bleed        a red trace runs with the light
 *   paralyzed               barely moving
 *   unconscious             slow and faint, like sleep
 *   dying 1-3               fainter and slower with each step, beats missing
 *   dead, petrified         still: a flat grey line
 *
 * Pure: numbers and condition values in, a description out (the trace to
 * draw, how long the light takes to run it, its strength and effects). */

const clamp=(v,a,b)=>v<a?a:v>b?b:v;
/** The HP line's box: 200 wide, 22 high, the baseline through the middle. */
export const HEART_BOX=Object.freeze({w:200,h:22,base:11});

/** What the heartbeat needs from a PF2e actor (null-safe, any system):
 * {hp, max, cond: {slug: value}, dyingMax}. */
export function heartState(actor){
  const a=actor?.system?.attributes,value=Number(a?.hp?.value),max=Number(a?.hp?.max),cond={};
  try{
    for(const c of actor?.conditions?.active??[]){
      const slug=c?.slug;if(!slug)continue;
      if(slug==='persistent-damage'){if(c.system?.persistent?.damageType==='bleed')cond.bleed=1;continue;}
      cond[slug]=Math.max(cond[slug]??0,Number(c.value)||1);
    }
  }catch{}
  // (Dying, wounded and doomed are also kept on her attributes.)
  for(const k of ['dying','wounded','doomed']){const v=Number(a?.[k]?.value);if(v>0)cond[k]=Math.max(cond[k]??0,v);}
  return {hp:Number.isFinite(value)?value:null,max:Number.isFinite(max)&&max>0?max:null,cond,dyingMax:Number(a?.dying?.max)||4};
}

/** A small repeatable random sequence (the same uneven beats for the same state). */
function seeded(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}
  return()=>{h=h+0x6D2B79F5|0;let t=Math.imul(h^h>>>15,1|h);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
const f1=n=>Math.round(n*10)/10;

/** The trace: `beats` spikes spread along the line (one at 104 as before),
 * each `amp` tall, moved out of time by `uneven`, with a small flutter after
 * each and `skip` beats left as faint blips. */
export function heartTrace({beats=1,amp=1,uneven=0,flutter=0,skip=0,seed=''}={}){
  const n=clamp(Math.round(beats),1,3),R=seeded(seed||`${n}|${amp}|${uneven}`);
  const at=n===1?[104]:n===2?[54,146]:[32,98,164];
  let d=`M0 11`;const width=17+(flutter>0?10:0);
  for(let i=0;i<n;i++){
    const x=clamp(at[i]+(uneven?(R()-.5)*2*uneven*26:0),2,199-width);
    let a=clamp(amp*(1+(uneven?(R()-.5)*uneven*.9:0)),.08,1.35);
    if(skip&&i>=n-skip)a=Math.min(a,.14);
    d+=`H${f1(x)}l5 ${f1(-8*a)} 5 ${f1(16*a)} 4 ${f1(-12*a)} 3 ${f1(4*a)}`;
    if(flutter>0)d+=`l4 0 2 ${f1(-3*flutter)} 2 ${f1(5*flutter)} 2 ${f1(-2*flutter)}`;
  }
  return d+'H200';
}

/** A calm single beat (the trace as it always was). */
export const CALM_TRACE=heartTrace({});

/** The beat for her state. Returns {still, period (s for the light to run
 * the line), trace, amp, tremor, echo, pause, bleed, tone, color, words}. */
export function heartbeat({hp=null,max=null,cond={},dyingMax=4}={}){
  const c=k=>Math.max(0,Number(cond?.[k])||0),pct=max?clamp((hp??max)/max,0,1):1;
  const hpColor=pct>.5?'#e767ce':pct>.25?'#e2a256':'#c8324f';
  // Still: dead (no hit points and dying at its limit) or turned to stone.
  if(c('petrified')||(hp!==null&&hp<=0&&c('dying')>=dyingMax)){
    return {still:true,period:0,trace:'M0 11H200',amp:0,tremor:0,echo:0,pause:0,bleed:false,tone:'still',color:'#7d736f',words:[c('petrified')?'stone':'still']};
  }
  let period=pct>.5?2.6:pct>.25?1.6:.95,amp=1,beats=1,uneven=0,flutter=0,skip=0,tremor=0,echo=0,pause=0,tone='steady';
  const words=[];
  // Fear quickens it.
  const fr=Math.min(4,c('frightened'));
  if(c('fleeing')){period*=.5;beats=3;amp*=1.15;tremor=.7;words.push('frantic');}
  else if(fr){period/=1+.25*fr;beats=fr>=2?2:1;amp*=1+.06*fr;tremor=fr>=2?.15*fr:0;words.push('racing');}
  if(c('quickened'))period*=.85;
  if(c('slowed')){period*=1+.3*Math.min(3,c('slowed'));words.push('slowed');}
  if(c('fatigued')){period*=1.25;amp*=.85;words.push('tired');}
  if(c('drained'))amp*=1-.07*Math.min(4,c('drained'));
  if(c('sickened')){uneven=Math.max(uneven,.14*Math.min(4,c('sickened')));words.push('uneven');}
  if(c('confused')){uneven=Math.max(uneven,.45);words.push('uneven');}
  if(c('wounded'))flutter=Math.min(1,.35*c('wounded'));
  if(c('stunned')){pause=Math.min(3,Math.ceil(c('stunned')/1.5));words.push('stopping');}
  if(c('doomed'))echo=Math.min(1,.34*c('doomed'));
  // (Paralysed, unconscious or dying, fear no longer quickens it.)
  const calm=()=>{for(const w of ['racing','frantic']){const i=words.indexOf(w);if(i>=0)words.splice(i,1);}};
  if(c('paralyzed')){period*=2.4;amp*=.35;tremor=0;calm();words.push('barely moving');}
  // Unconscious: slow and faint. Dying: fainter and slower with each step, beats missing.
  const dying=Math.min(dyingMax,c('dying'));
  if(dying){period=Math.max(period,1.6)*(1.6+.4*dying);amp*=Math.max(.16,.62-.14*dying);beats=dying>=2?2:1;skip=dying>=2?1:0;tremor=0;tone='fading';calm();words.push('fading');}
  else if(c('unconscious')){period=Math.max(period,1.6)*1.8;amp*=.6;tremor=0;tone='faint';calm();words.push('slow');}
  const trace=heartTrace({beats,amp,uneven,flutter,skip,seed:JSON.stringify([beats,amp,uneven,flutter,skip])});
  const color=tone==='fading'?'#a6566c':tone==='faint'?'#b07aa4':hpColor;
  return {still:false,period:Math.round(period*100)/100,trace,amp,tremor:Math.round(tremor*100)/100,echo:Math.round(echo*100)/100,pause,bleed:c('bleed')>0,tone,color,
    words:[...new Set(words)]};
}
