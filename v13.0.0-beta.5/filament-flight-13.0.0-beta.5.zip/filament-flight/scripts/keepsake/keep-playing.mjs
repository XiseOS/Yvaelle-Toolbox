/** Beta.40: Keep playing. The sheet's and the HUD's endless loops hold still
 * while any token moves (decor-hold.mjs) and the HUD's sleep while it is
 * covered (app.mjs). These per-browser switches let the noticeable ones go on
 * regardless: while she or another token moves, and while the window is
 * unfocused or partly covered. A hidden browser tab, a minimised window, one
 * scrolled or moved off the screen or completely covered still pauses
 * everything, as nobody sees it; and Frame motion Off or Reduced motion still
 * stops them all.
 *
 * Each group names what you see and the elements its loops run on (matched
 * against an animation's own element: the sheet's classes, then the HUD's).
 * `cost` is what keeping the group on costs, measured on the real PF2e sheet
 * over a moving canvas (tools: the fix40 sheet harness; see the release
 * notes). */
const ID='filament-flight';

export const KEEP_GROUPS=Object.freeze([
  {id:'Heart',name:'Heartbeat and HP line',def:true,
    desc:'The beat running along her HP line, its tremor and the dying beat',
    sheet:'.ffks-hbglint, .ffks-hbglint *, .ffks-hb, .ffks-hb *, .ffks-ic.dy1, .ffks-ic.dy2, .ffks-ic.dy3, .ffks-track .pips i.ffks-pip',
    hud:'.hb, .hb *'},
  {id:'Portrait',name:'Portrait breathing and mood',def:false,
    desc:'Her portrait breathing, and its pulse when she is badly hurt',
    sheet:'.ffks-ptr-mood',hud:'.ks-portrait'},
  {id:'Petals',name:'Hero Point petals and flowers',def:false,
    desc:'The Hero Point petals swaying, the drifting petals, the sprig and the lunar lily',
    sheet:'.ffks-hero i.ffks-petal, .ffks-sway, .ffks-lily',hud:'.hp.held, .hp.arriving, .petal, .sway, .sway2, .lily'},
  {id:'Sky',name:'Moon and stars',def:false,
    desc:'The moon’s glow and the twinkling stars in the corners',
    sheet:'.ffks-moonglow, .ffks-twinkle',hud:'.moonglow, .twinkle'},
  {id:'Corners',name:'Corner glints and cords',def:false,
    desc:'The light running along the cords and corners, and the gems’ glow',
    sheet:'.ffks-shine, .ffks-run, .ffks-gemglow',hud:'.cord-shine, .run, .gemglow'}
]);
/** What keeping each group costs while tokens move (main-thread style, layout and paint per display frame, beta.40,
 * measured on the real PF2e sheet and on the HUD with each group alone; a software-drawn test page, so likely less on
 * a graphics card). Said in the setting only where it is worth knowing. */
export const KEEP_COST=Object.freeze({
  sheet:{Heart:'about 0.2 ms a frame while tokens move',Portrait:'very little, and only while she is badly hurt',Petals:'about 0.3 ms a frame while tokens move',Sky:'about 0.15 ms a frame while tokens move',Corners:'about 0.2 ms a frame while tokens move'},
  hud:{Heart:'about 0.8 ms a frame while tokens move',Portrait:'about 0.2 ms a frame while tokens move',Petals:'about 2 ms a frame while tokens move',Sky:'about 0.5 ms a frame while tokens move',Corners:'about 2.5 ms a frame while tokens move, the most of these'}});
export const SURFACES=Object.freeze({sheet:'Sheet',hud:'Hud'});
export const keepKey=(surface,id)=>`keepPlaying${SURFACES[surface]}${id}`;

/** Client settings (config.mjs spreads these into SETTINGS). Hidden from Foundry's own list:
 * HUD › Settings › Keep playing has them, and the All settings window too. */
export function keepSettingDefinitions(){
  const out={};
  for(const [surface,label] of [['sheet','her sheet'],['hud','the HUD']])for(const g of KEEP_GROUPS)
    out[keepKey(surface,g.id)]={name:`Keep playing on ${label}: ${g.name}`,hint:`${g.desc} keep playing on ${label} while tokens move and while it is partly covered or not in focus (a hidden or minimised window still pauses). Frame motion Off and Reduced motion still stop it. This browser only.`,
      scope:'client',config:false,type:Boolean,default:g.def};
  return out;
}

// (read on every hold tick, 10 a second: cached until a setting changes)
let cache=null;
for(const hook of ['filamentFlightSettingsChanged','clientSettingChanged','updateSetting'])try{globalThis.Hooks?.on?.(hook,()=>{cache=null;});}catch{}
export function invalidateKeep(){cache=null;}
const get=(k,fallback)=>{try{const v=globalThis.game?.settings?.get?.(ID,k);return v??fallback;}catch{return fallback;}};
/** Frame motion Off or Reduced motion (the module's, or the system's): nothing keeps playing. */
function stilled(view){
  if(get('reducedMotion',false)||globalThis.canvas?.photosensitiveMode)return true;
  const ui=get('keepsakeUI',null);if(ui&&ui.fm==='Off')return true;
  try{if((view??globalThis).matchMedia?.('(prefers-reduced-motion: reduce)')?.matches)return true;}catch{}
  return false;
}
/** The groups kept on a surface: {ids:Set, selector:string|null, corners:boolean}. */
export function keptOn(surface,view=null){
  const now=Date.now();
  // (prefers-reduced-motion and Frame motion are re-read at most once a second)
  if(cache&&now-cache.at<1000&&cache.view===view&&cache[surface])return cache[surface];
  if(!cache||cache.view!==view||now-cache.at>=1000)cache={at:now,view};
  const still=stilled(view),groups=still?[]:KEEP_GROUPS.filter(g=>!!get(keepKey(surface,g.id),g.def));
  const out={ids:new Set(groups.map(g=>g.id)),selector:groups.length?groups.map(g=>g[surface]).join(', '):null,corners:groups.some(g=>g.id==='Corners'),still};
  cache[surface]=out;return out;
}
/** Whether this running animation belongs to a kept group on `surface`. */
export function keepsAnimation(surface,animation,view=null){
  const k=keptOn(surface,view);if(!k.selector)return false;
  const el=animation?.effect?.target;if(!el||el.nodeType!==1)return false;
  try{return el.matches(k.selector);}catch{return false;}
}
