/** Yvaelle’s Toolbox v13 · The Heart Turned: the GM's curse wheel.
 *
 * A tap of the GM's own key opens it round the pointer; a tap again (or Escape, a right-click, a click outside) closes it.
 * Only the GM has the key, and only the GM's page ever makes the wheel.
 *
 *   the six threads     her six states, numbered as on the table. Lean on one and it turns to briar; click it and that
 *                       state is laid on her outright (no roll: on her screen it devours the other five).
 *   the centre          click it and she rolls for it herself.
 *   the strip beside it who is cursed (top) · "that person": the roll of faith, or one of the people pinned (the other
 *                       player characters, and any tokens the GM has selected or targeted) · how long: 1d3, 1d4 or 1d6 Spans.
 *   the bar under it    (beta.2) Watch her roll (off as it comes: on, the GM's own page plays her view as she rolls) ·
 *                       Edit the states (their names, verbs and texts) · and, while a curse is on her, what it is and
 *                       the Spans left, with −1 Span and Lift.
 * A pinned person is who the curse is about ("toward"); with nobody pinned her roll of faith chooses among the people shown.
 *
 * Nothing exists while it is closed: no element, no frame callback. Its host (curse-runtime.mjs) knows Foundry:
 *   host.her() → {name, img} | null         host.people() → [{id, n, img}]        host.active() → her record | null
 *   host.send({state, toward, people, die}) → {ok, local, name, why}               host.lift() · host.burn()
 *   host.useSelected() → name | null (make the selected token's character the one who is cursed)
 *   host.gm() / host.saveGm({die, pin, watch})    host.now()    host.edit() (open the states' editor) */
import {CURSE_NOW as TAB,CURSE_DICE,dieOf,stateIndex,spansLeft,spanWord,namesSomeone,tintOf} from './curse-model.mjs?v=13.0.0-beta.5';   // (beta.2) the states as they are now, with the GM's edits
import {curseArt,BONE,MAG,EMB,PI,TAU,E,F} from './curse-art.mjs?v=13.0.0-beta.5';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cssUrl=u=>`url("${String(u).replace(/["\\\n\r]/g,'')}")`;
/** The wheel's canvas (CSS px) and where its centre sits in it. */
export const WHEEL=Object.freeze({w:700,h:624,cx:350,cy:300,hub:32,reach:250});
/** How far the strip stands from the wheel's reach (to its left, to its right), and so how wide a side label may be. */
const STRIP_GAP=Object.freeze({left:160,right:96,label:138});
/** Which thread lies under a point (dx, dy from the centre): 0 to 5 · -1 the centre · -2 outside the wheel. */
export function wheelSector(dx,dy){
  const r=Math.hypot(dx,dy);if(r<=WHEEL.hub)return -1;if(r>WHEEL.reach)return -2;
  return ((Math.round((Math.atan2(dy,dx)+PI/2)/(PI/3))%6)+6)%6;
}
const FAITH_SVG='<svg width="24" height="14" viewBox="0 0 24 14" aria-hidden="true"><g fill="#ffe4fb"><path d="M3 1l2 5-2 7-2-7z"/><path d="M9 1l2 5-2 7-2-7z"/><path d="M15 1l2 5-2 7-2-7z"/><path d="M21 1l2 5-2 7-2-7z"/></g></svg>';

export class CurseWheel{
  constructor({host,doc=globalThis.document,win=globalThis.window}={}){
    this.host=host;this.doc=doc;this.win=win;this.root=null;this.cv=null;this.x=null;this.art=null;this.strip=null;this.bar=null;this.watch=false;this.frame=0;this.listeners=null;this.closing=false;
    this.S={a:0,x:0,y:0,inn:[0,0,0,0,0,0],dk:[0,0,0,0,0,0],hov:-2,pull:0,lock:false,t0:0,mx:0,my:0};this.die=4;this.pin='';this.people=[];this.her=null;this.tw=[];this.lastT=0;
    this.stats={opened:0,laid:0,asked:0};
  }
  get open(){return !!this.root&&!this.closing;}
  /** Open round a point of the page (the pointer), or close if it is open. */
  toggle(px,py){if(this.root){this.close();return false;}this.show(px,py);return true;}
  tween(ms,fn,ez=E.io){return new Promise(res=>{this.tw.push({t0:this.win.performance.now(),ms,fn,ez,res});fn(ez(0));});}
  show(px,py){
    if(this.root)return;const d=this.doc,W=this.win.innerWidth||1280,Hh=this.win.innerHeight||720,S=this.S;this.stats.opened++;this.closing=false;
    const gm=(()=>{try{return this.host.gm?.()??{};}catch{return {};}})();this.die=dieOf(gm.die);this.pin=typeof gm.pin==='string'?gm.pin:'';this.watch=!!gm.watch;
    try{this.her=this.host.her?.()??null;this.people=this.host.people?.()??[];}catch{this.her=null;this.people=[];}
    if(this.pin&&!this.people.some(p=>p.id===this.pin))this.pin='';
    const X=Math.round(Math.max(WHEEL.cx+4,Math.min(W-WHEEL.cx-4,Number.isFinite(px)?px:W/2))),Y=Math.round(Math.max(WHEEL.cy+4,Math.min(Hh-(WHEEL.h-WHEEL.cy)-4,Number.isFinite(py)?py:Hh/2)));
    Object.assign(S,{a:0,x:X,y:Y,inn:[0,0,0,0,0,0],dk:[0,0,0,0,0,0],hov:-2,pull:0,lock:false,t0:this.win.performance.now()/1000,mx:px??X,my:py??Y});
    const root=d.createElement('div');root.className='ff-cu-wheel';root.innerHTML='<canvas class="ff-cu-wcv" aria-hidden="true"></canvas><div class="ff-cu-strip" role="group" aria-label="Curse wheel"></div><div class="ff-cu-bar" role="group" aria-label="Curse wheel: watch, edit, what is on her"></div>';d.body.appendChild(root);
    this.root=root;this.cv=root.querySelector('canvas');this.strip=root.querySelector('.ff-cu-strip');this.bar=root.querySelector('.ff-cu-bar');this.bar.style.left=X+'px';this.bar.style.top=(Y+WHEEL.cy-2)+'px';const dpr=Math.min(2,this.win.devicePixelRatio||1);
    this.cv.width=Math.round(WHEEL.w*dpr);this.cv.height=Math.round(WHEEL.h*dpr);this.cv.style.width=WHEEL.w+'px';this.cv.style.height=WHEEL.h+'px';this.cv.style.left=(X-WHEEL.cx)+'px';this.cv.style.top=(Y-WHEEL.cy)+'px';
    this.x=this.cv.getContext('2d');this.x.setTransform(dpr,0,0,dpr,0,0);this.art=curseArt(this.x);
    // the strip stands beside the wheel, clear of its labels: to its left, or to its right where that leaves more room for the names beside it
    const roomL=X-WHEEL.reach-STRIP_GAP.left-8,roomR=W-(X+WHEEL.reach+STRIP_GAP.right+64)-8,left=roomL>=190||roomL>=roomR;
    this.strip.style.left=(left?X-WHEEL.reach-STRIP_GAP.left:X+WHEEL.reach+STRIP_GAP.right)+'px';this.strip.classList.toggle('ff-cu-right',!left);this.fillStrip();
    {const r=this.strip.getBoundingClientRect?.(),h=r?.height||300;this.strip.style.top=Math.round(Math.max(8,Math.min(Hh-h-8,Y-h/2)))+'px';}
    const move=ev=>{S.mx=ev.clientX;S.my=ev.clientY;};
    const down=ev=>{if(this.strip.contains(ev.target)||this.bar.contains(ev.target))return;ev.preventDefault();ev.stopPropagation();if(ev.button!==0){this.close();return;}if(S.lock)return;const h=wheelSector(ev.clientX-S.x,ev.clientY-S.y);if(h===-2)this.close();else void this.choose(h);};
    const key=ev=>{if(ev.key!=='Escape')return;ev.preventDefault();ev.stopPropagation();ev.stopImmediatePropagation?.();this.close();};
    const stop=ev=>{ev.preventDefault();ev.stopPropagation();};
    root.addEventListener('pointermove',move);root.addEventListener('pointerdown',down);root.addEventListener('contextmenu',stop);root.addEventListener('wheel',stop,{passive:false});this.win.addEventListener('keydown',key,true);
    this.listeners=()=>this.win.removeEventListener('keydown',key,true);
    this.tween(260,v=>S.a=v,E.out);for(let i=0;i<6;i++)this.win.setTimeout(()=>{if(this.root===root)this.tween(300,v=>S.inn[i]=v,E.out);},i*30);
    const tick=ts=>{if(this.root!==root)return;this.frame=this.win.requestAnimationFrame(tick);
      for(const o of this.tw.slice()){const u=Math.min(1,(ts-o.t0)/o.ms);o.fn(o.ez(Math.max(0,u)));if(u>=1){this.tw.splice(this.tw.indexOf(o),1);o.res();}}
      this.draw(ts/1000);};
    this.frame=this.win.requestAnimationFrame(tick);
  }
  async close(){
    const root=this.root;if(!root||this.closing)return;this.closing=true;this.S.lock=true;root.classList.add('ff-cu-out');await this.tween(220,v=>this.S.a=Math.min(this.S.a,1-v),E.in);this.destroy(root);
  }
  destroy(root=this.root){
    if(!root)return;if(this.root===root){if(this.frame)this.win.cancelAnimationFrame(this.frame);this.frame=0;this.listeners?.();this.listeners=null;this.root=null;this.cv=null;this.x=null;this.art=null;this.strip=null;this.bar=null;this.tw=[];this.closing=false;}
    root.remove();
  }
  /** The person pinned, or null (the roll of faith). */
  pinned(){return this.people.find(p=>p.id===this.pin)??null;}
  save(){try{this.host.saveGm?.({die:this.die,pin:this.pin,watch:this.watch});}catch{}}
  /* ───────── the strip ───────── */
  fillStrip(){
    const s=this.strip;if(!s)return;const her=this.her;this.fillBar();
    const dot=(p,cls,label,inner='')=>`<button type="button" class="ff-cu-sp ${cls}" data-id="${esc(p?.id??'')}">${inner}<span>${esc(label)}</span></button>`;
    let h=`<div class="ff-cu-st">Cursed</div><button type="button" class="ff-cu-sp ff-cu-her${her?'':' ff-cu-none'}" data-act="her">${her&&!her.img?esc(her.name[0]):her?'':'?'}<span>${her?esc(her.name)+' · click to use the selected token instead':'Nobody yet: select her token, then click here'}</span></button>`;
    h+=`<div class="ff-cu-st ff-cu-rule">That<br>person</div>`+dot(null,'ff-cu-faith'+(this.pin?'':' ff-cu-pin'),this.pin?'Roll of faith':'Roll of faith · her roll finds who',FAITH_SVG);
    for(const p of this.people)h+=dot(p,'ff-cu-who'+(p.id===this.pin?' ff-cu-pin':''),p.n+(p.id===this.pin?' · pinned':''),p.img?'':esc(p.n[0]));
    h+=`<div class="ff-cu-st ff-cu-rule">Lasts</div><div class="ff-cu-dd">${CURSE_DICE.map(n=>`<button type="button" class="${n===this.die?'ff-cu-on':''}" data-die="${n}">1d${n}</button>`).join('')}</div>`;
    s.innerHTML=h;
    for(const b of s.querySelectorAll('.ff-cu-sp')){const id=b.dataset.id,p=this.people.find(q=>q.id===id);const who=b.classList.contains('ff-cu-her')?(her?{n:her.name,img:her.img}:null):p;
      if(who){const [c1,c2]=tintOf(who.n);b.style.setProperty('--c1',c1);b.style.setProperty('--c2',c2);if(who.img){b.style.backgroundImage=cssUrl(who.img);b.classList.add('ff-cu-pic');}}}
    if(!s.dataset.bound){s.dataset.bound='1';s.addEventListener('pointerdown',ev=>ev.stopPropagation());s.addEventListener('click',ev=>{const b=ev.target.closest?.('button');if(!b||!s.contains(b))return;ev.preventDefault();b.blur?.();this.stripAct(b);});}
  }
  /** The bar under the wheel: Watch · Edit the states · what is on her now, with −1 Span and Lift. */
  fillBar(){
    const b=this.bar;if(!b)return;const act=(()=>{try{return this.host.active?.()??null;}catch{return null;}})();
    let h=`<button type="button" class="ff-cu-tog${this.watch?' ff-cu-on':''}" data-act="watch" aria-pressed="${this.watch}" title="On: your own screen plays her view as she rolls (when her player is connected; otherwise it is shown here anyway)">Watch her roll<b>${this.watch?'On':'Off'}</b></button>`
      +'<button type="button" data-act="edit" title="Rename the six states, change the word after “You are made to”, and rewrite what each one says">Edit the states</button>';
    if(act?.k){const e=TAB[stateIndex(act.k)],n=spansLeft(act,this.host.now?.()??0);
      h+=`<span class="ff-cu-now" style="--ffcu-ac:rgb(${e.acc})">On her<b>${esc(e.n)}</b><i>${n===null?'not rooted':n+' '+spanWord(n)}</i></span>${n!==null&&n>0?'<button type="button" data-act="burn" title="One Span has passed">−1 Span</button>':''}<button type="button" data-act="lift" title="End the curse now">Lift</button>`;}
    else if(act)h+='<span class="ff-cu-now">On her<i>a roll is asked</i></span><button type="button" data-act="lift" title="Take the request back">Lift</button>';
    b.innerHTML=h;
    if(!b.dataset.bound){b.dataset.bound='1';b.addEventListener('pointerdown',ev=>ev.stopPropagation());b.addEventListener('click',ev=>{const t=ev.target.closest?.('button');if(!t||!b.contains(t))return;ev.preventDefault();t.blur?.();this.stripAct(t);});}
  }
  stripAct(b){
    const act=b.dataset.act;
    if(act==='watch'){this.watch=!this.watch;this.save();this.fillBar();return;}
    if(act==='edit'){const host=this.host;void this.close().then(()=>{try{host.edit?.();}catch{}});return;}
    if(act==='her'){let name=null;try{name=this.host.useSelected?.()??null;}catch{}if(name){this.her=this.host.her?.()??null;this.people=this.host.people?.()??[];if(this.pin&&!this.people.some(p=>p.id===this.pin))this.pin='';}this.fillStrip();return;}
    if(act==='lift'){try{this.host.lift?.();}catch{}this.win.setTimeout(()=>this.fillStrip(),120);return;}
    if(act==='burn'){try{this.host.burn?.();}catch{}this.win.setTimeout(()=>this.fillStrip(),120);return;}
    if(b.dataset.die){this.die=dieOf(+b.dataset.die);this.save();this.fillStrip();return;}
    if(b.classList.contains('ff-cu-faith')){this.pin='';this.save();this.fillStrip();return;}
    if(b.classList.contains('ff-cu-who')){this.pin=b.dataset.id===this.pin?'':b.dataset.id;this.save();this.fillStrip();}
  }
  /* ───────── a choice ───────── */
  /** h: 0 to 5 lays that state on her; -1 (the centre) lets her roll for it. */
  async choose(h){
    const S=this.S,root=this.root;if(!root||S.lock)return;const pin=this.pinned();
    let out=null;try{out=await this.host.send({state:h>=0?h:null,toward:pin,people:this.people,die:this.die});}catch(e){out={ok:false,why:String(e?.message??e)};}
    if(this.root!==root)return;
    if(!out?.ok){this.note(out?.why||'Nothing was sent.','',null,true);return;}
    S.lock=true;S.hov=h;if(h>=0){this.stats.laid++;for(let j=0;j<6;j++)if(j!==h)this.tween(240,v=>S.inn[j]=Math.min(S.inn[j],1-v),E.in);await this.tween(200,v=>S.pull=v,E.out);await new Promise(r=>this.win.setTimeout(r,140));}else this.stats.asked++;
    const who=h>=0&&!namesSomeone(TAB[h].k)?'all within 15 ft':pin?`toward ${pin.n}`:this.people.length?'toward the roll of faith':'toward no one named',name=out.name||'her';
    // (with no player of hers connected it is shown on this very page: that is its own confirmation)
    // (nothing to add when this page shows it itself, or watches it)
    if(!out.local&&!out.watching)this.note(h>=0?`${TAB[h].n} — laid on ${name}`:`Roll sent to ${name}`,`${who} · 1d${this.die} Spans`,h>=0?TAB[h].acc:null);
    root.classList.add('ff-cu-out');await this.tween(h>=0?320:260,v=>{S.a=Math.min(S.a,1-v);if(h>=0)S.inn[h]=Math.min(S.inn[h],1-v);},E.in);this.destroy(root);
  }
  /** A small confirmation where the wheel was (it goes by itself). */
  note(title,line,acc=null,bad=false){
    const d=this.doc,c=d.createElement('div');c.className='ff-cu-chip'+(bad?' ff-cu-bad':'');c.style.setProperty('--ffcu-ac',acc?`rgb(${acc})`:'#ff78f6');
    c.innerHTML=`<svg class="ff-cu-gem" width="16" height="24" viewBox="-8 -11 16 24" aria-hidden="true"><path d="M0-10 5 0 0 12-5 0Z" fill="#120c10" stroke="#5a4650"/><path class="ff-cu-core" d="M0-3 1.6 0 0 4-1.6 0Z"/></svg><div><div class="ff-cu-n">${esc(title)}</div>${line?`<div class="ff-cu-m">${esc(line)}</div>`:''}</div>`;
    const W=this.win.innerWidth||1280;c.style.left=Math.max(8,Math.min(W-380,this.S.x+34))+'px';c.style.top=Math.max(8,this.S.y-22)+'px';d.body.appendChild(c);void c.offsetWidth;c.classList.add('ff-cu-on');
    this.win.setTimeout(()=>{c.classList.remove('ff-cu-on');this.win.setTimeout(()=>c.remove(),600);},bad?3200:2400);return c;
  }
  /* ───────── one frame ───────── */
  draw(t){
    const x=this.x,S=this.S;if(!x)return;const {path,light,briar,thorn,glow,txt,eyebrow,sigil}=this.art,X=WHEEL.cx,Y=WHEEL.cy,a0=S.a,dt=Math.min(.05,Math.max(.001,t-(this.lastT||t)));this.lastT=t;const sm=r=>1-Math.pow(1-r,dt*30);
    if(!S.lock){const over=this.strip&&this.doc.elementFromPoint?.(S.mx,S.my),on=over&&(this.strip.contains(over)||this.bar?.contains(over));S.hov=on?-2:wheelSector(S.mx-S.x,S.my-S.y);if(this.cv)this.cv.style.cursor=S.hov>=-1&&!on?'pointer':'';}
    x.clearRect(0,0,WHEEL.w,WHEEL.h);if(a0<.01)return;
    const g=x.createRadialGradient(X,Y,20,X,Y,300);g.addColorStop(0,`rgba(8,5,9,${.93*a0})`);g.addColorStop(.74,`rgba(8,5,9,${.86*a0})`);g.addColorStop(1,'rgba(8,5,9,0)');x.fillStyle=g;x.beginPath();x.arc(X,Y,300,0,TAU);x.fill();
    const hov=S.hov,tt=t-S.t0;
    for(let i=0;i<6;i++){const e=TAB[i],an=-PI/2+i*PI/3,dx=Math.cos(an),dy=Math.sin(an),hv=hov===i,inn=S.inn[i];S.dk[i]+=((hv?1:0)-S.dk[i])*sm(.14);const dk=S.dk[i],dim=(hov>=0&&!hv)?.42:1,n=30,P=[],ext=hv?S.pull*16:0;
      for(let j=0;j<=n;j++){const u=j/n,r=24+(128+ext)*u*inn,vb=4*Math.sin(PI*u)*Math.cos(tt*21+i*2)*Math.exp(-tt*3.2)+(hv?.9*Math.sin(t*33+u*9)*Math.sin(PI*u):0);P.push([X+dx*r-dy*vb,Y+dy*r+dx*vb]);}
      x.save();x.globalAlpha=a0;const i0=Math.round(n*dk);if(i0<n)light(P.slice(i0),dim,0);
      if(i0>0){path(P.slice(0,i0+1));x.strokeStyle=`rgba(${EMB},.3)`;x.lineWidth=11;x.stroke();briar(P.slice(0,i0+1),1,.9);for(let j=3;j<i0;j+=4){const a=Math.atan2(P[j+1][1]-P[j-1][1],P[j+1][0]-P[j-1][0]);thorn(P[j][0],P[j][1],a+((j>>2)%2?1:-1)*(PI/2-.4),9);}if(dk<.98)glow(P[i0][0],P[i0][1],16,.7,EMB);}
      sigil(e.k,X+dx*(172+ext),Y+dy*(172+ext),13,inn*(hv?1:.7*dim),hv?e.acc:BONE);const lx=X+dx*(200+ext),ly=Y+dy*(200+ext),al=Math.abs(dx)<.3?'center':dx>0?'left':'right';
      const lab=(i+1)+'  '+e.n,room=al==='center'?260:STRIP_GAP.label;let px=hv?20:17;x.font=F.caps(px);x.letterSpacing='2px';const lw=x.measureText(lab).width;if(lw>room)px*=room/lw;
      txt(lab,lx+(al==='left'?4:al==='right'?-4:0),ly+(al==='center'?(dy<0?-4:16):6),F.caps(px),2,BONE,inn*(hv?1:.66*dim),al);x.restore();}
    x.save();x.globalAlpha=a0;x.fillStyle='rgba(13,9,11,1)';x.beginPath();x.arc(X,Y,7,0,TAU);x.fill();x.strokeStyle='rgba(112,84,100,.9)';x.lineWidth=1;x.stroke();glow(X,Y,hov===-1?30:hov<0?22:14,hov===-1?.7:hov<0?.45:.3,hov<0?MAG:EMB);
    const e=hov>=0?TAB[hov]:null,pin=this.pinned(),name=this.her?.name??'';
    if(!this.her)txt('NOBODY IS CHOSEN TO CURSE YET',X,Y+262,F.sans(10),2.8,'255,150,248',1);
    else if(e)eyebrow(`Lay on ${name}:`,e.n,e.acc,X,Y+262,1);else txt(`LET ${name.toUpperCase()} ROLL FOR IT`,X,Y+262,F.sans(10),2.8,'255,150,248',hov===-1?1:.72);
    const who=e&&!namesSomeone(e.k)?'all within 15 ft':pin?`toward ${pin.n} · pinned`:this.people.length?'toward whoever the roll of faith finds':'toward no one named';
    txt(this.her?`${who}  ·  1d${this.die} Spans`:'Select her token, then click the top of the strip',X,Y+282,F.ital(14),0,BONE,.7);x.restore();
  }
}
