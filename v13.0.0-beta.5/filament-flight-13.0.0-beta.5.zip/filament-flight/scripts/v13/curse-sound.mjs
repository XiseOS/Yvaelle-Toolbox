/** Yvaelle’s Toolbox v13 · The Heart Turned: what her full view sounds like (13.0.0-beta.4).
 *
 * Off as it comes (Settings › Her › Moods & milestones › The Heart Turned › Sound). The stage (curse-stage.mjs) raises a
 * named cue at each moment that has a sound; this file says which recording that is, how loud and at what speed, and
 * keeps the two loops under it. Nothing here is drawn, written or sent: each page that shows the view (her own, a GM's
 * who watches) plays it for itself, if its own switch is on.
 *
 *   the recordings   assets/audio/curse/<name>.ogg, cut from generated takes by tools/audio/import_v13_pack.py. Quiet, dark
 *                    and set in a room: a wind moaning low in a hollow place, far creaks, a sigh when something is let
 *                    go. High-passed so that none of them thumps, and nothing in them is a tune
 *   the bed          the wind. The stage says how much of it there is (bed {to, ms}): a little while her emblem draws
 *                    itself, rising all through her roll, and gone in the moment it holds still before the last one
 *                    (hush {ms}), so that the silence comes before the cut
 *   one shots        everything else, each ringing on in its room. The same recording is never played twice quite
 *                    alike: its speed follows what the cue says (which filament, how hard the pull, how late in the roll)
 *
 * The player is plain logic over a small audio back end, so the tests and the audition tool run the very same rules
 * with a back end that only writes down what would have been played (tools/v13/sound-sim.mjs). */

/** Every recording there is: assets/audio/curse/<name>.ogg. */
export const CURSE_SOUND_FILES=Object.freeze(['bed','creepbed','veil','filament','briar','snap','tick','strain','release','cut','round','prowl','root','lurch','close','notch','cinch',
  'take','ash','sear','turn','scorch','bead','beadstop','thorn','set','fold','open','strike','drain']);
/** How many of one recording may sound at once (each rings on in its room for a second or two, so a run of them overlaps). Everything else: two. */
export const CURSE_VOICES=Object.freeze({tick:6,bead:6,scorch:5,filament:6,lurch:5,root:6,drain:5,thorn:6,notch:5,prowl:4,strain:3,cut:3});
export const CURSE_VOLUMES=Object.freeze({faint:.12,quiet:.3,soft:.6,normal:1,loud:1.6});
/** From quietest to loudest (the full view's own control steps through these; below the first is off). */
export const CURSE_VOLUME_ORDER=Object.freeze(['faint','quiet','soft','normal','loud']);

const cl=(v,a=0,b=1)=>Math.min(b,Math.max(a,v)),num=(v,d)=>Number.isFinite(v)?v:d;
/** cue → {f: recording, v: volume, r: speed, gap: the least time (ms) between two of them, when: (detail) → is this one heard at all}.
 * v and r may read the cue's detail. Everything is quiet: the loudest moments (a cut, the noose's bite, her heart turning) sit
 * well under a click of Foundry's own, and the many small ones (it is on this one, a bead, a letter) are barely there. */
export const CURSE_SHOTS=Object.freeze({
  veil:{f:'veil',v:.5},
  filament:{f:'filament',v:.28,r:d=>.9+.05*num(d?.i,0),gap:60},
  briar:{f:'briar',v:.45},
  press:{f:'snap',v:d=>.5*num(d?.v,1)},
  on:{f:'tick',v:d=>.22*num(d?.v,1),r:d=>.96+.02*num(d?.i,0),gap:110},
  strain:{f:'strain',v:d=>d?.last?.5:.2+.2*num(d?.v,.5),r:d=>d?.last?1.06:.92+.12*num(d?.v,.5)},
  // (every creak ends in a snap: a small one when it lets go, a cut when one is cut away, and the one that takes her)
  release:{f:'release',v:.34},
  cut:{f:'cut',v:d=>.55*num(d?.v,1),r:d=>1.03-.015*num(d?.i,2)},
  round:{f:'round',v:.35},
  prowl:{f:'prowl',v:d=>.16+.16*num(d?.v,.5),r:d=>cl(740/num(d?.ms,740),.8,1.25)},
  root:{f:'root',v:.3,r:d=>.95+.03*num(d?.i,0)},
  latch:{f:'root',v:.22,r:d=>1.12+.03*num(d?.i,0)},
  lurch:{f:'lurch',v:d=>d?.last?.45:.14+.2*num(d?.v,.5),r:d=>d?.last?.92:1.08-.12*num(d?.v,.5),gap:110},
  close:{f:'close',v:.4},
  notch:{f:'notch',v:d=>.2+.2*num(d?.v,0),r:d=>1+.2*num(d?.v,0)},
  cinch:{f:'cinch',v:.6},
  take:{f:'take',v:.7},
  // (reimagined) what the picture does now has a sound of its own: a petal withering where it was cut, the thorns coming in
  // from the window's edges, and the view going in to her heart
  wither:{f:'root',v:.2,r:d=>.72+.03*num(d?.i,0)},
  edge:{f:'strain',v:d=>.14+.1*num(d?.v,.5),r:d=>.78-.1*num(d?.v,.5),gap:600},
  push:{f:'round',v:.42,r:d=>cl(1150/num(d?.ms,1500),.6,.9)},
  ash:{f:'ash',v:.35},
  sear:{f:'sear',v:.42},
  turn:{f:'turn',v:.6},
  bead:{f:'bead',v:d=>.14+.06*num(d?.v,0),r:d=>1.1-.18*num(d?.v,0),gap:60},
  beadStop:{f:'beadstop',v:d=>.4*num(d?.v,1)},
  // (the word is cursed letter by letter: every other letter is heard, or it chatters)
  scorch:{f:'scorch',v:.16,r:d=>1.05-.15*(num(d?.i,0)/Math.max(1,num(d?.n,1))),gap:80,when:d=>num(d?.i,0)%2===0},
  thorn:{f:'thorn',v:.32,r:d=>1.04-.04*(num(d?.i,1)-1)},
  set:{f:'set',v:.4},
  fold:{f:'fold',v:d=>.32*num(d?.v,1)},
  open:{f:'open',v:.32},
  strike:{f:'strike',v:.55},
  drain:{f:'drain',v:.3,r:d=>1-.08*num(d?.v,0)}
});
/** The two loops: the cue that drives each, its recording and its volume when the stage asks for all of it. */
export const CURSE_LOOPS=Object.freeze({bed:{f:'bed',v:.55},creep:{f:'creepbed',v:.5}});
/** Cues the stage raises that are deliberately silent (the picture fading to the result). */
export const CURSE_SILENT=Object.freeze(['out']);
/** Is this a cue the player knows what to do with? (The stage's own list is checked against this in the tests.) */
export const knowsCue=name=>name==='stop'||name==='hush'||name in CURSE_SHOTS||name in CURSE_LOOPS||CURSE_SILENT.includes(name);
const val=(x,d,dflt)=>typeof x==='function'?x(d):x??dflt;
/** What one cue asks for, as plain data: {f, volume, rate, gap} for a one shot, else null. */
export function shotFor(name,detail=null){
  const s=CURSE_SHOTS[name];if(!s||(s.when&&!s.when(detail)))return null;
  return {f:s.f,volume:cl(val(s.v,detail,.4),0,1),rate:cl(val(s.r,detail,1),.5,2),gap:s.gap??0};
}

/** The player.
 *   audio   the back end: {ready(f), shot(f, volume, rate, voices), loop(f, volume, rate) → {aim(to, tau, {at, keep}), rate(r, tau), stop(ms)}, stopAll(ms), warm()}
 *   on      () → is the sound switched on on this page   ·   bed: () → is the bed   ·   level: () → the page's own volume (1 = as made)
 *   now     () → ms (for the least gap between two of the same) */
export function createCurseSound({audio,on=()=>true,bed=()=>true,level=()=>1,now=()=>globalThis.performance?.now?.()??Date.now()}={}){
  const loops={bed:null,creep:null},last=new Map(),stats={cues:0,shots:0,skipped:0,loops:0,unknown:0};let sounding=false;
  const lv=()=>cl(num(level(),1),0,2.5);
  const endLoop=(id,ms)=>{const L=loops[id];if(!L)return;loops[id]=null;try{L.h.aim(0,Math.max(.02,ms/3000));L.h.stop(ms+250);}catch{}};
  function loopTo(id,to,ms){
    const spec=CURSE_LOOPS[id];to=cl(num(to,0));ms=Math.max(60,num(ms,600));
    if(to<=.001){endLoop(id,ms);return;}
    if(id==='bed'&&!bed()){endLoop(id,200);return;}
    const vol=spec.v*to*lv(),rate=id==='bed'?.95+.1*to:1;let L=loops[id];
    if(!L){if(!audio.ready(spec.f)){stats.skipped++;return;}const h=audio.loop(spec.f,0,rate);if(!h){stats.skipped++;return;}L=loops[id]={h,vol:0};stats.loops++;sounding=true;}
    L.vol=vol;try{L.h.aim(vol,ms/3000);L.h.rate?.(rate,ms/3000);}catch{}
  }
  /** The moment it holds still: both loops drop away at once and come back when it moves again. */
  function hush(ms){
    ms=Math.max(80,num(ms,400));
    for(const id of ['bed','creep']){const L=loops[id];if(!L)continue;try{L.h.aim(L.vol*.05,.03);L.h.aim(L.vol,.09,{at:ms/1000,keep:true});}catch{}}
  }
  function stop(ms=160){
    for(const id of ['bed','creep'])endLoop(id,ms);last.clear();
    if(sounding){sounding=false;try{audio.stopAll(ms);}catch{}}
  }
  function cue(name,detail=null){
    stats.cues++;
    if(name==='stop'){stop();return false;}
    if(!on()){if(sounding||loops.bed||loops.creep)stop();return false;}
    if(name==='bed'){loopTo('bed',detail?.to,detail?.ms);return true;}
    if(name==='creep'){loopTo('creep',detail?.on?1:0,detail?.on?500:420);return true;}
    if(name==='hush'){hush(detail?.ms);return true;}
    const s=shotFor(name,detail);if(!s){if(!(name in CURSE_SHOTS)&&!CURSE_SILENT.includes(name))stats.unknown++;return false;}
    const t=now();if(s.gap&&t-(last.get(name)??-1e9)<s.gap){stats.skipped++;return false;}
    if(!audio.ready(s.f)){stats.skipped++;return false;}
    last.set(name,t);const ok=audio.shot(s.f,cl(s.volume*lv(),0,1),s.rate,CURSE_VOICES[s.f]??2)!==false;if(ok){stats.shots++;sounding=true;}else stats.skipped++;return ok;
  }
  /** Fetch and decode the recordings now, so that the first cue of a curse is not late. → the names that would not load. */
  const warm=()=>{try{return Promise.resolve(audio.warm?.()??[]);}catch(e){return Promise.reject(e);}};
  return {cue,stop,warm,hear:(name,detail=null)=>{const s=shotFor(name,detail);if(!s||!audio.ready(s.f))return false;return audio.shot(s.f,cl(s.volume*lv(),0,1),s.rate,CURSE_VOICES[s.f]??2)!==false;},
    stats,status:()=>({bed:loops.bed?loops.bed.vol:0,creep:loops.creep?loops.creep.vol:0,sounding,...stats})};
}

/** The back end in Foundry: its own Sound class (so the core volume sliders and the first-gesture unlock apply), in the
 * interface context (this is a view over the game, not a sound in the scene), each recording decoded once.
 *   base     the folder of the recordings   ·   trouble: (where, error) → kept for the module's own check */
export function foundryCurseAudio({base,files=CURSE_SOUND_FILES,Sound=null,trouble=null,game=()=>globalThis.game}={}){
  const pools=new Map(),live=new Set(),until=new WeakMap(),failed=new Set(),clock=()=>globalThis.performance?.now?.()??Date.now();let warming=null;
  const Type=()=>Sound??globalThis.foundry?.audio?.Sound,ctx=()=>{const a=game()?.audio;return a?.interface??a?.environment;};
  const src=f=>`${base}/${f}.ogg`,locked=()=>!!game()?.audio?.locked;
  const make=async f=>{const T=Type();if(!T)throw new Error('Foundry audio is not ready.');const s=new T(src(f),{context:ctx()});await s.load();return s;};
  const quiet=p=>{try{Promise.resolve(p).catch(()=>{});}catch{}};
  const halt=(s,ms=0)=>{try{s?.unscheduleAll?.();quiet(s?.stop?.({fade:ms}));}catch{}};
  const setRate=(s,r,tau=0)=>{try{const n=s?.sourceNode,p=n?.playbackRate,t=s?.context?.currentTime;
    if(p&&tau>0&&p.setTargetAtTime&&Number.isFinite(t)){p.cancelScheduledValues(t);p.setTargetAtTime(r,t,tau);}else if(p)p.value=r;else if(n?.mediaElement){n.mediaElement.preservesPitch=false;n.mediaElement.playbackRate=r;}}catch{}};
  function warm(){
    return warming??=(async()=>{
      await Promise.all(files.map(async f=>{if(pools.has(f))return;try{pools.set(f,[await make(f)]);failed.delete(f);}catch(e){failed.add(f);try{trouble?.('loading the sound '+f,e);}catch{}}}));
      const bad=[...failed];if(bad.length)warming=null;return bad;
    })();
  }
  const start=(s,f,volume,rate)=>{
    until.set(s,clock()+Math.min(6000,1000*(Number.isFinite(s.duration)?s.duration:1)/Math.max(.5,rate)));
    try{const p=s.play({volume,loop:false,fade:0});if(Math.abs(rate-1)>.004){setRate(s,rate);Promise.resolve(p).then(()=>setRate(s,rate)).catch(()=>{});}else quiet(p);live.add(s);return true;}
    catch(e){try{trouble?.('playing the sound '+f,e);}catch{}return false;}
  };
  /** A one shot. voices: how many of this recording may ring at once: a free one is used, else one more is made (its
   * data is already decoded), else the oldest is taken. */
  function shot(f,volume,rate,voices=2){
    const pool=pools.get(f);if(!pool?.length||locked())return false;const t=clock();
    // (a Sound that was told to play a moment ago may not say it is playing yet: its own end time is kept as well)
    let s=pool.find(q=>typeof q.play==='function'&&!q.playing&&(until.get(q)??0)<=t);if(s)return start(s,f,volume,rate);
    if(pool.length<voices){const hold={};pool.push(hold);make(f).then(n=>{const i=pool.indexOf(hold);if(i>=0)pool[i]=n;else pool.push(n);if(!locked())start(n,f,volume,rate);}).catch(e=>{const i=pool.indexOf(hold);if(i>=0)pool.splice(i,1);try{trouble?.('playing the sound '+f,e);}catch{}});return true;}
    s=pool.find(q=>typeof q.play==='function');if(!s)return false;pool.splice(pool.indexOf(s),1);pool.push(s);halt(s);return start(s,f,volume,rate);
  }
  function loop(f,volume,rate=1){
    const pool=pools.get(f);if(!pool?.length||locked())return null;
    const h={s:null,dead:false,pend:[]};const run=fn=>{if(h.dead)return;if(h.s)fn(h.s);else h.pend.push(fn);};
    // (a loop gets a Sound of its own each time: the one before may still be fading out)
    void(async()=>{try{const s=await make(f);if(h.dead)return;await s.play({volume,loop:true,fade:0});if(h.dead){halt(s);return;}h.s=s;live.add(s);if(Math.abs(rate-1)>.004)setRate(s,rate);for(const fn of h.pend.splice(0))fn(s);}
      catch(e){try{trouble?.('playing the sound '+f,e);}catch{}}})();
    return {
      aim:(to,tau,{at=0,keep=false}={})=>run(s=>{try{const p=s.gain,t=s.context?.currentTime;
        if(p?.setTargetAtTime&&Number.isFinite(t)){if(!keep)p.cancelScheduledValues(t);p.setTargetAtTime(to,t+at,Math.max(.012,tau));}
        else if(at>0)globalThis.setTimeout?.(()=>{if(!h.dead)quiet(s.fade?.(to,{duration:tau*3000}));},at*1000);else quiet(s.fade?.(to,{duration:tau*3000}));}catch{}}),
      rate:(r,tau)=>run(s=>setRate(s,r,tau)),
      stop:(ms=0)=>{if(h.dead)return;const s=h.s;h.dead=true;if(s){halt(s,ms);live.delete(s);}}
    };
  }
  function stopAll(ms=0){for(const s of [...live]){if(s.playing)halt(s,ms);live.delete(s);}}
  return {ready:f=>!!pools.get(f)?.length,shot,loop,stopAll,warm,failed:()=>[...failed],loaded:()=>[...pools.keys()],voices:f=>pools.get(f)?.length??0,src};
}
