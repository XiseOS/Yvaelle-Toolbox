import {SCAN_METHOD_CATALOG} from './v84-scan-methods.mjs?v=13.0.0-beta.5';
import {compileScanPlan,sampleBitTool} from './v8-scan-choreography.mjs?v=13.0.0-beta.5';
import {paintScanArtwork} from './v8-scan-art.mjs?v=13.0.0-beta.5';
import {paintResonantBit,sampleBitResonance} from './bit-resonance.mjs?v=13.0.0-beta.5';
import {TokenScanMaskCache} from './v83-token-scan-mask.mjs?v=13.0.0-beta.5';

const IDS=['leftUpper','rightUpper','leftLower','rightLower'],WIDTH=96,HEIGHT=144;
const COLOR='#ff62df',HOVER_INTENT=160,FRAME_INTERVAL=1000/24;
let nextId=0;
const templates=new Map();
const rect=(x,y,w,h)=>[{x,y},{x:x+w,y},{x:x+w,y:y+h},{x,y:y+h}];
function template(group,method){
  if(!SCAN_METHOD_CATALOG[group]?.some(choice=>choice.id===method))throw new Error('Unknown scanning style.');
  const key=`${group}:${method}`;if(templates.has(key))return templates.get(key);
  const creature=group==='creature',center={x:0,y:0},radius=creature?HEIGHT*.94:170;
  const cells=Array.from({length:4},(_,i)=>{const row=Math.floor(i/2),col=i%2,x=(col-1)*100,y=(row-1)*100;return{id:`preview:${row}:${col}`,offset:{i:row,j:col},center:{x:x+50,y:y+50},bounds:{x,y,width:100,height:100},polygon:rect(x,y,100,100)};});
  const utility={mode:creature?'creatureScan':'areaScan',center,radiusPixels:radius,seed:'scan-style-preview-881',scanSpeed:.6,scanMethods:{[group]:[method]},examinationMovement:'deliberate',...(!creature?{region:{type:'polygon',points:rect(-100,-100,200,200)}}:{})};
  const event={id:`style-preview:${key}`,kind:'utility',bits:IDS,formationBits:IDS,started:0,travelDuration:900,utility};
  const context={source:{x:-210,y:0},target:center,size:100,targetSize:100,targetWidth:WIDTH,targetHeight:HEIGHT,targetRotation:0,transform:{angle:0},orientations:{},origins:{},snapshot:{gems:{color:COLOR},effective:{reducedMotion:false}},...(!creature?{gridScan:{cells}}:{})};
  const targetBounds=creature?{halfWidth:WIDTH/radius*50,halfHeight:HEIGHT/radius*50}:undefined;
  const plan=compileScanPlan(utility,IDS,{center,radius,size:100,targetBounds,gridScan:context.gridScan});
  const visit=plan.routes[0].visits.find(v=>v.scan>0&&(!creature||v.scanStage==='close'));
  const result={event,context,visit};templates.set(key,result);return result;
}

/** Isolated production sampler: enter the chosen optical exposure immediately,
 * with one identical fixture for each family and no scene/document access. */
export function createScanStylePreviewFrame(group,method,elapsed=0,{reducedMotion=false}={}){
  const {event,context,visit}=template(group,method),period=visit.scan/.6;
  const q=reducedMotion?.48:((Math.max(0,elapsed)+period*.35)%period)/period;
  const time=event.travelDuration+(visit.at+visit.travel+visit.settle+visit.scan*q)/.6;
  // Reduced motion holds a real readable exposure instead of changing the
  // sampler's animation mode (which can also alter the represented stage).
  const sample=sampleBitTool(event,time,context);
  if(group==='creature')sample.effects=sample.effects.map(effect=>({...effect,channels:effect.channels.filter(channel=>channel.scanStage==='close')})).filter(effect=>effect.channels.length);
  return {group,method,event,context,sample,time,period,progress:q,reducedMotion};
}

/** Local transparent humanoid fixture. It never loads an image or borrows a
 * scene token. Its native alpha passes through the same cache as live scans. */
export function createScanStylePreviewResources(document){
  const portrait=document.createElement('canvas');portrait.width=WIDTH;portrait.height=HEIGHT;
  const ctx=portrait.getContext('2d');if(!ctx)throw new Error('Canvas previews are unavailable.');
  const gradient=ctx.createLinearGradient(0,18,0,HEIGHT);gradient.addColorStop(0,'#777185');gradient.addColorStop(.55,'#4a405b');gradient.addColorStop(1,'#292537');
  ctx.fillStyle=gradient;ctx.beginPath();ctx.moveTo(36,48);ctx.bezierCurveTo(15,55,20,85,9,111);ctx.lineTo(22,116);ctx.lineTo(27,94);ctx.lineTo(22,139);ctx.quadraticCurveTo(48,147,74,139);ctx.lineTo(69,94);ctx.lineTo(74,116);ctx.lineTo(87,111);ctx.bezierCurveTo(76,85,81,55,60,48);ctx.closePath();ctx.fill();
  ctx.fillStyle='#aaa0ad';ctx.beginPath();ctx.ellipse(48,29,16,21,0,0,Math.PI*2);ctx.fill();ctx.fillRect(41,44,14,12);
  ctx.fillStyle='#47384f';ctx.beginPath();ctx.moveTo(31,29);ctx.bezierCurveTo(27,2,68,0,65,34);ctx.lineTo(59,17);ctx.quadraticCurveTo(45,21,34,15);ctx.closePath();ctx.fill();
  ctx.strokeStyle='#b4a0b9';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(30,65);ctx.lineTo(42,92);ctx.lineTo(38,129);ctx.moveTo(66,65);ctx.lineTo(54,92);ctx.lineTo(58,129);ctx.moveTo(36,59);ctx.quadraticCurveTo(48,69,60,59);ctx.stroke();
  const token={center:{x:0,y:0},w:WIDTH,h:HEIGHT,mesh:{x:0,y:0,width:WIDTH,height:HEIGHT,rotation:0,scale:{x:1,y:1},anchor:{x:.5,y:.5},texture:{orig:{x:0,y:0,width:WIDTH,height:HEIGHT},frame:{x:0,y:0,width:WIDTH,height:HEIGHT},baseTexture:{valid:true,resolution:1,resource:{source:portrait}}}}};
  const masks=new TokenScanMaskCache({document,limit:1,maxSize:256});
  return {portrait,token,masks,destroy(){masks.destroy();portrait.width=portrait.height=1;}};
}

/** Paint the exact sampled artwork and metal instruments; UI dressing stays
 * outside the optical field. Resources are reused for the whole popover. */
export function paintScanStylePreview(ctx,frame,{width=ctx.canvas.width,height=ctx.canvas.height,resources}={}){
  const {sample,group,time}=frame,creature=group==='creature',size=100;
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,width,height);ctx.fillStyle='#10101a';ctx.fillRect(0,0,width,height);
  const scale=Math.min(width,height)/280;ctx.translate(width/2,height/2);ctx.scale(scale,scale);
  if(!creature){ctx.strokeStyle='#67566c';ctx.globalAlpha=.17;ctx.lineWidth=.8;ctx.beginPath();for(let n=-200;n<=200;n+=100){ctx.moveTo(n,-200);ctx.lineTo(n,200);ctx.moveTo(-200,n);ctx.lineTo(200,n);}ctx.stroke();ctx.globalAlpha=1;}
  else if(resources){ctx.globalAlpha=.74;ctx.drawImage(resources.portrait,-WIDTH/2,-HEIGHT/2);ctx.globalAlpha=1;}
  const artScale=(sample.effectScale??1)*size/100,anchor=sample.effectCenter??{x:0,y:0};
  const mask=creature?resources?.masks.get(resources.token,{center:anchor,rotation:sample.effectRotation??0,scale:artScale,primary:null}):undefined;
  const paint=plane=>{for(const effect of sample.effects??[]){ctx.save();ctx.translate(anchor.x,anchor.y);ctx.rotate(sample.effectRotation??0);ctx.scale(artScale,artScale);paintScanArtwork(ctx,effect,{plane,quality:'standard',tokenMask:mask});ctx.restore();}};
  paint('rear');
  for(const [index,id]of IDS.entries()){
    const p=sample.positions?.[id];if(!p)continue;
    const flight={gems:{strength:.65,program:'poised',design:'vanes',assetStates:true,mechanicalResponse:true,color:COLOR},bitActivity:sample.coreStates?.[id]??null};
    const resonance=sampleBitResonance({flight,channels:{},side:id.startsWith('left')?-1:1,index:index>1?1:0,time:time/1000,deployment:1,animated:!frame.reducedMotion});
    paintResonantBit(ctx,{points:[[p.x,p.y]],strength:1,hardware:{artwork:'resonant',design:'vanes',angle:sample.rotations?.[id]??0,scale:.56,power:1,resonance,glow:{strength:.25,color:COLOR,direction:[0,-1]},glowMode:'core',tool:sample.tools?.[id],metalHighlights:true,highlightStrength:.45}});
  }
  paint('front');ctx.restore();return sample;
}

/** One noninteractive private tooltip per tools popover. Hover/focus owns no
 * task API, scene data, audio, network operation or saved preference. */
export class ScanStyleHoverPreview{
  constructor({root,canOpen=()=>true,reducedMotion=()=>false}){
    this.root=root;this.doc=root.ownerDocument;this.view=this.doc.defaultView;this.canOpen=canOpen;this.reducedMotion=reducedMotion;this.events=new this.view.AbortController();const {signal}=this.events;
    const popup=this.doc.createElement('aside');popup.className='ff-v881-scan-preview';popup.hidden=true;popup.dataset.scanPreview='';popup.id=`ff-scan-style-preview-${++nextId}`;popup.setAttribute('role','tooltip');popup.setAttribute('popover','manual');
    this.popup=popup;this.title=this.doc.createElement('strong');this.title.dataset.scanPreviewTitle='';this.description=this.doc.createElement('p');this.description.dataset.scanPreviewDescription='';this.canvas=this.doc.createElement('canvas');this.canvas.width=this.canvas.height=336;this.canvas.dataset.scanPreviewCanvas='';this.canvas.setAttribute('aria-hidden','true');const hint=this.doc.createElement('small');hint.textContent='Private preview · hover or focus · not applied';popup.append(this.title,this.description,this.canvas,hint);
    const style=this.view.getComputedStyle(root);for(const key of ['--ff-bg','--ff-panel','--ff-accent','--ff-focus','--ff-text','--ff-gold','--ff-muted','--ff-line'])popup.style.setProperty(key,style.getPropertyValue(key));
    this.doc.body.append(popup);
    const row=target=>target?.closest?.('.ff-v84-scan-style');
    root.addEventListener('pointerover',event=>{if(event.pointerType==='touch')return;const choice=row(event.target);if(choice&&root.contains(choice)&&!choice.contains(event.relatedTarget)){if(this.opened&&choice===this.anchor)this.cancelHide();else this.schedule(choice);}},{signal});
    root.addEventListener('pointerout',event=>{const choice=row(event.target);if(choice&&choice===this.anchor&&!choice.contains(event.relatedTarget)&&!popup.contains(event.relatedTarget))this.scheduleHide();},{signal});
    popup.addEventListener('pointerenter',()=>this.cancelHide(),{signal});
    popup.addEventListener('pointerover',()=>this.cancelHide(),{signal});
    popup.addEventListener('pointerleave',event=>{if(!this.anchor?.contains(event.relatedTarget))this.scheduleHide();},{signal});
    popup.addEventListener('pointerout',event=>{if(!popup.contains(event.relatedTarget)&&!this.anchor?.contains(event.relatedTarget))this.scheduleHide();},{signal});
    root.addEventListener('focusin',event=>{const choice=row(event.target);if(choice&&root.contains(choice))this.show(choice);},{signal});
    root.addEventListener('focusout',event=>{if(row(event.target)===this.anchor&&!this.anchor?.contains(event.relatedTarget))this.hide();},{signal});
    this.doc.addEventListener('scroll',()=>this.hide(),{capture:true,passive:true,signal});
    root.addEventListener('toggle',event=>{if(event.target.tagName==='DETAILS'&&!event.target.open)this.hide();},{capture:true,signal});
    root.addEventListener('click',event=>{if(event.target.closest?.('summary'))this.hide();},{capture:true,signal});
    this.doc.addEventListener('visibilitychange',()=>{if(this.doc.hidden)this.hide();},{signal});
    this.view.addEventListener('resize',()=>this.hide(),{passive:true,signal});this.view.addEventListener('blur',()=>this.hide(),{signal});
  }
  schedule(anchor){this.hide();this.anchor=anchor;this.intent=this.view.setTimeout(()=>{this.intent=null;this.show(anchor);},HOVER_INTENT);}
  scheduleHide(){this.cancelHide();this.hideTimer=this.view.setTimeout(()=>{this.hideTimer=null;this.hide();},85);}
  cancelHide(){if(this.hideTimer!=null)this.view.clearTimeout(this.hideTimer);this.hideTimer=null;}
  show(anchor){
    if(this.destroyed||!this.root.isConnected||!this.canOpen()||this.doc.hidden||!this.root.contains(anchor)||anchor.closest('details:not([open])')){this.hide();return;}
    if(this.opened&&anchor===this.anchor){this.cancelHide();return;}
    const input=anchor.querySelector('[data-scan-method]'),group=input?.dataset.scanMethodGroup,method=input?.dataset.scanMethod,choice=SCAN_METHOD_CATALOG[group]?.find(c=>c.id===method);if(!choice)return;
    this.hide();this.anchor=anchor;this.group=group;this.method=method;this.title.textContent=choice.label;this.description.textContent=choice.description;this.popup.dataset.group=group;this.popup.dataset.method=method;
    this.described=input;this.previousDescription=input.getAttribute('aria-describedby');input.setAttribute('aria-describedby',[this.previousDescription,this.popup.id].filter(Boolean).join(' '));
    try{this.ctx??=this.canvas.getContext('2d');if(!this.ctx)throw new Error('Canvas previews are unavailable.');if(group==='creature')this.resources??=createScanStylePreviewResources(this.doc);}catch{this.hide();return;}
    this.opened=true;this.popup.hidden=false;try{this.popup.showPopover?.();}catch{/* Fixed-position fallback. */}this.position();
    this.start=null;this.last=-Infinity;this.paint(0);if(!this.isReduced())this.frame=this.view.requestAnimationFrame(t=>this.tick(t));
  }
  isReduced(){return this.reducedMotion()||this.view.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches===true;}
  paint(elapsed){this.currentFrame=createScanStylePreviewFrame(this.group,this.method,elapsed,{reducedMotion:this.isReduced()});paintScanStylePreview(this.ctx,this.currentFrame,{resources:this.resources});}
  tick(timestamp){
    this.frame=null;if(!this.opened)return;if(!this.root.isConnected||!this.canOpen()||this.doc.hidden){this.hide();return;}
    this.start??=timestamp;if(this.last===-Infinity)this.last=timestamp;
    if(timestamp-this.last>=FRAME_INTERVAL){this.paint(timestamp-this.start);this.last=timestamp;}
    if(!this.isReduced())this.frame=this.view.requestAnimationFrame(t=>this.tick(t));
  }
  position(){
    const rect=this.anchor.getBoundingClientRect(),vw=this.view.innerWidth,vh=this.view.innerHeight,pad=8,gap=9,width=Math.max(1,Math.min(280,vw-pad*2,vh-pad*2-110)),height=Math.min(vh-pad*2,width+110);
    let x=rect.right+gap;if(x+width>vw-pad)x=rect.left-gap-width;this.popup.style.width=`${width}px`;this.popup.style.maxHeight=`${vh-pad*2}px`;this.popup.style.left=`${Math.max(pad,Math.min(vw-pad-width,x))}px`;this.popup.style.top=`${Math.max(pad,Math.min(vh-pad-height,rect.top))}px`;
  }
  dismiss(){if(!this.opened&&this.intent==null)return false;this.hide();return true;}
  hide(){
    this.cancelHide();
    if(this.intent!=null)this.view.clearTimeout(this.intent);this.intent=null;if(this.frame!=null)this.view.cancelAnimationFrame(this.frame);this.frame=null;
    if(this.described){if(this.previousDescription==null)this.described.removeAttribute('aria-describedby');else this.described.setAttribute('aria-describedby',this.previousDescription);}this.described=null;this.previousDescription=null;
    try{this.popup.hidePopover?.();}catch{/* Already hidden or unsupported. */}this.popup.hidden=true;this.opened=false;this.anchor=null;this.currentFrame=null;
  }
  destroy(){if(this.destroyed)return;this.hide();this.destroyed=true;this.events.abort();this.resources?.destroy();this.resources=null;this.canvas.width=this.canvas.height=1;this.popup.remove();}
}
