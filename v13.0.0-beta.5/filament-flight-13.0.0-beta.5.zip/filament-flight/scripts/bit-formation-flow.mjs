/** Optional formation cycling uses the existing shared clock. A bounded pool
 * and deterministic schedule require no frame writes, timers or socket traffic. */
const unit=n=>Math.max(0,Math.min(1,n));
export function validateFormationFlow(input={},programs=[]){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Formation cycling must be an object.');
  const out={};
  for(const [k,v]of Object.entries(input)){
    if(k==='enabled'){if(typeof v!=='boolean')throw new Error('Cycling enabled must be true or false.');}
    else if(k==='pool'){if(!Array.isArray(v)||v.length>Math.max(16,programs.length)||new Set(v).size!==v.length||v.some(p=>!programs.includes(p)))throw new Error(`Choose up to ${Math.max(16,programs.length)} distinct formation families.`);out.pool=[...v];continue;}
    else if(k==='hold'){if(!Number.isFinite(v)||v<8000||v>180000)throw new Error('Formation hold must be 8–180 seconds.');}
    else if(k==='duration'){if(!Number.isFinite(v)||v<800||v>8000)throw new Error('Formation transition must be 0.8–8 seconds.');}
    else if(k==='epoch'){if(!Number.isFinite(v)||v<0||v>Number.MAX_SAFE_INTEGER)throw new Error('Cycling epoch must be a timestamp.');}
    else throw new Error(`Unknown cycling setting: ${k}.`);
    out[k]=v;
  }return out;
}
export function formationFlowState(program,now,flow={},animated=true){
  const pool=Array.isArray(flow.pool)?flow.pool:[],enabled=flow.enabled===true&&animated&&pool.length>=2;
  if(!enabled)return {program,fromProgram:program,progress:1,active:false,cycle:0};
  const hold=Math.max(8000,Math.min(180000,flow.hold??30000)),duration=Math.max(800,Math.min(8000,flow.duration??2600)),period=hold+duration;
  const age=Math.max(0,now-(flow.epoch??0)),cycle=Math.floor(age/period),elapsed=age-cycle*period;
  const offset=Math.max(0,pool.indexOf(program)),fromProgram=pool[(offset+cycle)%pool.length],next=pool[(offset+cycle+1)%pool.length];
  return {program:elapsed<hold?fromProgram:next,fromProgram,progress:elapsed<hold?1:unit((elapsed-hold)/duration),
    active:elapsed>=hold,cycle,duration,endsAt:(flow.epoch??0)+(cycle+1)*period,holdRemaining:Math.max(0,hold-elapsed)};
}
/** Position/rotation derivatives use seconds. Tangents are clamped to a local
 * passage: an interrupted action can continue its motion without overshooting
 * across the token. The live target's velocity is joined exactly at the end.
 * Enhanced formation captures may also request zero endpoint acceleration;
 * the original intercept remains the default for existing light handoffs. */
export function smoothIntercept(a,b,progress,duration,velocity=0,targetVelocity=0,continuousAcceleration=false){
  const p=unit(progress);if(p===0)return a;if(p===1)return b;
  const d=Math.max(.001,duration),limit=Math.max(8,Math.abs(b-a)*.7),va=velocity*d,vb=targetVelocity*d;
  // Preserve the actual derivatives at both ends. Damp a large tangent's
  // excursion instead of clipping its velocity at the handoff itself.
  const da=Math.max(0,Math.abs(va)/limit-1),db=Math.max(0,Math.abs(vb)/limit-1);
  const p2=p*p,p3=p2*p;
  if(continuousAcceleration){
    const r=1-p,r2=r*r,r3=r2*r,blend=p<=.5?p3*(10-15*p+6*p2):1-r3*(10-15*r+6*r2);
    // Squared damping keeps the captured first derivative and zero second
    // derivative at each end. Its narrow support still limits very large
    // captured tangents to the same local passage instead of overshooting.
    return (1-blend)*a+blend*b+p*r3*(1+3*p)*va*Math.exp(-2*(p*da)*(p*da))-
      p3*r*(4-3*p)*vb*Math.exp(-2*(r*db)*(r*db));
  }
  return (2*p3-3*p2+1)*a+(-2*p3+3*p2)*b+
    (p3-2*p2+p)*va*Math.exp(-p*da)+(p3-p2)*vb*Math.exp(-(1-p)*db);
}
/** The same visible formation, visit phase and pool order, re-anchored so the
 * current visit is cycle 0 of a schedule starting at the shown family. Flow's
 * slot schedule then needs at most one solved passage instead of up to the
 * whole circuit. Slot ownership restarts, so apply this only at a command
 * edge that already blends from captured poses (a formation transition). */
export function rebaseFormationFlow(group,now,animated=true){
  const flow=group?.flow;if(flow?.enabled!==true)return group;
  const state=formationFlowState(group.program,now,flow,animated);
  if(!state.cycle&&state.fromProgram===group.program)return group;
  const period=Math.max(8000,Math.min(180000,flow.hold??30000))+Math.max(800,Math.min(8000,flow.duration??2600));
  return {...group,program:state.fromProgram,flow:{...flow,epoch:(flow.epoch??0)+state.cycle*period}};
}
