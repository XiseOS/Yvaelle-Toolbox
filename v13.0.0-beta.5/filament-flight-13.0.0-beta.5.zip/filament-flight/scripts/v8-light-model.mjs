/** A parked instrument owns a real scene light, independent of the character's
 * lantern. Preferences are intentionally small and use scene distance units. */
export const PARKED_LIGHT_DEFAULTS=Object.freeze({enabled:true,bright:10,dim:20,intensity:.45,angle:360,rotation:0,color:'#ff00ff'});
const number=(value,fallback,min,max)=>Number.isFinite(value)?Math.max(min,Math.min(max,value)):fallback;
export function normalizeParkedLight(raw={}){
  raw=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
  const bright=number(raw.bright,PARKED_LIGHT_DEFAULTS.bright,0,120),dim=Math.max(bright,number(raw.dim,PARKED_LIGHT_DEFAULTS.dim,0,120));
  return {enabled:raw.enabled!==false,bright,dim,intensity:number(raw.intensity,PARKED_LIGHT_DEFAULTS.intensity,0,1),
    angle:number(raw.angle,PARKED_LIGHT_DEFAULTS.angle,15,360),rotation:((number(raw.rotation,0,-360000,360000)%360)+360)%360,
    color:PARKED_LIGHT_DEFAULTS.color};
}

/** Collapse belongs to the actual instruments. Browser artwork and quality
 * switches are cosmetic and must not change the light seen by other players. */
export function parkedLightPower(snapshot={},emitter={}){
  const clamp=value=>Math.max(0,Math.min(1,Number.isFinite(value)?value:0));
  const presence=clamp(emitter.strength??1),response=snapshot.conditionResponse;
  return presence*(response?.bits===true?1-clamp(response.collapse?.mix??0):1);
}
