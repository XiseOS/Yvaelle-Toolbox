/** v10 settings panel: every Yvaelle’s Toolbox setting in one searchable,
 * grouped window, so Foundry's own settings list can show only the main
 * switches. Pure DOM builder plus a small ApplicationV2 wrapper. */
const GROUPS=[
  ['Essentials',k=>['effectsEnabled','localEffects','reducedMotion','hudEnabled','wingLightStyle','wingFollowThrough','formationLibrary','effectLibrary','attentionSync'].includes(k)],
  ['Wings & poses',k=>/^(wing|pose|advancedPoses|foreground|structure)/.test(k)],
  ['Bits & formations',k=>/^(gem|bit|controlGems|formation|compact)/.test(k)],
  ['Light & lantern',k=>/^(light|lantern|wingLight)/i.test(k)],
  ['Reactions & HP',k=>/^(hp|reaction|damage|healing|critical|transient|visualConditions|temporary|condition(?!Effect))/.test(k)],
  ['Effect defaults',k=>/^(conditionEffect_|reactionEffect_|effect)/.test(k)],
  ['Movement & flight',k=>/^(trail|movement|bank|pitch|hover|float|transition|takeoff|landing|flight)/i.test(k)],
  ['Audio',k=>/^audio/.test(k)],
  ['Keep playing (HUD and sheet)',k=>/^keepPlaying/.test(k)],
  ['Bit tools (v8)',k=>/^v8/.test(k)],
  ['Appearance & animation (v7)',k=>/^v7/.test(k)],
  ['Craft (v9)',k=>/^v9/.test(k)],
  ['Quality & performance',k=>/(quality|FPS|Worker|renderWorker|rig|performance)/i.test(k)],
  ['Everything else',()=>true]
];
export const ESSENTIAL_SETTINGS=Object.freeze(['effectsEnabled','localEffects','reducedMotion','hudEnabled','wingLightStyle','wingFollowThrough','formationLibrary','effectLibrary','attentionSync','wingRenderer','v7Enabled','v9SignatureCraft','v9MedicalCraft']);
export function settingGroup(key){return GROUPS.find(([,test])=>test(key))[0];}
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

export const SETTINGS_PANEL_CSS=`
.ffs{display:grid;gap:10px;font-size:13px;color:var(--color-text-primary,#f0e6dc)}
.ffs-top{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.ffs-top input{flex:1;min-width:180px;height:30px}
.ffs-count{font-size:12px;opacity:.75}
.ffs details{border:1px solid rgba(207,174,118,.25);border-radius:4px;background:rgba(0,0,0,.12)}
.ffs summary{cursor:pointer;padding:8px 10px;font-weight:600;display:flex;gap:8px;align-items:center}
.ffs summary .n{margin-left:auto;font-weight:400;font-size:11.5px;opacity:.7}
.ffs summary .chg{font-size:11px;color:#ff8cff}
.ffs-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(140px,auto) auto;gap:4px 12px;align-items:center;padding:8px 10px;border-top:1px dashed rgba(207,174,118,.18)}
.ffs-row .nm{font-weight:600}.ffs-row .ht{grid-column:1/-1;font-size:11.5px;opacity:.72;margin-top:-2px}
.ffs-row.changed .nm::after{content:" · changed";color:#ff8cff;font-weight:400;font-size:11px}
.ffs-row .rs{font-size:11px;height:24px;padding:0 8px;line-height:1}
.ffs-row .lock{font-size:11px;opacity:.6}
.ffs-row input[type=range]{width:140px}
.ffs-row .val{font-variant-numeric:tabular-nums;font-size:12px;min-width:3ch;text-align:right}
.ffs-row .ctl{display:flex;gap:6px;align-items:center;justify-content:flex-end}
`;

/** api: {settings, get(key), set(key,value), canEdit(entry)} */
export function buildSettingsPanel(doc,api){
  const root=doc.createElement('div');root.className='ffs';
  const keys=Object.keys(api.settings).filter(k=>api.settings[k].type!==Object);
  root.innerHTML=`<div class="ffs-top"><input type="search" placeholder="Search ${keys.length} settings" aria-label="Search settings"><span class="ffs-count"></span></div><div class="ffs-groups"></div>`;
  const list=root.querySelector('.ffs-groups'),search=root.querySelector('input'),count=root.querySelector('.ffs-count');
  const byGroup=new Map();for(const k of keys){const g=settingGroup(k);if(!byGroup.has(g))byGroup.set(g,[]);byGroup.get(g).push(k);}
  const control=(k,e,v)=>{
    const dis=api.canEdit(e)?'':' disabled';
    if(e.type===Boolean)return `<input type="checkbox" data-k="${k}"${v?' checked':''}${dis}>`;
    if(e.choices)return `<select data-k="${k}"${dis}>${Object.entries(e.choices).map(([id,l])=>`<option value="${esc(id)}"${id===v?' selected':''}>${esc(l)}</option>`).join('')}</select>`;
    if(e.type===Number&&e.range)return `<input type="range" data-k="${k}" min="${e.range.min}" max="${e.range.max}" step="${e.range.step}" value="${v}"${dis}><span class="val">${v}</span>`;
    if(e.type===Number)return `<input type="number" data-k="${k}" value="${v}"${dis}>`;
    return `<input type="text" data-k="${k}" value="${esc(v)}"${dis}>`;
  };
  // A rebuild after a change keeps the open groups, the scroll position and the focused control.
  let lastQ=null;
  const render=()=>{
    const q=search.value.trim().toLowerCase(),same=q===lastQ,scroller=root.parentElement,top=scroller?.scrollTop??0,f=list.contains(doc.activeElement)?doc.activeElement.dataset:{};
    const focus=f.k?`[data-k="${f.k}"]`:f.reset?`[data-reset="${f.reset}"]`:null;
    const wasOpen=same?new Map([...list.children].map(d=>[d.dataset.group,d.open])):null;
    lastQ=q;let shown=0;list.innerHTML='';
    for(const [group] of GROUPS){const ks=(byGroup.get(group)??[]).filter(k=>!q||`${k} ${api.settings[k].name} ${api.settings[k].hint}`.toLowerCase().includes(q));if(!ks.length)continue;
      shown+=ks.length;const changed=ks.filter(k=>api.get(k)!==api.settings[k].default).length;
      const d=doc.createElement('details');d.dataset.group=group;d.open=wasOpen?.get(group)??(!!q||group==='Essentials');
      d.innerHTML=`<summary>${esc(group)}${changed?`<span class="chg">${changed} changed</span>`:''}<span class="n">${ks.length}</span></summary>`+ks.map(k=>{const e=api.settings[k],v=api.get(k);
        return `<div class="ffs-row${v!==e.default?' changed':''}"><span class="nm">${esc(e.name)}</span><span class="ctl">${control(k,e,v)}</span>${api.canEdit(e)?`<button type="button" class="rs" data-reset="${k}" title="Back to default">Reset</button>`:'<span class="lock">GM only</span>'}<span class="ht">${esc(e.hint)}${e.scope==='client'?' · this browser':''}</span></div>`;}).join('');
      list.appendChild(d);}
    count.textContent=q?`${shown} found`:'';
    if(same){if(scroller)scroller.scrollTop=top;if(focus)list.querySelector(focus)?.focus({preventScroll:true});}
  };
  root.addEventListener('input',e=>{if(e.target===search)return render();const k=e.target.dataset.k;if(!k)return;if(e.target.type==='range')e.target.nextElementSibling.textContent=e.target.value;});
  root.addEventListener('change',async e=>{const k=e.target.dataset.k;if(!k)return;const s=api.settings[k];
    const v=s.type===Boolean?e.target.checked:s.type===Number?Number(e.target.value):e.target.value;await api.set(k,v);render();});
  root.addEventListener('click',async e=>{const k=e.target.dataset?.reset;if(!k)return;await api.set(k,api.settings[k].default);render();});
  render();return root;
}

export function settingsPanelClass(ID,SETTINGS){
  const Base=globalThis.foundry?.applications?.api?.ApplicationV2;if(!Base)return null;
  return class FilamentSettingsPanel extends Base{
    static DEFAULT_OPTIONS={id:'filament-flight-settings',window:{title:'Yvaelle’s Toolbox · All settings',resizable:true},position:{width:640,height:720}};
    async _renderHTML(){
      if(!document.getElementById('ffs-style')){const s=document.createElement('style');s.id='ffs-style';s.textContent=SETTINGS_PANEL_CSS;document.head.appendChild(s);}
      return buildSettingsPanel(document,{settings:SETTINGS,get:k=>{try{return game.settings.get(ID,k);}catch{return SETTINGS[k].default;}},
        set:(k,v)=>game.settings.set(ID,k,v),canEdit:e=>e.scope==='client'||game.user.isGM});
    }
    _replaceHTML(result,content){content.replaceChildren(result);content.style.overflow='auto';}
  };
}
