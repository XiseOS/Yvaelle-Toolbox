/** Cosmetic cadence for native status wing states. These samples belong to
 * shoulder-fixed geometry: they never move a token, change an action, alter a
 * flight mode/elevation, or restart the continuously integrated wing clock.
 * Units: bank/leftBias are radians, sway/settle are source-art units; liftScale
 * only weights the posed wing stroke. The existing condition rate remains its
 * single authority. Every result is serializable for the render worker.
 */
const TAU=Math.PI*2;
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const unit=n=>Math.max(0,Math.min(1,finite(n)));
const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));

export const STATUS_FLIGHT_CHARACTERS=Object.freeze({
  untethered:'Unpowered drift',controlled:'Borrowed cadence',fleeing:'Purposeful retreat',
  confused:'Uneven wandering',sickened:'Queasy roll',encumbered:'Weighted stroke',
  slowed:'Held release',quickened:'Double pulse',frightened:'Protective catches',fatigued:'Heavy recovery'
});
const IDS=Object.keys(STATUS_FLIGHT_CHARACTERS);
const neutral=(time=0)=>({active:false,id:null,animated:false,time,beatMultiplier:1,
  bank:0,sway:0,settle:0,liftScale:1,phaseWarp:0,phaseHarmonic:0,phaseTug:0,
  phaseDownstroke:0,leftBias:0,strokeWeight:0,noPropulsion:false,strengths:{}});

function strength(response,id){
  const entry=response?.active?.find(value=>value.id===id),rule=response?.config?.conditions?.[id];
  if(!entry||entry.style==='none'||rule?.style==='none'||rule?.enabled===false||rule?.strength===0)return 0;
  return unit(response?.levels?.[id]??entry.strength??0);
}

/** Stunned owns its exact 1/2/3 choreography, including when fatigue is also
 * present. Prone, held states and collapse likewise keep their established
 * phase/rate and recovery behavior instead of gaining another moving layer.
 */
function ownsExistingMotion(response){
  if(response?.collapse?.phase&&response.collapse.phase!=='awake')return true;
  const prone=response?.config?.conditions?.prone;
  if(prone?.enabled!==false&&prone?.style!=='none'&&(response?.targetStrengths?.prone??0)>.001)return true;
  return ['stunned','prone','paralyzed','petrified','unconscious'].some(id=>strength(response,id)>.001);
}

export function sampleStatusFlightCharacter(response,profile={},config={}){
  const time=Math.max(0,finite(profile.conditionFrozenTime,finite(profile.effectTime,finite(profile.time))));
  if(!response?.wings||response.enabled===false||config.visualConditions===false||config.filamentInstability===false||
    ownsExistingMotion(response))return neutral(time);
  const motion=clamp(finite(config.conditionMotionStrength,1),0,2);
  const strengths=Object.fromEntries(IDS.map(id=>[id,strength(response,id)*motion]).filter(([,value])=>value>.001));
  const ids=IDS.filter(id=>strengths[id]>0);
  if(!ids.length)return neutral(time);
  const animated=!response.reduced&&!config.reduced&&!config.reducedMotion&&profile.animated!==false&&
    !profile.conditionMotionFrozen&&profile.conditionFrozenTime==null;
  // A startup envelope lets the phase warp join at time zero without a snap.
  // Frozen/reduced frames have no secondary cadence, bob or banking at all.
  const gain=animated?1-Math.exp(-Math.min(80,time*time)*2):0;
  const normalization=1/Math.max(1,Object.values(strengths).reduce((sum,n)=>sum+n,0));
  const a=id=>(strengths[id]??0)*normalization*gain;
  const sin=rate=>Math.sin(time*rate),breath=rate=>.5-.5*Math.cos(time*rate);
  const fatigue=a('fatigued'),load=a('encumbered'),slow=a('slowed'),quick=a('quickened'),
    confusion=a('confused'),malaise=a('sickened'),fear=a('frightened'),flight=a('fleeing'),
    puppet=a('controlled'),drift=a('untethered');
  return {active:true,id:ids[0],animated,time,beatMultiplier:1,strengths,
    // Gentle root-fixed tilts: confusion wanders unevenly; sickness rolls
    // slowly; fear makes short, inward protective catches rather than a shake.
    bank:clamp(.024*confusion*sin(.67)+.018*malaise*sin(.83)+.011*fear*sin(7.7)+.009*flight*sin(1.17)+.014*drift*sin(.36),-.03,.03),
    sway:clamp(3.2*confusion*sin(.91)+1.25*malaise*sin(.62)+.8*slow*sin(.38)+.65*flight*sin(1.17)+2.4*drift*sin(.29),-5,5),
    settle:clamp(3.1*fatigue*breath(.78)+2.8*load*breath(.54)+1.2*slow*sin(.41)-1.5*quick*breath(2.6)
      +1.9*confusion*sin(.59)+.8*malaise*sin(.83)-1.3*flight*breath(1.63)+1.7*puppet*Math.sin(time*1.16)**3+2.1*drift*sin(.34),-5,5),
    liftScale:clamp(1-.035*fatigue*breath(.78)-.065*load*breath(.54),.9,1),
    phaseWarp:.10*fatigue+.13*load+.52*slow-.14*quick-.19*flight+.10*fear,
    phaseHarmonic:-.04*fatigue-.04*load-.10*slow+.22*quick+.08*flight+.22*puppet+.09*fear,
    phaseTug:.08*puppet+.04*fear,
    phaseDownstroke:.30*fatigue+.46*load+.08*slow+.17*flight,
    leftBias:.12*confusion*sin(.71)+.025*malaise*sin(.83)+.035*fear*sin(7.7),
    strokeWeight:clamp(.09*fatigue*breath(.78)+.14*load*breath(.54)+.09*quick*sin(2.6)+.07*flight*breath(1.63)+.08*puppet*Math.sin(time*1.16)**3,-.12,.16),
    // The caller suppresses the cosmetic propulsion stroke in native wing
    // geometry, retaining these tiny weightless drifts at the shoulder roots.
    noPropulsion:(strengths.untethered??0)>.001};
}

/** An unwrapped, monotone C1 periodic remapping of the existing beat phase.
 * Holds/releases vary instantaneous stroke speed, not the elapsed clock. At
 * each cycle seam both the value and derivative match, with no modulo jump.
 * A derivative bound prevents combinations from reversing or jittering.
 */
export function statusWingBeatPhase(phase,character,side=1){
  phase=finite(phase);
  if(!character?.active||!character.animated)return phase;
  const a=finite(character.phaseWarp)+finite(character.leftBias)*(side<0?-1:1),
    b=finite(character.phaseHarmonic),c=finite(character.phaseTug),d=finite(character.phaseDownstroke);
  const scale=.86/Math.max(.86,Math.abs(a)+2*Math.abs(b)+3*Math.abs(c)+Math.abs(d));
  return phase+scale*(a*Math.sin(phase)+b*Math.sin(2*phase)+c*Math.sin(3*phase)+d*(1-Math.cos(phase)));
}

export const STATUS_FLIGHT_PHASE_PERIOD=TAU;
