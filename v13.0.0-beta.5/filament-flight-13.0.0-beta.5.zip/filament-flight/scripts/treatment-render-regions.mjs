import {techniqueBounds} from './hardlight-techniques.mjs?v=13.0.0-beta.5';

/** Bound patient-local paint independently of the travelling instruments. The
 * cropped canvas keeps exactly the same pixels per unit as its full canvas. */
export function actionEffectViewport(effects,resolution,plane='front',{ignoreTokenFields=false,boundsCache=null}={}){
  let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
  for(const effect of effects){
    if(effect.effect==='sprite'||ignoreTokenFields&&effect.effect==='token-field'||!(effect.strength>0))continue;
    if(plane==='rear'&&!['hardlight','v8-scan'].includes(effect.effect))continue;
    if(effect.effect==='v8-scan'&&!effect.channels?.some(channel=>(channel.plane??'front')===plane&&channel.strength>0))continue;
    if(effect.effect==='hardlight'&&effect.phase==='finishing'&&effect.progress>=1)continue;
    let bounds=null;
    if(effect.effect==='hardlight'){
      // This cache belongs to one renderer update, so mutable emitters, detail
      // changes and later clocks cannot retain an obsolete envelope.
      if(boundsCache?.has(effect))bounds=boundsCache.get(effect);
      else {bounds=techniqueBounds(effect);boundsCache?.set(effect,bounds);}
    }
    // Legacy/custom effects retain a conservative envelope. New techniques
    // declare their instrument and emitter envelope without reading pixels.
    const b=bounds??(effect.effect==='v8-scan'?effect.bounds:null)??{x:-110,y:-110,width:220,height:220};
    left=Math.min(left,b.x);top=Math.min(top,b.y);right=Math.max(right,b.x+b.width);bottom=Math.max(bottom,b.y+b.height);
  }
  if(!Number.isFinite(left))return null;
  const ratio=resolution/280,cell=16;
  const x=Math.max(0,Math.floor(((left+140)*ratio-2)/cell)*cell),y=Math.max(0,Math.floor(((top+140)*ratio-2)/cell)*cell);
  right=Math.min(resolution,Math.ceil(((right+140)*ratio+2)/cell)*cell);
  bottom=Math.min(resolution,Math.ceil(((bottom+140)*ratio+2)/cell)*cell);
  return {x,y,width:Math.max(1,right-x),height:Math.max(1,bottom-y)};
}

export function treatmentResolution(diameter,detail='standard',zoom=1,deviceScale=1){
  const cap=detail==='low'?256:detail==='high'?640:448;
  const density=detail==='low'?1:detail==='high'?2.25:1.6;
  const projected=Math.max(1,diameter)*Math.max(.05,zoom)*Math.max(1,deviceScale);
  return Math.min(cap,Math.max(128,Math.ceil(projected*density/32)*32));
}

/** Area scans paint only their team crop (`cropUnits`, in the 280-unit
 * field). Give the crop the density a whole surface of the crop's world size
 * would get, then express it as the full-field resolution the painter uses.
 * Crops are quantized to 16 units so a changing team shape rarely reallocates.
 * Never below the ordinary whole-field resolution. */
export function scanCropResolution(diameter,cropUnits,detail='standard',zoom=1,deviceScale=1,maximum=8192){
  const whole=treatmentResolution(diameter,detail,zoom,deviceScale);
  if(!(cropUnits>0))return whole;
  const units=Math.min(280,Math.max(16,Math.ceil(cropUnits/16)*16)),crop=treatmentResolution(diameter*units/280,detail,zoom,deviceScale);
  return Math.max(whole,Math.min(maximum,Math.ceil(crop*280/units/32)*32));
}

/** Zooming in is immediate. A stable smaller footprint can return memory after
 * one second, without reallocating textures throughout a wheel gesture. */
export function settledTreatmentResolution(record,desired,now){
  if(!record.resolution||desired>=record.resolution){record.pendingResolution=null;return desired;}
  if(desired>record.resolution*.8){record.pendingResolution=null;return record.resolution;}
  let pending=record.pendingResolution;
  if(!pending||now<pending.started)pending=record.pendingResolution={started:now,resolution:desired};
  else pending.resolution=Math.max(pending.resolution,desired);
  if(now-pending.started<1000)return record.resolution;
  record.pendingResolution=null;return pending.resolution;
}

export function stableEffectViewport(record,desired,now,{maxPixels=Infinity}={}){
  const previous=record.viewport;
  if(!previous)return desired;
  const union=(a,b)=>{const x=Math.min(a.x,b.x),y=Math.min(a.y,b.y);return {x,y,width:Math.max(a.x+a.width,b.x+b.width)-x,height:Math.max(a.y+a.height,b.y+b.height)-y};};
  const expanded=union(previous,desired);
  // A crop-sized area scan can jump across a huge virtual raster; never grow
  // a retained texture past the cap just to span the old and new crops.
  if(expanded.width*expanded.height>maxPixels){record.pendingViewport=null;return desired;}
  if(expanded.x!==previous.x||expanded.y!==previous.y||expanded.width!==previous.width||expanded.height!==previous.height){record.pendingViewport=null;return expanded;}
  if(desired.width*desired.height>previous.width*previous.height*.7){record.pendingViewport=null;return previous;}
  let pending=record.pendingViewport;
  if(!pending||now<pending.started)pending=record.pendingViewport={started:now,bounds:desired};else pending.bounds=union(pending.bounds,desired);
  if(now-pending.started<600)return previous;
  record.pendingViewport=null;return pending.bounds;
}
