/** Ellie's local portrait stage. No document writes, actor polling or scene ticker.
 * Registered artwork is deformed in small anatomical regions; health changes
 * blend the currently visible mixture, including when another change interrupts. */
export const PORTRAIT_STATES=Object.freeze(['healthy','light','wounded','severe','critical','unconscious']);
export const PORTRAIT_HP_BANDS=Object.freeze(PORTRAIT_STATES.slice(0,5));
export const PORTRAIT_SETS=Object.freeze({original:{label:'Original',hint:'The original restrained expressions.'},resolute:{label:'Resolute',hint:'Determination gives way to strain, a guarded eye and exhaustion.'},pained:{label:'Pained',hint:'A fading smile, a wince and increasingly visible pain.'}});
export const PORTRAIT_ASSET_ROOT='modules/filament-flight/assets/hud/v611/';
export const PORTRAIT_VARIANT_ROOT='modules/filament-flight/assets/hud/v62/';
export const PORTRAIT_CACHE_LIMIT=6;
export const PORTRAIT_TIMING=Object.freeze({transition:900,recovery:1450,fps:16,hoverCooldown:2800,cueCooldown:650});
const clamp=(n,min=0,max=1)=>Math.max(min,Math.min(max,Number(n)||0));
const smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const stateId=id=>PORTRAIT_STATES.includes(id)?id:'healthy';
const blend=(a,b,t)=>a+(b-a)*t;
const POSES=Object.freeze({
  healthy:{breath:4.8,lift:1,head:1,hair:1,posture:0},
  light:{breath:5.3,lift:.88,head:.78,hair:.9,posture:.0015},
  wounded:{breath:5.8,lift:.72,head:.58,hair:.72,posture:.003},
  severe:{breath:6.9,lift:.55,head:.37,hair:.5,posture:.005},
  critical:{breath:8.2,lift:.38,head:.2,hair:.31,posture:.007},
  unconscious:{breath:9.6,lift:.2,head:0,hair:.08,posture:.01}
});
// Registered to the supplied 3:2 banner: Ellie occupies the right side and her
// hair trails left. Motion stays within those regions; the transparent space and
// frame boundaries stay fixed. Eye artwork is always the unmodified source.
export const PORTRAIT_REGIONS=Object.freeze({head:{x:.68,y:.28,rx:.145,ry:.22},torso:{x:.76,y:.70,rx:.23,ry:.32},hairLeft:{x:.48,y:.59,rx:.26,ry:.38},hairRight:{x:.85,y:.40,rx:.12,ry:.33}});
export const PORTRAIT_CANVAS=Object.freeze({width:540,height:360});
export function portraitUnconscious(model={}){
  const hp=model.hp,actor=model.token?.document?.actor;
  let unconscious=!!hp?.unconscious;
  try{unconscious||=!!(actor?.hasCondition?.('unconscious')||actor?.statuses?.has?.('unconscious')||actor?.statuses?.has?.('dead'));}catch{}
  return unconscious||Number.isFinite(hp?.value)&&hp.value<=0;
}
export function portraitHPBand(model={}){
  const hp=model.hp;
  if(Number.isFinite(hp?.value)&&hp.value<=0)return 'critical';
  if(!hp||!Number.isFinite(hp.max)||hp.max<=0)return 'healthy';
  const ratio=clamp(hp.value/hp.max),raw=model.cfg?.hpThresholds??{},moderate=clamp(raw.moderate??.7,.01,.99),low=clamp(raw.low??.35,.001,moderate),critical=clamp(raw.critical??.15,0,low);
  if(ratio<=critical)return 'critical';
  if(ratio<=low)return 'severe';
  if(ratio<=blend(low,moderate,.5))return 'wounded';
  if(ratio<=moderate)return 'light';
  return 'healthy';
}
export function portraitState(model={}){return portraitUnconscious(model)?'unconscious':portraitHPBand(model);}
const setId=id=>Object.hasOwn(PORTRAIT_SETS,id)?id:'original';
function frameInfo(id){
  if(PORTRAIT_STATES.includes(id))return {set:'original',band:id==='unconscious'?'critical':id,unconscious:id==='unconscious'};
  const [set,band,extra]=String(id??'').split(':');
  if(extra||!PORTRAIT_HP_BANDS.includes(band)||!['unconscious','resolute','pained'].includes(set))return null;
  if(set!=='unconscious'&&band==='healthy')return null;
  return {set:set==='unconscious'?'original':set,band,unconscious:set==='unconscious'};
}
const frameId=id=>frameInfo(id)?id:'healthy';
export function portraitAppearance(model={}){
  const theme=model.prefs?.theme??{},set=setId(theme.portraitSet),enabled=theme.headerHP!==false,band=enabled?portraitHPBand(model):'healthy',unconscious=enabled&&portraitUnconscious(model);
  const id=unconscious?(band==='critical'?'unconscious':`unconscious:${band}`):set==='original'||band==='healthy'?band:`${set}:${band}`;
  return {id,set,band,unconscious,asset:portraitAsset(id)};
}
export function portraitAsset(id){
  const info=frameInfo(id)??frameInfo('healthy');
  if(info.unconscious)return info.band==='critical'?`${PORTRAIT_ASSET_ROOT}portrait-unconscious.webp`:`${PORTRAIT_VARIANT_ROOT}unconscious-${info.band}.webp`;
  return info.set==='original'||info.band==='healthy'?`${PORTRAIT_ASSET_ROOT}portrait-${info.band}.webp`:`${PORTRAIT_VARIANT_ROOT}${info.set}-${info.band}.webp`;
}
export function portraitSettings(model={}){
  const t=model.prefs?.theme??{},cfg=model.cfg??{},health=portraitState(model),appearance=portraitAppearance(model);
  return {state:t.headerHP===false?'healthy':health,health,...appearance,custom:t.header||'',show:t.showHeader!==false,
    motion:t.motion!==false&&t.headerMotion!==false&&!cfg.reduced&&!cfg.reducedMotion&&(t.motionStrength??.75)>0,
    strength:clamp(t.portraitStrength??.65)*clamp(t.motionStrength??.75),interactions:t.portraitInteractions!==false};
}
export function portraitWeights(transition,time){
  if(!transition)return {healthy:1};
  const t=smooth((time-transition.started)/Math.max(1,transition.duration)),out={};
  for(const id of new Set([...Object.keys(transition.from??{}),transition.to])){if(!frameInfo(id))continue;const value=(transition.from?.[id]??0)*(1-t)+(transition.to===id?t:0);if(value>.00001)out[id]=value;}
  return out;
}
export function transitionPortrait(previous,to,time,{immediate=false}={}){
  to=frameId(to);if(previous?.to===to&&!immediate)return previous;
  const from=previous?portraitWeights(previous,time):{[to]:1};
  const rank=id=>{const info=frameInfo(id)??frameInfo('healthy');return PORTRAIT_HP_BANDS.indexOf(info.band)+(info.unconscious?5:0);};
  const healing=rank(to)<rank(previous?.to??to);
  return {from:immediate?{[to]:1}:from,to,started:time,duration:immediate?0:healing?PORTRAIT_TIMING.recovery:PORTRAIT_TIMING.transition};
}
/** Values are normalized image-space amplitudes. No random per-frame movement. */
export function samplePortraitMotion(id,time,strength=.65,cue=null){
  id=stateId(id);const p=POSES[id],s=clamp(strength),t=time/1000,breath=Math.sin(t*2*Math.PI/p.breath),awake=id!=='unconscious';
  const cueAge=cue?(time-cue.started)/Math.max(1,cue.duration??1100):2,envelope=cueAge>=0&&cueAge<1?Math.sin(Math.PI*cueAge)*(1-cueAge*.35):0;
  const attention=awake?envelope:0;
  return {breath:breath*.008*p.lift*s,headX:(Math.sin(t*.57)*.006*p.head+attention*(cue?.direction??-1)*.006)*s,
    headY:(Math.sin(t*.41)*.004*p.head+p.posture)*s,hair:Math.sin(t*.83+.8)*.011*p.hair*s,
    shoulder:Math.sin(t*2*Math.PI/p.breath+.3)*.002*p.lift*s,
    energy:awake&&cue?.energy?attention*s*.18:0,attention};
}
const bell=(v,c,r)=>Math.exp(-Math.pow((v-c)/r,2)*2.2);
const regionWeight=(x,y,r)=>bell(x,r.x,r.rx)*bell(y,r.y,r.ry);
export function deformPortraitPoint(x,y,motion){
  const head=regionWeight(x,y,PORTRAIT_REGIONS.head),body=regionWeight(x,y,PORTRAIT_REGIONS.torso),hair=(regionWeight(x,y,PORTRAIT_REGIONS.hairLeft)+regionWeight(x,y,PORTRAIT_REGIONS.hairRight))*(1-head*.94);
  // Edge attenuation retains exact transparent frame edges and avoids clipping.
  const edge=clamp(Math.min(x,1-x,y,1-y)*12);
  return {x:x+edge*(head*motion.headX+hair*motion.hair*(x<PORTRAIT_REGIONS.head.x?-1:1)+body*(x-PORTRAIT_REGIONS.torso.x)*motion.breath*.6),
    y:y+edge*(head*(motion.headY-motion.breath*.35)+body*(-motion.breath)+hair*motion.shoulder)};
}
export function portraitCue(previous,detail,time,health='healthy'){
  if(health==='unconscious'||!detail)return previous;
  const hover=detail.type==='hover'||detail.type==='focus',cooldown=hover?PORTRAIT_TIMING.hoverCooldown:PORTRAIT_TIMING.cueCooldown;
  const previousHover=previous?.type==='hover'||previous?.type==='focus';
  if(previous&&time-previous.started<cooldown&&!(previousHover&&!hover))return previous;
  const tab=detail.tab,action=detail.action??'',energy=/wing|bits|bit|effect|pulse|stutter|reform|light|flight/i.test(action);
  return {started:time,duration:hover?850:1200,direction:tab==='effects'?-1:tab==='settings'?1:-.45,energy:!hover&&energy,type:detail.type??'command'};
}

// Source triangles, grid coordinates and affine coefficients never move. Keep
// only four numeric topologies (no image/window references), shared by HP layers.
// Target vertices remain continuous and are recalculated for each live sample.
const portraitTopologies=new Map();
function portraitTopology(width,height){
  const key=`${width}:${height}`;if(portraitTopologies.has(key))return portraitTopologies.get(key);
  const columns=width>height?9:6,rows=width>height?6:9,points=[],triangles=[];
  for(let y=0;y<=rows;y++)for(let x=0;x<=columns;x++)points.push([x/columns,y/rows]);
  const add=(indices,p0,p1,p2)=>{
    const den=p0.x*(p1.y-p2.y)+p1.x*(p2.y-p0.y)+p2.x*(p0.y-p1.y);
    const sx=Math.max(0,Math.min(p0.x,p1.x,p2.x)-4),sy=Math.max(0,Math.min(p0.y,p1.y,p2.y)-4),ex=Math.min(width,Math.max(p0.x,p1.x,p2.x)+4),ey=Math.min(height,Math.max(p0.y,p1.y,p2.y)+4);
    triangles.push({indices,den,dx:[p1.y-p2.y,p2.y-p0.y,p0.y-p1.y],dy:[p2.x-p1.x,p0.x-p2.x,p1.x-p0.x],
      offset:[p1.x*p2.y-p2.x*p1.y,p2.x*p0.y-p0.x*p2.y,p0.x*p1.y-p1.x*p0.y],sx,sy,sw:ex-sx,sh:ey-sy});
  };
  for(let y=0;y<rows;y++)for(let x=0;x<columns;x++){
    const a=y*(columns+1)+x,b=a+1,c=a+columns+1,d=c+1,x0=x*width/columns,x1=(x+1)*width/columns,y0=y*height/rows,y1=(y+1)*height/rows;
    add([a,b,c],{x:x0,y:y0},{x:x1,y:y0},{x:x0,y:y1});
    add([b,d,c],{x:x1,y:y0},{x:x1,y:y1},{x:x0,y:y1});
  }
  const result={points,triangles};if(portraitTopologies.size>=4)portraitTopologies.delete(portraitTopologies.keys().next().value);portraitTopologies.set(key,result);return result;
}
/** Canvas clipping deliberately overlaps by 1.8px: source-over antialias edges
 * otherwise leave partially transparent triangular seams in opaque skin. */
function triangle(ctx,image,topology,points){
  const {indices,den,dx,dy,offset,sx,sy,sw,sh}=topology;if(Math.abs(den)<.001)return;
  const q0=points[indices[0]],q1=points[indices[1]],q2=points[indices[2]],cx=(q0.x+q1.x+q2.x)/3,cy=(q0.y+q1.y+q2.y)/3;
  ctx.save();ctx.beginPath();for(let i=0;i<3;i++){const q=points[indices[i]],dx=q.x-cx,dy=q.y-cy,l=Math.hypot(dx,dy)||1,x=q.x+dx/l*1.8,y=q.y+dy/l*1.8;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);}ctx.closePath();ctx.clip();
  const a=(q0.x*dx[0]+q1.x*dx[1]+q2.x*dx[2])/den,c=(q0.x*dy[0]+q1.x*dy[1]+q2.x*dy[2])/den,e=(q0.x*offset[0]+q1.x*offset[1]+q2.x*offset[2])/den;
  const b=(q0.y*dx[0]+q1.y*dx[1]+q2.y*dx[2])/den,d=(q0.y*dy[0]+q1.y*dy[1]+q2.y*dy[2])/den,f=(q0.y*offset[0]+q1.y*offset[1]+q2.y*offset[2])/den;
  ctx.transform(a,b,c,d,e,f);ctx.drawImage(image,sx,sy,sw,sh,sx,sy,sw,sh);ctx.restore();
}
export function paintPortraitMesh(ctx,image,motion,width,height=width*image.height/image.width){
  const topology=portraitTopology(image.width,image.height),points=topology.points.map(([x,y])=>{const p=deformPortraitPoint(x,y,motion);return {x:p.x*width,y:p.y*height};});
  for(const tri of topology.triangles)triangle(ctx,image,tri,points);
}
// Cache within a browser window without keeping detached Foundry popouts alive.
const imageCaches=new WeakMap();
function loadImage(path,win,doc){
  let imageCache=imageCaches.get(win);if(!imageCache){imageCache=new Map();imageCaches.set(win,imageCache);}
  if(imageCache.has(path)){const promise=imageCache.get(path);imageCache.delete(path);imageCache.set(path,promise);return promise;}
  // Retain only the display-sized surface. The decoded source image can be
  // collected, even after browsing every set; no full-size asset gallery stays
  // resident in the HUD. The LRU bounds retained promises/surfaces; an evicted
  // request can finish decoding independently and is discarded if no longer used.
  const promise=new Promise(resolve=>{const image=new win.Image();image.decoding='async';image.onload=()=>{const surface=doc.createElement('canvas');surface.width=PORTRAIT_CANVAS.width;surface.height=PORTRAIT_CANVAS.height;const context=surface.getContext('2d');context?.drawImage(image,0,0,surface.width,surface.height);image.onload=null;image.onerror=null;resolve(context?surface:null);};image.onerror=()=>{image.onload=null;image.onerror=null;resolve(null);};image.src=path;});
  if(imageCache.size>=PORTRAIT_CACHE_LIMIT)imageCache.delete(imageCache.keys().next().value);imageCache.set(path,promise);return promise;
}
function validCarry(carry,owner){
  if(!owner||carry?.owner!==owner||!frameInfo(carry.transition?.to))return null;
  const transition=carry.transition,weights=Object.entries(transition.from??{});
  if(!Number.isFinite(transition.started)||!Number.isFinite(transition.duration)||transition.duration<0||!weights.length||weights.some(([id,w])=>!frameInfo(id)||!Number.isFinite(w)||w<0)||Math.abs(weights.reduce((n,[,w])=>n+w,0)-1)>.001)return null;
  return carry;
}
/** Destroy/recreate on content replacement; reusing one transition preserves the
 * visible health mixture even when a tab redraw replaces the DOM. */
export function createPortraitController(root,model,{carry=null,now=()=>globalThis.performance?.now?.()??Date.now(),setTimer=setTimeout,clearTimer=clearTimeout}={}){
  const stage=root?.querySelector?.('[data-ff-portrait-stage]'),canvas=stage?.querySelector?.('[data-ff-portrait-canvas]'),doc=root?.ownerDocument,win=doc?.defaultView;
  if(!stage||!canvas||!win)return {update(){},setPaused(){},cue(){},destroy(){}};
  const ctx=canvas.getContext('2d',{alpha:true});if(!ctx)return {update(){},setPaused(){},cue(){},destroy(){}};
  let owner=model.token?.document?.uuid??model.token?.document?.id??null;const saved=validCarry(carry,owner);
  let settings=portraitSettings(model),transition=saved?.transition??transitionPortrait(null,settings.id,now(),{immediate:true}),paused=false,destroyed=false,timer=null,interaction=saved?.interaction??null,drawn=false,frame=0;
  const images=new Map(saved?.images instanceof Map?[...saved.images].filter(([id,image])=>frameInfo(id)&&image?.width===PORTRAIT_CANVAS.width&&image?.height===PORTRAIT_CANVAS.height):[]),pending=new Set();canvas.width=PORTRAIT_CANVAS.width;canvas.height=PORTRAIT_CANVAS.height;
  const layer=doc.createElement('canvas');layer.width=canvas.width;layer.height=canvas.height;const lc=layer.getContext('2d');
  const reduced=()=>!!win.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
  const invisible=()=>paused||doc.hidden||root.dataset.ffPaused==='true'||root.closest?.('.minimized')||!settings.show;
  const animated=()=>settings.motion&&!reduced()&&!settings.custom&&!invisible()&&settings.strength>0;
  const fallback=stage.querySelector('[data-ff-portrait-fallback]');
  function stop(){if(timer!==null)clearTimer(timer);timer=null;stage.dataset.ffPortraitAnimated='false';}
  const needed=id=>id===settings.id||(portraitWeights(transition,now())[id]??0)>.001;
  function request(id){if(!frameInfo(id)||images.has(id)||pending.has(id)||settings.custom)return;pending.add(id);
    loadImage(portraitAsset(id),win,doc).then(image=>{pending.delete(id);if(destroyed||!needed(id))return;if(image){images.set(id,image);stage.dataset.ffPortraitLoaded='true';if(id===settings.id&&transition.to!==id)transition=transitionPortrait(transition,id,now(),{immediate:!settings.motion||reduced()});}draw(now());schedule();});
  }
  function draw(time){
    if(destroyed||invisible()||settings.custom)return;
    const weights=portraitWeights(transition,time),available=Object.entries(weights).filter(([id,w])=>w>.001&&images.has(id));
    for(const id of images.keys())if(id!==settings.id&&(weights[id]??0)<=.001)images.delete(id);
    if(!available.length)return;
    const total=available.reduce((sum,[,w])=>sum+w,0),motionEnabled=animated();ctx.clearRect(0,0,canvas.width,canvas.height);
    // Additive weighted layers preserve transparent silhouette opacity during a
    // crossfade. Each settled transition releases all outgoing image layers.
    ctx.globalCompositeOperation='lighter';
    for(const [id,weight] of available){const image=images.get(id),info=frameInfo(id),motion=samplePortraitMotion(settings.health==='unconscious'||info.unconscious?'unconscious':info.band,time,motionEnabled?settings.strength:0,settings.interactions?interaction:null);ctx.globalAlpha=weight/total;
      if(motionEnabled){lc.clearRect(0,0,layer.width,layer.height);paintPortraitMesh(lc,image,motion,layer.width,layer.height);ctx.drawImage(layer,0,0);}else ctx.drawImage(image,0,0,canvas.width,canvas.height);
    }
    ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;drawn=true;canvas.hidden=false;stage.dataset.ffPortraitLoaded='true';if(fallback)fallback.hidden=true;
    const light=stage.querySelector('.ff-portrait-response');if(light){const m=samplePortraitMotion(settings.health,time,motionEnabled?settings.strength:0,interaction);light.style.opacity=String(m.energy);}
    stage.dataset.ffPortraitFrame=String(++frame);stage.dataset.ffPortraitState=settings.state;stage.dataset.ffPortraitSet=settings.set;stage.dataset.ffPortraitBand=settings.band;stage.dataset.ffPortraitUnconscious=String(settings.unconscious);stage.dataset.ffPortraitAsset=settings.asset;
  }
  function schedule(){if(destroyed||timer!==null||invisible()||settings.custom||!images.size)return;const time=now(),blending=time<transition.started+transition.duration;
    if(!animated()&&!blending){stop();return;}stage.dataset.ffPortraitAnimated=String(animated());timer=setTimer(()=>{timer=null;draw(now());schedule();},1000/PORTRAIT_TIMING.fps);
  }
  function update(next){if(destroyed)return;const before=settings;settings=portraitSettings(next);const time=now();
    const nextOwner=next.token?.document?.uuid??next.token?.document?.id??null;
    if(nextOwner!==owner){owner=nextOwner;transition=transitionPortrait(null,settings.id,time,{immediate:true});interaction=null;images.clear();drawn=false;canvas.hidden=true;if(fallback){fallback.hidden=false;fallback.src=settings.custom||settings.asset;}stop();}
    const changed=Object.keys(settings).some(key=>settings[key]!==before[key]);
    // A reconstructed HUD already has the new settings in `before`, but its
    // carried transition can still point at the previous selection. Redirect it
    // from its current mixture even when the requested source is already loaded.
    const retarget=!settings.custom&&transition.to!==settings.id&&images.has(settings.id);
    if(!changed&&drawn&&!retarget){schedule();return;}
    if(before.custom!==settings.custom||before.show!==settings.show){stop();}
    if(retarget)transition=transitionPortrait(transition,settings.id,time,{immediate:!settings.motion||reduced()});
    if(before.id!==settings.id||retarget)interaction=null;
    if(!settings.motion||reduced()||settings.strength===0){stop();transition=transitionPortrait(transition,settings.id,time,{immediate:true});}
    stage.dataset.ffPortraitState=settings.state;stage.dataset.ffPortraitCustom=String(!!settings.custom);
    if(settings.custom){canvas.hidden=true;if(fallback){fallback.hidden=false;if(fallback.getAttribute('src')!==settings.custom)fallback.src=settings.custom;}stop();return;}
    request(settings.id);for(const [id,w]of Object.entries(portraitWeights(transition,time)))if(w>.001)request(id);
    if(settings.health==='unconscious')interaction=null;
    draw(time);schedule();
  }
  const media=win.matchMedia?.('(prefers-reduced-motion: reduce)'),mediaChanged=()=>{if(destroyed)return;stop();if(reduced())transition=transitionPortrait(transition,settings.id,now(),{immediate:true});draw(now());schedule();};media?.addEventListener?.('change',mediaChanged);
  update(model);
  return {update,setPaused(value){const changed=paused!==!!value;paused=!!value;if(paused)stop();else if(changed||!drawn){draw(now());schedule();}},
    cue(detail){if(destroyed||invisible()||!settings.interactions||!animated())return;interaction=portraitCue(interaction,detail,now(),settings.health);schedule();},
    snapshot(){return {owner,transition,interaction,images:new Map(images)};},
    destroy(){if(destroyed)return;destroyed=true;stop();media?.removeEventListener?.('change',mediaChanged);images.clear();interaction=null;},
    get state(){return {state:settings.state,id:settings.id,set:settings.set,band:settings.band,unconscious:settings.unconscious,asset:settings.asset,transition,paused,ticking:timer!==null,frame,images:images.size,cachedImages:imageCaches.get(win)?.size??0};}};
}
