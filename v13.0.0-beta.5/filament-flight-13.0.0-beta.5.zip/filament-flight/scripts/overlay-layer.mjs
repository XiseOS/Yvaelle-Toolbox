/** v10 beta.7 · A screen-sized 2D overlay above the board canvas, shared by
 * warps and routines. The board's screen rectangle is cached and refreshed
 * only when the window or the board element resizes, so a running effect no
 * longer forces a layout read and four style writes on every frame. */
export function createOverlay(id){
  let el=null,rect=null,observed=null,observer=null,listening=false,styleKey='';
  const invalidate=()=>{rect=null;};
  function watch(view){
    if(!listening){listening=true;globalThis.addEventListener?.('resize',invalidate,{passive:true});globalThis.addEventListener?.('scroll',invalidate,{passive:true,capture:true});}
    if(observed===view)return;
    try{observer?.disconnect();}catch{}
    observed=view;rect=null;
    try{observer=typeof ResizeObserver==='function'?new ResizeObserver(invalidate):null;observer?.observe(view);}catch{observer=null;}
  }
  return {
    /** The overlay canvas sized to the board, or null without a board. */
    ensure(){
      const view=globalThis.canvas?.app?.view??null;if(!view)return null;
      watch(view);
      if(!el||!el.isConnected){el=document.createElement('canvas');el.id=id;el.setAttribute('aria-hidden','true');
        el.style.cssText='position:fixed;pointer-events:none;left:0;top:0';view.after(el);styleKey='';rect=null;}
      rect??=view.getBoundingClientRect();
      const r=rect,dpr=Math.min(2,globalThis.devicePixelRatio||1),w=Math.round(r.width*dpr),h=Math.round(r.height*dpr);
      if(el.width!==w||el.height!==h){el.width=w;el.height=h;}
      const key=`${r.left}|${r.top}|${r.width}|${r.height}`;
      if(key!==styleKey){styleKey=key;Object.assign(el.style,{left:`${r.left}px`,top:`${r.top}px`,width:`${r.width}px`,height:`${r.height}px`});}
      return {el,r,dpr};
    },
    get element(){return el;},
    clear(){if(el)el.getContext('2d').clearRect(0,0,el.width,el.height);},
    /** Give the pixel memory back once nothing is drawing (up to ~33 MB at 4K). */
    release(){if(el){el.width=0;el.height=0;}},
    invalidate
  };
}
