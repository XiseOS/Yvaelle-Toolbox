/** Small serializable per-treatment sound overrides. No document or audio work. */
export const TREATMENT_AUDIO_STAGES=Object.freeze({depart:'Deploy',scan:'Scan',tool:'Treatment',success:'Success',criticalSuccess:'Exceptional success',failure:'Incomplete treatment',criticalFailure:'Disengage',return:'Return'});
export const V7_MEDKIT_AUDIO_STYLES=Object.freeze(['capillaryBridge','irisPatch','segmentedCradle','lymphaticCircuit','fibrilRepair','tissueLens','pulseReservoir','petalSanctuary']);
export const TREATMENT_SOUND_DESIGNS=Object.freeze({
  suture:'Electronic tension draws, alternating stitch contacts and a closing hardlight seal',
  lattice:'Materializing field joints with staggered actuator locks and powered support checks',
  compression:'Controlled containment charge, pressure modulation and a damped seal release',
  precision:'Focused electronic measuring passes, instrument contacts and fine actuator corrections',
  microloom:'Articulated shuttle passes, modulated fabrication energy and dressing checks',
  vascular:'Pulsed energy conduction through circuit gates, with measured valve contacts',
  helix:'Rotating inharmonic energy and opposing collar-alignment drives',
  splint:'Unfolding servos, paired brace locks and short support measurements',
  membrane:'An electronic enclosure charge with circulating hardlight repair energy',
  resonance:'Modulated diagnostic measurements resolving into a controlled alignment field',
  pulseHalo:'Charged restorative discharges and returning field measurements',
  mendingVeil:'Interwoven electronic projection passes with delicate seam-setting contacts',
  renewalSpiral:'Circulating energy drives with inward restorative transfer and instrument checks',
  heartline:'Measured diagnostic charging and paired restorative discharges, without monitor beeps',
  threadbind:'Fine filament draws, soft lacing ticks at each anchor and a low cinching hum',
  crystalCast:'Glassy settling chimes, one per plate, under a low resonant hum',
  wingSuture:'Long filament draws from the wings and quick light needle ticks',
  capillaryBridge:'Low braided conduction with staggered transfer gates and soft receiving contacts',
  irisPatch:'Quiet overlapping actuator draws, controlled scale contacts and damped closure',
  segmentedCradle:'Low suspension drive, articulated support contacts and gently balanced release',
  lymphaticCircuit:'Two measured filtration currents with muted gate transitions and contained reservoirs',
  fibrilRepair:'Fine low electronic tension with interlacing contacts and an unhurried finishing draw',
  tissueLens:'Layered low measuring resonance with slow optical articulation and soft contact focus',
  pulseReservoir:'Contained low charging basins and measured upward transfers without sharp discharges',
  petalSanctuary:'Soft suspended field resonance and gently opening medical petals; no voices or music'
});
const plain=v=>v&&typeof v==='object'&&!Array.isArray(v);
export const validTreatmentSound=value=>typeof value==='string'&&value.length<=2048&&!/[\u0000-\u001f]/.test(value)&&!/^\s*(?:javascript|data|file|blob):/i.test(value);
export function normalizeTreatmentAudio(value={}, {strict=true}={}){
  const fail=message=>{if(strict)throw new Error(message);};
  if(!plain(value)){fail('Treatment audio settings must be an object.');value={};}
  const out={volume:1,radius:20,sounds:{}};
  for(const key of Object.keys(value))if(!['volume','radius','sounds'].includes(key))fail(`Unknown treatment audio setting: ${key}.`);
  for(const [key,min,max] of [['volume',0,1],['radius',1,240]])if(value[key]!==undefined){
    if(!Number.isFinite(value[key])||value[key]<min||value[key]>max)fail(`Treatment audio ${key} must be ${min}–${max}.`);else out[key]=value[key];
  }
  if(value.sounds!==undefined){
    if(!plain(value.sounds))fail('Treatment sounds must be an object.');
    else for(const [stage,src]of Object.entries(value.sounds)){
      if(!Object.hasOwn(TREATMENT_AUDIO_STAGES,stage)){fail(`Unknown treatment sound stage: ${stage}.`);continue;}
      if(!validTreatmentSound(src)){fail('Use a Foundry-served audio path, HTTP(S) URL, none, or a blank default.');continue;}
      if(src.trim())out.sounds[stage]=src.trim();
    }
  }
  return out;
}
export function validTreatmentAudio(value){if(value===undefined)return true;try{normalizeTreatmentAudio(value);return true;}catch{return false;}}
export function treatmentAudioSlot(style,stage){return stage==='tool'?`medkit_${style}`:`medkit_${style}_${stage}`;}
