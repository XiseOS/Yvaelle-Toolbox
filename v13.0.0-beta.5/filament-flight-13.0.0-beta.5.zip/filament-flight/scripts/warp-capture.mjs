/** Warp capture (beta.29): a still copy of Ellie exactly as the canvas shows her
 * this frame (token art, every wing layer, each bit and her ground shadow), so
 * a warp can hide the real token and keep animating her wings and bits on the
 * warp layer instead of dropping them between two frames.
 *
 * The live wing layers and bits are PrimarySpriteMesh children of
 * canvas.primary named `filament-flight.<tokenId>.<part>` whose textures are 2D
 * canvases; they are copied once, at the hand-off, with their placement. All
 * offsets are world units from her centre. */
const ID='filament-flight';
const TAU=Math.PI*2;
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
const SKIP=/\.(trails|drag|flightfx|action|sprite)(\.|$)/;

function sourceOf(mesh){
  const tex=mesh?.texture,src=tex?.baseTexture?.resource?.source??tex?.baseTexture?.resource?.bitmap;
  if(!src||!(src.width>1||src.naturalWidth>1))return null;
  const fr=tex.frame??{x:0,y:0,width:src.width,height:src.height};
  return {src,fr:{x:fr.x,y:fr.y,width:fr.width,height:fr.height}};
}
function copyOf(src,fr,max=900){
  const s=Math.min(1,max/Math.max(fr.width,fr.height)),c=document.createElement('canvas');
  c.width=Math.max(1,Math.round(fr.width*s));c.height=Math.max(1,Math.round(fr.height*s));
  try{c.getContext('2d').drawImage(src,fr.x,fr.y,fr.width,fr.height,0,0,c.width,c.height);}catch{return null;}
  return c;
}

/** Copy her as she is drawn right now. `img` is her token art (already loaded).
 * Returns null when nothing can be copied (then callers keep the older look). */
/* beta.34: where and how big she is drawn. Flight feel lifts her body off
 * her token (height, hover, momentum sway), shrinks it with height and banks
 * it; the token mesh itself keeps her ground position. flight.mjs hands in a
 * reader for its per-token motion state. */
let poseSource=null;
export function setBodyPoseSource(fn){poseSource=typeof fn==='function'?fn:null;}
/** {dx,dy}: her body's offset from her token centre (world units), k: its
 * scale, bank: its extra turn. Neutral when she is not flying. */
export function bodyPose(token){
  let s=null;try{s=poseSource?.(token)??null;}catch{}
  const n=(v,d)=>Number.isFinite(v)?v:d;
  return {dx:n(s?.swayX,0),dy:n(s?.lift,0),k:Math.max(.05,n(s?.altScale,1)),sx:n(s?.squashX,1),sy:n(s?.squashY,1),bank:n(s?.bank,0)};
}
/** A world point moved to where her body is drawn over it. */
export function bodyPoint(p,pose){return pose?{x:p.x+pose.dx,y:p.y+pose.dy}:p;}
export function captureHer(token,img){
  if(!token||token.destroyed)return null;
  const g0=token.center??{x:token.x+token.w/2,y:token.y+token.h/2},m=token.mesh,tokenSort=m?.sort??0,pose=bodyPose(token);
  // offsets are taken from her body (lifted), so a copy drawn at the lifted
  // point lines up; her ground shadow keeps its offset down to the ground
  const c={x:g0.x+pose.dx,y:g0.y+pose.dy};
  const size=Math.max(token.w,token.h)||canvas?.grid?.size||100;
  const cap={cx:c.x,cy:c.y,size,pose,layers:[],bits:[],shadows:[],portrait:null};
  if(img){const w=Math.abs(m?.width||token.w||size)*pose.k*pose.sx,h=Math.abs(m?.height||token.h||size)*pose.k*pose.sy;cap.portrait={img,w,h,rot:(m?.rotation??0)+pose.bank,alpha:clamp(m?.alpha??1),x:0,y:0};
    // (a token mesh drawn off its centre keeps that offset; a stale or unrelated position is ignored)
    const ox=Number.isFinite(m?.x)?m.x-g0.x:0,oy=Number.isFinite(m?.y)?m.y-g0.y:0;if(Math.hypot(ox,oy)<size*.3){cap.portrait.x=ox;cap.portrait.y=oy;}}
  const prefix=`${ID}.${token.id??token.document?.id}.`;
  for(const mesh of globalThis.canvas?.primary?.children??[]){
    const name=mesh?.name;if(typeof name!=='string'||!name.startsWith(prefix)||SKIP.test(name))continue;
    if(mesh.visible===false||!(mesh.alpha>0.01)||mesh.destroyed)continue;
    const s=sourceOf(mesh);if(!s)continue;
    const src=copyOf(s.src,s.fr);if(!src)continue;
    const sx=Math.sign(mesh.scale?.x??1)||1,sy=Math.sign(mesh.scale?.y??1)||1;
    const part={name,src,x:mesh.x-c.x,y:mesh.y-c.y,rot:mesh.rotation||0,w:Math.abs(mesh.width)*sx,h:Math.abs(mesh.height)*sy,
      ax:mesh.anchor?.x??.5,ay:mesh.anchor?.y??.5,alpha:clamp(mesh.alpha),front:(mesh.sort??0)>tokenSort};
    if(name.includes('.bit.')){part.id=name.split('.bit.')[1].split('.')[0];cap.bits.push(part);}
    else if(/shadow$/i.test(name))cap.shadows.push(part);
    else cap.layers.push(part);
  }
  cap.wings=cap.layers.length>0;
  // bits keep their own order: rear copies first, then front ones
  cap.bits.sort((a,b)=>(a.front?1:0)-(b.front?1:0));
  // one entry per bit (its front/rear copies move together)
  const groups=new Map();for(const b of cap.bits){const g=groups.get(b.id)??{id:b.id,x:b.x,y:b.y,parts:[]};g.parts.push(b);groups.set(b.id,g);}
  cap.bitGroups=[...groups.values()].sort((a,b)=>a.y-b.y||a.x-b.x);
  if(!cap.portrait&&!cap.wings&&!cap.bits.length)return null;
  return cap;
}

/** Draw one copied mesh with the current transform at her centre (overlay
 * pixels, scale = overlay pixels per world unit). */
export function drawPart(f,p,scale,alpha=1,{dx=0,dy=0}={}){
  const a=p.alpha*alpha;if(a<=.004)return;
  f.save();f.globalAlpha=clamp(a);f.translate((p.x+dx)*scale,(p.y+dy)*scale);f.rotate(p.rot);
  f.drawImage(p.src,-p.ax*p.w*scale,-p.ay*p.h*scale,p.w*scale,p.h*scale);f.restore();
}
export function drawPortrait(f,cap,scale,alpha=1){
  const p=cap.portrait;if(!p||alpha*p.alpha<=.004)return;
  f.save();f.globalAlpha=clamp(alpha*p.alpha);f.translate((p.x||0)*scale,(p.y||0)*scale);f.rotate(p.rot);f.drawImage(p.img,-p.w*scale/2,-p.h*scale/2,p.w*scale,p.h*scale);f.restore();
}
/** Her whole copy in the canvas' own order: shadow, rear wings, rear bits,
 * token, front wings, front bits. `wing(f,part)` may wrap each wing layer in a
 * transform (folds); `bit` likewise for bits. */
export function drawHer(f,cap,scale,{alpha=1,wings=1,bits=1,portrait=1,shadow=1,wing=null,bit=null}={}){
  for(const s of cap.shadows)drawPart(f,s,scale,alpha*shadow);
  const layer=(front)=>{for(const p of cap.layers)if(p.front===front){if(wing){f.save();wing(f,p);drawPart(f,p,scale,alpha*wings);f.restore();}else drawPart(f,p,scale,alpha*wings);}
    for(const p of cap.bits)if(p.front===front){if(bit){f.save();bit(f,p);drawPart(f,p,scale,alpha*bits);f.restore();}else drawPart(f,p,scale,alpha*bits);}};
  layer(false);drawPortrait(f,cap,scale,alpha*portrait);layer(true);
}

/** Her wings (and optionally token) flattened into one canvas in world units,
 * for clipping, masking and slicing. Cached per key. */
export function composite(cap,{wings=true,portrait=true,res=1.5}={}){
  const key=`${wings}|${portrait}|${res}`;cap.composites??={};if(cap.composites[key])return cap.composites[key];
  let x0=-cap.size*.6,y0=-cap.size*.6,x1=cap.size*.6,y1=cap.size*.6;
  if(wings)for(const p of cap.layers){const r=Math.hypot(p.w,p.h)*.75;x0=Math.min(x0,p.x-r);x1=Math.max(x1,p.x+r);y0=Math.min(y0,p.y-r);y1=Math.max(y1,p.y+r);}
  const c=document.createElement('canvas');c.width=Math.max(2,Math.ceil((x1-x0)*res));c.height=Math.max(2,Math.ceil((y1-y0)*res));
  const g=c.getContext('2d');g.translate(-x0*res,-y0*res);
  if(wings)for(const p of cap.layers)if(!p.front)drawPart(g,p,res);
  if(portrait)drawPortrait(g,cap,res);
  if(wings)for(const p of cap.layers)if(p.front)drawPart(g,p,res);
  return cap.composites[key]={canvas:c,x0,y0,x1,y1,res};
}
export function drawComposite(f,comp,scale,alpha=1){
  if(alpha<=.004)return;f.save();f.globalAlpha=clamp(alpha);f.drawImage(comp.canvas,comp.x0*scale,comp.y0*scale,(comp.x1-comp.x0)*scale,(comp.y1-comp.y0)*scale);f.restore();
}
/** Points on her lit wing filaments (world offsets), brightest first spread
 * out: where threads leave and re-knit. Deterministic for a given copy. */
export function filamentPoints(cap,n=48){
  cap.points??={};if(cap.points[n])return cap.points[n];
  const out=[];
  if(cap.wings){
    const comp=composite(cap,{wings:true,portrait:false,res:.5}),c=comp.canvas;
    let data=null;try{data=c.getContext('2d').getImageData(0,0,c.width,c.height).data;}catch{}
    if(data){const cand=[];for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){const a=data[(y*c.width+x)*4+3];if(a>60)cand.push([x,y,a]);}
      // spread: walk a hashed order and keep points that are not too close
      const min=cap.size*.14;
      for(let i=0;i<cand.length&&out.length<n;i++){const k=Math.floor(hash(i*3.17+.5)*cand.length),[x,y,a]=cand[k];
        const wx=comp.x0+(x+.5)/comp.res,wy=comp.y0+(y+.5)/comp.res;if(Math.hypot(wx,wy)<cap.size*.42)continue;
        if(out.some(p=>Math.hypot(p.x-wx,p.y-wy)<min))continue;out.push({x:wx,y:wy,a:a/255});}
    }
  }
  // no wings showing: points over her portrait instead; otherwise a loose wing-shaped spread
  for(let i=out.length;i<n;i++){const u=hash(i*1.9),v=hash(i*2.3);
    if(!cap.wings){const a=v*TAU,r=Math.sqrt(u)*cap.size*.45;out.push({x:Math.cos(a)*r,y:Math.sin(a)*r,a:.6});continue;}
    const side=i%2?1:-1;out.push({x:side*cap.size*(.5+1.1*u),y:cap.size*(-.9+1.5*v)*(1-.4*u),a:.6});}
  return cap.points[n]=out;
}
/** A wing layer tinted one colour (its filaments lit gold, say), cached. */
export function tinted(cap,part,rgb){
  part.tints??={};const key=rgb.join(',');if(part.tints[key])return part.tints[key];
  const c=document.createElement('canvas');c.width=part.src.width;c.height=part.src.height;const g=c.getContext('2d');
  g.drawImage(part.src,0,0);g.globalCompositeOperation='source-in';g.fillStyle=`rgb(${key})`;g.fillRect(0,0,c.width,c.height);
  return part.tints[key]=c;
}
export {TAU,hash,clamp};
