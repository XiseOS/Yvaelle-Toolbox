/** Yvaelle’s Toolbox v11 · the nested quick wheel: tree, smart rules, migration
 * and the macro ring's storage. Pure data and pure functions (no DOM, no
 * Foundry): tools/v11/test-wheel.mjs checks every rule here.
 *
 * Every leaf is an ordinary quick-wheel slot {action, value} from
 * WHEEL_CATALOG (plus emote and fade), so quick-wheel.mjs's describe(slot) and
 * run(slot) do the work. This file decides WHERE things sit and WHEN they can
 * be used.
 *
 * TREE
 *   main ring (12 positions, 30° apart)
 *     cardinals : Her (12) · Light (3) · Macros (6) · Emotes (9)  (swappable, hideable)
 *     sockets   : up to 6 user shortcuts on the 8 places between them
 *     centre    : her token. Releasing there CANCELS (nothing runs).
 *     last used : a separate small gem just below her rim (never the centre).
 *   Her → one ring, three tinted arcs (Flight top, Bits right, Wings left).
 *     Each arc shows the user's own 3 or 4 picks (Settings, default 4) + More….
 *     Context ONLY ADDS: situational options (Climb, Descend, Shield, Bind)
 *     appear in a small inner "context lane" of the arc, each at its own fixed
 *     place; the user's picks never move and never step into More….
 *   Light → Light on/off · Aim lantern · Leave a light · Light my target
 *   Emotes → ten emotes · Macros → the user's macro ring (user flag). */

export const MAIN_POSITIONS=12;
export const CARDINALS=Object.freeze([0,3,6,9]);
export const SOCKETS=Object.freeze([1,2,4,5,7,8,10,11]);
export const MAX_SHORTCUTS=6;
export const CATEGORIES=Object.freeze({
  her:{name:'Her',icon:'her',hint:'Flight · Wings · Bits'},
  light:{name:'Light',icon:'light',hint:'Her light and lantern'},
  macros:{name:'Macros',icon:'macroCat',hint:'Your own macros'},
  emotes:{name:'Emotes',icon:'emotes',hint:'Ten wing emotes'},
  // (test.16) the doors layout: what she does, where it goes
  actions:{name:'Actions',icon:'actions',hint:'Teleport · fade · shield · light'},
  bits:{name:'Bits',icon:'bitsDoor',hint:'Summon · formations · tools'}
});

/* ------------------------------------------------------------ (test.16) the doors layout */
/** Two layouts of the same wheel (Settings › Emotes & wheel › Nested wheel › Parts › Layout):
 *   'doors'   (default) four doors named for what they do, each opening ONE ring of named gems:
 *             Her (flying, her wings, and Emote as a single gem) · Actions (teleport, fade, shield,
 *             light, medkit) · Bits · Macros. Each ring holds up to RING_SLOTS of your own picks
 *             and a More… gem that lists everything else that door offers (◆ keeps one on the ring).
 *   'classic' Her (three arcs) · Light · Macros · Emotes, as before.
 * Both keep the same favourites (shortcuts) on the main ring, and each keeps its own picks, so
 * switching back and forth loses nothing. */
export const LAYOUTS=Object.freeze(['doors','classic']);
export const layoutOf=v=>v==='classic'?'classic':'doors';
export const DOOR_CATS=Object.freeze(['her','actions','bits','macros']);
export const CLASSIC_CATS=Object.freeze(['her','light','macros','emotes']);
export const catsOf=layout=>layoutOf(layout)==='doors'?DOOR_CATS:CLASSIC_CATS;
export const DOOR_ORDER=Object.freeze({0:'her',3:'actions',6:'macros',9:'bits'});
export const DOOR_HINTS=Object.freeze({her:'Fly · wings · emote'});
export const RING_SLOTS=8;
/** A door's ring: RING_SLOTS places and More…, evenly round the circle, dealt clockwise from the door. */
export const RING_STEP=360/(RING_SLOTS+1);
export const DOORS=Object.freeze({
  her:{name:'Her',tint:'#ff7ae6'},
  actions:{name:'Actions',tint:'#c39bff'},
  bits:{name:'Bits',tint:'#e9c789'}
});
const S0=(action,value=null)=>({action,value});
export const DEFAULT_RINGS=Object.freeze({
  her:[S0('flight'),S0('height','up'),S0('wings'),S0('pose','forwardGuard'),S0('gesture','lunarBow'),S0('reaction','pulse'),S0('emote','bow'),S0('look','builtin:ellie')],
  actions:[S0('warp'),S0('warpBare'),S0('fade'),S0('shield'),S0('afterimages','last'),S0('light'),S0('lanternAim'),S0('medkit')],
  bits:[S0('bits'),S0('formation','halo'),S0('gatherBits'),S0('sendBits'),S0('scanArea','region'),S0('examine'),S0('routine'),null]
});
/** Which door an action belongs behind (More… lists, and where a classic pick is carried to). */
export function doorOf(slot){
  const a=slot?.action;
  if(['flight','wings','height','wingShadow','sound','pose','gesture','reaction','look','condition','emote'].includes(a))return 'her';
  if(['bits','gatherBits','sendBits','examine','scanArea','formation','routine'].includes(a))return 'bits';
  if(a==='macro')return 'macros';
  return 'actions';
}
/** Everything a door offers (its More… list, and the library in Edit). */
export const DOOR_GROUPS=Object.freeze({
  her:{name:'Her',rows:[S0('flight'),S0('wings'),S0('wingShadow'),S0('sound'),{param:'heightStep',action:'height'},{param:'emote',action:'emote'},{param:'pose',action:'pose'},{param:'gesture',action:'gesture'},{param:'reaction',action:'reaction'},{param:'look',action:'look'},{param:'condition',action:'condition'}]},
  actions:{name:'Actions',rows:[S0('warp'),S0('warpBare'),S0('fade'),S0('shield'),S0('afterimages','last'),S0('light'),S0('lanternAim'),S0('parkLight','point'),S0('parkLight','target'),S0('decoy','cast'),S0('decoy','warp'),S0('decoyLook'),S0('medkit'),S0('hud'),{param:'feature',action:'feature'}]},
  bits:{name:'Bits',rows:[S0('bits'),S0('gatherBits'),S0('sendBits'),S0('examine'),S0('scanArea','region'),S0('scanArea','around'),{param:'formation',action:'formation'},{param:'routine',action:'routine'}]}
});
/** Context only adds, as in the classic arcs: each at its own place in a small inner lane at the door. */
export const DOOR_LANES=Object.freeze({
  her:[{id:'descend',at:-1,why:'flying',want:c=>c.air?S0('height','down'):null},{id:'climb',at:1,why:'flying',want:c=>c.air?S0('height','up'):null}],
  actions:[{id:'shield',at:0,why:'combat',want:c=>c.combat&&c.wingsOpen?S0('shield'):null}],
  bits:[{id:'bind',at:0,why:'combat',want:c=>c.combat&&c.targets===1&&c.bitsOut?S0('sendBits'):null}]
});
/** One door's ring as shown → {slots:[{slot,index,context}|null ×RING_SLOTS], lane:[{slot,id,at,why}]}.
 * The user's picks keep their places; a context item already on the ring is marked there, not doubled. */
export function arrangeRing(door,userSlots,ctx){
  const slots=[];for(let i=0;i<RING_SLOTS;i++){const s=userSlots?.[i];slots.push(s?{slot:s,index:i,context:false}:null);}
  const lane=[],c=ctx??context();
  for(const L of DOOR_LANES[door]??[]){const want=L.want(c);if(!want)continue;
    const mine=slots.find(e=>e&&e.slot.action===want.action&&(e.slot.value??null)===(want.value??null));
    if(mine){mine.context=L.why;continue;}
    lane.push({slot:want,id:L.id,at:L.at,why:L.why});}
  return {slots,lane};
}
/** ◆ in a door's More…: keep on the ring / take off it. The first free place, else the last place. Pure. */
export function toggleRingPin(ring,slot){
  const a=(ring??[]).slice(0,RING_SLOTS);while(a.length<RING_SLOTS)a.push(null);
  const i=a.findIndex(x=>x&&x.action===slot.action&&(x.value??null)===(slot.value??null));
  if(i>=0){a[i]=null;return a;}
  const e=a.findIndex(x=>!x);a[e>=0?e:RING_SLOTS-1]=S0(slot.action,slot.value??null);return a;
}
/** The rings for someone who has never used the doors layout: the defaults, with any pick they had put in a classic
 * arc themselves carried to its door (into a free place, else in place of the last default, two a door at most). */
export function ringsFromClassic(arcs){
  const rings=structuredClone(DEFAULT_RINGS),added={her:0,actions:0,bits:0};
  for(const id of Object.keys(DEFAULT_ARCS)){const mine=arcs?.[id]??[],def=DEFAULT_ARCS[id];
    for(const s of mine){if(!s||def.some(d=>d.action===s.action&&(d.value??null)===(s.value??null)))continue;
      const door=doorOf(s),ring=rings[door];if(!ring||added[door]>=2)continue;
      // (an action that is one gem with options in the doors layout is already there: its option is taken)
      const same=ring.findIndex(x=>x&&x.action===s.action);
      if(same>=0&&['pose','gesture','reaction','look','emote','formation','routine','condition','warp','warpBare'].includes(s.action)){ring[same]=S0(s.action,s.value??null);continue;}
      if(ring.some(x=>x&&x.action===s.action&&(x.value??null)===(s.value??null)))continue;
      const e=ring.findIndex(x=>!x);ring[e>=0?e:RING_SLOTS-1-added[door]]=S0(s.action,s.value??null);added[door]++;}}
  return rings;
}

/* ------------------------------------------------------------ Her: arcs */
/** centre = degrees clockwise from 12 o'clock. */
export const ARC_STEP=22;
export const ARCS=Object.freeze({
  flight:{name:'Flight',centre:0,tint:'#ff7ae6'},
  bits:{name:'Bits',centre:120,tint:'#e9c789'},
  wings:{name:'Wings',centre:240,tint:'#c39bff'}
});
/** User slot i → offset (in ARC_STEPs) from the arc centre. Slot 0 is the
 * centre; with 3 options the -2 place is simply not used. More… is always +2. */
export const ARC_OFFSETS=Object.freeze([0,1,-1,-2]);
export const ARC_MORE_OFFSET=2;
export const ARC_SLOTS=4;
export const ARC_SIZES=Object.freeze([3,4]);
export const arcSize=v=>+v===3?3:4;

const S=(action,value=null)=>({action,value});
export const DEFAULT_ARCS=Object.freeze({
  flight:[S('flight'),S('wings'),S('warp'),S('shield')],
  bits:[S('bits'),S('formation','halo'),S('gatherBits'),S('examine')],
  wings:[S('reaction','pulse'),S('gesture','lunarBow'),S('pose','forwardGuard'),S('look','builtin:ellie')]   // (test.2) her own look: 'moonlit' was a lab look, not a module preset
});

/* ------------------------------------------------------------ context lane */
/** The context lane sits inside the arc, between her and the arc, at offsets
 * of LANE_STEP degrees from the arc centre. Each context item has ITS OWN
 * place (never shared, never shuffled), so Climb is always in the same spot
 * when it shows. */
export const LANE_STEP=20;
export const CONTEXT_LANES=Object.freeze({
  flight:[
    {id:'descend',at:-1,why:'flying',want:c=>c.air?S('height','down'):null},
    {id:'shield',at:0,why:'combat',want:c=>c.combat&&c.wingsOpen?S('shield'):null},
    {id:'climb',at:1,why:'flying',want:c=>c.air?S('height','up'):null}],
  bits:[
    {id:'bind',at:0,why:'combat',want:c=>c.combat&&c.targets===1&&c.bitsOut?S('sendBits'):null}],
  wings:[]
});
export function context(s={}){
  return {air:!!s.air,combat:!!s.combat,bitsOut:!!s.bitsOut,targets:s.targets??0,lanternLit:!!s.lanternLit,wingsOpen:s.wingsOpen!==false,shieldNoWings:!!s.shieldNoWings,
    fade:!!s.fade,emotesOff:s.emotesOff instanceof Set?s.emotesOff:new Set(s.emotesOff??[]),emotesOn:s.emotesOn!==false,
    // (12.0.0-beta.5) lights her bits have left out, by the gem that left them
    parked:{point:Number(s.parked?.point)||0,target:Number(s.parked?.target)||0},
    // (12.0.0-beta.6) her decoy: standing now, and whether the feature is on
    decoy:!!s.decoy,decoyOn:s.decoyOn!==false};
}
export const slotKey=s=>s?`${s.action}:${s.value??''}`:'';
export const sameSlot=(a,b)=>!!a&&!!b&&a.action===b.action&&(a.value??null)===(b.value??null);

/** One arc as shown. Context only ADDS:
 *  · the user's picks keep their own places, always (slots[i] is userSlots[i]);
 *  · a context item the user already shows is not doubled: that gem is marked
 *    `context` (a small gold notch) in place;
 *  · otherwise it appears in the lane at its own fixed place.
 * → {slots:[{slot,index,offset,context}|null], lane:[{slot,id,at,why}], more:offset} */
export function arrangeArc(arcId,userSlots,ctx,size=ARC_SLOTS){
  const n=arcSize(size),slots=[];
  for(let i=0;i<n;i++){const s=userSlots?.[i];slots.push(s?{slot:s,index:i,offset:ARC_OFFSETS[i],context:false}:null);}
  const lane=[],c=ctx??context();
  for(const L of CONTEXT_LANES[arcId]??[]){
    const want=L.want(c);if(!want)continue;
    const mine=slots.find(e=>sameSlot(e?.slot,want));
    if(mine){mine.context=L.why;continue;}
    lane.push({slot:want,id:L.id,at:L.at,why:L.why});
  }
  return {slots,lane,more:ARC_MORE_OFFSET};
}

/* ------------------------------------------------------------ availability */
const BITS_NEEDED=new Set(['formation','gatherBits','sendBits','examine','scanArea','parkLight','routine']);
/** Unavailable → the reason shown in the plaque. Greyed in place, never hidden. */
export function unavailable(slot,ctx){
  const a=slot?.action;if(!a)return null;const c=ctx??context();
  if(a==='height')return c.air?null:'Grounded · take off first';
  // (12.0.0-beta.5) a light this gem left is out: the gem calls it back, whatever her bits or targets are now
  if(a==='parkLight'&&c.parked?.[slot.value==='target'?'target':'point']>0)return null;
  // (12.0.0-beta.6) the Decoy: its gem always ends a standing one; making one needs the feature on, and a cast needs her bits out
  if(a==='decoy'){if(c.decoy)return null;if(!c.decoyOn)return 'The Decoy is off in Settings';if(slot.value!=='warp'&&!c.bitsOut)return 'No bits summoned';return null;}
  if(a==='decoyLook')return c.decoy?null:'No decoy stands';
  if(BITS_NEEDED.has(a)&&!c.bitsOut)return 'No bits summoned';
  if((a==='sendBits'||(a==='parkLight'&&slot.value==='target'))&&c.targets!==1)return c.targets?'Target just one token':'Target one token first';
  if(a==='lanternAim'&&!c.lanternLit)return 'Light the lantern first';
  if(a==='shield'&&!c.wingsOpen&&!c.shieldNoWings)return c.bitsOut?'Open your wings first':'Open your wings or summon her bits first';
  if(a==='fade'&&!c.fade)return 'Fade is not in this build yet';
  if(a==='emote'){if(!c.emotesOn)return 'Emotes are off in Settings';if(c.emotesOff.has(slot.value))return 'This emote is off in Settings';}
  return null;
}
export const TOGGLES=new Set(['flight','wings','bits','light','lanternAim','afterimages','shield','wingShadow','sound','fade','feature','parkLight','decoy','decoyLook']);
export function groupOf(slot){
  const a=slot?.action;
  if(['flight','wings','height','shield','warp','warpBare','afterimages','wingShadow','sound','decoy','decoyLook'].includes(a))return 'flight';
  if(['bits','gatherBits','sendBits','examine','scanArea','formation','routine'].includes(a))return 'bits';
  if(['reaction','gesture','pose','look','condition','fade'].includes(a))return 'wings';
  if(['light','lanternAim','parkLight'].includes(a))return 'light';
  if(a==='emote')return 'emotes';if(a==='macro')return 'macros';if(a==='feature')return 'features';return 'other';
}
/** Everything a group offers (More… lists these; Edit's library too). `param` rows expand to every value. */
export const GROUPS=Object.freeze({
  flight:{name:'Flight',rows:[S('flight'),S('wings'),{param:'heightStep',action:'height'},S('shield'),S('warp'),S('warpBare'),S('decoy','cast'),S('decoy','warp'),S('decoyLook'),S('afterimages','last'),S('wingShadow'),S('sound')]},
  bits:{name:'Bits',rows:[S('bits'),S('gatherBits'),S('sendBits'),S('examine'),S('scanArea','region'),S('scanArea','around'),{param:'formation',action:'formation'},{param:'routine',action:'routine'}]},
  wings:{name:'Wings',rows:[S('fade'),{param:'reaction',action:'reaction'},{param:'gesture',action:'gesture'},{param:'pose',action:'pose'},{param:'look',action:'look'},{param:'condition',action:'condition'}]},
  light:{name:'Light',rows:[S('light'),S('lanternAim'),S('parkLight','point'),S('parkLight','target')]},
  emotes:{name:'Emotes',rows:[{param:'emote',action:'emote'}]},
  macros:{name:'Macros',rows:[{param:'macro',action:'macro'}]},
  features:{name:'Features',rows:[{param:'feature',action:'feature'}]},
  other:{name:'Other',rows:[S('medkit'),S('hud')]}
});
/** The Light ring: four, in this order, dealt from the Light door. */
export const LIGHT_ITEMS=Object.freeze([S('light'),S('lanternAim'),S('parkLight','point'),S('parkLight','target')]);
export const LIGHT_OFFSETS=Object.freeze([0,1,-1,2]);
export const LIGHT_STEP=26;

/* ------------------------------------------------------------ fast-flick safety */
/** A very fast flick through Her must not fire Take off by accident.
 * An action fires on key release only when the release point is inside the
 * option's gem zone, or the pointer came to REST pointing at it (still for
 * SAFE_DWELL_MS, near its ring, and not right after a flick opened the ring).
 * dwellMs is time at rest (any move over a few pixels restarts it), not time
 * since the pick, so a flick that keeps moving past the gem never counts.
 * Otherwise the wheel stays open for a click. */
export const SAFE_DWELL_MS=140;
export const SAFE_AFTER_FLICK_MS=240;
export const GEM_ZONE_PX=26;
export const REST_MOVE_PX=6;
export const NEAR_RING_PX=44;
export function releaseDecision({inZone=false,near=true,dwellMs=0,sinceEnterMs=Infinity,swift=false}={}){
  if(inZone)return 'fire';
  if(near&&dwellMs>=SAFE_DWELL_MS&&!(swift&&sinceEnterMs<SAFE_AFTER_FLICK_MS))return 'fire';
  return 'hold';
}

/* ------------------------------------------------------------ config + migration */
/** Client setting `quickWheel`, version 2:
 * {version:2, slots:[v1 flat slots, kept untouched for a rollback], shortcuts:{[socket]:slot},
 *  order:{[cardinal]:categoryId}, hidden:[categoryId], arcs:{flight,bits,wings:[slot|null ×4]},
 *  macros:[uuid] (old macro slots, seed the macro ring once), last:slot|null} */
export const FRESH_SHORTCUTS=Object.freeze({1:S('flight'),11:S('bits'),7:S('medkit')});
export function freshConfig(){return {version:2,slots:[],shortcuts:structuredClone(FRESH_SHORTCUTS),order:{0:'her',3:'light',6:'macros',9:'emotes'},hidden:[],arcs:structuredClone(DEFAULT_ARCS),macros:[],last:null,
  // (test.16) the doors layout's own order and rings (rings: null until first used, then seeded from the classic arcs)
  order2:{...DOOR_ORDER},rings:null};}
const OLD_DEFAULTS=[['flight'],['wings'],['bits'],['formation','halo'],['light'],['reaction','pulse'],['medkit'],['hud']];
const sameAsOld=slots=>slots.length===OLD_DEFAULTS.length&&slots.every((s,i)=>s.action===OLD_DEFAULTS[i][0]&&(s.value??null)===(OLD_DEFAULTS[i][1]??null));
const isSlot=s=>!!s&&typeof s==='object'&&typeof s.action==='string'&&s.action.length>0;
const cleanSlot=s=>isSlot(s)?S(s.action,s.value??null):null;
/** v1 flat slots → v2.
 *  · Untouched v1 defaults (or nothing stored) → the new calm defaults (3 shortcuts).
 *  · Customised: each old slot (in order) becomes a shortcut on the free socket
 *    nearest its old angle, so muscle memory roughly survives. "Open the HUD"
 *    moves to the plaque. Past 6, a macro joins the macro ring seed and a Her
 *    action takes a free arc slot; everything stays reachable in More….
 *  · The v1 array is kept untouched (rolling back to 10.0.1 reads it). */
export function migrate(raw){
  if(raw?.version===2)return sanitize(raw);
  const cfg=freshConfig(),slots=Array.isArray(raw?.slots)?raw.slots.filter(isSlot):[];
  cfg.slots=structuredClone(slots);
  for(const s of slots)if(s.action==='macro'&&typeof s.value==='string'&&!cfg.macros.includes(s.value))cfg.macros.push(s.value);
  if(!slots.length||sameAsOld(slots))return cfg;
  cfg.shortcuts={};const n=slots.length,free=new Set(SOCKETS),seen=new Set();let placed=0;
  slots.forEach((s,i)=>{
    const slot=S(s.action,s.value??null),k=slotKey(slot);
    if(s.action==='hud'||seen.has(k))return;seen.add(k);
    if(placed>=MAX_SHORTCUTS){const g=groupOf(slot),arc=cfg.arcs[g];
      if(arc&&!arc.some(x=>sameSlot(x,slot))){const e=arc.findIndex(x=>!x);if(e>=0)arc[e]=slot;}return;}
    const deg=i*360/n;let best=null,bd=1e9;
    for(const q of SOCKETS){if(!free.has(q))continue;const d=Math.abs(((q*30-deg+540)%360)-180);if(d<bd-1e-6){bd=d;best=q;}}
    free.delete(best);cfg.shortcuts[best]=slot;placed++;
  });
  return cfg;
}
/** A stored v2 config made safe to use (bad pieces fall back to defaults). */
export function sanitize(raw){
  const cfg=freshConfig();
  cfg.slots=Array.isArray(raw.slots)?raw.slots.filter(isSlot):[];
  if(raw.shortcuts&&typeof raw.shortcuts==='object'){cfg.shortcuts={};let n=0;
    for(const p of SOCKETS){const s=cleanSlot(raw.shortcuts[p]);if(s&&n<MAX_SHORTCUTS){cfg.shortcuts[p]=s;n++;}}}
  if(raw.order&&typeof raw.order==='object'){const o={},used=new Set();
    for(const p of CARDINALS){const c=raw.order[p];if(CLASSIC_CATS.includes(c)&&!used.has(c)){o[p]=c;used.add(c);}}
    for(const c of CLASSIC_CATS)if(!used.has(c)){const p=CARDINALS.find(q=>!o[q]);if(p!=null)o[p]=c;}
    cfg.order=o;}
  if(raw.order2&&typeof raw.order2==='object'){const o={},used=new Set();
    for(const p of CARDINALS){const c=raw.order2[p];if(DOOR_CATS.includes(c)&&!used.has(c)){o[p]=c;used.add(c);}}
    for(const c of DOOR_CATS)if(!used.has(c)){const p=CARDINALS.find(q=>!o[q]);if(p!=null)o[p]=c;}
    cfg.order2=o;}
  cfg.hidden=Array.isArray(raw.hidden)?raw.hidden.filter(c=>CATEGORIES[c]):[];
  if(raw.arcs&&typeof raw.arcs==='object')for(const id of Object.keys(ARCS))if(Array.isArray(raw.arcs[id])){
    const a=raw.arcs[id].slice(0,ARC_SLOTS).map(cleanSlot);while(a.length<ARC_SLOTS)a.push(null);cfg.arcs[id]=a;}
  if(raw.rings&&typeof raw.rings==='object'){cfg.rings={};
    for(const id of Object.keys(DOORS)){const a=Array.isArray(raw.rings[id])?raw.rings[id].slice(0,RING_SLOTS).map(cleanSlot):structuredClone(DEFAULT_RINGS[id]);while(a.length<RING_SLOTS)a.push(null);cfg.rings[id]=a;}
    // (test.18) a ring saved by test.16/17 could hold two wing warps and no bare one: the second becomes the bare warp, with its look
    const A=cfg.rings.actions,w=A.map((s,i)=>s?.action==='warp'?i:-1).filter(i=>i>=0);if(w.length>1&&!A.some(s=>s?.action==='warpBare'))A[w[1]]=S('warpBare',A[w[1]].value??null);}
  cfg.macros=Array.isArray(raw.macros)?raw.macros.filter(u=>typeof u==='string'):[];
  cfg.last=cleanSlot(raw.last);
  return cfg;
}
/** What the old flat wheel saves when the nested wheel is switched off: only
 * `slots` changes, so turning the nested wheel back on finds everything. */
export function withFlatSlots(raw,slots){
  const base=raw&&typeof raw==='object'?structuredClone(raw):{};
  base.slots=structuredClone(slots);return base;
}
/** Pin or unpin an item in a Her arc (More… ◆). The first free place among the
 * shown ones, else the last shown place. Pure: returns a new arc list. */
export function togglePin(arc,slot,size=ARC_SLOTS){
  const n=arcSize(size),a=(arc??[]).slice(0,ARC_SLOTS);while(a.length<ARC_SLOTS)a.push(null);
  const i=a.findIndex((x,k)=>k<n&&sameSlot(x,slot));
  if(i>=0){a[i]=null;return a;}
  const e=a.findIndex((x,k)=>k<n&&!x);a[e>=0?e:n-1]=S(slot.action,slot.value??null);return a;
}

/* ------------------------------------------------------------ macro ring storage */
/** Stored on the USER (flags.filament-flight.macroRing), so it follows the
 * player across browsers: {v:1, slots:[{uuid, icon|null}]}. Up to 12. */
export const MACRO_FLAG='macroRing';
export const MACRO_RING_MAX=12;
export function normalizeRing(raw){
  const list=Array.isArray(raw)?raw:Array.isArray(raw?.slots)?raw.slots:[];
  const out=[],seen=new Set();
  for(const e of list){
    const uuid=typeof e==='string'?e:e?.uuid;if(typeof uuid!=='string'||!uuid||seen.has(uuid))continue;
    seen.add(uuid);const icon=typeof e?.icon==='string'&&/^(mi-|fi:)[a-z0-9-]+$/.test(e.icon)?e.icon:null;
    out.push({uuid,icon});if(out.length>=MACRO_RING_MAX)break;
  }
  return out;
}
export const ringFlagValue=list=>({v:1,slots:normalizeRing(list)});
/** The ring to show: the saved flag; never saved yet → the macros of the old flat wheel. */
export function ringFrom(flag,seed=[]){return flag&&Array.isArray(flag.slots)?normalizeRing(flag):normalizeRing(seed);}
/** Reorder: move index `from` to `to`. Pure. */
export function moveInRing(list,from,to){const a=list.slice();if(from<0||from>=a.length)return a;const [x]=a.splice(from,1);a.splice(Math.max(0,Math.min(to,a.length)),0,x);return a;}
/** Add (or move, if already there) a macro at `at`. Returns {list, added:boolean, full:boolean}. */
export function addToRing(list,uuid,at=list.length){
  const was=list.findIndex(e=>e.uuid===uuid);
  if(was<0&&list.length>=MACRO_RING_MAX)return {list,added:false,full:true};
  const a=list.slice();let entry={uuid,icon:null};
  if(was>=0){entry=a.splice(was,1)[0];if(at>was)at--;}
  a.splice(Math.max(0,Math.min(at,a.length)),0,entry);
  return {list:a,added:was<0,full:false};
}
/** How one ring entry shows: 'macro' (runnable), 'locked' (you can't run it) or 'missing' (deleted). */
export function macroState(info){return !info?'missing':info.canExecute===false?'locked':'macro';}
/** The first comment line of a script macro, the first line of a chat macro, or "Run macro". */
export function macroLine(type,command){
  const lines=String(command??'').split('\n').map(l=>l.trim()).filter(Boolean);
  if(type==='script'){for(const l of lines){const m=l.match(/^\/\/+\s*(.+)$/)||l.match(/^\/\*+\s*(.*?)\s*(\*\/)?$/);if(m&&m[1])return m[1].slice(0,80);if(!l.startsWith('//')&&!l.startsWith('/*'))break;}return 'Run macro';}
  return lines[0]?lines[0].slice(0,80):'Run macro';
}

/* ------------------------------------------------------------ emotes */
/** The ten emotes of the Emotes ring, in ring order. `gesture` = the wing
 * gesture that already carries it (synced to every client, and her token
 * layer reads it as the emote); `layer` = the token-layer emote played
 * directly when there is no gesture. Laugh is laugh A (the soft chuckle)
 * unless Settings › Emotes › Laugh says B. */
export const EMOTE_LIST=Object.freeze([
  {id:'bow',label:'Bow',hint:'A deep, graceful sweep forward and down',gesture:'lunarBow',layer:'bow'},
  {id:'laugh',label:'Laugh',hint:'A soft shoulder-lift and three easy bounces',layer:null},
  {id:'sigh',label:'Sigh',hint:'The wings droop, then slowly lift back',gesture:'heldBreath',layer:'sigh'},
  {id:'shrug',label:'Shrug',hint:'Both wings lift and drop once',gesture:'resolveArc',layer:'shrug'},
  {id:'wave',label:'Wave',hint:'One wing gives a gentle wave',gesture:'greetingFold',layer:null},
  {id:'cheer',label:'Cheer',hint:'The wings flare up and the bits spin once',layer:null},
  {id:'startle',label:'Startle',hint:'The wings snap in tight, then ease out',layer:'startle'},
  {id:'comfort',label:'Comfort',hint:'The wings wrap round the ally beside her',layer:null,sided:true},
  {id:'curious',label:'Curious',hint:'A slight tilt; the bits lean in toward something',gesture:'featherTurn',layer:'curious'},
  {id:'pray',label:'Pray',hint:'Wings fold forward like cupped hands; a soft glow',gesture:'softShelter',layer:'pray'}
]);
export const EMOTE_IDS=Object.freeze(EMOTE_LIST.map(e=>e.id));
export const emoteById=id=>EMOTE_LIST.find(e=>e.id===id)??null;
/** The settings part that switches an emote (features.mjs: emotes › emoteBow…). */
export const emotePart=id=>'emote'+id[0].toUpperCase()+id.slice(1);
/** Laugh A unless the laugh picker says B: the variant id later phases play. */
export const emoteVariant=(id,laughStyle='a')=>id==='laugh'?`laugh_${laughStyle==='b'?'b':'a'}`:id;
/** Which side a one-sided emote (Comfort) plays to, from where the ally is in
 * HER frame: +1 ally on her right (as authored), −1 on her left (mirrored).
 * rotation in degrees (her token's). A small dead band straight ahead or
 * behind keeps the authored side, so it never flickers. */
export function emoteSide(her,ally,{deadBand=.12,size=100}={}){
  if(!her||!ally)return 1;
  const a=-(her.rotation??0)*Math.PI/180,dx=ally.x-her.x,dy=ally.y-her.y;
  const lx=(dx*Math.cos(a)-dy*Math.sin(a))/(size||100);
  return lx< -deadBand?-1:1;
}
/** The ally Comfort wraps round: the one targeted ally if any, else the
 * nearest friendly token within reach (1.6 grid squares, centre to centre). */
export function comfortAlly(her,candidates,{targets=[],grid=100,reach=1.6}={}){
  const t=targets.filter(x=>x&&x.id!==her?.id);if(t.length===1)return t[0];
  let best=null,bd=Infinity;
  for(const c of candidates??[]){if(!c||c.id===her?.id)continue;const d=Math.hypot(c.x-her.x,c.y-her.y);if(d<bd){bd=d;best=c;}}
  return best&&bd<=reach*grid?best:null;
}
