/** Render-local pursuit. No flags, timers, network writes or changes to the
 * shared work clock: a hurrying instrument closes, travels, then rejoins the
 * current pass. Large owner teleports carry the closed instruments too. */
const clamp=n=>Math.max(0,Math.min(1,n)),distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const mix=(a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});
const turn=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
const limited=(v,limit)=>{const n=Math.hypot(v.x,v.y);return n>limit?{x:v.x*limit/n,y:v.y*limit/n}:v;};
/** Physical render-local pursuit, in native pixels/seconds. Owner velocity is
 * feed-forward; displacement closes the remaining gap. Acceleration is bounded
 * as a vector, so a reversal brakes instead of flipping the travel direction.
 * The near-target spring is critically damped and does not change work clocks. */
export function stepScanPursuit(previous,{position,target,velocity={x:0,y:0},dt=16,size=100,maxSpeed}={}){
  const seconds=Math.max(0,Math.min(100,dt))/1000,from=position??previous?.position??target;
  const prior=previous?.velocity??{x:0,y:0},owner=limited(velocity,Math.max(1,size)*20);
  if(!seconds)return {position:{...from},velocity:{...prior},speed:Math.hypot(prior.x,prior.y)};
  const gap={x:target.x-from.x,y:target.y-from.y},omega=8;
  const acceleration=limited({x:gap.x*omega*omega+(owner.x-prior.x)*2*omega,y:gap.y*omega*omega+(owner.y-prior.y)*2*omega},Math.max(1,size)*28);
  // A lower new speed target must brake through the same envelope. Clipping
  // an already faster velocity to that cap would recreate an instant stop.
  const cap=Math.max(Math.hypot(prior.x,prior.y),maxSpeed??Math.max(1,size)*7+Math.hypot(owner.x,owner.y));
  const next=limited({x:prior.x+acceleration.x*seconds,y:prior.y+acceleration.y*seconds},cap);
  return {position:{x:from.x+(prior.x+next.x)*seconds/2,y:from.y+(prior.y+next.y)*seconds/2},velocity:next,speed:Math.hypot(next.x,next.y)};
}
/** Arc-length counterpart for a previously checked wall route. Integrating
 * the previous and next speeds removes the first-frame jump of a speed cap. */
export function stepScanRouteSpeed(previous=0,{distance=0,availableDistance=Infinity,sourceSpeed=0,dt=16,size=100,maxSpeed=Infinity,braking=false}={}){
  const seconds=Math.max(0,Math.min(100,dt))/1000,scale=Math.max(1,size),pace=Math.max(0,Math.min(scale*20,sourceSpeed));
  const brake=scale*36,frameBrake=brake*seconds;
  const stopping=Math.sqrt(frameBrake*frameBrake+2*brake*Math.max(0,availableDistance))-frameBrake;
  const goal=braking?0:Math.max(0,Math.min(scale*7+pace,distance*8+pace,stopping,maxSpeed)),rate=scale*(goal<previous?36:28);
  const speed=previous+Math.sign(goal-previous)*Math.min(Math.abs(goal-previous),rate*seconds);
  return {speed,travel:Math.max(0,(previous+speed)*seconds/2)};
}
export function stepScanLocomotion(previous,{source,now,size=100,radius=100,reduced=false}={}){
  source={x:Number(source?.x)||0,y:Number(source?.y)||0};size=Math.max(1,size);
  if(!previous||!Number.isFinite(previous.now)||now<previous.now)return {source,now,speed:0,paceSpeed:0,velocity:{x:0,y:0},amount:0,direction:0,lastRapid:-Infinity,lastMoving:-Infinity,travelOrigin:source,travelStarted:now,positions:{},headings:{},velocities:{},teleported:false,withdraw:false,active:false};
  if(now===previous.now&&distance(source,previous.source)<1e-7)return {...previous,dt:0,previousPositions:previous.positions,previousHeadings:previous.headings,previousVelocities:previous.velocities,teleported:false};
  const rawDelta=now-previous.now,dt=Math.max(1,Math.min(100,rawDelta)),d=distance(source,previous.source);
  const teleported=d>Math.max(size*2.5,radius*.85)||rawDelta<=0&&d>size*2.5;
  const speed=rawDelta>0?d*1000/rawDelta:d*1000,moving=speed>size*.7;
  // A document packet is a position, not a reliable one-frame speed. Smooth
  // the observed visual velocity and cap corrupt/instantaneous derivatives.
  const rawVelocity=limited({x:(source.x-previous.source.x)*1000/dt,y:(source.y-previous.source.y)*1000/dt},size*20),gain=1-Math.exp(-dt/110),oldVelocity=previous.velocity??{x:0,y:0};
  const velocity=teleported?{x:0,y:0}:{x:oldVelocity.x+(rawVelocity.x-oldVelocity.x)*gain,y:oldVelocity.y+(rawVelocity.y-oldVelocity.y)*gain},paceSpeed=Math.hypot(velocity.x,velocity.y);
  // Foundry can animate one grid step in 80–250 ms. Its instantaneous speed
  // is not evidence that Ellie has left the working area. Require sustained
  // *net* travel beyond the working leash, so a step, a reversal or hovering
  // never withdraws all four instruments.
  const newJourney=moving&&now-(previous.lastMoving??-Infinity)>180;
  const travelOrigin=newJourney?previous.source:previous.travelOrigin??previous.source,travelStarted=newJourney?previous.now:previous.travelStarted??previous.now;
  const traveled=distance(source,travelOrigin),alreadyTraveling=previous.amount>.2&&now-previous.lastRapid<300;
  const rapid=teleported||moving&&speed>size*3.6&&(alreadyTraveling||now-travelStarted>=180&&traveled>Math.max(size*2.25,radius*.55));
  const lastRapid=rapid?now:previous.lastRapid,direction=d>.2?Math.atan2(source.y-previous.source.y,source.x-previous.source.x):previous.direction;
  const target=rapid||now-lastRapid<220?1:0,amount=reduced?target:previous.amount+(target-previous.amount)*(1-Math.exp(-dt/(target?135:250))),withdraw=!!target||amount>.006||!!previous.catchingUp;
  return {source,now,dt,speed,paceSpeed,velocity,amount:teleported?1:amount,direction,lastRapid,lastMoving:moving?now:previous.lastMoving,travelOrigin,travelStarted,traveled,teleported,withdraw,
    positions:previous.positions??{},headings:previous.headings??{},velocities:previous.velocities??{},previousPositions:previous.positions??{},previousHeadings:previous.headings??{},previousVelocities:previous.velocities??{},active:withdraw};
}
export function applyScanLocomotion(sample,frame,context){
  if(!frame||sample.state?.phase==='returning')return sample;
  if(sample.state?.phase==='paused'){
    frame.positions=Object.fromEntries(Object.entries(sample.positions??{}).map(([id,p])=>[id,{...p}]));
    frame.velocities=Object.fromEntries(Object.keys(sample.positions??{}).map(id=>[id,{x:0,y:0}]));
    frame.catchingUp=false;return sample;
  }
  const ids=Object.keys(sample.positions??{}),size=Math.max(1,context.size??100),positions={},headings={},velocities={};let displaced=false;
  for(let index=0;index<ids.length;index++){
    const id=ids[index],desired=sample.positions[id],basis=(context.transform?.angle??0)+(context.orientations?.[id]??0);
    const desiredHeading=(sample.rotations?.[id]??0)+basis;
    const prior=(frame.previousPositions??frame.positions)[id],priorVelocity=(frame.previousVelocities??frame.velocities??{})[id]??{x:0,y:0};
    if(!frame.active&&!frame.teleported){positions[id]={...desired};headings[id]=desiredHeading;velocities[id]=prior?limited({x:(desired.x-prior.x)*1000/Math.max(1,frame.dt??16),y:(desired.y-prior.y)*1000/Math.max(1,frame.dt??16)},size*20):{x:0,y:0};continue;}
    const lateral=(index-(ids.length-1)/2)*size*.24,back=size*(.3+(index%2)*.13),c=Math.cos(frame.direction),s=Math.sin(frame.direction);
    const tucked={x:frame.source.x-c*back-s*lateral,y:frame.source.y-s*back+c*lateral},target=mix(desired,tucked,frame.amount);
    const pursued=prior&&!frame.teleported?stepScanPursuit({velocity:priorVelocity},{position:prior,target,velocity:{x:(frame.velocity?.x??0)*frame.amount,y:(frame.velocity?.y??0)*frame.amount},dt:frame.dt,size}):{position:target,velocity:{x:0,y:0}},position=pursued.position;
    velocities[id]=pursued.velocity;
    sample.positions[id]=positions[id]=position;displaced||=distance(position,desired)>1.5||frame.amount>.012;
    const path=prior&&distance(prior,position)>.1?Math.atan2(position.y-prior.y,position.x-prior.x)+Math.PI/2:frame.direction+Math.PI/2;
    const targetHeading=turn(desiredHeading,path,clamp(frame.amount*1.6)),heading=frame.teleported?targetHeading:turn((frame.previousHeadings??frame.headings)[id]??desiredHeading,targetHeading,1-Math.exp(-Math.max(0,frame.dt??16)/100));
    sample.rotations[id]=heading-basis;headings[id]=heading;
  }
  // State belongs to this newly computed frame, never to the previous cache.
  frame.positions=positions;frame.headings=headings;frame.velocities=velocities;frame.catchingUp=displaced;
  if(!displaced)return sample;
  sample.effects=[];sample.focuses=[];sample.completedCells={};sample.scanWorking=0;sample.scanComplete=false;sample.encounterSurfaces=[];
  const phase=frame.now-frame.lastRapid<220?'relocating':'resettling';sample.state={phase,progress:1-frame.amount};
  for(const id of ids){sample.phases[id]={phase,progress:1-frame.amount};sample.coreStates[id]={state:phase==='relocating'?'encased':'charging',amount:phase==='relocating'?.35:.25,progress:1-frame.amount};
    if(sample.tools)delete sample.tools[id];if(sample.glows?.[id])sample.glows[id]={...sample.glows[id],strength:.35};}
  sample.scanRelocating=true;return sample;
}
