/** Independent bit deployment. The saved flag is the destination; a shared
 * deadline animates the trip with no delayed writes or extra timers. */
const unit=n=>Math.max(0,Math.min(1,n));
export function bitsWanted(data){
  return data.gemMotion?.enabled!==false&&data.gemMotion?.style!=='hidden';
}
export function bitTarget(data,cfg){
  const deployed=data.enabled!==false||data.bitsDeployed===true;
  return cfg.controlGems!==false&&cfg.wingRenderer!=='atlas'&&deployed&&bitsWanted(data)?1:0;
}
export function readBitTransition(raw){
  if(raw==null)return null;
  if(typeof raw!=='object'||Array.isArray(raw)||typeof raw.id!=='string'||!/^[\w-]{1,64}$/.test(raw.id)||
    !Number.isFinite(raw.started)||!Number.isFinite(raw.duration)||raw.duration<0||raw.duration>10000||
    !['from','to'].every(k=>Number.isFinite(raw[k])&&raw[k]>=0&&raw[k]<=1))throw new Error('Invalid bit deployment transition.');
  return Object.fromEntries(['id','started','duration','from','to'].map(k=>[k,raw[k]]));
}
export function sampleBitDeployment(data,cfg,now,resume=true){
  const target=bitTarget(data,cfg),t=data.bitTransition;
  const animate=t&&resume&&cfg.controlGems!==false&&cfg.wingRenderer!=='atlas'&&cfg.bitTransitions!==false&&cfg.transitions!==false&&!cfg.reduced&&t.duration>0&&t.to===target;
  const progress=animate?unit((now-t.started)/t.duration):1;
  const w=progress*progress*(3-2*progress);
  return {value:animate?t.from+(target-t.from)*w:target,
    transition:t?{...t,active:animate&&progress<1,progress}:null};
}

export const bitCountTarget=data=>Math.max(1,Math.min(4,Math.round(Number(data.gemMotion?.count)||4)));
const countValues=count=>Array.from({length:4},(_,i)=>i<count?1:0);
const countFormation=count=>Array.from({length:4},(_,i)=>i===count-1?1:0);
export function readBitCountTransition(raw){
  if(raw==null)return null;
  const vector=v=>Array.isArray(v)&&v.length===4&&v.every(n=>Number.isFinite(n)&&n>=0&&n<=1);
  if(typeof raw!=='object'||Array.isArray(raw)||typeof raw.id!=='string'||! /^[\w-]{1,64}$/.test(raw.id)||
    !Number.isFinite(raw.started)||!Number.isFinite(raw.duration)||raw.duration<0||raw.duration>10000||
    !vector(raw.from)||!vector(raw.fromFormation)||Math.abs(raw.fromFormation.reduce((a,b)=>a+b,0)-1)>.0001||!Number.isInteger(raw.to)||raw.to<1||raw.to>4)
    throw new Error('Invalid bit count transition.');
  return {id:raw.id,started:raw.started,duration:raw.duration,from:[...raw.from],fromFormation:[...raw.fromFormation],to:raw.to};
}
/** Count changes carry their sampled starting weights, so a reversal can never
 * queue old commands or snap an already travelling instrument to its endpoint. */
export function sampleBitCount(data,cfg,now,resume=true){
  const count=bitCountTarget(data),target=countValues(count),formation=countFormation(count),t=data.bitCountTransition;
  const animate=t&&t.to===count&&resume&&cfg.bitTransitions!==false&&cfg.transitions!==false&&!cfg.reduced&&t.duration>0;
  if(!animate)return {count,values:target,formationWeights:formation,transition:t?{...t,active:false,progress:1}:null};
  const progress=unit((now-t.started)/t.duration),smooth=n=>{n=unit(n);return n*n*(3-2*n);};
  const formationProgress=smooth(progress),changes=target.flatMap((v,i)=>Math.abs(v-t.from[i])>.000001?[i]:[]);
  const values=target.map((v,i)=>{
    if(!changes.includes(i))return v;
    const order=v>t.from[i]?changes.indexOf(i):changes.length-1-changes.indexOf(i);
    const delay=changes.length>1?order*.10:0,p=smooth((progress-delay)/(1-delay));
    return t.from[i]+(v-t.from[i])*p;
  });
  return {count,values,formationWeights:formation.map((v,i)=>t.fromFormation[i]+(v-t.fromFormation[i])*formationProgress),
    transition:{...t,active:progress<1,progress}};
}
