/** Shared scan-style choices. Method selection never changes physical routes. */
const entry=(id,label,description,geometric=false)=>Object.freeze({id,label,description,...(geometric?{geometric:true}: {})});
export const SCAN_METHOD_CATALOG=Object.freeze({
 creature:Object.freeze([
  entry('structuredLight','Coded structured light','Measured light bands and retained surface returns.'),
  entry('laserTriangulation','Crossed laser profiling','Opposed pencil lasers trace a precise moving intersection.'),
  entry('lidarReconstruction','Pulsed point reconstruction','Range echoes gather into a restrained point mesh.'),
  entry('contourTomography','Contour tomography','Layered cross sections resolve across the visible token.'),
  entry('phaseInterferometry','Phase interferometry','Curved phase fields meet and settle into a surface lattice.')
 ]),
 area:Object.freeze([
  entry('structuredLight','Sweeping light bands','A measured exposure follows each team’s assigned squares.'),
  entry('radialRanging','Range pulses','Quiet expanding range shells inspect the assigned cells.'),
  entry('sparseReconstruction','Sampling stations','Deliberate point checks gather local surface returns.'),
  entry('edgeTracing','Contour tracing','A moving probe traces the edges of the assigned cells.'),
  entry('crosshatchSurvey','Crosshatch survey','Two restrained acquisition directions resolve the cell surface.'),
  entry('geometricStructuredLight','Geometric light bands','One linked frame and continuous light bands span the team’s cells.',true),
  entry('geometricRadialRanging','Geometric range field','Shared range pulses travel through one connected team frame.',true),
  entry('geometricSparseReconstruction','Geometric sample lattice','A shared sampling lattice resolves the connected team field.',true),
  entry('geometricEdgeTracing','Geometric contour frame','A measuring front follows the team’s exterior without internal dividers.',true),
  entry('geometricCrosshatchSurvey','Geometric crosshatch','Crossed acquisition lines span one continuous team frame.',true)
 ])
});
export const AVAILABLE_SCAN_METHODS=Object.freeze(Object.fromEntries(Object.entries(SCAN_METHOD_CATALOG).map(([group,list])=>[group,Object.freeze(list.map(style=>style.id))])));
// Geometric fields are opt-in; existing characters retain their soft style set.
export const DEFAULT_SCAN_METHODS=Object.freeze(Object.fromEntries(Object.entries(SCAN_METHOD_CATALOG).map(([group,list])=>[group,Object.freeze(list.filter(style=>!style.geometric).map(style=>style.id))])));
export const SCAN_METHOD_IDS=Object.freeze([...new Set(Object.values(AVAILABLE_SCAN_METHODS).flat())]);
const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
export function effectiveScanMethods(raw){
 return Object.fromEntries(Object.entries(AVAILABLE_SCAN_METHODS).map(([group,ids])=>{
  const enabled=Array.isArray(raw?.[group])?ids.filter(id=>raw[group].includes(id)):[];
  return [group,enabled.length?enabled:[...DEFAULT_SCAN_METHODS[group]]];
 }));
}
export function normalizeScanMethods(patch,{defaults=DEFAULT_SCAN_METHODS}={}){
 if(!object(patch)||Object.keys(patch).some(group=>!Object.hasOwn(DEFAULT_SCAN_METHODS,group)))throw new Error('Choose creature or area scanning styles.');
 const result=effectiveScanMethods(defaults);
 for(const [group,enabled]of Object.entries(patch)){
  if(!Array.isArray(enabled)||enabled.length<1||enabled.length>AVAILABLE_SCAN_METHODS[group].length||enabled.some(id=>!AVAILABLE_SCAN_METHODS[group].includes(id))||new Set(enabled).size!==enabled.length)throw new Error(`Keep at least one valid ${group==='creature'?'creature':'area'} scanning style enabled.`);
  result[group]=AVAILABLE_SCAN_METHODS[group].filter(id=>enabled.includes(id));
 }
 return result;
}
function seedOf(value){let h=2166136261;for(const c of String(value??'')){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
const decks=new Map();
const defaultMasks=Object.freeze(Object.fromEntries(Object.entries(AVAILABLE_SCAN_METHODS).map(([category,ids])=>[category,ids.reduce((mask,id,i)=>mask|(DEFAULT_SCAN_METHODS[category].includes(id)?1<<i:0),0)])));
export function selectScanMethod(utility={},category='area',ordinal=0,seed=utility.seed??0){
 // Select only this instrument's category. Read the live array each time so
 // in-place preference edits still apply; canonical masks avoid rebuilding
 // both validated categories and their string decks on every display sample.
 const known=Object.hasOwn(AVAILABLE_SCAN_METHODS,category),ids=known?AVAILABLE_SCAN_METHODS[category]:AVAILABLE_SCAN_METHODS.area;
 const raw=known&&Array.isArray(utility.scanMethods?.[category])?utility.scanMethods[category]:null;
 let mask=0;for(let i=0;i<ids.length;i++)if(raw?.includes(ids[i]))mask|=1<<i;
 if(!mask)mask=defaultMasks[known?category:'area'];
 const key=`${category}:${seed}:${mask}`;let deck=decks.get(key);
 if(!deck){deck=ids.filter((_,i)=>mask&(1<<i));let x=seedOf(`${category}:${seed}:${deck.join(',')}`);for(let i=deck.length-1;i>0;i--){x=(Math.imul(x,1664525)+1013904223)>>>0;const j=x%(i+1);[deck[i],deck[j]]=[deck[j],deck[i]];}if(decks.size>=128)decks.delete(decks.keys().next().value);decks.set(key,deck);}
 const index=Math.max(0,Math.floor(Number.isFinite(ordinal)?ordinal:0));return deck[index%deck.length];
}
export function heldScanMethod(event,id,scanVisit,selected){const hold=event.scanMethodHold?.[id];return hold?.visit===String(scanVisit)&&SCAN_METHOD_IDS.includes(hold.method)?hold.method:selected;}
