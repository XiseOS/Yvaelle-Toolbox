/** Token-only scan surfaces. Borrow native texture pixels read-only; no GPU
 * extraction, pixel reads, token filters, texture uploads or document writes.
 * A bounded source-alpha cache and one scratch surface per attended token are
 * owned by the renderer / preview and released with that owner. */
export const TOKEN_SCAN_MASK_LIMIT=16,TOKEN_SCAN_MASK_SIZE=512;
// One sample owns its portrait descriptor. Reuse that same native transform
// for the alpha mask in the same update without storing handles in samples.
const portraitFrames=new WeakMap(),portraitGeometryKeys=new WeakMap();
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const matrix=(a=1,b=0,c=0,d=1,tx=0,ty=0)=>({a,b,c,d,tx,ty});
const valid=m=>m&&[m.a,m.b,m.c,m.d,m.tx,m.ty].every(Number.isFinite)&&Math.abs(m.a*m.d-m.b*m.c)>1e-10;
const multiply=(m,n)=>matrix(m.a*n.a+m.c*n.b,m.b*n.a+m.d*n.b,m.a*n.c+m.c*n.d,m.b*n.c+m.d*n.d,m.a*n.tx+m.c*n.ty+m.tx,m.b*n.tx+m.d*n.ty+m.ty);
function inverse(m){const det=m.a*m.d-m.b*m.c;return matrix(m.d/det,-m.b/det,-m.c/det,m.a/det,(m.c*m.ty-m.d*m.tx)/det,(m.b*m.tx-m.a*m.ty)/det);}
const transform=(m,x,y)=>({x:m.a*x+m.c*y+m.tx,y:m.b*x+m.d*y+m.ty});
const rotation=angle=>matrix(Math.cos(angle),Math.sin(angle),-Math.sin(angle),Math.cos(angle));
const rect=(r,w,h)=>r&&[r.x,r.y,r.width,r.height].every(Number.isFinite)&&r.width>0&&r.height>0?{x:r.x,y:r.y,width:r.width,height:r.height}:{x:0,y:0,width:w,height:h};
function sourceDimensions(source){return {width:finite(source?.naturalWidth,finite(source?.videoWidth,finite(source?.width))),height:finite(source?.naturalHeight,finite(source?.videoHeight,finite(source?.height)))};}
function canvasSurface(width,height,document=globalThis.document){
  const canvas=document?.createElement?.('canvas')??(globalThis.OffscreenCanvas?new OffscreenCanvas(width,height):null);
  if(!canvas)return null;canvas.width=width;canvas.height=height;
  const ctx=canvas.getContext?.('2d');return ctx?{canvas,ctx}:null;
}
function release(record){if(!record)return;if(record.alpha)record.alpha.width=record.alpha.height=1;if(record.scratch)record.scratch.width=record.scratch.height=1;record.source=null;record.texture=null;record.revision=null;record.ctx=null;record.scratchCtx=null;}

/** Native PIXI sprite geometry, expressed in primary-canvas scene coordinates.
 * orig/frame/trim/UVs preserve transparent margins and atlas crops. The mesh
 * affine transform preserves scale, skew, mirroring and rotation. A supplied
 * visual pose adds Filament's render-only lift/sway/bank to the native image. */
export function scanTokenTextureGeometry(token,{primary=globalThis.canvas?.primary,pose=null}={}){
  const mesh=token?.mesh,texture=mesh?.texture,base=texture?.baseTexture;
  if(!mesh||mesh.destroyed||mesh.visible===false||mesh.renderable===false||texture?.destroyed||base?.destroyed||base?.valid===false)return null;
  const source=mesh.sourceElement??token?.sourceElement??base?.resource?.source??texture?.source?.resource??texture?.source?.source;
  const dimensions=sourceDimensions(source);
  if(!source||dimensions.width<=0||dimensions.height<=0||source.complete===false)return null;
  const resolution=Math.max(.01,finite(base?.resolution,1));
  const frame=rect(texture.frame,dimensions.width/resolution,dimensions.height/resolution),orig=rect(texture.orig,frame.width,frame.height),trim=rect(texture.trim,orig.width,orig.height);
  const anchor={x:finite(mesh.anchor?.x),y:finite(mesh.anchor?.y)};
  let native,posed=false;
  if(pose&&valid(mesh.parent?.worldTransform)&&valid(primary?.worldTransform)&&Number.isFinite(mesh.scale?.x)&&Number.isFinite(mesh.scale?.y)){
    // Filament restores local token values after native transform updates.
    // worldTransform may therefore already contain last frame's visual lift.
    // Rebuild from restored native locals + this frame's explicit pose once.
    const angle=finite(pose.angle,finite(mesh.rotation)),sx=mesh.scale.x,sy=mesh.scale.y*finite(pose.scaleY,1),kx=finite(mesh.skew?.x),ky=finite(mesh.skew?.y);
    const a=Math.cos(angle+ky)*sx,b=Math.sin(angle+ky)*sx,c=-Math.sin(angle-kx)*sy,d=Math.cos(angle-kx)*sy,px=finite(mesh.pivot?.x),py=finite(mesh.pivot?.y);
    const local=matrix(a,b,c,d,finite(pose.x,finite(mesh.x))-px*a-py*c,finite(pose.y,finite(mesh.y))-px*b-py*d);
    native=multiply(multiply(inverse(primary.worldTransform),mesh.parent.worldTransform),local);posed=true;
  }else if(valid(mesh.worldTransform)&&valid(primary?.worldTransform))native=multiply(inverse(primary.worldTransform),mesh.worldTransform);
  else{
    const angle=finite(mesh.rotation),c=Math.cos(angle),s=Math.sin(angle);
    const sx=Number.isFinite(mesh.scale?.x)?mesh.scale.x:Math.abs(finite(mesh.width,orig.width))/orig.width*(Math.sign(token?.document?.texture?.scaleX)||1);
    const sy=Number.isFinite(mesh.scale?.y)?mesh.scale.y:Math.abs(finite(mesh.height,orig.height))/orig.height*(Math.sign(token?.document?.texture?.scaleY)||1);
    native=matrix(c*sx,s*sx,-s*sy,c*sy,finite(mesh.x,finite(token?.center?.x)),finite(mesh.y,finite(token?.center?.y)));
  }
  if(!valid(native))return null;
  if(pose&&!posed){
    const turn=finite(pose.angle,finite(mesh.rotation))-finite(mesh.rotation),r=rotation(turn),x=native.tx,y=native.ty;
    native=multiply(matrix(1,0,0,1,x+finite(pose.x,finite(mesh.x))-finite(mesh.x),y+finite(pose.y,finite(mesh.y))-finite(mesh.y)),multiply(r,multiply(matrix(1,0,0,1,-x,-y),native)));
  }
  const imageToWorld=multiply(native,matrix(1,0,0,1,-anchor.x*orig.width,-anchor.y*orig.height));
  const uv=texture._uvs??texture.uvs;
  const uvs=uv&&['x0','y0','x1','y1','x3','y3'].every(key=>Number.isFinite(uv[key]))?{x0:uv.x0,y0:uv.y0,x1:uv.x1,y1:uv.y1,x3:uv.x3,y3:uv.y3}:null;
  const revision=[texture._updateID??0,base?._updateID??0,dimensions.width,dimensions.height,resolution,frame.x,frame.y,frame.width,frame.height,orig.width,orig.height,trim.x,trim.y,trim.width,trim.height,texture.rotate??0,...(uvs?Object.values(uvs):[])].join(':');
  return {mesh,texture,source,sourceWidth:dimensions.width,sourceHeight:dimensions.height,resolution,frame,orig,trim,uvs,imageToWorld,revision};
}
/** Stable native geometry only. Advancing alpha frames and Filament's visual
 * pose do not own a route certification. Parent/primary linear transforms do:
 * a native scale, skew, anchor or frame edit must retire the earlier footprint.
 * The guard separately checks that visual motion stays in its certified slack. */
function nativePortraitGeometryKey(token,geometry,primary){
  const mesh=token?.mesh,orig=geometry?.orig;
  const parent=valid(mesh?.parent?.worldTransform)&&valid(primary?.worldTransform)?multiply(inverse(primary.worldTransform),mesh.parent.worldTransform):matrix();
  const stable=value=>Math.round(value*1e8)/1e8;
  // Atlas/frame coordinates and pixel revisions may advance without changing
  // the full original-image footprint. Orig dimensions and native transforms
  // cover geometry-changing frame edits without restarting animated portraits.
  return JSON.stringify([finite(mesh?.rotation,finite(token?.document?.rotation)*Math.PI/180),
    finite(mesh?.scale?.x,orig?Math.abs(finite(mesh?.width,orig.width))/orig.width:finite(mesh?.width)),
    finite(mesh?.scale?.y,orig?Math.abs(finite(mesh?.height,orig.height))/orig.height:finite(mesh?.height)),
    finite(mesh?.skew?.x),finite(mesh?.skew?.y),finite(mesh?.pivot?.x),finite(mesh?.pivot?.y),finite(mesh?.anchor?.x),finite(mesh?.anchor?.y),
    parent.a,parent.b,parent.c,parent.d,
    geometry?[geometry.orig.width,geometry.orig.height]:[finite(mesh?.width),finite(mesh?.height)]].map(value=>Array.isArray(value)?value.map(stable):stable(value)));
}
/** Internal certification identity for a descriptor from the current update.
 * The descriptor remains plain render data; texture handles stay weakly owned. */
export function scanPortraitGeometryKey(portrait){return portraitGeometryKeys.get(portrait)??null;}
/** Full displayed portrait extents, independent of occupied grid dimensions.
 * The image centre follows non-default sprite anchors and render-only poses. */
export function scanTokenPortrait(token,{pose=null,primary=globalThis.canvas?.primary}={}){
  const geometry=scanTokenTextureGeometry(token,{pose,primary}),mesh=token?.mesh;
  if(geometry){
    const m=geometry.imageToWorld,angle=finite(pose?.angle,finite(mesh?.rotation)),c=Math.cos(angle),s=Math.sin(angle);
    // Bounds in the scan's rotation frame enclose skewed native quads too.
    // The alpha mask then removes every transparent/unused part of this frame.
    const portrait={center:transform(m,geometry.orig.width/2,geometry.orig.height/2),width:Math.abs(c*m.a+s*m.b)*geometry.orig.width+Math.abs(c*m.c+s*m.d)*geometry.orig.height,height:Math.abs(-s*m.a+c*m.b)*geometry.orig.width+Math.abs(-s*m.c+c*m.d)*geometry.orig.height,rotation:angle};
    portraitFrames.set(portrait,{token,primary,geometry});portraitGeometryKeys.set(portrait,nativePortraitGeometryKey(token,geometry,primary));return portrait;
  }
  const portrait={center:{x:finite(pose?.x,finite(mesh?.x,finite(token?.center?.x))),y:finite(pose?.y,finite(mesh?.y,finite(token?.center?.y)))},width:Math.max(.01,Math.abs(finite(mesh?.width,finite(token?.w,100)))),height:Math.max(.01,Math.abs(finite(mesh?.height,finite(token?.h,100)))),rotation:finite(pose?.angle,finite(mesh?.rotation,finite(token?.document?.rotation)*Math.PI/180))};
  portraitGeometryKeys.set(portrait,nativePortraitGeometryKey(token,null,primary));return portrait;
}
function paintSourceAlpha(record,geometry){
  const {ctx,alpha}=record,{source,sourceWidth,sourceHeight,resolution,frame,orig,trim,uvs}=geometry;
  ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,alpha.width,alpha.height);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  const sx=alpha.width/orig.width,sy=alpha.height/orig.height,dx=trim.x*sx,dy=trim.y*sy,dw=trim.width*sx,dh=trim.height*sy;
  if(uvs){
    const sourceToUnit=inverse(matrix((uvs.x1-uvs.x0)*sourceWidth,(uvs.y1-uvs.y0)*sourceHeight,(uvs.x3-uvs.x0)*sourceWidth,(uvs.y3-uvs.y0)*sourceHeight,uvs.x0*sourceWidth,uvs.y0*sourceHeight));
    const m=multiply(matrix(dw,0,0,dh,dx,dy),sourceToUnit);
    ctx.save();ctx.beginPath();ctx.rect(dx,dy,dw,dh);ctx.clip();ctx.setTransform(m.a,m.b,m.c,m.d,m.tx,m.ty);ctx.drawImage(source,0,0);ctx.restore();
  }else if(!geometry.texture.rotate)ctx.drawImage(source,frame.x*resolution,frame.y*resolution,frame.width*resolution,frame.height*resolution,dx,dy,dw,dh);
  else{
    // Rotated atlas textures normally expose UVs. With unavailable UVs the
    // source cannot be matched reliably, so suppress instead of boxing it.
    return false;
  }
  record.source=source;record.texture=geometry.texture;record.revision=geometry.revision;return true;
}
function boundsOf(m,width,height){
  // Linear extents do not depend on translation. Avoid cancellation between
  // large world-space corners; near-integral raster extents below also avoid
  // gaining a spurious pixel from floating-point multiplication alone.
  const ax=m.a*width,ay=m.b*width,cx=m.c*height,cy=m.d*height;
  return {x:m.tx+Math.min(0,ax)+Math.min(0,cx),y:m.ty+Math.min(0,ay)+Math.min(0,cy),width:Math.abs(ax)+Math.abs(cx),height:Math.abs(ay)+Math.abs(cy)};
}
function rasterSize(value,maximum){
  const integer=Math.round(value),stable=Math.abs(value-integer)<=Math.max(1,Math.abs(value))*1e-12?integer:value;
  return Math.max(1,Math.min(maximum,Math.ceil(stable)));
}

export class TokenScanMaskCache {
  constructor({document=globalThis.document,limit=TOKEN_SCAN_MASK_LIMIT,maxSize=TOKEN_SCAN_MASK_SIZE}={}){this.document=document;this.limit=Math.max(1,Math.min(TOKEN_SCAN_MASK_LIMIT,finite(limit,TOKEN_SCAN_MASK_LIMIT)));this.maxSize=Math.max(32,Math.min(TOKEN_SCAN_MASK_SIZE,finite(maxSize,TOKEN_SCAN_MASK_SIZE)));this.records=new Map();this.stats={builds:0,paints:0,releases:0};}
  /** scale is world pixels per scan-art unit. No scene or user texture is ever
   * retained after destroy(), eviction, or explicit retain() removal. */
  get(token,{center=token?.center??{x:0,y:0},rotation:angle=0,scale=1,pose=null,primary=globalThis.canvas?.primary,portrait=null}={}){
    if(this.destroyed||!token||!(scale>0))return null;
    // `portrait` is optional and must be this update's descriptor. Ordinary
    // public callers still resolve current native geometry independently.
    const frame=portrait&&portraitFrames.get(portrait);
    const geometry=frame?.token===token&&frame.primary===primary?frame.geometry:scanTokenTextureGeometry(token,{pose:typeof pose==='function'?pose():pose,primary});
    if(!geometry){this.delete(token);return null;}
    let record=this.records.get(token);
    const ratio=Math.min(1,this.maxSize/Math.max(geometry.orig.width,geometry.orig.height)),width=Math.max(1,Math.ceil(geometry.orig.width*ratio)),height=Math.max(1,Math.ceil(geometry.orig.height*ratio));
    if(!record){
      const surface=canvasSurface(width,height,this.document);if(!surface)return null;
      if(this.records.size>=this.limit)this.delete(this.records.keys().next().value);
      record={alpha:surface.canvas,ctx:surface.ctx};this.records.set(token,record);
    }else{this.records.delete(token);this.records.set(token,record);}
    if(record.source!==geometry.source||record.texture!==geometry.texture||record.revision!==geometry.revision){
      // A texture revision needs new alpha pixels, not a new backing store.
      // Animated portraits commonly retain their dimensions between frames.
      if(record.alpha.width!==width)record.alpha.width=width;
      if(record.alpha.height!==height)record.alpha.height=height;
      try{if(!paintSourceAlpha(record,geometry)){this.delete(token);return null;}}catch{this.delete(token);return null;}
      this.stats.builds++;
    }
    const c=Math.cos(angle)/scale,s=Math.sin(angle)/scale;
    const worldToArt=matrix(c,-s,s,c,(-c*center.x-s*center.y),(s*center.x-c*center.y));
    const imageToArt=multiply(worldToArt,geometry.imageToWorld),alphaToArt=multiply(imageToArt,matrix(geometry.orig.width/record.alpha.width,0,0,geometry.orig.height/record.alpha.height));
    const owner=this;
    return {signature:[geometry.revision,...Object.values(alphaToArt)].join(':'),paint(ctx,drawSurface,{frameRotation=0}={}){
      if(owner.destroyed||owner.records.get(token)!==record)return false;
      const toChannel=multiply(rotation(-frameRotation),alphaToArt),bounds=boundsOf(toChannel,record.alpha.width,record.alpha.height);
      if(!(bounds.width>1e-7&&bounds.height>1e-7))return false;
      // Preserve approximately the caller's physical raster density without
      // allowing a large scene token to allocate unbounded offscreen pixels.
      const cm=ctx.getTransform?.(),density=cm?Math.max(Math.hypot(cm.a,cm.b),Math.hypot(cm.c,cm.d)):2;
      const pixelScale=Math.min(Math.max(.05,density),owner.maxSize/Math.max(bounds.width,bounds.height));
      const width=rasterSize(bounds.width*pixelScale,owner.maxSize),height=rasterSize(bounds.height*pixelScale,owner.maxSize);
      if(!record.scratch){const surface=canvasSurface(width,height,owner.document);if(!surface)return false;record.scratch=surface.canvas;record.scratchCtx=surface.ctx;}
      if(record.scratch.width!==width)record.scratch.width=width;if(record.scratch.height!==height)record.scratch.height=height;
      const scratch=record.scratchCtx;scratch.setTransform(1,0,0,1,0,0);scratch.clearRect(0,0,width,height);scratch.save();
      const sx=width/bounds.width,sy=height/bounds.height;
      scratch.setTransform(sx,0,0,sy,-bounds.x*sx,-bounds.y*sy);scratch.globalCompositeOperation='source-over';scratch.globalAlpha=1;scratch.lineJoin=ctx.lineJoin;scratch.lineCap=ctx.lineCap;
      try{
        drawSurface(scratch);
        scratch.setTransform(sx,0,0,sy,-bounds.x*sx,-bounds.y*sy);scratch.globalCompositeOperation='destination-in';scratch.globalAlpha=1;
        scratch.transform(toChannel.a,toChannel.b,toChannel.c,toChannel.d,toChannel.tx,toChannel.ty);scratch.drawImage(record.alpha,0,0);
      }finally{scratch.restore();}
      ctx.save();ctx.globalAlpha=1;ctx.drawImage(record.scratch,bounds.x,bounds.y,bounds.width,bounds.height);ctx.restore();owner.stats.paints++;return true;
    }};
  }
  delete(token){const record=this.records.get(token);if(!record)return;release(record);this.records.delete(token);this.stats.releases++;}
  retain(tokens){const active=new Set(tokens);for(const token of this.records.keys())if(!active.has(token)||token.destroyed)this.delete(token);}
  destroy(){for(const token of this.records.keys())this.delete(token);this.destroyed=true;this.document=null;}
}
