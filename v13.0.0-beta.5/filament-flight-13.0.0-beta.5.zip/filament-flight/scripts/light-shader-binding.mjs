/** Pixi caches a uniform upload function per UniformGroup and program ID.
 * A native reset can bind an existing patched program before its late-added
 * uniforms are restored. Invalidate that one layout on structural changes;
 * ordinary animated values retain the cached upload function. */
export function lightUniformLayoutChanged(shader,record,activeOwnedNames=[]){
  const group=shader?.uniformGroup,uniforms=shader?.uniforms,previous=record?.lightUniformLayout;
  const changed=!previous||previous.group!==group||previous.uniforms!==uniforms||
    previous.names.length!==activeOwnedNames.length||previous.names.some((name,index)=>name!==activeOwnedNames[index])||
    activeOwnedNames.some(name=>!Object.hasOwn(uniforms??{},name));
  if(record&&changed)record.lightUniformLayout={group,uniforms,names:[...activeOwnedNames]};
  return changed;
}

// A weak marker belongs to the live shader, not its source, settings object or
// clock. Native resets and external edits are still checked against the actual
// uniform object on every update.
const pendingUniformUpdates=new WeakSet();
export function noteLightUniformChange(shader){if(shader&&typeof shader==='object')pendingUniformUpdates.add(shader);}

export function invalidateLightUniformLayout(shader,program=shader?.program){
  noteLightUniformChange(shader);
  const cache=shader?.uniformGroup?.syncUniforms,id=program?.id;
  if(id===undefined||id===null||!cache)return;
  if(cache instanceof Map)cache.delete(id);
  else if(Object.hasOwn(cache,id))delete cache[id];
}

export function markLightShaderUniformsDirty(shader,{changedOnly=false}={}){
  const changed=pendingUniformUpdates.delete(shader);
  if(changedOnly&&!changed)return;
  const group=shader?.uniformGroup;if(!group?.static)return;
  if(typeof group.update==='function')group.update();
  else if(Number.isFinite(group.dirtyId))group.dirtyId++;
}

export function setLightShaderProgram(shader,program,{layoutChanged=false}={}){
  if(layoutChanged)invalidateLightUniformLayout(shader,program);
  if(shader.program===program)return;
  noteLightUniformChange(shader);
  const renderer=globalThis.canvas?.app?.renderer;
  if(renderer?.shader?.shader===shader){renderer.batch?.flush?.();renderer.shader.reset?.();}
  shader.program=program;
}

/** Native layers may be replaced by core or another module at any time. Read
 * their three current shader identities every frame, but retain the small
 * iteration layout while those identities are unchanged. */
export function lightShaderLayers(source,entry){
  const layers=source.layers,background=layers?.background?.shader,
    illumination=layers?.illumination?.shader,coloration=layers?.coloration?.shader;
  if(!entry.layerList||entry.backgroundShader!==background||entry.illuminationShader!==illumination||entry.colorationShader!==coloration){
    entry.backgroundShader=background;entry.illuminationShader=illumination;entry.colorationShader=coloration;
    entry.layerList=[];
    for(const [name,shader]of [['background',background],['illumination',illumination],['coloration',coloration]])
      if(shader)entry.layerList.push([name,{shader}]);
  }
  return entry.layerList;
}

/** Keep animated values at the display cadence without repeatedly assigning
 * their unchanged companions. Reading the actual uniform object also repairs
 * native resets and external edits instead of trusting a stale value cache. */
export function setLightUniform(shader,name,value,affectsOutput=true){
  if(shader.uniforms[name]!==value){shader.uniforms[name]=value;if(affectsOutput)noteLightUniformChange(shader);return true;}
  return false;
}

/** In-place vectors retain Pixi's cached upload layout. Compare their stored
 * components after Float32 rounding so an unchanged bearing stays unchanged,
 * while both genuine motion and repaired external component edits upload. */
export function setLightUniformVector(shader,name,vector,x,y){
  const previousX=vector[0],previousY=vector[1];vector[0]=x;vector[1]=y;
  if(previousX!==vector[0]||previousY!==vector[1])noteLightUniformChange(shader);
  return setLightUniform(shader,name,vector);
}
