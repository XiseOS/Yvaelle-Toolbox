const unit=n=>Math.max(0,Math.min(1,n)),smooth=n=>{n=unit(n);return n*n*(3-2*n);};
export const WING_STATION_IDS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);
const perimeter=['leftUpper','rightUpper','rightLower','leftLower'];
const defaults={leftUpper:{x:-188,y:-151,z:-24,angle:-.28},rightUpper:{x:188,y:-151,z:-24,angle:.28},leftLower:{x:-174,y:199,z:-24,angle:.24},rightLower:{x:174,y:199,z:-24,angle:-.24}};
const finite=(n,fallback)=>Number.isFinite(n)?n:fallback;
const wrap=(n,period)=>(n%period+period)%period;
const turn=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
// Shared by all four controllers and by main/worker sampling. Geometry keys
// are content-based, so frame snapshots do not rebuild the same rounded path.
// A fixed cap bounds memory even while owners edit many custom placements.
const passageCache=new Map(),PASSAGE_CACHE_LIMIT=128;

/** Only unreserved home instruments share the wing workload. A count fade is
 * visibility, not another available worker. IDs stay stable when a bit leaves. */
export function wingStabilizationStations(flight={}){
  const supplied=Array.isArray(flight.bitHomeStations)?flight.bitHomeStations:null;
  const hidden=new Set(flight.bitActionAssignments?.hidden??[]);
  return WING_STATION_IDS.filter((id,i)=>supplied?supplied.includes(id):i<(flight.gems?.count??4)&&!hidden.has(id));
}

/** Exterior passages are axis-aligned outside the largest ordinary wing pose.
 * The short approach/departure ends exactly at the owner's saved point. Saved
 * interior points are intentional; no sampler silently relocates that anchor. */
function passage(from,to,anchors,size,extent){
  const key=[from,to,size,extent,...WING_STATION_IDS.flatMap(id=>[anchors[id].x,anchors[id].y])].join(',');
  const saved=passageCache.get(key);if(saved)return saved;
  const a=anchors[from],b=anchors[to],pad=30*Math.max(.5,size),scale=Math.max(1,extent);
  const points=Object.values(anchors),left=Math.min(-270*scale-pad,...points.map(p=>p.x-pad)),right=Math.max(270*scale+pad,...points.map(p=>p.x+pad));
  const top=Math.min(-250*scale-pad,...points.map(p=>p.y-pad)),bottom=Math.max(257*scale+pad,...points.map(p=>p.y+pad));
  const side=id=>(Math.sign(anchors[id].x)||(id.startsWith('left')?-1:1))<0?left:right,ax=side(from),bx=side(to);
  const crossing=Math.abs(a.y-top)+Math.abs(b.y-top)<=Math.abs(a.y-bottom)+Math.abs(b.y-bottom)?top:bottom;
  const raw=ax===bx?[[a.x,a.y],[ax,a.y],[ax,b.y],[b.x,b.y]]:
    [[a.x,a.y],[ax,a.y],[ax,crossing],[bx,crossing],[bx,b.y],[b.x,b.y]];
  // Small rounded corners keep travel continuous without cutting across the
  // wing. The 30-unit clearance remains at least 24 units after rounding.
  const path=[raw[0]];
  for(let i=1;i<raw.length-1;i++){
    const p=raw[i],before=raw[i-1],after=raw[i+1],l=Math.hypot(p[0]-before[0],p[1]-before[1]),r=Math.hypot(after[0]-p[0],after[1]-p[1]),radius=Math.min(12,l/3,r/3);
    if(!radius){path.push(p);continue;}
    const entry=p.map((v,k)=>v+(before[k]-v)*radius/l),exit=p.map((v,k)=>v+(after[k]-v)*radius/r);path.push(entry);
    for(let j=1;j<=6;j++){const u=j/6;path.push(p.map((v,k)=>(1-u)**2*entry[k]+2*(1-u)*u*v+u*u*exit[k]));}
  }
  path.push(raw.at(-1));
  const lengths=path.slice(1).map((p,i)=>Math.hypot(p[0]-path[i][0],p[1]-path[i][1]));
  const route={path,lengths,length:lengths.reduce((a,b)=>a+b,0)};
  if(passageCache.size>=PASSAGE_CACHE_LIMIT)passageCache.delete(passageCache.keys().next().value);
  passageCache.set(key,route);return route;
}
function along(route,t){
  let distance=route.length*smooth(t);
  for(let i=0;i<route.lengths.length;i++){
    const length=route.lengths[i];if(distance<=length||i===route.lengths.length-1){const a=route.path[i],b=route.path[i+1],u=length?unit(distance/length):0;return {x:a[0]+(b[0]-a[0])*u,y:a[1]+(b[1]-a[1])*u};}distance-=length;
  }
  return {x:route.path[0][0],y:route.path[0][1]};
}

/** Count/placement transitions reuse the same exterior passages. Exact end
 * points keep interrupted captures continuous, including arbitrary identities. */
export function sampleWingTransfer(from,to,progress,{size=1,extent=1}={}){
  const p=unit(progress);if(p===0)return {...from};if(p===1)return {...to};
  let xy;
  // A nearby edit on the same side is a local correction, not a lap around
  // the wing. Cross-side moves always use the exterior corridor.
  const local=Math.sign(from.x)===Math.sign(to.x)&&Math.hypot(to.x-from.x,to.y-from.y)<=80;
  if(local)xy={x:from.x+(to.x-from.x)*smooth(p),y:from.y+(to.y-from.y)*smooth(p)};
  else{
    const aSide=from.x<0?'left':'right',bSide=to.x<0?'left':'right',upper=(from.y+to.y)/2<15;
    const a=aSide+(upper?'Upper':'Lower'),b=bSide+(aSide===bSide?(upper?'Lower':'Upper'):(upper?'Upper':'Lower'));
    xy=along(passage(a,b,{...defaults,[a]:from,[b]:to},size,extent),p);
  }
  return {...to,...xy,z:finite(from.z,-24)+(finite(to.z,-24)-finite(from.z,-24))*smooth(p),angle:turn(finite(from.angle,0),finite(to.angle,0),smooth(p))};
}

/** Pure, shared support choreography. Four hold exact anchors; three make
 * tiny outward corrections; two patrol opposite sides; one makes the complete
 * exterior circuit. Time is the existing, speed-adjusted visual clock. */
export function sampleWingStabilization({station='leftUpper',anchors=defaults,stations=WING_STATION_IDS,time=0,strength=.55,enabled=true,reducedMotion=false,seed=0,size=1,extent=1,formationWeights=null}={}){
  // Compatibility for raw pre-allocation count snapshots only. Current HUD/API
  // changes migrate to allocation captures and use a fixed end-time intercept.
  // Weights alone retain interrupted legacy blend boundaries, but cannot encode
  // the previous route/winding needed for obstacle-safe captured handoffs.
  if(formationWeights){
    let result=null,total=0;
    for(let n=1;n<=4;n++){
      const weight=formationWeights[n-1]??0;if(weight<.000001)continue;
      const current=sampleWingStabilization({station,anchors,stations:WING_STATION_IDS.slice(0,n),time,strength,enabled,reducedMotion,seed,size,extent});
      if(!result){result=current;total=weight;continue;}
      const gain=weight/(total+weight),before=result;
      result={...current,...sampleWingTransfer(result,current,gain,{size,extent}),energy:before.energy+(current.energy-before.energy)*gain,dwell:before.dwell+(current.dwell-before.dwell)*gain};
      total+=weight;
    }
    if(result)return result;
  }
  if(WING_STATION_IDS.some(id=>!anchors[id]||!['x','y','z','angle'].every(k=>Number.isFinite(anchors[id][k]))))
    anchors=Object.fromEntries(WING_STATION_IDS.map(id=>{const p=anchors[id]??defaults[id];return [id,{x:finite(p.x,defaults[id].x),y:finite(p.y,defaults[id].y),z:finite(p.z,-24),angle:finite(p.angle,defaults[id].angle)}];}));
  const ids=WING_STATION_IDS.filter(id=>stations.includes(id)),count=ids.length,home=anchors[station]??anchors.leftUpper,index=WING_STATION_IDS.indexOf(station),side=Math.sign(home.x)||(station.startsWith('left')?-1:1);
  const rest={...home,count,energy:1,dwell:1,target:station,phase:'holding',supportSide:side,bothWings:count===1,activity:null};
  if(!ids.includes(station)||!enabled||reducedMotion||!(strength>0)||count===4||count===0)return rest;
  const a=unit(strength),clock=finite(time,0),phase=clock*(.8+.35*a)+index*1.79+finite(seed,0)*.13;
  if(count===3){
    const x=side*a*2.6*(1-Math.cos(phase)),y=(home.y<15?-1:1)*a*1.15*(1-Math.cos(phase*.79));
    return {...rest,x:home.x+x,y:home.y+y,angle:home.angle+a*.035*Math.sin(phase),energy:1+.045*a*(1+Math.sin(phase*.8)),dwell:.85,phase:'correcting',activity:{state:'aligning',amount:.18*a}};
  }
  let order;
  if(count===2){
    const other=ids.find(id=>id!==station),sameSide=other.startsWith('left')===station.startsWith('left');
    const identitySide=station.startsWith('left')?-1:1,assigned=sameSide&&ids.indexOf(station)===1?-identitySide:identitySide,prefix=assigned<0?'left':'right';
    order=station.endsWith('Lower')?[prefix+'Lower',prefix+'Upper']:[prefix+'Upper',prefix+'Lower'];
  }else{const start=perimeter.indexOf(station);order=[...perimeter.slice(start),...perimeter.slice(0,start)];}
  const speed=(count===1?230:115)*(.7+.6*a),hold=count===1?.42:.86;
  const legs=order.map((id,i)=>{const target=order[(i+1)%order.length],route=passage(id,target,anchors,size,extent);return {id,target,route,duration:route.length/speed};});
  const period=legs.reduce((v,leg)=>v+hold+leg.duration,0);let elapsed=wrap(clock,period);
  for(const leg of legs){
    const from=anchors[leg.id],to=anchors[leg.target];
    if(elapsed<hold){
      const pulse=Math.sin(Math.PI*elapsed/hold)**2;
      return {...rest,...from,target:leg.id,energy:1.2+.24*pulse,dwell:1,phase:'stabilizing',supportSide:Math.sign(from.x)||(leg.id.startsWith('left')?-1:1),
        activity:{state:'bracing',amount:.65+.25*pulse,progress:elapsed/hold}};
    }
    elapsed-=hold;
    if(elapsed<leg.duration){
      const progress=elapsed/leg.duration,p=along(leg.route,progress),settle=1-smooth(progress/.16)*smooth((1-progress)/.16);
      return {...rest,...p,z:from.z+(to.z-from.z)*smooth(progress),angle:turn(from.angle,to.angle,smooth(progress)),target:leg.target,
        energy:1.02+.18*settle,dwell:settle,phase:'transit',supportSide:p.x<0?-1:1,activity:{state:'conducting',amount:.32,progress}};
    }
    elapsed-=leg.duration;
  }
  return rest;
}
/** Independent station keeping bounded to a six-unit ellipse around each
 * configured anchor. The core's existing machinery has a separate clock. */
export function sampleWingStationMotion({station='leftUpper',time=0,strength=.55,enabled=true,seed=0,program='poised'}={}){
  if(!enabled||!(strength>0))return {x:0,y:0,z:0,angle:0,energy:1};
  const index=['leftUpper','rightUpper','leftLower','rightLower'].indexOf(station),i=Math.max(0,index),a=unit(strength),phase=time*(program==='seraph'?.69:program==='orbital'?.93:.78)+i*1.79+(seed%173)/173*6.283;
  const cycle=(time*.081+i*.231)%1,adjust=smooth(cycle/.18)*(1-smooth((cycle-.43)/.24));
  const x=a*(3.8*Math.sin(phase)+1.15*Math.sin(phase*.43+i)),y=a*(4.6*Math.cos(phase*.81)+.7*Math.sin(phase*.37));
  return {x,y,z:a*.75*Math.sin(phase*.61),angle:a*(.055*Math.sin(phase*.73)+.018*adjust*(i%2?1:-1)),
    energy:1+a*(.035*Math.sin(phase*1.31)+.035*adjust)};
}
