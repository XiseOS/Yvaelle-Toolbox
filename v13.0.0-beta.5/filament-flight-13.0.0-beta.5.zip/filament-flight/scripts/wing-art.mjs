/** Original, code-drawn filament wings using exactly #ff00ff with varying opacity.
 * No portrait pixels or third-party animation assets are used.
 * Coordinates are in a 600 × 600 transparent frame; attachment point is (300,300).
 */
export const ART_SIZE = 600;
export const FRAME_SIZE = 512;
export const FRAME_COUNT = 48;
export const FRAME_COLUMNS = 8;
export const LOOP_SECONDS = 2.4;
export const WING_COLOR = '#ff00ff';

const WING_RGB = [1,3,5].map(i=>parseInt(WING_COLOR.slice(i,i+2),16)).join(',');
const ink = alpha=>`rgba(${WING_RGB},${alpha})`;

const TAU = Math.PI * 2;
const ROOT = [27, -13];
const RIBS = [
  [ROOT, [85,-25], [99,-176], [165,-202]],
  [ROOT, [84,-46], [115,-139], [160,-141]],
  [ROOT, [103,-53], [160,-123], [197,-78]],
  [ROOT, [124,-40], [193,-80], [226,-5]],
  [ROOT, [128,-48], [210,-19], [246,79]],
  [ROOT, [97,-15], [176,6], [197,64]],
  [ROOT, [113,4], [194,55], [211,119]],
  [ROOT, [98,2], [190,103], [192,176]],
  [ROOT, [86,6], [171,141], [143,218]],
  [ROOT, [96,13], [178,148], [96,249]]
];

export function cubic(points, t) {
  const s = 1-t;
  return [0,1].map(i => s*s*s*points[0][i] + 3*s*s*t*points[1][i]
    + 3*s*t*t*points[2][i] + t*t*t*points[3][i]);
}

function warp([x,y], phase, side) {
  const w = Math.max(0, (x-ROOT[0])/220);
  // The root is fixed; the tips sweep back and flex during each wingbeat.
  const spread = 0.62 + 0.38 * (0.5 + 0.5*Math.cos(phase));
  return [side*(ROOT[0] + (x-ROOT[0])*spread),
    y + w*26*Math.sin(phase) + w*w*8*Math.sin(phase+y*0.012)];
}

function path(ctx, points, phase, side) {
  ctx.beginPath();
  points.forEach((p,i) => {
    const [x,y] = warp(p,phase,side);
    if (i) ctx.lineTo(x,y); else ctx.moveTo(x,y);
  });
}

function glowStroke(ctx, pts, phase, side, strength=1, width=1) {
  path(ctx,pts,phase,side);
  ctx.strokeStyle = ink(0.10*strength);
  ctx.lineWidth = width*10; ctx.stroke();
  ctx.strokeStyle = ink(0.24*strength);
  ctx.lineWidth = width*4; ctx.stroke();
  ctx.strokeStyle = ink(0.9*strength);
  ctx.lineWidth = width; ctx.stroke();
  ctx.strokeStyle = ink(0.95*strength);
  ctx.lineWidth = width*0.28; ctx.stroke();
}

function bezierPoints(p, count=36) {
  return Array.from({length:count+1},(_,i)=>cubic(p,i/count));
}

function star(ctx, x, y, radius, alpha) {
  const g=ctx.createRadialGradient(x,y,0,x,y,radius*3.8);
  g.addColorStop(0,ink(alpha*0.7));
  g.addColorStop(1,ink(0));
  ctx.fillStyle=g; ctx.beginPath(); ctx.arc(x,y,radius*3.8,0,TAU); ctx.fill();
  ctx.fillStyle=ink(alpha);
  ctx.beginPath(); ctx.moveTo(x,y-radius*1.7); ctx.quadraticCurveTo(x+radius*0.15,y-radius*0.1,x+radius,y);
  ctx.quadraticCurveTo(x+radius*0.15,y+radius*0.1,x,y+radius*1.7);
  ctx.quadraticCurveTo(x-radius*0.15,y+radius*0.1,x-radius,y);
  ctx.quadraticCurveTo(x-radius*0.15,y-radius*0.1,x,y-radius*1.7);ctx.fill();
}

function sigil(ctx,x,y,phase,side,scale) {
  const p=warp([x,y],phase,side);
  ctx.save(); ctx.translate(...p);ctx.rotate(side*(0.38+0.07*Math.sin(phase)));
  ctx.scale(scale,scale);
  ctx.lineWidth=0.55; ctx.strokeStyle=ink(0.5);
  ctx.beginPath();ctx.ellipse(0,0,15,31,0,0,TAU);ctx.stroke();
  ctx.beginPath();ctx.ellipse(0,-8,8,12,0,0,TAU);ctx.stroke();
  ctx.strokeStyle=ink(0.9);ctx.lineWidth=0.65;
  ctx.beginPath();ctx.moveTo(0,-32);ctx.lineTo(4,-17);ctx.lineTo(10,-13);
  ctx.lineTo(4,-10);ctx.lineTo(0,1);ctx.lineTo(-4,-10);
  ctx.lineTo(-10,-13);ctx.lineTo(-4,-17);ctx.closePath();ctx.stroke();
  star(ctx,0,-12,1.5,0.8);
  ctx.restore();
}

function wing(ctx,phase,side) {
  const outline = [
    [ROOT,[83,-34],[92,-176],[165,-202]],
    [[165,-202],[123,-179],[132,-142],[125,-122]],
    [[125,-122],[176,-158],[224,-23],[246,79]],
    [[246,79],[208,17],[190,46],[211,119]],
    [[211,119],[229,191],[159,222],[96,249]],
    [[96,249],[169,183],[158,118],[137,57]],
    [[137,57],[101,24],[61,14],ROOT]
  ].flatMap(p=>bezierPoints(p,24));

  path(ctx,outline,phase,side);
  const membrane=ctx.createLinearGradient(side*35,-40,side*215,135);
  membrane.addColorStop(0,ink(0.035));
  membrane.addColorStop(0.5,ink(0.17));
  membrane.addColorStop(1,ink(0.025));
  ctx.fillStyle=membrane;ctx.fill();
  glowStroke(ctx,outline,phase,side,0.95,1.05);

  // Main bowed filaments. The delicate web is attached to these ribs.
  RIBS.forEach((rib,i)=>{
    glowStroke(ctx,bezierPoints(rib),phase,side, i===0||i===4||i===9?1:0.7,
      i===0||i===4||i===9?1.8:0.9);
  });
  for(let i=0;i<RIBS.length-1;i++) {
    for(let j=1;j<=9;j++) {
      const t=j/10;
      const a=cubic(RIBS[i], t);
      const b=cubic(RIBS[i+1], Math.min(0.96,t+0.045*Math.sin(i*2.1+j*1.9)));
      const bend=[(a[0]+b[0])*0.5-6*Math.sin(j*1.7+i), (a[1]+b[1])*0.5+8];
      const pts=bezierPoints([a,bend,bend,b],12);
      glowStroke(ctx,pts,phase,side,0.32+0.22*(0.5+0.5*Math.sin(i*1.5+j)),0.55);
      if((i+j)%3===0 && j<9) {
        const c=cubic(RIBS[i+1],Math.min(0.98,t+0.13));
        const cp=[(a[0]+c[0])/2+4,(a[1]+c[1])/2-6];
        glowStroke(ctx,bezierPoints([a,cp,cp,c],12),phase,side,0.32,0.45);
      }
    }
  }

  // Travelling light follows the veins; nothing flickers at random each frame.
  [0,2,4,6,8,9].forEach((ribIndex,i)=>{
    const t=(phase/TAU*2+i*0.149)%1;
    const alpha=Math.pow(Math.sin(Math.PI*t),0.8)*0.9;
    const trail=[];
    for(let k=0;k<=9;k++) trail.push(cubic(RIBS[ribIndex],Math.max(0,t-k*0.006)));
    glowStroke(ctx,trail,phase,side,alpha,1.6);
    const p=warp(cubic(RIBS[ribIndex],t),phase,side);
    star(ctx,...p,1.5+0.3*Math.sin(phase+i),alpha);
  });
  sigil(ctx,220,-159,phase,side,0.8);
  sigil(ctx,205,202,phase,side,0.64);
}

export function drawFrame(ctx, phase, size=FRAME_SIZE) {
  ctx.clearRect(0,0,size,size);
  ctx.save();ctx.scale(size/ART_SIZE,size/ART_SIZE);ctx.translate(300,285);
  ctx.lineCap='round';ctx.lineJoin='round';
  wing(ctx,phase,-1);wing(ctx,phase,1);
  ctx.restore();
}

export function drawShadow(ctx,width=192,height=96) {
  ctx.clearRect(0,0,width,height);ctx.save();ctx.translate(width/2,height/2);
  ctx.scale(width/2,height/2);
  const g=ctx.createRadialGradient(0,0,0,0,0,1);
  g.addColorStop(0,'rgba(8,0,15,0.62)');g.addColorStop(0.3,'rgba(12,0,17,0.35)');
  g.addColorStop(0.7,'rgba(18,0,26,0.08)');g.addColorStop(1,'rgba(18,0,26,0)');
  ctx.fillStyle=g;ctx.fillRect(-1,-1,2,2);ctx.restore();
}
