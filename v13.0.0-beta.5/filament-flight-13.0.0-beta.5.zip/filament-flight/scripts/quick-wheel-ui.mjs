/** Quick wheel interface. Pure DOM: no Foundry globals, so the same code runs
 * in the module and in the stand-alone preview page.
 *
 * The centre stays open so the token is always visible. Slots are diamond
 * "bits" on a braided filament ring; the chosen action is named on a small
 * plaque under the ring.
 *
 * host = {
 *   doc, anchor(): {x, y, r?} screen centre and token radius,
 *   slots(), saveSlots(slots), describe(slot): {label, sub, active, disabled},
 *   run(slot), catalog, choices(param), defaults(), reducedMotion(), error(e)
 * } */
export const WHEEL_ICONS={
  flight:'M4 18c3-8 9-12 16-13M9 18c1-5 5-8 10-9M4 18h16',
  wings:'M12 6v13M12 8C9 5 4 5 3 9c3 0 5 2 9 4M12 8c3-3 8-3 9 1-3 0-5 2-9 4',
  afterimage:'M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0M8 9.5a3 3 0 0 0 0 5M5 10.5a2 2 0 0 0 0 3',
  shield:'M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z',
  height:'M12 20V5M8 9l4-4 4 4M6 20h12',
  shadow:'M4 17c3 2 13 2 16 0M7 13c2-3 8-3 10 0',
  sound:'M5 10v4h3l4 3V7L8 10zM16 9c1.5 1.5 1.5 4.5 0 6M18.5 7c3 3 3 7 0 10',
  bits:'M12 3l3 5-3 5-3-5zM5 13l2.5 4L5 21l-2.5-4zM19 13l2.5 4-2.5 4-2.5-4z',
  formation:'M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16M12 2v3M12 19v3M2 12h3M19 12h3',
  light:'M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z',
  aim:'M12 3v4M12 17v4M3 12h4M17 12h4M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8',
  pose:'M12 5v14M12 9C8 4 3 6 3 11c3-1 6 0 9 3M12 9c4-5 9-3 9 2-3-1-6 0-9 3',
  condition:'M12 2l4 7-4 13-4-13z',
  spark:'M12 2v6M12 16v6M2 12h6M16 12h6M5 5l4 4M15 15l4 4M19 5l-4 4M9 15l-4 4',
  gesture:'M4 16c4-8 12-8 16 0M8 16c2-4 6-4 8 0',
  medkit:'M4 8h16v11H4zM9 8V5h6v3M12 11v5M9.5 13.5h5',
  hud:'M4 5h16v14H4zM4 9h16M9 9v10',
  macro:'M8 6l-5 6 5 6M16 6l5 6-5 6M14 4l-4 16',
  add:'M12 5v14M5 12h14',
  warp:'M4 18L10 12M14 8l6-6M15 3h5v5M7 12a5 5 0 0 0 5 5M12 7a5 5 0 0 1 5 5M3 21l2-2',
  routine:'M12 3a9 9 0 1 0 9 9M12 7a5 5 0 1 0 5 5M12 11a1 1 0 1 0 1 1M16 3l5 0 0 5',
  rift:'M12 2c3 4 3 16 0 20-3-4-3-16 0-20M5 12h2M17 12h2M7 6l1.5 1.5M16.5 16.5L18 18M17 6l-1.5 1.5M8.5 16.5L7 18',
  scan:'M3 3h6M3 3v6M21 3h-6M21 3v6M3 21h6M3 21v-6M21 21h-6M21 21v-6M6 12h12',
  examine:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6',
  park:'M12 2l3 5-3 5-3-5zM12 12v6M8 21h8M5 9l2 1M19 9l-2 1',
  bind:'M10 14a4 4 0 0 1 0-5.6l2.8-2.8a4 4 0 0 1 5.6 5.6l-1.4 1.4M14 10a4 4 0 0 1 0 5.6l-2.8 2.8a4 4 0 0 1-5.6-5.6l1.4-1.4',
  gather:'M12 12m-3 0a3 3 0 1 0 6 0 3 3 0 0 0-6 0M4 4l4 4M20 4l-4 4M4 20l4-4M20 20l-4-4',
  look:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18M12 7l1.5 3.5L17 12l-3.5 1.5L12 17l-1.5-3.5L7 12l3.5-1.5z'
};
const SVGNS='http://www.w3.org/2000/svg';
const TAU=Math.PI*2;
const wrapAngle=a=>((a%TAU)+TAU)%TAU;

export const WHEEL_CSS=`
.ffw{position:fixed;z-index:100;left:0;top:0;width:0;height:0;pointer-events:none;font-family:'Keepsake Sans',system-ui,sans-serif;
  --mag:#ff00ff;--hot:#ffd2ff;--gold:#cfae76;--gold-hi:#f3d79a;--ink:#f3eadf;--plum:#170d13}
.ffw *{box-sizing:border-box}
.ffw-ring{position:absolute;overflow:visible;pointer-events:none}
.ffw-ring .veil{fill:url(#ffw-veil);opacity:0;transition:opacity .45s}
.ffw.open .ffw-ring .veil{opacity:1}
.ffw-ring .rim{fill:none;stroke:var(--mag);stroke-width:1.6;stroke-dasharray:var(--rimlen);stroke-dashoffset:var(--rimlen);filter:drop-shadow(0 0 4px rgba(255,0,255,.9))}
.ffw.open .ffw-ring .rim{animation:ffw-draw .45s cubic-bezier(.3,.8,.3,1) forwards}
.ffw-ring .rim.gold{stroke:var(--gold);stroke-width:.8;filter:none;opacity:.8}
.ffw.open .ffw-ring .rim.gold{animation-delay:.08s}
.ffw-ring .braid{fill:none;stroke-linecap:round;stroke-dasharray:var(--braidlen);stroke-dashoffset:var(--braidlen)}
.ffw-ring .braid.a{stroke:rgba(255,0,255,.85);stroke-width:1.2;filter:drop-shadow(0 0 3px rgba(255,0,255,.8))}
.ffw-ring .braid.b{stroke:rgba(207,174,118,.75);stroke-width:.9}
.ffw-ring .braid.c{stroke:rgba(255,190,255,.5);stroke-width:.6}
.ffw.open .ffw-ring .braid{animation:ffw-draw .9s cubic-bezier(.25,.8,.3,1) .12s forwards}
.ffw.open .ffw-ring .braid.b{animation-delay:.2s}.ffw.open .ffw-ring .braid.c{animation-delay:.28s}
.ffw-ring .spin{transform-origin:0 0;animation:ffw-spin 60s linear infinite}
.ffw-ring .spin.rev{animation-direction:reverse;animation-duration:84s}
.ffw-ring .knot{fill:var(--gold);opacity:0;transition:opacity .3s}
.ffw.open .ffw-ring .knot{opacity:.95;transition-delay:calc(.45s + var(--i)*40ms)}
.ffw-ring .mote{fill:#fff;filter:drop-shadow(0 0 3px var(--mag))}
.ffw-ring .mote{opacity:0;transition:opacity .4s .6s}.ffw.open .ffw-ring .mote{opacity:.9}
.ffw-ring .tether{fill:none;stroke:var(--mag);stroke-width:1.6;stroke-linecap:round;stroke-dasharray:3 5;filter:drop-shadow(0 0 4px rgba(255,0,255,.95));opacity:0;transition:opacity .18s;animation:ffw-flow .7s linear infinite}
.ffw-ring .tether.core{stroke:var(--hot);stroke-width:.6;stroke-dasharray:none;animation:none}
.ffw.has-pick .ffw-ring .tether{opacity:1}
@keyframes ffw-draw{to{stroke-dashoffset:0}}
@keyframes ffw-spin{to{transform:rotate(360deg)}}
@keyframes ffw-flow{to{stroke-dashoffset:-16}}
/* diamond slots */
.ffw-slot{position:absolute;left:-30px;top:-30px;width:60px;height:60px;padding:0;border:0;background:none;cursor:pointer;pointer-events:auto;outline:none;
  transform:translate(0,0) rotate(-120deg) scale(.15);opacity:0;
  transition:transform .55s cubic-bezier(.22,1.3,.4,1) calc(.1s + var(--i)*45ms),opacity .3s calc(.1s + var(--i)*45ms)}
.ffw.open .ffw-slot{transform:translate(var(--x),var(--y)) rotate(0) scale(1);opacity:1}
.ffw.closing .ffw-slot{transition:transform .26s cubic-bezier(.5,0,.8,.4) calc(var(--i)*18ms),opacity .22s calc(var(--i)*18ms)}
.ffw-bob{position:absolute;inset:0;animation:ffw-bob 3.2s ease-in-out infinite;animation-delay:calc(var(--i)*-.41s)}
@keyframes ffw-bob{50%{transform:translateY(-2.5px)}}
.ffw-gem{position:absolute;left:10px;top:10px;width:40px;height:40px;transform:rotate(45deg);border-radius:3px;
  background:linear-gradient(135deg,#3a2131 0%,#1a0e16 55%,#2a1622 100%);
  box-shadow:inset 0 0 0 1.5px var(--gold),inset 0 0 0 4px #150b12,inset 0 0 0 5px rgba(207,174,118,.35),0 6px 14px rgba(0,0,0,.65);
  transition:transform .28s cubic-bezier(.3,1.6,.5,1),box-shadow .28s,background .28s}
.ffw-gem::before{content:"";position:absolute;inset:5px;border-radius:2px;background:linear-gradient(135deg,rgba(255,255,255,.14),transparent 45%);pointer-events:none}
.ffw-gem::after{content:"";position:absolute;inset:-2px;border-radius:3px;background:linear-gradient(115deg,transparent 35%,rgba(255,235,255,.85) 50%,transparent 65%);background-size:250% 250%;background-position:120% 120%;opacity:0;pointer-events:none}
.ffw.open .ffw-gem::after{animation:ffw-glint .9s ease-out forwards;animation-delay:calc(.45s + var(--i)*45ms)}
@keyframes ffw-glint{0%{opacity:1;background-position:120% 120%}100%{opacity:0;background-position:-20% -20%}}
.ffw-icon{position:absolute;inset:0;display:grid;place-items:center;color:var(--gold-hi);transition:color .2s,transform .28s cubic-bezier(.3,1.6,.5,1)}
.ffw-icon svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 1px 1px rgba(0,0,0,.6))}
.ffw-slot.active .ffw-gem{background:linear-gradient(135deg,#5a1450 0%,#2a0a24 60%,#3e1035 100%);box-shadow:inset 0 0 0 1.5px var(--gold-hi),inset 0 0 0 4px #200a1b,inset 0 0 0 5px rgba(255,0,255,.6),0 0 14px rgba(255,0,255,.4),0 6px 14px rgba(0,0,0,.65)}
.ffw-slot.active .ffw-icon{color:#fff}
.ffw.has-pick .ffw-slot:not(.picked){opacity:.72}
.ffw-slot.picked .ffw-gem{transform:rotate(45deg) scale(1.2);background:linear-gradient(135deg,#ff3df0 0%,#8a0f7c 45%,#3a0a33 100%);
  box-shadow:inset 0 0 0 1.5px var(--hot),inset 0 0 0 4px rgba(40,6,34,.85),inset 0 0 0 5.5px var(--gold-hi),0 0 26px rgba(255,0,255,.75),0 0 60px rgba(255,0,255,.25),0 8px 18px rgba(0,0,0,.6)}
.ffw-slot.picked .ffw-icon{color:#fff;transform:scale(1.12)}
.ffw-slot.disabled .ffw-gem{filter:saturate(.3) brightness(.7)}
.ffw-slot.fired .ffw-gem{animation:ffw-fire .55s cubic-bezier(.2,.8,.3,1)}
@keyframes ffw-fire{0%{transform:rotate(45deg) scale(1.2)}40%{transform:rotate(135deg) scale(1.35);box-shadow:0 0 0 0 rgba(255,0,255,.9),0 0 40px rgba(255,0,255,.9)}100%{transform:rotate(225deg) scale(.6);box-shadow:0 0 0 30px rgba(255,0,255,0)}}
.ffw-slot.add .ffw-gem{background:transparent;box-shadow:inset 0 0 0 1px rgba(255,0,255,.6);border:1px dashed rgba(255,0,255,.45)}
.ffw-slot.add .ffw-icon{color:var(--mag)}
.ffw.editing .ffw-bob{animation:ffw-wobble 1.8s ease-in-out infinite;animation-delay:calc(var(--i)*-.25s)}
@keyframes ffw-wobble{25%{transform:rotate(-5deg)}75%{transform:rotate(5deg)}}
/* plaque */
.ffw-plaque{position:absolute;left:0;top:var(--py);transform:translate(-50%,0) translateY(8px);width:240px;box-sizing:border-box;padding:7px 22px 8px;text-align:center;pointer-events:auto;
  background:linear-gradient(180deg,rgba(32,16,27,.96),rgba(17,9,14,.96));
  clip-path:polygon(12px 0,calc(100% - 12px) 0,100% 50%,calc(100% - 12px) 100%,12px 100%,0 50%);
  box-shadow:inset 0 0 0 1px rgba(207,174,118,.5);opacity:0;transition:opacity .3s .35s,transform .45s cubic-bezier(.3,1.4,.5,1) .35s}
.ffw-plaque::before,.ffw-plaque::after{content:"";position:absolute;top:50%;width:6px;height:6px;margin-top:-3px;background:var(--mag);transform:rotate(45deg);box-shadow:0 0 6px var(--mag)}
.ffw-plaque::before{left:7px}.ffw-plaque::after{right:7px}
.ffw.open .ffw-plaque{opacity:1;transform:translate(-50%,0)}
.ffw.closing .ffw-plaque{transition-delay:0s,0s}
.ffw-name{display:block;font-family:'Keepsake Serif',Georgia,serif;font-weight:700;font-size:19px;line-height:1.1;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ffw-name.swap{animation:ffw-swap .22s ease-out}
@keyframes ffw-swap{from{opacity:.2;transform:translateY(3px)}}
.ffw-meta{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:1px;font-size:11px;color:#b9a69c;white-space:nowrap}
.ffw-sub{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;text-align:left}
.ffw-edit{flex-shrink:0}
.ffw-edit{font:600 10px/1 inherit;letter-spacing:.08em;text-transform:uppercase;color:var(--gold);background:none;border:0;border-bottom:1px solid rgba(207,174,118,.4);padding:1px 0;cursor:pointer}
.ffw-edit:hover,.ffw-edit:focus-visible{color:var(--hot);border-color:var(--mag);outline:none}
/* editor */
.ffw-editor{position:absolute;width:250px;padding:14px;pointer-events:auto;background:rgba(23,13,19,.98);border:1px solid #4a3240;box-shadow:0 18px 40px rgba(0,0,0,.7);color:var(--ink);font-size:12.5px;display:grid;gap:10px;animation:ffw-in .3s cubic-bezier(.2,.9,.3,1.1)}
@keyframes ffw-in{from{opacity:0;transform:translateX(-8px)}}
.ffw-editor h3{margin:0;font-family:'Keepsake Caps',Georgia,serif;font-size:15px;letter-spacing:.08em;color:var(--gold)}
.ffw-editor label{display:grid;gap:4px;font-size:11px;color:#b9a69c}
.ffw-editor select{width:100%;height:30px;padding:0 8px;background:#0f080c;color:var(--ink);border:0;box-shadow:inset 0 0 0 1px #3f2b36;font:inherit;font-size:12.5px}
.ffw-editor .row{display:flex;gap:6px;flex-wrap:wrap}
.ffw-editor button{height:28px;padding:0 10px;font:600 11.5px/1 inherit;color:var(--ink);background:#21151d;border:0;box-shadow:inset 0 0 0 1px #4a3240;cursor:pointer}
.ffw-editor button:hover,.ffw-editor button:focus-visible{box-shadow:inset 0 0 0 1px var(--mag);outline:none}
.ffw-editor button.primary{background:#3a1a30;box-shadow:inset 0 0 0 1px var(--mag)}
.ffw-editor{box-shadow:inset 0 0 0 4px rgba(23,13,19,.98),inset 0 0 0 5px rgba(207,174,118,.26),0 18px 40px rgba(0,0,0,.7)!important;border-color:#4a3240}
.ffw-editor button,.ffw-editor select{clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)}
.ffw-editor .note{color:#9c8a80;font-size:11px;margin:0}
.ffw-burst{position:absolute;left:0;top:0;width:0;height:0;pointer-events:none}
.ffw-burst i{position:absolute;left:-3px;top:-3px;width:6px;height:6px;background:var(--hot);transform:rotate(45deg);box-shadow:0 0 8px var(--mag);animation:ffw-shard .6s cubic-bezier(.2,.8,.3,1) forwards}
@keyframes ffw-shard{to{transform:translate(var(--bx),var(--by)) rotate(225deg) scale(.2);opacity:0}}
.ffw.reduced *{transition-duration:0s!important;animation:none!important}
.ffw.reduced .ffw-ring .rim,.ffw.reduced .ffw-ring .braid{stroke-dashoffset:0}
`;

function braidPath(R,amp,waves,phase){
  let d='';const N=180;
  for(let k=0;k<=N;k++){const a=k/N*TAU,r=R+amp*Math.sin(a*waves+phase);d+=(k?'L':'M')+(r*Math.sin(a)).toFixed(2)+' '+(-r*Math.cos(a)).toFixed(2);}
  return d+'Z';
}

export class QuickWheel{
  constructor(host){this.host=host;this.doc=host.doc;this.root=null;this.pick=-1;this.editing=false;this.editSlot=-1;}
  get isOpen(){return !!this.root;}
  geometry(){
    const a=this.host.anchor?.()??{x:0,y:0,r:40},tokenR=Math.max(24,a.r??40);
    const R=Math.max(118,tokenR+62);
    return {x:a.x,y:a.y,tokenR,R};
  }
  open(){
    if(this.root)return;
    const d=this.doc;if(!d.getElementById('ffw-style')){const s=d.createElement('style');s.id='ffw-style';s.textContent=WHEEL_CSS;d.head.appendChild(s);}
    this.slots=this.host.slots().slice(0,10);this.pick=-1;this.editing=false;
    const root=this.root=d.createElement('div');root.className='ffw';if(this.host.reducedMotion?.())root.classList.add('reduced');
    root.setAttribute('role','menu');root.setAttribute('aria-label','Quick wheel');
    // a new root has no position yet: forget the last centre so place() writes it
    this.center=null;d.body.appendChild(root);this.build();this.place();
    requestAnimationFrame(()=>requestAnimationFrame(()=>root.classList.add('open')));
    this.onMove=e=>this.pointer(e);
    this.onKey=e=>{if(e.key!=='Escape')return;e.preventDefault();e.stopImmediatePropagation();if(this.editing)this.toggleEdit();else this.close();};
    this.onOutside=e=>{if(!this.root||this.editing)return;if(e.target?.closest?.('.ffw-slot,.ffw-plaque,.ffw-editor'))return;if(performance.now()-this.openedAt<250)return;this.close();};
    d.addEventListener('pointermove',this.onMove,true);d.addEventListener('keydown',this.onKey,true);d.addEventListener('pointerdown',this.onOutside,true);
    const loop=()=>{if(!this.root)return;this.place();this.raf=requestAnimationFrame(loop);};this.raf=requestAnimationFrame(loop);
    this.openedAt=performance.now();
  }
  build(){
    const d=this.doc,root=this.root,n=this.slots.length+(this.editing&&this.slots.length<10?1:0);
    const {tokenR,R}=this.g=this.geometry();
    root.innerHTML='';root.classList.toggle('editing',this.editing);
    const box=R+70,rimR=tokenR+5,rimLen=Math.ceil(TAU*rimR),braidLen=Math.ceil(TAU*R*1.08);
    const svg=d.createElementNS(SVGNS,'svg');svg.setAttribute('class','ffw-ring');
    svg.setAttribute('viewBox',`${-box} ${-box} ${box*2} ${box*2}`);svg.style.cssText=`left:${-box}px;top:${-box}px;width:${box*2}px;height:${box*2}px;--rimlen:${rimLen};--braidlen:${braidLen}`;
    // Open centre: the veil darkens the table around the wheel but leaves a clear hole over the token.
    svg.innerHTML=`<defs><radialGradient id="ffw-veil" cx="0" cy="0" r="${box}" gradientUnits="userSpaceOnUse">
        <stop offset="${(rimR+2)/box}" stop-color="rgba(14,6,12,0)"/><stop offset="${(rimR+18)/box}" stop-color="rgba(14,6,12,.42)"/>
        <stop offset="${(R)/box}" stop-color="rgba(40,4,40,.38)"/><stop offset="1" stop-color="rgba(14,6,12,0)"/></radialGradient></defs>
      <circle class="veil" r="${box}"/>
      <circle class="rim" r="${rimR}"/><circle class="rim gold" r="${rimR+4}"/>
      <g class="spin"><path class="braid a" d="${braidPath(R,3.2,n*2,0)}"/></g>
      <g class="spin rev"><path class="braid b" d="${braidPath(R,3.2,n*2,Math.PI)}"/></g>
      <g class="spin"><path class="braid c" d="${braidPath(R+1,5,n*3,1.1)}"/></g>
      <path class="tether" d=""/><path class="tether core" d=""/>`;
    for(let k=0;k<3;k++){const m=d.createElementNS(SVGNS,'circle');m.setAttribute('class','mote');m.setAttribute('r',k?1.2:1.7);
      m.innerHTML=`<animateMotion dur="${7+k*2.5}s" repeatCount="indefinite" begin="${-k*2.1}s" path="${braidPath(R,3.2,n*2,k?Math.PI:0)}"/>`;svg.appendChild(m);}
    const step=TAU/n;
    for(let i=0;i<n;i++){const a=(i+.5)*step,x=R*Math.sin(a),y=-R*Math.cos(a),k=d.createElementNS(SVGNS,'rect');
      k.setAttribute('x',x-3);k.setAttribute('y',y-3);k.setAttribute('width',6);k.setAttribute('height',6);k.setAttribute('transform',`rotate(45 ${x} ${y})`);
      k.setAttribute('class','knot');k.style.setProperty('--i',i);svg.appendChild(k);}
    root.appendChild(svg);this.svg=svg;
    this.buttons=[];
    for(let i=0;i<n;i++){
      const add=i>=this.slots.length,slot=this.slots[i],b=d.createElement('button');b.type='button';b.className='ffw-slot'+(add?' add':'');
      const a=i*step;b.style.setProperty('--x',`${(R*Math.sin(a)).toFixed(1)}px`);b.style.setProperty('--y',`${(-R*Math.cos(a)).toFixed(1)}px`);b.style.setProperty('--i',i);
      b.setAttribute('role','menuitem');
      const info=add?{label:'Add a slot',sub:''}:this.host.describe(slot);
      const icon=add?'add':(this.host.catalog[slot.action]?.icon??'macro');
      b.innerHTML=`<span class="ffw-bob"><span class="ffw-gem"></span><span class="ffw-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${WHEEL_ICONS[icon]??WHEEL_ICONS.macro}"/></svg></span></span>`;
      b.setAttribute('aria-label',info.label+(info.sub?` · ${info.sub}`:''));
      b.classList.toggle('active',!!info.active);b.classList.toggle('disabled',!!info.disabled);
      b.addEventListener('pointerenter',()=>{if(!this.editing)this.setPick(i);});
      b.addEventListener('focus',()=>{if(!this.editing)this.setPick(i);});
      b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(this.editing)this.editAt(i);else this.fire(i);});
      b.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();if(!this.editing){this.editing=true;this.pick=-1;this.root.classList.remove('has-pick');}this.editSlot=Math.min(i,this.slots.length);if(i>=this.slots.length)this.editAt(i);else{this.build();this.root.classList.add('open');}});
      root.appendChild(b);this.buttons.push(b);
    }
    const plaque=d.createElement('div');plaque.className='ffw-plaque';
    const below=(this.doc.defaultView?.innerHeight??1e9)-(this.g.y??0)>R+110;
    plaque.style.setProperty('--py',below?`${R+46}px`:`${-R-96}px`);
    plaque.innerHTML=`<span class="ffw-name">${this.editing?'Edit the wheel':'Quick wheel'}</span><span class="ffw-meta"><span class="ffw-sub">${this.editing?'Choose a slot to change it':'Point, then release · right-click edits'}</span><button type="button" class="ffw-edit">${this.editing?'Done':'Edit'}</button></span>`;
    const edit=plaque.querySelector('.ffw-edit');
    edit.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();e.stopPropagation();this.toggleEdit();});
    edit.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(e.detail===0)this.toggleEdit();});
    root.appendChild(plaque);this.plaque=plaque;
    if(this.editing&&this.editSlot>=0)this.renderEditor();
  }
  place(){
    const a=this.host.anchor?.();if(!a||!this.root)return;
    if(a.x!==this.center?.x||a.y!==this.center?.y){this.root.style.left=`${a.x}px`;this.root.style.top=`${a.y}px`;}
    this.center=a;
    if(this.g&&Math.abs((a.r??40)-(this.g.tokenR??40))>6&&!this.editing){this.build();this.root.classList.add('open');}
  }
  pointer(e){
    if(!this.root||this.editing)return;
    const dx=e.clientX-this.center.x,dy=e.clientY-this.center.y,dist=Math.hypot(dx,dy);
    this.overChrome=!!e.target?.closest?.('.ffw-plaque,.ffw-editor');
    if(this.overChrome||dist>this.g.R+56){this.setPick(-1);return;}
    if(dist<this.g.tokenR*.6){if(!this.buttons[this.pick]?.matches(':hover'))this.setPick(-1);return;}
    const n=this.buttons.length,step=TAU/n,a=wrapAngle(Math.atan2(dx,-dy)+step/2);
    this.setPick(Math.floor(a/step)%n);
  }
  setPick(i){
    if(i===this.pick)return;this.pick=i;
    this.buttons.forEach((b,k)=>b.classList.toggle('picked',k===i));
    this.root.classList.toggle('has-pick',i>=0);
    if(i>=0){
      // a filament thread runs from her token's rim out to the chosen bit
      const n=this.buttons.length,a=i*TAU/n,{tokenR,R}=this.g,r0=tokenR+6,r1=R-26,bend=.22;
      const x0=r0*Math.sin(a),y0=-r0*Math.cos(a),x1=r1*Math.sin(a),y1=-r1*Math.cos(a),mx=(r0+r1)/2*Math.sin(a+bend),my=-(r0+r1)/2*Math.cos(a+bend);
      for(const t of this.svg.querySelectorAll('.tether'))t.setAttribute('d',`M${x0} ${y0}Q${mx} ${my} ${x1} ${y1}`);
    }
    if(this.editing)return;
    const name=this.plaque.querySelector('.ffw-name'),sub=this.plaque.querySelector('.ffw-sub');
    const info=i<0?{label:'Quick wheel',sub:'Point, then release · right-click edits'}:this.slots[i]?this.host.describe(this.slots[i]):{label:'Add a slot',sub:''};
    name.textContent=info.label;sub.textContent=info.sub??'';
    name.classList.remove('swap');void name.offsetWidth;name.classList.add('swap');
  }
  /** Key released: fire the pointed slot; a quick tap (under 200 ms) leaves the wheel open for clicking. */
  release(){
    if(!this.root||this.editing)return;
    if(this.overChrome||performance.now()-this.openedAt<200)return;
    if(this.pick>=0&&this.pick<this.slots.length)this.fire(this.pick);
  }
  burst(i){
    const b=this.buttons[i];if(!b||this.root.classList.contains('reduced'))return;
    const s=this.doc.createElement('span');s.className='ffw-burst';s.style.transform=`translate(${b.style.getPropertyValue('--x')},${b.style.getPropertyValue('--y')})`;
    for(let k=0;k<8;k++){const a=k/8*TAU,sh=this.doc.createElement('i');sh.style.setProperty('--bx',`${Math.cos(a)*34}px`);sh.style.setProperty('--by',`${Math.sin(a)*34}px`);s.appendChild(sh);}
    this.root.appendChild(s);
  }
  async fire(i){
    const slot=this.slots[i];if(!slot)return;const b=this.buttons[i];
    b?.classList.add('fired');this.burst(i);
    const info=this.host.describe(slot);
    setTimeout(()=>this.close(),info.disabled?180:260);
    if(info.disabled)return;
    try{await this.host.run(slot);}catch(error){this.host.error?.(error);}
  }
  toggleEdit(){this.editing=!this.editing;this.editSlot=this.editing?0:-1;this.pick=-1;this.overChrome=false;this.root.classList.remove('has-pick');this.build();requestAnimationFrame(()=>this.root?.classList.add('open'));if(!this.editing)this.host.saveSlots(this.slots);}
  editAt(i){
    if(i>=this.slots.length){this.slots.push({action:'flight'});this.editSlot=this.slots.length-1;this.build();this.root.classList.add('open');return;}
    this.editSlot=i;this.renderEditor();
  }
  renderEditor(){
    const d=this.doc;this.root.querySelector('.ffw-editor')?.remove();
    const slot=this.slots[this.editSlot];if(!slot)return;
    const ed=d.createElement('div');ed.className='ffw-editor';const R=this.g.R;
    const right=(this.center?.x??0)+R+300<(d.defaultView?.innerWidth??1e9);
    ed.style.left=right?`${R+48}px`:`${-R-298}px`;ed.style.top='-150px';
    const groups={};for(const [id,c] of Object.entries(this.host.catalog))(groups[c.group]??=[]).push([id,c]);
    const opts=Object.entries(groups).map(([g,list])=>`<optgroup label="${g}">${list.map(([id,c])=>`<option value="${id}"${id===slot.action?' selected':''}>${c.name}</option>`).join('')}</optgroup>`).join('');
    const param=this.host.catalog[slot.action]?.param,choices=param?this.host.choices(param):[];
    if(param&&!choices.some(c=>c.id===slot.value))slot.value=choices[0]?.id??null;
    ed.innerHTML=`<h3>Slot ${this.editSlot+1}</h3>
      <label>Does<select data-k="action">${opts}</select></label>
      ${param?`<label>${{formation:'Formation',pose:'Pose',condition:'Condition (1 minute)',reaction:'Reaction',gesture:'Gesture',macro:'Macro',feature:'Feature',emote:'Emote',scanWhere:'Where',warpLook:'Look',lightPlace:'Place',look:'Look'}[param]??'Choice'}<select data-k="value">${choices.map(c=>`<option value="${c.id}"${c.id===slot.value?' selected':''}>${c.label}</option>`).join('')}</select></label>`:''}
      <div class="row"><button type="button" data-m="-1">◀ Move</button><button type="button" data-m="1">Move ▶</button><button type="button" data-x>Remove</button></div>
      <div class="row"><button type="button" data-reset>Reset wheel</button><button type="button" class="primary" data-done>Done</button></div>
      <p class="note">Saved when you press Done. The wheel stays open while you edit · Esc also finishes.${this.host.version?` · v${this.host.version}`:''}</p>`;
    ed.addEventListener('change',e=>{const k=e.target.dataset.k;if(!k)return;slot[k]=e.target.value;if(k==='action')slot.value=null;this.build();this.root.classList.add('open');});
    ed.addEventListener('click',e=>{const t=e.target;
      if(t.dataset.m){const j=this.editSlot+Number(t.dataset.m);if(j<0||j>=this.slots.length)return;[this.slots[j],this.slots[this.editSlot]]=[this.slots[this.editSlot],this.slots[j]];this.editSlot=j;this.build();this.root.classList.add('open');}
      if(t.hasAttribute('data-x')&&this.slots.length>3){this.slots.splice(this.editSlot,1);this.editSlot=Math.min(this.editSlot,this.slots.length-1);this.build();this.root.classList.add('open');}
      if(t.hasAttribute('data-reset')){this.slots=this.host.defaults();this.editSlot=0;this.build();this.root.classList.add('open');}
      if(t.hasAttribute('data-done'))this.toggleEdit();});
    this.root.appendChild(ed);
    this.buttons.forEach((b,k)=>b.classList.toggle('picked',k===this.editSlot));
  }
  close(){
    const root=this.root;if(!root)return;this.root=null;cancelAnimationFrame(this.raf);
    if(this.editing)this.host.saveSlots(this.slots);
    this.doc.removeEventListener('pointermove',this.onMove,true);this.doc.removeEventListener('keydown',this.onKey,true);this.doc.removeEventListener('pointerdown',this.onOutside,true);
    root.classList.add('closing');root.classList.remove('open');setTimeout(()=>root.remove(),380);
  }
}
