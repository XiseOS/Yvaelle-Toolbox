/** Eight count-specific companion scores. Each slot owns its local lane for
 * the entire score; roles and working accents pass without exchanging bodies.
 * Smooth closed envelopes provide notice, preparation, work and release. */
const TAU=Math.PI*2,unit=n=>Math.max(0,Math.min(1,n));
const ease=n=>{n=unit(n);return n*n*n*(10+n*(-15+6*n));};
const entry=(name,description)=>Object.freeze({name,description});
const family=(name,counts)=>Object.freeze({name,v7:true,counts:Object.freeze(Object.fromEntries(counts.map(([name,description],i)=>[i+1,entry(name,description)])))});
export const V7_BIT_PROGRAMS=Object.freeze({
  nightbloom:family('Nightbloom',[
    ['Lily keeper','One companion traces a petal circuit beside the shoulder, visiting its lower front and upper rear before folding inward.'],
    ['Parted petals','Opposite companions trace staggered petal circuits and alternate their forward and rear passages.'],
    ['Three veined petals','Two lateral petals turn around a rising stem keeper, with separate front and rear passages.'],
    ['Fourfold nightbloom','Four petal circuits unfold in sequence, trading depth and inclination around the open frame.']]),
  prismArc:family('Prism gallery',[
    ['One shifting facet','One instrument visits four corners of a slanted facet, rounding each turn while examining its reflection.'],
    ['Facing facets','Opposite instruments traverse complementary slanted facets while retaining their own side.'],
    ['Threefold aperture','Two lateral facets articulate an aperture while its high keeper makes a vertical inspection circuit.'],
    ['Refractive arcade','Four instruments traverse unequal faceted archways, with staggered turns and depth passes.']]),
  velvetCourt:family('Velvet court',[
    ['Private courtesy','A companion rises outward, sweeps into a forward bow and withdraws along its shoulder lane.'],
    ['Attendant courtesy','Opposite attendants take staggered outward rises, forward bows and measured withdrawals.'],
    ['Quiet audience','Two attendants sweep a shallow fan while a high witness makes a rising and lowering acknowledgment.'],
    ['Poised retinue','High and low attendants perform staggered courtly passages, approaching, inclining and withdrawing.']]),
  tensionWeft:family('Tension loom',[
    ['Single tensioner','A worker follows an oval shuttle passage, drawing outward, checking its tension and returning through the rear.'],
    ['Opposing tensioners','Opposite workers alternate draw and release along offset oval shuttle passages.'],
    ['Three-point tension','Two lateral shuttles share load with a high keeper that lifts and releases the central tension.'],
    ['Four-strand loom','High and low pairs shuttle through separate working bows, drawing and releasing in diagonal sequence.']]),
  lilyVigil:family('Lily vigil',[
    ['One quiet light','A sentinel makes a deliberate shoulder inspection arc, turning inward before returning through the rear.'],
    ['Shared vigil','Opposite sentinels make staggered inspection arcs and turn their attention through separate depth lanes.'],
    ['Three quiet promises','Two lateral sentinels survey in broad local arcs while a high keeper rises and lowers through its watch.'],
    ['A vigil of four','Four sentinels circulate within separate watch lanes, staggering their inward turns and rear passages.']]),
  foldedLetter:family('Folded correspondence',[
    ['Unsent letter','One writer follows two folded strokes beside Ellie, rounds their corners and gathers the thought back into its core.'],
    ['Private reply','Opposite writers traverse folded strokes in separate lanes and exchange a restrained core response.'],
    ['Three signatures','Two lateral writers trace folded signatures while their high reader makes a vertical checking stroke.'],
    ['Four little letters','Four folded writing passages turn independently; replies pass through core light between the writers.']]),
  pearlCanopy:family('Pearl canopy',[
    ['Held canopy','One companion climbs an inward arch and descends through its outer rear passage.'],
    ['Two half arches','Opposite companions climb complementary arch passages, taking turns opening the canopy.'],
    ['Open vaulted roof','Lateral supports traverse the sides of a vault while its high keystone rises and lowers through the opening.'],
    ['Four suspended arches','Four supports traverse staggered arch passages, lifting and closing an open canopy around Ellie.']]),
  resonantMeasure:family('Resonant measure',[
    ['One measured phrase','One companion follows a measured figure eight, pairing two vertical beats with each inward and outward sweep.'],
    ['Call and resonance','A pair answers with offset figure eights, passing forward and rear as their mechanisms open and settle.'],
    ['Three-part resonance','Two lateral voices articulate staggered figure eights while a high keeper follows their double beat.'],
    ['A measured quartet','Four local figure eights overlap in a measured score, with distinct depths, turns and internal phrases.']]),
});
export const V7_BIT_PROGRAM_IDS=Object.freeze(Object.keys(V7_BIT_PROGRAMS));
/** Station layout belongs to the score. The silhouette remains identifiable
 * even in Reduced motion: petals, a slanted aperture, courtly fan, working
 * rails, high vigil, folded diagonal, nested canopy and asymmetric quartet.
 * The array slots remain physical ownership slots throughout each score;
 * neither the active worker nor an attention target remaps this arrangement. */
const layouts={
  nightbloom:{1:[[106,-42]],2:[[-108,-46],[108,-24]],3:[[-106,27],[106,21],[0,-105]],4:[[-96,-65],[96,-61],[-108,53],[108,49]]},
  prismArc:{1:[[124,-7]],2:[[-116,-68],[116,42]],3:[[-118,-42],[118,42],[0,-119]],4:[[-122,-42],[104,-108],[-104,104],[122,38]]},
  velvetCourt:{1:[[101,-69]],2:[[-92,-90],[92,-90]],3:[[-120,7],[120,7],[0,-122]],4:[[-104,-104],[104,-104],[-123,21],[123,21]]},
  tensionWeft:{1:[[118,12]],2:[[-121,9],[121,9]],3:[[-124,-2],[124,-2],[0,-111]],4:[[-102,-49],[102,-49],[-126,39],[126,39]]},
  lilyVigil:{1:[[89,-104]],2:[[-117,-74],[117,-74]],3:[[-116,-57],[116,-57],[0,-126]],4:[[-124,-23],[124,-23],[-104,-114],[104,-114]]},
  foldedLetter:{1:[[116,38]],2:[[-102,-77],[124,31]],3:[[-119,-28],[119,46],[0,-110]],4:[[-102,-82],[126,-5],[-126,5],[102,82]]},
  pearlCanopy:{1:[[99,-87]],2:[[-105,-78],[105,-78]],3:[[-113,-38],[113,-38],[0,-127]],4:[[-108,-65],[108,-65],[-104,-107],[104,-107]]},
  resonantMeasure:{1:[[110,-24]],2:[[-114,-13],[114,49]],3:[[-111,43],[111,-19],[0,-113]],4:[[-124,-31],[106,-68],[-106,68],[124,31]]},
};
const depths={1:[.45],2:[-.48,.65],3:[.58,.72,-.58],4:[-.62,-.45,.58,.75]};
const periods={nightbloom:18,prismArc:20,velvetCourt:21,tensionWeft:18,lilyVigil:24,foldedLetter:19,pearlCanopy:22,resonantMeasure:18};
/** A faceted route rounds every corner with zero velocity and acceleration.
 * The small pause belongs to each turn, rather than a long stationary post. */
function foldedRoute(clock,period,points,offset=0){
  const phase=clock/period+offset,step=Math.floor(phase),u=ease(phase-step);
  const a=points[((step%points.length)+points.length)%points.length],b=points[(((step+1)%points.length)+points.length)%points.length];
  return [a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u];
}
function phrase(clock,period,index,count){
  const age=clock/period-index*.075,cycle=Math.floor(age),p=age-cycle;
  const prepare=ease((p-.14)/.18),release=ease((p-.7)/.22),engage=prepare*(1-release),work=ease((p-.32)/.17)*(1-ease((p-.66)/.18));
  const settle=ease((p-.67)/.12)*(1-ease((p-.84)/.10));
  return {p,cycle,engage,work,settle,phase:p<.14?'rest':p<.32?'prepare':p<.67?'work':p<.94?'settle':'rest'};
}
export function sampleV7BitScene(count,program,clock,{personality=.35,animated=true,behaviour={},stations=[],displayOffsets=[]}={}){
  const poses=[],intents=[],activities=[],tools=[],focusTargets=[],t=animated?clock:0,strength=animated?unit(personality):0;
  const period=(periods[program]??29)*({composed:1.65,attentive:1,expressive:.76}[behaviour.frequency]??1);
  const workEnabled=strength>0&&behaviour.enabled!==false,energy=unit(behaviour.energy??.5),base=(layouts[program]??layouts.nightbloom)[count]??layouts.nightbloom[4];
  for(let i=0;i<count;i++){
    const a=base[i],side=Math.sign(a[0]),q=t*TAU/(periods[program]??20),f=phrase(t,period,i,count),local=q+i*.81;
    let x=a[0],y=a[1],z=depths[count]?.[i]??depths[4][i],angle=-side*.045;
    // The physical route is independent of optional personality episodes and
    // their frequency. Each instrument keeps its lane, but makes an actual
    // excursion at token scale even between projected work and acknowledgments.
    if(program==='nightbloom'){
      const sweep=q-i*.61,petal=.5-.5*Math.cos(sweep);
      x+=side*(-8+24*petal);y+=side?30*Math.sin(sweep)-6*petal:-15*(1+Math.sin(t*TAU/13-i*.61));
      z+=.22*Math.sin(sweep+.35);angle+=side*.22*Math.sin(sweep);
    }else if(program==='prismArc'){
      const facet=foldedRoute(t,3.1,side?[[0,0],[-20,-24],[12,-28],[8,21]]:[[0,0],[0,-24],[0,-7],[0,-26]],i*.67);
      x+=side*facet[0];y+=facet[1];z+=.23*Math.sin(local);angle+=side*.24*Math.sin(local);
    }else if(program==='velvetCourt'){
      const courtesy=foldedRoute(t,3.6,side?[[-8,-6],[10,-22],[16,3],[-10,31]]:[[0,0],[0,-30],[0,-2],[0,-32]],i*.62);
      x+=side*courtesy[0];y+=courtesy[1];z+=.19*Math.sin(local);
      angle-=side*(.08+.30*ease((courtesy[1]+6)/37));
    }else if(program==='tensionWeft'){
      const shuttle=q+(i%2?Math.PI:0)+Math.floor(i/2)*.7;
      x+=side*(-4+16*Math.cos(shuttle));
      // Upper and lower workers retain separate tension rails during their
      // shared handoff. The rail has a visible bow, with a smaller correction
      // than the lateral shuttle, so the supporting pair does not pinch into
      // one displayed height while a flowing formation exchanges its sides.
      const rail=count===4?12+10*(.5-.5*Math.cos(shuttle)):14*(.5-.5*Math.cos(shuttle));
      y+=side?23*Math.sin(shuttle)+4*Math.sin(shuttle*2)+Math.sign(a[1]||-1)*rail:-16+16*Math.sin(shuttle);
      z+=.18*Math.sin(shuttle+.5);angle+=side*.24*Math.cos(shuttle);
    }else if(program==='lilyVigil'){
      const survey=t*TAU/17+i*1.13;
      x+=side*(-6+16*Math.sin(survey));y+=(side?25:19)*Math.cos(survey);
      z+=.24*Math.sin(survey+.65);angle-=side*.24*Math.sin(survey-.4);
    }else if(program==='foldedLetter'){
      const stroke=foldedRoute(t,2.5,side?[[-14,-16],[8,-16],[-12,12],[8,25],[0,0]]:[[0,-6],[0,-29],[0,-12],[0,-32]],i*.71);
      x+=side*stroke[0];y+=stroke[1];z+=.21*Math.sin(local);angle+=side*.25*Math.sin(local*2);
    }else if(program==='pearlCanopy'){
      const arch=t*TAU/16+i*.93,rise=.5-.5*Math.cos(arch);
      x-=side*(3+18*rise);y+=(side?25:19)*Math.sin(arch)-4*rise;
      z-=.22*Math.cos(arch);angle+=side*.24*Math.sin(arch);
    }else {
      const measure=t*TAU/(count===1?13:15)+i*1.27;
      x+=side*12*Math.sin(measure);y+=side?22*Math.sin(measure*2)+3*Math.sin(measure):-16+16*Math.sin(measure*2);
      z+=.22*Math.cos(measure);angle+=side*.24*Math.sin(measure*2);
    }
    poses[i]=[x,y,z,angle];
    const target=[x*.48,y*.35,z],key=`v7:${program}:${f.cycle}:${i}`;
    focusTargets[i]={kind:'work',target,key};
    if(!workEnabled)continue;
    const amount=strength*f.engage*energy,kind=program==='foldedLetter'||program==='resonantMeasure'?'conduct':'tensionWeft'===program?'mend':program==='pearlCanopy'?'canopy':program==='lilyVigil'?'watch':'observe';
    intents[i]={kind,amount,progress:f.p,target,passive:true};
    const charging=program==='resonantMeasure'||program==='nightbloom',working=program==='tensionWeft'?'aligning':program==='lilyVigil'?'scanning':charging?'charging':'conducting';
    activities[i]={state:working,amount:strength*.48,progress:f.p,phase:f.phase,
      coreChannels:{align:strength*f.engage*.32,open:f.work*.28,charge:charging?f.work*.35:0,conduct:charging?0:f.work*.25,scan:program==='lilyVigil'?f.work*.25:0,settle:f.settle*.25}};
    if(program==='tensionWeft'&&f.work>0)tools[i]={type:'probe',amount:strength*energy*f.work*.26,progress:f.p,variation:i%3};
  }
  return {poses,intents,activities,tools,focusTargets};
}
