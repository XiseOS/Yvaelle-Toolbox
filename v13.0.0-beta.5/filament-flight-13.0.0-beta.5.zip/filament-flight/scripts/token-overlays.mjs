/** Her token's own labels follow her visible body in flight (beta.32).
 *
 * Foundry draws a token's elevation tooltip, nameplate, resource bars and
 * status icons at fixed spots around the token's document box. In flight the
 * module lifts her picture up the screen, shrinks it with her height and lets
 * it swing with her momentum (flight feel: lift, altScale, swayX), so at
 * height the "15 ft" tooltip sat on top of her art. Every display frame (and
 * again right after Foundry refreshes the token) this moves those overlays by
 * the same offset as her visible body:
 *   - her elevation tooltip keeps its gap above the top of her visible picture;
 *   - her nameplate keeps its gap below it;
 *   - both follow her sideways swing and keep their size.
 *
 * Left on her square: the resource bars, the status icons, the selection
 * border, the target arrows and the hit area (bars and icons on her shrunken
 * picture would cover her face; the rest mark where her token is on the map).
 *
 * Foundry's own refresh still sets each position: the offset is added on top
 * of whatever Foundry last set (a change we did not make is taken as Foundry's
 * new base), and everything goes back to Foundry's positions when she lands,
 * flight feel is off, or the module lets go of the token. Nothing is replaced
 * or wrapped. */

const records=new WeakMap();
const EPS=.05;

/** The overlays to move and which edge of her picture each keeps to: only
 * her elevation tooltip and her nameplate. The resource bars and status icons
 * stay on her square as in beta.31 (on her shrunken picture they would cover
 * her face). */
function overlays(token){
  const list=[];
  if(token.tooltip)list.push([token.tooltip,'top']);
  if(token.nameplate)list.push([token.nameplate,'bottom']);
  return list.filter(([o])=>o&&!o.destroyed&&o.position);
}

/** Her visible body's offset from her token box (token-local px): sideways,
 * and for the top and bottom edges of her picture. Zero when she isn't lifted. */
export function bodyOffset(s,token){
  const k=Number.isFinite(s?.altScale)?s.altScale:1,lift=Number.isFinite(s?.lift)?s.lift:0,sway=Number.isFinite(s?.swayX)?s.swayX:0;
  const h=Number(token?.h)||0,shrink=h/2*(1-k);
  return {x:sway,top:lift+shrink,bottom:lift-shrink};
}

/** Move her overlays by `offset` (or put them back with null). Safe to call
 * every frame and from Foundry's refresh hook. */
export function placeOverlays(token,offset){
  if(!token||token.destroyed)return;
  let rec=records.get(token);
  const active=!!offset&&(Math.abs(offset.x)>EPS||Math.abs(offset.top)>EPS||Math.abs(offset.bottom)>EPS);
  if(!active&&!rec)return;
  rec??=records.set(token,new Map()).get(token);
  for(const [o,edge] of overlays(token)){
    let r=rec.get(o);
    const p=o.position;
    // A position we did not write is Foundry's own (a refresh): the new base.
    if(!r||p.x!==r.ax||p.y!==r.ay){r={bx:p.x,by:p.y,ax:p.x,ay:p.y};rec.set(o,r);}
    const x=active?r.bx+offset.x:r.bx,y=active?r.by+(edge==='top'?offset.top:offset.bottom):r.by;
    if(p.x!==x||p.y!==y)p.set(x,y);
    r.ax=p.x;r.ay=p.y;
  }
  if(!active)records.delete(token);
}

/** Put every overlay back where Foundry placed it. */
export function restoreOverlays(token){placeOverlays(token,null);}
