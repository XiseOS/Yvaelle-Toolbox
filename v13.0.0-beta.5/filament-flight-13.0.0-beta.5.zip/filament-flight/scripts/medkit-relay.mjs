/** Medkit GM relay over the module's own socket.
 * Replaces the old "Yvaelle GM Bridge" macro and the Advanced Macros
 * dependency. A player may ask the active GM to make exactly three kinds of
 * change on a patient they do not own, and only Medkit-shaped ones:
 *   createEffect  – a rebuilt immunity or pending-directive effect, no rules
 *   deleteItems   – removing that healer's Medkit effect items only
 *   applyDamage   – Battle Medicine or Treat Wounds healing/harm, and the
 *                   1d8 of the healer's own Risky Surgery
 * The GM client identifies the requester from Foundry's socket sender id
 * (never the message body) and checks that this user owns the healer. */
const ID='filament-flight',CHANNEL=`module.${ID}`;
const FLAG_SCOPE='world',FLAG_KEY='yvaelleSmartBattleMedicine';
const TIMEOUT_MS=15000,MAX_HEAL=150,MAX_HARM=8,DAY=86400;
const KINDS=new Set(['battle-medicine-immunity','treat-wounds-immunity','keep-on-keeping-on-pending']);
const UNIT_SECONDS={rounds:6,minutes:60,hours:3600,days:DAY};
const OUTCOMES=new Set(['criticalFailure','failure','success','criticalSuccess']);
const ROLL_OPTIONS=new Set(['action:battle-medicine','origin:action:slug:battle-medicine','origin:action:trait:healing','origin:action:trait:manipulate','origin:action:trait:skill','item:trait:healing','action:keep-on-keeping-on','lead-by-example',
  'action:treat-wounds','origin:action:slug:treat-wounds','origin:action:trait:exploration']);
const pending=new Map();
let installed=false,senderWarned=false;

const plain=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
const text=(value,max)=>typeof value==='string'?value.slice(0,max):'';
const uuid=value=>typeof value==='string'&&value.length<=256?value:null;
const finite=(value,fallback,min,max)=>{const n=Number(value);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback;};
const medkitFlag=item=>item?.type==='effect'?item.getFlag?.(FLAG_SCOPE,FLAG_KEY):undefined;
const isResponsibleGM=()=>game.user?.isGM&&game.users?.activeGM?.id===game.user.id;
const isBattleMedicine=item=>item?.type==='feat'&&(item.slug==='battle-medicine'||/^battle medicine$/i.test(item.name??''));
const isRiskySurgery=item=>item?.type==='feat'&&(item.slug==='risky-surgery'||/^risky surgery$/i.test(item.name??''));
// Only the plain tags the Medkit writes survive; no attributes, no other markup.
const description=value=>text(value,4000).replace(/<(?!\/?(?:p|strong|em|br)\s*\/?>)[^>]*>?/gi,'');

/** Foundry passes the sending user's id as the listener's second argument.
 * Only where that is missing is the self-reported id used, with one warning. */
function senderOf(message,senderId){
  if(senderId!=null)return game.users.get(senderId)??null;
  if(!senderWarned){senderWarned=true;console.warn('Yvaelle’s Toolbox | Foundry did not identify the socket sender; the Medkit relay is falling back to the id in the message.');}
  return game.users.get(message.from)??null;
}

/** A player's effect is rebuilt from known fields, never passed through. */
function cleanEffectSource(source,healer,patient){
  const flag=source?.flags?.[FLAG_SCOPE]?.[FLAG_KEY],system=source?.system;
  if(source?.type!=='effect'||!plain(flag)||!plain(system))throw new Error('Only Medkit effects can be created for you.');
  if(!KINDS.has(flag.kind)||flag.healerActorUuid!==healer.uuid)throw new Error('That Medkit effect does not belong to your healer.');
  if(system.rules!==undefined&&!(Array.isArray(system.rules)&&!system.rules.length))throw new Error('Medkit effects cannot carry rule elements.');
  const duration=system.duration,value=Number(duration?.value);
  if(!Object.hasOwn(UNIT_SECONDS,duration?.unit)||!(value>0)||value*UNIT_SECONDS[duration.unit]>DAY)throw new Error('That Medkit effect lasts too long.');
  const context=plain(system.context)?system.context:{},origin=plain(context.origin)?context.origin:{},target=plain(context.target)?context.target:null,roll=plain(context.roll)?context.roll:null;
  const img=typeof source.img==='string'&&source.img.length<=2048&&!/^\s*(?:javascript|data|blob|file):/i.test(source.img)?source.img:'icons/svg/regen.svg';
  const data={kind:flag.kind,healerActorUuid:healer.uuid,healerName:text(flag.healerName,60)};
  if(flag.bonus!==undefined)data.bonus=Math.trunc(finite(flag.bonus,0,-20,60));
  if(['directive','regular'].includes(flag.mode))data.mode=flag.mode;
  return {name:text(source.name,120).trim()||'Medkit effect',type:'effect',img,
    system:{description:{value:description(system.description?.value)},
      duration:{value,unit:duration.unit,expiry:['turn-start','turn-end','round-end'].includes(duration.expiry)?duration.expiry:'turn-start',sustained:false},
      level:{value:Math.trunc(finite(system.level?.value,1,1,30))},rules:[],start:{value:0,initiative:null},tokenIcon:{show:system.tokenIcon?.show!==false},traits:{value:[]},fromSpell:false,
      context:{origin:{actor:healer.uuid,token:uuid(origin.token),item:uuid(origin.item),spellcasting:null,rollOptions:[]},
        target:target?{actor:patient.uuid,token:uuid(target.token)}:null,
        roll:roll?{total:finite(roll.total,0,-999,999),degreeOfSuccess:Math.trunc(finite(roll.degreeOfSuccess,0,0,3))}:null}},
    flags:{[FLAG_SCOPE]:{[FLAG_KEY]:data}}};
}

async function perform(action,payload,requester){
  if(!requester)throw new Error('The Medkit request did not identify its user.');
  if(!plain(payload))throw new Error('The Medkit request was empty.');
  const healer=uuid(payload.healerUuid)?await fromUuid(payload.healerUuid):null;
  if(healer?.documentName!=='Actor')throw new Error('The healer could not be found.');
  if(!requester.isGM&&!healer.testUserPermission?.(requester,'OWNER'))throw new Error('You must own the healer to treat this patient.');
  const actor=uuid(payload.actorUuid)?await fromUuid(payload.actorUuid):null;
  if(actor?.documentName!=='Actor')throw new Error('The patient could not be found.');
  switch(action){
    case 'createEffect':{
      const source=requester.isGM?payload.source:cleanEffectSource(payload.source,healer,actor);
      if(source?.type!=='effect'||source?.flags?.[FLAG_SCOPE]?.[FLAG_KEY]===undefined)throw new Error('Only Medkit effects can be created for you.');
      const created=await actor.createEmbeddedDocuments('Item',[source]);
      return created?.[0]?.uuid??null;
    }
    case 'deleteItems':{
      const ids=[...new Set(Array.isArray(payload.ids)?payload.ids.slice(0,64):[])].filter(id=>typeof id==='string'&&medkitFlag(actor.items.get(id))?.healerActorUuid===healer.uuid);
      if(ids.length)await actor.deleteEmbeddedDocuments('Item',ids);
      return ids.length;
    }
    case 'applyDamage':{
      // Exactly what the Medkit sends: healing on a success, or the final 1d8
      // of a critical failure. Anything else is refused.
      const damage=Number(payload.damage),outcome=payload.outcome,harm=damage>0,surgery=payload.surgery===true;
      const item=uuid(payload.itemUuid)?await fromUuid(payload.itemUuid):null;
      if(surgery){
        // Risky Surgery: 1d8 slashing before Treat Wounds heals, from the healer's own feat.
        if(!OUTCOMES.has(outcome)||!Number.isFinite(damage)||!(damage>=1&&damage<=MAX_HARM))throw new Error('That Medicine result is out of range.');
        if(!isRiskySurgery(item)||item.actor?.uuid!==healer.uuid)throw new Error('Risky Surgery must come from the healer.');
      }else{
        if(!OUTCOMES.has(outcome)||!Number.isFinite(damage)||(harm?!(outcome==='criticalFailure'&&payload.final===true&&damage<=MAX_HARM):!((outcome==='success'||outcome==='criticalSuccess')&&damage>=-MAX_HEAL)))throw new Error('That Medicine result is out of range.');
        // Treat Wounds is a skill action with no item; Battle Medicine must be the healer's own feat.
        if(payload.medicineAction==='treat-wounds'){if(item&&item.actor?.uuid!==healer.uuid)throw new Error('Treat Wounds must come from the healer.');}
        else if(!isBattleMedicine(item)||item.actor?.uuid!==healer.uuid)throw new Error('Battle Medicine must come from the healer.');
      }
      const token=uuid(payload.tokenUuid)?await fromUuid(payload.tokenUuid):null;
      if(!token||token.actor?.uuid!==actor.uuid)throw new Error('The patient token does not match.');
      const rollOptions=new Set((Array.isArray(payload.rollOptions)?payload.rollOptions:[]).filter(option=>ROLL_OPTIONS.has(option)));
      const application={damage,token,rollOptions,outcome};if(item)application.item=item;
      if(harm&&!surgery)application.final=true;
      await actor.applyDamage(application);
      return true;
    }
    default:throw new Error(`Unknown Medkit request: ${action}.`);
  }
}

export function installMedkitRelay(){
  if(installed||!game.socket)return;installed=true;
  game.socket.on(CHANNEL,async(message,senderId)=>{
    if(!plain(message))return;
    if(message.type==='medkitResponse'){
      if(message.to!==game.user.id||!senderOf(message,senderId)?.isGM)return;
      const entry=pending.get(message.id);if(!entry)return;pending.delete(message.id);clearTimeout(entry.timer);
      message.ok?entry.resolve(message.result):entry.reject(new Error(text(message.error,500)||'The GM could not complete the treatment.'));
      return;
    }
    if(message.type!=='medkitRequest'||!isResponsibleGM())return;
    const requester=senderOf(message,senderId);
    let reply;
    try{reply={ok:true,result:await perform(message.action,message.payload,requester)};}
    catch(error){reply={ok:false,error:String(error?.message??error)};console.warn('Yvaelle’s Toolbox | Medkit relay refused a request',error);}
    // `from` remains for older clients; receivers trust Foundry's sender id.
    game.socket.emit(CHANNEL,{type:'medkitResponse',id:message.id,from:game.user.id,to:requester?.id??senderId??message.from,...reply});
  });
}

/** Ask for a privileged Medkit change. Runs locally for a GM. */
export async function medkitRequest(action,payload){
  if(game.user.isGM)return perform(action,payload,game.user);
  if(!game.users.activeGM)throw new Error('A GM must be connected so Yvaelle can treat a token you do not own.');
  const id=foundry.utils.randomID(16);
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{pending.delete(id);reject(new Error('The GM did not answer in time. Check that the GM is connected and has Yvaelle’s Toolbox enabled.'));},TIMEOUT_MS);
    pending.set(id,{resolve,reject,timer});
    game.socket.emit(CHANNEL,{type:'medkitRequest',id,from:game.user.id,action,payload});
  });
}
