/** Pure, patient-relative work for the eight bit-operated medical techniques.
 * Distances are token diameters; contacts sit on the patient and every physical
 * source stays on its assigned side. No anatomy, success or Foundry state is
 * inferred. A bit is the instrument: its short projected tool does the work. */
const define=(name,mechanism,period,roles,bounds,fallback)=>Object.freeze({name,mechanism,period,roles:Object.freeze(roles),bounds:Object.freeze(bounds),fallback});
export const V7_MEDICAL_WORK_SPECS=Object.freeze({
  capillaryBridge:define('Restorative infusion','Short core-fed infusion braid delivers restorative packets at a local contact',6.4,['Deliver restorative infusion','Receive and regulate infusion','Stabilize contact','Verify flow'],[67,61],'vascular'),
  irisPatch:define('Pressure mend','Two bit-projected pads press and seal a compact repair patch',6.8,['Press first margin','Seal opposing margin','Hold patch edge','Verify seal'],[65,66],'compression'),
  segmentedCradle:define('Alignment brace','Opposed short hardlight grips support and align a local injured region',7.2,['Support repair region','Align opposing grip','Hold alignment','Verify support'],[72,70],'splint'),
  lymphaticCircuit:define('Cleanse and flush','A bit withdraws spent flecks while its partner returns a clean restorative pulse',6.6,['Extract spent current','Flush clean restorative current','Support clean flow','Verify cleansing'],[67,62],'vascular'),
  fibrilRepair:define('Fiber knit','Fine bit-projected needles knit short stitches across a local seam',7,['Draw repair stitch','Hold and tension stitch','Support seam margin','Inspect knitted seam'],[62,61],'suture'),
  tissueLens:define('Precision mend','A compact focused nib traces and repairs one narrow treatment line',7.6,['Focus and trace repair line','Guide local regeneration','Hold focal reference','Inspect repaired line'],[68,67],'precision'),
  pulseReservoir:define('Reviving cadence','Charged bit apertures press and release paired measured restorative fronts',6.9,['Deliver first restorative pulse','Answer with measured pulse','Stabilize rhythm','Verify response'],[69,72],'pulseHalo'),
  petalSanctuary:define('Protective dressing','A small transparent care film is drawn from the bits and smoothed onto the patient',8.2,['Lay protective film','Smooth and seal dressing','Hold dressing edge','Inspect coverage'],[70,79],'membrane')
});
export const isV7Treatment=id=>Object.hasOwn(V7_MEDICAL_WORK_SPECS,id);
export const classicTreatmentStyle=id=>V7_MEDICAL_WORK_SPECS[id]?.fallback??id;
const TAU=Math.PI*2,clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,Number(n)||0));
const smooth=n=>{n=clamp(n);return n*n*(3-2*n);},wrap=n=>(n%1+1)%1,mix=(a,b,q)=>a+(b-a)*q;
const point=(x,y,z=.30)=>({x,y,z});
const blend=(a,b,q)=>point(mix(a.x,b.x,q),mix(a.y,b.y,q),mix(a.z,b.z,q));
const rotate=(x,y,a,z=.30)=>point(x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a),z);
// Sweep one small treatment region, hold the contact, then return locally.
// Stationary ends leave time for transfer/sealing rather than perpetual orbit.
const heldSweep=q=>q<.08?0:q<.42?smooth((q-.08)/.34):q<.58?1:q<.92?1-smooth((q-.58)/.34):0;
const contactPress=q=>smooth((q-.08)/.20)*(1-smooth((q-.72)/.20));
const cubic=(a,b,c,d,u)=>{u=clamp(u);const q=1-u;return point(q*q*q*a.x+3*q*q*u*b.x+3*q*u*u*c.x+u*u*u*d.x,q*q*q*a.y+3*q*q*u*b.y+3*q*u*u*c.y+u*u*u*d.y,.35);};
const cubicTangent=(a,b,c,d,u)=>{u=clamp(u);const q=1-u;return point(3*q*q*(b.x-a.x)+6*q*u*(c.x-b.x)+3*u*u*(d.x-c.x),3*q*q*(b.y-a.y)+6*q*u*(c.y-b.y)+3*u*u*(d.y-c.y),0);};
const normal=(p,d)=>{const n=Math.hypot(d.x,d.y)||1;return point(-d.y/n*p,d.x/n*p,0);};
const safeTime=time=>Number.isFinite(Number(time))?Math.max(0,Number(time)):0;
/** Good-result contact completion: exact work pose and velocity at entry,
 * followed by a measured finish shared by the actual tools and repair paint. */
export const v7MedicalCompletionProgress=progress=>smooth((progress-.08)/.72);
const DELIVERY_STYLES=new Set(['capillaryBridge','lymphaticCircuit','pulseReservoir']);

/** Local aperture clock for charge -> transfer -> arrival. Every source begins
 * the first acquisition at charge phase zero. Team offsets ease in after that
 * first delivery, then retain the existing stagger at full speed on all later
 * cycles. The wrapped clock is shared with physical core opening and paint. */
export function sampleV7MedicalDeliveryPhase(style,role,count,time=0){
  if(!DELIVERY_STYLES.has(style))return null;
  const period=V7_MEDICAL_WORK_SPECS[style].period,t=safeTime(time),elapsed=t/period;
  const n=clamp(Math.round(count)||1,1,4),offset=n>1&&role===1?(style==='capillaryBridge'?.24:.50):0;
  const stagger=smooth((elapsed-.74)/.22),localElapsed=style==='lymphaticCircuit'&&n===1?elapsed*2:elapsed;
  const wrapped=wrap(localElapsed+offset*stagger),phase=wrapped<1e-12||1-wrapped<1e-12?0:wrapped;
  const transfer=smooth((phase-.18)/.52);
  return {phase,charge:smooth(phase/.09)*(1-smooth((phase-.18)/.09)),
    transfer,delivery:transfer<=0||transfer>=1?0:Math.sin(Math.PI*transfer)**2,
    arrival:smooth((phase-.70)/.09)*(1-smooth((phase-.90)/.10)),
    acquisition:smooth(t/.38),stagger};
}
function deliveryHints(style,role,count,time,repositionAmount=0,cue=sampleV7MedicalDeliveryPhase(style,role,count,time)){
  if(!cue)return {};
  return {charge:cue.charge,transfer:cue.transfer,delivery:cue.delivery,arrival:cue.arrival,acquisition:cue.acquisition,
    deliveryGate:cue.acquisition*(1-repositionAmount),deliveryCharge:cue.charge,
    deliveryTransfer:cue.transfer,deliveryArrival:cue.arrival,
    coreOpening:smooth((cue.phase-.14)/.08)*(1-smooth((cue.phase-.94)/.06))*(1-repositionAmount)};
}

/** Shared material sites for the four contact-authored procedures. The live
 * source geometry and patient painter consume these exact points, so a needle
 * cannot hover beside its stitch or a dressing tool press into the film face.
 * Construction grows once; inspection cursors may loop over the built repair.
 * Every point is in token diameters and every progress is bounded 0..1. */
export function sampleV7MedicalSite(style,count,time=0){
  const spec=V7_MEDICAL_WORK_SPECS[style];if(!spec)return null;
  const n=clamp(Math.round(count)||1,1,4),t=safeTime(time),elapsed=t/spec.period,cycle=wrap(elapsed);
  const site={style,count:n,time:t,elapsed,cycle,materialProgress:smooth(elapsed)};
  if(style==='irisPatch'){
    const cursor=heldSweep(cycle),materialProgress=smooth(elapsed/.65),gap=mix(.060,.022,materialProgress);
    const seam=u=>point(0,mix(-.10,.22,clamp(u)),.35);
    const margins=[[-1,1].map(v=>point(-gap,v<0?-.10:.22,.35)),[-1,1].map(v=>point(gap,v<0?-.10:.22,.35))];
    return {...site,cursor,materialProgress,gap,seam,trace:seam,margins};
  }
  if(style==='tissueLens'){
    const a=point(-.12,-.08,.35),b=point(-.085,.025,.35),c=point(.085,.095,.35),d=point(.12,.20,.35);
    const trace=u=>cubic(a,b,c,d,u),tangent=u=>cubicTangent(a,b,c,d,u),cursor=heldSweep(cycle);
    // The first forward pass deposits the repaired line; later return passes
    // inspect that line instead of erasing or rebuilding its material.
    return {...site,endpoints:[a,d],controlPoints:[a,b,c,d],trace,tangent,cursor,
      materialProgress:elapsed>=.42?1:heldSweep(elapsed)};
  }
  if(style==='fibrilRepair'){
    const rows=2+Math.min(3,n),duration=spec.period/rows,currentStitch=Math.min(rows-1,Math.floor(cycle*rows)),needlePhase=wrap(cycle*rows);
    const stitches=Array.from({length:rows},(_,i)=>{
      const y=-.13+.26*i/(rows-1),start=rotate(-.085,y,-.30,.35),end=rotate(.085,y+.014,-.30,.35);
      const controlA=rotate(-.035,y-.030,-.30,.35),controlB=rotate(.035,y+.044,-.30,.35);
      return {start,end,controlA,controlB,progress:smooth((t-i*duration)/(duration*.70))};
    });
    const current=stitches[currentStitch],next=stitches[(currentStitch+1)%rows],stitchProgress=smooth(needlePhase/.70);
    const transit=needlePhase>.70?(needlePhase-.70)/.30:0,transitionAmount=needlePhase>.70?Math.sin(Math.PI*transit)**2:0;
    const needle=cubic(current.start,current.controlA,current.controlB,current.end,stitchProgress);
    const needleContact=needlePhase<=.70?needle:blend(current.end,next.start,smooth(transit));
    const tensionContact=needlePhase<=.70?current.start:blend(current.start,next.start,smooth(transit));
    const verificationContact=needlePhase<=.70?current.end:blend(current.end,next.end,smooth(transit));
    return {...site,rows,currentStitch,needlePhase,stitchProgress,stitches,needleContact,tensionContact,verificationContact,transitionAmount,
      trace:u=>cubic(current.start,current.controlA,current.controlB,current.end,u),
      tangent:u=>cubicTangent(current.start,current.controlA,current.controlB,current.end,u),
      materialProgress:stitches.reduce((sum,s)=>sum+s.progress,0)/rows};
  }
  if(style==='segmentedCradle'){
    const alignedEndpoints=[point(-.15,-.09,.35),point(.15,.21,.35)],alignment=smooth(elapsed/.58);
    const crookedEndpoints=[point(-.19,-.135,.35),point(.185,.265,.35)];
    return {...site,alignedEndpoints,crookedEndpoints,alignment,materialProgress:alignment,
      endpoints:alignedEndpoints.map((p,i)=>blend(crookedEndpoints[i],p,alignment))};
  }
  if(style==='petalSanctuary'){
    const corners=[point(-.19,-.10,.35),point(.19,-.10,.35),point(.19,.23,.35),point(-.19,.23,.35)];
    const layProgress=smooth(elapsed/.60),y=mix(-.10,.23,layProgress);
    return {...site,corners,layProgress,materialProgress:layProgress,filmEdge:[point(-.19,y,.35),point(.19,y,.35)]};
  }
  return site;
}

/** A good knit result completes the remaining passes with the real needle.
 * Material advances only on that virtual work clock; already deposited rows
 * retain their progress even when an action has run through several loops.
 * Coordinates are uncontracted, so paint and actual contacts apply the same
 * explicit x contraction after sampling the needle and each laid stitch. */
export function sampleV7FinishingSite(style,count,time=0,progress=0){
  if(style!=='fibrilRepair')return sampleV7MedicalSite(style,count,time);
  const t=safeTime(time),period=V7_MEDICAL_WORK_SPECS[style].period,completion=v7MedicalCompletionProgress(progress);
  const destination=(Math.floor(t/period)+1)*period,virtualTime=mix(t,destination,completion);
  return {...sampleV7MedicalSite(style,count,virtualTime),virtualTime,completion,contraction:1-.75*completion};
}

/** Smooth bounded local profiles. First two active sources are the repair
 * team, independent of whether the selected physical crystals are upper or
 * lower. Additional sources hold a useful contact or verify that same work. */
function primaryGeometry(style,role,side,lane,cycle,site,delivery=sampleV7MedicalDeliveryPhase(style,role,site.count,site.time)){
  const k=cycle*TAU,travel=heldSweep(cycle),press=contactPress(cycle);
  const second=role===1,lead=second?1:-1,depth=.30+lane*.10;
  let position,workPoint,toolType='plate',toolPhase=cycle,contact=.28+.72*press,repairProgress=travel,repositionAmount=0;
  switch(style){
    case 'capillaryBridge':{
      const y=-.23+.46*travel,regulate=second?.035*Math.sin(k):0;
      position=point(side*(.62-.085*press),second?.20-y*.68:y,depth);
      workPoint=point(lead*(.12+regulate),second?.12-y*.50:y*.72,.35);
      toolType='probe';toolPhase=wrap(cycle+(second?.24:0));break;
    }
    case 'irisPatch':{
      const row=site.seam(site.cursor).y,seat=.10*press;
      position=point(side*(.64-seat),row+(second?.06:-.035),depth);
      workPoint=point(lead*site.gap,row,.35);repairProgress=site.materialProgress;
      toolPhase=wrap(cycle+(second?.16:0));break;
    }
    case 'segmentedCradle':{
      workPoint=site.endpoints[role];
      position=point(side*(.62-.085*press),workPoint.y+(second?.065:-.035),depth);
      repairProgress=site.alignment;
      toolPhase=wrap(cycle+(second?.13:0));break;
    }
    case 'lymphaticCircuit':{
      const y=-.21+.42*(second?1-travel:travel);
      position=point(side*(.62-.08*press),y,depth);
      workPoint=point(lead*.15,y*.74+(second?.025:-.025),.35);
      toolType='probe';toolPhase=wrap(cycle+(second?.50:0));break;
    }
    case 'fibrilRepair':{
      workPoint=second?site.tensionContact:site.needleContact;
      const needle=.025*Math.sin(site.needlePhase*Math.PI*2)*press;
      position=point(side*(.59-.055*press+needle+.07*site.transitionAmount),workPoint.y+(second?.075:-.035),depth);
      contact*=1-site.transitionAmount;repositionAmount=site.transitionAmount;
      repairProgress=site.materialProgress;toolType='probe';toolPhase=site.needlePhase;break;
    }
    case 'tissueLens':{
      const focus=.075*press,p=site.trace(site.cursor),offset=normal(second?.045:0,site.tangent(site.cursor));
      workPoint=point(p.x+offset.x,p.y+offset.y,.35);
      position=point(side*(.60-focus),workPoint.y+(second?.075:-.035),depth);
      repairProgress=site.materialProgress;toolType=second?'plate':'probe';toolPhase=site.cursor;break;
    }
    case 'pulseReservoir':{
      const local=TAU*delivery.phase,beat=.5-.5*Math.cos(local);
      position=point(side*(.65-.11*beat),.15+.09*Math.sin(local),depth);
      workPoint=point(lead*.14,.07+.035*Math.sin(local),.35);
      toolPhase=wrap(cycle+(second?.50:0));contact=.25+.75*beat;break;
    }
    case 'petalSanctuary':{
      workPoint=site.filmEdge[role];
      position=point(side*(.61-.075*press),workPoint.y+(second?.045:-.045),depth);
      repairProgress=site.layProgress;
      toolPhase=wrap(cycle+(second?.18:0));break;
    }
  }
  if(delivery)toolPhase=delivery.phase;
  position.y+=lane*.16;
  return {position,workPoint,toolType,toolPhase,contact,activity:.38+.42*press,repairProgress,repositionAmount};
}

function supplementalGeometry(style,role,side,lane,cycle,site,delivery=sampleV7MedicalDeliveryPhase(style,role,site.count,site.time)){
  const k=cycle*TAU,inspect=role===3,depth=.30+lane*.10;
  const first=primaryGeometry(style,inspect?1:0,side,lane,cycle,site);
  // Additional sources hold just outside the repair team. They support the
  // same contact with small deliberate readjustments, never build a second
  // decorative machine or repeat the primary treatment at full strength.
  const sway=Math.sin(k+(inspect?.6:0)),hold=.5-.5*Math.cos(k);
  const y=(inspect?-.24:.27)+sway*.065;
  let workPoint=first.workPoint;
  if(style==='petalSanctuary')workPoint=site.corners[inspect?1:0];
  else if(style==='segmentedCradle'){
    const axis=blend(site.endpoints[0],site.endpoints[1],inspect?.70:.30);
    const d=point(site.endpoints[1].x-site.endpoints[0].x,site.endpoints[1].y-site.endpoints[0].y,0),offset=normal(inspect?.020:0,d);
    workPoint=point(axis.x+offset.x,axis.y+offset.y,.35);
  }else if(style==='tissueLens')workPoint=site.trace(inspect?.75:.25);
  else if(style==='fibrilRepair')workPoint=inspect?site.verificationContact:site.tensionContact;
  else if(style==='irisPatch')workPoint=point((inspect?1:-1)*site.gap,site.seam(inspect?.70:.30).y,.35);
  return {position:point(side*(.74-.035*hold),y,depth+.05),
    workPoint,
    toolType:inspect?'lens':'plate',toolPhase:delivery?.phase??wrap(cycle+(inspect?.35:.18)),contact:.32+.18*hold,
    activity:.38+.16*Math.sin(Math.PI*cycle)**2,repairProgress:first.repairProgress};
}

/** Source-preserving work sampler. `index` is normally the physical station.
 * Sparse/borrowed selections pass logical `roleIndex` (active-list order) and
 * stable `physicalIndex` (leftUpper/rightUpper/leftLower/rightLower = 0/1/2/3).
 * A solo bit smoothly performs both complementary jobs on its physical side;
 * it retracts its tool between contacts instead of conjuring a second source. */
export function sampleV7MedicalWork(style,index,count,time=0,options={}){
  const spec=V7_MEDICAL_WORK_SPECS[style];if(!spec)return null;
  const n=clamp(Math.round(count)||1,1,4),physical=clamp(Math.round(options.physicalIndex??index)||0,0,3);
  const active=clamp(Math.round(options.roleIndex??index)||0,0,n-1),side=physical%2?1:-1,lane=Math.floor(physical/2);
  const t=safeTime(time),cycle=wrap(t/spec.period),prepared=options.site;
  // A patient artwork update samples every source at the same work clock.
  // Reuse only that update's exact site; nothing survives the call or keys a
  // mutable emitter by identity. Other clocks/counts retain ordinary sampling.
  const site=prepared?.style===style&&prepared.count===n&&prepared.time===t?prepared:sampleV7MedicalSite(style,n,t);
  // The same charge/transfer/arrival clock drives the source, its tool and the
  // patient response. Compute it once rather than reconstructing that cue for
  // geometry, tool phase and scalar hints independently at display rate.
  const delivery=sampleV7MedicalDeliveryPhase(style,active,n,t);
  if(n===1){
    if(style==='fibrilRepair'){
      // A lone needle never leaves a stitch to form by itself. It performs
      // every writing pass; complementary tension/setup happens only between
      // those passes, while deposited material is already stationary.
      const a=primaryGeometry(style,0,side,lane,cycle,site,delivery),reposition=site.needlePhase>.70+1e-10;
      return {...a,cycle,jobIndex:reposition?1:0,roleIndex:reposition?1:0,reposition,
        repositionAmount:site.transitionAmount,activity:mix(a.activity,.20,site.transitionAmount),roleBlend:0};
    }
    const a=primaryGeometry(style,0,side,lane,cycle,site,delivery),b=primaryGeometry(style,1,side,lane,cycle,site,delivery);
    // The precision nib finishes its entire first deposited line before it
    // changes into the complementary reference/inspection tool.
    const depart=style==='tissueLens'?.48:.35,arrive=style==='tissueLens'?.60:.50,returnStart=style==='tissueLens'?.86:.85;
    const rising=cycle>=depart&&cycle<arrive,falling=cycle>=returnStart;
    const route=rising?(cycle-depart)/(arrive-depart):falling?(cycle-returnStart)/(1-returnStart):0;
    const balance=cycle<depart?0:rising?smooth(route):cycle<returnStart?1:1-smooth(route);
    const roleTransition=rising||falling?Math.sin(Math.PI*route)**2:0;
    const repositionAmount=1-(1-roleTransition)*(1-mix(a.repositionAmount??0,b.repositionAmount??0,balance));
    const position=blend(a.position,b.position,balance);
    // Retreat a few pixels while the projected tool changes purpose. It is a
    // local withdrawal on the same source side, with zero endpoint velocity.
    position.x+=side*.08*repositionAmount;
    const contact=mix(a.contact,b.contact,balance)*(1-repositionAmount);
    return {...a,position,workPoint:blend(a.workPoint,b.workPoint,balance),cycle,
      jobIndex:cycle<.5?0:1,roleIndex:cycle<.5?0:1,reposition:rising||falling||repositionAmount>.000001,repositionAmount,
      activity:mix(a.activity,.20,repositionAmount),contact,repairProgress:mix(a.repairProgress,b.repairProgress,balance),
      toolType:balance<.5?a.toolType:b.toolType,toolPhase:delivery?.phase??wrap(cycle),roleBlend:balance,
      ...deliveryHints(style,cycle<.5?0:1,n,t,repositionAmount,delivery)};
  }
  const roleIndex=active,result=roleIndex<2?primaryGeometry(style,roleIndex,side,lane,cycle,site,delivery):supplementalGeometry(style,roleIndex,side,lane,cycle,site,delivery);
  return {...result,cycle,jobIndex:roleIndex,roleIndex,reposition:(result.repositionAmount??0)>.000001,repositionAmount:result.repositionAmount??0,
    ...deliveryHints(style,roleIndex,n,t,result.repositionAmount??0,delivery)};
}
export const v7TreatmentWorkGeometry=sampleV7MedicalWork;
