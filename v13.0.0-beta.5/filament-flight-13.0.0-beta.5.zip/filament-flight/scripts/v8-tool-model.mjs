import {normalizeScanMethods} from './v84-scan-methods.mjs?v=13.0.0-beta.5';
import {normalizeScanMode} from './v88-task-lifecycle.mjs?v=13.0.0-beta.5';
/** Serializable V8 instrument jobs. Geometry uses scene pixels; displayed
 * coverage always remains feet, independent of a scene's grid distance. */
export const BIT_TOOL_MODES=Object.freeze(['areaScan','creatureScan','parkLight']);
export const BIT_TOOL_LABELS=Object.freeze({areaScan:'Area scan',creatureScan:'Creature examination',parkLight:'Parked light',dispatch:'Send instruments'});
const finite=(v,min,max)=>typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;
const object=v=>v&&typeof v==='object'&&!Array.isArray(v);
export function toolPoint(value){
  if(!object(value)||Object.keys(value).some(k=>!['x','y'].includes(k))||!finite(value.x,-1000000,1000000)||!finite(value.y,-1000000,1000000))
    throw new Error('Choose a finite scene point with x and y coordinates.');
  return {x:value.x,y:value.y};
}
export function scanRadiusPixels(count,scene={},dimensions={},radiusFeet=count*5){
  if(!Number.isInteger(count)||count<1||count>4)throw new Error('Choose one to four scanning instruments.');
  const size=scene.grid?.size??dimensions.size??100,distance=scene.grid?.distance??dimensions.distance??5;
  if(!finite(size,.01,100000)||!finite(distance,.001,100000))throw new Error('This scene needs a valid grid size and distance.');
  const units=String(scene.grid?.units??'ft').trim().toLowerCase();
  const metres=/^(m|meter|meters|metre|metres)$/.test(units);
  if(!finite(radiusFeet,.01,120))throw new Error('Scan radius must be greater than zero and no more than 120 feet.');
  const radius=radiusFeet*(metres?.3048:1)*size/distance;
  if(!finite(radius,.01,1000000))throw new Error('The scan radius is outside this scene’s supported scale.');
  return radius;
}
/** Player-owned scan regions are local geometry, never Scene Region documents.
 * Keep a canonical simple polygon so commands, previews and saved jobs agree. */
export function toolRegion(value){
  if(!object(value)||value.type!=='polygon'||Object.keys(value).some(k=>!['type','points','source'].includes(k))||!Array.isArray(value.points)||value.points.length<3||value.points.length>64||value.source!==undefined&&!['rectangle','ellipse','polygon'].includes(value.source))throw new Error('Draw a rectangle, ellipse or polygon with 3–64 corners.');
  const points=value.points.map(toolPoint);
  if(points.length>3&&points[0].x===points.at(-1).x&&points[0].y===points.at(-1).y)points.pop();
  const cross=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
  const on=(a,b,c)=>Math.abs(cross(a,b,c))<1e-7&&c.x>=Math.min(a.x,b.x)-1e-7&&c.x<=Math.max(a.x,b.x)+1e-7&&c.y>=Math.min(a.y,b.y)-1e-7&&c.y<=Math.max(a.y,b.y)+1e-7;
  for(let i=0;i<points.length;i++){
    const a=points[i],b=points[(i+1)%points.length];if(Math.hypot(b.x-a.x,b.y-a.y)<.001)throw new Error('Scan region corners must be distinct.');
    for(let j=i+1;j<points.length;j++){
      if(j===i+1||i===0&&j===points.length-1)continue;
      const c=points[j],d=points[(j+1)%points.length],a1=cross(a,b,c),a2=cross(a,b,d),b1=cross(c,d,a),b2=cross(c,d,b);
      if(a1*a2<0&&b1*b2<0||on(a,b,c)||on(a,b,d)||on(c,d,a)||on(c,d,b))throw new Error('Scan region edges cannot cross or touch themselves.');
    }
  }
  const area=Math.abs(points.reduce((sum,a,i)=>{const b=points[(i+1)%points.length];return sum+a.x*b.y-a.y*b.x;},0))/2;
  if(!(area>.01))throw new Error('Draw a scan region with a visible area.');
  return {type:'polygon',points,...(value.source?{source:value.source}:{})};
}
export function scanRegionGeometry(value,count,scene={},dimensions={}){
  const region=toolRegion(value),xs=region.points.map(p=>p.x),ys=region.points.map(p=>p.y),center={x:(Math.min(...xs)+Math.max(...xs))/2,y:(Math.min(...ys)+Math.max(...ys))/2};
  const radiusPixels=Math.max(...region.points.map(p=>Math.hypot(p.x-center.x,p.y-center.y))),pixelsPerFoot=scanRadiusPixels(count,scene,dimensions,1),radiusFeet=radiusPixels/pixelsPerFoot;
  if(!finite(radiusFeet,.01,120)||!finite(radiusPixels,.01,1000000))throw new Error('Draw a scan region with a radius no greater than 120 feet.');
  return {region,center,radiusPixels,radiusFeet};
}
export function normalizeToolLight(input={}){
  if(!object(input)||Object.keys(input).some(k=>!['bright','dim','intensity','angle','rotation','color','enabled'].includes(k)))throw new Error('Unknown parked light control.');
  const result={bright:10,dim:20,intensity:.45,angle:360,rotation:0,color:'#ff00ff',enabled:true,...input};
  for(const [key,min,max] of [['bright',0,120],['dim',0,120],['intensity',0,1],['angle',15,360],['rotation',-3600,3600]])
    if(!finite(result[key],min,max))throw new Error(`Parked light ${key} must be ${min}–${max}.`);
  if(result.dim<result.bright)throw new Error('The dim light radius must include the bright light radius.');
  if(result.color!=='#ff00ff'||typeof result.enabled!=='boolean')throw new Error('Parked lights use the instruments’ magenta core.');
  return result;
}
export function validBitUtility(value,bits=[],target=null){
  if(!object(value)||value.version!==1||!BIT_TOOL_MODES.includes(value.mode)||Object.keys(value).some(k=>!['version','mode','center','radiusFeet','radiusPixels','seed','sceneId','weighty','light','elevation','level','followSource','scanSpeed','region','scanMethods','scanMode','examinationMovement','customRadius'].includes(k)))return false;
  if(typeof value.sceneId!=='string'||value.sceneId.length<1||value.sceneId.length>64||!finite(value.seed,0,0xffffffff)||!Number.isInteger(value.seed)||typeof value.weighty!=='boolean')return false;
  if(value.elevation!==undefined&&!finite(value.elevation,-1000000,1000000)||value.level!==undefined&&value.level!==null&&(typeof value.level!=='string'||value.level.length>128))return false;
  if(value.center!==undefined){try{toolPoint(value.center);}catch{return false;}}
  if(value.followSource!==undefined&&(typeof value.followSource!=='boolean'||value.mode!=='areaScan'))return false;
  if(value.region!==undefined){
    if(value.mode!=='areaScan'||value.followSource)return false;
    try{const region=toolRegion(value.region),xs=region.points.map(p=>p.x),ys=region.points.map(p=>p.y),x=(Math.min(...xs)+Math.max(...xs))/2,y=(Math.min(...ys)+Math.max(...ys))/2;
      if(!value.center||Math.abs(value.center.x-x)>1e-5||Math.abs(value.center.y-y)>1e-5||region.points.some(p=>Math.hypot(p.x-x,p.y-y)>value.radiusPixels+1e-5))return false;
    }catch{return false;}
  }
  if(value.scanMethods!==undefined){if(value.mode==='parkLight')return false;try{normalizeScanMethods(value.scanMethods);}catch{return false;}}
  if(value.scanSpeed!==undefined&&(value.mode==='parkLight'||!finite(value.scanSpeed,.25,1.5)))return false;
  if(value.examinationMovement!==undefined&&(value.mode!=='creatureScan'||!['deliberate','classic'].includes(value.examinationMovement)))return false;
  if(value.customRadius!==undefined&&(value.customRadius!==true||value.mode!=='areaScan'||value.region||value.followSource))return false;
  if(value.scanMode!==undefined){if(value.mode!=='areaScan'||value.followSource&&value.scanMode==='once')return false;try{normalizeScanMode(value.scanMode);}catch{return false;}}
  if(value.mode==='areaScan'&&(!value.center&&!value.followSource||target!==null&&target!==undefined)||value.mode==='creatureScan'&&(!target||value.center!==undefined))return false;
  if(value.mode==='parkLight'&&(bits.length!==1||!!value.center===!!target))return false;
  if(value.mode!=='parkLight'&&((value.followSource||value.region||value.customRadius?!finite(value.radiusFeet,.01,120):value.radiusFeet!==bits.length*5)||!finite(value.radiusPixels,.01,1000000)||value.light!==undefined))return false;
  if(value.mode==='parkLight'){
    if(value.radiusFeet!==undefined||value.radiusPixels!==undefined)return false;
    try{normalizeToolLight(value.light);}catch{return false;}
  }
  return true;
}
/** Only actions whose physical/mechanical lifetime must never be rewound. */
export function instrumentActivitySignature(events=[]){
  return JSON.stringify(events.filter(e=>!['escort','utility'].includes(e.kind)).map(e=>({id:e.id,kind:e.kind,status:e.status,bits:e.bits,outcome:e.outcome??null,finishAt:e.finishAt??null,requestedOutcome:e.requestedOutcome??null})).sort((a,b)=>a.id.localeCompare(b.id)));
}
export function toolIntentFingerprint(record,events=[],flight={}){
  const groups=Object.fromEntries(Object.entries(record.groups??{}).map(([key,{transition,...group}])=>[key,group]));
  const utilities=events.filter(e=>e.kind==='utility'&&e.status!=='returning').map(e=>({id:e.id,bits:e.bits,target:e.target??null,utility:e.utility,paused:e.taskPausedAt!=null})).sort((a,b)=>a.id.localeCompare(b.id));
  const light=Object.fromEntries(['lightEnabled','lightWithBits','lightIntensity','lightBright','lightDim','lightAppearance','lightVisualReactions','lanternArtwork','lantern'].map(key=>[key,flight[key]??null]));
  return JSON.stringify({bits:record.bits,preferredCount:record.preferredCount,randomOnSummon:record.randomOnSummon,groups,utilities,light});
}
