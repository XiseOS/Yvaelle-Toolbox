/** Yvaelle’s Toolbox v11 · the nested quick wheel's art: gem frames, arc
 * dividers, label plaques and icons, all as SVG strings (24-grid icons, 1.7
 * stroke, round caps: the quick wheel's own idiom). Gradients live once in
 * DEFS. Ported from the approved lab designs (nested wheel, emotes, macros). */

const D=(x,y,r)=>`M${x} ${y-r}l${r} ${r}-${r} ${r}-${r}-${r}z`;
const C=(x,y,r)=>`M${x-r} ${y}a${r} ${r} 0 1 0 ${2*r} 0a${r} ${r} 0 1 0 ${-2*r} 0`;
export const NEW_ICONS={
  her:`${C(12,14,2.7)}M9.7 12.7C8 9.2 5.2 7.7 2.4 8.4c1.6 1 2.6 2.7 3 5.1 1.4-.2 2.8.2 4.3 1.3M14.3 12.7c1.7-3.5 4.5-5 7.3-4.3-1.6 1-2.6 2.7-3 5.1-1.4-.2-2.8.2-4.3 1.3${D(12,4.8,1.5)}${D(6.6,19.4,1.2)}${D(17.4,19.4,1.2)}`,
  wingsCat:'M11 12C8.5 7.5 5 6 2.5 7.5c2 .8 3.2 2.6 3.6 5.2 1.7-.4 3.4 0 4.9.9M13 12c2.5-4.5 6-6 8.5-4.5-2 .8-3.2 2.6-3.6 5.2-1.7-.4-3.4 0-4.9.9M12 12.5v7.5M9.5 20h5',
  // (test.16) the doors layout: Actions (a four-pointed spark) and Bits (three bits round her)
  actions:`M12 2.8l2.3 6.9 6.9 2.3-6.9 2.3L12 21.2l-2.3-6.9L2.8 12l6.9-2.3z${C(12,12,1.1)}`,
  bitsDoor:`${D(12,5.6,2.7)}${D(5.6,16.4,2.7)}${D(18.4,16.4,2.7)}${C(12,13.2,1.2)}M9.6 8.6L7.2 13M14.4 8.6l2.4 4.4M8.8 17h6.4`,
  macroCat:'M7 4h11a2 2 0 0 1 0 4H8M7 4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8M9 12h6M9 15.5h4',
  climb:'M12 19V7M7.5 11.5L12 7l4.5 4.5M7 3.5h10',
  descend:'M12 5v12M7.5 12.5L12 17l4.5-4.5M7 20.5h10',
  hLow:`M4 20.5h16M6 5v2M6 10v2M6 15v2${D(13,16.4,2.4)}`,
  hCruise:`M4 20.5h16M6 5v2M6 10v2M6 15v2${D(13,11.2,2.4)}`,
  hHigh:`M4 20.5h16M6 5v2M6 10v2M6 15v2${D(13,6,2.4)}`,
  scanAround:`${C(12,12,8.5)}${D(12,12,2.2)}M12 3.5v3M20.5 12h-3`,
  parkTarget:`M12 3v3M12 18v3M3 12h3M18 12h3${C(12,12,6)}${D(12,12,2)}`,
  more:`${D(6,12,1.9)}${D(12,12,1.9)}${D(18,12,1.9)}`,
  back:'M14.5 6.5L9 12l5.5 5.5',
  last:'M5.6 9.2A7.4 7.4 0 1 1 5 14.4M5.4 4.6v4.8h4.8',
  trash:'M5 7h14M10 7V4.5h4V7M7 7l1 13h8l1-13',
  fHalo:`${C(12,12,7)}${D(12,5,1.9)}${D(19,12,1.9)}${D(12,19,1.9)}${D(5,12,1.9)}`,
  fSentinel:`${D(5.5,5.5,2)}${D(18.5,5.5,2)}${D(5.5,18.5,2)}${D(18.5,18.5,2)}${D(12,12,1.4)}`,
  fLemniscate:`M12 12c-2.5-3.6-7.6-3.6-7.6 0s5.1 3.6 7.6 0 7.6-3.6 7.6 0-5.1 3.6-7.6 0${D(4.4,12,1.6)}${D(19.6,12,1.6)}`,
  fComet:`${D(17.2,6.8,2.6)}M14.8 9.2L4.5 19.5M13 7.6L6.5 14.1M16.4 11L10.4 17`,
  fCrown:`M4 17.5l2-9 4 4 2-6.5 2 6.5 4-4 2 9zM4.5 20.5h15`,
  fSearch:`M3 17a10 10 0 0 1 18 0${D(4.6,13.4,1.6)}${D(8.8,8.6,1.6)}${D(15.2,8.6,1.6)}${D(19.4,13.4,1.6)}`,
  pGuard:'M12 6v13M12 9C9 9 6 11 5 16c2-1 4.2-1 7 .4M12 9c3 0 6 2 7 7-2-1-4.2-1-7 .4',
  pRaised:'M12 9v11M12 11C10 6.5 7 3.5 3.6 3.4c0 4 2.4 7.4 8.4 9.4M12 11c2-4.5 5-7.5 8.4-7.6 0 4-2.4 7.4-8.4 9.4',
  pCocoon:'M12 3.5c-4.6 2-6.8 5.6-6.8 9.2 0 4.2 3 7.6 6.8 7.6s6.8-3.4 6.8-7.6c0-3.6-2.2-7.2-6.8-9.2M12 3.5v16.8M9 9c1 1.6 1.2 4 0 6.4M15 9c-1 1.6-1.2 4 0 6.4',
  pCrossed:'M5 5.5l14 12.5M19 5.5L5 18M12 12v8.5',
  rPulse:`${D(12,12,2.2)}M7.4 7.6a6.4 6.4 0 0 0 0 8.8M16.6 7.6a6.4 6.4 0 0 1 0 8.8M4.4 5a10 10 0 0 0 0 14M19.6 5a10 10 0 0 1 0 14`,
  rStutter:'M2.5 12h4l2-5 3 10 2-7 2 4h6',
  rReform:'M12 4a8 8 0 0 1 8 8M12 20a8 8 0 0 1-8-8M17.2 9.2l2.8 2.8 2.8-2.8M6.8 14.8L4 12l-2.8 2.8',
  gLunar:'M5 15c1.5-5 5-8 10-8M5 15c2.8-.8 5-.4 7 1.2M15 7c-.6 2.4.2 4.6 2.6 6.2M17 4.2l.6 1.6M20 7.4l-1.6.4',
  medkit:'M4 8h16v11H4zM9 8V5h6v3M12 11v5M9.5 13.5h5',
  hud:'M4 5h16v14H4zM4 9h16M9 9v10',
  fade:'M12 3.5a8.5 8.5 0 1 0 0 17M12 3.5c4.7 0 8.5 3.8 8.5 8.5s-3.8 8.5-8.5 8.5M15 6.2v.1M17.6 9v.1M18.4 12.5v.1M17.2 15.8v.1M14.8 18.3v.1',
  // (12.0.0-beta.6) the Decoy: her and her copy · its two looks (half solid, half lines)
  decoy:'M8.5 4.5a3 3 0 1 0 0 6 3 3 0 0 0 0-6M3 19.5c.5-3.6 2.7-5.5 5.5-5.5s5 1.9 5.5 5.5M16.5 7v.1M18.4 8.4v.1M18.4 10.6v.1M16.5 12v.1M15 15.3v.1M17.6 15.6v.1M19.6 17.2v.1M20.6 19.5v.1',
  decoyLook:'M12 3.5v17M12 3.5a8.5 8.5 0 0 0 0 17M14.5 4.4v.1M17.4 6v.1M19.4 8.6v.1M20.3 12v.1M19.4 15.4v.1M17.4 18v.1M14.5 19.6v.1M9 8.5a3.5 3.5 0 0 0 0 7'
};
export const DEFS=`<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
  <linearGradient id="ffn-cat" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4a2240"/><stop offset=".5" stop-color="#1c0d17"/><stop offset="1" stop-color="#341429"/></linearGradient>
  <linearGradient id="ffn-leaf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3d1a33"/><stop offset=".55" stop-color="#1b0d17"/><stop offset="1" stop-color="#2e1426"/></linearGradient>
  <linearGradient id="ffn-hot" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff3df0"/><stop offset=".45" stop-color="#8a0f7c"/><stop offset="1" stop-color="#3a0a33"/></linearGradient>
  <radialGradient id="ffn-bit" cx=".5" cy=".42" r=".6"><stop offset="0" stop-color="#7d2a6e"/><stop offset=".55" stop-color="#2c0f26"/><stop offset="1" stop-color="#150810"/></radialGradient>
  <linearGradient id="ffn-sheen" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/></linearGradient>
</defs></svg>`;
/** Category gem: a larger diamond, double gold frame, four small compass tips. */
export const FRAME_CAT=`<svg class="fr" viewBox="-34 -34 68 68" aria-hidden="true">
  <path class="tips" d="M0-33.5l2.2 6.4L0-25l-2.2-2.1zM33.5 0l-6.4 2.2L25 0l2.1-2.2zM0 33.5l-2.2-6.4L0 25l2.2 2.1zM-33.5 0l6.4-2.2L-25 0l-2.1 2.2z"/>
  <path class="body" d="M0-23L23 0 0 23-23 0z"/><path class="sheen" d="M0-19.5L19.5 0 0 19.5-19.5 0z"/>
  <path class="rim" d="M0-23L23 0 0 23-23 0z"/><path class="rim2" d="M0-18.6L18.6 0 0 18.6-18.6 0z"/></svg>`;
/** Shortcut: one of her bits — a tall rhombus with a magenta core and two small filament wings. */
export const FRAME_SHORT=`<svg class="fr" viewBox="-26 -26 52 52" aria-hidden="true">
  <path class="orn" d="M-12.5 1C-15.5-2.6-19.6-3-22.4-.2c2.2.1 3.7 1 4.6 2.8M12.5 1c3-3.6 7.1-4 9.9-1.2-2.2.1-3.7 1-4.6 2.8"/>
  <path class="orn cap" d="M0-23.6l1.4 1.6L0-20.4-1.4-22zM0 23.6l1.4-1.6L0 20.4-1.4 22z"/>
  <path class="body" d="M0-19L12.6 0 0 19-12.6 0z"/><path class="core" d="M0-14L8.4 0 0 14-8.4 0z"/>
  <path class="rim" d="M0-19L12.6 0 0 19-12.6 0z"/></svg>`;
/** Option gem (sub rings): a diamond whose rim carries the arc's tint. */
export const FRAME_LEAF=`<svg class="fr" viewBox="-28 -28 56 56" aria-hidden="true">
  <path class="body" d="M0-19.5L19.5 0 0 19.5-19.5 0z"/><path class="sheen" d="M0-16L16 0 0 16-16 0z"/>
  <path class="rim" d="M0-19.5L19.5 0 0 19.5-19.5 0z"/><path class="rim2" d="M0-16.2L16.2 0 0 16.2-16.2 0z"/></svg>`;
export const FRAME_MORE=`<svg class="fr" viewBox="-28 -28 56 56" aria-hidden="true">
  <path class="body" d="M0-15L15 0 0 15-15 0z"/><path class="rim dash" d="M0-15L15 0 0 15-15 0z"/></svg>`;
export const FRAME_SOCKET=`<svg class="fr" viewBox="-26 -26 52 52" aria-hidden="true"><path class="sbody" d="M0-17L11.4 0 0 17-11.4 0z"/><path class="rim dash" d="M0-17L11.4 0 0 17-11.4 0z"/></svg>`;
/** Last used: a small gem on her lower rim with a returning filament curl. */
export const FRAME_LAST=`<svg class="fr" viewBox="-22 -22 44 44" aria-hidden="true">
  <path class="curl" d="M-14.6 3.4A15 15 0 1 1 -6 13.8M-14.8-2.2l.2 5.8 5.6-.6"/>
  <path class="body" d="M0-11.5L11.5 0 0 11.5-11.5 0z"/><path class="rim" d="M0-11.5L11.5 0 0 11.5-11.5 0z"/></svg>`;
/** Arc divider: a gold knot with two filament curls, laid along the ring. */
export const DIVIDER=`<path class="dv-curl" d="M-15 0c3.4-4.6 6.8-4.6 9.4-1.4M15 0c-3.4 4.6-6.8 4.6-9.4 1.4"/><path class="dv-knot" d="M0-4.2L4.2 0 0 4.2-4.2 0z"/>`;
/** Label plaque for an arc: an elongated hexagon. */
export const plaquePath=w=>`M${-w/2} 0L${-w/2+7}-9.5H${w/2-7}L${w/2} 0 ${w/2-7} 9.5H${-w/2+7}z`;

/** Emote icons: her (a small disc) and her wings in the emote's key pose. */
const DISC=(x,y,r=2.4)=>`M${x} ${y-r}a${r} ${r} 0 1 0 0 ${2*r}a${r} ${r} 0 1 0 0 ${-2*r}`;
export const EMOTE_ICONS={
  emotes:`${DISC(12,12.5,2.6)}M9.6 11.6C7.5 8.4 4.2 7.6 2.6 9.6c2.2.2 3.8 1.4 6.6 4.3M14.4 11.6c2.1-3.2 5.4-4 7-2-2.2.2-3.8 1.4-6.6 4.3M10.8 3.6l1.2-1.6 1.2 1.6-1.2 1.6z`,
  bow:`${DISC(12,7.2)}M9.8 8.4C6.4 10 4.8 13.6 6.2 18.4c1.2-1.8 3.3-2.6 5.8-2.4M14.2 8.4c3.4 1.6 5 5.2 3.6 10-1.2-1.8-3.3-2.6-5.8-2.4M12 16v4.6`,
  laugh:`${DISC(12,13)}M9.6 12.2C7.6 9.6 4.6 9 3.2 10.8M14.4 12.2c2-2.6 5-3.2 6.4-1.4M4.2 6.4l1 1.6M7.6 4.2l.4 1.8M19.8 6.4l-1 1.6M16.4 4.2l-.4 1.8`,
  sigh:`${DISC(12,8.4)}M9.8 9.8C7.4 11.8 5.6 15.4 5.6 20.4M14.2 9.8c2.4 2 4.2 5.6 4.2 10.6M15.6 3.4c1.4-.6 2.6.6 4 0`,
  shrug:`${DISC(12,13.4)}M9.8 12.2C8.8 8.8 6.2 7.4 3.2 8.2c1.4 1 2.4 2.4 3 4.6M14.2 12.2c1-3.4 3.6-4.8 6.6-4M20.8 8.2c-1.4 1-2.4 2.4-3 4.6M5.6 4.4l1.4-1.4 1.4 1.4M15.6 4.4l1.4-1.4 1.4 1.4`,
  wave:`${DISC(11,14)}M8.6 13.6C6.6 12 4 12.2 2.8 14.6M13.2 12.8c.8-3.8 2.8-6.6 6-8.2-.2 3.4-1.6 6.4-4.6 8.8M20.4 9c1 1.2 1.4 2.4 1.2 3.8M21.2 5.2c.9.2 1.6.8 2 1.6`,
  cheer:`${DISC(12,15)}M9.8 13.8C6.6 12.6 4 9.6 3.6 4.6c2.6 1.6 4.8 4 6.4 7.6M14.2 13.8c3.2-1.2 5.8-4.2 6.2-9.2-2.6 1.6-4.8 4-6.4 7.6M12 2.4v3.2M10.4 4h3.2`,
  startle:`${DISC(12,12.5)}M10.4 11c-.9-2.2-.8-4.6.4-6.8M13.6 11c.9-2.2.8-4.6-.4-6.8M3.6 8.6l2.4 1M3.6 13h2.6M20.4 8.6l-2.4 1M20.4 13h-2.6M4.6 17.4l2.2-1.2M19.4 17.4l-2.2-1.2`,
  comfort:`${DISC(7.4,12.4)}${DISC(16.6,13.2,2.8)}M9.2 10.8c2-4.4 8.2-5.6 11.4-2 2.8 3.2 1.4 8.6-2.8 9.8M9.4 14.2c1.6 3 4.4 4.6 7.2 4.4`,
  curious:`M9.6 10.2a2.4 2.4 0 1 0 2.8 3.9 2.4 2.4 0 1 0-2.8-3.9M9.2 13.8C6.8 12.4 4 13 2.8 15.2M12.6 10.2c1.4-3.4 4.4-5 7.4-4.4M17 13.2c0-1.6 3-1.8 3.4.2.2 1.4-1.6 1.6-1.6 3M18.8 19.4v.1`,
  pray:`${DISC(12,16.6)}M10.4 15C8.4 11.6 8.8 6.4 12 2.6M13.6 15c2-3.4 1.6-8.6-1.6-12.4M6.2 6.6l1.4 1M17.8 6.6l-1.4 1M5 11.6h1.8M19 11.6h-1.8`,
  back:'M14.5 6.5L9 12l5.5 5.5',
};
/** Macro ring icons. */
export const MACRO_ICONS={
  macros:'M12 2.2l1.8 1.8-1.8 1.8-1.8-1.8zM18.93 14.2l1.8 1.8-1.8 1.8-1.8-1.8zM5.07 14.2l1.8 1.8-1.8 1.8-1.8-1.8zM14.74 4.48A8 8 0 0 1 19.88 13.39M17.14 18.13A8 8 0 0 1 6.86 18.13M4.12 13.39A8 8 0 0 1 9.26 4.48M10.4 9.3v5.4l4.3-2.7z',
  missing:'M12 4l8 8-8 8-8-8zM10 10a2 2 0 1 1 2.6 1.9c-.4.2-.6.5-.6 1v.6M12 15.6v.1',
  lock:'M7 11h10v8H7zM9 11V8a3 3 0 0 1 6 0v3',
  back:'M14.5 6.5L9 12l5.5 5.5',
  add:'M12 6v12M6 12h12',
};

/* ------------------------------------------------------------------ */
/* (test.19) The Hardlight look: gems as panes of light in their door's */
/* colour, and four rings to go with them. The classic frames and braid  */
/* stay as options (Settings › Emotes & wheel › Nested wheel › Parts).   */
/* ------------------------------------------------------------------ */
export const WHEEL_LOOKS=Object.freeze(['hardlight','classic']);
export const WHEEL_RINGS=Object.freeze(['halo','twin','panes','woven','classic']);
export const lookOf=v=>WHEEL_LOOKS.includes(v)?v:'hardlight';
export const ringOf=v=>WHEEL_RINGS.includes(v)?v:'halo';
const HL={cat:[34,23],short:[26,17],leaf:[28,19.5],lane:[28,15],more:[28,15]};
const dia=r=>`M0-${r}L${r} 0 0 ${r}-${r} 0z`;
/** A Hardlight gem frame for a kind of gem (same boxes as the classic frames), or null when the kind keeps its classic frame. */
export function hardlightFrame(kind){
  const g=HL[kind];if(!g)return null;const [vb,r]=g;let ticks='';
  for(const a of [0,90,180,270])ticks+=`<path class="ht" transform="rotate(${a})" d="M0-${r+2.5}v-4.2"/>`;
  return `<svg class="fr hl" viewBox="-${vb} -${vb} ${vb*2} ${vb*2}" aria-hidden="true"><path class="hb" d="${dia(r)}"/><path class="hi" d="${dia(r-4.5)}"/><path class="hr" d="${dia(r)}"/><path class="hh" d="M-${r-5} -1.5L-1.5 -${r-5}"/>${ticks}</svg>`;
}
const pt=(deg,R)=>[Math.sin(deg*Math.PI/180)*R,-Math.cos(deg*Math.PI/180)*R];
const f1=n=>n.toFixed(1);
const halfC=(R,side)=>`M0 ${-R}A${R} ${R} 0 0 ${side>0?1:0} 0 ${R}`;
const fullC=R=>`M0 ${-R}A${R} ${R} 0 1 1 0 ${R}A${R} ${R} 0 1 1 0 ${-R}`;
const arcC=(R,a0,a1)=>{const [x0,y0]=pt(a0,R),[x1,y1]=pt(a1,R);return `M${f1(x0)} ${f1(y0)}A${R} ${R} 0 0 1 ${f1(x1)} ${f1(y1)}`;};
const braidC=(R,amp,n,ph)=>{let d='';for(let i=0;i<360;i+=2){const t=i*Math.PI/180,r=R+amp*Math.sin(n*t+ph);d+=(i?'L':'M')+f1(Math.sin(t)*r)+' '+f1(-Math.cos(t)*r);}return d+'Z';};
const node=(x,y,r,cls,extra='')=>`<path class="${cls}" ${extra} d="M${f1(x)} ${f1(y-r)}L${f1(x+r)} ${f1(y)} ${f1(x)} ${f1(y+r)} ${f1(x-r)} ${f1(y)}z"/>`;
/** The main ring's markup for a ring style at radius R (inside <g class="L-main">), or null for the classic braid.
 * Every path carries pathLength, so the CSS needs no measurements and each loop closes without a seam. */
export function ringMarkup(style,R){
  let h='';
  if(style==='halo'){
    h=`<circle class="rg-band" r="${R}"/>`;for(const s of [1,-1])h+=`<path class="rg-core rg-draw" pathLength="100" d="${halfC(R,s)}"/>`;
    h+='<g class="rg-orbw"><g class="rg-orb">';for(let i=0;i<4;i++)h+=`<g transform="rotate(${i*90+15})">${node(0,-R,3.4,'rg-bit')}<path class="rg-tail" d="${arcC(R,-13,-2)}"/></g>`;
    return h+'</g></g>';}
  if(style==='twin'){
    for(const s of [1,-1])h+=`<path class="rg-line rg-draw" pathLength="100" d="${halfC(R+3.2,s)}"/><path class="rg-line in rg-draw" pathLength="100" d="${halfC(R-3.2,s)}"/>`;
    h+=`<path class="rg-pulse" pathLength="1000" d="${fullC(R+3.2)}"/><path class="rg-pulse in" pathLength="1000" d="${fullC(R-3.2)}"/>`;
    for(let i=0;i<12;i++){const [x,y]=pt(i*30,R);h+=node(x,y,2.3,'rg-node',`style="animation-delay:${(.25+Math.min(i,12-i)*.06).toFixed(2)}s"`);}
    return h;}
  if(style==='panes'){
    for(let i=0;i<12;i++){const a0=i*30+5,a1=i*30+25,dl=`style="animation-delay:${(.1+i*.045).toFixed(3)}s,${(1+i*.3).toFixed(2)}s"`;
      h+=`<path class="rg-pane" ${dl} d="${arcC(R,a0,a1)}"/><path class="rg-edge" ${dl} d="${arcC(R+4.6,a0,a1)}"/><path class="rg-edge in" ${dl} d="${arcC(R-4.6,a0,a1)}"/>`;}
    return h;}
  if(style==='woven')return `<path class="rg-th a" pathLength="920" d="${braidC(R,4,12,0)}"/><path class="rg-th b" pathLength="920" d="${braidC(R,4,12,Math.PI)}"/><path class="rg-th c" pathLength="900" d="${braidC(R,6.5,18,1.1)}"/>`;
  return null;
}
export const HARDLIGHT_CSS=`
/* (test.19) Hardlight gems */
.ffn.look-hl .ffn-b{--jt:var(--tint,#ff7ae6)}
.ffn-b .hb{fill:color-mix(in srgb,var(--jt) 16%,rgba(20,8,18,.72));transition:fill .15s}
.ffn-b .hr{fill:none;stroke:var(--jt);stroke-width:1.7;filter:drop-shadow(0 0 4px var(--jt));transition:stroke .15s}
.ffn-b .hh{fill:none;stroke:rgba(255,255,255,.6);stroke-width:1;stroke-linecap:round}
.ffn-b .hi{fill:none;stroke:color-mix(in srgb,var(--jt) 55%,transparent);stroke-width:.7}
.ffn-b .ht{fill:none;stroke:#e2c38c;stroke-width:1.1;stroke-linecap:round}
.ffn.look-hl .ffn-b .ico{color:#fff3fd}
.ffn.look-hl .ffn-b.k-more .ico{color:var(--jt)}
.ffn.look-hl .ffn-b.k-socket .ico{color:rgba(255,150,240,.9)}
.ffn-b.k-more .hr{stroke-dasharray:3 2.4;stroke-width:1.2}.ffn-b.k-more .hh,.ffn-b.k-more .hi,.ffn-b.k-lane .hi{display:none}
.ffn-b.k-lane .hr{stroke-dasharray:2.4 1.6;stroke-width:1.4}
.ffn-b.picked .hb{fill:rgba(255,60,240,.38)}
.ffn-b.picked .hr{stroke:#ffd2ff;stroke-width:2.2;filter:drop-shadow(0 0 8px #ff3df0)}
.ffn.look-hl .ffn-b.picked .fr{filter:drop-shadow(0 0 12px rgba(255,0,255,.7))}
.ffn.look-hl .ffn-b.off .fr{filter:saturate(.2) brightness(.62)}
.ffn.look-hl .ffn-b.off .ico{color:#8d7c74}
.ffn-b.off.picked .hb{fill:color-mix(in srgb,var(--jt) 16%,rgba(20,8,18,.72))}.ffn-b.off.picked .hr{stroke:#8d7c74;filter:none}
.ffn.look-hl .ffn-b .lab{color:#f6e3f3;text-shadow:0 1px 2px #000,0 0 6px rgba(231,103,206,.55)}
.ffn.look-hl .ffn-b.picked .lab{color:#fff}.ffn.look-hl .ffn-b.off .lab{color:#8d7c74}
/* (test.19) the four Hardlight rings */
.ffn .rg-x{opacity:0;transition:opacity .3s}.ffn.open .rg-x{opacity:1}
.ffn.rg .knots{display:none}
.ffn .rg-x path,.ffn .rg-x circle{fill:none}
.ffn .rg-draw{stroke-dasharray:100;stroke-dashoffset:100}
.ffn.open .rg-draw{animation:ffn-rg-draw .65s cubic-bezier(.3,.7,.2,1) .05s forwards}
@keyframes ffn-rg-draw{to{stroke-dashoffset:0}}@keyframes ffn-rg-in{to{opacity:1}}
/* halo and bits */
.ffn .rg-band{stroke:rgba(255,60,235,.11);stroke-width:13;opacity:0}.ffn.open .rg-band{animation:ffn-rg-in .8s .2s forwards}
.ffn .rg-core{stroke:#ff8fe8;stroke-width:1.5;filter:drop-shadow(0 0 4px rgba(255,60,235,.95))}
.ffn .rg-orbw{opacity:0}.ffn.open .rg-orbw{animation:ffn-rg-in .5s .6s forwards}
.ffn .rg-orb{transform-origin:0 0;animation:ffn-rg-spin 16s linear infinite}
@keyframes ffn-rg-spin{to{rotate:360deg}}
.ffn .rg-x .rg-bit{fill:#ffe1ff;filter:drop-shadow(0 0 5px #ff3df0)}
.ffn .rg-tail{stroke:#ff9be9;stroke-width:1.8;stroke-linecap:round;filter:drop-shadow(0 0 3px #ff3df0);opacity:.85}
/* twin filament */
.ffn .rg-line{stroke:#ff6ae8;stroke-width:1.3;filter:drop-shadow(0 0 3px rgba(255,60,235,.9))}
.ffn .rg-line.in{stroke:#c98bff;stroke-width:1}.ffn.open .rg-line.in{animation-delay:.16s}
.ffn .rg-pulse{stroke:#ffe1ff;stroke-width:2.4;stroke-linecap:round;filter:drop-shadow(0 0 6px #ff3df0);stroke-dasharray:60 940;opacity:0}
.ffn .rg-pulse.in{stroke-width:1.8;stroke-dasharray:40 960}
.ffn.open .rg-pulse{animation:ffn-rg-run 5.2s linear .7s infinite,ffn-rg-in .5s .7s forwards}
.ffn.open .rg-pulse.in{animation:ffn-rg-run 7.4s linear .9s infinite reverse,ffn-rg-in .5s .9s forwards}
@keyframes ffn-rg-run{to{stroke-dashoffset:-1000}}
.ffn .rg-x .rg-node{fill:#ff8fe8;filter:drop-shadow(0 0 3px #ff3df0);opacity:0}.ffn.open .rg-node{animation:ffn-rg-in .3s forwards}
/* panes */
.ffn .rg-pane{stroke:rgba(255,80,235,.3);stroke-width:8;opacity:0}
.ffn .rg-edge{stroke:#ff7aea;stroke-opacity:.8;stroke-width:1.3;stroke-linecap:round;filter:drop-shadow(0 0 3px rgba(255,60,235,.95));opacity:0}
.ffn .rg-edge.in{stroke:#c98bff;stroke-width:.9}
.ffn.open .rg-pane{animation:ffn-rg-pin .35s cubic-bezier(.3,.8,.3,1) forwards,ffn-rg-shim 3.6s ease-in-out infinite}
.ffn.open .rg-edge{animation:ffn-rg-pin .35s cubic-bezier(.3,.8,.3,1) forwards,ffn-rg-shim2 3.6s ease-in-out infinite}
@keyframes ffn-rg-pin{from{opacity:0;scale:.92}to{opacity:1;scale:1}}
@keyframes ffn-rg-shim{0%,70%,100%{stroke:rgba(255,80,235,.3)}82%{stroke:rgba(255,170,245,.75)}}
@keyframes ffn-rg-shim2{0%,70%,100%{stroke-opacity:.8}82%{stroke-opacity:1}}
/* woven light */
.ffn .rg-th{stroke-width:1.5;stroke-linecap:round;stroke-dasharray:16 7;opacity:0}
.ffn .rg-th.a{stroke:#ff6ae8;filter:drop-shadow(0 0 3px rgba(255,60,235,.95))}
.ffn .rg-th.b{stroke:#c98bff;filter:drop-shadow(0 0 3px rgba(170,110,255,.9))}
.ffn .rg-th.c{stroke:#ffb3ee;stroke-width:1;stroke-dasharray:6 12;filter:drop-shadow(0 0 2px rgba(255,120,235,.9))}
.ffn.open .rg-th.a{animation:ffn-rg-in .6s .1s forwards,ffn-rg-flow 2.4s linear infinite}
.ffn.open .rg-th.b{animation:ffn-rg-in .6s .22s forwards,ffn-rg-flow 3.1s linear infinite reverse}
.ffn.open .rg-th.c{animation:ffn-rg-in .6s .34s forwards,ffn-rg-flow2 1.8s linear infinite}
@keyframes ffn-rg-flow{to{stroke-dashoffset:-46}}@keyframes ffn-rg-flow2{to{stroke-dashoffset:-36}}
/* reduced motion and the close: everything simply there, nothing moving */
.ffn.reduced .rg-x *{opacity:1;stroke-dashoffset:0}.ffn.reduced .rg-pulse{opacity:0}
.ffn.sub .rg-x .rg-orb,.ffn.sub .rg-x .rg-pulse,.ffn.sub .rg-x .rg-th,.ffn.sub .rg-x .rg-pane,.ffn.sub .rg-x .rg-edge{animation-play-state:paused}
`;
