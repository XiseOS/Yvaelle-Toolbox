/** Beta.32: the most wing pictures a second worth painting and uploading.
 * The wings still move every display frame; only the painted picture is held.
 * On a 60 Hz canvas nothing changes. On a faster one (an 82 fps or 164 Hz
 * canvas) each picture is held for a whole, even number of frames, so the
 * texture rate stays near 60 or below instead of following the display. */
export const MAX_REPAINT_HZ=60;
/** Display frames each painted picture is held for: 1 at the display rate,
 * otherwise an even whole number (30 fps on 60 Hz = every second frame).
 * A canvas up to about 78 fps keeps one picture a frame (the 0.3 slack), so a
 * 75 Hz screen is not halved; faster canvases hold 2 frames (about 78 to
 * 138 fps: 60 at 120 Hz), 3 (144 and 164 Hz: 48 and 55) and so on. */
export function displayHold(fps,frameMs){
  const frame=frameMs>0?frameMs:1000/60;
  const wanted=Math.max(1,Math.floor(1000/Math.max(1,fps)/frame+.25));
  const cap=Math.max(1,Math.ceil(1000/frame/MAX_REPAINT_HZ-.3));
  return Math.max(wanted,cap);
}
/** The same cap for surfaces repainted on a clock rather than on counted
 * frames (the wing shield): a picture at most every 12.5 ms, so a 60 or 75 Hz
 * screen keeps one a frame and faster ones settle at 41 to 72 a second. */
export const MIN_REPAINT_MS=1000/MAX_REPAINT_HZ*.75;
