import {V7_MEDICAL_WORK_SPECS as V7_MEDKIT_TECHNIQUES,v7TreatmentWorkGeometry,sampleV7MedicalSite,sampleV7FinishingSite,v7MedicalCompletionProgress} from './v7-medical-work.mjs?v=13.0.0-beta.5';
import {transitionTreatmentCore} from './treatment-core-motion.mjs?v=13.0.0-beta.5';
import {sampleMedicalOutcomeMotion} from './treatment-outcomes.mjs?v=13.0.0-beta.5';
/** Shared deterministic operation clock for real treatment instruments, energy
 * contacts, core states and authored sound accents. Distances are patient-token
 * diameters. No Foundry state, timers, random histories or document writes. */
const TAU=Math.PI*2,clamp=n=>Math.max(0,Math.min(1,n)),smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const mix=(a,b,p)=>a+(b-a)*p,wrap=n=>(n%1+1)%1;
const definition=(period,roles)=>Object.freeze({period,roles:Object.freeze(roles),cues:Object.freeze([.18,.50,.78])});
export const TREATMENT_OPERATIONS=Object.freeze({
  suture:definition(4.9,['Draw stitch','Hold margin','Tension thread','Inspect seam']),
  lattice:definition(3.6,['Place ribs','Join braces','Hold alignment','Inspect structure']),
  compression:definition(4.6,['Seat pressure jaw','Counter pressure','Check seal','Regulate pressure']),
  precision:definition(5.4,['Probe working point','Hold with forceps','Measure contact','Inspect work']),
  microloom:definition(5.8,['Pass shuttle','Tension warp','Bind edge','Inspect weave']),
  vascular:definition(4.2,['Trace channel','Drive infusion','Regulate junction','Check terminal']),
  helix:definition(5.6,['Guide upper collar','Guide lower collar','Support traction','Check axis']),
  splint:definition(4.8,['Place support','Align joint','Lock brace','Check alignment']),
  membrane:definition(5.2,['Lay membrane','Seal panels','Support enclosure','Inspect seam']),
  resonance:definition(3.6,['Measure vibration','Counter vibration','Hold reference','Check alignment']),
  pulseHalo:definition(5.4,['Gather wave','Guide healing wave','Support basin','Check response']),
  mendingVeil:definition(5.8,['Weave surface','Join surface','Reinforce edge','Inspect closure']),
  renewalSpiral:definition(6.2,['Raise energy channel','Guide inward flow','Support channel','Check renewal']),
  heartline:definition(5,['Read diagnostic','Deliver pulse','Regulate output','Verify response']),
  threadbind:definition(5.6,['Carry thread','Draw lacing','Hold anchor','Check tension']),
  crystalCast:definition(5.2,['Set plates','Hold the cast','Bond edges','Check the cast']),
  wingSuture:definition(5.8,['Draw filament','Guide needle','Hold margin','Check seam']),
  ...Object.fromEntries(Object.entries(V7_MEDKIT_TECHNIQUES).map(([id,spec])=>[id,definition(spec.period,spec.roles)]))
});
const point=(x,y,z=.25)=>({x,y,z});
const rotate=(x,y,a,z=.25)=>point(x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a),z);
const blend=(a,b,q)=>point(mix(a.x,b.x,q),mix(a.y,b.y,q),mix(a.z,b.z,q));
const SINGLE_REPOSITION=new Set(['suture','splint','precision','vascular','lattice','resonance','mendingVeil','heartline','microloom','threadbind','crystalCast','wingSuture']);
const LOCAL_DELIVERY_CORE=new Set(['capillaryBridge','lymphaticCircuit','pulseReservoir']);
const entranceTangents=new Map();
function entranceTangent(style,index,count,roleIndex=index){
  const key=`${style}:${index}:${count}:${roleIndex}`;let result=entranceTangents.get(key);if(result)return result;
  const a=workGeometry(style,index,count,0,{roleIndex}),b=workGeometry(style,index,count,.000001,{roleIndex});
  result=Object.fromEntries(['position','workPoint'].map(kind=>[kind,Object.fromEntries(['x','y','z'].map(axis=>[axis,(b[kind][axis]-a[kind][axis])*1000000]))]));
  entranceTangents.set(key,result);return result;
}
function continuousWorkCore(cycle,activity,reposition){
  const opening=smooth((cycle-.14)/.08)*(1-smooth((cycle-.94)/.06))*(1-reposition);
  // The only participating mechanisms are charging and open. Compute their
  // exact normalized blend directly instead of capturing and sampling both
  // full generic activities on every display frame.
  const charge=activity*(1-opening),open=activity*opening,amount=charge+open;
  if(!(amount>0))return null;
  const weights={};if(charge>0)weights.charging=charge/amount;if(open>0)weights.open=open/amount;
  return {state:open>charge?'open':'charging',amount:clamp(amount),progress:0,weights,
    coreChannels:{encase:0,open:open/amount,charge:charge/amount,guard:0,settle:0,scan:0,brace:0,align:0,rest:0,conduct:0}};
}
function workGeometry(style,i,n,t,options={}){
  const upgrade=v7TreatmentWorkGeometry(style,i,n,t,options);if(upgrade)return upgrade;
  const spec=TREATMENT_OPERATIONS[style],cycle=wrap(t/spec.period),k=TAU*cycle;
  // A lone instrument alternates both complementary jobs instead of leaving
  // one side of the procedure unpowered. Transit follows an outer arc; it does
  // not fly through the patient to switch stations.
  if(n===1&&SINGLE_REPOSITION.has(style)){
    const first=workGeometry(style,0,2,t),second=workGeometry(style,1,2,t);
    if(cycle<.32)return {...first,jobIndex:0};
    if(cycle<.5){const u=(cycle-.32)/.18,q=smooth(u),p=blend(first.position,second.position,q);p.y-=Math.sin(Math.PI*q)*.95;return {position:p,workPoint:blend(first.workPoint,second.workPoint,q),cycle,jobIndex:1,reposition:true};}
    if(cycle<.82)return {...second,jobIndex:1};
    const u=(cycle-.82)/.18,q=smooth(u),p=blend(second.position,first.position,q);p.y+=Math.sin(Math.PI*q)*.95;return {position:p,workPoint:blend(second.workPoint,first.workPoint,q),cycle,jobIndex:0,reposition:true};
  }
  const side=i%2?1:-1,lane=Math.floor(i/2),offset=i*TAU/n,a=k+i*TAU/n;
  const sweep=.5-.5*Math.cos(k),sweep2=.5-.5*Math.cos(k+lane*Math.PI);
  let position,workPoint;
  switch(style){
    case 'membrane':{
      // Real tools trace opposite meridians and progressively seal the canopy.
      const theta=-Math.PI*.83+offset+k,bow=Math.sin(k)*.13;
      position=point(Math.cos(theta)*(.87+lane*.06),Math.sin(theta)*.73-.03,Math.sin(theta));
      workPoint=point(Math.cos(theta)*.55,Math.sin(theta)*.61+bow,Math.sin(theta));break;
    }
    case 'splint':{
      const y=-.48+.96*(i%2?1-sweep2:sweep2),support=lane*.28;
      position=point(side*(.72+support+.09*Math.sin(k)**2),y,.3+lane*.28);
      workPoint=point(side*(.30+lane*.04),y*.82,.35);break;
    }
    case 'helix':{
      const theta=n===1?a:i%2?Math.PI+k:k;
      position=point(Math.cos(theta)*(.64+lane*.24),n===1?Math.sin(a)*.77:side*(.70+lane*.24)+Math.sin(k)*.045,Math.sin(theta));
      workPoint=point(Math.cos(theta)*.30,n===1?Math.sin(a)*.52:side*.53,Math.sin(theta));break;
    }
    case 'vascular':{
      const y=-.48+.96*(i%2?1-sweep:sweep),x=side*(.83+lane*.28-.06*Math.sin(k)**2);
      position=point(x,y,.3+lane*.28);
      workPoint=point(side*(.26+.10*Math.sin(k+i)),y*.74,.35);break;
    }
    case 'compression':{
      const angle=n===1?a-Math.PI*.75:-Math.PI*.75+offset+.26*Math.sin(k),r=.88-.11*Math.sin(k*.5)**2;
      position=point(Math.cos(angle)*r,Math.sin(angle)*r,Math.sin(angle)*.7);
      workPoint=point(Math.cos(angle)*.44,Math.sin(angle)*.44,Math.sin(angle)*.7);break;
    }
    case 'precision':{
      // Upper probe and lower forceps follow the working point, with inspection
      // instruments stationed on the alternate diagonals when available.
      const x=-.03+.05*Math.sin(k),y=-.02+.13*Math.sin(k);
      const upper=i%2===0,station=lane?-1:1;
      position=point((upper?-.69:.69)*station+.10*Math.sin(k+i),upper?-.35+.23*Math.sin(k):.29+.20*Math.cos(k),.25+lane*.15);
      workPoint=point(upper?x:x+.12,upper?y:y+.07,.3);break;
    }
    case 'suture':{
      const y=-.31+.62*(i%2?1-sweep:sweep),cross=Math.sin(k*2)*.055;
      position=rotate(side*(.64+lane*.28+cross),y,-.42,.28+lane*.28);
      workPoint=rotate(side*(.06+.012*Math.sin(k)),y,-.42,.35);break;
    }
    case 'microloom':{
      const y=-.34+.68*(i%2?1-sweep:sweep),x=n===1?-.67+.14*Math.sin(k):side*(.66+lane*.28);
      position=rotate(x,y,-.55,.3+lane*.28);
      workPoint=rotate(n===1?.26*Math.sin(k*3):i%2?.26:.26*Math.sin(k*3),y*.77,-.55,.35);break;
    }
    case 'lattice':{
      const y=-.42+.84*(i%2?1-sweep:sweep);
      position=point(side*(.76+lane*.28+.08*Math.sin(k)**2),y,.18+lane*.15);
      workPoint=point(side*(.31-Math.abs(y)*.2),y*.75,.25);break;
    }
    case 'resonance':{
      position=point(side*(.80+lane*.28+.075*Math.sin(k)),Math.sin(k+i*Math.PI)*.33,.25+lane*.15);
      workPoint=point(side*.41,Math.sin(k+i*Math.PI)*.14,.3);break;
    }
    case 'pulseHalo':{
      // Tools climb with individual wave fronts and then lower along the rim.
      const theta=Math.PI*.72+offset+k,rise=.5-.5*Math.cos(k);
      position=point(Math.cos(theta)*(.92+lane*.04),.37+Math.sin(theta)*.35-rise*.43,Math.sin(theta));
      workPoint=point(Math.cos(theta)*.48,.43-rise*.76+Math.sin(theta)*.12,Math.sin(theta));break;
    }
    case 'mendingVeil':{
      const y=-.46+.92*((i+lane)%2?1-sweep:sweep),w=.27+n*.05;
      position=point(side*(.81+lane*.28+.05*Math.sin(k*2)),y,.27+lane*.14);
      workPoint=point(side*(w-(.06+.05*Math.sin(k))*(lane?1:0)),y*.93,.3);break;
    }
    case 'renewalSpiral':{
      // Rise around the patient; return on the outer channel without a wrap jump.
      const theta=Math.PI*.75+offset+k,rise=.5-.5*Math.cos(k),r=.89+lane*.05;
      position=point(Math.cos(theta)*r,.45-rise*.96+Math.sin(theta)*.18,Math.sin(theta));
      workPoint=point(Math.cos(theta)*.47,.58-rise*1.16,Math.sin(theta));break;
    }
    case 'crystalCast':{
      // one pair above, one below; work points sweep the rows as plates set
      position=point(side*(.70+.06*Math.sin(k)),(lane?.62:-.62)+.08*Math.sin(k+i),.3+lane*.12);
      workPoint=point(side*.24*Math.sin(k*2+i),-.40+.80*(lane?1-sweep:sweep),.3);break;
    }
    case 'wingSuture':{
      // held high at the sides like wing tips, drawing filament down to the needle
      position=point(side*(.88+lane*.2),-.52+.16*Math.sin(k+i)+lane*.5,.25+lane*.12);
      workPoint=point(side*.08,-.42+.84*sweep,.3);break;
    }
    case 'threadbind':{
      // carry thread ends down opposite sides, crossing rows like a lacer
      const y=-.42+.84*((i+lane)%2?1-sweep:sweep),x=side*(.80+lane*.26+.05*Math.sin(k*2+i));
      position=point(x,y,.26+lane*.14);
      workPoint=point(side*(.36+.04*Math.sin(k*3)),y*.9,.3);break;
    }
    case 'heartline':{
      const reader=i%2===0,y=reader?-.37+.58*sweep+lane*.45:.17+.22*Math.sin(k)-lane*.45,x=side*(.86+lane*.28-.09*Math.sin(k)**2);
      position=point(x,y,.28+lane*.14);
      workPoint=point(reader?-.29+.58*sweep:.20*Math.sin(k),reader?-.05:.06,.3);break;
    }
  }
  return {position,workPoint,cycle};
}
/** Exported scan orbit meets each first job exactly, including its depth. */
export function treatmentScanOperation(style,index,count,scanProgress,options={}){
  const n=Math.max(1,Math.min(4,Math.round(count)||1)),i=Math.max(0,Math.min(options.v7&&V7_MEDKIT_TECHNIQUES[style]?3:n-1,index)),q=smooth(scanProgress);
  const end=workGeometry(style,i,n,0,{roleIndex:options.roleIndex??i,site:options.site});
  if(options.v7){
    const variant=Math.max(0,Math.min(3,Math.round(options.variant)||0)),side=end.position.x<0?-1:1,lane=Math.floor(i/2);
    const height=[-.68,-.40,-.82,-.56][variant]-(lane*.07),origin=point(side*(.90+lane*.18),height,.18+lane*.18);
    const position=blend(origin,end.position,q);
    position.y-=Math.sin(Math.PI*q)**2*[.08,.035,.12,.06][variant];
    const startWork=point(side*.28,-.40,.3),workPoint=blend(startWork,end.workPoint,q);
    if(options.reducedMotion!==true){
      // The scan's final 30% joins the first work contact's velocity. This
      // endpoint tangent is fixed per authored style/station/count, so it adds
      // no repeated look-ahead geometry to settled work frames.
      const u=clamp((scanProgress-.70)/.30),gain=u*u*(u-1)*1.6*.30,tangent=entranceTangent(style,i,n,options.roleIndex??i);
      for(const [kind,value]of [['position',position],['workPoint',workPoint]])for(const axis of ['x','y','z'])value[axis]+=tangent[kind][axis]*gain;
    }
    // Every entrance ends exactly at its first working contact and keeps the
    // physical side of that station throughout setup.
    return {position,workPoint};
  }
  const a=Math.atan2(end.position.y,end.position.x)-Math.PI*1.5*(1-q);
  const r=mix(.90+Math.floor(i/2)*.13,Math.hypot(end.position.x,end.position.y),q);
  const position=point(Math.cos(a)*r,Math.sin(a)*r,mix(Math.sin(a),end.position.z,smooth((q-.78)/.22)));
  const workPoint=blend(point(Math.cos(a)*.30,-.4+.8*q,Math.sin(a)),end.workPoint,smooth((q-.72)/.28));
  return {position,workPoint};
}
/** Pure shared sampler. One instrument performs roles in sequence, while teams
 * divide construction, support and verification without duplicating a body.
 * Outcomes freeze the exact work pose and gently disengage; success is supplied
 * by the actual result, never inferred from elapsed time. */
export function sampleTreatmentOperations(style,count,time,options={}){
  const spec=TREATMENT_OPERATIONS[style];if(!spec)return null;
  const n=Math.max(1,Math.min(4,Math.round(count)||1)),animated=options.reducedMotion!==true;
  const t=animated?Math.max(0,Number(time)||0):0,cycle=wrap(t/spec.period),phase=options.phase??'treating';
  const progress=clamp(options.progress??0),scanP=animated?clamp(options.scanProgress??0):1;
  const success=['success','criticalSuccess'].includes(options.outcome);
  const result=options.v7&&phase==='finishing'?sampleMedicalOutcomeMotion(style,options.outcome,progress,{animated}):null;
  // All real instruments work on this one patient site at this exact clock.
  // Share only within this sample: movement, sparse station roles and result
  // contacts remain live, with no cross-frame or persisted geometry cache.
  const workSite=V7_MEDKIT_TECHNIQUES[style]?sampleV7MedicalSite(style,n,t):null;
  const completedKnitSite=options.v7&&style==='fibrilRepair'&&phase==='finishing'&&animated&&success?sampleV7FinishingSite(style,n,t,progress):null;
  const operations=Array.from({length:n},(_,i)=>{
    const station=options.stations?.[i],physicalIndex=options.v7&&V7_MEDKIT_TECHNIQUES[style]&&['leftUpper','rightUpper','leftLower','rightLower'].includes(station)?['leftUpper','rightUpper','leftLower','rightLower'].indexOf(station):i;
    const medical=!!V7_MEDKIT_TECHNIQUES[style],geometry=workGeometry(style,physicalIndex,n,t,{roleIndex:i,site:workSite}),work=geometry.workPoint;
    let position=geometry.position,workPoint=work,stage=cycle<.18?'approach':cycle<.5?'work':cycle<.78?'transfer':'check',finishSite=null,finishGeometry=null;
    let activity=geometry.activity??(.38+.42*Math.sin(cycle*Math.PI)**2);
    if(geometry.reposition){stage='reposition';if(!medical)activity=.20;}
    const reposition=medical?(geometry.repositionAmount??0):options.v7&&n===1&&SINGLE_REPOSITION.has(style)?
      smooth((cycle-.30)/.04)*(1-smooth((cycle-.48)/.04))+smooth((cycle-.80)/.04)*(1-smooth((cycle-.96)/.04)):0;
    if(options.v7&&!medical)activity=mix(.38+.42*Math.sin(cycle*Math.PI)**2,.20,reposition);
    let core={state:stage==='approach'||stage==='reposition'?'charging':'open',amount:activity};
    if(options.v7)core=continuousWorkCore(LOCAL_DELIVERY_CORE.has(style)?geometry.toolPhase:cycle,activity,reposition);
    if(phase==='travel'||phase==='scanning'){
      const scan=treatmentScanOperation(style,physicalIndex,n,phase==='travel'?0:scanP,{...options,roleIndex:i,site:workSite});position=scan.position;workPoint=scan.workPoint;stage='scan';activity=.36;core={state:'charging',amount:.4};
      if(options.v7){const ending=smooth((scanP-.72)/.28);activity=mix(.36,.38,ending);core={state:'charging',amount:mix(.4,.38,ending)};}
    }else if(phase==='finishing'){
      const release=animated?smooth((progress-.42)/.58):0,dir=Math.atan2(position.y,position.x);
      const variant=Math.max(0,Math.min(3,Math.round(options.variant)||0)),distance=options.v7?[.08,.06,.11,.075][variant]:.1;
      position=point(position.x+Math.cos(dir)*distance*release,position.y+Math.sin(dir)*distance*release-(options.v7?[0,.035,.065,.02][variant]*release:0),position.z);
      if(result&&animated){
        position.x+=Math.cos(dir)*result.toolSpread*result.gain;
        position.y+=Math.sin(dir)*result.toolSpread*result.gain-.035*result.inspection*result.gain;
      }
      if(options.v7&&style==='fibrilRepair'&&animated&&success){
        finishSite=completedKnitSite;
        finishGeometry=workGeometry(style,physicalIndex,n,finishSite.virtualTime,{roleIndex:i,site:finishSite});
        if(finishSite.completion>0){
          const prior=workPoint,contact=n===1||i===0?finishSite.needleContact:i===3?finishSite.verificationContact:finishSite.tensionContact;
          workPoint=point(contact.x*finishSite.contraction,contact.y,contact.z);
          position=point(position.x+(workPoint.x-prior.x)*.15,position.y+(workPoint.y-prior.y)*.65,position.z);
        }
      }
      if(options.v7&&medical&&animated&&success&&(geometry.roleIndex??i)<2){
        // Resolve the work the actual tools were performing. Corrections wait
        // through the initial clock brake and start at zero velocity; the first
        // result sample therefore retains the exact work pose and momentum.
        const completion=v7MedicalCompletionProgress(progress);
        if(completion>0){
          const site=workSite,prior=workPoint;
          if(style==='tissueLens'){
            const cursor=mix(site.cursor,1,completion),contact=site.trace(cursor),d=site.tangent(cursor),length=Math.hypot(d.x,d.y)||1;
            const offset=(n===1?geometry.roleBlend??0:geometry.roleIndex===1?1:0)*.045;
            workPoint=point(contact.x-d.y/length*offset,contact.y+d.x/length*offset,.35);
          }else if(style==='irisPatch')workPoint=point(prior.x*(1-completion),prior.y,prior.z);
          else if(style==='segmentedCradle'){
            const goal=n===1?blend(site.alignedEndpoints[0],site.alignedEndpoints[1],geometry.roleBlend??0):site.alignedEndpoints[geometry.roleIndex];
            workPoint=blend(prior,goal,completion);
          }else if(style==='petalSanctuary')workPoint=point(prior.x,mix(prior.y,.23,completion),prior.z);
          position=point(position.x+(workPoint.x-prior.x)*.15,position.y+(workPoint.y-prior.y)*.65,position.z);
        }
      }
      stage=success?'seal':'release';const fromCore=core,fromActivity=activity;activity=clamp((success?.8:.3)*(1-progress)*(result?.coreEnergy??1));core={state:'settling',progress,amount:activity};
      if(options.v7){const join=clamp((options.finishElapsed??1)/.24);core=transitionTreatmentCore(fromCore,core,join);activity=mix(fromActivity,activity,smooth(join));}
    }
    const type=phase==='scanning'?'lens':geometry.toolType??(['suture','precision','microloom','fibrilRepair','capillaryBridge'].includes(style)?'probe':style==='tissueLens'?'lens':'plate');
    let toolAmount=phase==='travel'?0:phase==='scanning'?.47*smooth(scanP/.40):phase==='finishing'?.55*(1-smooth(progress/.75)):.47+.10*Math.sin(cycle*Math.PI)**2;
    if(finishGeometry)toolAmount=.55*(1-smooth((progress-.82)/.18))*(1-(finishGeometry.repositionAmount??0));
    if(options.v7&&animated){
      if(phase==='scanning')toolAmount*=1-smooth((scanP-.76)/.24);
      else if(phase==='treating')toolAmount*=smooth(t/.38);
      else if(result)toolAmount*=1-.55*result.interlock*result.gain;
    }
    if(medical&&phase==='treating')toolAmount*=1-reposition;
    if(options.v7&&phase==='finishing'){
      const fromWork=(.47+.10*Math.sin(cycle*Math.PI)**2)*(medical?(1-reposition)*(animated?smooth(t/.38):1):1);
      toolAmount=mix(fromWork,toolAmount,smooth((options.finishElapsed??1)/.24));
    }
    const contact=medical?(phase==='travel'||phase==='scanning'?0:geometry.contact??0):undefined;
    const displayed=finishGeometry??geometry;
    return {index:i,position,workPoint,...(options.v7?{tool:{type,amount:toolAmount,progress:phase==='scanning'?scanP:displayed.toolPhase??cycle}}:{}),role:spec.roles[n===1?(displayed.jobIndex??Math.floor(cycle*spec.roles.length)%spec.roles.length):displayed.roleIndex??i],stage,activity,core,
      ...(medical?{roleIndex:displayed.roleIndex,reposition:!!displayed.reposition,toolPhase:displayed.toolPhase,contact:finishGeometry?finishGeometry.contact:contact,repairProgress:finishSite?.materialProgress??geometry.repairProgress}: {})};
  });
  return {period:spec.period,cycle,stage:phase,animated,operations};
}
