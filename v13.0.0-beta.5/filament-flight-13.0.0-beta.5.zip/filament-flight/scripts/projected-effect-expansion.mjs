/** Eight bounded hardlight constructions powered by the participating cores.
 * All work sites are shared with core aiming and emission. No particle history,
 * raster textures, filters or document state are retained here. */
const TAU=Math.PI*2;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const frac=v=>((v%1)+1)%1;
const smooth=v=>{v=clamp(v,0,1);return v*v*(3-2*v);};
const mix=(a,b,u)=>a+(b-a)*u;
const definition=(id,label,category,description,state,jobs)=>Object.freeze({id,label,category,description,state,jobs:Object.freeze(jobs)});
export const EXPANDED_PROJECTED_EFFECT_PROGRAMS=Object.freeze([
  definition('facetWard','Facet ward','protective','Hinged hardlight facets unfold toward the shared visible target, receive a pressure glint and divert it along their folded edges.','bracing',['Fold and deflect','Leading and trailing facets','Ward with a supporting hinge','Two interlocked ward pairs']),
  definition('deflectionFins','Deflection fins','protective','Articulated fins catch a travelling contact spark, turn together and release it outward along narrow deflection vanes.','guarding',['Travelling interception fin','Alternating interception fins','Three-way interception','Four coordinated deflectors']),
  definition('contourScan','Contour scan','awareness','Narrow tracing shoes climb and descend beside the token, building a short measured contour behind each scanner.','scanning',['Alternating contour trace','Opposing contour traces','Trace, range and verify','Paired contour and verification scans']),
  definition('sectorSearch','Sector search','awareness','A narrow searching slit sweeps the shared visible target direction; precise staggered range marks answer as it passes.','scanning',['Search and range','Search and verification','Search, range and triangulate','Two coordinated search pairs']),
  definition('prismRelay','Prism relay','awareness','Compact turning prisms receive core light, route measured packets through a visible elbow and pass the signal toward the shared visible target.','conducting',['Receive, turn and send','Receiving and forwarding prisms','Receive, route and forward','Two alternating relay routes']),
  definition('signalPennants','Signal pennants','expressive','Crisp woven light pennants unfurl above the token; travelling folds and bright edge signals answer between the active bits.','charging',['Woven signal pennant','Counterfolded pennants','Three-part signal banner','Two woven pennant pairs']),
  definition('lightBridge','Light bridge','expressive','Interlocking hardlight steps grow forward in sequence, carrying a bright travelling seam from one plate to the next.','conducting',['Sequential bridge plates','Paired bridge anchors','Anchor, lay and verify','Two interlocking bridge teams']),
  definition('filamentLoom','Filament loom','expressive','Fine suspended filaments carry a distinct shuttle through a small triangular light sail; additional bits hold its lower corners and verify the woven edge.','aligning',['Shuttle and tension','Shuttle and counter-tension','Shuttle with upper and lower tension','Upper rails, lower tension and edge verification'])
]);
const BY_ID=new Map(EXPANDED_PROJECTED_EFFECT_PROGRAMS.map(p=>[p.id,p]));
export const isExpandedProjectedEffect=id=>BY_ID.has(id);
const roleLists={
  facetWard:[['Fold and deflect'],['Leading facet','Trailing facet'],['Leading facet','Trailing facet','Hinge support'],['Leading left facet','Trailing right facet','Left hinge support','Right hinge support']],
  deflectionFins:[['Sweep interception'],['Left interception','Right deflection'],['Leading interception','Left deflection','Right deflection'],['Upper interception','Upper deflection','Lower interception','Lower deflection']],
  contourScan:[['Trace and verify'],['Left tracing shoe','Right tracing shoe'],['Left tracing shoe','Right tracing shoe','Range verification'],['Left tracing shoe','Right tracing shoe','Left verification','Right verification']],
  sectorSearch:[['Search and range'],['Searching slit','Range verification'],['Searching slit','Range verification','Triangulation'],['Left searching slit','Right searching slit','Left range verifier','Right range verifier']],
  prismRelay:[['Receive, route and forward'],['Receiving prism','Forwarding prism'],['Receiving prism','Turning prism','Forwarding prism'],['Left receiving prism','Right receiving prism','Left forwarding prism','Right forwarding prism']],
  signalPennants:[['Weave and signal'],['Left signal weaver','Right signal weaver'],['Signal weaver','Counterfold weaver','Edge verification'],['Left signal weaver','Right signal weaver','Left edge tension','Right edge tension']],
  lightBridge:[['Lay and verify steps'],['Left bridge anchor','Right bridge anchor'],['Bridge anchor','Step laying','Seam verification'],['Left bridge anchor','Right bridge anchor','Left step laying','Right step laying']],
  filamentLoom:[['Shuttle and tension'],['Travelling shuttle','Counter-tension'],['Travelling shuttle','Upper tension','Lower corner tension'],['Left upper rail','Right upper rail','Lower corner tension','Woven edge verification']]
};
const local=(p,c,a)=>[c[0]+p[0]*Math.cos(a)-p[1]*Math.sin(a),c[1]+p[0]*Math.sin(a)+p[1]*Math.cos(a)];
const basis=options=>{
  const raw=options.focus??options.motion??{},x=Number.isFinite(raw.x)?raw.x:0,y=Number.isFinite(raw.y)?raw.y:0,length=Math.hypot(x,y);
  return length>.0001?[x/length,y/length]:[0,-1];
};
/** The focus input already excludes hidden/deleted targets. The fallback is a
 * quiet forward display, never a target lookup or an inferred target position. */
export function expandedProjectedEffectPoint(id,i,n,t,options={}){
  const [fx,fy]=basis(options),angle=Math.atan2(fy,fx),spread=i-(n-1)/2;
  switch(id){
    case 'facetWard':return local([52+Math.sin(t*.42+i*.9)*2,spread*(n>2?21:31)], [0,0],angle);
    case 'deflectionFins':{const a=-Math.PI/2+i*TAU/n+Math.sin(t*.37+i*.9)*.16;return [Math.cos(a)*57,Math.sin(a)*60];}
    case 'contourScan':{const side=n===1?-1:i%2?1:-1,u=.5-.5*Math.cos(t*.54+(n===1?0:i%2*.5));return [side*(43+Math.sin(u*Math.PI)*5+Math.floor(i/2)*6),mix(-34,39,u)];}
    case 'sectorSearch':return local([43+(i%2)*5,spread*(n>2?15:24)],[0,0],angle+Math.sin(t*.34)*.28);
    case 'prismRelay':return local([48+(i%2)*11,spread*(n>2?16:24)],[0,0],angle);
    case 'signalPennants':return [spread*(n>2?22:38),-65+Math.sin(t*.46+i*.7)*2+(i%2)*6];
    case 'lightBridge':return local([51+Math.floor(i/2)*10,spread*(n>2?14:23)],[0,0],angle);
    case 'filamentLoom':{
      const corners=[[-24,-68],[25,-65],n===4?[-13,-38]:[11,-37],[18,-35]],c=corners[i];
      return [c[0]+Math.sin(t*.28+i)*1.2,c[1]+Math.sin(t*.33+i*.5)*1.6];
    }
    default:return null;
  }
}
export function expandedProjectedEffectDuty(id,index,count,t){
  const def=BY_ID.get(id);if(!def)return null;
  const i=clamp(index,0,3),n=clamp(count,1,4),phase=t*.46+i*.72,work=.5-.5*Math.cos(phase);
  return {state:def.state,amount:.62+.30*work,energy:.87+.23*work,role:roleLists[id][n-1][i]??def.jobs[n-1]};
}

export function drawExpandedProjectedEffect(id,{n,t,options,add,curve,diamond}){
  if(!BY_ID.has(id))return false;
  const low=options.detail==='low',steps=low?6:10,[fx,fy]=basis(options),direction=Math.atan2(fy,fx);
  const at=i=>expandedProjectedEffectPoint(id,i,n,t,options);
  const path=(points,opts={})=>add(points,{...opts,work:opts.work??'working-surface'});
  const segment=(a,b,u)=>[mix(a[0],b[0],u),mix(a[1],b[1],u)];
  switch(id){
    case 'facetWard':{
      for(let i=0;i<n;i++){
        const c=at(i),fold=.5-.5*Math.cos(t*.62+i*.5),a=direction+Math.sin(t*.34+i)*.12,length=n===1?28:n>2?17:23;
        const p=([-2,-length]),q=([6+fold*4,0]),r=([-2,length]),inside=([-8,0]);
        const polygon=[p,q,r,inside].map(p=>local(p,c,a));
        path(polygon,{closed:true,alpha:.76,width:1.15,fill:.055,glow:true,work:'folded-ward'});
        path([p,inside,r].map(p=>local(p,c,a)),{alpha:.34,width:.65,work:'hinged-facet'});
        path([inside,q].map(p=>local(p,c,a)),{alpha:.76,width:.9,highlight:true,work:'ward-fold'});
        const phase=frac(t*.26+i/n),u=smooth(phase),contact=local(q,c,a),end=local([12,-length-7],c,a);
        path([segment(contact,end,clamp(u-.10,0,1)),segment(contact,end,u)],{alpha:.95*Math.sin(phase*Math.PI),width:1.45,highlight:true,work:'diverted-contact'});
        const lip=[[-2,-length],[4,-length-3],[10,-length+1]].map(p=>local(p,c,a));path(lip,{alpha:.48,width:.75});
        diamond(...c,2.5,{alpha:.78,width:.85,fill:.05,highlight:true,work:'ward-hinge'});
      }break;
    }
    case 'deflectionFins':{
      for(let i=0;i<n;i++){
        const c=at(i),a=Math.atan2(c[1],c[0]),cycle=t*.68+i*.9,turn=Math.sin(cycle)*.24,s=Math.sin(cycle)*2;
        const fin=[[-6,-14],[5,-10],[10+s,0],[3,11],[-7,14],[-2,0]].map(p=>local(p,c,a+turn));
        path(fin,{closed:true,alpha:.76,width:1.1,fill:.055,glow:true,work:'interception-fin'});
        path([[-2,-10],[4+s,0],[-2,10]].map(p=>local(p,c,a+turn)),{alpha:.82,width:1,highlight:true,work:'fin-spine'});
        path([[-8,-5],[-11,0],[-8,5]].map(p=>local(p,c,a)),{alpha:.50,width:.8,work:'fin-hinge'});
        const phase=frac(t*.34+i/n),u=smooth(phase),contact=local([7,0],c,a+turn),end=local([21+7*u,-15-9*u],c,a);
        path([segment(contact,end,clamp(u-.12,0,1)),segment(contact,end,u)],{alpha:Math.sin(phase*Math.PI)*.96,width:1.4,highlight:true,work:'fin-deflection'});
        path([[7,-2],[11,0],[7,2]].map(p=>local(p,c,a+turn)),{alpha:.25+.45*Math.sin(phase*Math.PI)**4,width:.85,work:'fin-contact'});
        if(!low)path([[-4,-11],[1,-8],[3,-5]].map(p=>local(p,c,a+turn)),{alpha:.28,width:.65});
      }break;
    }
    case 'contourScan':{
      for(let i=0;i<n;i++){
        const c=at(i),side=c[0]<0?-1:1,u=.5-.5*Math.cos(t*.54+(n===1?0:i%2*.5)),a=side<0?0:Math.PI;
        path([[-4,-6],[3,-6],[6,-3],[6,3],[3,6],[-4,6]].map(p=>local(p,c,a)),{closed:true,alpha:.76,width:.95,fill:.055,highlight:true,work:'contour-shoe'});
        path([[c[0]-side*7,c[1]-7],[c[0]-side*8,c[1]+7]],{alpha:.8,width:1.35,glow:true,work:'scanning-slit'});
        const trace=(v,offset=0)=>[side*(42+Math.sin(v*Math.PI)*5+Math.floor(i/2)*6)+offset,mix(-34,39,v)];
        const tail=Math.min(.28,u),start=u-tail;
        curve(v=>trace(mix(start,u,v),-side*7),{steps,alpha:.59,width:.85,work:'measured-contour'});
        curve(v=>trace(mix(start,u,v),-side*12),{steps,alpha:.21,width:.55,tint:'#c8b8f5',work:'range-echo'});
        for(let j=0;j<3;j++){
          const q=u-j*.075;if(q<0)continue;const p=trace(q,-side*8);
          path([p,[p[0]-side*(j===0?6:4),p[1]]],{alpha:.63-j*.13,width:.75,work:'contour-measurement'});
        }
      }break;
    }
    case 'sectorSearch':{
      const a=direction+Math.sin(t*.34)*.28;
      for(let i=0;i<n;i++){
        const c=at(i),reach=31+(i%2)*8,spread=n===1?13:10,sweep=.5+.5*Math.sin(t*.72+i*.8);
        const top=local([reach,-spread],c,a),bottom=local([reach,spread],c,a);
        path([local([-4,-7],c,a),local([3,-7],c,a),local([6,-3],c,a),local([6,3],c,a),local([3,7],c,a),local([-4,7],c,a)],{closed:true,alpha:.67,width:.9,fill:.04,work:'search-aperture'});
        path([c,top,bottom,c],{alpha:.20,width:.55,fill:.018,closed:true,work:'search-frustum'});
        const slit=local([reach,mix(-spread,spread,sweep)],c,a);
        path([c,slit],{alpha:.70,width:1.0,glow:true,work:'searching-slit'});
        path([local([reach-4,mix(-spread,spread,sweep)-3],c,a),slit,local([reach-4,mix(-spread,spread,sweep)+3],c,a)],{alpha:.85,width:.9,highlight:true,work:'range-cursor'});
        for(let j=0;j<2;j++){
          const y=(j?1:-1)*spread*.55,hit=Math.max(0,1-Math.abs(mix(-spread,spread,sweep)-y)/7),x=reach-6-j*7;
          path([local([x-2,y-2],c,a),local([x+2,y],c,a),local([x-2,y+2],c,a)],{alpha:.16+.69*hit,width:.85,work:'range-answer'});
        }
      }break;
    }
    case 'prismRelay':{
      for(let i=0;i<n;i++){
        const c=at(i),a=direction,turn=(i%2?-1:1),knee=local([15,turn*9],c,a),end=local([38,turn*9],c,a),phase=frac(t*.24+i/n),q=smooth(phase);
        const prism=[[-5,0],[0,-8],[6,0],[0,8]].map(p=>local(p,c,a));
        path(prism,{closed:true,alpha:.8,width:1.0,fill:.07,glow:true,work:'turning-prism'});
        path([[-4,0],[0,-5],[3,0],[0,5],[-4,0]].map(p=>local(p,c,a)),{alpha:.62,width:.7,highlight:true,work:'prism-facets'});
        path([c,knee,end],{alpha:.33,width:.75,work:'relay-route'});
        path([local([-2,-2],knee,a),local([2,2],knee,a)],{alpha:.74,width:1.0,highlight:true,work:'relay-elbow'});
        const p=q<.45?segment(c,knee,q/.45):segment(knee,end,(q-.45)/.55);
        diamond(...p,2.4,{alpha:.97*Math.sin(phase*Math.PI),width:.85,highlight:true,fill:.07,work:'routed-packet'});
        path([[end[0]-fy*4,end[1]+fx*4],end,[end[0]+fy*4,end[1]-fx*4]],{alpha:.45+.30*Math.sin(phase*Math.PI)**4,width:.9,work:'relay-receiver'});
        if(!low)path([segment(c,knee,.42),segment(c,knee,.72)],{alpha:.32,width:1.5,tint:'#c8b8f5',work:'relay-charge'});
      }break;
    }
    case 'signalPennants':{
      for(let i=0;i<n;i++){
        const c=at(i),flip=i%2?-1:1,wave=Math.sin(t*.66+i*.7),width=n>2?24:33,height=20;
        const rail=(u,y=0)=>[c[0]+flip*u*width,c[1]+y+Math.sin(u*Math.PI)*wave*3];
        const top=Array.from({length:steps+1},(_,j)=>rail(j/steps)),bottom=Array.from({length:steps+1},(_,j)=>rail(1-j/steps,height*(1-(1-j/steps)*.24)));
        path([...top,...bottom],{closed:true,alpha:.58,width:.85,fill:.04,glow:true,work:'woven-pennant'});
        curve(u=>rail(u),{steps,alpha:.86,width:1.1,highlight:true,work:'pennant-leading-edge'});
        for(let j=1;j<=2;j++)curve(u=>rail(u,height*j/3*(1-u*.24)),{steps,alpha:.34,width:.65,work:'pennant-filament'});
        const q=.5-.5*Math.cos(t*.72+i*.6),p=rail(q,height*.52),tilt=flip*3;
        path([[p[0]-tilt,p[1]-5],[p[0],p[1]],[p[0]+tilt,p[1]+5]],{alpha:.86,width:1.15,highlight:true,work:'travelling-fold'});
        path([[c[0],c[1]-3],[c[0],c[1]+height+3]],{alpha:.56,width:.9,work:'pennant-tension'});
      }break;
    }
    case 'lightBridge':{
      for(let i=0;i<n;i++){
        const c=at(i),a=direction,phase=frac(t*.19+i/n),front=.5-.5*Math.cos(t*.42+i*.45),stride=14,wide=n>2?5:8;
        path([local([-5,-wide-2],c,a),c,local([-5,wide+2],c,a)],{alpha:.75,width:1,highlight:true,work:'bridge-anchor'});
        for(let j=0;j<3;j++){
          const built=smooth((front-j*.18)/.32),x=j*stride+3,tip=x+stride*built;
          const points=[[x,-wide],[tip-3,-wide],[tip,0],[tip-3,wide],[x,wide],[x+3,0]].map(p=>local(p,c,a));
          path(points,{closed:true,alpha:.18+.50*built,width:.85,fill:.02+.04*built,glow:j===0,work:'interlocked-step'});
        }
        // The seam follows the available construction front, so it never
        // travels over a plate that has not been laid yet.
        const builtReach=stride*(smooth(front/.32)+smooth((front-.18)/.32)+smooth((front-.36)/.32));
        const q=smooth(phase),p=local([3+q*builtReach,0],c,a);
        path([[p[0]+fy*wide*.8,p[1]-fx*wide*.8],[p[0]-fy*wide*.8,p[1]+fx*wide*.8]],{alpha:.86*Math.sin(phase*Math.PI),width:1.3,highlight:true,work:'travelling-bridge-seam'});
        path([local([3,-wide-3],c,a),local([stride*3+3,-wide-3],c,a)],{alpha:.23,width:.6,work:'bridge-tension'});
      }break;
    }
    case 'filamentLoom':{
      const a=at(0),b=n>1?at(1):[25+Math.sin(t*.28)*1.2,-65+Math.sin(t*.33)*1.6],d=n===4?at(3):n>2?at(2):[11,-37],e=n===4?at(2):d;
      // One shared sail makes the extra bit a real corner holder rather than
      // adding another copy of the same rectangle. Solo uses its own projected
      // retained rail, fed from the same single working aperture.
      path(n===4?[a,b,d,e]:[a,b,d],{closed:true,alpha:.67,width:1.0,fill:.045,glow:true,work:'loom-sail'});
      path([a,d],{alpha:.30,width:.65,work:'diagonal-warp'});
      const warp=Math.sin(t*.45)*1.2,threads=low?3:5;
      for(let j=1;j<=threads;j++){
        const u=j/(threads+1),start=segment(a,b,u),end=segment(e,d,u);
        curve(v=>[mix(start[0],end[0],v)+Math.sin(v*Math.PI)*warp,mix(start[1],end[1],v)],{steps,alpha:.49,width:.7,work:'tensioned-warp'});
      }
      const sweep=.5-.5*Math.cos(t*.71),left=segment(a,e,sweep),right=segment(b,d,sweep),q=.5-.5*Math.cos(t*1.1),p=segment(left,right,q),forward=Math.sin(t*1.1)>=0;
      path([forward?left:right,p],{alpha:.72,width:.95,glow:true,work:'laid-weft'});
      path([[p[0]-4,p[1]-2.8],[p[0]+4,p[1]],[p[0]-4,p[1]+2.8],[p[0]-2,p[1]]],{closed:true,alpha:.97,width:1.1,fill:.13,highlight:true,work:'travelling-shuttle'});
      for(let i=0;i<n;i++){
        const c=at(i),hold=i<2?-1:1;
        path([[c[0]-4,c[1]-hold*2],[c[0],c[1]+hold*2],[c[0]+4,c[1]-hold*2]],{alpha:.85,width:1.15,highlight:true,work:i===3?'loom-edge-verifier':'loom-corner-grip'});
      }
      if(n===1)path([a,[a[0]+18,a[1]-7],b],{alpha:.26,width:.7,work:'retained-loom-rail'});
      break;
    }
  }
  return true;
}
