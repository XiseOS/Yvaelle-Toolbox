/** Small autonomous work excursions from the unchanged formation path.
 * References belong to one deterministic episode; live bases belong to this
 * sample. Neither station names nor a new slot order decide where a bit goes. */
export const EPISODE_LOCAL_LIMITS=Object.freeze({x:18,y:20});
const finite=(value,fallback=0)=>Number.isFinite(value)?value:fallback;
const unit=value=>Math.max(0,Math.min(1,finite(value)));
const soft=(value,limit)=>limit>0?limit*Math.tanh(value/limit):0;

/** A housing's quiet lean follows the transverse focus direction, rather than
 * clamping a wrapped full-circle bearing. The soft distance keeps the result
 * continuous when a focus crosses behind the instrument or passes through it.
 * A true wave bearing remains the wave renderer's separate responsibility.
 */
export function boundedFocusLean(from,target,{rotation=0,max=.65,softDistance=12}={}){
  const coordinate=(p,index,key)=>finite(Array.isArray(p)?p[index]:p?.[key]);
  const dx=coordinate(target,0,'x')-coordinate(from,0,'x'),dy=coordinate(target,1,'y')-coordinate(from,1,'y'),angle=finite(rotation),distance=Math.max(.0001,Math.abs(finite(softDistance,12))),limit=Math.max(0,finite(max,.65));
  const transverse=dx*Math.cos(angle)+dy*Math.sin(angle);
  return limit*transverse/Math.sqrt(dx*dx+dy*dy+distance*distance);
}

/** Return a move(i, desired, weight=1) compatible with the native episode jobs.
 * Live poses are copied before any job moves, so jobs cannot borrow a previous
 * job's station. Only x/y change. Natural base crossings and depth remain exact.
 * Optional offsets are the renderer's existing per-bit x/y additions, in rig
 * units. Ownership uses the displayed baseline; raw poses retain their offsets.
 * Half-gap bounds shrink continuously to zero when base stations pass each
 * other; x also shrinks at the centre in both directions, avoiding a side flip.
 */
export function createEpisodeMove(poses,referencePoses,amount,{offsets=[]}={}){
  const base=poses.map(p=>[finite(p?.[0]),finite(p?.[1]),finite(p?.[2])]);
  const reference=base.map((p,i)=>[finite(referencePoses?.[i]?.[0],p[0]),finite(referencePoses?.[i]?.[1],p[1])]);
  const displayed=base.map((p,i)=>[p[0]+finite(offsets?.[i]?.[0]),p[1]+finite(offsets?.[i]?.[1])]);
  const bounds=displayed.map((p,i)=>{
    const limits=[Math.min(EPISODE_LOCAL_LIMITS.x,Math.abs(p[0])*.95),EPISODE_LOCAL_LIMITS.y];
    for(let j=0;j<displayed.length;j++)if(j!==i)for(let axis=0;axis<2;axis++)limits[axis]=Math.min(limits[axis],Math.abs(displayed[j][axis]-p[axis])*.5);
    return limits;
  });
  const gain=unit(amount);
  return (i,desired,weight=1)=>{
    if(!Number.isInteger(i)||!base[i]||!poses[i]||!Array.isArray(desired))return;
    const intensity=gain*unit(weight),limits=[EPISODE_LOCAL_LIMITS.x,EPISODE_LOCAL_LIMITS.y];
    for(let axis=0;axis<2;axis++){
      const requested=finite(desired[axis],reference[i][axis])-reference[i][axis];
      const delta=soft(requested,limits[axis])*intensity;
      poses[i][axis]=base[i][axis]+soft(delta,bounds[i][axis]);
    }
    poses[i][2]=base[i][2];
  };
}
