/** Bounded C1 handoffs for native wing channels. Velocity uses values per
 * millisecond. One shared damping coefficient keeps simplex weights summing to
 * one while preserving the incoming derivative exactly at an interruption. */
export function handoffDamping(from,to,tangent,min=0,max=1){
  let damp=0;
  for(let i=0;i<from.length;i++){
    const v=tangent[i]??0;if(!v)continue;
    const room=Math.max(0,v>0?max-from[i]:from[i]-min);
    const limit=Math.max(1e-9,Math.min(Math.max(.04,Math.abs(to[i]-from[i])*.65),room*.18));
    damp=Math.max(damp,Math.abs(v)/limit-1);
  }
  return Math.max(0,damp);
}

export function sampleWingHandoff(from,to,velocity,p,duration,{min=0,max=1}={}){
  if(p>=1||!duration)return {values:[...to],velocity:to.map(()=>0)};
  if(p<=0)return {values:[...from],velocity:p<0?from.map(()=>0):[...velocity]};
  const tangent=velocity.map(v=>v*duration),damp=handoffDamping(from,to,tangent,min,max),attenuation=Math.exp(-p*damp);
  const h=p*p*(3-2*p),dh=6*p*(1-p),g=p*(1-p)**2,dg=(1-p)*(1-3*p);
  return {values:from.map((a,i)=>a+(to[i]-a)*h+g*tangent[i]*attenuation),
    velocity:from.map((a,i)=>((to[i]-a)*dh+(dg-g*damp)*tangent[i]*attenuation)/duration)};
}
