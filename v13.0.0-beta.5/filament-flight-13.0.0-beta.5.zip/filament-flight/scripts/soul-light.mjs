/** "Soul light" filament material (optional, per viewer).
 * The same filament geometry as the original painter, drawn as layered light
 * on Ellie's soul magenta: a violet halo, a magenta body, a hot core on ribs
 * and edges, tapering ribs, energy travelling from the shoulders and small
 * twinkles along the lattice. Conditions change heat, never hue. Runs in the
 * worker as well as on the main thread; no Foundry or DOM globals. */
const TAU=Math.PI*2;
const unit=n=>Math.max(0,Math.min(1,n));
const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
const strHash=s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))|0;return Math.abs(h)%1000/7.3;};
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${Math.max(0,Math.min(1,a))})`;

export const SOUL_PALETTES=Object.freeze({
  normal:    {halo:[170,0,230],body:[255,0,255],core:[255,196,255],haloA:.11,glowA:.3,bodyA:1,coreA:.55,haloW:7,motes:1,pulse:.42,pulseA:.85},
  damaged:   {halo:[160,0,210],body:[250,0,240],core:[255,186,252],haloA:.08,glowA:.24,bodyA:.88,coreA:.45,haloW:6,motes:.8,pulse:.3,pulseA:.55,flicker:.35,tipFade:.55,embers:[255,70,255]},
  unstable:  {halo:[180,0,235],body:[255,0,255],core:[255,200,255],haloA:.11,glowA:.3,bodyA:.95,coreA:.55,haloW:7.5,motes:1,pulse:.62,pulseA:.8,jitter:1.3},
  glitching: {halo:[160,0,230],body:[255,0,255],core:[255,210,255],haloA:.1,glowA:.27,bodyA:.92,coreA:.5,haloW:7,motes:.7,pulse:.5,pulseA:.7,split:2.2},
  overdrive: {halo:[230,0,255],body:[255,40,255],core:[255,228,255],haloA:.16,glowA:.4,bodyA:1,coreA:.8,haloW:9.5,motes:1.8,pulse:.95,pulseA:1},
  suppressed:{halo:[80,0,110],body:[190,0,205],core:[230,150,240],haloA:.06,glowA:.17,bodyA:.75,coreA:.3,haloW:5,motes:.3,pulse:.16,pulseA:.35},
  collapsed: {halo:[100,0,125],body:[215,0,220],core:[245,170,250],haloA:.06,glowA:.19,bodyA:.78,coreA:.38,haloW:5,motes:.5,pulse:.12,pulseA:.3,embers:[255,80,255],tipFade:.4}
});
/** Strongest active condition channel in the sampled visual profile. */
export function soulCondition(v={}){
  const c=[['collapsed',v.collapse],['suppressed',v.suppression],['overdrive',v.overdrive],['glitching',v.glitch],['unstable',v.instability],['damaged',v.damage]]
    .filter(([,n])=>Number(n)>.28).sort((a,b)=>b[1]-a[1])[0];
  return c?c[0]:'normal';
}
const kindOf=id=>String(id).split('-')[0];
function widthAt(kind,u,t){
  if(kind==='rib')return 1.08-.78*u;
  if(kind==='edge')return .5+.45*Math.sin(Math.PI*unit(t));
  return .25+.75*Math.sin(Math.PI*unit(t));
}
function ribbon(ctx,pts,wfn,from=0,to=pts.length-1,dx=0){
  if(to-from<1)return;const L=[],R=[];
  for(let i=from;i<=to;i++){
    const a=pts[Math.max(from,i-1)],b=pts[Math.min(to,i+1)],p=pts[i];
    let nx=-(b[1]-a[1]),ny=b[0]-a[0];const l=Math.hypot(nx,ny)||1;nx/=l;ny/=l;const w=wfn(i)/2;
    L.push(p[0]+nx*w+dx,p[1]+ny*w);R.push(p[0]-nx*w+dx,p[1]-ny*w);
  }
  ctx.beginPath();ctx.moveTo(L[0],L[1]);for(let i=2;i<L.length;i+=2)ctx.lineTo(L[i],L[i+1]);
  for(let i=R.length-2;i>=0;i-=2)ctx.lineTo(R[i],R[i+1]);ctx.closePath();ctx.fill();
}
function glint(ctx,x,y,r,c,a){
  const g=ctx.createRadialGradient(x,y,0,x,y,r*3);g.addColorStop(0,rgba(c,a*.55));g.addColorStop(1,rgba(c,0));
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r*3,0,TAU);ctx.fill();
  ctx.fillStyle=rgba([255,240,255],a);ctx.beginPath();
  ctx.moveTo(x,y-r*1.6);ctx.lineTo(x+r*.32,y-r*.32);ctx.lineTo(x+r*1.6,y);ctx.lineTo(x+r*.32,y+r*.32);
  ctx.lineTo(x,y+r*1.6);ctx.lineTo(x-r*.32,y+r*.32);ctx.lineTo(x-r*1.6,y);ctx.lineTo(x-r*.32,y-r*.32);ctx.closePath();ctx.fill();
}

/** Paint one layer's filament parts. The context is already in rig units
 * (translated to the shoulder origin). Hardware and stars are left to the caller. */
export function paintSoulParts(ctx,parts,visual={}){
  const condition=soulCondition(visual),P=SOUL_PALETTES[condition];
  const time=Number(visual.time)||0,energy=Math.max(.35,Math.min(1.6,visual.energy??1))*(1+Math.max(0,visual.flare??0)*.8);
  const healing=unit(visual.healing??0);
  const strands=parts.filter(s=>!s.hardware&&!s.star&&s.points?.length>1);
  const ribs=[],FL=new Map(),fl=s=>FL.get(s)??1;
  ctx.save();ctx.globalCompositeOperation='lighter';
  for(const s of strands){
    const k=kindOf(s.id),pts=s.points,n=pts.length-1,str=s.strength*energy,seed=strHash(s.id);
    if(k==='rib')ribs.push(s);
    FL.set(s,P.flicker?1-P.flicker*(.5+.5*Math.sin(time*9+seed))*(hash(Math.floor(time*6)+seed)>.6?1:.2):1);
    const jx=P.jitter?Math.sin(time*23+seed)*P.jitter:0;
    ctx.fillStyle=rgba(P.halo,P.haloA*str*fl(s));ribbon(ctx,pts,i=>s.width*P.haloW*(.55+.45*widthAt(k,pts[i][3]??0,i/n)),0,n,jx);
    ctx.fillStyle=rgba(P.body,P.glowA*str*fl(s));ribbon(ctx,pts,i=>s.width*2.6*widthAt(k,pts[i][3]??0,i/n));
  }
  for(const s of strands){
    const k=kindOf(s.id),pts=s.points,n=pts.length-1,str=Math.min(1,s.strength*energy)*fl(s),w=i=>s.width*1.35*widthAt(k,pts[i][3]??0,i/n);
    if(P.split){const on=Math.sin(time*3.1+strHash(s.id))>.55?1:.25;ctx.fillStyle=rgba([255,0,150],.55*str*on);ribbon(ctx,pts,w,0,n,P.split*on);ctx.fillStyle=rgba([150,40,255],.55*str*on);ribbon(ctx,pts,w,0,n,-P.split*on);}
    if(P.tipFade){for(let a=0;a<n;a+=6){const b=Math.min(n,a+7);ctx.fillStyle=rgba(P.body,P.bodyA*str*(1-P.tipFade*(pts[a][3]??a/n)));ribbon(ctx,pts,w,a,b);}}
    else{ctx.fillStyle=rgba(P.body,P.bodyA*str);ribbon(ctx,pts,w);}
  }
  for(const s of strands){
    const k=kindOf(s.id),pts=s.points,n=pts.length-1,str=Math.min(1,s.strength*energy)*fl(s),coreA=(k==='rib'?1:k==='edge'?.75:0)*P.coreA*str;
    if(coreA<.03)continue;ctx.fillStyle=rgba(P.core,coreA);ribbon(ctx,pts,i=>s.width*.26*widthAt(k,pts[i][3]??0,i/n));
  }
  // energy travelling shoulder -> tip
  if(visual.animated!==false&&P.pulse>0)for(const s of ribs){
    const pts=s.points,n=pts.length-1,idx=+String(s.id).split('-')[1]||0;
    for(const lane of [0,.5]){
      const head=(time*P.pulse*.55+idx*.137+lane)%1.25;if(head>1.08)continue;const tail=head-.16;let a=-1,b=-1;
      for(let i=0;i<=n;i++){const u=pts[i][3]??i/n;if(u>=tail&&a<0)a=i;if(u<=head)b=i;}
      if(a<0||b<=a)continue;
      ctx.fillStyle=rgba(P.core,.55*P.pulseA*fl(s));ribbon(ctx,pts,i=>{const u=pts[i][3]??i/n,f=(u-tail)/(head-tail);return s.width*(.6+1.6*f*f)*widthAt('rib',u,i/n);},a,b);
      glint(ctx,pts[b][0],pts[b][1],1.2+1.4*P.pulseA,P.body,.7*P.pulseA*fl(s));
    }
  }
  // healing: light re-threads from the tips back to the shoulders
  if(healing>.04)for(const s of strands){
    const k=kindOf(s.id),pts=s.points,n=pts.length-1,front=1.08-((time*.9)%1.25);let a=-1,b=-1;
    for(let i=0;i<=n;i++){const u=pts[i][3]??i/n;if(u>=front&&a<0)a=i;if(u<=front+.12)b=i;}
    if(a<0||b<=a)continue;ctx.fillStyle=rgba([255,170,255],(k==='web'?.3:.75)*s.strength*healing);
    ribbon(ctx,pts,i=>s.width*(k==='web'?1.1:1.6)*widthAt(k,pts[i][3]??0,i/n),a,b);
  }
  // twinkles (or embers when damaged/collapsed)
  if(visual.animated!==false){let m=0;const limit=Math.round(78*P.motes);
    for(const s of strands){
      const k=kindOf(s.id);if(k!=='rib'&&k!=='edge'&&k!=='web')continue;const seed=strHash(s.id),chance=k==='rib'?.95:k==='edge'?.7:.16;
      if(hash(seed)>chance*P.motes)continue;if(++m>limit)break;
      const pts=s.points,p=pts[Math.round(hash(seed+3)*(pts.length-1))],tw=Math.pow(Math.max(0,Math.sin(time*(1.3+hash(seed+5)*1.7)+seed*3)),6);if(tw<.04)continue;
      if(P.embers){const fall=(time*.35+hash(seed+9))%1;glint(ctx,p[0]+Math.sin(time+seed)*3,p[1]+fall*22,1.3,P.embers,tw*(1-fall));}
      else glint(ctx,p[0],p[1],1.1+hash(seed+7)*1.4,P.body,tw*.95);
    }}
  ctx.restore();
}
