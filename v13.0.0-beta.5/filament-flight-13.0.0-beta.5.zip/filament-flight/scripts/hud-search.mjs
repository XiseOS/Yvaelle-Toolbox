/** Local settings filtering. No scene documents, timers or animation work. */
const indexes=new WeakMap();
const ROW='.ff-slider,.ff-feature,.ff-select-row,.ff-number,.ff-check,.ff-theme-path,.ff-light-radius,.ff-audio-file,.ff-bit-map,.ff-saved-look,label,button,input,select';
const HEADER='summary,.ff-section-title,h3,h4';
const NOTE='.ff-note,.ff-system-status,.ff-hint';
const OMIT='option,optgroup,.ff-pin-setting,[aria-hidden="true"]';

const normalizedSearchText=value=>String(value??'').normalize('NFKC').toLocaleLowerCase();
export const settingsSearchTerms=query=>normalizedSearchText(query).trim().split(/\s+/u).filter(Boolean);
export const matchesSettingsSearch=(terms,text)=>{if(!terms.length)return true;const normalized=normalizedSearchText(text);return terms.every(term=>normalized.includes(term));};

function searchableText(node){
  if(node.nodeType===3)return node.textContent;
  if(node.nodeType!==1||node.matches(OMIT))return '';
  const attrs=[node.getAttribute('aria-label'),node.getAttribute('title')].filter(Boolean);
  // Unselected choices must not make every condition picker match every effect.
  if(node.tagName==='SELECT')return [...attrs,...Array.from(node.selectedOptions??[],option=>option.textContent)].join(' ');
  return [...attrs,...Array.from(node.childNodes,searchableText)].join(' ');
}
function headerFor(node){
  if(node.tagName==='DETAILS')return node.querySelector(':scope > summary');
  if(node.matches('.ff-effect-card'))return node.querySelector(':scope > .ff-effect-select-row');
  if(node.matches('.ff-condition-rule'))return node.querySelector(':scope > .ff-check');
  if(!node.matches('section,.ff-section'))return null;
  return node.querySelector(':scope > .ff-section-title,:scope > h3,:scope > h4');
}
function headingText(node){
  // Short headings supply context without turning a broad descriptive hint into
  // a match for every unrelated setting in the same group.
  const copy=node.cloneNode(true);
  for(const extra of copy.querySelectorAll('small,button,select,input,.ff-pin-setting,[aria-hidden="true"]'))extra.remove();
  return searchableText(copy);
}
function detailsPreference(node,prefs){
  if(node.hasAttribute('data-ff-reactions'))return !!prefs.reactionEffectsOpen;
  if(node.dataset.ffAudioOpen!==undefined)return (prefs.audioOpen??[]).includes(node.dataset.ffAudioOpen);
  if(node.dataset.ffSection!==undefined)return (prefs.openSections??[]).includes(node.dataset.ffSection);
  return node.open;
}
function createIndex(root){
  const groups=Array.from(root.querySelectorAll('[data-ff-group]'));
  const headers=new Map(),headings=new Map(),nodes=[],entries=[],details=[];
  for(const group of groups){
    for(const node of [group,...group.querySelectorAll('*')]){
      nodes.push(node);
      const header=headerFor(node);if(header)headers.set(node,header);
      if(node.tagName==='DETAILS')details.push(node);
    }
    for(const row of group.querySelectorAll(ROW)){
      if(row.closest(HEADER)||row.matches('.ff-pin-setting')||row.closest('[hidden]'))continue;
      if(row.parentElement.closest(ROW)&&group.contains(row.parentElement.closest(ROW)))continue;
      const context=[],parents=[];
      for(let parent=row.parentElement;parent&&group.contains(parent);parent=parent.parentElement){
        parents.push(parent);const header=headers.get(parent);if(header){if(!headings.has(header))headings.set(header,headingText(header));context.push(headings.get(header));}
      }
      const notes=[];
      for(let next=row.nextElementSibling;next?.matches(NOTE);next=next.nextElementSibling)notes.push(next);
      entries.push({row,group,parents,notes,text:normalizedSearchText([searchableText(row),...context].join(' '))});
    }
  }
  return {groups,headers,nodes,entries,details,active:false,open:new Map()};
}

/** Preserve original feature visibility; search owns only its own CSS classes. */
export function filterHUDSettings(root,query,prefs={}){
  if(!root)return {groups:0,controls:0};
  const terms=settingsSearchTerms(query);let index=indexes.get(root);
  if(!terms.length&&!index)return {groups:0,controls:0};
  if(!index){index=createIndex(root);indexes.set(root,index);}
  const {groups,headers,nodes,entries,details}=index;
  if(!terms.length){
    for(const node of nodes){node.classList.remove('ff-search-hidden','ff-search-match');}
    if(index.active)for(const [node,open]of index.open)node.open=open;
    index.active=false;index.open.clear();return {groups:groups.length,controls:entries.length};
  }
  if(!index.active){for(const node of details)index.open.set(node,detailsPreference(node,prefs));index.active=true;}
  const visible=new Set(),matchedGroups=new Set();let controls=0;
  const revealTree=node=>{visible.add(node);for(const child of node.querySelectorAll('*'))visible.add(child);};
  for(const entry of entries){
    const match=terms.every(term=>entry.text.includes(term));entry.row.classList.toggle('ff-search-match',match);
    if(!match)continue;
    controls++;matchedGroups.add(entry.group);revealTree(entry.row);
    for(const note of entry.notes)revealTree(note);
    for(const parent of entry.parents){visible.add(parent);const header=headers.get(parent);if(header)revealTree(header);}
  }
  // Group controls must retain the selected recipient, otherwise a matching
  // slider would not say whose formation it changes.
  for(const group of matchedGroups)for(const context of group.querySelectorAll('.ff-settings-group-context')){revealTree(context);for(let p=context.parentElement;p&&group.contains(p);p=p.parentElement)visible.add(p);}
  for(const node of nodes)node.classList.toggle('ff-search-hidden',!visible.has(node));
  for(const node of details)if(visible.has(node))node.open=true;
  return {groups:matchedGroups.size,controls};
}
