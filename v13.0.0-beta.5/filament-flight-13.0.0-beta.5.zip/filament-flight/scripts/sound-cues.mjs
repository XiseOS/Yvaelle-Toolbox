/** v10 sound cues for effects that live outside the wing snapshot (warps and
 * routines). Every client already runs these effects from the socket, so each
 * client plays its own sound through the wing audio: the token's Audio switch,
 * categories, radius, mutes and volumes all apply, and nothing is broadcast. */
let sink=null;
export function setCueSink(value){sink=value;}
export function playCue(token,slot,options={}){try{return sink?.play?.(token,slot,options)??null;}catch(e){console.warn('Yvaelle’s Toolbox | sound cue',slot,e);return null;}}
export function stopCue(token,slot,fade=300){try{sink?.stopShot?.(token,slot,fade);}catch{}}
