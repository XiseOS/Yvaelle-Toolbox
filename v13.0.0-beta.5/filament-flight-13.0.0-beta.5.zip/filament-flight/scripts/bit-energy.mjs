/** Shared, clock-driven emitter pass for native solids, legacy sprite assets,
 * and the original vector housing. The final pass always sits above artwork. */
const TAU=Math.PI*2;
const unit=n=>Math.max(0,Math.min(1,Number(n)||0));

export function bitEnergy(h){
  if(!h.glow||h.glow.strength<=0)return null;
  const r=h.resonance??{};
  const gain=Math.max(0,Math.min(4,Number(h.glow.strength)||0));
  const state=r.coreState??{},activity=1+(state.charge??0)*.28+(state.open??0)*.12+(state.guard??0)*.16-(state.encase??0)*.22;
  const strength=gain*unit(h.power)*Math.max(.65,Math.min(1.2,r.response??1))*activity;
  if(strength<=.0001)return null;
  const direction=h.glow.direction??[0,-1],c=Math.cos(-h.angle),s=Math.sin(-h.angle);
  return {strength,field:h.glowMode==='field',direction:[direction[0]*c-direction[1]*s,direction[0]*s+direction[1]*c],
    color:/^#[\da-f]{6}$/i.test(h.glow.color??'')?h.glow.color:null,
    state,tool:h.tool??null,attention:unit(h.intent?.amount),phase:r.phase??0,focus:r.focus??0,motion:r.motion??0,style:r.fieldStyle??'contour',healing:r.healing??0,charge:r.charge??1};
}

function bloom(ctx,x,y,rx,ry,alpha,color=null){
  ctx.save();ctx.translate(x,y);ctx.scale(rx,ry);
  const g=ctx.createRadialGradient(0,0,0,0,0,1);
  const rgb=color?[1,3,5].map(i=>Number.parseInt(color.slice(i,i+2),16)).join(','):null;
  g.addColorStop(0,`rgba(${rgb??'255,105,245'},${alpha})`);g.addColorStop(.4,`rgba(${rgb??'248,25,236'},${alpha*.6})`);
  g.addColorStop(.78,`rgba(${rgb??'218,0,236'},${alpha*.12})`);g.addColorStop(1,`rgba(${rgb??'218,0,236'},0)`);
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,1,0,TAU);ctx.fill();ctx.restore();
}
const wrap=n=>(n%1+1)%1;

/** Temporary hardlight instruments stay inside the housing's existing 42-unit
 * artwork bound. The work pass is native vector ink, with no filters, textures,
 * particles, persistent trails or separate animation tickers. */
export function paintInstrumentTool(ctx,tool,phase=0,color='#ffd4f6'){
  if(!tool||tool.amount<=.001)return;
  const gain=unit(tool.amount),p=unit(tool.progress),variation=tool.variation??0;
  ctx.save();ctx.globalAlpha*=gain;ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=.56;ctx.lineCap='round';
  const line=points=>{ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.stroke();};
  if(tool.type==='lens'){
    const x=17,y=-8,r=5.8+.4*Math.sin(phase*.7);line([[7,-3],[12,-6],[x-r,-6]]);
    ctx.beginPath();ctx.ellipse(x,y,r,r*.66,-.24,0,TAU);ctx.stroke();
    ctx.globalAlpha*=.5;ctx.beginPath();ctx.ellipse(x,y,r*.72,r*.43,-.24,0,TAU);ctx.stroke();
    const scan=Math.sin(phase*1.6)*r*.7;line([[x+scan,y-3],[x+scan,y+3]]);
    for(const q of [-1,1])line([[x+q*8,y-2],[x+q*8,y-5],[x+q*6,y-5]]);
  }else if(tool.type==='probe'){
    const tipX=20+2*Math.sin(phase*.9+variation),tipY=-2+4*Math.sin(phase*.66);
    line([[6,0],[12,-4],[17,-3],[tipX,tipY]]);line([[8,2],[13,-1],[17,-1]]);
    ctx.beginPath();ctx.arc(tipX,tipY,1.1,0,TAU);ctx.stroke();
    ctx.globalAlpha*=.36;ctx.beginPath();ctx.arc(tipX,tipY,3.5+.8*Math.sin(phase),-.8,.8);ctx.stroke();
  }else if(tool.type==='plate'){
    const x=16,y=3,tilt=Math.sin(phase*.55)*1.2;
    line([[6,4],[10,8],[13,6]]);line([[x-5,y-8],[x+8,y-5+tilt],[x+5,y+8],[x-8,y+5-tilt],[x-5,y-8]]);
    ctx.globalAlpha*=.45;for(let i=0;i<3;i++)line([[x-5+i*3,y-6+i],[x-8+i*3,y+4+i]]);
    line([[x-6,y-1],[x+6,y+2]]);
  }else if(tool.type==='travel'){
    const p=wrap(phase*.23);for(const lane of [-1,1]){ctx.globalAlpha*=.8;line([[lane*10,9+p*7],[lane*12,15+p*6],[lane*11,20+p*5]]);}
  }else if(tool.type==='spark'){
    const a=phase*.47+variation*.9,x=17+Math.cos(a)*3,y=-4+Math.sin(a)*6,r=1.2+Math.sin(Math.PI*p)*.7;
    line([[x,y-r*2],[x+r,y],[x,y+r*2],[x-r,y],[x,y-r*2]]);
    ctx.globalAlpha*=.32;line([[7,-3],[11,-4],[x-3,y]]);
  }
  ctx.restore();
}

/** Drawn inside the bit's local transform. Beyond this compact emitter, the
 * rig adds animated currents sampled along the actual nearby wing contour. */
function paintOrdinaryBitEnergy(ctx,part,pass='front'){
  const h=part.hardware,e=bitEnergy(h);if(!e)return;
  const modern=h.artwork==='resonant',extent=modern?(h.design==='shielded'?14:18):25;
  ctx.save();ctx.globalAlpha=unit(part.strength*e.strength);ctx.globalCompositeOperation='source-over';
  const gain=1+Math.max(0,e.strength-1)*.20;
  if(pass==='back'){
    bloom(ctx,0,-1,(modern?9:12)*gain,extent*.92*gain,.62,e.color);
    if(e.field){
      const [x,y]=e.direction;
      ctx.save();ctx.translate(x*8,y*8);ctx.rotate(Math.atan2(y,x));
      bloom(ctx,0,0,(modern?18:21)*gain,(modern?11:15)*gain,.4,e.color);ctx.restore();
    }
  }else{
    bloom(ctx,0,-1,(modern?4.6:5.3)*gain,(modern?9:13)*gain,.64,e.color);
    ctx.strokeStyle='rgba(255,194,250,.85)';ctx.lineWidth=modern?.55:.75;
    // Two advancing internal currents wind around the luminous core. This
    // emissive overlay also makes glow work on every opaque atlas frame.
    for(const lane of [-1,1]){
      ctx.beginPath();
      for(let i=0;i<=16;i++){
        const t=i/16,y=-(modern?7:11)+t*(modern?13:18);
        const x=lane*Math.sin(t*Math.PI)*Math.sin(e.phase*1.4+t*TAU)*.9;
        i?ctx.lineTo(x,y):ctx.moveTo(x,y);
      }
      ctx.stroke();
    }
    // Optional work-state accents stay inside the existing atlas. Three
    // bounded traces give the crystal a clear job without a blur/filter stack.
    const state=e.state,charging=state.charge??0,opening=state.open??0,guarding=state.guard??0;
    if(charging>.001||opening>.001||guarding>.001||e.attention>.001){
      const amount=Math.max(charging,opening,guarding,e.attention*.42);
      for(let lane=0;lane<3;lane++){
        const p=wrap(e.phase*.16+lane/3),y=-extent*.58+p*extent*1.16;
        const half=2+Math.sin(Math.PI*p)*(3.8+opening*1.5);
        ctx.strokeStyle=e.color??'#ffd4f6';ctx.lineWidth=.42;
        ctx.globalAlpha=unit(part.strength*e.strength)*amount*Math.sin(Math.PI*p)*.72;
        ctx.beginPath();ctx.moveTo(-half,y);ctx.quadraticCurveTo(0,y-1.6-guarding*1.3,half,y);ctx.stroke();
      }
      ctx.globalAlpha=unit(part.strength*e.strength);
    }
    if(e.field){
      const a=Math.atan2(e.direction[1],e.direction[0]),radius=modern?9.2:13;
      // Staggered crescent fronts continually leave the emitter and settle.
      // These are curved local fields, never a straight connection or beam.
      for(let lane=0;lane<3;lane++){
        const travel=wrap(e.phase*.19+lane/3),r=radius+travel*8;
        const span=.37+.27*Math.sin(Math.PI*travel)+.12*e.focus;
        const arcAlpha=Math.sin(Math.PI*travel)*(.43+.12*e.motion);
        ctx.strokeStyle=`rgba(253,136,246,${arcAlpha})`;ctx.lineWidth=.48;
        ctx.beginPath();ctx.arc(0,-.5,r,a-span,a+span);ctx.stroke();
        const packet=a+(travel-.5)*span*1.5;
        ctx.strokeStyle=`rgba(255,216,250,${arcAlpha*.95})`;ctx.lineWidth=.75;
        ctx.beginPath();ctx.arc(0,-.5,r,packet-.065,packet+.065);ctx.stroke();
      }
      if(e.style==='weave'){
        for(const lane of [-1,1]){
          ctx.beginPath();
          for(let i=0;i<=18;i++){
            const t=i/18,rad=radius+2+7*t,ang=a+lane*Math.sin(t*Math.PI+e.phase*.5)*.39;
            const x=Math.cos(ang)*rad,y=Math.sin(ang)*rad-.5;
            i?ctx.lineTo(x,y):ctx.moveTo(x,y);
          }
          ctx.strokeStyle='rgba(249,157,244,.43)';ctx.lineWidth=.4;ctx.stroke();
        }
      }
    }
    paintInstrumentTool(ctx,e.tool,e.phase,e.color??'#ffd4f6');
  }
  ctx.restore();
}

/** Projection has its own quiet light cycle. The ordinary field waves,
 * travelling work tools and winding idle currents fade away completely;
 * a focusing aperture and two slow converging filaments take their place. */
export function paintBitEnergy(ctx,part,pass='front'){
  const h=part.hardware,lantern=h.lantern,weight=unit(lantern?.weight);
  if(!weight||!lantern.projection)return paintOrdinaryBitEnergy(ctx,part,pass);
  if(weight<1)paintOrdinaryBitEnergy(ctx,{...part,strength:part.strength*(1-weight),
    hardware:{...(lantern.original??h),angle:h.angle,scale:h.scale,glow:h.glow,glowMode:h.glowMode}},pass);
  const projection={...h,...lantern.projection,glow:h.glow?{...h.glow,direction:lantern.direction}:null,glowMode:h.glowMode},e=bitEnergy(projection);if(!e)return;
  const phase=lantern.phase??0,pulse=.5+.5*Math.sin(phase),[dx,dy]=e.direction,nx=-dy,ny=dx;
  const powering=lantern.powering,gain=powering?.strength??0,supply=(before,after)=>before+(after-before)*gain;
  const alpha=unit(part.strength*e.strength)*weight*(lantern.contributor?.78:1);
  ctx.save();ctx.globalAlpha=alpha;ctx.globalCompositeOperation='source-over';
  if(pass==='back'){
    bloom(ctx,0,0,7.7,16.2,supply(.4+.018*pulse,.34+.16*pulse),e.color);
    ctx.save();ctx.rotate(Math.atan2(dy,dx));bloom(ctx,7,0,supply(14,12+4*pulse),5.4,supply(.22,.18+.13*pulse),e.color);ctx.restore();
  }else{
    bloom(ctx,0,0,3.8,8.8,supply(.6+.022*pulse,.48+.22*pulse),e.color);
    ctx.strokeStyle=e.color??'#ffdbf8';ctx.lineWidth=.44;ctx.lineCap='round';
    for(const lane of [-1,1]){
      ctx.beginPath();
      for(let i=0;i<=16;i++){
        const p=i/16,along=-9+p*17,across=lane*(1.5*(1-p)+supply(.15,.65)*Math.sin(phase+p*Math.PI));
        const x=dx*along+nx*across,y=dy*along+ny*across;
        i?ctx.lineTo(x,y):ctx.moveTo(x,y);
      }
      ctx.globalAlpha=alpha*supply(.62+.035*Math.sin(phase+lane*.8),.46+.30*(.5+.5*Math.sin(phase+lane*.8)));ctx.stroke();
    }
    // Two small collimation edges agree with the exact emission bearing.
    ctx.globalAlpha=alpha*.38;ctx.lineWidth=.36;
    for(const lane of [-1,1]){
      ctx.beginPath();ctx.moveTo(nx*lane*3.1,ny*lane*3.1);
      ctx.quadraticCurveTo(dx*7+nx*lane*2.1,dy*7+ny*lane*2.1,dx*14+nx*lane*.9,dy*14+ny*lane*.9);ctx.stroke();
    }
    if(powering){
      // Charge travels through the existing aperture towards the shared
      // focus. Fading at both ends makes wraparound invisible; no free
      // particles, emitter cones or independent idle waves are introduced.
      ctx.strokeStyle=e.color??'#ffd5f7';ctx.lineWidth=.85;
      for(let packet=0;packet<3;packet++){
        const p=wrap(phase/TAU+packet/3),along=-8+p*21,half=1.1+.8*Math.sin(Math.PI*p);
        ctx.globalAlpha=alpha*gain*Math.sin(Math.PI*p)*.82;
        ctx.beginPath();ctx.moveTo(dx*along-nx*half,dy*along-ny*half);
        ctx.lineTo(dx*(along+1),dy*(along+1));ctx.lineTo(dx*along+nx*half,dy*along+ny*half);ctx.stroke();
      }
    }
  }
  ctx.restore();
}
