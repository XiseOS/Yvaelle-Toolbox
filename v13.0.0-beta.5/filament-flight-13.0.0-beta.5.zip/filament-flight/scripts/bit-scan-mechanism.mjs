/** The close-examination mechanism follows its viewing phrase rather than
 * the idle clock. These channels reuse the familiar shell, gimbals and core;
 * there is no extra renderer, timer, random choice or scene-light source. */
const PHASES=new Set(['acquire','turn','settle','measure','release']);
const KEYS=['phase','progress','viewIndex','weight','turn'];
const unit=value=>Math.max(0,Math.min(1,Number(value)||0));
const smoother=value=>{const p=unit(value);return p*p*p*(10+p*(-15+6*p));};

/** Saved action captures are untrusted input. Validation is deliberately
 * stricter than the local sampler's normalization: no omitted, extra or
 * coerced fields can survive a treatment/transfer record round-trip. */
export function validScanMechanism(input){
  return !!input&&typeof input==='object'&&!Array.isArray(input)&&Object.keys(input).length===KEYS.length&&
    Object.keys(input).every(key=>KEYS.includes(key))&&KEYS.every(key=>Object.hasOwn(input,key))&&PHASES.has(input.phase)&&
    Number.isFinite(input.progress)&&input.progress>=0&&input.progress<=1&&
    Number.isFinite(input.weight)&&input.weight>=0&&input.weight<=1&&
    Number.isSafeInteger(input.viewIndex)&&input.viewIndex>=0&&Number.isFinite(input.turn);
}

/** Keep only finite local choreography data in interrupted action captures. */
export function captureScanMechanism(input){
  if(!input||typeof input!=='object'||!PHASES.has(input.phase)||!Number.isFinite(input.turn))return null;
  const viewIndex=Number(input.viewIndex);
  return {phase:input.phase,progress:unit(input.progress),viewIndex:Number.isFinite(viewIndex)?Math.max(0,Math.floor(viewIndex)):0,
    weight:input.weight==null?1:unit(input.weight),turn:input.turn};
}

/** One purposeful open / examine / close phrase. The view number describes
 * the physical route, not an extra rotation of the internal machinery. The
 * inner crystal makes one restrained axial stroke while the shell stays
 * aligned; meaningful changes of position and heading belong to the body. */
export function sampleScanMechanism(input){
  const cue=captureScanMechanism(input);if(!cue)return null;
  const p=cue.progress,opening=cue.phase==='measure'?1:cue.phase==='settle'?smoother(p):cue.phase==='release'?1-smoother(p):0;
  // Zero velocity and acceleration at both ends let the small mechanical
  // movement enter and leave the held pose without a kick at the light cue.
  const stroke=cue.phase==='measure'&&p>0&&p<1?64*(p*(1-p))**3:0;
  return {...cue,opening,stroke,channels:{encase:.08*(1-opening),open:.62*opening,charge:.2*opening,
    guard:0,settle:0,scan:.18*opening*stroke,brace:.12+.12*(1-opening),align:.72,rest:0,conduct:0}};
}
