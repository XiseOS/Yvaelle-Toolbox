/** Read-only adapters for Foundry v14's native grid API. World polygons are
 * deliberately kept separate from portrait size/rotation: a token's artwork
 * can be taller than its occupied space without rotating the scene grid. */
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const point=p=>({x:finite(p?.x??p?.[0]),y:finite(p?.y??p?.[1])});
const validPoint=p=>Number.isFinite(p?.x??p?.[0])&&Number.isFinite(p?.y??p?.[1]);
const vertices=value=>Array.isArray(value)?value.filter(validPoint).map(point):[];
const sizeOf=(grid,scene)=>Math.max(.01,finite(grid?.size,finite(scene?.grid?.size,100)));
const isGridless=(grid,scene)=>grid?.isGridless===true||(grid?.type??scene?.grid?.type)===0;
const rectangle=b=>[{x:b.x,y:b.y},{x:b.x+b.width,y:b.y},{x:b.x+b.width,y:b.y+b.height},{x:b.x,y:b.y+b.height}];
export function scanPolygonBounds(polygon=[]){
  if(!polygon.length)return {x:0,y:0,width:0,height:0};
  const xs=polygon.map(p=>p.x),ys=polygon.map(p=>p.y),x=Math.min(...xs),y=Math.min(...ys);
  return {x,y,width:Math.max(...xs)-x,height:Math.max(...ys)-y};
}
export function scanPointInPolygon(p,polygon=[]){
  let inside=false;
  for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){
    const a=polygon[i],b=polygon[j],cross=(p.x-a.x)*(b.y-a.y)-(p.y-a.y)*(b.x-a.x);
    if(Math.abs(cross)<1e-7&&p.x>=Math.min(a.x,b.x)-1e-7&&p.x<=Math.max(a.x,b.x)+1e-7&&p.y>=Math.min(a.y,b.y)-1e-7&&p.y<=Math.max(a.y,b.y)+1e-7)return true;
    if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)inside=!inside;
  }
  return inside;
}
function segmentDistanceSquared(p,a,b){
  const x=b.x-a.x,y=b.y-a.y,t=Math.max(0,Math.min(1,((p.x-a.x)*x+(p.y-a.y)*y)/(x*x+y*y||1)));
  return (p.x-a.x-t*x)**2+(p.y-a.y-t*y)**2;
}
function circleIntersects(polygon,center,radius,bounds){
  if(bounds){
    const right=bounds.x+bounds.width,bottom=bounds.y+bounds.height,r2=radius*radius+1e-7,
      nearX=Math.max(bounds.x-center.x,0,center.x-right),nearY=Math.max(bounds.y-center.y,0,center.y-bottom);
    if(nearX*nearX+nearY*nearY>r2)return false;
    const farX=Math.max(Math.abs(bounds.x-center.x),Math.abs(right-center.x)),farY=Math.max(Math.abs(bounds.y-center.y),Math.abs(bottom-center.y));
    if(farX*farX+farY*farY<=r2)return true;
  }
  if(scanPointInPolygon(center,polygon))return true;
  return polygon.some((p,i)=>segmentDistanceSquared(center,p,polygon[(i+1)%polygon.length])<=radius*radius+1e-7);
}
function segmentsIntersect(a,b,c,d){
  const side=(p,q,r)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x),a1=side(a,b,c),a2=side(a,b,d),b1=side(c,d,a),b2=side(c,d,b);
  if(a1*a2<0&&b1*b2<0)return true;
  const between=(p,q,r)=>r.x>=Math.min(p.x,q.x)-1e-7&&r.x<=Math.max(p.x,q.x)+1e-7&&r.y>=Math.min(p.y,q.y)-1e-7&&r.y<=Math.max(p.y,q.y)+1e-7;
  return Math.abs(a1)<1e-7&&between(a,b,c)||Math.abs(a2)<1e-7&&between(a,b,d)||Math.abs(b1)<1e-7&&between(c,d,a)||Math.abs(b2)<1e-7&&between(c,d,b);
}
export function scanPolygonsOverlap(a=[],b=[]){
  if(a.length<3||b.length<3)return false;
  const x=scanPolygonBounds(a),y=scanPolygonBounds(b);
  if(x.x+x.width<y.x||y.x+y.width<x.x||x.y+x.height<y.y||y.y+y.height<x.y)return false;
  if(a.some(p=>scanPointInPolygon(p,b))||b.some(p=>scanPointInPolygon(p,a)))return true;
  return a.some((p,i)=>b.some((q,j)=>segmentsIntersect(p,a[(i+1)%a.length],q,b[(j+1)%b.length])));
}
const polygonArea=polygon=>Math.abs(polygon.reduce((sum,a,i)=>{const b=polygon[(i+1)%polygon.length];return sum+a.x*b.y-a.y*b.x;},0))/2;
/** Native cells are convex (squares/hexagons). Clipping first excludes the
 * shared boundary edges of adjacent occupied spaces from scan discoveries. */
function clipConvex(subject,clip){
  if(subject.length<3||clip.length<3)return [];
  const signed=clip.reduce((sum,a,i)=>{const b=clip[(i+1)%clip.length];return sum+a.x*b.y-a.y*b.x;},0),orientation=signed<0?-1:1;
  let output=subject;
  for(let i=0;i<clip.length&&output.length;i++){
    const a=clip[i],b=clip[(i+1)%clip.length],side=p=>orientation*((b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x)),input=output;output=[];
    for(let j=0;j<input.length;j++){
      const p=input[j],q=input[(j+1)%input.length],sp=side(p),sq=side(q),pin=sp>=-1e-8,qin=sq>=-1e-8;
      if(pin)output.push(p);
      if(pin!==qin){const t=sp/(sp-sq);output.push({x:p.x+(q.x-p.x)*t,y:p.y+(q.y-p.y)*t});}
    }
  }
  return output;
}
const triangulationCache=new WeakMap();
function polygonTriangles(polygon){
  if(triangulationCache.has(polygon))return triangulationCache.get(polygon);
  const signed=polygon.reduce((sum,a,i)=>{const b=polygon[(i+1)%polygon.length];return sum+a.x*b.y-a.y*b.x;},0),orientation=signed<0?-1:1,remaining=polygon.map((_,i)=>i),triangles=[];
  const cross=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
  for(let guard=0;remaining.length>3&&guard<polygon.length*polygon.length;guard++){
    let found=false;
    for(let i=0;i<remaining.length;i++){
      const ai=remaining[(i+remaining.length-1)%remaining.length],bi=remaining[i],ci=remaining[(i+1)%remaining.length],a=polygon[ai],b=polygon[bi],c=polygon[ci];
      if(cross(a,b,c)*orientation<=1e-8)continue;
      if(remaining.some(j=>j!==ai&&j!==bi&&j!==ci&&cross(a,b,polygon[j])*orientation>=-1e-8&&cross(b,c,polygon[j])*orientation>=-1e-8&&cross(c,a,polygon[j])*orientation>=-1e-8))continue;
      triangles.push([a,b,c]);remaining.splice(i,1);found=true;break;
    }
    if(!found)break;
  }
  if(remaining.length===3)triangles.push(remaining.map(i=>polygon[i]));
  triangulationCache.set(polygon,triangles);return triangles;
}
function overlapsWithArea(subject,cell){return polygonArea(clipConvex(subject,cell))>1e-6;}
const nativeCache=new WeakMap();
const rangeCache=new WeakMap();
const areaCache=new WeakMap(),targetCache=new WeakMap();
const fallbackGrid={};
const gridKey=(grid,scene)=>`${scene?.id??''}:${scene?._stats?.modifiedTime??''}:${grid?.type??scene?.grid?.type??1}:${sizeOf(grid,scene)}:${grid?.sizeX??''}:${grid?.sizeY??''}:${grid?.origin?.x??''}:${grid?.origin?.y??''}`;
function nativeCell(grid,offset,scene,stamp=gridKey(grid,scene)){
  const i=offset.i,j=offset.j,id=`${i}:${j}`;
  let cached=grid&&nativeCache.get(grid);
  // A moving following circle can visit thousands of already-known cells per
  // display frame. Compare the grid revision once at entry, then keep those
  // lookups to a short native offset instead of rebuilding a full scene/grid
  // signature for every cache hit. Geometry still expires on every old stamp.
  if(cached?.stamp!==stamp){cached=null;if(grid&&typeof grid==='object')nativeCache.set(grid,cached={stamp,cells:new Map()});}
  if(cached?.cells.has(id))return cached.cells.get(id);
  const size=sizeOf(grid,scene);
  let polygon=[],center;
  try{polygon=vertices(grid?.getVertices?.(offset));center=grid?.getCenterPoint?.(offset);}catch{/* A removed/unsupported native grid falls through below. */}
  if(polygon.length<3){
    // Only a square grid has a reliable rectangular fallback. A missing hex
    // adapter uses free coverage instead of drawing false square hex cells.
    if(grid?.isHexagonal||(grid?.type??scene?.grid?.type)>1)return null;
    let top;
    try{top=grid?.getTopLeftPoint?.(offset);}catch{}
    top=validPoint(top)?top:{x:finite(grid?.origin?.x)+j*size,y:finite(grid?.origin?.y)+i*size};
    polygon=rectangle({x:top.x,y:top.y,width:size,height:size});
  }
  const bounds=scanPolygonBounds(polygon);
  center=validPoint(center)?point(center):{x:bounds.x+bounds.width/2,y:bounds.y+bounds.height/2};
  const result={id,offset:{i,j},center,polygon,bounds};
  if(cached){if(cached.cells.size>=4096)cached.cells.delete(cached.cells.keys().next().value);cached.cells.set(id,result);}
  return result;
}
function nativeRangeCells(grid,scene,stamp,range,owner,remember=true){
  let cached=remember?rangeCache.get(owner):null;if(remember&&cached?.stamp!==stamp)rangeCache.set(owner,cached={stamp,ranges:new Map()});
  const key=range.join(':');
  if(cached?.ranges.has(key)){const hit=cached.ranges.get(key);cached.ranges.delete(key);cached.ranges.set(key,hit);return hit;}
  const [i0,j0,i1,j1]=range,cells=[];let visited=0;
  // Fractional following movement usually retains the same exclusive offset
  // range. Reuse its native geometry roster; circle/region membership below
  // is still recomputed against the exact current centre on every call.
  for(let i=i0;i<i1&&visited<16384;i++)for(let j=j0;j<j1&&visited++<16384;j++){
    const cell=nativeCell(grid,{i,j},scene,stamp);if(cell)cells.push(cell);
  }
  if(cached){if(cached.ranges.size>=32)cached.ranges.delete(cached.ranges.keys().next().value);cached.ranges.set(key,cells);}return cells;
}
/** Native square/hex cell geometry, with an empty roster on gridless scenes.
 * getOffsetRange's upper bounds are exclusive (Foundry v14 BaseGrid docs).
 * The shared caches are LRU: a following scan's per-frame keys cannot evict a
 * fixed scan that is read every frame. `cache:false` (local editors, such as
 * the region picker) computes without reading or filling the shared caches. */
export function scanSceneContext({center={x:0,y:0},radius=100,region,grid=globalThis.canvas?.grid,scene=globalThis.canvas?.scene,cache:shared=true}={}){
  center=point(center);radius=Math.max(.01,finite(radius,100));
  const regionPolygon=Array.isArray(region?.points)&&region.points.length>=3?region.points:null;
  const stamp=gridKey(grid,scene),owner=grid&&typeof grid==='object'?grid:fallbackGrid,key=`${stamp}:${center.x}:${center.y}:${radius}:${regionPolygon?JSON.stringify(regionPolygon):''}`;
  let cache=shared?areaCache.get(owner):null;
  if(cache?.has(key)){const hit=cache.get(key);cache.delete(key);cache.set(key,hit);return hit;}
  const remember=value=>{if(!shared)return value;if(!cache)areaCache.set(owner,cache=new Map());if(cache.size>=32)cache.delete(cache.keys().next().value);cache.set(key,value);return value;};
  const gridless=isGridless(grid,scene),size=sizeOf(grid,scene),bounds={x:center.x-radius,y:center.y-radius,width:radius*2,height:radius*2};
  if(gridless)return remember({cells:[],gridless:true,native:false,cacheKey:`${stamp}:gridless`});
  let range;
  try{range=grid?.getOffsetRange?.(bounds);}catch{}
  if(!Array.isArray(range)||range.length<4||!range.every(Number.isFinite)){
    if(grid?.isHexagonal||(grid?.type??scene?.grid?.type)>1)return remember({cells:[],gridless:false,native:false,cacheKey:`${stamp}:free`});
    const x=finite(grid?.origin?.x),y=finite(grid?.origin?.y);
    range=[Math.floor((bounds.y-y)/size),Math.floor((bounds.x-x)/size),Math.ceil((bounds.y+bounds.height-y)/size),Math.ceil((bounds.x+bounds.width-x)/size)];
  }
  const cells=[];
  // The API limits scan radii; this final guard also handles corrupted scene
  // scales without blocking the render thread. Ordinary 120-foot areas fit.
  for(const cell of nativeRangeCells(grid,scene,stamp,range.map(Math.trunc),owner,shared)){
    if(circleIntersects(cell.polygon,center,radius,cell.bounds)&&(!regionPolygon||polygonTriangles(regionPolygon).some(triangle=>overlapsWithArea(triangle,cell.polygon))))cells.push(cell);
  }
  return remember({cells,gridless:false,native:!!grid?.getVertices,center,radius,cacheKey:stamp});
}
function boundaryPolygons(cells){
  const key=p=>`${Math.round(p.x*1e5)},${Math.round(p.y*1e5)}`,edges=new Map();
  for(const {polygon}of cells)for(let i=0;i<polygon.length;i++){
    const a=polygon[i],b=polygon[(i+1)%polygon.length],ka=key(a),kb=key(b),reverse=`${kb}|${ka}`,forward=`${ka}|${kb}`;
    if(edges.has(reverse))edges.delete(reverse);else edges.set(forward,{a,b,ka,kb});
  }
  const outgoing=new Map();for(const edge of edges.values()){const list=outgoing.get(edge.ka)??[];list.push(edge);outgoing.set(edge.ka,list);}
  const polygons=[];
  while(edges.size){
    const first=edges.values().next().value,polygon=[first.a];let edge=first;
    for(let step=0;step<cells.length*8+8;step++){
      edges.delete(`${edge.ka}|${edge.kb}`);polygon.push(edge.b);if(edge.kb===first.ka)break;
      edge=outgoing.get(edge.kb)?.find(e=>edges.has(`${e.ka}|${e.kb}`));if(!edge)break;
    }
    if(polygon.length>=4){polygon.pop();polygons.push(polygon);}
  }
  const area=p=>Math.abs(p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a.x*b.y-a.y*b.x;},0));
  return polygons.sort((a,b)=>area(b)-area(a));
}
/** Snapshot the full occupied grid footprint and the unrotated portrait.
 * Native occupancy remains correct for large, hex, and non-square tokens. */
export function targetScanContext(token,{grid=globalThis.canvas?.grid,scene=globalThis.canvas?.scene}={}){
  const document=token?.document??token??{},size=sizeOf(grid,scene),mesh=token?.mesh,stamp=gridKey(grid,scene);
  const key=JSON.stringify([stamp,token?.x,token?.y,token?.w,token?.h,document.x,document.y,document.width,document.height,document.elevation,document.level,
    document.shape?.type??(typeof document.shape==='string'?document.shape:null),document.hexagonalShape??null,document._stats?.modifiedTime,mesh?.width,mesh?.height,mesh?.rotation,document.rotation]);
  const previous=token&&targetCache.get(token);if(previous&&previous.grid===grid&&previous.key===key)return previous.value;
  let actualSize;
  try{actualSize=document.getSize?.();}catch{}
  const width=Math.max(1,finite(token?.w,finite(actualSize?.width,finite(document.width,1)*size))),height=Math.max(1,finite(token?.h,finite(actualSize?.height,finite(document.height,1)*size)));
  const bounds={x:finite(token?.x,finite(document.x)),y:finite(token?.y,finite(document.y)),width,height};
  let occupied=[];
  if(!isGridless(grid,scene))try{occupied=document.getOccupiedGridSpaceOffsets?.()??[];}catch{}
  const cells=occupied.map(offset=>nativeCell(grid,offset,scene,stamp)).filter(Boolean),polygons=boundaryPolygons(cells),polygon=polygons[0]??rectangle(bounds);
  const footprintBounds=scanPolygonBounds(polygons.flat().length?polygons.flat():polygon);
  const value={occupiedFootprint:{polygon,polygons:polygons.length?polygons:[polygon],bounds:footprintBounds,cells},
    portrait:{width:Math.max(width,Math.abs(finite(mesh?.width))),height:Math.max(height,Math.abs(finite(mesh?.height))),rotation:finite(mesh?.rotation,finite(document.rotation)*Math.PI/180)}};
  if(token&&typeof token==='object')targetCache.set(token,{grid,key,value});return value;
}
/** Visibility is evaluated before geometry, so hidden or undetected tokens
 * cannot alter a player's route or reveal an encounter through a scan. */
export function scanTokenVisible(token,{scene=globalThis.canvas?.scene,source}={}){
  if(!token||token.destroyed||token.isPreview||token._original||token===source||token.id&&token.id===source?.id)return false;
  const document=token.document??{};
  if(scene?.id&&document.parent?.id&&scene.id!==document.parent.id)return false;
  if(document.hidden||!token.mesh||token.mesh.visible===false||token.mesh.renderable===false)return false;
  if(token.visible===false||token.renderable===false||token.isVisible===false||token.detectionFilter)return false;
  // A real placeable supplies isVisible; document-only candidates are never
  // used for automatic discovery, since they have no user-visibility result.
  return token.isVisible===true||token.visible===true;
}
export function scanCellIntersectsToken(cell,token,options={}){
  if(!scanTokenVisible(token,options))return false;
  const footprint=targetScanContext(token,options).occupiedFootprint;
  const cells=cell?.cells?.length?cell.cells:[cell],region=cell?.scanRegionPolygon,triangles=region?.length>=3?polygonTriangles(region):null;
  for(const native of cells){
    const boundary=native?.polygon??rectangle(native?.bounds??{x:0,y:0,width:0,height:0});
    for(const polygon of footprint.polygons){
      const intersection=clipConvex(polygon,boundary);if(polygonArea(intersection)<=1e-6)continue;
      const pieces=triangles?triangles.map(triangle=>clipConvex(intersection,triangle)):[intersection];
      if(pieces.some(piece=>polygonArea(piece)>1e-6&&(!cell.clipCircle||circleIntersects(piece,cell.clipCircle.center,cell.clipCircle.radius))))return true;
    }
  }
  return false;
}
