/** V7.1 patient-local reconstructions of four older medical mechanisms.
 * These are bounded surfaces and instruments, never inferred anatomy or rules.
 * A single deterministic clock drives material, tools and energy; patient fill
 * stays translucent. The live renderer extracts tagged source apertures into
 * its existing small, display-rate crystal attachments; standalone previews
 * retain those authored paths in the patient-local reference frame. */
export const REFINED_MEDKIT_STYLES=Object.freeze(['suture','microloom','splint','mendingVeil']);
const SPECS=Object.freeze({suture:{period:4.9,bounds:[65,66]},microloom:{period:5.8,bounds:[70,72]},splint:{period:4.8,bounds:[71,72]},mendingVeil:{period:5.8,bounds:[67,75]}});
const TAU=Math.PI*2,PINK='#ff75d8',PEARL='#ffdff6',GOLD='#e5c8ad',PALE='#ffb2e7';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,Number(v)||0));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
const mix=(a,b,p)=>a+(b-a)*p,wrap=v=>(v%1+1)%1;
const bez=(a,b,c,d,u)=>{const v=1-u;return [v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*c[0]+u*u*u*d[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*c[1]+u*u*u*d[1]];};
const rotate=(x,y,a)=>[x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a)];

export function refinedMedkitBounds(effect){
  const spec=SPECS[effect?.style];if(!spec)return null;
  let left=-spec.bounds[0],right=spec.bounds[0],top=-spec.bounds[1],bottom=spec.bounds[1];
  for(const e of effect.emitters??[])for(const p of [e,e.workPoint].filter(Boolean)){
    left=Math.min(left,p.x*100-7);right=Math.max(right,p.x*100+7);
    top=Math.min(top,p.y*100-7);bottom=Math.max(bottom,p.y*100+7);
  }
  return {x:left-5,y:top-5,width:right-left+10,height:bottom-top+10};
}

/** The treating frame and finishing progress zero are identical, including
 * every material and energy path. Outcomes continuously close or release the
 * mechanism; outcome-specific finishing artwork is supplied separately. */
export function sampleRefinedMedkitTreatment(effect){
  const spec=SPECS[effect?.style];if(!spec)return null;
  const quality=effect.detail==='low'?0:effect.detail==='high'?2:1,steps=[8,12,16][quality];
  const animated=effect.animated!==false,t=animated?Math.max(0,Number(effect.clock)||0):0,k=t/spec.period*TAU;
  const scanning=effect.phase==='scanning',finishing=effect.phase==='finishing',p=clamp(effect.progress),scanP=clamp(effect.scan??p);
  const success=finishing&&['success','criticalSuccess'].includes(effect.outcome);
  const closure=success?smooth(p/.84):0,release=finishing&&!success?smooth(p):0;
  const fade=finishing?1-smooth((p-.57)/.43):1,entry=scanning?smooth(scanP/.82):1;
  const strength=clamp(effect.strength??1,0,2),count=clamp(Math.round(effect.emitters?.length??1),1,4),paths=[];
  const frame={id:effect.style,color:'#ff00ff',strength,count,paths,emitters:[],bounds:refinedMedkitBounds(effect),phase:effect.phase,treatment:true,outcome:effect.outcome??null,
    activation:{charge:entry,projection:entry,sustain:entry}};
  if(!strength||!fade)return frame;
  const add=(points,{alpha=.6,width=.7,plane='front',closed=false,fill=0,highlight=false,glow=false,tint=PINK,fillTint=tint,role='structure',emitterId}={})=>{
    const a=clamp(alpha*strength*fade),f=clamp(fill*strength*fade,0,.13);if(points.length<2||a+f<.00001)return;
    paths.push({points,alpha:a,width,plane,closed,fill:f,highlight,glow:glow&&quality>0,tint,fillTint,role,...(emitterId==null?{}:{emitterId})});
  };
  const curve=(fn,o={})=>{const n=o.steps??steps,points=new Array(n+1);for(let i=0;i<=n;i++)points[i]=fn(i/n);add(points,o);};
  const cubic=(a,b,c,d,o={})=>curve(u=>bez(a,b,c,d,u),o);
  const line=(a,b,o={})=>add([a,b],o);
  const ellipse=(x,y,rx,ry,o={})=>curve(u=>[x+Math.cos(u*TAU)*rx,y+Math.sin(u*TAU)*ry],{...o,closed:true,steps:quality===0?10:16});
  const panel=(curves,o={})=>{const points=[];for(const [a,b,c,d]of curves)for(let i=0;i<=(quality?6:4);i++)points.push(bez(a,b,c,d,i/(quality?6:4)));add(points,{...o,closed:true});};
  const packet=(fn,phase=0,o={})=>{
    const q=animated?wrap(t/spec.period+phase):.53,on=animated?Math.sin(Math.PI*q)**2:.7;
    curve(u=>fn(mix(Math.max(0,q-.065),q,u)),{...o,steps:3,alpha:(o.alpha??.78)*on*entry,width:1.45,highlight:true,glow:true,role:'energy-packet'});
  };
  const metal={alpha:.74*entry,width:.9,tint:PEARL},gold={alpha:.64*entry,width:.65,tint:GOLD},fine={alpha:.28*entry,width:.45,tint:PALE};

  if(effect.style==='suture'){
    // Paired tapered hardlight margins, bevelled outer edges and gently bowed
    // stitch loops form a supported seam. Needle holders move with the real
    // left/right operating contacts instead of unrelated circulating marks.
    const a=-.42,tr=(x,y)=>rotate(x,y,a),gap=(6+.45*Math.sin(k))*(1-closure*.92)+release*8;
    const rows=[5,7,9][quality],needleTravel=31*Math.cos(k);
    for(const s of [-1,1]){
      const y0=-39,y1=39,inner=s*gap,outer=s*(gap+18);
      const edges=[
        [tr(inner,y0),tr(s*(gap+3),-15),tr(s*(gap-2),18),tr(inner,y1)],
        [tr(inner,y1),tr(s*(gap+8),43),tr(s*(gap+16),31),tr(outer,12)],
        [tr(outer,12),tr(s*(gap+21),-5),tr(s*(gap+18),-31),tr(s*(gap+10),-40)],
        [tr(s*(gap+10),-40),tr(s*(gap+7),-43),tr(s*(gap+3),-42),tr(inner,y0)]
      ];
      panel(edges,{alpha:.43*entry,width:.9,fill:.13*entry,tint:PALE});
      // An inset material ridge catches a broad, dim reflection beneath its
      // pearl rim. This makes the treatment margin a bonded flexible surface,
      // rather than an extra wire tracing the seam.
      cubic(tr(s*(gap+2.8),-34),tr(s*(gap+5.1),-11),tr(s*(gap+1.3),12),tr(s*(gap+2.8),34),{alpha:.26*entry,width:4.1,tint:PEARL});
      cubic(tr(s*(gap+15),-34),tr(s*(gap+24),-14),tr(s*(gap+21),19),tr(s*(gap+12),33),{...fine,alpha:.42*entry,width:1.05,tint:GOLD});
      cubic(tr(inner,-36),tr(s*(gap+2),-12),tr(s*(gap-2),12),tr(inner,36),{...metal,alpha:.73*entry,width:1.05,glow:true});
      for(const y of [-34,34])add([tr(s*(gap+8),y-3),tr(s*(gap+15),y-2),tr(s*(gap+15),y+2),tr(s*(gap+8),y+3)],{...gold,closed:true,fill:.06*entry});
      const y=s*needleTravel,holder=tr(s*(gap+12),y),contact=tr(s*gap,y);
      ellipse(...holder,2.7,2.7,{...gold,width:.8});
      const armA=tr(s*(gap+14),y-s*8),armB=tr(s*(gap+5),y-s*10),arm=u=>bez(holder,armA,armB,contact,u);
      curve(arm,{...metal,width:1.05});curve(u=>arm(u*.7),{...gold,width:.48});
      cubic(contact,tr(s*(gap+5),y+4),tr(-s*(gap+3),y+5),tr(-s*gap,y+1),{alpha:.53*entry,width:.55,tint:PEARL});
    }
    for(let j=0;j<rows;j++){
      const y=-31+j*62/(rows-1),built=scanning?smooth(scanP*1.55-j/(rows-1)*.47):1;
      const tension=.5+.24*Math.sin(k+j*.63),bow=(5.4-3.2*tension)*(1-closure)+release*3;
      const a=tr(-gap,y-2.2),b=tr(-gap-4,y-bow),c=tr(gap+4,y+bow),d=tr(gap,y+2.2),fn=u=>bez(a,b,c,d,u);
      curve(fn,{alpha:.76*entry*built*(1-release*.78),width:.86,tint:PEARL});
      if(quality>0)cubic(tr(-gap,y+2.2),tr(-gap-3,y+bow*.8),tr(gap+3,y-bow*.8),tr(gap,y-2.2),{alpha:.32*entry*built*(1-release*.78),width:.45,tint:GOLD});
      // Small rounded eyelets seat each tensioned strand in its own margin.
      for(const s of [-1,1])ellipse(...tr(s*gap,y+s*2.2),1.15,1.15,{alpha:.68*entry*built,width:.55,tint:GOLD});
      if(j%2===0)packet(fn,j/(rows+1),{alpha:.52*built*(1-release)});
    }
    for(const s of [-1,1])cubic(tr(s*30,-43),tr(s*45,-18),tr(s*45,18),tr(s*30,43),{...fine,plane:'rear',alpha:.19*entry});
  }

  if(effect.style==='microloom'){
    // A curved woven dressing is suspended within a dimensional microloom.
    // Warp yarns visibly dip below the weft and rise at alternate crossings.
    // The eye-shaped shuttle physically pulls its thread from a side bobbin.
    const angle=-.55,tr=(x,y)=>rotate(x+.08*y,y*.9,angle),w=29,h=34;
    const n=[5,7,9][quality],threadPitch=2*w/(n-1),rowPitch=2*h/(n-1),lift=(1-closure)*1.4;
    const cloth=(x,y)=>tr(x,y+.7*Math.sin(k)*Math.sin(Math.PI*(x+w)/(2*w))*(1-closure));
    const spread=release*5+(scanning?5*(1-entry):0);
    for(const s of [-1,1]){
      const x=s*(w+8+spread),rail=[[x-s*3,-h-9],[x+s*4,-h-6],[x+s*4,h+6],[x-s*3,h+9]];
      add(rail.map(([x,y])=>tr(x,y)),{...metal,width:1.2,closed:true,fill:.10*entry});
      line(tr(x+s*2,-h-4),tr(x+s*2,h+4),{...gold,width:1.1});
      for(const y of [-h-5,h+5]){
        add([[x-s*2,y-3],[x+s*5,y-2],[x+s*5,y+2],[x-s*2,y+3]].map(([x,y])=>tr(x,y)),{...gold,closed:true});
        ellipse(...tr(x,y),1.5,1.5,{alpha:.8*entry,width:.75,tint:PEARL});
      }
    }
    for(const s of [-1,1]){
      add([[-w-5,s*(h+5)],[-w-2,s*(h+9)],[w+2,s*(h+9)],[w+5,s*(h+5)]].map(([x,y])=>tr(x,y)),{...gold,closed:true,fill:.027*entry});
      cubic(tr(-w,s*(h+1)),tr(-w/3,s*(h+4)),tr(w/3,s*(h+4)),tr(w,s*(h+1)),{...metal,width:.75});
    }
    const clothAlpha=entry*(1-release*.85);
    // Narrow translucent ribbon faces supply fabric depth without obscuring
    // the portrait behind a checkerboard. Crossings are authored gaps, not
    // bright random lines or moving dust.
    for(let i=0;i<n;i++){
      const x=-w+i*threadPitch,built=scanning?smooth(scanP*1.8-i/(n-1)*.47):1;
      // Broad translucent yarn faces carry the weave at normal token size;
      // the existing alternating crossings supply detail without more wires.
      curve(u=>cloth(x,-h+2*h*u),{alpha:.40*clothAlpha*built,width:2.8,tint:PALE});
      for(let j=0;j<n-1;j++){
        const y=-h+j*rowPitch,under=(i+j)%2===0,offset=under?rowPitch*.22:0;
        cubic(cloth(x,y+offset),cloth(x-lift,y+rowPitch*.36),cloth(x+lift,y+rowPitch*.66),cloth(x,y+rowPitch-offset),{alpha:(under?.35:.65)*clothAlpha*built,width:under?.48:.68,tint:under?GOLD:PEARL,steps:4});
      }
    }
    for(let j=0;j<n;j++){
      const y=-h+j*rowPitch,built=scanning?smooth(scanP*1.8-j/(n-1)*.47):1;
      curve(u=>cloth(-w+2*w*u,y+lift*.32*Math.cos(u*Math.PI*(n-1))),{alpha:.60*clothAlpha*built,width:.68,tint:j%2?GOLD:PEARL});
    }
    const shuttleX=26*Math.sin(k*3),shuttleY=-26.18*Math.cos(k),bobbin=tr(-w-8,-h+5);
    const sampled=cloth(shuttleX,shuttleY),contact=effect.emitters?.[0]?.workPoint;
    // The real shuttle conductor and projected shuttle share the contact,
    // including the lone bit's complementary-job handoff. A local translation
    // retains the shuttle's cloth perspective without an independent orbit.
    const contactGain=scanning?smooth((scanP-.45)/.55):1;
    const shuttle=contact?[mix(sampled[0],contact.x*100,contactGain),mix(sampled[1],contact.y*100,contactGain)]:sampled;
    const shift=[shuttle[0]-sampled[0],shuttle[1]-sampled[1]],at=(x,y)=>{const q=cloth(x,y);return [q[0]+shift[0],q[1]+shift[1]];};
    const threadA=tr(-w+5,-h+9),threadB=at(shuttleX-10,shuttleY+6),thread=u=>bez(bobbin,threadA,threadB,shuttle,u);
    curve(thread,{alpha:.69*entry*(1-release),width:.7,tint:PEARL});packet(thread,.32,{alpha:.55*(1-release)});
    const body=[[-6.5,0],[-3.2,-2.7],[3.7,-2.7],[7,0],[3.7,2.7],[-3.2,2.7]].map(([x,y])=>at(shuttleX+x,shuttleY+y));
    add(body,{...metal,width:1.1,closed:true,fill:.13*entry});line(at(shuttleX-3,shuttleY),at(shuttleX+3.5,shuttleY),{...gold,width:1});
    for(const s of [-1,1])cubic(tr(s*43,-43),tr(s*49,-20),tr(s*49,20),tr(s*43,43),{...fine,plane:'rear',alpha:.2*entry});
  }

  if(effect.style==='splint'){
    // Two tangible hinged braces hold segmented pressure pads. Broad bevelled
    // plates, inset rails and pivot caps have distinct materials; depth bands
    // wrap behind the patient instead of laying a rectangle over the portrait.
    const spread=release*8+(scanning?9*(1-entry):0),ys=[-32,0,32];
    for(const s of [-1,1]){
      const centers=ys.map((y,j)=>[s*(42+spread+(j===1?-2:1)),y]);
      for(let j=0;j<3;j++){
        const [x,y]=centers[j],built=scanning?smooth(scanP*1.55-j*.20):1;
        const angle=s*(.07*Math.sin(k+j*.45)*(1-closure)+release*.19),tr=(dx,dy)=>{const r=rotate(dx*s,dy,angle);return [x+r[0],y+r[1]];};
        const plate=[[-7,-12],[5,-15],[12,-10],[14,7],[6,14],[-7,11]].map(([x,y])=>tr(x,y));
        add(plate,{alpha:.8*entry*built,width:1.02,tint:PEARL,fill:.13*entry*built,closed:true,glow:true});
        // Two bevel faces and an inset reflection distinguish plate thickness
        // from its outline. Their fills stay localized at the outside support
        // stations, keeping the treatment's central working field open.
        add([[-7,-12],[5,-15],[12,-10],[10,-7],[4,-11],[-5,-8]].map(([x,y])=>tr(x,y)),{alpha:.58*entry*built,width:.7,tint:GOLD,fill:.075*entry*built,closed:true});
        add([[12,-10],[14,7],[6,14],[5,10],[11,6],[10,-7]].map(([x,y])=>tr(x,y)),{alpha:.55*entry*built,width:.7,tint:PALE,fill:.09*entry*built,closed:true});
        add([tr(7,-10),tr(10,-7),tr(12,6),tr(5,10)],{alpha:.62*entry*built,width:2.35,tint:GOLD});
        const catchLight=.22+.04*Math.sin(k+j*.6+s*.3);
        line(tr(-4,-6),tr(6,-9),{alpha:catchLight*entry*built,width:3.6,tint:PEARL});
        add([tr(-3,-8),tr(4,-10),tr(8,-5),tr(9,5),tr(3,8),tr(-3,6)],{alpha:.34*entry*built,width:.55,tint:PALE,closed:true,fill:.017*entry*built});
        line(tr(-7,-8),tr(-7,7),{alpha:.85*entry*built,width:1.15,tint:PEARL});
        ellipse(...tr(2,0),2.3,2.3,{alpha:.80*entry*built,width:.8,tint:GOLD,fill:.085*entry*built});
        line(tr(1.2,-1.3),tr(2.8,1.3),{alpha:.78*entry*built,width:.7,tint:PEARL});
        if(quality>0)for(let r=0;r<3;r++)line(tr(-1,-5+r*5),tr(3,-5+r*5),{alpha:.38*entry*built,width:.45,tint:GOLD});
      }
      for(let j=0;j<2;j++){
        const a=centers[j],b=centers[j+1],y=(a[1]+b[1])/2,x=s*(47+spread);
        add([[a[0]+s*5,a[1]+13],[x,y-4],[x,y+4],[b[0]+s*5,b[1]-13]],{alpha:.72*entry,width:1.25,tint:GOLD});
        ellipse(x,y,3.1,3.1,{...metal,width:.9,fill:.1*entry});
        ellipse(x-.3*s,y-.4,1.25,1.25,{...gold,width:.65,fill:.055*entry});
      }
      const rail=u=>[s*(48+spread+Math.sin(u*Math.PI)*2),-44+88*u];
      curve(rail,{alpha:.22*entry,width:.45,tint:PALE});packet(rail,s<0?.08:.58,{alpha:.55});
    }
    for(const [j,y]of ys.entries()){
      const built=scanning?smooth(scanP*1.55-j*.20):1,w=42+spread;
      cubic([-w,y],[-32,y-9],[32,y-9],[w,y],{alpha:.16*entry*built,width:4.3,tint:PEARL,plane:'rear'});
      cubic([-w,y],[-32,y-9],[32,y-9],[w,y],{alpha:.25*entry*built,width:.8,tint:PALE,plane:'rear'});
      if(j!==1||quality>0){
        cubic([-w,y+2],[-27,y+11],[27,y+11],[w,y+2],{alpha:.18*entry*built,width:3.4,tint:PEARL});
        cubic([-w,y+2],[-27,y+11],[27,y+11],[w,y+2],{alpha:.31*entry*built,width:1.05,tint:PEARL});
        if(quality>0)cubic([-w,y+5],[-27,y+14],[27,y+14],[w,y+5],{alpha:.15*entry*built,width:.5,tint:GOLD});
      }
    }
  }

  if(effect.style==='mendingVeil'){
    // Two gently lofted transparent sheets carry curved contours and folded
    // hems. A luminous bonding front follows their suspended surface. The
    // distinct drape and nested membranes replace the old rectangular sheets.
    const halfWidth=39+count*2,gap=(7+.65*Math.sin(k))*(1-closure*.9)+release*13;
    const breath=(animated?Math.sin(k)*1.2:0)*(1-closure),rows=[3,4,5][quality];
    for(const s of [-1,1]){
      const inner=u=>[s*(gap+Math.sin(u*Math.PI)*(2+breath)), -48+96*u];
      const outer=u=>[s*(halfWidth+Math.sin(u*Math.PI)*(7+breath)), -48+96*u];
      const rim=[],n=steps;for(let i=0;i<=n;i++)rim.push(inner(i/n));
      for(let i=1;i<=4;i++)rim.push(bez(inner(1),[s*(gap+10),56],[s*(halfWidth-9),56],outer(1),i/4));
      for(let i=n-1;i>=0;i--)rim.push(outer(i/n));
      for(let i=1;i<4;i++)rim.push(bez(outer(0),[s*(halfWidth-9),-56],[s*(gap+10),-56],inner(0),i/4));
      add(rim,{alpha:.36*entry*(1-release*.7),width:.9,closed:true,fill:(s<0?.085:.115)*entry*(1-release),tint:PALE,plane:s<0?'rear':'front'});
      // A narrow folded hem adds readable material thickness and suspension.
      const hem=[];for(let i=0;i<=n;i++)hem.push(outer(i/n));for(let i=n;i>=0;i--){const q=outer(i/n);hem.push([q[0]-s*2.4,q[1]+.7]);}
      add(hem,{alpha:.37*entry,width:.55,closed:true,fill:.013*entry,tint:GOLD,plane:s<0?'rear':'front'});
      curve(inner,{alpha:.63*entry*(1-release*.65),width:.95,tint:PEARL});
      // Curved specular bands within the membrane distinguish its material
      // from a plain wire cage; they remain below full body opacity.
      if(quality>0)for(const f of [.23,.78])curve(u=>{
        const a=inner(u),b=outer(u);return [mix(a[0],b[0],f),a[1]];
      },{alpha:(f<.5?.22:.28)*entry*(1-release),width:f<.5?2.6:3.4,tint:PEARL,plane:s<0?'rear':'front'});
      for(let j=0;j<rows;j++){
        const q=(j+1)/(rows+1),y=-48+96*q,built=scanning?smooth(scanP*1.5-q*.44):1,x1=inner(q)[0],x2=outer(q)[0];
        const fn=u=>[mix(x1,x2,u),y+Math.sin(Math.PI*u)*(4+breath+1.3*Math.sin(k+j*.6))];
        curve(fn,{alpha:.30*entry*built*(1-release),width:.5,tint:PALE,plane:s<0?'rear':'front'});
        if(quality>0&&j%2===0)curve(u=>{const q=fn(u);return [q[0],q[1]+2.3];},{alpha:.13*entry*built*(1-release),width:.45,tint:GOLD,plane:s<0?'rear':'front'});
      }
      for(const y of [-48,48]){
        const x=s*halfWidth;add([[x-s*5,y-2],[x+s*3,y-4],[x+s*5,y+1],[x-s*3,y+3]],{...gold,closed:true,fill:.024*entry});
        cubic([s*gap,y],[s*(gap+9),y+(y<0?-4:4)],[s*(halfWidth-8),y+(y<0?-4:4)],[x,y],{...metal,alpha:.5*entry,width:.7});
      }
    }
    const sweep=.5-.5*Math.cos(scanning?scanP*TAU:k),y=-43+86*sweep,bond=u=>[-halfWidth+2*halfWidth*u,y+Math.sin(Math.PI*u)*(7+breath)];
    const wave=Array.from({length:steps+1},(_,i)=>bond(i/steps));
    const ribbon=wave.concat([...wave].reverse().map(([x,y])=>[x,y+2.6]));
    add(ribbon,{alpha:.24*entry*(1-release),fill:.058*entry*(1-release),width:.55,closed:true,tint:PALE});
    curve(bond,{alpha:.65*entry*(1-release),width:.9,tint:PEARL,glow:true});
    for(let j=0;j<3;j++){
      const y=-29+j*29,opening=(gap+2)*(1-closure*.25),x=opening;
      cubic([-x,y-2],[-x*.65,y+5],[x*.65,y+5],[x,y-2],{alpha:.52*entry*(1-release),width:.76,tint:GOLD});
      if(quality>0)cubic([-x,y-3],[-x*.4,y+1],[x*.4,y+1],[x,y-3],{alpha:.33*entry*(1-release),width:.5,tint:PEARL});
    }
  }

  // The same sampled real contact powers every mechanism. Packets dim before
  // wrapping, so the open feed never resets with a bright visible jump. The
  // source crystal diamond remains in the root renderer's attached layer.
  for(let i=0;i<(effect.emitters??[]).length;i++){
    const e=effect.emitters[i],from=[e.x*100,e.y*100],target=[Number(e.workPoint?.x??0)*100,Number(e.workPoint?.y??0)*100],plane=e.z<0?'rear':'front';
    const bow=(i%2?1:-1)*4,a=[mix(from[0],target[0],.33),from[1]+bow],b=[mix(from[0],target[0],.72),target[1]-bow],fn=u=>bez(from,a,b,target,u);
    const activity=clamp(e.activity??.5),power=(.28+activity*.35)*entry*(1-release)*(1-closure*.55),feed=scanning?smooth(scanP*1.3):1;
    curve(u=>fn(u*feed),{alpha:power,width:.55,plane,tint:PALE,glow:true,role:'emitter-feed',emitterId:e.id??i,steps:8});
    packet(fn,i*.19,{alpha:power,plane,emitterId:e.id??i});
    if(effect.style==='mendingVeil'){
      // Retain the original veil's exact source-diamond shape and interface.
      // The production renderer extracts this tag before patient painting and
      // follows the real bit each display frame; it is not a second moving
      // housing painted into the capped patient field. Keep its authored glow
      // at every detail level, including the original low-detail fallback.
      const build=scanning?smooth(scanP*1.6-i*.07):1,r=2.6+(.6+.5*Math.sin(k+i))*build;
      const apertureAlpha=clamp(.65*build*(1-release)*(.38+count*.155)*strength*fade);
      if(apertureAlpha>.00001)paths.push({points:[[from[0],from[1]-r],[from[0]+r*.65,from[1]],[from[0],from[1]+r],[from[0]-r*.65,from[1]]],
        plane,alpha:apertureAlpha,width:.8,fill:0,closed:true,highlight:true,glow:true,role:'emitter-aperture',emitterId:e.id??i});
    }
    ellipse(...target,1.8,1.05,{alpha:.54*entry*(1-release),width:.62,plane,tint:PEARL,role:'work-contact',emitterId:e.id??i});
    frame.emitters.push({...e,from,port:target,plane});
  }
  return frame;
}
