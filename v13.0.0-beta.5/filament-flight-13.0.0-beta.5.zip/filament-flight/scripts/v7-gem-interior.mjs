/** Optional v7 crystal optics. Geometry uses the actual three-dimensional
 * crystal space, then the same housing projection and depth sort as its skin.
 * No sprite, auxiliary ticker, bloom surface or scene light is allocated. */
const TAU=2*Math.PI;
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const unit=n=>Math.max(0,Math.min(1,finite(n)));
const DETAIL=Object.freeze({low:{layers:1,segments:10},medium:{layers:2,segments:16},high:{layers:3,segments:24}});
// Fixed sample topology is shared by every crystal. Its angles, endpoint
// fractions and envelope powers are exactly the original expressions; only
// the live clock, radius and perspective are evaluated for each picture.
const VOLUME_RINGS=Array.from({length:3},(_,layer)=>Array.from({length:6},(_,i)=>{
  const angle=i/6*TAU+layer*.44;return [Math.cos(angle),Math.sin(angle)];
}));
const FILAMENT_TOPOLOGY=Object.fromEntries(Object.values(DETAIL).map(({segments})=>[segments,
  Array.from({length:segments+1},(_,i)=>{const u=i/segments;return {
    u,y:u-.5,envelope:Math.sin(Math.PI*u)**1.3,angle:u*TAU*1.23,phase:u*Math.PI
  };})]));
const SHADES=['#59184f','#c82cac','#f578e0'];

/** Store only bounded, serializable channels on the existing bit resonance.
 * An absent, disabled or zero-strength feature adds no hardware properties.
 * The work load changes shape, never the multiplier of an accumulated clock. */
export function sampleV7GemInterior(flight={}, {time=0,index=0,side=1,animated=true,deployment=1}={}){
  const cfg=flight.v7;
  if(!cfg||cfg.enabled===false||cfg.gemInteriors!==true)return null;
  const strength=unit(finite(cfg.gemStrength,.65));if(!strength)return null;
  const moving=animated===true&&!flight.effective?.reducedMotion;
  const detail=flight.quality?.bitDetail??flight.bitQuality??'high';
  const response=flight.conditionResponse,station=`${side<0?'left':'right'}${index?'Lower':'Upper'}`;
  const levels=response?.bits?response.levels??{}:{};
  const collapse=response?.bits&&response.collapse?.phase!=='awake'&&
    (!response.collapse?.bits?.length||response.collapse.bits.includes(station))?unit(response.collapse?.mix):0;
  // Condition motion changes bounded shape amplitudes instead of rescaling the
  // old clock. This mirrors the existing bit hold without creating a second
  // condition reader, state machine or recovery timer.
  const motion=(1-collapse)*Math.max(.05,1-unit(levels.stunned)*.9-Math.max(unit(levels.fatigued),unit(levels.slowed))*.35+unit(levels.quickened)*.15);
  const lantern=unit(flight.lantern?.weight??(flight.lantern?.active?1:0));
  const light=flight.light?.active?unit(flight.light.intensity??1)*.35:0;
  return {strength,detail:Object.hasOwn(DETAIL,detail)?detail:'high',animated:moving,
    ...(flight.v9?.signatureCraft===true?{signatureCraft:true}:{}),
    clock:moving?finite(time):0,motion:moving?Math.min(1,motion):0,seed:index*1.37+(side<0?.61:2.03),
    deployment:unit(deployment),lantern:Math.max(lantern,light)};
}

/** Positive-oriented outline of the original projected gemstone. The painter
 * caches this once per frame, clipping every inner line to this exact volume.
 * Face arrays keep fixed topology through interrupted projector blending. */
export function projectedCrystalOutline(faces=[]){
  // Sort numeric coordinates directly. Twelve faces repeat the same eight
  // corners; formatting every repeated floating point pair as a string added
  // temporary key/entry storage to each live bit frame. Keep the last equal
  // point, matching the previous map's value when projected depths coincide.
  const points=[];
  for(const point of faces.flat().sort((a,b)=>a[0]-b[0]||a[1]-b[1])){
    const last=points.at(-1);
    if(last&&last[0]===point[0]&&last[1]===point[1])points[points.length-1]=point;
    else points.push(point);
  }
  if(points.length<3)return points;
  const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
  const half=list=>{const out=[];for(const p of list){while(out.length>1&&cross(out.at(-2),out.at(-1),p)<=0)out.pop();out.push(p);}return out;};
  const lower=half(points),upper=half([...points].reverse());lower.pop();upper.pop();return [...lower,...upper];
}

/** Layered optical volumes, a suspended folded filament and restrained veins.
 * The volumes counter-rotate more slowly than the exterior, so their true
 * parallax changes with viewing yaw rather than sliding over a flat facet.
 * All raw points stay well inside the existing double-pyramid crystal. */
export function v7GemInteriorGeometry({sample,project,radius,length,float=0,spin=0,facets=[],resonance={},power=1}={}){
  if(!sample?.strength)return [];
  const s=sample,detail=DETAIL[s.detail]??DETAIL.high,t=s.animated?finite(s.clock):0;
  const motion=unit(s.motion??(s.animated?1:0));
  const health=unit(resonance.charge??1)*unit(power)*(1-.8*unit(resonance.collapse));
  const working=resonance.coreState??{};
  const load=unit(Math.max(s.lantern,finite(working.open)*.6,finite(working.charge),finite(working.conduct)*.8,finite(resonance.healing)));
  const gain=unit(s.strength*s.deployment*health);
  const breathe=.5+.5*Math.sin(t*.53+s.seed)*motion;
  const contract=1-.16*load+.045*(breathe-.5);
  const innerAngle=spin*.31+s.seed+.13*Math.sin(t*.31+s.seed)*motion;
  const c=Math.cos(innerAngle),sn=Math.sin(innerAngle);
  const turn=([x,y,z])=>project([x*c+z*sn,y+float,-x*sn+z*c]);
  const parts=[];
  const add=(id,raw,fill=null,stroke=null,width=.22,alpha=.3)=>{
    const points=[];let z=0;for(const point of raw){const vertex=turn(point);points.push(vertex);z+=vertex[2];}
    parts.push({id:`v7-gem-${id}`,points,z:z/points.length,
      fill,stroke,width,alpha:gain*alpha,clipFaces:facets,interior:true});
  };
  const addProjected=(id,vertices,fill=null,stroke=null,width=.22,alpha=.3)=>{
    const points=[];let z=0;for(const vertex of vertices){points.push(vertex.slice());z+=vertex[2];}
    parts.push({id:`v7-gem-${id}`,points,z:z/points.length,
      fill,stroke,width,alpha:gain*alpha,clipFaces:facets,interior:true});
  };
  const radial=(a,r,y)=>[Math.cos(a)*r,y,Math.sin(a)*r];
  for(let layer=0;layer<detail.layers;layer++){
    const scale=(.66-layer*.16)*contract,half=length*(.67-layer*.16),ringRadius=radius*scale;
    const ring=VOLUME_RINGS[layer].map(([c,s])=>[c*ringRadius,-.7,s*ringRadius]);
    // A layered crystal has eight physical corners. Sharing their projection
    // avoids turning the same apex/ring endpoints for each of its facets.
    const projectedRing=ring.map(turn),apex=turn([0,-half,0]),end=turn([0,half,0]);
    for(let i=0;i<6;i++){
      addProjected(`volume-${layer}-upper-${i}`,[apex,projectedRing[i],projectedRing[(i+1)%6]],SHADES[layer],null,0,(.21+.07*load)/(layer+1));
      addProjected(`volume-${layer}-lower-${i}`,[end,projectedRing[(i+1)%6],projectedRing[i]],SHADES[(layer+1)%3],null,0,(.16+.08*load)/(layer+1));
    }
    // Individual ridges expose thickness without outlining the whole volume.
    for(const edge of [1,4])addProjected(`lamella-${layer}-${edge}`,[apex,projectedRing[edge],end],null,layer===0?'#d76aba':'#ffb2ef',.20,.28+load*.15);
  }
  // A folded, asymmetrical filament is hung within the crystal. Slow local
  // shape changes remain during projection; the entire bit is never bobbed.
  const filament=[];
  for(const topology of FILAMENT_TOPOLOGY[detail.segments]){
    const y=topology.y*length*1.12;
    const a=topology.angle+s.seed+.13*Math.sin(t*.39+topology.phase)*motion;
    const r=radius*.36*topology.envelope*contract;
    filament.push(radial(a,r,y));
  }
  const flow=t*.16+s.seed/TAU;
  const projectedFilament=filament.map(turn);
  for(let i=0;i<filament.length-1;i++){
    const u=(i+.5)/detail.segments,current=.5+.5*Math.cos((u-flow)*TAU)*motion;
    const p=unit((current-.72)/.12),glint=p*p*(3-2*p);
    const color=glint===0?'#ff65df':glint===1?'#ffe1f8':`rgb(255,${101+124*glint},${223+25*glint})`;
    addProjected(`filament-${i}`,[projectedFilament[i],projectedFilament[i+1]],null,color,.30+.09*load,
      .58+current*(.24+.14*load));
  }
  // Veins are in a second internal plane, separated from the folded filament.
  const veins=s.detail==='low'?2:4;
  for(let branch=0;branch<veins;branch++){
    const y=(branch/(veins-1)-.5)*length*.68,sign=branch%2?1:-1;
    add(`vein-${branch}`,[[0,y,0],[sign*radius*.17,y-length*.05,radius*.12],
      [sign*radius*.46,y-length*.12,radius*.10]],null,'#e979cf',.16,.24+.14*load);
  }
  // A loaded crystal seats two complementary half-collars around its actual
  // interior filament. They only appear while the existing mechanism carries
  // work/light/guard load, so quiet attendants do not acquire another idle
  // fidget. Geometry follows the double-pyramid taper and the existing native
  // crystal clip; it never becomes an exterior halo or a universal pulse.
  const duty=unit(Math.max(finite(working.open),finite(working.conduct),finite(working.guard),s.lantern));
  if(s.signatureCraft&&duty>.001){
    const segments=s.detail==='low'?6:10;
    for(const collar of [-1,1]){
      const y=collar*length*(.19-.055*duty),r=radius*(.59+.12*duty)*(1-Math.abs(y)/length);
      const a0=s.seed+collar*.42,points=Array.from({length:segments+1},(_,i)=>radial(a0+i/segments*Math.PI*1.35,r,y));
      add(`load-collar-${collar}`,points,null,collar<0?'#ffc9f0':'#dc6ec8',.24+.06*duty,.24*duty);
      const stop=points.at(collar<0?0:-1);
      add(`load-seat-${collar}`,[stop,[stop[0]*.56,stop[1]-collar*length*.055,stop[2]*.56]],null,'#ffe1f5',.22,.36*duty);
    }
  }
  return parts;
}
