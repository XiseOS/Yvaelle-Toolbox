/** Health estimates instead of HP numbers, the way PF2e HUD shows them.
 * If PF2e HUD is active, its own Health Status labels and markers are used,
 * so the Medkit reads exactly like the rest of the table; otherwise its
 * defaults: Dead, At Death's Door, Not Feeling Good, Seen Better Days,
 * Barely Hurt, Perfectly Fine. Current HP plus temporary HP (and Stamina when
 * that variant is on) is compared with max HP, as PF2e HUD does. */
const DEFAULT={dead:'Dead',full:'Perfectly Fine',entries:[
  {label:"At Death's Door",marker:1},{label:'Not Feeling Good',marker:25},{label:'Seen Better Days',marker:50},{label:'Barely Hurt',marker:75}]};

function clean(entries){
  const list=entries.filter(e=>e&&typeof e.label==='string'&&Number.isFinite(Number(e.marker)))
    .map(e=>({label:e.label.trim()||'???',marker:Math.max(1,Math.min(99,Number(e.marker)))})).sort((a,b)=>a.marker-b.marker);
  for(let i=list.length-1;i>=0;i--){
    const prev=list[i-1]?.marker??0,next=list[i+1]?.marker??100;
    if(list[i].marker<=prev)list[i].marker=prev+1;
    if(list[i].marker>=next)list.splice(i,1);
  }
  return list;
}
/** The table's health status scale: PF2e HUD's when it is active. */
export function healthScale(){
  try{
    if(globalThis.game?.modules?.get?.('pf2e-hud')?.active){
      const src=game.settings.get('pf2e-hud','healthStatusData');
      if(src&&typeof src==='object'&&Array.isArray(src.entries)&&src.entries.length){
        const entries=clean(src.entries);
        if(entries.length)return {dead:String(src.dead||DEFAULT.dead),full:String(src.full||DEFAULT.full),entries};
      }
    }
  }catch{}
  return DEFAULT;
}
/** {label, level, levels, ratio, hue}: level 0 is dead, `levels` is unharmed.
 * `ratio` is the bucket (level/levels), never the exact HP fraction. */
export function healthEstimate(actor,scale=healthScale()){
  const hp=actor?.system?.attributes?.hp,max=Number(hp?.max);
  const levels=scale.entries.length+1;
  if(!hp||!(max>0))return {label:'Unknown',level:levels,levels,ratio:1,hue:125,unknown:true};
  const value=Math.min(Math.max(Number(hp.value)||0,0),max),temp=Math.max(0,Number(hp.temp)||0);
  let spMax=0,sp=0;
  try{if(actor.type==='character'&&game.pf2e?.settings?.variants?.stamina){spMax=Number(hp.sp?.max)||0;sp=Math.min(Math.max(Number(hp.sp?.value)||0,0),spMax);}}catch{}
  const total=value+sp+temp,totalMax=max+spMax;
  let level,label;
  if(total<=0){level=0;label=scale.dead;}
  else if(total>=totalMax){level=levels;label=scale.full;}
  else{
    const pct=Math.max(total/totalMax*100,1);let idx=-1;
    scale.entries.forEach((e,i)=>{if(pct>=e.marker)idx=i;});
    level=idx+1;label=idx>=0?scale.entries[idx].label:'???';
    if(level<1){level=1;}
  }
  const ratio=level/levels;
  return {label,level,levels,ratio,hue:Math.round(ratio*ratio*122+3)};
}
