import {scanArtworkPreparation} from './v8-scan-art.mjs?v=13.0.0-beta.5';
import {actionEffectViewport} from './treatment-render-regions.mjs?v=13.0.0-beta.5';

/** Crop only empty survey pixels. Keep the original global raster density,
 * native clipping, shared team field, connectors and source-aperture glow.
 * The painter clips every area surface to its region; only the 8-unit source
 * aperture and its straight measuring path can extend outside that region. */
export function scanEffectBounds(effect,plane='front',preparedArtwork=null){
  if(effect?.effect!=='v8-scan'||effect.mode!=='areaScan')return effect?.bounds??null;
  let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
  const add=(x,y,pad,c,s)=>{const px=x*c-y*s,py=x*s+y*c;left=Math.min(left,px-pad);top=Math.min(top,py-pad);right=Math.max(right,px+pad);bottom=Math.max(bottom,py+pad);};
  for(const raw of (effect.channels??[]).slice(0,4)){
    if((raw.plane??'front')!==plane||!(raw.strength>0))continue;
    const g=scanArtworkPreparation(raw,effect.mode,preparedArtwork).geometry,c=Math.cos(g.frameRotation),s=Math.sin(g.frameRotation);
    // Rectangle corners are a conservative envelope for polygon/circle clips.
    for(const x of [g.center.x-g.halfWidth,g.center.x+g.halfWidth])for(const y of [g.center.y-g.halfHeight,g.center.y+g.halfHeight])add(x,y,2,c,s);
    const sources=g.sources.length?g.sources:[g.source];
    for(const source of sources)add(source.x,source.y,8,c,s);
  }
  if(!Number.isFinite(left))return null;
  return {x:left,y:top,width:right-left,height:bottom-top};
}

/** Preserve the previous native raster origin exactly. Canvas implementations
 * can quantize rotated antialiasing differently after a crop translation, even
 * at identical density. Paint in one retained original envelope, then copy
 * only occupied pixels to the uploaded texture. No extraction or readback. */
/** The retained full-envelope raster is kept only up to the old 640-texel
 * field (its envelope is ~608²); anything larger paints straight into the crop. */
export const SCAN_RASTER_PIXEL_LIMIT=640*640;
export function paintCroppedScanSurface(record,sample,options,paint,{document:hostDocument=globalThis.document}={}){
  const {size,plane,viewport}=options;
  const original=actionEffectViewport(sample.effects,size,plane,{ignoreTokenFields:true});
  if(!original||original.x===viewport.x&&original.y===viewport.y&&original.width===viewport.width&&original.height===viewport.height){paint(record.ctx,sample,options);return;}
  // A large area scan sized from its team crop has a virtual full raster far
  // beyond any allocatable canvas. Area fields are unrotated and crops sit on
  // a 16-texel lattice, so paint straight into the crop (integer translation).
  if(original.width*original.height>SCAN_RASTER_PIXEL_LIMIT){record.scanRaster=null;paint(record.ctx,sample,options);return;}
  let raster=record.scanRaster;
  if(!raster){const surface=hostDocument?.createElement?.('canvas')??(globalThis.OffscreenCanvas?new OffscreenCanvas(original.width,original.height):null);if(!surface){paint(record.ctx,sample,options);return;}const ctx=surface.getContext('2d');if(!ctx)throw new Error('A 2D canvas is needed for scan artwork.');raster=record.scanRaster={surface,ctx};}
  if(raster.surface.width!==original.width)raster.surface.width=original.width;
  if(raster.surface.height!==original.height)raster.surface.height=original.height;
  paint(raster.ctx,sample,{...options,viewport:original});
  record.ctx.clearRect(0,0,viewport.width,viewport.height);
  record.ctx.drawImage(raster.surface,viewport.x-original.x,viewport.y-original.y,viewport.width,viewport.height,0,0,viewport.width,viewport.height);
}
