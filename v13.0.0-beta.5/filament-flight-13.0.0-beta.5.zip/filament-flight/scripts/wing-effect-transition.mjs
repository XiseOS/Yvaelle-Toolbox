/** Short, renderer-local artwork handoffs. Numerical HP/condition channels
 * already ease, but changing an effect's topology needs the pixels currently
 * displayed as its origin. Only one destination rig is evaluated per frame;
 * this module morphs matching paths and fades genuinely unmatched topology.
 * Nothing here writes documents, starts timers, or retains old scene tokens. */
export const WING_EFFECT_BLEND_MS=550;
const KEYS=['leftRear','rightRear','leftFront','rightFront'];
const unit=x=>Math.max(0,Math.min(1,x));
const ease=x=>{x=unit(x);return x*x*(3-2*x);};
const mix=(a,b,t)=>a+(b-a)*t;
const number=x=>typeof x==='number'&&Number.isFinite(x);
const groupKey=p=>`${p.id}|${p.hardware?'hardware':p.star?'star':p.echo?'echo':'line'}|${p.highlight?'lit':''}`;
const visible=p=>p.strength>=.025;
function groups(parts){
  const out=new Map();
  for(const part of parts){const key=groupKey(part);if(!out.has(key))out.set(key,[]);out.get(key).push(part);}
  return out;
}
function pointAt(points,q){
  const at=unit(q)*(points.length-1),i=Math.floor(at),a=points[i],b=points[Math.min(points.length-1,i+1)];
  return a.map((n,j)=>mix(n,b[j]??n,at-i));
}
function blendPoints(a,b,t){
  const count=Math.max(a.length,b.length);
  return Array.from({length:count},(_,i)=>{
    const q=count>1?i/(count-1):0,from=a.length===count?a[i]:pointAt(a,q),to=b.length===count?b[i]:pointAt(b,q);
    return to.map((n,j)=>mix(from[j]??n,n,t));
  });
}
function hardwareBlend(a,b,t,depth=0){
  if(!a||!b||depth>4)return b;
  const out={...b};
  for(const [key,value] of Object.entries(b)){
    if(number(value)&&number(a[key])){
      const delta=['angle','coreAngle'].includes(key)?Math.atan2(Math.sin(value-a[key]),Math.cos(value-a[key])):value-a[key];
      out[key]=a[key]+delta*t;
    }else if(Array.isArray(value)&&Array.isArray(a[key])&&value.every(number)&&a[key].every(number)){
      if(key==='direction'&&value.length===2&&a[key].length===2){
        const from=Math.atan2(a[key][1],a[key][0]),to=Math.atan2(value[1],value[0]);
        const angle=from+Math.atan2(Math.sin(to-from),Math.cos(to-from))*t;out[key]=[Math.cos(angle),Math.sin(angle)];
      }else out[key]=value.map((n,i)=>number(a[key][i])?mix(a[key][i],n,t):n);
    }else if(value&&a[key]&&typeof value==='object'&&!Array.isArray(value)&&!Array.isArray(a[key]))out[key]=hardwareBlend(a[key],value,t,depth+1);
  }
  return out;
}
function blendPart(a,b,t){
  const part={...b,points:blendPoints(a.points,b.points,t),strength:mix(a.strength,b.strength,t),width:mix(a.width??1,b.width??1,t)};
  if(b.hardware)part.hardware=hardwareBlend(a.hardware,b.hardware,t);
  return part;
}
/** Endpoints retain their exact native geometry. Incompatible cuts/echoes
 * crossfade instead of stretching a whole rib into one short broken section.
 * Native path counts are bounded; the safety cap only matters under sustained
 * rapid interruption and removes the faintest already-invisible remnants. */
export function blendWingGeometry(from,to,progress){
  const t=unit(progress);if(t===0)return from;if(t===1)return to;
  const result={};
  // Allocation/retraction owns physical instruments. A wing-art handoff may
  // never resurrect a bit that has left for a patient or been tucked away.
  const hardware=new Set(KEYS.flatMap(key=>(to[key]??[]).filter(p=>p.hardware).map(p=>`${key.startsWith('left')?'left':'right'}|${p.id}`)));
  for(const key of KEYS){
    const old=groups(from[key]??[]),next=groups(to[key]??[]),parts=[];
    for(const [id,target] of next){
      const source=old.get(id);old.delete(id);
      if(source?.length===target.length){
        for(let i=0;i<target.length;i++)parts.push(blendPart(source[i],target[i],t));
      }else{
        if(source)for(const p of source)parts.push({...p,strength:p.strength*(1-t)});
        for(const p of target)parts.push({...p,strength:p.strength*t});
      }
    }
    for(const source of old.values())for(const p of source){
      if(p.hardware&&!hardware.has(`${key.startsWith('left')?'left':'right'}|${p.id}`))continue;
      parts.push({...p,strength:p.strength*(1-t)});
    }
    let shown=parts.filter(visible);
    if(shown.length>4096)shown=shown.sort((a,b)=>b.strength-a.strength).slice(0,4096);
    result[key]=shown;
  }
  return result;
}

/** No animation clocks, motion samples or continuously changing severity in
 * this identity: one semantic change starts one handoff, not one per tick. */
export function wingEffectIdentity(snapshot){
  const v=snapshot.visual??{},p=v.profile??{};
  return JSON.stringify([v.condition,v.effectStyle,p.variant?.id??null,p.variant?.condition??null,
    p.enhanced,p.gates,snapshot.conditionResponse?.wings?snapshot.conditionResponse.active?.map(entry=>[entry.id,entry.style]):null,
    snapshot.conditionResponse?.collapse?.phase==='awake'?'awake':'reform',snapshot.requested?.wingForm??p.statusWingState?.form??'original']);
}
function paintVisual(from,to,t){
  if(!from||t>=1)return to;if(t<=0)return {...to,...from};
  const out={...to};
  for(const key of ['energy','renderOpacity','geometryPulse','pulse'])if(number(from[key])&&number(to[key]))out[key]=mix(from[key],to[key],t);
  out.energyPulses=from.energyPulses||to.energyPulses;
  return out;
}
const paintChannels=v=>({energy:v?.energy??1,renderOpacity:v?.renderOpacity??Math.min(1,v?.energy??1),geometryPulse:v?.geometryPulse??v?.pulse??0,pulse:v?.pulse??0,energyPulses:v?.energyPulses});

export class WingEffectTransition {
  constructor(){this.identity=null;this.displayed=null;this.from=null;this.started=0;this.dirty=false;}
  /** A semantic boundary records what is displayed. The worker blends from its
   * own last frame; the main thread rebuilds an accepted worker frame only if
   * it must paint the blend itself (lazy capture in paint()). */
  update(snapshot,config,now){
    const identity=wingEffectIdentity(snapshot),response=snapshot.conditionResponse;
    const allowed=config.transitions!==false&&!config.reduced&&snapshot.rendering?.wingsActive!==false&&
      // Beta.29: a knockout blends from the wing on screen (falling/fallen);
      // only a rebuild, which grows behind its own front, skips the handoff.
      !(response?.wings&&response.collapse?.phase==='recovering')&&!(snapshot.visual?.profile?.reformation&&!(response?.wings&&['falling','fallen'].includes(response.collapse?.phase)));
    if(!allowed){if(this.from)this.dirty=true;this.from=null;this.identity=identity;return false;}
    if(this.identity!==null&&identity!==this.identity&&this.displayed){
      this.from={geometry:this.displayed.geometry??null,input:this.displayed.input??null,visual:this.displayed.visual};this.started=now;this.dirty=true;
    }
    this.identity=identity;
    if(this.from&&now-this.started>=WING_EFFECT_BLEND_MS){this.from=null;this.dirty=true;}
    return !!this.from;
  }
  active(now){return !!this.from&&now-this.started<WING_EFFECT_BLEND_MS;}
  progress(now){return this.from?ease((now-this.started)/WING_EFFECT_BLEND_MS):1;}
  visual(target,now){return paintVisual(this.from?.visual,target,this.progress(now));}
  /** paintVisual(...).renderOpacity??min(1,energy), without the copy. */
  opacity(target,now){
    const from=this.from?.visual,t=this.progress(now);
    if(!from||t>=1)return target.renderOpacity??Math.min(1,target.energy);
    if(t<=0)return from.renderOpacity??Math.min(1,from.energy);
    const energy=number(from.energy)&&number(target.energy)?mix(from.energy,target.energy,t):target.energy;
    return (number(from.renderOpacity)&&number(target.renderOpacity)?mix(from.renderOpacity,target.renderOpacity,t):target.renderOpacity)??Math.min(1,energy);
  }
  /** Worker frame input: the worker keeps its displayed geometry across epochs. */
  request(target,now){
    if(!this.from)return null;
    const v=this.visual(target,now);
    return {started:this.started,progress:this.progress(now),paint:{energy:v.energy,renderOpacity:v.renderOpacity,geometryPulse:v.geometryPulse,pulse:v.pulse,energyPulses:v.energyPulses}};
  }
  paint(geometry,target,now,capture){
    const from=this.from;
    if(from&&!from.geometry&&from.input&&capture){from.geometry=capture(from.input)??null;from.input=null;}
    const visual=this.visual(target,now),mixed=from?.geometry?blendWingGeometry(from.geometry,geometry,this.progress(now)):geometry;
    this.remember({geometry:mixed,visual});this.dirty=false;
    return {geometry:mixed,visual};
  }
  remember({geometry,input,visual}){this.displayed={geometry,input,visual:paintChannels(visual)};}
  clear(){this.identity=null;this.from=null;this.displayed=null;this.dirty=false;}
}
