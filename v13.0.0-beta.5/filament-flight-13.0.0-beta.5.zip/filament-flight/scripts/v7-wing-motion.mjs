/** V7 gestures are additive material motion, never new poses. The original
 * shoulder, silhouette, pose transition and collapse channels retain ownership.
 * Saved events are pure server-clock data; no timer or renderer-local randomness.
 * Channel order per side: lift, spread, fold, camber, roll, twist, lower, upper,
 * depth. Native rig units are applied by v7-wing-material, not stored here. */
const unit=x=>Math.max(0,Math.min(1,x));
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const zero=()=>Array(18).fill(0);
const side=(a,b=a)=>[...a,...b];
const descriptor=(label,detail,shape,enter,hold,release,drift)=>Object.freeze({label,detail,shape:Object.freeze(shape),enter,hold,release,drift});
export const WING_GESTURES=Object.freeze({
  lunarBow:descriptor('Lunar bow','Upper filaments incline first; the lower curls answer and settle.',side([.35,-.15,.24,.2,0,.08,.2,-.24,.12]),1500,2100,1900,.14),
  quietFlourish:descriptor('Quiet flourish','An outward unfurl runs through the lobes and returns with a soft torsion.',side([.22,.76,-.15,.24,-.06,.55,-.3,.36,-.12]),1600,2400,2100,.2),
  featherTurn:descriptor('Feather turn','One wing receives a delicate lift while its partner counters in depth.',side([.35,.2,.08,.1,-.3,.4,-.16,.25,.22],[-.08,.08,.12,.14,.3,-.26,.18,-.1,-.18]),1800,2000,1800,.15),
  heldBreath:descriptor('Held breath','The wing lattice gathers slowly, then releases its tension through the tips.',side([.1,-.24,.62,.38,0,.12,.26,.12,.2]),2200,2200,2800,.08),
  resolveArc:descriptor('Resolve arc','A lifted upper arc and taut lower strands form a composed, deliberate display.',side([.5,.4,-.12,-.2,0,.16,-.35,.65,-.18]),1700,3200,2400,.1),
  softShelter:descriptor('Soft shelter','The middle lobes cup gently without closing the tall gothic tips.',side([-.1,-.2,.7,.6,0,-.16,.28,-.06,.42]),2100,3000,2500,.08),
  greetingFold:descriptor('Greeting fold','A small paired inclination travels from the shoulders to the outer filaments.',side([-.25,-.1,.3,.08,.18,.18,.22,-.12,.12],[-.25,-.1,.3,.08,-.18,-.18,.22,-.12,.12]),1400,1800,2100,.12),
  trailingBloom:descriptor('Trailing bloom','Lower curls open behind the upper ribs, then rise back into the current pose.',side([-.05,.34,-.12,.15,0,.28,-.75,.05,-.36]),2000,2800,2600,.17),
  keystoneRelay:Object.freeze({...descriptor('Keystone relay','A measured upper-arc lift passes into the lower curls, one wing answering the other before the lattice settles.',side([.08,.10,.16,-.08,0,0,.04,.02,0]),1600,4400,2300,0),v9:true}),
  reliquaryRelease:Object.freeze({...descriptor('Reliquary release','The lower curls gather inward; their opening travels upward into a composed lifted display, then returns to the chosen pose.',side([-.06,-.10,.42,.18,0,.04,.34,.02,.12]),1900,4600,2500,0),v9:true})
});
export const WING_BRIDGE_VARIANTS=Object.freeze(['rising arc','torsion relay','nested fold']);
function hash(value){let h=2166136261;for(const ch of String(value??'')){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
export function validateWingGesture(name){if(!Object.hasOwn(WING_GESTURES,name))throw new Error(`Unknown wing gesture ${name}.`);return name;}
/** Null remains null; malformed persisted events fail with a useful error. */
export function readWingGesture(raw){
  if(raw==null)return null;
  validateWingGesture(raw.name);
  if(!finite(raw.started)||!finite(raw.enter)||raw.enter<600||raw.enter>10000||!finite(raw.hold)||raw.hold<0||raw.hold>60000||!finite(raw.release)||raw.release<600||raw.release>10000||!finite(raw.intensity)||raw.intensity<0||raw.intensity>1||!Number.isInteger(raw.variant)||raw.variant<0||raw.variant>2||!Array.isArray(raw.from)||raw.from.length!==18||!raw.from.every(n=>finite(n)&&Math.abs(n)<=2)||!Array.isArray(raw.velocity)||raw.velocity.length!==18||!raw.velocity.every(n=>finite(n)&&Math.abs(n)<=.006))throw new Error('Invalid saved V7 wing gesture.');
  if(raw.source!=null&&!['manual','bridge'].includes(raw.source))throw new Error('Invalid V7 wing gesture source.');
  return {name:raw.name,started:raw.started,enter:raw.enter,hold:raw.hold,release:raw.release,intensity:raw.intensity,variant:raw.variant,from:[...raw.from],velocity:[...raw.velocity],source:raw.source??'manual',...(raw.releaseOnly===true?{releaseOnly:true}:{})};
}
/** Quintic Hermite: position, velocity and zero acceleration at both ends.
 * The corresponding endpoint of a held gesture is evaluated in advance, so
 * the evolving hold does not acquire a velocity jump at the entry boundary. */
function hermite(a,av,b,bv,p,duration){
  const p2=p*p,p3=p2*p,p4=p3*p,p5=p4*p;
  const h0=1-10*p3+15*p4-6*p5,h1=p-6*p3+8*p4-3*p5,h2=10*p3-15*p4+6*p5,h3=-4*p3+7*p4-3*p5;
  const d0=(-30*p2+60*p3-30*p4)/duration,d1=1-18*p2+32*p3-15*p4,d2=(30*p2-60*p3+30*p4)/duration,d3=-12*p2+28*p3-15*p4;
  return {channels:a.map((v,i)=>v*h0+av[i]*duration*h1+b[i]*h2+bv[i]*duration*h3),velocity:a.map((v,i)=>v*d0+av[i]*d1+b[i]*d2+bv[i]*d3)};
}
/** The V9 scores own one finite phrase, not another free-running idle loop.
 * Their analytic velocities join the same captured Hermite entry/release as
 * the older library, including a custom shortened/zero hold. */
function heldSignature(event,elapsed){
  const d=WING_GESTURES[event.name],duration=Math.max(1,event.hold),p=event.hold===0?1:unit((elapsed-event.enter)/duration),channels=[...d.shape],velocity=zero();
  const bump=(start,end)=>{
    const q=unit((p-start)/(end-start)),inside=p>start&&p<end;
    return {value:Math.sin(Math.PI*q)**2,velocity:inside?Math.PI*Math.sin(2*Math.PI*q)/(duration*(end-start)):0};
  };
  const rise=(start,end)=>{
    const q=unit((p-start)/(end-start)),q2=q*q,q3=q2*q;
    return {value:q3*(10-15*q+6*q2),velocity:p>start&&p<end?30*q2*(1-q)*(1-q)/(duration*(end-start)):0};
  };
  if(event.name==='keystoneRelay'){
    for(let wing=0;wing<2;wing++){
      const upper=bump(wing?.13:0,wing?.72:.59),lower=bump(wing?.43:.32,wing?1:.91),sign=wing?1:-1;
      const first=[.18,.20,-.06,-.12,0,sign*.28,-.08,.55,sign*.16],answer=[.08,.13,-.12,.15,0,-sign*.20,.62,-.16,-sign*.12];
      for(let i=0;i<9;i++){const k=wing*9+i;channels[k]+=first[i]*upper.value+answer[i]*lower.value;velocity[k]=first[i]*upper.velocity+answer[i]*lower.velocity;}
    }
  }else{
    const composed=side([.34,.46,-.12,-.08,0,.13,-.12,.30,-.10]);
    for(let k=0;k<18;k++){
      const channel=k%9,curve=rise(channel===6?0:channel===7?.35:channel===0?.30:.10,channel===6?.52:channel===7?.96:channel===0?1:.80),delta=composed[k]-d.shape[k];
      channels[k]+=delta*curve.value;velocity[k]=delta*curve.velocity;
    }
  }
  return {channels:channels.map(n=>n*event.intensity),velocity:velocity.map(n=>n*event.intensity)};
}
function held(event,elapsed){
  if(WING_GESTURES[event.name]?.v9)return heldSignature(event,elapsed);
  const d=WING_GESTURES[event.name],t=elapsed/1000,frequency=.38+(event.variant*.035),phase=event.variant*.8;
  const shape=d.shape,amount=event.intensity,drift=d.drift;
  return {channels:shape.map((v,i)=>v*amount*(1+drift*Math.sin(t*frequency+i*.23+phase))),velocity:shape.map((v,i)=>v*amount*drift*frequency*Math.cos(t*frequency+i*.23+phase)/1000)};
}
/** Three bounded bridge paths, each with stationary ends. They vary the
 * approach, not the destination and never switch while an event is playing. */
function bridge(sample,event,p,duration,returning=false){
  const amount=event.intensity*(returning?.6:1),bump=64*p**3*(1-p)**3,db=192*p*p*(1-p)**2*(1-2*p)/duration;
  const profiles=[side([.16,.08,0,-.04,0,.03,-.06,.14,-.04]),side([0,-.04,.06,.02,-.05,.22,.06,-.02,.08],[0,-.04,.06,.02,.05,-.22,.06,-.02,.08]),side([-.04,-.12,.22,.15,0,0,.12,-.02,.12])];
  const direction=returning?-1:1;
  return {channels:sample.channels.map((v,i)=>v+direction*amount*profiles[event.variant][i]*bump),velocity:sample.velocity.map((v,i)=>v+direction*amount*profiles[event.variant][i]*db)};
}
function sampleDetailed(event,now){
  if(!event||now<event.started)return {channels:zero(),velocity:zero(),active:false,name:null,variant:0};
  const elapsed=now-event.started,endHold=event.enter+event.hold,total=endHold+event.release;
  if(event.releaseOnly){
    if(elapsed>=event.release)return {channels:zero(),velocity:zero(),active:false,name:event.name,variant:event.variant};
    return {...hermite(event.from,event.velocity,zero(),zero(),unit(elapsed/event.release),event.release),active:true,name:event.name,variant:event.variant};
  }
  if(elapsed>=total)return {channels:zero(),velocity:zero(),active:false,name:event.name,variant:event.variant};
  let out;
  if(elapsed<event.enter){const target=held(event,event.enter);out=bridge(hermite(event.from,event.velocity,target.channels,target.velocity,unit(elapsed/event.enter),event.enter),event,unit(elapsed/event.enter),event.enter);}
  else if(elapsed<endHold)out=held(event,elapsed);
  else {const source=held(event,endHold);out=bridge(hermite(source.channels,source.velocity,zero(),zero(),unit((elapsed-endHold)/event.release),event.release),event,unit((elapsed-endHold)/event.release),event.release,true);}
  return {...out,active:true,name:event.name,variant:event.variant};
}
export function sampleWingGesture(event,now,{reduced=false}={}){
  if(reduced)return {channels:zero(),active:false,name:event?.name??null,variant:event?.variant??0};
  const {velocity,...result}=sampleDetailed(event,now);return result;
}
/** Capturing a prior event guarantees continuous position and velocity even
 * when the request interrupts an entry, hold or release. No old event queue. */
export function beginWingGesture(name,now,previous=null,{intensity=1,key='',hold,variants=true,source='manual'}={}){
  validateWingGesture(name);if(!finite(now))throw new Error('Wing gesture requires a finite server clock.');
  const d=WING_GESTURES[name],from=sampleDetailed(previous,now),variant=variants?hash(key||`${name}:${now}`)%3:0;
  const event={name,started:now,enter:d.enter,hold:hold==null?d.hold:Math.max(0,Math.min(60000,Number(hold)||0)),release:d.release,intensity:unit(Number(intensity)||0),variant,from:from.channels,velocity:from.velocity,source};
  return readWingGesture(event);
}
/** Explicit dismissal is a captured C1 release, including interruptions while
 * a previous dismissal is already underway. No synchronous geometry reset. */
export function endWingGesture(previous,now,{release=1800}={}){
  if(!previous)return null;if(!finite(now))throw new Error('Wing release requires a finite server clock.');
  const current=sampleDetailed(previous,now);
  if(!current.active)return null;
  return readWingGesture({name:previous.name,started:now,enter:600,hold:0,release:Math.max(600,Math.min(10000,finite(release)?release:1800)),intensity:0,variant:previous.variant??0,from:current.channels,velocity:current.velocity,source:previous.source??'manual',releaseOnly:true});
}
