const values=collection=>collection?.contents??(collection?.values?[...collection.values()]:[]);
const count=collection=>collection?.size??collection?.contents?.length??0;

/** All-scene token lookup. Scene enumeration occurs on initial load/scene
 * changes; an HP update visits only the affected actor's existing tokens. */
export class ActorTokenIndex {
  constructor(){this.documents=new Map();this.actors=new Map();this.scenes=null;this.sceneCount=-1;}
  ensure(scenes=globalThis.game?.scenes){
    if(this.scenes!==scenes||this.sceneCount!==count(scenes))this.rebuild(scenes);
    return this;
  }
  rebuild(scenes=globalThis.game?.scenes){
    this.documents.clear();this.actors.clear();this.scenes=scenes;this.sceneCount=count(scenes);
    for(const scene of values(scenes))this.addScene(scene);
    return this;
  }
  addScene(scene){for(const doc of values(scene?.tokens))this.upsert(doc);}
  upsert(doc){
    if(!doc?.uuid)return;
    const actorId=doc.actor?.uuid??null,previous=this.documents.get(doc.uuid);
    if(previous?.doc===doc&&previous.actorId===actorId)return;
    this.remove(doc);
    this.documents.set(doc.uuid,{doc,actorId,sceneId:doc.parent?.id});
    if(actorId){let records=this.actors.get(actorId);if(!records)this.actors.set(actorId,records=new Map());records.set(doc.uuid,doc);}
  }
  remove(doc){
    const key=typeof doc==='string'?doc:doc?.uuid,previous=this.documents.get(key);
    if(!previous)return;
    this.documents.delete(key);
    const records=this.actors.get(previous.actorId);records?.delete(key);
    if(records&&!records.size)this.actors.delete(previous.actorId);
  }
  removeScene(scene){for(const [key,record] of this.documents)if(record.sceneId===scene.id)this.remove(key);}
  forActor(actor){return this.actors.get(actor?.uuid)?.values()??[];}
  all(){return Array.from(this.documents.values(),record=>record.doc);}
}
