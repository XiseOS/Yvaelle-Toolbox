/** V5 patient-local working volumes. Every technique has a different surface,
 * silhouette and rhythm. Pure bounded canvas paths; no filter stacks, random
 * history, image downloads, or timers. Existing instrument choreography is
 * painted over these surfaces by hardlight-techniques.mjs. */
const TAU=Math.PI*2,clamp=v=>Math.max(0,Math.min(1,v)),smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
const wrap=v=>(v%1+1)%1;
const rotator=angle=>{const c=Math.cos(angle),s=Math.sin(angle);return (x,y)=>[x*c-y*s,x*s+y*c];};
const PINK='#ff64cf',PEARL='#ffe8fa',ICE='#c6eaff',GOLD='#eecda7';
export const SURFACE_BOUNDS=Object.freeze({membrane:[72,76],splint:[62,66],helix:[52,74],vascular:[70,61],compression:[76,76],precision:[69,65],suture:[62,67],microloom:[66,66]});
export const TREATMENT_SEQUENCES=Object.freeze({
  membrane:'A diagnostic wave maps the patient. A translucent hardlight enclosure assembles around them, circulating repair waves until the result closes or releases it.',
  splint:'The bits measure separate support stations, unfold articulated braces and lock broad support plates. Indicators travel along the braces while alignment is maintained.',
  helix:'Opposing collars establish an axis. Broad helical ribbons rotate through front and rear depth, carrying energy along the patient before tension releases.',
  vascular:'Paired reservoirs establish a perfusion circuit. Branches open in sequence and bright fluid packets travel through the circuit to active terminal wells.',
  compression:'A sectional pressure enclosure surrounds a small central seal. Independent hardlight petals compress in rhythm before a successful result closes the seal.',
  precision:'A projected sterile work field unfolds beneath independently moving instruments. Local measurement tiles and focused contact glows follow their work.',
  suture:'Paired hardlight margins frame a diagonal seam. Needles cross in alternating passes and leave independently tensioned stitches; success draws the seam together.',
  microloom:'A floating loom constructs a translucent woven dressing, cell by cell. A shuttle works across alternating illuminated threads until the dressing is sealed.'
});

export function paintTreatmentSurface(ctx,effect,{plane='front'}={}){
  if(!SURFACE_BOUNDS[effect.style])return false;
  const front=plane!=='rear',scan=effect.phase==='scanning',finish=effect.phase==='finishing';
  const p=clamp(effect.progress??0),success=finish&&['success','criticalSuccess'].includes(effect.outcome);
  const closure=success?smooth(p/.82):0,release=finish&&!success?smooth(p):0;
  const scanP=clamp(effect.scan??p),t=Math.max(0,effect.clock??0),q=wrap(t/5.6);
  const build=scan?smooth(scanP*1.35):1,fade=finish?1-smooth((p-.7)/.3):1;
  const gain=clamp((effect.strength??1)*fade)*build,quality=effect.detail==='low'?0:effect.detail==='high'?2:1;
  if(gain<.002)return true;
  const poly=(points,{fill=.07,stroke=.35,width=.6,color=PINK,closed=true}={})=>{
    ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));if(closed)ctx.closePath();
    ctx.fillStyle=ctx.strokeStyle=color;ctx.lineWidth=width;
    if(fill>0){ctx.globalAlpha=clamp(fill*gain);ctx.fill();}
    if(stroke>0){ctx.globalAlpha=clamp(stroke*gain);ctx.stroke();}
  };
  const ellipse=(x,y,rx,ry,{fill=0,stroke=.4,width=.7,color=PINK,angle=0,start=0,end=TAU}={})=>{
    if(rx<=0||ry<=0)return;ctx.beginPath();ctx.ellipse(x,y,rx,ry,angle,start,end);
    ctx.fillStyle=ctx.strokeStyle=color;ctx.lineWidth=width;
    if(fill){ctx.globalAlpha=clamp(fill*gain);ctx.fill();}if(stroke){ctx.globalAlpha=clamp(stroke*gain);ctx.stroke();}
  };
  const glow=(x,y,r,amount=.6,color=PEARL)=>{
    if(quality>0)ellipse(x,y,r*2,r*1.5,{fill:amount*.045,stroke:0,color});
    ellipse(x,y,r,r*.75,{fill:amount*.18,stroke:amount*.5,width:.65,color});
    ellipse(x,y,r*.27,r*.22,{fill:amount,stroke:0,color});
  };
  ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
  switch(effect.style){
    case 'membrane':{
      // An enclosing ellipsoid, translucent skin and hemispherical scan waves.
      const rx=(60+release*7)*(scan?.65+.35*build:1),ry=67-closure*6;
      ellipse(0,-3,rx,ry,{fill:front?.043:.075,stroke:effect.v9MedicalCraft?(front?.24:.20):(front?.37:.29),width:1,color:ICE});
      const rows=quality===0?3:5;
      for(let j=0;j<rows;j++){
        const y=-ry+2*ry*(j+1)/(rows+1),r=rx*Math.sqrt(Math.max(0,1-((y+3)/ry)**2));
        ellipse(0,y,r,10,{start:front?0:Math.PI,end:front?Math.PI:TAU,stroke:effect.v9MedicalCraft?.07:.12,width:.5});
      }
      const wave=scan?scanP:wrap(t/5.6*1.8),y=-ry+2*ry*wave,r=rx*Math.sqrt(Math.max(0,1-((y+3)/ry)**2));
      // V9 uses the canopy's one shared bonding face. Keep the induction shell
      // as support instead of running a second unrelated bright sweep clock.
      if(!effect.v9MedicalCraft)ellipse(0,y,r,11,{start:front?0:Math.PI,end:front?Math.PI:TAU,stroke:.68*Math.sin(wave*Math.PI),width:2,color:PEARL});
      if(front&&quality>0)for(const s of [-1,1])poly([[s*rx*.82,-33],[s*rx*.91,-17],[s*rx*.94,7]],{closed:false,fill:0,stroke:.37,width:2.2,color:PEARL});
      if(closure>0)ellipse(0,-3,rx+closure*6,ry+closure*6,{stroke:.55*(1-closure),width:1.5,color:GOLD});
      break;
    }
    case 'splint':{
      // Physical-looking separated support plates and locking bands.
      const spread=release*10+(scan?9*(1-build):0);
      for(const s of [-1,1])for(let j=0;j<3;j++){
        const y=-39+j*28,x=s*(35+spread),u=scan?smooth(scanP*2-j*.3):1;
        if(front){
          poly([[x-s*5,y-8],[x+s*9,y-12],[x+s*13,y+5],[x+s*5,y+13],[x-s*5,y+8]],{fill:.17*u,stroke:.68*u,width:.9,color:ICE});
          poly([[x+s*7,y-6],[x+s*9,y+3],[x+s*4,y+7]],{closed:false,fill:0,stroke:.65*u,width:1.8,color:PEARL});
          glow(x,y,2,.4+.5*Math.exp(-(((wrap(q+j/3)-.5)*7)**2)),GOLD);
        }else ellipse(0,y+3,48+spread,10,{stroke:.24,fill:.025,width:2,color:ICE,start:Math.PI,end:TAU});
      }
      break;
    }
    case 'helix':{
      // Filled helical ribbons, subdivided into explicit depth segments.
      const n=quality===0?28:44,twist=2.2-.35*release,turn=t*.82;
      for(let i=0;i<n;i++){
        const a=i/n,b=(i+1)/n,angle=a*TAU*twist+turn,next=b*TAU*twist+turn;
        if((Math.sin((angle+next)/2)>=0)!==front)continue;
        const r=38-closure*5,points=[[Math.cos(angle)*r,-54+a*108],[Math.cos(next)*r,-54+b*108],[Math.cos(next+.13)*(r-4),-48+b*108],[Math.cos(angle+.13)*(r-4),-48+a*108]];
        poly(points,{fill:.12+.09*Math.max(0,Math.sin(angle)),stroke:.32,width:.5,color:ICE});
      }
      for(const s of [-1,1])ellipse(0,s*57,43,11,{fill:.035,stroke:.35,width:1.5,color:PEARL,start:front?0:Math.PI,end:front?Math.PI:TAU});
      break;
    }
    case 'vascular':{
      if(!front)break;
      // Reservoirs have a visible moving fluid level, not an abstract ring.
      for(const s of [-1,1]){
        const x=s*50,y=-s*22,h=18+5*Math.sin(t*1.7+s),level=scan?h*scanP:h;
        // a slim glass phial in filament line, its fluid a light wash under a bright meniscus
        poly([[x-4,y-20],[x+4,y-20],[x+6,y-16],[x+6,y+17],[x+3,y+20],[x-3,y+20],[x-6,y+17],[x-6,y-16]],{fill:.018,stroke:.42,width:.6,color:ICE});
        poly([[x-4.5,y+17-level],[x+4.5,y+17-level],[x+4.5,y+17],[x-4.5,y+17]],{fill:.07,stroke:0,color:s<0?ICE:PINK});
        poly([[x-4.5,y+17-level],[x+4.5,y+17-level]],{closed:false,fill:0,stroke:.7,width:.7,color:s<0?ICE:PINK});
        poly([[x,y-s*20],[x,y-s*25],[s*24,-s*35]],{closed:false,fill:0,stroke:.4,width:1.3,color:PEARL});
      }
      const knots=quality===0?4:6;for(let j=0;j<knots;j++){
        const y=-27+j*54/(knots-1),s=j%2?1:-1,at=wrap(q*2-j*.13),x=s*(17+Math.sin(j)*4);
        glow(x,y,3.1,.3+.6*Math.exp(-(((at-.5)*7)**2)),j%2?PINK:ICE);
      }
      break;
    }
    case 'compression':{
      // Eight moving petals make a sectional enclosure around the four jaws.
      const pressure=scan?build*.4:.6+.05*Math.sin(t*2.1)+closure*.35-release*.4;
      for(let j=0;j<8;j++){
        const a=j*TAU/8+Math.PI/8;
        if((Math.sin(a)>=0)!==front)continue;
        // light filament petals held close to the patient, not flat panels
        const inner=41-pressure*10,outer=56-pressure*5,rotate=rotator(a);
        poly([[inner,-8],[outer,-13],[outer+3,0],[outer,13],[inner,8]].map(([x,y])=>rotate(x,y)),{fill:.03,stroke:.46,width:.65,color:ICE});
        poly([[inner+2,0],[outer+1,0]].map(([x,y])=>rotate(x,y)),{closed:false,fill:0,stroke:.32,width:.5,color:PEARL});
        poly([[inner+4,-5],[outer-2,-8],[outer+.5,0]].map(([x,y])=>rotate(x,y)),{closed:false,fill:0,stroke:.36,width:.55,color:GOLD});
      }
      if(front){ellipse(0,0,17-pressure*6,17-pressure*6,{fill:.04,stroke:.35,width:1,color:PEARL});glow(0,0,5,.45+pressure*.35);}
      break;
    }
    case 'precision':{
      if(!front)break;
      // Small working islands sit on a projected oblique sterile surface.
      const a=-.24,open=scan?build:1,extent=32*open,tr=rotator(a);
      poly([tr(-extent,-36),tr(extent,-36),tr(extent,36),tr(-extent,36)],{fill:.065,stroke:.27,width:.6,color:ICE});
      for(const s of [-1,1]){
        const x=s*(10+Math.sin(t*.9+s)*4),y=s*(9+Math.sin(t*.63+s)*9);
        ellipse(x,y,9,4,{fill:.075,stroke:.3,width:.6,color:ICE,angle:a});
        glow(x,y,3.6,.6+.2*Math.sin(t*2+s),PEARL);
      }
      if(quality>0)for(let j=0;j<4;j++)poly([tr(-25,22+j*3),tr(-12+j*2,22+j*3)],{closed:false,fill:0,stroke:.25,width:.6,color:PEARL});
      break;
    }
    case 'suture':{
      if(!front)break;
      // Two luminous treatment margins. They close only on a successful result.
      const a=-.42,rotate=rotator(a),gap=6*(1-closure)+release*5;
      for(const s of [-1,1]){
        const points=[rotate(s*gap,-38),rotate(s*(gap+12),-33),rotate(s*(gap+17),-10),rotate(s*(gap+15),20),rotate(s*(gap+8),38),rotate(s*gap,38)];
        poly(points,{fill:.11,stroke:.25,width:.6,color:s<0?PINK:ICE});
        const y=-30+60*wrap(q*2+(s<0?.5:0)),point=rotate(s*(gap+2),y);glow(...point,2.8,.75,PEARL);
      }
      if(closure>0)poly([rotate(0,-37),rotate(0,37)],{closed:false,fill:0,stroke:closure*.6,width:2.8,color:PEARL});
      break;
    }
    case 'microloom':{
      if(!front)break;
      // The dressing is a real translucent checker-woven surface, with moving
      // over/under illumination; it does not share the suture seam silhouette.
      const a=-.55,rotate=rotator(a),n=quality===0?4:6,h=29,w=h*2/n;
      for(let j=0;j<n;j++)for(let i=0;i<n;i++){
        const x=-h+i*w,y=-h+j*w,buildCell=scan?smooth(scanP*2-(i+j)/(n*1.5)):1;
        if(buildCell<.002)continue;
        const lit=Math.max(0,1-Math.abs(j/(n-1)-wrap(t/5.6*1.7))*5)*Math.sin(Math.PI*wrap(t/5.6*1.7)),fill=(.045+.075*((i+j)%2)+lit*.07)*(1-release)*buildCell;
        poly([rotate(x,y),rotate(x+w-.4,y),rotate(x+w-.4,y+w-.4),rotate(x,y+w-.4)],{fill,stroke:.09,width:.3,color:(i+j)%2?PEARL:ICE});
      }
      for(const s of [-1,1])poly([rotate(s*36,-35),rotate(s*41,-26),rotate(s*41,26),rotate(s*36,35)],{closed:false,fill:0,stroke:.52,width:1.4,color:GOLD});
      break;
    }
  }
  ctx.restore();return true;
}
