/** Commands carry intention, never trusted precomputed events or bit poses. */
export const SCAN_MODES=Object.freeze(['continuous','once']);
export const EXAMINATION_MOVEMENTS=Object.freeze(['deliberate','classic']);
export function normalizeScanMode(value='continuous'){
  if(!SCAN_MODES.includes(value))throw new Error('Choose continuous searching or a single survey.');
  return value;
}
export function normalizeExaminationMovement(value='deliberate'){
  if(!EXAMINATION_MOVEMENTS.includes(value))throw new Error('Choose deliberate or classic examination movement.');
  return value;
}
/** Borrowing changes the working roster, but preserves the assigned duty. */
export function taskEditFingerprint(event){
  return JSON.stringify({id:event.id,revision:event.utilityRevision??0,utility:event.utility,target:event.target??null,bits:event.formationBits??event.bits});
}
export function taskEditInput(event,patch={}){
  if(!patch||typeof patch!=='object'||Array.isArray(patch)||Object.keys(patch).some(k=>!['id','kind','mode','bits','point','center','target','region','radiusFeet','followSource','light','scanMode'].includes(k)))throw new Error('Unknown instrument task edit.');
  const u=event.utility,bits=event.formationBits??event.bits;
  if(patch.kind!==undefined&&patch.kind!==u.mode||patch.mode!==undefined&&patch.mode!==u.mode||patch.bits!==undefined&&JSON.stringify(patch.bits)!==JSON.stringify(bits))throw new Error('Editing keeps this task’s instruments and purpose.');
  const next={kind:u.mode,bits:[...bits],seed:u.seed,weighty:u.weighty,
    ...(u.center?{point:{...u.center}}:{}),...(event.target?{target:event.target}:{}),
    ...(u.region?{region:structuredClone(u.region)}:{}),...(u.followSource?{followSource:true}:{}),
    ...(u.light?{light:structuredClone(u.light)}:{}),
    ...(u.mode!=='parkLight'?{radiusFeet:u.radiusFeet,scanSpeed:event.scanClock?.speed??u.scanSpeed,scanMethods:u.scanMethods}:{}),
    ...(u.mode==='areaScan'?{scanMode:normalizeScanMode(u.scanMode)}:{})};
  if(Object.hasOwn(patch,'region')){delete next.point;delete next.followSource;next.region=patch.region;}
  if(Object.hasOwn(patch,'point')||Object.hasOwn(patch,'center')){delete next.region;delete next.target;delete next.followSource;next.point=patch.point??patch.center;}
  if(Object.hasOwn(patch,'target')){delete next.point;delete next.region;next.target=patch.target;}
  if(Object.hasOwn(patch,'followSource')){
    next.followSource=patch.followSource;
    if(patch.followSource){delete next.point;delete next.region;delete next.target;}
  }
  for(const key of ['radiusFeet','light','scanMode'])if(Object.hasOwn(patch,key))next[key]=patch[key];
  return next;
}
export function taskPausePose(sample,context){
  return {positions:structuredClone(sample.positions??{}),depths:structuredClone(sample.depths??{}),
    rotations:Object.fromEntries(Object.entries(sample.rotations??{}).map(([id,rotation])=>[id,rotation+(context.transform?.angle??0)+(context.orientations?.[id]??0)]))};
}
