# Filament Flight v6.0.0

V6 develops the controls, energy structures and instruments together. It retains the existing Resonant Core design, all older formation and effect choices, saved Looks and the current Medkit integration.

## Ellie’s compact personal HUD

Effects · Home · Settings keeps Home central. Its fixed main actions are Wings, Bits and Take off/Land, followed by the small identity diamonds, dispatch confirmation and count control. A single collapsible carousel moves directly through Flight & wings and occupied bit locations. Shortcuts and directional swipes replace nested group headings. Flight pairs related controls, while detail stays in focused Simple/Advanced Settings with Back navigation. Quick effects remain in a compact bottom rail.

The personal header uses the existing customizable portrait with subtle drifting light and two new lightweight SVG ornaments. Meaningful state text, a thin HP filament, small condition tag and light switch replace the larger status blocks. Header motion, glints and reactive wording can be disabled. Motion honors strength, reduced motion, minimization and browser visibility. No animation frame rerenders the HUD or writes scene data.

Shift-click selects exact diamonds. Holding Left Shift and dragging paints selection or deselection according to the first diamond, once per instrument. Pointer/Shift release ends the gesture. Selection moves nothing until a command is confirmed.

With selected instruments, normal Bits click retracts only those that are out; a fully retracted selection summons only itself. Shift-click returns selected remote instruments to Ellie without retracting them. With no selection, the established global behavior remains. Selected recalls leave unselected assignments and shared treatment partners active, and late treatment completion cannot reclaim a recalled instrument. The dispatch icon continues to track the current visible target; neutral/enemy names remain anonymous.

## Previews without duplicate panels

Hover or keyboard focus updates the visible large built-in preview. It stays in its original panel, so no empty preview-sized hole is left behind. Only when that view is hidden or offscreen does the floating preview appear. The fallback is larger, bounded to the viewport and reuses one renderer. Leaving, filtering, closing or Escape cleans it up. Hovering remains silent and private; only Apply changes the scene.

## Thirty-two structure poses

Eight alternate structures each gain four tailored forms: draped/gathered/trailing/wrapped mantle, tall/narrow/canopy/sheltering arch, crown/coronet/halo/guard, wide/nested/tilted/enclosing orrery, elongated/compact/open/closed lantern, rising/tight/separated/crossed helices, broad/knot/vertical/folded infinity, and tiered/gathered/fanned/vault spires.

The same Pose control changes with the structure; original wing poses remain. Each structure remembers its pose and 35–160% size, including saved Looks. These options change actual geometry and depth, rather than relying on uniform scaling. Attached bits and stabilizing contours follow it; free custom positions are preserved. Pose/form/size changes blend through interruptions. Larger artwork uses bounded expanded cropping instead of flattening against the old canvas edge.

## More expressive instruments

Little atelier, Sheltering company, Lantern keepers and Ribbon relay add **16 count-specific routines**, bringing the full catalog to **48**. Their work exchanges, protective passages, rising lights and handoffs differ for one, two, three or four instruments. Passive currents and gestures remain optional.

Five additional core states—Diagnostic sweep, Protective lock, Precision alignment, Resting machinery and Current conductor—add mechanisms, scanning surfaces and energy accents around the same Resonant Core design. The existing base animation and all previous state choices remain.

A configurable expression layer covers quiet attention, travel/settling, damage, frightened, stunned, slowed, fatigued, quickened/overdrive and shared stabilization. It provides an enable switch, strength and per-situation mapping or None. Responses remain subtle by default, honor custom stations, and yield to treatment, collapse and reduced motion. Owner HP and conditions drive deployed instruments even when wings are closed or the group surrounds another token.

## Varied falls that stay on the map

Enabled zero-HP/Unconscious reactions capture instruments at their actual visible positions, including remote escorts and treatment travel. Shared seeded timing gives each collapse a different fall, orientation and resting arrangement. Resting positions are saved in scene coordinates: moving, rotating or resizing Ellie or the recipient does not move them; reloads do not reroll the event.

On recovery, each instrument rises from its saved resting point toward its current assignment. Healing does not release an actor still marked Unconscious. Existing broken/Reform wing recovery remains continuous, and Ellie stays grounded until Take off is explicitly chosen. Retracted wings stay retracted. Responses honor the existing opt-outs and do not modify HP, conditions, healing or game actions.

## Compatibility and performance

The bundled Medkit macro and Yvaelle GM Bridge remain unchanged. Existing assets, formation families, wing effects, quality preferences, audio settings and macro methods are retained. See `v6-api.md` for structure control, expression mapping and selected recall extensions.

The new motion uses pure bounded samplers, cached settings and existing capped render paths. Worker inputs now carry the small owner-response fields needed for the same expressions on both rendering paths. Resting-bit visibility checks inspect at most four saved positions, so a fallen bit can stay visible when Ellie moves offscreen. Header motion uses transform/opacity and pauses when hidden. Separate self/observer quality controls remain available.

## Validation

The final suite passed **255 automated tests**, **67 Chromium UI checks** and **14 rendered-art checks**, with zero browser runtime errors. A preservation audit compared **121 configurations per version**; all **327 previous assets** and **10 macro files** remain byte-identical. Syntax/import checks covered all 93 production modules.

## Validation limits

The optional Validation archive contains the final automated test log, HUD control-preservation audit, browser interaction report, rendered structure/formation/core-state contact sheets and performance notes. Browser checks use production controller, view, styles and Canvas painters inside a minimal Foundry ApplicationV2/API fixture. They are not a live Foundry world or multiplayer session, and do not establish GPU FPS on players’ machines. Consult the included reports for actual checks and counts.
