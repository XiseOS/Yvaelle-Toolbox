# V8 bit tools API

## V8.8 task refinements

```js
const flight = game.modules.get('filament-flight').api;
const ellie = canvas.tokens.controlled[0];
const task = flight.bitTools.get(ellie).tasks.find(job => job.mode === 'areaScan');

// Read-only local edit intention; the real job keeps working.
const edit = flight.bitTools.previewEdit(ellie, {
  id: task.id, region: {type: 'polygon', source: 'rectangle', points: [
    {x: 600, y: 400}, {x: 800, y: 400},
    {x: 800, y: 600}, {x: 600, y: 600}
  ]}
});
// Call after the player's confirmation. Revalidates the existing job.
await flight.bitTools.edit(ellie, edit);

await flight.bitTools.setPaused(ellie, true, {id: task.id});
await flight.bitTools.setPaused(ellie, false, {id: task.id});
await flight.bitTools.setExaminationMovement(ellie, 'classic');
// 'deliberate' restores the new default for subsequent examinations.

await flight.lockLantern(ellie, {x: 800, y: 600});
await flight.lockLantern(ellie, canvas.tokens.get('visible-recipient-id'));
await flight.unlockLantern(ellie);
await flight.applyLightPreset(ellie, 'closeWork');
await flight.saveLightPreset(ellie, 'travel');
await flight.resetLightPreset(ellie, 'search');
```

Area requests accept `scanMode: 'continuous' | 'once'`. Once applies to placed areas and returns after actual guarded native-cell coverage; following scans remain continuous. Task state exposes `paused`, `editable`, `assignedBits`, `yieldedBits`, `coveredCells`, `totalCells` and `scanPending`. An edit changes its existing job and assigned identities, while a new task request creates a new job. Changed region geometry restarts that area's coverage. Competing destination edits invalidate old preview intentions; medical borrowing preserves the assigned task.

Preset IDs are `closeWork`, `travel` and `search`. Apply changes the current light, Save explicitly records current brightness/range/width in a named slot, and Reset restores that slot's defaults. Subject tracking uses a persistent choice and local display updates, with no per-frame document writes.

Use the public API with an owned, placed token in the current scene. Persistent jobs use the existing four instrument identities and action reservations.

```js
const flight = game.modules.get('filament-flight').api;
const ellie = canvas.tokens.controlled[0];

// Read-only plan; it changes no flags, reservations, lighting or audio.
const plan = flight.bitTools.preview(ellie, {
  kind: 'areaScan', bits: 2, point: {x: 700, y: 500}
});

// Submit only after your own confirmation workflow.
const job = await flight.bitTools.execute(ellie, plan);
```

The HUD's shared thought renderer adds its own local animation and confirmation strip. Preview plans capture physical sources, coverage, job identity and a guard against intervening changes. Execution rechecks ownership, visibility, availability and the scene, and captures the current departure positions again.

## Jobs

`kind` is `areaScan`, `creatureScan`, `parkLight` or `dispatch`. `bits` accepts a count from one through four or unique station IDs: `leftUpper`, `rightUpper`, `leftLower`, `rightLower`.

```js
// A world-fixed 20-foot scan area.
await flight.startBitTool(ellie, {
  kind: 'areaScan', bits: 4, point: {x: 1000, y: 800}
});

// A 30-foot scan emanation following Ellie.
await flight.startBitTool(ellie, {
  kind: 'areaScan', bits: 3, followSource: true, radiusFeet: 30
});

// Close examination follows this visible creature.
await flight.startBitTool(ellie, {
  kind: 'creatureScan', bits: 2, target: canvas.tokens.get('recipient-id')
});

// Each real parked light uses one available physical bit.
await flight.startBitTool(ellie, {
  kind: 'parkLight', bits: ['leftUpper'], point: {x: 800, y: 600},
  light: {bright: 10, dim: 20, intensity: .45}
});

// Companion light: supply a target instead of a point.
await flight.startBitTool(ellie, {
  kind: 'parkLight', bits: 1, target: canvas.tokens.get('recipient-id')
});
```

Fixed area radius is five feet per chosen instrument. Following radius defaults to that value and supports a finite positive override up to 120 feet. Pixel geometry uses the scene's grid scale, including metre grids. Scans illustrate examination and do not generate discoveries, rolls, healing or rule bonuses.

## Read, stop and undo

```js
const state = flight.bitTools.get(ellie);
console.log(state.tasks, state.available, state.sources, state.undo);

await flight.bitTools.stop(ellie, {id: state.tasks[0].id});
// Or stop all tool jobs:
await flight.bitTools.stop(ellie);

if (flight.bitTools.get(ellie).undo.available) {
  await flight.bitTools.undo(ellie);
}
```

Stop returns instruments from their actual displayed positions. A later explicit command takes precedence over an older treatment's restoration. Undo is one level and local to the commanding client; mechanical action changes, scene changes and conflicting current state prevent an unsafe restoration.

## Character preferences

```js
await flight.setBitToolPreferences(ellie, {
  weightedTravel: false,
  obstacleRoutes: true,
  workingPosture: true
});

// null returns a channel to its world default.
await flight.bitTools.setPreferences(ellie, {weightedTravel: null});
console.log(flight.bitTools.getPreferences(ellie));
```

Preferences accept the three named boolean channels, `scanSpeed` from .25 to 1.5, `scanMethods`, or `null` inheritance values. These preferences belong to the owned token and do not change medical mechanics. Obstacle routing covers dispatched transfers and explicit recalls; authored continuous scan coverage is not a terrain simulation.

## Scanning styles (V8.4+)

```js
// Saves choices and updates future passes of active area/creature jobs.
// A pass already settling, scanning or closing completes with its old style.
await flight.bitTools.setScanMethods(ellie, {
  creature: ['contourTomography', 'phaseInterferometry'],
  area: ['radialRanging', 'edgeTracing', 'crosshatchSurvey']
});
console.log(flight.bitTools.get(ellie).scanMethods);

// Partial categories preserve the other saved category.
await flight.bitTools.setScanMethods(ellie, {area: ['edgeTracing']});

// Preferences affect future jobs; the dedicated setter above also updates active jobs.
await flight.setBitToolPreferences(ellie, {scanMethods: {area: ['crosshatchSurvey']}});
await flight.setBitToolPreferences(ellie, {scanMethods: null}); // All enabled again.
```

Creature IDs are `structuredLight`, `laserTriangulation`, `lidarReconstruction`, `contourTomography`, `phaseInterferometry`. Soft area IDs are `structuredLight`, `radialRanging`, `sparseReconstruction`, `edgeTracing`, `crosshatchSurvey`. V8.6 adds optional area IDs `geometricStructuredLight`, `geometricRadialRanging`, `geometricSparseReconstruction`, `geometricEdgeTracing`, `geometricCrosshatchSurvey`. The defaults retain the five soft area styles; geometric styles require selection. Both area families may be mixed in one `area` array.

Each provided category must contain at least one known unique ID. New scan options may also supply `scanMethods`; plans capture complete effective selections. These choices do not change physical routes, coverage or scan clocks. Automatic creature detours inherit the creature category. The single occupied-space acquisition survey is independent of the selected deep-scan styles.

```js
// One linked geometric frame per cooperating team; no soft styles selected.
await flight.bitTools.setScanMethods(ellie, {
  area: ['geometricStructuredLight', 'geometricSparseReconstruction']
});
```
