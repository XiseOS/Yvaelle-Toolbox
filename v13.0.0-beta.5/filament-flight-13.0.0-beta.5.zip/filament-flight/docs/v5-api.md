# Filament Flight v5.4: instruments and animation API

V6 keeps this API compatible. See `v6-api.md` for structure poses, expression mappings and selection-aware recall additions. The v6 HUD uses those recall extensions when diamonds are selected.

```js
const flight = game.modules.get('filament-flight').api;
const ellie = canvas.tokens.controlled[0];
const target = [...game.user.targets][0];
```

Commands require ownership of the source token. A patient or escort target must be a visible, placed token in the current scene; it does not need to be owned. These animation methods update only the source token's module flags. They do not heal actors, apply system effects, grant permissions, or replace the Yvaelle GM Bridge.

The four stable station IDs are `leftUpper`, `rightUpper`, `leftLower`, and `rightLower`. `flight.bits.stations` returns those IDs. Instruments never gain new identities when their count or destination changes.

## Individual and group commands

| Method | Behaviour / return |
|---|---|
| `bits.toggle(source, station)` | Summon a retracted instrument; retract one beside Ellie; recall a remote or temporarily borrowed instrument. Returns a Promise for allocation state. |
| `bits.toggleAll(source, {count?})` | Normal HUD Bits button: if any instrument is out, retract all four and cancel their outstanding actions. Otherwise summon the preferred count (or explicit 1–4 `count`) beside Ellie. Includes temporarily borrowed instruments whose saved location is retracted. Returns allocation state. |
| `bits.retractAll(source)` | Unconditionally retract every instrument, including remote, working and returning ones, and cancel queued actions. Returns allocation state. |
| `bits.gather(source)` | Shift-click/Gather: bring instruments assigned to or temporarily working at other tokens into Ellie's formation. Leave already local or genuinely retracted instruments unchanged. Interrupts affected work, preserving unrelated actions. Returns allocation state. |
| `bits.setDeployment(source, {count, enabled, bits?, duration?})` | `count` is 1–4. By default operates only on home/retracted instruments, preserving remote groups. Changing count while retracted remembers the next deployment. Explicit `bits` is a station-ID array. Returns allocation state. |
| `bits.assign(source, target, {bits, program?, travelDuration?, returnDuration?, requireAvailable?})` | Send a numeric count (1–4) selected from home/retracted instruments, or an explicit station-ID array from any group. Omitted `bits` sends one. Other assignments remain. Returns an animation handle. |
| `bits.recall(source, {bits?, retract?, duration?})` | Recall selected IDs; omitted IDs selects remote instruments. `retract:true` returns into Ellie; otherwise they join her formation. Returns allocation state. |
| `bits.returnAll(source)` | Cancels outstanding actions, recalls all remote allocations to Ellie and turns off active group effects. Already retracted instruments remain retracted. Returns `{returning}`. |
| `bits.setGroup(source, group, patch)` | Change `home` or a target token ID's formation/settings. Returns allocation state. |
| `bits.setEffect(source, group, {id?, enabled?, strength?})` | Select/toggle one token effect for a group. Strength is 0–3. Returns allocation state. |
| `bits.getEffects()` | Return the 16 effect definitions with IDs, labels, categories and descriptions. Each adapts to the actual participating count. |
| `bits.getState(source)` | Read allocation, group and action state without changing anything. |

With `requireAvailable:true`, `bits.assign` rechecks availability inside the source token’s command queue and rejects an unavailable selection before moving anything. It never substitutes another instrument for an explicit station ID. Settled remote escorts can be redirected, but moving, returning, treating or queued instruments must finish or be explicitly interrupted first. The HUD uses this option for selected-bit dispatch. Omitting it preserves the existing explicit macro override behavior. Target existence and visibility are also checked again when the queued command runs.

Group patch fields:

- `program`: `orbit`, `drift`, `weave`, `curious`, `escort`, `social`, `vigil`, `patrol`.
- `radius`: 0.4–1.6; `personality`: 0–1; `passive`: boolean.
- `internalState`: `idle`, `auto`, `encased`, `open`, `charging`, `guarding`, `settling`. `idle` preserves the established Resonant Core animation. `auto` permits action-driven state changes.
- `effect`: `{id, enabled, strength}`; equivalent to `setEffect`.

An enabled effect records a shared `started` timestamp when switched on or changed to a different effect. Strength changes preserve that timestamp, so they do not restart its projection sequence.

Home group choices stay in sync with the existing flight settings and saved looks. Remote group settings remain independent. `flight.setBits`, `flight.setBitsEnabled`, `flight.toggleBits`, and existing `setState({gemMotion:…})` calls remain supported.

```js
await flight.bits.assign(ellie, target, {bits:2, program:'social'});
await flight.bits.setEffect(ellie, target.id, {id:'shield', enabled:true, strength:.8});
await flight.bits.setGroup(ellie, target.id, {internalState:'auto', personality:.3});
// The two other instruments are not recalled by this command.
await flight.bits.setDeployment(ellie, {count:2, enabled:false});
```

## Allocation state

`getState` returns `version:2`, `revision`, `preferredCount`, `allocations`, `groups`, `available`, `retracted`, `outBits`, `remoteBits`, `active`, `queued`, `busy`, and the compatible single `assignment` summary.

`outBits` includes active temporary reservations and instruments travelling back into Ellie, even when their saved destination is `retracted`. `remoteBits` includes temporary work at another token as well as persistent remote assignments. Use these lists for the global button and Gather availability; the saved `retracted` list alone does not describe physical presence during treatment.

Each allocation has `{id, location, revision, activity, eventId, actionTarget, actionKind}`. `location` is the intended return destination: `home`, `retracted`, or a target token ID. During treatment it deliberately retains that destination; `actionTarget` identifies the patient. Activity can include idle, travelling, escorting, scanning, treating, finishing, returning and queued.

Each occupied group has `{id, target, bits, count, presentBits, presentCount, borrowedBits, status, program, radius, personality, passive, internalState, effect}`. `target` is null for home. Intended members remain listed while borrowed; `presentBits` and `presentCount` show those available to its current formation. IDs expose no token names. HUD recipient naming must still apply visibility/disposition rules.

Persistent allocation is stored separately from the flight flag. Replacing a saved flight look does not accidentally erase remote assignments. All renderer work uses shared timestamps; animation frames do not write document flags.

## Treatment lifecycle

```js
const action = await flight.bits.treat(ellie, target, {
  bits:2, style:'membrane', priority:100,
  audio:false, timeout:180000
});
// Resolve your macro's check/healing through its existing, authorised path.
await action.finish({outcome:'success'});
```

Use the installed treatment catalog's style IDs. Omitted `bits` selects two; `bits:'pair'` is also accepted. Selection prefers available instruments at the patient, then those deployed around other remote tokens, then those beside Ellie, and finally retracted instruments. Busy actions retain their scheduler protections: free instruments are preferred before queueing or replacing occupied ones. Explicit station arrays are supported. Existing treatment settings (`style`, `intensity`, `scale`, `detail`, `audio`, `audioSettings`) remain accepted.

A treatment temporarily reserves its instruments. Unused members of other groups remain there and adapt their formation. On completion or cancellation, borrowed instruments return to their current intended assignments and group settings. A newer explicit diamond, assignment, deployment or recall command takes precedence over an older action. Redirecting one instrument cancels its interrupted action cleanly and returns the action's remaining instruments; no duplicate instruments are created.

Global retract/gather commands explicitly override the affected reservations, like `returnAll`, so an owner can recover their instruments without waiting on an old task. Late completion from that task cannot restore its previous destination. Wing deployment and flight mode are unchanged by these commands.

Handles expose `{id, done, finish(result), cancel(reason), status}`. `done` resolves with `{id, status, outcome, reason}`. `finish` accepts an outcome object, an outcome string, or degree 0–3 (`criticalFailure`, `failure`, `success`, `criticalSuccess`). Awaiting `finish` or `cancel` waits for the return lifecycle, not merely the flag write. `bits.finish(source,id,result)` and `bits.cancel(source,id,reason)` provide equivalent ID-based control.

Timeouts, lost targets, disconnected owners and scene changes have cleanup paths. Lost remote targets release their instruments back to Ellie. Effects remain cosmetic; treatment mechanics remain in Ellie's Medkit dialogue and the existing GM Bridge.

## Custom sequences and priorities

`bits.register(name, definition)` compiles a named sequence. `bits.play(source, nameOrDefinition, options)` returns the same handle type; `bits.unregister(name)` and `bits.getAnimations()` manage registrations for the current client session.

Supported steps remain `move`, `wait`, `formation`, `glow`, `effect`, `rotate`, `return`, plus nested `parallel` and `repeat`. Paths can use source, target or world coordinates. Sequence steps may address a subset of the reserved station IDs. Existing local sprite effects remain supported. Token fields and internal states use the separate `setEffect` / `setGroup` methods above; they are not new sequence step names.

```js
const action = await flight.bits.play(ellie, {
  name:'A quiet inspection',
  steps:[
    {type:'move', to:{space:'target',x:-.65,y:-.1}, duration:850, arc:.3},
    {type:'glow', strength:1.2, mode:'field', duration:900},
    {type:'formation', formation:'orbit', radius:.6, turns:1, duration:2400},
    {type:'return', duration:800}
  ]
}, {target, bits:['leftUpper','rightUpper'], priority:60, conflict:'queue'});
await action.done;
```

Priority is 0–1000; higher queued priority goes first, with FIFO ties. Persistent escort reservations use priority 5 and yield to temporary actions. Active actions use `conflict:'queue'` by default; `reject` fails if busy and `replace` interrupts equal/lower-priority owners of the requested stations. Replacing a higher-priority action is rejected. Duration, nesting, track counts, point ranges and local asset paths are bounded at submission.

## PF2e condition reactions (v5.2)

V5.2.1 preserves this API. Unconscious recovery now leaves `airborne` and `rendering.flightActive` false, with `effective.mode` grounded, until a later explicit takeoff. Open wings still complete the chosen Reform; bit assignments and the selected flight mode remain saved. `conditionResponse.collapse.flightGrounded` is an internal acknowledgement for repairing old recovery records, not an option macros should set. Ordinary actor reactions no longer replace selected non-normal or HP-driven wing artwork; the unassigned normal appearance can still use its mapped actor animation.

`flight.conditionReactions` configures cosmetic responses to the **source actor's** effective conditions. Those conditions drive Ellie's local and remote instruments; the recipient's conditions do not replace the source's state. Reads are synchronous and do not modify documents. Configuration methods require source ownership and return a Promise for the resulting settings.

| Method | Return / behavior |
|---|---|
| `conditionReactions.get(source)` | Defensive copy of all resolved settings. |
| `conditionReactions.configure(source, patch)` | Deep-merge the supplied controls and per-condition choices. Omitted siblings remain unchanged. |
| `conditionReactions.reset(source)` | Restore default reaction settings, retaining the saved flight look and bit allocations. |
| `conditionReactions.getState(source)` | Current cosmetic response: active conditions, priority, levels and collapse/recovery phase. |

```js
await flight.conditionReactions.configure(ellie, {
  enabled: true,
  wings: true,
  bits: true,
  conditions: {
    unconscious: {enabled: true},
    frightened: {strength: .35, style: 'tremor'},
    fatigued: {strength: .5},
    quickened: {enabled: false}
  }
});
const response = flight.conditionReactions.getState(ellie);
console.log(response.label, response.collapse.phase);
```

Settings shape:

```js
{
  enabled: true, wings: true, bits: true,
  conditions: {
    unconscious: {enabled: true, strength: 1, style: 'default'},
    stunned:     {enabled: true, strength: .6, style: 'default'},
    prone:       {enabled: true, strength: .6, style: 'default'},
    frightened:  {enabled: true, strength: .6, style: 'default'},
    fatigued:    {enabled: true, strength: .6, style: 'default'},
    slowed:      {enabled: true, strength: .6, style: 'default'},
    quickened:   {enabled: true, strength: .6, style: 'default'}
  }
}
```

`strength` is 0–1. For the six non-unconscious conditions, `style` accepts `default`, `none`, or any existing **condition** animation ID from `flight.getCapabilities().effectCatalog.conditions`. Categories organize that library without restricting assignments. `none` suppresses that condition's extra wing artwork, while its other enabled bit/wing responses remain available. Unconscious uses `style:'default'` only: it holds and resumes the existing selected **Reform** animation (`rethread`, `weave` or `recall`), falling back to `rethread`. Disable that condition to opt out; do not assign an unrelated damaged/collapsed style to it. Its positive strength enables the full hold/recovery sequence; zero opts out.

Priority is deterministic: Unconscious, Stunned, Prone, Frightened, Fatigued, Slowed, then Quickened. One reaction owns extra wing artwork; compatible restrained movement/power responses combine underneath. Saved manual conditions, temporary effects, formations, custom stations and appearance are retained. While unconscious, the existing Reform broken phase takes precedence; retracted wings remain retracted. Recovery begins when the **Unconscious condition is removed**, rather than from an HP increase alone.

`getState` includes:

- `enabled`, `wings`, `bits`: effective switches.
- `active`: entries `{id, label, value, strength, style}`.
- `primary`, `label`: leading condition and a readable status message.
- `levels`: bounded visual intensities; `rawLevels`: current/interpolated actor condition values.
- `collapse`: `{id, phase, mix, progress, reformProgress, started, bits, originsWorld, originDepths}`. `phase` is `awake`, `falling`, `fallen`, or `recovering`. These are read-only sampled diagnostics, not command arguments.

A single event-driven token flag records each condition transition. All observers sample its server-clock timing. Render frames neither write flags nor change system conditions. Unconsciousness cancels queued/active temporary **visual** work; borrowed instruments remain visibly grounded through a paused return and recover toward their current assignments. New treatment/sequence requests are rejected while the instrument collapse is active. Explicit recall/assignment commands remain authoritative; a stale task cannot restore an older allocation. Disabling the relevant response releases paused returns. Scene restoration reconciles an interrupted pause write or changed actor condition.

`filamentFlightStateChanged` continues to notify the HUD of these changes. `flight.getState(source).conditionResponse` provides the same current response inside the complete flight snapshot. This feature does not change PF2e actions, HP, flight rules, effects, ownership or the GM Bridge.

## Wing-side station movement (v5.2)

Small independent hovering, turns and corrections remain bounded around each assigned wing-side station. They retain the selected Resonant Core design and existing internal animation. Set these per-source controls through the established gem-motion API:

```js
await flight.setGemMotion(ellie, {
  stationMotion: true,
  stationMotionStrength: .45
});
// Opt out without resetting any saved station positions:
await flight.setGemMotion(ellie, {stationMotion: false});
```

`stationMotion` is boolean; `stationMotionStrength` is 0–1. The default is enabled at strength 0.55. The global/local animation and reduced-motion preferences still apply. These controls supplement wing-side stations; standalone groups keep their own formation programs, radius and personality settings.

## Private treatment and audio previews (v5.2)

`await flight.previewTreatment(options)` opens a **local** preview dialog using the production treatment sampler and sound family. It reserves no instruments, deploys no real bits, applies no healing or effects, spends no resources and sends no shared animation. Source and target are optional display/audio context; omitted values use the controlled token and first targeted token when available.

```js
const preview = await flight.previewTreatment({
  source: ellie,
  target,
  style: 'membrane',
  count: 2,
  intensity: 1,
  scale: 1,
  detail: 'standard',
  audio: true,
  outcome: 'success'
});
// Optional cleanup from a calling macro:
preview.close();
```

Supported options:

| Option | Values / default |
|---|---|
| `source`, `target` | Placed Token or TokenDocument; optional. Only used for the preview's existing appearance, portrait and audio context. |
| `style` | Any of the 14 treatment IDs; default `suture`. The same original and restorative catalog is used by `bits.treat`. |
| `count` | 1–4 preview instruments; default 2. |
| `intensity` | 0.25–2; default 1. |
| `scale` | 0.5–1.75; default 1. |
| `detail` | `low`, `standard`, or `high`; default `standard`. |
| `audio` | Boolean, default false. The dialog can toggle sound. Existing local mute/volume controls remain respected. |
| `audioSettings` | Same normalized treatment audio configuration accepted by `bits.treat`, including custom cue paths. |
| `outcome` | `success` (default), `criticalSuccess`, `failure`, or `criticalFailure`. This previews a result without resolving any rules. |
| `soundOnly` | Boolean. Hide the animation canvas while auditioning the selected treatment sounds. |

The returned handle has `close()`, `stop()` (also closes), and a read-only `closed` property. The dialog provides Pause/Play, Replay, count, outcome and sound controls. Closing it releases its canvas/audio, hook listeners and animation loop. It respects local reduced motion and automatically stops its sound while the browser is hidden. Scene teardown closes the preview. This API is independent of the existing Yvaelle GM Bridge.

## v5.3 additive structure options

The existing structure API also accepts `lantern`, `helices`, `infinity` and `spires`. Enumerate the normal catalogs for all available choices. Existing form IDs, condition/reaction calls, bit allocation semantics and treatment APIs are unchanged. The new condition styles remain selectable across categories through the existing effect-style API.
