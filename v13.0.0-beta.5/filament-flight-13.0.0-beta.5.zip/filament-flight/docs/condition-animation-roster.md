# Condition effects on Original wings — 7.8.0

**Original filament wings are the only structure.** All 41 supported actor statuses have fitting effects on their existing ribs and web, including the Stunned progression and Unconscious/Reform response. Alternate forms, structures and their selector have been removed. V7 appearance and animation controls remain available in Settings.

## Automatic effects on Original wings

| Actor condition | Filament effect |
| --- | --- |
| Blinded | Slow searching sweeps cross the fan; returning feedback currents travel along existing spars. |
| Clumsy | Misaligned light runs and corrective seams catch up unevenly across neighboring ribs. |
| Concealed | Soft veil shimmer travels across the web with subdued light along its rim. |
| Confused | Contrary outward and returning currents follow competing clocks, with a local conflicting return loop. |
| Controlled | Four existing spars carry synchronized command rails and unnaturally coordinated charges. |
| Cursebound | Large interlocking ritual tatting weaves through the existing web; higher values strengthen its cinching light. |
| Dazzled | Broad diffusion bands and bowed glints spread softly through the filaments. |
| Deafened | Resonance channels lose their connecting return span and their travelling beat. |
| Doomed | Faint return channels carry light shoulderward as it unthreads; higher values leave less surviving light. |
| Drained | Thinning ebb channels draw light toward the shoulders through the familiar lattice. |
| Dying | Intermittent failing relays follow the existing resting/broken material; higher values weaken their pulses. |
| Encumbered | Load-bearing stays and weighted brace light cross the lower spars with a heavier stroke. |
| Enfeebled | Yielding support currents hang between existing ribs while their spar light weakens and returns. |
| Fascinated | Currents converge along the fan toward a lingering inner focus. |
| Fatigued | Gentle support stays and shallow recovery currents accompany a heavier stroke while the span stays usable. |
| Fleeing | Fast retreating currents and windward returns sweep through the existing wing. |
| Frightened | Nervous light seams quiver above protective crossed guard currents. |
| Grabbed | Local tether catches, taut connecting light and elastic returns pull against the existing spars. |
| Hidden | Quiet near-root guard light and close returning channels reduce the outward activity. |
| Immobilized | Binding cuffs cinch the shoulderward web while short root currents remain connected. |
| Invisible | Fine coherent refraction traces and neighboring echoes follow the same wing contours. |
| Off-Guard | Incomplete catch currents trace a depleted middle guard and its exposed return. |
| Paralyzed | The wing body holds still; small electrical crackles and forks can continue locally along its ribs. |
| Persistent Damage | Local typed injury treats the existing sails: heat tongues, rime fractures, electrical arcs, dissolved channels and fitting damage currents. |
| Petrified | Angular facet locks and rigid connecting seams hold over the original ribs. |
| Prone | Quiet resting drapes and shallow channels follow the existing grounded posture. |
| Quickened | Fast doubled charges and short afterimages route through the existing spars. |
| Restrained | Tightening ribbon bands and crossed binding threads lie across the existing lattice. |
| Sickened | Uneven rolling fronts and queasy returning currents pass through the web. |
| Slowed | Weighted lagging light and delayed release packets accompany a slower held-release cadence. |
| Stunned | The familiar interruption remains: mild at 1, stronger at 2 and motionless at 3 after its short transition. |
| Stupefied | Spaced relays miss their signals and recover unevenly across successive spars. |
| Unconscious | Existing Broken Reform holds the broken lattice and rebuilds during recovery without automatic takeoff. |
| Undetected | Quiet shoulderward currents leave the existing wing readable with subdued outward activity. |
| Unnoticed | Dormant root charges and faint transmitted web traces carry an almost silent signal. |
| Wounded | Repair sutures and tension currents bridge the existing ribs, with light along a supporting patch seam. |
| Glitching — SF2e | Diagnostic relays and signal packets drop and reconnect locally, distinct from Stunned's phase tears. |
| Suppressed — SF2e | Defensive shield fronts recoil across the same web, fed by shoulderward light channels. |
| Untethered — SF2e | Slow independently drifting currents retain fixed shoulder connections without a propulsion stroke. |
| Malevolence — adventure | Intrusive currents and opposing returns travel through neighboring existing ribs. |
| Dead — Foundry status | Static extinguished links and small shoulder embers remain on the resting/broken lattice. |

Energy effects have bounded path budgets and continuous cycles. They are attached to the displayed material and receive the same HP and collapse cuts. Existing wing structure stays recognizable; no status selects a replacement body.

## Reaction controls and held states

The tiny HUD status icon controls automatic reactions per token. **Settings → Condition reactions** retains the master switch, separate wing/bit switches, individual strength and **No extra wing animation** choices. Disabling a status effect preserves the Original wing artwork and its appearance preferences.

Stunned uses its actual value: **1** keeps most of the wingbeat with a mild interruption, **2** has a deeper disruption, and **3** settles into complete stillness. Paralyzed holds the body while its dedicated crackle remains local; Petrified and Stunned 3 retain their held clocks. Reduced motion holds decorative detail still. Fatigued retains a broad usable wing span instead of collapsing it.

Prone, Paralyzed and Stunned 3 retain module-flight grounding. Unconscious collapse returns flight to rest, and removing the condition never automatically takes off. Waking while still Prone rebuilds the existing resting posture directly, without a brief full flap. Old saved forms read as Original without triggering any of these behaviors.

Several active conditions can contribute compatible bounded filament effects on the original wing body. Automatic HP damage and glitches remain independently controlled and visible with chosen artwork. Bit supports and stabilization follow the displayed original filaments. Existing medical animations, macros and all 418 bundled assets are preserved.

## Reading conditions and observer limits

The effective PF2e actor-condition API takes priority over stale icons or inactive items. Valued conditions use their actual severity, bounded for visual intensity. Legacy `flat-footed` is accepted as Off-Guard.

Concealed, Hidden, Undetected and Unnoticed may be relative to particular observers, and Off-Guard may apply only against particular attacks or creatures. Filament Flight reacts to explicit actor-level state; it does not calculate per-observer detection or infer Off-Guard from flanking. Effects respect existing token visibility and grant no concealment or invisibility themselves.

SF2e's three additional conditions use effect items. The reader accepts their prepared slug or canonical source identity, ignores expired/suppressed/disabled items, and can fall back to prepared condition roll options. Glitching reads its counter badge for severity.

| SF2e condition | Canonical item ID | Interpretation |
| --- | --- | --- |
| Glitching | `6A2QDy8wRGCVQsSd` | Actor-wide technical malfunction; its counter badge supplies the value. The visual does not resolve the flat check or add Stunned. |
| Suppressed | `enA7BxAjBb7ns1iF` | Incoming fire; defensive status light remains separate from the selected low-power injury artwork named Suppressed. |
| Untethered | `z1ucw4CLwLqHoAp3` | Unsupported drift without suitable propulsion. The animation neither moves the token nor supplies propulsion. |

Canonical sources are `Compendium.sf2e.conditions.Item.<ID>`. A glitching piece of equipment does not by itself establish an actor-wide condition or a failed wing power source.

Persistent Damage reads active `system.persistent.damageType` values across concurrent condition items. Its observed identity includes those types, so changing Fire to Cold updates the effect without requiring the general condition to end first. Up to three recognized types contribute together; additional types remain mechanically untouched.

The fitting patterns cover Acid, Bleed, Bludgeoning, Cold, Electricity, Fire, Force, Mental, Piercing, Poison, Slashing, Sonic, Spirit, Vitality, Void and Untyped. Radiation is accepted for compatibility. Legacy Positive/Negative map to Vitality/Void. These are local material effects on the original wing.

## Excluded actor conditions

| Condition | Reason |
| --- | --- |
| Broken | Applies to objects. A broken item does not establish that the wing source is broken; manually chosen injury artwork remains available. |
| Friendly, Helpful, Hostile, Indifferent, Unfriendly | Dispositions toward particular creatures do not establish a general wing impairment. |
| Observed | Ordinary detection baseline rather than a changed wing state. |

No artwork program changes condition values, HP, actions, speeds, token elevation, detection rules or bit assignments.

## Sources and verification

The existing coverage follows [PF2e Remaster conditions](https://2e.aonprd.com/Conditions.aspx), including [Dying](https://2e.aonprd.com/Conditions.aspx?ID=69), [Wounded](https://2e.aonprd.com/Conditions.aspx?ID=99), [Off-Guard](https://2e.aonprd.com/Conditions.aspx?ID=58) and [Persistent Damage](https://2e.aonprd.com/Conditions.aspx?ID=86). Cursebound, adventure-specific Malevolence and the SF2e representations were checked against the preserved Foundry source snapshot at commit `4cf4c97f92dfe68d6f8edb722d2d4c4cdeb01ba3`:

- [PF2e condition definitions](https://github.com/foundryvtt/pf2e/tree/4cf4c97f92dfe68d6f8edb722d2d4c4cdeb01ba3/packs/pf2e/conditions)
- [SF2e condition effects](https://github.com/foundryvtt/pf2e/tree/4cf4c97f92dfe68d6f8edb722d2d4c4cdeb01ba3/packs/sf2e/conditions)
- [Malevolence condition](https://github.com/foundryvtt/pf2e/blob/4cf4c97f92dfe68d6f8edb722d2d4c4cdeb01ba3/packs/pf2e/campaign-effects/malevolence/malevolence.json)
- [Persistent-damage payload](https://github.com/foundryvtt/pf2e/blob/4cf4c97f92dfe68d6f8edb722d2d4c4cdeb01ba3/src/module/item/condition/data.ts)

See the [7.7.0 release notes](v7.7.0-release.md) for the validation status, completed automated checks, production visual review and limits of live Foundry multiplayer testing.
