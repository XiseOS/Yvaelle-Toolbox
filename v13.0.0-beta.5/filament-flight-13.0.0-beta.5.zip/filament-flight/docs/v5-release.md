# Filament Flight 5.0.0 — release and validation

This build is based on the latest supplied v4.0.0 module and the confirmed `yvaelle_smart_medicine_nonowner_fixed.js` macro. The module ID remains `filament-flight`; version is 5.0.0 and existing flight schema remains 2. A separate allocation flag stores the four persistent instruments.

## Included

- Five-page personal HUD with central Home, tiny individual bit diamonds, current-target dispatch, occupied-group tabs and safe recipient labels.
- Independent home/remote bit groups, count-specific formations, smooth transitions, task borrowing and recovery.
- Preserved default Resonant Core animation, plus optional encased/open/charging/guarding/settling and action-responsive states.
- Sixteen count-aware cosmetic token effects, passive personality gestures and native preview libraries.
- Eight expanded Medkit techniques, all ten existing treatment choices, 87 revised nonmusical audio assets and patient-local audio controls.
- Preserved categorized condition/reaction libraries, independent wings/flight/float controls, custom positions, Looks and separate local/observer quality settings.
- Additive public allocation/effect/group API with existing sequence, treatment, priority and cancellation contracts retained.

## Verification

All 47 current automated tests passed. They cover split assignments, stable identities, treatment reuse and restoration, newer-command precedence, deleted targets, count/program transitions, bounded effect geometry, glow gates, core-state defaults, audio locality, macro mechanics preservation, worker/preview cleanup and flight renderer lifecycle. Native browser fixtures exercise the actual HUD handlers and animation painters. Visual contact sheets were inspected for the treatment surfaces, sixteen token effects and optional core states.

The confirmed Medkit setup/GM Bridge code and complete Medicine mechanics suffix are checked against baseline hashes. The working bridge itself is unchanged.

Ninety-eight older regression tests were also run against both v4 and v5: both passed the same 93. The five inherited failures assert superseded sound-catalog sizes, old audio filenames or pre-independent-float behaviour; they are recorded rather than represented as current passing tests. No new failure appeared in that comparison.

## CPU comparison

Method: eleven poses, stationary and moving (22 scenarios), sixteen frames per sample, median of four measured rounds after warm-up. Both versions receive identical resolved inputs. Native Canvas draws four 512px layers; this is not a live Foundry/WebGL benchmark.

| Measurement | V4 | V5 |
| --- | ---: | ---: |
| Collapsed, stationary geometry | 3.76 ms | 3.18 ms |
| Collapsed, moving geometry | 3.82 ms | 3.17 ms |
| Held wing body with animated cores, cached geometry | 1.03 ms | 0.21 ms |

Median geometry time across the 22 cases fell by about 15.6%. Maximum sampled coordinate difference was 8.5e-14, at floating-point rounding scale. Geometry improvements do not translate directly into an equal FPS gain: raster work still dominates some folded poses, and canvas paint timings vary. The stronger cache result applies only when the wing body is held; genuinely animated condition artwork continues updating.

A second check exercised the live wing-rig update path with one and four moving tokens (neutral, cocoon and collapsed; medium detail, 60 display samples and 24 artwork frames per second). Four cases used approximately 1–7% less measured CPU time; cocoon with one token and collapsed with four tokens were approximately 1.8% and 0.2% higher. Upload counts and sampled pixel areas stayed identical. These short runs show modest overall CPU changes and timing noise, not a uniform FPS improvement. Native rasterisation remains the main cost.

A live Foundry world, GPU uploads, scene lighting, other installed modules, networking between real clients and your particular GPU were not available for validation. This release therefore does not claim a measured recovery of the reported 30 FPS. The existing in-module performance tools and separate quality controls remain available for scene testing.

## Deployment

Replace the module folder and reload all clients. Replace the Medkit command or import its JSON. Leave the confirmed Yvaelle GM Bridge unchanged. The supplied animation API controls cosmetic effects; it does not bypass token permissions or itself grant rules effects/healing.
