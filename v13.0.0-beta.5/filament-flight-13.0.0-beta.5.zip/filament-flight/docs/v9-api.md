# Filament Flight 9 current API

Foundry VTT 14 only. The exported API version is `9.0.0`. Use an owned, placed Token or TokenDocument. Visual commands do not roll Medicine, heal, consume resources or confer a rules benefit. Existing ownership and controller refusals remain binding.

```js
const flight = game.modules.get('filament-flight').api;
const ellie = canvas.tokens.controlled[0];
if (!ellie) return ui.notifications.warn('Select Ellie first.');
await flight.openHUD(ellie);
```

## New optional wing gestures

```js
await flight.wingGesture(ellie, 'keystoneRelay');
await flight.wingGesture(ellie, 'reliquaryRelease', {intensity: .75});
await flight.stopWingGesture(ellie); // Captured smooth release.
```

**Keystone relay** passes upper-wing tension into the lower curls with an answering phrase. **Reliquary release** opens gathered lower filaments into a composed rise. Both use the original wing rig and return to the selected pose. They require V9 signature craft and the existing Enhanced wing-animation switches; reduced motion, collapse and condition authority still apply. Turning the new setting off does not erase the saved gesture, but it suppresses its display. Requests for a disabled new gesture refuse before writing.

The original eight gesture IDs remain: `lunarBow`, `quietFlourish`, `featherTurn`, `heldBreath`, `resolveArc`, `softShelter`, `greetingFold`, `trailingBloom`. Enumerate current definitions with `flight.getWingGestures()`. Use `setPose` for a continuing pose; a gesture is a finite additive expression.

## Artwork choices and scope

Configure **V9 signature craft** and **V9 medical craft** in Module Settings. They are independent world choices. The former controls the new signature materials and manual gestures; the latter refines Enhanced medicine. Classic medicine remains the existing per-use `enhanced:false` path. `diagnosticScan:false` independently skips the opening scan without adding another stage.

```js
const patient = [...game.user.targets][0];
if (!patient) return ui.notifications.warn('Target a visible patient.');
const care = await flight.bits.treat(ellie, patient, {
  style: 'tissueLens', bits: 2, enhanced: true,
  diagnosticScan: false, audio: false, conflict: 'queue'
});
// When your actual rules workflow supplies its result:
await care.finish('success');
// Alternatively cancel with care.cancel('interrupted').
```

`finish` accepts `criticalFailure`, `failure`, `success`, `criticalSuccess`, their indices 0-3, or an object with `outcome`. The existing Medkit supplies the actual result. A pending cosmetic treatment waits for that workflow; calling `finish` itself does not apply healing.

Numeric `bits` selects available instruments using the existing borrowing preferences. For a deliberate mixed-team test use exact identities, for example `bits:['leftUpper','leftLower']`; do not assume a numeric count must borrow a busy scanner when idle instruments are available.

## Existing work and scoped recovery

```js
const scan = await flight.startBitTool(ellie, {
  kind: 'creatureScan', target: patient,
  bits: ['leftUpper','rightUpper'], seed: 9009, scanSpeed: .6
});
await flight.setLightIntensity(ellie, .7);
await flight.setBitToolScanSpeed(ellie, 1.2, {id: scan.id});
await flight.undoBitCommand(ellie);
```

An Undo for a light-only intent edit retains unrelated current tasks, their clocks/handles and newer active pace. If the original command also changed deployment or allocation it retains captured destination recovery; it is not silently reclassified as light-only. A newer pace edit invalidates unsafe older broad recovery. A refusal or no-change edit does not consume a still-valid earlier Undo.

`setBitCount` retains its public authority distinctions. Live allocation-affecting refusals now occur before writes. Simple accepted count changes combine flight preference and allocation; a mixed count-plus-group edit may still make a later group update. Explicit saved-state edits on off-scene tokens remain supported.

The continuing tool API is documented in `v8-bit-tools-api.md`. Its seeded scan, edit, pause, stop and lantern examples remain supported. Current storage scopes are described in `../START-HERE.md`.

## Local performance capture

```js
flight.performance.start({duration: 10000});
// Perform the controlled fixture sequence, then inspect/export through My view.
const report = flight.performance.getReport();
flight.performance.stop(); // Also restores local component isolation.
```

Reports identify the build, runtime/backend, quality and observed worker path. Main-thread CPU is the union of instrumented synchronous spans; stage rows can overlap. Worker timing/result age, browser frame intervals and GPU cost are separate responsibilities. Captures omit actor/world/document content. Capture duration remains 2-30 seconds. Use the separate Validation reference scene and browser trace for device comparisons.

## Returning to an older installer

V9 artwork can be disabled without downgrading. If you do choose to install pre-v9 code, first clear stored new gesture events while v9 is still installed; pre-v9 gesture validation does not recognize their names. A smooth Stop can retain that name during its release, so clear the saved event explicitly:

```js
for (const scene of game.scenes.contents) for (const token of scene.tokens.contents) {
  const gesture = token.getFlag('filament-flight','flight')?.v7?.wingGesture;
  if (token.isOwner && ['keystoneRelay','reliquaryRelease'].includes(gesture?.name)) {
    await flight.setV7Preferences(token, {wingGesture: null});
  }
}
```

This only removes those gesture events on owned placed copies. Keep your ordinary world backup for a version change. No saved pose, allocation, diagnostic preference or other appearance is reset by the command.

## Historical guides

`v6-api.md` records removed alternate structures and `setStructurePose`; it is historical. The current structure is the original filament wings. Current examples use exported methods above rather than retired form APIs.
