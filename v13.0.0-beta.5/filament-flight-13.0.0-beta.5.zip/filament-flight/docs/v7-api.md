# V7 material and wing animation API

Use the module API with an owned Token or TokenDocument, just like existing flight controls. These commands update saved preferences once per action; the renderer performs the animation locally.

```js
const api = game.modules.get("filament-flight").api;
const token = canvas.tokens.controlled[0];
await api.wingGesture(token, "quietFlourish", {intensity: 0.45});
await api.stopWingGesture(token);
```

`getWingGestures()` returns the eight gesture IDs and their descriptions/timing. Gesture options accept finite numeric `intensity` from 0 to 1 and `hold` from 0 to 60000 milliseconds. Dismissal releases from current displayed channels, including after the animation library is disabled.

```js
await api.setV7Preferences(token, {
  gemInteriors: true,
  gemStrength: 0.58,
  transitionVariants: false
});
await api.classicVisuals(token);
await api.enhancedVisuals(token);
```

Cosmetic preference keys are `enabled`, `gemInteriors`, `filamentTexture`, `refraction`, `wingAnimations`, `seamlessActions`, `formations`, `medkit`, `transitionVariants`; their three strengths are `gemStrength`, `filamentStrength`, `refractionStrength`. Boolean feature and strength overrides accept `null` to inherit the module setting. Strengths range from 0 to 1. Mode accepts `enhanced`, `classic` or `null` (inherit). Prefer the public methods instead of writing serialized animation records.

`getTreatmentStyles(token)` returns the allowed medical catalog for the current character. `getState(token).v7` contains the resolved material snapshot and current wing gesture channels. Portable Looks retain material choices and inheritance, excluding running wing gestures. Existing looks load compatible remaining preferences when obsolete appearance fields are present.

New methods retain existing ownership checks and do not assign keybindings. Keybindings still require the HUD character pin and are unassigned by default.

For a complete downgrade, use the standalone **Restore-6.6.7-Compatibility** macro before installing the preserved release. The macro also works after downgrade and reports any documents it cannot update. Its JS and JSON forms are bundled under `macros`.
