# Filament Flight v7 — Ellie’s ensemble

Historical release notes. Lunar glow and chosen ensemble presence were removed in 7.0.2; see `v7.0.2-release.md` for current behavior.

V7 extends Ellie’s existing technological filament wings and metallic Resonant Core bits. The magenta palette, housing silhouettes, wing anchors and existing control logic remain the foundation. Lunar and character motifs are visual interpretations of her guarded presence, restrained tenderness and partly unfolded lunar-lily imagery; they add no powers or medical rules.

## New artwork and expression

- **Layered gemstone interiors:** depth-sorted translucent facets, suspended folded filaments, travelling highlights and inner veins animate inside the existing gemstone. Working, projection, Lunar and presence states can change the internal concentration. The solid footprint and housing stay unchanged.
- **Textured wing filaments:** tension ribs and narrow travelling highlights add braid-like depth to the existing transparent web. Detail scales with viewer quality.
- **Lunar Unfolding:** an activatable visual aspect opens internal strands and veined filament detail across the ensemble. Activation, dismissal and reversal blend from the current visible state.
- **Chosen presence:** Neutral, Guarded, Unguarded and Resolute express selected body language through wing tension, gemstone disclosure and restrained housing articulation. Presence is a player choice and does not infer Ellie’s feelings. Bit posture keeps every station, world heading and focus bearing intact.
- **Refracted light:** softly evolving internal lenses and caustics enrich the circular light, token lantern and wing wash. They are drawn inside Foundry’s existing native light coloration, so the established radii, clipping, walls, brightness and aim remain authoritative. Plain magenta and the prior appearance remain selectable. There are no additional light sources.

## New choreography

Eight wing gestures: **Lunar bow, Quiet flourish, Feather turn, Held breath, Resolve arc, Soft shelter, Greeting fold and Trailing bloom**. Each has a distinct deformation score with measured entry, work and release. Manual gestures take priority over automatic accents. Interrupted gestures retain sampled position and velocity rather than restarting from rest.

Eight formation families: **Nightbloom, Prism gallery, Velvet court, Tension loom, Lily vigil, Folded correspondence, Pearl canopy and Resonant measure**. Each has four count-specific scores, bringing the library from **64 to 96** routines. Roles, pauses, local movement and internal work differ by count. Bits retain their owned lanes during flow and work instead of exchanging sides for a gesture.

Eight medical techniques: **Capillary bridge, Iris patch, Segmented cradle, Filtration circuit, Fibril repair, Prismatic tissue lens, Pulse reservoir and Lunar care canopy**. They add distinct patient-surface geometry, count-specific instrument roles and preparation/work/resolution sequences. The returning instruments release their medical artwork gradually. Existing PF2e rolls, healing rules, targets and GM bridge remain unchanged. The bundled macro exposes enhanced-animation and variation choices per use. New optional audio assets follow existing mute, volume and custom-sound controls.

Handoffs have controlled variation: three wing-score interpretations, four formation passage accents, four medical transit paths and three refracted-light ignition seeds. Variation is chosen from saved action identity rather than randomizing each frame. All paths keep their original endpoints. Rapid reversals and action interruptions start from sampled visible channels. Automatic wing accents accompany relevant opening, pose, movement, lighting and medical actions without displacing manual gestures.

## Controls and compatibility

**Advanced Settings → V7 · Ellie’s ensemble** contains independent switches for the master upgrade, gemstone interiors, filament texture, refraction, Lunar aspect, presence, wing gestures, seamless action accents, formations, Medkit additions and transition variation. Feature choices can inherit world defaults or be overridden for the current character. Four strength controls tune the interior, filament, refraction and presence additions. New rendering features default on; Lunar stays off and presence stays Neutral until selected.

Home provides Lunar and presence controls. Wing and ensemble libraries preview locally before applying. Saved cosmetic Looks support the new preferences and include additional v7 presets; they never capture transient gesture clocks or alter HP, flight, light power or assignments.

**Classic 6.6.7** restores the earlier visual route without reinstalling. New saved formation and treatment choices are interpreted through classic fallbacks when their libraries are disabled. The `Restore-6.6.7-Compatibility` macro prepares those choices for a full downgrade. The original v6.6.7 archive is preserved separately, unchanged. See `START-HERE.md` for the downgrade procedure.

The v6.6.7 health recovery, grounded open-wing stabilization, wing-mounted lantern wash, cross-scene HUD character pin and unassigned optional keybindings remain. New visual additions respect collapse, active work, reduced motion, viewer quality and existing stabilization priorities.

## Performance and verification

New geometry is procedural and drawn through existing renderers. No new ticker or per-frame flag write is introduced. Worker command identity excludes decorative clocks, preventing animation frames from repeatedly cancelling the same work. Stationary bit artwork now sleeps when movement is disabled; its display placement still follows the token every frame. Material layers scale with quality, while reduced motion holds decorative motion still.

The validation archive includes the complete automated suite, production-renderer regressions, classic pixel/geometry comparisons, interrupted-motion checks, actual Canvas artwork sheets and motion clips, native Foundry v14 lighting shader compile/raster evidence, static import checks and package hashes. Shader verification uses the pinned Foundry v14.365 sources; artwork checks use production samplers and painters.

A live user Foundry world, installed system build and multiplayer session were unavailable. These checks do not establish live multiplayer frame rates or replace playtesting in your world. The validation report records the final test counts, source hashes and precise evidence scopes.
