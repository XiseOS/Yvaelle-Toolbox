/** Private, read-only previews. No bit reservations, token writes or Medicine calls. */
import {sampleV7Appearance} from './v7-ensemble.mjs?v=13.0.3';
import {sampleTreatmentTransit,treatmentTransitionVariant,classicTreatmentStyle} from './hardlight-v7-medkit.mjs?v=13.0.3';
import {treatmentUpgradeEnabled} from './hardlight-treatment.mjs?v=13.0.3';
import {configuration} from './config.mjs?v=13.0.3';
import {TREATMENT_LABELS,TREATMENT_TIMING,treatmentOptions,treatmentPhase,treatmentOutcomeDuration,sampleTreatment,paintHardlight,prepareHardlightArtwork} from './hardlight-treatment.mjs?v=13.0.3';
import {samplePreviewBits} from './compact-animation-preview.mjs?v=13.0.3';
import {paintResonantBit} from './bit-resonance.mjs?v=13.0.3';
import {withCoreActivity} from './bit-core-states.mjs?v=13.0.3';
import {createTreatmentAudioPreview} from './audio-runtime.mjs?v=13.0.3';
import {createHUDMotion,hudMotionOptions} from './hud-motion.mjs?v=13.0.3';
import {updateWorldBitWaveDirection,retainBitWaveDirections} from './bit-wave-direction.mjs?v=13.0.3';
import {TREATMENT_OPERATIONS} from './treatment-choreography.mjs?v=13.0.3';
import {paintScanArtwork} from './v8-scan-art.mjs?v=13.0.3';
import {medicalPreviewPatient,medicalPreviewMask,paintMedicalPreviewPatient,releaseMedicalPreviewPatient,paintGenericPreviewPatient} from './medical-preview-patient.mjs?v=13.0.3';
import {previewQualityConfiguration} from './quality.mjs?v=13.0.3';

const IDS=['leftUpper','rightUpper','leftLower','rightLower'];
const OUTCOMES={criticalFailure:'Critical failure',failure:'Failure',success:'Success',criticalSuccess:'Critical success'};
const PHASE_LABELS={travel:'Approach',scanning:'Scan',treating:'Treatment',finishing:'Resolve',returning:'Return',complete:'Complete'};
const clamp=(n,a=0,b=1)=>Math.min(b,Math.max(a,n));
const ease=n=>{n=clamp(n);return n*n*(3-2*n);};
const lerp=(a,b,p)=>a+(b-a)*p;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const waveContexts=new WeakMap();
const genericPatientMask=scale=>({paint(ctx,draw){ctx.save();ctx.beginPath();ctx.arc(0,0,45/scale,0,Math.PI*2);ctx.clip();draw(ctx);ctx.restore();return true;}});

export function treatmentPreviewTimeline(options={}) {
  const disabled=options.v7Medkit===false||options.v7?.enabled===false||options.v7?.medkit===false;
  const spec=treatmentOptions({...options,...(disabled?{enhanced:false}:{})}),count=Math.round(clamp(Number(options.count)||2,1,4));
  const event={id:'private-treatment-preview',started:0,status:'running',travelDuration:900,returnDuration:900,
    bits:IDS.slice(0,count),treatment:spec,outcome:Object.hasOwn(OUTCOMES,options.outcome)?options.outcome:'success'};
  // workDuration (ms) stands in for a long Medicine roll (tests, slow tables)
  event.finishAt=event.travelDuration+TREATMENT_TIMING.scan+Math.max(7200,(TREATMENT_OPERATIONS[spec.style]?.period??0)*1000,Number(options.workDuration)||0);
  event.returnAt=event.finishAt+treatmentOutcomeDuration(event);
  return {event,duration:event.returnAt+event.returnDuration};
}

export function sampleTreatmentPreview(options={},elapsed=0) {
  const {event,duration}=treatmentPreviewTimeline(options),now=clamp(Number(elapsed)||0,0,duration);
  const source={x:-128,y:77},context={source,target:{x:20,y:-8},size:100,targetSize:100,orientations:{},transform:{angle:0},snapshot:{effective:{reducedMotion:!!options.reduced},v9:{medicalCraft:options.v9MedicalCraft===true},...(options.v7?{v7:options.v7}:options.v7Medkit===undefined?{}:{v7:{enabled:true,medkit:options.v7Medkit,transitionVariants:options.v7TransitionVariants!==false}})}};
  if(event.treatment.diagnosticScan)context.medicalScan={portrait:options.patientPortrait??{center:context.target,width:90,height:90,rotation:0},methods:options.scanMethods};
  const origins=Object.fromEntries(event.bits.map((id,i)=>[id,{x:source.x+(i%2?10:-10),y:source.y+(i<2?-12:11)}]));
  const base=()=>({positions:structuredClone(origins),rotations:{},glows:{},effects:[]});
  let phase=treatmentPhase(event,Math.min(now,event.returnAt)),sample=sampleTreatment(event,Math.min(now,event.returnAt),context,phase,base());
  let stage=phase.phase==='travel'?'depart':phase.phase==='scanning'?'scan':phase.phase==='treating'?'tool':event.outcome;
  let stageStarted=phase.phase==='travel'?0:phase.phase==='scanning'?event.travelDuration:phase.phase==='treating'?event.travelDuration+TREATMENT_TIMING.scan:event.finishAt;
  if(now>=event.returnAt){
    const p=ease((now-event.returnAt)/event.returnDuration);
    const upgraded=treatmentUpgradeEnabled(context,event.treatment),variant=treatmentTransitionVariant(event,context.snapshot?.v7?.transitionVariants!==false);
    sample={...sample,positions:Object.fromEntries(event.bits.map((id,index)=>[id,upgraded?sampleTreatmentTransit(sample.positions[id],origins[id],p,{index,size:context.size,reduced:!!options.reduced,variant,returning:true}):{x:lerp(sample.positions[id].x,origins[id].x,p),y:lerp(sample.positions[id].y,origins[id].y,p)-Math.sin(p*Math.PI)*18}])),effects:[],tools:Object.fromEntries(event.bits.map(id=>[id,{...(sample.tools?.[id]??{type:'plate',amount:0}),amount:(sample.tools?.[id]?.amount??0)*(1-ease(p/.42))}])),coreStates:Object.fromEntries(event.bits.map(id=>[id,{state:'settling',amount:.6,progress:p}])),depths:Object.fromEntries(event.bits.map(id=>[id,1]))};
    phase={phase:now>=duration?'complete':'returning',progress:p};stage='return';stageStarted=event.returnAt;
  }
  return {event,duration,now,phase,stage,stageElapsed:Math.max(0,(now-stageStarted)/1000),sample,context,origins};
}

/** Production treatment sampler, surfaces and Resonant Core painter on one private Canvas. */
export function paintTreatmentPreview(canvas,options={},elapsed=0) {
  const ctx=canvas?.getContext?.('2d');if(!ctx)return null;
  const patient=medicalPreviewPatient(canvas,options.patientToken,options.tokenImage);
  const frame=sampleTreatmentPreview({...options,patientPortrait:patient?.portrait},elapsed),{sample,event,context}=frame;
  const {tokenImage,patientToken,patientPortrait,...appearance}=options,fingerprint=JSON.stringify({...appearance,patient:patientToken?.id??null});
  let waves=waveContexts.get(canvas);
  if(!waves||waves.fingerprint!==fingerprint||elapsed<waves.elapsed){waves={fingerprint,elapsed,waves:new Map()};waveContexts.set(canvas,waves);}
  waves.elapsed=elapsed;retainBitWaveDirections(waves.waves,event.bits);
  const width=canvas.width,height=canvas.height,bounds=patient?.bounds;
  const stageWidth=Math.max(345,bounds?2*Math.max(Math.abs(bounds.x),Math.abs(bounds.x+bounds.width))+130:0);
  const stageHeight=Math.max(285,bounds?2*Math.max(Math.abs(bounds.y),Math.abs(bounds.y+bounds.height))+90:0),unit=Math.min(width/stageWidth,height/stageHeight);
  const hardware=samplePreviewBits({...options,count:4,id:'orbit',elapsed:options.reduced?0:elapsed,animated:!options.reduced,coreState:'idle'});
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,width,height);ctx.fillStyle=options.background??'#1b141c';ctx.fillRect(0,0,width,height);
  // zoom > 1 frames the patient (the Medkit window's small preview well)
  const zoom=Math.max(1,Math.min(3,Number(options.zoom)||1)),U=unit*zoom,tx=context.target?.x??0,ty=context.target?.y??0;
  if(zoom>1){ctx.translate(width/2-tx*U,height/2-ty*U);ctx.scale(U,U);}else{ctx.translate(width/2+22*unit,height/2);ctx.scale(unit,unit);}
  ctx.save();ctx.strokeStyle='#856276';ctx.globalAlpha=.14;ctx.lineWidth=.5;
  for(let i=-3;i<=3;i++){ctx.beginPath();ctx.moveTo(-155,i*35);ctx.lineTo(140,i*35);ctx.stroke();}ctx.restore();
  // Small origin marker keeps the entire departure/return visible without a second real token.
  // A framed (zoomed) preview leaves her off-frame: the bits arrive from the lower left.
  if(zoom<=1){ctx.save();ctx.translate(context.source.x,context.source.y);ctx.globalAlpha=.7;ctx.fillStyle='#2e212b';ctx.strokeStyle='#cfae76';ctx.lineWidth=.8;ctx.beginPath();ctx.arc(0,0,19,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#eedfd0';ctx.font='16px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('E',0,1);ctx.restore();}
  const bit=(id,i)=>{
    const part=hardware.find(x=>x.station===id)?.part??hardware[i]?.part,p=sample.positions[id];if(!part||!p)return;
    const activity=sample.coreStates?.[id]??{state:frame.phase.phase==='treating'?'open':frame.phase.phase==='finishing'?'settling':'charging',amount:.6,progress:frame.phase.progress};
    const tool=sample.tools?.[id]??(!['travel','returning','complete'].includes(frame.phase.phase)?{type:frame.phase.phase==='scanning'?'lens':['precision','suture','microloom'].includes(event.treatment.style)?'probe':'plate',amount:.45*(frame.phase.phase==='finishing'?1-frame.phase.progress:1),progress:frame.phase.progress}:null);
    const skin={...withCoreActivity(part.hardware,activity,{selection:'auto',time:elapsed/1000}),tool};
    const glow=sample.glows[id];
    const wave=updateWorldBitWaveDirection(waves.waves,id,{position:p,charge:context.source,
      target:['travel','returning','complete'].includes(frame.phase.phase)?null:context.target,
      now:elapsed,animated:!options.reduced,reduced:!!options.reduced});
    paintResonantBit(ctx,{...part,points:[[p.x,p.y,sample.depths?.[id]??1,.92]],hardware:{...skin,scale:(skin.scale??1)*.58,angle:(skin.angle??0)+(sample.rotations[id]??0),glow:glow?{...glow,direction:wave.direction}:skin.glow}});
  };
  const artwork=sample.effects.map(fx=>({effect:fx,prepared:fx.effect==='hardlight'?prepareHardlightArtwork(fx):null}));
  const diagnostic=sample.effects.some(e=>e.medicalDiagnostic);
  const tokenMask=diagnostic?(patient?medicalPreviewMask(patient,context.target,event.treatment.scale):genericPatientMask(event.treatment.scale)):undefined;
  const effect=plane=>{ctx.save();ctx.translate(context.target.x,context.target.y);ctx.scale(event.treatment.scale,event.treatment.scale);for(const entry of artwork){if(entry.effect.effect==='v8-scan')paintScanArtwork(ctx,entry.effect,{plane,tokenMask});else paintHardlight(ctx,entry.effect,{plane,prepared:entry.prepared});}ctx.restore();};
  effect('rear');event.bits.forEach((id,i)=>{if((sample.depths?.[id]??1)<0)bit(id,i);});
  if(patient)paintMedicalPreviewPatient(ctx,patient);
  else paintGenericPreviewPatient(ctx,context.target);
  effect('front');event.bits.forEach((id,i)=>{if((sample.depths?.[id]??1)>=0)bit(id,i);});ctx.restore();return frame;
}

export async function previewTreatment(options={}) {
  const document=globalThis.document,window=document?.defaultView??globalThis;
  if(!document?.body)throw new Error('Open the Foundry scene to preview a treatment.');
  const source=options.source?.object??options.source??globalThis.canvas?.tokens?.controlled?.[0];
  const target=options.target?.object??options.target??[...(globalThis.game?.user?.targets??[])][0];
  const cfg=previewQualityConfiguration(configuration()),raw=source?.document?.getFlag?.('filament-flight','flight')??source?.getFlag?.('filament-flight','flight')??{},v7=sampleV7Appearance(raw.v7,cfg,0),spec=treatmentOptions({...options,style:v7.enabled&&v7.medkit?options.style:classicTreatmentStyle(options.style??'suture')}),count=Math.round(clamp(options.count??2,1,4));
  const details=['low','standard','high'];spec.detail=details[Math.min(details.indexOf(spec.detail),Math.max(0,details.indexOf(cfg.treatmentDetail??'high')))];
  const doc=source?.document??source,skin=doc?.getFlag?.('filament-flight','flight')?.gemMotion??{};
  const image=target?.mesh?.texture?.baseTexture?.resource?.source;
  const params={...spec,count,v7,v9MedicalCraft:cfg.v9MedicalCraft===true,reduced:!!cfg.reduced,tokenImage:image,patientToken:target,scanMethods:options.scanMethods??doc?.getFlag?.('filament-flight','v8Tools')?.scanMethods,background:'#1b141c',design:skin.design??cfg.gemDesign,program:skin.program??cfg.gemProgram,size:skin.size??cfg.gemSize,metalHighlights:skin.metalHighlights??cfg.gemMetalHighlights,coreDepth:skin.coreDepth??cfg.gemCoreDepth??false,coreDepthStrength:skin.coreDepthStrength??cfg.gemCoreDepthStrength??.35,outcome:Object.hasOwn(OUTCOMES,options.outcome)?options.outcome:'success'};
  const audio=createTreatmentAudioPreview({style:options.style??spec.style,audioSettings:spec.audioSettings??{},enhanced:spec.enhanced,source,configuration});
  const dialog=document.createElement('dialog');dialog.className='ff-treatment-preview';dialog.setAttribute('aria-label',`${TREATMENT_LABELS[spec.style]} preview`);
  let prefs={};try{prefs=globalThis.game?.settings?.get('filament-flight','hudPreferences')??{};}catch{}
  const motionOptions=hudMotionOptions({cfg,prefs}),motion=createHUDMotion(motionOptions);
  dialog.dataset.ffMenuMotion=String(motionOptions.enabled&&motionOptions.strength>0);
  for(const key of ['background','panel','accent','text','gold'])if(/^#[0-9a-f]{6}$/i.test(prefs.theme?.[key]??''))dialog.style.setProperty(`--ff-${key}`,prefs.theme[key]);
  dialog.innerHTML=`<header><div><small>ELLIE · FIELD MEDICINE</small><h2>${esc(TREATMENT_LABELS[spec.style])}</h2><p>Private preview · no healing or bit deployment</p></div><button type="button" data-close aria-label="Close preview">×</button></header><div class="ff-treatment-preview-body"><canvas width="640" height="520" role="img" aria-label="Treatment animation preview"${options.soundOnly?' hidden':''}></canvas><div class="ff-treatment-preview-phases" aria-label="Treatment stages">${['travel','scanning','treating','finishing','returning'].map(p=>`<span data-stage="${p}">${PHASE_LABELS[p]}</span>`).join('')}</div><div class="ff-treatment-preview-options"><label>Bits <select data-count>${[1,2,3,4].map(n=>`<option value="${n}"${n===count?' selected':''}>${n}</option>`).join('')}</select></label><label>Outcome <select data-outcome>${Object.entries(OUTCOMES).map(([id,label])=>`<option value="${id}">${label}</option>`).join('')}</select></label><label class="ff-treatment-preview-audio"><input type="checkbox" data-audio${spec.audio?' checked':''}> Sound</label></div><p data-status role="status">${cfg.reduced?'Reduced motion is respected. Stages remain visible.':'Preview follows the actual treatment choreography.'}</p></div><footer><button type="button" data-play>Pause</button><button type="button" data-replay>Replay</button><button type="button" data-close>Close</button></footer>`;
  dialog.querySelector('[data-outcome]').value=params.outcome;
  const canvas=dialog.querySelector('canvas'),events=new window.AbortController(),{signal}=events,returnFocus=document.activeElement;
  // Resolve My view before allocating and scheduling this private painter.
  // A target's observer cap is never consulted by this rehearsal.
  // "Audition sound" only needs the stage clock: the hidden canvas is never painted.
  const raster=cfg.treatmentDetail==='low'?448:cfg.treatmentDetail==='high'?768:640,soundOnly=!!options.soundOnly;
  if(soundOnly)canvas.width=canvas.height=1;else{canvas.width=raster;canvas.height=Math.round(raster*520/640);}
  const previewFPS=Math.max(12,Math.min(36,cfg.rigFPS??24));
  motion.bindDisclosures(dialog,{signal});
  let closed=false,playing=false,elapsed=0,began=0,raf=null,lastPaint=-Infinity,frame=null,soundEnabled=spec.audio,paused=false;
  const hooks=[],stages=[...dialog.querySelectorAll('[data-stage]')],statusNode=dialog.querySelector('[data-status]'),playButton=dialog.querySelector('[data-play]');
  let shownPhase=null,shownStatus=null;
  const stopAudio=()=>audio.stop();
  const time=()=>elapsed+(playing?window.performance.now()-began:0);
  const halt=()=>{if(playing)elapsed=time();playing=false;if(raf!=null)window.cancelAnimationFrame(raf);raf=null;stopAudio();};
  const paintFrame=()=>{
    if(closed)return;
    frame=soundOnly?sampleTreatmentPreview(params,time()):paintTreatmentPreview(canvas,params,time());
    if(!frame)return;
    // Stage chips and status change a few times per second, not every frame.
    if(frame.phase.phase!==shownPhase){shownPhase=frame.phase.phase;for(const el of stages){const current=el.dataset.stage===shownPhase,changed=current&&!el.classList.contains('is-current');el.classList.toggle('is-current',current);if(changed)motion.feedback(el,{kind:'press'});}}
    if(soundEnabled&&playing&&frame.phase.phase!=='complete')audio.update({stage:frame.stage,elapsed:frame.stageElapsed});
    const status=frame.phase.phase==='complete'?'Preview complete. Replay to watch again.':`${PHASE_LABELS[frame.phase.phase]}${params.reduced?' · reduced motion':''} · ${Math.min(frame.now/1000,frame.duration/1000).toFixed(1)}s`;
    if(status!==shownStatus){shownStatus=status;statusNode.textContent=status;}
    if(frame.phase.phase==='complete'){halt();paused=true;playButton.textContent='Play';}
  };
  const paint=()=>{try{paintFrame();}catch(error){halt();paused=true;playButton.textContent='Play';shownStatus=statusNode.textContent=`Preview stopped: ${error.message}`;}};
  // 4 ms of slack keeps e.g. 24 fps on 60 Hz displays (a strict test lands at 20 fps).
  const interval=1000/previewFPS;
  const play=()=>{if(closed||playing||paused||document.hidden)return;playing=true;began=window.performance.now();lastPaint=-Infinity;const tick=now=>{raf=null;if(!playing)return;if(!dialog.isConnected){close();return;}const since=now-lastPaint;if(since>=interval-4){paint();lastPaint=since<interval*2?lastPaint+interval:now;}if(playing)raf=window.requestAnimationFrame(tick);};raf=window.requestAnimationFrame(tick);};
  const restart=()=>{halt();elapsed=0;paused=false;playButton.textContent='Pause';paint();motion.feedback(dialog.querySelector('.ff-treatment-preview-phases'),{kind:'press'});play();};
  const close=()=>{
    if(closed)return;halt();closed=true;audio.close();events.abort();for(const [hook,id]of hooks)globalThis.Hooks?.off?.(hook,id);dialog.inert=true;
    void motion.exit(dialog,{kind:'library'}).finally(()=>{
      waveContexts.delete(canvas);releaseMedicalPreviewPatient(canvas);motion.destroy();const restoreFocus=document.activeElement===document.body||dialog.contains(document.activeElement);
      if(dialog.open)dialog.close();dialog.remove();canvas.width=canvas.height=1;
      if(restoreFocus&&returnFocus?.isConnected)returnFocus.focus({preventScroll:true});
    });
  };
  for(const button of dialog.querySelectorAll('[data-close]'))button.addEventListener('click',close,{signal});
  dialog.addEventListener('cancel',event=>{event.preventDefault();close();},{signal});dialog.addEventListener('close',close,{signal});
  playButton.addEventListener('click',()=>{if(frame?.phase.phase==='complete'){restart();return;}paused=!paused;if(paused)halt();else play();playButton.textContent=paused?'Play':'Pause';},{signal});
  dialog.querySelector('[data-replay]').addEventListener('click',restart,{signal});
  dialog.querySelector('[data-count]').addEventListener('change',event=>{params.count=Number(event.target.value);restart();},{signal});
  dialog.querySelector('[data-outcome]').addEventListener('change',event=>{params.outcome=event.target.value;restart();},{signal});
  dialog.querySelector('[data-audio]').addEventListener('change',event=>{soundEnabled=event.target.checked;if(!soundEnabled)stopAudio();else if(playing&&frame)audio.update({stage:frame.stage,elapsed:frame.stageElapsed});},{signal});
  // Only a focused control would change value under the wheel; elsewhere the dialog scrolls.
  dialog.addEventListener('wheel',event=>{if(event.target.matches('select,input[type=number],input[type=range]')&&event.target===document.activeElement)event.preventDefault();},{signal,passive:false});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)halt();else play();},{signal});
  for(const hook of ['canvasTearDown','closeGame'])if(globalThis.Hooks?.on)hooks.push([hook,globalThis.Hooks.on(hook,close)]);
  document.body.append(dialog);
  try{dialog.showModal();motion.enter(dialog,{kind:'library'});paint();play();}catch(error){close();throw error;}
  return Object.freeze({close,stop:close,get closed(){return closed;}});
}
