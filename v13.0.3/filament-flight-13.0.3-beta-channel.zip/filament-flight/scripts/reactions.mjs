import {ID,runtimeConfiguration} from './config.mjs?v=13.0.3';
import {normalizeFlag} from './state.mjs?v=13.0.3';
import {readHealth,healthKey,sampleHP} from './conditions.mjs?v=13.0.3';
import {CriticalAdapter} from './critical-adapter.mjs?v=13.0.3';
import {ActorTokenIndex} from './actor-token-index.mjs?v=13.0.3';
import {ConditionResponseRuntime} from './condition-response-runtime.mjs?v=13.0.3';
import {reactionVisualActive} from './condition-response.mjs?v=13.0.3';

const clock=()=>Number(game.time?.serverTime)||Date.now();
const values=collection=>collection?.contents??(collection?.values?[...collection.values()]:[]);
const activation=doc=>{const raw=doc.getFlag(ID,'flight');return raw?.activation??raw?.started;};
const active=doc=>reactionVisualActive(doc.getFlag(ID,'flight'),doc.getFlag(ID,'bitAllocations'),doc.getFlag(ID,'bitAnimations'));

export class Reactions {
  constructor(api,manager) {
    this.api=api;this.manager=manager;this.health=new Map();this.latest=new Map();this.pending=new Map();this.tokens=new ActorTokenIndex();this.responses=new ConditionResponseRuntime(this);
    this.critical=new CriticalAdapter((actor,event)=>this.criticalHit(actor,event),e=>manager.report(e));
  }
  tokenDocuments(actor=null) {
    this.tokens.ensure(game.scenes);
    return [...(actor?this.tokens.forActor(actor):this.tokens.all())].filter(active);
  }
  indexToken(doc){this.tokens.ensure(game.scenes).upsert(doc);}
  removeToken(doc){this.tokens.remove(doc);this.pending.delete(doc.uuid);this.responses.removeToken(doc);}
  seedActor(actor) {this.responses.conditions(actor);const hp=readHealth(actor);if(actor?.uuid&&hp&&!this.health.has(actor.uuid))this.health.set(actor.uuid,hp);}
  seed() {
    this.tokens.rebuild(game.scenes);
    const actors=new Map(this.tokenDocuments().filter(d=>d.actor?.uuid).map(d=>[d.actor.uuid,d.actor]));
    this.health=new Map([...actors].map(([id,actor])=>[id,readHealth(actor)]));
    this.latest.clear();this.pending.clear();this.responses.seed();
  }
  configure() {
    const cfg=runtimeConfiguration();
    if(cfg.effectsEnabled&&cfg.criticalReactions&&cfg.hpReactions&&['pf2e','sf2e'].includes(game.system?.id))this.critical.install(CONFIG.Actor?.documentClass);
    else this.critical.uninstall();
  }
  /** HP and Unconscious as last read by the actor/item/effect hooks above
   * (seedActor, observeHealth); a live read only for an actor not seen yet. */
  cachedHealth(actor){const id=actor?.uuid;return id&&this.health.has(id)?this.health.get(id):readHealth(actor);}
  context(doc,now=clock()) {
    const live={health:this.cachedHealth(doc?.actor),seed:doc?.uuid??'flight'},context={...live,...this.responses.context(doc,live.health)},pending=this.pending.get(doc.uuid),raw=doc.getFlag(ID,'flight');
    if(!pending)return context;
    // Bridge the actor update and its later token-flag update without snapping to
    // the target HP appearance first. This is a local rendering cache, not a write.
    if(!active(doc)||activation(doc)!==pending.activation||healthKey(context.health)!==pending.timing.healthKey||
      now>=pending.timing.started+pending.timing.duration){this.pending.delete(doc.uuid);return context;}
    const saved=raw?.hpTransition;
    if(saved?.id!==pending.previousID&&saved?.healthKey===pending.timing.healthKey&&saved.started>=pending.timing.started-100){
      this.pending.delete(doc.uuid);return context;
    }
    return {...context,hpTransition:{...pending.timing,pending:true}};
  }
  writer(actor) {
    const users=values(game.users).filter(u=>u.active||u.id===game.user.id);
    const gm=users.filter(u=>u.isGM).sort((a,b)=>a.id.localeCompare(b.id))[0];if(gm)return gm.id;
    if(!actor)return undefined;
    const preferred=actor.primaryUpdater;
    if(preferred&&users.some(u=>u.id===preferred.id))return preferred.id;
    return users.filter(u=>actor.canUserModify?.(u,'update')||actor.testUserPermission?.(u,'OWNER')).sort((a,b)=>a.id.localeCompare(b.id))[0]?.id;
  }
  observe(actor,changes={},options={},userId) {
    this.manager.invalidateActor?.(actor);
    try {this.responses.observe(actor);this.observeHealth(actor,changes,options??{},userId);}catch(error){this.manager.report(error);}
  }
  observeHealth(actor,changes={},options={},userId) {
    if(!actor?.uuid)return;
    const previous=this.health.get(actor.uuid),next=readHealth(actor);
    if(next)this.health.set(actor.uuid,next);else this.health.delete(actor.uuid);
    if(!previous||!next)return;
    if(previous.value===next.value&&previous.max===next.max&&previous.temp===next.temp&&previous.unconscious===next.unconscious)return;
    const docs=this.tokenDocuments(actor),now=clock();
    const event={id:foundry.utils.randomID(16),started:now,healthKey:healthKey(next),temp:next.temp,strength:Math.min(1,0.4+
      (Math.max(0,previous.value-next.value)+Math.max(0,previous.temp-next.temp))/next.max),
      tokens:docs.map(doc=>({doc,activation:activation(doc)}))};
    this.latest.set(actor.uuid,event.id);
    this.critical.observe(actor,previous,next,options,userId,event);
    const cfg=runtimeConfiguration();
    if(!cfg.effectsEnabled||!cfg.hpReactions)return;
    // Every client starts the same cosmetic transition immediately. Only the
    // elected writer persists it so a reconnect can reconstruct the deadline.
    const transitions=new Map();
    if(healthKey(previous)!==healthKey(next))for(const {doc,activation:session} of event.tokens) {
      const raw=doc.getFlag(ID,'flight');if(raw?.autoHP===false)continue;
      const data=normalizeFlag(raw,now),pending=this.pending.get(doc.uuid);
      const livePending=!!pending&&pending.activation===session&&pending.timing.healthKey===healthKey(previous);
      if(livePending)data.hpTransition=pending.timing;
      const resume=livePending||this.manager.resumeHPTransition?.(doc);
      const timing={id:event.id,started:now,duration:cfg.hpRecoveryDuration,healthKey:event.healthKey,from:sampleHP(data,previous,cfg,now,resume).profile};
      transitions.set(doc.uuid,timing);this.pending.set(doc.uuid,{activation:session,previousID:raw?.hpTransition?.id,timing});
    }
    if(this.writer(actor)!==game.user.id)return;
    const damage=previous.max===next.max&&!options.damageUndo&&(next.value<previous.value||next.temp<previous.temp);
    const heal=previous.max===next.max&&!options.damageUndo&&next.value>previous.value;
    for(const {doc,activation:session} of event.tokens) {
      const raw=doc.getFlag(ID,'flight');if(raw?.autoHP===false)continue;
      const patch={};
      if(transitions.has(doc.uuid))patch.hpTransition=transitions.get(doc.uuid);
      if(heal){patch['cues.damage']=null;patch['cues.critical']=null;
        if(cfg.healingPulses)patch['cues.heal']={id:event.id,kind:'heal',started:now,duration:cfg.healingDuration,strength:Math.min(1,0.4+(next.value-previous.value)/next.max)};
      } else if(damage){patch['cues.heal']=null;
        if(cfg.damageFlares)patch['cues.damage']={id:event.id,kind:'damage',started:now,duration:cfg.damageDuration,strength:event.strength};
      }
      if(!Object.keys(patch).length)continue;
      void this.api.automatic(doc,patch,()=>{
        const current=runtimeConfiguration();return this.writer(actor)===game.user.id&&current.effectsEnabled&&current.hpReactions&&doc.getFlag(ID,'flight')?.autoHP!==false&&
          this.isCurrent(doc,actor,event,session);
      }).catch(e=>this.manager.report(e));
    }
  }
  isCurrent(doc,actor,event,session) {
    const hp=readHealth(doc.actor);
    return this.latest.get(actor.uuid)===event.id&&activation(doc)===session&&
      healthKey(hp)===event.healthKey&&hp?.temp===event.temp;
  }
  async criticalHit(actor,event) {
    const cfg=runtimeConfiguration();if(!cfg.effectsEnabled||!cfg.hpReactions||!cfg.damageFlares||!cfg.criticalReactions)return;
    for(const {doc,activation:session} of event.tokens) {
      if(doc.getFlag(ID,'flight')?.autoHP===false)continue;
      await this.api.automatic(doc,{'cues.critical':{id:event.id,kind:'critical',started:clock(),duration:cfg.damageDuration,strength:event.strength}},()=>{
        const current=runtimeConfiguration();return current.effectsEnabled&&current.hpReactions&&current.damageFlares&&current.criticalReactions&&
          doc.getFlag(ID,'flight')?.autoHP!==false&&this.isCurrent(doc,actor,event,session);
      });
    }
  }
}
