import {v11Geometry,v11Paint,v11PaletteAt,v11Active} from './v11/wing-damage.mjs?v=13.0.3';
import {WING_COLOR, cubic} from './wing-art.mjs?v=13.0.3';
import {POSES, weightsFor, ease, getWingMotionStyle} from './poses.mjs?v=13.0.3';
import {conditionPaths,disturbPoint,disturbanceParameters} from './filament-vfx.mjs?v=13.0.3';
import {growthPaths,sweepPoint,sweepInfluence} from './flight-dynamics.mjs?v=13.0.3';
import {recallWarp,strandGrowth,recallLights} from './v12/landing-recall.mjs?v=13.0.3';
import {conditionAccents,fitOwnedEffectPoint,withEffectExtent,enhancedPathParameters} from './condition-art.mjs?v=13.0.3';
import {completeConditionWarp,completeConditionAccents,completeConditionMaterialPaths} from './complete-condition-art.mjs?v=13.0.3';
import {variantAccents,variantPointParameters} from './effect-variants.mjs?v=13.0.3';
import {movementAccents} from './movement-art.mjs?v=13.0.3';
import {choreographedGems} from './gem-choreography.mjs?v=13.0.3';
import {transformStructurePoint,structureStrandStrength} from './energy-structures.mjs?v=13.0.3';
import {bitIntentCurrents} from './bit-intent.mjs?v=13.0.3';
import {paintStabilizer,stabilizerField,stabilizerCurrents} from './stabilizer-art.mjs?v=13.0.3';
import {v7WingWarp,v7WingPointCoordinates,v7WingRigIdentity,v7WingMaterialPaths} from './v7-wing-material.mjs?v=13.0.3';
import {actorConditionWarp,actorConditionAccents,actorConditionMaterialPaths} from './condition-wing-motion.mjs?v=13.0.3';
import {statusWingBeatPhase} from './status-flight-character.mjs?v=13.0.3';
import {originalStatusFilamentAccents,originalStatusMaterialPaths} from './status-filament-effects.mjs?v=13.0.3';
import {workingWingWeights} from './v8-motion.mjs?v=13.0.3';
import {paintSoulParts} from './soul-light.mjs?v=13.0.3';
import {reactionLight,REACTION_TINTS} from './quick-choreography.mjs?v=13.0.3';
import {drainGeometry,paintV11Parts,drainLit} from './v11/shadow-wings.mjs?v=13.0.3';
import {healGeometry,healPaint} from './v11/heal-wing.mjs?v=13.0.3';
import {emoteGeometry} from './v11/emote-apply.mjs?v=13.0.3';
import {withSideFold,lightPalettes,lightPaletteAt,litPalette} from './v11/world-paint.mjs?v=13.0.3';

/** Filament topology derived from the original drawing. Each point carries its
 * distance from its shoulder (u); z is depth relative to the token, not elevation.
 * There are no solid wing panels. The original atlas/source are left untouched.
 */
export const ROOT = Object.freeze([27,-13]);
export const ART_SIZE=600;
export const RIBS=[
  [ROOT,[85,-25],[99,-176],[165,-202]], [ROOT,[84,-46],[115,-139],[160,-141]],
  [ROOT,[103,-53],[160,-123],[197,-78]], [ROOT,[124,-40],[193,-80],[226,-5]],
  [ROOT,[128,-48],[210,-19],[246,79]], [ROOT,[97,-15],[176,6],[197,64]],
  [ROOT,[113,4],[194,55],[211,119]], [ROOT,[98,2],[190,103],[192,176]],
  [ROOT,[86,6],[171,141],[143,218]], [ROOT,[96,13],[178,148],[96,249]]
];
const TAU=2*Math.PI;
const clamp=x=>Math.max(0,Math.min(1,x));
const point=(rib,t)=>[...cubic(rib,t),t,t];
const curve=(p,count=28,from=0,to=1)=>Array.from({length:count+1},(_,i)=>[...cubic(p,i/count),from+(to-from)*i/count]);
const ink=a=>`rgba(255,0,255,${a})`,MAGENTA=Object.freeze([255,0,255]);

function makeTopology() {
  const strands=[];
  const add=(id,points,strength,width)=>strands.push({id,points:points.map((p,i)=>[...p,i/(points.length-1)]),strength,width});
  RIBS.forEach((p,i)=>add(`rib-${i}`,curve(p,36),[0,4,9].includes(i)?1:0.7,[0,4,9].includes(i)?1.8:0.9));
  const outline=[
    [ROOT,[83,-34],[92,-176],[165,-202]],
    [[165,-202],[123,-179],[132,-142],[125,-122]],
    [[125,-122],[176,-158],[224,-23],[246,79]],
    [[246,79],[208,17],[190,46],[211,119]],
    [[211,119],[229,191],[159,222],[96,249]],
    [[96,249],[169,183],[158,118],[137,57]],
    [[137,57],[101,24],[61,14],ROOT]
  ];
  outline.forEach((p,i)=>add(`edge-${i}`,curve(p,28,i?1:0,i===6?0:1),0.95,1.05));
  for (let i=0;i<RIBS.length-1;i++) for (let j=1;j<=9;j++) {
    const t=j/10,bt=Math.min(0.96,t+0.045*Math.sin(i*2.1+j*1.9));
    const a=cubic(RIBS[i],t),b=cubic(RIBS[i+1],bt);
    const bend=[(a[0]+b[0])/2-6*Math.sin(j*1.7+i),(a[1]+b[1])/2+8];
    add(`web-${i}-${j}`,curve([a,bend,bend,b],10,t,bt),0.32+0.22*(0.5+0.5*Math.sin(i*1.5+j)),0.55);
    if ((i+j)%3===0 && j<9) {
      const ct=Math.min(0.98,t+0.13),c=cubic(RIBS[i+1],ct),cp=[(a[0]+c[0])/2+4,(a[1]+c[1])/2-6];
      add(`cross-${i}-${j}`,curve([a,cp,cp,c],10,t,ct),0.32,0.45);
    }
  }
  return strands;
}
export const STRANDS=makeTopology();
// Static source coordinates are shared by every rig and client. Their easing,
// radial weight and phase-independent sine terms never change; keeping these
// outside the frame loop avoids thousands of repeated trig/ease calculations.
const DEFORMATION_COORDINATES=new WeakMap();
const V7_DEFORMATION_COORDINATES=new WeakMap();
for(const strand of STRANDS)for(const p of strand.points){
  const w=Math.max(0,(p[0]-ROOT[0])/220);
  DEFORMATION_COORDINATES.set(p,{eased:ease(p[2]??0),w26:w*26,w8:w*w*8,sine:Math.sin(p[1]*.012),cosine:Math.cos(p[1]*.012)});
  V7_DEFORMATION_COORDINATES.set(p,v7WingPointCoordinates(p));
}
// Only seven primary contours support the four fields. Their live visible
// spans are shared with the filament body, including condition/Reform cuts.
// Echoes and loose sparks are effects, never a second structure to stabilize.
const SUPPORT_STRANDS=STRANDS.filter(s=>s.id.startsWith('edge-'));
const supportSpan=part=>(part.support||part.id.startsWith('edge-'))&&!part.echo&&!part.star&&part.strength>.025&&part.points.length>1;

/** Independent left/right deformation, before any token rotation or banking. */
const POSE_RIGIDITY=Object.freeze({forwardGuard:0.2,cocoon:0.1,wrap:0.2,aggressiveFlare:0.32,raised:0.25,collapsed:0.05,drooped:0.12,crossed:0.12,trailing:0.4});
/** v10 folded pose: the wings fold tight against her back with the lower lobes
 * hanging just past the portrait, so a collapsed (or landing) wing still reads
 * as wings at token size instead of vanishing behind the token. */
const FOLD=Object.freeze({a:.42,d:.3,curl:30,drop:66});
const LINEAR_POSES=new Set(['neutral','wrap','raised','trailing','collapsed','drooped','crossed']);
const LINEAR_POINTS=new Map();
/** Settled poses have an affine sine/cosine deformation. Compile their fixed
 * topology once and retain exactly the same continuous wingbeat. Folded poses
 * no longer re-run the general blended-pose loop for every filament vertex.
 * Weak keys retain no temporary deployment or effect vertices. */
function linearPosePoint(pose,point,amplitude){
  const folded=pose==='collapsed'&&getWingMotionStyle()!=='classic',slot=folded?'collapsed-v10':pose;
  let points=LINEAR_POINTS.get(slot);if(!points){points=new WeakMap();LINEAR_POINTS.set(slot,points);}
  let value=points.get(point);if(value)return value;
  const [x,y,u=0]=point,cached=DEFORMATION_COORDINATES.get(point),w=cached?0:Math.max(0,(x-ROOT[0])/220);
  const w26=cached?.w26??w*26,w8=cached?.w8??w*w*8,sine=cached?.sine??Math.sin(y*.012),cosine=cached?.cosine??Math.cos(y*.012);
  let a=1,b=0,c=0,d=1,ox=ROOT[0],oy=ROOT[1],z=-22;
  if(pose==='wrap'){a=Math.cos(u*2.12);d=.7;ox+=32*Math.sin(Math.PI*u);z+=52*(cached?.eased??ease(u));}
  else if(pose==='raised'){a=.64;b=.23*u;d=.52;oy-=135*u;}
  else if(pose==='trailing'){a=.48;d=.7;oy+=60*u;z-=40*u;}
  else if(folded){a=FOLD.a;d=FOLD.d;ox-=FOLD.curl*u;oy+=FOLD.drop*u;}
  else if(pose==='collapsed'){a=.12;d=.18;oy+=58*u;}
  else if(pose==='drooped'){a=.48;d=.5;oy+=110*u;}
  else if(pose==='crossed'){a=Math.cos(2.35*u);d=.3;ox-=28*u;oy+=45*u;z+=62*(cached?.eased??ease(u));}
  const dx=(x-ROOT[0])*(1-.19*amplitude),dc=(x-ROOT[0])*.19*amplitude,dy=y-ROOT[1],ds=amplitude*(w26+w8*cosine),dcY=amplitude*w8*sine;
  value=[ox+a*dx+b*dy,a*dc+b*dcY,b*ds,oy+c*dx+d*dy,c*dc+d*dcY,d*ds,z];
  // The permanent source topology is bounded; temporary source arrays should
  // not fill even the weak cache during a growing/reforming wing sequence.
  if(cached)points.set(point,value);
  return value;
}
export function deformer(weights=weightsFor('neutral'),phase=0,side=1,tipWeights=weights,lag=0) {
  const active=weights.map((weight,i)=>({weight,tip:tipWeights[i],pose:POSES[i]})).filter(x=>Math.max(x.weight,x.tip)>0.000001).map(entry=>{
    let {pose}=entry;
    if(pose==='leftForwardWrap')pose=side<0?'wrap':'neutral';
    if(pose==='rightForwardWrap')pose=side>0?'wrap':'neutral';
    return {...entry,pose,amplitude:POSE_RIGIDITY[pose]??1};
  });
  const folded=getWingMotionStyle()!=='classic';
  const phaseCosine=Math.cos(phase),beatAll=0.62+0.38*(0.5+0.5*phaseCosine),phaseSine=Math.sin(phase);
  if(active.length===1&&active[0].weight===1&&active[0].tip===1&&LINEAR_POSES.has(active[0].pose)){
    const {pose,amplitude}=active[0];
    if(lag>0)return point=>{const p=linearPosePoint(pose,point,amplitude),q=phase-lag*(point[2]??0),c=Math.cos(q),sn=Math.sin(q);return [side*(p[0]+p[1]*c+p[2]*sn),p[3]+p[4]*c+p[5]*sn,p[6]];};
    return point=>{const p=linearPosePoint(pose,point,amplitude);return [side*(p[0]+p[1]*phaseCosine+p[2]*phaseSine),p[3]+p[4]*phaseCosine+p[5]*phaseSine,p[6]];};
  }
  return point=>{
    const [x,y,u=0]=point,cached=DEFORMATION_COORDINATES.get(point);
    const result=[0,0,0],eased=cached?.eased??ease(u),w=cached?0:Math.max(0,(x-ROOT[0])/220);
    // Optional follow-through: the beat reaches each point later the further it is from the shoulder.
    const pc=lag>0?Math.cos(phase-lag*u):phaseCosine,ps=lag>0?Math.sin(phase-lag*u):phaseSine,beat=lag>0?0.62+0.38*(0.5+0.5*pc):beatAll;
    const flex=cached?cached.w26*ps+cached.w8*(ps*cached.cosine+pc*cached.sine):w*26*ps+w*w*8*Math.sin(phase-lag*u+y*0.012);
    for (let {weight,tip,pose,amplitude} of active) {
      weight+=(tip-weight)*eased;
      const dx=(x-ROOT[0])*(1-(1-beat)*amplitude);
      const dy=y-ROOT[1]+amplitude*flex;
      let px=ROOT[0]+dx,py=ROOT[1]+dy,z=-22;
      switch(pose) {
        case 'forwardGuard':
        case 'wrap': {
          // The guard leaves its tall upper tips open; the middle lobes shield
          // the torso. A cocoon instead closes every tip into an enclosing shell.
          const middle=Math.exp(-Math.pow(dy/115,2));
          const angle=pose==='wrap'?2.12:1.26+0.78*middle+0.3*clamp(dy/260);
          px=ROOT[0]+dx*Math.cos(u*angle)+32*Math.sin(Math.PI*u);
          py=ROOT[1]+dy*(pose==='wrap'?0.7:0.82);
          z=-22+52*eased;break;
        }
        case 'cocoon':
          px=ROOT[0]+112*Math.sin(Math.PI*u)-(ROOT[0]+10*Math.cos(dy*0.018))*eased;
          py=ROOT[1]+dy*0.83+8*Math.sin(Math.PI*u);
          z=-22+62*eased;break;
        case 'aggressiveFlare':{
          // A taut lance sweep: elevated inner tips, a long shoulder-facing
          // middle point and gathered lower lobes, visibly unlike neutral/open.
          const upper=ease((-dy-25)/150),lower=ease((dy-25)/235);
          px=ROOT[0]+dx*(1.03-.31*upper+.34*lower);
          py=ROOT[1]+dy*.77-(49+38*upper)*eased-28*lower*eased;
          z=-22-18*eased;break;
        }
        case 'raised':px=ROOT[0]+dx*0.64+dy*0.23*u;py=ROOT[1]+dy*0.52-135*u;break;
        case 'trailing':px=ROOT[0]+dx*0.48;py=ROOT[1]+dy*0.7+60*u;z=-22-40*u;break;
        case 'collapsed':if(folded){px=ROOT[0]+dx*FOLD.a-FOLD.curl*u;py=ROOT[1]+dy*FOLD.d+FOLD.drop*u;}else{px=ROOT[0]+dx*0.12;py=ROOT[1]+dy*0.18+58*u;}break;
        case 'drooped':px=ROOT[0]+dx*0.48;py=ROOT[1]+dy*0.5+110*u;break;
        case 'crossed':px=ROOT[0]+dx*Math.cos(2.35*u)-28*u;py=ROOT[1]+dy*0.3+45*u;z=-22+62*eased;break;
      }
      result[0]+=weight*side*px;result[1]+=weight*py;result[2]+=weight*z;
    }
    return result;
  };
}

/** Split at the token plane, including the exact interpolated crossing point.
 * A strand can produce several spans, preserving curves that cross repeatedly.
 */
export function splitDepth(points) {
  if(points.length<2)return [];
  // Most wings live wholly behind the token. Retain the existing polyline
  // instead of allocating and filling a second point array for every strand.
  let rear=true,front=true;
  for(const p of points){if(p[2]>0)rear=false;else front=false;}
  if(rear||front)return [{front:!rear,points}];
  const spans=[];
  const append=(a,b,front)=>{
    let last=spans.at(-1);
    if (!last || last.front!==front) {last={front,points:[a]};spans.push(last);}
    last.points.push(b);
  };
  for (let i=1;i<points.length;i++) {
    const a=points[i-1],b=points[i];
    if (a[2]*b[2]<0) {
      const t=-a[2]/(b[2]-a[2]),cross=a.map((v,i)=>i===2?0:v+t*(b[i]-v));
      append(a,cross,a[2]>0);append(cross,b,b[2]>0);
    } else append(a,b,(a[2]+b[2])>0);
  }
  return spans;
}

const STROKE=.22;
export function wingWarp(weights,phase,side,visual=null,flight=null,strandId='rib-4',parameters=null) {
  // (12.0.0-beta.3) a landing style's recall bends the finished warp (v12/landing-recall.mjs)
  const recall=flight?.formation?.recall;
  if(recall&&recall.style!=='reelin'){
    const plain=fold=>wingWarp(weights,phase,side,visual,{...flight,formation:{...flight.formation,recall:null,fold}},strandId,parameters);
    return recallWarp(recall,side,plain(flight.formation.fold??0),()=>plain(1));
  }
  phase=statusWingBeatPhase(phase,visual?.statusFlightCharacter,side);
  let tips=flight?.poseAnimation?.tipWeights??weights;
  if(flight?.workingPosture?.amount>0){const working=workingWingWeights(flight,side,weights,tips);weights=working.weights;tips=working.tipWeights;}
  const suppression=(visual?.suppression??0)*0.38*(visual?.motionStrength??1);
  let collapse=1-(1-(visual?.collapse??0))*(1-(flight?.formation?.fold??0))*(1-suppression);
  // Beta.29: a recovering fold may open its roots before its tips.
  let collapseTip=visual?.collapseTip==null?collapse:1-(1-visual.collapseTip)*(1-(flight?.formation?.fold??0))*(1-suppression);
  // v11 wall fold (v11/world-paint.mjs): this wing's own fold, root and tip.
  if(visual?.v11Fold){const f=withSideFold(visual,side,collapse,collapseTip);if(f){collapse=f[0];collapseTip=f[1];}}
  if(collapse||collapseTip){
    const fold=(w,amount)=>w.map((v,i)=>v*(1-amount)+(POSES[i]==='collapsed'?amount:0));
    weights=fold(weights,collapse);tips=fold(tips,collapseTip);
  }
  // v10: a light power stroke (quicker opening, slower recovery) at no
  // per-vertex cost; the optional follow-through keeps its stronger warp.
  // Flight feel (beta.23): under load the panes bend and the tips trail the
  // beat (the same follow-through, scaled by how hard she is working).
  const follow=visual?.followThrough>0,flex=follow?0:Math.round(Math.max(0,Math.min(1,visual?.flightFlex??0))*20)/20;
  const stroke=follow?.32:getWingMotionStyle()==='classic'?0:STROKE+.1*flex;
  const nativeBase=deformer(weights,stroke?phase+stroke*Math.sin(phase):phase,side,tips,follow?1.05:1.05*flex),expression=v7WingWarp(flight,visual,side,V7_DEFORMATION_COORDINATES),actorWarp=actorConditionWarp(side,visual);
  const expressed=expression?p=>expression(nativeBase(p),p):nativeBase;
  const actorBase=actorWarp?p=>actorWarp(expressed(p),p):expressed,completeWarp=completeConditionWarp(side,visual);
  const base=completeWarp?p=>completeWarp(actorBase(p),p):actorBase,disturbance=disturbanceParameters(side,visual,parameters?.variant);
  const influence=flight?.movement?.sweep?sweepInfluence(weights,side):undefined;
  // Original wings take the original hot path: no structure sampler, maps or
  // additional per-vertex branches when this optional feature is not in use.
  if(!flight?.structureAnimation?.rigRequired)return p=>{
    const result=sweepPoint(disturbPoint(base(p),p[2]??1,side,visual,disturbance),p[2]??1,side,weights,flight?.movement,influence);
    return visual?.enhanced||visual?.variant||visual?.reactions?.length?fitOwnedEffectPoint(result):result;
  };
  return p=>{
    let shape=transformStructurePoint(base(p),p,strandId,side,flight?.structureAnimation);
    if(collapse&&flight?.structureAnimation?.rigRequired){
      const strength=collapse*(1-(flight.structureAnimation.weights[0]??0))*.78;
      shape=shape.map((v,i)=>v+(i===0?side*27-v:i===1?42-v:-26-v)*strength);
    }
    const result=sweepPoint(disturbPoint(shape,p[2]??1,side,visual,disturbance),p[2]??1,side,weights,flight?.movement,influence);
    return visual?.enhanced||visual?.variant||visual?.reactions?.length?fitOwnedEffectPoint(result):result;
  };
}

export function wingAnchors(weights,phase=0,visual=null,flight=null) {
  // The strand id only chose an alternate structure (wings are the only one):
  // one warp per side serves all three trail anchors.
  return withEffectExtent(flight?.structureAnimation?.artworkExtent??1,()=>[-1,1].flatMap(side=>{
    const warp=wingWarp(weights,phase,side,visual,flight);return [0,4,9].map(i=>warp(point(RIBS[i],.94)));}));
}

/** A rig-local cache for the unchanged filament body. Animated housings and
 * their support fields still sample below on every requested artwork frame.
 * No token/world positions belong in this key. Dynamic conditions and
 * structures deliberately take the uncached path. */
function bodyCacheKey(weights,phase,visual,flight){
  // (12.0.0-beta.3) a recall moves every strand every frame
  if(flight?.formation?.recall)return null;
  if(visual?.statusFilamentEffects?.active)return null;
  // (v11) an emote moves the wings in place every frame: never from (or into) the cache
  if(visual?.v11emo?.on)return null;
  if(visual&&(visual.damage||visual.glitch||visual.instability||visual.overdrive||visual.flare||visual.geometryFlare||visual.sag||visual.healing||visual.reformation||visual.variant||visual.actorConditionMotion?.active||visual.reactions?.length||visual.bursts?.length))return null;
  if(flight?.structureAnimation?.rigRequired)return null;
  return JSON.stringify([getWingMotionStyle(),weights,flight?.poseAnimation?.tipWeights,phase,flight?.formation?.growth??1,
    flight?.formation?.fold??0,flight?.movement,visual?.collapse,visual?.collapseTip,visual?.suppression,visual?.motionStrength,!!visual?.enhanced,v7WingRigIdentity(flight),flight?.workingPosture,visual?.followThrough>0,Math.round((visual?.flightFlex??0)*20),visual?.v11Fold?.key??0]);
}
export function frameGeometry(weights,phase=0,visual=null,flight=null,cache=null) {
  const geometry=withEffectExtent(flight?.structureAnimation?.artworkExtent??1,()=>frameGeometryWithinExtent(weights,phase,visual,flight,cache));
  // v11 emotes (v11/emote-apply.mjs): the wings turned at the shoulder, Comfort's wrap. Absent: one property read.
  if(visual?.v11emo?.on)emoteGeometry(geometry,visual.v11emo);
  // v11 wounds, persistent damage, dying and mood (scripts/v11/wing-damage.mjs).
  // Absent (the usual case) this is one property read. The struck wing of a
  // mental wound beats at its own held phase: that side is sampled once more.
  const D=visual?.v11dmg;
  const drained0=g=>visual?.v11Drain?drainGeometry(g,visual.v11Drain):g;
  // v11 (phase 3a, v11/heal-wing.mjs): level-up ribs and the occult ripple; absent, one property read
  const drained=visual?.v11heal?g=>drained0(healGeometry(g,visual.v11heal)):drained0;
  if(!v11Active(D))return drained(geometry);
  const alt=D.alt&&Number.isFinite(D.alt.phase)?{side:D.alt.side,wings:emoteGeometry(withEffectExtent(flight?.structureAnimation?.artworkExtent??1,()=>frameGeometryWithinExtent(weights,D.alt.phase,{...visual,v11dmg:null},flight,null)),visual?.v11emo)}:null;
  return drained(v11Geometry(geometry,D,alt));
}
function frameGeometryWithinExtent(weights,phase=0,visual=null,flight=null,cache=null) {
  const layers={leftRear:[],rightRear:[],leftFront:[],rightFront:[]},lanternFrame={};
  // The breathing field depends on material coordinate and effect clock, not
  // side, wingbeat phase or strand. Share only these exact samples for this
  // synchronous frame, including the held phase-zero support references.
  const warpParameters={variant:variantPointParameters(visual)};
  const growth=flight?.formation?.growth??1;
  const key=cache?bodyCacheKey(weights,phase,visual,flight):null;
  const body=key!==null&&cache?.bodyKey===key?cache.body:null;
  const nextBody=cache&&key!==null&&!body?{leftRear:[],rightRear:[],leftFront:[],rightFront:[]}:null;
  const supportBySide=new Map(),builtSides=new Set(),supportReferenceBySide=new Map(),supportPointReferences=new WeakMap();
  const legacyWeight=1;
  // Healing and the held effect clock are identical for every strand in one
  // profile. Masks have their own local entry; nothing survives this frame.
  const pathParameters=new WeakMap();
  const cutPaths=(strand,points,side,profile=visual)=>{
    let parameters=null;
    if(profile?.enhanced&&(profile.damage||profile.glitch||profile.instability||profile.overdrive)){
      parameters=pathParameters.get(profile);
      if(!parameters){parameters=enhancedPathParameters(profile);pathParameters.set(profile,parameters);}
    }
    return conditionPaths(strand,points,side,profile,parameters);
  };
  // The supported Original structure scales the same rig for every strand.
  // All strands therefore share a warp in a given side/frame, including
  // enlarged wings. Support material
  // coordinates additionally sample phase zero. Keep this cache strictly
  // local so changing a profile, pose or gesture on the next call is immediate.
  const liveWarps=new Map(),referenceWarps=new Map();
  const sourceWarp=(id,side,samplePhase=phase)=>{
    const warps=samplePhase===phase?liveWarps:referenceWarps;
    if(!warps.has(side))warps.set(side,wingWarp(weights,samplePhase,side,visual,flight,id,warpParameters));
    return warps.get(side);
  };
  const source={strands:STRANDS,supports:SUPPORT_STRANDS};
  const sourceForSide=()=>source;
  const recall=flight?.formation?.recall??null,reel=recall?.style==='reelin';
  const sourcePaths=reel?strand=>growthPaths(strand.points,strandGrowth(strand.id,growth)):strand=>growthPaths(strand.points,growth);
  const supportReference=side=>{
    if(supportReferenceBySide.has(side))return supportReferenceBySide.get(side);
    const referenceKey=cache?bodyCacheKey(weights,0,visual,flight):null;
    if(referenceKey!==null&&cache?.supportReferenceKey===referenceKey&&cache.supportReferences?.has(side)){const refs=cache.supportReferences.get(side);supportReferenceBySide.set(side,refs);return refs;}
    const refs=new Map();
    for(const strand of sourceForSide(side).supports){const warp=sourceWarp(strand.id,side,0),points=[];
      const sourceIndices=new WeakMap();
      for(const path of sourcePaths(strand))for(const p of path){sourceIndices.set(p,points.length);points.push(warp(p));}
      // The body already contains every posed source point. Recompute a live
      // material span only when a cut introduces an interpolated point.
      points.sourceIndices=sourceIndices;
      refs.set(strand.id,points);}
    if(cache&&referenceKey!==null){if(cache.supportReferenceKey!==referenceKey){cache.supportReferenceKey=referenceKey;cache.supportReferences=new Map();}cache.supportReferences.set(side,refs);}
    supportReferenceBySide.set(side,refs);return refs;
  };
  const attachReference=(path,id,side)=>{
    const sourceId=id.startsWith('status-')?id:id.match(/^edge-\d+/)?.[0]??id;
    const reference=supportReference(side).get(sourceId);if(!reference?.length)return path;
    // The material coordinate survives strand cutting and depth splitting.
    // Outline fragments therefore cannot change allegiance with a wingbeat.
    if(path.supportReference)return path;
    path.supportReference=path.map(p=>{
      const saved=supportPointReferences.get(p);if(saved)return saved;
      // Cutting/depth crossing introduces an interpolated vertex. Resolve it
      // against its original posed material span, never another outline edge.
      const live=reference.livePhase===phase?reference.live:(reference.live=(()=>{const strand=sourceForSide(side).supports.find(s=>s.id===sourceId);if(!strand)return reference.live??[];const warp=sourceWarp(strand.id,side);return sourcePaths(strand).flatMap(p=>p.map(warp));})());reference.livePhase=phase;let nearest=reference[0],distance=Infinity;
      for(let i=1;i<live.length;i++){
        const a=live[i-1],b=live[i],dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2],ll=dx*dx+dy*dy+dz*dz;
        const t=ll?clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy+(p[2]-a[2])*dz)/ll):0;
        const d=(p[0]-a[0]-dx*t)**2+(p[1]-a[1]-dy*t)**2+(p[2]-a[2]-dz*t)**2;
        if(d<distance){distance=d;nearest=reference[i-1].map((v,k)=>v+(reference[i][k]-v)*t);}
      }return nearest;
    });return path;
  };
  const referenceNeeded=flight?.gems?.appearance==='physical'&&((flight.gems.glow&&flight.gems.glowStrength>0)||Object.values(flight.bitActionAssignments?.support??{}).some(d=>d.amount>0));
  const mapPath=(strand,path,warp,side)=>{
    const points=path.map(warp);
    if(referenceNeeded&&(strand.support||strand.id.startsWith('edge-'))){const refs=supportReference(side).get(strand.id);
      for(let i=0;i<points.length;i++){const index=refs?.sourceIndices.get(path[i]);if(index!==undefined)supportPointReferences.set(points[i],refs[index]);}
    }return points;
  };
  const materialParts=(part,side)=>{
    let parts=[part];
    if(!part.statusBody){
      if(visual?.actorConditionMotion?.active)parts=parts.flatMap(p=>actorConditionMaterialPaths(p,p.points,side,visual)??[p]);
      if(visual?.completeConditionMotion?.active)parts=parts.flatMap(p=>completeConditionMaterialPaths(p,p.points,side,visual)??[p]);
    }
    return visual?.statusFilamentEffects?.active?parts.flatMap(p=>originalStatusMaterialPaths(p,p.points,visual)??[p]):parts;
  };
  const effectFan=side=>({ribs:RIBS,warp:sourceWarp('rib-4',side)});
  const supportContours=side=>{
    if(supportBySide.has(side))return supportBySide.get(side);
    const paths=[],name=side<0?'left':'right';
    if(builtSides.has(side)){
      // Reuse the exact surviving body points: no second deformation pass and
      // no phantom open-wing silhouette during collapse, suppression or Reform.
      for(const key of [name+'Rear',name+'Front'])for(const part of layers[key])if(supportSpan(part))paths.push(attachReference(part.points,part.supportSourceId??part.id,side));
    }else{
      // A solo bit/shared duty can support the opposite wing before that side's
      // body loop runs. Lazily sample only its seven edges with the same visual
      // clock and strand cutting. Cache them for every subsequent controller.
      const warp=flight?.structureAnimation?.rigRequired?null:sourceWarp('rib-4',side),depthPaths=[[],[]];
      for(const strand of sourceForSide(side).supports){
        const contourWarp=warp??sourceWarp(strand.id,side);
        const strength=warp?strand.strength:strand.strength*structureStrandStrength(strand.id,flight.structureAnimation);
        const contour=strength===strand.strength?strand:{...strand,strength};
        for(const path of sourcePaths(strand))for(const originalPart of cutPaths(contour,mapPath(strand,path,contourWarp,side),side))for(const part of materialParts(originalPart,side))if(supportSpan(part))
          for(const span of splitDepth(part.points))depthPaths[span.front?1:0].push(attachReference(span.points,part.supportSourceId??part.id,side));
      }
      paths.push(...depthPaths[0],...depthPaths[1]);
    }
    supportBySide.set(side,paths);return paths;
  };
  for (const side of [-1,1]) {
    const warp=sourceWarp('rib-4',side),name=side<0?'left':'right';
    let effectControllers=null;
    const emit=part=>{
      if(/^(gem|sigil)-/.test(part.id)) {
        // Free controllers cross the token plane as one rigid piece. A narrow
        // depth handoff avoids an abrupt rear/front opacity and occlusion pop.
        const front=ease((part.points[0][2]+6)/12);
        if(front<.999999)layers[name+'Rear'].push({...part,strength:part.strength*(1-front)});
        if(front>.000001)layers[name+'Front'].push({...part,strength:part.strength*front});
        return;
      }
      if(part.star||part.hardware){const p=part.points[0];layers[name+(p[2]>0?'Front':'Rear')].push(part);return;}
      for(const span of splitDepth(part.points)){if(referenceNeeded&&supportSpan(part))attachReference(span.points,part.supportSourceId??part.id,side);layers[name+(span.front?'Front':'Rear')].push({...part,points:span.points});}
    };
    const add=(strand,points)=>{
      const cut=cutPaths(strand,points,side);
      const parts=visual?.actorConditionMotion?.active||visual?.completeConditionMotion?.active||visual?.statusFilamentEffects?.active?cut.flatMap(part=>materialParts(part,side)):cut;
      for(const part of parts)emit(part);
      return parts;
    };
    if(body){
      layers[name+'Rear'].push(...body[name+'Rear']);layers[name+'Front'].push(...body[name+'Front']);
      cache.hits=(cache.hits??0)+1;
    }else if(!flight?.structureAnimation?.rigRequired){
      for(const strand of sourceForSide(side).strands){
        if(growth>=1)add(strand,mapPath(strand,strand.points,warp,side));
        else for(const path of sourcePaths(strand))add(strand,mapPath(strand,path,warp,side));
      }
    }else for(const strand of sourceForSide(side).strands){
      const strandWarp=sourceWarp(strand.id,side);
      const strength=strand.strength*structureStrandStrength(strand.id,flight.structureAnimation);
      const source=strength===strand.strength?strand:{...strand,strength};
      if(growth>=1)add(source,mapPath(strand,strand.points,strandWarp,side));
      else for(const path of sourcePaths(strand))add(source,mapPath(strand,path,strandWarp,side));
    }
    if(nextBody){nextBody[name+'Rear']=layers[name+'Rear'].slice();nextBody[name+'Front']=layers[name+'Front'].slice();}
    builtSides.add(side);
    // V7 material remains optional and native. It samples the same posed rig,
    // growth clipping, damage cuts and depth plane as the original filaments.
    for(const material of legacyWeight>.001?v7WingMaterialPaths({flight,visual,side,phase,ribs:RIBS,warp,growth}):[]){
      const {source,...strand}=material;add({...strand,strength:strand.strength*legacyWeight},material.points);
    }
    // Bounded, deterministic light packets travel along the ribs.
    (legacyWeight<=.001||visual && !visual.energyPulses?[]:[0,2,4,6,8,9]).forEach((ri,i)=>{
      const t=((phase/TAU*2+i*0.149)%1+1)%1;
      const strength=Math.pow(Math.sin(Math.PI*t),0.8)*0.9*legacyWeight;
      const source=Array.from({length:10},(_,k)=>point(RIBS[ri],Math.max(0,t-k*0.006)));
      const lightWarp=sourceWarp(`rib-${ri}`,side);
      for(const path of growthPaths(source,growth)) {
        const points=path.map(lightWarp),parts=add({id:`light-${ri}`,width:1.6,strength},points);
        const p=points[0];
        const head=parts.find(part=>!part.echo&&!part.star&&(part.points[0]===p||part.sourceStart===p));
        if(head&&path[0]===source[0])emit({id:`spark-${ri}`,star:true,points:[head.points[0]],strength:head.strength,width:1.5});
      }
    });
    if(recall)for(const [ri,g,strength,width] of recallLights(recall,growth,RIBS)){
      const p=sourceWarp('rib-4',side)(ri===null?[ROOT[0],ROOT[1],0,0]:point(RIBS[ri],g));
      layers[name+(p[2]>0?'Front':'Rear')].push({id:`recall-${ri??'root'}`,star:true,points:[p],strength,width});
    }
    else if(legacyWeight>.001&&flight?.formationGlow&&visual?.energyPulses&&growth>0&&growth<1)for(const ri of [0,4,9]) {
      const p=sourceWarp(`rib-${ri}`,side)(point(RIBS[ri],growth));
      layers[name+(p[2]>0?'Front':'Rear')].push({id:`form-${ri}`,star:true,points:[p],strength:Math.sin(Math.PI*growth)*0.8,width:1.4});
    }
    // Stabilizers have their own transforms. Do not feed rigid housings or free
    // energy symbols through the wing's strand-cutting/glitch deformation.
    if(flight?.gems?.style==='choreographed'||(flight?.gems?.style==='classic'&&flight.gems.rigRequired)) {
      const assignments=flight.bitActionAssignments??{},hidden=new Set(assignments.hidden??[]),support=assignments.support??{};
      const stationFor=part=>`${side<0?'left':'right'}${/-1(?:-|$)/.test(part.id)?'Lower':'Upper'}`;
      const controllers=choreographedGems(weights,phase,visual,flight,side,lanternFrame).filter(part=>!hidden.has(stationFor(part)));
      const subset=Array.isArray(flight.bitHomeStations)&&flight.bitHomeStations.length<4;
      const solo=Array.isArray(flight.bitHomeStations)?flight.bitHomeStations.length===1:flight.gems.count===1;
      const controllerSide=part=>{const duty=support[stationFor(part)];return flight.gems.placement==='follow'&&duty?.amount>0?Math.sign(duty.x)||side:part.hardware?.stabilization?.supportSide??(subset?Math.sign(part.points[0][0])||side:side);};
      if(visual?.variant?.id==='surgeRouting')effectControllers=controllers.filter(part=>part.hardware||part.id.startsWith('gem-core-'));
      let contours=[],oppositeContours=[];
      const supporting=controllers.some(part=>(support[stationFor(part)]?.amount??0)>0);
      if(flight.gems.appearance==='physical'&&((flight.gems.glow&&flight.gems.glowStrength>0)||supporting||controllers.some(p=>p.hardware?.repair>0||p.hardware?.intent?.kind==='inspect'))) {
        // Disabling machinery animation holds the core still, not its support
        // target: fields always follow the current wingbeat and visible shape.
        contours=supportContours(side);
        if(solo||controllers.some(part=>support[stationFor(part)]?.bothWings||controllerSide(part)!==side))oppositeContours=supportContours(-side);
      }
      for(const part of controllers) {
        if(part.strength<=.001)continue;
        const assignment=support[stationFor(part)],duty=Math.max(0,Math.min(1,assignment?.amount??0));
        const supportSide=controllerSide(part);
        const ownContours=supportSide===side?contours:oppositeContours;
        const bothWings=solo||part.hardware?.stabilization?.bothWings||assignment?.bothWings;
        const otherContours=bothWings?(supportSide===side?oppositeContours:contours):[];
        if(duty&&part.hardware){
          if(flight.gems.placement==='follow'){const p=part.points[0];p[0]+=(assignment.x-p[0])*duty;p[1]+=(assignment.y-p[1])*duty;}
          part.hardware.glowMode='field';part.hardware.power=Math.max(part.hardware.power,.95*duty);
          if(part.hardware.resonance)part.hardware.resonance.focus=Math.max(part.hardware.resonance.focus,.9*duty);
        }
        if(part.hardware&&ownContours.length){
          const base=flight.gems.glow?flight.gems.glowStrength*(part.hardware.stabilization?.energy??1):0,glowStrength=base+(2.3-base)*duty;
          const field=stabilizerField(part,otherContours.length?[...ownContours,...otherContours]:ownContours,supportSide,glowStrength);
          if(glowStrength>0)part.hardware.glow=field;
          if(part.hardware.intent?.kind==='inspect'&&field){
            const target=Math.atan2(field.direction[1],field.direction[0])+Math.PI/2-part.hardware.angle;
            part.hardware.coreAngle+=Math.max(-.45,Math.min(.45,Math.atan2(Math.sin(target),Math.cos(target))))*part.hardware.intent.amount;
          }
          if(part.hardware.repair>0&&field){
            const target=Math.atan2(field.direction[1],field.direction[0])+Math.PI/2-part.hardware.angle;
            const turn=Math.atan2(Math.sin(target),Math.cos(target));
            part.hardware.coreAngle+=Math.max(-.5,Math.min(.5,turn))*part.hardware.repair;
          }
        }
        emit(part);
        for(const current of stabilizerCurrents(part,ownContours,supportSide,flight))emit(current);
        for(const current of stabilizerCurrents(part,otherContours,-supportSide,flight))emit({...current,id:current.id+'-opposite'});
      }
      for(const current of bitIntentCurrents(controllers,flight,side))emit(current);
    } else if(flight?.gems?.style!=='hidden')for (const [index,x,y,scale] of [[0,220,-159,0.8],[1,205,202,0.64]]) {
      const formed=ease((growth-0.85)/0.15);if(!formed)continue;
      const center=warp([x,y,0.92]),angle=side*(0.38+0.07*Math.sin(phase));
      const size=scale*(flight?.gems?.size??1);
      const place=([a,b])=>[center[0]+size*(a*Math.cos(angle)-b*Math.sin(angle)),center[1]+size*(a*Math.sin(angle)+b*Math.cos(angle)),center[2]];
      const ring=Array.from({length:41},(_,i)=>place([15*Math.cos(i/40*TAU),31*Math.sin(i/40*TAU)]));
      add({id:`sigil-${index}`,width:0.55,strength:0.55*formed},ring);
      add({id:`gem-${index}`,width:0.8,strength:0.85*formed},[[0,-32],[4,-17],[10,-13],[4,-10],[0,1],[-4,-10],[-10,-13],[-4,-17],[0,-32]].map(place));
    }
    const wingPortion=(flight?.structureAnimation?.weights?.[0]??1)*legacyWeight;
    // HP's selected artwork can reset its numeric paint channels. Give actor
    // seams the same injury as a material mask without repeating the primary
    // variant on them or applying HP twice to the entire wing. The new art
    // therefore cannot draw an intact silhouette across an injured lattice.
    if(wingPortion>.001&&visual?.actorConditionMotion?.active){
      const hp=visual.actorConditionMotion.hp,gates=visual.actorConditionMotion.gates??visual.gates??{};
      const mask={...visual,variant:null,reactions:[],bursts:[],reformation:null,sparks:false,echoes:false,
        damage:Math.max(visual.damage??0,gates.breaks===false?0:hp?.damage??0),
        instability:Math.max(visual.instability??0,gates.instability===false?0:hp?.instability??0),
        glitch:visual.animated===false||gates.glitches===false?0:Math.min(gates.glitchLimit??1,Math.max(visual.glitch??0,hp?.glitch??0))};
      const dim=visual.actorConditionMotion.hpDim??1;
      for(const accent of actorConditionAccents(side,visual,warp,RIBS,growth))
        for(const part of cutPaths({...accent,strength:accent.strength*wingPortion*dim},accent.points,side,mask))emit(part);
      const collapsedMask=visual.reformation?{...mask,reformation:visual.reformation}:mask;
      for(const accent of completeConditionAccents(side,visual,warp,RIBS,growth))
        for(const part of cutPaths({...accent,strength:accent.strength*wingPortion*dim},accent.points,side,collapsedMask))emit(part);
    }
    if(visual?.statusFilamentEffects?.active&&(flight?.structureAnimation?.weights?.[0]??1)>.001){
      const fan=effectFan(side),hp=visual.actorConditionMotion?.hp,gates=visual.actorConditionMotion?.gates??visual.gates??{};
      if(fan){
        const mask={...visual,variant:null,reactions:[],bursts:[],sparks:false,echoes:false,
          damage:Math.max(visual.damage??0,gates.breaks===false?0:hp?.damage??0),
          instability:Math.max(visual.instability??0,gates.instability===false?0:hp?.instability??0),
          glitch:visual.animated===false||gates.glitches===false?0:Math.max(visual.glitch??0,hp?.glitch??0)};
        const dim=visual.actorConditionMotion?.hpDim??1;
        const amount=flight?.structureAnimation?.weights?.[0]??1;
        for(const accent of originalStatusFilamentAccents(side,visual,fan.warp,fan.ribs,growth)){
          const surviving=cutPaths({...accent,strength:accent.strength*dim*amount},accent.points,side,mask);
          for(const part of surviving)emit(part);
          // A tiny localized spark forms only on a surviving material span.
          // The parent still owns HP cutting and the held wing's exact pose.
          if(accent.localSpark){const span=surviving.find(p=>!p.echo&&p.strength>.08&&p.points.length>1);
            if(span)emit({...span,id:accent.id+'-glint',star:true,width:1.6,highlight:1,points:[span.points[Math.floor(span.points.length/2)]]});}
        }
      }
    }
    if(wingPortion===1){
      for(const accent of conditionAccents(side,visual,warp,RIBS,growth))emit(accent);
      for(const accent of variantAccents(side,visual,warp,RIBS,growth,effectControllers?{controllers:effectControllers}:null))emit(accent);
      for(const accent of movementAccents(side,visual,warp,RIBS,growth,flight?.movement))emit(accent);
    }else if(wingPortion>.001)for(const accent of [
      ...conditionAccents(side,visual,warp,RIBS,growth),...variantAccents(side,visual,warp,RIBS,growth,effectControllers?{controllers:effectControllers}:null),
      ...movementAccents(side,visual,warp,RIBS,growth,flight?.movement)])emit({...accent,strength:accent.strength*wingPortion});
  }
  if(cache){cache.bodyKey=key;cache.body=nextBody??(key!==null?body:null);}
  return layers;
}

export const LAYER_NAMES=Object.freeze(['leftRear','rightRear','leftFront','rightFront']);
const FILAMENT_STROKES=Object.freeze([[8,.08],[3,.2],[1,.88],[.28,.92]].map(Object.freeze));
const MATERIAL_STROKES=Object.freeze([[3,.08],[1,.7],[.35,.88]].map(Object.freeze));

/** Reuse four transparent canvases/textures. Batch like strokes to keep draw calls
 * bounded. No Foundry/PIXI globals: the same painter runs in the visual QA preview.
 */
export function paintLayers(contexts,geometry,size=512,visual=null,bitAssetCache,viewports=null,onlyLayers=LAYER_NAMES) {
  const light=reactionLight(visual);
  const glow=Math.max(.55,1+(visual?Math.max(0,visual.energy-1)*1.4+(visual.energyPulses?(visual.geometryPulse??visual.pulse)*0.55:0):0)+light.glow);
  // A reaction tints only the soft halo strokes; the wire itself stays magenta.
  const lightTint=light.mix>.01?REACTION_TINTS[light.tint]?.bloom:null,mixed=lightTint?[0,1,2].map(i=>Math.round(MAGENTA[i]+(lightTint[i]-MAGENTA[i])*light.mix)):null;
  const halo=mixed?a=>`rgba(${mixed[0]},${mixed[1]},${mixed[2]},${a})`:ink;
  // v11 (wing-damage.mjs): a strand's palette by damage type, dying stage or
  // mood. Wire, halo and pale cores take its colours; a reaction tint still
  // mixes into the halo. Without a v11 state: the v10 paint, unchanged.
  const D=v11Active(visual?.v11dmg)?visual.v11dmg:null;
  // v11 light catch (v11/world-paint.mjs): strands the damage looks leave alone take the nearby light.
  const LC=visual?.v11Light?lightPalettes(visual.v11Light,visual.time):null;
  for (const key of onlyLayers) {
    const ctx=contexts[key],viewport=viewports?.[key];ctx.clearRect(0,0,viewport?.width??size,viewport?.height??size);
    ctx.save();if(viewport)ctx.translate(-viewport.x,-viewport.y);
    ctx.scale(size/ART_SIZE,size/ART_SIZE);ctx.translate(300,285);
    ctx.lineCap='round';ctx.lineJoin='round';
    const groups=new Map(),stars=[],hardware=[],soul=visual?.lightStyle==='soul';let v11Parts=null;
    if(soul)paintSoulParts(ctx,geometry[key],visual);
    for (const strand of geometry[key]) {
      if (strand.hardware) {hardware.push(strand);continue;}
      if (strand.v11) {(v11Parts??=[]).push(strand);continue;}
      if (strand.star) {stars.push(strand);continue;}
      // Soul light paints the body itself; beta.29 keeps the tinted reaction
      // currents (heal gold, stutter violet...) on top instead of dropping them.
      if (soul&&!(strand.highlight&&strand.tint&&REACTION_TINTS[strand.tint])) continue;
      if (D&&strand.v11mark) continue;
      const material=strand.material??'',levels=material?40:10,strength=Math.round(strand.strength*levels)/levels,highlight=Math.round(Math.max(0,Math.min(1,Number(strand.highlight??strand.paleHighlight)||0))*10)/10,tint=highlight&&strand.tint||'';
      // (test.3) a mood's palette is her state, the light is the world's: the light is caught over the mood
      // (a wound's or persistent mark's own strands keep theirs)
      const pal0=D?v11PaletteAt(D,strand,key):null,lpal=LC?lightPaletteAt(LC,strand):null;
      const pal=lpal?(pal0?(strand.wl?pal0:litPalette(pal0,lpal)):lpal):pal0,edge=!!(pal&&pal.edge&&strand.id?.startsWith('edge-'));
      const groupKey=pal?`${strand.width}:${strength}:${highlight}:${material}:${tint}:${pal.key}:${edge?'e':''}`:`${strand.width}:${strength}:${highlight}:${material}:${tint}`;
      if (!groups.has(groupKey)) groups.set(groupKey,{width:strand.width,strength,highlight,material,tint,mood:pal?v11Paint$(pal,lightTint,light.mix,glow):null,edge,strands:[]});
      groups.get(groupKey).strands.push(strand.points);
    }
    for (const {width,strength,highlight,material,tint,mood,edge,strands} of groups.values()) {
      ctx.beginPath();
      for (const points of strands)for(let i=0;i<points.length;i++){const p=points[i];if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);}
      // v11: one wide, very faint wash beneath the wire (afterglow, sickened, poison)
      if(!soul&&mood?.under){const u=mood.under;ctx.lineWidth=width*13*mood.glow;ctx.strokeStyle=`rgba(${u[0]},${u[1]},${u[2]},${Math.min(1,u[3]*strength)})`;ctx.stroke();}
      if(!soul)for (const [w,a] of material?MATERIAL_STROKES:FILAMENT_STROKES) {
        ctx.lineWidth=width*w*(w>1?(mood?mood.glow:glow):(mood&&w<.5?mood.wire:1));ctx.strokeStyle=(w>1?(mood?mood.halo:halo):(mood?mood.ink:ink))(Math.min(1,a*strength));ctx.stroke();
      }
      // v11: a fine pale line along the outer edge (Quickened's brighter edge)
      if(edge&&mood){const c=mood.edgeColor;ctx.lineWidth=Math.max(.6,width*.75);ctx.strokeStyle=`rgba(${c[0]},${c[1]},${c[2]},${Math.min(1,mood.edge*strength)})`;ctx.stroke();}
      const colours=tint?REACTION_TINTS[tint]:null;
      if(highlight&&colours){
        // v10 reaction currents: a tinted bloom and a core wide enough to
        // survive token scale (about one screen pixel at default wing size).
        const s=Math.min(1,strength)*highlight,b=colours.bloom,c=colours.core;
        ctx.lineWidth=width*6.5;ctx.strokeStyle=`rgba(${b[0]},${b[1]},${b[2]},${.18*s})`;ctx.stroke();
        ctx.lineWidth=width*2.8;ctx.strokeStyle=`rgba(${b[0]},${b[1]},${b[2]},${.42*s})`;ctx.stroke();
        ctx.lineWidth=Math.max(1.7,width*1.35);ctx.strokeStyle=`rgba(${c[0]},${c[1]},${c[2]},${s})`;ctx.stroke();
      } else if(highlight){
        // Pale cores make a moving charge legible on a saturated magenta rib.
        // Only the current is highlighted; the silhouette keeps its thin wire art.
        ctx.lineWidth=Math.max(.65,width*.8);const pc=mood?.core;ctx.strokeStyle=pc?`rgba(${pc[0]},${pc[1]},${pc[2]},${Math.min(1,strength)*highlight})`:`rgba(255,214,255,${Math.min(1,strength)*highlight})`;ctx.stroke();
      }
    }
    // v10 portrait clearance: strands that wrap in front fade softly over her
    // face (not at the silhouette edge), one gradient fill per front layer.
    const portrait=visual?.portraitRadius;
    if(portrait>0&&key.endsWith('Front')&&geometry[key].length&&getWingMotionStyle()!=='classic'){
      // Beta.29: cover the whole portrait (crossed guard and cocoon strands ran
      // across her brow and chin), keeping a faint trace and a soft rim.
      const cy=15-portrait*.06,reach=portrait*1.06,face=ctx.createRadialGradient(0,cy,portrait*.12,0,cy,reach);
      face.addColorStop(0,'rgba(0,0,0,.9)');face.addColorStop(.72,'rgba(0,0,0,.86)');face.addColorStop(1,'rgba(0,0,0,0)');
      ctx.save();ctx.globalCompositeOperation='destination-out';ctx.fillStyle=face;ctx.fillRect(-reach,cy-reach,reach*2,reach*2);ctx.restore();
    }
    // (11.0.0-test.21) hidden with a ghost kept: her portrait is see-through, so whatever passes behind it (or in front) is cleared to its edge
    const behind=visual?.v11Behind;
    if(behind&&behind[2]>0&&behind[3]>0&&geometry[key].length){
      const [hx,hy,rx,ry]=behind,hole=ctx.createRadialGradient(0,0,rx*.9,0,0,rx*1.03);hole.addColorStop(0,'rgba(0,0,0,1)');hole.addColorStop(1,'rgba(0,0,0,0)');
      ctx.save();ctx.globalCompositeOperation='destination-out';ctx.translate(hx,hy);ctx.scale(1,ry/rx);ctx.fillStyle=hole;ctx.fillRect(-rx*1.05,-rx*1.05,rx*2.1,rx*2.1);ctx.restore();
    }
    for (const star of stars) {
      const [[x,y]]=star.points,r=star.width;
      const glow=ctx.createRadialGradient(x,y,0,x,y,r*3.8);
      glow.addColorStop(0,ink(star.strength*0.7));glow.addColorStop(1,ink(0));
      ctx.fillStyle=glow;ctx.beginPath();ctx.arc(x,y,r*3.8,0,TAU);ctx.fill();
      ctx.fillStyle=WING_COLOR;ctx.globalAlpha=star.strength;
      ctx.beginPath();ctx.moveTo(x,y-r*2);ctx.lineTo(x+r*0.45,y);ctx.lineTo(x,y+r*2);ctx.lineTo(x-r*0.45,y);ctx.closePath();ctx.fill();
      if(star.highlight){ctx.fillStyle='#ffe8ff';ctx.beginPath();ctx.arc(x,y,r*.4,0,TAU);ctx.fill();}
      ctx.globalAlpha=1;
    }
    // v11: the state's own strokes (embers, frost, crackle, glints) over this layer
    // (test.2) under the invisibility drain they fade with her light (the owner's ghost keeps a faint share)
    if(D){const lit=visual?.v11Drain?drainLit(visual.v11Drain):1;if(lit>.01){if(lit<1)ctx.globalAlpha=lit;v11Paint(ctx,key,geometry,D);ctx.globalAlpha=1;}}
    if(v11Parts)paintV11Parts(ctx,key,v11Parts,visual);
    // v11 (phase 3a): heals, spell traditions, Hero Points and the level-up ribs (v11/heal-wing.mjs)
    if(visual?.v11heal){const lit=visual.v11Drain?drainLit(visual.v11Drain):1;if(lit>.01){if(lit<1)ctx.globalAlpha=lit;healPaint(ctx,key,geometry,visual.v11heal);ctx.globalAlpha=1;}}
    for(const part of hardware)paintStabilizer(ctx,part,bitAssetCache);
    ctx.restore();
  }
}
/** v11: a palette's stroke styles, cached with it (one per palette, halo tint and glow). */
const V11_PAINT=new Map();
const rgbaOf=c=>a=>`rgba(${c[0]},${c[1]},${c[2]},${a})`;
function v11Paint$(p,lightTint,mix,glow){
  const k=`${p.key}|${lightTint?lightTint.join(','):''}|${Math.round(mix*20)}|${Math.round(glow*100)}`;let m=V11_PAINT.get(k);
  if(!m){const hb=lightTint?[0,1,2].map(i=>Math.round(p.halo[i]+(lightTint[i]-p.halo[i])*mix)):p.halo;
    m={ink:rgbaOf(p.ink),halo:rgbaOf(hb),core:p.core,glow:glow*(p.glow??1),edge:p.edge??0,edgeColor:p.edgeColor??p.core,wire:p.wire??1,under:p.under&&p.under[3]>.002?p.under:null};
    if(V11_PAINT.size>4096)V11_PAINT.clear();V11_PAINT.set(k,m);}
  return m;
}
