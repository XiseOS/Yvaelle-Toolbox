import {splitDepth,paintLayers} from './wing-rig.mjs?v=13.0.3';
import {stableLayerViewport,sameLayerPixels} from './render-regions.mjs?v=13.0.3';
import {placeBehind} from './renderer.mjs?v=13.0.3';
import {localPerformance} from './performance.mjs?v=13.0.3';

/** At most two small cropped textures for rare passive companion gestures.
 * They share the bit clock and existing primary layer, with no extra ticker,
 * filter stack, particle emitter or document updates. */
export class CompactCurrents {
  constructor(token){this.token=token;this.layers={};}
  paint(paths,quality,now){
    const size={low:192,medium:256,high:384}[quality]??256;
    if(this.size!==size){this.clear();this.size=size;}
    const geometry={rear:[],front:[]};
    for(const part of paths)if(part.strength>.002)for(const span of splitDepth(part.points))geometry[span.front?'front':'rear'].push({...part,points:span.points});
    for(const depth of ['rear','front']){
      const parts=geometry[depth];let layer=this.layers[depth];
      if(!layer&&parts.length){
        const surface=document.createElement('canvas');surface.width=surface.height=1;const context=surface.getContext('2d');
        if(!context)continue;
        const texture=PIXI.Texture.from(surface,{mipmap:PIXI.MIPMAP_MODES?.OFF??0,scaleMode:PIXI.SCALE_MODES?.LINEAR??1});
        layer=this.layers[depth]={surface,context,texture};
        const Base=foundry.canvas.primary.PrimarySpriteMesh,Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
        class EffectMesh extends Base{get shouldRenderDepth(){return false;}containsCanvasPoint(){return false;}}
        let mesh;try{mesh=layer.mesh=new EffectMesh({name:`filament-flight.${this.token.id}.companion.${depth}`,texture},Shader);}catch(error){this.clear();throw error;}
        mesh.eventMode='none';mesh.interactive=false;mesh.visible=false;mesh.alpha=0;canvas.primary.addChild(mesh);
      }
      if(!layer)continue;
      layer.hasContent=parts.length>0;
      if(!parts.length){layer.mesh.visible=false;layer.parts=[];continue;}
      const viewport=stableLayerViewport(parts,size,1,layer,now,true);
      if(viewport!==layer.viewport||!sameLayerPixels(layer.parts,parts)){
        if(layer.surface.width!==viewport.width||layer.surface.height!==viewport.height){
          layer.surface.width=viewport.width;layer.surface.height=viewport.height;
          layer.texture.baseTexture.resource?.resize?.(viewport.width,viewport.height);layer.texture.baseTexture.setRealSize?.(viewport.width,viewport.height);
        }
        layer.viewport=viewport;layer.mesh.anchor.set((size/2-viewport.x)/viewport.width,(size/2-viewport.y)/viewport.height);
        paintLayers({[depth]:layer.context},geometry,size,{energy:1,energyPulses:false},undefined,{[depth]:viewport},[depth]);
        layer.texture.baseTexture.update();localPerformance.count('companionCurrentUploads');
        localPerformance.count('companionCurrentPixels',viewport.width*viewport.height);
      }
      layer.parts=parts;
    }
  }
  place(transform,source,alpha,cfg){
    for(const [depth,layer]of Object.entries(this.layers)){
      const {mesh,viewport}=layer;mesh.visible=!!layer.hasContent&&alpha>0;if(!mesh.visible)continue;
      mesh.position.set(transform.x,transform.y);mesh.rotation=transform.angle;
      mesh.width=transform.width*viewport.width/this.size;mesh.height=transform.height*viewport.height/this.size;
      mesh.alpha=alpha;placeBehind(mesh,source,depth==='front'?-.13:.23);
    }
  }
  hide(){for(const layer of Object.values(this.layers))if(layer.mesh)layer.mesh.visible=false;}
  clear(){for(const layer of Object.values(this.layers)){layer.mesh?.parent?.removeChild(layer.mesh);layer.mesh?.destroy({children:true,texture:false,baseTexture:false});layer.texture.destroy(true);layer.surface.width=layer.surface.height=1;}this.layers={};}
  destroy(){this.clear();}
}
