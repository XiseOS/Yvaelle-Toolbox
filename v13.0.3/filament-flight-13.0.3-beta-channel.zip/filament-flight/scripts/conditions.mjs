import {ease,unit} from './poses.mjs?v=13.0.3';
import {CONDITION_IDS,resolveEffectStyle,resolveReactionStyle} from './effect-styles.mjs?v=13.0.3';
import {variant,resolveTuning,DEFAULT_CONDITION_ART,isLegacyAnimated,legacyAnimationCategory} from './effect-catalog.mjs?v=13.0.3';
import {DEFAULT_REACTION_ART,reformationOf} from './reaction-art.mjs?v=13.0.3';

export const CONDITIONS=CONDITION_IDS;
export const CHANNELS=Object.freeze(['damage','instability','glitch','energy','collapse']);
const profiles={
  normal:[0,0,0,1,0],damaged:[0.2,0.12,0.1,0.9,0],unstable:[0.4,0.5,0.35,0.82,0],
  glitching:[0.64,0.8,0.8,0.72,0],overdrive:[0,0.12,0.1,1.4,0],suppressed:[0.08,0,0,0.15,0],collapsed:[0.86,0.1,0.06,0.075,1]
};
export const profileFor=condition=>{const p=profiles[condition];return {damage:p[0],instability:p[1],glitch:p[2],energy:p[3],collapse:p[4]};};
/** Resolved semantic severity, shared by artwork and the existing audio bed.
 * Uses the blended profile so healing/condition changes keep their timing. */
export function conditionSeverity(profile,condition) {
  const reference=profileFor(condition);
  if(condition==='normal')return 1;
  if(condition==='overdrive')return unit((profile.energy-1)/.4);
  if(condition==='suppressed')return unit((1-profile.energy)/.85);
  if(condition==='collapsed')return unit(Math.max(profile.collapse,profile.damage/.86));
  const key=condition==='glitching'?'glitch':condition==='unstable'?'instability':'damage';
  return unit(profile[key]/Math.max(.01,reference[key]));
}
export const mixProfiles=(a,b,t)=>({damage:a.damage+(b.damage-a.damage)*t,instability:a.instability+(b.instability-a.instability)*t,
  glitch:a.glitch+(b.glitch-a.glitch)*t,energy:a.energy+(b.energy-a.energy)*t,collapse:a.collapse+(b.collapse-a.collapse)*t});
export const validateCondition=condition=>{
  if (!CONDITIONS.includes(condition)) throw new Error(`Unknown wing condition ${condition}. Use ${CONDITIONS.join(', ')} or auto.`);
  return condition;
};
export function hash(value) {
  let h=2166136261;for(const c of String(value))h=Math.imul(h^c.charCodeAt(0),16777619);
  return h>>>0;
}

/** Prefer the system's effective condition API to older status icons/stored
 * items. A successfully read false/null result is authoritative. Fall back
 * only when that API is absent or unavailable during actor preparation. */
export function readActorCondition(actor,id) {
  let effective=null,condition=null;
  try {if(typeof actor?.hasCondition==='function')effective=!!actor.hasCondition(id);}catch{/* Try another public representation. */}
  if(effective===false)return {active:false,condition:null};
  try {
    if(typeof actor?.getCondition==='function'){
      condition=actor.getCondition(id);
      condition=condition&&condition.active!==false?condition:null;
      return {active:effective===true||!!condition,condition};
    }
  }catch{/* Try the public condition collection. */}
  try {
    const bySlug=actor?.conditions?.bySlug;
    if(typeof bySlug==='function'||typeof bySlug?.get==='function'){
      const entries=typeof bySlug==='function'?bySlug.call(actor.conditions,id,{active:true}):bySlug.get(id);
      condition=Array.isArray(entries)?entries.find(c=>c&&c.active!==false)??null:null;
      return {active:effective===true||!!condition,condition};
    }
  }catch{/* Generic actors may have only Foundry statuses. */}
  if(effective===true)return {active:true,condition:null};
  try {return {active:!!actor?.statuses?.has?.(id),condition:null};}catch{return {active:false,condition:null};}
}

export function readHealth(actor) {
  let hp,dead=false;
  try {hp=actor?.hitPoints??actor?.system?.attributes?.hp;}catch{return null;}
  // Dead is a Foundry status rather than a PF2e condition item. Retain it even
  // when the effective Unconscious condition has already been removed.
  try {dead=!!actor?.statuses?.has?.('dead');}catch{/* Preserve valid HP if an actor is being destroyed. */}
  const unconscious=readActorCondition(actor,'unconscious').active||dead;
  if (!Number.isFinite(hp?.value)||!Number.isFinite(hp?.max)||hp.max<=0) return null;
  return {value:Math.max(0,hp.value),max:hp.max,temp:Math.max(0,Number.isFinite(hp.temp)?hp.temp:0),
    ratio:unit(hp.value/hp.max),unconscious};
}
export const healthKey=hp=>hp?hash(`${hp.value}|${hp.max}|${hp.unconscious}`).toString(36):'unknown';
export const healthContext=doc=>({health:readHealth(doc?.actor),seed:doc?.uuid??'flight'});

/** Beta.29: the three "Wings at zero HP" looks, shared by the HP band and the
 * Unconscious reaction so each choice looks like itself. `opacity` is the
 * resting light the wing keeps (the rebuild grows out from it).
 * Fold and fade: the v10 folded pose, dimmed but still readable as wings.
 * Fragment: open wings broken into drifting pieces. Fade: a bare whisper. */
export const ZERO_HP_LOOKS=Object.freeze({
  collapse:Object.freeze({damage:.16,instability:.03,glitch:0,energy:.5,collapse:1,opacity:.8}),
  fragment:Object.freeze({damage:.8,instability:.26,glitch:.14,energy:.55,collapse:0,opacity:.85}),
  fade:Object.freeze({damage:0,instability:0,glitch:0,energy:.055,collapse:0,opacity:.07})
});
const HP_BAND_WEAR=Object.freeze({damage:.8,instability:.55,glitch:.35,energy:1});
export function automaticHealth(hp,config) {
  if (!hp) return {condition:'normal',profile:profileFor('normal'),incapacitated:false};
  const {moderate,low,critical}=config.hpThresholds;
  const incapacitated=hp.value===0||(config.unconsciousCollapse&&hp.unconscious);
  if (incapacitated && config.zeroHPBehavior!=='ignore') {
    const look=ZERO_HP_LOOKS[config.zeroHPBehavior]??ZERO_HP_LOOKS.collapse;
    return {condition:'collapsed',profile:{damage:look.damage,instability:look.instability,glitch:look.glitch,energy:look.energy,collapse:look.collapse},incapacitated:true};
  }
  const ratio=incapacitated?0:hp.ratio;
  let condition,profile;
  if (ratio>moderate) {condition='normal';profile=profileFor('normal');}
  else if (ratio>low) {
    condition='damaged';profile=mixProfiles({damage:0.025,instability:0.05,glitch:0.035,energy:0.97,collapse:0},profileFor('damaged'),unit((moderate-ratio)/Math.max(0.001,moderate-low)));
  } else if (ratio>critical) {
    condition='unstable';profile=mixProfiles(profileFor('unstable'),profileFor('glitching'),unit((low-ratio)/Math.max(0.001,low-critical))*0.6);
  } else {condition='glitching';profile=profileFor('glitching');}
  return {condition,profile:mixProfiles(profileFor('normal'),profile,config.hpReactionIntensity),incapacitated};
}

export function readProfile(raw) {
  if (!raw||typeof raw!=='object'||CHANNELS.some(k=>!Number.isFinite(raw[k])||raw[k]<0||raw[k]>(k==='energy'?1.5:1))) throw new Error('Invalid saved wing condition profile.');
  return Object.fromEntries(CHANNELS.map(k=>[k,raw[k]]));
}
export function readConditionTiming(raw,kind='transition') {
  if (raw==null)return null;
  const max=kind==='temporary'?3600000:10000;
  if (typeof raw!=='object'||typeof raw.id!=='string'||!/^[\w-]{1,64}$/.test(raw.id)||!Number.isFinite(raw.started)
    ||!Number.isFinite(raw.duration)||raw.duration<0||raw.duration>max)throw new Error('Invalid saved wing condition timing.');
  const out={id:raw.id,started:raw.started,duration:raw.duration,from:readProfile(raw.from)};
  if(kind!=='health'&&raw.hpSeparated!=null){
    if(typeof raw.hpSeparated!=='boolean')throw new Error('Invalid saved wing condition origin.');
    if(raw.hpSeparated)out.hpSeparated=true;
  }
  if (kind==='temporary') {
    out.condition=validateCondition(raw.condition);
    if (!Number.isFinite(raw.fadeDuration)||raw.fadeDuration<0||raw.fadeDuration>10000) throw new Error('Invalid temporary condition fade duration.');
    out.fadeDuration=raw.fadeDuration;
  }
  if (kind==='health') {
    if(typeof raw.healthKey!=='string'||!/^[a-z0-9]{1,32}$/.test(raw.healthKey))throw new Error('Invalid saved HP transition.');
    out.healthKey=raw.healthKey;
  }
  return out;
}
export function sampleHP(data,hp,config,now,resumeTransition=true) {
  const automatic=automaticHealth(hp,config),t=data.hpTransition;
  const p=resumeTransition===false||!t||!config.transitions||config.reduced||!t.duration?1:unit((now-t.started)/t.duration);
  return {...automatic,profile:t&&p<1&&t.healthKey===healthKey(hp)?mixProfiles(t.from,automatic.profile,ease(p)):automatic.profile};
}
export function sampleCondition(data,hp,config,now,context={}) {
  const automatic=sampleHP(data,hp,config,now,context.resumeHPTransition);
  const autoHP=config.hpReactions&&data.autoHP!==false;
  const auto=data.conditionSource==='auto'&&autoHP;
  let condition=auto?automatic.condition:data.condition,profile=auto?automatic.profile:profileFor(data.condition);
  const t=data.conditionTransition;
  const animate=config.transitions&&!config.reduced;
  const p=context.resumeConditionTransition===false||!animate||!t||!t.duration?1:unit((now-t.started)/t.duration);
  let authoredProfile=profileFor(auto?'normal':data.condition);
  if(t&&p<1){
    authoredProfile=mixProfiles(t.from,authoredProfile,ease(p));
    // New command origins exclude HP. Compose it once for an auto destination;
    // older persisted events retain their original complete-profile timing.
    profile=t.hpSeparated?(auto?healthMaterialProfile(authoredProfile,automatic.profile):authoredProfile):mixProfiles(t.from,profile,ease(p));
  }
  let phase=p<1?'changing':'steady',overrideActive=false;
  const o=config.temporaryConditions?data.temporaryCondition:null;
  if (o&&now>=o.started) {
    const elapsed=now-o.started,fade=animate?o.fadeDuration:0;
    if (elapsed<o.duration) {
      profile=mixProfiles(o.from,profileFor(o.condition),ease(fade?elapsed/fade:1));condition=o.condition;
      authoredProfile={...profile};
      phase=elapsed<fade?'entering':'holding';overrideActive=true;
    } else if (fade&&elapsed<o.duration+fade) {
      const end=mixProfiles(o.from,profileFor(o.condition),ease(o.duration/fade));
      authoredProfile=mixProfiles(end,authoredProfile,ease((elapsed-o.duration)/fade));
      profile=o.hpSeparated?{...authoredProfile}:mixProfiles(end,profile,ease((elapsed-o.duration)/fade));phase='returning';overrideActive=true;
    }
  }
  return {condition,profile,authoredProfile,phase,overrideActive,autoHP,automaticCondition:automatic.condition,automaticProfile:automatic.profile,
    incapacitated:auto&&automatic.incapacitated};
}

const healthMaterialProfile=(base,hp)=>({damage:Math.max(base.damage,hp.damage),instability:Math.max(base.instability,hp.instability),
  glitch:Math.max(base.glitch,hp.glitch),energy:base.energy*hp.energy,collapse:Math.max(base.collapse,hp.collapse)});

/** HP is a material response around the chosen artwork, not another condition
 * command. Keep authored/actor variants and their clocks while damaging the
 * same filament body. Maxima avoid counting a manual damage profile twice;
 * energy is relative so overdrive and suppressed states retain their character.
 * Saved transition origins continue to describe the authored condition alone. */
export function composeHPArtwork(visual,config={}) {
  const hp=visual.hpOverlayProfile;
  if(!hp||visual.hpComposed)return visual;
  const p={...visual.profile},semantic={...visual.semanticProfile};
  if(!visual.hpSemanticComposed){
    for(const key of ['damage','instability','glitch','collapse'])semantic[key]=Math.max(semantic[key]??0,hp[key]);
    semantic.energy=(semantic.energy??1)*hp.energy;
  }
  const lift=p.reformation?.lift??0,remaining=1-lift,energy=hp.energy+(1-hp.energy)*lift;
  p.damage=Math.max(p.damage??0,config.filamentBreaks===false?0:hp.damage*remaining);
  p.instability=Math.max(p.instability??0,config.filamentInstability===false?0:hp.instability*remaining);
  p.glitch=config.filamentGlitches===false||config.reduced?0:Math.min(config.glitchLimit??1,Math.max(p.glitch??0,hp.glitch*remaining*(1-Math.min(.75,(p.healing??0)*.65))));
  p.collapse=Math.max(p.collapse??0,hp.collapse*remaining);
  p.energy=(p.energy??1)*energy;
  p.sag=Math.max(p.sag??0,config.filamentInstability===false?0:p.damage);
  p.overdrive=p.enhanced?unit((p.energy-1)/.4):0;
  p.suppression=p.enhanced?ease(unit((.65-p.energy)/.5))*(1-p.collapse)*(1-ease((p.damage-.15)/.4)):0;
  p.echoes=p.enhanced&&config.glitchEchoes!==false&&p.animated&&p.glitch>0;
  p.renderOpacity=(p.renderOpacity??1)*Math.min(1,energy);
  p.dynamic=p.dynamic||p.animated!==false&&(p.glitch>0||p.instability>0);
  return {...visual,semanticProfile:semantic,profile:p,hpComposed:true,hpSemanticComposed:true,
    rigMix:Math.max(visual.rigMix??0,Math.min(1,Math.max(p.damage,p.instability,p.glitch,p.collapse,Math.abs(p.energy-1))*6))};
}

export const CUE_SLOTS=Object.freeze(['damage','heal','critical','manual']);
export const CUE_KINDS=Object.freeze(['damage','heal','critical','flare','pulse','stutter','reform']);
export function readCue(raw) {
  if(raw==null)return null;
  if(typeof raw!=='object'||typeof raw.id!=='string'||!/^[\w-]{1,64}$/.test(raw.id)||!CUE_KINDS.includes(raw.kind)
    ||!Number.isFinite(raw.started)||!Number.isFinite(raw.duration)||raw.duration<0||raw.duration>10000
    ||!Number.isFinite(raw.strength)||raw.strength<0||raw.strength>1)throw new Error('Invalid saved wing reaction.');
  return {id:raw.id,kind:raw.kind,started:raw.started,duration:raw.duration,strength:raw.strength};
}
export function resolveVisuals(data,hp,config,now,seed='flight',context={}) {
  const sampled=sampleCondition(data,hp,config,now,context);
  const effectStyle=resolveEffectStyle(data,config.visualConditions?sampled.condition:'normal',config);
  const legacyAnimated=config.visualConditions&&isLegacyAnimated(sampled.condition,effectStyle);
  const worldConfig=config,choice=config.visualConditions&&!legacyAnimated?variant('condition',sampled.condition,
    effectStyle==='animated'?DEFAULT_CONDITION_ART[sampled.condition]:effectStyle):null;
  // Preserve the existing complete treatment when no new choice is selected.
  // No saved condition, pose, HP profile or transition deadline is replaced.
  // Only this derived switch differs from the sampled configuration. Keep it
  // local instead of copying every unrelated world preference each frame.
  const enhancedConditions=effectStyle==='animated'||legacyAnimated;
  let profile=config.visualConditions?{...sampled.profile}:profileFor('normal');
  if(data.glitchIntensity!=null&&config.visualConditions)profile.glitch=data.glitchIntensity;
  const semanticProfile={...profile};
  const tuning=resolveTuning(data,sampled.condition);
  const severity=conditionSeverity(profile,sampled.condition);
  // Restored treatments reuse the original renderer and seeded damage pattern.
  // Tuning changes their render channels only; semantic severity remains intact.
  if(legacyAnimated){
    const source=legacyAnimationCategory(effectStyle);
    profile=source===sampled.condition?mixProfiles(profileFor('normal'),profile,tuning.strength):mixProfiles(profileFor('normal'),profileFor(source),tuning.strength*severity);
  }
  const hpFade=sampled.incapacitated&&!sampled.overrideActive&&config.zeroHPBehavior==='fade';
  const variantAllowed=choice&&!hpFade&&(!choice.gate||worldConfig[choice.gate])&&
    (!['corona','circuit','starlit','drain','surgeRouting'].includes(choice.id)||worldConfig.energyPulses);
  const amount=variantAllowed?tuning.strength*severity*(choice?.sourceCondition==='glitching'?(sampled.condition==='glitching'?Math.min(worldConfig.glitchLimit,profile.glitch)/Math.max(.001,profile.glitch):Math.min(1,worldConfig.glitchLimit/.8)):1):0;
  // An appearance changes only artwork, never the semantic HP/flight/light state.
  // Beta.29: "None" removes only the extra effect. The condition's own shape
  // (gaps, fold, dimming) stays, instead of showing fully healthy wings.
  if(choice&&!hpFade)profile=profileFor('normal');
  let flare=0,pulse=0,stutter=0,healing=0,geometryFlare=0,geometryPulse=0;
  const bursts=[],reactions=[];

  if(config.transientEffects&&!config.reduced)for(const slot of CUE_SLOTS) {
    const cue=data.cues?.[slot];if(!cue||cue.duration===0||now<cue.started||now>=cue.started+cue.duration)continue;
    if(slot!=='manual'&&(!sampled.autoHP||!config.effectsEnabled))continue;
    if(cue.kind==='damage'&&!config.damageFlares)continue;
    if(cue.kind==='heal'&&!config.healingPulses)continue;
    const p=(now-cue.started)/cue.duration;
    if(slot!=='manual'&&cue.kind==='critical'&&(!config.criticalReactions||!config.damageFlares))continue;
    let reactionStyle=resolveReactionStyle(data,cue.kind,worldConfig,effectStyle);
    if(cue.kind==='critical'&&!config.criticalReactions&&reactionStyle!=='none')reactionStyle=effectStyle==='original'?'original':'animated';
    if(reactionStyle==='none')continue;
    const selected=variant('reaction',cue.kind,reactionStyle);
    if(selected){
      const allowed=cue.kind==='stutter'?config.filamentGlitches&&config.glitchLimit>0:config.reactionWaves&&config.energyPulses;
      if(allowed){
        const strength=cue.strength*config.reactionStrength*resolveTuning(data,cue.kind,'reaction').strength;
        if(strength<=0)continue;
        if(['heal','reform'].includes(cue.kind))healing=Math.max(healing,strength*ease(Math.min(1,p/.12))*(1-ease(p)));
        reactions.push({id:selected.id,kind:cue.kind,progress:p,strength,
          envelope:strength*ease(Math.min(1,p/.12))*(1-ease(p))});
      }
      continue;
    }
    // A separate attack envelope sustains a short flare and then releases it.
    const amount=cue.strength*config.reactionStrength*resolveTuning(data,cue.kind,'reaction').strength;
    if(amount<=0)continue;
    const burst=amount*ease(Math.min(1,p/0.12))*(1-ease(p));
    if(reactionStyle==='animated'&&cue.kind==='stutter'){
      if(config.filamentGlitches&&config.glitchLimit>0)reactions.push({id:'phaseSlip',kind:cue.kind,
        progress:p,strength:amount,envelope:burst});
      continue;
    }
    if(['damage','critical','flare'].includes(cue.kind))flare=Math.max(flare,burst*(cue.kind==='critical'&&config.criticalReactions?1.65:1));
    if(['heal','pulse','reform'].includes(cue.kind))pulse=Math.max(pulse,burst);
    if(cue.kind==='stutter')stutter=Math.max(stutter,burst);
    if(cue.kind==='heal'||cue.kind==='reform')healing=Math.max(healing,burst);
    // Preserve response channels for the bits/audio, while the v2 animated
    // treatment uses local currents instead of inflating the entire wing.
    if(reactionStyle==='original'){
      if(['damage','critical','flare'].includes(cue.kind))geometryFlare=Math.max(geometryFlare,burst);
      if(['heal','pulse','reform'].includes(cue.kind))geometryPulse=Math.max(geometryPulse,burst);
      // Older saved Pulse choices used only a slight glow-width change, which
      // disappeared at normal token scale. Keep its restrained intensity but
      // give the actual lattice a readable tension/release cycle as well.
      if(cue.kind==='pulse'&&worldConfig.enhancedConditions&&config.reactionWaves&&config.energyPulses)
        bursts.push({id:'resonance',kind:'pulse',progress:p,strength:burst*.65,amount:amount*.65,envelope:burst*.65});
    }
    if(reactionStyle==='animated'&&config.reactionWaves&&config.energyPulses&&cue.kind!=='stutter')
      bursts.push({id:DEFAULT_REACTION_ART[cue.kind==='critical'&&!config.criticalReactions?'flare':cue.kind],kind:cue.kind,progress:p,strength:Math.min(1,burst),amount,
        envelope:burst,critical:cue.kind==='critical'&&config.criticalReactions});
  }
  const reformation=reformationOf(bursts,reactions);
  if(reformation){
    // A visible reconstruction temporarily relights the drawn wings. Semantic
    // health/collapse channels captured above remain authoritative for rules.
    const lift=reformation.lift;
    for(const channel of ['damage','instability','glitch','collapse'])profile[channel]*=1-lift;
    profile.energy+=(1-profile.energy)*lift;
  }
  if(!config.filamentBreaks)profile.damage=0;
  if(!config.filamentInstability)profile.instability=0;
  profile.glitch=config.filamentGlitches?Math.min(config.glitchLimit,Math.max(profile.glitch,stutter)):0;
  profile.glitch*=1-Math.min(0.75,healing*0.65);
  if(config.reduced)profile.glitch=0;
  if(!config.energyPulses){pulse=0;healing=0;}
  const animated=!config.reduced;
  const time=animated?(now-data.started)/1000:0;
  const result={...profile,flare:Math.min(1,flare),pulse:Math.min(1,pulse),geometryFlare:Math.min(1,geometryFlare),
    geometryPulse:Math.min(1,geometryPulse),healing:Math.min(1,healing),
    reformation,
    reactionMotion:worldConfig.filamentInstability?worldConfig.conditionMotionStrength:0,
    sag:config.filamentInstability?profile.damage:0,
    time,seed:hash(seed),animated,energyPulses:config.energyPulses&&animated};
  // These are derived render channels only. Existing saved profiles/schema and
  // cinematic interpolation stay unchanged, including old transition endpoints.
  const enhanced=!!enhancedConditions;
  const overdrive=enhanced?unit((profile.energy-1)/0.4):0;
  const hpAlternative=sampled.incapacitated&&!sampled.overrideActive&&config.zeroHPBehavior!=='collapse';
  const suppression=enhanced&&!hpAlternative?
    ease(unit((0.65-profile.energy)/0.5))*(1-profile.collapse)*(1-ease((profile.damage-0.15)/0.4)):0;
  Object.assign(result,{enhanced,overdrive,suppression,
    motionStrength:enhanced?config.conditionMotionStrength:0,
    effectTime:time*(config.conditionAnimationSpeed??1)*(legacyAnimated?tuning.speed:1),
    displacement:enhanced?config.glitchDisplacement:0,
    echoes:enhanced&&config.glitchEchoes&&animated&&profile.glitch>0,
    sparks:enhanced&&config.conditionSparks&&animated&&config.energyPulses,
    arcs:enhanced&&config.overdriveArcs&&animated&&config.energyPulses,
    bursts,
    // Retain enough filament light for the geometric damage to be legible.
    // Source alpha, token opacity and world intensity caps are still multiplied.
    renderOpacity:effectStyle==='none'?Math.max(.55,Math.min(1,profile.energy)):enhanced&&!(hpAlternative&&config.zeroHPBehavior==='fade')?profile.energy>=0.65?Math.min(1,0.86+0.14*(profile.energy-0.65)/0.35):
      0.12+0.74*profile.energy/0.65:Math.min(1,profile.energy)});
  if(legacyAnimated)result.variant=null;
  if(choice||reactions.length){
    const repairGain=['damaged','unstable','glitching'].includes(sampled.condition)?1-Math.min(.75,healing*.65):1;
    const variantAmount=amount*(1-(reformation?.lift??0))*repairGain;
    result.variant=variantAmount>0?{id:choice.id,condition:choice.sourceCondition??sampled.condition,activeCondition:sampled.condition,amount:variantAmount,time:time*(worldConfig.conditionAnimationSpeed??1)*tuning.speed,frequency:tuning.frequency}:null;
    result.reactions=reactions;
    result.variantMotion=worldConfig.conditionMotionStrength;
    result.gates={breaks:worldConfig.filamentBreaks,instability:worldConfig.filamentInstability,
      glitches:worldConfig.filamentGlitches,sparks:worldConfig.conditionSparks&&config.energyPulses,
      echoes:worldConfig.glitchEchoes,arcs:worldConfig.overdriveArcs&&config.energyPulses,
      displacement:worldConfig.glitchDisplacement,glitchLimit:worldConfig.glitchLimit};
    result.renderOpacity=choice&&amount>0?(.98-.15*(choice.sourceCondition==='suppressed'?amount:0)):result.renderOpacity;
  }
  result.dynamic=animated&&(profile.glitch>0||profile.instability>0||enhanced&&(
    result.sparks&&(profile.damage>0||profile.collapse>0)||result.arcs&&overdrive>0||
    result.energyPulses&&(overdrive>0||suppression>0))||bursts.length>0||!!result.variant||reactions.length>0);
  const rigMix=Math.min(1,Math.max(profile.damage,profile.instability,profile.glitch,profile.collapse,
    Math.abs(profile.energy-1),flare,pulse,amount,reactions.length?1:0,!enhanced&&bursts.some(b=>b.strength>0)?1:0)*6);
  const hpOverlayProfile=config.visualConditions&&sampled.autoHP&&hp&&
    resolveEffectStyle(data,sampled.automaticCondition,worldConfig)!=='none'?{...sampled.automaticProfile,
      ...(data.glitchIntensity!=null?{glitch:data.glitchIntensity}:{})}:null;
  const visual={...sampled,condition:config.visualConditions?sampled.condition:'normal',effectStyle,semanticProfile,profile:result,rigMix,hpOverlayProfile,hpComposed:false,
    hpSemanticComposed:data.conditionSource==='auto'&&!sampled.overrideActive};
  // Auto alone keeps its existing authored HP treatment. Manual states and
  // temporary conditions gain the independent material layer immediately;
  // actor-condition artwork composes it when that artwork is selected later.
  if(hpOverlayProfile&&effectStyle!=='none'&&(data.conditionSource!=='auto'||sampled.overrideActive))return composeHPArtwork(visual,worldConfig);
  // Beta.29: the Damaged and Unstable HP bands also wear part of their own
  // material wear (real gaps, sag, a little tremor) under the band's artwork,
  // so a hurt wing reads at token size. Critical and below already read.
  if(hpOverlayProfile&&choice&&amount>0&&['damaged','unstable'].includes(sampled.condition)&&!sampled.overrideActive){
    const hp=hpOverlayProfile,wear=HP_BAND_WEAR;
    return composeHPArtwork({...visual,hpOverlayProfile:{damage:hp.damage*wear.damage,instability:hp.instability*wear.instability,glitch:hp.glitch*wear.glitch,
      energy:1-(1-hp.energy)*wear.energy,collapse:0}},worldConfig);
  }
  return visual;
}
