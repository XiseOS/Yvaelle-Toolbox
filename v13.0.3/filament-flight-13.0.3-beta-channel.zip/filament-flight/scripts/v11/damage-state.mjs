/** Yvaelle’s Toolbox v11 · Damage state: events and clocks → the wing state (pure).
 *
 * One record per token. The runtime feeds it what the table already knows
 * (a blow and its type, her persistent damage, her dying value and recovery
 * checks, her conditions, her HP), and each frame `sampleDamage` writes the
 * small state the wing rig draws (wing-damage.mjs) into one reused object.
 * Nothing is allocated per frame once a look is running; with nothing going
 * on it returns null and the rig does no v11 work at all.
 *
 * Times are seconds on one monotonic clock (the caller's). Every client runs
 * the same rules on the same synced data, so every client shows the same
 * looks (each from the moment it heard of the event). */
import {CYCLE,LEAD,CLEAN_T,SLOT_OFF,PERSIST_PREFER,PERSIST_PHSHIFT,QUADS,WOUND_SPAN,mentalHold,persistHitch,LOST_BIT,dyingFold} from './wing-damage.mjs?v=13.0.3';
import {woundLookOf,persistLookOf,tintForType,persistPart,woundPart} from './damage-events.mjs?v=13.0.3';
import {statusWingBeatPhase} from '../status-flight-character.mjs?v=13.0.3';

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const env=(t,a,ain,b,bout)=>smooth((t-a)/ain)*(1-smooth((t-b)/bout));
const accEnv=(ph,len=.3)=>{const x=ph/len;return x<1?(x<.25?smooth(x/.25):1-smooth((x-.25)/.75)):0;};
const hash1=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s);};
const tint6=t=>[...t.rgb,...t.core];

export function createDamageState(){
  return {
    wound:null,                    // {look,type,at,side,elec,tint}
    prevWound:null,                // (test.5) the wound a new blow cut short: {…wound, cut} (its bits ease back)
    persist:[],                    // [{type,look,n,at,off,quad,slot,tint,name}]
    nextN:0,
    dying:{level:0,startAt:-1,l2At:-1,l3At:-1,dropAt2:-1,dropAt3:-1,okAt:-1,healAt:-1,fails:[],relit:false},
    mood:{to:'normal',from:'normal',at:-1e9,in:1,afterglowAt:-1e9},
    fatigue:{k:0,target:0,at:0},
    phases:new Float64Array(8),phaseN:0,phaseFrame:-1,heldAt:-1,held:0,
    D:{t:0,tick:0,wound:null,prevWound:null,persist:[],dying:null,mood:null,alt:null,px:1.7},
    W:{look:'',q:0,side:'right',elec:'b',tint:null},
    W0:{look:'',q:0,side:'right',elec:'b',tint:null,k:0},
    Y:{ember:0,huddle:0,lost:0,ok:0,heal:0,t:0,stutter:null,fold:1},
    St:{i:0,k:0,hold:false},
    M:{from:'normal',to:'normal',k:1},
    live:[],                       // reused persistent contexts
  };
}

/* ---------------- events ---------------- */
/** A blow of damage type `type` from direction dir (push direction, token → away from the attacker). */
export function noteBlow(S,{type,at,dir=null,elec='b',css=null}){
  const look=woundLookOf(type);
  // the struck wing faces the attacker: a blow pushing her left came from her right
  const dx=dir?.[0]??0;const side=Math.abs(dx)>.15?(dx<0?'right':'left'):null;
  // (test.5) a wound still playing is not cut: its bits' dim, tint and spin ease back under the new one
  const old=S.wound;S.prevWound=old&&at-old.at>=0&&at-old.at<WOUND_SPAN?{...old,cut:at}:null;
  S.wound={look,type,at,side,elec:elec==='a'?'a':'b',tint:look==='other'?tint6(tintForType(type,css)):null};
  return S.wound;
}
/** Her persistent damage types now (e.g. from the condition response). New
 * types claim a quarter (keeping existing ones where they are); removed types
 * play their cleansed ending. cssFor(type) → PF2e's colour (fallback only). */
export function setPersistent(S,types,at,cssFor=null){
  const want=new Set(types??[]);
  for(const x of S.persist)if(x.off<0&&!want.has(x.type))x.off=at;
  for(const type of want){
    if(S.persist.some(x=>x.type===type&&x.off<0))continue;
    const look=persistLookOf(type),live=S.persist.filter(x=>x.off<0||at-x.off<CLEAN_T);
    const used=new Set(live.map(x=>x.quad)),pref=PERSIST_PREFER[look]??PERSIST_PREFER.fallback;
    const quad=pref.find(q=>!used.has(q))??pref[0];
    const usedS=new Set(live.map(x=>x.slot)),slot=[0,1,2,3].find(k=>!usedS.has(k))??live.length%4;
    S.persist.push({type,look,n:S.nextN++%16,at,off:-1,quad,slot,tint:look==='fallback'?tint6(tintForType(type,cssFor?.(type)??null)):null});
  }
  S.persist=S.persist.filter(x=>x.off<0||at-x.off<CLEAN_T);
  return S.persist;
}
/** The quarter each live persistent type holds (for tests and the HUD). */
export const persistQuarters=S=>Object.fromEntries(S.persist.filter(x=>x.off<0).map(x=>[x.type,x.quad]));
/** Her dying value now. */
export function setDying(S,value,at,{dead=false}={}){
  const Y=S.dying,v=Math.max(0,Math.min(3,Math.round(value)||0)),was=Y.level;
  if(v===was)return;
  if(v>0&&was===0&&!(Y.startAt>=0&&Y.healAt>=0&&at-Y.healAt<.5)){Object.assign(Y,{startAt:at,l2At:-1,l3At:-1,dropAt2:-1,dropAt3:-1,okAt:-1,healAt:-1,relit:false});Y.fails.length=0;}
  if(v>=2&&was<2){Y.l2At=at;Y.dropAt2=-1;}
  if(v>=3&&was<3){Y.l3At=at;Y.dropAt3=-1;Y.relit=false;}
  if(v<3&&was>=3){Y.dropAt3=at;}
  if(v<2&&was>=2){Y.dropAt2=at;}
  if(v===0&&was>0&&!dead)Y.healAt=at;
  Y.level=v;
}
/** A recovery check: success or failure (the flat-check chat message). */
export function noteRecovery(S,success,at){
  const Y=S.dying;if(Y.level<=0&&Y.healAt<0)return;
  if(success)Y.okAt=at;else{Y.fails.push({at,bit:Y.level>=2?LOST_BIT:2});if(Y.fails.length>4)Y.fails.shift();}
}
/** Mood weather: the mood her state calls for now ('normal', 'frightened', …). */
const MOOD_IN={frightened:3.2,afterglow:1.4,doomed:3.4,quickened:2.8,sickened:3.2};
const MOOD_OUT={frightened:3.2,afterglow:25,doomed:3.2,quickened:3.2,sickened:3.2,normal:3.2};
export const AFTERGLOW_HOLD=6;
export function setMood(S,mood,at){
  const M=S.mood;if(mood===M.to)return;
  M.from=M.to;M.to=mood;M.at=at;M.in=mood==='normal'?MOOD_OUT[M.from]??3.2:MOOD_IN[mood]??3;
}
/** Which mood her conditions call for (each part a switch). c: {frightened, sickened, doomed, wounded, quickened}, afterglow: s since a big heal. */
export function moodFor(c,afterglowAge,parts){
  if(parts.moodFrightened&&c.frightened)return 'frightened';
  if(parts.moodSickened&&c.sickened)return 'sickened';
  if(parts.moodDoomed&&(c.doomed||(c.wounded??0)>=2))return 'doomed';
  if(parts.moodQuickened&&c.quickened)return 'quickened';
  if(parts.moodAfterglow&&afterglowAge>=0&&afterglowAge<AFTERGLOW_HOLD)return 'afterglow';
  return 'normal';
}

/* ---------------- low-HP fatigue ---------------- */
/** How fatigued she is for an HP fraction (0 above about a quarter, 1 by a tenth). */
export const fatigueTarget=hp=>smooth((.26-hp)/.085);
/** The module's own status phase warp for fatigue f (statusFlightCharacter). */
export function fatigueCharacter(f){return {active:f>.001,animated:true,phaseWarp:.14*f,phaseHarmonic:-.05*f,phaseTug:0,phaseDownstroke:.52*f,leftBias:0};}
/** An occasional catch in the rhythm, at irregular times (0..1). */
export function fatigueCatch(t){
  const P=3.1,i=Math.floor(t/P),start=i*P+hash1(i)*1.6,x=t-start;
  if(hash1(i*7.3)<.35)return 0;   // not every window catches
  return x<0?0:x<.12?x/.12:x<.38?1-.15*(x-.12)/.26:x<.62?.85*(1-(x-.38)/.24):0;
}

/** Two-stage easing toward a target (the lab's follow, tau s). */
export function followFatigue(F,target,dt,tau=.55){const k=1-Math.exp(-Math.max(0,dt)/tau);F.a=(F.a??0)+(target-(F.a??0))*k;F.k+=(F.a-F.k)*k;if(Math.abs(F.k-target)<1e-4&&Math.abs(F.a-target)<1e-4)F.k=F.a=target;return F.k;}
/** The visual profile with this frame's state on it (a new object only while something shows). */
export function withDamageVisual(visual,D,fatigue=0){
  if(!D&&!(fatigue>.001))return visual;
  const v={...visual,v11dmg:D};
  if(D?.dying&&(visual.collapse??0)>D.dying.fold)v.collapse=D.dying.fold;
  if(fatigue>.001){const f=fatigueCharacter(fatigue),c=visual.statusFlightCharacter;
    v.statusFlightCharacter=c?.active?{...c,phaseWarp:(c.phaseWarp??0)+f.phaseWarp,phaseHarmonic:(c.phaseHarmonic??0)+f.phaseHarmonic,phaseDownstroke:(c.phaseDownstroke??0)+f.phaseDownstroke}:f;}
  return v;
}

/** Mental: the struck wing (or a persistent mental quarter on its turn) beats at a
 * held phase. Call once the frame's wing phase is known; writes D.alt. */
export function applyHeldPhase(S,D,phase,now){
  D.alt=null;const live=D.persist??[];
  const fr=Math.round(now*30);if(fr!==S.phaseFrame){S.phaseFrame=fr;S.phases[fr&7]=phase;}
  let hold=0,lag=0,side=null;
  if(D.wound?.look==='mental'){const h=mentalHold(D.wound.q);if(h){hold=h.hold;lag=h.lag;side=D.wound.side;}}
  if(!side)for(const c of live)if(persistHitch(c)){hold=3;lag=.05*TAU;side=QUADS[c.quad].side;break;}
  if(!side)return null;
  const held=fr-((fr%hold+hold)%hold),p=S.phases[held&7];const alt=D.altRec??={side:'left',phase:0};
  alt.side=side;alt.phase=(fr-held<8&&Number.isFinite(p)?p:phase)-lag;D.alt=alt;return alt;
}

/* ---------------- the frame's state ---------------- */
/** Write this frame's wing state (or return null when nothing shows).
 * now: seconds; parts: {wounds, persistent, dyingStages, moodWeather} part maps (feature off → all false);
 * phase: her wing phase (radians, for the mental hold); fallen: on her fallen pose. */
export function sampleDamage(S,now,parts,{phase=null,fallen=false,px=1.7,elec='b',moving=true}={}){
  const D=S.D;let any=false,anim=false;
  // a wound
  const w=S.wound;D.wound=null;
  if(w){const q=now-w.at;
    if(q>WOUND_SPAN+.1)S.wound=null;
    else if(q>=0&&parts.wounds?.[woundPart(w.look)]){const W=S.W;W.look=w.look;W.q=q;W.side=w.side??sideOf(w.look);W.elec=parts.elec??w.elec;W.tint=w.tint;D.wound=W;any=anim=true;}}
  const pw=S.prevWound;D.prevWound=null;
  if(pw){const k=1-smooth((now-pw.cut)/PREV_FADE),q=now-pw.at;
    if(!(k>0)||q>WOUND_SPAN)S.prevWound=null;
    else if(q>=0&&parts.wounds?.[woundPart(pw.look)]){const W=S.W0;W.look=pw.look;W.q=q;W.side=pw.side??sideOf(pw.look);W.elec=parts.elec??pw.elec;W.tint=pw.tint;W.k=k;D.prevWound=W;any=anim=true;}}
  // persistent damage
  const live=S.live;live.length=0;D.persist=live;
  if(S.persist.length){
    let keep=0;for(const x of S.persist)if(x.off<0||now-x.off<CLEAN_T)S.persist[keep++]=x;S.persist.length=keep;   // (in place)
    for(const x of S.persist){
      if(!parts.persistent?.[persistPart(x.look)])continue;
      const q=now-x.at;if(q<0)continue;const cq=x.off>=0?now-x.off:-1,cl=cq<0?0:unit(cq/CLEAN_T);if(cl>=1)continue;
      const on=smooth(q/1.2);
      // a quarter shared by a 5th+ type: they alternate every two cycles
      let share=1,n=0,k0=0;for(const y of S.persist)if(y.quad===x.quad&&(y.off<0||now-y.off<CLEAN_T)&&parts.persistent?.[persistPart(y.look)]){if(y===x)k0=n;n++;}
      if(n>1){const per=CYCLE*2,u=(now/per)%n,d=Math.min(Math.abs(u-k0),n-Math.abs(u-k0));share=1-smooth((d-.4)/.2);}
      const phase=(q-LEAD+(PERSIST_PHSHIFT[x.look]??0)*CYCLE)/CYCLE+SLOT_OFF[x.slot],cycleN=Math.floor(phase),ph=((phase%1)+1)%1;
      const acc=q<LEAD-.05?0:accEnv(ph);
      if(on*share<=.002&&cq<0)continue;
      const c=x.ctx??={look:x.look,n:x.n,quad:x.quad,tint:x.tint};
      c.look=x.look;c.n=x.n;c.quad=x.quad;c.tint=x.tint;c.q=q;c.cq=cq;c.cq0=x.off>=0?x.off-x.at:0;c.cl=cl;c.on=on*share;c.k=on*share*(cq<0?1:1-smooth(cl/.9));c.ph=ph;c.acc=acc*share;c.cycleN=cycleN;c.t=now;
      live.push(c);any=anim=true;
    }
  }
  // dying stages (on her fallen pose)
  D.dying=null;
  const Yd=S.dying;
  const DP=parts.dyingStages;
  if(DP&&(DP.dying1||DP.dying2||DP.dying3||DP.dyingRecover)&&(Yd.level>0||Yd.healAt>=0&&now-Yd.healAt<4)&&Yd.startAt>=0){
    const Y=S.Y,P=parts.dyingStages,heal=Yd.healAt>=0?now-Yd.healAt:-1,healOut=t0=>heal<0?1:1-smooth((heal-t0)/2.4);
    Y.t=now;Y.heal=P.dyingRecover&&heal>=0?heal:-1;
    Y.huddle=P.dying1?smooth((now-Yd.startAt)/1.4)*(heal<0?1:1-smooth((heal-.6)/2.2)):0;
    const e2=Yd.l2At>=0?smooth((now-Yd.l2At)/1.8)*(Yd.dropAt2>=0?1-smooth((now-Yd.dropAt2-.4)/2.4):1):0;
    Y.ember=P.dying2?e2*healOut(.4):0;
    let lost=0;
    if(P.dying3&&Yd.l3At>=0){const q=now-Yd.l3At;lost=q<2.2?(Math.sin(q*31)*Math.sin(q*13.7)>.1-.6*q/2.2?1:0)*smooth(q/.2):1;
      if(Yd.dropAt3>=0)lost*=1-.75*smooth((now-Yd.dropAt3-.5)/.8);
      lost*=heal<0?1:1-smooth((heal-.3)/1.2);}
    Y.lost=lost;
    Y.ok=P.dyingRecover&&Yd.okAt>=0?env(now,Yd.okAt,.25,Yd.okAt+1.6,.9):0;
    Y.stutter=null;
    if(P.dyingRecover)for(const f of Yd.fails){const q=now-f.at;if(q>=0&&q<1.1){const St=S.St;St.i=f.bit;St.k=bump(unit(q/1.1));St.hold=Math.floor(q*30)%5<3;Y.stutter=St;}}
    Y.fold=heal>=0?dyingFold(heal):.86;
    // the continuous stage (0..3) the wingless frame reads: each step eases in, and out as she recovers
    const st=(at,drop)=>at<0?0:smooth((now-at)/.9)*(drop>=0?1-smooth((now-drop)/.9):1);
    Y.lv=(st(Yd.startAt,-1)+(P.dying2?st(Yd.l2At,Yd.dropAt2):0)+(P.dying3?st(Yd.l3At,Yd.dropAt3):0))*(heal<0?1:1-smooth(heal/2.4));
    if(Y.huddle>.002||Y.ember>.002||Y.lost>.002||Y.ok>.002||Y.stutter||heal>=0){D.dying=Y;any=true;anim=true;}
    if(heal>=0&&heal>4){Yd.startAt=-1;Yd.healAt=-1;}
  }
  // mood weather
  D.mood=null;const M=S.mood;
  if(parts.moodWeather!==false&&!(M.to==='normal'&&M.from==='normal')){
    const k=unit((now-M.at)/M.in),Mo=S.M;Mo.from=M.from;Mo.to=M.to;Mo.k=k;
    if(k>=1&&M.to==='normal'){M.from='normal';}
    else{D.mood=Mo;any=true;if(k<1)anim=true;}
  }
  D.alt=null;
  if(phase!=null)applyHeldPhase(S,D,phase,now);
  if(!any){return null;}
  D.px=px;
  if(anim&&moving!==false){D.t=now;D.tick=(D.tick+1)%1e6;}
  D.anim=anim;
  return D;
}
const SIDES={fire:'right',cold:'left',electricity:'right',acid:'left',force:'right',mental:'left',void:'right',poison:'right',slashing:'right',piercing:'left',bludgeoning:'right',other:'right'};
export const sideOf=look=>SIDES[look]??'right';

/* ---------------- feel (main thread, with the flight feel) ---------------- */
import {woundFeel,woundBit,persistFeel,persistBit,moodBitTint} from './wing-damage.mjs?v=13.0.3';
const BIT=[0,1,2,3].map(()=>({spin:0,dim:0,tint:null,spinMul:1})),BIT0={spin:0,dim:0,tint:null};
/** (test.5) How long a wound cut short by a new blow takes to let its bits go (s). */
export const PREV_FADE=.4;
const HUD=[[-.6,-.2],[.6,-.2],[-.48,.4],[.48,.4]];
/** Apply this frame's state to the flight feel's output (beat rate, lift, flex, bits).
 * size: her token size in px. fatigue: 0..1 (low HP), t: s, turns: her wing clock. */
export function applyDamageFeel(D,out,{size=100,fatigue=0,t=0,turns=0}={}){
  const u=size/100;
  if(D){
    if(D.wound){const b=out.beatRate,l=out.lift;woundFeel(D.wound,out);out.lift=l+(out.lift-l)*u;void b;}
    if(D.persist?.length)persistFeel(D.persist,out);
    for(let i=0;i<4;i++){const o=BIT[i];o.spin=0;o.dim=0;o.tint=null;o.spinMul=1;const left=i===0||i===2;
      if(D.wound)woundBit(D.wound,o,i,left);
      if(D.prevWound){const p=BIT0,k=D.prevWound.k;p.spin=0;p.dim=0;p.tint=null;woundBit(D.prevWound,p,i,left);
        if(p.dim)o.dim=Math.max(o.dim,p.dim*k);if(p.spin)o.spin+=p.spin*k;
        if(p.tint){const a=o.tint??[1,1,1];o.tint=[a[0]+(p.tint[0]-a[0])*k,a[1]+(p.tint[1]-a[1])*k,a[2]+(p.tint[2]-a[2])*k];}}
      if(D.persist?.length)persistBit(D.persist,o,i,left);
      if(D.mood){const m=moodBitTint(D.mood);if(m)o.tint=o.tint?[o.tint[0]*m[0],o.tint[1]*m[1],o.tint[2]*m[2]]:m;}
      const Y=D.dying;
      if(Y){const fb=out.bits[i];
        // Dying 1: the bits huddle in close round her, low and slow
        if(Y.huddle>.002){fb.mix=Math.max(fb.mix??0,Y.huddle);fb.local=true;fb.tx=HUD[i][0];fb.ty=HUD[i][1]+Math.sin(t*1.4+i*1.6)*.015*Y.huddle;o.spinMul*=1-.7*Y.huddle;}
        if(Y.ember>.002)o.tint=mix3(o.tint,[.65*.6+.35,.62,.62],Y.ember);
        if(i===LOST_BIT&&Y.lost>0)o.dim=Math.max(o.dim,Y.lost);
        if(Y.stutter&&Y.stutter.i===i){if(Y.stutter.hold)o.dim=Math.max(o.dim,.75);fb.x=(fb.x??0)+Math.sin(t*90)*2*Y.stutter.k*u;}
        if(Y.ok>0)o.spinMul*=1-Y.ok;
      }
      const fb=out.bits[i];
      if(o.spinMul!==1)fb.spin=(fb.spin??0)*o.spinMul;
      if(o.spin)fb.spin=(fb.spin??0)+o.spin;
      if(o.dim)fb.dim=Math.max(fb.dim??0,o.dim);
      fb.v11tint=o.tint?((Math.round(unit(o.tint[0])*255)<<16)|(Math.round(unit(o.tint[1])*255)<<8)|Math.round(unit(o.tint[2])*255)):undefined;
    }
  }
  if(fatigue>.001){
    const f=fatigue,c=fatigueCatch(t)*f,ph=statusWingBeatPhase(turns*TAU,fatigueCharacter(f),1);
    out.beatRate*=(1-.27*f)*(1-.72*c);
    out.lift+=(6.5*f+2.4*f*Math.cos(ph)+2.4*c)*u;
    out.bank+=.02*c*Math.sin(t*3.1);
    out.flex=Math.min(1,(out.flex??0)+.35*f);
    out.wingAlpha*=1-.1*f;
    for(let i=0;i<4;i++){const fb=out.bits[i];fb.spin=(fb.spin??0)*(1-.3*f);fb.dim=Math.max(fb.dim??0,.1*f);
      // the bits lag her bob a touch and droop slightly
      fb.y=(fb.y??0)+(1.8*f+.8*f*Math.sin(t*1.3+i))*u-(2.4*f*Math.cos(ph))*.72*f*u;}
  }
  return out;
}
const mix3=(a,b,k)=>a?[a[0]+(b[0]-a[0])*k,a[1]+(b[1]-a[1])*k,a[2]+(b[2]-a[2])*k]:[1+(b[0]-1)*k,1+(b[1]-1)*k,1+(b[2]-1)*k];
