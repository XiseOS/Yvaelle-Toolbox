/** Yvaelle’s Toolbox v11 · Invisibility: the runtime.
 *
 * One record per token with Yvaelle’s Toolbox on it. It reads her sources
 * (conditions, the invisibility skin effect, the manual Fade), picks the look
 * (v11/invis.mjs lookFor), and plays it:
 *
 *   classic  her wings drain through the wing painter (visual.v11Drain, see
 *            v11/shadow-wings.mjs), her portrait through the token layer's
 *            hidden drain, her bits and shadow through two alpha hooks;
 *   a b c    a sweep: one cloak filter on each of her meshes (v11/cloak-filter.mjs)
 *            sharing one state block; the owner/GM ghost behind the front is
 *            the classic held look (her wings painted a second time with the
 *            drain held, into ghost textures); C's few shed pixels are drawn by
 *            the filter, inside her silhouette (test.8: no sprites).
 *   held     (fully cloaked, any look) no filter at all: the classic held
 *            look, a plain ghost for owner/GM and nothing for others.
 *   flicker  a hit while held: the filter comes back for 1.8 s and lets her
 *            waver toward solid (switchable parts: the flicker, the fringe,
 *            the slip and the tremor; others only with the GM option).
 *
 * Sync: a tech cloak (and the manual Fade) is a token flag
 * flags.filament-flight.v11Cloak = {on, start, dir, variant, src, fade}
 * written once per change by one client (her active owner, else the GM);
 * every client computes the same front from it. Classic drains from
 * conditions start on each client when the condition arrives.
 *
 * Cost: nothing at all while she is plainly visible (no ticker, no filter,
 * one Map lookup in each renderer hook). The ticker runs only during a sweep,
 * a drain or a flicker; held is static. Nothing here writes her token's
 * transform, bounds, visibility or vision, and nothing asks for perception.
 * Foundry decides first who can see her; this only ever hides more. */
import {CLOAK,CLOAK_FLAG,CLOAK_SPEEDS,CLOAK_QUICK,sweepOf,nextLook,DIRECTIONS,DRAIN,FLICKER,FLICK_LEN,VARIANT_INDEX,activeSource,lookFor,isCloak,isSkin,frontAt,nextFlag,extentAlong,runOut,
  drainFront,drainHid,viewOf,keepsGhost,threadGhost,filterGhost,ownerViewOf,veilAlpha,hitSeverity,flickerAt,flickerSolid,flickerDetail,slipAt,fringeAt,tremorAt,dirOf} from './invis.mjs?v=13.0.3';
import {HELD,drainGeometry} from './shadow-wings.mjs?v=13.0.3';
import {cloakFilterClass,createCloakState,LIGHT_GAIN,familyOf} from './cloak-filter.mjs?v=13.0.3';
import {rimTextureOf} from './token-rim.mjs?v=13.0.3';
import {hasFoundryRing} from './token-shape.mjs?v=13.0.3';
import {invisHooks} from './invis-hooks.mjs?v=13.0.3';
import {frameSet} from './token-layer-filter.mjs?v=13.0.3';
import {isOn,partOn,choice,partsOf} from './features.mjs?v=13.0.3';
import {paintLayers} from '../wing-rig.mjs?v=13.0.3';
import {cue12,cloakKey} from '../v12/sound-set.mjs?v=13.0.3';

const ID='filament-flight';
const HELD_OWN=HELD,HELD_OTHER=Object.freeze({...HELD,ghost:0});
const LINGER_FRAMES=40;
/** A flag that starts this far past our clock was not written in this session (clients of one session differ by far less). */
const STALE_AHEAD_MS=1500;

/** A PF2e condition on her actor (0 when absent). */
function condition(actor,slug){
  try{
    if(actor?.getCondition?.(slug))return 1;
    if(actor?.hasCondition?.(slug))return 1;
    if(actor?.statuses?.has?.(slug))return 1;
    for(const it of actor?.itemTypes?.condition??[])if(it.slug===slug)return 1;
  }catch{}
  return 0;
}
/** Her sources, read when her actor changes (never per frame). */
export function readSources(actor){
  let skin=false;
  try{
    for(const it of actor?.itemTypes?.effect??[])if(isSkin(it)){skin=true;break;}
    if(!skin)for(const e of actor?.appliedEffects??actor?.effects??[])if(!e.disabled&&isSkin(e)){skin=true;break;}
  }catch{}
  return {invisible:!!condition(actor,'invisible'),hidden:!!condition(actor,'hidden'),undetected:!!condition(actor,'undetected'),skin};
}
function hpOf(actor){const hp=actor?.system?.attributes?.hp;const v=Number(hp?.value),m=Number(hp?.max);return Number.isFinite(v)&&m>0?{value:v,max:m}:null;}

/* ------------------------------------------------------------------ */
/* Ghost wings: her wing layers painted with the drain held             */
/* ------------------------------------------------------------------ */
class GhostWings{
  constructor(){this.layers={};}
  layer(rig,key){
    const src=rig.layers?.[key];if(!src?.surface)return null;
    let g=this.layers[key];
    if(!g){const surface=document.createElement('canvas');surface.width=surface.height=1;g=this.layers[key]={surface,ctx:surface.getContext('2d'),texture:null,painted:false};
      g.texture=PIXI.Texture.from(surface,{mipmap:PIXI.MIPMAP_MODES?.OFF??0});}
    if(g.surface.width!==src.surface.width||g.surface.height!==src.surface.height){g.surface.width=src.surface.width;g.surface.height=src.surface.height;
      g.texture.baseTexture.resource?.resize?.(src.surface.width,src.surface.height);g.texture.baseTexture.setRealSize?.(src.surface.width,src.surface.height);}
    return g;
  }
  /** Start from what her layers show now (held: that IS the ghost). */
  copy(rig){for(const rec of rig.layerRecords??[]){const g=this.layer(rig,rec.key);if(!g)continue;g.ctx.clearRect(0,0,g.surface.width,g.surface.height);g.ctx.drawImage(rec.surface,0,0);g.texture.baseTexture.update();g.painted=true;}}
  /** Paint the layers the rig just painted, with the drain held. */
  paint(rig,geometry,visual,changed,ghost){
    const keys=(rig.layerRecords??[]).filter(rec=>changed.includes(rec.key)||!this.layers[rec.key]?.painted).map(rec=>rec.key);if(!keys.length)return 0;
    const drained=drainGeometry(geometry,ghost),v={...visual,v11Drain:ghost},contexts={};
    for(const key of keys){const g=this.layer(rig,key);if(g)contexts[key]=g.ctx;}
    paintLayers(contexts,drained,rig.size,v,undefined,rig.viewports,Object.keys(contexts));
    for(const key of Object.keys(contexts)){const g=this.layers[key];g.texture.baseTexture.update();g.painted=true;}
    return keys.length;
  }
  destroy(){for(const g of Object.values(this.layers)){g.texture?.destroy(true);g.surface.width=g.surface.height=1;}this.layers={};}
}

/* ------------------------------------------------------------------ */
/* Her record                                                           */
/* ------------------------------------------------------------------ */
class Cloaked{
  constructor(rt,token){
    this.rt=rt;this.token=token;this.src=null;this.look=null;this.sources={invisible:false,hidden:false,undetected:false,skin:false};
    this.flag=null;this.classic=null;this.fl=null;this.hp=undefined;
    this.ph='solid';this.evalAt=-1;this.fr={f:-CLOAK.over,q:1,phase:'solid',moving:false};this.mode='hide';this.F=0;this.q=0;this.view='other';
    this.drainObj=null;this.applied='solid';this.veil='none';this.veilOk=false;
    this.state=createCloakState();this.filters=new Map();this.meshes=[];this.meshCheck=0;this.E=50;this.Et=0;this.eAt=-1;
    this.ghost=null;this.ghostRig=null;this.linger=0;this.heldPainted=false;this.lastT=0;
  }
  get doc(){return this.token.document;}
}

export class InvisRuntime{
  /** manager: the flight manager (her renderers); tokenLayers: v11 token layers; now(): server ms. */
  constructor({manager=null,tokenLayers=null,now=()=>Number(globalThis.game?.time?.serverTime)||Date.now(),reduced=()=>false,current=t=>!!t&&!t.destroyed}={}){
    this.manager=manager;this.tokenLayers=tokenLayers;this.now=now;this.reduced=reduced;this.current=current;
    this.records=new Map();this.atLoad=new Map();this.stale=new Map();this.failed=new WeakMap();this.lastError=null;this.ticking=false;this.frame=0;this.rects=[];
    this.stats={ticks:0,sweeps:0,flickers:0,filterAttach:0,ghostPaints:0,flagWrites:0,pixels:0};   // (pixels: C's shed pixels are drawn by the filter since test.8; always 0)
    if(tokenLayers)tokenLayers.invis=this;
  }
  /* ---------------- which tokens ---------------- */
  wants(token){const doc=token?.document;if(!doc||token.isPreview||!this.current(token))return false;let f=null;try{f=doc.getFlag?.(ID,'flight');}catch{}return !!f;}
  recordOf(target){
    if(!target)return null;if(this.records.has(target))return this.records.get(target);
    const doc=target.document??target;for(const [t,R] of this.records)if(t.document===doc||t.document?.id===doc?.id)return R;return null;
  }
  /** (test.22) Her record, made now if it is missing: a record is dropped when its frame throws (see tick), and until this
   * build nothing brought it back before her token was redrawn, so Fade answered "switch Yvaelle’s Toolbox on" for a token that had it on. */
  recordFor(target){
    const R=this.recordOf(target);if(R)return R;
    const token=target?.object??target;if(!token||!this.wants(token))return null;
    try{this.sync(token);}catch(error){console.error('Yvaelle’s Toolbox | v11 invisibility (re-sync)',error);}
    return this.records.get(token)??null;
  }
  sync(token){
    const has=this.records.get(token),want=this.wants(token);
    if(want&&!has){const R=new Cloaked(this,token);this.records.set(token,R);this.read(R,true);}
    else if(!want&&has)this.drop(has);
    else if(has)this.read(has,false);
  }
  syncAll(){for(const t of [...this.records.keys()])if(!this.wants(t))this.drop(this.records.get(t));for(const t of globalThis.canvas?.tokens?.placeables??[])this.sync(t);}
  drop(R){this.detachAll(R,true);R.ghost?.destroy();if(R.veil==='held')this.tokenLayers?.veil(R.token,'none');this.records.delete(R.token);}

  /* ---------------- reading her (on hooks only) ---------------- */
  choices(doc){return {invisLooks:isOn('invisLooks',doc),invisSpell:choice('invisSpell',doc),invisSkin:choice('invisSkin',doc)};}
  /** (test.7) What her owner or a GM sees of her while hidden, on this browser: faint | gone | threads. */
  ownerView(doc){try{return ownerViewOf(choice('invisLooks.ownerView',doc));}catch{return 'faint';}}
  read(R,first){
    const doc=R.doc,actor=doc.actor;
    R.sources=readSources(actor);R.flag=this.flagOf(doc);R.flickerParts=partsOf('invisFlicker',doc);
    const ov=this.ownerView(doc);if(ov!==R.ov)R.evalAt=-1;if(!first&&ov!==R.ov&&R.filters.size){R.ov=ov;this.evaluate(R,this.now());for(const [mesh,rec] of R.filters)this.attachMesh(R,mesh,rec.kind);const rig=this.rigOf(R);if(rig)rig.signature=null;}R.ov=ov;
    const fade=!!R.flag?.fade,src=activeSource({...R.sources,fade});let look=lookFor(src,this.choices(doc));
    // (12.0.0-beta.11) a Fade wears the look its flag was written with (the wheel, a different look each time, a cloak
    // warp), not the look chosen for her skin. With her skin's look set to Classic, a Fade in any other look was taken
    // for a classic one as it ended: her portrait came back at once and a classic reveal (2 s) ran alongside the sweep,
    // so a short cloak took 2 s to come back and she jumped as the return began.
    if(src==='fade'&&look!=='none'&&R.flag?.fade&&R.flag.variant)look=R.flag.variant;
    const was=R.src,wasLook=R.look;R.src=src;R.look=look;
    // (test.23) what she was found as when this session first read her (for the self-check: a cloak that comes back after a restart)
    if(first&&doc.id&&!this.atLoad.has(doc.id))this.atLoad.set(doc.id,{flag:R.flag?JSON.stringify(R.flag):'none',src:src??'none',look:look??'none',sources:Object.entries(R.sources).filter(([,v])=>v).map(([k])=>k).join('+')||'none',at:this.now()});
    const hp=hpOf(actor);if(hp){if(!first&&R.hp!==undefined&&hp.value<R.hp)this.hit(R,R.hp-hp.value,hp.max);R.hp=hp.value;}
    // a classic or token-layer-only look starts on this client when the source changes
    const local=src&&(look==='classic'||look==='none'),wasLocal=was&&(wasLook==='classic'||wasLook==='none');
    if(!first&&!!local!==!!wasLocal&&!(src&&this.flagGoverns(R))){
      R.classic={mode:local?'hide':'reveal',at:this.now()};
      this.tokenLayers?.hidden(R.token,!!local);R.veil=local?'anim':'none';
    }else if(first&&local){R.classic=null;}
    if(look==='none'&&R.classic){R.classic=null;}
    // (12.0.0-beta.4) the Fade with the Classic drain as her look: the drain runs from the synced flag (evaluate), and
    // her portrait's own drain or reveal begins with it on every client, once per change of the flag
    const cf=R.flag;
    if(cf&&cf.variant==='classic'&&this.flagGoverns(R)){
      const key=`${cf.start}:${cf.on?1:0}`;
      if(R.classicFlag!==key){R.classicFlag=key;
        if(!first&&this.now()-cf.start<(cf.on?DRAIN.hide:DRAIN.reveal)*1000){this.tokenLayers?.hidden(R.token,!!cf.on);R.veil=cf.on?'anim':'none';}}
    }
    // (12.0.0-beta.7) the v12 sound set: her cloak has a sound, going and coming back: once per change of the flag, on
    // every client, and only for a sweep that has just begun (not one found already running, or turned round part-way)
    if(cf&&this.flagGoverns(R)){
      const key=`${cf.start}:${cf.on?1:0}`;
      if(R.soundFlag!==key){R.soundFlag=key;
        if(!first&&this.now()-cf.start<700)cue12(R.token,'cloak',cloakKey(!!cf.on,cf.variant==='classic'?(cf.on?DRAIN.hide:DRAIN.reveal)*DRAIN.done:sweepOf(cf)));}
    }
    this.decide(R);
    this.wake(R);
  }
  /** Her saved cloak flag. (test.24) The flag's start is on the server clock, and Foundry's server clock starts again from zero
   * whenever the server does (seen: a flag from start 195906 read at clock 90144). A flag saved in an earlier session can
   * therefore start "in the future": its sweep looked as if it had not begun, so a cloak that was off came back fully
   * cloaked after a restart. Such a flag is from before this session and is long finished: it is read as settled, and
   * remembered so that it does not replay when this session's clock reaches that number. */
  flagOf(doc){
    let f=null;try{f=doc.getFlag?.(ID,CLOAK_FLAG)??null;}catch{}
    if(!f||typeof f!=='object'||!Number.isFinite(f.start))return null;
    const now=this.now();
    if(f.start>now+STALE_AHEAD_MS)this.stale.set(doc.id,f.start);
    return this.stale.get(doc.id)===f.start?{...f,start:Math.min(f.start,now)-sweepOf(f)*1000-1000}:f;
  }
  flagGoverns(R,now=this.now()){const f=R.flag;return !!f&&(f.on||now-f.start<sweepOf(f)*1000);}
  /** (12.0.0-beta.5) Cloak depth: how long her cloak's sweep takes (s). Normal unless she chose another speed. */
  speed(doc){try{return isOn('cloakDepth',doc)?CLOAK_SPEEDS[choice('cloakSpeed',doc)]??CLOAK.sweep:CLOAK.sweep;}catch{return CLOAK.sweep;}}
  /** One client writes the flag for a change: her first active non-GM owner, else the first active GM. */
  isWriter(doc){
    const users=[...(globalThis.game?.users??[])].filter(u=>u.active);
    const owns=u=>{try{return doc.testUserPermission?.(u,'OWNER')??false;}catch{return false;}};
    const players=users.filter(u=>!u.isGM&&owns(u)),pool=players.length?players:users.filter(u=>u.isGM);
    pool.sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);
    return (pool[0]?.id??globalThis.game?.user?.id)===globalThis.game?.user?.id;
  }
  /** The writer brings the flag in line with her sources (a tech cloak, or the manual Fade, needs the synced front). */
  decide(R){
    const doc=R.doc,flag=R.flag,src=R.src,look=R.look;
    if(!doc.isOwner&&!globalThis.game?.user?.isGM)return;
    if(!this.isWriter(doc))return;
    const synced=!!src&&(isCloak(look)||src==='fade'),now=this.now(),fade=!!flag?.fade;
    if(synced&&!flag?.on){
      const variant=look==='none'?'classic':look;
      this.writeFlag(R,{...nextFlag(flag,true,now,{dir:choice('invisSweep',doc),variant,src,T:this.speed(doc)}),fade});
    }else if(!synced&&flag?.on){
      // still invisible from a classic source (her skin came off, the spell stays): no sweep, she stays held
      if(src&&(look==='classic'||look==='none'))this.writeFlag(R,{...flag,on:false,start:now-sweepOf(flag)*1000-1,fade});
      else this.writeFlag(R,{...nextFlag(flag,false,now),fade});
    }
  }
  writeFlag(R,flag){
    // (12.0.0-beta.6) its length is always written. A document update MERGES into the stored flag, so a flag written
    // without T kept the T of the one before it: after a cloak warp (1.1 s) or an attack breaking her Fade (0.85 s),
    // every later cloak was cut short at that length on the next read of the document.
    flag={...flag,T:sweepOf(flag)};
    if(R.writing&&JSON.stringify(R.writing)===JSON.stringify(flag))return;
    R.writing=flag;R.flag=flag;this.stats.flagWrites++;this.wake(R);
    Promise.resolve(R.doc.update?.({[`flags.${ID}.${CLOAK_FLAG}`]:flag})).catch(error=>console.warn('Yvaelle’s Toolbox | v11 cloak flag',error)).finally(()=>{if(R.writing===flag)R.writing=null;});
  }
  /** A blow while she is held: the flicker. */
  hit(R,lost,max){
    if(!isOn('invisFlicker',R.doc))return;
    const now=this.now();this.evaluate(R,now);if(R.ph!=='held'&&R.ph!=='flicker')return;
    R.fl={at:now,sev:hitSeverity(lost,max)};this.stats.flickers++;this.wake(R);
  }

  /* ---------------- the moment (cheap, cached per clock value) ---------------- */
  evaluate(R,now){
    if(R.evalAt===now)return R.ph;R.evalAt=now;
    const tk=R.token,doc=R.doc,g=globalThis.game;
    R.view=viewOf({isOwner:!!doc.isOwner,isGM:!!g?.user?.isGM,detected:!!tk.detectionFilter,ownerView:R.ov});
    let ph='solid';const f=R.flag;
    if(f&&this.flagGoverns(R,now)){
      if(isCloak(f.variant)){frontAt(f,now,sweepOf(f),CLOAK.over,R.fr);ph=R.fr.moving?'sweep':f.on?'held':'solid';}
      else{R.mode=f.on?'hide':'reveal';R.q=(now-f.start)/1000;ph=this.classicPhase(R);}
    }else if(R.src&&(R.look==='classic'||R.look==='none')){
      if(R.classic?.mode==='hide'){R.mode='hide';R.q=(now-R.classic.at)/1000;ph=this.classicPhase(R);}else ph='held';
    }else if(R.classic?.mode==='reveal'){R.mode='reveal';R.q=(now-R.classic.at)/1000;ph=this.classicPhase(R);if(ph==='solid')R.classic=null;}
    if(ph==='drain')R.F=Math.round(drainFront(R.mode,R.q)*400)/400;
    if(ph==='held'&&R.fl){const q=(now-R.fl.at)/1000;if(q<FLICK_LEN&&(keepsGhost(R.view)||partOn('invisFlicker','invisFlickerOthers')))ph='flicker';else if(q>=FLICK_LEN)R.fl=null;}
    R.ph=ph;return ph;
  }
  classicPhase(R){const len=R.mode==='hide'?DRAIN.hide:DRAIN.reveal;return R.q<len*DRAIN.done?'drain':R.mode==='hide'?'held':'solid';}

  /* ---------------- renderer hooks ---------------- */
  /** view (11.0.0-test.4, the self-check): 'owner' | 'detected' | 'other' evaluates another client's view; omitted, this client's. */
  drainFor(token,now,view=null){
    const R=this.records.get(token);if(!R||R.look==='none')return null;
    const ph=this.evaluate(R,now),V=view??R.view,own=keepsGhost(V);
    // (test.7) Faint keeps her own wing pattern: no drain at all, her pieces fade by alpha (alphaFor)
    if(V==='faint')return null;
    if(view)return ph==='held'?(own?HELD_OWN:HELD_OTHER):ph==='drain'?{mode:R.mode,F:R.F,ghost:own?1:0}:null;
    if(ph==='held')return own?HELD_OWN:HELD_OTHER;
    if(ph!=='drain')return null;
    const len=R.mode==='hide'?DRAIN.hide:DRAIN.reveal,hot=R.q/len<DRAIN.done,o=R.drainObj;
    if(o&&o.F===R.F&&o.mode===R.mode&&o.ghost===(own?1:0)&&o.hot===hot)return o;
    return R.drainObj=Object.freeze({mode:R.mode,F:R.F,ghost:own?1:0,hot});
  }
  /** (test.21) Is her portrait see-through here right now (not solid, and this screen keeps her ghost)? Her wings behind it would show through. */
  throughFor(token){const R=this.records.get(token);if(!R||R.look==='none')return false;return this.evaluate(R,this.now())!=='solid'&&keepsGhost(R.view);}
  /** (test.7) Does this client keep her portrait's ghost (the token layer asks while her hidden look plays)? null: not hers. */
  ghostFor(token){const R=this.records.get(token);if(!R)return null;this.evaluate(R,this.now());return keepsGhost(R.view);}
  alphaFor(token,kind,view=null){
    const R=this.records.get(token);if(!R||R.look==='none')return 1;
    // (test.7) a piece that carries a cloak filter right now is veiled by the filter alone: its own alpha stays 1
    // (the filters are put on and taken off by tick(), which runs before her renderers each frame, so the two never disagree)
    if(!view&&R.filters.size&&kind!=='fx'&&this.filtered(R,kind))return 1;
    const ph=this.evaluate(R,this.now()),V=view??R.view;
    if(ph==='held')return veilAlpha(V,1,kind);
    // (test.3) the effects drawn away from her meshes carry no cloak filter: they follow the sweep's front
    // (hidden while held, even through a flicker); a drain hides them as it hides her light
    if(kind==='fx'){if(ph==='flicker')return veilAlpha(V,1,kind);
      if(ph==='sweep'){const O=CLOAK.over,hid=Math.max(0,Math.min(1,(R.fr.f+O)/(2*O)));return veilAlpha(V,hid,kind);}}
    if(ph!=='drain')return 1;
    const hid=kind==='bits'?(R.mode==='hide'?smoothBit(R.F):1-smoothBitR(R.F)):drainHid(R.mode,R.F);
    return veilAlpha(V,hid,kind);
  }
  /** Only the thread ghost needs her wing geometry on this thread (GhostWings); Faint, Gone and other players leave the painting where it is. */
  /** Does one of her pieces of this alpha kind (wings | bits | shadow) carry a cloak filter now? */
  filtered(R,kind){
    let K=R.fk;if(!K||R.fkN!==R.filters.size){K=R.fk??={wings:false,bits:false,shadow:false,token:false};K.wings=K.bits=K.shadow=K.token=false;
      for(const rec of R.filters.values())K[rec.kind==='wing'||rec.kind==='plain'?'wings':rec.kind==='compact'?'bits':rec.kind]=true;R.fkN=R.filters.size;}
    return !!K[kind];
  }
  mainThreadFor(token){const R=this.records.get(token);if(!R)return false;const ph=this.evaluate(R,this.now());return (ph==='sweep'||ph==='flicker')&&threadGhost(R.view);}
  painted(rig,geometry,visual,changed){
    const R=this.records.get(rig.token);if(!R)return;
    if(visual?.v11Drain===HELD_OWN||visual?.v11Drain===HELD_OTHER)R.heldPainted=true;
    const ph=R.ph;if((ph!=='sweep'&&ph!=='flicker')||!threadGhost(R.view))return;
    if(R.ghostRig!==rig){R.ghost?.destroy();R.ghost=new GhostWings();R.ghostRig=rig;}
    const n=R.ghost.paint(rig,geometry,visual,changed,HELD_OWN);this.stats.ghostPaints+=n;
    if(n)for(const [mesh,rec] of R.filters)if(rec.kind==='wing'){const key=rig.layerRecords.find(l=>l.mesh===mesh)?.key,tx=key&&R.ghost.layers[key]?.texture;if(tx)rec.filter.ghostTexture=tx;}
  }

  /* ---------------- the ticker (sweeps, drains, flickers only) ---------------- */
  wake(R){if(R)R.awake=true;this.ensureTicker();}
  ensureTicker(){if(this.ticking)return;const ticker=globalThis.canvas?.app?.ticker;if(!ticker)return;this.ticking=true;ticker.add(this.tick,this,-9);}
  stopTicker(){if(!this.ticking)return;this.ticking=false;globalThis.canvas?.app?.ticker?.remove(this.tick,this);}
  tick(){
    this.frame++;this.stats.ticks++;const now=this.now();let any=false;
    for(const R of this.records.values()){
      if(!R.awake)continue;
      try{
        if(!this.current(R.token)){this.drop(R);continue;}
        const ph=this.evaluate(R,now);this.apply(R,ph,now);
        R.awake=ph==='sweep'||ph==='flicker'||ph==='drain'||R.linger>0||(R.veil==='held'&&!R.veilOk&&R.veilTries<120);
        any||=R.awake;
      }catch(error){console.error('Yvaelle’s Toolbox | v11 invisibility',error);this.stats.errors=(this.stats.errors??0)+1;this.lastError=String(error?.stack??error).slice(0,400);const tk=R.token,n=(this.failed.get(tk)??0)+1;this.failed.set(tk,n);this.drop(R);
        // (test.22) one bad frame no longer leaves her without a record: it is made again (at most three times a token, so a fault that repeats cannot loop)
        if(n<=3)queueMicrotask(()=>{try{if(this.current(tk))this.sync(tk);}catch{}});}
    }
    if(!any)this.stopTicker();
  }
  /** Bring her pieces in line with the moment. */
  apply(R,ph,now){
    const prev=R.applied,active=ph==='sweep'||ph==='flicker';
    if(active){
      if(prev!=='sweep'&&prev!=='flicker'){
        if(ph==='sweep')this.stats.sweeps++;
        // ghost first (held now: her layers already show it), filters next, then her pieces turn solid underneath
        const rig=this.rigOf(R);if(rig&&threadGhost(R.view)){if(R.ghostRig!==rig){R.ghost?.destroy();R.ghost=new GhostWings();R.ghostRig=rig;}
          if(prev==='held')R.ghost.copy(rig);else rig.signature=null;}   // (a repaint on this thread paints the ghost too)
        this.writeState(R,ph,now);this.attachAll(R);
        this.setVeil(R,'none');
      }
      this.writeState(R,ph,now);
      if((this.frame-R.meshCheck)>=15)this.attachAll(R);
      R.linger=0;R.heldPainted=false;
      this.redraw();
    }else if(ph==='held'){
      if(prev!=='held'){
        // fully behind the front: a static state block (nothing moves it now)
        R.state.s1[1]=CLOAK.over*4;R.state.s2[1]=VARIANT_INDEX.c;R.family=0;R.state.s2[3]=0;R.state.s3.fill(0);R.state.s2[0]=keepsGhost(R.view)?1:0;
        // (test.7) only the thread ghost waits for her rig to repaint its wings drained (the wing filters linger until then);
        // Faint and Gone hand every piece straight to plain alpha, and the compact bits now carry the veil themselves
        const thread=threadGhost(R.view);
        this.setVeil(R,'held');R.heldPainted=false;R.linger=R.filters.size&&thread?LINGER_FRAMES:0;
        this.detachKinds(R,k=>!(k==='wing'&&thread)&&!(k==='token'&&!R.veilOk));
        if(!thread){R.ghost?.destroy();R.ghost=null;R.ghostRig=null;}
      }
      if(R.veil==='held'&&!R.veilOk)this.setVeil(R,'held');
      if(R.linger>0){R.linger--;if(R.heldPainted||!this.rigOf(R)||R.linger===0){this.detachKinds(R,k=>k==='wing');R.linger=0;R.ghost?.destroy();R.ghost=null;R.ghostRig=null;}}
    }else{
      if(prev==='sweep'||prev==='flicker'||prev==='held'){this.detachAll(R);R.ghost?.destroy();R.ghost=null;R.ghostRig=null;}
      if(ph==='solid'&&R.veil==='held')this.setVeil(R,'none');
      R.linger=0;
    }
    R.applied=ph;
  }
  /** Her portrait's hidden look: the token layer holds it; without a token layer (or its Hidden part)
   * a static cloak filter on her token does (no ticker: nothing in it moves). */
  setVeil(R,state){
    const tl=this.tokenLayers;
    if(state==='held'){
      if(R.veil!=='held')R.veilTries=0;R.veil='held';R.veilTries=(R.veilTries??0)+1;
      R.veilOk=!!(tl?.canVeil?.(R.token)&&tl.veil(R.token,'held'));
      const m=R.token.mesh,rec=m&&R.filters.get(m);
      if(R.veilOk){if(rec)this.detachMesh(R,m,rec);}
      else if(!rec){R.state.s2[0]=keepsGhost(R.view)?1:0;this.attachMesh(R,m,'token');}
    }
    else{if(R.veil==='held'||R.veil==='anim')tl?.veil?.(R.token,'none');R.veil='none';R.veilOk=false;}
  }
  rigOf(R){return this.manager?.states?.get(R.token)?.renderer?.rig??null;}
  /** Her meshes: token, wing layers, bits, shadows (the renderer's own list). */
  herMeshes(R,out){
    out.length=0;const tk=R.token;if(tk.mesh&&!tk.mesh.destroyed)out.push(tk.mesh,'token');
    const r=this.manager?.states?.get(tk)?.renderer;if(!r)return out;
    try{for(const [name,mesh] of r.previewMeshes?.()??[]){if(!mesh||mesh.destroyed)continue;
      out.push(mesh,name.startsWith('rig.bit')?'bits':name.startsWith('rig.')?'wing':name.startsWith('compact.')?'compact':name==='shadow'?'shadow':'plain');}}catch{}
    if(r.wingShadow&&!r.wingShadow.destroyed)out.push(r.wingShadow,'shadow');
    return out;
  }
  filterOf(R,mesh){return mesh?R.filters.get(mesh)?.filter??null:null;}
  attachAll(R){
    R.meshCheck=this.frame;if(R.token.visible===false)return;
    const list=this.herMeshes(R,R.meshes);
    for(let i=0;i<list.length;i+=2)this.attachMesh(R,list[i],list[i+1]);
    this.measure(R,true);
  }
  attachMesh(R,mesh,kind){
    if(!mesh||mesh.destroyed)return;
    let rec=R.filters.get(mesh);
    const thread=threadGhost(R.view);
    // (11.0.0) the look's program: A, B and C in one, the nine newer looks in another (a filter of the other one is replaced)
    const family=R.family??0;
    if(rec&&rec.filter.family!==family){this.detachMesh(R,mesh,rec);rec=null;}
    if(!rec){const F=cloakFilterClass(),k=kind==='token'?'token':kind==='wing'?'wing':'plain';
      const filter=new F(R.state,k,{ghost:filterGhost(R.view,kind),gain:LIGHT_GAIN[kind]??.5,family});filter.mesh=mesh;
      rec={filter,kind};R.filters.set(mesh,rec);R.fkN=-1;this.stats.filterAttach++;}
    const f=rec.filter,K=f.uniforms?.uKind;
    // (test.7) the ghost behind the front follows the owner view: a wing layer samples the thread ghost only for Threads;
    // Faint shows her own pixels at her token's ghost strength (exactly the alpha she is held at after the sweep)
    if(K&&rec.kind!=='token'){K[0]=rec.kind==='wing'&&thread?1:0;K[1]=filterGhost(R.view,rec.kind);}
    if(rec.kind==='wing'&&thread){const key=[...(this.rigOf(R)?.layerRecords??[])].find(l=>l.mesh===mesh)?.key;f.ghostTexture=key&&R.ghost?.layers[key]?.texture||PIXI.Texture.EMPTY;}
    if(rec.kind==='token'){let fs=null;try{const tl=this.tokenLayers?.layerOf?.(R.token);fs=tl?.frames?.ready?tl.frames:null;}catch{}f.outline=fs?.outline??null;
      // (test.8) frame off: the ghost's thin ring is the edge of her own token art (cached per texture)
      f.rim=f.outline?null:rimTextureOf(mesh.texture??null,undefined,this.tokenLayers?.layerOf?.(R.token)?.fit??(hasFoundryRing(R.token)?{mode:'auto',ring:true}:null))?.texture??null;}
    const list=mesh.filters;
    if(!list||list[list.length-1]!==f)mesh.filters=list?.length?[...list.filter(x=>x!==f),f]:[f];
  }
  detachKinds(R,pick){for(const [mesh,rec] of [...R.filters])if(pick(rec.kind))this.detachMesh(R,mesh,rec);}
  detachAll(R){for(const [mesh,rec] of [...R.filters])this.detachMesh(R,mesh,rec);}
  detachMesh(R,mesh,rec){
    if(mesh&&!mesh.destroyed&&mesh.filters?.includes(rec.filter)){const rest=mesh.filters.filter(f=>f!==rec.filter);mesh.filters=rest.length?rest:null;}
    rec.filter.destroy?.();R.filters.delete(mesh);R.fkN=-1;
  }
  /** Her extent along the sweep, from her real meshes' bounds (four times a second). */
  measure(R,force=false){
    const t=this.frame;if(!force&&t-R.eAt<40)return;R.eAt=t;
    const tk=R.token,s=R.state,rects=this.rects,own=this.ownRect??=[null];rects.length=0;own[0]=null;
    for(const [mesh,rec] of R.filters){if(!mesh.visible||mesh.destroyed||mesh.alpha<=0)continue;try{const b=mesh.getBounds?.(true);if(b&&b.width>0){const r=rec.kind==='token'?this.artRect(R,mesh,b):b;rects.push(r);if(rec.kind==='token')own[0]=r;}}catch{}}
    const Z=s.s1[3]||1,dir=DIRECTIONS[dirOf(R.flag?.dir)]??DIRECTIONS.left;
    const fallback=Math.max(tk.w??100,tk.h??100)*.5*Z;
    R.E=extentAlong(rects,s.s0[0],s.s0[1],s.s0[2],dir.dirA,fallback)*.9;
    // (12.0.0-beta.12) her token's own half extent along the sweep: the first three looks' front must clear it (invis.mjs runOut)
    R.Et=own[0]?extentAlong(own,s.s0[0],s.s0[1],s.s0[2],dir.dirA,0):0;
  }
  /** (test.9) Her token's real art on screen: its measured box inside the picture (v11/token-shape.mjs), through her
   * mesh's transform (turned, mirrored, scaled). A picture with a transparent margin no longer stretches the sweep. */
  artRect(R,mesh,b){
    const pr=rimTextureOf(mesh.texture??null,undefined,this.tokenLayers?.layerOf?.(R.token)?.fit??null)?.profile,B=pr?.bounds;
    if(!B||!(B.w>0)||(B.w>.94&&B.h>.94))return b;
    const wt=mesh.worldTransform,tex=mesh.texture,w=tex?.orig?.width??tex?.width??1,h=tex?.orig?.height??tex?.height??1,ax=mesh.anchor?.x??.5,ay=mesh.anchor?.y??.5;
    let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
    for(let k=0;k<4;k++){const lx=((k&1?B.x+B.w:B.x)-ax)*w,ly=((k&2?B.y+B.h:B.y)-ay)*h,X=wt.a*lx+wt.c*ly+wt.tx,Y=wt.b*lx+wt.d*ly+wt.ty;if(X<x0)x0=X;if(X>x1)x1=X;if(Y<y0)y0=Y;if(Y>y1)y1=Y;}
    const r=R.art??={x:0,y:0,width:0,height:0};r.x=x0;r.y=y0;r.width=x1-x0;r.height=y1-y0;return r;
  }
  /** The shared state for this frame: centre, bank, direction, extent, front, time, view, flicker. */
  writeState(R,ph,now){
    const s=R.state,tk=R.token,m=tk.mesh,f=R.flag,dir=DIRECTIONS[dirOf(f?.dir)]??DIRECTIONS.left,t=now/1000;
    if(m&&!m.destroyed){const wt=m.worldTransform,tex=m.texture,w=tex?.orig?.width??tex?.width??1,h=tex?.orig?.height??tex?.height??1,ax=m.anchor?.x??.5,ay=m.anchor?.y??.5,lx=(.5-ax)*w,ly=(.5-ay)*h;
      s.s0[0]=wt.a*lx+wt.c*ly+wt.tx;s.s0[1]=wt.b*lx+wt.d*ly+wt.ty;s.s0[2]=Math.atan2(wt.b,wt.a)-(Number(m.rotation)||0);
      const p=m.parent?.worldTransform;s.s1[3]=p?Math.hypot(p.a,p.b)||1:1;}
    s.s0[3]=dir.dirA;s.s2[2]=dir.tilt;s.s1[2]=t%3600;s.s2[0]=keepsGhost(R.view)?1:0;
    this.measure(R);s.s1[0]=R.E;
    const FL=FLICKER;s.s4[0]=FL.shift;s.s4[1]=FL.split;s.s4[2]=FL.zone;s.s4[3]=FL.rate;s.s5[0]=FL.bright;
    R.family=familyOf(VARIANT_INDEX[f?.variant]??2);   // (the flicker runs in her look's own program)
    if(ph==='sweep'){const vi=VARIANT_INDEX[f.variant]??2;s.s1[1]=R.fr.f*runOut(vi,R.E,R.Et,s.s1[3]);s.s2[1]=vi;s.s2[3]=0;s.s3.fill(0);}
    else{
      // the flicker: fully behind the front, her solid self shown at k
      const q=(now-R.fl.at)/1000,fl=flickerAt(q,R.fl.sev),P=R.flickerParts??partsOf('invisFlicker',R.doc),glimpse=!!P.invisFlickerOthers,detail=flickerDetail(R.view,glimpse)*(this.reduced()?0:1);
      const k=P.flickerWaver!==false?flickerSolid(R.view,fl,glimpse):0,Z=s.s1[3];
      s.s1[1]=CLOAK.over*4;s.s2[1]=3;s.s2[3]=k;
      s.s3[0]=P.flickerSlip!==false?slipAt(q,fl*detail):0;s.s3[1]=P.flickerFringe!==false?fringeAt(q,fl*detail):0;
      s.s3[2]=P.flickerTremor!==false?tremorAt(t,fl*detail)*Z:0;s.s3[3]=0;s.s5[2]=Math.floor(q*24);s.s5[3]=k+(keepsGhost(R.view)?.2:0);
    }
  }
  redraw(){const p=globalThis.canvas?.primary;if(p&&'renderDirty' in p)p.renderDirty=true;}

  /* ---------------- entry points ---------------- */
  /** The manual Fade. The quick wheel calls fade(on, {token}) (on a boolean, token a Token placeable);
   * fade(on) uses her controlled token; fade(token, on) also works. on undefined: toggle. */
  async fade(a,b){
    let token=null,on;
    if(typeof a==='boolean'||a===undefined||a===null){on=a??undefined;token=b&&typeof b==='object'&&'token' in b&&!b.document?b.token:b??null;}else{token=a;on=b;}
    token=token?.object??token??this.herToken();const R=this.recordFor(token);if(!R)return false;
    const doc=R.doc;if(!doc.isOwner&&!globalThis.game?.user?.isGM)return false;
    const fade=on===undefined?!R.flag?.fade:!!on,now=this.now(),src=activeSource({...R.sources,fade});let look=lookFor(src,this.choices(doc));
    const synced=!!src&&(isCloak(look)||src==='fade');
    // (12.0.0-beta.5) Cloak depth › a different look each time: her Fade steps on from the look it wore last
    if(fade&&src==='fade'&&!R.flag?.on&&look!=='none'&&isOn('invisLooks',doc)&&partOn('cloakDepth','cloakRotate',doc))look=isCloak(R.flag?.variant)?nextLook(R.flag.variant):isCloak(look)?look:'c';
    let flag;
    if(synced)flag=R.flag?.on?{...R.flag,fade}:{...nextFlag(R.flag,true,now,{dir:choice('invisSweep',doc),variant:look==='none'?'classic':look,src,T:this.speed(doc)}),fade};
    else flag=R.flag?.on?{...nextFlag(R.flag,false,now),fade}:{...(R.flag??{on:false,start:now-CLOAK.sweep*1000-1,dir:dirOf(choice('invisSweep',doc)),variant:'c',src:'fade'}),fade};
    R.src=src;R.look=look;this.writeFlag(R,flag);return true;
  }
  /** Is her manual Fade on? (the quick wheel's label and state; read from the synced flag, so it is right
   * after a reload or when another of her owners faded her). */
  faded(target){
    const token=target?.object??target??this.herToken();const R=this.recordOf(token);
    if(R)return !!R.flag?.fade;
    const doc=token?.document??token;try{return !!doc?.getFlag?.(ID,CLOAK_FLAG)?.fade;}catch{return false;}
  }
  /** A cloak played directly (api.v11.tokenLayer.cloak): look a|b|c|classic, sweep left|right|top|bottom. */
  cloak(target,on,{look=null,sweep=null,T=null}={}){
    const R=this.recordFor(target);if(!R)return false;const doc=R.doc;if(!doc.isOwner&&!globalThis.game?.user?.isGM)return false;
    // (12.0.0-beta.5) T: this sweep's own length (a cloak warp is short); else her speed going on, and the way it went coming off
    const variant=look??lookFor('fade',this.choices(doc)),flag={...nextFlag(R.flag,!!on,this.now(),{dir:sweep??choice('invisSweep',doc),variant:variant==='none'?'classic':variant,src:'fade',T:T??(on?this.speed(doc):null)}),fade:!!on};
    this.writeFlag(R,flag);return true;
  }
  /** (12.0.0-beta.5) Cloak depth › an attack breaks her Fade: her own attack roll while she is faded brings her back at once,
   * a quick sweep and a flare of her wings. Only the manual Fade (a spell's invisibility is the rules' business, not this
   * module's), only a roll everyone can see (a secret roll must not give itself away), and one client writes it. */
  noteAttack(message){
    const ctx=message?.flags?.pf2e?.context;if(!ctx||!['attack-roll','spell-attack-roll'].includes(ctx.type))return false;
    if(message.blind||message.whisper?.length||message.visible===false)return false;
    const token=globalThis.canvas?.tokens?.get?.(message.speaker?.token),R=token?this.recordOf(token):null;if(!R)return false;
    const f=R.flag;if(!f?.on||!f.fade)return false;
    if(!partOn('cloakDepth','cloakAttack',R.doc))return false;
    if((!R.doc.isOwner&&!globalThis.game?.user?.isGM)||!this.isWriter(R.doc))return false;
    this.writeFlag(R,{...nextFlag(f,false,this.now(),{T:CLOAK_QUICK.flourish}),fade:false});this.stats.flourishes=(this.stats.flourishes??0)+1;
    try{const api=globalThis.game?.modules?.get?.('filament-flight')?.api;if(api?.getState?.(token)?.enabled)Promise.resolve(api.flare?.(token,{strength:.8})).catch(()=>{});}catch{}
    return true;
  }
  herToken(){
    const ok=t=>{try{return !!t?.document?.getFlag?.(ID,'flight')&&t.document.isOwner;}catch{return false;}};
    return (globalThis.canvas?.tokens?.controlled??[]).find(ok)??[...this.records.keys()].find(ok)??null;
  }
  /** What the runtime is doing (for tests and the perf harness). */
  status(target){const R=this.recordOf(target);if(!R)return null;const now=this.now();this.evaluate(R,now);
    return {source:R.src,look:R.look,phase:R.ph,view:R.view,front:R.fr.f,flag:R.flag?{...R.flag}:null,filters:R.filters.size,veil:R.veil,pixels:0};}

  /* ---------------- hooks ---------------- */
  install(){
    if(this.installed||!globalThis.Hooks)return;this.installed=true;
    invisHooks.drain=(t,n)=>this.drainFor(t,n);invisHooks.through=t=>this.throughFor(t);invisHooks.alpha=(t,k)=>this.alphaFor(t,k);
    invisHooks.mainThread=t=>this.mainThreadFor(t);invisHooks.painted=(r,g,v,c)=>this.painted(r,g,v,c);
    Hooks.on('canvasReady',()=>{for(const R of [...this.records.values()])this.drop(R);this.syncAll();});
    Hooks.on('canvasTearDown',()=>{for(const R of [...this.records.values()])this.drop(R);this.stopTicker();});
    // (12.0.0-beta.5) Cloak depth: her own attack while she is faded (nothing happens unless that part is on)
    Hooks.on('createChatMessage',m=>{try{this.noteAttack(m);}catch(error){console.warn('Yvaelle’s Toolbox | v11 cloak flourish',error);}});
    Hooks.on('drawToken',token=>queueMicrotask(()=>this.sync(token)));
    Hooks.on('refreshToken',token=>{const R=this.records.get(token);if(!R)return;if(R.filters.size)this.wake(R);if(R.veil==='held'&&!R.veilOk)this.wake(R);});
    Hooks.on('updateToken',(doc,changes)=>{const token=doc.object;if(!token)return;const fl=changes?.flags?.[ID];
      if(fl!==undefined&&(CLOAK_FLAG in fl||`-=${CLOAK_FLAG}` in fl||'flight' in fl||'v11' in fl))this.sync(token);});
    Hooks.on('deleteToken',doc=>{const R=doc.object&&this.records.get(doc.object);if(R)this.drop(R);});
    const actorChanged=actor=>{for(const R of this.records.values())if(R.doc.actor===actor||R.doc.actorId===actor?.id)this.read(R,false);};
    Hooks.on('updateActor',actor=>actorChanged(actor));
    for(const hook of ['createItem','updateItem','deleteItem'])Hooks.on(hook,item=>{if(['condition','effect'].includes(item?.type))actorChanged(item.parent);});
    for(const hook of ['createActiveEffect','updateActiveEffect','deleteActiveEffect'])Hooks.on(hook,effect=>actorChanged(effect?.parent));
    Hooks.on('filamentFlightSettingsChanged',()=>{for(const R of this.records.values())this.read(R,false);});
  }
  destroy(){for(const R of [...this.records.values()])this.drop(R);this.stopTicker();for(const k of Object.keys(invisHooks))invisHooks[k]=null;}
}
const unit=x=>x<0?0:x>1?1:x,sm=x=>{x=unit(x);return x*x*(3-2*x);};
/** Her bits as a group (mean station .62 of the way out). */
const smoothBit=F=>sm((F-.625)/.18),smoothBitR=F=>sm((F-.575)/.2);
