/** Yvaelle’s Toolbox v11 · her wings and the world (Foundry glue).
 *
 * Four features, each its own switch in features.mjs (Settings › Flight › World):
 *  - Wall fold (wallFold): a wing near a wall folds in; both fold in corridors
 *    and doorways; they reopen gracefully. Ray casts from her centre against
 *    the walls near her (the walls quadtree), only when she reaches a new
 *    position (a fifth of a square) or heading (7.5°) or a wall or door changes;
 *    cached per position and per position + heading; at most two new casts a
 *    frame (spread over frames); one spring per wing root and tip.
 *  - Light catch (lightCatch): her wings borrow the colour of the lights near
 *    her (canvas.effects.lightSources: colour, radius, animation), refreshed on
 *    lightingRefresh and when she moves; quantised, so a repaint only follows a
 *    visible step. Painted through the rig's palette hook (world-paint.mjs).
 *  - Wing shadow on tokens (wingShadowTokens): where her flying wing shadow lies
 *    across a token, a masked copy of it lies on the token (a little nearer her
 *    and crisper, as on a standing figure). Overlaps are only re-checked when she
 *    or a token moves; each copy repaints at most 12 times a second while it shows.
 * Zero idle cost: nothing runs for a token with every feature off, nothing per
 * frame while she stands still with nothing to fold and no light near. No document writes, no perception, nothing on her token's transform. */
import {isOn} from './features.mjs?v=13.0.3';
import {fxAlpha,tokenSeen} from './fx-visibility.mjs?v=13.0.3';
import {veilAlphaOf} from './invis-hooks.mjs?v=13.0.3';
import {WallFold,foldFeel,wallBlocksWings,lightReach,sampleLight,lightPalette,LIGHT_BINS,
  shadowOverlap,shadowOnFigure,ENVELOPE_MAX} from './world.mjs?v=13.0.3';

const ID='filament-flight';
const perfNow=()=>globalThis.performance?.now?.()??Date.now();
const FLAME=new Set(['torch','flame','fire','candle','fairy']),PULSE=new Set(['pulse','sunburst','energy','witchwave','ghost','siren']);
const SHADOW_FPS=12,MAX_COPIES=4;
/** A light step's key (world.mjs quantiseLight) → its palette. */
const PAL_BY_KEY=new Map();

/** visual.v11Light: plain data for the painter (and the worker); its frame signature is just its small sig. */
class CaughtLight{constructor(bins,fl,flick,sig){this.bins=bins;this.fl=fl;this.flick=flick;this.sig=sig;}toJSON(){return this.sig;}}
/** Her record: the switches and each feature's state. */
class Record{
  constructor(doc){this.doc=doc;this.fold=null;this.light=null;this.copies=null;this.feelMem={};this.readParts();}
  readParts(){const d=this.doc;this.on={fold:isOn('wallFold',d),light:isOn('lightCatch',d),shadow:isOn('wingShadowTokens',d)};
    if(!this.on.fold)this.fold=null;if(!this.on.light)this.light=null;}
}

export class WorldRuntime{
  constructor({clock=perfNow}={}){
    this.clock=clock;this.profile=false;this.records=new Map();this.getState=()=>null;this.installed=false;
    this.wallsRev=0;this.lightsRev=0;this.lightsDirty=true;this.tokensRev=0;
    this.lights=[];this.lightCount=0;this.lightSig=NaN;
    this.stats={foldMs:0,lightMs:0,shadowMs:0,calls:0,casts:0,decisions:0,lightSamples:0,lightRebuilds:0,shadowChecks:0,shadowPaints:0,maxMs:0};
    this.query=this.query.bind(this);
    this.shadowImg=null;
  }
  recordOf(token,create=true){
    const doc=token?.document??token;if(!doc?.id)return null;
    let r=this.records.get(doc.id);if(r&&r.doc!==doc){r.doc=doc;r.readParts();}
    if(!r&&create){r=new Record(doc);this.records.set(doc.id,r);}
    return r??null;
  }
  /* ------------------------------------------------------------------ */
  /* Walls                                                                */
  /* ------------------------------------------------------------------ */
  /** The solid walls inside a box, flat into out ([ax,ay,bx,by,…]); returns the
   * count, or minus the count when out is too small (the caller grows it). */
  query(x0,y0,x1,y1,out){
    const layer=globalThis.canvas?.walls;if(!layer)return 0;
    let set=null;
    try{const q=layer.quadtree;if(q?.getObjects){const R=globalThis.PIXI?.Rectangle;set=q.getObjects(R?new R(x0,y0,x1-x0,y1-y0):{x:x0,y:y0,width:x1-x0,height:y1-y0});}}catch{set=null;}
    set??=layer.placeables??[];
    let n=0,over=false;
    for(const w of set){
      const d=w.document??w;if(!wallBlocksWings(d))continue;const c=d.c;if(!c)continue;
      if(Math.max(c[0],c[2])<x0||Math.min(c[0],c[2])>x1||Math.max(c[1],c[3])<y0||Math.min(c[1],c[3])>y1)continue;
      if(n*4+4>out.length){over=true;n++;continue;}
      const o=n*4;out[o]=c[0];out[o+1]=c[1];out[o+2]=c[2];out[o+3]=c[3];n++;
    }
    return over?-n:n;
  }
  wallsChanged(){this.wallsRev++;for(const r of this.records.values())r.fold?.clear();}

  /* ------------------------------------------------------------------ */
  /* Lights                                                               */
  /* ------------------------------------------------------------------ */
  /** Rebuild the compact light list (pooled; a new revision only when something changed). */
  readLights(){
    this.lightsDirty=false;
    const C=globalThis.canvas,src=C?.effects?.lightSources;let n=0,sig=0;
    const grid=C?.grid?.size??100,far=grid*60;
    if(src)for(const s of src.values?.()??src){
      try{
        if(!s||s.active===false||s.data?.disabled||s.isPreview)continue;
        const id=s.sourceId??'';if(id==='globalLight'||/global/i.test(s.constructor?.name??''))continue;
        const d=s.data??s,x=Number(d.x),y=Number(d.y);if(!Number.isFinite(x)||!Number.isFinite(y))continue;
        if((d.luminosity??.5)<0)continue;
        const dim=Number(s.radius??d.dim??d.radius)||0,bright=Number(d.bright)||0;if(dim<=0&&bright<=0)continue;
        const reach=lightReach(dim,bright);if(reach>far)continue;
        const raw=d.color,num=raw==null||raw===''?NaN:Number(raw);
        let r=255,g=236,b=210,w=.35;
        if(Number.isFinite(num)&&num>=0){r=(num>>16)&255;g=(num>>8)&255;b=num&255;const a=Number(d.alpha??.5);w=Math.max(.4,Math.min(1,a*2));}
        const at=d.animation?.type??null,inten=Number(d.animation?.intensity??5)/5;
        const anim=at&&FLAME.has(at)?Math.min(1.5,inten):at&&PULSE.has(at)?.5*Math.min(1.5,inten):0;
        const L=this.lights[n]??={};
        L.x=x;L.y=y;L.reach=reach;L.r=r;L.g=g;L.b=b;L.w=w;L.anim=anim;L.object=s.object??null;L.id=id;n++;
        sig=(sig*31+x*7+y*13+reach*3+r+g*5+b*11+w*97+anim*53)%1e9;
      }catch{}
    }
    this.lightCount=n;sig+=n*1e9;
    if(sig!==this.lightSig){this.lightSig=sig;this.lightsRev++;this.stats.lightRebuilds++;}
  }
  /** The lights near her wing frame, excluding her own (into r.light.near). */
  lightFrame(r,token,T){
    const doc=token.document,L=r.light??={keys:new Float64Array(LIGHT_BINS),vals:new Float64Array(LIGHT_BINS*5),near:[],rev:-1,x:NaN,y:NaN,a:NaN,w:NaN,visual:null,sig:0};
    if(this.lightsDirty)this.readLights();
    const moved=Math.abs(T.x-L.x)>12||Math.abs(T.y-L.y)>12||Math.abs(T.angle-L.a)>.08||Math.abs(T.width-L.w)>T.width*.02;
    if(!moved&&L.rev===this.lightsRev)return L.visual;
    L.x=T.x;L.y=T.y;L.a=T.angle;L.w=T.width;L.rev=this.lightsRev;
    const span=Math.max(T.width,T.height)*.6;let m=0;
    for(let i=0;i<this.lightCount;i++){const l=this.lights[i];
      if(l.object===token||l.object?.document===doc||(doc?.id&&l.id.includes(doc.id)))continue;
      const R=l.reach*3+span;if(Math.abs(l.x-T.x)>R||Math.abs(l.y-T.y)>R)continue;L.near[m++]=l;}
    L.near.length=m;
    if(!m){L.visual=null;return null;}
    const C=globalThis.canvas,darkness=Number(C?.environment?.darknessLevel??C?.darknessLevel??0)||0,dark=.45+.55*Math.max(0,Math.min(1,darkness));
    const keys=L.keys,prev=L.prevKeys??=new Float64Array(LIGHT_BINS);prev.set(keys);
    const lit=sampleLight(L.near,m,{x:T.x,y:T.y,angle:T.angle,sx:T.width/600,sy:T.height/600},dark,keys,L.vals);this.stats.lightSamples++;
    if(!lit){L.visual=null;return null;}
    let same=!!L.visual;for(let b=0;b<LIGHT_BINS&&same;b++)if(keys[b]!==prev[b])same=false;
    if(same)return L.visual;
    const bins=new Array(LIGHT_BINS),fl=new Float32Array(LIGHT_BINS);let flick=false,h=0;
    for(let b=0;b<LIGHT_BINS;b++){const v=L.vals,o=b*5;if(!keys[b]){bins[b]=null;continue;}
      let pal=PAL_BY_KEY.get(keys[b]);if(!pal){pal=lightPalette(v[o],v[o+1],v[o+2],v[o+3]);if(PAL_BY_KEY.size>2048)PAL_BY_KEY.clear();PAL_BY_KEY.set(keys[b],pal);}bins[b]=pal;fl[b]=v[o+4];if(v[o+4]>0)flick=true;h=(h*131+keys[b])%999983;}
    L.sig=((h%997)+1)*1e-9;
    return L.visual=new CaughtLight(bins,fl,flick,L.sig);
  }

  /* ------------------------------------------------------------------ */
  /* The wing rig (pose-renderer, each painted frame)                     */
  /* ------------------------------------------------------------------ */
  /** Her visual profile with this frame's fold and caught light (or untouched: zero idle cost). */
  wingVisual(token,visual,s,T,config,now=this.clock()){
    const r=this.records.get(token?.document?.id)??(token?.document?.getFlag?.(ID,'flight')?this.recordOf(token):null);
    if(!r||!(r.on.fold||r.on.light))return visual;
    // (timed only while a harness profiles it: the clock itself allocates)
    const t0=this.profile?perfNow():0;let fold=null,light=null;
    try{
      if(r.on.fold){
        const F=r.fold??=new WallFold();
        const grid=globalThis.canvas?.grid?.size??100,c0=F.stats.casts,d0=F.stats.decisions;
        const f0=this.profile?perfNow():0;F.stepFrame(T,grid,now,this.query,!!config?.reduced,s?.source?.x??T.x,s?.source?.y??T.y);if(this.profile)this.stats.stepMs=(this.stats.stepMs??0)+perfNow()-f0;
        this.stats.casts+=F.stats.casts-c0;this.stats.decisions+=F.stats.decisions-d0;
        if(F.shows){const p=F.pair,key=Math.round(p[0][0]*40)*68921+Math.round(p[0][1]*40)*1681+Math.round(p[1][0]*40)*41+Math.round(p[1][1]*40)+1;
          if(r.foldKey!==key){r.foldKey=key;r.foldVis={l:[p[0][0],p[0][1]],r:[p[1][0],p[1][1]],key};}fold=r.foldVis;}
        else r.foldKey=0;
      }
      if(r.on.light){const l0=this.profile?perfNow():0;light=this.lightFrame(r,token,T);if(this.profile){const d=perfNow()-l0;this.stats.lightMs+=d;if(d>(this.stats.lightMax??0))this.stats.lightMax=d;}}
    }catch(e){if(!this.warned){this.warned=true;console.warn('Yvaelle’s Toolbox | v11 world',e);}}
    this.stats.calls++;if(this.profile){const ms=perfNow()-t0;this.stats.foldMs+=ms;if(ms>this.stats.maxMs)this.stats.maxMs=ms;}
    if(!fold&&!light)return visual;
    // one merged profile per change (the same object while nothing changed)
    // (an emote's profile is one object rewritten every frame: never reuse a merge made from it)
    const m=r.merged;if(m&&m.in===visual&&!visual.v11emo&&m.fold===fold&&m.light===light)return m.out;
    const m0=this.profile?perfNow():0;const out={...visual};if(fold)out.v11Fold=fold;if(light)out.v11Light=light;
    r.merged={in:visual,fold,light,out};if(this.profile){this.stats.mergeMs=(this.stats.mergeMs??0)+perfNow()-m0;this.stats.merges=(this.stats.merges??0)+1;}return out;
  }

  /* ------------------------------------------------------------------ */
  /* The flight feel (flight-feel-runtime, before composeFeel)            */
  /* ------------------------------------------------------------------ */
  feel(token,out,s,{dt=1/60,reduced=false}={}){
    const r=this.records.get(token?.document?.id);if(!r)return;
    const t0=this.profile?perfNow():0;
    try{
      // wall fold: fewer, shallower beats while held in, a roll away from the wall, a heavier first stroke as they open
      const F=r.fold;
      if(F&&(F.shows||(r.feelMem.openK??0)>.002)){foldFeel(out,F.left,F.right,reduced?0:F.opening,dt,r.feelMem);s.v11FoldK=(F.left+F.right)/2;}
      else if(s.v11FoldK)s.v11FoldK=0;
    }catch(e){if(!this.warned){this.warned=true;console.warn('Yvaelle’s Toolbox | v11 world',e);}}
    if(this.profile)this.stats.foldMs+=perfNow()-t0;
  }

  /* ------------------------------------------------------------------ */
  /* Wing shadow on tokens (renderer.mjs feelShadow, each frame it shows)  */
  /* ------------------------------------------------------------------ */
  /** shadow: her wing-shadow mesh as placed this frame; make: {EffectMesh, placeBehind, Texture}. */
  shadowOnTokens(token,s,shadow,make){
    const r=this.records.get(token?.document?.id);
    const off=!r||!r.on.shadow||!shadow?.visible||!(shadow.alpha>.004)||!((s.feel?.alt??0)>1)||!((s.feel?.air??0)>.3);
    if(off){if(r?.copies)this.hideCopies(r);return;}
    r.her=token;
    const t0=this.profile?perfNow():0,C=globalThis.canvas;
    try{
      const S=r.shadowCheck??={x:NaN,y:NaN,w:NaN,rev:-1,hits:[]};
      // Overlaps: only when she (her shadow) or a token moved.
      if(S.rev!==this.tokensRev||Math.abs(shadow.x-S.x)>4||Math.abs(shadow.y-S.y)>4||Math.abs(shadow.width-S.w)>8){
        S.x=shadow.x;S.y=shadow.y;S.w=shadow.width;S.rev=this.tokensRev;this.stats.shadowChecks++;
        let n=0;
        for(const t of C?.tokens?.placeables??[]){
          if(t===token||t.document===token.document||t.isPreview||!t.mesh||t.mesh.visible===false||t.visible===false||t.document?.hidden)continue;
          const m=t.mesh,w=t.w??100,h=t.h??100;
          if(shadowOverlap(shadow.x,shadow.y,shadow.width,shadow.height,m.x-w/2,m.y-h/2,w,h)>0&&n<MAX_COPIES)S.hits[n++]=t;
        }
        S.hits.length=n;
      }
      if(!S.hits.length){if(r.copies)this.hideCopies(r);return;}
      const img=this.shadowImage();if(!img)return;
      r.copies??=new Map();
      for(const [t,c] of r.copies)if(!S.hits.includes(t)){c.mesh.visible=false;}
      for(const t of S.hits)this.paintCopy(r,t,s,shadow,img,make);
    }catch(e){if(!this.warned){this.warned=true;console.warn('Yvaelle’s Toolbox | v11 world',e);}}
    if(this.profile)this.stats.shadowMs+=perfNow()-t0;
  }
  shadowImage(){
    if(this.shadowSmall)return this.shadowSmall;
    if(this.shadowImg){const im=this.shadowImg;if(!(im.complete&&im.naturalWidth))return null;
      // once: a 256 px copy (each paint then scales a small picture, not the full-size one)
      try{const c=globalThis.document.createElement('canvas'),k=Math.min(1,256/Math.max(im.naturalWidth,im.naturalHeight));c.width=Math.max(1,Math.round(im.naturalWidth*k));c.height=Math.max(1,Math.round(im.naturalHeight*k));
        c.getContext('2d').drawImage(im,0,0,c.width,c.height);this.shadowSmall=c;}catch{this.shadowSmall=im;}
      return this.shadowSmall;}
    try{const I=globalThis.Image;if(!I)return null;const img=this.shadowImg=new I();
      img.src=globalThis.foundry?.utils?.getRoute?.(`modules/${ID}/assets/flight/shadow-wings.webp`)??`modules/${ID}/assets/flight/shadow-wings.webp`;}catch{}
    return null;
  }
  paintCopy(r,t,s,shadow,img,make){
    let c=r.copies.get(t);const w=Math.ceil(t.w??100),h=Math.ceil(t.h??100);
    if(!c){
      const canvas=globalThis.document.createElement('canvas');canvas.width=w;canvas.height=h;
      const texture=make.Texture.from(canvas);
      const mesh=new make.EffectMesh({name:`${ID}.${t.id}.v11WingShadow`,texture},make.shader);
      mesh.anchor.set(.5);mesh.eventMode='none';mesh.interactive=false;mesh.visible=false;globalThis.canvas.primary.addChild(mesh);
      c={canvas,ctx:canvas.getContext('2d'),texture,mesh,key:NaN,at:-1e9};r.copies.set(t,c);
    }
    const m=t.mesh,feel=s.feel,fig=shadowOnFigure(feel.alt);
    // on the figure: nearer her (up toward her body by the figure's share of her rise) and a little smaller
    const sw=shadow.width*fig.scale,sh=shadow.height*fig.scale,sx=shadow.x,sy=shadow.y-(feel.rise??0)*fig.toward;
    // (test.3) the copy carries no cloak filter: it follows her veil's front (her own shadow's alpha has the rest)
    const alpha=Math.min(fig.max,shadow.alpha*fig.alpha)*veilAlphaOf(r.her,'fx');
    const key=Math.round(sx-m.x)*7919+Math.round(sy-m.y)*104729+Math.round(sw)*31+Math.round(alpha*40);
    const now=perfNow();
    if(key!==c.key&&now-c.at>=1000/SHADOW_FPS){
      c.key=key;c.at=now;this.stats.shadowPaints++;
      const g=c.ctx;if(c.canvas.width!==w||c.canvas.height!==h){c.canvas.width=w;c.canvas.height=h;}
      g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-over';g.globalAlpha=1;g.clearRect(0,0,w,h);
      // the mask: the token's disc (a little inside its edge, softened)
      g.save();g.beginPath();g.ellipse(w/2,h/2,w*.47,h*.47,0,0,Math.PI*2);g.clip();
      g.globalAlpha=alpha;const ix=sx-m.x+w/2-sw/2,iy=sy-m.y+h/2-sh/2;g.drawImage(img,ix,iy,sw,sh);g.drawImage(img,ix,iy,sw,sh);g.restore();
      c.texture.baseTexture?.update?.();
    }
    const mesh=c.mesh;
    if(mesh.x!==m.x||mesh.y!==m.y)mesh.position.set(m.x,m.y);
    if(mesh.width!==w)mesh.width=w;if(mesh.height!==h)mesh.height=h;
    if(mesh.alpha!==1)mesh.alpha=1;if(!mesh.visible)mesh.visible=true;
    // just above that token (its own elevation and sort)
    make.placeBehind(mesh,m,-0.04);
  }
  hideCopies(r){for(const c of r.copies.values())if(c.mesh.visible)c.mesh.visible=false;}
  dropCopies(r){if(!r?.copies)return;for(const c of r.copies.values()){try{c.mesh.parent?.removeChild(c.mesh);c.mesh.destroy?.({children:true,texture:true,baseTexture:true});}catch{}c.canvas.width=c.canvas.height=1;}r.copies=null;}
  /** Her renderer went away (or the feature was switched off). */
  releaseShadows(token){const r=this.records.get(token?.document?.id);if(r)this.dropCopies(r);}

  install({getState=null}={}){
    if(getState)this.getState=getState;
    if(this.installed||!globalThis.Hooks)return;this.installed=true;
    for(const h of ['createWall','updateWall','deleteWall'])Hooks.on(h,()=>this.wallsChanged());
    for(const h of ['lightingRefresh','initializeLightSources','createAmbientLight','updateAmbientLight','deleteAmbientLight'])Hooks.on(h,()=>{this.lightsDirty=true;});
    const moved=()=>{this.tokensRev++;};
    Hooks.on('updateToken',(doc,changes)=>{
      if(changes&&('x' in changes||'y' in changes||'elevation' in changes||'width' in changes||'height' in changes||'hidden' in changes||'movementAction' in changes))moved();
      const r=this.records.get(doc.id);if(r&&changes?.flags?.[ID]!==undefined){r.readParts();if(!r.on.shadow)this.dropCopies(r);}});
    for(const h of ['createToken','deleteToken'])Hooks.on(h,moved);
    // a token's picture moving along its path (its animation): overlaps and partners follow it
    Hooks.on('refreshToken',(t,flags)=>{if(!flags||flags.refreshPosition)moved();});
    Hooks.on('deleteToken',doc=>{const r=this.records.get(doc.id);if(r)this.dropCopies(r);this.records.delete(doc.id);
      // a token her shadow lay on: its copy goes with it
      for(const o of this.records.values())if(o.copies)for(const [t,c] of o.copies)if(t.document===doc||t.document?.id===doc.id){try{c.mesh.parent?.removeChild(c.mesh);c.mesh.destroy?.({children:true,texture:true,baseTexture:true});}catch{}c.canvas.width=c.canvas.height=1;o.copies.delete(t);}});
    Hooks.on('canvasReady',()=>{for(const r of this.records.values())this.dropCopies(r);this.records.clear();this.wallsChanged();this.lightsDirty=true;moved();});
    Hooks.on('canvasTearDown',()=>{for(const r of this.records.values())this.dropCopies(r);this.records.clear();});
    Hooks.on('filamentFlightSettingsChanged',()=>{for(const r of this.records.values()){r.readParts();if(!r.on.shadow)this.dropCopies(r);}});
  }
}
/** The one runtime (flight.mjs installs its hooks). */
export const worldRuntime=new WorldRuntime();
