/** Flight feel in the game (v10 beta.23): reads the inputs the physics needs
 * from Foundry (her flight settings, elevation, combat starts, hits, target)
 * and runs one frame per token for the flight manager. Everything here is
 * local to each screen: other players derive the same motion from the same
 * shared data (token flags, elevation, combat, HP), never from messages. */
import {ID} from './config.mjs?v=13.0.3';
import {damageRuntime} from './v11/damage-runtime.mjs?v=13.0.3';
import {healRuntime} from './v11/heal-runtime.mjs?v=13.0.3';
import {emoteRuntime} from './v11/emote-runtime.mjs?v=13.0.3';
import {worldRuntime} from './v11/world-runtime.mjs?v=13.0.3';
import {forceDelete,deleteKey,isDeletion,deletes} from './forced-delete.mjs?v=13.0.3';
import {createFeel,stepFeel,composeFeel,clearFeel,normalizeFeel,feelBusy,FEEL_WEIGHTS,FEEL_SCALES,WING_SHADOWS,landingDescentTime} from './flight-feel.mjs?v=13.0.3';
import {FlightFx,emitFlightEvents,emitAfterimages,emitModeEffects,ghostImage,liveGhost} from './flight-fx.mjs?v=13.0.3';
import {readBitIntentTarget} from './bit-intent.mjs?v=13.0.3';
import {shieldStyleFeel,shieldStyleOf,rotorHub,trimShieldBits} from './v12/shield-styles.mjs?v=13.0.3';
import {soundFor,noteAsked} from './v12/sound-set.mjs?v=13.0.3';
import {liveBitPositions} from './bit-renderer.mjs?v=13.0.3';
import {blendCharacter,modeAltitude} from './flight-character.mjs?v=13.0.3';

export const FEEL_FLAG='flightFeel',GROUND_FLAG='flightGround',SHIELD_FLAG='wingShield';

/** Wing shield: raised by hand (token flag) or, if allowed, while PF2e's
 * Raise a Shield effect is on her. */
export function raiseShieldEffect(doc){
  try{return doc?.actor?.items?.find?.(i=>i.type==='effect'&&/raise-a-shield/.test(i.slug??i.system?.slug??''))??null;}catch{return null;}
}
export function wingShieldRaised(doc,settings=readFlightFeel(doc)){
  const flag=doc?.getFlag?.(ID,SHIELD_FLAG);
  if(flag===true)return true;
  if(settings.autoShield===false)return false;
  // Lowered by hand while Raise a Shield is on: stays down for that effect only.
  const effect=raiseShieldEffect(doc);
  return !!effect&&flag!==`off:${effect.id}`;
}

/** Versions › Flight feel: the new physics (v10) or the earlier hover. */
let feelSwitch=null;
export function setFlightFeelSwitch(value){feelSwitch=value!=='classic';}
export function flightFeelEnabled(){
  if(feelSwitch!==null)return feelSwitch;
  try{return game.settings.get(ID,'versionFlightFeel')!=='classic';}catch{return true;}
}
/** Cached per saved flag object and its contents: Foundry updates flag
 * objects in place, so the object alone is not enough to know it changed. */
const feelCache=new WeakMap();
export function readFlightFeel(doc){
  const raw=doc?.flags?.[ID]?.[FEEL_FLAG];
  if(raw&&typeof raw==='object'){
    const sig=JSON.stringify(raw);let c=feelCache.get(raw);
    if(!c||c.sig!==sig){c={sig,value:normalizeFeel(raw)};feelCache.set(raw,c);}
    return c.value;
  }
  return normalizeFeel(doc?.getFlag?.(ID,FEEL_FLAG));
}
/** Her height in a flight mode: the chosen height, scaled by the mode when
 * height follows the flight mode (see FLIGHT_CHARACTERS). */
export function flyingHeight(settings,mode){
  return settings.heightByMode&&mode?modeAltitude(settings.altitude,mode):settings.altitude;
}
/** The flight mode she is in or heading for (never the takeoff/landing
 * transition itself, which has no height of its own). */
export function steadyMode(state){
  const m=state?.effective?.mode;
  return m==='takeoff'||m==='landing'?state?.flightProfile?.mode??state?.requested?.mode??'hover':m;
}
/** While airborne at elevation 0 she still hovers a little (feet). */
export const HOVER_LOOK=4;
/** Her height for the flying look (feet). By default (beta.32) this is her
 * token's elevation, which the player sets: the module never writes it. With
 * "Takeoff sets her elevation" on, takeoff raised it by her flying height
 * above the ground she left, so the height is the elevation above that ground
 * (or her saved flying height when no ground was recorded). */
export function feelAltitude(doc,settings=readFlightFeel(doc),mode=null){
  if(!settings.takeoffElevation){
    const e=Number(doc?._source?.elevation??doc?.elevation)||0,ground=Number(doc?.getFlag?.(ID,GROUND_FLAG));
    // (A ground left by an older takeoff that wrote her elevation still counts until she lands.)
    return Math.max(0,Number.isFinite(ground)?e-ground:e);
  }
  // No recorded ground (a classic-mode takeoff, real height turned on mid-flight,
  // after a fall): show her saved flying height rather than raw elevation.
  const ground=Number(doc?.getFlag?.(ID,GROUND_FLAG));
  if(!Number.isFinite(ground))return flyingHeight(settings,mode);
  // (Her saved elevation: where she is headed, even if the game eases it.)
  return Math.max(0,(Number(doc?._source?.elevation??doc?.elevation)||0)-ground);
}
/** How long a landing should last so her wings fold as she touches down
 * ({duration, foldMs} for the saved transition, or nothing): with Flight feel she sinks from her height, which
 * takes longer than the fold itself (beta.29). */
export function landingTiming(doc,state,base){
  if(!flightFeelEnabled()||!(base>0))return {};
  try{
    const settings=readFlightFeel(doc),alt=Math.max(HOVER_LOOK,feelAltitude(doc,settings,steadyMode(state)));
    if(!(alt>1))return {};
    const duration=Math.min(6000,Math.round((landingDescentTime(alt,FEEL_WEIGHTS[settings.weight]??.5)+.15)*1000));
    return duration>base?{duration,foldMs:base}:{};
  }catch{return {};}
}
/** Document changes that put a token back on the ground it took off from
 * (empty when no ground was recorded). Used by every path that grounds her. */
export function groundElevationChanges(doc){
  const ground=Number(doc?.getFlag?.(ID,GROUND_FLAG));
  if(!Number.isFinite(ground)){
    // (beta.35) No recorded ground (the player set her height): landing or
    // putting her wings away brings her down to elevation 0, unless turned off.
    const e=Number(doc?._source?.elevation??doc?.elevation)||0;
    // (Only when she was in the air: standing on a balcony with wings out keeps her height.)
    const flying=doc?.getFlag?.(ID,'flight')?.airborne===true;
    return flying&&e>0&&readFlightFeel(doc).landToGround!==false?{elevation:0}:{};
  }
  return forceDelete({elevation:ground},`flags.${ID}`,GROUND_FLAG);
}

/* ---- combat starts and hits, seen identically on every screen ---- */
const combatStarts=new Map(),hits=new Map(),dodges=new Map(),saves=new Map(),hp=new Map();
// (v11) the emote runtime's per-frame inputs, reused
const EMOTE_CTX={now:0,dt:0,size:100,f:null,unconscious:false,mode:null,hit:null,dodge:null,save:null};
/** A hit, miss or save older than this is not played (her token was off
 * screen or asleep, the tab was in the background): it would come late. */
const FRESH_MS=3000;
const fresh=r=>r&&!(Date.now()-(r.at??Date.now())>FRESH_MS)?r:undefined;
function remember(map,key,record){
  if(map.size>64){const now=Date.now();for(const [k,v] of map)if(now-(v.at??0)>60000)map.delete(k);}
  map.set(key,record);
}
/** Dice So Nice: a reaction waits for the 3D dice to land, so the result is
 * never shown before the roll is (and is dropped if the dice never land). */
const awaitingDice=new Map();
function afterDice(message,apply){
  const dice=globalThis.game?.modules?.get?.('dice-so-nice')?.active&&message?.rolls?.length&&message.id;
  if(!dice){apply();return;}
  // (Dice So Nice marks the messages it animates in its own hook: look once every hook has run.)
  setTimeout(()=>{
    if(!message._dice3danimating){apply();return;}
    const id=message.id;awaitingDice.set(id,apply);
    setTimeout(()=>{if(awaitingDice.get(id)===apply)awaitingDice.delete(id);},15000);
  },0);
}
const strings=list=>Array.isArray(list)?list.filter(o=>typeof o==='string'):list instanceof Set?[...list].filter(o=>typeof o==='string'):[];
/** Was this PF2e attack roll a ranged attack? The roll's own options and
 * domains say so for weapons and spells (a melee marker wins, so reach
 * weapons stay melee); otherwise an attacker more than two squares away is
 * shooting at her. */
export function attackIsRanged(ctx,attacker=null,target=null){
  const options=strings(ctx?.options),domains=strings(ctx?.domains);
  if(options.includes('item:melee')||domains.some(d=>/^melee-(strike-)?attack-roll$/.test(d)))return false;
  if(options.some(o=>o==='item:ranged'||/^item:(range-increment|range|thrown)(:|$)/.test(o))||domains.some(d=>/^(ranged-(strike-)?attack-roll|spell-attack-roll)$/.test(d)))return true;
  if(!attacker?.center||!target?.center)return false;
  const grid=globalThis.canvas?.grid?.size||100;
  return Math.hypot(target.center.x-attacker.center.x,target.center.y-attacker.center.y)/grid>2.5;
}
/** Which saving throw a PF2e check is (fortitude, reflex or will), or null. */
export function saveKindOf(ctx){
  if(ctx?.type!=='saving-throw')return null;
  const kinds=['fortitude','reflex','will'];
  if(kinds.includes(ctx.statistic))return ctx.statistic;
  for(const d of strings(ctx.domains))if(kinds.includes(d))return d;
  for(const o of strings(ctx.options)){const m=/^(?:check:statistic|save|saving-throw):(fortitude|reflex|will)$/.exec(o);if(m)return m[1];}
  return null;
}
const OUTCOMES=['criticalSuccess','success','failure','criticalFailure'];
let hooked=false;
export function installFlightFeelHooks(){
  if(hooked||!globalThis.Hooks)return;hooked=true;
  Hooks.on('updateCombat',(combat,changes)=>{
    // Round 1 starting (from no round) is "combat starts" for its combatants.
    if(!Object.hasOwn(changes??{},'round')||changes.round!==1)return;
    const id=`${combat.id}:${combat.started??''}:${Date.now()}`;
    for(const c of combat.combatants??[])if(c.tokenId)combatStarts.set(c.tokenId,id);
  });
  // PF2e: an attack roll against her that misses is a dodge (a sidestep), or,
  // for a ranged attack, a bit taking the shot. Her saving throws brace her.
  Hooks.on('createChatMessage',message=>{
    try{
      const ctx=message?.flags?.pf2e?.context;if(!ctx)return;
      // A roll this player cannot see (whispered to others, blind) shows
      // nothing here: the motion would give its result away.
      if(message.visible===false||message.isContentVisible===false)return;
      const id=message.id??foundry.utils.randomID(8),kind=saveKindOf(ctx);
      if(kind){
        const speaker=message.speaker??{};
        const ids=speaker.token?[speaker.token]:(globalThis.game?.actors?.get?.(speaker.actor)?.getActiveTokens?.()??[]).map(t=>t.id??t.document?.id);
        // (A save rolled with no DC has no result: the bits simply let go.
        // A reroll changes the result of a brace still holding.)
        const outcome=OUTCOMES.includes(ctx.outcome)?ctx.outcome:'success',reroll=!!ctx.isReroll;
        afterDice(message,()=>{const at=Date.now();for(const tokenId of ids)if(tokenId)remember(saves,tokenId,{id,kind,outcome,reroll,at});});
        return;
      }
      if(ctx.type!=='attack-roll'||!['failure','criticalFailure'].includes(ctx.outcome))return;
      const targetId=String(ctx.target?.token??'').split('.').pop();if(!targetId)return;
      const target=globalThis.canvas?.tokens?.get?.(targetId),attacker=globalThis.canvas?.tokens?.get?.(message.speaker?.token);
      let dx=0,dy=1,from=null;
      if(target&&attacker&&attacker!==target){dx=target.center.x-attacker.center.x;dy=target.center.y-attacker.center.y;from={x:attacker.center.x,y:attacker.center.y};}
      const ranged=attackIsRanged(ctx,attacker,target);
      afterDice(message,()=>remember(dodges,targetId,{id,dx,dy,ranged,from,at:Date.now()}));
    }catch{}
  });
  Hooks.on('diceSoNiceRollComplete',id=>{const apply=awaitingDice.get(id);if(apply){awaitingDice.delete(id);try{apply();}catch{}}});
  Hooks.on('updateActor',(actor,changes)=>{
    const next=changes?.system?.attributes?.hp?.value;
    if(!Number.isFinite(next))return;
    const key=actor.uuid,before=hp.get(key);hp.set(key,next);
    if(!Number.isFinite(before)||next>=before)return;
    const max=Number(actor.system?.attributes?.hp?.max)||Math.max(1,before);
    const severity=Math.min(1,(before-next)/max*3);
    for(const token of actor.getActiveTokens?.()??[]){
      // Knocked away from whoever is acting now (if it is someone else).
      const attacker=globalThis.game?.combat?.combatant?.token?.object;
      let dx=0,dy=0;
      if(attacker&&attacker!==token){dx=token.center.x-attacker.center.x;dy=token.center.y-attacker.center.y;}
      // v11: the blow's damage type (the latest PF2e damage message aimed at her) rides on the hit;
      // her wing wears the type's wound and her portrait recoils and tints in step.
      let type='';try{type=damageRuntime.hit(token,{dx,dy,severity});}catch{}
      remember(hits,token.document.id,{id:foundry.utils.randomID(8),dx,dy,severity,type,at:Date.now()});
    }
  });
}
function rememberHp(doc){
  const actor=doc?.actor,value=actor?.system?.attributes?.hp?.value;
  if(actor&&Number.isFinite(value)&&!hp.has(actor.uuid))hp.set(actor.uuid,value);
}

// Each moment's sound and how strongly it plays (the 9.1 takeoff and landing
// sounds already mark those moments; the lift and settle sit quietly beneath).
const SOUNDS={liftoff:['flightLiftoff',.75],touchdown:['flightTouchdown',.75],impact:['flightImpact',1],unfurl:['flightUnfurl',1],hit:['flightBrace',1],
  shieldHit:['flightShieldHit',1],shieldUp:['flightShield',.8],shatter:['flightShatter',1],stop:['flightBrake',1],
  // beta.26: a shot glancing off a bit is a small shield hit, heard as it
  // lands (not as the bit sets off); a braced save is quiet.
  interceptHit:['flightShieldHit',.7]};

/**
 * One frame for one token's motion state `s` (after motion()). Returns true
 * when the feel ran. `audio` is the manager's WingAudio (optional).
 */
export function runFlightFeel(s,token,snapshot,{size,dt,now,cfg,audio=null}){
  if(!flightFeelEnabled()){if(s.feelState){clearFeel(s);s.feelState=null;s.feelFx?.clear();}return false;}
  const doc=token.document,settings=readFlightFeel(doc);rememberHp(doc);
  const f=s.feelState??=createFeel(doc.id);
  const mode=snapshot.effective?.mode,response=snapshot.conditionResponse;
  const airborne=!!snapshot.rendering?.flightActive&&mode!=='landing'&&mode!=='grounded';
  // (12.0.0-beta.2) Scale mail and Rotor need no wings: with her wings away they rise while her bits are out
  const wings=!!snapshot.rendering?.wingsActive,raised=wingShieldRaised(doc,settings),shield=raised&&(wings||['scalemail','rotor'].includes(shieldStyleOf(doc)));
  // Asleep on the ground: nothing to move, show or play. The token looks
  // exactly as without flight feel and the frame costs almost nothing.
  const pendingCombat=combatStarts.get(doc.id)!==undefined&&combatStarts.get(doc.id)!==f.combatId&&wings;
  if(f.init&&!airborne&&!snapshot.rendering?.flightActive&&f.air<.002&&f.alt<=0&&f.shield<.002&&!shield&&f.shatter<0&&f.prep<0&&
    Math.abs(f.squash)<.002&&Math.abs(f.squashV)<.02&&Math.abs(f.kick)<.002&&Math.abs(f.width-1)<.002&&Math.abs(f.dip)<.002&&Math.abs(f.dipV)<.02&&
    Math.abs(f.lean)<.002&&Math.abs(f.leanV)<.02&&!s.feelFx?.active&&!pendingCombat&&!feelBusy(f)&&!healRuntime.busy(token)&&!emoteRuntime.busy(token)){
    if(s.feel)clearFeel(s);s.feelShare=s.feelCue=null;s.feelHold=0;f.sleeping=true;f.hitId=hits.get(doc.id)?.id;f.dodgeId=dodges.get(doc.id)?.id;f.saveId=saves.get(doc.id)?.id;f.combatId=combatStarts.get(doc.id);return false;
  }
  if(f.sleeping){f.sleeping=false;f.tx=s.source.x;f.ty=s.source.y;f.vx=f.vy=f.ax=f.ay=0;f.bodyInit=false;}
  const unconscious=!!(response&&(response.wings||response.bits)&&['falling','fallen'].includes(response.collapse?.phase));
  let target=null;
  try{const t=readBitIntentTarget(doc);if(t?.center&&!t.document?.hidden)target=t.center;}catch{}
  const character=blendCharacter(snapshot.flightProfile?.modeWeights,mode);
  const floatTime=(now-(snapshot.started??0))/1000*(s.opts?.floatSpeed??1);
  // (v11) an emote outranks her idle gestures: one in progress fades out, no new one starts
  let idleGestures=settings.idleGestures;
  if(emoteRuntime.busy(token)){if(f.idleId)f.idleAbort=true;else idleGestures='off';}
  // (v11 phase 3a: Last light carries her: healRuntime.feelInput sets her height while the bits hold her)
  const out=stepFeel(f,healRuntime.feelInput(token,{x:s.source.x,y:s.source.y,size,dt,time:now/1000,character,hover:s.opts?.floatStyle??'hover',floatTime,
    weight:FEEL_WEIGHTS[settings.weight],scale:FEEL_SCALES[settings.scale],
    airborne,altitude:airborne?Math.max(HOVER_LOOK,feelAltitude(doc,settings,steadyMode(snapshot))):0,
    phase:(s.wingClock?.turns??0)*Math.PI*2,turns:s.wingClock?.turns,
    tilt:(s.opts?.tiltDegrees??12)*Math.PI/180,bank:snapshot.flightProfile?.bank??1,reduced:!!cfg.reduced,unconscious,epoch:s.kinematics?.epoch??0,
    hit:fresh(hits.get(doc.id)),dodge:fresh(dodges.get(doc.id)),save:fresh(saves.get(doc.id)),combat:combatStarts.get(doc.id),target,shield,wings,
    intercept:settings.missReaction!=='sidestep',bruise:settings.bruise!==false,brace:settings.braceSaves!==false,idleGestures,
    // (Which bits the wing renderer showed at their stations last frame: only those can take a shot.)
    bitsDrawn:s.feelBitsDrawn??0,
    // (12.0.0-beta.7) a Rotor or a Wing wrap holds her bits while it is up and while it settles: no idle gesture takes them
    shieldBits:(shield||(f.shield??0)>.004)&&['rotor','wingwrap'].includes(shieldStyleOf(doc)),
    rotation:s.source.rotation??0,wingScale:s.opts?.wingScale??3.5,
    dest:destination(token,s.feelDest??={}),grid:globalThis.canvas?.grid?.size,
    fresh:mode==='takeoff'||Number.isFinite(snapshot.started)&&now-snapshot.started<2500},f));
  s.feelBitsDrawn=0;
  out.collapse=response?.wings?Math.max(0,Math.min(1,response.collapse?.mix??0)):0;
  // (12.0.0-beta.2) her shield style: the rotor takes her bits, the wrap takes her wings (v12/shield-styles.mjs)
  try{shieldStyleFeel(doc,s,out,dt,s.feelFx?.shield?.angle);}catch{}
  out.wingShadow=WING_SHADOWS[settings.wingShadow]??1;
  // v11: wounds, persistent damage, dying and low-HP fatigue tweak the beat, lift and bits
  try{damageRuntime.feel(token,out,{size,turns:s.wingClock?.turns??0});}catch{}
  // v11 (phase 3a): healing and the bits' jobs: heals, the lent bit, spell traditions, die moods… (v11/heal-runtime.mjs)
  try{healRuntime.feel(token,out,{size,s});}catch{}
  // v11: an emote (v11/emote-runtime.mjs): beat, stillness, tilt, lift and the bits; it gives way to the moments above
  if(emoteRuntime.active.size)try{const c=EMOTE_CTX;c.now=now;c.dt=dt;c.size=size;c.f=f;c.unconscious=unconscious;c.mode=mode;c.hit=hits.get(doc.id);c.dodge=dodges.get(doc.id);c.save=saves.get(doc.id);
    emoteRuntime.feel(token,out,s,c);}catch(e){console.error('Yvaelle’s Toolbox | emote',e);}
  // v11: her wings held in by a wall, and her beat falling into step with a flier beside her
  try{worldRuntime.feel(token,out,s,{dt,reduced:!!cfg.reduced});}catch{}
  composeFeel(s,out,size,{allowHover:cfg.hover!==false,allowBank:cfg.banking!==false,allowPitch:cfg.pitching!==false});
  // Wing flex is quantized so the painter's cache and signature stay stable.
  s.feelFlex=Math.round(out.flex*20)/20;
  // The wing manoeuvres (flight-manoeuvres.mjs) ride on this flight: the
  // mode's share of each gesture, the wings lifting while she gathers or
  // stretches, and gestures for this frame's moments (read next frame).
  // (The mode's own wing raise: Sentinel's half-raised guard, Surge's gather.)
  s.feelShare=character;s.feelHold=Math.max(out.gather*.7,out.stretch*.8,out.modeRaise??0);s.feelFlareHold=out.modeFlare??0;
  for(const e of f.events){
    const cue=s.feelCue??={};
    // (Surge takes off with a power stroke: the wings lift high, then beat down hard.)
    if(e.type==='takeoff')cue.raise=(cue.raise??0)+.35+(character.burstFx>0?.5:0);
    else if(e.type==='touchdown')cue.raise=(cue.raise??0)+.25*(e.strength??1);
    else if(e.type==='unfurl')cue.flare=(cue.flare??0)+.85;
    // (beta.29) How the mode's wings brake at a stop: flared forward (Surge,
    // Fast, Sentinel) or raised as she coasts in (Glide).
    // Surge's burst is a power stroke: the wings lift, then beat down hard.
    else if(e.type==='burst'&&character.burstFx>0)cue.raise=(cue.raise??0)+.7*(e.strength??1);
    else if(e.type==='overshoot'&&character.rebound>0)cue.flare=(cue.flare??0)+character.stopFlare*Math.min(1,.5+e.dist*2);
    else if(e.type==='stop'){
      if(character.stopFlare>0&&!(character.rebound>0))cue.flare=(cue.flare??0)+character.stopFlare*(e.strength??1);
      if(character.stopRaise>0)cue.raise=(cue.raise??0)+character.stopRaise*(e.strength??1);
    }
  }
  // Combat moments and afterimages (takeoff, landing and travel are motion only).
  if(cfg.enabled!==false&&!cfg.reduced){
    s.feelFx??=new FlightFx(hashSeed(doc.id));
    const body={x:s.source.x+(s.swayX??0),y:s.source.y+s.lift},wingScale=s.opts?.wingScale??3.5;
    // (Fragments of a shattered wing ride on her body.)
    s.feelFx.anchor.x=body.x;s.feelFx.anchor.y=body.y;
    // Who she last saw coming at her (a hit or a miss from a known side).
    for(const r of [fresh(hits.get(doc.id)),fresh(dodges.get(doc.id))])
      if(r&&(r.dx||r.dy)&&r.id!==s.threatId){s.threatId=r.id;s.threat={angle:Math.atan2(-r.dy,-r.dx),at:now};}
    if(out.shield>.004||s.feelFx.shield){
      // The shield faces her target, else whoever last attacked her (for a
      // while), else the way she is heading (or last headed), else ahead of
      // her up the screen. It turns smoothly to a new side.
      let goal;
      if(target)goal=Math.atan2(target.y-body.y,target.x-body.x);
      else if(s.threat&&now-s.threat.at<45000)goal=s.threat.angle;
      else if(f.dirX||f.dirY)goal=Math.atan2(f.dirY,f.dirX);
      else goal=-Math.PI/2;
      const sh=s.feelFx.shield;
      let angle=sh?.angle??goal;
      const turn=Math.atan2(Math.sin(goal-angle),Math.cos(goal-angle));angle+=turn*(1-Math.exp(-7*dt));
      s.feelFx.shield=Object.assign(sh??{},{amount:out.shield,angle,x:body.x,y:body.y,r:size*out.scale*1.2,style:s.shieldStyle??'weave',want:shield,token,phase:s.rotorPhase??0});
      // (the rotor's disc sits where her bits are really turning; with none riding it draws its own blades)
      if(s.shieldStyle==='rotor'||s.shieldStyle==='wingwrap'){const bp=liveBitPositions(token);trimShieldBits(s,bp,body,angle,size*out.scale,out.shield);
        if(s.shieldStyle==='rotor')s.feelFx.shield.hub=rotorHub(bp,body,angle,size*out.scale);}
      if(out.shield<=.004){s.feelFx.shield=null;s.shieldBias=null;}
    }
    emitFlightEvents(s.feelFx,out,f.events,{size,body,wingSpan:wings?size*wingScale*out.scale:0,combat:settings});
    // (beta.30) Afterimages and the dodge copy use the beta.28 copy picture; it
    // is built as soon as she flies, so the first dodge already has one. The
    // modes' own copies (Fast's streak, Wraith's echo) use her live wings.
    const oldCopy=airborne&&wings?ghostImage(doc.texture?.src,wingScale,{wingsSrc:feelWingsSrc()}):null;
    const style=airborne&&wings?settings.afterimages:'off';
    const modeCopy=wings&&(f.events.some(e=>e.type==='stop')||(character.streak>.05&&out.speed>2.4));
    const img=modeCopy?liveGhost(s,s.renderer,doc.texture?.src,wingScale,now)??oldCopy:null;
    const rot=(s.source.rotation??0)+s.bank;
    s.wingScale=wingScale;
    if(airborne&&wings)emitModeEffects(s.feelFx,s,out,f.events,character,{size,body,img,rot,dt,speed:out.speed,dirX:f.dirX,dirY:f.dirY});
    if(style!=='off'||(settings.combatFx!==false&&settings.combatDodge!==false&&f.events.some(e=>e.type==='dodge'))){
      emitAfterimages(s.feelFx,s,{...body,size:size*wingScale*out.scale,rot,img:oldCopy??(wings?ghostImage(doc.texture?.src,wingScale,{wingsSrc:feelWingsSrc()}):null),speed:out.speed,dt,style,events:settings.combatFx!==false&&settings.combatDodge!==false?f.events:f.events.filter(e=>e.type!=='dodge'),dirX:f.dirX,dirY:f.dirY});
    }else s.ghostClock=0;
    s.feelFx.step(dt);
  }else s.feelFx?.clear();
  if(audio&&f.events.length)for(const e of f.events){
    if(e.type==='stroke'){
      // Only working strokes (climbing, catching herself, combat) pulse; a calm
      // hover is the steady hum alone, which already breathes with the beat.
      if(e.strength<.55)continue;
      s.feelBeat=((s.feelBeat??0)+1)%3;
      audio.play(token,`flightWingbeat${s.feelBeat+1}`,{strength:.2+.8*e.strength});
    }else if(SOUNDS[e.type]){
      let [slot,gain]=SOUNDS[e.type];
      // (12.0.0-beta.7) with V12 sounds on, Scale mail, Rotor and Wing wrap are raised with their own sound
      if(e.type==='shieldUp'){const own=soundFor(doc,'shields',shieldStyleOf(doc));if(own){slot=own;noteAsked(own);}}
      const k=e.type==='stop'?(e.strength??0)*character.stopSound:(e.strength??1);
      // (A step of a tile or two settles quietly: the brake is heard only
      // when she has built up some momentum.)
      if(k>(e.type==='stop'?.2:.05))audio.play(token,slot,{strength:Math.min(1,k*gain)});
    }
  }
  return true;
}
/** Where the token is headed: its saved position (the token's picture
 * animates toward it; the source data holds the destination even if the
 * document itself is animated). Centre, in canvas pixels. */
function destination(token,out={}){
  const d=token.document,src=d?._source??d,g=globalThis.canvas?.grid?.size??100;
  const x=Number(src?.x),y=Number(src?.y);
  if(!Number.isFinite(x)||!Number.isFinite(y))return null;
  try{const c=token.getCenterPoint?.({x,y});if(Number.isFinite(c?.x)&&Number.isFinite(c?.y)){out.x=c.x;out.y=c.y;return out;}}catch{}
  const w=(token.w??(d.width??1)*g),h=(token.h??(d.height??1)*g);
  out.x=x+w/2;out.y=y+h/2;return out;
}
const feelWingsSrc=()=>{try{return foundry.utils.getRoute(`modules/${ID}/assets/flight/shadow-wings.webp`);}catch{return null;}};
function hashSeed(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
