/** Original wing poses remain in the existing pose flag. Only their shared
 * cosmetic fit is retained from former structure-specific preferences. */
import {sampleWingHandoff} from './wing-handoffs.mjs?v=13.0.3';
export const STRUCTURE_POSES=Object.freeze({wings:Object.freeze({})});
export const STRUCTURE_POSE_IDS=Object.freeze(['wings']);
export const STRUCTURE_SIZE_RANGE=Object.freeze({min:.35,max:1.6,step:.05});
const unit=n=>Math.max(0,Math.min(1,n));
const finiteSize=value=>Number.isFinite(value)&&value>=STRUCTURE_SIZE_RANGE.min&&value<=STRUCTURE_SIZE_RANGE.max;
const requireWings=id=>{if(id!=='wings')throw new Error('Only the original filament wings are available.');return id;};
export const defaultStructurePose=id=>(requireWings(id),'neutral');
export function validateStructurePose(id,pose){requireWings(id);throw new Error('Use the original wing pose controls.');}
export function validateStructureSize(size){if(!finiteSize(size))throw new Error('Wing fit must be a finite number from 0.35 to 1.6.');return size;}
export function structurePosePatch(input={}){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Wing fit settings must be an object.');
  const out={};
  for(const [id,value] of Object.entries(input)){
    requireWings(id);if(value===null){out.wings=null;continue;}
    if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('Wing fit must contain size.');
    if(Object.keys(value).some(key=>key!=='size')||!Object.hasOwn(value,'size'))throw new Error('Wing fit must contain size only.');
    out.wings={size:validateStructureSize(value.size)};
  }
  return out;
}
export function readSavedStructurePoses(input={}){
  if(input==null)return {};
  if(typeof input!=='object'||Array.isArray(input))throw new Error('Invalid saved wing fit.');
  if(!Object.hasOwn(input,'wings'))return {};
  const saved=input.wings;
  if(saved===null)return {wings:null};
  if(!saved||typeof saved!=='object'||Array.isArray(saved))throw new Error('Invalid saved wing fit.');
  return Object.hasOwn(saved,'size')?structurePosePatch({wings:{size:saved.size}}):{};
}
export function structurePoseSettings(data,id='wings'){
  requireWings(id);return {pose:data?.pose??'neutral',size:data?.structurePoses?.wings?.size??1};
}
export function mergeStructurePoses(before={},patch={}){
  const old=readSavedStructurePoses(before),next=structurePosePatch(patch);
  return {...old,...(Object.hasOwn(next,'wings')?{wings:next.wings===null?null:{...old.wings,...next.wings}}:{})};
}
// Saved transitions are validated once, by normalizeFlag; frames reuse them.
const validTransitions=new WeakSet();
export function readStructurePoseTransition(raw){
  if(raw==null)return null;
  if(validTransitions.has(raw))return raw;
  // Former transitions carried several alternate structure samples. Ignore
  // those clocks entirely while preserving valid original-wing fit handoffs.
  if(raw?.from&&typeof raw.from==='object'&&Object.keys(raw.from).some(id=>id!=='wings'))return null;
  if(!raw||typeof raw!=='object'||Array.isArray(raw)||typeof raw.id!=='string'||!/^[\w-]{1,64}$/.test(raw.id)||
    !Number.isFinite(raw.started)||!Number.isFinite(raw.duration)||raw.duration<0||raw.duration>10000||!raw.from||typeof raw.from!=='object'||Array.isArray(raw.from))throw new Error('Invalid saved wing fit transition.');
  const value=raw.from.wings;
  if(!value||!finiteSize(value.size)||!Array.isArray(value.weights)||value.weights.length!==1||value.weights[0]!==1)throw new Error('Invalid saved wing fit sample.');
  const from={wings:{weights:[1],size:value.size}};
  if(value.velocity!=null){const v=value.velocity;if(!v||!Array.isArray(v.weights)||v.weights.length!==1||v.weights[0]!==0||!Number.isFinite(v.size)||Math.abs(v.size)>1)throw new Error('Invalid saved wing fit velocity.');from.wings.velocity={weights:[0],size:v.size};}
  const out={id:raw.id,started:raw.started,duration:raw.duration,from};validTransitions.add(out);return out;
}
export function sampleStructurePoses(data,now,animate=true,resume=true){
  const transition=readStructurePoseTransition(data.structurePoseTransition),progress=!animate||resume===false||!transition||transition.duration===0?1:unit((now-transition.started)/transition.duration),settings=structurePoseSettings(data),from=transition?.from.wings;
  const sized=from&&progress<1?sampleWingHandoff([from.size],[settings.size],[from.velocity?.size??0],progress,transition.duration,{min:STRUCTURE_SIZE_RANGE.min,max:STRUCTURE_SIZE_RANGE.max}):{values:[settings.size],velocity:[0]};
  return {samples:{wings:{...settings,weights:[1],size:sized.values[0],velocity:{weights:[0],size:sized.velocity[0]}}},active:progress<1,progress};
}
export function makeStructurePoseTransition(data,now,{id='wing-fit',duration=850,enabled=true}={}){
  if(!Number.isFinite(duration)||duration<0||duration>10000)throw new Error('Wing fit duration must be 0–10000 milliseconds.');
  const sample=sampleStructurePoses(data,now,enabled).samples.wings;
  return readStructurePoseTransition({id,started:now,duration:enabled?duration:0,from:{wings:{weights:[1],size:sample.size,velocity:sample.velocity}}});
}
export function deformStructurePosePoint(id,pose,p){requireWings(id);return p;}
export function poseStructurePoint(id,p,side,animation){
  requireWings(id);const size=animation?.poseSamples?.wings?.size??1;return size===1?p:p.map(n=>n*size);
}
