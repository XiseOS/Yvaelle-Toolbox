/** Deterministic wing-local geometry. No timers, document writes, filters or
 * full-token flashes. All extra art shares the existing four wing textures. */
import {hash} from './conditions.mjs?v=13.0.3';
import {ease,unit} from './poses.mjs?v=13.0.3';
import {cubic} from './wing-art.mjs?v=13.0.3';
import {reactionAccents} from './reaction-art.mjs?v=13.0.3';

const rnd=key=>hash(key)/4294967295;
const frac=x=>x-Math.floor(x);
const lerp=(a,b,t)=>t===0?a:t===1?b:a.map((v,i)=>v+(b[i]-v)*t);
const rootWeight=u=>ease((u-0.1)/0.32);
const inkStrength=n=>Math.round(Math.max(0,Math.min(1.5,n))*20)/20;
const timeOf=v=>v.animated?(v.effectTime??v.time):0;
const soft=(n,lo,hi)=>n<lo?lo-12*Math.tanh((lo-n)/12):n>hi?hi+12*Math.tanh((n-hi)/12):n;
// Scope a bounded enlarged canvas to one synchronous draw. All legacy effect
// helpers share this fitter, so a larger structure cannot be flattened by an
// older effect's fixed artwork edge. Nested draws and errors restore the scope.
let effectExtent=1;
let effectLeft=-272,effectRight=272,effectTop=-257,effectBottom=286;
export function withEffectExtent(extent,draw){
  const previous=effectExtent;effectExtent=Math.max(1,Math.min(1.6,Number.isFinite(extent)?extent:1));
  effectLeft=-272*effectExtent;effectRight=272*effectExtent;effectTop=-257*effectExtent;effectBottom=286*effectExtent;
  try{return draw();}finally{effectExtent=previous;effectLeft=-272*effectExtent;effectRight=272*effectExtent;effectTop=-257*effectExtent;effectBottom=286*effectExtent;}
}
export function fitEffectPoint(p){
  const x=soft(p[0],effectLeft,effectRight),y=soft(p[1],effectTop,effectBottom);
  // Filament vertices contain xyz and usually their material coordinate.
  // Their tails never need an intermediate sliced array on the hot path.
  if(p.length===4)return [x,y,p[2],p[3]];
  if(p.length===3)return [x,y,p[2]];
  return [x,y,...p.slice(2)];
}
/** Internal hot paths already own their newly created point. Preserve every
 * original soft-bounds pass while avoiding another short-lived point copy.
 * Public fitEffectPoint deliberately retains its independent result contract. */
export function fitOwnedEffectPoint(p){
  p[0]=soft(p[0],effectLeft,effectRight);p[1]=soft(p[1],effectTop,effectBottom);return p;
}
const bandCaches=new WeakMap();

/** Bands hold for several texture frames, snap apart, and reform independently.
 * Both ends of a sliced segment use the same displacement: no diagonal bridges
 * across a tear. The seed and clock reproduce the pattern after a reload. */
export function glitchBand(visual,side,band) {
  const t=timeOf(visual),step=Math.floor(t*7),g=visual.glitch;
  if(!g||!visual.animated)return {dx:0,dy:0,drop:false,echo:false,active:false};
  const stamp=`${visual.seed}:${step}:${g}:${visual.displacement}:${visual.motionStrength}`;
  let cache=bandCaches.get(visual);
  if(cache?.stamp!==stamp){cache={stamp,bands:new Map()};bandCaches.set(visual,cache);}
  const key=`${side}:${band}`;
  if(cache.bands.has(key))return cache.bands.get(key);
  const seed=`${visual.seed}:slice:${side}:${band}:${step}`;
  const quiet=frac(step/7*1.55+rnd(`${visual.seed}:rest:${side}`))>0.78;
  const active=!quiet&&rnd(seed)<0.18+0.72*g;
  const amplitude=active?g*(visual.displacement??1)*(visual.motionStrength??1):0;
  const result={active,dx:(rnd(seed+':x')>0.5?1:-1)*(12+22*rnd(seed+':m'))*amplitude,
    dy:(rnd(seed+':y')-0.5)*11*amplitude,
    drop:active&&rnd(seed+':cut')>0.77,echo:active&&rnd(seed+':copy')>0.3};
  cache.bands.set(key,result);return result;
}

/** Frame-local constants; never retained across effect or seed changes. */
export function enhancedPointParameters(side,v) {
  return {motion:v.motionStrength??1,time:timeOf(v),phase:rnd(`${v.seed}:flex:${side}`)*Math.PI*2};
}
export function enhancedPoint(point,u,side,v,parameters) {
  // Stable wings still need the original bounds pass, but none of the wave
  // terms can contribute. This is also shared by held support coordinates.
  // Avoid evaluating five trigonometric waves and copying a second point.
  if(!(v.instability||v.overdrive||(v.geometryFlare??v.flare)||v.suppression&&v.energyPulses))return fitEffectPoint(point);
  const {motion:m,time:t,phase}=parameters??enhancedPointParameters(side,v);
  const out=[...point],r=rootWeight(u);
  const sway=v.instability*m*r;
  out[0]+=side*sway*(15*Math.sin(t*2.7+phase-u*8)+6*Math.sin(t*6.1+u*13+phase));
  out[1]+=sway*(18*Math.sin(t*2.2+u*9+phase)+7*Math.sin(t*5.3-u*12));
  // Unequal, soft buckling for unstable wings; energetic outward rib sweeps for
  // overdrive and attack flares. The shoulder roots and z-plane are unchanged.
  const surge=v.overdrive??0,breath=v.energyPulses?0.5+0.5*Math.sin(t*3.5-u*8):0.5;
  const spread=(surge*(0.055+0.035*breath)+(v.geometryFlare??v.flare)*0.07)*m*r;
  out[0]+=(out[0]-side*27)*spread;
  out[1]+=(out[1]+13)*spread*0.48-surge*9*m*r;
  if(v.suppression&&v.energyPulses){out[0]-=(out[0]-side*27)*0.055*v.suppression*m*r*breath;out[1]+=v.suppression*m*r*5*Math.sin(t*1.4+u*5);}
  return fitOwnedEffectPoint(out);
}

function sectionCuts(a,b,enabled) {
  if(!enabled||Math.abs(b[1]-a[1])<0.00001)return [0,1];
  const lo=Math.min(a[1],b[1]),hi=Math.max(a[1],b[1]),cuts=[0,1];
  for(let y=(Math.floor((lo+275)/38)+1)*38-275;y<hi;y+=38)cuts.push((y-a[1])/(b[1]-a[1]));
  return cuts.sort((x,y)=>x-y);
}
function shifted(p,band,echo=false) {
  const w=rootWeight(p[3]??1),factor=echo?-0.58:1;
  return fitEffectPoint([p[0]+band.dx*w*factor,p[1]+band.dy*w*factor,p[2],p[3]??1]);
}

export function enhancedPathParameters(v){
  return {time:timeOf(v),healHead:Math.max(0,...[...(v.bursts??[]),...(v.reactions??[])].filter(x=>['heal','reform'].includes(x.kind)).map(x=>x.progress*1.2))};
}
export function enhancedPaths(strand,points,side,v,parameters=null) {
  // Transient currents use their own fine paths. An otherwise healthy wing
  // needs no section slicing or seeded damage sampling just because it pulses.
  if(!(v.damage||v.glitch||v.instability||v.overdrive))return [{...strand,points}];
  const result=[],echoes=[],frays=[],{time:t,healHead}=parameters??enhancedPathParameters(v);
  let prior=null,priorEcho=null,lastFray=-1,rankGroup=-1,rank=0;
  const append=(target,a,b,strength,sourceA,tag,isEcho=false)=>{
    let last=isEcho?priorEcho:prior;
    if(last&&last.tag===tag&&last.strength===strength&&last.sourceEnd===sourceA){last.points.push(b);}
    else{last={...strand,id:isEcho?`echo-${strand.id}`:strand.id,points:[a,b],strength,echo:isEcho,
      width:strand.width*(isEcho?0.72:1),tag,sourceStart:sourceA};target.push(last);}
    if(isEcho)priorEcho=last;else prior=last;
    return last;
  };
  for(let i=1;i<points.length;i++) {
    const a=points[i-1],b=points[i],u=((a[3]??1)+(b[3]??1))/2;
    const group=Math.floor((i-1)/4),protectedRoot=rootWeight(u);
    // Four adjacent material segments share this exact deterministic damage
    // rank. Reusing it locally preserves cuts while avoiding repeated hashes.
    if(group!==rankGroup){rank=rnd(`${v.seed}:${side}:${strand.id}:${group}`);rankGroup=group;}
    const repaired=(v.healing??0)*(1-ease((u-healHead+0.1)/0.25));
    const damage=v.damage*(1-0.8*repaired);
    const broken=rank<damage*0.76*protectedRoot;
    if(broken) {
      prior=null;priorEcho=null;
      // Loose ends emerge from actual missing rib sections, not an unrelated aura.
      if(v.sparks&&strand.id.startsWith('rib-')&&lastFray!==group&&u>0.2) {
        lastFray=group;const life=frac(t*0.65+rank*13),s=damage*Math.sin(Math.PI*life);
        const drift=(v.motionStrength??1)*life;
        const tail=[a,fitEffectPoint([a[0]+side*(4+12*drift),a[1]+5+18*drift,a[2],a[3]]),
          fitEffectPoint([a[0]+side*(2+8*drift)+Math.sin(t*3+rank*20)*5*life*(v.motionStrength??1),a[1]+12+28*drift,a[2],a[3]])];
        frays.push({id:`fray-${strand.id}-${group}`,points:tail,width:0.65,strength:0.65*s});
        if(rank<damage*0.35)frays.push({id:`ember-${strand.id}-${group}`,star:true,points:[tail.at(-1)],width:1.05,strength:s*0.7});
      }
      continue;
    }
    const cuts=sectionCuts(a,b,v.glitch>0&&v.animated);
    for(let j=1;j<cuts.length;j++) {
      const start=lerp(a,b,cuts[j-1]),end=lerp(a,b,cuts[j]),mid=(start[1]+end[1])/2;
      const index=Math.floor((mid+275)/38),band=glitchBand(v,side,index);
      const localRoot=rootWeight(((start[3]??1)+(end[3]??1))/2);
      let strength=strand.strength*(v.energyPulses?1-0.16*v.instability*(0.5+0.5*Math.sin(t*2.1+rank*9)):1);
      if(v.energyPulses)strength*=1+(v.overdrive??0)*0.38*(0.5+0.5*Math.sin(t*5.4-u*16));
      if(band.drop&&localRoot>0.15)strength*=1-0.97*localRoot;
      strength=inkStrength(strength);
      const tag=`${index}:${band.dx}:${band.dy}`;
      if(strength>=0.025){const seg=append(result,shifted(start,band),shifted(end,band),strength,start,tag);seg.sourceEnd=end;}
      else prior=null;
      if(v.echoes&&band.echo&&localRoot>0.1){
        const seg=append(echoes,shifted(start,band,true),shifted(end,band,true),inkStrength(strand.strength*v.glitch*0.4*localRoot),start,tag,true);seg.sourceEnd=end;
      }else priorEcho=null;
    }
  }
  return [...result,...echoes,...frays];
}

/** Local accent topology samples the same deformer as the wings. */
export function conditionAccents(side,v,warp,ribs,growth=1) {
  if(!v||(!v.enhanced&&!v.bursts?.length)||!v.animated||growth<=0)return [];
  const out=reactionAccents(side,v,warp,ribs,growth,v.bursts??[]),t=timeOf(v),m=v.motionStrength??1;
  const at=(i,u)=>warp([...cubic(ribs[i],u),u]);
  const line=(id,points,width,strength)=>{if(strength>0.025)out.push({id,points:points.map(fitEffectPoint),width,strength});};
  const spark=(id,p,strength,size=1.4)=>{if(strength>0.025)out.push({id,star:true,points:[fitEffectPoint(p)],width:size,strength});};
  if(v.arcs&&v.overdrive>0)for(let i=0;i<8;i++) {
    const u=0.24+0.7*frac(t*0.36+i*0.173),next=(i+1)%9;
    if(u>growth)continue;
    const a=at(i,u),b=at(next,Math.max(0,u-0.055)),phase=Math.sin(t*5+i*2.1+side);
    const arc=Array.from({length:9},(_,j)=>{
      const f=j/8,p=lerp(a,b,f);return [p[0]+side*Math.sin(Math.PI*f)*5*m*phase,p[1]-Math.sin(Math.PI*f)*8*m,p[2],p[3]];
    });
    line(`overdrive-arc-${i}`,arc,0.85,v.overdrive*(0.42+0.35*Math.sin(Math.PI*u)));
    spark(`overdrive-node-${i}`,a,v.overdrive*0.8,1.5);
  }
  if(v.energyPulses) {
    const waves=v.overdrive>0?Array.from({length:2},(_,i)=>({kind:'surge',u:frac(t*0.55+i*.5),strength:v.overdrive*.8,gain:1})):[];
    for(let wi=0;wi<waves.length;wi++) {
      const wave=waves[wi],u=wave.u;if(u<=0||u>growth)continue;
      const amp=wave.strength*Math.sin(Math.PI*u),points=ribs.map((_,i)=>at(i,u));
      line(`wave-${wi}`,points,1.25*wave.gain,amp*0.85);
      for(const ri of [0,2,4,6,8,9]) {
        const packet=Array.from({length:9},(_,j)=>at(ri,Math.max(0,u-j*.012)));
        line(`surge-${wi}-${ri}`,packet,2*wave.gain,amp);
        spark(`surge-head-${wi}-${ri}`,packet[0],amp*0.9,1.8*wave.gain);
      }
    }
    if(v.suppression>0)for(let i=0;i<4;i++) {
      const u=0.1+0.8*(1-frac(t*.2+i*.25));if(u>growth)continue;
      line(`return-current-${i}`,Array.from({length:9},(_,j)=>at(i*2,Math.min(growth,u+j*.012))),1.15,v.suppression*.75*Math.sin(Math.PI*u));
    }
  }
  if(v.sparks&&v.collapse>0.05)for(let i=0;i<9;i++) {
    const r=rnd(`${v.seed}:fall:${side}:${i}`),life=frac(t*(.28+r*.14)+r),u=.5+.4*r;
    if(u>growth)continue;
    const a=at(i,u),dx=side*(6+16*r)*life*m,dy=(35+70*r)*life*m;
    const p=[a[0]+dx,a[1]+dy,a[2],u],strength=v.collapse*Math.sin(Math.PI*life)*.85;
    line(`fall-${i}`,[[p[0]-side*5*life*m,p[1]-14*life*m,p[2],u],p],.75,strength);
    spark(`fall-spark-${i}`,p,strength,1.3);
  }
  return out;
}
