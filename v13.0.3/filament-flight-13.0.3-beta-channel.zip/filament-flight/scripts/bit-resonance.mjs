import {unit} from './poses.mjs?v=13.0.3';
import {paintBitEnergy} from './bit-energy.mjs?v=13.0.3';
import {sampleCoreState} from './bit-core-states.mjs?v=13.0.3';
import {sampleV7GemInterior,v7GemInteriorGeometry,projectedCrystalOutline} from './v7-gem-interior.mjs?v=13.0.3';
import {sampleScanMechanism} from './bit-scan-mechanism.mjs?v=13.0.3';

const TAU=2*Math.PI;
// The two gimbals share this fixed circle topology in every design. Preserve
// the exact original edge angles (including floating-point endpoints), then
// project each unique vertex once per ring instead of once per painted edge.
const GIMBAL_TOPOLOGY=(()=>{
  const vertices=[],indices=new Map(),index=t=>{
    if(!indices.has(t)){indices.set(t,vertices.length);vertices.push([Math.cos(t),Math.sin(t)]);}
    return indices.get(t);
  };
  const edges=Array.from({length:24},(_,i)=>{const angle=i/24*TAU;return {angle,first:index(angle),last:index(angle+TAU/24)};});
  return {vertices,edges};
})();
export const RESONANT_PROGRAMS=Object.freeze({poised:'Poised constellation',orbital:'Orbital gyroscope',seraph:'Seraph cadence'});
// Retained silhouettes describe the resting outer envelope. The live artwork
// below consists of independently moving three-dimensional solid components.
export const RESONANT_DESIGNS=Object.freeze({
  vanes:Object.freeze({name:'Prism spindle',radius:4.7,length:19,hull:[[0,-19],[2.8,-13],[4.5,-4],[4.1,7],[1.7,15],[0,18],[-1.7,15],[-4.1,7],[-4.5,-4],[-2.8,-13]],core:[[0,-10],[1.8,-4],[1.4,5],[0,10],[-1.4,5],[-1.8,-4]]}),
  shielded:Object.freeze({name:'Aegis lens',radius:6,length:15,hull:[[0,-14],[4,-10],[6.2,-3],[6,5],[2.7,12],[0,15],[-2.7,12],[-6,5],[-6.2,-3],[-4,-10]],core:[[0,-8],[2.8,-3],[2.6,4],[0,9],[-2.6,4],[-2.8,-3]]}),
  spine:Object.freeze({name:'Filament needle',radius:3.8,length:21,hull:[[0,-21],[1.6,-13],[3.2,-4],[2.4,8],[.9,16],[0,21],[-.9,16],[-2.4,8],[-3.2,-4],[-1.6,-13]],core:[[0,-11],[1.25,-3],[.9,8],[0,13],[-.9,8],[-1.25,-3]]})
});

/** All mechanisms and energy share the resolved wing clock. These are smooth
 * continuous transforms, not frame substitutions or whole-sprite oscillation. */
export function sampleBitResonance({flight,channels:c,side,index,time,deployment,animated}){
  const cfg=flight.gems,amount=Math.max(0,Number(cfg.strength)||0),live=animated&&amount>0;
  const profile=flight.movement?.profile??flight.flightProfile??{};
  const clock=live?time*.8+index*1.7+side*.42:0;
  // A bounded phase modulation preserves continuity when mode profiles blend,
  // even after an hours-long session; never multiply a new rate by old time.
  const phase=clock+(live?.7*((profile.bitOrbit??1)-1)*Math.sin(clock*.51):0);
  const weights=flight.poseAnimation?.tipWeights??flight.poseAnimation?.weights??[1];
  const guard=unit((weights[1]??0)+(weights[2]??0)+(weights[10]??0)+(side<0?(weights[3]??0):(weights[4]??0))+(profile.guard??0)*.65);
  const responsive=cfg.assetStates!==false;
  const drive=responsive?unit((c.overdrive??0)+(profile.flare??0)*.35):0,heal=responsive&&cfg.repairFocus!==false?unit(c.heal??0):0;
  const focus=responsive?Math.max(guard,drive*.85,heal):0;
  const motion=responsive?unit(flight.movement?.sweep??0):0;
  const program=Object.hasOwn(RESONANT_PROGRAMS,cfg.program)?cfg.program:'poised';
  const damage=responsive?unit(c.damage??0):0,suppression=responsive?unit(c.suppression??0):0,collapse=responsive?unit(c.collapse??0):0;
  const flightProfile=flight.flightProfile?.id??flight.flightProfile?.name??flight.effective?.mode??'hover';
  const yaw=live?amount*(program==='orbital'?phase*.72:program==='seraph'?phase*.31:.24*Math.sin(phase*.7)+phase*.19):0;
  const precession=live?amount*(.10+.13*motion+.11*drive)*Math.sin(phase*.53+index):0;
  const station=`${side<0?'left':'right'}${index?'Lower':'Upper'}`,duty=flight.bitActionAssignments?.support?.[station]?.amount??0;
  const activity=flight.bitActivity??(duty>0?{state:'guarding',amount:duty}:null);
  const coreState=sampleCoreState({selection:cfg.coreState??'idle',activity,channels:{...c,guard},deployment,responsive,time:live?time:0});
  const v7Interior=sampleV7GemInterior(flight,{time,index,side,animated:live,deployment});
  return {coreState,...(v7Interior?{v7Interior}:{}),...(flight.v9?.signatureCraft===true&&flight.v7?.enabled===true?{signatureCraft:true}:{}),phase,animated:live,amount:live?amount:0,mechanical:live&&cfg.mechanicalResponse!==false?amount:0,fieldRate:profile.field??1,program,fieldStyle:cfg.fieldStyle??'contour',side,index,focus,motion,guard:responsive?guard:0,drive,
    response:live?.88+.08*Math.sin(phase*1.8)+.12*motion+.10*focus:.94,
    orbit:live?phase*(program==='orbital'?.95:.59)+index*.3-.22*guard*Math.sin(phase*.61):index*.3,
    yaw,precession,tilt:live?amount*(.14*Math.sin(phase*.43)+.21*motion+.08*guard):0,
    charge:unit(deployment*(1-.72*suppression)*(1-.9*collapse)),deployment:unit(deployment),flightProfile,
    healing:heal,damage,instability:responsive?unit(c.instability??0):0,glitch:responsive?unit(c.glitch??0):0,
    suppression,collapse,impact:responsive?unit(c.impact??0):0,pulse:responsive?unit(c.pulse??0):0,
    dominant:deployment<.999?'formation':!responsive?'idle':heal>.1?'recovery':collapse>.3?'collapsed':suppression>.3?'suppressed':(c.glitch??0)>.3?'glitching':drive>.3?'overdrive':damage>.1?'damaged':guard>.4?'guard':motion>.3?'travel':'idle'};
}

function rotation(yaw,tilt,roll){
  // One transform per component, shared by every face vertex this frame.
  const c=Math.cos(yaw),s=Math.sin(yaw),ct=Math.cos(tilt),st=Math.sin(tilt),cr=Math.cos(roll),sr=Math.sin(roll);
  return ([x,y,z])=>{const a=x*c+z*s,b=-x*s+z*c,d=y*ct-b*st,e=y*st+b*ct;return [a*cr-d*sr,a*sr+d*cr,e];};
}
// Shading already resolves to one of 256 literal metal colours. Reuse those
// exact strings instead of formatting them for every rail and vane frame.
const METAL_COLORS=Array.from({length:256},(_,n)=>`rgb(${Math.max(0,n-8)},${Math.min(255,n+3)},${Math.min(255,n+14)})`);
const color=(l,tint=0)=>{
  const n=Math.round(Math.max(0,Math.min(255,l)));
  return tint===0&&Number.isFinite(n)?METAL_COLORS[n]:`rgb(${Math.max(0,n-8+tint)},${Math.min(255,n+3)},${Math.min(255,n+14)})`;
};

/** Restrained internal shading, entirely contained by an existing projected
 * triangular facet. Barycentric coordinates stay strictly inside that face,
 * so no glow, wider silhouette, mask, texture or extra renderer is involved.
 * Sharing the parent's depth keeps these accents immediately after its fill
 * in the stable depth sort, behind every existing foreground component. */
function internalCoreDepth(parent,{strength,phase,index,yaw}){
  const [first,second,third]=parent.points;
  // These are triangular facets. Retain the original left-to-right sum,
  // including its initial zero, without allocating barycentric weight arrays
  // and nested per-coordinate callbacks for every little depth accent.
  const blend=(a,b,c)=>[
    0+first[0]*a+second[0]*b+third[0]*c,
    0+first[1]*a+second[1]*b+third[1]*c,
    0+first[2]*a+second[2]*b+third[2]*c
  ];
  const detail=(kind,points,fill,alpha)=>({id:`core-depth-${kind}-${parent.id}`,points,z:parent.z,fill,alpha:parent.alpha*strength*alpha,stroke:null,width:0,parent:parent.id});
  const glint=.5+.5*Math.sin(phase*.61+index*.93+yaw*.27),tip=.45+.07*Math.sin(phase*.37+index*.8);
  return [
    detail('recess',[blend(.28,.55,.17),blend(.18,.38,.44),blend(.35,.12,.53)],'#351637',.13),
    detail('reflection',[blend(tip,.7-tip,.3),blend(tip+.045,.655-tip,.3),blend(.20,.25,.55),blend(.16,.29,.55)],'#ffe2f7',.075*(.25+.75*glint))
  ];
}

/** v10 beta: every work state gets one signature mark that reads at token
 * size. Classic keeps the original small marks (Versions › Bit core states). */
let coreMarkStyle='v10';
export function setCoreMarkStyle(style){coreMarkStyle=style==='classic'?'classic':'v10';}
export function getCoreMarkStyle(){return coreMarkStyle;}
/** Optional darker outline for token-size legibility (Versions › Bit outline; off by default). */
let bitOutline=false;
export function setBitOutline(on){bitOutline=!!on;}
export function getBitOutline(){return bitOutline;}
const ring=(radial,r,y,n=20,a0=0,a1=TAU)=>Array.from({length:n+1},(_,i)=>radial(a0+(a1-a0)*i/n,r,y));
function v10CoreMarks({line,radial,phase,radius,L,charge,encase,working,charging,guarding,settle,scan,brace,align,rest,conduct}){
  const k=.35+.65*charge;
  // Encased: a hexagonal crystal sheath around the whole instrument
  if(encase>.01){for(let i=0;i<6;i++){const a=i*TAU/6+.3;line(`v10-sheath-${i}`,[radial(a,radius+2.6,-L*.8),radial(a,radius+3.4,0),radial(a,radius+2.6,L*.8)],'#f3c8ec',.42,encase*k*.6);}
    for(const y of [-L*.8,L*.8])line(`v10-sheath-rim-${y>0?1:0}`,ring(radial,radius+2.6,y,6,.3,.3+TAU),'#f3c8ec',.32,encase*k*.4);}
  // Open: three light spokes from the core between the parted rails
  if(working>.01)for(let j=0;j<3;j++){const a=j*TAU/3+.24+Math.PI/3,f=.6+.4*Math.sin(phase*2+j);line(`v10-open-${j}`,[radial(a,1,0),radial(a,radius+4+2*f,0)],'#ff7cf0',.6,working*k*.75*f);}
  // Charging: rings climb the spine and tighten as energy gathers
  if(charging>.01)for(let i=0;i<3;i++){const u=((phase*.35+i/3)%1+1)%1,y=L*(.8-1.6*u),r=(radius+4)*(1-.55*u);line(`v10-charge-${i}`,ring(radial,r,y),'#ff5cf0',.5+.3*u,charging*k*Math.sin(Math.PI*u)*.9);}
  // Guarding: a forward shield arc in two bands
  if(guarding>.01)for(const y of [-L*.3,L*.3])line(`v10-guard-${y>0?1:0}`,ring(radial,radius+5,y,16,-.15*TAU+Math.PI/2,.15*TAU+Math.PI/2+.0001).map(p=>p),'#ffd0f6',.7,guarding*k*(.55+.2*Math.sin(phase*1.4)));
  // Settling: one ring sinks and fades, like an exhale
  if(settle>.01){const u=((phase*.22)%1+1)%1;line('v10-settle',ring(radial,radius+3-1.5*u,-L*.3+L*1.1*u),'#d9b7d4',.45,settle*k*(1-u)*.8);}
  // Scanning: a wide lens that sweeps the instrument's length with a reading tick
  if(scan>.01){const y=Math.sin(phase*.9)*L*.7;line('v10-scan-lens',ring(radial,radius+4.5,y,24),'#ffd6f7',.55,scan*k*.8);line('v10-scan-tick',[radial(Math.PI/2,radius+4.5,y),radial(Math.PI/2,radius+8.5,y)],'#fff1fb',.6,scan*k*.85);}
  // Bracing: locked triangles at both ends
  if(brace>.01)for(const y of [-L*.55,L*.55])line(`v10-brace-${y>0?1:0}`,ring(radial,radius+3.2,y,3,.5,.5+TAU),'#eab8dd',.6,brace*k*.75);
  // Aligning: a sighting line through both terminals with three ticks
  if(align>.01){line('v10-align-axis',[[0,-L-7,0],[0,L+7,0]],'#f4e3c4',.4,align*k*.7);for(let i=0;i<3;i++){const a=i*TAU/3+.5;line(`v10-align-${i}`,[radial(a,radius+1.5,-L*.25),radial(a,radius+1.5,L*.25)],'#e8d9c0',.45,align*k*.55);}}
  // Resting: a dim slow breath ring at the waist
  if(rest>.01)line('v10-rest',ring(radial,radius+2+.6*Math.sin(phase*.3),0,20),'#b48fb0',.4,rest*(.25+.2*Math.sin(phase*.3)));
  // Conducting: zig-zag current running end to end around the rails
  if(conduct>.01)for(let j=0;j<3;j++){const pts=Array.from({length:11},(_,i)=>{const f=i/10,a=j*TAU/3+phase*.8+f*.9+(i%2?.18:-.18);return radial(a,radius+2.4,-L*.75+f*L*1.5);});line(`v10-conduct-${j}`,pts,'#ffe0fa',.55,conduct*k*(.45+.35*Math.sin(phase*2.4+j)**2));}
}
/** Project actual solid faces, sort by depth, and shade the turning facets.
 * The core, three shell rails, two gimbals, and three counter-orbiting vanes
 * remain separate parts. A shell can never articulate as a grabbing pincer. */
function sampleResonantBitGeometry(h){
  const r=h.resonance??{},d=RESONANT_DESIGNS[h.design]??RESONANT_DESIGNS.vanes;
  const phase=r.phase??0,conditionPhase=r.conditionPhase??phase,amount=r.amount??0,yaw=r.yaw??0,tilt=(r.tilt??0)+.18,precession=r.precession??0;
  const focus=r.focus??0,drive=r.drive??0,heal=r.healing??0,charge=r.charge??1,dep=r.deployment??1;
  const state=r.coreState??{},encase=state.encase??0,working=state.open??0,charging=state.charge??0,guarding=state.guard??0;
  const scan=state.scan??0,brace=state.brace??0,align=state.align??0,rest=state.rest??0,conduct=state.conduct??0;
  const mechanical=r.mechanical??amount,damage=(r.damage??0)*mechanical*(1-heal),quiet=(r.suppression??0)*mechanical,collapse=(r.collapse??0)*mechanical*(1-heal);
  const fault=(r.glitch??0)*mechanical*(h.desync??0),impact=(r.impact??0)*mechanical;
  // Work-state weights can change at any point in an hours-long clock. A
  // bounded posture modulation preserves the original idle phase without
  // multiplying its accumulated revolutions by a changing state weight.
  const radius=d.radius,L=d.length,parts=[],turn=rotation(yaw-(.72*rest+.28*align)*Math.sin(yaw),tilt+rest*.2,precession*(1-.8*brace));
  const project=p=>{
    const [x,y,z]=turn(p);const perspective=1+z*.006;
    return [x*perspective,y*perspective,z];
  };
  const projectedFace=(id,vertices,fill,{alpha=1,stroke=null,width=.32}={})=>{
    const points=[];let z=0;for(const vertex of vertices){points.push(vertex.slice());z+=vertex[2];}
    parts.push({id,points,z:z/points.length,fill,alpha,stroke,width});
  };
  const face=(id,points,fill,{alpha=1,stroke=null,width=.32}={})=>{
    const projected=[];let z=0;for(const point of points){const vertex=project(point);projected.push(vertex);z+=vertex[2];}
    parts.push({id,points:projected,z:z/projected.length,fill,alpha,stroke,width});
  };
  const line=(id,points,stroke,width=.4,alpha=1)=>face(id,points,null,{stroke,width,alpha});
  const radial=(angle,rad,y)=>[Math.cos(angle)*rad,y,Math.sin(angle)*rad];
  // Dark needle-shaped central spine, with restrained gold terminal fittings.
  face('spine',[[0,-L,-.8],[1,-L+3,-.8],[.65,L-3,-.8],[0,L,-.8],[-.65,L-3,-.8],[-1,-L+3,-.8]],'#1b2738');
  for(const sign of [-1,1]){
    face(`terminal-${sign}`,[[0,sign*L,0],[-1.15,sign*(L-3.2),0],[0,sign*(L-5),1.4],[1.15,sign*(L-3.2),0]],'#bbad91',{stroke:'#e9d9b7',width:.28});
  }
  // Three non-hinged satin shell rails roll around the long axis. Segment
  // offsets advance in a gentle travelling wave; no two jaws open or close.
  for(let j=0;j<3;j++){
    const base=j*TAU/3+.24;
    const shift=amount*(.16+.19*heal)*Math.sin(phase*.93+j*TAU/3)+(1-dep)*.4+damage*.20*Math.sin(j*2.4+conditionPhase*.45)+fault*(j-1)*.22;
    const angle=base+shift*(1-.65*encase-.28*guarding-.5*brace)+conduct*.17*Math.sin(phase*1.3+j*TAU/3);
    for(let segment=0;segment<3;segment++){
      const center=(segment-1)*L*.47,half=L*.21;
      const axial=amount*(.5+.8*heal)*Math.sin(phase*1.1+j+segment*.9)*(1-.7*focus)*(1-.8*rest-.7*align)+damage*(j===1?1.6:-.3)*(segment+1)+collapse*(1-segment)*2.3+impact*(segment-1)*1.1+working*(segment-1)*1.5+charging*.55*Math.sin(phase*1.6+segment*1.1+j)+scan*.9*Math.sin(phase+segment*1.7)+align*(segment-1)*.65;
      const shellRadius=radius*(.76+.08*Math.cos(segment*Math.PI))+(1-dep)*.7+working*2.5+charging*.5-encase*.34+scan*(segment===1?1.7:.45)+brace*.65-rest*.3;
      const y0=center-half+axial,y1=center+half+axial;
      const width=(segment===1?.42:.31)+encase*.72-working*.05;
      const raw=[radial(angle-width,shellRadius*.74,y0),radial(angle-width*.75,shellRadius,y0+half*.4),radial(angle-width*.5,shellRadius,y1-half*.26),radial(angle,shellRadius*.6,y1),radial(angle+width*.5,shellRadius,y1-half*.26),radial(angle+width*.75,shellRadius,y0+half*.4)];
      const light=.5+.5*Math.cos(angle+yaw-1.05);
      face(`shell-${j}-${segment}`,raw,color(65+108*light),{stroke:color(98+104*light),width:.3});
      const ridge=raw.map(p=>p.slice());ridge[0]=radial(angle,shellRadius*1.10,y0+1.1);ridge[3]=radial(angle,shellRadius*.87,y1-1);
      face(`bevel-${j}-${segment}`,[ridge[0],raw[1],raw[2],ridge[3]],color(42+96*light));
      if(h.metalHighlights&&h.highlightStrength>0)line(`shine-${j}-${segment}`,[raw[1],raw[2]],'#edf2f0',.4,h.highlightStrength*(.3+.7*light));
      // V9: one recessed machining channel in each middle rail. It belongs
      // to the existing metal face, with a small specular lip following that
      // face's turning normal. No sprite-wide sheen, new silhouette or glow.
      if(r.signatureCraft&&segment===1&&h.metalHighlights&&h.highlightStrength>0){
        const mix=(a,b,t)=>a.map((n,k)=>n+(b[k]-n)*t);
        const lo=mix(raw[1],raw[5],.35),hi=mix(raw[2],raw[4],.35);
        const inset=[mix(lo,hi,.18),mix(lo,hi,.81)];
        line(`machined-recess-${j}`,inset,'#182233',.52,h.highlightStrength*.66);
        const glint=.22+.78*Math.pow(light,5);
        line(`machined-lip-${j}`,[mix(raw[1],raw[2],.21),mix(raw[1],raw[2],.68)],'#f4e5d4',.48,h.highlightStrength*glint);
      }
      if(segment===1&&charge>.03)line(`seam-${j}`,[radial(angle,shellRadius*1.06,-2.5+axial),radial(angle,shellRadius*1.06,2.6+axial)],'#ff9cf0',.34,charge*.72);
    }
  }
  // Each vane is a thin solid blade on its own counter-orbit, suspended clear
  // of the housing. Their trajectories are helical, never a pinch gesture.
  const orbitClock=r.orbit??0;
  const orbit=orbitClock+(.55*drive-.65*quiet-.75*collapse)*Math.sin(orbitClock*.7),program=r.program??'poised';
  const stateOrbit=orbit-(.72*brace+.85*rest)*Math.sin(orbit);
  for(let j=0;j<3;j++){
    const a=j*TAU/3-stateOrbit*(program==='seraph'?.74:1.17)+.5+align*.13*Math.sin(phase*.4+j);
    const bob=amount*(program==='seraph'?2.1:1.1)*Math.sin(phase*.84+j*TAU/3)*(1-.8*brace-.85*rest)+conduct*2*Math.sin(phase*1.8+j*TAU/3);
    const vr=radius+1.5+focus*.7+drive*.9-quiet*.75-collapse*.8+impact*.9+working*2.6+guarding*1.1-encase*1.8+brace*1.6+scan*.85-rest*.9;
    const sweep=(program==='seraph'?L*.2:0)+collapse*3+damage*(j===1?2:0);
    const length=L*(program==='seraph'?.65:.49);
    const vane=[radial(a-.14,vr*.8,-length+bob+sweep),radial(a+.09,vr+1,-length*.33+bob),radial(a+.16,vr,length*.6+bob),radial(a+.03,vr*.8,length+bob-sweep),radial(a-.12,vr*.9,length*.44+bob),radial(a-.19,vr*.86,-length*.25+bob)];
    const light=.5+.5*Math.cos(a+yaw-1.1);
    face(`vane-${j}`,vane,color(58+122*light),{stroke:color(92+115*light),width:.34});
    face(`vane-gold-${j}`,[vane[0],vane[1],radial(a+.03,vr*.95,-length*.46+bob)],'#b8a784');
    line(`vane-energy-${j}`,[radial(a+.17,vr+.15,-length*.23+bob),radial(a+.18,vr+.10,length*.48+bob)],'#ef6add',.36,charge*(.38+.3*focus));
  }
  // Two elliptical gimbals precess on opposing axes; split into short depth
  // sorted segments so the core really passes in front of and behind them.
  for(let ring=0;ring<2;ring++){
    const angle=(ring?-.55:.55)+amount*.35*Math.sin(phase*.65+ring*Math.PI)*(1-.8*guarding)*(1-.8*align-.8*brace)+guarding*(ring?-.27:.27)+align*(ring?.42:-.42);
    const rr=radius+1.15+ring*.5+guarding*1.4+working*.65+brace*.8,yy=(ring?1:-1)*(2.5-1.3*focus+charging*1.9)+scan*L*.4*Math.sin(phase*.7+ring*.5)+conduct*1.1*Math.sin(phase*1.7+ring*Math.PI);
    const sine=Math.sin(angle),cosine=Math.cos(angle);
    const vertices=GIMBAL_TOPOLOGY.vertices.map(([c,s])=>{const z=s*rr;return project([c*rr,yy+z*sine,z*cosine]);});
    for(let i=0;i<24;i++){
      const edge=GIMBAL_TOPOLOGY.edges[i],t=edge.angle,points=[vertices[edge.first],vertices[edge.last]],z=(points[0][2]+points[1][2])/2;
      parts.push({id:`gimbal-${ring}-${i}`,points,z,fill:null,alpha:.8,stroke:'#8997aa',width:.35});
      const current=t+(ring?-1:1)*orbit*1.8;
      const packet=(current%TAU+TAU)%TAU;
      if(packet<.78)parts.push({id:`bearing-current-${ring}-${i}`,points,z,fill:null,alpha:charge*.9,stroke:'#ffc5f4',width:.56});
    }
  }
  // Counter-rotating faceted crystal: four front/back triangular faces on
  // either side of a narrow equator, with a floating core inside the rails.
  const spin=h.suspendedCore?(h.coreAngle??0)-yaw*.62+amount*.36*Math.sin(phase*.83):0;
  const coreRadius=h.design==='shielded'?2.5:h.design==='spine'?1.35:1.9;
  const coreLength=L*.52,ordinaryFloat=h.suspendedCore?amount*.65*Math.sin(phase*.91):0;
  const coreFloat=r.scanExtension==null?ordinaryFloat:ordinaryFloat+r.scanExtension;
  const coreTurn=rotation(spin,0,amount*.035*Math.sin(phase*.7));
  const coreProject=p=>coreTurn(p).map((v,i)=>i===1?v+coreFloat:v);
  const top=coreProject([0,-coreLength,0]),bottom=coreProject([0,coreLength,0]);
  const diamond=Array.from({length:6},(_,i)=>coreProject(radial(i/6*TAU,coreRadius,-.7)));
  // The twelve crystal facets meet at eight physical corners. Project each
  // corner once for this sample, retaining independent face arrays below.
  const projectedTop=project(top),projectedBottom=project(bottom),projectedDiamond=diamond.map(project);
  const colors=['#fac2f4','#d25cc6','#823483','#572754','#983991','#f195e4'];
  const coreDepth=h.coreDepth===true?unit(Number.isFinite(h.coreDepthStrength)?h.coreDepthStrength:.35):0;
  const depthPhase=r.animated===false?0:phase;
  const crystalFacets=[];
  for(let i=0;i<6;i++){
    projectedFace(`core-upper-${i}`,[projectedTop,projectedDiamond[i],projectedDiamond[(i+1)%6]],colors[i],{alpha:.52+.48*unit(h.power)});
    crystalFacets.push(parts.at(-1));
    if(coreDepth>0)parts.push(...internalCoreDepth(parts.at(-1),{strength:coreDepth,phase:depthPhase,index:i,yaw}));
    projectedFace(`core-lower-${i}`,[projectedBottom,projectedDiamond[(i+1)%6],projectedDiamond[i]],colors[(i+2)%6],{alpha:.52+.48*unit(h.power)});
    crystalFacets.push(parts.at(-1));
    if(coreDepth>0)parts.push(...internalCoreDepth(parts.at(-1),{strength:coreDepth,phase:depthPhase,index:i+6,yaw}));
  }
  if(r.v7Interior?.strength>0){
    // Existing facets become the translucent outer skin. Their vertex positions,
    // metal housing, original ridges and depth remain exactly where they were.
    const depths=crystalFacets.map(p=>p.z).sort((a,b)=>a-b),middle=(depths[5]+depths[6])*.5;
    // A rotating face must not suddenly double its opacity when two centroid
    // depths trade places. Retain the established front/rear material away
    // from their short shared passage, joining it with zero endpoint slopes.
    const passage=Math.max(.025,(depths.at(-1)-depths[0])*.12);
    for(const facet of crystalFacets){
      const p=unit(.5+(facet.z-middle)/(2*passage)),facing=p*p*(3-2*p);
      facet.alpha*=1-r.v7Interior.strength*(.22+.66*facing);
    }
    parts.push(...v7GemInteriorGeometry({sample:r.v7Interior,project,radius:coreRadius,length:coreLength,
      float:coreFloat,spin,facets:crystalFacets.map(p=>p.points),resonance:r,power:h.power}));
  }
  line('core-ridge',[top,diamond[1],bottom],'#ffe2f7',.3,.8);
  // Distinct repair travel along successive shell segments is visible even
  // when body placement is held still. Suppression naturally dims these.
  if(heal>0){
    const scan=(conditionPhase*.4%1+1)%1,y=-L*.72+scan*L*1.44;
    const points=Array.from({length:25},(_,i)=>radial(i/24*TAU,radius*.94,y));
    line('repair-scan',points,'#fff0fa',.7,heal*charge*.9);
  }
  // Situation states use the existing solid mechanism and add only small
  // local marks: a scanning lens, braced triangle, alignment ticks or current.
  if(coreMarkStyle==='v10')v10CoreMarks({line,radial,phase,radius,L,charge,encase,working,charging,guarding,settle:state.settle??0,scan,brace,align,rest,conduct});
  else{
  if(scan>0){const y=Math.sin(phase*.72)*L*.55;line('diagnostic-lens',Array.from({length:17},(_,i)=>radial(i/16*TAU,radius+2.5,y)),'#ffd6f7',.48,scan*charge*.62);}
  if(brace>0){const points=Array.from({length:4},(_,i)=>radial(i/3*TAU+.5,radius+3,0));line('brace-lock',points,'#eab8dd',.56,brace*charge*.55);}
  if(align>0)for(let i=0;i<3;i++){const a=i*TAU/3+.5;line(`alignment-tick-${i}`,[radial(a,radius+1,-L*.35),radial(a,radius+1,L*.35)],'#e8d9c0',.45,align*charge*.55);}
  if(conduct>0)for(let j=0;j<3;j++){const points=Array.from({length:9},(_,i)=>{const f=i/8,turn=h.lanternPowering?.32*Math.sin(phase*.8):phase*.8;return radial(j*TAU/3+turn+f*.9,radius+2.2,-L*.65+f*L*1.3);});line(`conductor-current-${j}`,points,'#ffd7f7',.55,conduct*charge*(.4+.25*Math.sin(phase*1.6+j)**2));}
  }
  return parts.sort((a,b)=>a.z-b.z);
}

const projectionColor=value=>{
  if(/^#[\da-f]{6}$/i.test(value??''))return [1,3,5].map(i=>Number.parseInt(value.slice(i,i+2),16));
  const match=/^rgb\((\d+(?:\.\d+)?),(\d+(?:\.\d+)?),(\d+(?:\.\d+)?)\)$/.exec(value??'');return match?match.slice(1).map(Number):null;
};
function blendProjectionColor(a,b,weight){
  if(a===b)return a;const first=projectionColor(a),last=projectionColor(b);
  return first&&last?`rgb(${first.map((v,i)=>Math.round(v+(last[i]-v)*weight)).join(',')})`:b??a;
}
/** A dedicated projector opens the familiar shell around a working gem.
 * Slow aperture currents replace the idle rail/vane counter-orbits. Shape
 * interpolation happens after projection, so entering at an hours-long idle
 * phase or leaving a long hold cannot rephase the accumulated machinery. */
export function resonantBitGeometry(h){
  const bridge=h.scanResume;if(!bridge)return sampleWorkingBitGeometry(h);
  const weight=unit(bridge.weight);if(!weight||!Array.isArray(bridge.geometry))return sampleWorkingBitGeometry(h);
  const r=h.resonance??{};
  // Condition modifiers may run after an action builds its local handoff.
  // A saved healthy picture cannot replace those current authoritative
  // channels. Healing is the intentional new work that this short bridge
  // joins; injury, lost power and mechanical opt-outs bypass it immediately.
  const changedMotion=bridge?.expectedMotion&&['amount','mechanical','charge'].some(key=>bridge.expectedMotion[key]!==r[key]);
  const reaction=['damage','instability','glitch','suppression','collapse','impact','drive'].some(key=>(r[key]??0)>0);
  if(r.animated===false||(r.mechanical??r.amount??0)<=0||changedMotion||reaction)return sampleWorkingBitGeometry(h);
  if(weight===1)return bridge.geometry;
  return blendResonantGeometry(sampleWorkingBitGeometry(h),bridge.geometry,weight);
}

function sampleWorkingBitGeometry(h){
  const lantern=h.lantern,weight=unit(lantern?.weight);
  if(!weight||!lantern.projection){
    const r=h.resonance??{},cue=r.animated!==false&&(r.mechanical??r.amount??0)>0?sampleScanMechanism(r.coreState?.examination):null;
    if(!cue?.weight)return sampleResonantBitGeometry(h);
    const strength=unit(r.mechanical??r.amount);
    // The physical bit carries the viewing turn. Accumulating its view index
    // here also rolled the crystal, orbited the vanes and wobbled the housing
    // on unrelated axes, making a stationary reader look restless. Hold one
    // familiar aligned projection and give its core only an axial read stroke.
    const target={...h,coreAngle:0,resonance:{...r,phase:0,amount:0,
      yaw:0,tilt:0,precession:0,orbit:.27,scanExtension:strength*.35*cue.stroke,
      ...(r.v7Interior?{v7Interior:{...r.v7Interior,clock:cue.opening*.8+cue.stroke*.18}}:{}),
      coreState:{...r.coreState,...cue.channels}}};
    // Conditions keep their ordinary mechanical clock while the healthy
    // examination pose replaces idle precession and counter-orbits.
    const reactions=['healing','damage','glitch','suppression','collapse','impact','drive'];
    if(reactions.some(key=>(r[key]??0)>0))target.resonance.conditionPhase=r.conditionPhase??r.phase;
    const projected=sampleResonantBitGeometry(target);
    return cue.weight===1?projected:blendResonantGeometry(sampleResonantBitGeometry(h),projected,cue.weight);
  }
  const original=lantern.original??h,projection={...original,...lantern.projection,lantern:null,...(lantern.powering?{lanternPowering:true}: {})};
  const target=sampleResonantBitGeometry(projection),phase=lantern.phase??0;
  const pulse=.5+.5*Math.sin(phase),rimRadius=5.4+.65*pulse;
  const add=(id,points,alpha,width)=>target.push({id,points,z:12,fill:null,alpha,stroke:'#ffd8f7',width});
  add('lantern-focus-aperture',Array.from({length:33},(_,i)=>{
    const a=i/32*TAU;return [Math.cos(a)*rimRadius,Math.sin(a)*(2.1+.6*pulse),12];
  }),.28+.08*pulse,.4);
  for(const lane of [-1,1])add(`lantern-projector-filament-${lane}`,Array.from({length:17},(_,i)=>{
    const p=i/16,y=-8.3+p*16.6,x=lane*(2.45+.55*Math.sin(phase+p*Math.PI));return [x,y,12];
  }),.26+.10*(.5+.5*Math.sin(phase+lane*.8)),.36);
  if(lantern.powering){
    // Short packets rise along the familiar spindle, behind its forward
    // emission. Metal and gemstone retain their original solid topology.
    for(let packet=0;packet<3;packet++){
      const p=((phase/TAU+packet/3)%1+1)%1,y=4-p*8,half=1.7+.9*Math.sin(Math.PI*p);
      add(`lantern-power-transfer-${packet}`,[[-half,y,12],[0,y-1.1,12],[half,y,12]],
        lantern.powering.strength*Math.sin(Math.PI*p)*.72,.7);
    }
  }
  if(weight===1)return target.sort((a,b)=>a.z-b.z);
  return blendResonantGeometry(sampleResonantBitGeometry(original),target,weight);
}

/** Share the existing projector's face interpolation. Scan acquisition and
 * release use this same bounded entrance rather than resetting idle phase. */
function blendResonantGeometry(source,target,weight){
  const targets=new Map(target.map(p=>[p.id,p])),out=[],clipBlends=new Map();
  const blendClip=(first,last)=>{
    let clips=clipBlends.get(first);if(!clips){clips=new Map();clipBlends.set(first,clips);}
    if(!clips.has(last))clips.set(last,first.map((face,i)=>face.map((point,j)=>point.map((v,axis)=>v+(last[i][j][axis]-v)*weight))));
    return clips.get(last);
  };
  for(const first of source){
    const last=targets.get(first.id);targets.delete(first.id);
    if(!last||first.points.length!==last.points.length){out.push({...first,alpha:first.alpha*(1-weight)});if(last)out.push({...last,alpha:last.alpha*weight});continue;}
    out.push({...last,points:first.points.map((p,i)=>p.map((v,axis)=>v+(last.points[i][axis]-v)*weight)),
      z:first.z+(last.z-first.z)*weight,alpha:first.alpha+(last.alpha-first.alpha)*weight,
      width:first.width+(last.width-first.width)*weight,fill:blendProjectionColor(first.fill,last.fill,weight),
      stroke:blendProjectionColor(first.stroke,last.stroke,weight),
      ...(first.clipFaces&&last.clipFaces?{clipFaces:blendClip(first.clipFaces,last.clipFaces)}:{})});
  }
  for(const last of targets.values())out.push({...last,alpha:last.alpha*weight});
  return out.sort((a,b)=>a.z-b.z);
}

/** v10: token-size legibility. At a hundred pixels a token, a bit is about
 * seventeen pixels tall and its pale satin metal melted into portraits and
 * light maps. One dark keyline under every solid face (a single path, one
 * stroke) gives the instrument a crisp steel silhouette on any background. */
function paintKeyline(ctx,parts,strength){
  let any=false;ctx.beginPath();
  for(const p of parts){
    if(!p.fill||p.clipFaces||p.alpha<.3||p.parent)continue;
    const points=p.points;any=true;
    ctx.moveTo(points[0][0],points[0][1]);for(let i=1;i<points.length;i++)ctx.lineTo(points[i][0],points[i][1]);ctx.closePath();
  }
  if(!any)return;
  ctx.save();
  // A soft smoky backing, the shape of the housing, separates the steel from
  // bright stone and parchment maps. One gradient per painted frame.
  const shade=ctx.createRadialGradient(0,0,0,0,0,1);shade.addColorStop(0,'rgba(20,11,23,.42)');shade.addColorStop(.6,'rgba(20,11,23,.22)');shade.addColorStop(1,'rgba(20,11,23,0)');
  ctx.save();ctx.scale(8.5,23);ctx.globalAlpha=strength;ctx.fillStyle=shade;ctx.fillRect(-1,-1,2,2);ctx.restore();ctx.globalAlpha=strength*.7;ctx.lineJoin='round';ctx.strokeStyle='#140b17';ctx.lineWidth=1.7;ctx.stroke();ctx.restore();
}
/** v10: the magenta core line, drawn as hardlight that shines through the
 * gaps of the housing, so the signature line survives minification. Its
 * power follows the existing core charge (suppressed or collapsed bits dim). */
function paintCoreLine(ctx,parts,strength,energy){
  if(energy<=.02)return;
  const ridge=parts.find(p=>p.id==='core-ridge');if(!ridge)return;
  const [top,,bottom]=ridge.points,lerp=(t,i)=>top[i]+(bottom[i]-top[i])*t;
  ctx.save();ctx.lineCap='round';ctx.globalCompositeOperation='lighter';
  ctx.beginPath();ctx.moveTo(lerp(.1,0),lerp(.1,1));ctx.lineTo(lerp(.9,0),lerp(.9,1));
  ctx.globalAlpha=strength*energy*.45;ctx.strokeStyle='#e767ce';ctx.lineWidth=1.6;ctx.stroke();
  ctx.globalAlpha=strength*energy*.85;ctx.strokeStyle='#ff9ae9';ctx.lineWidth=.75;ctx.stroke();
  ctx.beginPath();ctx.moveTo(lerp(.22,0),lerp(.22,1));ctx.lineTo(lerp(.78,0),lerp(.78,1));
  ctx.globalAlpha=strength*energy*.55;ctx.strokeStyle='#fff0fb';ctx.lineWidth=.28;ctx.stroke();
  ctx.restore();
}

export function paintResonantBit(ctx,part){
  const h=part.hardware;if(h.artwork!=='resonant')return false;
  const [[cx,cy]]=part.points;
  ctx.save();ctx.translate(cx,cy);ctx.rotate(h.angle);ctx.scale(h.scale,h.scale);
  paintBitEnergy(ctx,part,'back');
  const clipCache=new Map(),Path=globalThis.Path2D;let activeClip=null;
  let alpha,fill,stroke,width;
  const geometry=resonantBitGeometry(h),legible=bitOutline;
  if(legible)paintKeyline(ctx,geometry,part.strength);
  for(const p of geometry){
    const wanted=p.clipFaces??null;
    // Keep the exact depth painter order. Only adjacent parts sharing the
    // same crystal volume retain its clip; metal/facets close the group before
    // drawing. One reusable path avoids rebuilding its outline on re-entry.
    if(wanted!==activeClip){
      if(activeClip){ctx.restore();alpha=fill=stroke=width=undefined;}activeClip=wanted;
      if(wanted){
        let clip=clipCache.get(wanted);
        if(!clip){
          const outline=projectedCrystalOutline(wanted);let path=null;
          if(typeof Path==='function'){
            path=new Path();outline.forEach(([x,y],i)=>i?path.lineTo(x,y):path.moveTo(x,y));path.closePath();
          }
          clip={outline,path};clipCache.set(wanted,clip);
        }
        ctx.save();
        if(clip.path)ctx.clip(clip.path);
        else {ctx.beginPath();clip.outline.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.clip();}
      }
    }
    const opacity=part.strength*p.alpha;if(alpha!==opacity){ctx.globalAlpha=opacity;alpha=opacity;}
    ctx.beginPath();
    for(let i=0;i<p.points.length;i++){const point=p.points[i];if(i)ctx.lineTo(point[0],point[1]);else ctx.moveTo(point[0],point[1]);}
    if(p.fill){ctx.closePath();if(fill!==p.fill){ctx.fillStyle=p.fill;fill=p.fill;}ctx.fill();}
    if(p.stroke){if(stroke!==p.stroke){ctx.strokeStyle=p.stroke;stroke=p.stroke;}if(width!==p.width){ctx.lineWidth=p.width;width=p.width;}ctx.stroke();}
  }
  if(activeClip)ctx.restore();
  if(legible)paintCoreLine(ctx,geometry,part.strength,unit(h.power??1)*unit(h.resonance?.charge??1));
  paintBitEnergy(ctx,part,'front');ctx.restore();return true;
}
