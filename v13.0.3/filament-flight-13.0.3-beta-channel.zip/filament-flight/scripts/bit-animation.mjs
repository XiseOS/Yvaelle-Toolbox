/** Deterministic animation sampling. The actual pictures live in assets/bits;
 * this selects their frames from the existing flight/effect clock. */
import {unit} from './poses.mjs?v=13.0.3';
export const BIT_ATLAS=Object.freeze({width:128,height:192,columns:16,rows:16,frames:16,
  clips:['idle','travel','guard','crown','damaged','unstable','glitching','overdrive','suppressed','collapsed','recovery','formation'],
  components:{core:12,shutters:13,sheen:14,energy:15},designs:['vanes','shielded','spine']});
// Larger frames are divided by track; no client needs to decode a giant atlas.
export const BIT_HD=Object.freeze({width:256,height:384,columns:8,rows:2,
  tracks:[...BIT_ATLAS.clips,'core','shutters','sheen','energy'],maxPages:24,retainMs:1500});
const DURATION={idle:2.4,travel:1.4,guard:2.4,crown:2.8,damaged:2,unstable:1.6,glitching:1.2,overdrive:1,suppressed:2.8,collapsed:2.8,recovery:1.8};
const wrap=n=>(n%1+1)%1;
export function bitFrame(clip,time=0,animated=true,progress=null){
  const frame=progress==null?(animated?wrap(time/(DURATION[clip]??2.4))*16:0):unit(progress)*15;
  const a=Math.floor(frame),b=progress==null?(a+1)%16:Math.min(15,a+1);
  return {a,b,mix:frame-a};
}
export function sampleBitAnimation({flight,channels,side,index,time,deployment,animated}){
  const cfg=flight.gems,c=channels,live=animated&&cfg.strength>0;
  // No advancing phase survives the animation/reduced-motion/zero-amount gates.
  const clock=live?time+index*.43+(side>0?.19:0):0;
  const weights=flight.poseAnimation?.tipWeights??flight.poseAnimation?.weights??[1];
  let layers=[{clip:'idle',weight:1}];
  const blend=(clip,amount)=>{amount=Number.isFinite(amount)?unit(amount):0;if(amount<=.0001)return;for(const l of layers)l.weight*=1-amount;layers.push({clip,weight:amount});};
  if(cfg.assetStates){
    const guard=(weights[1]??0)+(weights[2]??0)+(weights[10]??0)+
      (side<0?(weights[3]??0):(weights[4]??0));
    blend('travel',unit(flight.movement?.sweep??0));
    blend('guard',guard);blend('crown',weights[6]??0);blend('collapsed',weights[8]??0);
    if(cfg.mechanicalResponse){
      blend('damaged',c.damage/.2);blend('unstable',(c.instability-.18)/.32);
      blend('glitching',(c.glitch-.4)/.4);blend('overdrive',c.overdrive);
      blend('suppressed',c.suppression);blend('collapsed',c.collapse);
    }
    if(cfg.repairFocus&&live)blend('recovery',c.heal);
    if(deployment<.999){layers=[{clip:'formation',weight:1}];}
  }
  // Three contributions bound work even when interrupted conditions overlap.
  layers=layers.filter(l=>l.weight>.005).sort((a,b)=>b.weight-a.weight).slice(0,3);
  const sum=layers.reduce((n,l)=>n+l.weight,0)||1;
  return {layers:layers.map(l=>({...l,weight:l.weight/sum,row:BIT_ATLAS.clips.indexOf(l.clip),
      ...bitFrame(l.clip,clock,live,l.clip==='formation'?deployment:null)})),
    core:bitFrame('idle',clock,live),sheen:bitFrame('idle',clock*.6,live),
    animated:live,dominant:layers[0]?.clip??'idle'};
}
