/** The ⋯ at the end of the Keepsake tab bar: what this tab shows, which tabs
 * there are and what the sidebar shows, plus who sees the Keepsake sheet.
 * Switching a field off hides it at once and the rest glide into place. */
import {SHEET_TABS,SHEET_FIELDS,SIDE_FIELDS,HEAD_FIELDS,fieldKey} from './model.mjs?v=13.0.0-beta.7';
import {hiddenFields,hiddenScope,canEditFields,setHiddenFields,sheetMode,setSheetMode,canChooseEveryone,herActorId} from './prefs.mjs?v=13.0.0-beta.7';
import {activeTab,prepareGlide,tabLabel} from './dress.mjs?v=13.0.0-beta.7';
import {iconHTML} from './sprite.mjs?v=13.0.0-beta.7';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const el=x=>x?.[0]??x??null;
const open=new WeakMap();

export function toggleSheetMenu(app,button){
  const root=el(app.element);if(!root)return;
  const existing=root.querySelector(':scope > .ffks-menu');
  if(existing){closeMenu(app);return;}
  const menu=root.ownerDocument.createElement('div');menu.className='ffks-menu';menu.setAttribute('role','dialog');menu.setAttribute('aria-label','What her sheet shows');
  root.append(menu);
  const place=()=>{const b=button.getBoundingClientRect(),r=root.getBoundingClientRect();
    menu.style.top=`${Math.round(b.bottom-r.top+8)}px`;menu.style.right=`${Math.max(14,Math.round(r.right-b.right-6))}px`;};
  place();
  const away=event=>{if(!menu.contains(event.target)&&!event.target.closest?.('.ffks-menu-btn'))closeMenu(app);};
  const key=event=>{if(event.key==='Escape'){event.stopPropagation();event.preventDefault();closeMenu(app);button.focus?.();}};
  root.ownerDocument.addEventListener('pointerdown',away,true);root.ownerDocument.addEventListener('keydown',key,true);
  open.set(app,{menu,away,key,place});
  button.setAttribute('aria-expanded','true');
  draw(app);
  menu.querySelector('button')?.focus?.({preventScroll:true});
}
export function closeMenu(app){
  const o=open.get(app);if(!o)return;open.delete(app);
  o.menu.ownerDocument.removeEventListener('pointerdown',o.away,true);o.menu.ownerDocument.removeEventListener('keydown',o.key,true);
  o.menu.classList.add('closing');setTimeout(()=>o.menu.remove(),160);
  el(app.element)?.querySelector('.ffks-menu-btn')?.setAttribute('aria-expanded','false');
}
/** Redraw an open menu (after a switch, or when another screen changes her sheet). */
export function redrawMenu(app){if(open.has(app))draw(app);}

function sw(on,key,name,icon,{locked=false,disabled=false}={}){
  return `<div class="ffks-trow${on?'':' off'}"><span class="n">${icon?iconHTML(icon,'s14'):''}${esc(name)}</span><button type="button" class="ffks-switch${on?' on':''}${locked||disabled?' locked':''}" role="switch" aria-checked="${on}" aria-label="${on?'Hide':'Show'} ${esc(name)}${locked?' (always shown)':''}" data-key="${esc(key)}" ${locked||disabled?'disabled':''}></button></div>`;
}
function draw(app){
  const o=open.get(app);if(!o)return;
  const focused=o.menu.contains(o.menu.ownerDocument.activeElement)?o.menu.ownerDocument.activeElement:null,focusKey=focused?.dataset?.key??focused?.dataset?.mode??null;
  const actor=app.actor,hidden=hiddenFields(actor),tab=activeTab(app),editable=canEditFields(actor),scope=hiddenScope(actor);
  const fields=SHEET_FIELDS[tab]??[],tabName=tabLabel(tab),tabIcon=SHEET_TABS.find(t=>t[0]===tab)?.[2]??'tab-module';
  const tabHidden=fields.filter(f=>hidden[fieldKey(tab,f[0])]).map(f=>fieldKey(tab,f[0]));
  const mode=actor?.id===herActorId()||scope==='everyone'?sheetMode(actor):'me';
  const modes=[['off','Off'],['me','Just me'],['everyone','Everyone']].map(([id,label])=>{
    const dis=id==='everyone'&&!canChooseEveryone(actor);
    return `<button type="button" class="${mode===id?'on':''}" role="radio" aria-checked="${mode===id}" data-mode="${id}" ${dis?'disabled title="Only her owner can choose this"':''}>${esc(label)}</button>`;}).join('');
  o.menu.innerHTML=`<div class="ffks-menu-cols">
<div><div class="ffks-sec-h sm">${iconHTML(tabIcon,'s14')}<span class="t">On ${esc(tabName)}</span><span class="ffks-line"></span>${tabHidden.length&&editable?`<button type="button" class="ffks-tbtn sm" data-show-all>${iconHTML('ui-eye','s12')}Show all</button>`:''}</div>
${fields.length?fields.map(f=>sw(!hidden[fieldKey(tab,f[0])],fieldKey(tab,f[0]),f[1],f[2],{disabled:!editable})).join(''):'<span class="ffks-note">Nothing to switch off on this tab.</span>'}
<span class="ffks-note small">Each tab keeps its own list. What you hide here stays hidden on her sheet for ${scope==='everyone'?'everyone who sees her Keepsake sheet':'you, on this browser'}.</span></div>
<div><div class="ffks-sec-h sm">${iconHTML('tab-character','s14')}<span class="t">Tabs</span><span class="ffks-line"></span></div>
${SHEET_TABS.filter(([id])=>el(app.element)?.querySelector(`nav.sheet-navigation a.item[data-tab="${id}"]:not(.hidden)`)).map(([id,,icon])=>sw(id==='character'||!hidden[fieldKey('tab',id)],fieldKey('tab',id),tabLabel(id),icon,{locked:id==='character',disabled:!editable})).join('')}
${el(app.element)?.querySelector('nav.sheet-navigation a.manage-tabs')?`<button type="button" class="ffks-tbtn sm ffks-menu-pf2e" data-pf2e-tabs style="margin-top:8px">${iconHTML('ui-list','s12')}PF2e’s own tab list…</button>`:''}</div>
<div><div class="ffks-sec-h sm">${iconHTML('ft-class','s14')}<span class="t">Header</span><span class="ffks-line"></span></div>
${HEAD_FIELDS.map(([k,name])=>sw(!hidden[fieldKey('head',k)],fieldKey('head',k),name,null,{disabled:!editable})).join('')}
<div class="ffks-sec-h sm" style="margin-top:12px">${iconHTML('st-ac','s14')}<span class="t">Sidebar</span><span class="ffks-line"></span></div>
${SIDE_FIELDS.map(([k,name])=>sw(!hidden[fieldKey('side',k)],fieldKey('side',k),name,null,{disabled:!editable})).join('')}
<div class="ffks-sec-h sm" style="margin-top:12px">${iconHTML('ui-swap','s14')}<span class="t">Keepsake sheet</span><span class="ffks-line"></span></div>
<div class="ffks-seg" role="radiogroup" aria-label="Who sees her Keepsake sheet">${modes}</div>
<span class="ffks-note small">${mode==='everyone'?'Everyone who opens her sheet sees it like this.':mode==='me'?'Only you see it like this. Everyone else sees PF2e’s sheet.':'Off: her sheet is PF2e’s own.'}</span>
<button type="button" class="ffks-tbtn" data-portrait style="margin-top:8px" ${actor?.isOwner?'':'hidden'}>${iconHTML('ui-image','s14')}Portrait studio…</button></div>
</div>`;
  o.menu.onclick=event=>onClick(app,event);
  if(focusKey)o.menu.querySelector(`[data-key="${CSS.escape(focusKey)}"],[data-mode="${CSS.escape(focusKey)}"]`)?.focus?.({preventScroll:true});
}
async function onClick(app,event){
  const t=event.target.closest('button');if(!t||t.disabled)return;event.preventDefault();event.stopPropagation();
  const actor=app.actor;
  try{
    if(t.dataset.key){prepareGlide(app);peek(app);await setHiddenFields(actor,[t.dataset.key]);settle(app);return;}
    if(t.hasAttribute('data-show-all')){const hidden=hiddenFields(actor),tab=activeTab(app);
      const keys=(SHEET_FIELDS[tab]??[]).map(f=>fieldKey(tab,f[0])).filter(k=>hidden[k]);if(!keys.length)return;
      prepareGlide(app);peek(app);await setHiddenFields(actor,keys);settle(app);return;}
    if(t.dataset.mode){const mode=t.dataset.mode;closeMenu(app);await setSheetMode(mode,actor);
      ui.notifications?.info?.(mode==='off'?'Keepsake sheet off · her sheet is PF2e’s own again.':mode==='me'?'Keepsake sheet · just you, on this browser.':'Keepsake sheet · everyone who opens her sheet sees it.');return;}
    if(t.hasAttribute('data-portrait')){closeMenu(app);const m=await import('./studio.mjs?v=13.0.0-beta.7');m.openPortraitStudio(actor);return;}
    // PF2e's own tab manager (its button is folded into the ⋯)
    if(t.hasAttribute('data-pf2e-tabs')){closeMenu(app);el(app.element)?.querySelector('nav.sheet-navigation a.manage-tabs')?.click();}
  }catch(e){ui.notifications?.error?.(e?.message??String(e));}
}
/** After a switch the menu thins for a moment, so she sees the fields under it glide into place. */
function peek(app){
  const o=open.get(app),root=el(app.element);if(!o||!root||root.classList.contains('ffks-fm-off'))return;
  if(root.ownerDocument.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches)return;
  o.menu.classList.add('ffks-peek');clearTimeout(o.peekTimer);o.peekTimer=setTimeout(()=>o.menu.classList.remove('ffks-peek'),760);
}
/** The client setting's change re-applies on every open sheet; this redraws the menu either way. */
function settle(app){
  // "Just me": the setting's change re-applies on every open sheet (with the glide).
  // "Everyone": her actor changes and PF2e re-renders the sheet; the glide plays after it.
  redrawMenu(app);
}
