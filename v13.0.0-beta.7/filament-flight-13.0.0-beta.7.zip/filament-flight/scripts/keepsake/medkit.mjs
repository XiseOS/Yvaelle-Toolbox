/** Ellie's Medkit window: its own square window, separate from the HUD.
 * Patients as medallions with health estimates (never HP numbers), the
 * treatment as a few plain dropdowns, the hardlight technique previewed live,
 * and a wax seal that treats. All rules run in the Medkit engine; this view
 * only gathers the choices and shows each patient's progress and result. */
import {DCLogic} from './runtime.mjs?v=13.0.0-beta.7';
import {playMedkitSound,uiSoundsOn,setUiSounds} from './medkit-sounds.mjs?v=13.0.0-beta.7';
import {medkitView,runMedkitView,splitBits,saveMedkitChoices,partyView,saveMedkitOptions,previewMedkit,stopMedkitPreview} from './medkit-adapter.mjs?v=13.0.0-beta.7';

const OUTCOMES=['success','criticalSuccess','failure','criticalFailure'];
const OUTCOME_NAMES={success:'success',criticalSuccess:'critical success',failure:'failure',criticalFailure:'critical failure'};
const GROUPS=[['original','Original'],['restorative','Restorative'],['legacy','Compact (Legacy)']];
const GAP=2.6;
const ICONS={battleMedicine:'M12 2.5l9.5 9.5-9.5 9.5L2.5 12zM12 7.5v9M7.5 12h9',treatWounds:'M12 3a9 9 0 1 0 0.01 0M12 7v5l3.2 2.2M5 3.5l-1.6 1.6M19 3.5l1.6 1.6',
  directiveOne:'M12 20.5s-7.5-4.6-7.5-10.4A4.2 4.2 0 0 1 12 7.4a4.2 4.2 0 0 1 7.5 2.7c0 5.8-7.5 10.4-7.5 10.4zM6.5 12.5h3l1.6-2.6 2 4.6 1.4-2H18',
  leadByExample:'M8.5 4.5a3 3 0 1 1-0.01 0M16.5 7a2.4 2.4 0 1 1-0.01 0M3 20.5c0-4.2 2.5-6.5 5.5-6.5s5.5 2.3 5.5 6.5M14.5 20.5c0-1.4.3-2.6.8-3.6M15.3 16.9c.7-1.2 1.9-1.9 3.2-1.9 1.9 0 3.5 1.9 3.5 5.5'};
/** Which immunity an action respects. The directive alone has none. */
const immunityKey=mode=>mode==='treatWounds'?'treatWounds':mode==='directiveOne'?null:'battleMedicine';

/** The health ring: one segment per health status, lit up to the patient's. */
function ring(health){
  const n=Math.max(1,health?.levels??5),k=Math.max(0,Math.min(n,health?.level??n)),seg=100/n;
  const one=`${(seg-GAP).toFixed(2)} ${GAP}`;
  return {segBg:Array(n).fill(one).join(' '),segLit:k?`${Array(k).fill(one).join(' ')} 0 100`:'0 100',segRot:(-90+GAP/2*3.6).toFixed(2)};
}
const healthColor=h=>h?.unknown?'#bba99c':`hsl(${h?.hue??125} 62% 64%)`;
const healthGlow=h=>h?.unknown?'rgba(187,169,156,.18)':`hsl(${h?.hue??125} 70% 55% / .22)`;

export class KeepsakeMedkit extends DCLogic {
  constructor(props){super(props);this.memo={};this.selects={};this.state={hint:null,msg:null,msgFail:false,...this.initialState()};}
  get ctx(){return this.props.ctx;}
  get model(){return this.ctx.model;}
  /** Hover hints write straight into the status line (as the HUD's do), so
   * moving across the Medkit's controls never rebuilds the window. Leaving
   * waits a beat, so going from control to control doesn't flash the message. */
  setHint(h){
    const s=this.state;clearTimeout(this.hintTimer);
    if((s.hint?.click??null)===(h?.click??null)){s.hint=h;return;}
    s.hint=h;
    const span=this._host?.container?.querySelector?.('.mk-status > span');
    if(!span){this.forceUpdate();return;}
    if(!h){this.hintTimer=setTimeout(()=>this.forceUpdate(),90);return;}
    span.textContent=h.click;span.setAttribute('style','color: #e6d8c6');span.className=this.sw('foot',h.click);
  }
  bump(key,value){const m=this.memo[key]??(this.memo[key]={v:value,n:0});if(m.v!==value){m.v=value;m.n++;}return m.n;}
  sw(key,value,prefix='sw'){return prefix+(this.bump(key,value)%2);}
  /** An animation class that replays whenever `value` changes, but not on first sight. */
  pulse(key,value,prefix){const n=this.bump(key,value);return n?` ${prefix}${n%2}`:'';}
  initialState(){return {opts:false,o:{},oa:{},party:false,screen:'actions',shift:false,risky:false,mode:null,dc:null,together:null,medicFor:null,style:null,sound:null,scan:null,animate:null,excluded:{},hers:{},
    busy:false,progress:{},results:null,sealDone:0,outcomePreview:0,rk:0,ask:null};}
  /** The view model is rebuilt from the engine when targets, the healer or
   * the table change, but held still while a treatment runs. */
  view(){
    if(this.state.busy&&this.memo.view)return this.memo.view;
    const token=this.model.token,targets=[...(globalThis.game?.user?.targets??[])].filter(t=>t!==token);
    const key=[token?.document?.uuid??'',...targets.map(t=>t.document.uuid)].join('|')+'#'+this.state.rk;
    if(this.memo.viewKey!==key){this.memo.viewKey=key;this.memo.view=null;this.memo.viewError=null;
      try{this.memo.view=medkitView(token,targets);}catch(e){this.memo.viewError=e?.message??String(e);}}
    return this.memo.view;
  }
  field(id,label,value,options,{help='',hint='',disabled=false,change}){
    this.selects[id]={value:String(value??''),options:options.map(o=>({value:String(o.value??''),label:o.label,disabled:!!o.disabled,group:o.group??null})),disabled};
    return {id,label,help,cls:'mk-field'+this.pulse('pick'+id,String(value),'pk'),helpCls:'mk-help'+this.pulse('help'+id,help,'hp'),change:e=>{if(this.state.busy)return;playMedkitSound('choose');change(e.target.value);},enter:()=>this.setHint({click:hint||help})};
  }
  renderVals(){
    const s=this.state,ctx=this.ctx,v=this.view(),token=this.model.token,prefs=v?.prefs??{};
    const note=s.hint?.click??s.msg??(v?'Choose who and how · then press the seal':'The Medkit needs a pinned character');
    const modeAny=v?.modes?.find(m=>m.id===s.mode)??null,mode=modeAny?.available?modeAny:null,onTreat=s.screen==='treat'&&!!modeAny;
    const ik=immunityKey(modeAny?.id),imm=p=>ik?p.immunities?.[ik]??{immune:p.immune,unlabeled:p.unlabeled}:{immune:null,unlabeled:null};
    const usesMedic=ik==='battleMedicine',usesBits=modeAny?.id!=='directiveOne',isDirective=modeAny?.id==='directiveOne';
    const together=s.together??prefs.together??true,style=s.style??prefs.style??'random',sound=s.sound??prefs.sound??true,scan=s.scan??prefs.scan??false;
    const animate=s.animate??prefs.animate??true;
    const patientsAll=v?.patients??[],max=v?.maxPatients??4;
    const chosen=patientsAll.filter(p=>!s.excluded[p.uuid]),inWard=chosen.slice(0,max),overflow=chosen.slice(max);
    const medicFor=usesMedic&&s.medicFor&&inWard.some(p=>p.uuid===s.medicFor)?s.medicFor:null;
    const blocked=p=>!!imm(p).immune||!!imm(p).unlabeled&&!s.hers[p.uuid];
    const treatable=inWard.filter(p=>!blocked(p)||p.uuid===medicFor);
    const shares=onTreat&&usesBits?splitBits(v?.freeBits??4,treatable.map(p=>p.uuid)):{};
    const {progress,results}=s;

    // ---- patients ----
    const patients=patientsAll.map((p,i)=>{
      const out=!!s.excluded[p.uuid],over=!out&&overflow.includes(p),bits=shares[p.uuid]??0,pr=progress[p.uuid],res=results?.find(r=>r.uuid===p.uuid);
      let state='',stateText='',stateCls='mk-state';
      if(out){state='out';stateText='Not treating';stateCls+=' dim';}
      else if(over){state='out';stateText='Next time';stateCls+=' dim';}
      else if(res&&res.directive&&!res.outcome){state='success';stateText='Directive given';stateCls+=' good';}
      else if(res){
        const o=res.outcome;state=res.skipped?'skipped':o==='criticalSuccess'?'crit':o==='success'?'success':o==='criticalFailure'?'critfail':'fail';
        stateText=res.skipped?res.reason??'Skipped':OUTCOME_NAMES[o]??res.label??o;stateText=stateText[0].toUpperCase()+stateText.slice(1);
        stateCls+=res.skipped?' dim':o==='criticalSuccess'?' gold':o==='success'?' good':' bad';
      }else if(pr){state='working';stateText=pr.label??'Bits working';stateCls+=' good';}
      else if(blocked(p)&&p.uuid===medicFor){stateText='Medic reaches past';stateCls+=' medic';}
      else if(!onTreat){
        // the action screen: what each immunity would mean
        const bm=p.immunities?.battleMedicine?.immune??p.immune,tw=p.immunities?.treatWounds?.immune;
        const show=s.shift?tw:bm,label=s.shift?'Treat Wounds':'Battle Medicine';
        if(show){state='immune';stateText=`${label} · ${show.remaining}`;stateCls+=' immune';}
        else if(!s.shift&&(p.immunities?.battleMedicine?.unlabeled??p.unlabeled)){stateText='Unlabeled immunity';stateCls+=' immune';}
        else{stateText='Ready';stateCls+=' good';}
      }
      else if(imm(p).immune){state='immune';stateText=`Immune · ${imm(p).immune.remaining}`;stateCls+=' immune';}
      else if(imm(p).unlabeled&&!s.hers[p.uuid]){state='immune';stateText='Unlabeled immunity';stateCls+=' immune';}
      else if(isDirective){stateText=`+${v?.directiveBonus??0} next healing`;stateCls+=' good';}
      else{stateText=bits?`${bits} bit${bits>1?'s':''}`:v?.animationAvailable===false?'Ready':'Treated without bits';stateCls+=bits||v?.animationAvailable===false?' good':' dim';}
      const shown=state==='out'||state==='immune'?0:bits;
      const bitMarks=Array.from({length:shown},(_,k)=>({style:`transform: rotate(${(k-(shown-1)/2)*24}deg) translateY(var(--mk-bit-r, -58px))`}));
      const heal=res&&!res.skipped&&res.amount?res.amount:0,hurt=res&&!res.skipped&&res.harm?res.harm:0;
      return {...p,cls:`mk-card ${state}`,on:out?'false':'true',clip:`mk-clip-${i}`,img:p.img||ctx.tokenImage,...ring(p.health),
        healthColor:healthColor(p.health),healthGlow:healthGlow(p.health),healthLabel:p.health?.label??'',
        sealed:onTreat&&blocked(p)&&p.uuid!==medicFor&&!res||!!res?.immunity,bits:bitMarks,stateCls,stateText,
        hasFloat:!!res&&!res.skipped&&!res.directive,floatCls:'mk-float '+(hurt?'hurt':heal?(res.outcome==='criticalSuccess'?'crit':'heal'):'none'),floatText:hurt?`−${hurt}`:heal?`+${heal}`:'—',
        aria:`${p.name}, ${p.health?.label??''}${p.immune?`, immune for ${p.immune.remaining}`:''}. ${out?'Click to treat':'Click to leave out'}.`,
        toggle:()=>{if(s.busy)return;this.setState({excluded:{...s.excluded,[p.uuid]:!out},results:null});},
        enter:()=>this.setHint({click:out?`Treat ${p.name} again`:`Click to leave ${p.name} out of this treatment`})};
    });
    const n=treatable.length,several=inWard.length>1;

    // ---- the dropdowns ----
    this.selects={};this.memo.dcPick=null;const fields=[];
    if(v&&onTreat&&!isDirective){
      const dcList=v.dcs??[],dcPick=dcList.find(d=>d.id===s.dc)??dcList.find(d=>d.id===prefs.dc)??dcList[0];
      this.memo.dcPick=dcPick;
      if(dcList.length)fields.push(this.field('dc','Medicine DC',dcPick?.id??'',dcList.map(d=>({value:d.id,label:`DC ${d.dc} · ${d.name}`})),
        {help:dcPick?.heal??'',change:id=>this.setState({dc:Number(id)||id})}));
      if(usesBits&&v.animationAvailable!==false)fields.push(this.field('style','Technique',style,[{value:'random',label:'Random · each time'},
        ...GROUPS.flatMap(([g,name])=>(v.techniques??[]).filter(t=>t.group===g&&t.enabled!==false).map(t=>({value:t.id,label:t.label,group:name})))],
        {help:style==='random'?'A different technique each time':(v.techniques??[]).find(t=>t.id===style)?.description??'',change:id=>this.pickTech(id)}));
      if(several)fields.push(this.field('together','Several patients',together?'one':'each',[{value:'one',label:'One check for everyone'},{value:'each',label:'A check each'}],
        {help:together?'One roll, its healing applied to each':'Rules as written: a roll per patient',change:val=>{const t=val==='one';this.setState({together:t,results:null});saveMedkitChoices({together:t});}}));
      if(modeAny.id==='treatWounds'&&v.treatWounds?.risky)fields.push(this.field('risky','Risky Surgery',s.risky?'use':'',[{value:'',label:"Don't use"},{value:'use',label:'Use · 1d8 slashing first'}],
        {help:s.risky?'+2 to the check · a success becomes critical':'Optional · deals 1d8 slashing first',hint:'Risky Surgery: deal 1d8 slashing damage to each patient first; +2 circumstance to the check, and a success becomes a critical success',change:val=>this.setState({risky:val==='use',results:null})}));
      const medic=v.medic,immune=inWard.filter(blocked);
      if(usesMedic&&medic?.has&&(immune.length||!medic.bypassReady)){
        const ready=medic.bypassReady&&immune.length>0;
        fields.push(this.field('medic','Medic Dedication',ready?(medicFor??''):'',ready?[{value:'',label:"Don't use"},...immune.map(p=>({value:p.uuid,label:`Treat ${p.name} anyway`}))]:[{value:'',label:medic.bypassReady?'No one is immune':'Used · recharging'}],
          {disabled:!ready,help:ready?'Reach past one immunity · then it recharges':medic.cooldown||medic.note||'',change:id=>this.setState({medicFor:id||null,results:null})}));
      }
      for(const p of inWard.filter(p=>imm(p).unlabeled)){
        const hers=!!s.hers[p.uuid];
        fields.push(this.field(`hers-${p.uuid}`,`${p.name}'s immunity`,hers?'hers':'',[{value:'',label:'Not from her · skip'},{value:'hers',label:"From Yvaelle · replace it"}],
          {help:'An immunity the Medkit cannot trace',hint:`${p.name} has a ${modeAny.name} immunity without a healer on it. If it came from Yvaelle, it is replaced.`,change:val=>this.setState({hers:{...s.hers,[p.uuid]:val==='hers'},results:null})}));
      }
    }
    const cards=s.cards??prefs.cards??false;
    const canOptions=!!v&&onTreat&&usesBits&&v.animationAvailable!==false,showOpts=canOptions&&s.opts;
    const toggles=v&&onTreat&&!showOpts?[...(usesBits?[...(v.animationAvailable===false?[]:[['animate','Bits animate',animate,'The bits fly out and perform the technique on each patient']]),
      ['sound','Sound',sound,'Play the treatment sounds'],['scan','Diagnostic scan',scan,'Scan each patient before treating (adds about 1.6 s)']]:[]),
      ['cards','Keepsake chat cards',cards,cards?'Results post as Keepsake cards · off for the regular PF2e cards':'Results post as the regular PF2e cards · on for Keepsake cards']].map(([id,name,on,hint])=>({name,
      cls:'mk-toggle'+(on?' on':'')+this.pulse('tog'+id,on,'tg'),on:on?'true':'false',pick:()=>{if(s.busy)return;playMedkitSound(on?'toggle-off':'toggle-on');this.setState({[id]:!on});saveMedkitChoices({[id]:!on});},enter:()=>this.setHint({click:hint})})):[];

    // ---- technique preview ----
    const techs=(v?.techniques??[]).filter(t=>t.enabled!==false),tech=techs.find(t=>t.id===style);
    // Random never picks a Legacy technique for a real treatment, so its preview doesn't either
    const pool=techs.filter(t=>t.group!=='legacy'),previewStyle=style==='random'?(this.memo.randomPreview??=(pool.length?pool:techs)[Math.floor(Math.random()*(pool.length||techs.length))]?.id??'suture'):style;
    const outcome=OUTCOMES[s.outcomePreview%OUTCOMES.length];
    this.previewSpecs=v&&techs.length?{technique:{kind:'treatment',style:previewStyle,count:Math.max(1,Math.min(4,shares[treatable[0]?.uuid]??2)),outcome,scan,zoom:1.55,restart:style+outcome+scan}}:{};

    // ---- the seal ----
    const dcPick=this.memo.dcPick;
    const ready=!!v&&!!mode&&n>0&&(isDirective||!!dcPick)&&!s.busy;
    const busyDone=Object.values(progress).filter(p=>p.done).length,total=Math.max(1,Object.keys(progress).length);
    const verb=isDirective?'Direct':'Treat';
    const treatLabel=s.busy?(isDirective?'Directing…':'Treating…'):!v?'Medkit unavailable':n>1?`${verb} ${n} patients`:n===1?`${verb} ${treatable[0].name}`:verb;
    const treatSub=!v?(this.memo.viewError??'Pin a character with Battle Medicine'):s.busy?'Results land on each patient as the bits finish':
      !mode?(modeAny?.reason??'Choose an action'):n===0?(inWard.length?'Everyone here is immune':'Target the patients first'):
      isDirective?`+${v.directiveBonus} to their next healing · until her next turn`:
      `${mode.name} · DC ${dcPick?.dc??'—'}${several?` · ${together?'one check':'a check each'}`:''}${s.risky&&modeAny.id==='treatWounds'?' · Risky Surgery':''}`;
    const unlabeled=inWard.filter(p=>imm(p).unlabeled);
    // the action screen: Shift turns Battle Medicine into Treat Wounds
    const tw=v?.modes?.find(m=>m.id==='treatWounds');
    const actionTiles=(v?.modes??[]).filter(m=>m.id!=='treatWounds').map(m0=>{
      const m=m0.id==='battleMedicine'&&s.shift&&tw?tw:m0,off=!m.available;
      return {name:m.name,cost:m.cost,sub:off?m.reason:m.sub,icon:ICONS[m.id]??ICONS.battleMedicine,cls:'mk-act'+(off?' off':'')+(m.id==='treatWounds'?' tw':'')+(m0.id==='battleMedicine'?this.pulse('shiftflip',!!s.shift,'fl'):''),disabled:off?'true':'false',
        hasShift:m0.id==='battleMedicine'&&!!tw,shiftText:s.shift?'Release Shift · Battle Medicine':'Shift · Treat Wounds',
        pick:e=>{const id=m0.id==='battleMedicine'&&(e?.shiftKey||s.shift)&&tw?'treatWounds':m0.id,chosen=v.modes.find(x=>x.id===id);
          if(!chosen?.available){ctx.message(chosen?.reason??'Not available',true);return;}
          playMedkitSound('screen');this.setState({screen:'treat',mode:id,results:null,progress:{},shift:false,hint:null,msg:null,msgFail:false});},
        enter:()=>this.setHint({click:off?m.reason:m0.id==='battleMedicine'&&tw?`${m.name} · hold Shift for ${s.shift?'Battle Medicine':'Treat Wounds'}`:m.name})};});
    const facts=v?[v.healer?.rank?`Medicine ${v.healer.rank}`:null,`${v.freeBits??0} bits free`,v.medic?.has?'Medic Dedication':null].filter(Boolean):[];
    return {
      rootClass:(this.model.cfg?.reduced?'fm-off ':'')+'mk-open'+(showOpts?' mk-opts-open':''),screenCls:'mk-in'+(this.bump('screen',(onTreat?'t:':'a:')+(modeAny?.id??''))%2),keyDown:e=>{if(e.key!=='Escape'||s.ask||s.busy||e.target?.localName==='select')return;if(onTreat)this.back();else this.ctx.close();},
      onActions:!onTreat,onTreat,actionTiles,shiftNote:tw?(s.shift?'Shift held · Treat Wounds':'Hold Shift · Battle Medicine becomes Treat Wounds'):'',
      back:()=>this.back(),hintBack:()=>this.setHint({click:'Back to the actions (Esc)'}),
      modeName:modeAny?.name??'',modeCost:modeAny?.cost??'',modeIcon:ICONS[modeAny?.id]??ICONS.battleMedicine,
      showPreview:onTreat&&usesBits&&v?.animationAvailable!==false,showInfo:onTreat&&(!usesBits||v?.animationAvailable===false),
      infoTitle:isDirective?'Keep on Keeping On!':modeAny?.name??'',infoText:isDirective?`${treatable[0]?.name??'Your ally'} adds +${v?.directiveBonus??0} to the next healing they receive, until the start of Yvaelle's next turn.`:modeAny?.sub??'',
      hasFields:!showOpts&&fields.length>0,canOptions,showOpts,showBottom:!showOpts,optsLabel:s.opts?'Treatment':'Options',
      toggleOpts:()=>{if(s.busy)return;playMedkitSound('choose');if(s.opts)void stopMedkitPreview();this.setState({opts:!s.opts,hint:null});},
      hintOpts:()=>this.setHint({click:s.opts?'Back to the treatment choices':'Animation options: bits, brightness, size, detail, sound and stage sounds'}),
      ...(showOpts?this.optionsVals(v,style,sound,scan):{optFields:[],optSounds:[],optButtons:[]}),mouseLeave:()=>this.setState({hint:null}),
      closeApp:()=>this.ctx.close(),
      soundsOn:(s.uiSounds??uiSoundsOn())?'true':'false',soundsLabel:(s.uiSounds??uiSoundsOn())?'Mute the Medkit window sounds':'Turn the Medkit window sounds on',
      toggleSounds:()=>{const on=!(s.uiSounds??uiSoundsOn());this.setState({uiSounds:on});void setUiSounds(on);if(on)playMedkitSound('toggle-on',{force:true});},
      hintSounds:()=>this.setHint({click:(s.uiSounds??uiSoundsOn())?'Window sounds on · click to mute':'Window sounds off · click to turn on'}),clearHint:()=>this.setState({hint:null}),
      footer:note,footSw:this.sw('foot',note),footColor:s.hint?'#e6d8c6':s.msgFail?'#f08aa0':'#bba99c',
      healerName:token?.document?.name??'No healer',healerImg:token?.document?.texture?.src??ctx.portrait,facts,
      wardNote:!patientsAll.length?'':`${inWard.length} targeted${onTreat&&usesBits&&n&&v?.animationAvailable!==false?` · bits ${treatable.map(p=>shares[p.uuid]??0).join(' · ')}`:''}`,
      wardSw:this.sw('ward',inWard.length+'/'+n),
      refresh:()=>{this.memo.viewKey=null;this.memo.randomPreview=null;this.setState({rk:s.rk+1,results:null,progress:{}});},
      hintRefresh:()=>this.setHint({click:'Read the targets, health and immunities again · clears the last results'}),
      hasPatients:!s.party&&patientsAll.length>0,noPatients:!s.party&&!patientsAll.length,patients,
      ...this.partyVals(),
      cardsCls:'mk-cards'+(patientsAll.length===1?' solo':'')+' ca'+(this.bump('cards',patientsAll.map(p=>p.uuid).join('|'))%2),cardsStyle:`grid-template-columns: repeat(${Math.min(4,Math.max(1,patientsAll.length))}, minmax(0, 1fr))`,
      fields,toggles,
      techAlt:`Preview of ${tech?.label??'a random technique'} · click for another result`,techKicker:style==='random'?'Random · previewing':'Hardlight technique',
      techName:style==='random'?(techs.find(t=>t.id===previewStyle)?.label??'Random'):tech?.label??style,techSw:this.sw('tech',style),
      techOutcomeLabel:`Showing ${OUTCOME_NAMES[outcome]}`,
      outcomeCycle:()=>this.setState({outcomePreview:s.outcomePreview+1}),hintOutcome:()=>this.setHint({click:'Click to preview how this technique ends on another result'}),
      sealCls:'mk-sealbtn'+(s.busy?' busy':ready?' ready':' off')+(s.sealDone?` done${s.sealDone%2}`:''),sealDisabled:ready?'false':'true',
      sealDash:s.busy?`${Math.round(busyDone/total*100)} 100`:ready?'100 0':'0 100',
      treatLabel,treatSub,hintTreat:()=>this.setHint({click:treatSub}),
      treat:()=>this.treat({cards,risky:!!s.risky&&modeAny?.id==='treatWounds',mode,dc:isDirective?null:dcPick,together,style,sound,scan,animate,medicFor,patients:treatable,unlabeled:unlabeled.filter(p=>s.hers[p.uuid]).map(p=>p.uuid)}),
      hasAsk:!!s.ask,askText:s.ask?.text??'',
      askOpts:(s.ask?.options??[]).map(o=>({name:o.name,cls:'mk-ask-btn'+(o.primary?' primary':''),pick:()=>{const a=this.state.ask;this.setState({ask:null});a?.resolve(o.id);}}))
    };
  }
  back(){if(this.state.busy)return;playMedkitSound('screen');this.setState({screen:'actions',results:null,progress:{},hint:null,msg:null,msgFail:false});}
  /** Animation options (the classic dialog's tuning, beta.21): saved with the
   * Medkit preferences; stage sounds are per technique. */
  optionsVals(v,style,sound,scan){
    const s=this.state,base=v.animationOptions??{},o={...base,...s.o};
    const prof=key=>({volume:1,radius:20,...(base.audioProfiles?.[key]??{}),...(s.oa[key]??{}),sounds:{...(base.audioProfiles?.[key]?.sounds??{}),...(s.oa[key]?.sounds??{})}});
    const ap=prof(style),pct=n=>`${Math.round(n*100)}%`;
    const set=(k,val)=>{this.setState({o:{...this.state.o,[k]:val}});saveMedkitOptions({[k]:val});};
    const setAudio=patch=>{const cur=this.state.oa[style]??{};const next={...cur,...patch,sounds:{...(cur.sounds??{}),...(patch.sounds??{})}};
      this.setState({oa:{...this.state.oa,[style]:next}});saveMedkitOptions({audio:patch},{style});};
    const num=(list,val)=>[...new Set([...list,Number(val)])].filter(Number.isFinite).sort((a,b)=>a-b);
    const optFields=[
      this.field('o-bits','Bits to use',o.bits,[1,2,3,4].map(n=>({value:n,label:`${n} bit${n>1?'s':''}`})),{help:'For one patient · several share the free bits',change:val=>set('bits',Number(val))}),
      this.field('o-intensity','Brightness',o.intensity,num([.25,.5,.75,1,1.25,1.5,2],o.intensity).map(n=>({value:n,label:pct(n)})),{help:'How bright the hardlight is',change:val=>set('intensity',Number(val))}),
      this.field('o-scale','Effect size',o.scale,num([.5,.75,1,1.25,1.5,1.75],o.scale).map(n=>({value:n,label:pct(n)})),{help:'How large the instruments draw',change:val=>set('scale',Number(val))}),
      this.field('o-detail','Detail',o.detail,[['low','Light'],['standard','Standard'],['high','Intricate']].map(([value,label])=>({value,label})),{help:'Lighter for slower computers',change:val=>set('detail',val)}),
      this.field('o-volume','Treatment volume',ap.volume,num([0,.25,.5,.75,1],ap.volume).map(n=>({value:n,label:pct(n)})),{help:`For ${style==='random'?'Random':'this technique'} · each player's own volume applies`,change:val=>setAudio({volume:Number(val)})}),
      this.field('o-radius','Audible distance',ap.radius,num([5,10,15,20,30,60,120,240],ap.radius).map(n=>({value:n,label:`${n} ${base.units??'ft'}`})),{help:'Heard near the patient and by you',change:val=>setAudio({radius:Number(val)})})];
    if(base.v7?.variation)optFields.push(this.field('o-variation','Action transitions',o.variation===false?'off':'on',[{value:'on',label:'Varied'},{value:'off',label:'Always the same'}],{help:'Vary how the bits move between actions',change:val=>set('variation',val==='on')}));
    const FilePicker=globalThis.foundry?.applications?.apps?.FilePicker?.implementation;
    const optSounds=Object.entries(base.stages??{}).map(([stage,label])=>{const val=ap.sounds?.[stage]??'';return {label,value:val,placeholder:`Default ${String(label).toLowerCase()}`,
      change:e=>setAudio({sounds:{[stage]:String(e.target.value??'').trim()}}),
      browse:()=>{if(!FilePicker){this.ctx.message('Paste a Foundry audio path into the field',true);return;}
        try{new FilePicker({type:'audio',current:val==='none'?'':val,callback:src=>setAudio({sounds:{[stage]:src}})}).render(true);}catch(e){console.warn(e);}},
      hint:()=>this.setHint({click:`${label}: a custom sound file for ${style==='random'?'Random':'this technique'} · blank for the default · none to silence it`})};});
    const previewOk=!!base.previewAvailable,token=this.model.token;
    const run=soundOnly=>{if(!previewOk){this.ctx.message('The treatment preview is unavailable here',true);return;}
      void previewMedkit(token,{style,soundOnly,sound,scan}).catch(e=>this.ctx.message(e?.message??String(e),true));};
    const optButtons=[{name:'Preview on her token',cls:'mk-ask-btn primary',pick:()=>run(false),enter:()=>this.setHint({click:'A private preview of this technique on her token, only you see it'})},
      {name:'Audition sound',cls:'mk-ask-btn',pick:()=>run(true),enter:()=>this.setHint({click:'Hear this technique without the animation'})},
      {name:'Stop',cls:'mk-ask-btn',pick:()=>void stopMedkitPreview(),enter:()=>this.setHint({click:'Stop the preview'})}];
    return {optFields,optSounds,optButtons,optSoundTitle:`Stage sounds · ${style==='random'?'Random':(v.techniques??[]).find(t=>t.id===style)?.label??style}`};
  }
  /** The Party view: everyone's Battle Medicine and Treat Wounds immunity, in
   * place of the patients (no extra panel). Click someone to (un)target them. */
  partyVals(){
    const s=this.state;
    const toggleParty=()=>{if(s.busy)return;playMedkitSound('choose');this.setState({party:!s.party,hint:null});};
    const base={showParty:s.party,partyLabel:s.party?'Patients':'Party',toggleParty,
      hintParty:()=>this.setHint({click:s.party?'Back to the targeted patients':"See the party's Battle Medicine and Treat Wounds immunities"}),
      wardTitle:s.party?'Party':'Patients'};
    if(!s.party)return {...base,partyRows:[],partyEmpty:false};
    let rows=[];try{rows=partyView(this.model.token)??[];}catch(e){console.warn('Yvaelle’s Toolbox | Medkit party',e);}
    const short=t=>String(t??'').replace(/ minutes?$/,' min').replace(/ hours?$/,' h').replace(/ seconds$/,' s');
    const chip=(i,name,cls)=>i?.status==='immune'?{cls:`mk-pchip ${cls}`,text:`${name} · ${short(i.text)}`}:i?.status==='unlabeled'?{cls:`mk-pchip ${cls} dim`,text:`${name} · unlabeled`}:{cls:'mk-pchip ready',text:`${name} · ready`};
    const targets=new Set([...(globalThis.game?.user?.targets??[])].map(t=>t.document?.uuid));
    return {...base,partyEmpty:!rows.length,partyRows:rows.map(r=>{
      const on=!!r.token&&targets.has(r.token.document?.uuid);
      return {name:r.name,img:r.img||this.ctx.tokenImage,healthLabel:r.health?.label??'',healthColor:r.health?.unknown?'#bba99c':`hsl(${r.health?.hue??125} 62% 64%)`,
        bm:chip(r.bm,'Battle Medicine','bm'),tw:chip(r.tw,'Treat Wounds','tw'),cls:'mk-prow'+(on?' on':'')+(r.token?'':' off'),
        pick:()=>{const t=r.token;if(!t){this.ctx.message(`${r.name} is not on this scene`,true);return;}try{t.setTarget(!t.isTargeted,{releaseOthers:false});}catch(e){console.warn(e);}},
        enter:()=>this.setHint({click:r.token?(on?`Untarget ${r.name}`:`Target ${r.name}`):`${r.name} is not on this scene`})};})};
  }
  /** An in-window question (rerolls, confirmations) instead of a pop-up. */
  ask(text,options){playMedkitSound('ask');return new Promise(resolve=>this.setState({ask:{text,options,resolve}}));}
  pickTech(id){if(this.state.busy)return;this.memo.randomPreview=null;this.setState({style:id,outcomePreview:0});saveMedkitChoices({style:id});}
  async treat(choice){
    const s=this.state,ctx=this.ctx;if(s.busy)return;
    if(!choice.mode){ctx.message('No treatment is available');return;}
    if(!choice.patients.length){ctx.message('Target the patients first: hover a token and press T');return;}
    if(choice.mode.needsConfirm){const go=await this.ask(choice.mode.needsConfirm,[{id:'go',name:'Continue',primary:true},{id:'stop',name:'Cancel'}]);if(go!=='go')return;}
    const progress=Object.fromEntries(choice.patients.map(p=>[p.uuid,{label:'Bits on their way',done:false}]));
    playMedkitSound('seal');this.setState({busy:true,progress,results:null});
    if(choice.dc)saveMedkitChoices({dc:choice.dc.id});
    try{
      const results=await runMedkitView(this.model.token,choice,event=>{
        const cur=this.state.progress;if(!event?.uuid||!cur[event.uuid])return;
        this.setState({progress:{...cur,[event.uuid]:{...cur[event.uuid],label:event.label??cur[event.uuid].label,done:!!event.done}}});
      },request=>{
        if(request?.type!=='reroll')return 'continue';
        const who=request.names?.length>1?request.names.join(', '):request.names?.[0]??'the patient';
        const options=[...(request.heroPoints>0?[{id:'hero',name:`Spend a Hero Point (${request.heroPoints})`,primary:true}]:[]),{id:'free',name:'Reroll (another effect)'},{id:'continue',name:`Keep the ${String(request.failureText).toLowerCase()}`}];
        return this.ask(`${request.failureText} on ${who}. Reroll?`,options);
      });
      if(results===null){this.setState({busy:false,progress:{}});ctx.message('Treatment cancelled');return;}
      // read the patients again so their health estimates and new immunities show
      this.memo.viewKey=null;
      this.setState({busy:false,progress:{},results,sealDone:s.sealDone+1,rk:this.state.rk+1});
      const healed=results.filter(r=>r.amount>0).length;
      ctx.message(healed?`${healed} patient${healed>1?'s':''} healed`:'The treatment did not heal anyone');
    }catch(e){this.setState({busy:false,progress:{}});ctx.message(e?.message??String(e),true);}
  }
}
