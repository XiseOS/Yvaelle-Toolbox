/** v2 transient art is made from the live wing lattice. Each cue owns a small,
 * deterministic choreography; there are no billboards, filters or new textures. */
import {ease,unit} from './poses.mjs?v=13.0.0-beta.7';
import {cubic} from './wing-art.mjs?v=13.0.0-beta.7';
import {fitEffectPoint} from './condition-art.mjs?v=13.0.0-beta.7';
import {isQuickReaction,quickParameters,quickPoint,quickAccents,stutterSegment,REACTION_KIND_TINT} from './quick-choreography.mjs?v=13.0.0-beta.7';

export const DEFAULT_REACTION_ART=Object.freeze({damage:'recoilWave',critical:'overload',heal:'mending',
  flare:'ignition',pulse:'resonance',stutter:'phaseSlip',reform:'rethread'});
export const V2_REACTION_IDS=Object.freeze(Object.values(DEFAULT_REACTION_ART));
const phase=(q,start,duration)=>(q-start)/duration;
const alive=q=>q>0&&q<1;
const bell=q=>alive(q)?Math.sin(Math.PI*q)**2:0;
const mix=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*t);
const ridge=(u,head,width)=>Math.exp(-(((u-head)/width)**2));
const root=u=>ease((u-.08)/.36);
const quant=x=>Math.round(Math.max(0,Math.min(1.4,x))*20)/20;


/** A reconstruction is a temporary render envelope, never a health change.
 * The actual lattice dissolves locally, reforms behind a root-to-tip front,
 * then returns to the currently resolved condition before the cue expires. */
export const REFORM_UNRAVEL=.24;
export function reformationOf(bursts=[],reactions=[]) {
  const cue=[...bursts,...reactions].find(b=>b.kind==='reform'&&(b.amount??b.strength)>0);
  if(!cue)return null;
  const progress=cue.progress,strength=Math.min(1,cue.amount??cue.strength);
  // Beta.29: a visible unravel, then the rebuild. The front first runs in from
  // the tips to the shoulders (0-24%, about 0.34 s of a 1.4 s Reform) instead of
  // blinking the wing out, then runs back out to the tips. A faint scaffold
  // (20%) stays where the lattice is undone, so she is never wingless.
  const attack=ease(progress/.05),release=1-ease((progress-.82)/.18);
  const out=unit((progress-REFORM_UNRAVEL)/.5),head=progress<REFORM_UNRAVEL?1.12-1.06*ease(progress/REFORM_UNRAVEL):.06+1.02*(1-(1-out)**2);
  return {id:cue.id,progress,strength,head,unravel:progress<REFORM_UNRAVEL,
    lift:attack*release*Math.min(1,strength/.7),hide:.8*attack*Math.min(1,strength/.7)};
}

/** Work on actual surviving lattice spans. Short held sector offsets have
 * distinct quiet intervals, and never join across a skipped section. */
export function reactionPaths(strand,points,side,v) {
  const repair=v?.reformation;
  const slips=v?.animated&&v.gates?.glitches!==false?quickParameters(v,side).filter(b=>b.kind==='stutter'):[];
  if(!repair&&!slips.some(b=>b.gain>.001))return [{...strand,points}];
  // Glitch displacement has its own switch. Turning off flutter must not also
  // silently disable a manually requested stutter.
  const out=[],echoes=[],motion=v.variantMotion??v.motionStrength??1;
  const displacement=(v.gates?.displacement??1)*motion;
  const rib=/^rib-/.test(strand.id),web=/^(web|cross)-/.test(strand.id);
  const rank=Number(strand.id.match(/(\d+)(?:-\d+)?$/)?.[1]??0);
  let last=null;
  const append=(a,b,strength,tag)=>{
    if(strength<=.025){last=null;return;}
    if(last&&last.tag===tag&&last.strength===strength&&last.points.at(-1).every((x,i)=>x===a[i]))last.points.push(b);
    else {last={...strand,points:[a,b],strength,tag};out.push(last);}
  };
  for(let i=1;i<points.length;i++){
    const a=points[i-1],b=points[i],u=((a[3]??1)+(b[3]??1))/2,r=root(u);
    let gain=strand.strength,dx=0,dy=0,tag='plain',skip=false;
    for(const slip of slips){
      const local=stutterSegment(slip,a,b,u,rank,web);if(!local)continue;
      const amount=local.gain;
      dx+=local.dx*displacement;dy+=local.dy*motion;
      gain*=local.fade;tag=local.tag;
      // Sparse web gaps make the interruption readable without extinguishing a wing.
      if(local.skip)skip=true;
      if(v.gates?.echoes&&rib&&amount>.1)echoes.push({...strand,id:`phase-slip-echo-${strand.id}`,
        echo:true,points:[a,b],width:strand.width*.55,strength:strand.strength*amount*.25});
    }
    if(repair&&u>.11){
      const frontier=ease((u-repair.head)/.105),hidden=repair.hide*frontier*r;
      // Recall keeps its loosened pieces visible while they drift and return.
      gain*=1-hidden*(repair.id==='recall'?.5:1);
      if(gain<=.025)skip=true;
      // Recall gathers displaced fragments; weaving and rethreading draw a clean
      // formation front. Neither contracts the whole finished wing into a flash.
      if(repair.id==='recall'&&hidden>.001){
        dx+=side*(12+rank%4*4)*hidden*motion;dy+=(18+rank%3*6)*hidden*motion;
        tag+=`-recall-${Math.floor(u*7)}`;
      }
      if(hidden>.001)tag+='-forming';
    }
    if(skip){last=null;continue;}
    const shift=p=>dx||dy?fitEffectPoint([p[0]+dx,p[1]+dy,p[2],p[3]??u]):p;
    append(shift(a),shift(b),gain,tag);
  }
  return [...out,...echoes];
}

/** Compute cue clocks once per wing, outside the vertex loop. */
export function reactionParameters(v,side) {
  if(!v?.animated)return [];
  return [...quickParameters(v,side),...([...(v.bursts??[]),...(v.reactions??[])].filter(b=>V2_REACTION_IDS.includes(b.id)&&!isQuickReaction(b)).map(b=>{
    const q=b.progress,k=b.amount??b.strength;
    const entry={id:b.id,q,k,side,head:0,gain:0,compression:0};
    if(b.id==='ignition'){entry.head=.05+1.07*ease(unit(q/.8));entry.gain=bell(q)*k;}
    if(b.id==='overload'){
      entry.compression=ease(q/.07)*(1-ease((q-.1)/.19))*k;
      entry.head=.08+.91*ease(unit((q-.15)/.65));entry.gain=bell(phase(q,.14,.72))*k;
    }
    if(b.id==='resonance'){
      const outward=q<.55,local=outward?q/.55:(q-.55)/.45;
      entry.head=outward?.07+.88*ease(local):.95-.88*ease(local);
      entry.gain=bell(local)*k*(outward?1:.48);
    }
    if(b.id==='recoilWave'){entry.compression=ease(q/.04)*(1-ease((q-.07)/.25))*k;entry.head=.1+.85*ease(unit(q/.7));entry.gain=bell(phase(q,.15,.62))*k;}
    if(b.id==='mending'||b.id==='rethread'){entry.head=.05+.94*ease(q);entry.gain=bell(q)*k;}
    if(b.id==='phaseSlip'){entry.head=.2+.68*ease(q);entry.gain=bell(q)*k;}
    return entry;
  }))];
}

export function reactionPoint(point,u,side,parameters,motion=1) {
  if(!parameters?.length||!motion)return point;
  const p=quickPoint(point,u,side,parameters,motion),r=root(u),x=p[0]-side*27,y=p[1]+13;
  for(const b of parameters){
    if(isQuickReaction(b))continue;
    const packet=ridge(u,b.head,.14)*b.gain*r*motion;
    if(b.id==='ignition'){p[0]+=x*.06*packet;p[1]-=18*packet*ease((70-y)/150);}
    else if(b.id==='overload'){p[0]-=x*.2*b.compression*r*motion;p[0]+=x*.055*packet;p[1]-=6*packet;}
    else if(b.id==='resonance'){p[0]+=x*.028*packet;p[1]+=y*.012*packet;}
    else if(b.id==='recoilWave'){p[0]-=x*.17*b.compression*r*motion;p[1]+=6*b.compression*r*motion;}
    else if(b.id==='rethread'){p[0]-=x*.025*(1-ease(b.q))*packet;}
  }
  return p;
}

/** Fine currents follow existing ribs and link adjacent strands locally. Their
 * tips taper in a bounded number of strokes; all coordinates retain formation u. */
export function reactionAccents(side,v,warp,ribs,growth=1,reactions=[]) {
  if(!v?.animated||growth<=0||!reactions.length)return [];
  const selected=new Set(reactions);
  const out=quickAccents(side,v,warp,ribs,growth,quickParameters(v,side).filter(b=>selected.has(b.source))),
    sparks=v.gates?.sparks??v.sparks,arcs=v.gates?.arcs??v.arcs;
  const at=(i,u)=>warp([...cubic(ribs[i],u),u]);
  let tint='base';
  const line=(id,points,width,strength)=>{
    const gain=quant(strength);
    if(gain<=.025||points.length<2||points.some(p=>(p[3]??1)>growth+.000001))return;
    out.push({id,points,width,strength:gain,highlight:true,tint});
  };
  const knot=(id,i,u,gain)=>{
    if(!sparks||u>growth||gain<=.04)return;
    const p=at(i,u),a=at(i,Math.max(0,u-.035)),b=at(i,Math.min(1,u+.035));
    const len=Math.hypot(b[0]-a[0],b[1]-a[1])||1,tx=(b[0]-a[0])/len,ty=(b[1]-a[1])/len;
    const place=(x,y)=>[p[0]+tx*x-ty*y,p[1]+ty*x+tx*y,p[2],u];
    // Slender energy facets, aligned with the supporting filament.
    line(`${id}-facet`,[place(-3,0),place(0,-1.1),place(3,0),place(0,1.1),place(-3,0)],.48,gain*.72);
  };
  const current=(id,i,head,gain,length=.16,width=1.1,reverse=false)=>{
    if(head<=0||head>growth||gain<=.03)return;
    // Two fading tails and one slender core; no hard pulse ring through the web.
    const points=Array.from({length:13},(_,j)=>at(i,unit(head+(reverse?1:-1)*length*j/12)));
    for(let j=0;j<3;j++)line(`${id}-${j}`,points.slice(j*4,j*4+5),width*[1,.72,.4][j],gain*[1,.58,.21][j]);
    knot(id,i,head,gain);
  };
  const bridge=(id,i,u,gain,twist=0)=>{
    if(!arcs||u<=0||u>growth)return;
    const a=at(i,u),b=at(i+1,Math.max(0,u-.025));
    line(id,Array.from({length:13},(_,j)=>{
      const q=j/12,p=mix(a,b,q);p[0]+=side*twist*Math.sin(Math.PI*q);p[1]-=3*Math.sin(Math.PI*q);return p;
    }),.56,gain);
  };
  for(const b of reactions){
    if(isQuickReaction(b))continue;
    if(!V2_REACTION_IDS.includes(b.id))continue;
    const q=b.progress,k=b.amount??b.strength,id=`${b.id}-${b.kind}`;tint=REACTION_KIND_TINT[b.kind]??'base';
    if(b.id==='ignition')for(let i=0;i<10;i++){
      const delay=i*.016,life=phase(q,delay,.72);if(!alive(life))continue;
      const u=.06+.93*ease(life),gain=k*bell(life)*.9;
      current(`${id}-${i}`,i,u,gain,.19,1.25);
      if(life>.64){const tipGain=k*bell(phase(life,.62,.38));current(`${id}-tip-${i}`,i,.99,tipGain*.72,.09,.85);}
    }
    else if(b.id==='overload'){
      // A short inward gathering precedes three distinct, staggered releases.
      if(q<.23)for(const i of [0,3,6,9]){
        const life=q/.23;current(`${id}-gather-${i}`,i,.68-.55*ease(life),bell(life)*k*.5,.1,.85,true);
      }
      for(let group=0;group<3;group++){
        const life=phase(q,.13+group*.12,.46);if(!alive(life))continue;
        const u=.06+.93*ease(life),gain=k*bell(life)*(1-group*.12);
        for(const i of [group,group+3,group+6].filter(i=>i<10)){
          current(`${id}-release-${group}-${i}`,i,u,gain,.2,1.5);
          if(i<9)bridge(`${id}-join-${group}-${i}`,i,u,gain*.45,2);
        }
      }
    }
    else if(b.id==='resonance'){
      const reverse=q>=.55,life=reverse?(q-.55)/.45:q/.55;
      const u=reverse?.95-.88*ease(life):.07+.88*ease(life),gain=k*bell(life)*(reverse?.38:.7);
      for(const i of [0,2,4,6,8,9])current(`${id}-${i}`,i,u,gain,.15,1.2,reverse);
      for(const i of [1,4,7])bridge(`${id}-weft-${i}`,i,u,gain*.38);
    }
    else if(b.id==='mending'||b.id==='rethread'){
      const rethread=b.id==='rethread';
      for(let i=0;i<10;i++){
        const life=phase(q,i*.005,.88);if(!alive(life))continue;
        const u=rethread?(v.reformation?.head??(.04+.96*ease((q-.075)/.68))):.06+.92*ease(life),gain=k*bell(life)*.95;
        current(`${id}-${i}`,i,u,gain,rethread?.23:.14,.95);
        if(i<9)bridge(`${id}-seam-${i}`,i,u,gain*.6,rethread?4:1.5);
        if(rethread&&i%2===0)current(`${id}-echo-${i}`,i,Math.max(.01,u-.08),gain*.32,.1,.5);
      }
    }
    else if(b.id==='recoilWave'){
      const life=phase(q,.12,.67);if(!alive(life))continue;
      const u=.07+.86*ease(life),gain=k*bell(life)*.7;
      for(const i of [1,4,7,9])current(`${id}-${i}`,i,u,gain,.12,1.05);
    }
    else if(b.id==='phaseSlip'){
      const life=phase(q,.06,.85);if(!alive(life))continue;
      const u=.16+.7*ease(life),gain=k*bell(life)*(v.gates?.glitchLimit??1);
      for(const i of [0,3,6,9])current(`${id}-${i}`,i,u,gain*.8,.12,.85);
      for(const i of [1,4,7])bridge(`${id}-reconnect-${i}`,i,u,gain*.42,2);
    }
  }
  return out;
}
