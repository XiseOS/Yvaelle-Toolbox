/** Yvaelle’s Toolbox v11 · the session recap card (experimental; the GM's world switch).
 *
 * Her player posts it (HUD › Tapestry › Post recap, or the "Post Session
 * Recap" macro): a Keepsake card in the chat summing up the session from her
 * journal: her heartbeat start to end, heals given, damage taken, Hero Points,
 * crits, the moment that stood out, and any petal that grew.
 *  - The reveal (blocks rise, the heartbeat wipes on, the gold rule draws)
 *    plays only on a fresh message: one that arrives while you watch, once.
 *  - "Share image" draws the share-size version (1920×1080 PNG) and saves it.
 * Off: no chat hook at all; cards already posted keep their look (the styles
 * are static) and simply lose the Share button. */
import {isOn,partOn} from './features.mjs?v=13.0.0-beta.7';
import {heartbeatPath,milestoneById,MILESTONES} from './journal.mjs?v=13.0.0-beta.7';
import {flowerInner,flowerSVG,petalIcon,petalArt,petalDefs,GLINT,PETAL_COLORS} from './petal-art.mjs?v=13.0.0-beta.7';

const ID='filament-flight';
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const I={
  heal:'<path d="M3.4 20.4c2.8-.3 4.3-2.1 4.7-4.5.5-2.9 2.8-4.2 5-3.4 1.8.7 1.9 3.1.2 3.5-1.6.4-2.3-1.4-1.3-3.1l4-5.6"/><path d="M17.5 3.5v4M15.5 5.5h4"/>',
  hp:'<path d="M12 20.2S4 15.6 4 9.9A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 8 2.3c0 5.7-8 10.3-8 10.3z"/><path d="M6.4 12.6h2.8l1.3-2.3 1.9 4.4 1.3-2.1h3.9"/>',
  hero:'<path d="M12 21C8 16.4 7.6 10.2 12 3c4.4 7.2 4 13.4 0 18z" fill="currentColor" fill-opacity=".28" stroke="none"/><path d="M12 21C8 16.4 7.6 10.2 12 3c4.4 7.2 4 13.4 0 18z"/><path d="M12 18.6V9.4" stroke-opacity=".5"/>',
  crit:'<path d="M12 2.4l2.3 7.3 7.3 2.3-7.3 2.3-2.3 7.3-2.3-7.3L2.4 12l7.3-2.3z" fill="currentColor" fill-opacity=".28" stroke="none"/><path d="M12 2.4l2.3 7.3 7.3 2.3-7.3 2.3-2.3 7.3-2.3-7.3L2.4 12l7.3-2.3z"/>',
  loom:'<path d="M5 4h14M5 20h14M7 4v16M17 4v16"/><path d="M7 8c3 1.5 7-1.5 10 0M7 12c3 1.5 7-1.5 10 0M7 16c3 1.5 7-1.5 10 0" stroke-opacity=".7"/>',
  share:'<path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"/>'
};
export const icon=(k,cls='ffx-ic')=>`<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[k]}</svg>`;
const MOON='M92 24a13 13 0 1 0 10.5 20a10.5 10.5 0 1 1 -10.5 -20z';
const heroPetal=on=>`<svg viewBox="-4 -9.4 8 10" aria-hidden="true"><path d="M0 0C-3 -4 -2.5 -8 0 -9C2.5 -8 3 -4 0 0Z" fill="#f0dfe4" fill-opacity="${on?1:.18}" stroke="#a3243f" stroke-width=".6" stroke-opacity="${on?1:.5}"/></svg>`;

/** The heartbeat line as an inline svg. */
function heartbeatSVG(r,w,h,id){
  const hb=heartbeatPath(r.hp,r.span,r.max,w,h);
  return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" fill="none" aria-hidden="true"><defs><linearGradient id="${id}g" x1="0" x2="1"><stop offset="0" stop-color="#a1418f"/><stop offset=".5" stop-color="#e767ce"/><stop offset="1" stop-color="#ffd8f1"/></linearGradient>
<linearGradient id="${id}f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e767ce" stop-opacity=".16"/><stop offset="1" stop-color="#e767ce" stop-opacity="0"/></linearGradient></defs>
<path d="M0 ${hb.top}H${w}" stroke="#3b2631" stroke-width="1" stroke-dasharray="2 3"/><path d="${hb.d}V${h}H0Z" fill="url(#${id}f)"/><path d="${hb.d}" stroke="url(#${id}g)" stroke-width="1.6" stroke-linejoin="round"/>
<circle cx="${hb.low.x}" cy="${hb.low.y}" r="3" fill="#1c1219" stroke="#e2a256" stroke-width="1.2"/><path transform="translate(${w-3} ${hb.end.y}) scale(.9)" d="${GLINT}" fill="#fff4e8"/></svg>`;
}
let uid=0;
/** The chat card. r = recapOf(...); name = her name; pinned = the flower's petals now. */
export function recapCardHTML(r,{name='Yvaelle',pinned=[],lit=5}={}){
  const id=`ffxr${(uid++).toString(36)}${Date.now().toString(36).slice(-3)}`;
  const heroPips=Array.from({length:Math.max(1,Math.min(6,r.heroMax))},(_,k)=>heroPetal(k>=r.hero)).join('');
  const newPetal=r.petals[0]?milestoneById(r.petals[0]):null;
  const hl=r.highlight;
  return `<div class="ffx-rc" data-ffx-recap="${r.n}">
<div class="ffx-rc-top ffx-rv"><span class="ffx-rc-fl">${flowerSVG({size:30,pinned,lit,prefix:id+'p',sw:.6})}</span><svg class="ffx-rc-moon" viewBox="78 23 28 28" aria-hidden="true"><path d="${MOON}" fill="#efe4d4"/></svg>
<div class="ffx-rc-k">Session ${r.n} · Recap</div><div class="ffx-rc-t">${esc(r.name)}</div><div class="ffx-rc-m">${esc([r.dates,`${r.duration} at the table`].filter(Boolean).join(' · '))}</div></div>
<div class="ffx-rc-body">
<div class="ffx-hb ffx-rv"><div class="ffx-hbo"><div class="ffx-hbi">${heartbeatSVG(r,268,52,id)}</div></div></div>
<div class="ffx-hbcap ffx-rv"><span>Her heartbeat, start to end</span><span><b>${r.end}</b> / ${r.max}</span></div>
<div class="ffx-stats">
<div class="ffx-st heal ffx-rv"><div class="r">${icon('heal')}<span class="l">Healed</span></div><div class="v">${r.healed}</div><div class="s">${r.allies?`across ${r.allies} all${r.allies===1?'y':'ies'}`:'no one needed her'}</div></div>
<div class="ffx-st hurt ffx-rv"><div class="r">${icon('hp')}<span class="l">Taken</span></div><div class="v">${r.taken}</div><div class="s">lowest ${r.lowest} HP</div></div>
<div class="ffx-st hero ffx-rv"><div class="r">${icon('hero')}<span class="l">Hero Points</span></div><div class="v">${r.hero}<small>of ${r.heroMax}</small><span class="pips">${heroPips}</span></div><div class="s">spent · ${r.heroKept} kept</div></div>
<div class="ffx-st crit ffx-rv"><div class="r">${icon('crit')}<span class="l">Crits</span></div><div class="v">${r.crits}</div><div class="s">${r.saves?`${r.saves} saved an ally`:r.crits?'clean and bright':'none this time'}</div></div>
</div>
${hl?`<div class="ffx-hl ffx-rv"><span class="rule"></span><div class="k">The moment</div><q>${esc(hl.line)}</q>${hl.at?`<div class="at">${esc(hl.at)}</div>`:''}</div>`:''}
<div class="ffx-rc-foot ffx-rv">${newPetal?`<span class="np">${petalIcon(newPetal.id,{prefix:id+'n'})}<span>New petal</span><b>${esc(newPetal.name)}</b></span>`:`<span class="np">${r.allStanding?'<span>Everyone stood</span>':'<span>Woven into her tapestry</span>'}</span>`}
<span class="ffx-threads">${icon('loom')}${r.threads} thread${r.threads===1?'':'s'}</span>
<button type="button" class="ffx-share" data-ffx-share aria-label="Save the share-size image" title="Save the share-size image (1920 × 1080)">${icon('share')}</button></div>
</div><div class="ffx-rc-cord"></div></div>`;
}
/** A message arrived while you watch (the reveal plays once, only then). */
export const isFresh=(message,now=Date.now())=>now-Number(message?.timestamp??0)<15000;

/* ------------------------------------------------------------------ */
/* Posting                                                             */
/* ------------------------------------------------------------------ */
export async function postRecap(actor,{n=null,recapFor,pinned=[]}={}){
  if(!isOn('xRecap'))throw new Error('The recap card is off (Settings › Advanced › Experimental: the GM’s switch).');
  if(!actor)throw new Error('Pin her in the HUD first.');
  if(!actor.isOwner)throw new Error('Only her player (or the GM) can post her recap.');
  const r=recapFor(actor,n);if(!r)throw new Error('Nothing is woven yet: her journal starts with the Tapestry, the petals or the recap switched on.');
  const name=actor.name??'Yvaelle';
  const content=recapCardHTML(r,{name,pinned});
  const speaker=globalThis.ChatMessage?.getSpeaker?.({actor})??{actor:actor.id,alias:name};
  return ChatMessage.create({content,speaker,flags:{[ID]:{recap:{...r,sessionName:r.name,name,pinned}}}});
}

/* ------------------------------------------------------------------ */
/* In the chat: the reveal and the share button (only while it is on)  */
/* ------------------------------------------------------------------ */
const shown=new Set();
export class RecapChat {
  constructor(){this.hook=null;}
  install(){
    if(this.installed||!globalThis.Hooks)return this;this.installed=true;
    const sync=()=>this.sync();Hooks.once('ready',sync);Hooks.on('filamentFlightSettingsChanged',sync);return this;
  }
  sync(){
    const on=isOn('xRecap');globalThis.document?.body?.classList.toggle('ffx-recap-on',on);
    if(on&&!this.hook){this.hook=['renderChatMessageHTML',Hooks.on('renderChatMessageHTML',(m,html)=>this.render(m,html))];}
    else if(!on&&this.hook){Hooks.off(...this.hook);this.hook=null;}
  }
  render(message,html){
    const data=message?.flags?.[ID]?.recap;if(!data)return;
    const el=html?.[0]??html,card=el?.querySelector?.('.ffx-rc');if(!card)return;
    const share=card.querySelector('[data-ffx-share]');
    if(share){share.hidden=!partOn('xRecap','recapShare');share.onclick=e=>{e.preventDefault();void saveShareImage(data).catch(err=>globalThis.ui?.notifications?.error?.(err.message??String(err)));};}
    if(!shown.has(message.id)&&isFresh(message)&&partOn('xRecap','recapReveal')&&!globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches){shown.add(message.id);reveal(card);}
    else shown.add(message.id);
  }
}
export function reveal(card){
  const E='cubic-bezier(.2,.8,.2,1)',T='cubic-bezier(.45,0,.2,1)',a=(el,kf,ms,o={})=>el?.animate?.(kf,{duration:ms,easing:E,fill:'both',...o});
  a(card,[{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'none'}],240);
  [...card.querySelectorAll('.ffx-rv')].forEach((e,i)=>a(e,[{opacity:0,transform:'translateY(6px)'},{opacity:1,transform:'none'}],300,{delay:80+i*60}));
  const o=card.querySelector('.ffx-hbo');if(o){o.classList.add('wipe');a(o,[{transform:'translateX(-100%)'},{transform:'none'}],550,{delay:220,easing:T});a(o.firstElementChild,[{transform:'translateX(100%)'},{transform:'none'}],550,{delay:220,easing:T})?.finished?.then(()=>o.classList.remove('wipe'),()=>{});}
  a(card.querySelector('.ffx-hl .rule'),[{transform:'scaleY(0)'},{transform:'scaleY(1)'}],320,{delay:640});
  a(card.querySelector('.np svg'),[{transform:'scale(.3)',opacity:0},{transform:'none',opacity:1}],420,{delay:820,easing:'cubic-bezier(.16,1,.3,1)'});
}

/* ------------------------------------------------------------------ */
/* The share-size image (1920×1080): drawn on a canvas, saved as PNG   */
/* ------------------------------------------------------------------ */
const CURLS=`<g fill="none" stroke="#c7a66c" stroke-linecap="round"><path d="M27 15.5C41 5 53 27 69 15.5C79 8.5 91 10.5 104 15.5" stroke-width="1.7"/><path d="M49 15.5c0 -6 8 -8 10 -3 1 3 -2 5 -4 3" stroke-width="1.4"/><path d="M30 26c6 4 10 10 8 16M26 30c4 6 10 10 16 8" stroke-width="1.1"/><circle cx="37" cy="37" r="1.6" fill="#c7a66c" stroke="none"/><path d="M80 12c3 -5 9 -4 9 1" stroke-width=".9"/><path d="M15.5 27C5 41 27 53 15.5 69C8.5 79 10.5 91 15.5 104" stroke-width="1.7"/><path d="M15.5 49c-6 0 -8 8 -3 10 3 1 5 -2 3 -4" stroke-width="1.4"/><path d="M12 80c-5 3 -4 9 1 9" stroke-width=".9"/><path d="M15.5 6.5L24.5 15.5 15.5 24.5 6.5 15.5Z" fill="#160c12" stroke-width="1.4"/><circle cx="15.5" cy="15.5" r="2.2" fill="#e767ce" stroke="none"/></g>`;
export const CORNER_CURLS=CURLS;
const svgImage=(svg,w,h)=>new Promise((res,rej)=>{const img=new Image(w,h);img.onload=()=>res(img);img.onerror=()=>rej(new Error('An image for the card could not be drawn.'));img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);});
/** The braided cord as a canvas pattern. */
async function cordPattern(g,vertical=false){
  const svg=vertical?`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="14"><g transform="scale(2)"><rect width="8" height="7" fill="#1a0f15"/><path d="M.5 -1.5L7.5 5.5" stroke="#bf9d63" stroke-width="2.4" stroke-linecap="round"/><path d="M.5 2L7.5 9" stroke="#eadfcf" stroke-opacity=".8" stroke-width="1.6" stroke-linecap="round"/><path d="M.4 0V7M7.6 0V7" stroke="#5a4330" stroke-width=".8"/></g></svg>`
    :`<svg xmlns="http://www.w3.org/2000/svg" width="14" height="16"><g transform="scale(2)"><rect width="7" height="8" fill="#1a0f15"/><path d="M-1.5 7.5L5.5 .5" stroke="#bf9d63" stroke-width="2.4" stroke-linecap="round"/><path d="M2 7.5L9 .5" stroke="#eadfcf" stroke-opacity=".8" stroke-width="1.6" stroke-linecap="round"/><path d="M0 .4H7M0 7.6H7" stroke="#5a4330" stroke-width=".8"/></g></svg>`;
  return g.createPattern(await svgImage(svg,vertical?16:14,vertical?14:16),'repeat');
}
/** The Keepsake frame on a canvas: cords, four corners of curls, the motto. Used by the share image and photo mode. */
export async function drawKeepsakeFrame(g,W,H,{motto=true,scale=1.6,moon=true,flower=null}={}){
  const C=130*scale,inset=104*scale,hp=await cordPattern(g),vp=await cordPattern(g,true);
  g.save();g.fillStyle=hp;g.translate(0,11*scale);g.fillRect(inset,0,W-inset*2,16);g.restore();
  g.save();g.fillStyle=hp;g.translate(0,H-11*scale-16);g.fillRect(inset,0,W-inset*2,16);g.restore();
  g.save();g.fillStyle=vp;g.translate(11*scale,0);g.fillRect(0,inset,16,H-inset*2);g.restore();
  g.save();g.fillStyle=vp;g.translate(W-11*scale-16,0);g.fillRect(0,inset,16,H-inset*2);g.restore();
  const corner=t=>svgImage(`<svg xmlns="http://www.w3.org/2000/svg" width="${C}" height="${C}" viewBox="0 0 130 130"><g transform="${t}">${CURLS}</g></svg>`,C,C);
  const [tl,tr,bl,br]=await Promise.all(['','translate(130 0) scale(-1 1)','translate(0 130) scale(1 -1)','translate(130 130) scale(-1 -1)'].map(corner));
  g.drawImage(tl,0,0,C,C);g.drawImage(tr,W-C,0,C,C);g.drawImage(bl,0,H-C,C,C);g.drawImage(br,W-C,H-C,C,C);
  if(flower){const k=scale,f=await svgImage(flowerSVG({size:96,...flower}),96,96);g.drawImage(f,(40-17)*k,(40-17)*k,34*k,34*k);}
  if(moon){const m=await svgImage(`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="78 23 28 28"><path d="${MOON}" fill="#efe4d4"/></svg>`,64,64);
    g.save();g.shadowColor='#f3e6d0';g.shadowBlur=8*scale;g.drawImage(m,W-C+78*scale,23*scale,28*scale,28*scale);g.restore();}
  if(motto){g.save();g.font=`italic 400 ${Math.round(12*scale)}px "Keepsake Serif", Georgia, serif`;g.textAlign='center';g.textBaseline='middle';
    const t='you are more than their mirror'.split('').join(String.fromCharCode(8202)),w=g.measureText(t).width+24*scale;g.fillStyle='#0f080c';g.fillRect(W/2-w/2,H-11*scale-16-2,w,24);
    g.fillStyle='#a88a5c';g.fillText(t,W/2,H-11*scale-8);g.restore();}
}
function wrapText(g,text,maxW){const words=String(text).split(/\s+/),lines=[];let line='';for(const w of words){const t=line?line+' '+w:w;if(g.measureText(t).width>maxW&&line){lines.push(line);line=w;}else line=t;}if(line)lines.push(line);return lines;}
/** Draw the share card. Returns the canvas. */
export async function drawShareCard(data,{W=1920,H=1080}={}){
  const doc=globalThis.document;await doc?.fonts?.ready;
  for(const f of ['600 72px "Keepsake Serif"','italic 600 72px "Keepsake Serif"','700 20px "Keepsake Caps"','400 20px "Keepsake Sans"'])try{await doc.fonts.load(f);}catch{}
  const c=doc.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');
  // dusk plum, a warm glow behind the flower
  const bg=g.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#1a0d15');bg.addColorStop(1,'#0e070b');g.fillStyle=bg;g.fillRect(0,0,W,H);
  const glow=g.createRadialGradient(W*.22,H*.48,0,W*.22,H*.48,H*.62);glow.addColorStop(0,'rgba(122,24,48,.42)');glow.addColorStop(1,'rgba(122,24,48,0)');g.fillStyle=glow;g.fillRect(0,0,W,H);
  await drawKeepsakeFrame(g,W,H,{scale:2,flower:{pinned:[],lit:5,sw:.7}});
  const S=2;   // the lab's 960×540 design, at 2×
  // left: the flower and her name
  const fl=await svgImage(flowerSVG({size:460,pinned:data.pinned??[],lit:5,sw:.3,gem:2.3,prefix:'sh'}),460,460);
  g.save();g.shadowColor='rgba(231,103,206,.25)';g.shadowBlur=40;g.drawImage(fl,(44+180)*S-230,(270-40)*S-230,460,460);g.restore();
  g.textAlign='center';g.fillStyle='#cfae76';g.font=`700 ${13*S}px "Keepsake Caps", Georgia, serif`;g.letterSpacing=`${.16*13*S}px`;g.fillText('LITTLE DUSK',224*S,352*S);g.letterSpacing='0px';
  g.fillStyle='#fbf1e4';g.font=`italic 700 ${44*S}px "Keepsake Serif", Georgia, serif`;g.fillText(data.name??'Yvaelle',224*S,396*S);
  g.fillStyle='rgba(243,234,223,.85)';g.font=`italic 400 ${15*S}px "Keepsake Serif", Georgia, serif`;g.fillText('A little light. A steady hand.',224*S,420*S);
  // right
  const X=416*S,RW=(960-56-416)*S;g.textAlign='left';
  g.fillStyle='#cfae76';g.font=`700 ${13*S}px "Keepsake Caps", Georgia, serif`;g.letterSpacing=`${.14*13*S}px`;g.fillText(`SESSION ${data.n} · RECAP`,X,62*S);g.letterSpacing='0px';
  return finishShare(g,c,data,{X,RW,S,W,H});
}
async function finishShare(g,c,data,{X,RW,S,W,H}){
  g.fillStyle='#fbf1e4';g.font=`600 ${36*S}px "Keepsake Serif", Georgia, serif`;g.fillText(String(data.sessionName??''),X,104*S);
  g.fillStyle='#9c8a80';g.font=`400 ${13*S}px "Keepsake Sans", system-ui, sans-serif`;
  g.fillText([data.dates,data.level?`Level ${data.level}`:'',`${data.duration} at the table`].filter(Boolean).join(' · '),X,128*S);
  // heartbeat
  const hb=await svgImage(heartbeatSVG(data,RW/S,72,'sh').replace('<svg ',`<svg xmlns="http://www.w3.org/2000/svg" `).replace(/width="[\d.]+" height="[\d.]+"/,`width="${RW}" height="${72*S}"`),RW,72*S);
  g.drawImage(hb,X,146*S,RW,72*S);
  // stats: four tiles
  const tiles=[['heal','Healed',String(data.healed),data.allies?`across ${data.allies} all${data.allies===1?'y':'ies'}`:'no one needed her','#f08ad9','#ffd8f1'],
    ['hp','Taken',String(data.taken),`lowest ${data.lowest} HP`,'#e2a256','#fbf1e4'],
    ['hero','Hero Points',`${data.hero}`,`spent · ${data.heroKept} kept`,'#cfae76','#fbf1e4',`of ${data.heroMax}`],
    ['crit','Crits',String(data.crits),data.saves?`${data.saves} saved an ally`:'clean and bright','#cfae76','#fbf1e4']];
  const gap=8*S,tw=(RW-gap*3)/4,ty=232*S,th=78*S;
  for(const [i,[k,l,v,sub,ic,vc,small]] of tiles.entries()){
    const x=X+i*(tw+gap);g.fillStyle='rgba(18,10,15,.7)';g.fillRect(x,ty,tw,th);g.strokeStyle='#33222b';g.lineWidth=2;g.strokeRect(x+1,ty+1,tw-2,th-2);
    const img=await svgImage(`<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="${ic}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${I[k].replace(/currentColor/g,ic)}</svg>`,28,28);
    g.drawImage(img,x+10*S,ty+9*S,14*S,14*S);
    g.fillStyle='#bba99c';g.font=`400 ${12*S}px "Keepsake Sans", system-ui, sans-serif`;g.fillText(l,x+30*S,ty+21*S);
    g.fillStyle=vc;g.font=`600 ${28*S}px "Keepsake Serif", Georgia, serif`;g.fillText(v,x+10*S,ty+52*S);
    if(small){const vw=g.measureText(v).width;g.fillStyle='#9c8a80';g.font=`400 ${13*S}px "Keepsake Serif", Georgia, serif`;g.fillText(small,x+10*S+vw+4*S,ty+52*S);
      // her Hero Points as petals: spent ones dim
      if(k==='hero'){const sw=g.measureText(small).width,n=Math.max(1,Math.min(6,data.heroMax));
        for(let j=0;j<n;j++){const on=j>=data.hero,pi=await svgImage(`<svg xmlns="http://www.w3.org/2000/svg" width="18" height="26" viewBox="-4 -9.4 8 10"><path d="M0 0C-3 -4 -2.5 -8 0 -9C2.5 -8 3 -4 0 0Z" fill="#f0dfe4" fill-opacity="${on?1:.18}" stroke="#a3243f" stroke-width=".6" stroke-opacity="${on?1:.5}"/></svg>`,18,26);
          g.drawImage(pi,x+10*S+vw+4*S+sw+8*S+j*11*S,ty+52*S-24,18,26);}}}
    g.fillStyle='#9c8a80';g.font=`400 ${11*S}px "Keepsake Sans", system-ui, sans-serif`;g.fillText(sub,x+10*S,ty+68*S);
  }
  // the moment
  let y=ty+th+30*S;
  if(data.highlight){
    const rule=g.createLinearGradient(0,y,0,y+80*S);rule.addColorStop(0,'#f3d79c');rule.addColorStop(1,'#8a6d45');
    g.fillStyle='#cfae76';g.font=`700 ${11*S}px "Keepsake Caps", Georgia, serif`;g.letterSpacing=`${.12*11*S}px`;g.fillText('THE MOMENT',X+14*S,y+12*S);g.letterSpacing='0px';
    g.fillStyle='#fbf1e4';g.font=`italic 400 ${18*S}px "Keepsake Serif", Georgia, serif`;
    const lines=wrapText(g,data.highlight.line,RW-20*S).slice(0,3);lines.forEach((ln,i)=>g.fillText(ln,X+14*S,y+38*S+i*25*S));
    let end=y+38*S+(lines.length-1)*25*S;
    if(data.highlight.at){g.fillStyle='#9c8a80';g.font=`400 ${12*S}px "Keepsake Sans", system-ui, sans-serif`;g.fillText(data.highlight.at,X+14*S,end+22*S);end+=22*S;}
    g.fillStyle=rule;g.fillRect(X,y,2*S,end-y+6*S);y=end+26*S;
  }
  // foot
  g.fillStyle='#33222b';g.fillRect(X,y,RW,2);y+=26*S;
  g.textBaseline='middle';
  const np=data.petals?.[0]?milestoneById(data.petals[0]):null;let fx=X;
  if(np){const pi=await svgImage(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="33" viewBox="-6 -15.5 12 16.5"><defs>${petalDefs('shp')}</defs>${petalArt(np.id,'shp')}</svg>`,24,33);g.drawImage(pi,fx,y-17,24,33);fx+=36;
    g.fillStyle='#bba99c';g.font=`400 ${12*S}px "Keepsake Sans", system-ui, sans-serif`;g.fillText('New petal',fx,y);fx+=g.measureText('New petal').width+10*S;
    g.fillStyle='#f3d79c';g.font=`italic 500 ${13*S}px "Keepsake Serif", Georgia, serif`;g.fillText(np.name,fx,y);fx+=g.measureText(np.name).width+14*S;
    g.fillStyle='#9c8a80';g.fillText('·',fx,y);fx+=14*S;}
  g.fillStyle='#cfae76';g.font=`400 ${12*S}px "Keepsake Sans", system-ui, sans-serif`;g.fillText(`${data.threads} thread${data.threads===1?'':'s'} woven`,fx,y);
  g.textAlign='right';g.fillStyle='#9c8a80';g.fillText('Yvaelle’s Toolbox · Keepsake',X+RW,y);
  return c;
}
/** Save a canvas as a PNG download. */
export function downloadCanvas(c,filename){
  return new Promise((res,rej)=>c.toBlob(b=>{if(!b){rej(new Error('The image could not be made (the canvas is tainted or too large).'));return;}
    const url=URL.createObjectURL(b),a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),4000);res(filename);},'image/png'));
}
const slug=s=>String(s??'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'recap';
export async function saveShareImage(data){
  const c=await drawShareCard(data);
  return downloadCanvas(c,`${slug(data.name)}-session-${data.n}-recap.png`);
}
export {MILESTONES,PETAL_COLORS,flowerInner};
