/** Persistent instruments and their intended destinations. Temporary actions
 * reserve instruments without rewriting this record, so a return follows the
 * latest explicit command instead of an old saved formation. Pure and bounded. */
import {COMPACT_BIT_PROGRAMS} from './compact-bit-formations.mjs?v=13.0.0-beta.7';
import {BIT_CORE_STATES} from './bit-core-states.mjs?v=13.0.0-beta.7';
import {validateBehaviour,captureBehaviourPose} from './bit-behaviour.mjs?v=13.0.0-beta.7';
import {validateFormationFlow} from './bit-formation-flow.mjs?v=13.0.0-beta.7';
export const ALLOCATION_FLAG='bitAllocations';
export const STATIONS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);
const PROGRAMS=Object.keys(COMPACT_BIT_PROGRAMS);
const STATES=Object.keys(BIT_CORE_STATES);
const tokenId=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(v)&&!['__proto__','prototype','constructor'].includes(v);
const groupId=v=>v==='home'||tokenId(v)&&v!=='retracted';
const finite=(v,min,max)=>Number.isFinite(v)&&v>=min&&v<=max;
const clone=v=>structuredClone(v);
export function defaultGroup(snapshot={}){
  const g=snapshot.gems??{};
  return {program:PROGRAMS.includes(g.soloProgram)?g.soloProgram:'halo',radius:g.soloRadius??1,
    personality:g.personality??.55,passive:g.passiveEffects!==false,internalState:g.coreState??'idle',
    behaviour:{enabled:true,frequency:'attentive',energy:.5,audio:false},
    flow:{enabled:false,pool:[],hold:30000,duration:2600,epoch:0},effect:{id:'shield',enabled:false,strength:1}};
}
export function validateGroupPatch(input={}){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Group settings must be an object.');
  const result={};
  for(const [key,v] of Object.entries(input)){
    if(key==='program'){if(!PROGRAMS.includes(v))throw new Error('Unknown companion formation.');result[key]=v;}
    else if(key==='radius'){if(!finite(v,.4,1.6))throw new Error('Formation radius must be 0.4–1.6.');result[key]=v;}
    else if(key==='personality'){if(!finite(v,0,1))throw new Error('Personality must be 0–1.');result[key]=v;}
    else if(key==='passive'){if(typeof v!=='boolean')throw new Error('Passive gestures must be true or false.');result[key]=v;}
    else if(key==='internalState'){if(!STATES.includes(v))throw new Error('Unknown internal bit state.');result[key]=v;}
    else if(key==='behaviour')result.behaviour=validateBehaviour(v);
    else if(key==='flow')result.flow=validateFormationFlow(v,PROGRAMS);
    else if(key==='effect'){
      if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).some(k=>!['id','enabled','strength','started'].includes(k)))throw new Error('Invalid token effect options.');
      if(v.id!==undefined&&(!tokenId(v.id)||v.id.length>48))throw new Error('Invalid token effect identifier.');
      if(v.enabled!==undefined&&typeof v.enabled!=='boolean')throw new Error('Effect enabled must be true or false.');
      if(v.strength!==undefined&&!finite(v.strength,0,3))throw new Error('Effect strength must be 0–3.');
      if(v.started!==undefined&&!finite(v.started,0,Number.MAX_SAFE_INTEGER))throw new Error('Effect start time must be a non-negative timestamp.');
      result.effect={...v};
    }else throw new Error(`Unknown group setting: ${key}.`);
  }
  return result;
}
export function readAllocations(raw,snapshot={},legacyEvents=[]){
  const count=Math.max(1,Math.min(4,Math.round(snapshot.gems?.count??4))),deployed=(snapshot.bitDeployment??0)>.01;
  const out={version:1,revision:0,preferredCount:count,randomOnSummon:false,bits:{},groups:{home:defaultGroup(snapshot)}};
  for(let i=0;i<4;i++)out.bits[STATIONS[i]]={location:deployed&&i<count?'home':'retracted',revision:0};
  if(raw?.version===1&&raw.bits&&typeof raw.bits==='object'){
    out.revision=Number.isSafeInteger(raw.revision)&&raw.revision>=0?raw.revision:0;
    out.preferredCount=Number.isInteger(raw.preferredCount)&&raw.preferredCount>=1&&raw.preferredCount<=4?raw.preferredCount:count;
    out.randomOnSummon=raw.randomOnSummon===true;
    for(const id of STATIONS){const b=raw.bits[id];if(b&&(b.location==='retracted'||groupId(b.location)))out.bits[id]={location:b.location,revision:Number.isSafeInteger(b.revision)&&b.revision>=0?b.revision:0};}
    for(const [id,g] of Object.entries(raw.groups??{}).slice(0,5)){
      if(!groupId(id))continue;
      try{
        const {transition,...patch}=g,valid=validateGroupPatch(patch);
        out.groups[id]={...defaultGroup(snapshot),...valid,behaviour:{...defaultGroup(snapshot).behaviour,...valid.behaviour},flow:{...defaultGroup(snapshot).flow,...valid.flow},effect:{...defaultGroup(snapshot).effect,...valid.effect}};
        if(transition&&PROGRAMS.includes(transition.fromProgram)&&finite(transition.started,0,Number.MAX_SAFE_INTEGER)&&finite(transition.duration,0,10000)){
          out.groups[id].transition={fromProgram:transition.fromProgram,started:transition.started,duration:transition.duration};
          if(Number.isInteger(transition.fromCount)&&transition.fromCount>=1&&transition.fromCount<=4)out.groups[id].transition.fromCount=transition.fromCount;
          if(Array.isArray(transition.fromStations)&&transition.fromStations.length<=4&&transition.fromStations.every(s=>STATIONS.includes(s)))out.groups[id].transition.fromStations=[...transition.fromStations];
          if(Array.isArray(transition.fromPoses)&&transition.fromPoses.length<=4&&transition.fromPoses.every(p=>STATIONS.includes(p.station)&&['x','y','z','angle','scale','brightness'].every(k=>finite(p[k],-10000,10000))))out.groups[id].transition.fromPoses=transition.fromPoses.map(captureBehaviourPose);
          if(Array.isArray(transition.fromVelocities)&&transition.fromVelocities.length<=4&&transition.fromVelocities.every(p=>STATIONS.includes(p.station)&&['x','y','z','angle','scale','brightness'].every(k=>finite(p[k],-10000,10000))))out.groups[id].transition.fromVelocities=clone(transition.fromVelocities);
          if(Array.isArray(transition.wingFromPoses)&&transition.wingFromPoses.length<=4&&transition.wingFromPoses.every(p=>STATIONS.includes(p.station)&&['x','y','z','angle','scale','brightness'].every(k=>finite(p[k],-10000,10000))))out.groups[id].transition.wingFromPoses=clone(transition.wingFromPoses);
        }
      }catch{/* Invalid remote data cannot introduce unbounded renderer work. */}
    }
  }else for(const event of legacyEvents){
    if(event.kind!=='escort'||event.status==='returning'||!groupId(event.target))continue;
    for(const id of event.bits??[])if(STATIONS.includes(id))out.bits[id].location=event.target;
    out.groups[event.target]={...defaultGroup(snapshot),...event.group};
  }
  for(const b of Object.values(out.bits))if(b.location!=='retracted'&&!out.groups[b.location])out.groups[b.location]=defaultGroup(snapshot);
  return out;
}
export function stationList(input){
  if(!Array.isArray(input)||!input.length||input.length>4||new Set(input).size!==input.length||input.some(v=>!STATIONS.includes(v)))throw new Error('Choose one to four unique bit station IDs.');
  return [...input];
}
export function allocationGroups(record){
  const result=[];
  for(const location of ['home',...new Set(STATIONS.map(id=>record.bits[id].location).filter(v=>!['home','retracted'].includes(v)))]){
    const bits=STATIONS.filter(id=>record.bits[id].location===location);
    if(bits.length)result.push({id:location,target:location==='home'?null:location,bits,count:bits.length,...clone(record.groups[location]??{})});
  }
  return result;
}
/** Returning instruments already own their destination slots. Other members
 * make room during the trip, so the physical-renderer handoff changes no
 * formation membership at the final frame. Queued work owns no position. */
export function formationStations(record,events=[],location='home'){
  return STATIONS.filter(id=>record.bits[id]?.location===location&&!events.some(e=>
    e.status==='running'&&e.kind!=='escort'&&e.bits.includes(id)));
}
export function setDestinations(record,bits,location){
  stationList(bits);if(location!=='retracted'&&!groupId(location))throw new Error('Invalid destination.');
  const next=clone(record);next.revision++;
  for(const id of bits)next.bits[id]={location,revision:next.revision};
  return next;
}
/** Saved destinations survive temporary work. Presence additionally accounts
 * for instruments borrowed out of the token by an active action. Queued work
 * has not launched an instrument and must not make a retracted one look out. */
export function allocationPresence(record,events=[],sourceId=null){
  const active=events.filter(e=>e.status==='running'||e.status==='returning');
  const outBits=[],remoteBits=[],locations={};
  for(const id of STATIONS){
    const saved=record.bits[id].location,event=active.find(e=>e.bits.includes(id));
    const remoteAction=event&&!event.localTransfer&&(event.kind==='utility'&&!event.utility?.followSource||event.target&&event.target!==sourceId);
    if(saved!=='retracted'||event)outBits.push(id);
    if(!['home','retracted'].includes(saved)||remoteAction)remoteBits.push(id);
    locations[id]=event?.status==='running'&&event.target
      ?event.target===sourceId?'home':event.target
      :saved;
  }
  return {outBits,remoteBits,locations};
}
/** Numeric dispatch selects free instruments at home first. Remote groups are
 * never silently dismantled by count controls; borrowing is explicit treatment
 * behaviour and has its own ordering below. */
export function chooseAvailable(record,count,{events=[],target=null,treatment=false,sourceId=null}={}){
  if(!Number.isInteger(count)||count<1||count>4)throw new Error('Choose one to four instruments.');
  const busy=new Set(events.filter(e=>e.kind!=='escort'&&e.status!=='queued').flatMap(e=>e.bits));
  const locations=treatment?allocationPresence(record,events,sourceId).locations:null;
  // Available instruments at the patient, then another remote token, then
  // Ellie, and finally retracted. Busy actions still respect scheduler priority.
  const priority=id=>{const l=locations?.[id]??record.bits[id].location;
    return (busy.has(id)?10:0)+(treatment?(l===target?0:l==='home'?2:l==='retracted'?3:1):l==='home'?1:l==='retracted'?2:3);};
  const candidates=STATIONS.filter(id=>treatment||['home','retracted'].includes(record.bits[id].location)).sort((a,b)=>priority(a)-priority(b)||STATIONS.indexOf(a)-STATIONS.indexOf(b));
  if(candidates.length<count)throw new Error(`Only ${candidates.length} bit${candidates.length===1?' is':'s are'} available beside Ellie or retracted. Recall a group or choose its individual diamonds.`);
  return candidates.slice(0,count);
}
export function deploymentSelection(record,count){
  if(!Number.isInteger(count)||count<0||count>4)throw new Error('Choose zero to four deployed instruments.');
  const local=STATIONS.filter(id=>['home','retracted'].includes(record.bits[id].location));
  const ordered=[...local.filter(id=>record.bits[id].location==='home'),...local.filter(id=>record.bits[id].location==='retracted')];
  return {home:ordered.slice(0,count),retracted:ordered.slice(count)};
}
