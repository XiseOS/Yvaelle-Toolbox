/** Instrument personalities and work gestures. Pure, bounded, shared by live
 * rendering and previews; no timers, randomness, targets or document writes. */
import {createEpisodeMove,boundedFocusLean} from './bit-episode-motion.mjs?v=13.0.0-beta.7';
import {captureCoreActivity} from './bit-core-states.mjs?v=13.0.0-beta.7';
const TAU=Math.PI*2;
export const INSTRUMENT_IDS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);
export const INSTRUMENT_PERSONALITIES=Object.freeze({
  leftUpper:{role:'Surveyor',pace:1.04,lean:-.12},rightUpper:{role:'Keeper',pace:.93,lean:.08},
  leftLower:{role:'Artisan',pace:.98,lean:-.07},rightLower:{role:'Companion',pace:1.02,lean:.11}});
const entry=(name,description)=>Object.freeze({name,description});
const family=(name,counts)=>Object.freeze({name,counts:Object.freeze(counts)});
export const LIVING_BIT_PROGRAMS=Object.freeze({
  curiousCompanions:family('Curious Companions',{
    1:entry('Pocket surveyor','A shoulder visit becomes a careful inspection, with a small lens and a quiet acknowledgement.'),
    2:entry('Lookout & lens','A keeper makes room while the surveyor inspects; they exchange the lead on the next visit.'),
    3:entry('Three perspectives','One close inspection with two attentive witnesses, passing the discovery around the group.'),
    4:entry('Shared discovery','An investigating pair crosses in front while two keep the rear stations; their duties rotate.')}),
  quietExchange:family('Quiet Exchange',{
    1:entry('Private correspondence','A lone companion makes a shoulder checking circuit, offers a tiny packet toward its charge and gathers it back.'),
    2:entry('Passing a thought','Two instruments alternate upper and lower circuit passages, then meet to exchange a travelling pulse.'),
    3:entry('Three-way agreement','A staggered relay moves around a triangular meeting, with each recipient acknowledging it.'),
    4:entry('Paired confidants','Two pairs traverse staggered upper and lower passages on opposite sides, then rendezvous and quietly transfer energy.')}),
  attentiveEscort:family('Attentive Escort',{
    1:entry('Gentle vanguard','One companion checks ahead, pauses to attend its charge and falls into step again.'),
    2:entry('Courteous handover','A forward guide and rear keeper exchange duties through separate, yielding passages.'),
    3:entry('Attendant fan','A lead instrument watches ahead while two escorts open and close an asymmetric protective fan.'),
    4:entry('Watch & welcome','Four escorts pass the lead around a rounded frame, making room and acknowledging their charge.')}),
  livingWorkshop:family('Living Workshop',{
    1:entry('One careful craft','A lone artisan prepares a miniature work surface, checks it with a probe and folds it away.'),
    2:entry('Probe & cradle','Two instruments make complementary checking circuits, then one holds a delicate cradle while its partner works.'),
    3:entry('Triangular workbench','A brace and a reader support the working instrument, sharing light through a small triangular workspace.'),
    4:entry('Ellie’s little atelier','Two pairs circle opposite work lanes, preparing surfaces, checking the frame and passing the work onward.')})
});
export const BIT_GESTURES=Object.freeze({
  inspect:{label:'Inspect',description:'Prepare a lens, read a small area with a scanning wave, then close the instrument.',duration:5600,tool:'lens'},
  attend:{label:'Attend',description:'Approach the charge, open a small supporting surface and settle back into place.',duration:6200,tool:'plate'},
  confer:{label:'Confer',description:'Gather in a measured rendezvous, exchange a pulse and acknowledge one another.',duration:5800,tool:'spark'},
  settle:{label:'Settle',description:'Close working tools, release their remaining energy and return to a quiet posture.',duration:3600,tool:null},
  acknowledge:{label:'Acknowledge',description:'A short deliberate nod and core beat, gently staggered through the group.',duration:2800,tool:null},
  beckon:{label:'Beckon',description:'Curl inward within each instrument’s own lane, then quietly return.',duration:3800,tool:null},
  makeRoom:{label:'Make Room',description:'Open the current arrangement outward, preserving its order and depth, then ease back.',duration:5000,tool:null},
  poise:{label:'Poise',description:'Lift slightly, align inward and tighten the existing mechanisms into a deliberate stillness.',duration:4300,tool:null},
  flourish:{label:'Flourish',description:'A restrained roll along a small oval around each instrument’s own position.',duration:4100,tool:null},
  recalibrate:{label:'Recalibrate',description:'A brief self-check: the existing iris and plates adjust, glint and seat closed.',duration:4600,tool:'plate'}
});
export const WORK_PHASES=Object.freeze(['rest','notice','approach','prepare','work','settle']);
const unit=n=>Math.max(0,Math.min(1,Number(n)||0));
const smooth=n=>{n=unit(n);return n*n*(3-2*n);};
const mix=(a,b,t)=>a+(b-a)*t;
const turn=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
const wrap=(n,m)=>(n%m+m)%m;
const blendStateWeights=(from,to,blend)=>{
  const result={};for(const [state,weight]of Object.entries(from))result[state]=(result[state]??0)+weight*(1-blend);
  for(const [state,weight]of Object.entries(to))result[state]=(result[state]??0)+weight*blend;return result;
};
// Shape channels anticipate each descriptive phase boundary and finish just
// afterwards. A label may change without replacing an already open mechanism.
const settleWeights=(weights,progress)=>blendStateWeights(weights,{settling:1},smooth((progress-.74)/.06));
function episodeStateWeights(progress,working){
  return settleWeights(blendStateWeights({aligning:1},{[working]:1},smooth((progress-.16)/.06)),progress);
}
export function captureBehaviourPose(p){
  const pose=Object.fromEntries(['station','x','y','z','angle','scale','brightness'].map(k=>[k,p[k]]));
  if(p.tool&&['lens','probe','plate','spark'].includes(p.tool.type))pose.tool={type:p.tool.type,amount:unit(p.tool.amount),progress:unit(p.tool.progress),variation:Math.max(0,Math.min(3,Number(p.tool.variation)||0))};
  const activity=captureCoreActivity(p.activity);if(activity)pose.activity=activity;
  if(p.intent&&['inspect','exchange','receive','observe','watch','mend','canopy','lantern','conduct'].includes(p.intent.kind)&&Array.isArray(p.intent.target)&&p.intent.target.length===3&&p.intent.target.every(n=>Number.isFinite(n)&&Math.abs(n)<=10000))pose.intent={kind:p.intent.kind,amount:unit(p.intent.amount),progress:unit(p.intent.progress),target:[...p.intent.target],passive:p.intent.passive===true};
  return pose;
}
export function validateBehaviour(input={}){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Behaviour settings must be an object.');
  const out={};
  for(const [k,v] of Object.entries(input)){
    if(['enabled','audio'].includes(k)){if(typeof v!=='boolean')throw new Error(`${k} must be true or false.`);}
    else if(k==='frequency'){if(!['composed','attentive','expressive'].includes(v))throw new Error('Choose composed, attentive or expressive behaviour.');}
    else if(k==='energy'){if(!Number.isFinite(v)||v<0||v>1)throw new Error('Behaviour energy must be 0–1.');}
    else throw new Error(`Unknown behaviour setting: ${k}.`);
    out[k]=v;
  }
  return out;
}
export function behaviourSettings(input={},personality=.35){
  return {enabled:input.enabled!==false,frequency:input.frequency??(personality<.2?'composed':personality>.7?'expressive':'attentive'),energy:unit(input.energy??.5),audio:input.audio===true};
}
/** Every phase has its own envelope. Tools are already closed before rest,
 * so changes of episode, leader or variation cannot introduce an abrupt pop. */
export function workPhase(progress){
  const p=unit(progress),phase=p<.08?'rest':p<.19?'notice':p<.35?'approach':p<.49?'prepare':p<.77?'work':'settle';
  const engage=smooth((p-.08)/.27)*(1-smooth((p-.77)/.23));
  const work=smooth((p-.35)/.14)*(1-smooth((p-.77)/.17));
  const tool=smooth((p-.38)/.11)*(1-smooth((p-.77)/.15));
  return {phase,progress:p,engage,work,tool};
}
/** Closed routes contain count-specific pauses and separate front/rear lanes.
 * All loops join exactly. Identity affects pace/lean, never slot membership. */
export function livingBase(count,i,time,program,station=INSTRUMENT_IDS[i],enhancedMotion=false){
  const identity=INSTRUMENT_PERSONALITIES[station]??INSTRUMENT_PERSONALITIES.leftUpper;
  const q=time*.18+i*TAU/count,breath=Math.sin(time*.47*identity.pace+i*.9)*2.2;
  let x,y,z,angle;
  if(program==='curiousCompanions'){
    const u=q+.22*count;
    x=(110+9*Math.cos(u*2))*Math.cos(u);y=-18+(count===1?68:54)*Math.sin(u)+8*Math.sin(u*2);
    z=Math.sin(u);angle=.08*Math.sin(u*2);
  }else if(program==='quietExchange'){
    const lane=count===4?Math.floor(i/2):0,side=count===4?(lane?-1:1):(i%2?-1:1);
    if(count===1&&enhancedMotion){const phrase=time*.38;x=108+17*Math.sin(phrase);y=-25+51*Math.sin(phrase-.55);z=.82*Math.cos(phrase);}
    else if(count===1){x=108+8*Math.sin(q);y=-25+47*Math.sin(q*.9);z=Math.cos(q);}
    else if(count===3){x=110*Math.cos(q);y=-9+66*Math.sin(q);z=Math.sin(q);}
    else if(enhancedMotion){
      // Confidants on one side travel together. Opposed half-period loops
      // made their actual partner bearing spin too quickly for the restrained
      // twelve-degree-per-second field to follow. A shared checking passage
      // keeps that partner physically stable while both housings remain alive.
      const phrase=time*.43+lane*1.1+(count===4?0:i%2?Math.PI:0);
      x=side*(106+21*Math.sin(phrase));
      y=count===4?-15+(i%2?-1:1)*37+29*Math.cos(phrase):-15+39*Math.cos(phrase);
      z=.84*Math.sin(phrase+.4);
    }
    else{x=side*(108+7*Math.sin(time*.22+lane));y=-15+(i%2?-1:1)*(37+13*Math.sin(time*.21));z=Math.sin(time*.22+i*Math.PI/2);}
    angle=side*.06*Math.sin(time*.4);
  }else if(program==='attentiveEscort'){
    const lead=time*.2+(count===1?0:i*TAU/count),dwell=Math.tanh(Math.cos(lead)*1.7);
    x=112*dwell;y=-22+(count===1?72:50+count*3)*Math.sin(lead)+9*Math.sin(lead*2);
    z=Math.sin(lead);angle=.1*Math.sin(lead)+identity.lean*.3;
  }else{
    const side=count===1?1:count===2?(i?-1:1):i<count/2?-1:1;
    if(count===3){x=109*Math.cos(q);y=-14+72*Math.sin(q);z=Math.sin(q);}
    else if(enhancedMotion&&count===2){const work=time*.43+i*Math.PI;x=side*(107+20*Math.sin(work));y=-25+40*Math.cos(work);z=.8*Math.sin(work+.35);}
    else if(enhancedMotion&&count===4){const work=time*.48+(i%2?Math.PI:0)+(side<0?0:.7);x=side*(107+21*Math.sin(work));y=(i%2?42:-65)+28*Math.cos(work);z=.82*Math.sin(work+.4);}
    else{x=side*(109+6*Math.sin(time*.23+i));y=count===1?-20+52*Math.sin(time*.2):count===2?-25+32*Math.sin(time*.22+i*Math.PI):(i%2?42:-65)+6*Math.sin(time*.31+i);z=Math.sin(time*.2+i*Math.PI/2);}
    angle=-side*.08+identity.lean*.25;
  }
  return [x,y+breath,z,angle??0];
}
/** Wave-only attention begins while the instruments prepare and remains
 * through the quiet part of their existing episode. It does not enable a tool,
 * increase activity strength or change any position. Partners use the actual
 * sampled point, and work spots remain the same prospective job for the cycle. */
function livingFocusTargets(count,program,poses,{cycle,side,leader}){
  const focusTargets=Array.from({length:count},()=>({kind:'charge',target:[0,-20,0],key:`${program}:${cycle}`}));
  const set=(i,target,kind='work',partnerIndex=null)=>{focusTargets[i]={kind,target:target.slice(0,3),key:`${program}:${cycle}`,...(partnerIndex==null?{}:{partnerIndex})};};
  if(program==='curiousCompanions'){
    const spot=[side*(38+(cycle%3)*5),-26+(cycle%3)*17,.85];set(leader,spot);
    if(count>1){const helper=(leader+1)%count;set(helper,poses[leader],'partner',leader);}
  }else if(program==='quietExchange'){
    if(count===1)set(0,[side*34,-12,.8]);
    else if(count===3){for(let i=0;i<count;i++)set(i,poses[(i+1)%count],'partner',(i+1)%count);}
    else {const pairs=count===4?[[0,1],[2,3]]:[[leader,1-leader]];for(const [a,b]of pairs){set(a,poses[b],'partner',b);set(b,poses[a],'partner',a);}}
  }else if(program==='attentiveEscort'){
    set(leader,[side*40,-35,.8]);for(let i=0;i<count;i++)if(i!==leader)set(i,poses[leader],'partner',leader);
  }else{
    const spot=[side*52,2+(cycle%2)*14,.9];set(leader,spot);
    if(count>1)set((leader+1)%count,spot);
    if(count>2)set((leader+2)%count,[-side*47,-3,-.5]);
    if(count===4)set((leader+3)%count,poses[leader],'partner',leader);
  }
  return focusTargets;
}
/** Shared episode determines cooperation. The fixed identity gives each bit a
 * restrained manner; deterministic cycles vary the lead, side and tool angle. */
export function sampleLivingScene(count,program,clock,{stations=INSTRUMENT_IDS,personality=.35,behaviour={},animated=true,displayOffsets=[],enhancedMotion=false}={}){
  const cfg=behaviourSettings(behaviour,personality),poses=Array.from({length:count},(_,i)=>livingBase(count,i,clock,program,stations[i],enhancedMotion)),intents=[],activities=[],tools=[];
  if(!animated||!cfg.enabled||!(personality>0))return {poses,intents,activities,tools};
  const period=(program==='livingWorkshop'?20:program==='quietExchange'?23:26)*(cfg.frequency==='composed'?2.8:cfg.frequency==='expressive'?.74:1);
  const cycle=Math.floor(clock/period),elapsed=wrap(clock,period),duration=program==='livingWorkshop'?8:7;
  const phase=workPhase((elapsed-(period-duration))/duration),leader=wrap(cycle,count),side=cycle%2?-1:1;
  const focusEpisode={cycle,side,leader};
  if(!phase.engage)return {poses,intents,activities,tools,focusTargets:livingFocusTargets(count,program,poses,focusEpisode)};
  const gesture=program==='curiousCompanions'?'inspect':program==='quietExchange'?'confer':program==='attentiveEscort'?'attend':'inspect';
  const episodeStart=cycle*period+period-duration;
  const referencePoses=Array.from({length:count},(_,i)=>livingBase(count,i,episodeStart,program,stations[i],enhancedMotion));
  const move=createEpisodeMove(poses,referencePoses,phase.engage,{offsets:displayOffsets});
  const set=(i,kind,target,weight=1,partnerIndex=null,tool=null)=>{
    const p=poses[i],identity=INSTRUMENT_PERSONALITIES[stations[i]]??INSTRUMENT_PERSONALITIES.leftUpper;
    const aim=p[3]+boundedFocusLean(p,target,{rotation:p[3],max:.66});
    p[3]=turn(p[3],aim+identity.lean*.18,phase.engage*weight);
    const amount=phase.engage*weight*(.36+.5*unit(personality));
    intents[i]={kind,target,partnerIndex,amount:amount*cfg.energy,progress:phase.progress,phase:phase.phase,episode:cycle,gesture};
    const working=kind==='inspect'?'scanning':kind==='mend'?'open':'conducting';
    activities[i]={state:phase.phase==='settle'?'settling':phase.phase==='notice'?'aligning':working,amount:amount*.72,progress:phase.phase==='settle'?unit((phase.progress-.77)/.23):phase.progress,
      weights:episodeStateWeights(phase.progress,working),settleProgress:unit((phase.progress-.77)/.23),phase:phase.phase,job:kind};
    if(tool)tools[i]={type:tool,amount:phase.tool*weight*cfg.energy,progress:phase.progress,variation:wrap(cycle+i,3)};
  };
  if(program==='curiousCompanions'){
    const spot=[side*(38+(cycle%3)*5),-26+(cycle%3)*17,.85];
    move(leader,[side*96,spot[1]-17,.95]);set(leader,'inspect',spot,1,null,'lens');
    if(count>1){const helper=(leader+1)%count;move(helper,[side*117,spot[1]+26,.9],.6);set(helper,'observe',poses[leader],.42,leader,'spark');}
    if(count===4){const keeper=(leader+2)%count;move(keeper,[-side*111,-43,-.8],.46);set(keeper,'watch',[0,-20,-.5],.27);}
  }else if(program==='quietExchange'){
    if(count===1){move(0,[side*107,-29,.9],.6);set(0,'observe',[side*34,-12,.8],1,null,'spark');}
    else if(count===3){for(let i=0;i<count;i++){const a=-Math.PI/2+i*TAU/3;move(i,[Math.cos(a)*115,-9+Math.sin(a)*87,i===leader?.9:-.3],.72);set(i,i===leader?'exchange':'receive',poses[(i+1)%count],i===leader?1:.38,(i+1)%count,'spark');}}
    else{const pairs=count===4?[[0,1],[2,3]]:[[leader,1-leader]];for(const [a,b]of pairs){const s=count===4?(a===0?-1:1):side;move(a,[s*115,-38,.9]);move(b,[s*116,6,.9]);set(a,'exchange',poses[b],1,b,'spark');set(b,'receive',poses[a],.72,a,'spark');}}
  }else if(program==='attentiveEscort'){
    move(leader,[side*106,-61,.8],.68);set(leader,'canopy',[side*40,-35,.8],.78,null,'plate');
    for(let i=0;i<count;i++)if(i!==leader){const s=i%2?-side:side;move(i,[s*116,i===((leader+1)%count)?33:-40,i%2?-.7:.9],.44);set(i,'observe',poses[leader],.25,leader);}
  }else{
    const spot=[side*52,2+(cycle%2)*14,.9];move(leader,[side*106,-25,.9]);set(leader,'mend',spot,1,null,'probe');
    if(count>1){const helper=(leader+1)%count;move(helper,[side*113,35,.9]);set(helper,'conduct',spot,.8,leader,'plate');}
    if(count>2){const brace=(leader+2)%count;move(brace,[-side*105,20,-.65],.5);set(brace,'canopy',[-side*47,-3,-.5],.4,null,'plate');}
    if(count===4){const witness=(leader+3)%count;set(witness,'observe',poses[leader],.3,leader,'lens');}
  }
  // Copy targets after moves, rather than retaining mutable pose arrays.
  for(const v of intents)if(v)v.target=v.target.slice(0,3);
  return {poses,intents,activities,tools,focusTargets:livingFocusTargets(count,program,poses,focusEpisode),episode:cycle,phase:phase.phase};
}
const finiteBound=(v,bound)=>Number.isFinite(v)&&Math.abs(v)<=bound;
/** A command captures this once, when it actually launches. Station names are
 * identities, never an instruction to move into a left/right choreography slot.
 * Positions and velocities are normalized token-local units; depths keep the
 * currently rendered plane. Incoming velocities are world pixels per second. */
export function captureGestureLayout(ids,origins,center,size=100,{rotation=0,depths={},velocities={}}={}){
  const scale=Math.max(.0001,Number(size)||100),angle=Number(rotation)||0,c=Math.cos(angle),s=Math.sin(angle),poses={};
  for(const id of ids){
    const p=origins[id]??center,x=p.x-center.x,y=p.y-center.y,v=velocities[id]??{},vx=v.x??v.vx??0,vy=v.y??v.vy??0;
    poses[id]={x:(x*c+y*s)/scale,y:(-x*s+y*c)/scale,z:depths[id]??-.8,vx:(vx*c+vy*s)/scale,vy:(-vx*s+vy*c)/scale};
  }
  const order=[...ids].sort((a,b)=>Math.atan2(poses[a].y,poses[a].x)-Math.atan2(poses[b].y,poses[b].x)||INSTRUMENT_IDS.indexOf(a)-INSTRUMENT_IDS.indexOf(b));
  return {version:1,center:{x:center.x,y:center.y},size:scale,rotation:angle,poses,order};
}
export function validGestureLayout(layout,ids=[]){
  if(!layout||layout.version!==1||!layout.center||!finiteBound(layout.center.x,1e6)||!finiteBound(layout.center.y,1e6)||!finiteBound(layout.size,1e5)||layout.size<=0||!finiteBound(layout.rotation,1e6)||!layout.poses||!Array.isArray(layout.order)||layout.order.length<1||layout.order.length>4||new Set(layout.order).size!==layout.order.length)return false;
  const keys=Object.keys(layout.poses);if(keys.length!==layout.order.length||!keys.every(id=>INSTRUMENT_IDS.includes(id)&&layout.order.includes(id))||!ids.every(id=>keys.includes(id)))return false;
  if(layout.sourceRotation!==undefined&&!finiteBound(layout.sourceRotation,1e6)||layout.orientations!==undefined&&(!layout.orientations||typeof layout.orientations!=='object'||!Object.entries(layout.orientations).every(([id,v])=>keys.includes(id)&&finiteBound(v,1e6))))return false;
  return keys.every(id=>{const p=layout.poses[id];return p&&finiteBound(p.x,1e4)&&finiteBound(p.y,1e4)&&finiteBound(p.z,100)&&(p.vx===undefined||finiteBound(p.vx,1e4))&&(p.vy===undefined||finiteBound(p.vy,1e4));});
}
function gesturePartners(ids,poses,order){
  if(ids.length===1)return {[ids[0]]:ids[0]};
  if(ids.length!==4)return Object.fromEntries(order.map((id,i)=>[id,order[(i+1)%order.length]]));
  // The three possible pairings are cheap to compare once against frozen poses.
  // Same-side neighbours cooperate when available; no array-order side swap.
  const options=[[[0,1],[2,3]],[[0,2],[1,3]],[[0,3],[1,2]]],cost=option=>option.reduce((sum,[a,b])=>{
    const p=poses[order[a]],q=poses[order[b]],opposite=p.x*q.x<0?1:0;
    return sum+(p.x-q.x)**2+(p.y-q.y)**2+opposite*.5;
  },0),pairs=options.reduce((best,p)=>cost(p)<cost(best)?p:best,options[0]),partners={};
  for(const [a,b]of pairs){partners[order[a]]=order[b];partners[order[b]]=order[a];}return partners;
}
const localWorld=(p,center,size,angle)=>({x:center.x+(p.x*Math.cos(angle)-p.y*Math.sin(angle))*size,y:center.y+(p.x*Math.sin(angle)+p.y*Math.cos(angle))*size});
const inward=(x,max)=>-Math.sign(x)*Math.min(max,Math.abs(x)*.26);
function laneX(id,x,poses){
  const base=poses[id].x;let lo=-Infinity,hi=Infinity;
  for(const [other,p]of Object.entries(poses))if(other!==id&&Math.abs(p.x-base)>1e-5){const middle=(base+p.x)/2;if(p.x<base)lo=Math.max(lo,middle);else hi=Math.min(hi,middle);}
  if(base>0)lo=Math.max(lo,Math.min(base,.012));else if(base<0)hi=Math.min(hi,Math.max(base,-.012));
  return Math.max(lo,Math.min(hi,x));
}
/** Brief Hermite braking preserves the incoming velocity at an interruption,
 * then seats the bit before its new work begins. It does not accumulate drift. */
function brakeWindow(poses){
  let window=.32;const entries=Object.values(poses),peak=4/27;
  for(let i=0;i<entries.length;i++){
    const p=entries[i],vx=p.vx??0;
    if(p.x*vx<0)window=Math.min(window,.8*Math.abs(p.x)/(peak*Math.abs(vx)));
    for(let j=i+1;j<entries.length;j++){
      const q=entries[j],dx=q.x-p.x,dv=(q.vx??0)-vx;
      if(Math.abs(dx)>1e-5&&dx*dv<0)window=Math.min(window,.8*Math.abs(dx)/(peak*Math.abs(dv)));
    }
  }
  return Math.max(.0001,window);
}
function incomingDrift(p,seconds,reduced,window=.32){
  if(reduced||seconds>=window)return {x:0,y:0};const t=Math.max(0,seconds),w=t*(1-t/window)**2;
  return {x:(p.vx??0)*w,y:(p.vy??0)*w};
}
/** A direction returns to its latest assignment without the dispatch delay or
 * decorative arcs. Derivatives at each endpoint match the captured velocities. */
export function sampleGestureReturn(from,to,progress,duration=1000,{fromVelocity={},toVelocity={},reduced=false,movingTarget=false}={}){
  const t=unit(progress);if(t===0)return {...from};if(t===1)return {...to};
  const seconds=Math.max(0,Number(duration)||0)/1000,h00=2*t**3-3*t**2+1,h10=t**3-2*t**2+t,h01=-2*t**3+3*t**2,h11=t**3-t**2;
  return Object.fromEntries(['x','y'].map(k=>{const arrival=to[k]+(movingTarget&&!reduced?(toVelocity[k]??0)*seconds*(1-t):0);return [k,h00*from[k]+h01*arrival+seconds*(h10*(reduced?0:fromVelocity[k]??0)+h11*(reduced?0:toVelocity[k]??0))];}));
}
/** v10 beta gesture motion. Each gesture gets one signature path that reads at
 * token size; the classic excursions stay available behind the Versions switch. */
let gestureStyle='v10';
export function setGestureStyle(style){gestureStyle=style==='classic'?'classic':'v10';}
export function getGestureStyle(){return gestureStyle;}
function v10Gesture(name,{from,partner,q,engage,work,side,rank,count}){
  const spin=side||1,len=Math.hypot(from.x,from.y)||1,inX=d=>-from.x/len*Math.min(d,len*.3),inY=d=>-from.y/len*Math.min(d,len*.3);
  const pulse=(u,n)=>{const v=unit(u)*n;return Math.sin(Math.PI*(v%1))**2*(v<n?1:0);};
  switch(name){
    case 'inspect':{// close in, then sweep a reading arc side to side
      const sweep=Math.sin(unit((q-.35)/.42)*TAU*1.5)*work;
      return {dx:inX(.17)*engage+.06*sweep,dy:inY(.17)*engage-.03*engage-.018*Math.abs(sweep),angle:-side*.18*engage+.35*sweep};}
    case 'attend':{// dip in and under, holding a cradle with a small steady bob
      return {dx:inX(.19)*engage,dy:inY(.12)*engage+.07*engage+.01*Math.sin(q*TAU*3)*work,angle:-side*.28*engage};}
    case 'confer':{// meet the partner most of the way, touch twice, part
      if(count===1)return {dx:inX(.1)*engage,dy:inY(.1)*engage-.06*engage,angle:.2*Math.sin(q*TAU*2)*work};
      const touch=pulse((q-.35)/.42,2);
      return {dx:(partner.x-from.x)*(.34+.06*touch)*engage,dy:(partner.y-from.y)*(.34+.06*touch)*engage-.025*touch,angle:Math.max(-.3,Math.min(.3,(partner.x-from.x)*.3))*engage};}
    case 'settle':{// sink and drift in, as if exhaling
      const d=smooth(q);return {dx:inX(.07)*d,dy:inY(.04)*d+.075*d-.015*Math.sin(Math.PI*d),angle:side*.12*d};}
    case 'acknowledge':{// two clear nods
      const nod=pulse((q-.1)/.7,2);return {dx:0,dy:.055*nod,angle:-side*.34*nod};}
    case 'beckon':{// two quick inward pulls that ease back slowly
      const v=unit((q-.1)/.72)*2,k=v%1,pull=v<2?(k<.3?smooth(k/.3):1-smooth((k-.3)/.7)):0;
      return {dx:inX(.2)*pull,dy:inY(.2)*pull-.025*pull,angle:side*.4*pull};}
    case 'makeRoom':{// open the whole arrangement wide, hold, close
      return {dx:from.x*.32*engage,dy:from.y*.32*engage,angle:side*.1*engage};}
    case 'poise':{// rise and draw in to a held, upright stillness
      const lift=Math.sin(Math.PI*unit((q-.4)/.4))*work;
      return {dx:inX(.07)*engage,dy:inY(.05)*engage-.1*engage-.02*lift,angle:-side*.06*engage};}
    case 'flourish':{// one full loop with a turn of the instrument, staggered
      const u=smooth(unit((q-.12-rank*.04)/.62)),r=.075;
      return {dx:spin*r*Math.sin(TAU*u),dy:-r*(1-Math.cos(TAU*u)),angle:spin*TAU*u};}
    case 'recalibrate':{// a small figure-eight check, then seat
      const u=unit((q-.3)/.45)*TAU*2;return {dx:.04*Math.sin(u)*work,dy:.022*Math.sin(2*u)*work,angle:.12*Math.sin(2*u)*work};}
  }
  return null;
}
/** Live actions and compact previews share the same captured-angle handoff. */
export function gestureOrientation(origin,aim,easedProgress){return turn(origin,aim,smooth(easedProgress/.35));}
/** Work remains a small excursion from each captured pose. Count choreography
 * changes pairing and timing, never station membership or the current plane. */
export function sampleWorkGesture(name,ids,progress,origins,center,size=100,{energy=.65,reduced=false,layout=null,rotation=0,originDepths={},duration=null,supporting=false}={}){
  const definition=BIT_GESTURES[name];if(!definition)throw new Error('Unknown instrument gesture.');
  const captured=validGestureLayout(layout,ids)?layout:captureGestureLayout(ids,origins,center,size,{rotation,depths:originDepths});
  const poses=Object.fromEntries(ids.map(id=>[id,captured.poses[id]])),order=captured.order.filter(id=>ids.includes(id)),partners=gesturePartners(ids,poses,order),phase=workPhase(progress),count=ids.length;
  const out={positions:{},rotations:{},depths:{},glows:{},coreStates:{},tools:{},intents:[]},local={},details={},strength=unit(energy),movement=reduced?0:supporting?.4:1,braking=brakeWindow(poses);
  for(const id of ids){
    const from=poses[id],rank=order.indexOf(id),partner=poses[partners[id]],side=Math.sign(from.x),delay=count===1?0:name==='acknowledge'||name==='recalibrate'?rank*.035:name==='flourish'&&count>2?(rank%2)*.055:0;
    const q=unit((progress-delay)/(1-delay)),work=workPhase(q),engage=work.engage,beat=Math.sin(Math.PI*smooth((q-.08)/.65))**2,drift=incomingDrift(from,unit(progress)*(duration??definition.duration)/1000,reduced,braking);
    let dx=0,dy=0,angle=0,state='conducting',amount=engage*.65,tool=definition.tool,toolAmount=work.tool*strength,light=work.work*.65,target={x:0,y:0,z:from.z},kind=null;
    if(name==='inspect'){
      dx=inward(from.x,.105)*engage;dy=-.018*engage+.016*Math.sin(q*TAU)*engage;angle=-side*.18*engage;state='scanning';kind='inspect';target={x:from.x+inward(from.x,.21),y:from.y-.03,z:from.z};
    }else if(name==='attend'){
      dx=inward(from.x,.13)*engage;dy=-.025*engage;angle=-side*.16*engage;state='bracing';kind='canopy';target={x:from.x+inward(from.x,.23),y:from.y+.035,z:from.z};
    }else if(name==='confer'){
      dx=(partner.x-from.x)*.12*engage;dy=(partner.y-from.y)*.12*engage;angle=Math.max(-.22,Math.min(.22,(partner.x-from.x)*.18))*engage;kind=count>1?'exchange':'observe';
    }else if(name==='settle'){
      state='settling';amount=.6*(1-smooth(q));light=0;
    }else if(name==='acknowledge'){
      dy=.029*beat;angle=-side*.22*beat;state='aligning';amount=beat*.46;light=beat*.4;
    }else if(name==='beckon'){
      dx=inward(from.x,.125)*beat;dy=-.04*Math.sin(q*TAU)*engage;angle=side*.28*Math.sin(q*TAU)*engage;state='aligning';amount=engage*.4;light=beat*.25;
    }else if(name==='makeRoom'){
      dx=from.x*.12*engage;dy=from.y*.12*engage;angle=side*.08*engage;state='bracing';amount=engage*.38;light=work.work*.2;
    }else if(name==='poise'){
      dy=-.046*engage;angle=-side*.20*engage;state=work.phase==='work'?'encased':'aligning';amount=engage*.6;light=work.work*.18;
    }else if(name==='flourish'){
      const ellipse=q*TAU,r=Math.min(.055,Math.abs(from.x)*.28),spin=side||1;
      dx=spin*r*Math.sin(ellipse)*engage;dy=.035*(1-Math.cos(ellipse))*engage;angle=spin*.72*Math.sin(ellipse)*engage;state='aligning';amount=engage*.38;light=work.work*.26;
    }else if(name==='recalibrate'){
      const check=Math.sin(q*TAU*2)*work.work;angle=(side||1)*.065*check;state=q<.59?'aligning':'encased';amount=work.tool*.5;toolAmount=work.tool*strength*.28;light=Math.sin(Math.PI*smooth((q-.39)/.35))**2*.36;
    }
    if(gestureStyle==='v10'){const v=v10Gesture(name,{from,partner,q,engage,work:work.work,side,rank,count});if(v){dx=v.dx;dy=v.dy;angle=v.angle;}}
    // Make Room is a uniform expansion, which mathematically retains order.
    // Other gestures stay in disjoint captured lanes, even on irregular layouts.
    const x=from.x+dx*movement,y=from.y+dy*movement+drift.y;
    local[id]={x:(name==='makeRoom'||gestureStyle==='v10'&&Math.abs(from.x)<.03?x:laneX(id,x,poses))+drift.x,y,z:from.z};out.positions[id]=localWorld(local[id],center,size,rotation);
    out.rotations[id]=reduced?0:angle;out.depths[id]=from.z;
    out.glows[id]={strength:(.45+light*strength)*(name==='settle'?1-.35*q:1),mode:'core',color:null};
    let weights={ [state]:1 };
    if(name==='poise')weights=blendStateWeights({aligning:1},{encased:1},smooth((q-.465)/.05));
    else if(name==='recalibrate')weights=blendStateWeights({aligning:1},{encased:1},smooth((q-.565)/.05));
    if(name!=='settle')weights=settleWeights(weights,q);
    out.coreStates[id]={state:work.phase==='settle'?'settling':state,amount,progress:name==='settle'?q:work.phase==='settle'?unit((q-.77)/.23):q,
      weights,settleProgress:name==='settle'?q:unit((q-.77)/.23),phase:work.phase};
    if(tool)out.tools[id]={type:tool,amount:toolAmount,progress:q,variation:rank%3};
    details[id]={kind,target,work,q};
  }
  for(const id of ids){
    const {kind,target,work,q}=details[id];if(!kind)continue;
    const localTarget=name==='confer'&&count>1?local[partners[id]]:target,world=localWorld(localTarget,center,size,rotation),p=out.positions[id];
    out.intents.push({station:id,x:p.x,y:p.y,z:out.depths[id],intent:{kind,amount:work.work*strength*.58,progress:q,target:[world.x,world.y,localTarget.z],passive:true}});
  }
  return {...out,phase:phase.phase};
}
