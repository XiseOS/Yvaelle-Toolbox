/** Yvaelle’s Toolbox v12 · Field menus (12.0.0-beta.13): a small menu under her decoy and under each job her bits are out on.
 *
 * Held key → the menus appear where the things are, on the map; released → they go. Nothing exists while they are
 * hidden: no element, no frame callback, no listener on the page but the key itself.
 * They are drawn in the quick wheel's language (styles/field-menus.css): a filament down from the thing, a cut-cornered
 * plaque with its name and state, and a row of hardlight gems, each with its name under it.
 *
 *   her decoy          Look (hardlight ↔ normal) · Dismiss
 *   a parked light     Call back
 *   a scan / an exam   Pause ↔ Resume · Slower · Faster · Recall
 *   bits sent out      Recall
 *   bits with another creature (stationed on it, or following it)   Recall
 *   a treatment under way on a creature                              Stop
 * (a cast decoy holds her bits at its corners with jobs of its own: those belong to the decoy's menu, not to menus of theirs)
 *
 * Shown while: the module's own key "Menus on her decoy and bits" is held (none is assigned as it comes: she sets it in
 * Configure Controls; tap it to leave them up, tap again or Escape to put them away) · the pointer is still on one of them ·
 * and, only where the part "Alt shows them too" is switched on, while Foundry's highlight key (Alt) is held.
 * Every action goes through the same entry points the HUD and the wheel use. */
import {ID} from '../config.mjs?v=13.0.0-beta.7';
import {isOn,partOn} from '../v11/features.mjs?v=13.0.0-beta.7';

export const FIELD_KEY='fieldMenus';
/** Scan speed steps (the scan clock takes .25 to 1.5). */
export const SPEED_STEP=1.3,SPEED_MIN=.25,SPEED_MAX=1.5;
export const stepSpeed=(speed,dir)=>{const s=Number.isFinite(speed)?speed:.6,v=dir>0?s*SPEED_STEP:s/SPEED_STEP;return Math.round(Math.max(SPEED_MIN,Math.min(SPEED_MAX,v))*100)/100;};
const finite=n=>typeof n==='number'&&Number.isFinite(n);
/** The gems' icons (24 px grid, stroked, as the quick wheel's). */
export const FIELD_ICONS=Object.freeze({
  look:'M12 3.5v17M12 3.5a8.5 8.5 0 0 0 0 17M14.5 4.4v.1M17.4 6v.1M19.4 8.6v.1M20.3 12v.1M19.4 15.4v.1M17.4 18v.1M14.5 19.6v.1M9 8.5a3.5 3.5 0 0 0 0 7',
  dismiss:'M6.5 6.5l11 11M17.5 6.5l-11 11',pause:'M9 6v12M15 6v12',resume:'M8.5 5.5v13l10-6.5z',
  slower:'M11.5 7l-5 5 5 5M18 7l-5 5 5 5',faster:'M6 7l5 5-5 5M12.5 7l5 5-5 5',recall:'M9 14.5L4 9.5l5-5M4 9.5h10.5a5.5 5.5 0 0 1 0 11H11'});
const TITLES=Object.freeze({areaScan:'Area scan',creatureScan:'Examination',parkLight:'Parked light',dispatch:'Bits sent out'});

/** The menus for one token (pure). size: her token's width in scene px. decoy: api.decoy.status() while one stands, else null.
 * tool: getBitToolState(): {tasks:[{id,mode,bits,target,center,paused,editable,scanSpeed}], sources:[{id,x,y}]}.
 * bits: api.bits.getState(): {allocations:[{id,location}], active:[{id,kind,status,bits,target}]} (her bits with other creatures, treatments).
 * targets: id → {x,y,w,h,name} for the tokens the jobs are on. self: her own token's {x,y,w,h} (a menu that would lie on her goes under her instead). Each menu: {key, kind, title, sub, x, y (scene px: its top middle), buttons:[{act,label,title,on?,off?}]}. */
export function fieldMenus({tokenId='',size=100,decoy=null,tool=null,bits=null,targets=()=>null,self=null}={}){
  const out=[],gap=Math.max(6,size*.12),held=new Set(decoy?.jobs??[]);
  if(decoy&&decoy.phase!=='end'&&decoy.phase!=='gone'&&finite(decoy.x)&&finite(decoy.y)){
    const normal=decoy.look==='normal';
    out.push({key:`${tokenId}:decoy`,token:tokenId,kind:'decoy',title:'Decoy',sub:normal?'looks like her':'hardlight',x:decoy.x,y:decoy.y+size*.5+gap,
      buttons:[{act:'decoyLook',icon:'look',label:normal?'Hardlight':'Normal',title:normal?'Show it as a hardlight projection':'Show it as her, as she is'},{act:'decoyDismiss',icon:'dismiss',label:'Dismiss',title:'End the decoy'}]});
  }
  const at=new Map((tool?.sources??[]).filter(s=>finite(s?.x)&&finite(s?.y)).map(s=>[s.id,s]));
  for(const t of tool?.tasks??[]){
    if(!t||typeof t.id!=='string'||held.has(t.id))continue;
    const pts=(t.bits??[]).map(b=>at.get(b)).filter(Boolean),on=t.target?targets(t.target):null;let x,y;
    if(on&&finite(on.x)&&finite(on.y)){x=on.x+(on.w??size)/2;y=on.y+(on.h??size)+gap;}
    else if(pts.length){x=pts.reduce((a,p)=>a+p.x,0)/pts.length;y=Math.max(...pts.map(p=>p.y))+size*.16+gap;}
    else if(finite(t.center?.x)&&finite(t.center?.y)){x=t.center.x;y=t.center.y+size*.16+gap;}
    else continue;
    // bits working round her (a scan that follows her): the menu would lie on her picture, so it goes under her
    if(self&&finite(self.x)&&finite(self.y)&&x>self.x-size*.6&&x<self.x+(self.w??size)+size*.6&&y>self.y-gap&&y<self.y+(self.h??size)+gap){x=self.x+(self.w??size)/2;y=self.y+(self.h??size)+gap;}
    const scan=t.mode==='areaScan'||t.mode==='creatureScan',buttons=[];
    if(scan){
      const can=t.editable!==false,sp=finite(t.scanSpeed)?t.scanSpeed:.6;
      buttons.push({act:'pause',icon:t.paused?'resume':'pause',label:t.paused?'Resume':'Pause',title:t.paused?'Carry on with it':'Hold it where it is',on:!!t.paused,off:!can});
      buttons.push({act:'slower',icon:'slower',label:'Slower',title:'Scan more slowly',off:!can||sp<=SPEED_MIN+1e-6});
      buttons.push({act:'faster',icon:'faster',label:'Faster',title:'Scan more quickly',off:!can||sp>=SPEED_MAX-1e-6});
    }
    buttons.push({act:'recall',icon:'recall',label:t.mode==='parkLight'?'Call back':'Recall',title:t.mode==='parkLight'?'Call the light back to her':'Call these bits back to her',off:t.editable===false});
    out.push({key:`${tokenId}:${t.id}`,token:tokenId,kind:'task',task:t.id,mode:t.mode,speed:finite(t.scanSpeed)?t.scanSpeed:null,paused:!!t.paused,title:TITLES[t.mode]??'Bits at work',
      sub:t.paused?'paused':t.editable===false?'coming back':scan&&finite(t.scanSpeed)?`speed ${Math.round(t.scanSpeed*100)}%`:'',x,y,buttons});
  }
  // her bits with another creature (stationed on it or following it), and a treatment under way on one
  const working=new Set((tool?.tasks??[]).flatMap(t=>t?.bits??[])),under=(id)=>{const on=id&&id!==tokenId?targets(id):null;return on&&finite(on.x)&&finite(on.y)?on:null;};
  const treated=new Set();
  for(const e of bits?.active??[]){
    if(!e||typeof e.id!=='string'||e.kind==='utility'||e.kind==='escort'||e.status==='returning')continue;const on=under(e.target);if(!on)continue;
    for(const b of e.bits??[])treated.add(b);
    out.push({key:`${tokenId}:ev:${e.id}`,token:tokenId,kind:'event',event:e.id,title:e.kind==='treatment'?'Treatment':'Bits at work',sub:on.name?`on ${on.name}`:'',x:on.x+(on.w??size)/2,y:on.y+(on.h??size)+gap,
      buttons:[{act:'stopEvent',icon:'dismiss',label:'Recall',title:'Call these bits back now. This ends what is shown, not the treatment itself: its roll and result stand.'}]});
  }
  const withTarget=new Map();
  for(const a of bits?.allocations??[]){if(!a||['home','retracted'].includes(a.location)||working.has(a.id)||treated.has(a.id)||!under(a.location))continue;if(!withTarget.has(a.location))withTarget.set(a.location,[]);withTarget.get(a.location).push(a.id);}
  for(const [loc,ids] of withTarget){const on=under(loc);
    out.push({key:`${tokenId}:with:${loc}`,token:tokenId,kind:'bits',bits:ids,title:ids.length>1?`${ids.length} bits`:'Bit',sub:on.name?`with ${on.name}`:'',x:on.x+(on.w??size)/2,y:on.y+(on.h??size)+gap,
      buttons:[{act:'recallBits',icon:'recall',label:'Recall',title:ids.length>1?'Call these bits back to her':'Call this bit back to her'}]});}
  return out;
}
/** The rack under a menu's plaque (pure): a slice of a ring, n gems on it. Half its span H (px), how far its middle hangs (sag),
 * each gem's x from the middle and y down the curve, and the curve's two halves as SVG paths drawn from the middle outward. */
export const RACK=Object.freeze({pitch:54,over:28,gem:36,top:9});
export function rackOf(n){
  n=Math.max(1,Math.min(8,n|0));const H=(n-1)/2*RACK.pitch+RACK.over,sag=7+n*2,f=v=>+v.toFixed(1);
  const gems=[];for(let i=0;i<n;i++){const x=(i-(n-1)/2)*RACK.pitch;gems.push({x:f(x),y:f(sag*(1-(x/H)**2)),d:Math.round(Math.abs(i-(n-1)/2))});}
  const cy=RACK.top+RACK.gem/2,half=sgn=>`M${f(H)} ${f(cy+sag)}Q${f(H+sgn*H/2)} ${f(cy+sag)} ${f(H+sgn*H)} ${f(cy)}`;
  return {n,H:f(H),sag:f(sag),width:f(H*2),height:f(RACK.top+sag+RACK.gem+24),cy:f(cy),gems,left:half(-1),right:half(1),
    whole:`M0 ${f(cy)}Q${f(H)} ${f(cy+2*sag)} ${f(2*H)} ${f(cy)}`};
}
/** What a button does (pure): the call to make, as [entry, ...args]. */
export function fieldAction(menu,act){
  switch(act){
    case 'decoyLook':return ['decoy.setLook'];
    case 'decoyDismiss':return ['decoy.dismiss'];
    case 'pause':return ['setBitToolPaused',!menu.paused,{id:menu.task}];
    case 'slower':return ['setBitToolScanSpeed',stepSpeed(menu.speed,-1),{id:menu.task}];
    case 'faster':return ['setBitToolScanSpeed',stepSpeed(menu.speed,1),{id:menu.task}];
    case 'recall':return ['stopBitTool',{id:menu.task}];
    case 'recallBits':return ['bits.recall',{bits:[...(menu.bits??[])]}];
    case 'stopEvent':return ['bits.cancel',menu.event,'stopped from the map'];
    default:return null;
  }
}

export const TAP_MS=260,REFRESH_MS=140,LINGER_MS=350,CLOSE_MS=230,FOLLOW_MS=90,FOLLOW_SNAP=400,FIRE_MS=520;
/** A gem: its orbit and the bit on it, the ring that answers the pointer, and the cut stone (four facets round a table, lit from
 * the upper left; a line of light on the table's upper edge), with the glint that crosses it. The icon goes on top. */
const GEM_HTML='<i class="ff-fm-orbit"><i></i></i><i class="ff-fm-ring"></i><span class="ff-fm-stone"><svg class="ff-fm-cut" viewBox="0 0 36 36" aria-hidden="true">'
  +'<path class="ff-fm-f1" d="M18 1L3 18h7l8-9z"/><path class="ff-fm-f2" d="M18 1l15 17h-7l-8-9z"/><path class="ff-fm-f3" d="M3 18l15 17v-8l-8-9z"/><path class="ff-fm-f4" d="M33 18L18 35v-8l8-9z"/>'
  +'<path class="ff-fm-tb" d="M18 9l8 9-8 9-8-9z"/><path class="ff-fm-tl" d="M18 9l-8 9h3l5-5.6 5 5.6h3z"/><path class="ff-fm-ln" d="M18 1v8M3 18h7M33 18h-7M18 35v-8"/><path class="ff-fm-ed" d="M18 1l15 17-15 17L3 18z"/>'
  +'</svg><i class="ff-fm-shine"></i></span>';
/** A name or an icon that changed while the menu is up comes in with a small move (restart its animation). */
const swap=el=>{try{el.classList.remove('ff-fm-swap');void el.offsetWidth;el.classList.add('ff-fm-swap');}catch{}};
export class FieldMenus{
  constructor({api=()=>globalThis.game?.modules?.get?.(ID)?.api,now=()=>globalThis.performance?.now?.()??Date.now()}={}){
    this.api=api;this.now=now;this.alt=false;this.key=false;this.pinned=false;this.hover=false;this.root=null;this.els=new Map();this.menus=[];this.frame=0;this.last=-Infinity;this.downAt=0;this.linger=0;this.events=null;this.shownAt=new Map();this.dying=new Set();this.lastFrame=0;
    this.stats={shown:0,acts:0};
  }
  enabled(){try{return isOn(FIELD_KEY,null)!==false;}catch{return true;}}
  // (12.0.0-beta.15) Alt is off as it comes: the menus have a key of their own, which she sets herself
  altOn(){try{return partOn(FIELD_KEY,'fieldAlt',null)===true;}catch{return false;}}
  install(){
    const H=globalThis.Hooks;if(!H?.on)return this;
    H.on('highlightObjects',active=>{this.alt=!!active&&this.altOn();this.sync();});
    H.on('canvasTearDown',()=>this.reset());
    globalThis.window?.addEventListener?.('blur',()=>{this.alt=false;this.key=false;this.sync();});
    return this;
  }
  /** The module's own key: held shows them; a tap leaves them up (or puts them away). */
  keyDown(){if(!this.enabled())return false;if(this.key)return true;this.key=true;this.downAt=this.now();this.sync();return true;}
  keyUp(){if(!this.key)return false;this.key=false;if(this.now()-this.downAt<TAP_MS)this.pinned=!this.pinned;this.sync();return true;}
  /** Show or hide them from a script or the self-check (as a pin). */
  show(on=true){this.pinned=!!on&&this.enabled();if(!on){this.alt=this.key=this.hover=false;}this.sync();return this.shown();}
  shown(){return !!this.root;}
  reset(){this.alt=this.key=this.pinned=this.hover=false;this.close(true);for(const r of this.dying)r.remove();this.dying.clear();}
  wanted(){return this.enabled()&&(this.alt||this.key||this.pinned||this.hover);}
  sync(){if(this.wanted())this.open();else this.close();}
  /** Her tokens here: the ones this user owns that the module runs on. */
  tokens(){const out=[];for(const t of globalThis.canvas?.tokens?.placeables??[]){const d=t?.document;if(!d?.isOwner)continue;let f=null;try{f=d.getFlag?.(ID,'flight');}catch{}if(f)out.push(t);}return out;}
  collect(){
    const api=this.api(),out=[];if(!api)return out;
    const targets=id=>{const t=globalThis.canvas?.tokens?.get?.(id);return t&&t.visible!==false?{x:t.x,y:t.y,w:t.w,h:t.h,name:String(t.document?.name??t.name??'').slice(0,24)}:null;};
    for(const token of this.tokens()){
      let decoy=null,tool=null,bits=null;
      try{decoy=api.decoy?.active?.(token)?api.decoy.status(token):null;}catch{}
      try{tool=api.getBitToolState?.(token)??null;}catch{}
      try{bits=api.bits?.getState?.(token)??null;}catch{}
      if(!decoy&&!tool?.tasks?.length&&!bits?.active?.length&&!bits?.remoteBits?.length)continue;
      for(const m of fieldMenus({tokenId:token.id,size:token.w??100,decoy,tool,bits,targets,self:{x:token.x,y:token.y,w:token.w,h:token.h}}))out.push(m);
    }
    return out;
  }
  open(){
    const doc=globalThis.document,view=doc?.defaultView;if(!doc?.body||!view)return;
    if(!this.root){
      const menus=this.collect();if(!menus.length){this.menus=menus;if(!this.frame&&(this.alt||this.key||this.pinned))this.frame=view.requestAnimationFrame(t=>this.tick(t));return;}
      this.mount(doc);
    }
    if(!this.frame)this.frame=view.requestAnimationFrame(t=>this.tick(t));
  }
  mount(doc){
    const root=this.root=doc.createElement('div');root.className='ff-fm-layer';root.setAttribute('role','group');root.setAttribute('aria-label','Her decoy and bits');// (12.1.0-beta.1) the module's own Reduced motion (and Foundry's photosensitive mode) still the menus, as the system's setting does
    try{if(globalThis.game?.settings?.get(ID,'reducedMotion')||globalThis.canvas?.photosensitiveMode)root.classList.add('ff-fm-still');}catch{}
    doc.body.append(root);this.stats.shown++;
    const Abort=doc.defaultView.AbortController??AbortController;this.events=new Abort();const signal=this.events.signal;
    // the pointer on a menu keeps them up after the key is let go; off them, they stay a moment longer (the way to the next one)
    const view=doc.defaultView;
    root.addEventListener('pointerenter',()=>{view.clearTimeout(this.linger);this.hover=true;},{signal,capture:true});
    // (12.0.2) leaving one part of a gem for another part of the same gem is a leave with no enter after it: ask the page
    // whether the pointer is still on a menu before putting them away (they used to close under the pointer)
    root.addEventListener('pointerleave',()=>{view.clearTimeout(this.linger);this.linger=view.setTimeout(()=>{if(this.root===root&&root.matches?.(':hover'))return;this.hover=false;this.sync();},LINGER_MS);},{signal,capture:true});
    root.addEventListener('pointerdown',e=>{e.stopPropagation();},{signal});
    // (12.0.2) a pressed gem must not keep the keyboard: Space (Foundry's pause) or Enter would press it again
    root.addEventListener('mousedown',e=>{e.preventDefault();},{signal});
    root.addEventListener('contextmenu',e=>{e.preventDefault();e.stopPropagation();},{signal});
    root.addEventListener('click',e=>{const b=e.target?.closest?.('button[data-act]');if(!b||b.disabled)return;e.preventDefault();e.stopPropagation();b.classList.remove('ff-fm-fired');void b.offsetWidth;b.classList.add('ff-fm-fired');view.setTimeout(()=>b.classList?.remove('ff-fm-fired'),FIRE_MS);try{b.blur?.();}catch{}void this.act(b.closest('[data-key]')?.dataset.key,b.dataset.act);},{signal});
    doc.addEventListener('keydown',e=>{if(e.key==='Escape'&&this.pinned){this.pinned=false;this.sync();}},{signal});
  }
  /** Put them away: a short fold (the layer fades and lifts), or at once (a scene torn down). */
  close(now=false){
    const root=this.root,view=root?.ownerDocument?.defaultView??globalThis.window;
    if(this.frame){view?.cancelAnimationFrame?.(this.frame);this.frame=0;}
    try{view?.clearTimeout?.(this.linger);}catch{}
    this.events?.abort();this.events=null;this.root=null;this.els.clear();this.shownAt.clear();this.menus=[];this.hover=false;this.last=-Infinity;this.lastFrame=0;
    if(!root)return;
    if(now||!view?.setTimeout||!root.classList){root.remove();return;}
    root.classList.add('ff-fm-closing');root.style.pointerEvents='none';this.dying.add(root);
    view.setTimeout(()=>{root.remove();this.dying.delete(root);},CLOSE_MS);
  }
  tick(t){
    this.frame=0;if(!this.wanted()){this.close();return;}
    const doc=globalThis.document,view=doc.defaultView;
    if(t-this.last>=REFRESH_MS){this.last=t;this.menus=this.collect();if(this.menus.length&&!this.root)this.mount(doc);if(this.root)this.render();}
    if(this.root)this.place(t);
    this.frame=view.requestAnimationFrame(n=>this.tick(n));
  }
  /** Bring the elements in line with the menus: made once, then changed in place (a pressed gem keeps turning while its name changes). */
  render(){
    const doc=this.root.ownerDocument,seen=new Set();
    for(const m of this.menus){
      seen.add(m.key);let el=this.els.get(m.key);
      if(!el){
        el=doc.createElement('div');el.className='ff-fm';el.dataset.key=m.key;el.dataset.kind=m.kind;
        const inner=doc.createElement('div');inner.className='ff-fm-in';
        const stem=doc.createElement('i');stem.className='ff-fm-stem';
        const plaque=doc.createElement('div');plaque.className='ff-fm-plaque';const span=doc.createElement('span'),b=doc.createElement('b'),small=doc.createElement('small');span.append(b,small);plaque.append(span);
        const rack=doc.createElement('div');rack.className='ff-fm-rack';rack.setAttribute('role','toolbar');const arc=doc.createElement('div');rack.append(arc);
        inner.append(stem,plaque,rack);el.append(inner);el.parts={b,small,rack,arc,n:0,buttons:new Map()};
        this.root.append(el);this.els.set(m.key,el);
      }
      const P=el.parts;
      if(P.b.textContent!==m.title)P.b.textContent=m.title;
      if(P.small.textContent!==(m.sub??'')){const first=!P.small.dataset.seen;P.small.dataset.seen='1';P.small.textContent=m.sub??'';if(!first)swap(P.small);}
      const acts=new Set(m.buttons.map(b=>b.act));
      for(const [act,btn] of [...P.buttons])if(!acts.has(act)){btn.remove();P.buttons.delete(act);}
      // the rack: a slice of the wheel's ring, sized to her gems
      const R=rackOf(m.buttons.length);
      if(P.n!==R.n){P.n=R.n;P.rack.style.width=`${R.width}px`;P.rack.style.height=`${R.height}px`;
        P.arc.innerHTML=`<svg class="ff-fm-arc" width="${R.width}" height="${R.height}" viewBox="0 0 ${R.width} ${R.height}" aria-hidden="true">`
          +`<path class="ff-fm-a2" pathLength="1" d="${R.left}" transform="translate(0 3.5)"/><path class="ff-fm-a2" pathLength="1" d="${R.right}" transform="translate(0 3.5)"/>`
          +`<path class="ff-fm-a1" pathLength="1" d="${R.left}"/><path class="ff-fm-a1" pathLength="1" d="${R.right}"/><path class="ff-fm-run" pathLength="1" d="${R.whole}"/>`
          +`<rect class="ff-fm-end" x="-2.5" y="${R.cy-2.5}" width="5" height="5" transform="rotate(45 0 ${R.cy})"/><rect class="ff-fm-end" x="${R.width-2.5}" y="${R.cy-2.5}" width="5" height="5" transform="rotate(45 ${R.width} ${R.cy})"/></svg>`;}
      m.buttons.forEach((b,i)=>{
        let btn=P.buttons.get(b.act);const g=R.gems[i]??R.gems[0];
        if(!btn){
          btn=doc.createElement('button');btn.type='button';btn.className='ff-fm-g';btn.dataset.act=b.act;btn.tabIndex=-1;
          const fl=doc.createElement('span');fl.className='ff-fm-float';fl.innerHTML=GEM_HTML;const gem=doc.createElement('span');gem.className='ff-fm-ico';fl.append(gem);
          const lab=doc.createElement('span');lab.className='ff-fm-lab';btn.append(fl,lab);btn.gem=gem;btn.lab=lab;
          P.rack.append(btn);P.buttons.set(b.act,btn);
        }
        const pos=`${g.x}|${g.y}|${i}`;if(btn.dataset.pos!==pos){btn.dataset.pos=pos;const st=btn.style;st.setProperty?.('--ff-fm-x',`${g.x}px`);st.setProperty?.('--ff-fm-y',`${g.y}px`);st.setProperty?.('--ff-fm-i',String(i));st.setProperty?.('--ff-fm-d',String(g.d));}
        const sig=`${b.icon}|${b.label}|${b.on?1:0}|${b.off?1:0}`;if(btn.dataset.sig===sig)return;const first=!btn.dataset.sig;btn.dataset.sig=sig;
        if(btn.dataset.icon!==b.icon){btn.dataset.icon=b.icon;btn.gem.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true"${first?'':' class="ff-fm-swap"'}><path d="${FIELD_ICONS[b.icon]??''}"/></svg>`;}
        if(btn.lab.textContent!==b.label){btn.lab.textContent=b.label;if(!first)swap(btn.lab);}
        btn.title=b.title??b.label;btn.setAttribute('aria-label',`${m.title}: ${b.label}`);
        btn.classList.toggle('ff-fm-on',!!b.on);btn.disabled=!!b.off;
      });
    }
    for(const [k,el] of [...this.els])if(!seen.has(k)){el.remove();this.els.delete(k);this.shownAt.delete(k);}
    // their sizes, read once a refresh (for stacking), after the writes above
    for(const el of this.els.values()){const inner=el.firstElementChild;el.w=inner?.offsetWidth||0;el.h=inner?.offsetHeight||0;}
  }
  /** Scene to screen, every frame; a menu follows its thing with a short ease (her bits move while they work). */
  place(t=0){
    const cv=globalThis.canvas,el=cv?.app?.canvas??cv?.app?.view;if(!el?.getBoundingClientRect)return;
    const rect=el.getBoundingClientRect(),T=cv.stage?.worldTransform,screen=cv.app?.renderer?.screen??{width:rect.width,height:rect.height};if(!T)return;
    const sx=rect.width/(screen.width||rect.width),sy=rect.height/(screen.height||rect.height),dt=this.lastFrame?Math.min(100,Math.max(0,t-this.lastFrame)):0,k=dt?1-Math.exp(-dt/FOLLOW_MS):1;this.lastFrame=t;
    const placed=[];
    for(const m of this.menus){const e=this.els.get(m.key);if(!e)continue;
      let at=this.shownAt.get(m.key);if(!at||Math.hypot(m.x-at.x,m.y-at.y)>FOLLOW_SNAP){at={x:m.x,y:m.y};this.shownAt.set(m.key,at);}else{at.x+=(m.x-at.x)*k;at.y+=(m.y-at.y)*k;}
      const x=rect.left+(T.a*at.x+T.c*at.y+T.tx)*sx;let y=rect.top+(T.b*at.x+T.d*at.y+T.ty)*sy;
      // two menus under the same creature: the later one goes below the earlier
      const w=e.w||Math.max(110,rackOf(m.buttons.length).width),h=e.h||rackOf(m.buttons.length).height+40;for(const r of placed)if(Math.abs(x-r.x)<(w+r.w)/2+4&&y<r.y+r.h+4&&y+h>r.y-4)y=r.y+r.h+6;placed.push({x,y,w,h});
      const inside=x>rect.left-40&&x<rect.right+40&&y>rect.top-40&&y<rect.bottom+40;
      e.style.transform=`translate(${Math.round(x)}px,${Math.round(y)}px)`;e.style.visibility=inside?'visible':'hidden';}
  }
  async act(key,act){
    const menu=this.menus.find(m=>m.key===key),call=menu&&fieldAction(menu,act),api=this.api();if(!call||!api)return false;
    const token=globalThis.canvas?.tokens?.get?.(menu.token);if(!token)return false;
    const [name,...args]=call;this.stats.acts++;
    try{
      if(name==='decoy.setLook')await api.decoy.setLook(token);
      else if(name==='decoy.dismiss')await api.decoy.dismiss(token);
      else if(name==='stopBitTool')await api.stopBitTool(token,...args);
      else if(name==='bits.recall')await api.bits.recall(token,...args);
      else if(name==='bits.cancel')await api.bits.cancel(token,...args);
      else await api[name](token,...args);
      this.last=-Infinity;return true;
    }catch(error){globalThis.ui?.notifications?.warn?.(`${menu.title}: ${error?.message??error}`);return false;}
  }
}
/** The module's own key (no key assigned as it comes: Alt already shows them). */
export function registerFieldMenuKey(menus){
  const K=globalThis.game?.keybindings;if(!K?.register)return false;
  const typing=context=>!!context?.event?.target?.closest?.('input,textarea,select,[contenteditable="true"]');
  K.register(ID,FIELD_KEY,{name:'Menus on her decoy and bits (hold)',
    hint:'Hold to show a small menu under her decoy and under each job her bits are out on; release to put them away. Tap to leave them up, tap again (or Escape) to put them away. No key is assigned by default: set yours here. (Settings › Emotes & wheel can make Alt show them too.)',
    editable:[],uneditable:[],restricted:false,repeat:false,
    onDown:context=>typing(context)?false:menus.keyDown(),onUp:context=>typing(context)?false:menus.keyUp()});
  return true;
}
