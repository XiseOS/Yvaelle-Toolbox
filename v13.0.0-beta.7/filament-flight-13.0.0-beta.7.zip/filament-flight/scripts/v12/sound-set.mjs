/** Yvaelle’s Toolbox v12 · the v12 sound set (12.0.0-beta.7).
 *
 * Their own sounds for what v12 added: the four warps of beta.2, the three
 * shield styles, the three landing styles, her cloak and the Decoy. Eighteen
 * one-shots, registered as ordinary sound slots (audio-model.mjs), so each has
 * its volume, its file and its "none" in the Sound settings like every other.
 *
 * (12.0.0-beta.10) The sounds are generated recordings (ElevenLabs sound
 * effects; the briefs, takes and timings are in tools/audio/v12-sources.json),
 * cut against a recording of each effect, and they come in two styles, chosen
 * by the "Sound style" picker under the switch:
 *   classics   each modelled on a well-loved sci-fi sound (the default)
 *   hardlight  one shimmer-and-hum family throughout
 * Classics are the slots' own files; Hardlight's are the same names under
 * assets/audio/v12-hardlight/. A slot whose file she changed herself (custom
 * or none) is left alone.
 *
 * Switched by one feature, HUD › Settings › Sound › V12 sounds (per token,
 * OFF as it comes), with a part for each family. While it is off nothing here
 * is asked for: the four warps keep the sounds they borrowed, every shield
 * style has the weave's, and landing styles, cloaks and decoys are silent, as
 * before. Her sounds themselves are a separate switch (off as they come): with
 * them off none of this is heard either way.
 *
 * Cost: one settings lookup when an effect begins. Nothing runs per frame. */
import {resolveV11} from '../v11/features.mjs?v=13.0.0-beta.7';
import {playCue} from '../sound-cues.mjs?v=13.0.0-beta.7';

/** The slot each v12 moment plays, by family. */
export const SOUND_SET=Object.freeze({
  warps:Object.freeze({flock:'warpFlock',starfall:'warpStarfall',ribbon:'warpRibbon',prism:'warpPrism'}),
  shields:Object.freeze({scalemail:'flightShieldScalemail',rotor:'flightShieldRotor',wingwrap:'flightShieldWingwrap'}),
  landing:Object.freeze({powerdown:'landingPowerdown',foldaway:'landingFoldaway',reelin:'landingReelin'}),
  cloak:Object.freeze({on:'cloakOn',off:'cloakOff',onQuick:'cloakOnQuick',offQuick:'cloakOffQuick'}),
  decoy:Object.freeze({cast:'decoyCast',appear:'decoyAppear',look:'decoyLook',break:'decoyBreak'})
});
/** The feature's part that switches each family. */
export const SOUND_PARTS=Object.freeze({warps:'soundWarps',shields:'soundShields',landing:'soundLanding',cloak:'soundCloak',decoy:'soundDecoy'});
export const SOUND_SLOTS=Object.freeze(Object.values(SOUND_SET).flatMap(f=>Object.values(f)));
/** The styles the set comes in, and where the files of every style but the first are kept. */
export const SOUND_STYLES=Object.freeze(['classics','hardlight']);
export const SOUND_STYLE_DIRS=Object.freeze({hardlight:'v12-hardlight'});
const SLOT_SET=new Set(SOUND_SLOTS);
/** Her style of the set (the first when nothing is chosen or the value is unknown). */
export function soundStyleOf(doc){
  try{const v=resolveV11(doc).soundStyle;return SOUND_STYLES.includes(v)?v:SOUND_STYLES[0];}catch{return SOUND_STYLES[0];}
}
/** The file a v12 slot plays in her style: the slot's own file for Classics, its namesake in the style's folder otherwise.
 *  Anything that is not a v12 slot, and a slot whose file was changed in the Sound settings, is returned as it came. */
export function styledSrc(doc,slot,src,preset='default'){
  if(!src||!SLOT_SET.has(slot)||(preset!=='default'&&preset!=='refined'))return src;
  const dir=SOUND_STYLE_DIRS[soundStyleOf(doc)];if(!dir)return src;
  return src.replace(/assets\/audio\/(?:refined|flight)\//,`assets/audio/${dir}/`);
}
/** A cloak shorter than this (s) plays the quick sound: Swift, a cloak warp, a broken Fade, the Classic drain. */
export const CLOAK_QUICK_UNDER=2.2;
/** How often each slot was asked for (the self-check reads it; a sound that is asked for is heard only where her sounds are on). */
export const soundStats={asked:Object.create(null)};

/** Is a family of the set switched on for her? */
export function soundOn(doc,family){
  try{const v=resolveV11(doc);return v.soundSet===true&&v[`soundSet.${SOUND_PARTS[family]}`]!==false;}catch{return false;}
}
/** The slot for a moment, or null when the set (or its family) is off or the moment has no sound of its own. */
export function soundFor(doc,family,key){return soundOn(doc,family)?SOUND_SET[family]?.[key]??null:null;}
/** Which cloak sound a sweep of `seconds` plays. */
export const cloakKey=(on,seconds)=>(on?'on':'off')+(seconds<CLOAK_QUICK_UNDER?'Quick':'');
export function noteAsked(slot){soundStats.asked[slot]=(soundStats.asked[slot]??0)+1;}
/** Ask for a v12 sound (nothing when its family is off). Every client runs these effects itself, so each plays its own. */
export function cue12(token,family,key,options){
  const slot=soundFor(token?.document,family,key);if(!slot)return null;
  noteAsked(slot);return playCue(token,slot,options);
}
