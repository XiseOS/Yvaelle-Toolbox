/** Bit send-out styles (v10).
 *
 * When bits leave her for a task (Medkit treatments, fields, scans, parked
 * lights and other bit actions) and when they come home again, the default
 * flight can be replaced by one of four short, thematic choreographies. Each
 * one changes with the number of bits sent (1-4):
 *
 *  - warp    Seam warp. Bits slip into a thin magenta seam beside her and step
 *            out of a seam at the task. 1: one seam each side. 2: a shared
 *            seam. 3: three seams opening in a cascade. 4: a constellation of
 *            four seams around her and around the task.
 *  - thread  Thread relay. She throws a filament line to the task and the bits
 *            ride it. 1: a lone rider. 2: two parallel threads. 3: a spaced
 *            train on one thread. 4: two threads, two riders each.
 *  - sling   Sling. The bits whirl around her (passing behind and in front),
 *            then are released toward the task in a staggered arc.
 *  - flight  Formation flight. 1: a dart with a small wind-up. 2: a crossing
 *            pair that braid over and under. 3: a triangle relay that turns as
 *            it flies. 4: a diamond that unfolds at the task.
 *
 * The styles reshape the existing travel only: every path starts at the bit's
 * real departure point and ends exactly on the default path's arrival, so the
 * task's own timing, targets and hand-offs are unchanged and nothing pops.
 * The choice is made per browser ("Bit send-out style"); it is purely visual.
 */
import {ID} from './config.mjs?v=13.0.0-beta.7';
import {effectMeshClass,placeBehind,setMeshTransform} from './renderer.mjs?v=13.0.0-beta.7';

export const SEND_OUT_STYLES=Object.freeze({classic:'Classic',mixed:'Mixed',warp:'Seam warp',thread:'Thread relay',sling:'Sling',flight:'Formation flight'});
const ALTERNATIVES=Object.freeze(['warp','thread','sling','flight']);
const TAU=Math.PI*2;
const unit=x=>Math.max(0,Math.min(1,Number.isFinite(x)?x:0));
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const smoother=x=>{x=unit(x);return x*x*x*(x*(x*6-15)+10);};
const lerp=(a,b,t)=>a+(b-a)*t;
const lerpP=(a,b,t)=>({x:lerp(a.x,b.x,t),y:lerp(a.y,b.y,t)});
const hash=s=>{let h=2166136261;for(const c of String(s))h=Math.imul(h^c.charCodeAt(0),16777619);return (h>>>0)/4294967296;};
const finite=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
// Envelope that rises over [a,b] and falls over [c,d].
const band=(u,a,b,c,d)=>smooth((u-a)/Math.max(1e-6,b-a))*(1-smooth((u-c)/Math.max(1e-6,d-c)));

/* ---------- choice ---------- */
const chosen=new Map(),lastAlternative=new Map();
function readSetting(){try{return globalThis.game?.settings?.get(ID,'bitSendOutStyle')??'mixed';}catch{return 'mixed';}}
/** The style for one action. Outbound and return share it. Mixed is mostly
 * Classic, sometimes an alternative, never the same alternative twice running
 * (per token, on this browser). The pick is cached per action. */
export function sendOutStyle(event,setting=readSetting(),ownerKey=null){
  if(!event?.id)return 'classic';
  if(setting!=='mixed')return Object.hasOwn(SEND_OUT_STYLES,setting)?setting:'classic';
  const key=`${setting}:${event.id}`;
  if(chosen.has(key))return chosen.get(key);
  const owner=ownerKey??event.owner??'token',roll=hash(`${event.id}:roll`);
  let style='classic';
  if(roll<.38){
    const last=lastAlternative.get(owner),pool=ALTERNATIVES.filter(s=>s!==last);
    style=pool[Math.floor(hash(`${event.id}:pick`)*pool.length)%pool.length];
    lastAlternative.set(owner,style);
  }
  chosen.set(key,style);if(chosen.size>96)chosen.delete(chosen.keys().next().value);
  return style;
}

/* ---------- geometry ---------- */
function windowOf(event,now){
  if(event.conditionPausedAt!=null)return null;
  if(event.status==='returning'){
    const d=event.returnDuration;if(!(d>=300))return null;
    const u=(now-event.returnAt)/d;return u>=0&&u<1?{u,back:true}:null;
  }
  if(event.status!=='running')return null;
  const d=event.travelDuration;if(!(d>=300))return null;
  const u=(now-event.started)/d;return u>=0&&u<1?{u,back:false}:null;
}
function centroid(points){let x=0,y=0,n=0;for(const p of points)if(finite(p)){x+=p.x;y+=p.y;n++;}return n?{x:x/n,y:y/n}:null;}

/** Reshape a sampled action's travel in place. Adds sample.sendOut with
 * per-bit alpha/scale multipliers and ornaments (seams, threads, links). */
export function applySendOut(event,sample,context,now,{setting}={}){
  if(!sample?.positions||!context?.source||context.snapshot?.effective?.reducedMotion)return sample;
  if(!['utility','escort','treatment'].includes(event.kind)||event.sequence)return sample;
  const win=windowOf(event,now);if(!win)return sample;
  const style=sendOutStyle(event,setting??readSetting(),context.sourceId);if(style==='classic')return sample;
  const ids=event.bits.filter(id=>finite(sample.positions[id]));const n=ids.length;if(!n)return sample;
  const size=context.size||100,S=context.source;
  let A,B;
  if(win.back){A=centroid(ids.map(id=>event.returnFrom?.[id]))??centroid(ids.map(id=>sample.positions[id]));B={x:S.x,y:S.y};}
  else{
    A={x:S.x,y:S.y};
    const target=event.target?context.target:event.utility?.center??null;
    B=finite(target)&&Math.hypot(target.x-S.x,target.y-S.y)>size*.5?target:null;
    // Point jobs without a token: aim at where the bits are bound.
    if(!B&&event.utility?.center)B=event.utility.center;
  }
  if(!finite(A)||!finite(B))return sample;
  const dx=B.x-A.x,dy=B.y-A.y,L=Math.hypot(dx,dy);
  // Short hops (fields on herself, work at her side) keep the classic move.
  if(L<size*1.2)return sample;
  const dir={x:dx/L,y:dy/L},nrm={x:-dir.y,y:dir.x};
  const ctx={event,sample,context,ids,n,size,S,A,B,L,dir,nrm,u:win.u,back:win.back,now};
  const out={style,alpha:{},scale:{},ornaments:[]};
  ({warp,thread,sling,flight})[style]?.(ctx,out);
  sample.sendOut=out;
  return sample;
}

/* ---------- order: lanes sorted across the travel line ---------- */
function lanes(ctx){
  const {ids,sample,nrm,A}=ctx,from=id=>(ctx.back?ctx.event.returnFrom?.[id]:ctx.context.origins?.[id])??sample.positions[id];
  return [...ids].sort((a,b)=>{const p=from(a),q=from(b);return ((p.x-A.x)*nrm.x+(p.y-A.y)*nrm.y)-((q.x-A.x)*nrm.x+(q.y-A.y)*nrm.y);});
}

/* ---------- 1. Seam warp ---------- */
function warp(ctx,out){
  const {sample,n,size,A,B,dir,nrm,u}=ctx,order=lanes(ctx);
  // Seam layout by count: 1 single, 2 shared, 3 cascade, 4 constellation.
  const stagger=n===2?.07:n===3?.085:n===4?.02:0,len=size*(n===1?.56:n===2?.64:n===3?.44:.4),wide=size*(n===2?.1:n===1?.085:.072);
  const near=(P,toward,i,k)=>{
    // Seams sit beside the departure/arrival, on the travel side.
    if(n===1||n===2)return {x:P.x+toward.x*size*.5,y:P.y+toward.y*size*.5};
    if(n===3){const s=(i-1)*.62;return {x:P.x+toward.x*size*.5+nrm.x*size*s*k,y:P.y+toward.y*size*.5+nrm.y*size*s*k};}
    const a=-Math.PI/4+i*Math.PI/2+Math.atan2(toward.y,toward.x);return {x:P.x+Math.cos(a)*size*.62*k,y:P.y+Math.sin(a)*size*.62*k};
  };
  const seamAngle=Math.atan2(nrm.y,nrm.x);
  // beta.30: the seam has weight. Each bit draws back and gathers light,
  // is pulled in (accelerating, stretched toward the slit), the seam closes
  // with a soft snap and a brief inward pull of light, and at the far side the
  // bit is pushed out past its mark and settles. The map bends a little
  // around each seam as it opens and seals (map only, never tokens).
  const ANT=.17,DIVE=.36,SNAP=.44,OPEN=.54;
  order.forEach((id,i)=>{
    const d=i*stagger,v=unit((u-d)/(1-stagger*(n-1)||1)),p=sample.positions[id];
    const enter=near(A,dir,i,1),exit=near(B,{x:-dir.x,y:-dir.y},i,1);
    const tx=enter.x-p.x,ty=enter.y-p.y,tl=Math.hypot(tx,ty)||1,to={x:tx/tl,y:ty/tl};
    const drawn=smooth(v/ANT)*size*.11,back={x:p.x-to.x*drawn,y:p.y-to.y*drawn};
    let pos,alpha=1,scale=1;
    if(v<ANT){pos=back;scale=1+.1*smooth(v/ANT);
      out.ornaments.push({type:'gather',x:pos.x,y:pos.y,r:size*.16,alpha:.6*smooth(v/ANT)});}
    else if(v<DIVE){
      // the squeeze shrinks by a steady ratio per frame (geometric), so even
      // the last frames before the slit change size smoothly
      const w=(v-ANT)/(DIVE-ANT),e=w*w*w;pos=lerpP(back,enter,e);scale=1.1*Math.pow(.3/1.1,Math.pow(w,1.25));alpha=1-smooth((w-.55)/.45);
      // stretched toward the slit as the pull takes it
      out.ornaments.push({type:'stretch',x:pos.x,y:pos.y,dx:-to.x*size*(.12+.5*e),dy:-to.y*size*(.12+.5*e),w:size*.045*(1-.4*e),alpha:.85*Math.min(1,w*2.5)*(1-smooth((w-.9)/.1))});
      if(w<.35)out.ornaments.push({type:'gather',x:pos.x,y:pos.y,r:size*.16,alpha:.6*(1-w/.35)});}
    else if(v<OPEN){pos=lerpP(enter,exit,smooth((v-DIVE)/(OPEN-DIVE)));alpha=0;scale=.3;}
    else{
      const w=(v-OPEN)/(1-OPEN),c=1.9,q=w-1,e=1+(c+1)*q*q*q+c*q*q;// push out past the mark, then settle
      pos=lerpP(exit,p,e);alpha=smooth(w/.22);scale=.3*Math.pow(1/.3,smooth(w/.45))+.07*Math.sin(Math.PI*unit((w-.25)/.55));
      const ox=p.x-exit.x,oy=p.y-exit.y,ol=Math.hypot(ox,oy)||1,push=Math.sin(Math.PI*unit(w/.4));
      if(push>.02)out.ornaments.push({type:'stretch',x:pos.x,y:pos.y,dx:-ox/ol*size*.35*push,dy:-oy/ol*size*.35*push,w:size*.04,alpha:.75*push});}
    sample.positions[id]={x:pos.x,y:pos.y};out.alpha[id]=alpha;out.scale[id]=scale;
    if(sample.depths)sample.depths[id]=1;
    if(n!==2||i===0){
      // opens while the bit gathers, holds, then a soft snap shut (fast at the end)
      const openA=v<DIVE?smooth(v/(ANT*.9)):v<SNAP?1-Math.pow((v-DIVE)/(SNAP-DIVE),2.2):0;
      const snap=v>DIVE-.02&&v<SNAP+.07?Math.sin(Math.PI*unit((v-(DIVE-.02))/(SNAP+.09-DIVE))):0;
      const openB=v<OPEN-.06?0:v<OPEN+.06?smooth((v-(OPEN-.06))/.12):1-smooth((v-(OPEN+.12))/.3);
      if(openA>.01||snap>.01)out.ornaments.push({type:'seam',x:enter.x,y:enter.y,angle:seamAngle,length:len,width:wide,open:Math.max(0,openA),
        lens:.55*openA+.6*snap,twist:.6*snap});
      if(snap>.02)out.ornaments.push({type:'motes',x:enter.x,y:enter.y,r:size*.42*(1-.85*smooth(unit((v-(DIVE-.02))/(SNAP+.09-DIVE)))),alpha:.8*snap,seed:i,angle:seamAngle});
      if(openB>.01)out.ornaments.push({type:'seam',x:exit.x,y:exit.y,angle:seamAngle,length:len,width:wide,open:openB,lens:-.5*openB*(v<OPEN+.12?1:openB)});
    }
  });
}

/* ---------- 2. Thread relay ---------- */
function thread(ctx,out){
  const {sample,n,size,A,B,dir,nrm,u,back}=ctx,order=lanes(ctx);
  const lanesOf={1:[0],2:[-.16,.16],3:[0,0,0],4:[-.15,-.15,.15,.15]}[n];
  const slot={1:[0],2:[0,0],3:[0,1,2],4:[0,1,0,1]}[n],gap=n===3?.12:n===4?.1:0;
  const start=d=>({x:A.x+dir.x*size*.42+nrm.x*size*d,y:A.y+dir.y*size*.42+nrm.y*size*d});
  const end=d=>({x:B.x-dir.x*size*.42+nrm.x*size*d,y:B.y-dir.y*size*.42+nrm.y*size*d});
  // She throws the line outward; on the way home it is thrown from her to them.
  const grow=smoother(u/.26),fade=1-smooth((u-.8)/.2);
  const threads=[...new Set(lanesOf)];
  for(const d of threads){
    const p0=start(d),p1=end(d);
    out.ornaments.push({type:'thread',x0:back?p1.x:p0.x,y0:back?p1.y:p0.y,x1:back?p0.x:p1.x,y1:back?p0.y:p1.y,grow,alpha:.85*fade,wave:u});
  }
  order.forEach((id,i)=>{
    const d=lanesOf[i],k=slot[i],p=sample.positions[id];
    const s=smoother((u-.12-k*gap)/(.68-gap*2));
    const ride=lerpP(start(d),end(d),s),w=smooth(u/.16)*(1-smooth((u-.82)/.18));
    sample.positions[id]={x:lerp(p.x,ride.x,w),y:lerp(p.y,ride.y,w)};
    if(sample.depths)sample.depths[id]=lerp(sample.depths[id]??1,1,w);
    out.alpha[id]=1;out.scale[id]=1-.12*w;
    if(w>.3&&s>0&&s<1)out.ornaments.push({type:'bead',x:sample.positions[id].x,y:sample.positions[id].y,alpha:.55*w});
  });
}

/* ---------- 3. Sling ---------- */
function sling(ctx,out){
  const {sample,n,size,S,dir,u,back,event,context}=ctx,order=lanes(ctx);
  const R=size*.58,launch=Math.atan2(dir.y,dir.x);
  order.forEach((id,i)=>{
    const p=sample.positions[id];
    if(!back){
      const O=context.origins?.[id]??p,r0=Math.max(size*.2,Math.hypot(O.x-S.x,O.y-S.y)),a0=Math.atan2(O.y-S.y,O.x-S.x);
      // Swing the way that needs about half a turn (behind or in front of
      // her) so the bit leaves on a tangent pointing at the task.
      let sigma=1,delta=Math.PI,best=Infinity;
      for(const sg of [1,-1]){const rel=launch-sg*Math.PI/2;let m=((rel-a0)*sg%TAU+TAU)%TAU;if(m<Math.PI*.5)m+=TAU;const cost=Math.abs(m-Math.PI)+(sg!==(i%2?-1:1)?.35:0);if(cost<best&&m<=Math.PI*1.6){best=cost;sigma=sg;delta=sg*m;}}
      if(!Number.isFinite(best)){sigma=1;delta=Math.PI;}
      const uR=.46+i*(n===4?.04:.06),wv=unit(u/uR);
      if(u<uR){
        const e=wv**1.6,a=a0+delta*e,r=lerp(r0,R,smooth(wv/.5));
        sample.positions[id]={x:S.x+Math.cos(a)*r,y:S.y+Math.sin(a)*r*.82};
        if(sample.depths)sample.depths[id]=Math.sin(a);
        // The filament arc it traces, brightest at the bit, fading behind.
        if(wv>.04)out.ornaments.push({type:'trail',cx:S.x,cy:S.y,r,ry:.82,a0:a-sigma*Math.min(Math.PI*1.3,Math.abs(a-a0)),a1:a,alpha:.85*smooth((wv-.04)/.2)});
      }else{
        const aR=a0+delta,Prel={x:S.x+Math.cos(aR)*R,y:S.y+Math.sin(aR)*R*.82},v=(u-uR)/(1-uR);
        const tdir={x:-Math.sin(aR)*sigma,y:Math.cos(aR)*sigma*.82},tl=Math.hypot(tdir.x,tdir.y)||1,reach=Math.hypot(p.x-Prel.x,p.y-Prel.y);
        const Q={x:Prel.x+tdir.x/tl*reach*v*.7,y:Prel.y+tdir.y/tl*reach*v*.7},e=smooth(v);
        sample.positions[id]={x:lerp(Q.x,p.x,e),y:lerp(Q.y,p.y,e)};
        if(sample.depths)sample.depths[id]=lerp(Math.sin(aR),sample.depths[id]??1,e);
        // Released: the arc fades where it was and a filament tail follows the throw.
        const fadeArc=1-smooth(v/.55),fadeTail=1-smooth(v/.75);
        if(fadeArc>.02)out.ornaments.push({type:'trail',cx:S.x,cy:S.y,r:R,ry:.82,a0:aR-sigma*Math.min(Math.PI*1.3,Math.abs(delta)),a1:aR,alpha:.85*fadeArc});
        if(fadeTail>.02){const q=sample.positions[id],from=lerpP(Prel,q,smooth(v/.9)*.6);out.ornaments.push({type:'filament',x0:from.x,y0:from.y,x1:q.x,y1:q.y,alpha:.75*fadeTail});}
      }
    }else{
      // Home again: swing in around her once, then settle into the station.
      const uE=.5-i*(n===4?.04:.06),from=event.returnFrom?.[id]??p,a1=Math.atan2(p.y-S.y,p.x-S.x),r1=Math.hypot(p.x-S.x,p.y-S.y);
      const ain=Math.atan2(from.y-S.y,from.x-S.x),sigma=i%2?-1:1;
      let delta=sigma*Math.PI*1.1;
      const E={x:S.x+Math.cos(ain)*R,y:S.y+Math.sin(ain)*R*.82};
      if(u<uE){const v=u/uE,e=smooth(v);sample.positions[id]={x:lerp(p.x,E.x,e),y:lerp(p.y,E.y,e)};}
      else{
        const v=(u-uE)/(1-uE);
        let end=a1;while(sigma*(end-(ain+delta))>Math.PI)end-=sigma*TAU;while(sigma*((ain+delta)-end)>Math.PI)end+=sigma*TAU;
        const a=lerp(ain,end,smooth(v)),r=lerp(R,r1,smooth(v)),pt={x:S.x+Math.cos(a)*r,y:S.y+Math.sin(a)*r*lerp(.82,1,smooth(v))};
        const k=smooth((v-.7)/.3);
        sample.positions[id]={x:lerp(pt.x,p.x,k),y:lerp(pt.y,p.y,k)};
        if(sample.depths)sample.depths[id]=lerp(Math.sin(a),sample.depths[id]??1,k);
        if(v<.92)out.ornaments.push({type:'trail',cx:S.x,cy:S.y,r,ry:.82,a0:ain,a1:a,alpha:.8*smooth(v/.12)*(1-smooth((v-.55)/.37))});
      }
    }
    out.alpha[id]=1;out.scale[id]=1;
  });
}

/* ---------- 4. Formation flight ---------- */
function flight(ctx,out){
  const {sample,n,size,dir,nrm,u}=ctx,order=lanes(ctx),G=centroid(order.map(id=>sample.positions[id]));
  const rot=(v,a)=>({x:v.x*Math.cos(a)-v.y*Math.sin(a),y:v.x*Math.sin(a)+v.y*Math.cos(a)});
  const frame=(f,s)=>({x:dir.x*f+nrm.x*s,y:dir.y*f+nrm.y*s});
  if(n===1){
    const id=order[0],p=sample.positions[id],from=ctx.back?ctx.event.returnFrom?.[id]??p:ctx.context.origins?.[id]??p;
    // Dart: a small wind-up, a straight run (the arc pulled flat), a settle.
    const t=Math.max(0,(p.x-from.x)*dir.x+(p.y-from.y)*dir.y),line={x:from.x+dir.x*t,y:from.y+dir.y*t},flat=Math.sin(Math.PI*u)**.6;
    const wind=-Math.sin(Math.PI*unit(u/.24))*size*.16,settle=Math.sin(Math.PI*unit((u-.82)/.18))*size*.05;
    sample.positions[id]={x:lerp(p.x,line.x,flat)+dir.x*(wind+settle),y:lerp(p.y,line.y,flat)+dir.y*(wind+settle)};
    out.alpha[id]=1;out.scale[id]=1;
    // The dart draws a taut filament behind it for its straight run.
    const run=band(u,.18,.3,.66,.86);if(run>.02){const q=sample.positions[id];out.ornaments.push({type:'filament',x0:q.x-dir.x*size*.8,y0:q.y-dir.y*size*.8,x1:q.x,y1:q.y,alpha:.8*run,taper:true});}
    return;
  }
  const w=smooth(u/.22)*(1-smooth((u-.72)/.28));
  let slots;
  if(n===2){
    // Crossing pair: braid across the line, one over and one under.
    const b=Math.sin(TAU*u);slots=[frame(0,-size*.34*b),frame(0,size*.34*b)];
    order.forEach((id,i)=>{if(sample.depths)sample.depths[id]=lerp(sample.depths[id]??1,(i?1:-1)*Math.cos(Math.PI*u)*.9,Math.min(1,w*1.6));});
  }else if(n===3){
    // Triangle relay: the lead hands on as the triangle turns a third.
    const turn=TAU/3*smooth((u-.2)/.6);slots=[0,1,2].map(k=>rot(frame(size*.36,0),turn+k*TAU/3));
  }else{
    // Diamond: closes up for the flight, opens as a quarter-turn at the task.
    const open=(1-w)*Math.PI/4;slots=[frame(size*.4,0),frame(0,size*.3),frame(-size*.36,0),frame(0,-size*.3)].map(v=>rot(v,open*(u>.5?1:-1)));
  }
  const pts=[];
  order.forEach((id,i)=>{
    const p=sample.positions[id],s=slots[i],goal={x:G.x+s.x,y:G.y+s.y},k=n===2?Math.min(1,w*1.6):w;
    sample.positions[id]={x:lerp(p.x,goal.x,k),y:lerp(p.y,goal.y,k)};pts.push(sample.positions[id]);
    out.alpha[id]=1;out.scale[id]=1;
  });
  // A shared filament holds the shape; it breaks into beads and dissolves
  // as the shape unfolds at the task.
  const dissolve=u>.5?1-w:0,shown=u>.5?Math.max(w,.0)*1:w;
  if(n>=3&&shown>.04)out.ornaments.push({type:'links',points:pts,closed:true,alpha:.8*Math.sqrt(shown),dissolve});
  if(n===2&&shown>.04)out.ornaments.push({type:'links',points:pts,closed:false,alpha:.7*Math.sqrt(shown),dissolve});
}

/* ---------- the map bends around each bit seam (map only, never tokens) ----------
 * The same pinch as her own token warp (warp.mjs), with four small slots so
 * up to four seams can bend the map at once. It is attached only to the
 * scene background and the tiles it reaches, exactly like the warp's
 * map-only lens, and removed as soon as no seam is open. */
const SEAM_LENS_SRC=`
varying vec2 vTextureCoord;uniform sampler2D uSampler;uniform vec4 inputSize;uniform vec4 outputFrame;
uniform vec4 l0;uniform vec4 l1;uniform vec4 l2;uniform vec4 l3;uniform vec4 d0;uniform vec4 d1;uniform vec4 d2;uniform vec4 d3;
vec2 pinch(vec2 p,vec4 l,vec4 o){vec2 d=p-l.xy;float r=length(d);
  if(l.z<=0.0||l.w==0.0||r>=l.z)return p;float n=r/l.z,f=pow(1.0-n,1.6),k=max(0.35,1.0+l.w*f*1.8);
  float a=o.w*f*f;d=vec2(cos(a)*d.x-sin(a)*d.y,sin(a)*d.x+cos(a)*d.y);
  if(dot(o.xy,o.xy)<0.25)return l.xy+d*k;
  vec2 u=normalize(o.xy),v=vec2(-u.y,u.x);
  return l.xy+u*dot(d,u)*k+v*dot(d,v)*k*(1.0+o.z*f);}
void main(){vec2 p=vTextureCoord*inputSize.xy+outputFrame.xy;
  p=pinch(p,l0,d0);p=pinch(p,l1,d1);p=pinch(p,l2,d2);p=pinch(p,l3,d3);
  gl_FragColor=texture2D(uSampler,(p-outputFrame.xy)*inputSize.zw);}`;
let seamLens=null;const seamRequests=new Map(),seamTargets=new Set();
function seamLensFilter(){
  const P=globalThis.PIXI;if(!P?.Filter)return null;
  if(seamLens===null){try{const u={};for(const k of ['l0','l1','l2','l3','d0','d1','d2','d3'])u[k]=new Float32Array(4);seamLens=new P.Filter(undefined,SEAM_LENS_SRC,u);seamLens.padding=0;}catch(e){console.warn('Yvaelle’s Toolbox | bit seam lens unavailable',e);seamLens=false;}}
  return seamLens||null;
}
function mapTargets(circles){
  const group=globalThis.canvas?.primary;if(!group||!circles.length)return [];
  const out=[],bg=group.background;if(bg&&!bg.destroyed)out.push(bg);
  for(const tile of globalThis.canvas?.tiles?.placeables??[]){const m=tile?.mesh;if(!m||m.destroyed||m===bg)continue;const d=tile.document??{};
    const x=d.x??tile.x??0,y=d.y??tile.y??0,w=d.width??tile.w??0,h=d.height??tile.h??0;
    if(circles.some(c=>c.x+c.r>x&&c.x-c.r<x+w&&c.y+c.r>y&&c.y-c.r<y+h))out.push(m);}
  return out;
}
function setFilter(obj,f,on){const list=obj.filters??[];
  if(on&&!list.includes(f))obj.filters=[...list,f];
  if(!on&&list.includes(f)){const next=list.filter(x=>x!==f);obj.filters=next.length?next:null;}}
/** One owner (a token's send-out layer) reports its open seams each frame. */
export function setSeamLens(owner,lenses){
  if(lenses?.length)seamRequests.set(owner,lenses);else seamRequests.delete(owner);
  const all=[...seamRequests.values()].flat().sort((a,b)=>Math.abs(b.k)-Math.abs(a.k)).slice(0,4);
  const f=all.length?seamLensFilter():seamLens||null;if(!f){seamTargets.clear();return;}
  const want=new Set(mapTargets(all));
  for(const o of [...seamTargets])if(!want.has(o)||o.destroyed){try{if(!o.destroyed)setFilter(o,f,false);}catch{}seamTargets.delete(o);}
  for(const o of want)if(!seamTargets.has(o)){try{setFilter(o,f,true);seamTargets.add(o);}catch{}}
  if(!seamTargets.size)return;
  const wt=globalThis.canvas?.stage?.worldTransform,toScreen=p=>wt?.apply?wt.apply(p):{x:p.x*(wt?.a??1)+(wt?.tx??0),y:p.y*(wt?.d??1)+(wt?.ty??0)},zoom=Math.hypot(wt?.a??1,wt?.b??0);
  for(let i=0;i<4;i++){const l=f.uniforms[`l${i}`],d=f.uniforms[`d${i}`],z=all[i];
    if(!z){l.fill(0);d.fill(0);continue;}const s=toScreen(z);
    l[0]=s.x;l[1]=s.y;l[2]=z.r*zoom;l[3]=z.k;d[0]=z.ax;d[1]=z.ay;d[2]=.9*Math.abs(z.k);d[3]=z.twist??0;}
}

/* ---------- ornaments: one small world-space surface per token ---------- */
const PINK='231,103,206',CORE='255,222,246',GOLD='207,174,118';
function bounds(list){
  let l=Infinity,t=Infinity,r=-Infinity,b=-Infinity;const add=(x,y,m=0)=>{l=Math.min(l,x-m);t=Math.min(t,y-m);r=Math.max(r,x+m);b=Math.max(b,y+m);};
  for(const o of list){
    if(o.type==='seam'){const h=o.length/2+(o.width??0)*2+6;add(o.x,o.y,h);}
    else if(o.type==='thread'||o.type==='filament'){add(o.x0,o.y0,10);add(o.x1,o.y1,10);}
    else if(o.type==='links')for(const p of o.points)add(p.x,p.y,8);
    else if(o.type==='streak'){add(o.x,o.y,8);add(o.x+o.dx,o.y+o.dy,8);}
    else if(o.type==='trail')add(o.cx,o.cy,o.r+10);
    else if(o.type==='stretch'){add(o.x,o.y,8);add(o.x+o.dx,o.y+o.dy,8);}
    else if(o.type==='gather'||o.type==='motes')add(o.x,o.y,o.r+8);
    else add(o.x,o.y,12);
  }
  return Number.isFinite(l)?{x:l,y:t,width:Math.max(2,r-l),height:Math.max(2,b-t)}:null;
}
function glowStroke(g,path,width,alpha,rgb=PINK){
  for(const [w,a,c] of [[width*5,.10,rgb],[width*2.4,.28,rgb],[width,.9,CORE]]){g.lineWidth=w;g.strokeStyle=`rgba(${c},${a*alpha})`;path();g.stroke();}
}
export function paintSendOutOrnaments(g,list,k,origin){
  g.lineCap='round';g.lineJoin='round';
  const X=x=>(x-origin.x)*k,Y=y=>(y-origin.y)*k;
  for(const o of list){
    if(o.type==='seam'){
      // A glowing slit: a soft magenta lens with a pale core and a thin gold
      // edge. It opens wide, then seals back to a hairline and is gone.
      const op=smooth(o.open),h=o.length/2*(.3+.7*op)*k,half=Math.max(.5,(o.width??o.length*.15)/2*op*op*k),x=X(o.x),y=Y(o.y);
      g.save();g.translate(x,y);g.rotate(o.angle);
      const glow=g.createRadialGradient(0,0,0,0,0,h*1.1);glow.addColorStop(0,`rgba(${PINK},${.42*o.open})`);glow.addColorStop(1,`rgba(${PINK},0)`);
      g.fillStyle=glow;g.beginPath();g.ellipse(0,0,h*1.1,half*3.2+2*k,0,0,TAU);g.fill();
      const lens=()=>{g.beginPath();g.moveTo(-h,0);g.quadraticCurveTo(0,-half*2,h,0);g.quadraticCurveTo(0,half*2,-h,0);g.closePath();};
      const fill=g.createLinearGradient(0,-half,0,half);fill.addColorStop(0,`rgba(${PINK},${.85*o.open})`);fill.addColorStop(.5,`rgba(${CORE},${.95*o.open})`);fill.addColorStop(1,`rgba(${PINK},${.85*o.open})`);
      g.fillStyle=fill;lens();g.fill();
      g.strokeStyle=`rgba(${GOLD},${.9*o.open})`;g.lineWidth=Math.max(.7,k*.7);lens();g.stroke();
      g.strokeStyle=`rgba(${CORE},${o.open})`;g.lineWidth=Math.max(.7,k*.6);g.beginPath();g.moveTo(-h*.96,0);g.lineTo(h*.96,0);g.stroke();
      g.restore();
    }else if(o.type==='thread'){
      const x0=X(o.x0),y0=Y(o.y0),x1=X(o.x1),y1=Y(o.y1),tip=smooth(o.grow),xe=lerp(x0,x1,tip),ye=lerp(y0,y1,tip);
      const len=Math.hypot(xe-x0,ye-y0),nx=-(ye-y0)/(len||1),ny=(xe-x0)/(len||1),sag=(1-tip)*len*.08;
      glowStroke(g,()=>{g.beginPath();g.moveTo(x0,y0);g.quadraticCurveTo((x0+xe)/2+nx*sag,(y0+ye)/2+ny*sag,xe,ye);},Math.max(.7,k*.8),o.alpha);
      if(tip<.999&&o.alpha>.05){g.fillStyle=`rgba(${CORE},${o.alpha})`;g.beginPath();g.arc(xe,ye,Math.max(1,k*1.4),0,TAU);g.fill();}
    }else if(o.type==='links'){
      const rgb=o.gold?GOLD:PINK,d=unit(o.dissolve??0);
      // Dissolving: the line breaks into ever shorter beads.
      if(d>0)g.setLineDash([Math.max(.5,(1-d)*9*k+.5),d*9*k+.5]);
      glowStroke(g,()=>{g.beginPath();o.points.forEach((p,i)=>i?g.lineTo(X(p.x),Y(p.y)):g.moveTo(X(p.x),Y(p.y)));if(o.closed)g.closePath();},Math.max(.6,k*.85),o.alpha,rgb);
      g.setLineDash([]);
    }else if(o.type==='streak'){
      const x=X(o.x),y=Y(o.y),grad=g.createLinearGradient(x,y,x+o.dx*k,y+o.dy*k);grad.addColorStop(0,`rgba(${CORE},${.8*o.alpha})`);grad.addColorStop(.25,`rgba(${PINK},${.45*o.alpha})`);grad.addColorStop(1,`rgba(${PINK},0)`);
      g.strokeStyle=grad;g.lineWidth=Math.max(1,k*2.4);g.beginPath();g.moveTo(x,y);g.lineTo(x+o.dx*k,y+o.dy*k);g.stroke();
    }else if(o.type==='filament'){
      const x0=X(o.x0),y0=Y(o.y0),x1=X(o.x1),y1=Y(o.y1);
      for(const [w,a,c] of [[3.6,.22,PINK],[1.1,.95,CORE]]){const grad=g.createLinearGradient(x1,y1,x0,y0);grad.addColorStop(0,`rgba(${c},${a*o.alpha})`);grad.addColorStop(1,`rgba(${c},0)`);
        g.strokeStyle=grad;g.lineWidth=Math.max(.6,k*w);g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();}
    }else if(o.type==='trail'){
      // A filament arc: brightest at the bit, fading along the swing.
      const steps=Math.max(8,Math.min(28,Math.round(Math.abs(o.a1-o.a0)*9)));
      for(const [w,a,c] of [[3.6,.24,PINK],[1.1,.95,CORE]])for(let i=0;i<steps;i++){
        const t0=i/steps,t1=(i+1)/steps,a0=lerp(o.a0,o.a1,t0),a1=lerp(o.a0,o.a1,t1+.02);
        g.strokeStyle=`rgba(${c},${a*o.alpha*t1**1.6})`;g.lineWidth=Math.max(.5,k*w*(.35+.65*t1));
        g.beginPath();g.moveTo(X(o.cx+Math.cos(a0)*o.r),Y(o.cy+Math.sin(a0)*o.r*o.ry));g.lineTo(X(o.cx+Math.cos(a1)*o.r),Y(o.cy+Math.sin(a1)*o.r*o.ry));g.stroke();
      }
    }else if(o.type==='gather'){
      // the bit gathering light before it dives: a soft magenta glow, no flash
      const x=X(o.x),y=Y(o.y),r=o.r*k,grad=g.createRadialGradient(x,y,0,x,y,r);
      grad.addColorStop(0,`rgba(${CORE},${.55*o.alpha})`);grad.addColorStop(.35,`rgba(${PINK},${.35*o.alpha})`);grad.addColorStop(1,`rgba(${PINK},0)`);
      g.fillStyle=grad;g.beginPath();g.arc(x,y,r,0,TAU);g.fill();
    }else if(o.type==='stretch'){
      // the bit drawn out toward the slit: a tapered body of light behind it
      const x=X(o.x),y=Y(o.y),ex=x+o.dx*k,ey=y+o.dy*k,l=Math.hypot(ex-x,ey-y)||1,nx=-(ey-y)/l,ny=(ex-x)/l,w=o.w*k;
      const grad=g.createLinearGradient(x,y,ex,ey);grad.addColorStop(0,`rgba(${CORE},${.9*o.alpha})`);grad.addColorStop(.3,`rgba(${PINK},${.6*o.alpha})`);grad.addColorStop(1,`rgba(${PINK},0)`);
      g.fillStyle=grad;g.beginPath();g.moveTo(x+nx*w,y+ny*w);g.quadraticCurveTo(x-(ex-x)*.08,y-(ey-y)*.08,x-nx*w,y-ny*w);g.lineTo(ex,ey);g.closePath();g.fill();
    }else if(o.type==='motes'){
      // a brief inward pull of light into the sealing seam
      const x=X(o.x),y=Y(o.y);
      for(let m=0;m<6;m++){const a=o.angle+(m-2.5)*.55+(o.seed%2?.3:-.3)+(m%2?Math.PI:0),r=o.r*k*(.75+.25*((m*37%7)/7)),px=x+Math.cos(a)*r,py=y+Math.sin(a)*r,tx=x+Math.cos(a)*r*.55,ty=y+Math.sin(a)*r*.55;
        const grad=g.createLinearGradient(tx,ty,px,py);grad.addColorStop(0,`rgba(${CORE},${.9*o.alpha})`);grad.addColorStop(1,`rgba(${PINK},0)`);
        g.strokeStyle=grad;g.lineWidth=Math.max(.8,k*1.1);g.beginPath();g.moveTo(px,py);g.lineTo(tx,ty);g.stroke();}
    }else if(o.type==='bead'){
      const x=X(o.x),y=Y(o.y),grad=g.createRadialGradient(x,y,0,x,y,7*k);grad.addColorStop(0,`rgba(${PINK},${.45*o.alpha})`);grad.addColorStop(1,`rgba(${PINK},0)`);
      g.fillStyle=grad;g.beginPath();g.arc(x,y,7*k,0,TAU);g.fill();
    }
  }
}
/** Repainted each display frame while a styled trip is in the air (a few
 * hundred milliseconds); hidden otherwise. */
export class SendOutLayer {
  constructor(token){this.token=token;this.record=null;}
  update(list,source){
    const lenses=(list??[]).filter(o=>o.type==='seam'&&Math.abs(o.lens??0)>.01).map(o=>({x:o.x,y:o.y,r:o.length*.85,k:o.lens,ax:Math.cos(o.angle),ay:Math.sin(o.angle),twist:o.twist??0}));
    try{setSeamLens(this,lenses);}catch(e){console.warn('Yvaelle’s Toolbox | bit seam lens',e);}
    if(!list?.length){this.hide();return false;}
    const box=bounds(list);if(!box){this.hide();return false;}
    const world=globalThis.canvas?.primary?.worldTransform??globalThis.canvas?.stage?.worldTransform,zoom=world?Math.max(Math.hypot(world.a??1,world.b??0),Math.hypot(world.c??0,world.d??1)):1;
    let k=Math.max(1,Math.min(2.5,zoom*(globalThis.canvas?.app?.renderer?.resolution??1)));
    k=Math.min(k,1400/Math.max(box.width,box.height));
    const w=Math.max(2,Math.ceil(box.width*k)),h=Math.max(2,Math.ceil(box.height*k));
    let r=this.record;
    if(!r){
      const surface=document.createElement('canvas');surface.width=w;surface.height=h;const ctx=surface.getContext('2d');if(!ctx)return false;
      const texture=PIXI.Texture.from(surface,{mipmap:PIXI.MIPMAP_MODES?.OFF??0}),Mesh=effectMeshClass();
      const mesh=new Mesh({name:`${ID}.${this.token.id}.action.sendout`,texture},foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader);
      mesh.eventMode='none';mesh.anchor.set(0,0);canvas.primary.addChild(mesh);r=this.record={surface,ctx,texture,mesh};
    }
    if(r.surface.width!==w||r.surface.height!==h){r.surface.width=w;r.surface.height=h;r.texture.baseTexture.resource?.resize?.(w,h);r.texture.baseTexture.setRealSize?.(w,h);}
    r.ctx.setTransform(1,0,0,1,0,0);r.ctx.clearRect(0,0,w,h);
    paintSendOutOrnaments(r.ctx,list,k,box);r.texture.baseTexture.update();
    setMeshTransform(r.mesh,box.x,box.y,0,w/k,h/k);
    if(r.mesh.alpha!==(source?.alpha??1))r.mesh.alpha=source?.alpha??1;
    if(!r.mesh.visible)r.mesh.visible=true;
    placeBehind(r.mesh,source,-.138);
    return true;
  }
  hide(){try{setSeamLens(this,null);}catch{}if(this.record?.mesh&&this.record.mesh.visible)this.record.mesh.visible=false;}
  destroy(){try{setSeamLens(this,null);}catch{}const r=this.record;this.record=null;if(!r)return;r.mesh.parent?.removeChild(r.mesh);r.mesh.destroy({children:true,texture:false,baseTexture:false});r.texture.destroy(true);r.surface.width=r.surface.height=1;}
}
