import {MIN_REPAINT_MS} from './repaint-cadence.mjs?v=13.0.0-beta.7';
import {BitPictureLease} from './bit-picture-lease.mjs?v=13.0.0-beta.7';
import {ID} from './config.mjs?v=13.0.0-beta.7';
import {BitRenderer} from './bit-renderer.mjs?v=13.0.0-beta.7';
import {choreographedGems} from './gem-choreography.mjs?v=13.0.0-beta.7';
import {BIT_IDS,BIT_KEY,sampleSequence,eventState,ease} from './bit-sequences.mjs?v=13.0.0-beta.7';
import {effectMeshClass,isShown,isOnScreen,placeBehind,setMeshTransform} from './renderer.mjs?v=13.0.0-beta.7';
import {wingTransform} from './trails.mjs?v=13.0.0-beta.7';
import {bitAssets} from './bit-assets.mjs?v=13.0.0-beta.7';
import {paintHardlight,prepareHardlightArtwork,TREATMENT_TIMING,TREATMENT_RELEASE_MS,underlayHardlightSurface} from './hardlight-treatment.mjs?v=13.0.0-beta.7';
import {localPerformance} from './performance.mjs?v=13.0.0-beta.7';
import {compactBitTransform,compactWingHandoff} from './compact-bit-renderer.mjs?v=13.0.0-beta.7';
import {actionEffectViewport,treatmentResolution,scanCropResolution,settledTreatmentResolution,stableEffectViewport} from './treatment-render-regions.mjs?v=13.0.0-beta.7';
import {sampleTokenEffect,paintTokenEffect,tokenEffectDefinition,selfFieldFrame} from './token-effects.mjs?v=13.0.0-beta.7';
import {sampleCompactCurrents,compactGeometryPlacement} from './compact-bit-formations.mjs?v=13.0.0-beta.7';
import {sampleGroupFormation,blendGroupFields} from './bit-group-motion.mjs?v=13.0.0-beta.7';
import {formationStations} from './bit-allocations.mjs?v=13.0.0-beta.7';
import {applyBitCondition} from './condition-response.mjs?v=13.0.0-beta.7';
import {withCoreActivity,captureCoreActivity} from './bit-core-states.mjs?v=13.0.0-beta.7';
import {visibleProjectionFocus,sampleProjectionMotion} from './projection-context.mjs?v=13.0.0-beta.7';
import {isProjectedEffect} from './projected-effect-programs.mjs?v=13.0.0-beta.7';
import {updateWorldBitWaveDirection,retainBitWaveDirections,acquireBitWaveDirections,BIT_WAVE_STATIONS} from './bit-wave-direction.mjs?v=13.0.0-beta.7';
import {readBitIntentTarget} from './bit-intent.mjs?v=13.0.0-beta.7';
import {bitLanternInFrame} from './bit-lantern.mjs?v=13.0.0-beta.7';
import {medicalEmitterArtwork,medicalEmitterSurfaceSize,paintMedicalEmitter} from './medical-emitter-artwork.mjs?v=13.0.0-beta.7';
import {isProjectedEmitterPath,projectedEmitterArtwork,projectedBeaconSurfaceSize,paintProjectedBeacon,projectedConnectorViewport,paintProjectedConnector,projectedConnectorTransform} from './projected-emitter-artwork.mjs?v=13.0.0-beta.7';
import {paintScanArtwork} from './v8-scan-art.mjs?v=13.0.0-beta.7';
import {scanEffectBounds,paintCroppedScanSurface} from './v882-scan-render-regions.mjs?v=13.0.0-beta.7';
import {stepScanAnchor} from './v8-scan-choreography.mjs?v=13.0.0-beta.7';
import {scanSceneContext,targetScanContext} from './v82-scene-scan-context.mjs?v=13.0.0-beta.7';
import {ScanEncounterController} from './v82-scan-encounters.mjs?v=13.0.0-beta.7';
import {TokenScanMaskCache,scanTokenPortrait} from './v83-token-scan-mask.mjs?v=13.0.0-beta.7';
import {stepScanLocomotion,applyScanLocomotion} from './v88-scan-locomotion.mjs?v=13.0.0-beta.7';
import {sceneScanWallContext,guardScanSample} from './v88-scan-walls.mjs?v=13.0.0-beta.7';
import {guardScanOrientation} from './v884-scan-orientation.mjs?v=13.0.0-beta.7';
import {captureScanMechanism} from './bit-scan-mechanism.mjs?v=13.0.0-beta.7';
import {resonantBitGeometry} from './bit-resonance.mjs?v=13.0.0-beta.7';
import {applySendOut,SendOutLayer} from './bit-send-out.mjs?v=13.0.0-beta.7';

const scanCueEase=value=>{const p=Math.max(0,Math.min(1,value));return p*p*p*(10+p*(-15+6*p));};
const SCAN_MECHANISM_HANDOFF=300;
const SCAN_INTERNAL_CLOCKS=['phase','yaw','precession','orbit','tilt','response','v7Interior'];

function setSquareAttachmentTransform(mesh,x,y,rotation,width){
  // Preserve the native width getter's round trip when deriving the height.
  // PIXI may represent the requested width through a fractional texture scale.
  setMeshTransform(mesh,x,y,rotation,width,mesh.height);
  const height=mesh.width;if(mesh.height!==height)mesh.height=height;
}

/** Filament's transform wrapper restores the mesh's physical coordinates after
 * rendering. Actions follow the displayed portrait without changing the native
 * positions used for vision, illumination or positional audio. */
const HANDBACK_MS=90;
export function tokenVisualPose(token,manager){
  const mesh=token.mesh,state=manager?.states?.get(token),motion=state?.source===mesh?state:null;
  return {x:mesh.x+(motion?.swayX??0),y:mesh.y+(motion?.lift??0),angle:(mesh.rotation??0)+(motion?.bank??0)};
}
function scanVisualPose(token,manager){
  const pose=tokenVisualPose(token,manager),state=manager?.states?.get(token);
  if(state?.source===token.mesh)pose.scaleY=1+(state.pitch??0)*(state.motionBlend??state.blend??0);
  return pose;
}
export function sourceTransform(token,snapshot,manager){
  const s=manager?.states?.get(token),handoff=compactWingHandoff(snapshot,s?.blend);
  if(handoff.active?handoff.compact>0:snapshot.compactBits)return compactBitTransform(token.mesh,token,snapshot,s);
  if(s?.blend>.002)return wingTransform(s,snapshot);
  const pose=tokenVisualPose(token,manager),size=Math.max(token.w,token.h),angle=pose.angle;
  const x=(snapshot.options.offsetX??0)*size,y=(snapshot.options.offsetY??0)*size;
  return {x:pose.x+x*Math.cos(angle)-y*Math.sin(angle),y:pose.y+x*Math.sin(angle)+y*Math.cos(angle),
    width:size*snapshot.options.wingScale,height:size*snapshot.options.wingScale,angle,presence:0};
}
export function toWorld(point,transform){const x=point[0]/600*transform.width,y=(point[1]-15)/600*transform.height,c=Math.cos(transform.angle),s=Math.sin(transform.angle);return {x:transform.x+x*c-y*s,y:transform.y+x*s+y*c};}
export function actionHardware(snapshot,now,{destination=false}={}){
  // Without wings, bits away from home (recalled, or all four at work) keep
  // their compact companion size instead of growing to wing-mounted scale.
  const handoff=compactWingHandoff(snapshot),compact=handoff.active?handoff.compact>0:snapshot.compactBits||snapshot.rendering?.wingsActive===false;
  const flight={...snapshot,compactBits:compact,formation:destination&&!compact?(snapshot.formation??{growth:1,fold:0,presence:1}):{growth:1,fold:0,presence:1},
    bitDeployment:destination?(snapshot.bitDeployment??1)*(compact?handoff.compact:1):1,wingBitHandoff:destination&&!compact?handoff.wing:1,
    bitCount:destination?snapshot.bitCount:{...snapshot.bitCount,values:[1,1,1,1]},bitHardwareAll:!destination,
    bitHomeStations:destination?(snapshot.bitHomeStations??BIT_IDS.filter((_,i)=>(snapshot.bitCount?.values?.[i]??(i<(snapshot.gems?.count??4)?1:0))>.00001)):BIT_IDS,
    stabilizerDeployment:destination&&!compact&&!snapshot.formation?.explicit?Math.max(0,Math.min(1,snapshot.bitWingBlend??1)):1,bitSequenceActive:destination?snapshot.bitSequenceActive:true,
    gems:{...snapshot.gems,style:'choreographed',appearance:'physical',enabled:true}};
  const visual={...snapshot.visual.profile,time:compact?now/1000:snapshot.visual.profile.time??now/1000},bits={},frame={};
  for(const side of [-1,1])for(const part of choreographedGems(snapshot.poseAnimation.weights,0,visual,flight,side,frame)){
    if(part.hardware){const id=`${side<0?'left':'right'}${part.id==='gem-0'?'Upper':'Lower'}`;bits[id]=part;}
  }
  return bits;
}
/** Advance only the pure artwork clock for command-edge velocity sampling.
 * Token position and hover remain the currently displayed visual frame. */
export function actionSnapshotAt(snapshot,now,delta=8){
  return {...snapshot,bitFormationNow:(snapshot.bitFormationNow??now)+delta,
    visual:{...snapshot.visual,profile:{...snapshot.visual?.profile,time:(snapshot.visual?.profile?.time??now/1000)+delta/1000}}};
}
export function actionContext(token,target,snapshot,event,manager,hardware,now=(snapshot.visual?.profile?.time??0)*1000,{returnMotion=true,scanGeometry=true}={}){
  const transform=sourceTransform(token,snapshot,manager),size=Math.max(token.w,token.h),sourcePose=tokenVisualPose(token,manager),targetPose=target?.mesh?tokenVisualPose(target,manager):sourcePose;
  snapshot=bitLanternInFrame(snapshot,transform.angle);
  const source={x:sourcePose.x,y:sourcePose.y};
  const deployed=snapshot.rendering.active&&snapshot.bitDeployment>.01&&snapshot.gems.style!=='hidden';
  const displayBlend=manager?.states?.get(token)?.blend,handoff=compactWingHandoff(snapshot,displayBlend),changing=handoff.active||snapshot.bitTransition?.active||snapshot.bitCount?.transition?.active;
  const sequenceReturn=event.kind==='sequence'&&event.sequence?.tracks?.some(step=>step.type==='return');
  const destinationSnapshot=sequenceReturn&&snapshot.bitAllocationState?{...snapshot,bitHomeStations:formationStations(snapshot.bitAllocationState,(snapshot.bitReservationEvents??[]).filter(e=>e.id!==event.id))}:snapshot;
  let destination=hardware;
  if((event.status==='returning'||sequenceReturn)&&snapshot.compactBits&&!handoff.active){
    const flight={...destinationSnapshot,formation:{growth:1,fold:0,presence:1},stabilizerDeployment:1},time=snapshot.gems.animated?now/1000*(snapshot.gems.speed??1):0;
    destination={};for(const id of BIT_IDS){const p=compactGeometryPlacement(id,flight,time);destination[id]={points:[p.center],hardware:{angle:p.angle}};}
  }else if(changing||event.status==='returning'||sequenceReturn)destination=actionHardware({...destinationSnapshot,bitWingBlend:displayBlend},now,{destination:true});
  const originTransform=event.originScale?{...transform,width:size*event.originScale[0],height:size*event.originScale[1]}:transform;
  const returns={},origins={},deployedBits=[],returnGlows={},returnTargets={},returnDepths={},returnRotations={},remoteSamples=new Map();
  // Remote group slots are read only by returns (and sequence return steps);
  // an escort or job does not sample its destination formation every frame.
  const needsReturns=event.status==='returning'||sequenceReturn;
  for(const id of BIT_IDS){
    const side=id.startsWith('left')?-1:1,index=id.endsWith('Lower')?1:0;
    const root=toWorld([side*27,-23+index*18],transform);
    const active=deployed&&(snapshot.bitCount?.values?.[BIT_IDS.indexOf(id)]??1)>.01;
    if(active)deployedBits.push(id);
    const support=snapshot.bitActionAssignments?.returnSupport?.[id];
    let returnPoint=destination[id]?.points[0]??[side*27,-23+index*18];
    if(active&&support){const amount=Math.max(0,Math.min(1,support.amount??0));
      if(snapshot.gems?.placement==='follow')returnPoint=[returnPoint[0]+(support.x-returnPoint[0])*amount,returnPoint[1]+(support.y-returnPoint[1])*amount,...returnPoint.slice(2)];
      returnGlows[id]={strength:2.3*amount,mode:'field',color:null};}
    returns[id]=active?toWorld(returnPoint,transform):root;
    returnDepths[id]=active?(returnPoint[2]??-24)/24:-1;
    returnRotations[id]=active?(destination[id]?.hardware?.angle??0)-(hardware[id]?.hardware?.angle??0):0;
    const origin=event.origins?.[id];
    origins[id]=event.originsWorld?.[id]??(origin?toWorld(origin,originTransform):root);
    const allocation=snapshot.bitAllocationState,location=allocation?.bits?.[id]?.location;
    if(needsReturns&&event.bits.includes(id)&&location&&location!=='home'&&location!=='retracted'){
      const remote=globalThis.canvas?.tokens?.get(location);
      if(remote?.mesh){
        let group=remoteSamples.get(location);
        if(!group){
          // A running treatment/sequence may ask for its future return slot.
          // Include this action's own identities, while other borrowed tools
          // remain absent. Unrelated IDs need no return point for this event.
          const cfg={...snapshot.gems,...allocation.groups?.[location]},stations=formationStations(allocation,(snapshot.bitReservationEvents??[]).filter(e=>e.id!==event.id),location),pose=tokenVisualPose(remote,manager);
          const points=sampleGroupFormation(stations,allocation.groups?.[location],cfg,now,snapshot);
          group={stations,points,pose,cfg,scale:Math.max(remote.w,remote.h)*3.5/600};remoteSamples.set(location,group);
        }
        const p=group.points[group.stations.indexOf(id)],c=Math.cos(group.pose.angle),s=Math.sin(group.pose.angle),x=p.x*group.scale,y=(p.y-15)*group.scale;
        returns[id]={x:group.pose.x+x*c-y*s,y:group.pose.y+x*s+y*c};returnTargets[id]=remote;returnDepths[id]=p.z;
        returnRotations[id]=p.angle+group.pose.angle-transform.angle-(hardware[id]?.hardware?.angle??0);
        if(!deployedBits.includes(id))deployedBits.push(id);
        returnGlows[id]={strength:group.cfg.glow===false?0:group.cfg.glowStrength??.4,mode:group.cfg.glowMode??'core',color:null};
      }
    }
  }
  let returnVelocities;
  if(returnMotion&&event.status==='returning'&&event.sequence?.gesture){
    // Decorative gesture returns join the moving assignment's velocity. This
    // extra geometry sample exists only for their short return, never at rest.
    const delta=8,nextSnapshot=actionSnapshotAt(snapshot,now,delta),nextHardware=actionHardware(nextSnapshot,now+delta);
    const next=actionContext(token,target,nextSnapshot,event,manager,nextHardware,now+delta,{returnMotion:false});
    returnVelocities=Object.fromEntries(event.bits.flatMap(id=>{const a=returns[id],b=next.returns[id];return a&&b?[[id,{x:(b.x-a.x)*1000/delta,y:(b.y-a.y)*1000/delta}]]:[];}));
  }
  const context={source,sourceId:token.document?.id??token.id,target:{x:targetPose.x,y:targetPose.y},size,targetSize:target?Math.max(target.w,target.h):size,
    targetWidth:Math.max(target?.w??size,Math.abs(target?.mesh?.width??0)),targetHeight:Math.max(target?.h??size,Math.abs(target?.mesh?.height??0)),origins,returns,deployed,deployedBits,transform,
    snapshot,targetRotation:targetPose.angle,orientations:Object.fromEntries(BIT_IDS.map(id=>[id,destination[id]?.hardware?.angle??0])),
    returnGlows,returnTargets,returnDepths,returnRotations,...(returnVelocities?{returnVelocities}:{}),returnGlow:{strength:snapshot.gems.glow?snapshot.gems.glowStrength:0,mode:snapshot.gems.glowMode??'core',color:null}};
  if(scanGeometry&&event.kind==='utility'&&event.utility?.mode==='areaScan')context.gridScan=scanSceneContext({center:event.utility.followSource?source:event.utility.center??context.target,radius:event.utility.radiusPixels??size});
  if(event.kind==='utility'&&event.utility?.mode==='creatureScan'&&target){
    const portrait=scanTokenPortrait(target,{pose:scanVisualPose(target,manager)});
    context.target=portrait.center;context.targetWidth=portrait.width;context.targetHeight=portrait.height;context.targetRotation=portrait.rotation;
    context.targetScan={...targetScanContext(target),portrait};
  }
  if(event.kind==='treatment'&&target?.mesh){
    // Diagnosis, work and result share the displayed original-image centre.
    // The authored treatment stays world-upright and token-scaled: reflection,
    // skew and rotation still belong to the native diagnostic alpha mask.
    // Nothing here moves native documents, real apertures or audio origins.
    const portrait=scanTokenPortrait(target,{pose:scanVisualPose(target,manager)});
    context.target=portrait.center;context.medicalPortrait=portrait;
    if(event.treatment?.diagnosticScan===true&&event.status!=='returning'&&now<event.started+event.travelDuration+TREATMENT_TIMING.scan){
      context.medicalScan={portrait,methods:token.document?.getFlag?.(ID,'v8Tools')?.scanMethods};
    }
  }
  if(event.kind==='utility'&&['areaScan','creatureScan'].includes(event.utility?.mode)&&event.status!=='returning')context.scanWalls=sceneScanWallContext({source:token,enabled:snapshot.v8Motion?.scanWalls!==false});
  return context;
}

/** A transfer can begin partway through another instrument's withdrawal.
 * Keep its physical opacity and size envelope without restarting the artwork
 * or creating another clock. Events without a capture retain the old curves. */
export function actionBitPresence(event,id,state,context,now){
  const deployed=event.deployedBits?event.deployedBits.includes(id):event.deployed;
  const acquisition=ease((now-event.started)/Math.max(1,Math.min(event.travelDuration,450)));
  const prior=event.originPresence?.[id],captured=prior&&Number.isFinite(prior.alpha)&&Number.isFinite(prior.scale);
  const clamp=value=>Math.max(0,Math.min(1,value));
  const deployment=captured?clamp(prior.alpha)+(1-clamp(prior.alpha))*acquisition:deployed?1:acquisition;
  const size=captured?clamp(prior.scale)+(1-clamp(prior.scale))*acquisition:deployment;
  const returningToFormation=context.deployedBits?context.deployedBits.includes(id):context.deployed;
  const returning=state.phase==='returning'&&!returningToFormation?1-ease((state.progress-.65)/.35):1;
  return {alpha:deployment*returning,scale:Math.min(size,returning),deployment,returning};
}

/** Extend the cropped treatment canvas to bounded token fields without forcing
 * medicine to allocate a full square or increasing its quality cap. */
export function bitEffectViewport(effects,resolution,plane='front',boundsCache=null,preparedScanArtwork=null){
  const bounded=effects.map(effect=>effect.effect==='v8-scan'&&effect.mode==='areaScan'?{...effect,bounds:scanEffectBounds(effect,plane,preparedScanArtwork)}:effect);
  let result=actionEffectViewport(bounded,resolution,plane,{ignoreTokenFields:true,boundsCache});
  // Patient portraits can extend beyond their occupied grid square. Keep the
  // original medical pixel density while allowing this short native reading's
  // crop to enclose its actual image, offset anchor and exterior instruments.
  for(const effect of effects){
    if(!effect.medicalDiagnostic||!effect.channels?.some(c=>(c.plane??'front')===plane&&c.strength>0)||!effect.bounds)continue;
    const b=effect.bounds,ratio=resolution/280,cell=16,x=Math.floor(((b.x+140)*ratio-2)/cell)*cell,y=Math.floor(((b.y+140)*ratio-2)/cell)*cell;
    const right=Math.ceil(((b.x+b.width+140)*ratio+2)/cell)*cell,bottom=Math.ceil(((b.y+b.height+140)*ratio+2)/cell)*cell;
    if(!result)result={x,y,width:right-x,height:bottom-y};
    else {const left=Math.min(x,result.x),top=Math.min(y,result.y);result={x:left,y:top,width:Math.max(right,result.x+result.width)-left,height:Math.max(bottom,result.y+result.height)-top};}
  }
  for(const effect of effects){
    if(effect.effect!=='token-field'||!effect.paths?.some(p=>p.plane===plane&&p.alpha>0))continue;
    const b=effect.bounds??{x:-130,y:-130,width:260,height:260},ratio=resolution/280,cell=16;
    const x=Math.max(0,Math.floor(((b.x+140)*ratio-2)/cell)*cell),y=Math.max(0,Math.floor(((b.y+140)*ratio-2)/cell)*cell);
    const right=Math.min(resolution,Math.ceil(((b.x+b.width+140)*ratio+2)/cell)*cell),bottom=Math.min(resolution,Math.ceil(((b.y+b.height+140)*ratio+2)/cell)*cell);
    const next={x,y,width:right-x,height:bottom-y};
    if(!result)result=next;else{const left=Math.min(x,result.x),top=Math.min(y,result.y);result={x:left,y:top,width:Math.max(right,result.x+result.width)-left,height:Math.max(bottom,result.y+result.height)-top};}
  }
  return result;
}

export function groupVisualEffect(group,count,now,snapshot,detail='standard',options={}){
  const cfg=snapshot.gems??{},effect=group?.effect;
  if(effect?.enabled&&tokenEffectDefinition(effect.id))return sampleTokenEffect(effect.id,count,now,{strength:effect.strength??1,color:cfg.color??snapshot.options?.color,animated:!snapshot.effective?.reducedMotion,detail,program:group.program??cfg.soloProgram,radius:group.radius??cfg.soloRadius,...options});
  if(group?.passive===false||!cfg.animated||snapshot.effective?.reducedMotion)return null;
  const present=options.emitters?.map(e=>e.id);
  const points=sampleGroupFormation(options.stations??present??count,group,cfg,now,snapshot).filter(p=>!present||present.includes(p.station));
  const paths=sampleCompactCurrents(points).map(p=>({points:p.points.map(q=>[q[0]*3.5/6,(q[1]-15)*3.5/6]),plane:p.points.at(-1)?.[2]<0?'rear':'front',alpha:p.strength,width:p.width*.75,highlight:p.highlight}));
  let extent=1;for(const path of paths)for(const p of path.points)extent=Math.max(extent,Math.abs(p[0]),Math.abs(p[1]));
  const effectScale=Math.max(1,extent/125);if(effectScale>1)for(const path of paths){path.width/=effectScale;for(const p of path.points){p[0]/=effectScale;p[1]/=effectScale;}}
  return paths.length?{effect:'token-field',id:'passive',strength:1,color:cfg.color??snapshot.options?.color??'#ff62df',paths,effectScale,bounds:{x:-130,y:-130,width:260,height:260}}:null;
}

/** Canvas artwork shared by the live overlay and reproducible preview. */
export function paintActionEffects(ctx,sample,{size=512,now=0,color='#ff62df',plane='front',viewport=null,preparedArtwork=null,attachedEmitters=null,attachedProjectedEmitters=null,tokenMask=undefined,preparedScanArtwork=null}={}){
  ctx.clearRect(0,0,viewport?.width??size,viewport?.height??size);ctx.save();ctx.translate(size/2-(viewport?.x??0),size/2-(viewport?.y??0));ctx.scale(size/280,size/280);
  ctx.lineCap='round';ctx.lineJoin='round';
  const line=(points,alpha,width=.65,stroke=color)=>{ctx.globalAlpha=Math.max(0,Math.min(1,alpha));ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.stroke();};
  for(const effect of sample.effects){
    if(effect.effect==='v8-scan'){paintScanArtwork(ctx,effect,{plane,tokenMask,preparedArtwork:preparedScanArtwork});continue;}
    if(effect.effect==='token-field'){paintTokenEffect(ctx,attachedProjectedEmitters?.size?{...effect,paths:effect.paths.filter(p=>!isProjectedEmitterPath(p)||!attachedProjectedEmitters.has(p.emitter))}:effect,{plane});continue;}
    if(effect.effect==='hardlight'){
      if(preparedArtwork&&!preparedArtwork.has(effect))preparedArtwork.set(effect,prepareHardlightArtwork(effect));
      paintHardlight(ctx,effect,{plane,prepared:preparedArtwork?.get(effect),attachedEmitters});continue;
    }
    if(plane==='rear')continue;
    const a=effect.strength,clock=now/1000;
    if(effect.effect==='diagnostic'){
      const nodes=Array.from({length:7},(_,i)=>{const t=-Math.PI/2+i/7*Math.PI*2+.045*Math.sin(clock*.6);return [Math.cos(t)*40,Math.sin(t)*48];});
      line([...nodes,nodes[0]],a*.58,.65);
      for(let i=0;i<7;i++){
        const p=nodes[i],q=nodes[(i+3)%7];line([p,q],a*(.10+.12*Math.sin(clock*1.2+i)**2),.42);
        ctx.fillStyle='#ffe3fa';ctx.globalAlpha=a*(.6+.3*Math.sin(clock*2+i));ctx.beginPath();ctx.arc(...p,1.3,0,Math.PI*2);ctx.fill();
      }
      const scan=-35+((clock*.22)%1)*70;
      line([[-22,scan],[22,scan]],a*.6,.8,'#ffe7fa');
      for(const sign of [-1,1])line([[sign*43,-9],[sign*32,-9],[sign*23,scan]],a*.45,.5);
    }
    if(effect.effect==='lattice'){
      for(let row=-2;row<=2;row++){
        const y=row*8,w=29-Math.abs(row)*4;
        line([[-w,y-5],[0,y+4],[w,y-5]],a*(.5+.2*Math.sin(clock*1.8+row)),.55);
      }
      for(const x of [-18,-9,0,9,18])line([[x,-21],[x+3,0],[x,21]],a*.32,.45);
    }
    if(effect.effect==='stitch'){
      const p=effect.progress,w=32*(1-.7*p);
      line([[-w,0],[w,0]],a*Math.sin(Math.PI*Math.min(.95,.1+p*.85)),1.25,'#fff0fd');
      for(let i=0;i<7;i++){
        const x=-26+i*8.6,q=ease((p-i*.07)/.38);
        if(q>0)line([[x-3,-9*(1-q)],[x+3,9*(1-q)]],a*(1-p*.75),.8,'#ffe3fa');
      }
      const r=8+p*24;line(Array.from({length:33},(_,i)=>[Math.cos(i/32*Math.PI*2)*r,Math.sin(i/32*Math.PI*2)*r*.55]),a*(1-p)*.35,.6);
    }
    if(effect.effect==='pulse'){
      const p=effect.progress,r=10+p*35;line(Array.from({length:41},(_,i)=>[Math.cos(i/40*Math.PI*2)*r,Math.sin(i/40*Math.PI*2)*r*.7]),a*(1-p)*.65,.8);
    }
  }
  ctx.restore();
}

/** Only the fully settled reduced-motion medical surface can sleep. Its
 * painter ignores treating progress and forces clock/scan to their static
 * values; every other authored effect and emitter input remains in the key.
 * Scans, outcomes and normal animated procedures keep their artwork clock. */
function settledTreatmentArtworkKey(event,sample,snapshot){
  if(event.kind==='utility'&&snapshot.effective?.reducedMotion===true&&sample.effects?.length&&sample.effects.every(effect=>effect.effect==='v8-scan'&&effect.animated===false))return JSON.stringify(sample.effects);
  if(event.kind!=='treatment'||snapshot.effective?.reducedMotion!==true||sample.state.phase!=='treating'||
    !sample.effects.length||!sample.effects.every(effect=>effect.effect==='hardlight'&&effect.animated===false&&effect.phase==='treating'))return null;
  const effects=sample.effects.map(({progress,clock,scan,...effect})=>({...effect,clock:0,scan:1}));
  return JSON.stringify(effects);
}
function settledTreatmentPaintKey(artworkKey,snapshot,cfg,resolution,plane,viewport,zoom,pixelRatio){
  if(artworkKey===null)return null;
  return JSON.stringify([resolution,plane,viewport,zoom,pixelRatio,cfg.bitQuality,snapshot.gems?.color,snapshot.options?.color])+'|'+artworkKey;
}

export class BitActionRenderer {
  constructor(token){this.token=token;this.bits=new BitRenderer(token);this.pictures=new BitPictureLease(this.bits);this.effects=new Map();this.medicalEmitters=new Map();this.projectedEmitters=new Map();this.sprites=new Map();this.lastPositions=new Map();this.depthSides=new Map();this.effectFrames=new Map();this.scanEncounters=new ScanEncounterController();this.tokenScanMasks=new TokenScanMaskCache();const waves=acquireBitWaveDirections(token);this.waveState=waves.memory;this.releaseWaves=waves.release;this.releaseAssets=bitAssets.acquire();}
  hasHomeFieldTail(now){
    const frame=this.effectFrames.get('home-token-field');
    return !!(frame?.identity||frame?.release&&now<frame.release.started+frame.release.duration);
  }
  /** A pause holds the partly projected machinery as well as its housing.
   * Rebuild the pause clock once, retaining current world transforms and live
   * condition channels. At most the four physical instruments are retained. */
  pausedScanHardware(event,snapshot,hardware,now,{readOnly=false}={}){
    const at=event.taskPausedAt,paused=Number.isFinite(at)&&event.kind==='utility'&&event.status!=='returning'&&['areaScan','creatureScan'].includes(event.utility?.mode);
    if(!paused)return hardware;
    let sampled;const out={...hardware};
    for(const id of event.bits){
      const live=hardware[id];if(!live?.hardware)continue;
      let held=this.scanPausedHardware?.get(id);
      if(held?.event===event.id&&held.at!==at&&this.scanMechanisms?.get(id)?.pausedAt!=null){held={...held,at};if(!readOnly)this.scanPausedHardware.set(id,held);}
      if(!held||held.event!==event.id||held.at!==at){
        sampled??=actionHardware(actionSnapshotAt(snapshot,now,at-now),at);
        const h=sampled[id]?.hardware;if(!h)continue;
        held={event:event.id,at,coreAngle:h.coreAngle,clocks:Object.fromEntries(SCAN_INTERNAL_CLOCKS.map(key=>[key,h.resonance?.[key]]))};
        if(!readOnly)(this.scanPausedHardware??=new Map()).set(id,held);
      }
      out[id]={...live,hardware:{...live.hardware,coreAngle:held.coreAngle,resonance:{...live.hardware.resonance,...held.clocks,
        conditionPhase:live.hardware.resonance?.conditionPhase??live.hardware.resonance?.phase}}};
    }
    return out;
  }
  beginScanGeometryHandoff(id,now,{pausedAt=null}={}){
    const previous=this.scanGeometryHandoffs?.get(id);if(previous?.at===now&&(previous.pausedAt??null)===pausedAt)return;
    const h=this.bits?.records?.get(BIT_KEY[id])?.frame?.bit?.part?.hardware;
    if(h?.artwork!=='resonant')return;
    // Resolve the actually painted shape once. Capturing faces instead of a
    // previous hardware chain keeps repeated interruptions strictly bounded.
    (this.scanGeometryHandoffs??=new Map()).set(id,{at:now,geometry:resonantBitGeometry(h),...(pausedAt!=null?{pausedAt}:{})});
  }
  /** The outgoing scan pose belongs to the physical instrument. Retain its
   * exact stroke while another task takes ownership, then release only its
   * projection weight into the recipient's current machinery. */
  scanMechanismActivity(event,id,activity,now,{readOnly=false}={}){
    const cue=captureScanMechanism(activity?.examination),source=cue?`${event.id}:${event.utilityRevision??0}`:null;
    const receiver=`${event.id}:${event.utilityRevision??0}:${event.status??'running'}`;
    const previous=this.scanMechanisms?.get(id);let state=previous;
    if(previous&&now<previous.now)return activity;
    if(previous&&Number.isFinite(event.taskPausedAt)&&event.kind==='utility'&&event.status!=='returning'){
      const held=previous.activity??{...activity,examination:previous.cue};
      if(!readOnly&&previous.pausedAt!==event.taskPausedAt&&this.scanGeometryHandoffs?.has(id))this.beginScanGeometryHandoff(id,now,{pausedAt:event.taskPausedAt});
      if(!readOnly&&(now!==previous.now||previous.pausedAt!==event.taskPausedAt))this.scanMechanisms.set(id,{source:previous.source,cue:held.examination,activity:held,now,pausedAt:event.taskPausedAt});
      return held;
    }
    if(previous?.pausedAt!=null&&!readOnly)this.beginScanGeometryHandoff(id,now);
    const receiverChanged=!!previous?.release&&previous.receiver!==receiver;
    if(receiverChanged&&!readOnly)this.beginScanGeometryHandoff(id,now);
    if(previous?.release){
      const q=Math.max(0,(now-previous.release.at)/SCAN_MECHANISM_HANDOFF);
      if(q<1){
        const outgoing={...previous.release.cue,weight:previous.release.cue.weight*(1-scanCueEase(q))};
        const heldActivity={...(activity??{state:'scanning',amount:1,progress:outgoing.progress}),examination:outgoing};state={...previous,now,receiver,activity:captureCoreActivity(heldActivity)};delete state.pausedAt;
        if(!readOnly&&(now!==previous.now||receiverChanged||previous.pausedAt!=null))this.scanMechanisms.set(id,state);
        return heldActivity;
      }
      state=cue?{source,cue,now,entrance:previous.release.at+SCAN_MECHANISM_HANDOFF}:null;
    }else if(previous&&source!==previous.source){
      if(!readOnly)this.beginScanGeometryHandoff(id,now);
      const outgoing=previous.cue;
      const heldActivity={...(activity??{state:'scanning',amount:1,progress:outgoing.progress}),examination:{...outgoing}};state={...previous,now,receiver,activity:captureCoreActivity(heldActivity),release:{at:now,cue:outgoing}};delete state.pausedAt;
      if(!readOnly)(this.scanMechanisms??=new Map()).set(id,state);
      return heldActivity;
    }
    if(cue){
      const entrance=state?.source===source?state.entrance:null;
      const examination=entrance!=null?{...cue,weight:cue.weight*scanCueEase((now-entrance)/SCAN_MECHANISM_HANDOFF)}:cue;
      state={source,receiver,cue:examination,activity:captureCoreActivity({...activity,examination}),now,...(entrance!=null&&now<entrance+SCAN_MECHANISM_HANDOFF?{entrance}:{})};
      if(!readOnly&&(!previous||now!==previous.now||source!==previous.source||previous.pausedAt!=null))(this.scanMechanisms??=new Map()).set(id,state);
      return {...activity,examination};
    }
    if(!readOnly&&previous)this.scanMechanisms.delete(id);
    return activity;
  }
  /** A command can interrupt the short reading before work has assembled.
   * Retain only its last local optical frame for a bounded fade, following the
   * returning physical sources. No image handles or extra action flags exist. */
  medicalDiagnosticRelease(event,sample,context,now,{readOnly=false}={}){
    if(event.kind!=='treatment'||event.treatment?.diagnosticScan!==true)return;
    const effect=sample.effects.find(e=>e.medicalDiagnostic),previous=this.medicalDiagnosticFrames?.get(event.id);
    if(event.status!=='returning'){
      if(!readOnly){if(effect)(this.medicalDiagnosticFrames??=new Map()).set(event.id,{effect,scale:sample.effectScale});else this.medicalDiagnosticFrames?.delete(event.id);}
      return;
    }
    const age=Math.max(0,now-event.returnAt),duration=Math.min(TREATMENT_RELEASE_MS,event.returnDuration??TREATMENT_RELEASE_MS);
    if(!previous||event.reason==='target-deleted'||!(duration>0)||age>=duration){if(!readOnly)this.medicalDiagnosticFrames?.delete(event.id);return;}
    const gain=1-ease(age/duration),channels=previous.effect.channels.map(channel=>({...channel,strength:channel.strength*gain}));
    sample.effects.push({...previous.effect,retiring:true,channels});
    sample.effectScale=previous.scale;
  }
  projectionContext(event,position,size,now,snapshot){
    if(!isProjectedEffect(event.group?.effect?.id)&&!isProjectedEffect(this.effectFrames.get(event.id)?.release?.group?.effect?.id))return {};
    this.projectionMotion??=new Map();
    const sample=sampleProjectionMotion(this.projectionMotion.get(event.id),position,now,size,!!snapshot.effective?.reducedMotion);this.projectionMotion.set(event.id,sample);
    return {motion:{x:sample.dx,y:sample.dy,amount:sample.amount},focus:visibleProjectionFocus(this.token,position)};
  }
  groupEffect(event,count,now,snapshot,emitters,projection={}){
    const reduced=!!snapshot.effective?.reducedMotion,color=snapshot.gems?.color??snapshot.options?.color,slot=reduced?0:Math.floor(now/(1000/(this.effectFPS??24))),previous=this.effectFrames.get(event.id),group=event.group;
    const anchors=reduced?JSON.stringify([emitters,projection]):null,identity=group?.effect?.enabled?group.effect.id:null,effectKey=`${identity}:${group?.effect?.strength}:${group?.effect?.started}`;
    const observed=previous?.identity===identity?previous.observed:now-1200;
    let release=previous?.release;
    // Keep exactly one outgoing style. Its live emitter paths follow the actual
    // moving instruments while its working surface releases over half a second.
    if(previous?.identity&&previous.identity!==identity)release={group:previous.group,started:now,duration:reduced?180:550};
    if(release&&now>=release.started+release.duration)release=null;
    if(previous&&previous.slot===slot&&previous.group===group&&previous.count===count&&previous.detail===event.detail&&previous.color===color&&previous.reduced===reduced&&previous.anchors===anchors&&previous.effectKey===effectKey&&!release&&!previous.release)return previous.frame;
    const started=Math.max(Number.isFinite(group?.effect?.started)?group.effect.started:observed,event.kind==='escort'?(event.started??0)+(event.travelDuration??0):0);
    const current=groupVisualEffect(group,count,now,snapshot,event.detail,{emitters,stations:event.formationBits,activationElapsed:Math.max(0,now-started),...projection});
    const outgoing=release?groupVisualEffect(release.group,count,now,snapshot,event.detail,{emitters,stations:event.formationBits,activationElapsed:1200,...projection}):null;
    const frame=blendGroupFields(current,outgoing,release?(now-release.started)/release.duration:1);
    this.effectFrames.set(event.id,{slot,group,count,detail:event.detail,color,reduced,frame,anchors,identity,observed,effectKey,release});return frame;
  }
  sample(event,snapshot,manager,now,preparedHardware=null,{readOnly=false}={}){
    snapshot={...snapshot,bitWingBlend:manager?.states?.get(this.token)?.blend};
    if(event.kind==='token-field'){
      const pose=tokenVisualPose(this.token,manager),size=Math.max(this.token.w,this.token.h),transform=sourceTransform(this.token,snapshot,manager),renderer=manager?.states?.get(this.token)?.renderer,compact=renderer?.compact;
      const ids=event.participants??snapshot.bitVisibleHomeStations??snapshot.bitHomeStations??BIT_IDS;
      const emitters=ids.flatMap(id=>{
        const key=BIT_KEY[id],native=snapshot.compactBits?compact?.baseBits?.get(key):renderer?.rig?.bits?.frames?.records?.get(key)?.bit;
        const part=native?.part??(this.homeHardware??=actionHardware(snapshot,now,{destination:true}))[id];if(!part?.points?.length||part.strength<=.00001)return [];
        const bitRenderer=snapshot.compactBits?compact?.bits:renderer?.rig?.bits,displayed=bitRenderer?.records?.has(key)?bitRenderer.placements?.get(id):null;
        const p=displayed??toWorld(part.points[0],transform),depth=displayed?.front??(snapshot.compactBits?compact?.depths?.get(key):native?(native.front??0)>=(native.rear??0):undefined),z=displayed?.z??part.points[0][2]??1;
        return [{id,x:(p.x-pose.x)/size*100,y:(p.y-pose.y)/size*100,z,plane:typeof depth==='boolean'?(depth?'front':'rear'):z<0?'rear':'front'}];
      });
      const response=snapshot.conditionResponse,collapsed=response?.bits&&response.collapse?.phase!=='awake';
      const grouped=collapsed?null:this.groupEffect(event,emitters.length,now,snapshot,emitters,this.projectionContext(event,pose,size,now,snapshot));
      // a field on Ellie herself keeps her face clear and stands apart from open wings
      const effect=grouped&&event.id==='home-token-field'?selfFieldFrame(grouped,{wings:snapshot.compactBits?0:snapshot.bitWingBlend??1}):grouped;
      if(collapsed)this.effectFrames.delete(event.id);
      const projectedSources=Object.fromEntries(emitters.map(e=>[e.id,{x:pose.x+e.x*size/100,y:pose.y+e.y*size/100,plane:e.plane,z:e.z}]));
      return {sample:{positions:{},glows:{},rotations:{},effects:effect?[effect]:[],projectedSources,effectScale:effect?.effectScale??1,state:{phase:'holding',progress:1}},hardware:{},context:{source:pose,target:pose,size,targetSize:size,transform:{width:size,angle:pose.angle}},target:this.token};
    }
    const target=event.target?canvas.tokens?.get(event.target):null,hardware=this.pausedScanHardware(event,snapshot,preparedHardware??(this.hardware??=actionHardware(snapshot,now)),now,{readOnly}),context=actionContext(this.token,target,snapshot,event,manager,hardware,now,{scanGeometry:!event.utility?.followSource});
    if(event.kind==='utility'&&event.utility?.followSource&&event.status!=='returning'){
      this.utilityAnchors??=new Map();
      this.utilityLocomotion??=new Map();
      context.scanLocomotion=stepScanLocomotion(this.utilityLocomotion.get(event.id),{source:context.source,now,size:context.size,radius:event.utility.radiusPixels,reduced:snapshot.effective?.reducedMotion});
      const anchor=stepScanAnchor(context.scanLocomotion.teleported?null:this.utilityAnchors.get(event.id),context.source,now,{radius:event.utility.radiusPixels,reduced:snapshot.effective?.reducedMotion,working:event.utility.mode==='areaScan',size:context.size,motion:context.scanLocomotion});
      if(!readOnly)this.utilityAnchors.set(event.id,anchor);context.scanCenter=anchor;
      if(event.utility.mode==='areaScan')context.gridScan=scanSceneContext({center:anchor,radius:event.utility.radiusPixels??context.size});
    }
    const wallStates=new Map(this.scanWallStates??[]);
    const guardSample=(sample,tool,toolContext)=>{
      // Discovery routing must see withdrawal before consuming completed cells.
      // Apply the physical pursuit once, after any attended creature bodies
      // have been installed by the encounter controller.
      if(event.utility?.followSource&&context.scanLocomotion?.active){sample.effects=[];sample.completedCells={};sample.scanWorking=0;sample.scanComplete=false;sample.scanRelocating=true;}
      if(toolContext.scanWalls){const guarded=guardScanSample(sample,tool,toolContext,now,wallStates.get(tool.id),{readOnly});wallStates.set(tool.id,guarded.state);return guarded.sample;}
      return sample;
    };
    const sample=event.kind==='utility'&&event.utility?.mode==='areaScan'&&event.status!=='returning'?(this.scanEncounters??=new ScanEncounterController()).sample(event,now,context,{tokens:globalThis.canvas?.tokens?.placeables??[],source:this.token,readOnly,guardSample,contextForTarget:attended=>{
      const pose=scanVisualPose(attended,manager),portrait=scanTokenPortrait(attended,{pose}),targetScan={...targetScanContext(attended),portrait};
      return {...context,target:portrait.center,targetSize:Math.max(attended.w,attended.h),targetWidth:portrait.width,targetHeight:portrait.height,targetRotation:portrait.rotation,targetScan};
    }}):guardSample(sampleSequence(event,now,context),event,context),response=snapshot.conditionResponse;
    if(event.kind==='treatment'&&event.treatment?.diagnosticScan===true)this.medicalDiagnosticRelease(event,sample,context,now,{readOnly});
    if(context.scanLocomotion){if(!context.scanWalls)applyScanLocomotion(sample,context.scanLocomotion,context);if(!readOnly)this.utilityLocomotion.set(event.id,context.scanLocomotion);}
    if(!readOnly&&context.scanWalls)this.scanWallStates=wallStates;
    if(event.kind==='utility'&&event.status!=='returning'&&['areaScan','creatureScan'].includes(event.utility?.mode)){
      // The return already starts at a captured displayed bearing and meets
      // the moving home slot exactly. Filtering that endpoint would leave a
      // residual turn when the home rig takes ownership again.
      const guarded=guardScanOrientation(sample,event,context,hardware,now,this.scanOrientations?.get(event.id));
      if(!readOnly)(this.scanOrientations??=new Map()).set(event.id,guarded.state);
    }
    applySendOut(event,sample,context,now);
    sample.conditionBits={};
    for(const [index,id] of event.bits.entries()){
      const p=sample.positions[id];if(!p)continue;
      const adjusted=applyBitCondition({...p,z:sample.depths?.[id],angle:context.transform.angle+(sample.rotations[id]??0)},response,{id,index,now,scale:context.size,source:context.source});
      sample.positions[id]={x:adjusted.x,y:adjusted.y};sample.rotations[id]=(sample.rotations[id]??0)+adjusted.angleDelta;
      if(Number.isFinite(adjusted.z))(sample.depths??={})[id]=adjusted.z;
      if(sample.glows[id])sample.glows[id].strength*=adjusted.glowMultiplier;sample.conditionBits[id]=adjusted;
    }
    if(event.treatment?.diagnosticScan===true)for(const effect of sample.effects)if(effect.medicalDiagnostic){
      // Conditions adjust the actual instrument after its authored reading.
      // Register both active and withdrawing optics to that final position.
      const scale=context.size*(sample.effectScale??1)/100,b=effect.bounds;let left=b.x,top=b.y,right=b.x+b.width,bottom=b.y+b.height;
      for(const channel of effect.channels){
        const p=sample.positions[channel.id];if(!p)continue;
        const angle=channel.frameRotation??0,c=Math.cos(angle),s=Math.sin(angle),x=(p.x-context.target.x)/scale,y=(p.y-context.target.y)/scale;
        channel.source={x:x*c+y*s,y:-x*s+y*c};left=Math.min(left,x-18);top=Math.min(top,y-18);right=Math.max(right,x+18);bottom=Math.max(bottom,y+18);
      }
      effect.bounds={x:left,y:top,width:right-left,height:bottom-top};
    }
    const collapsed=response?.bits&&response.collapse?.phase!=='awake';
    if(collapsed){sample.effects.length=0;sample.encounterSurfaces=[];this.effectFrames.delete(event.id);}
    if(!collapsed&&event.kind==='escort'&&sample.state.phase==='escorting'){
      const emitters=event.bits.flatMap(id=>{
        const p=sample.positions[id];if(!p)return [];
        const z=sample.depths?.[id]??1,key=`${event.id}:${id}`,previous=this.depthSides?.get(key),dx=p.x-context.target.x,dy=p.y-context.target.y,c=Math.cos(context.targetRotation),s=Math.sin(context.targetRotation);
        let front=z>=0;if(previous!==undefined&&previous!==front&&Math.abs(dx*c+dy*s)<(target?.w??context.targetSize)/2&&Math.abs(-dx*s+dy*c)<(target?.h??context.targetSize)/2)front=previous;
        return [{id,x:dx/context.targetSize*100,y:dy/context.targetSize*100,z,plane:front?'front':'rear'}];
      });
      const effect=this.groupEffect(event,emitters.length,now,snapshot,emitters,this.projectionContext(event,context.target,context.targetSize,now,snapshot));if(effect)sample.effects.push(effect);
      sample.projectedSources=Object.fromEntries(emitters.map(e=>[e.id,{...sample.positions[e.id],plane:e.plane,z:e.z}]));
      // Only an active field turns its instruments toward their own working
      // points. Disabling it immediately restores the chosen formation.
      if(effect?.emissionTargets)for(const aim of effect.emissionTargets){
        const p=sample.positions[aim.id],h=hardware[aim.id]?.hardware;if(!p||!h)continue;
        const targetAngle=Math.atan2(context.target.y+aim.y*context.targetSize/100-p.y,context.target.x+aim.x*context.targetSize/100-p.x)+Math.PI/2-context.transform.angle-(h.angle??0);
        const from=sample.rotations[aim.id]??0,delta=Math.atan2(Math.sin(targetAngle-from),Math.cos(targetAngle-from));
        sample.rotations[aim.id]=from+delta*(effect.activation?.projection??1)*.8;
      }
      if(effect?.duties?.length){sample.coreStates??={};for(const duty of effect.duties){sample.coreStates[duty.id]={state:duty.state,amount:duty.amount};if(sample.glows[duty.id])sample.glows[duty.id].strength*=duty.energy;}}
      if(event.group?.effect?.enabled&&snapshot.gems.glow!==false)for(const glow of Object.values(sample.glows))glow.strength=Math.min(3,glow.strength*(1+.8*(event.group.effect.strength??1)));
      sample.effectScale=context.targetSize/context.size*(effect?.effectScale??1);
      sample.effectRotation=effect?.id==='passive'?context.targetRotation??0:0;
    }
    for(const id of event.bits){const activity=this.scanMechanismActivity(event,id,sample.coreStates?.[id],now,{readOnly});if(activity)(sample.coreStates??={})[id]=activity;}
    return {sample,hardware,context,target};
  }
  /** Body material and mechanism channels are consumed only by a texture
   * paint. Keep pose, wave integration and placement at display cadence, then
   * prepare exactly the current frame if a capped paint or count change needs it. */
  prepareBodyPart(original,{event,sample,id,phase,poseAngle,placementAngle,glow,wave,condition,geometryHandoff},snapshot,cfg,now){
    const part={...original,hardware:{...original.hardware,angle:(original.hardware.angle??0)+poseAngle-placementAngle}};
    part.hardware={...part.hardware,power:Math.max(.85,part.hardware.power),glowMode:glow.mode??'core',glow:{direction:wave.direction,strength:glow.strength,color:glow.color},
      resonance:{...part.hardware.resonance,healing:event.kind==='treatment'?(phase==='returning'?1-sample.state.progress:1):part.hardware.resonance?.healing??0,focus:.8}};
    const coreSelection=event.group?.internalState??snapshot.gems.coreState??'idle',responsive=coreSelection==='auto'||coreSelection==='idle'&&!!sample.coreStates?.[id],effectState=event.group?.effect?.enabled?tokenEffectDefinition(event.group.effect.id)?.state:null;
    const activity=sample.coreStates?.[id]??(phase==='returning'||phase==='finishing'?{state:'settling',progress:sample.state.progress}:phase==='travel'?{state:'encased',amount:1-sample.state.progress}:event.kind==='treatment'?phase==='scanning'?{state:'charging',amount:.45}:{state:'open'}:effectState?{state:effectState}:null);
    part.hardware.tool=sample.tools?.[id]??(event.kind==='treatment'&&phase!=='travel'&&phase!=='returning'?{type:phase==='scanning'?'lens':['precision','suture','microloom'].includes(event.treatment?.style)?'probe':'plate',amount:.45*(phase==='finishing'?1-sample.state.progress:1),progress:sample.state.progress}:null);
    part.hardware=withCoreActivity(part.hardware,responsive?activity:null,{selection:coreSelection,time:now/1000,responsive:snapshot.gems.assetStates!==false});
    if(condition){part.hardware.power*=condition.glowMultiplier;part.hardware.roll*=condition.conditionMotion;
      if(condition.conditionGround>0)part.hardware=withCoreActivity(part.hardware,{state:'encased',amount:condition.conditionGround},{selection:'auto'});}
    const geometryAge=geometryHandoff?geometryHandoff.pausedAt!=null&&event.taskPausedAt!=null?0:now-geometryHandoff.at:Infinity,r=part.hardware.resonance;
    if(geometryAge>=0&&geometryAge<SCAN_MECHANISM_HANDOFF&&snapshot.gems.assetStates!==false&&r?.animated!==false&&(r?.mechanical??r?.amount??0)>0&&
      !['damage','glitch','suppression','collapse','impact','drive'].some(channel=>(r?.[channel]??0)>0)&&!(condition?.conditionGround>0)){
      part.hardware.scanResume={geometry:geometryHandoff.geometry,weight:1-scanCueEase(geometryAge/SCAN_MECHANISM_HANDOFF),expectedMotion:{amount:r.amount,mechanical:r.mechanical,charge:r.charge}};
    }
    if(cfg.performanceComponents?.fields===false)part.hardware.glow=null;
    return part;
  }
  update(events,snapshot,manager,cfg,now){
    localPerformance.recordQuality(cfg);localPerformance.recordRenderPath('action-main-thread');
    this.depthSides??=new Map();
    this.scanEncounters?.retain(events,globalThis.canvas?.scene,now);
    const token=this.token,source=token.mesh,visible=source&&isShown(token,source),slot=Math.floor(now/(1000/(cfg.rigFPS??30)));
    const sharedTarget=readBitIntentTarget(token.document),selectedFocus=sharedTarget?.mesh&&!sharedTarget.document?.hidden&&isShown(sharedTarget,sharedTarget.mesh)?tokenVisualPose(sharedTarget,manager):null;
    this.effectFPS=(cfg.rigFPS??30);
    // (Beta.32: a new picture at most every 12.5 ms, as the wings: on a canvas
    // running faster than 60 fps the field and its emitters were repainted on
    // uneven 1- and 2-frame holds; now even holds, about 41 to 55 a second.
    // Measured on the local clock: the synced game clock may move in steps.)
    const localNow=performance.now(),paint=slot!==this.slot&&!(localNow-this.paintedAt<MIN_REPAINT_MS),bits=new Map(),placements={},retained=new Set(),medicalRetained=new Set(),projectedRetained=new Set(),depthSources=new Map(),scanTargets=new Set(),bodyPreparations=[],sendOut=[];let culled=false;
    if(paint)this.paintedAt=localNow;
    this.medicalEmitters??=new Map();
    this.projectedEmitters??=new Map();
    // Hardware geometry changes only when its artwork can actually be repainted.
    if(paint){this.hardware=null;this.homeHardware=null;}
    const allocation=snapshot.bitAllocationState,home=allocation?.groups?.home,homeIds=snapshot.bitVisibleHomeStations??snapshot.bitHomeStations??BIT_IDS.filter(id=>allocation?.bits?.[id]?.location==='home');
    const homeEffect=(home?.effect?.enabled||this.hasHomeFieldTail(now))&&homeIds.length&&snapshot.bitDeployment>.01&&cfg.performanceComponents?.fields!==false;
    const drawEvents=homeEffect?[...events,{id:'home-token-field',kind:'token-field',bits:[],participants:homeIds,formationBits:snapshot.bitHomeStations,count:homeIds.length,group:home,status:'running',started:0,detail:cfg.treatmentDetail}]:events;
    // Off-screen (or hidden-patient) work keeps its textures and canvases; only
    // its meshes hide. A parked light still records its exact displayed place.
    const culledEvents=new Set(),cull=event=>{
      culled=true;culledEvents.add(event.id);
      if(event.kind==='utility'&&event.utility?.mode==='parkLight'&&event.status==='running')try{
        const {sample}=this.sample(event,snapshot,manager,now,this.hardware);
        this.lastPositions.set(event.id,sample.positions);(this.lastPositionTimes??=new Map()).set(event.id,now);
      }catch{}
    };
    if(!visible)for(const event of drawEvents)if(event.status!=='queued')cull(event);
    // Placement headings that may turn at display rate against the painted
    // texture, and the nominal scale each texture's density is sized for.
    const headings=new Map(),paintScales={},homeAlpha=(snapshot.options?.opacity??.95)*(snapshot.compactBits?1:(snapshot.effective?.intensity??1));
    for(const event of drawEvents){
      if(event.status==='queued'||!visible)continue;
      if(event.kind==='token-field'){
        const pose=tokenVisualPose(token,manager),radius=Math.max(token.w,token.h)*Math.max(1.4,snapshot.compactBits?1.4*(snapshot.gems.soloRadius??1):(snapshot.options?.wingScale??5));
        if(!isOnScreen(pose.x,pose.y,radius,radius)){cull(event);continue;}
      }
      if(event.kind==='treatment'||event.kind==='escort'){
        const patient=event.target?canvas.tokens?.get(event.target):null,transform=sourceTransform(token,snapshot,manager),sourcePose=tokenVisualPose(token,manager);
        const portrait=event.kind==='treatment'&&patient?.mesh?scanTokenPortrait(patient,{pose:scanVisualPose(patient,manager)}):null;
        const patientPose=portrait?.center??(patient?.mesh?tokenVisualPose(patient,manager):null);
        const phase=eventState(event,now).phase,transit=['travel','returning'].includes(phase)||snapshot.conditionResponse?.bits&&snapshot.conditionResponse?.collapse?.phase!=='awake';
        const rests=snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse?.phase!=='awake'?Object.values(snapshot.conditionResponse.collapse.restsWorld??{}):[];
        const positions=transit?[sourcePose,patientPose,...rests,...Object.values(event.returnFrom??{}),...Object.values(event.originsWorld??{}),...Object.values(event.origins??{}).map(p=>toWorld(p,transform))].filter(Boolean):[patientPose??sourcePose];
        const treatmentMargin=Math.max(Math.max(patient?.w??token.w,patient?.h??token.h)*2.5*(event.treatment?.scale??1),portrait?Math.max(portrait.width,portrait.height)/2+30:0);
        const margin=transit?Math.max(Math.max(token.w,token.h)*(snapshot.options?.wingScale??5),treatmentMargin):treatmentMargin;
        const xs=positions.map(p=>p.x),ys=positions.map(p=>p.y),left=Math.min(...xs)-margin,right=Math.max(...xs)+margin,top=Math.min(...ys)-margin,bottom=Math.max(...ys)+margin;
        if(!isOnScreen((left+right)/2,(top+bottom)/2,(right-left)/2,(bottom-top)/2)){cull(event);continue;}
      }
      if(event.kind==='utility'){
        const attended=event.target?canvas.tokens?.get(event.target):null;
        const center=event.utility?.followSource?tokenVisualPose(token,manager):attended?.mesh?tokenVisualPose(attended,manager):event.utility?.center;
        if(center){
          const margin=Math.max(event.utility?.radiusPixels??0,Math.max(attended?.w??token.w,attended?.h??token.h)*2);
          const candidates=[center,...Object.values(event.originsWorld??{}),...Object.values(event.returnFrom??{})];
          const left=Math.min(...candidates.map(p=>p.x))-margin,right=Math.max(...candidates.map(p=>p.x))+margin;
          const top=Math.min(...candidates.map(p=>p.y))-margin,bottom=Math.max(...candidates.map(p=>p.y))+margin;
          if(!isOnScreen((left+right)/2,(top+bottom)/2,(right-left)/2,(bottom-top)/2)){cull(event);continue;}
        }
      }
      // A hidden patient needs no (costly) sample at all.
      const patient=event.target?canvas.tokens?.get(event.target):null;
      if(!(event.status==='returning'&&!patient||!event.target||patient?.mesh&&isShown(patient,patient.mesh))){cull(event);continue;}
      const {sample,hardware,context,target}=this.sample({...event,detail:cfg.treatmentDetail},snapshot,manager,now,this.hardware);
      this.lastPositions.set(event.id,sample.positions);
      if(sample.sendOut?.ornaments?.length)sendOut.push(...sample.sendOut.ornaments);
      this.lastPositionTimes??=new Map();this.lastPositionTimes.set(event.id,now);
      const phase=sample.state.phase,age=now-event.started,emissions=sample.effects?.flatMap(fx=>fx.emissionTargets??[]);
      for(const [id,p] of Object.entries(sample.positions)){
        const presence=actionBitPresence(event,id,sample.state,context,now),deployment=presence.deployment;
        const original=hardware[id],glow=sample.glows[id];if(!original)continue;
        // Never mutate the shared hardware cache with one target's activity.
        const condition=sample.conditionBits?.[id],placementAngle=context.transform.angle;
        const poseAngle=condition?.conditionGround>0&&Number.isFinite(condition.angleAbsolute)?condition.angleAbsolute:placementAngle+(sample.rotations?.[id]??0);
        // The shell's temporary turn belongs to the capped artwork frame.
        // A display-rate mesh roll would rotate its cached fan between paints,
        // while the wave controller is following its restrained eased bearing.
        // This preserves the complete old body angle at every artwork sample.
        const intent=sample.intents?.find(v=>v.station===id)?.intent,focus=sample.focuses?.find(v=>v.station===id)?.focus,emission=emissions?.find(v=>v.id===id);
        const duty=emission?{x:context.target.x+emission.x*context.targetSize/100,y:context.target.y+emission.y*context.targetSize/100}:event.kind==='treatment'&&!['travel','returning'].includes(phase)?context.target:null;
        const returnToken=context.returnTargets?.[id],charge=phase==='returning'?returnToken?.mesh?tokenVisualPose(returnToken,manager):context.source:event.kind==='escort'?context.target:context.source;
        // The owner frame remains common across remote work, directions and
        // returns. A differently rotated recipient never rebases the fan.
        const frameAngle=context.transform.angle;
        const attention=event.kind==='escort'&&phase==='escorting'?selectedFocus??duty:duty;
        const wave=glow.mode==='field'&&glow.strength>0&&cfg.performanceComponents?.fields!==false?updateWorldBitWaveDirection(this.waveState,id,{position:p,charge,intent,focus,target:attention,
          frameAngle,placementAngle,now,
          animated:snapshot.gems.animated,reduced:!!snapshot.effective?.reducedMotion||!!cfg.reduced}):{direction:[0,-1]};
        if(cfg.performanceComponents?.bits===false)continue;
        const key=BIT_KEY[id],bit={id:key,left:id.startsWith('left'),front:1,rear:0,part:original};bits.set(key,bit);
        bodyPreparations.push({bit,original,event,sample,id,phase,poseAngle,placementAngle,glow,wave,condition,geometryHandoff:this.scanGeometryHandoffs?.get(id)});
        let front=sample.depths?.[id]!=null?sample.depths[id]>=0:age>Math.min(250,event.travelDuration*.25)&&!(phase==='returning'&&sample.state.progress>.8);
        if((event.kind==='escort'||event.sequence?.gesture)&&target?.mesh&&!(condition?.conditionGround>.05)){
          const depthKey=`${event.id}:${id}`,previous=this.depthSides.get(depthKey),dx=p.x-context.target.x,dy=p.y-context.target.y,c=Math.cos(context.targetRotation),s=Math.sin(context.targetRotation);
          if(previous!==undefined&&previous!==front&&Math.abs(dx*c+dy*s)<target.w/2&&Math.abs(-dx*s+dy*c)<target.h/2)front=previous;
          this.depthSides.set(depthKey,front);
        }
        // A local transfer (her home formation moving between the wings and her
        // side as she lands or takes off) starts at the size it was shown at home,
        // not at a remote escort's size: no one-frame growth at the handover.
        const physicalWidth=event.localTransfer&&Array.isArray(event.originScale)&&Number.isFinite(event.originScale[0])?context.size*event.originScale[0]:event.kind==='escort'?context.size*3.5:context.transform.width,returnWidth=phase==='returning'&&context.returnTargets?.[id]?context.size*3.5:context.transform.width;
        const width=phase==='returning'?physicalWidth+(returnWidth-physicalWidth)*sample.state.progress:physicalWidth;
        // Home bits draw at the token's opacity (and wing intensity). Leaving
        // home that factor releases over the acquisition; returning to the home
        // formation it is restored, so neither edge jumps in brightness.
        const homeWeight=event.localTransfer?1:phase==='returning'?(!context.returnTargets?.[id]&&(context.deployedBits?context.deployedBits.includes(id):context.deployed)?sample.state.progress:0):
          event.status==='running'&&!event.originPresence?.[id]?1-ease((now-event.started)/Math.max(1,Math.min(event.travelDuration,450))):0;
        const homeMatch=1+(homeAlpha-1)*Math.max(0,Math.min(1,homeWeight));
        placements[key]={...p,alpha:source.alpha*deployment*presence.returning*homeMatch*(sample.sendOut?.alpha?.[id]??1),scale:width/600*(.2+.8*presence.scale)*(sample.sendOut?.scale?.[id]??1),front,angle:placementAngle};
        paintScales[key]=width/600;
        // The housing turns at display rate against its cached texture, except
        // where an owner-frame field fan is painted (it would swing with it).
        const fan=glow.mode==='field'&&glow.strength>0&&cfg.performanceComponents?.fields!==false;
        if(!(condition?.conditionGround>0)&&(!fan||event.kind==='utility'&&['areaScan','creatureScan'].includes(event.utility?.mode)))headings.set(key,(original.hardware.angle??0)+poseAngle);
        if(condition?.conditionGround>0){
          if(Number.isFinite(condition.restingScale))placements[key].scale+=(condition.restingScale-placements[key].scale)*condition.conditionGround;
          placements[key].alpha=source.alpha*(deployment+(1-deployment)*condition.conditionGround)*homeMatch;
          if(condition.conditionGround>.98)placements[key].front=true;
        }
        const depthTarget=condition?.conditionGround>.05?this.token:phase==='returning'?context.returnTargets?.[id]??this.token:sample.depthTargets?.[id]??target;
        if(sample.depths?.[id]!=null&&depthTarget?.mesh)depthSources.set(key,depthTarget.mesh);
      }
      // A discovered creature has its own bounded portrait surface while the
      // colleagues' area projection keeps its original center and resolution.
      for(const layer of [{event,sample,context,target},...(sample.encounterSurfaces??[])]){
      const {event,sample,context,target}=layer;
      if(target&&(event.kind==='utility'&&event.utility?.mode==='creatureScan'||event.kind==='treatment'&&sample.effects.some(e=>e.medicalDiagnostic)))scanTargets.add(target);
      const effectDiameter=context.size*2.8*(sample.effectScale??1),effectTarget=sample.effectCenter??context.target??target?.mesh??source;
      let diagnosticExtent=0;
      if(event.treatment?.diagnosticScan===true)for(const effect of sample.effects)if(effect.medicalDiagnostic){const b=effect.bounds;diagnosticExtent=Math.max(diagnosticExtent,Math.abs(b.x),Math.abs(b.y),Math.abs(b.x+b.width),Math.abs(b.y+b.height));}
      const effectRadius=Math.max(effectDiameter/2*(sample.effectRotation?Math.SQRT2:1),diagnosticExtent*context.size*(sample.effectScale??1)/100),effectVisible=isOnScreen(effectTarget.x,effectTarget.y,effectRadius,effectRadius);
      const effectAllowed=['escort','token-field','utility'].includes(event.kind)?cfg.performanceComponents?.fields!==false:cfg.performanceComponents?.treatment!==false;
      if(effectVisible&&effectAllowed&&sample.effects.some(e=>e.effect!=='sprite')){
        const planes=event.treatment||sample.effects.some(e=>['token-field','v8-scan'].includes(e.effect))?['rear','front']:['front'];
        // Share only this update's patient path geometry. Cached display frames
        // allocate nothing here, and later samples cannot reuse stale artwork.
        let preparedArtwork,preparedScanArtwork,projectedArtwork,medicalResolution=0;
        const boundsCache=new Map(),details=['low','standard','high'],limit=details.indexOf(cfg.treatmentDetail??'high'),requested=['escort','token-field','utility'].includes(event.kind)?limit:details.indexOf(event.treatment?.detail??'standard');
        const detail=details[Math.min(Math.max(0,requested),Math.max(0,limit))],world=canvas.primary?.worldTransform,zoom=world?Math.max(Math.hypot(world.a??1,world.b??0),Math.hypot(world.c??0,world.d??1)):1;
        const desired=treatmentResolution(effectDiameter,detail,zoom,canvas.app?.renderer?.resolution??1);
        for(const effect of sample.effects)if(['hardlight','v8-scan'].includes(effect.effect))effect.detail=detail;
        const artworkKey=settledTreatmentArtworkKey(event,sample,snapshot);
        // Only rendered close surfaces acquire native alpha pixels. Prediction
        // samples and serialized choreography stay free of DOM/native handles.
        const tokenMask=sample.effects.some(e=>e.effect==='v8-scan'&&e.mode==='creatureScan')
          ?(this.tokenScanMasks??=new TokenScanMaskCache()).get(target,{center:effectTarget,rotation:sample.effectRotation??0,scale:context.size*(sample.effectScale??1)/100,portrait:context.medicalScan?.portrait??context.targetScan?.portrait,
            pose:()=>target?.mesh?scanVisualPose(target,manager):null}):undefined;
        const attachedEmitters=event.kind==='treatment'?new Set(Object.keys(sample.positions)):null;
        const attachedProjectedEmitters=sample.projectedSources?new Set(Object.keys(sample.projectedSources)):null;
        const attachmentKey=[attachedEmitters?.size?[...attachedEmitters].sort().join(','):'',attachedProjectedEmitters?.size?[...attachedProjectedEmitters].sort().join(','):'',tokenMask?.signature??(tokenMask===null?'no-token-alpha':'')].join('|');
        for(const plane of planes){
          const key=`${event.id}:${plane}`;let r=this.effects.get(key);
          // Large area scans: size the raster from the team crop, not the
          // whole 280-unit field, so a 120 ft survey stays sharp.
          let planeDesired=desired;const areaCrop=sample.effects.length>0&&sample.effects.every(effect=>effect.effect==='v8-scan'&&effect.mode==='areaScan');
          if(areaCrop){
            let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
            for(const effect of sample.effects){const b=scanEffectBounds(effect,plane,preparedScanArtwork??=new Map());if(b){left=Math.min(left,b.x);top=Math.min(top,b.y);right=Math.max(right,b.x+b.width);bottom=Math.max(bottom,b.y+b.height);}}
            if(Number.isFinite(left))planeDesired=scanCropResolution(effectDiameter,Math.max(right-left,bottom-top),detail,zoom,canvas.app?.renderer?.resolution??1);
          }
          const resolution=r&&r.detail===detail?settledTreatmentResolution(r,planeDesired,now):planeDesired;
          // Display-rate source motion must not resize/repaint a retained scan
          // between authored artwork frames. The cached texture follows its
          // world transform until the next normal optical exposure.
          const scanSurface=sample.effects.every(effect=>effect.effect==='v8-scan');
          if(scanSurface&&r?.mesh.visible===false)r.painted=false;
          const desiredViewport=scanSurface&&!paint&&r?.painted&&r.resolution===resolution?r.viewport:bitEffectViewport(sample.effects,resolution,plane,boundsCache,scanSurface?(preparedScanArtwork??=new Map()):null);if(!desiredViewport)continue;
          retained.add(key);
          if(!r){r=this.createEffect(key,resolution,desiredViewport);this.effects.set(key,r);}
          r.detail=detail;
          if(r.resolution!==resolution){r.viewport=null;r.pendingViewport=null;r.painted=false;}
          const viewport=stableEffectViewport(r,desiredViewport,now,areaCrop?{maxPixels:1024*1024}:undefined),regionChanged=viewport!==r.viewport;
          if(regionChanged){this.resizeEffect(r,resolution,viewport);r.painted=false;}
          if(r.lastAttachmentKey!==attachmentKey&&(!scanSurface||paint))r.painted=false;
          const staticField=snapshot.effective?.reducedMotion&&sample.effects.every(e=>e.effect==='token-field'),frame=sample.effects[0];
          const treatmentKey=settledTreatmentPaintKey(artworkKey,snapshot,cfg,resolution,plane,viewport,zoom,canvas.app?.renderer?.resolution??1);
          // Retained canvases wake when their visibility returns, while their
          // token transforms below continue updating even when paint sleeps.
          if(treatmentKey!==null&&r.mesh.visible===false)r.painted=false;
          const changed=treatmentKey!==null?r.lastTreatmentKey!==treatmentKey:!staticField||r.lastFrame!==frame;
          if(paint&&changed||!r.painted){const scanStarted=scanSurface&&localPerformance.active?localPerformance.beginStage():null;preparedArtwork??=new Map();if(attachedProjectedEmitters?.size)projectedArtwork??=projectedEmitterArtwork(sample.effects,attachedProjectedEmitters);const options={size:resolution,now,plane,viewport,preparedArtwork,attachedEmitters,attachedProjectedEmitters,tokenMask,preparedScanArtwork:scanSurface?(preparedScanArtwork??=new Map()):null};if(scanSurface&&sample.effects.every(effect=>effect.mode==='areaScan'))paintCroppedScanSurface(r,sample,options,paintActionEffects);else{paintActionEffects(r.ctx,sample,options);if(sample.effects.some(e=>e.effect==='hardlight'||e.selfField))underlayHardlightSurface(r.surface,r.ctx,resolution);}r.texture.baseTexture.update();if(scanStarted!==null){localPerformance.endStage('scanPaint',scanStarted);localPerformance.count('scanTextureUploads');localPerformance.count('scanUploadBytes',viewport.width*viewport.height*4);}r.painted=true;r.lastFrame=frame;r.lastTreatmentKey=treatmentKey;r.lastAttachmentKey=attachmentKey;localPerformance.count('treatmentTextureUploads');localPerformance.count('treatmentUploadBytes',viewport.width*viewport.height*4);}
          medicalResolution=Math.max(medicalResolution,resolution);
          setMeshTransform(r.mesh,effectTarget.x,effectTarget.y,sample.effectRotation??0,effectDiameter*viewport.width/resolution,effectDiameter*viewport.height/resolution);if(r.mesh.alpha!==source.alpha)r.mesh.alpha=source.alpha;if(r.mesh.visible!==true)r.mesh.visible=true;
          placeBehind(r.mesh,target?.mesh??source,plane==='front'?-.14:.23);
        }
        if(attachedEmitters?.size&&medicalResolution)this.updateMedicalEmitters(event,sample,context,target,source,medicalResolution,preparedArtwork,attachedEmitters,medicalRetained,placements,depthSources,paint);
        if(attachedProjectedEmitters?.size&&medicalResolution)this.updateProjectedEmitters(event,sample,context,target,source,medicalResolution,projectedArtwork,attachedProjectedEmitters,projectedRetained,depthSources);
      }
      for(const effect of effectVisible&&cfg.performanceComponents?.treatment!==false?sample.effects.filter(e=>e.effect==='sprite'):[]){
        this.sprites??=new Map();const key=`${event.id}:${effect.asset}`;retained.add(key);
        let sprite=this.sprites.get(key);if(!sprite){sprite={loading:true};this.sprites.set(key,sprite);void this.loadSprite(sprite,effect.asset,key);}
        if(sprite.mesh){const p=effect.progress;sprite.mesh.visible=true;sprite.mesh.alpha=Math.min(1,effect.strength)*Math.sin(Math.PI*p)*source.alpha;
          sprite.mesh.position.set(context.target.x,context.target.y);sprite.mesh.width=effect.size*context.size;sprite.mesh.height=sprite.mesh.width/sprite.aspect;
          sprite.mesh.rotation=effect.angle*Math.PI/180;placeBehind(sprite.mesh,target?.mesh??source,-.145);}
      }
      }
    }
    this.tokenScanMasks?.retain(scanTargets);
    if(culled&&!bits.size&&!retained.size&&!medicalRetained.size&&!projectedRetained.size){const changed=!!this.hadVisible;this.hadVisible=false;this.bits.hide();this.sendOut?.hide();for(const r of this.effects.values())r.mesh.visible=false;for(const r of this.medicalEmitters.values())r.mesh.visible=false;for(const r of this.projectedEmitters.values())r.mesh.visible=false;for(const r of this.sprites.values())if(r.mesh)r.mesh.visible=false;return changed;}
    // Hand-back overlap (beta.34): a bit this renderer drew last frame but
    // no longer owns (its trip ended, home has it now) keeps its last picture
    // and place for a few frames, fading out under the home renderer's copy.
    // Without it, the frame where the two renderers swap could show neither.
    {const held=this.handback??=new Map(),t=localNow;
      for(const [key,shown] of this.lastShown??[])if(!bits.has(key)&&!held.has(key)&&shown.placement.alpha>.02)held.set(key,{...shown,at:t});
      for(const [key,h] of held){const age=t-h.at;if(bits.has(key)||age>=HANDBACK_MS){held.delete(key);continue;}
        bits.set(key,h.bit);paintScales[key]=h.scale;placements[key]={...h.placement,alpha:h.placement.alpha*(1-age/HANDBACK_MS)};if(h.depth)depthSources.set(key,h.depth);}}
    if(paint||this.bitCount!==bits.size){
      for(const prepared of bodyPreparations)prepared.bit.part=this.prepareBodyPart(prepared.original,prepared,snapshot,cfg,now);
      const retain=new Set(drawEvents.filter(event=>culledEvents.has(event.id)).flatMap(event=>event.bits.map(id=>BIT_KEY[id])));
      this.bits.paint(bits,cfg.bitQuality,now,{scale:paintScales,retain,offload:this.pictures.offload(cfg,now)});this.bitCount=bits.size;this.slot=slot;
    }
    // Scanning cores use no directional field fan. Their metal housing may
    // therefore turn at display cadence against its cached native artwork,
    // while paints/uploads retain their existing 24 Hz ceiling. Compensating
    // the real painted angle also prevents an owner-frame rotation from
    // snapping the entire shell between two artwork frames.
    for(const [key,heading]of headings){const painted=this.bits.paintedHardware?.(key)?.angle??this.bits.records?.get(key)?.frame?.bit?.part?.hardware?.angle;if(Number.isFinite(painted)&&placements[key])placements[key].angle=heading-painted;}
    // Final depth belongs to the recipient/return target when present. Passing
    // it into placement avoids invalidating owner then patient sort every tick.
    this.bits.placeWorld(placements,source,cfg,depthSources);
    this.lastShown=new Map([...bits].filter(([key])=>placements[key]&&!this.handback?.has(key)).map(([key,bit])=>[key,{bit,placement:placements[key],scale:paintScales[key],depth:depthSources.get(key)}]));
    (this.sendOut??=new SendOutLayer(this.token)).update(sendOut,source);
    const dormant=id=>{const event=id.slice(0,id.indexOf(':'));return culledEvents.has(event)||events.some(e=>e.id===event&&e.kind==='utility'&&e.status!=='returning');};
    for(const [id,r] of this.effects)if(!retained.has(id)){
      // Repeated examinations have deliberate pauses, and culled work comes
      // back on screen. Keep those surfaces dormant instead of recreating them.
      if(dormant(id)){r.mesh.visible=false;continue;}
      this.releaseEffect(r);this.effects.delete(id);
    }
    for(const [id,r] of this.medicalEmitters)if(!medicalRetained.has(id)){if(culledEvents.has(id.slice(0,id.indexOf(':')))){r.mesh.visible=false;continue;}this.releaseEffect(r);this.medicalEmitters.delete(id);}
    for(const [id,r] of this.projectedEmitters)if(!projectedRetained.has(id)){if(culledEvents.has(id.slice(0,id.indexOf(':')))){r.mesh.visible=false;continue;}this.releaseEffect(r);this.projectedEmitters.delete(id);}
    for(const [key,r] of this.sprites??[])if(!retained.has(key)){if(culledEvents.has(key.slice(0,key.indexOf(':')))){if(r.mesh)r.mesh.visible=false;continue;}r.mesh?.parent?.removeChild(r.mesh);r.mesh?.destroy({children:true,texture:false,baseTexture:false});this.sprites.delete(key);}
    for(const id of this.lastPositions.keys())if(!events.some(e=>e.id===id))this.lastPositions.delete(id);
    for(const id of this.lastPositionTimes?.keys()??[])if(!events.some(e=>e.id===id))this.lastPositionTimes.delete(id);
    for(const id of this.utilityAnchors?.keys()??[])if(!events.some(e=>e.id===id))this.utilityAnchors.delete(id);
    for(const id of this.utilityLocomotion?.keys()??[])if(!events.some(e=>e.id===id))this.utilityLocomotion.delete(id);
    for(const id of this.scanOrientations?.keys()??[])if(!events.some(e=>e.id===id))this.scanOrientations.delete(id);
    for(const id of this.medicalDiagnosticFrames?.keys()??[])if(!events.some(e=>e.id===id))this.medicalDiagnosticFrames.delete(id);
    for(const id of this.scanWallStates?.keys()??[])if(!events.some(e=>id===e.id||id.startsWith(`${e.id}:`)))this.scanWallStates.delete(id);
    for(const id of this.scanMechanisms?.keys()??[])if(!events.some(e=>e.bits.includes(id)))this.scanMechanisms.delete(id);
    for(const id of this.scanPausedHardware?.keys()??[])if(!events.some(e=>e.bits.includes(id)&&e.taskPausedAt===this.scanPausedHardware.get(id).at))this.scanPausedHardware.delete(id);
    for(const [id,handoff]of this.scanGeometryHandoffs??[]){const owner=events.find(e=>e.bits.includes(id));if(!owner||!(handoff.pausedAt!=null&&owner.taskPausedAt!=null)&&now>=handoff.at+SCAN_MECHANISM_HANDOFF)this.scanGeometryHandoffs.delete(id);}
    for(const key of this.depthSides.keys())if(!events.some(e=>key.startsWith(e.id+':')))this.depthSides.delete(key);
    for(const key of this.effectFrames.keys())if(!drawEvents.some(e=>e.id===key))this.effectFrames.delete(key);
    for(const key of this.projectionMotion?.keys()??[])if(!drawEvents.some(e=>e.id===key))this.projectionMotion.delete(key);
    retainBitWaveDirections(this.waveState,BIT_WAVE_STATIONS);
    const before=this.hadVisible;this.hadVisible=bits.size>0||retained.size>0;return !!(before||this.hadVisible);
  }
  updateMedicalEmitters(event,sample,context,target,source,resolution,preparedArtwork,attachedEmitters,retained,placements,depthSources,artworkTick){
    const artwork=preparedArtwork?medicalEmitterArtwork(preparedArtwork.values(),attachedEmitters):null;
    const prefix=`${event.id}:emitter:`,ids=artwork?[...artwork.keys()]:[...this.medicalEmitters.keys()].filter(key=>key.startsWith(prefix)).map(key=>key.slice(prefix.length));
    for(const id of ids){
      const position=sample.positions[id];if(!position)continue;
      const key=prefix+id,frame=artwork?.get(id);let record=this.medicalEmitters.get(key);
      if(frame&&(artworkTick||!record||record.resolution!==resolution)){
        const size=medicalEmitterSurfaceSize(resolution),viewport={x:resolution/2-size/2,y:resolution/2-size/2,width:size,height:size};
        if(!record){record=this.createEffect(key,resolution,viewport,{medicalEmitter:true});this.medicalEmitters.set(key,record);}
        if(record.resolution!==resolution||record.surface.width!==size)this.resizeEffect(record,resolution,viewport);
        const anchor=paintMedicalEmitter(record.ctx,frame,{resolution,surfaceSize:size});if(record.mesh.anchor.x!==anchor.x||record.mesh.anchor.y!==anchor.y)record.mesh.anchor.set(anchor.x,anchor.y);
        record.texture.baseTexture.update();record.artwork=frame;
        localPerformance.count('treatmentEmitterTextureUploads');localPerformance.count('treatmentEmitterUploadBytes',size*size*4);
      }
      if(!record)continue;retained.add(key);
      const diameter=context.size*2.8*(sample.effectScale??1),mesh=record.mesh;
      const width=diameter*record.surface.width/record.resolution;
      setSquareAttachmentTransform(mesh,position.x,position.y,sample.effectRotation??0,width);
      if(mesh.alpha!==source.alpha)mesh.alpha=source.alpha;if(mesh.visible!==true)mesh.visible=true;
      const keyId=BIT_KEY[id],placement=placements[keyId],depth=sample.depths?.[id],plane=placement?placement.front?'front':'rear':depth==null?record.artwork.plane:depth>=0?'front':'rear';
      placeBehind(mesh,depthSources.get(keyId)??target?.mesh??source,plane==='front'?-.14:.23);
    }
  }
  updateProjectedEmitters(event,sample,context,target,source,resolution,artwork,attachedEmitters,retained,depthSources){
    const unitWorld=context.size*(sample.effectScale??1)/100;
    for(const id of attachedEmitters){
      const position=sample.projectedSources[id];if(!position||!Number.isFinite(position.x)||!Number.isFinite(position.y))continue;
      const prefix=`${event.id}:projection:${id}:`,frame=artwork?.get(id);
      if(artwork&&!frame)continue;
      const beaconKey=`${prefix}source`,previousBeacon=this.projectedEmitters.get(beaconKey);
      if(frame?.beacon){
        const size=projectedBeaconSurfaceSize(resolution),viewport={x:resolution/2-size/2,y:resolution/2-size/2,width:size,height:size};
        let record=previousBeacon;if(!record){record=this.createEffect(beaconKey,resolution,viewport,{projectedEmitter:true});this.projectedEmitters.set(beaconKey,record);}
        if(record.resolution!==resolution||(record.surface?.width??record.viewport.width)!==size)this.resizeEffect(record,resolution,viewport);
        record.viewport=viewport;
        const anchor=paintProjectedBeacon(record.ctx,frame.beacon,{resolution,surfaceSize:size});if(record.mesh.anchor.x!==anchor.x||record.mesh.anchor.y!==anchor.y)record.mesh.anchor.set(anchor.x,anchor.y);record.texture.baseTexture.update();record.artwork=frame.beacon;
        localPerformance.count('projectionEmitterTextureUploads');localPerformance.count('projectionEmitterUploadBytes',size*size*4);
      }
      const beacon=this.projectedEmitters.get(beaconKey);
      if(beacon&&(!artwork||frame?.beacon)){
        retained.add(beaconKey);const width=unitWorld*280*(beacon.surface?.width??beacon.viewport.width)/beacon.resolution;
        setSquareAttachmentTransform(beacon.mesh,position.x,position.y,0,width);
        if(beacon.mesh.alpha!==source.alpha)beacon.mesh.alpha=source.alpha;if(beacon.mesh.visible!==true)beacon.mesh.visible=true;
        placeBehind(beacon.mesh,depthSources.get(BIT_KEY[id])??target?.mesh??source,position.plane==='rear'?.23:-.14);
      }
      const lanes=frame?frame.connectors:[...this.projectedEmitters.entries()].filter(([key])=>key.startsWith(`${prefix}connector:`)).map(([,record])=>record.artwork);
      for(let i=0;i<lanes.length;i++){
        const key=`${prefix}connector:${i}`,lane=lanes[i];let record=this.projectedEmitters.get(key);
        if(frame){
          const viewport=projectedConnectorViewport(lane,resolution);
          if(!record){record=this.createEffect(key,resolution,viewport,{projectedEmitter:true});this.projectedEmitters.set(key,record);}
          if(record.resolution!==resolution||(record.surface?.width??record.viewport.width)!==viewport.width||(record.surface?.height??record.viewport.height)!==viewport.height)this.resizeEffect(record,resolution,viewport);
          record.viewport=viewport;
          const anchor=paintProjectedConnector(record.ctx,lane,{resolution,viewport});if(record.mesh.anchor.x!==anchor.x||record.mesh.anchor.y!==anchor.y)record.mesh.anchor.set(anchor.x,anchor.y);record.texture.baseTexture.update();record.artwork=lane;record.density=viewport.density;
          localPerformance.count('projectionEmitterTextureUploads');localPerformance.count('projectionEmitterUploadBytes',viewport.width*viewport.height*4);
        }
        if(!record)continue;retained.add(key);
        const transform=projectedConnectorTransform(record.artwork,position,context.target,unitWorld),mesh=record.mesh;
        setMeshTransform(mesh,transform.x,transform.y,transform.angle,(record.surface?.width??record.viewport.width)/record.density*transform.longitudinal,(record.surface?.height??record.viewport.height)/record.density*transform.transverse);
        if(mesh.alpha!==source.alpha)mesh.alpha=source.alpha;if(mesh.visible!==true)mesh.visible=true;
        record.displayTransform=transform;
        placeBehind(mesh,depthSources.get(BIT_KEY[id])??target?.mesh??source,position.plane==='rear'?.23:-.14);
      }
    }
  }
  createEffect(id,resolution=448,viewport={x:0,y:0,width:resolution,height:resolution},{medicalEmitter=false,projectedEmitter=false}={}){
    const surface=document.createElement('canvas');surface.width=viewport.width;surface.height=viewport.height;const ctx=surface.getContext('2d');if(!ctx)throw new Error('A 2D canvas is needed for bit effects.');
    const attached=medicalEmitter||projectedEmitter,texture=PIXI.Texture.from(surface,attached?{mipmap:PIXI.MIPMAP_MODES?.ON??PIXI.MIPMAP_MODES?.OFF??0,scaleMode:PIXI.SCALE_MODES?.LINEAR??1}:{mipmap:PIXI.MIPMAP_MODES?.OFF??0}),Mesh=effectMeshClass();
    const mesh=new Mesh({name:`${ID}.${this.token.id}.action.${id}`,texture},foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader);
    mesh.eventMode='none';if(attached)mesh.roundPixels=false;canvas.primary.addChild(mesh);const record={surface,ctx,texture,mesh};this.resizeEffect(record,resolution,viewport);return record;
  }
  resizeEffect(record,resolution,viewport){
    if(record.surface.width!==viewport.width||record.surface.height!==viewport.height){record.surface.width=viewport.width;record.surface.height=viewport.height;record.texture.baseTexture.resource?.resize?.(viewport.width,viewport.height);record.texture.baseTexture.setRealSize?.(viewport.width,viewport.height);}
    record.resolution=resolution;record.viewport=viewport;
    record.mesh.anchor.set((resolution/2-viewport.x)/viewport.width,(resolution/2-viewport.y)/viewport.height);
  }
  async loadSprite(record,path,key){
    try{
      const texture=await PIXI.Assets.load(foundry.utils.getRoute(path));
      if(this.destroyed||this.sprites.get(key)!==record)return;
      if(!texture?.baseTexture?.valid||texture.width>8192||texture.height>8192)throw new Error('Custom bit effect texture is invalid or exceeds 8192 pixels.');
      const Mesh=effectMeshClass();
      record.mesh=new Mesh({name:`${ID}.${this.token.id}.sprite.${key}`,texture},foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader);
      record.aspect=texture.width/texture.height;record.mesh.anchor.set(.5);record.mesh.visible=false;record.mesh.eventMode='none';canvas.primary.addChild(record.mesh);
    }catch(error){record.error=true;console.warn('Yvaelle’s Toolbox: a custom bit effect asset could not load.',error);}
    record.loading=false;
  }
  releaseEffect(r){r.mesh.parent?.removeChild(r.mesh);r.mesh.destroy({children:true,texture:false,baseTexture:false});r.texture.destroy(true);r.surface.width=r.surface.height=1;if(r.scanRaster)r.scanRaster.surface.width=r.scanRaster.surface.height=1;}
  /** Hide retained meshes while the document is hidden. The next visible
   * update samples the current server clock, rather than replaying old frames. */
  suspend(){
    const changed=!!this.hadVisible;this.hadVisible=false;this.bits.hide();this.sendOut?.hide();
    for(const r of this.effects.values())r.mesh.visible=false;
    for(const r of this.medicalEmitters?.values()??[])r.mesh.visible=false;
    for(const r of this.projectedEmitters?.values()??[])r.mesh.visible=false;
    for(const r of this.sprites.values())if(r.mesh)r.mesh.visible=false;
    return changed;
  }
  handingBack(){const t=performance.now();return [...(this.handback?.values()??[])].some(h=>t-h.at<HANDBACK_MS)||(this.lastShown?.size??0)>0;}
  destroy(){this.destroyed=true;this.pictures.destroy();this.bits.destroy();this.sendOut?.destroy();this.sendOut=null;this.scanEncounters?.clear();this.scanOrientations?.clear();this.medicalDiagnosticFrames?.clear();this.scanMechanisms?.clear();this.scanPausedHardware?.clear();this.scanGeometryHandoffs?.clear();this.tokenScanMasks?.destroy();for(const r of this.effects.values())this.releaseEffect(r);this.effects.clear();for(const r of this.medicalEmitters?.values()??[])this.releaseEffect(r);this.medicalEmitters?.clear();for(const r of this.projectedEmitters?.values()??[])this.releaseEffect(r);this.projectedEmitters?.clear();this.effectFrames.clear();this.releaseWaves?.();this.releaseWaves=null;this.projectionMotion?.clear();for(const r of this.sprites?.values()??[]){r.mesh?.parent?.removeChild(r.mesh);r.mesh?.destroy({children:true,texture:false,baseTexture:false});}this.sprites?.clear();this.releaseAssets?.();}
}
