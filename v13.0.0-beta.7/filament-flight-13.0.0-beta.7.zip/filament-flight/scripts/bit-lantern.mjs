/** Dedicated projection posture for the existing physical instruments.
 * This pure layer owns no timers, input, document flags or renderer state.
 * Ground instruments gather into a count-specific projector cradle. The
 * activation capture chooses each circular lane once, independent of Flow,
 * depth sorting and cursor direction. With open wings the instruments keep
 * their live wing stabilization stations and supply the light in place. */
import {smoothIntercept} from './bit-formation-flow.mjs?v=13.0.0-beta.7';
import {LANTERN_TIMING} from './lantern-model.mjs?v=13.0.0-beta.7';
export const BIT_LANTERN_STATIONS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);
const finite=(n,fallback=0)=>Number.isFinite(Number(n))?Number(n):fallback;
const unit=n=>Math.max(0,Math.min(1,finite(n)));
const turn=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
const CHANNELS=Object.freeze(['encase','open','charge','guard','settle','scan','brace','align','rest','conduct']);
const TAU=Math.PI*2;
// Coordinates are [forward, lateral]. These are physical lens cradles,
// rather than four identical corner slots or copies of the ordinary orbit.
const CRADLES=Object.freeze([
  Object.freeze([[-30,-116]]),
  Object.freeze([[-16,-116],[-16,116]]),
  Object.freeze([[-128,0],[-12,-120],[-12,120]]),
  Object.freeze([[-84,-96],[-84,96],[54,-118],[54,118]])
]);

/** Reserved, remote and preview-gesture instruments retain their own work.
 * During a fade the resolved weight remains authoritative even after the
 * saved enabled flag becomes false, so switching off cannot cut the motion. */
export function bitLanternWeight(flight={},station=null){
  const lantern=flight.lantern;
  if(!lantern||flight.bitHardwareAll||flight.bitGesturePreview||flight.bitProjectedEffect)return 0;
  const weight=unit(lantern.weight??(lantern.active===true?1:0));
  if(!weight||!station)return weight;
  if(!BIT_LANTERN_STATIONS.includes(station))return 0;
  if(flight.bitActionAssignments?.support?.[station])return 0;
  if(Array.isArray(flight.bitHomeStations))return flight.bitHomeStations.includes(station)?weight:0;
  if(flight.bitActionAssignments?.hidden?.includes(station))return 0;
  const index=BIT_LANTERN_STATIONS.indexOf(station),visible=flight.bitCount?.values?.[index]??(index<(flight.gems?.count??4)?1:0);
  return visible>.00001?weight:0;
}

/** Mounting is resolved once by the light runtime and travels with the same
 * snapshot to the main and worker painters. Compact companions use it only
 * with the explicit ground wash choice; undeclared old geometry stays compatible. */
export function bitLanternWingFlight(flight={}){
  return flight.lantern?.mounting==='stabilizers'&&(flight.compactBits!==true||flight.lantern.groundStyle==='stabilizers');
}

/** Switching between an assembled cradle and live stabilizers uses the
 * actual displayed controller capture. The short exterior lanes keep pieces
 * away from the token and preserve their physical identities on interruption.
 * There is no heading smoothing or additional motion once wings are settled. */
export function applyBitLanternMountingPose(pose,flight={},station=pose?.station){
  if(!pose||!bitLanternWeight(flight,station))return pose;
  const transition=flight.lantern?.mountingTransition;
  if(flight.compactBits===true&&transition?.compact!==true||!transition||transition.progress>=1)return pose;
  const source=transition.poses?.find(p=>p.station===station);
  if(!source)return pose;
  const reference=transition.targets?.find(p=>p.station===station);
  const p=unit(transition.progress),orientation=smooth(p);
  if(!p)return {...pose,x:source.x,y:source.y,z:source.z,angle:source.angle,scale:finite(source.scale,finite(pose.scale,1))};
  const dx=finite(pose.x)-finite(source.x),dy=finite(pose.y)-finite(source.y);
  // Route selection and winding use the captured destination, never a moving
  // endpoint. A live pose crossing the near-route bound or angular seam must
  // not suddenly choose another passage halfway through the bridge.
  const nearby=reference&&Math.sign(source.x)===Math.sign(reference.x)&&Math.hypot(reference.x-source.x,reference.y-source.y)<=80;
  let x,y;
  if(nearby){x=finite(source.x)+dx*orientation;y=finite(source.y)+dy*orientation;}
  else{
    // Radial acquisition, then angular travel, then radial settlement. Lanes
    // have fixed identity widths, so aiming cannot reassign their ordering.
    const index=Math.max(0,BIT_LANTERN_STATIONS.indexOf(station));
    const capturedScale=Math.max(1,...(transition.poses??[]).map(p=>finite(p.scale,1)),...(transition.targets??[]).map(p=>finite(p.scale,1)));
    const housingSize=Math.max(.5,finite(transition.gemSize,finite(flight.gems?.size,1)))*capturedScale;
    const wingScale=Math.max(.1,finite(transition.wingScale,finite(flight.options?.wingScale,3.5)));
    const lane=Math.max(170,300*Math.SQRT2/wingScale+48*housingSize)+index*60*Math.max(1,housingSize);
    const first=Math.hypot(source.x,source.y-15),last=Math.hypot(pose.x,pose.y-15);
    const acquire=smooth(p/.175),rotate=smooth((p-.175)/.65),settle=smooth((p-.825)/.175);
    const radius=first+(lane-first)*acquire+(last-lane)*settle;
    const a=Math.atan2(source.y-15,source.x),b=Math.atan2(pose.y-15,pose.x),r=reference?Math.atan2(reference.y-15,reference.x):b;
    const delta=Math.atan2(Math.sin(r-a),Math.cos(r-a))+Math.atan2(Math.sin(b-r),Math.cos(b-r)),theta=a+delta*rotate;
    x=Math.cos(theta)*radius;y=15+Math.sin(theta)*radius;
  }
  const first=finite(source.angle),last=finite(pose.angle),ref=finite(reference?.angle,last);
  const angle=first+(Math.atan2(Math.sin(ref-first),Math.cos(ref-first))+Math.atan2(Math.sin(last-ref),Math.cos(last-ref)))*orientation;
  const out={...pose,x,y,z:finite(source.z)+(finite(pose.z)-finite(source.z))*orientation,angle,
    scale:finite(source.scale,finite(pose.scale,1))+(finite(pose.scale,1)-finite(source.scale,finite(pose.scale,1)))*orientation};
  const velocity=transition.velocities?.find(v=>v.station===station);
  if(velocity){
    // Continue the captured tangent briefly, then settle onto the same fixed
    // exterior route. The correction and its derivative reach zero together;
    // a reversed bridge no longer stops the physical piece for one frame.
    const seconds=finite(transition.duration,700)/1000,window=Math.min(.14,seconds*.25),elapsed=p*seconds;
    if(window>0&&elapsed<window){
      const correction=elapsed*(1-elapsed/window)**3;
      for(const key of ['x','y','z','angle','scale'])out[key]+=finite(velocity[key])*correction;
    }
  }
  return out;
}

/** Command-edge tangent capture from an existing mounting route. This pure
 * derivative samples at most four controllers twice; it builds no geometry,
 * texture, native source or frame history. Repeated reversals include the
 * previous captured tangent rather than dropping it. */
export function bitLanternMountingVelocities(flight={}){
  const transition=flight.lantern?.mountingTransition;
  if(!transition||transition.progress>=1||!(transition.duration>0))return [];
  const p=unit(transition.progress),a=Math.max(0,p-.0001),b=Math.min(1,p+.0001),seconds=(b-a)*transition.duration/1000;
  if(!(seconds>0))return [];
  const at=progress=>({...flight,lantern:{...flight.lantern,mountingTransition:{...transition,progress}}});
  const first=at(a),last=at(b);
  return (transition.targets??[]).map(target=>{
    const from=applyBitLanternMountingPose(target,first,target.station),to=applyBitLanternMountingPose(target,last,target.station);
    return {station:target.station,x:(to.x-from.x)/seconds,y:(to.y-from.y)/seconds,z:(to.z-from.z)/seconds,
      angle:Math.atan2(Math.sin(to.angle-from.angle),Math.cos(to.angle-from.angle))/seconds,scale:(finite(to.scale,1)-finite(from.scale,1))/seconds};
  });
}

export function bitLanternDirection(flight={}){
  const angle=finite(flight.lantern?.localAngle,finite(flight.lantern?.angle))*Math.PI/180;
  return [Math.cos(angle),Math.sin(angle)];
}

/** Projection corrections use elapsed wall time, independent of the ordinary
 * formation speed or the wing's flight-relative animation clock. */
export function bitLanternElapsed(flight={},time=0){
  if(flight.gems?.animated===false||flight.effective?.reducedMotion||finite(flight.gems?.strength,1)<=0)return 0;
  return Math.max(0,Number.isFinite(flight.lantern?.clock)&&Number.isFinite(flight.lantern?.poseNow)?
    flight.lantern.clock-flight.lantern.poseNow/1000:
    (finite(time)-bitLanternPoseClock(flight,0,{relative:flight.compactBits!==true}))/Math.max(.0001,finite(flight.gems?.speed,1)));
}

/** The brighter supply cycle belongs to Animated light appearance. Older
 * standalone geometry inputs retain their existing projection artwork, and
 * comfort or machinery opt-outs keep the captured mechanisms unchanged. */
export function bitLanternPowering(flight={},station,time=0){
  const appearance=flight.lightAppearance??flight.light?.appearance??flight.requested?.lightAppearance;
  const strength=unit(finite(flight.effective?.intensity,1));
  if(appearance!=='animated'||!bitLanternWeight(flight,station)||flight.gems?.animated===false||
    flight.effective?.reducedMotion===true||finite(flight.gems?.strength,1)<=0||!strength)return null;
  const index=Math.max(0,BIT_LANTERN_STATIONS.indexOf(station)),phase=bitLanternElapsed(flight,time)*.55+index*.72;
  return {phase,load:.5+.5*Math.sin(phase),strength};
}

/** The rig's token centre is fifteen units below its shoulder-root origin.
 * Every home instrument supplies the same short forward focusing point. */
export function bitLanternTarget(flight={}){
  const [dx,dy]=bitLanternDirection(flight);return [dx*200,15+dy*200,0];
}

/** The runtime captures this unscaled clock once on entry. Formation and
 * support samplers freeze at that phase while their explicit handoff progress
 * continues normally. No sampled renderer frame or mutable global is needed. */
export function bitLanternPoseClock(flight={},fallback=0,{relative=false}={}){
  const clock=relative&&Number.isFinite(flight?.lantern?.poseNow)?
    (flight.lantern.poseNow-finite(flight.started))/1000:
    finite(flight?.lantern?.poseClock,fallback)-(relative?finite(flight?.started)/1000:0);
  return clock*finite(flight?.gems?.speed,1);
}
export function bitLanternPoseNow(flight={},fallback=0){return finite(flight?.lantern?.poseNow,fallback);}

/** Projection uses the nominal saved choreography phase as its anchor.
 * Reduced motion freezes the new cycle at that shared capture. Explicit
 * animation opt-outs remain binding. */
export function bitLanternHeldFlight(flight={}){
  const animated=flight.lantern?.poseAnimated??flight.gems?.animated;
  return {...flight,gems:{...flight.gems,animated,
    stationMotion:flight.lantern?.poseStationMotion??flight.gems?.stationMotion},
    effective:{...flight.effective,reducedMotion:false}};
}

/** Action captures and return destinations use the same source transform as
 * the home renderer. Saved headings remain world headings; only this frame
 * snapshot receives the local conversion. Disabled callers keep identity. */
export function bitLanternInFrame(flight,frameAngle=0){
  if(!(flight?.lantern?.weight>0))return flight;
  const degrees=finite(frameAngle)*180/Math.PI;
  return {...flight,lantern:{...flight.lantern,localAngle:finite(flight.lantern.angle)-degrees,
    localFormationAngle:finite(flight.lantern.formationAngle,finite(flight.lantern.angle))-degrees,
    localFormationStartAngle:finite(flight.lantern.formationStartAngle,finite(flight.lantern.formationAngle,finite(flight.lantern.angle)))-degrees}};
}

/** The bits converge on the token-centred projection rather than another
 * instrument. The native light itself is owned by the token. */
export function bitLanternFocus(flight,station,position){
  const weight=bitLanternWeight(flight,station);if(!weight)return null;
  if(bitLanternWingFlight(flight))return null;
  return {kind:'lantern',key:'cooperative-lantern',weight,target:bitLanternTarget(flight)};
}

const anchorPoint=p=>({station:p.station,x:finite(p.x,finite(p.points?.[0]?.[0])),
  y:finite(p.y,finite(p.points?.[0]?.[1])),z:finite(p.z,finite(p.points?.[0]?.[2])),
  angle:finite(p.angle,finite(p.hardware?.angle))});

const smooth=n=>{const p=unit(n);return p*p*(3-2*p);};
function compactDeployment(flight,station){
  const index=station.endsWith('Lower')?1:0,side=station.startsWith('left')?-1:1,stationIndex=BIT_LANTERN_STATIONS.indexOf(station);
  const growth=finite(flight.formation?.growth,1),fold=finite(flight.formation?.fold),formed=smooth((growth-(index?.07:0))/(index?.93:1));
  const count=flight.bitCount?.values?.[stationIndex]??(stationIndex<(flight.gems?.count??4)?1:0),delay=flight.bitTransition?.active?stationIndex*.045:0;
  const deployed=unit((unit(flight.bitDeployment??1)-delay)/(1-delay))*unit(count);
  const amount=formed*(1-smooth(fold))*unit(flight.stabilizerDeployment??1)*deployed,launch=Math.sin(Math.PI*amount);
  return {amount,root:[side*27,-23+index*18,-28/24],peel:[side*launch*(10+index*3),(index?1:-1)*launch*12,0]};
}
/** Compact station coordinates precede the shared shoulder-root deployment
 * transform. Saved physical captures follow it. Sampling and inversion here
 * let both geometry routes apply that transform exactly once. */
export function bitLanternControllerPose(pose,flight={},station=pose.station){
  if(flight.compactBits!==true)return pose;
  const {amount,root,peel}=compactDeployment(flight,station);
  return {...pose,x:Math.max(-257,Math.min(257,root[0]*(1-amount)+finite(pose.x)*amount+peel[0])),
    y:Math.max(-231,Math.min(265,root[1]*(1-amount)+finite(pose.y)*amount+peel[1])),z:root[2]*(1-amount)+finite(pose.z)*amount};
}

/** Saved captures contain physical rig depth; compact station depth uses a
 * twenty-fourth of that unit. Size remains controlled by the current artwork
 * setting, so the capture freezes location and heading without shrinking it. */
export function bitLanternAnchor(flight={},station,fallback={},transition=false){
  const lamp=flight.lantern,actual=lamp?.transitionCapture?.find(p=>p.station===station),original=lamp?.formationCapture?.find(p=>p.station===station);
  // Stored pieces have no displayed transition capture. Their virtual saved
  // formation remains a fixed pre-launch destination until they emerge; the
  // ordinary shoulder deployment is applied after this virtual route.
  if(lamp?.enabled===true&&Array.isArray(lamp.transitionCapture)&&!actual&&original){
    return flight.compactBits===true?{...fallback,x:original.x,y:original.y,z:original.z/24,angle:original.angle}:fallback;
  }
  const held=transition?actual:original;
  return held?{...fallback,x:held.x,y:held.y,z:flight.compactBits===true?held.z/24:held.z,
    angle:held.angle}:bitLanternControllerPose(fallback,flight,station);
}

/** The circular order is captured once from ordinary formations. Only cyclic
 * mappings are considered: entry arcs cannot weave through each other when
 * Flow's saved station ordering differs from the default four identities.
 * This mapping depends on the saved activation heading, never the live aim. */
export function bitLanternRoutes(flight={},anchors=[],transition=false){
  const supplied=anchors.filter(p=>bitLanternWeight(flight,p.station)>0)
    .map(p=>anchorPoint(bitLanternAnchor(flight,p.station,p,transition)));
  if(!supplied.length)return new Map();
  const head=finite(flight.lantern?.localFormationStartAngle,
    finite(flight.lantern?.formationStartAngle,finite(flight.lantern?.localAngle,finite(flight.lantern?.angle))))*Math.PI/180;
  const source=supplied.map(p=>({...p,theta:Math.atan2(p.y-15,p.x),radius:Math.hypot(p.x,p.y-15)}))
    .sort((a,b)=>a.theta-b.theta||BIT_LANTERN_STATIONS.indexOf(a.station)-BIT_LANTERN_STATIONS.indexOf(b.station));
  const slots=CRADLES[Math.min(3,source.length-1)].map(([forward,lateral])=>({forward,lateral,
    theta:Math.atan2(lateral,forward)+head,radius:Math.hypot(forward,lateral)})).sort((a,b)=>a.theta-b.theta);
  const savedOrder=flight.lantern?.formationOrder;
  if(Array.isArray(savedOrder)&&source.every(p=>savedOrder.includes(p.station))){
    // Saved IDs follow the activation's world angular order. A local render
    // frame may cross that order's seam, so unwrap it rather than sorting it
    // again. The corresponding world-angle slot order never depends on a
    // subsequently selected ordinary formation.
    const worldHead=finite(flight.lantern.formationStartAngle,head*180/Math.PI)*Math.PI/180,frame=worldHead-head;
    const ordered=source.sort((a,b)=>savedOrder.indexOf(a.station)-savedOrder.indexOf(b.station));
    const target=slots.map(p=>({...p,theta:Math.atan2(Math.sin(p.theta+frame),Math.cos(p.theta+frame))-frame})).sort((a,b)=>a.theta-b.theta);
    for(let i=0;i<ordered.length;i++){
      ordered[i].theta=Math.atan2(Math.sin(ordered[i].theta+frame),Math.cos(ordered[i].theta+frame))-frame;
      if(i)while(ordered[i].theta<ordered[i-1].theta)ordered[i].theta+=TAU;
    }
    const turns=Math.round(ordered.reduce((sum,p,i)=>sum+target[i].theta-p.theta,0)/ordered.length/TAU);
    for(const p of target)p.theta-=turns*TAU;
    return new Map(ordered.map((p,i)=>[p.station,{...p,target:target[i],startAngle:head,index:BIT_LANTERN_STATIONS.indexOf(p.station)}]));
  }
  let chosen=null,cost=Infinity;
  for(let offset=0;offset<source.length;offset++){
    const target=source.map((_,i)=>({...slots[(i+offset)%source.length],theta:slots[(i+offset)%source.length].theta+(i+offset>=source.length?TAU:0)}));
    const mean=source.reduce((sum,p,i)=>sum+target[i].theta-p.theta,0)/source.length;
    const turns=Math.round(mean/TAU);for(const p of target)p.theta-=turns*TAU;
    const score=source.reduce((sum,p,i)=>sum+(target[i].theta-p.theta)**2,0);
    if(score<cost-1e-9){cost=score;chosen=target;}
  }
  return new Map(source.map((p,i)=>[p.station,{...p,target:chosen[i],startAngle:head,index:BIT_LANTERN_STATIONS.indexOf(p.station)}]));
}

/** Gather and release follow the same reversible polar path. The radius
 * never passes through the token. The live ordinary pose contributes only
 * as the cradle releases, so switching off joins the current formation with
 * no stale held-pose jump. Full-on has its own deliberate supply cycle. */
export function applyBitLanternPose(pose,flight={},time=0,{station=pose?.station,anchor=pose,target=null,routes=null,anchors=null,returnPose=null,returnPath=null,deferMounting=false}={}){
  const weight=bitLanternWeight(flight,station);if(!pose||!weight)return pose;
  if(bitLanternWingFlight(flight))return deferMounting||flight.compactBits===true?pose:applyBitLanternMountingPose(pose,flight,station);
  const timed=Number.isFinite(flight.lantern?.changed)&&Number.isFinite(flight.lantern?.clock)&&
    flight.lantern?.transitionCapture?.some(p=>p.station===station);
  const anchorInput=anchor;
  anchor=bitLanternAnchor(flight,station,anchor,timed);
  const ordinary=bitLanternControllerPose(pose,flight,station);
  const [dx,dy]=bitLanternDirection(flight);
  routes??=bitLanternRoutes(flight,anchors??[anchorInput],timed);
  const route=routes.get(station);if(!route)return pose;
  const x=finite(anchor.x,finite(ordinary.x)),y=finite(anchor.y,finite(ordinary.y));
  const index=Math.max(0,BIT_LANTERN_STATIONS.indexOf(station)),elapsed=bitLanternElapsed(flight,time);
  const phase=elapsed*.55,offset=index*.72,live=elapsed>0&&flight.gems?.stationMotion!==false;
  const axial=live?8*(Math.sin(phase+offset)-Math.sin(offset)):0;
  const radial=live?5*(Math.sin(phase*.83+offset)-Math.sin(offset)):0;
  const bank=live?.10*(Math.sin(phase*.72+offset)-Math.sin(offset)):0;
  const heading=finite(flight.lantern?.localFormationAngle,
    finite(flight.lantern?.formationAngle,finite(flight.lantern?.localAngle,finite(flight.lantern?.angle))))*Math.PI/180;
  const forward=route.target.forward+axial,lateral=route.target.lateral+Math.sign(route.target.lateral||1)*radial;
  const opticalTurn=Math.atan2(lateral,forward)-Math.atan2(route.target.lateral,route.target.forward);
  let goalTheta=route.target.theta+heading-route.startAngle+Math.atan2(Math.sin(opticalTurn),Math.cos(opticalTurn));
  let goalRadius=Math.hypot(forward,lateral);
  const releasing=flight.lantern?.shuttingDown===true||flight.lantern?.enabled===false;
  const rawProgress=timed?unit((flight.lantern.clock*1000-flight.lantern.changed)/(releasing?LANTERN_TIMING.return:LANTERN_TIMING.gather)):weight;
  const progress=timed?rawProgress*rawProgress*(3-2*rawProgress):weight;
  if(timed&&releasing&&returnPose){
    returnPose=bitLanternControllerPose(returnPose,flight,station);
    const next=Math.atan2(returnPose.y-15,returnPose.x),delta=Math.atan2(Math.sin(next-route.theta),Math.cos(next-route.theta));
    goalTheta=route.theta+delta;goalRadius=Math.hypot(returnPose.x,returnPose.y-15);
  }
  const theta=route.theta+(goalTheta-route.theta)*progress;
  // A shallow outward clearance arc reads as a deliberate gather even if an
  // ordinary solo pose happens to begin close to its final projector socket.
  const radius=route.radius+(goalRadius-route.radius)*progress+24*Math.sin(Math.PI*progress);
  const targetX=Math.cos(theta)*radius,targetY=15+Math.sin(theta)*radius;
  // The spindle's forward aperture lies along its local -Y axis. Each
  // available instrument gently banks into the common token projection.
  const liveGain=!timed&&releasing?1-weight:0;
  const out={...pose,x:targetX+(finite(ordinary.x)-x)*liveGain,
    y:targetY+(finite(ordinary.y)-y)*liveGain,
    z:timed?finite(anchor.z)+(finite(releasing&&returnPose?returnPose.z:anchor.z)-finite(anchor.z))*progress:
      finite(ordinary.z)+(finite(anchor.z,finite(ordinary.z))-finite(ordinary.z))*weight,
    scale:finite(pose.scale,1)+(finite(anchor.scale,finite(pose.scale,1))-finite(pose.scale,1))*weight,
    brightness:finite(pose.brightness,1)+(1.015-finite(pose.brightness,1))*weight,lanternWeight:weight};
  target??=bitLanternTarget(flight);
  const direction=[finite(target[0])-out.x,finite(target[1])-out.y];
  const length=Math.hypot(...direction),[fx,fy]=length>.00001?direction.map(v=>v/length):[dx,dy];
  const startAxis=route.startAngle+Math.PI/2,anchorAngle=finite(anchor.angle,finite(pose.angle));
  const sourceAngle=anchorAngle+TAU*Math.round((startAxis-anchorAngle)/TAU);
  const rawAngle=Math.atan2(fy,fx)+Math.PI/2+bank;
  const projectorAngle=rawAngle+TAU*Math.round((heading+Math.PI/2-rawAngle)/TAU);
  // Keep one unwrapped branch over the lifecycle. Picking a fresh shortest
  // branch while weight is fractional can jump half a revolution on release.
  const ordinaryTurn=Math.atan2(Math.sin(finite(pose.angle)-anchorAngle),Math.cos(finite(pose.angle)-anchorAngle));
  const returnAngle=returnPose?sourceAngle+Math.atan2(Math.sin(returnPose.angle-sourceAngle),Math.cos(returnPose.angle-sourceAngle)):projectorAngle;
  out.angle=sourceAngle+((timed&&releasing?returnAngle:projectorAngle)-sourceAngle)*progress+ordinaryTurn*liveGain;
  if(timed&&releasing&&returnPath){out.x=returnPath.x;out.y=returnPath.y;out.z=returnPath.z;out.angle=returnPath.angle;}
  if(pose.intent)out.intent={...pose.intent,amount:finite(pose.intent.amount)*(1-weight)};
  if(pose.tool)out.tool={...pose.tool,amount:finite(pose.tool.amount)*(1-weight)};
  if(pose.activity)out.activity={...pose.activity,amount:finite(pose.activity.amount)*(1-weight)};
  if(pose.expression)out.expression={...pose.expression,energy:1+(finite(pose.expression.energy,1)-1)*(1-weight)};
  out.focus=target?{kind:'lantern',key:'cooperative-lantern',weight,target:[...target]}:bitLanternFocus(flight,station,out);
  if(flight.compactBits===true){
    const {amount,root,peel}=compactDeployment(flight,station);
    const virtualLaunch=flight.lantern?.enabled===true&&Array.isArray(flight.lantern?.transitionCapture)&&
      !flight.lantern.transitionCapture.some(p=>p.station===station)&&flight.lantern?.formationCapture?.some(p=>p.station===station);
    if(virtualLaunch){
      // A newly deployed instrument has no physical capture to invert. Keep
      // its immutable virtual path in the ordinary pre-launch coordinates,
      // so the renderer carries it out from the real shoulder root once.
    }else if(amount>.00001){
      out.x=(out.x-root[0]*(1-amount)-peel[0])/amount;
      out.y=(out.y-root[1]*(1-amount)-peel[1])/amount;
      out.z=(out.z-root[2]*(1-amount))/amount;
    }else{out.x=pose.x;out.y=pose.y;out.z=pose.z;}
  }
  return deferMounting||flight.compactBits===true?out:applyBitLanternMountingPose(out,flight,station);
}

/** Home instruments cooperate around one token-centred forward focus.
 * Slot selection never depends on current depth or bearing. */
export function applyBitLanternGroup(poses,flight={},time=0,{anchors=poses,returnPoses=null}={}){
  if(bitLanternWingFlight(flight))return poses.map(p=>applyBitLanternPose(p,flight,time));
  const target=bitLanternTarget(flight,anchors),timed=Number.isFinite(flight.lantern?.changed)&&Array.isArray(flight.lantern?.transitionCapture),routes=bitLanternRoutes(flight,anchors,timed),returns=returnPoses?bitLanternReturnPaths(flight,anchors,returnPoses):null;
  return poses.map(p=>applyBitLanternPose(p,flight,time,{anchor:anchors.find(q=>q.station===p.station)??p,
    target,routes,returnPose:returnPoses?.find(q=>q.station===p.station),returnPath:returns?.get(p.station)}));
}

/** Ordinary formations can reorder their circular identities while a light
 * is held. Distinct concentric return lanes allow those real physical pieces
 * to overtake without touching: acquire a lane, turn, then settle radially.
 * Destination radius orders the lanes, preserving order as they close. All
 * three stages use smooth endpoints and the actual shared shutdown clock. */
export function bitLanternReturnPaths(flight={},anchors=[],destinations=[]){
  if(bitLanternReturnNow(flight)===null||!Array.isArray(anchors)||!Array.isArray(destinations))return null;
  const progress=unit((flight.lantern.clock*1000-flight.lantern.changed)/LANTERN_TIMING.return),targets=new Map(destinations.map(p=>[p.station,p]));
  const paths=anchors.filter(p=>targets.has(p.station)&&bitLanternWeight(flight,p.station)>0&&flight.lantern.transitionCapture.some(q=>q.station===p.station))
    .map(p=>({station:p.station,source:bitLanternAnchor(flight,p.station,p,true),target:bitLanternControllerPose(targets.get(p.station),flight,p.station)}));
  paths.sort((a,b)=>Math.hypot(a.target.x,a.target.y-15)-Math.hypot(b.target.x,b.target.y-15)||BIT_LANTERN_STATIONS.indexOf(a.station)-BIT_LANTERN_STATIONS.indexOf(b.station));
  const acquire=smooth(progress/.175),rotate=smooth((progress-.175)/.65),settle=smooth((progress-.825)/.175),orientation=smooth(progress);
  return new Map(paths.map(({station,source,target},index)=>{
    const first=Math.hypot(source.x,source.y-15),last=Math.hypot(target.x,target.y-15),lane=110+index*28;
    const radius=first+(lane-first)*acquire+(last-lane)*settle;
    const angle=Math.atan2(source.y-15,source.x),bearing=Math.atan2(target.y-15,target.x),delta=Math.atan2(Math.sin(bearing-angle),Math.cos(bearing-angle)),theta=angle+delta*rotate;
    return [station,{x:Math.cos(theta)*radius,y:15+Math.sin(theta)*radius,z:finite(source.z)+(finite(target.z)-finite(source.z))*orientation,
      angle:finite(source.angle)+Math.atan2(Math.sin(finite(target.angle)-finite(source.angle)),Math.cos(finite(target.angle)-finite(source.angle)))*orientation}];
  }));
}

export function bitLanternReturnNow(flight={}){
  return flight?.lantern?.enabled===false&&Number.isFinite(flight.lantern?.changed)&&Array.isArray(flight.lantern?.transitionCapture)?
    flight.lantern.changed+LANTERN_TIMING.return:null;
}

/** Allocation edits keep the activation's circular lane order too. Their
 * captured start and moving destination meet in radius/heading space, so a
 * four-to-one recall cannot send the remaining lens straight through Ellie.
 * End derivatives come from the same ordinary captured-velocity contract. */
export function bitLanternHandoffGroup(from,to,flight={},progress=1,{duration=.85,velocities=[],targetVelocities=[]}={}){
  const p=unit(progress),targets=new Map(to.map(q=>[q.station,q]));
  if(!bitLanternWeight(flight))return new Map();
  const frame=(finite(flight.lantern?.formationStartAngle)-finite(flight.lantern?.localFormationStartAngle,finite(flight.lantern?.formationStartAngle)))*Math.PI/180;
  const angle=q=>Math.atan2(Math.sin(Math.atan2(q.y-15,q.x)+frame),Math.cos(Math.atan2(q.y-15,q.x)+frame))-frame;
  const order=flight.lantern?.formationOrder;
  const points=from.filter(q=>targets.has(q.station)&&bitLanternWeight(flight,q.station)>0)
    .map(q=>({from:q,to:targets.get(q.station),a:angle(q),b:angle(targets.get(q.station))}))
    .sort((a,b)=>Array.isArray(order)?order.indexOf(a.from.station)-order.indexOf(b.from.station):a.a-b.a);
  for(let i=1;i<points.length;i++){
    while(points[i].a<points[i-1].a)points[i].a+=TAU;
    while(points[i].b<points[i-1].b)points[i].b+=TAU;
  }
  const shift=points.length?Math.round(points.reduce((sum,q)=>sum+q.b-q.a,0)/points.length/TAU)*TAU:0;
  return new Map(points.map(q=>{
    const a=q.from,b=q.to;if(p===0)return [a.station,{x:a.x,y:a.y}];if(p===1)return [a.station,{x:b.x,y:b.y}];
    const ra=Math.hypot(a.x,a.y-15),rb=Math.hypot(b.x,b.y-15),v=velocities.find(v=>v.station===a.station)??{},w=targetVelocities.find(v=>v.station===a.station)??{};
    const components=(point,r,velocity)=>r>.00001?{
      radial:(point.x*finite(velocity.x)+(point.y-15)*finite(velocity.y))/r,
      angular:(point.x*finite(velocity.y)-(point.y-15)*finite(velocity.x))/(r*r)}:{radial:0,angular:0};
    const va=components(a,ra,v),vb=components(b,rb,w);
    const radius=Math.max(Math.min(ra,rb,100),smoothIntercept(ra,rb,p,duration,va.radial,vb.radial))+16*Math.sin(Math.PI*p)**2;
    const theta=smoothIntercept(q.a,q.b-shift,p,duration,va.angular,vb.angular);
    return [a.station,{x:Math.cos(theta)*radius,y:15+Math.sin(theta)*radius}];
  }));
}

/** Bitmap artwork makes bounded corrections around its captured pictures.
 * This is a dedicated slow mechanism cycle, never the ordinary idle loop.
 * Components still crossfade as images on entrance and release. */
export function bitLanternAnimation(animation,held,flight={},station,time=0){
  const weight=bitLanternWeight(flight,station);if(!animation||!held||!weight)return animation;
  // Wing machinery and support animation continue at their existing live
  // phase. The hardware power overlay supplies the alternative light state.
  if(bitLanternWingFlight(flight))return animation;
  const mix=(first,last)=>[...first.map(p=>({...p,weight:(p.weight??1)*(1-weight)})),
    ...last.map(p=>({...p,weight:(p.weight??1)*weight}))].filter(p=>p.weight>0);
  const elapsed=bitLanternElapsed(flight,time),phase=elapsed*.55,index=Math.max(0,BIT_LANTERN_STATIONS.indexOf(station));
  const shift=(frame,amount)=>{
    const current=frame.a+frame.mix+amount,wrapped=(current%16+16)%16,a=Math.floor(wrapped);
    return {...frame,a,b:(a+1)%16,mix:wrapped-a};
  };
  const delta=Math.sin(phase+index*.72)-Math.sin(index*.72),target={
    layers:held.layers.map(l=>shift(l,delta*1.7)),core:shift(held.core,delta*2.1),sheen:shift(held.sheen,delta*1.3)};
  // A working projector replaces idle motion, never an actor's damaged,
  // suppressed or recovering artwork. Those authored tracks retain their
  // ordinary live clock and current crossfade weights while the healthy
  // tracks keep the slower dedicated supply cycle.
  const reactions=new Set(['damaged','unstable','glitching','overdrive','suppressed','collapsed','recovery']);
  target.layers=target.layers.map(layer=>reactions.has(layer.clip)?
    animation.layers.find(live=>live.clip===layer.clip)??layer:layer);
  return {...animation,layers:mix(animation.layers,target.layers),
    coreLayers:mix([animation.core],[target.core]),sheenLayers:mix([animation.sheen],[target.sheen]),
    animated:elapsed>0||animation.animated&&weight<1,dominant:weight===1?'projection':animation.dominant};
}

/** Blend resolved shape channels, including a manually selected mechanism.
 * Multiplying a long-running internal phase by a new activity strength would
 * rephase the solid housing; only bounded shape channels and power change. */
export function applyBitLanternHardware(hardware,flight={},station,time=0,{position=null,response=null}={}){
  const weight=bitLanternWeight(flight,station);if(!hardware||!weight)return hardware;
  const index=Math.max(0,BIT_LANTERN_STATIONS.indexOf(station)),elapsed=bitLanternElapsed(flight,time);
  const phase=elapsed*.55+index*.72,breathe=.5+.5*Math.sin(phase),correction=Math.sin(phase)-Math.sin(index*.72);
  const powering=bitLanternPowering(flight,station,time),gain=powering?.strength??0;
  const supply=(before,after)=>before+(after-before)*gain;
  const resonance=hardware.resonance??{},before=resonance.coreState??{};
  const target={encase:0,open:supply(.38+.36*breathe,.24+.66*breathe),charge:supply(.2+.10*breathe,.26+.34*breathe),guard:0,settle:0,scan:0,
    brace:supply(.15,.24+.16*(1-breathe)),align:supply(.72,.78),rest:0,conduct:gain*(.28+.34*breathe)};
  const channels=Object.fromEntries(CHANNELS.map(key=>[key,finite(before[key])+(target[key]-finite(before[key]))*weight]));
  const amount=unit(finite(before.amount)+(1-finite(before.amount))*weight);
  const coreState={...before,...channels,id:before.id&&before.id!=='idle'?before.id:'open',amount,coreChannels:Object.fromEntries(CHANNELS.map(key=>[key,amount?channels[key]/amount:0])),lanternWeight:weight};
  const projection={roll:.1*correction,coreAngle:supply(.28*correction,.42*correction),aperture:supply(.55+.24*breathe,.42+.43*breathe),power:supply(.84+.085*breathe,.78+.20*breathe),
    resonance:{...resonance,coreState:{...coreState,...target,amount:1},phase,amount:0,mechanical:0,
      yaw:supply(.38*correction,.46*correction),tilt:supply(-.18+.10*correction,-.18+.13*correction),precession:.14*correction,orbit:.27+.56*correction,focus:1,motion:0,guard:0,drive:0,
      response:1,charge:1,healing:0,damage:0,instability:0,glitch:0,suppression:0,collapse:0,impact:0,pulse:0}};
  // Scene-light posture and actor health are simultaneous layers. Retain the
  // already resolved response, including all its opt-outs, without restarting
  // the supply cycle or adding the ordinary healthy idle counter-orbits.
  const reactionKeys=['healing','damage','instability','glitch','suppression','collapse','impact','pulse','drive'];
  if(reactionKeys.some(key=>finite(resonance[key])>0)){
    for(const key of reactionKeys)projection.resonance[key]=finite(resonance[key]);
    projection.resonance.mechanical=finite(resonance.mechanical);
    projection.resonance.conditionPhase=finite(resonance.phase);
    projection.resonance.charge*=finite(response?.charge,1);
  }
  projection.power=unit(projection.power*Math.max(0,finite(response?.power,1)));
  projection.aperture=unit(projection.aperture*unit(finite(response?.aperture,1)));
  projection.repair=finite(hardware.repair);projection.desync=finite(hardware.desync);
  const focusTarget=hardware.focus?.key==='cooperative-lantern'?hardware.focus.target:null;
  const toward=focusTarget&&position?[focusTarget[0]-position[0],focusTarget[1]-position[1]]:bitLanternDirection(flight),length=Math.hypot(...toward);
  const direction=length>.00001?toward.map(v=>v/length):bitLanternDirection(flight);
  return {...hardware,power:finite(hardware.power,1)+(projection.power-finite(hardware.power,1))*weight,
    roll:finite(hardware.roll)+(projection.roll-finite(hardware.roll))*weight,coreAngle:finite(hardware.coreAngle)+(projection.coreAngle-finite(hardware.coreAngle))*weight,
    aperture:finite(hardware.aperture,1)+(projection.aperture-finite(hardware.aperture,1))*weight,
    repair:finite(hardware.repair),desync:finite(hardware.desync),
    resonance:{...resonance,coreState},lantern:{weight,direction,contributor:true,origin:[0,0],originKind:bitLanternWingFlight(flight)?'bit':'token',phase,...(powering?{powering}:{}),
      projection,original:hardware}};
}
