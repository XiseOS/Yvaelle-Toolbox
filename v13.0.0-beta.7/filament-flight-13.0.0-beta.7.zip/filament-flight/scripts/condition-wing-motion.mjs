/** Optional PF2e responses articulate the existing filament lattice. They do
 * not change an actor, pose preference, light, movement rule, or bit assignment.
 * Each sample prepares its waves once; the vertex loop uses bounded arithmetic.
 */
import {cubic} from './wing-art.mjs?v=13.0.0-beta.7';

const unit=x=>Math.min(1,Math.max(0,Number(x)||0));
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const TAU=Math.PI*2;
export const NEW_ACTOR_WING_RESPONSES=Object.freeze({
  paralyzed:{label:'Suspended lattice',description:'The wingbeat settles into a held lattice; small suspension links keep its filaments visibly intact.'},
  petrified:{label:'Rigid facets',description:'The lattice gathers into angular, rigid facets with still crystalline edge seams.'},
  restrained:{label:'Snared lattice',description:'Crossed filament ties draw the outer web inward while its inner channels remain alive.'},
  immobilized:{label:'Bound roots',description:'Short binding loops cinch the shoulderward ribs; their tips flex within the held span.'},
  grabbed:{label:'Tethered tips',description:'Taut tethers pull the outer ribs inward, with a slight elastic response in the remaining weave.'},
  blinded:{label:'Veiled lattice',description:'A woven veil closes the upper web and inward searching currents travel beneath it.'},
  dazzled:{label:'Diffused glints',description:'Soft, spreading glints collect along the upper ribs without flashing the whole wing.'},
  deafened:{label:'Silent resonance',description:'Paired resonance brackets hold close to the ribs while their connecting currents lose their pulse.'},
  clumsy:{label:'Misaligned weave',description:'Alternating rib tips drift out of alignment and small displaced seam loops gently correct them.'},
  enfeebled:{label:'Yielding spars',description:'The lower ribs yield under their own light; shallow supporting catenaries carry their slack.'},
  drained:{label:'Ebbing channels',description:'Long, thinning return channels draw light shoulderward through a softly gathered lattice.'},
  sickened:{label:'Queasy currents',description:'A slow, uneven roll moves through the web and paired currents curl back upon themselves.'},
  stupefied:{label:'Failing relays',description:'Separated relay stitches light in an unhurried, uneven sequence within the intact wing.'},
  confused:{label:'Wandering circuits',description:'Overlapping return circuits wander through the inner web as the two wings sway out of phase.'},
  fascinated:{label:'Captive focus',description:'The upper ribs draw toward a narrow focus and their currents linger along converging filaments.'},
  encumbered:{label:'Laden loops',description:'Weighted loops hang from the lower spars and the wingbeat slows into a broad, heavy sway.'},
  fleeing:{label:'Flightward sweep',description:'The lattice narrows into a swept-back silhouette with long retreating currents along the tips.'}
});
export const NEW_ACTOR_WING_IDS=Object.freeze(Object.keys(NEW_ACTOR_WING_RESPONSES));

// The original responses need their own material changes too: only one named
// artwork can be primary, and a manually selected look owns that artwork.
const ORIGINAL_MOTION_IDS=['stunned','prone','frightened','fatigued','slowed','quickened'];
const MOTION_IDS=new Set([...NEW_ACTOR_WING_IDS,...ORIGINAL_MOTION_IDS]);

/** Severity is sampled from the actual PF2e value. The player's saved strength
 * remains independent, so Stunned 1 never inherits Stunned 3's interruption. */
export function actorConditionStunAmount(response){
  const raw=Math.max(0,Math.min(3,Number(response?.rawLevels?.stunned)||0));
  const severity=raw<=1?raw*.28:raw<=2?.28+(raw-1)*.4:.68+(raw-2)*.32;
  return available(response,'stunned')*severity;
}
const available=(response,id)=>response?.active?.some(entry=>entry.id===id&&entry.style!=='none')?(response.levels?.[id]??0):0;
/** Actionless states hold all wing motion regardless of decorative intensity.
 * Normalize the eased level by its saved strength; explicit opt-outs still win. */
export function actorConditionMotionArrest(response){
  if(!response?.wings)return 0;
  const normalized=id=>{const strength=response.config?.conditions?.[id]?.strength??.6;return strength>0?unit(available(response,id)/strength):0;};
  const stunned=unit((response.rawLevels?.stunned??0)-2)*normalized('stunned');
  return Math.max(stunned,normalized('paralyzed'),normalized('petrified'));
}

/** Numeric PF2e conditions retain their actual values; a modest extra bend makes
 * a higher value readable without escalating into unbounded distortion. */
const amount=(response,id)=>unit((response.levels?.[id]??0)*(1+.12*Math.min(3,Math.max(0,(response.rawLevels?.[id]??1)-1))));
export function sampleActorWingMotion(response,visual={},config={}){
  const recovering=response?.collapse?.phase==='recovering';
  if(!response?.wings||response.collapse?.phase!=='awake'&&!recovering)return null;
  const active=response.active?.filter(entry=>MOTION_IDS.has(entry.id)&&entry.style!=='none'&&(!recovering||entry.id==='prone'))??[];
  if(recovering&&(response.targetStrengths?.prone??0)>0&&!active.some(entry=>entry.id==='prone')&&response.config?.conditions?.prone?.style!=='none')
    active.push({id:'prone',style:response.config?.conditions?.prone?.style??'default'});
  if(!active.length)return null;
  const arrested=actorConditionMotionArrest(response);
  const animated=!response.reduced&&visual.animated!==false&&arrested<.999;
  const time=visual.conditionFrozenTime??(animated?(visual.effectTime??visual.time??0):0);
  const motion=config.filamentInstability===false?0:Math.max(0,Math.min(2,config.conditionMotionStrength??1));
  const strengths=Object.fromEntries(active.map(entry=>[entry.id,entry.id==='stunned'?actorConditionStunAmount(response):recovering&&entry.id==='prone'?response.targetStrengths?.prone??amount(response,entry.id):amount(response,entry.id)]));
  const a=id=>strengths[id]??0;
  const sin=(rate,phase=0)=>Math.sin(time*rate+phase);
  const fear=animated?1-arrested:0;
  // A condition may author the default lattice itself. Saved custom artwork
  // keeps only the subtle accompaniment below; it does not inherit this
  // silhouette choreography, material thinning, or rigid faceting.
  const authored=config.conditionAuthoredArtwork!==false&&config.enhancedConditions!==false;
  const authoredStrengths=Object.fromEntries(active.filter(entry=>authored&&entry.style==='default').map(entry=>[entry.id,strengths[entry.id]??0]));
  const d=id=>authoredStrengths[id]??0;
  return {active:true,animated,time,motion,strengths,authoredStrengths,authored,arrest:arrested,
    // Default art has its own small topology; a selected custom style uses its
    // existing artwork while these bounded kinematics still accompany it.
    fitting:config.enhancedConditions===false?[]:active.filter(entry=>entry.style==='default').map(entry=>entry.id),
    fold:motion*Math.min(.72,.22*a('restrained')+.12*a('immobilized')+.13*a('grabbed')+.12*a('blinded')+.06*a('drained')+.1*a('fascinated')+.08*a('stunned')+.07*a('prone')
      +(.46+.13*(.5+.5*sin(2.3))+.16*(.5+.5*sin(7.4)))*d('frightened')+.65*d('restrained')+.22*d('grabbed')+.2*d('drained')
      +(.15+.46*(.5+.5*sin(.62)))*d('slowed')+.25*d('stunned')),
    sag:motion*Math.min(68,16*a('enfeebled')+13*a('encumbered')+8*a('drained')+4*a('sickened')+9*a('fatigued')+11*a('prone')+7*a('slowed')+8*a('stunned')
      +6*d('fatigued')+30*d('encumbered')+14*d('stunned')),
    retreat:motion*(.2*a('fleeing')+.7*d('fleeing')),
    focus:motion*(12*a('fascinated')+55*d('fascinated')),facet:motion*10*a('petrified'),
    roll:motion*(7*a('sickened')*sin(.85)+5*a('confused')*sin(.67,.8)+4*a('clumsy')*sin(1.35)+fear*5*a('frightened')*sin(8.1,.4)),
    sway:motion*(6*a('confused')*sin(.92,1.1)+4*a('clumsy')*sin(1.55,.7)+3*a('deafened')*sin(.42)+fear*6*a('frightened')*sin(10.2,.7)+10*d('clumsy')*sin(1.55,.7)),
    elastic:motion*(3*a('grabbed')*sin(1.2)+2*a('immobilized')*sin(1.7,.5)),
    scatter:motion*(2*a('dazzled')*sin(.7)+2*a('stupefied')*sin(.56,.8)+fear*6*a('stunned')*sin(2.2,.3)),
    reverse:motion*(4*a('confused')*sin(.73,2.1)+3*a('sickened')*sin(1.05,1.5)),
    surge:motion*.045*a('quickened'),
    // Fatigue is a shallow recovery breath; slowing leaves delayed spatial
    // echoes, whereas encumbrance pulls only the lower supporting span. Their
    // silhouettes must stay distinct even on a manually selected wing look.
    breath:motion*a('fatigued')*(1.4+1.4*sin(.78,1.1)),
    lag:motion*a('slowed')*(2.6+2.6*sin(.38,.7)),
    laden:motion*3.8*a('encumbered')*sin(.58,1.4),
    cinch:motion*2.3*a('restrained')*sin(1.05,.9),
    hood:motion*.68*d('blinded'),
    crown:motion*.63*d('fascinated'),
    yield:motion*65*d('enfeebled'),
    rootBind:motion*.6*d('immobilized'),
    confusedLeft:motion*24*d('confused')*sin(.92,1.1),
    confusedRight:motion*24*d('confused')*sin(.67,3.3),
    confusedFoldLeft:motion*d('confused')*(.22+.3*(.5+.5*sin(.92,1.1))),
    confusedFoldRight:motion*d('confused')*(.22+.3*(.5+.5*sin(.67,3.3))),
    sickRoll:motion*18*d('sickened')*sin(.85),
    deafHold:motion*.7*d('deafened'),
    quiet:Math.min(.48,.28*a('drained')+.15*a('deafened')+.1*a('enfeebled')+.08*a('fatigued')+.1*a('stunned'))};
}

/** One closure per posed strand/sample. Roots and the token depth plane stay
 * fixed; support contours pass through the same function as the visible body. */
export function actorConditionWarp(side,visual){
  const m=visual?.actorConditionMotion;if(!m?.active)return null;
  const rx=side*27,ry=-13;
  return (point,source)=>{
    const u=unit(source?.[2]??point[3]??1),w=smooth((u-.08)/.92),bell=4*w*(1-w);
    const dx=point[0]-rx,dy=point[1]-ry,lower=unit((source?.[1]??dy)/220),upper=unit(-(source?.[1]??dy)/210);
    // Source-space rib groups make clumsiness/malaise uneven through the web,
    // rather than translating the entire wing or moving its root.
    const asymmetry=side*(.5+lower)-upper*.35;
    const confused=side<0?m.confusedLeft??0:m.confusedRight??0;
    const conflictingFold=side<0?m.confusedFoldLeft??0:m.confusedFoldRight??0;
    const hood=m.hood??0,crown=m.crown??0,rootBind=(m.rootBind??0)*bell*(1-w);
    const contraction=Math.min(.9,m.fold+conflictingFold+hood*.65*upper+crown*.7*upper+rootBind);
    let x=point[0]-dx*contraction*w+dx*(m.retreat*.32+(m.surge??0))*w+side*(m.sway*bell+m.scatter*w*upper)+side*m.facet*w*(upper-lower)
      -side*(m.lag??0)*bell+side*(m.laden??0)*bell*lower-side*(m.cinch??0)*bell
      +side*confused*bell*(upper-lower);
    let y=point[1]+m.sag*w*(.4+.6*lower)+m.retreat*(55*w+dy*.06*w)-m.focus*w*upper
      +m.roll*w*asymmetry+m.reverse*bell+m.elastic*w*(lower-.5)+(m.breath??0)*w*(.35+.65*lower)
      +95*hood*w*upper+(m.yield??0)*w*lower+confused*w*(.4+lower)+(m.sickRoll??0)*w*asymmetry;
    // Deafness removes the familiar shared beat: the outer lattice settles
    // toward a quiet rest while its broken resonant links reconnect locally.
    const still=unit((m.deafHold??0)*w),sx=source?.[0],sy=source?.[1];
    if(still&&Number.isFinite(sx)&&Number.isFinite(sy)){
      x+=(side*(27+(sx-27)*.82)-x)*still;y+=(sy-y)*still;
    }
    return [x,y,...point.slice(2)];
  };
}

/** A small accent budget, attached to posed material coordinates. These paths
 * are subsequently cut by the same HP/condition cutter as the wing itself.
 * No particles, filters, texture allocation, or screen/token-space overlays. */
export function actorConditionAccents(side,visual,warp,ribs,growth=1){
  const m=visual?.actorConditionMotion;
  if(!m?.active||growth<=0||!m.fitting.length)return [];
  const out=[],t=m.time;
  const source=(rib,u)=>[...cubic(ribs[rib],Math.min(u,growth)),u];
  const path=(id,sourcePoints,strength,width=.72)=>{
    const clipped=sourcePoints.filter(p=>(p[2]??1)<=growth+.000001);
    if(clipped.length<2||strength<=.025||out.length>=40)return;
    out.push({id:`actor-${id}`,points:clipped.map(warp),strength,width,conditionAccent:true});
  };
  const bridge=(id,from,to,u,drop,strength,width=.72)=>{
    const a=source(from,u),b=source(to,u),p=[];
    for(let n=0;n<=12;n++){const q=n/12;p.push([a[0]+(b[0]-a[0])*q,a[1]+(b[1]-a[1])*q+drop*Math.sin(Math.PI*q),u]);}
    path(id,p,strength,width);
  };
  const rail=(id,rib,lo,hi,strength,width=.72,offset=0)=>path(id,Array.from({length:17},(_,i)=>{
    const u=lo+(hi-lo)*i/16,p=source(rib,u);p[0]+=offset*Math.sin(Math.PI*i/16);return p;
  }),strength,width);
  const loop=(id,rib,u,rx,ry,strength,tilt=0)=>{
    if(u>growth)return;const p=source(rib,u);
    path(id,Array.from({length:25},(_,i)=>{const q=i/24*TAU;return [p[0]+rx*Math.cos(q)+tilt*Math.sin(q),p[1]+ry*Math.sin(q),u];}),strength);
  };
  for(const id of m.fitting){
    const a=m.strengths[id],authored=(m.authoredStrengths?.[id]??0)>0,s=(authored?1.18:.7)*a;
    switch(id){
    case 'frightened':
        for(let k=0;k<3;k++)rail(`${id}-tremor-${k}`,1+k*3,.32,.91,s,authored?1.18:.82,2+(authored?9:3)*Math.sin(t*8.1+k));
        if(authored)bridge(`${id}-protective-guard`,2,8,.79,-24,s*.8,1.32);break;
      case 'stunned':
        for(let k=0;k<3;k++){
          const u=.43+k*.12;
          rail(`${id}-relay-${k}`,1+k*3,u-.055,u+.035,s,.95,4*Math.sin(t*2.2+k));
          bridge(`${id}-catch-${k}`,1+k*3,Math.min(9,2+k*3),u,3,s*.75,.82);
        }break;
      case 'prone':
        // Resting wings have a shallow breathing drape without a wingbeat.
        bridge(`${id}-drape-0`,3,6,.66,12+1.2*Math.sin(t*.6),s,.88);
        bridge(`${id}-drape-1`,6,9,.7,15+1.2*Math.sin(t*.6+.4),s*.85,.82);break;
      case 'fatigued':
        // Supporting catenaries gently recover together. No falling droplets
        // or deep hanging weights: tired wings still carry their own span.
        bridge(`${id}-breath-0`,authored?2:3,6,.61,5+2*Math.sin(t*.78+1.1),s*.85,authored?1.3:.85);
        bridge(`${id}-breath-1`,6,9,.71,7+2*Math.sin(t*.78+.8),s,authored?1.4:.9);
        rail(`${id}-recovery`,5,.37,.74,s*(.78+.12*Math.sin(t*.78)),.76,2);break;
      case 'slowed':
        // Neighboring delayed contours visibly catch up in sequence. The
        // slow traveling head is continuous at its reversal; it never pops.
        for(let k=0;k<3;k++){
          const u=.37+.4*(.5+.5*Math.sin(t*.38-k*.65));
          rail(`${id}-lag-${k}`,1+k*3,Math.max(.15,u-.3),u,s*(1-k*.16),(authored?1.4:.91)-k*.12,(authored?15:3)+k*2);
          rail(`${id}-echo-${k}`,1+k*3,.24,.91,s*.58,authored?.92:.61,(authored?-18:-3)-k);
        }break;
      case 'quickened':
        for(let k=0;k<3;k++){
          const u=m.animated?.32+.5*(.5+.5*Math.sin(t*2.4-k*.55)):.66;
          rail(`${id}-surge-${k}`,1+k*3,Math.max(.15,u-.14),u,s,.98,2);rail(`${id}-return-${k}`,1+k*3,.22,.79,s*.6,.65,-3);
        }break;
      case 'blinded':
        for(let k=0;k<(authored?5:3);k++)bridge(`${id}-veil-${k}`,0,authored?4:3,.34+k*(authored?.12:.14),authored?28:7,s*.7,authored?1.3:.72);
        rail(`${id}-search`,1,.17,.9,s,authored?1.2:.86,(authored?14:4)*Math.sin(t*.7));break;
      case 'dazzled':
        for(let k=0;k<3;k++){
          const u=.46+.13*k+.018*Math.sin(t*.6+k),spread=.5+.5*Math.sin(t*.6+k);
          loop(`${id}-halo-${k}`,k,u,(authored?13:4)+k+(authored?10:3)*spread,(authored?10:3)+k+(authored?8:2)*spread,s*(.62+.18*spread));
          rail(`${id}-diffusion-${k}`,k,Math.max(.16,u-.09),Math.min(.92,u+.09),s*.42,authored?1.05:.6,(authored?14:3)+2*spread);
        }break;
      case 'deafened':
        // Outward resonance reaches a muted gap. Two short return links slowly
        // reconnect out of phase, rather than flashing or shaking the wing.
        for(let k=0;k<2;k++){
          const rib=2+k*4,reconnect=.5+.5*Math.sin(t*.42-k*1.7);
          rail(`${id}-outer-${k}`,rib,.24,.42,s*.75,authored?1.1:.76,authored?17:5);
          rail(`${id}-silence-${k}`,rib,.5,.89,s*(.28+.2*reconnect),authored?.85:.62,authored?17:5);
          rail(`${id}-return-${k}`,rib,.28,.82,s*(.35+.16*(1-reconnect)),authored?1:.65,authored?-17:-5);
          bridge(`${id}-muted-link-${k}`,rib,Math.min(9,rib+1),.44,-2,s*(.28+.1*reconnect),.61);
        }break;
      case 'clumsy':
        for(let k=0;k<3;k++)loop(`${id}-seam-${k}`,2+k*2,.62+.022*Math.sin(t*1.1+k),6,3,s,2.8*Math.sin(t*1.1+k));break;
      case 'enfeebled':
        bridge(`${id}-span-0`,4,6,.79,(authored?32:16)+2*Math.sin(t*.7),s,authored?1.35:.9);
        bridge(`${id}-span-1`,6,9,.73,(authored?41:19)+3*Math.sin(t*.7+.6),s*.8,authored?1.3:.8);break;
      case 'drained':
        for(let k=0;k<3;k++){const head=m.animated ? .25+.62*(.5+.5*Math.sin(t*.48+k*1.9)) : .48;rail(`${id}-ebb-${k}`,2+k*3,.15,head,s*(1-k*.12),(authored?1.55:1.02)-k*.18);}break;
      case 'sickened':
        loop(`${id}-return-0`,4,.48,12,7,s,5*Math.sin(t*.8));loop(`${id}-return-1`,6,.65,10,8,s*.8,-5*Math.sin(t*.8));break;
      case 'stupefied':
        for(let k=0;k<4;k++){const pulse=.42+.58*(.5+.5*Math.sin(t*.9-k*1.55));rail(`${id}-relay-${k}`,1+k*2,.32+k*.06,.42+k*.06,s*pulse,1.08);}break;
      case 'confused':
        loop(`${id}-circuit-0`,3,.5,authored?34:17,authored?23:10,s,(authored?15:6)*Math.sin(t*.67));
        loop(`${id}-circuit-1`,5,.58,authored?26:12,authored?35:18,s*.8,-(authored?16:5)*Math.sin(t*.73));break;
      case 'fascinated':
        for(let k=0;k<3;k++)rail(`${id}-focus-${k}`,k,.28,.96,s*(.8+.15*Math.sin(t*.5-k*.2)),authored?1.38:.92,2*(k-1));
        loop(`${id}-held-focus`,1,.86,authored?16:5,authored?25:7,s);break;
      case 'immobilized':
        for(let k=0;k<3;k++)bridge(`${id}-root-bind-${k}`,k*3,Math.min(9,k*3+3),.23+k*.025,authored?-13:-5,s,authored?1.5:.86);break;
      case 'restrained':
        bridge(`${id}-snare-0`,1,7,.65,2+2*Math.sin(t*1.05+.9),s,.95);
        bridge(`${id}-snare-1`,3,9,.66,-4-2*Math.sin(t*1.05+.9),s,.95);
        bridge(`${id}-snare-2`,0,5,.43,4,s*.75);break;
      case 'paralyzed':
        for(let k=0;k<3;k++)loop(`${id}-suspension-${k}`,1+k*3,.57,6,11,s,2);break;
      case 'grabbed':
        bridge(`${id}-tether-0`,0,5,.8,-7,s,.96);bridge(`${id}-tether-1`,5,9,.76,-5,s*.85,.86);break;
      case 'encumbered':
        for(let k=0;k<3;k++)loop(`${id}-load-${k}`,5+k*2,.77,authored?15:6,(authored?35:15)+k*2,s*(1-k*.12),(authored?8:3)*Math.sin(t*.58+k*.18));break;
      case 'petrified':
        for(let k=0;k<3;k++){const u=.54+k*.1,p=source(1+k*3,u);
          path(`${id}-facet-${k}`,[[p[0],p[1]-19,u],[p[0]+12,p[1]-5,u],[p[0]+9,p[1]+13,u],[p[0]-5,p[1]+20,u],[p[0]-12,p[1],u],[p[0],p[1]-19,u]],s,1.03);}break;
      case 'fleeing':
        for(let k=0;k<3;k++)rail(`${id}-sweep-${k}`,1+k*3,.42,.96,s*(.78+.15*Math.sin(t*.75-k*.6)),.98,5);break;
    }
  }
  return out;
}

/** Default condition artwork can reshape the surviving body material itself.
 * This receives already-cut HP spans, so faceting/thinning never reconnects a
 * damaged strand. Saved artwork and decorative hardware retain their painter.
 * There is no random dropout, allocation, or positional discontinuity here.
 */
export function actorConditionMaterialPaths(strand,points,side,visual){
  const m=visual?.actorConditionMotion,d=m?.authoredStrengths;
  if(!m?.active||!d||strand.conditionAccent||strand.hardware||strand.star||strand.echo||/^(gem|sigil)-/.test(strand.id)||points.length<2)return null;
  const a=id=>d[id]??0,drained=a('drained'),deafened=a('deafened'),petrified=a('petrified'),stupefied=a('stupefied'),dazzled=a('dazzled');
  if(!(drained||deafened||petrified||stupefied||dazzled))return null;
  const web=/^(web|cross)-/.test(strand.id),edge=strand.id.startsWith('edge-'),rib=Number(strand.id.split('-')[1])||0;
  const quiet=Math.max(.16,1-drained*(web?.92:edge?.24:.43)-deafened*(web?(rib%2?.76:.28):.09));
  const relay=1-stupefied*(web?.72:.28)*(.5+.5*Math.sin(m.time*.72-rib*1.14));
  const diffusion=1+dazzled*(web?.26:.12)*(.5+.5*Math.sin(m.time*.6+rib*.65));
  let posed=points;
  if(petrified){
    // Interpolate the existing surviving curve toward a few rigid planes.
    // Keep its same point count and depth/u metadata, including both cut ends.
    const planes=web?2:4,blend=unit(petrified/.6),last=points.length-1;
    const sample=u=>{const n=u*last,lo=Math.floor(n),hi=Math.min(last,lo+1),q=n-lo;return points[lo].slice(0,2).map((v,k)=>v+(points[hi][k]-v)*q);};
    posed=points.map((p,i)=>{
      const position=i/last*planes,lo=Math.min(planes-1,Math.floor(position)),q=position-lo;
      const left=sample(lo/planes),right=sample((lo+1)/planes);
      return [p[0]+(left[0]+(right[0]-left[0])*q-p[0])*blend,p[1]+(left[1]+(right[1]-left[1])*q-p[1])*blend,...p.slice(2)];
    });
  }
  return [{...strand,points:posed,strength:(strand.strength??1)*quiet*relay*diffusion,width:(strand.width??1)*(1-.35*drained+(edge?.17*petrified:0))}];
}

/** The existing continuous wing clock integrates this cosmetic rate. These
 * values never alter token movement, action economy, or PF2e condition values. */
export function actorConditionWingRate(response){
  if(!response?.wings)return 1;
  const a=id=>available(response,id),arrested=actorConditionMotionArrest(response);
  const load=Math.max(a('encumbered'),a('enfeebled'),a('drained'));
  const bound=Math.max(a('restrained'),a('immobilized'),a('grabbed'));
  // Lying down holds the beat, eased with the prone level (450 ms) rather than
  // stopped in one frame. A rebuilding prone actor is still lying down: its
  // level does not fade during Reform, so it never finishes with a full flap.
  const proneChoice=response.config?.conditions?.prone,proneStrength=proneChoice?.strength??.6;
  const prone=proneChoice?.style==='none'||!(proneStrength>0)?0:unit(a('prone')/proneStrength);
  if(prone>=1)return 0;
  return Math.max(0,(1-prone)*(1-(response.collapse?.mix??0))*(1-actorConditionStunAmount(response))*(1-.35*a('slowed'))*(1-.22*a('fatigued'))
    *(1+.2*a('quickened'))*(1-arrested)*(1-.2*load)*(1-.12*bound)*(1+.15*a('fleeing')));
}
