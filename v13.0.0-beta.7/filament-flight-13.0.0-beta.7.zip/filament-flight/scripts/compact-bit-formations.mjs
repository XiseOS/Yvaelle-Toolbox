import {applyCompactExpression} from './bit-expression.mjs?v=13.0.0-beta.7';
import {LIVING_BIT_PROGRAMS,sampleLivingScene,sampleWorkGesture,captureGestureLayout,gestureOrientation,BIT_GESTURES} from './bit-behaviour.mjs?v=13.0.0-beta.7';
import {formationFlowState,smoothIntercept} from './bit-formation-flow.mjs?v=13.0.0-beta.7';
import {createEpisodeMove,boundedFocusLean} from './bit-episode-motion.mjs?v=13.0.0-beta.7';
import {blendCoreActivities} from './bit-core-states.mjs?v=13.0.0-beta.7';
import {applyBitLanternGroup,bitLanternHandoffGroup,bitLanternReturnNow,bitLanternWeight,bitLanternPoseClock,bitLanternPoseNow,bitLanternHeldFlight,bitLanternWingFlight,applyBitLanternMountingPose} from './bit-lantern.mjs?v=13.0.0-beta.7';
import {V7_BIT_PROGRAMS,V7_BIT_PROGRAM_IDS,sampleV7BitScene} from './v7-bit-formations.mjs?v=13.0.0-beta.7';
import {REFINED_BIT_PROGRAMS,REFINED_BIT_PROGRAM_IDS,REFINED_SAMPLERS} from './refined-formations.mjs?v=13.0.0-beta.7';
import {sampleV7TransitionAccent} from './v7-ensemble.mjs?v=13.0.0-beta.7';
export {V7_BIT_PROGRAMS,V7_BIT_PROGRAM_IDS} from './v7-bit-formations.mjs?v=13.0.0-beta.7';
/** Close companions have their own count-specific choreography. Coordinates
 * are rig units: 600 units span 3.5 token widths, independent of wing scale. */
export const COMPACT_BIT_IDS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);
const TAU=Math.PI*2;
const unit=n=>Math.max(0,Math.min(1,n));
const ease=n=>{n=unit(n);return n*n*(3-2*n);};
const entry=(name,description)=>Object.freeze({name,description});
export const COMPACT_BIT_PROGRAMS=Object.freeze({
  ...REFINED_BIT_PROGRAMS,
  orbit:Object.freeze({name:'Quiet orbit',counts:Object.freeze({
    1:entry('Satellite','One instrument follows a tilted orbit, slipping behind Ellie before returning into view.'),
    2:entry('Counterbalance','A poised pair circles in opposite directions on two inclined planes.'),
    3:entry('Triune halo','A breathing triangle turns around Ellie with staggered front and rear passages.'),
    4:entry('Twin armillary','Two pairs trace perpendicular ellipses with a slowly precessing axis.')})}),
  drift:Object.freeze({name:'Companion drift',counts:Object.freeze({
    1:entry('Shoulder companion','One bit visits either shoulder, pausing before quietly changing sides.'),
    2:entry('Attendant pair','Two attendants trade high and low stations, crossing behind Ellie in turn.'),
    3:entry('Crown attendants','A three-point crown tilts as its attendants exchange their places.'),
    4:entry('Fourfold watch','Four attendants make staggered shoulder inspection circuits, trading front and rear depth within their own side.')})}),
  weave:Object.freeze({name:'Crossing paths',counts:Object.freeze({
    1:entry('Ribbon passage','A single bit traces a narrow figure eight through front and rear space.'),
    2:entry('Mirrored ribbons','Two counterwoven ribbons exchange vertical positions without meeting.'),
    3:entry('Trefoil braid','Three staggered instruments trace a soft trefoil braid around the token.'),
    4:entry('Double helix','Two offset pairs climb and descend on interlaced, counterturning helices.')})}),
  curious:Object.freeze({name:'Curious instruments',counts:Object.freeze({1:entry('Little surveyor','One bit pauses, leans toward a detail and returns to its quiet circuit.'),2:entry('Scout and keeper','One scouts ahead while its partner keeps watch, then they exchange duties.'),3:entry('Inquiry triangle','Three instruments inspect in turn, leaving two calm anchors.'),4:entry('Field researchers','Two companion pairs take turns investigating and regrouping.')})}),
  escort:Object.freeze({name:'Gentle escort',counts:Object.freeze({1:entry('Faithful companion','A close companion slips between shoulder and forward escort positions.'),2:entry('Courteous passage','Two companions open a passage and fall back into step.'),3:entry('Protective crescent','An attentive crescent opens and closes around its charge.'),4:entry('Quiet procession','Four companions move in a measured, staggered procession.')})}),
  social:Object.freeze({name:'Quiet conversation',counts:Object.freeze({1:entry('Attentive nod','A lone instrument turns toward its charge and acknowledges them.'),2:entry('Private exchange','Two instruments draw together briefly, exchange a core glimmer, then part.'),3:entry('Passing thought','A small acknowledgment passes from one instrument to the next.'),4:entry('Two conversations','Two pairs meet on opposite sides before exchanging companions.')})}),
  vigil:Object.freeze({name:'Watchful rest',counts:Object.freeze({1:entry('Patient watch','A still sentinel surveys its surroundings between long quiet pauses.'),2:entry('Changing the watch','One sentinel rests while the other makes a deliberate inspection.'),3:entry('Three watchposts','A triangle of watchposts advances through a calm inspection circuit.'),4:entry('Lantern guard','Four instruments guard cardinal posts with unhurried individual corrections.')})}),
  atelier:Object.freeze({name:'Little atelier',counts:Object.freeze({
    1:entry('Careful artisan','A single instrument inspects three close working points, then steps back to assess.'),
    2:entry('Hands and light','One works while a second holds a lamp above; they smoothly trade duties.'),
    3:entry('Three-part consultation','A high observer guides two attendants through opposite inspection points.'),
    4:entry('Quiet workshop','Two working pairs make oval checking passages, passing the working light between high and low duties.')})}),
  shelter:Object.freeze({name:'Sheltering company',counts:Object.freeze({
    1:entry('Small guardian','One guardian moves from shoulder watch to a brief protective bow in front.'),
    2:entry('Parting curtains','A pair opens a clear passage, then folds back into a protective crescent.'),
    3:entry('Gabled refuge','Two low guards support a high keystone, exchanging the upper watch in turn.'),
    4:entry('Four-point sanctuary','Four guardians traverse separate arcs around an opening diamond, passing through front and rear watch positions.')})}),
  lanterns:Object.freeze({name:'Lantern keepers',counts:Object.freeze({
    1:entry('Nightlight','A lone companion climbs a small helix, rests above a shoulder and descends behind.'),
    2:entry('Rising and setting','Two lamps exchange height across opposite sides without sharing a path.'),
    3:entry('Procession of lights','A leading lantern guides a following pair along a staggered upward procession.'),
    4:entry('Constellation keepers','Two high lamps and two lower companions climb staggered local circuits, exchanging a passing current in diagonal pairs.')})}),
  relay:Object.freeze({name:'Ribbon relay',counts:Object.freeze({
    1:entry('Returning messenger','One messenger draws a small looping flourish before returning to shoulder station.'),
    2:entry('Hand to hand','A pair trades the leading position along offset S-curves.'),
    3:entry('Thread relay','Three instruments pass a glimmer through a triangular circuit with distinct pauses.'),
    4:entry('Cross-stitch relay','Four companions trace opposing rounded squares, exchanging a pulse at the corners.')})}),
  patrol:Object.freeze({name:'Sentinel patrol',counts:Object.freeze({
    1:entry('Four-point survey','A lone instrument visits four nearby inspection stations, pausing at each.'),
    2:entry('Relay watch','One bit holds its station while its partner advances; then their roles reverse.'),
    3:entry('Triangular relay','A triangular escort rotates one station at a time with deliberately staggered departures.'),
    4:entry('Diamond sentinels','Four sentinels hold a diamond, then advance in two alternating pairs.')})}),
  ...LIVING_BIT_PROGRAMS,
  ...V7_BIT_PROGRAMS
});
export {REFINED_BIT_PROGRAM_IDS};
/** Every family stays selectable so saved choices keep working. The refined
 * library is listed first; 'refined' limits random/flow summons to it and
 * 'classic' hides it from lists. */
/** v10 beta: formations that repeat another's shape move to Legacy. They stay
 * selectable (listed last, under "Legacy") and saved choices keep working. */
export const LEGACY_FORMATION_IDS=Object.freeze(['orbit','drift','curious','escort','social','atelier','shelter','lanterns','nightbloom','prismArc','velvetCourt','tensionWeft','lilyVigil','foldedLetter','pearlCanopy','resonantMeasure',
  // beta.30: the user did not like Heartline; it stays choosable (and saved
  // choices keep it) but is listed under Legacy and never chosen at random.
  'heartline']);
const LEGACY=new Set(LEGACY_FORMATION_IDS);
export const isLegacyFormation=id=>LEGACY.has(id);
/** Distinct shapes used for random-on-summon and formation flow suggestions. */
export const SUMMON_FORMATION_IDS=Object.freeze([...REFINED_BIT_PROGRAM_IDS.filter(id=>id!=='search'&&id!=='heartline'),'weave','vigil','relay','patrol','curiousCompanions','quietExchange','attentiveEscort','livingWorkshop']);
const ORIGINAL_IDS=new Set(['halo','sentinel','lemniscate','pendulum','comet','petals','tide','spiral','perch','constellation','wingTrace','heartline','crown']);
export function enabledCompactProgramIds({v7Enabled=true,library='refined',forSummon=false}={}){
  // Wide search ranges beyond the preview frame; Resting searchlights selects it
  const ids=Object.keys(COMPACT_BIT_PROGRAMS).filter(id=>id!=='search'&&(v7Enabled||!V7_BIT_PROGRAM_IDS.includes(id)));
  // Classic: only the pre-refined families
  if(library==='classic')return ids.filter(id=>!ORIGINAL_IDS.has(id));
  if(forSummon&&library!=='all')return ids.filter(id=>SUMMON_FORMATION_IDS.includes(id));
  // Curated (default) and All: current shapes first, Legacy last
  return [...ids.filter(id=>!LEGACY.has(id)),...ids.filter(id=>LEGACY.has(id))];
}
export function compactAnimationChoices(count=4,options={}){count=Math.max(1,Math.min(4,Math.round(count)));return enabledCompactProgramIds(options).map(id=>({id,...COMPACT_BIT_PROGRAMS[id].counts[count],...(LEGACY.has(id)?{legacy:true,name:`Legacy · ${COMPACT_BIT_PROGRAMS[id].counts[count].name}`}:{})}));}
// Pause on both ends, retaining a zero derivative when each transit begins.
function stationCycle(time,period,points,offset=0,hold=.52){
  const p=time/period+offset,step=Math.floor(p),u=ease((p-step-hold*.5)/(1-hold));
  const a=points[((step%points.length)+points.length)%points.length],b=points[(((step+1)%points.length)+points.length)%points.length];
  return a.map((v,i)=>v+(b[i]-v)*u);
}
function orbit(count,i,t){
  const p=t*.40;
  if(count===1){const q=p-.55;return [112*Math.cos(q),-13+45*Math.sin(q),Math.sin(q+.28),.13*Math.sin(q)];}
  if(count===2){const q=(i?-p:p)+i*Math.PI+.4;return [113*Math.cos(q),-10+43*Math.sin(q)*(i?-.75:1),Math.sin(q)*(i?-1:1),.18*Math.sin(q+i)];}
  if(count===3){const q=p+i*TAU/3;const r=110+6*Math.sin(p*.6);return [r*Math.cos(q),-14+52*Math.sin(q),Math.sin(q+.5),.11*Math.sin(q-p*.25)];}
  const pair=i%2,lane=Math.floor(i/2),q=p*(lane?-.82:1)+pair*Math.PI+lane*.7,tilt=lane?.85:-.25;
  const x=107*Math.cos(q),y=39*Math.sin(q);
  return [x*Math.cos(tilt)-y*Math.sin(tilt),-10+x*Math.sin(tilt)*.43+y*Math.cos(tilt),Math.sin(q+lane*.9),.15*Math.sin(q)];
}
function drift(count,i,t){
  if(count===1){const q=t*.23,side=Math.tanh(Math.sin(q)*2.1);return [101*side,-62+14*Math.cos(q*2),Math.sin(q+.65),.12*side];}
  if(count===2){const q=t*.27+i*Math.PI;return [104*Math.cos(q),-28+37*Math.sin(q)*Math.cos(q),Math.sin(q),.10*Math.sin(q*.7)];}
  if(count===3){const q=t*.18+i*TAU/3;return [107*Math.sin(q),-49-28*Math.cos(q)+7*Math.sin(t*.57+i),Math.cos(q+.3),.13*Math.sin(q)];}
  const bases=[[-95,-62,-1],[95,-62,1],[-91,53,1],[91,53,-1]],b=bases[i],q=t*.28+i*Math.PI/2;
  // Alternating diagonal attendants trade depth while their nearby station holds.
  return [b[0]+12*Math.sin(q),b[1]+8*Math.cos(q*.87),Math.sin(q+b[2]*.5),.10*Math.sin(q*.8)];
}
function weave(count,i,t){
  const p=t*.34;
  if(count===1)return [110*Math.sin(p),-14+49*Math.sin(p*2),Math.cos(p),.18*Math.cos(p*2)];
  if(count===2){const q=p+i*Math.PI+.55;return [108*Math.sin(q),-14+44*Math.sin(q*2+i*Math.PI/2),Math.cos(q),.17*Math.cos(q*2+i)];}
  if(count===3){const q=p+i*TAU/3;return [100*Math.cos(q)+13*Math.cos(2*q),-10+43*Math.sin(q)-15*Math.sin(2*q),Math.sin(q*2+.3),.16*Math.sin(q)];}
  const lane=Math.floor(i/2),q=(lane?-p:p)+(i%2)*Math.PI+lane*Math.PI/2;
  return [106*Math.cos(q),-9+48*Math.sin(q*.5+lane*Math.PI),Math.sin(q),.16*Math.sin(q*.8+lane)];
}
function patrol(count,i,t){
  const square=[[-101,-53,-1],[99,-52,1],[101,51,1],[-99,52,-1]];
  if(count===1){const p=stationCycle(t,5.0,square);return [...p,.08*Math.sin(t*.4)];}
  if(count===2){const p=stationCycle(t,5.8,square,i*2+i*.5,.60);return [p[0],p[1]+i*8,p[2]*Math.cos(t*.2+i),.08*Math.sin(t*.4+i)];}
  if(count===3){const triangle=[[0,-91,-1],[111,35,1],[-111,35,1]],p=stationCycle(t,5.6,triangle,i+i/3,.50);return [...p,.09*Math.sin(t*.35+i*2)];}
  const diamond=[[0,-97,-1],[110,-2,1],[0,80,1],[-110,-2,-1]],p=stationCycle(t,6.4,diamond,i+(i%2)*.5,.52);return [...p,.07*Math.sin(t*.32+i)];
}
function curious(count,i,t){
  const points=[[-114,-54,-1],[5,-105,-1],[117,-31,1],[91,64,1],[-111,49,1]],p=stationCycle(t,4.6+count*.17,points,i*(5/count)+count*.16,.56);
  const q=t*.51+i*1.3,inspect=ease((Math.sin(t*.36+i*2.1)-.48)/.52);
  const c=Math.cos(count*.19),s=Math.sin(count*.19);return [p[0]*c-p[1]*s+inspect*7*Math.cos(q),p[0]*s+p[1]*c-inspect*12,p[2],.10*Math.sin(q)+inspect*.24*Math.sin(i+1)];
}
function escort(count,i,t){
  // A crescent travels as a courteous group, opening a passage between escorts.
  // It is deliberately not an evenly spaced ring of independent satellites.
  const spread=count===1?0:(i/(count-1)-.5)*(1.35+.2*Math.sin(t*.21)),q=t*.22+spread+.31*count;
  const lag=3*Math.sin(t*.62-i*.7),r=108+4*Math.sin(t*.3+i*.6);
  return [r*Math.cos(q),-15+(39+count*3)*Math.sin(q)+lag,Math.sin(q),.10*Math.sin(q)+.07*Math.sin(t*.33+i)];
}
function social(count,i,t){
  const base=t*.26+i*TAU/count+.19*count,pair=Math.floor(i/2),meeting=(.5+.5*Math.cos(t*.39+pair*2.3))**4;
  const turn=count===1?.22*Math.sin(t*.6):count===2?(i?-1:1)*1.13*meeting:count===3?.55*Math.sin(t*.39-i*TAU/3):(i%2?-1:1)*.51*meeting;
  const q=base+turn,r=111-5*meeting;
  return [r*Math.cos(q),-12+(42+count*2)*Math.sin(q),Math.sin(q),.13*Math.sin(q)+(i%2?-1:1)*meeting*.24];
}
function vigil(count,i,t){
  // Holding stations are linked by narrow, deliberate S-shaped passages. A
  // hyperbolic dwell keeps the motion smooth while giving each bit a long rest.
  const q=t*(.19+.004*count)+i*TAU/count+.25*count,side=Math.tanh(Math.cos(q)*2.2);
  return [111*side,-10+(43+count*7)*Math.sin(q*2)+3*Math.sin(t*.48+i),Math.sin(q),.045*Math.sin(t*.43+i)];
}
function atelier(count,i,t){
  const phase=t*.31,work=.5-.5*Math.cos(t*.38),bob=2*Math.sin(t*.8+i);
  if(count===1){const p=stationCycle(t,6.5,[[103,-47,1],[100,27,1],[-106,-29,-1]],0,.65);return [p[0],p[1]+bob,p[2],-.16*Math.tanh(p[0]/10)*work];}
  if(count===2){const p=stationCycle(t,8,[[108,29,1],[108,-92,-1],[-108,-92,-1],[-108,29,1]],i*2,.64);return [p[0],p[1]+bob,p[2],-.14*Math.tanh(p[0]/10)*work];}
  if(count===3){const p=stationCycle(t,9,[[0,-107,-1],[108,39,1],[-108,39,1]],i,.67);return [p[0]+3*Math.sin(phase+i),p[1]+bob,p[2],-.14*Math.tanh(p[0]/10)*work];}
  const left=i<2,pair=i%2,side=left?-1:1;return [side*(109+6*Math.sin(phase+(pair?Math.PI:0))),pair?40-14*work:-58+10*work,pair?.8:-.8,-side*(pair?-.08:.12)*work];
}
function shelter(count,i,t){
  const breath=.5-.5*Math.cos(t*.32),q=t*.24;
  if(count===1){const p=stationCycle(t,7.6,[[-103,-47,-1],[0,96,1],[103,-47,-1]],0,.57);return [p[0],p[1],p[2],.16*Math.sin(q)];}
  if(count===2){const side=i?-1:1;return [side*(99+17*breath),-36+47*breath,Math.sin(q+i*Math.PI),side*(.16-.32*breath)];}
  if(count===3){const p=stationCycle(t,11,[[0,-111,-1],[111,39,1],[-111,39,1]],i,.72);return [p[0]*(1+.06*breath),p[1]+3*Math.sin(q+i),p[2],-.10*Math.tanh(p[0]/10)];}
  const corners=[[-91,-83,-1],[91,-83,-1],[91,76,1],[-91,76,1]],p=corners[i];
  return [p[0]*(1+.24*breath),p[1]*(1-.2*breath),p[2],Math.sign(p[0])*(i<2?.11:-.11)*breath];
}
function lanterns(count,i,t){
  const q=t*.26;
  if(count===1)return [106*Math.cos(q),-20+82*Math.sin(q),Math.sin(q),.09*Math.sin(q)];
  if(count===2){const a=q+i*Math.PI;return [(i?-1:1)*(108+5*Math.sin(q*2)),7+79*Math.sin(a),Math.cos(a),.08*Math.sin(a)];}
  if(count===3){const a=q-i*.74,lead=i===0;return [109*Math.cos(a),-12+(lead?85:66)*Math.sin(a)+i*6,Math.sin(a),.08*Math.sin(a)];}
  const side=i%2?-1:1,row=i<2?-1:1,exchange=.5-.5*Math.cos(q);
  return [side*(101+12*Math.sin(q+(row<0?0:Math.PI))),row*(61-18*exchange)-11,Math.sin(q+i*Math.PI/2),side*.07*Math.sin(q)];
}
function relay(count,i,t){
  if(count===1){const q=t*.32,bow=Math.sin(q);return [103+15*Math.sin(q*2),-18+65*bow,Math.cos(q),.16*Math.sin(q*2)];}
  if(count===2){const p=stationCycle(t,7.2,[[-112,-52,-1],[112,-52,1],[112,49,1],[-112,49,-1]],i*2,.36);return [p[0],p[1]+7*Math.sin(t*.64+i*Math.PI),p[2],.14*Math.sin(t*.32+i*Math.PI)];}
  if(count===3){const p=stationCycle(t,5.9,[[0,-111,-1],[115,47,1],[-115,47,1]],i,.64);return [...p,.12*Math.sin(t*.38+i*2.1)];}
  const square=[[-108,-69,-1],[108,-69,1],[108,61,1],[-108,61,-1]],lane=Math.floor(i/2),p=stationCycle(lane?-t:t,8.3,square,i%2*2+lane,.42),radius=lane?.67:1.06;
  return [p[0]*radius,p[1]*radius+(lane?4:-4),p[2]+(lane?-.48:.48),.1*Math.sin(t*.36+i*Math.PI/2)];
}
const SAMPLERS={orbit,drift,weave,patrol,curious,escort,social,vigil,atelier,shelter,lanterns,relay,...REFINED_SAMPLERS};
/** Only the parked companion variants receive a new route. Classic mode keeps
 * its exact old sampler; the V7 formation switch enables these living routes.
 * These are held-side handoffs and local working passages, rather than noise
 * added to every orbit or a common idle bob. */
function livingCompanionPose(count,program,i,t){
  if(program==='drift'&&count===4){
    const bases=[[-95,-62],[95,-62],[-91,53],[91,53]],b=bases[i],q=t*.46+i*Math.PI/2,side=Math.sign(b[0]);
    return [b[0]+side*22*Math.sin(q),b[1]+28*Math.cos(q),.72*Math.sin(q+.4),side*.22*Math.cos(q)];
  }
  if(program==='atelier'){
    const bob=2*Math.sin(t*.8+i),work=.5-.5*Math.cos(t*.38);
    if(count===1){const p=stationCycle(t,4.8,[[103,-47,1],[100,27,1],[-106,-29,-1]],0,.16);return [p[0],p[1]+bob,p[2],-.16*Math.tanh(p[0]/10)*work];}
    if(count===2){const p=stationCycle(t,5.4,[[108,29,1],[108,-92,-1],[-108,-92,-1],[-108,29,1]],i*2,.16);return [p[0],p[1]+bob,p[2],-.14*Math.tanh(p[0]/10)*work];}
    if(count===3){const p=stationCycle(t,5.6,[[0,-107,-1],[108,39,1],[-108,39,1]],i,.16);return [p[0]+3*Math.sin(t*.31+i),p[1]+bob,p[2],-.14*Math.tanh(p[0]/10)*work];}
    const side=i<2?-1:1,row=i%2,q=t*.48+(row?Math.PI:0)+(side<0?0:.8);
    return [side*(107+22*Math.sin(q)),(row?36:-61)+27*Math.cos(q),.74*Math.sin(q+.4),-side*.25*Math.sin(q)];
  }
  if(program==='shelter'){
    if(count===1){const p=stationCycle(t,5.4,[[-103,-47,-1],[0,96,1],[103,-47,-1]],0,.18);return [...p,.16*Math.sin(t*.35)];}
    if(count===3){const p=stationCycle(t,6.6,[[0,-111,-1],[111,39,1],[-111,39,1]],i,.18);return [p[0],p[1]+3*Math.sin(t*.4+i),p[2],-.10*Math.tanh(p[0]/10)];}
    if(count===4){const corners=[[-91,-83],[91,-83],[91,76],[-91,76]],b=corners[i],side=Math.sign(b[0]),q=t*.39+i*Math.PI/2;
      return [b[0]+side*20*Math.sin(q),b[1]+26*Math.cos(q),.76*Math.sin(q+.5),side*.24*Math.cos(q)];}
  }
  if(program==='lanterns'&&count===4){
    const side=i%2?-1:1,row=i<2?-1:1,q=t*.47+i*Math.PI/2;
    return [side*(103+22*Math.sin(q)),row*56-11+29*Math.cos(q),.78*Math.sin(q),side*.23*Math.cos(q)];
  }
  return SAMPLERS[program](count,i,t);
}
const NUMERIC_FIELDS=Object.freeze(['x','y','z','angle','scale','brightness']);
const finite=(n,fallback=0)=>Number.isFinite(Number(n))?Number(n):fallback;
const wrap=n=>(n%1+1)%1;
const lerp=(a,b,t)=>a+(b-a)*t;
const angleBlend=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
function episode(clock,period,duration){
  const cycle=Math.floor(clock/period),elapsed=clock-cycle*period,progress=unit((elapsed-(period-duration))/duration);
  return {cycle,progress,amount:elapsed<period-duration?0:ease(progress/.24)*(1-ease((progress-.72)/.28))};
}
/** Each episode has one shared timeline. Partners therefore acknowledge one
 * another, while the unoccupied instruments visibly keep their own stations. */
function companionScene(count,program,clock,personality,animated,displayOffsets=[],enhancedMotion=false){
  const fn=enhancedMotion?(count,i,t)=>livingCompanionPose(count,program in SAMPLERS?program:'orbit',i,t):SAMPLERS[program]??orbit,poses=Array.from({length:count},(_,i)=>fn(count,i,clock));
  if(!animated||personality<=0)return {poses,intents:[]};
  const periods={curious:18,social:21,escort:25,vigil:29,atelier:17,shelter:27,lanterns:23,relay:19},period=periods[program]??37,duration=program==='social'?5.8:5.2,event=episode(clock,period,duration);
  const amount=event.amount*personality,intents=[],focusTargets=Array.from({length:count},()=>({kind:'charge',target:[0,-18,0],key:`${program}:${event.cycle}`}));
  const reference=amount>.00001||program==='atelier'||program==='vigil'?Array.from({length:count},(_,i)=>fn(count,i,event.cycle*period+period-duration)):poses;
  const leader=((event.cycle%count)+count)%count,move=amount>.00001?createEpisodeMove(poses,reference,amount,{offsets:displayOffsets}):()=>{};
  const set=(i,kind,target,weight=1,partnerIndex=null)=>{
    const p=poses[i],aim=boundedFocusLean(p,target);
    focusTargets[i]={kind:partnerIndex==null?'work':'partner',target:target.slice(0,3),partnerIndex,key:`${program}:${event.cycle}`};
    if(amount<.00001)return;
    p[3]=angleBlend(p[3],aim,amount*weight);
    intents[i]={kind,amount:amount*weight,progress:event.progress,target,partnerIndex};
  };
  if(program==='atelier'){
    const p=poses[leader],side=reference[leader][0]<0?-1:1;set(leader,'mend',[side*46,-4+(leader%2)*12,p[2]]);
    if(count>1){const helper=(leader+1)%count;set(helper,'observe',poses[leader].slice(0,3),.45,leader);}
  }else if(program==='shelter'){
    for(let i=0;i<count;i++)set(i,'canopy',[0,poses[i][1]*.36,poses[i][2]],i===leader?.7:.3);
  }else if(program==='lanterns'){
    if(count===1)set(0,'lantern',[poses[0][0],poses[0][1]+21,poses[0][2]],.72);
    else{const b=(leader+(count===4?2:1))%count;set(leader,'exchange',poses[b].slice(0,3),.8,b);set(b,'receive',poses[leader].slice(0,3),.6,leader);}
  }else if(program==='relay'){
    const b=(leader+1)%count;set(leader,count===1?'conduct':'exchange',count===1?[poses[0][0]-18,poses[0][1]+13,poses[0][2]]:poses[b].slice(0,3),.78,count===1?null:b);
  }else if(program==='curious'){
    const side=event.cycle%2?-1:1,patch=[side*32,-20+(event.cycle%3)*16,1];
    move(leader,[side*88,-39+(event.cycle%3)*19,.95]);set(leader,'inspect',patch);
    if(count===2){const keeper=1-leader;move(keeper,[-side*108,-29,-.25],.38);set(keeper,'watch',[0,0,0],.23);}
    if(count===3)for(let i=0;i<count;i++)if(i!==leader)move(i,[(i===((leader+1)%count)?-1:1)*103,32,i===((leader+1)%count)?-.3:.6],.24);
    if(count===4){const partner=(leader+1)%4;move(partner,[side*111,9,.8],.48);set(partner,'observe',poses[leader].slice(0,3),.32,leader);}
  }else if(program==='social'){
    if(count===1){move(0,[97,-39,.8],.42);set(0,'observe',[27,-8,.7]);}
    else{
      const a=count===4?((event.cycle%2+2)%2)*2:leader,b=(a+1)%count,side=event.cycle%2?-1:1;
      move(a,[side*112,-37,.85]);move(b,[side*116,0,.85]);
      set(a,'exchange',poses[b].slice(0,3),1,b);set(b,'receive',poses[a].slice(0,3),.78,a);
      if(count===3){const watcher=(b+1)%3;move(watcher,[-side*105,14,-.3],.35);set(watcher,'watch',[0,-4,0],.2);}
      if(count===4)for(let i=0;i<4;i++)if(i!==a&&i!==b)move(i,[-side*107,i%2?25:-43,i%2?.8:-.5],.38);
    }
  }else if(program==='escort'){
    for(let i=0;i<count;i++){
      const side=count===1?1:(i<count/2?-1:1),row=count<3?0:i%2;
      move(i,[side*(108+row*8),-31+row*59,row?.85:-.65],.52);
      set(i,i===leader?'observe':'watch',[0,-12,0],i===leader?.55:.2);
    }
  }else if(program==='vigil'){
    const side=poses[leader][0]<0?-1:1;
    move(leader,[side*118,-15,.8],.48);set(leader,'watch',[(reference[leader][0]<0?-1:1)*48,-31,.7]);
    if(count>1)set((leader+1)%count,'observe',poses[leader].slice(0,3),.25,leader);
  }else set(leader,'observe',[0,-18,0],.22);
  return {poses,intents,focusTargets};
}
/** Pure sampler used unchanged by the HUD preview and production renderer.
 * All original names/count choices remain; optional attention is additive. */
export function sampleCompactFormation(count=4,program='orbit',time=0,{radius=1,strength=.75,animated=true,personality=.35,passiveEffects=true,behaviour={},stations=COMPACT_BIT_IDS,v7=null}={}){
  count=Math.max(1,Math.min(4,Math.round(finite(count,4))));radius=Math.max(.4,Math.min(1.6,finite(radius,1)));strength=unit(finite(strength));
  personality=unit(finite(personality,.35));const live=animated&&strength>0,clock=live?finite(time):0;
  const displayOffsets=Array.from({length:count},(_,i)=>[0,live?strength*2.5*Math.sin(clock*.7+i)/radius:0,0]);
  if(v7&&(v7.enabled===false||v7.formations===false)&&Object.hasOwn(V7_BIT_PROGRAMS,program))program='orbit';
  const enhancedMotion=v7?.enabled===true&&v7.formations!==false,params={stations,personality,behaviour,animated:live,displayOffsets,enhancedMotion};
  const {poses,intents,activities=[],tools=[],focusTargets=[]}=Object.hasOwn(V7_BIT_PROGRAMS,program)?sampleV7BitScene(count,program,clock,params):Object.hasOwn(LIVING_BIT_PROGRAMS,program)?sampleLivingScene(count,program,clock,params):companionScene(count,program,clock,personality,live,displayOffsets,enhancedMotion);
  return stations.slice(0,count).map((station,i)=>{
    const p=poses[i],a=animated?strength:0,intent=intents[i];
    const x=p[0]*radius,y=p[1]*radius+(live?a*2.5*Math.sin(clock*.7+i):0),z=p[2];
    // v10 formations give depth a stronger read: a bit passing in front of her
    // is a touch larger and fully lit, one swinging behind is smaller and dimmer.
    const zc=Math.max(-1,Math.min(1,z)),near=enhancedMotion?Math.sign(zc)*Math.abs(zc)**.8:zc;
    return {station,x,y:y+15,z,angle:p[3]*(.3+.7*a),scale:enhancedMotion?1+near*.14:1+z*.065,
      brightness:(enhancedMotion?.9+.1*near:.94+.06*z)+(intent?.amount??0)*.08,
      activity:activities[i]?{...activities[i],amount:activities[i].amount*strength}:null,tool:passiveEffects!==false&&tools[i]?{...tools[i],amount:tools[i].amount*strength}:null,
      focus:focusTargets[i]?{...focusTargets[i],target:[focusTargets[i].target[0]*radius,focusTargets[i].target[1]*radius+15,focusTargets[i].target[2]]}:null,
      intent:intent?{...intent,amount:intent.amount*strength,passive:passiveEffects!==false,
        target:[intent.target[0]*radius,intent.target[1]*radius+15,intent.target[2]]}:null};
  });
}
/** A program change interpolates complete layouts at one common clock. Pauses
 * in either choreography are preserved; angles follow the shortest rotation.
 * Optional fromPoses permits an interrupted transition to continue exactly. */
function blendPoses(from,target,blend){
  return target.map(p=>{
    const a=from.find(q=>q.station===p.station)??p,out={...p};
    for(const key of NUMERIC_FIELDS)out[key]=key==='angle'?angleBlend(a[key],p[key],blend):lerp(a[key],p[key],blend);
    const fade=ease((blend-.55)/.45),oldFade=1-ease(blend/.45);
    out.intent=fade>0&&p.intent?{...p.intent,amount:p.intent.amount*fade}:oldFade>0&&a.intent?{...a.intent,amount:a.intent.amount*oldFade}:null;
    out.tool=fade>0&&p.tool?{...p.tool,amount:p.tool.amount*fade}:oldFade>0&&a.tool?{...a.tool,amount:a.tool.amount*oldFade}:null;
    const activity=blend<.5?a.activity:p.activity;out.activity=activity?{...activity,amount:activity.amount*(blend<.5?oldFade:fade)}:null;
    out.focus=blend<.5?a.focus:p.focus;
    return out;
  });
}
function transitionAccents(poses,from,target,progress,options,seed){
  if(options.v7?.enabled!==true||options.v7.transitionVariants!==true||options.animated===false||options.strength===0)return poses;
  const accentProgress=options.v7.formations!==false?flowBlend(progress):progress;
  return poses.map((pose,index)=>{
    const a=from.find(p=>p.station===pose.station),b=target.find(p=>p.station===pose.station);
    if(!a||!b)return pose;
    const side=a.x*b.x>0?Math.sign(a.x):0;
    // Keep the existing accent and its physical lane, but let it enter and
    // leave with zero acceleration instead of kicking the housing at a join.
    const accent=sampleV7TransitionAccent(accentProgress,{seed,kind:'formation',index,count:poses.length,side,strength:Math.min(.7,options.strength??.75)});
    return {...pose,x:pose.x+accent.x,y:pose.y+accent.y,z:pose.z+accent.z,angle:pose.angle+accent.angle};
  });
}
/** Four-bit exchange hands two upper attendants into a shared shoulder lane.
 * When their vertical order reverses, the ascending attendant passes outside
 * its partner. This authored passage changes no station, endpoint, depth or
 * duration; it is deliberately not a global separation solver. Cubic edge
 * factors retain the captured velocity and acceleration at both ends. */
function quietConversationPass(poses,from,target,p,{fromProgram,program,count,fromCount,refined,animated,radius=1}){
  if(!refined||animated===false||count!==4||fromCount!==4||fromProgram!=='quietExchange'||program!=='social'||p<=0||p>=1)return poses;
  const a=from.find(q=>q.station==='leftUpper'),b=from.find(q=>q.station==='rightUpper');
  const endA=target.find(q=>q.station==='leftUpper'),endB=target.find(q=>q.station==='rightUpper');
  if(!a||!b||!endA||!endB||(a.y-b.y)*(endA.y-endB.y)>=0)return poses;
  const side=Math.sign(a.x),r=Math.max(.1,finite(radius,1));
  if(!side||a.x*b.x<=0||endA.x*endB.x<=0||Math.sign(endA.x)!==side||Math.abs(a.x-b.x)>20*r)return poses;
  const passing=a.y>b.y?a.station:b.station,envelope=64*p*p*p*(1-p)*(1-p)*(1-p);
  for(const pose of poses)if(pose.station===passing)pose.x+=side*26*r*envelope;
  return poses;
}
const flowSchedules=new Map(),FLOW_SCHEDULE_LIMIT=64;
const pendingFlowSchedules=new Map();let flowIdleTask=null;
/** Preparation has no repeating timer. A busy browser can leave work queued;
 * sampling always finishes the exact prefix it needs before showing a pose. */
function queueFlowPreparation(signature,schedule){
  if(schedule.steps.length>=schedule.pool.length)return;
  pendingFlowSchedules.set(signature,schedule);
  if(flowIdleTask||typeof globalThis.requestIdleCallback!=='function'||globalThis.document?.hidden===true)return;
  const cancel=typeof globalThis.cancelIdleCallback==='function'?globalThis.cancelIdleCallback.bind(globalThis):null;
  flowIdleTask={id:globalThis.requestIdleCallback(deadline=>{
    flowIdleTask=null;
    if(globalThis.document?.hidden===true)return;
    // One pool link is the indivisible exact solver unit. Never begin one in
    // a short idle window, and never drain a whole sixteen-family circuit.
    if(deadline.timeRemaining()>=8){
      const next=pendingFlowSchedules.entries().next().value;
      if(next){const [key,entry]=next;pendingFlowSchedules.delete(key);
        if(flowSchedules.get(key)===entry&&entry.steps.length<entry.pool.length){
          prepareFlowSteps(entry,entry.steps.length+1);
          if(entry.steps.length<entry.pool.length)pendingFlowSchedules.set(key,entry);
        }
      }
    }
    const next=pendingFlowSchedules.entries().next().value;
    if(next)queueFlowPreparation(...next);
  }),cancel};
}
/** Scene teardown cancels optional work; cached exact orders remain reusable. */
export function cancelCompactFlowPreparation(){
  if(flowIdleTask){flowIdleTask.cancel?.(flowIdleTask.id);flowIdleTask=null;}
  pendingFlowSchedules.clear();
}
function permutations(values){
  if(values.length<2)return [values];
  return values.flatMap((v,i)=>permutations(values.filter((_,j)=>i!==j)).map(p=>[v,...p]));
}
const slotPermutations=Object.freeze([[],...Array.from({length:4},(_,i)=>permutations(Array.from({length:i+1},(_,j)=>j)))]);
const composeSlots=(first,next)=>next.map(slot=>first[slot]);
function repeatSlots(slots,times){
  let result=slots.map((_,i)=>i),power=slots;
  while(times>0){if(times%2===1)result=composeSlots(result,power);power=composeSlots(power,power);times=Math.floor(times/2);}
  return result;
}
const flowBlend=p=>p*p*p*(10+p*(-15+6*p));
function flowPathCrossings(frames){
  let crossings=0;const signs=new Map();
  for(const poses of frames)for(const p of poses){
    if(Math.abs(p.x)<=2)continue;const sign=Math.sign(p.x),last=signs.get(p.station);
    if(last&&last!==sign)crossings++;signs.set(p.station,sign);
  }
  return crossings;
}
/** Matching needs only position and physical identity. Avoid constructing nine
 * fully decorated pose blends for every candidate permutation: their tools,
 * activities and attention targets cannot change a passage's matching score. */
function flowCandidateCost(fromFrames,targetFrames,candidate,ownCrossings){
  const inverse=[];for(let i=0;i<candidate.length;i++)inverse[candidate[i]]=i;
  const from=fromFrames[0],target=targetFrames.at(-1);let crossing=0,inversions=0,distance=0;
  for(let i=0;i<from.length;i++){
    const p=from[i],q=target[inverse[i]];
    if(p.x*q.x<0&&Math.min(Math.abs(p.x),Math.abs(q.x))>2)crossing++;
    distance+=(p.x-q.x)**2+(p.y-q.y)**2+((p.z-q.z)*24)**2;
  }
  for(let i=0;i<from.length;i++)for(let j=i+1;j<from.length;j++){
    const dx=from[j].x-from[i].x,next=target[inverse[j]].x-target[inverse[i]].x;
    if(dx*next<0&&Math.min(Math.abs(dx),Math.abs(next))>2)inversions++;
  }
  let paths=0;const signs=[];
  for(let j=0;j<fromFrames.length;j++){
    const blend=flowBlend(j/8);
    for(let i=0;i<from.length;i++){
      const x=lerp(fromFrames[j][i].x,targetFrames[j][inverse[i]].x,blend);
      if(Math.abs(x)<=2)continue;
      const sign=Math.sign(x);if(signs[i]&&signs[i]!==sign)paths++;signs[i]=sign;
    }
  }
  return crossing*1e10+inversions*1e7+distance+Math.max(0,paths-ownCrossings)*1e8;
}
/** Visit clocks repeat with the pool. Each arriving formation starts at its
 * visit phase and then advances normally through its hold and departure.
 * A phase reset at the pool wrap happens only inside the existing crossfade,
 * so the assignment schedule and the geometry it matches genuinely repeat.
 * Outside Flow, sampleCompactFormation retains its original absolute clock.
 */
function flowVisitClock(program,time,options,state){
  const flow=options.flow,pool=flow.pool,hold=Math.max(8000,Math.min(180000,flow.hold??30000)),duration=Math.max(800,Math.min(8000,flow.duration??2600)),period=hold+duration;
  const rate=options.flowClockRate??1,now=options.now??time*1000,offset=Math.round((time-now/1000*rate)*1e6)/1e6,epoch=flow.epoch??0,anchor=epoch/1000*rate+offset,part=state.cycle%pool.length;
  const elapsed=Math.max(0,now-epoch-state.cycle*period),base=anchor+part*period/1000*rate,nextBase=anchor+((part+1)%pool.length)*period/1000*rate;
  return {hold,duration,period,rate,offset,epoch,anchor,part,current:base+elapsed/1000*rate,next:nextBase+(elapsed-hold-duration)/1000*rate};
}
/** A flow owns physical slots, rather than interpreting station names afresh
 * in each family. Match the actual repeating visit phases once, then compose
 * those small permutations. Repeating the circuit is logarithmic after a long
 * reload; it never reassigns instruments halfway through a hold or a passage.
 * Original paths remain intact; only Flow's per-visit phase schedule repeats.
 */
function prepareFlowSteps(schedule,required){
  const {count,pool,start,anchor,hold,duration,period,rate,options,identity}=schedule;
  while(schedule.steps.length<required){
    const i=schedule.steps.length,order=schedule.order;
    const fromProgram=pool[(start+i)%pool.length],toProgram=pool[(start+i+1)%pool.length],base=anchor+i*period/1000*rate,nextBase=anchor+((i+1)%pool.length)*period/1000*rate;
    const fromFrames=Array.from({length:9},(_,j)=>sampleCompactFormation(count,fromProgram,base+(hold+duration*j/8)/1000*rate,{...options,stations:order})),ownCrossings=flowPathCrossings(fromFrames);
    // The twelve companion paths have identity-independent coordinates.
    // Reuse their sampled trajectory and bind its slots to each candidate;
    // living paths retain their identity-specific pace and breathing sample.
    const sharedTargetFrames=Object.hasOwn(LIVING_BIT_PROGRAMS,toProgram)?null:Array.from({length:9},(_,j)=>sampleCompactFormation(count,toProgram,nextBase+(duration*j/8-duration)/1000*rate,{...options,stations:order}));
    let best=identity,cost=Infinity;
    for(const candidate of slotPermutations[count]){
      const stations=candidate.map(slot=>order[slot]),targetFrames=sharedTargetFrames??Array.from({length:9},(_,j)=>sampleCompactFormation(count,toProgram,nextBase+(duration*j/8-duration)/1000*rate,{...options,stations}));
      const score=flowCandidateCost(fromFrames,targetFrames,candidate,ownCrossings);
      if(score<cost-1e-7){cost=score;best=candidate;}
    }
    schedule.steps.push(best);schedule.circuit=composeSlots(schedule.circuit,best);schedule.order=best.map(slot=>order[slot]);
  }
}
function flowSchedule(count,program,time,options,state){
  const ids=(options.stations??COMPACT_BIT_IDS).slice(0,count),flow=options.flow,pool=flow.pool,{hold,duration,period,rate,offset,epoch,anchor}=flowVisitClock(program,time,options,state),start=Math.max(0,pool.indexOf(program));
  const enhancedMotion=options.v7?.enabled===true&&options.v7.formations!==false;
  const signature=JSON.stringify([count,ids,program,pool,hold,duration,epoch,rate,offset,options.radius??1,options.strength??.75,options.personality??.35,options.behaviour??{},enhancedMotion]);
  let schedule=flowSchedules.get(signature);
  if(!schedule){
    const identity=ids.map((_,i)=>i);
    // Keep only pure sampler options: idle work must not retain a token,
    // decorated live snapshot or mutable caller-owned pool/behaviour object.
    const sampling={radius:options.radius,strength:options.strength,animated:options.animated,personality:options.personality,passiveEffects:options.passiveEffects,behaviour:{...options.behaviour},v7:options.v7?{enabled:options.v7.enabled,formations:options.v7.formations}:null};
    schedule={count,pool:[...pool],start,anchor,hold,duration,period,rate,options:sampling,identity,steps:[],circuit:identity,order:[...ids]};flowSchedules.set(signature,schedule);
    if(flowSchedules.size>FLOW_SCHEDULE_LIMIT){const oldest=flowSchedules.keys().next().value;flowSchedules.delete(oldest);pendingFlowSchedules.delete(oldest);}
  }
  return {schedule,signature,ids,pool};
}
/** Command preparation can queue the exact visible schedule before its first
 * rendered frame. It never samples a substitute pose or changes the Flow epoch;
 * a cold renderer still finishes any required prefix before displaying it. */
export function prewarmCompactFlow(count,program,time,options={}){
  count=Math.max(1,Math.min(4,Math.round(finite(count,4))));
  if(options.v7&&(options.v7.enabled===false||options.v7.formations===false)){
    if(Object.hasOwn(V7_BIT_PROGRAMS,program))program='orbit';
    const saved=options.flow;
    if(Array.isArray(saved?.pool)&&saved.pool.some(id=>Object.hasOwn(V7_BIT_PROGRAMS,id)))options={...options,flow:{...saved,pool:saved.pool.filter(id=>!Object.hasOwn(V7_BIT_PROGRAMS,id))}};
  }
  const flow=options.flow;
  if(flow?.enabled!==true||options.animated===false||options.strength===0||!Array.isArray(flow.pool)||flow.pool.length<2)return false;
  const now=options.now??time*1000;if(now<(flow.epoch??0))return false;
  const state=formationFlowState(program,now,flow,true);
  const {signature,schedule}=flowSchedule(count,program,time,{...options,stations:options.stations??options.toStations},state);
  queueFlowPreparation(signature,schedule);return true;
}
function flowStationOrders(count,program,time,options,state){
  const {schedule,signature,ids,pool}=flowSchedule(count,program,time,options,state);
  // Geometry advances every display frame; physical slot ownership changes
  // only at a visit boundary. Reuse that exact small order while this visit
  // remains current, including late reloads and arbitrary clock reversals.
  const cached=schedule.resolvedOrders;
  if(cached?.cycle===state.cycle&&cached.active===state.active){
    if(schedule.steps.length<pool.length)queueFlowPreparation(signature,schedule);
    return cached.orders;
  }
  const laps=Math.floor(state.cycle/pool.length),part=state.cycle%pool.length;
  // During the initial hold the physical identity is already known. Later
  // visits need only their prefix; a repeated circuit or cold late reload
  // still obtains every exact step synchronously before displaying anything.
  prepareFlowSteps(schedule,laps>0?pool.length:part+(state.active?1:0));
  if(schedule.steps.length<pool.length)queueFlowPreparation(signature,schedule);
  else {pendingFlowSchedules.delete(signature);if(!pendingFlowSchedules.size)cancelCompactFlowPreparation();}
  let slots=repeatSlots(schedule.circuit,laps);
  for(let i=0;i<part;i++)slots=composeSlots(slots,schedule.steps[i]);
  const current=slots.map(slot=>ids[slot]),next=state.active?schedule.steps[part].map(slot=>current[slot]):current;
  const orders={current,next};schedule.resolvedOrders={cycle:state.cycle,active:state.active,orders};
  return orders;
}
function orderedFlowPoses(count,program,time,options,stations){
  const ids=(options.stations??COMPACT_BIT_IDS).slice(0,count),poses=sampleCompactFormation(count,program,time,{...options,stations});
  return ids.map(id=>{const p=poses.find(q=>q.station===id),partner=p.intent?.partnerIndex,focusPartner=p.focus?.partnerIndex;
    if(partner==null&&focusPartner==null)return p;
    return {...p,...(partner==null?{}:{intent:{...p.intent,partnerIndex:ids.indexOf(stations[partner])}}),...(focusPartner==null?{}:{focus:{...p.focus,partnerIndex:ids.indexOf(stations[focusPartner])}})};
  });
}
function sampleFlowFormation(count,program,time,options){
  if(options.v7&&(options.v7.enabled===false||options.v7.formations===false)){
    if(Object.hasOwn(V7_BIT_PROGRAMS,program))program='orbit';
    const saved=options.flow;
    if(Array.isArray(saved?.pool)&&saved.pool.some(id=>Object.hasOwn(V7_BIT_PROGRAMS,id)))options={...options,flow:{...saved,pool:saved.pool.filter(id=>!Object.hasOwn(V7_BIT_PROGRAMS,id))}};
  }
  const flow=formationFlowState(program,options.now??time*1000,options.flow,options.animated!==false&&options.strength!==0);
  if(options.flow?.enabled!==true||options.animated===false||options.strength===0||!Array.isArray(options.flow.pool)||options.flow.pool.length<2)return sampleCompactFormation(count,flow.program,time,options);
  if((options.now??time*1000)<(options.flow.epoch??0))return sampleCompactFormation(count,program,time,options);
  const clocks=flowVisitClock(program,time,options,flow),orders=flowStationOrders(count,program,time,options,flow),target=orderedFlowPoses(count,flow.program,flow.active?clocks.next:clocks.current,options,flow.active?orders.next:orders.current);
  if(!flow.active)return target;
  // Quintic crossfade joins both moving choreographies with matching velocity.
  const blend=flowBlend(flow.progress);
  const source=orderedFlowPoses(count,flow.fromProgram,clocks.current,options,orders.current);
  return transitionAccents(blendPoses(source,target,blend),source,target,flow.progress,options,`${options.flow.epoch??0}:${flow.cycle}:${flow.fromProgram}:${flow.program}`);
}
export function sampleCompactTransition(count,program,time,{fromProgram=program,progress=1,fromPoses=null,fromVelocities=null,fromCount=count,fromStations=null,toStations=null,duration=.85,clockRate=1,lanternFlight=null,expressionFlight=null,expressionGain=1,transitionSeed=null,...options}={}){
  count=Math.max(1,Math.min(4,Math.round(finite(count,4))));
  const projecting=bitLanternWeight(lanternFlight??{})>0&&!bitLanternWingFlight(lanternFlight??{}),heldTime=bitLanternPoseClock(lanternFlight),heldNow=bitLanternPoseNow(lanternFlight);
  const heldFlight=projecting?bitLanternHeldFlight(lanternFlight):null;
  let returnPoses=null;
  const expressive=(poses,clock)=>expressionFlight?applyCompactExpression(poses,expressionFlight,clock,expressionGain):poses;
  const lit=(poses,clock,held)=>{
    const shown=expressive(poses,clock);if(!projecting)return shown;
    const anchors=expressionFlight?applyCompactExpression(held,heldFlight,heldTime,expressionGain):held;
    return applyBitLanternGroup(shown,lanternFlight,clock,{anchors,returnPoses});
  };
  const opts={...options,flowClockRate:clockRate,stations:toStations??COMPACT_BIT_IDS},heldOptions={...opts,now:heldNow,
    ...(projecting?{animated:heldFlight.gems.animated,flowClockRate:heldFlight.gems.animated===false?0:heldFlight.gems.speed??1}:{})};
  const returnNow=bitLanternReturnNow(lanternFlight);
  if(projecting&&returnNow!==null){
    const returnTime=time+(returnNow-(options.now??lanternFlight.lantern.clock*1000))/1000*clockRate;
    const ordinary=sampleFlowFormation(count,program,returnTime,{...opts,now:returnNow});
    returnPoses=expressionFlight?applyCompactExpression(ordinary,{...expressionFlight,lantern:undefined,bitFormationNow:returnNow},returnTime,expressionGain):ordinary;
  }
  const target=lit(sampleFlowFormation(count,program,time,opts),time,projecting?sampleFlowFormation(count,program,heldTime,heldOptions):null),p=unit(finite(progress,1));
  const refined=!projecting&&options.v7?.enabled===true&&options.v7.formations!==false,blend=refined?flowBlend(p):ease(p);
  const sourceIds=fromStations??COMPACT_BIT_IDS,targetIds=toStations??COMPACT_BIT_IDS;
  const sameMapping=fromCount===count&&targetIds.slice(0,count).every((id,i)=>sourceIds[i]===id);
  if(blend>=1||fromProgram===program&&fromCount===count&&sameMapping&&!fromPoses)return target;
  const from=fromPoses??lit(sampleCompactFormation(fromCount,fromProgram,time,{...options,stations:fromStations??COMPACT_BIT_IDS}),time,
    projecting?sampleCompactFormation(fromCount,fromProgram,heldTime,{...heldOptions,stations:fromStations??COMPACT_BIT_IDS}):null);
  if(!fromPoses||!fromVelocities){const result=blendPoses(from,target,blend);return projecting?result:transitionAccents(result,from,target,p,options,transitionSeed??`${fromProgram}:${program}:${fromStations??''}:${toStations??''}`);}
  const endTime=time+(1-p)*duration*clockRate,endNow=(options.now??time*1000)+(1-p)*duration*1000;
  const heldTarget=projecting?sampleFlowFormation(count,program,heldTime,heldOptions):null;
  const end=lit(sampleFlowFormation(count,program,endTime,{...opts,now:endNow}),endTime,heldTarget),later=lit(sampleFlowFormation(count,program,endTime+.008*clockRate,{...opts,now:endNow+8}),endTime+.008*clockRate,heldTarget);
  const result=blendPoses(from,target,blend);
  for(const out of result){
    const a=from.find(q=>q.station===out.station),b=end.find(q=>q.station===out.station),c=later.find(q=>q.station===out.station),v=fromVelocities.find(q=>q.station===out.station);
    if(!a||!b||!c)continue;
    for(const key of NUMERIC_FIELDS){
      const delta=key==='angle'?Math.atan2(Math.sin(b[key]-a[key]),Math.cos(b[key]-a[key])):b[key]-a[key];
      const velocity=(key==='angle'?Math.atan2(Math.sin(c[key]-b[key]),Math.cos(c[key]-b[key])):c[key]-b[key])/.008;
      out[key]=smoothIntercept(a[key],a[key]+delta,p,duration,v?.[key]??0,velocity,refined);
    }
  }
  if(projecting){
    const targetVelocities=end.map(b=>{const c=later.find(q=>q.station===b.station);return {station:b.station,x:c?(c.x-b.x)/.008:0,y:c?(c.y-b.y)/.008:0};});
    const arcs=bitLanternHandoffGroup(from,end,lanternFlight,p,{duration,velocities:fromVelocities,targetVelocities});
    for(const out of result)if(arcs.has(out.station))Object.assign(out,arcs.get(out.station));
  }
  if(!projecting&&sameMapping)quietConversationPass(result,from,end,p,{fromProgram,program,count,fromCount,refined,animated:options.animated,radius:options.radius});
  return projecting?result:transitionAccents(result,from,end,p,options,transitionSeed??`${fromProgram}:${program}:${fromStations??''}:${toStations??''}`);
}
/** Sparse passive accents, using ordinary render paths and no textures. These
 * never become active shields or treatments, and leave no permanent tether. */
export function sampleCompactCurrents(poses,{enabled=true,strength=1}={}){
  if(!enabled)return [];const paths=[];
  for(const p of poses??[]){
    const v=p.intent;if(!v?.passive||!(v.amount>.001)||!Array.isArray(v.target))continue;
    const amount=v.amount*unit(strength),target=v.target,progress=v.progress;
    const point=(t,arc=0)=>[lerp(p.x,target[0],t)+Math.sin(Math.PI*t)*arc,
      lerp(p.y,target[1],t),lerp(p.z,target[2],t)*24,.92];
    if(v.kind==='exchange'){
      const travel=ease((progress-.14)/.66);if(travel<=0||travel>=1)continue;
      const start=Math.max(0,travel-.12),points=Array.from({length:8},(_,i)=>point(lerp(start,travel,i/7),5));
      paths.push({id:`companion-exchange-${p.station}`,points,width:.82,strength:amount*.62,highlight:true});
    }else if(v.kind==='inspect'){
      const scan=wrap(progress*1.7),x=target[0],y=target[1]+(scan-.5)*16,z=target[2]*24;
      const points=Array.from({length:9},(_,i)=>{const q=i/8;return [x+(q-.5)*20,y+Math.sin(q*Math.PI)*3,z,.92];});
      paths.push({id:`companion-inspect-${p.station}`,points,width:.56,strength:amount*.34*Math.sin(Math.PI*scan),highlight:false});
    }else if(['mend','canopy','lantern','conduct'].includes(v.kind)){
      const pulse=Math.sin(Math.PI*unit(progress)),width=v.kind==='canopy'?21:v.kind==='lantern'?9:13;
      const points=Array.from({length:13},(_,i)=>{const q=i/12,angle=q*Math.PI;return [target[0]+(q-.5)*width,target[1]-Math.sin(angle)*(v.kind==='canopy'?8:3),target[2]*24,.92];});
      if(v.kind==='mend'||v.kind==='conduct')points.unshift([p.x,p.y,p.z*24,.92]);
      paths.push({id:`companion-${v.kind}-${p.station}`,points,width:.58,strength:amount*.36*pulse,highlight:v.kind!=='canopy'});
    }else if(v.kind==='observe'){
      // A short acknowledgement leaves the housing but fades before reaching
      // the portrait. No new effect covers or obscures the player's token.
      const travel=ease((progress-.3)/.45);if(travel<=0||travel>=1)continue;
      const head=travel*.35,points=Array.from({length:5},(_,i)=>point(Math.max(0,head-.055+i/4*.055),2));
      paths.push({id:`companion-observe-${p.station}`,points,width:.5,strength:amount*.3*Math.sin(Math.PI*travel),highlight:true});
    }
  }
  return paths;
}
const sampleCache=new WeakMap();
/** One count blend per frame, shared by all four instruments and both sides. */
export function sampleCompactStations(flight,time){
  const cfg=flight.gems??{},cached=sampleCache.get(flight);
  if(cached?.time===time)return cached.stations;
  const supplied=!flight.bitHardwareAll&&Array.isArray(flight.bitHomeStations)?flight.bitHomeStations:null;
  const visible=supplied??COMPACT_BIT_IDS.filter((_,i)=>(flight.bitCount?.values?.[i]??(i<(cfg.count??4)?1:0))>.00001);
  const activeIds=[...new Set(visible)].filter(id=>COMPACT_BIT_IDS.includes(id));
  const count=Math.max(1,supplied?activeIds.length:cfg.count??4);
  // Stable identities may occupy any slot: a lone rightLower gets the one-bit
  // formation, rather than disappearing because it used to be slot four.
  const order=[...activeIds,...COMPACT_BIT_IDS.filter(id=>!activeIds.includes(id))];
  const weights=supplied?[0,0,0,0].map((_,i)=>i===count-1?1:0):flight.bitCount?.formationWeights??[0,0,0,0].map((_,i)=>i===count-1?1:0);
  const frames=new Map(),stations={},transition=flight.bitFormationTransition??{};
  const frame=n=>{
    if(!frames.has(n)){
      const projecting=bitLanternWeight(flight)>0&&!bitLanternWingFlight(flight),gain=transition.fromPoses?transition.progress??1:1;
      const sampled=sampleCompactTransition(n,cfg.soloProgram,time,{radius:cfg.soloRadius,strength:cfg.strength,
      animated:cfg.animated,personality:flight.bitSequenceActive&&!supplied?0:cfg.personality,passiveEffects:cfg.passiveEffects,
      behaviour:cfg.behaviour,flow:flight.bitFormationFlow,now:flight.bitFormationNow??time/(cfg.speed??1)*1000,lanternFlight:flight,expressionFlight:projecting?flight:null,v7:flight.v7??cfg.v7,
      expressionGain:gain,
      duration:(transition.duration??850)/1000,clockRate:cfg.animated===false?0:cfg.speed??1,fromVelocities:transition.fromVelocities,
      fromProgram:transition.fromProgram,progress:transition.progress,fromPoses:transition.fromPoses,fromCount:transition.fromCount??n,
      fromStations:transition.fromStations??order.slice(0,transition.fromCount??n),toStations:order.slice(0,n),transitionSeed:transition.seed??`${transition.started??0}:${transition.fromProgram??cfg.soloProgram}:${cfg.soloProgram}`});
      frames.set(n,projecting?sampled:applyCompactExpression(sampled,flight,time,gain));
    }
    return frames.get(n);
  };
  for(const station of COMPACT_BIT_IDS){
    const result={station,x:0,y:0,z:0,angle:0,scale:0,brightness:0,intent:null},activityEntries=[];let total=0,best=0,expressionEnergy=0,hasExpression=false;
    for(let n=1;n<=4;n++){
      const w=weights[n-1]??0;if(w<=.000001)continue;const p=frame(n).find(p=>p.station===station);if(!p)continue;
      total+=w;for(const key of NUMERIC_FIELDS)result[key]+=p[key]*w;
      activityEntries.push({activity:p.activity,weight:w});
      expressionEnergy+=(p.expression?.energy??1)*w;hasExpression||=!!p.expression;
      if(w>best){best=w;result.intent=p.intent;result.focus=p.focus;result.activity=p.activity;result.tool=p.tool;result.expression=p.expression;}
    }
    if(total<.000001){
      // Hidden destinations remain exact when a capture or return explicitly
      // requests them. Ordinary rendering should not prepare larger absent
      // constellations merely to build the visible one-bit or two-bit layout.
      Object.defineProperty(stations,station,{enumerable:true,configurable:true,get(){
        const value=frame(Math.max(count,order.indexOf(station)+1)).find(p=>p.station===station);
        if(Object.getOwnPropertyDescriptor(stations,station)?.configurable)
          Object.defineProperty(stations,station,{value,writable:true,enumerable:true,configurable:true});
        return value;
      }});
    }
    else {
      for(const key of NUMERIC_FIELDS)result[key]/=total;
      if(activityEntries.length>1){
        result.activity=blendCoreActivities(activityEntries.map(entry=>({...entry,weight:entry.weight/total})));
        if(hasExpression)result.expression={...result.expression,energy:expressionEnergy/total};
        // A discrete tool or work target changes only after the previous one
        // has closed. Physical positions and shape channels keep blending.
        const handoff=ease((2*best-total)/total);
        if(result.intent)result.intent={...result.intent,amount:result.intent.amount*handoff};
        if(result.tool)result.tool={...result.tool,amount:result.tool.amount*handoff};
      }
      stations[station]=result;
    }
  }
  if(flight.bitGesturePreview){
    const gesture=flight.bitGesturePreview,ids=order.slice(0,count),initial=sampleCompactFormation(count,cfg.soloProgram,gesture.captureTime??0,{radius:cfg.soloRadius,strength:cfg.strength,animated:cfg.animated,personality:0,stations:ids}),origins=Object.fromEntries(initial.map(p=>[p.station,{x:p.x,y:p.y}])),depths=Object.fromEntries(initial.map(p=>[p.station,p.z])),back=ease(gesture.returnProgress??0);
    const layout=gesture.layout??captureGestureLayout(ids,origins,{x:0,y:15},600/3.5,{depths});
    const sample=sampleWorkGesture(gesture.id,ids,gesture.progress,origins,{x:0,y:15},600/3.5,{energy:gesture.energy??.65,reduced:cfg.animated===false,layout});
    for(const id of ids){const p=stations[id],originAngle=gesture.originRotations?.[id]??initial.find(q=>q.station===id)?.angle??0,angle=gestureOrientation(originAngle,sample.rotations[id],ease(gesture.progress));p.x=lerp(sample.positions[id].x,p.x,back);p.y=lerp(sample.positions[id].y,p.y,back);p.z=lerp(sample.depths[id],p.z,back);p.angle=angleBlend(angle,p.angle,back);p.activity=back<1?sample.coreStates[id]:p.activity;p.tool=back<1?sample.tools[id]:p.tool;p.intent=back<1?sample.intents.find(q=>q.station===id)?.intent??null:p.intent;}
  }
  sampleCache.set(flight,{time,stations});return stations;
}
export function sampleCompactStation(station,flight,time){return sampleCompactStations(flight,time)[station];}
/** Legacy callers retain their exact anchor. Wing workload routing is sampled
 * by wing-station-motion; count must never reinterpret saved coordinates. */
export function countWingStation(station,center,angle,flight){
  return {center,angle};
}

/** Display-rate compact placement without rebuilding solid machinery. Input
 * time is the already speed-adjusted formation clock in seconds. The deployment
 * equations match the physical compact branch of choreographedGems exactly. */
export function compactGeometryPlacement(station,flight,time){
  const cfg=flight.gems??{},pose=sampleCompactStation(station,flight,time),side=station.startsWith('left')?-1:1,index=station.endsWith('Lower')?1:0;
  const growth=flight.formation?.growth??1,fold=flight.formation?.fold??0,formed=ease((growth-(index?.07:0))/(index?.93:1));
  const stationIndex=COMPACT_BIT_IDS.indexOf(station),countWeight=flight.bitCount?.values?.[stationIndex]??(stationIndex<(cfg.count??4)?1:0);
  const globalDeployment=unit(flight.bitDeployment??1),launchDelay=flight.bitTransition?.active?stationIndex*.045:0;
  const bitDeployment=unit((globalDeployment-launchDelay)/(1-launchDelay))*unit(countWeight);
  const deployment=formed*(1-ease(fold))*unit(flight.stabilizerDeployment??1)*bitDeployment;
  const root=[side*27,-23+index*18,-28],dest=[pose.x,pose.y,pose.z*24];
  const center=root.map((v,i)=>lerp(v,dest[i],deployment)),launch=Math.sin(Math.PI*deployment);
  center[0]+=side*launch*(10+index*3);center[1]+=(index?1:-1)*launch*12;
  center[0]=Math.max(-257,Math.min(257,center[0]));center[1]=Math.max(-231,Math.min(265,center[1]));
  const visibility=ease(bitDeployment/.16),recallScale=.16+.84*ease(bitDeployment/.42);
  const shown=applyBitLanternMountingPose({station,x:center[0],y:center[1],z:center[2],angle:pose.angle,scale:recallScale*pose.scale},flight,station);
  return {center:[shown.x,shown.y,shown.z],angle:shown.angle,scale:.76*(cfg.size??1)*shown.scale,strength:ease(growth/.06)*visibility*pose.brightness,intent:pose.intent??{amount:0}};
}
