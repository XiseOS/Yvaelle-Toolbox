import {setLightUniform} from './light-shader-binding.mjs?v=13.0.0-beta.7';
import {hash} from './conditions.mjs?v=13.0.0-beta.7';

/** A material detail inside the native coloration pass. It is independent of
 * aim: moving the lantern reveals another part of a changing caustic field,
 * rather than turning a projected picture. No bitmap, light source, network
 * write, source polygon or visibility mask belongs to this effect. */
export const V7_REFRACTION_PERIOD=112;
export const V7_REFRACTION_UNIFORMS=Object.freeze(['ffV7Refraction','ffV7RefractionPhase','ffV7RefractionSeed','ffV7RefractionVariation','ffV7RefractionMotion','ffV7RefractionEnvelope','ffV7RefractionShutdown','ffV7RefractionDisruption','ffV7RefractionRecovery','ffV7RefractionDetail']);
const TAU=Math.PI*2;
const finite=(value,fallback=0)=>Number.isFinite(value)?value:fallback;
const unit=value=>Math.max(0,Math.min(1,finite(value)));
const modulo=(value,period)=>(value%period+period)%period;
// Cache only immutable string identities, never snapshot/configuration objects.
// A bounded FIFO prevents arbitrary scene or action IDs accumulating forever.
const identityHashes=new Map(),IDENTITY_LIMIT=128;
function lightIdentity(value){
  const key=String(value),hit=identityHashes.get(key);
  if(hit!==undefined)return hit;
  const result=hash(key);
  if(identityHashes.size>=IDENTITY_LIMIT)identityHashes.delete(identityHashes.keys().next().value);
  identityHashes.set(key,result);return result;
}
const uncomment=source=>source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,part=>part.replace(/[^\n]/g,' '));

/** Saved action epochs select a repeatable assembly variation for every
 * observer. Native material and health channels remain bounded and local. */
export function sampleV7LightRefraction(snapshot={},config={},now=0,{seed='flight'}={}){
  const v7=snapshot.v7??{},master=v7.enabled??config.v7Enabled??false;
  const selected=v7.refraction??config.v7Refraction??false;
  const strength=unit(v7.refractionStrength??config.v7RefractionStrength??.55)*unit(snapshot.effective?.intensity??1);
  const enabled=master&&selected&&strength>0&&config.localEffects!==false&&config.effectsEnabled!==false;
  if(!enabled)return {enabled:false,strength:0};
  const reduced=config.reduced===true||snapshot.effective?.reducedMotion===true;
  const detail=snapshot.quality?.effectDetail??config.quality?.effectDetail??config.effectDetail??'high';
  const motion=reduced?0:detail==='low'?.32:detail==='medium'?.7:1;
  const lamp=snapshot.lantern,hasLantern=lamp?.active===true||lamp?.enabled===true||lamp?.shuttingDown===true;
  // An interrupted on/off/re-on sequence is one assembly episode. The
  // activation epoch remains saved through its return and only changes on a
  // genuinely new activation; a toggle's changed timestamp must not choose
  // another discrete front halfway through the displayed assembly.
  const action=(hasLantern?snapshot.requested?.lantern?.started??lamp.started??snapshot.requested?.lantern?.changed??lamp.changed:v7.lightActionEpoch)??v7.episodeKey??v7.actionEpoch??snapshot.transition?.started??snapshot.started??0;
  const identity=lightIdentity(`${seed}:${String(action)}:refraction`),phaseIdentity=(lightIdentity(`${seed}:material`)%1009)/1009*TAU;
  // Integer phase harmonics wrap exactly; reduction lowers motion amplitude
  // rather than changing the phase clock and introducing a comfort-mode seam.
  const phase=reduced?0:modulo(finite(now)/1000,V7_REFRACTION_PERIOD)*TAU/V7_REFRACTION_PERIOD;
  const envelope=hasLantern?unit(lamp.transition??1):unit(v7.lightEnvelope??1);
  const body=unit(lamp?.body??lamp?.weight??1),power=unit(lamp?.beamWeight??lamp?.weight??1),withdrawal=unit((body-power)*2);
  // The supply body and emitted power are continuous lifecycle channels.
  // Their separation quietly relaxes the front while the supply withdraws,
  // avoiding a coefficient flip on interruption or reactivation.
  const shutdown=reduced?0:hasLantern?withdrawal*withdrawal*(3-2*withdrawal):0;
  return {enabled:true,strength,phase,seed:phaseIdentity,variation:v7.transitionVariants===false?0:identity%3,
    envelope:reduced?1:envelope,shutdown,motion,detail:detail==='low'?0:1};
}

export function v7RefractionUniforms(sample={},effects={},storage=null){
  const values=storage??{};
  values.ffV7Refraction=sample.enabled?unit(sample.strength):0;
  values.ffV7RefractionPhase=finite(sample.phase);
  // Only the transient front reads the integer action variation.
  values.ffV7RefractionSeed=finite(sample.seed);values.ffV7RefractionVariation=unit(sample.variation/2);
  values.ffV7RefractionMotion=unit(sample.motion);values.ffV7RefractionEnvelope=unit(sample.envelope??1);
  values.ffV7RefractionShutdown=unit(sample.shutdown);values.ffV7RefractionDisruption=unit(effects.disruption);
  values.ffV7RefractionRecovery=unit(effects.recovery);values.ffV7RefractionDetail=unit(sample.detail??1);
  return values;
}

export function setV7RefractionUniforms(shader,sample,effects={},record=null){
  if(record)record.refractionValues??={};
  const values=v7RefractionUniforms(sample,effects,record?.refractionValues);
  for(const name of V7_REFRACTION_UNIFORMS){
    if(record&&!record.uniforms.has(name))record.uniforms.set(name,{exists:Object.hasOwn(shader.uniforms,name),value:shader.uniforms[name]});
    setLightUniform(shader,name,values[name]);
  }
}

export function releaseV7RefractionUniforms(shader,record){
  for(const name of V7_REFRACTION_UNIFORMS)if(record.uniforms.has(name)){
    const prior=record.uniforms.get(name);if(prior.exists)shader.uniforms[name]=prior.value;else delete shader.uniforms[name];record.uniforms.delete(name);
  }
}

const functions=`
float ffV7RefractionLine(float value,float width){return exp(-value*value/(width*width));}
float ffV7RefractionField(vec2 point,float phase,float seed){
  // Two smooth lenses deform one another. Their interference grows, divides
  // and relaxes locally; there is no polar angle, texture rotation or solid
  // repeating decal. Even the fastest deformation takes nine seconds.
  float a=phase*7.0+seed,b=phase*5.0-seed;
  vec2 bend=vec2(sin(point.y*3.1+a),sin(point.x*2.7-b))*0.11*ffV7RefractionMotion;
  vec2 p=point+bend;
  float broad=sin(p.x*4.0+0.46*sin(p.y*3.0-b)*ffV7RefractionMotion)+sin(p.y*3.3+0.37*cos(p.x*2.2+a)*ffV7RefractionMotion);
  float curveA=ffV7RefractionLine(broad-0.28*sin(a)*ffV7RefractionMotion,0.16);
  float curveB=ffV7RefractionLine(sin(p.x*3.4-p.y*2.8+0.33*cos(b)*ffV7RefractionMotion)+0.58*sin(p.y*4.1+0.29*sin(a)*ffV7RefractionMotion),0.12);
  float packet=mix(0.68,0.30+0.70*pow(0.5+0.5*sin(p.x*2.9+p.y*3.7-phase*9.0+seed),2.0),ffV7RefractionMotion);
  return (curveA+curveB*0.64*ffV7RefractionDetail)*packet;
}
`;

/** Disable/zero uses no shader transformation at all. Background and
 * illumination are returned byte-for-byte; already-clipped magenta coloration
 * alone receives restrained concentrations with its existing alpha intact. */
export function v7RefractionFragment(fragment,layer='coloration'){
  if(typeof fragment!=='string'||!['background','illumination','coloration'].includes(layer))return null;
  if(layer!=='coloration')return fragment;
  const inspected=uncomment(fragment),mains=[...inspected.matchAll(/\bvoid\s+main\s*\(\s*(?:void\s*)?\)\s*\{/g)],outputs=[...inspected.matchAll(/\bgl_FragColor\s*=\s*([^;]+);/g)];
  if(mains.length!==1||outputs.length!==1||inspected.includes('ffV7Refraction')||! /\bvarying\s+(?:(?:highp|mediump|lowp)\s+)?vec2\s+vUvs\s*;/.test(inspected))return null;
  const main=mains[0],output=outputs[0],start=main.index+main[0].length;
  let nesting=1,end=start;for(;end<inspected.length&&nesting;end++){if(inspected[end]==='{')nesting++;else if(inspected[end]==='}')nesting--;}
  if(nesting||output.index<start||output.index>=end)return null;
  const uniforms=V7_REFRACTION_UNIFORMS.map(name=>`uniform float ${name};\n`).join('')+functions;
  const expression=fragment.slice(inspected.indexOf('=',output.index)+1,output.index+output[0].length-1);
  const result=`vec4 ffV7RefractionOutput=${expression};
  if(ffV7Refraction>0.0){
    vec2 ffV7RefractionPoint=(vUvs-vec2(0.5))*2.0;
    float ffV7RefractionRadius=length(ffV7RefractionPoint);
    float ffV7RefractionTaper=smoothstep(0.04,0.18,ffV7RefractionRadius)*(1.0-smoothstep(0.72,0.98,ffV7RefractionRadius));
    float ffV7RefractionCaustic=ffV7RefractionField(ffV7RefractionPoint,ffV7RefractionPhase,ffV7RefractionSeed);
    float ffV7RefractionAssembly=1.0-smoothstep(0.80,1.0,ffV7RefractionEnvelope);
    float ffV7RefractionFront=ffV7RefractionLine(ffV7RefractionRadius-(0.10+0.75*ffV7RefractionEnvelope),0.12+0.045*ffV7RefractionVariation);
    ffV7RefractionFront*=mix(1.0,0.65+0.35*sin(ffV7RefractionPoint.x*3.0+ffV7RefractionSeed),ffV7RefractionVariation);
    float ffV7RefractionResponse=1.0-ffV7RefractionDisruption*0.55;
    float ffV7RefractionConcentration=ffV7RefractionCaustic*(0.20+0.02*ffV7RefractionRecovery);
    ffV7RefractionConcentration+=ffV7RefractionFront*ffV7RefractionAssembly*(0.12-0.035*ffV7RefractionShutdown);
    float ffV7RefractionGain=1.0+ffV7Refraction*ffV7RefractionTaper*ffV7RefractionResponse*(ffV7RefractionConcentration-0.072);
    ffV7RefractionOutput.rgb=min(max(vec3(0.0),ffV7RefractionOutput.rgb*ffV7RefractionGain),vec3(ffV7RefractionOutput.a));
  }
  gl_FragColor=ffV7RefractionOutput;`;
  return fragment.slice(0,main.index)+uniforms+fragment.slice(main.index,output.index)+result+fragment.slice(output.index+output[0].length);
}
