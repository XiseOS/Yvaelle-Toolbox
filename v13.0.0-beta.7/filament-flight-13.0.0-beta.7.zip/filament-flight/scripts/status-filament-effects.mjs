/** Automatic energy treatments on the supplied wing material. Body shape,
 * poses, gameplay, manual forms and HP cutting belong to their existing owners.
 * The separate FX clock permits cosmetic paralysis crackles on a held body.
 */
import {PHYSICAL_ORIGINAL_EFFECT_IDS,originalPhysicalStatusAccents} from './status-original-physical.mjs?v=13.0.0-beta.7';
import {SENSORY_ORIGINAL_EFFECT_IDS,originalSensoryStatusAccents} from './status-original-sensory.mjs?v=13.0.0-beta.7';
import {ARCANE_ORIGINAL_EFFECT_IDS,originalArcaneStatusAccents} from './status-original-arcane.mjs?v=13.0.0-beta.7';

export const STATUS_FILAMENT_EFFECT_IDS=Object.freeze([...PHYSICAL_ORIGINAL_EFFECT_IDS,...SENSORY_ORIGINAL_EFFECT_IDS,...ARCANE_ORIGINAL_EFFECT_IDS]);
const ids=new Set(STATUS_FILAMENT_EFFECT_IDS),MAX_ACCENTS=80;
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const unit=n=>Math.max(0,Math.min(1,finite(n)));
const families=new Map([
  ...PHYSICAL_ORIGINAL_EFFECT_IDS.map(id=>[id,originalPhysicalStatusAccents]),
  ...SENSORY_ORIGINAL_EFFECT_IDS.map(id=>[id,originalSensoryStatusAccents]),
  ...ARCANE_ORIGINAL_EFFECT_IDS.map(id=>[id,originalArcaneStatusAccents])
]);
export const STATUS_FILAMENT_EFFECT_LABELS=Object.freeze({
  paralyzed:'Suspended crackle',petrified:'Crystalline locks',restrained:'Binding bands',immobilized:'Root cinches',grabbed:'Tension anchors',
  enfeebled:'Yielding channels',drained:'Ebbing returns',encumbered:'Load braces',clumsy:'Misaligned relays',slowed:'Delayed currents',
  quickened:'Accelerating routes',fleeing:'Retreat currents',frightened:'Restless guard',wounded:'Repair stitches',fatigued:'Weighted recovery',prone:'Resting currents',
  blinded:'Searching feedback',dazzled:'Diffused glints',deafened:'Quiet resonance',sickened:'Queasy returns',stupefied:'Failing relays',
  confused:'Contrary circuits',fascinated:'Convergent light','off-guard':'Exposed guard',concealed:'Passing veil',invisible:'Fine refraction',
  hidden:'Close concealment',undetected:'Shadow tracing',unnoticed:'Dormant signals',controlled:'Command cadence',cursebound:'Ratcheting ties',
  malevolence:'Haunted counterflow',doomed:'Terminal returns',dying:'Failing root relays',dead:'Extinguished channels',
  'persistent-damage':'Typed injury currents',glitching:'Interrupted signals',suppressed:'Protective waves',untethered:'Weightless currents'
});
const descriptions={
  paralyzed:'Local electrical forks crackle along held original ribs without moving their structure.',petrified:'Still crystalline seams lock the existing filaments in place.',
  restrained:'Crossed bands cinch and release across the existing web.',immobilized:'Shoulderward channels gather into local root bindings.',grabbed:'Taut anchor currents pull light through the existing tip channels.',
  enfeebled:'Weak supporting channels yield softly while the original span remains recognizable.',drained:'Thin return currents carry diminishing light shoulderward.',encumbered:'Load-bearing braces and hanging currents carry the original wing’s weight.',
  clumsy:'Small relay alignments correct out of sequence along the original ribs.',slowed:'Delayed packets hold and release along existing channels.',quickened:'Successive routed charges accelerate through the existing fan.',
  fleeing:'Purposeful retreat currents stream through the original outer spars.',frightened:'Restless guard currents tremble locally across the existing membrane.',wounded:'Visible repair stitches tension along the original surviving web.',
  fatigued:'Gentle support loops accompany familiar, usable wings with weighted recovery.',prone:'Quiet draping currents remain on the original grounded lattice.',
  blinded:'Searching feedback fronts sweep across existing spars and return shoulderward.',dazzled:'Soft overlapping glints diffuse locally through the original fan.',deafened:'Open resonance links retain a quiet interrupted signal.',
  sickened:'Uneven rolling returns follow existing membrane channels.',stupefied:'Separated relay stitches lose and recover their signal.',confused:'Unpaired currents wander through contrary routes on the original web.',
  fascinated:'Coherent channels converge toward a restrained focus within the original wing.',
  'off-guard':'A local middle guard dims while its exposed seam carries an unseated return.',concealed:'A bowed translucent veil travels through the existing membrane.',
  invisible:'Fine coherent refraction dims internal lace while preserving a readable original outline.',hidden:'Quiet close channels conceal light without changing the original structure.',
  undetected:'Low shadow currents return slowly along the existing filaments.',unnoticed:'Dormant root charges remain small and measured on the original wing.',
  controlled:'Synchronized command charges impose a borrowed cadence on existing ribs.',cursebound:'Interlocking ritual ties ratchet across the original membrane.',malevolence:'Haunted channels intrude and return against the original energy flow.',
  doomed:'Outer channels unthread into faint terminal returns without changing flight rules.',dying:'Sparse failing relays remain inside the already collapsed original lattice.',dead:'Quiet extinguished links leave only a faint residual signal in the broken lattice.',
  'persistent-damage':'Damage-type-specific heat, rime, arcs and erosion travel through the original surviving material.',glitching:'Sequential signal faults interrupt local relays without replacing the original wing.',
  suppressed:'Protective recoil waves pass through the existing guard channels.',untethered:'Slow weightless currents drift through the original ribs without inventing propulsion.'
};
export const STATUS_FILAMENT_EFFECT_DESCRIPTIONS=Object.freeze(descriptions);

const canonicalTypes=raw=>{
  const aliases={electric:'electricity',lightning:'electricity',negative:'void',positive:'vitality'},out=[];
  for(const value of Array.isArray(raw)?raw:[]){
    const type=typeof value==='string'?value:value?.type??value?.damageType;
    if(typeof type!=='string')continue;
    const key=type.toLowerCase().trim(),id=aliases[key]??key;
    if(!out.includes(id))out.push(id);if(out.length===3)break;
  }
  return out.length?out:['untyped'];
};
const collapseState=response=>({phase:response?.collapse?.phase??'awake',mix:unit(response?.collapse?.mix??0),
  progress:unit(response?.collapse?.progress??1),reformProgress:unit(response?.collapse?.reformProgress??1)});
const present=(response,id)=>{
  const entry=response?.active?.find(e=>e.id===id),rule=response?.config?.conditions?.[id];
  if(!entry||entry.style==='none'||rule?.enabled===false||rule?.style==='none'||rule?.strength===0)return false;
  return (response?.levels?.[id]??entry.strength??0)>.001;
};

/** The body clock can be held while the explicitly permitted paralysis FX
 * clock continues. Severe stun and petrification retain their held FX frame;
 * explicit motion/animation opt-outs use a deterministic static frame.
 */
export function sampleStatusFilamentEffects(response,profile={},config={}){
  const motion=config.filamentInstability===false?0:Math.max(0,Math.min(2,finite(config.conditionMotionStrength,1)));
  const speed=Math.max(0,finite(config.conditionAnimationSpeed,1));
  const collapse=collapseState(response),sparks=config.conditionSparks!==false;
  const strengths={},severities={};
  const enabled=!!(response?.wings&&response.enabled!==false&&config.visualConditions!==false&&config.enhancedConditions!==false);
  if(enabled)for(const entry of response.active??[]){
    const id=entry.id,rule=response.config?.conditions?.[id],style=rule?.style??entry.style??'default';
    if(!ids.has(id)||style!=='default'||rule?.enabled===false||rule?.strength===0||id==='paralyzed'&&!sparks)continue;
    if(['falling','fallen'].includes(collapse.phase)&&!['dying','dead'].includes(id)||collapse.phase==='recovering'&&!['prone','dying','dead'].includes(id))continue;
    const strength=unit(response.levels?.[id]??entry.strength??rule?.strength??.6);
    if(strength<=.001)continue;
    strengths[id]=strength;severities[id]=Math.max(1,Math.min(4,finite(response.rawLevels?.[id],finite(entry.value,1))));
  }
  const active=Object.keys(strengths).length>0;
  const rawStun=finite(response?.rawLevels?.stunned,finite(response?.targetLevels?.stunned));
  const held=present(response,'stunned')&&rawStun>=2.999||present(response,'petrified');
  const reduced=response?.reduced||config.reduced||config.reducedMotion;
  const deadSettled=present(response,'dead')&&collapse.progress>=1;
  const animated=active&&!held&&!reduced&&!deadSettled&&profile.animated!==false&&motion>0&&speed>0;
  const heldTime=Math.max(0,finite(profile.conditionFrozenTime,finite(profile.effectTime,finite(profile.time))));
  // fxTime is fresh unscaled elapsed time; effectTime and conditionFrozenTime
  // already carry the body's configured speed and must not be scaled twice.
  const liveTime=Number.isFinite(response?.fxTime)?response.fxTime*speed:finite(profile.effectTime,finite(profile.time)*speed);
  const time=animated?Math.max(0,liveTime):held&&!reduced&&!deadSettled&&profile.animated!==false&&motion>0&&speed>0?heldTime:0;
  return {active,strengths,severities,time,animated,motion,damageTypes:canonicalTypes(response?.damageTypes),collapse,sparks};
}

/** A fair global budget is allocated after each condition has produced its
 * own authored group. Isolated calls avoid starving later conditions inside
 * a family's local budget. Deployment clipping and explicit gates take priority.
 */
export function originalStatusFilamentAccents(side,profile,warp,ribs,growth=1){
  const fx=profile?.statusFilamentEffects;
  if(!fx?.active||growth<=0||typeof warp!=='function'||!Array.isArray(ribs)||!ribs.length)return [];
  const groups=[];
  for(const id of STATUS_FILAMENT_EFFECT_IDS){
    const strength=fx.strengths?.[id];if(!(strength>.001)||id==='paralyzed'&&fx.sparks===false)continue;
    // animated is an evaluator flag here: the compiled clock already holds a
    // frozen frame. Preserve that frame instead of resetting physical art to 0.
    const local={...fx,animated:true,strengths:{[id]:strength},severities:{[id]:fx.severities?.[id]??1}};
    const candidates=families.get(id)(side,{...profile,statusFilamentEffects:local},warp,ribs,growth);
    const quiet=['fatigued','prone','deafened','invisible','hidden','undetected','unnoticed','dying','dead'].includes(id);
    const group=candidates.filter(part=>!(fx.sparks===false&&(part.localSpark||id==='persistent-damage'&&part.id.includes('-electricity-')))).map(part=>({
      ...part,statusId:id,statusFilamentAccent:true,conditionAccent:true,material:part.material??'status-fx',
      width:Math.min(3,part.width*(quiet?1:1.15)),
      highlight:Math.max(quiet?.25:.7,unit((part.highlight??part.paleHighlight??0)*1.6))
    }));
    if(group.length)groups.push(group);
  }
  const result=[];
  for(let index=0;result.length<MAX_ACCENTS;index++){
    let added=false;
    for(const group of groups){if(group[index]){result.push(group[index]);added=true;if(result.length===MAX_ACCENTS)break;}}
    if(!added)break;
  }
  return result;
}

/** Strength-only material masks: original point objects, path positions and
 * stroke width remain exact. A local exposed guard is split at existing
 * vertices rather than moving a rib or inserting a replacement outline.
 */
export function originalStatusMaterialPaths(strand,points,profile){
  const fx=profile?.statusFilamentEffects;
  if(!fx?.active||!Array.isArray(points)||points.length<2||strand.conditionAccent||strand.statusFilamentAccent||strand.hardware||
    /^(gem|sigil)-/.test(strand.id??''))return null;
  const a=id=>unit(fx.strengths?.[id]),isWeb=/^(web|cross)-/.test(strand.id??''),isEdge=/^edge-/.test(strand.id??'');
  const index=Number(strand.id?.match(/^(?:rib|edge|web|cross)-(\d+)/)?.[1]??-1);
  const middle=isEdge?index>=2&&index<=4:index>=2&&index<=7;
  const effective=['off-guard','concealed','invisible','hidden','undetected','unnoticed','doomed','dying','dead','persistent-damage'].some(id=>a(id)>0);
  if(!effective)return null;
  const t=finite(fx.time),out=[];let run=null;
  // These gains belong to the whole material span, not to each sampled
  // vertex. Keep their authored multiplication order exact while evaluating
  // status clamps and the failing relay only once per strand.
  let baseGain=1;
  baseGain*=1-a('concealed')*(isWeb?.16:.05);
  baseGain*=1-a('invisible')*(isWeb?.74:isEdge?.17:.33);
  baseGain*=1-a('hidden')*(isWeb?.5:isEdge?.14:.24);
  baseGain*=1-a('undetected')*(isWeb?.63:isEdge?.2:.3);
  baseGain*=1-a('unnoticed')*(isWeb?.84:isEdge?.28:.43);
  baseGain*=1-a('doomed')*(isWeb?.28:isEdge?.1:.18);
  baseGain*=1-a('persistent-damage')*(isWeb?.14:isEdge?.04:.08);
  const relay=.12+.88*Math.max(0,Math.sin(t*.89-index*.39))**7;
  baseGain*=1-a('dying')*(isWeb?.72:isEdge?.5:.65*(1-relay));
  const terminal=1-(1-a('dead'))**3;
  baseGain*=1-terminal*.88;
  const exposedGain=1-a('off-guard')*.48,strandStrength=finite(strand.strength,1);
  if(terminal===0&&(!middle||exposedGain===1)){
    // No position-dependent mask remains. The old loop produces one span
    // containing these exact point objects; a shallow copy preserves that
    // ownership without visiting every segment just to repeat the same gain.
    return [{...strand,points:points.slice(),strength:strandStrength*Math.max(.025,baseGain)}];
  }
  for(let i=1;i<points.length;i++){
    const p=points[i-1],q=points[i],u=unit(((p[3]??1)+(q[3]??1))/2);
    // One coherent light gain per span keeps the original connected lace and
    // avoids turning a dim treatment into dozens of per-segment draw calls.
    // The sampled condition strength already supplies gradual entry/removal.
    let gain=baseGain;
    gain*=1-terminal*.98*(u<=.16?.16:1);
    const exposed=middle&&u>=.38&&u<=.82;
    if(exposed)gain*=exposedGain;
    const strength=strandStrength*Math.max(.025,gain);
    if(run&&run.strength===strength&&run.points.at(-1)===p)run.points.push(q);
    else{run={...strand,points:[p,q],strength};out.push(run);}
  }
  return out;
}
