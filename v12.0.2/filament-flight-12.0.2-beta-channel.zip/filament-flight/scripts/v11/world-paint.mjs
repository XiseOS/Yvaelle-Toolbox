/** Yvaelle’s Toolbox v11 · her wings and the world: the wing rig's hooks.
 *
 *  - visual.v11Fold = {l:[collapse,tip], r:[collapse,tip], key}: each wing's own
 *    fold (the rig's folded pose, root and tip), from the wall fold.
 *  - visual.v11Light = {bins:[palette|null ×24], fl:Float32Array(24), sig}: the
 *    light each part of her wing frame catches (world.mjs sampleLight), painted
 *    through the same palette hook as the v11 damage looks (only on strands
 *    those leave alone). A flame's flicker is applied when a frame is painted
 *    anyway (from the profile's own clock): it never asks for a repaint.
 * Plain data both, so the off-thread painter gets them too. No globals. */
import {lightBinOf,lightPalette,flicker,LIGHT_BINS,LIGHT_K_STEPS} from './world.mjs?v=12.0.2';

/** One wing's [collapse, collapseTip] combined with the profile's own (both 0…1). */
export function withSideFold(visual,side,collapse,collapseTip){
  const f=visual?.v11Fold;if(!f)return null;
  const p=side<0?f.l:f.r;if(!p||!(p[0]>0||p[1]>0))return null;
  return [1-(1-collapse)*(1-p[0]),1-(1-collapseTip)*(1-p[1])];
}
/** Each bin's palette for this paint (the flame's flicker at the profile's clock). Cached per light state and flicker step. */
let last=null,lastQ=NaN,lastOut=null;
export function lightPalettes(L,time){
  if(!L)return null;
  const t=Number.isFinite(time)?time:0,q=Math.round(t*12);
  if(L===last&&(q===lastQ||!L.flick))return lastOut;
  const out=lastOut&&L===last?lastOut:new Array(LIGHT_BINS),f=flicker(q/12);
  for(let b=0;b<LIGHT_BINS;b++){
    const base=L.bins[b];if(!base||!L.fl[b]){out[b]=base??null;continue;}
    const k=Math.round(base.k*(1+L.fl[b]*(f-1))*LIGHT_K_STEPS)/LIGHT_K_STEPS;
    out[b]=k>0?lightPalette(k,base.rgb[0],base.rgb[1],base.rgb[2]):null;
  }
  last=L;lastQ=q;lastOut=out;return out;
}
/** The palette for one strand (by where its middle is in her wing frame), or null. */
export function lightPaletteAt(pals,strand){
  const pts=strand.points;if(!pts?.length)return null;const p=pts[pts.length>>1];
  return pals[lightBinOf(p[0],p[1])]??null;
}
/** (test.3) Light caught over another palette (a mood): the same pull toward the light's colour as
 * lightPalette, from that palette's colours instead of hers. Cached by both keys. */
const LIT=new Map(),mixc=(a,b,k)=>[Math.round(a[0]+(b[0]-a[0])*k),Math.round(a[1]+(b[1]-a[1])*k),Math.round(a[2]+(b[2]-a[2])*k)];
export function litPalette(base,light){
  if(!base)return light;if(!light)return base;
  const key=`${base.key}|${light.key}`;let p=LIT.get(key);if(p)return p;
  const k=light.k??0,col=light.rgb,pale=mixc(col,[255,255,255],.62);
  p={...base,key,ink:mixc(base.ink,mixc(col,base.ink,.42),k*.9),halo:mixc(base.halo,col,k),core:mixc(base.core,pale,Math.min(1,k*1.3)),glow:(base.glow??1)*(1+.12*k),
    under:base.under??light.under};
  if(LIT.size>2048)LIT.clear();LIT.set(key,p);return p;
}
