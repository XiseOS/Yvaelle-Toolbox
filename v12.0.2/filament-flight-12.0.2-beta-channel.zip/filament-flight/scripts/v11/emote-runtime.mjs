/** Yvaelle’s Toolbox v11 · Emotes runtime: the saved emote on her token, played on every client.
 *
 * Sync. api.v11.emote saves one token flag, flags.filament-flight.v11Emote =
 * {id, variant, started, side, ally, key}, with started = the shared server
 * clock (game.time.serverTime), as api.wingGesture saves a v7.wingGesture
 * event. Every client reads the flag when it arrives and samples the phrase at
 * τ = (server now − started) / 1000, so every client draws the same frame.
 * Nothing is sent per frame, and the flag is never rewritten while it plays.
 *
 * What it drives each display frame, only while an emote plays (zero idle
 * cost: with no emote each hook is one Map lookup):
 *  - the flight feel (flight-feel-runtime): wingbeat, stillness, tilt, body
 *    offset, and the bits' spin, dim and swell;
 *  - the wing painter (pose-renderer): pose blend, V7 channels, and the
 *    shoulder turn and Comfort's wrap inside the wing picture (wing-rig);
 *  - the bits' places (bit-renderer, through the feel's bit records);
 *  - the soft lights (emote-fx-renderer);
 *  - her token layer: the portrait's part with her wings shown, all ten on the
 *    portrait and frame when they are off (Wingless mode).
 *
 * Precedence (emote-apply.mjs EMOTE_PRECEDENCE): she falls → stop; a combat
 * moment → yield; she moves, takes off or lands → release; a new emote → the
 * old one fades beneath it. An emote holds back a wing gesture saved by hand
 * and pauses her idle gestures.
 *
 * Nothing here touches her token's transform, bounds, vision or lighting: the
 * tilt and body offset ride on the flight feel's own render-only offsets. */
import {createEmoteFrame,sampleEmote,scaleEmoteFrame,addEmoteFrame,clearEmoteFrame,blendEmotePose,readEmoteFlag,emoteDuration,EMOTE_NP} from './emote-model.mjs?v=12.0.2';
import {seenToken} from './fx-visibility.mjs?v=12.0.2';
import {emoteGate,emoteEndWeight,EMOTE_FADES,GESTURE_UNDER_EMOTE,emoteFeel,emoteFeelBits,emoteChannels,createEmoteGeometryState,emoteGeometryState,toArt,
  createEmoteBitContext,createEmoteGlows,emoteGlows,prayTipArt} from './emote-apply.mjs?v=12.0.2';
import {EmoteFx} from './emote-fx-renderer.mjs?v=12.0.2';

const ID='filament-flight';
export const EMOTE_FLAG='v11Emote';
const unit=x=>x<0?0:x>1?1:x,smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const serverNow=()=>{const t=Number(globalThis.game?.time?.serverTime);return Number.isFinite(t)&&t>0?t:Date.now();};
const FRESH_MS=1500;
/** A phrase's own Comfort (its wrap and warmth, already scaled), kept apart from the summed frame. */
function keepComfort(o,H){o.k=H.hasWrap?H.wrapK:0;o.squeeze=H.squeeze;o.side=H.side<0?-1:1;o.warm=H.warm;}
/** A point in her frame (token sizes, turned with her token) → map px, into out. */
function local(c,base,r,x,y,out){const cs=Math.cos(r),sn=Math.sin(r);out.x=c.x+(x*cs-y*sn)*base;out.y=c.y+(x*sn+y*cs)*base;return out;}
/** Art units of the wing picture → map px, for wing transform T (c, s: its cos and sin), into out. */
function artPoint(T,c,s,ax,ay,out){const lx=ax/600*T.width,ly=(ay-15)/600*T.height;out.x=T.x+lx*c-ly*s;out.y=T.y+lx*s+ly*c;return out;}
/** How present a phrase is (0 at its ends, 1 inside): a gesture saved by hand is held back by it. */
const presence=(tau,dur)=>smooth(tau/.35)*(1-smooth((tau-dur+.35)/.35));

/** One token's playing emote. */
class Rec{
  constructor(rt,doc){
    this.rt=rt;this.doc=doc;this.flag=null;this.prev=null;this.end=null;this.born=0;
    this.until=0;this.F=createEmoteFrame();this.G=createEmoteFrame();this.H=createEmoteFrame();
    this.live=false;this.sampledAt=-1;this.tau=0;this.k=0;
    // painter hand-off, reused every frame
    this.wA=[Array(EMOTE_NP).fill(0),Array(EMOTE_NP).fill(0)];this.tA=[Array(EMOTE_NP).fill(0),Array(EMOTE_NP).fill(0)];this.flip=0;
    this.pose={weights:null,tipWeights:null};this.ch=Array(18).fill(0);this.wm={channels:this.ch,active:true,name:'v11Emote',variant:0};this.v7={};this.vis={};
    this.E=createEmoteGeometryState();this.X=createEmoteBitContext();this.glows=createEmoteGlows();
    this.allyArt={ax:0,ay:0,Ra:0};this.allyAt={x:0,y:0};
    // (test.5) each phrase's own Comfort (wrap, warmth) and the fading one's ally, for a Comfort beneath a Comfort
    this.cw={k:0,squeeze:0,side:1,warm:0};this.pw={k:0,squeeze:0,side:1,warm:0};this.prevAllyAt={x:0,y:0};this.prevArt={k:0,squeeze:0,side:1,ax:0,ay:0,Ra:0};
    this.wrapSplit={main:null,alt:null};this.lookAt={x:0,y:0};this.tipArt={ax:0,ay:0};
    this.pos={tip:{x:0,y:0},body:{x:0,y:0},ally:null};this.vis4=[1,1,1,1];
    this.fx=null;this.feelBits=null;this.x0=0;this.y0=0;this.e0=0;
  }
}

export class EmoteRuntime{
  constructor({reduced=()=>false,tokenLayers=null,now=serverNow}={}){
    this.active=new Map();this.reduced=reduced;this.tokenLayers=tokenLayers;this.now=now;
    this.stats={samples:0,feel:0,wing:0,draws:0,started:0,ended:0};
  }
  /** Is an emote playing on her (one Map lookup: the idle cost). */
  busy(token){return !!this.recOf(token);}
  /** Her record, or null; one that nothing drew to its end (no wings shown) is dropped once it is over. */
  recOf(token){
    if(!this.active.size)return null;const rec=this.active.get(token?.document?.id);if(!rec)return null;
    if(this.now()>rec.until){this.finish(rec);return null;}
    return rec;
  }

  /* ---------------- the flag ---------------- */
  /** Her v11Emote flag arrived (or the scene loaded): start, replace or ignore it. */
  noteFlag(doc,raw=doc?.getFlag?.(ID,EMOTE_FLAG),{announce=true}={}){
    const flag=readEmoteFlag(raw);if(!doc?.id||!flag)return null;
    const now=this.now(),tau=(now-flag.started)/1000;
    let rec=this.active.get(doc.id);
    if(rec?.flag?.key===flag.key)return rec;
    if(!(tau<emoteDuration(flag.variant))||tau<-5)return null;   // already over (a late join), or a clock gone wrong
    if(this.reduced())return null;
    if(!rec){rec=new Rec(this,doc);this.active.set(doc.id,rec);}
    else if(rec.flag&&rec.live&&!rec.end)rec.prev={flag:rec.flag,at:now};   // the old one fades beneath it
    rec.doc=doc;rec.flag=flag;rec.end=null;rec.until=flag.started+emoteDuration(flag.variant)*1000+1000;rec.born=Date.now();rec.sampledAt=-1;rec.live=true;
    rec.x0=doc.x;rec.y0=doc.y;rec.e0=doc.elevation??0;rec.hp=Number(doc.actor?.system?.attributes?.hp?.value);
    this.stats.started++;
    const token=doc.object;
    // her token layer: the portrait's part (wings shown) or the whole token (wings off)
    try{this.tokenLayers?.emote?.(token,flag.id==='laugh'||flag.variant.startsWith('laugh')?'laugh':flag.variant,this.lookOf(rec,token),{elapsed:Math.max(0,tau)});}catch{}
    try{this.tokenLayers?.wake?.(this.tokenLayers.layerOf?.(token));}catch{}
    if(announce)try{globalThis.Hooks?.callAll?.('filamentFlightEmote',{token,id:flag.id,variant:flag.variant,side:flag.side,ally:flag.ally,start:flag.started,uuid:doc.uuid,local:false});}catch{}
    return rec;
  }
  /** End her emote for a reason ('stop' | 'yield' | 'release'); it eases back and is gone. */
  endFor(token,reason){
    const rec=this.recOf(token);if(!rec||rec.end&&EMOTE_FADES[rec.end.reason]<=EMOTE_FADES[reason])return false;
    rec.end={reason,at:this.now()};
    try{this.tokenLayers?.emoteEnd?.(token,EMOTE_FADES[reason]);}catch{}
    return true;
  }
  finish(rec){
    this.active.delete(rec.doc.id);this.stats.ended++;
    rec.X.on=false;rec.E.on=false;
    if(rec.feelBits)for(let i=0;i<4;i++){const o=rec.feelBits[i];if(o){o.emoX=null;o.emoScale=1;}}
    rec.fx?.destroy();rec.fx=null;
    try{const p=globalThis.canvas?.primary;if(p)p.renderDirty=true;}catch{}
  }

  /* ---------------- sampling ---------------- */
  /** This display frame's phrase into rec.F (memoised per frame). False when it is over. */
  sample(rec,now){
    if(rec.sampledAt===now)return rec.live;
    rec.sampledAt=now;this.stats.samples++;
    const F=rec.F,H=rec.H,G=rec.G;clearEmoteFrame(F);let any=false;
    const p=rec.prev;
    let k=0;
    if(p){const wp=emoteEndWeight('fade',(now-p.at)/1000),tp=(now-p.flag.started)/1000;
      if(wp>0&&sampleEmote(p.flag.variant,tp,p.flag.side,H,G)){scaleEmoteFrame(H,wp);keepComfort(rec.pw,H);for(let i=0;i<4;i++)H.bits[i].prev=true;
        addEmoteFrame(F,H);any=true;k=wp*presence(tp,emoteDuration(p.flag.variant));}else rec.prev=null;}
    const f=rec.flag;rec.tau=(now-f.started)/1000;
    const w=rec.end?emoteEndWeight(rec.end.reason,(now-rec.end.at)/1000):1;
    rec.cw.k=rec.cw.warm=0;
    if(w>0&&sampleEmote(f.variant,rec.tau,f.side,H,G)){scaleEmoteFrame(H,w);keepComfort(rec.cw,H);addEmoteFrame(F,H);if(H.side<0)F.side=-1;any=true;k=Math.max(k,w*presence(rec.tau,emoteDuration(f.variant)));}
    F.id=f.variant;rec.k=k;
    rec.live=any;return any;
  }
  /** Where the ally (Comfort) and what she looks at (Curious) are, map px (written into rec.allyAt /
   * rec.lookAt; virtual when nobody is there: beside her on the side chosen, or ahead of her). */
  places(rec,token,f=rec.flag,out=null){
    const c=token.center,base=Math.max(token.w??100,token.h??100),r=(token.document?.rotation??0)*Math.PI/180;
    let ally=null;if(f.ally){const t=globalThis.canvas?.tokens?.get?.(f.ally);if(t&&t!==token&&t.center)ally=t.center;}
    if(f.variant==='comfort'){const o=out??rec.allyAt;if(ally){o.x=ally.x;o.y=ally.y;}else local(c,base,r,f.side*1.08,.14,o);return o;}
    if(f.variant==='curious'){const o=rec.lookAt;if(ally){o.x=ally.x;o.y=ally.y;}else local(c,base,r,0,-2.2,o);return o;}
    return null;
  }
  /** The token layer's look direction (token-local unit vector) toward the ally or the target. */
  lookOf(rec,token){
    if(!token?.center)return null;const p=this.places(rec,token);if(!p)return null;
    const r=-(token.document?.rotation??0)*Math.PI/180,dx=p.x-token.center.x,dy=p.y-token.center.y,l=Math.hypot(dx,dy)||1;
    return {x:(dx*Math.cos(r)-dy*Math.sin(r))/l,y:(dx*Math.sin(r)+dy*Math.cos(r))/l};
  }

  /* ---------------- the flight feel (flight-feel-runtime, before composeFeel) ---------------- */
  /** ctx: {now, dt, size, f (feel state), unconscious, hit, dodge, save, mode} */
  feel(token,out,s,ctx){
    const rec=this.recOf(token);if(!rec)return;this.stats.feel++;
    const now=ctx.now,doc=token.document;
    // precedence: what in her life outranks the emote this frame
    const newer=r=>!!r&&(r.at??0)>rec.born&&Date.now()-(r.at??0)<FRESH_MS;
    const f=ctx.f;
    const reason=emoteGate({ko:ctx.unconscious,collapse:out.collapse??0,hit:newer(ctx.hit),dodge:newer(ctx.dodge),save:newer(ctx.save),
      intercept:!!f?.intercepts?.length,shield:out.shield??0,shatter:(f?.shatter??-1)>=0,
      moved:doc.x!==rec.x0||doc.y!==rec.y0||(doc.elevation??0)!==rec.e0,mode:ctx.mode});
    if(reason)this.endFor(token,reason);
    if(!this.sample(rec,now)){this.finish(rec);return;}
    const F=rec.F;
    // (she keeps beating while she travels: an emote rides on her flight, it does not stop her wings mid-path)
    const travel=smooth(((out.speed??0)-.3)/1.2);
    const turns=emoteFeel(F,out,ctx.size,s.wingClock?.turns??0,ctx.dt,travel);
    if(s.wingClock&&F.still>0)s.wingClock.turns=turns;
    emoteFeelBits(F,out.bits);rec.feelBits=out.bits;
    if(out.bits)for(let i=0;i<4;i++)if(out.bits[i])out.bits[i].emoX=rec.X;
  }

  /* ---------------- the wing painter (pose-renderer) ---------------- */
  /** This frame's emote for her wings, or null. transform: wingTransform(). */
  wing(token,now,transform){
    const rec=this.recOf(token);if(!rec)return null;this.stats.wing++;
    if(!this.sample(rec,now)){this.finish(rec);return null;}
    const F=rec.F,base=Math.max(token.w??100,token.h??100),place=this.places(rec,token);
    // the ally in the wing picture's own units (Comfort's wrap; also while a Comfort fades under a new emote)
    const cur=rec.flag.variant==='comfort'?rec.flag:null,pv=rec.prev?.flag.variant==='comfort'?rec.prev.flag:null,cf=cur??pv;
    let ally=null;const Ra=.48*base*600/Math.max(1,transform.width);
    if(cf){const p=this.places(rec,token,cf),a=rec.allyArt;toArt(transform,p.x,p.y,a);a.Ra=Ra;ally=a;}
    // (test.5) a Comfort fading out beneath a Comfort to her other side keeps its own wing, warmth and bits on its own
    // ally, each easing on its own (before, all of it leapt to the new side in one frame)
    const split=rec.wrapSplit,two=!!(cur&&pv&&pv.side!==cur.side);split.alt=null;
    if(cur&&pv&&!two){const c=rec.cw,q=rec.pw;split.main=q.k>c.k?q:c;}else split.main=cur?rec.cw:pv?rec.pw:null;
    if(two){const p=this.places(rec,token,pv,rec.prevAllyAt),a=rec.prevArt;toArt(transform,p.x,p.y,a);a.Ra=Ra;a.k=rec.pw.k;a.squeeze=rec.pw.squeeze;a.side=pv.side;split.alt=a;}
    emoteGeometryState(F,rec.E,ally,split.main?split:null);
    const X=rec.X;X.on=true;X.F=F;X.base=base;X.t=rec.tau;
    X.ally=cf?rec.allyAt:null;
    // (test.5) and a Curious fading out beneath the next emote keeps leaning toward what it looked at (its bits leapt home)
    const lk=rec.flag.variant==='curious'?null:rec.prev?.flag.variant==='curious'?rec.prev.flag:null;
    X.look=rec.flag.variant==='curious'?place:lk?this.places(rec,token,lk):null;
    X.side=cur?cur.side:pv?pv.side:null;X.prevAlly=two?rec.prevAllyAt:null;X.prevSide=pv?pv.side:null;
    return rec;
  }
  /** Her pose weights with the phrase blended over them (reused arrays; tips in rec.pose.tipWeights). */
  weights(rec,weights,tipWeights){
    const k=rec.flip=1-rec.flip,w=blendEmotePose(weights,rec.F.pose,rec.wA[k]),tw=blendEmotePose(tipWeights??weights,rec.F.tip,rec.tA[k]);
    rec.pose.weights=w;rec.pose.tipWeights=tw;return w;
  }
  /** The painter's flight input (already its own object): pose and V7 channels for this frame. */
  flight(rec,flight){
    const F=rec.F,src=flight.v7,v=rec.v7;
    flight.poseAnimation=rec.pose;
    const gesture=src?.enabled===true&&src.wingAnimations!==false&&src.wingMotion?.active?src.wingMotion.channels:null;
    if(!F.hasCh&&!gesture)return flight;
    for(const k in v)if(!src||!(k in src))delete v[k];
    if(src)for(const k in src)v[k]=src[k];
    if(src?.enabled!==true){v.enabled=true;v.filamentTexture=false;}
    v.wingAnimations=true;
    emoteChannels(F,gesture,rec.ch,1-(1-GESTURE_UNDER_EMOTE)*rec.k);
    rec.wm.active=true;v.wingMotion=rec.wm;flight.v7=v;
    return flight;
  }
  /** The visual profile with the wing-picture state on it (a reused copy: the painter and its worker read it). */
  visual(rec,visual){
    const o=rec.vis;
    for(const k in o)if(!(k in visual))delete o[k];
    for(const k in visual)o[k]=visual[k];
    o.v11emo=rec.E;return o;
  }
  /** The soft lights, after the bits are placed. */
  draw(rec,rig,transform,source,alpha,fx=1){
    const token=rig.token,F=rec.F,base=Math.max(token.w??100,token.h??100);this.stats.draws++;
    const G=emoteGlows(F,rec.glows,base,transform.size/base||1,rec.vis4,rec.tau);
    const any=G.glow>.003||G.aura.k>.003||G.warm.k>.003||G.bits[0].focusA+G.bits[1].focusA+G.bits[2].focusA+G.bits[3].focusA+G.bits[0].glowA+G.bits[1].glowA+G.bits[2].glowA+G.bits[3].glowA>.003;
    if(!any){rec.fx?.hide();return;}
    const P=rec.pos,c=Math.cos(transform.angle),s=Math.sin(transform.angle);
    // Pray: the light where her tips meet (6 px below them at 1:1), and the low glow 20 px above her centre
    if(G.aura.k>.003){prayTipArt(G.aura.k,rec.tipArt);artPoint(transform,c,s,rec.tipArt.ax,rec.tipArt.ay,P.tip);P.tip.y+=.06*base;
      P.body.x=transform.x;P.body.y=transform.y-.2*base;}
    // (test.3) Comfort's warmth lies round the ally only where this client sees that ally
    P.ally=F.warm>.003&&(!rec.flag.ally||seenToken(rec.flag.ally))?rec.allyAt:null;P.ally2=null;
    // (test.5) two Comforts to her two sides: each warmth round its own ally
    if(rec.X.prevAlly&&rec.prev){G.warm.k=Math.min(1,rec.cw.warm);G.warm.k2=Math.min(1,rec.pw.warm);
      P.ally2=G.warm.k2>.003&&(!rec.prev.flag.ally||seenToken(rec.prev.flag.ally))?rec.prevAllyAt:null;if(!(G.warm.k>.003))P.ally=null;}
    (rec.fx??=new EmoteFx(token)).update(rig,G,P,source,alpha,fx);
  }

  /* ---------------- hooks ---------------- */
  /** emote(id,{token}): the API entry point (for /me); isOn/partOn: the feature switches. */
  install({tokenLayers=null,reduced=null,emote=null,partOn=null}={}){
    if(tokenLayers)this.tokenLayers=tokenLayers;if(reduced)this.reduced=reduced;
    if(this.installed||!globalThis.Hooks)return;this.installed=true;
    Hooks.on('updateToken',(doc,changes)=>{
      const fl=changes?.flags?.[ID];
      if(fl&&(EMOTE_FLAG in fl))this.noteFlag(doc);
      // she moves (synced: every client sees the same move): the emote eases back
      const rec=this.active.size?this.active.get(doc.id):null;
      if(rec&&('x' in changes||'y' in changes||'elevation' in changes))this.endFor(doc.object??{document:doc},'release');
    });
    Hooks.on('canvasReady',()=>{for(const rec of [...this.active.values()])this.finish(rec);for(const t of globalThis.canvas?.tokens?.placeables??[])this.noteFlag(t.document,undefined,{announce:false});});
    Hooks.on('canvasTearDown',()=>{for(const rec of [...this.active.values()])this.finish(rec);});
    Hooks.on('deleteToken',doc=>{const rec=this.active.get(doc.id);if(rec)this.finish(rec);});
    // a blow (her HP drops) makes it yield; falling unconscious or dying stops it
    Hooks.on('updateActor',(actor,changes)=>{
      if(!this.active.size)return;
      const next=changes?.system?.attributes?.hp?.value,ko=!!(actor?.statuses?.has?.('unconscious')||actor?.statuses?.has?.('dying')||actor?.statuses?.has?.('dead'));
      for(const t of actor?.getActiveTokens?.()??[]){const rec=this.active.get(t.document?.id);if(!rec)continue;
        if(ko)this.endFor(t,'stop');else if(Number.isFinite(next)&&Number.isFinite(rec.hp)&&next<rec.hp)this.endFor(t,'yield');
        if(Number.isFinite(next))rec.hp=next;}
    });
    // /me in chat (Settings › Emotes & wheel › Emotes › /me in chat; off by default): only the writer's client acts
    Hooks.on('createChatMessage',message=>{try{
      if(!emote||!isEmoteMessage(message))return;
      const author=message.author?.id??message.user?.id??message.author??message.user;if(author!==globalThis.game?.user?.id)return;
      const id=parseMeEmote(message.content);if(!id)return;
      const token=speakerToken(message);if(!token||!token.document?.isOwner)return;
      if(partOn&&!partOn(token.document))return;
      Promise.resolve(emote(id,{token})).catch(()=>{});
    }catch{}});
  }
}
/** The one runtime (flight.mjs installs its hooks). */
export const emoteRuntime=new EmoteRuntime();

/* ---------------- /me ---------------- */
/** An emote-style chat message (/me): Foundry v12+ `style`, older `type`. */
export function isEmoteMessage(message){
  const C=globalThis.CONST,EM=C?.CHAT_MESSAGE_STYLES?.EMOTE??3,ET=C?.CHAT_MESSAGE_TYPES?.EMOTE??3;
  return !!message&&(message.style===EM||message.type===ET||message.type==='emote');
}
/** The verbs /me understands, in the order they are tried at each word. */
export const ME_VERBS=Object.freeze([
  ['bow',/^(bows?|bowing|bowed|curts(?:e?y|ies|eys|eying|ied))$/],
  ['laugh',/^(laugh(?:s|ing|ed)?|chuckl(?:e|es|ing|ed)|giggl(?:e|es|ing|ed))$/],
  ['sigh',/^(sigh(?:s|ing|ed)?)$/],
  ['shrug',/^(shrug(?:s|ging|ged)?)$/],
  ['wave',/^(wav(?:e|es|ing|ed))$/],
  ['cheer',/^(cheer(?:s|ing|ed)?|whoops?|whooping|whooped)$/],
  ['startle',/^(startl(?:e|es|ed|ing)|flinch(?:es|ing|ed)?|jumps|jumped)$/],
  ['comfort',/^(comfort(?:s|ing|ed)?|hug(?:s|ging|ged)?|consol(?:e|es|ing|ed)|embrac(?:e|es|ing|ed))$/],
  ['curious',/^(curious(?:ly)?|peers?|peering|peered|tilts?|tilting|tilted|wonders?|wondering)$/],
  ['pray',/^(pray(?:s|ing|ed)?)$/]]);
/** Which emote a /me line plays, from the first of her first six words that is one of the verbs (or null).
 * "/me bows deeply" → bow; "/me laughs softly" → laugh; "/me quietly sighs" → sigh; "/me draws her sword" → null. */
export function parseMeEmote(text){
  if(typeof text!=='string')return null;
  const plain=text.replace(/<[^>]*>/g,' ').replace(/&[a-z]+;|&#\d+;/gi,' ').toLowerCase();
  const words=plain.split(/[^a-z']+/).filter(Boolean).slice(0,6);
  for(const w of words){const word=w.replace(/'s$/,'');for(const [id,re] of ME_VERBS)if(re.test(word))return id;}
  return null;
}
/** Her token for a chat message's speaker (its token, else her actor's one token on this scene). */
function speakerToken(message){
  const sp=message?.speaker??{},tokens=globalThis.canvas?.tokens;
  let t=sp.token?tokens?.get?.(sp.token):null;
  if(!t&&sp.actor){const a=globalThis.game?.actors?.get?.(sp.actor);const list=a?.getActiveTokens?.()??[];t=list.find(x=>x.document?.getFlag?.(ID,'flight'))??null;}
  return t?.document?.getFlag?.(ID,'flight')?t:null;
}
