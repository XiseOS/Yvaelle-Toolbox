/** Named treatments deform and cut the actual wing lattice. They reuse the four
 * rig textures, the same shoulder roots, depth split and formation clipping. */
import {hash} from './conditions.mjs?v=12.0.2';
import {ease,unit} from './poses.mjs?v=12.0.2';
import {cubic} from './wing-art.mjs?v=12.0.2';
import {fitEffectPoint,fitOwnedEffectPoint} from './condition-art.mjs?v=12.0.2';
import {reactionAccents} from './reaction-art.mjs?v=12.0.2';
import {REACTION_KIND_TINT} from './quick-choreography.mjs?v=12.0.2';
import {expandedConditionPoint,expandedConditionPaths,expandedConditionAccents} from './expanded-condition-art.mjs?v=12.0.2';
import {isCuratedCondition,curatedConditionPoint,curatedConditionPaths,curatedConditionAccents,curatedConditionParameters} from './curated-condition-art.mjs?v=12.0.2';
import {isAdvancedCondition,advancedConditionPoint,advancedConditionPaths,advancedConditionAccents} from './advanced-condition-art.mjs?v=12.0.2';
import {isDistinctCondition,distinctConditionPoint,distinctConditionPaths,distinctConditionAccents} from './distinct-condition-art.mjs?v=12.0.2';
import {isV53Condition,v53ConditionPoint,v53ConditionPaths,v53ConditionAccents} from './v53-condition-art.mjs?v=12.0.2';
const NO_REACTIONS=Object.freeze([]);
const legacyReactions=v=>v.reactions?.length?v.reactions.filter(b=>b.kind!=='pulse'&&b.kind!=='stutter'):NO_REACTIONS;
const TAU=Math.PI*2,frac=x=>x-Math.floor(x),rnd=x=>hash(x)/4294967295;
const root=u=>ease((u-.09)/.35);
const lerp=(a,b,t)=>a.map((n,i)=>n+(b[i]-n)*t);
const quant=n=>Math.round(Math.max(0,Math.min(1.5,n))*20)/20;
const envelope=(p,center,width)=>Math.exp(-(((p-center)/width)**2));
// Avalanche only the refined effects' samples. Adjacent IDs must not select
// neighbouring strands in lockstep; older treatments keep their exact pattern.
function sample(key){
  let h=hash(key);h=Math.imul(h^(h>>>16),0x85ebca6b);h=Math.imul(h^(h>>>13),0xc2b2ae35);
  return ((h^(h>>>16))>>>0)/4294967296;
}
const fieldCache=new WeakMap();
function field(v,side){
  let c=fieldCache.get(v);
  if(!c||c.seed!==v.seed){c={seed:v.seed,sides:new Map()};fieldCache.set(v,c);}
  if(!c.sides.has(side))c.sides.set(side,{
    phase:sample(`${v.seed}:tremor:${side}`)*TAU,
    tears:[1,5,7].map((base,j)=>({rib:base+Math.floor(sample(`${v.seed}:fray-rib:${side}:${j}`)*2),
      u:.50+.28*sample(`${v.seed}:fray-u:${side}:${j}`),
      phase:sample(`${v.seed}:fray-phase:${side}:${j}`)*TAU}))
  });
  return c.sides.get(side);
}
const primary=id=>['rib-0','rib-4','rib-9'].includes(id)||id.startsWith('edge-');
const tailRoot=(v,side,i)=>.54+.3*sample(`${v.seed}:unravel:${side}:${i}`);
const phaseIn=(q,start,duration)=>(q-start)/duration;
const active=p=>p>0&&p<1;
const softBeat=p=>active(p)?Math.sin(Math.PI*p)**2:0;
const SHOCKS=Object.freeze([[.045,.30,1],[.27,.30,.88],[.53,.32,.76]]);
const HEARTBEATS=Object.freeze([[.05,.28,1],[.55,.32,.85]]);
/** Fragment recall: pieces loosen outward first, then converge (beta.29). */
const recallSpread=q=>ease(q/.22)*(1-ease((q-.24)/.58));
function ribbon(out,id,points,width,strength){
  if(strength<=.025||points.length<2)return;
  // Taper in a few batched strokes instead of adding a filter or extra texture.
  for(let j=0;j<4;j++){
    const start=Math.floor(j*(points.length-1)/4),end=Math.floor((j+1)*(points.length-1)/4);
    const gain=quant(strength*[1,.8,.5,.2][j]);if(gain<=.025)continue;
    out.push({id:`${id}-${j}`,points:points.slice(start,end+1).map(fitEffectPoint),width:width*[1,.72,.45,.2][j],strength:gain});
  }
}
const bend=(a,b,c,d,count=20)=>Array.from({length:count+1},(_,i)=>{
  const q=i/count,k=1-q;return a.map((x,j)=>k*k*k*x+3*k*k*q*b[j]+3*k*q*q*c[j]+q*q*q*d[j]);
});


/** The common breathing treatment shares one prepared field/sample map per
 * synchronous frame. Other catalogs retain their existing dispatch and clocks. */
export function variantPointParameters(v){
  return v?.variant?.id==='breathing'&&!v.reactions?.length?{curated:curatedConditionParameters(v)}:undefined;
}
export function variantPoint(point,u,side,v,parameters) {
  if(!v?.variant&&!v?.reactions?.length)return point;
  // The default breathing lattice is curated and has no legacy reactions.
  // Keep its original sampler and final bounds pass while avoiding unrelated
  // catalog dispatches and an extra point copy for every source vertex.
  if(v.variant?.id==='breathing'&&!v.reactions?.length){
    const p=curatedConditionPoint(point,u,side,v,parameters?.curated);
    return p===point?fitEffectPoint(p):fitOwnedEffectPoint(p);
  }
  const v53=isV53Condition(v),distinct=!v53&&isDistinctCondition(v),advanced=!v53&&!distinct&&isAdvancedCondition(v),curated=!v53&&!distinct&&!advanced&&isCuratedCondition(v);
  const deformed=v53?v53ConditionPoint(point,u,side,v):distinct?distinctConditionPoint(point,u,side,v):advanced?advancedConditionPoint(point,u,side,v):curated?curatedConditionPoint(point,u,side,v):expandedConditionPoint(point,u,side,v);
  if((v53||distinct||advanced)&&!legacyReactions(v).length)return deformed;
  let p=[...deformed],r=root(u),x=p[0]-side*27,y=p[1]+13;
  const a=v53||distinct||advanced||curated?null:v.variant,A=a?.amount??0,t=a?.time??0,m=v.variantMotion??1;
  const motion=m*(v.gates?.instability===false?0:1);
  switch(a?.id){
    case 'breathing':{
      const breath=Math.sin(t*.95-u*1.2),curl=Math.sin(t*.95-u*3);
      p[0]+=x*A*motion*.09*r*breath;p[1]+=A*motion*r*(9*curl-5*u*breath);break;}
    case 'fraying':p[1]+=A*motion*r*u*(6+7*u);break;
    case 'recoil':{
      const beat=Math.pow(Math.max(0,Math.sin(t*2.2*a.frequency+(side<0?0:1.7))),6);
      p[0]-=x*A*motion*r*.38*beat;p[1]+=A*motion*r*(24*beat+8*Math.sin(t*1.7+side));break;}
    case 'tremor':{
      const phase=field(v,side).phase,angle=Math.atan2(y,Math.abs(x)+.001);
      let dx=0,dy=0;
      for(let j=0;j<2;j++){
        const life=frac(t*(.32+j*.11)+phase/TAU+j*.47),head=.1+life*1.02;
        const band=.65*Math.sin(t*.57+phase+j*2.3);
        const packet=envelope(u,head,.105+j*.035)*(.18+.82*envelope(angle,band,.42))*Math.sin(Math.PI*life);
        dx+=packet*7*Math.sin(t*(8.1+j*.7)+phase+u*9+j*2);
        dy+=packet*7.8*Math.sin(t*(7.3+j*.8)+phase-u*11+j);
      }
      p[0]+=side*A*motion*r*dx;p[1]+=A*motion*r*dy;break;}
    case 'torsion':{
      const turn=Math.sin(t*.9+side*.9-u*5.3),height=Math.tanh(y/100);
      p[0]+=side*14*A*motion*r*height*turn;p[1]+=10*A*motion*r*Math.cos(t*.9+side*.9-u*5.3);break;}
    case 'corona':p[0]+=x*A*motion*r*(.06+.025*Math.sin(t*2-u*5));p[1]-=A*motion*r*8;break;
    case 'binding':p[0]-=x*A*r*(.48+.025*motion*Math.sin(t*1.2));p[1]*=1-A*r*.08;break;
    case 'drain':p[0]-=x*A*r*.22;p[1]+=A*r*u*12;break;
    case 'unravelling':{
      // Keep a broken upper scaffold; retain separation between the rib bundles.
      const drift=Math.sin(t*.72+y*.017+side)*3.5*motion*r;
      const target=[side*27+x*(.55-.075*ease((u-.5)/.5))+side*drift,
        -13+y*(y<0?.68:.42)+61*u];
      p[0]+=(target[0]-p[0])*A*r;p[1]+=(target[1]-p[1])*A*r;break;}
    case 'remnants':p[0]-=x*A*r*.43;p[1]+=(u*100-y*.5)*A*r;break;
  }
  for(const b of legacyReactions(v)){
    const e=b.envelope*r*motion,q=b.progress;
    switch(b.id){
      case 'impact':{
        const hit=ease(q/.055)*(1-ease((q-.075)/.25));
        const release=softBeat(phaseIn(q,.28,.24));
        p[0]-=x*r*motion*b.strength*(.24*hit-.025*release);
        p[1]+=r*motion*b.strength*8*hit;break;}
      case 'shock':{
        let push=0;
        for(const [start,duration,gain] of SHOCKS){const phase=phaseIn(q,start,duration);
          if(active(phase))push+=gain*envelope(u,.12+.86*ease(phase),.13)*Math.sin(Math.PI*phase);}
        p[0]+=x*r*motion*b.strength*.055*push;p[1]-=r*motion*b.strength*4*push;break;}

      case 'rupture':p[0]-=x*e*.34*Math.cos(q*Math.PI*2.2);p[1]+=e*18;break;
      case 'fan':p[0]+=x*e*.16;p[1]+=y*e*.07;break;
      case 'crown':p[1]-=e*(y<10?32:9);p[0]+=x*e*.05;break;
      case 'heartbeat':{
        const beat=HEARTBEATS.reduce((n,[start,duration,gain])=>n+gain*softBeat(phaseIn(q,start,duration)),0);
        p[0]+=x*r*b.strength*motion*.042*beat;break;}
      case 'weave':{
        const spread=(1-ease((q-u*.48)/.38))*b.envelope;p[0]-=x*r*motion*.10*spread;break;}
    }
  }
  return fitOwnedEffectPoint(p);
}

/** Segment cuts never bridge a missing section. Only displaced runs receive
 * extra moveTo strokes; undisturbed runs are batched back into one polyline. */
export function variantPaths(strand,points,side,v) {
  // Preserve the curated path's point identities, including the current-head
  // reference used to emit its travelling star, without unrelated dispatch.
  if(v?.variant?.id==='breathing'&&!legacyReactions(v).length){
    return curatedConditionPaths(strand,points,side,v);
  }
  const v53=isV53Condition(v),distinct=!v53&&isDistinctCondition(v),advanced=!v53&&!distinct&&isAdvancedCondition(v);
  const expanded=v53?v53ConditionPaths(strand,points,side,v):distinct?distinctConditionPaths(strand,points,side,v):advanced?advancedConditionPaths(strand,points,side,v):isCuratedCondition(v)?curatedConditionPaths(strand,points,side,v):expandedConditionPaths(strand,points,side,v);
  if(expanded){
    if((v53||distinct||advanced||isCuratedCondition(v))&&!legacyReactions(v).length)return expanded;
    const reactions={...v,variant:null};
    return expanded.flatMap(part=>{
      const bounded={...part,points:part.points.map(fitEffectPoint)};
      return part.echo||part.star?[bounded]:variantPaths(bounded,bounded.points,side,reactions);
    });
  }
  if(!v?.variant&&!legacyReactions(v).length)return [{...strand,points}];
  const out=[],extras=[],a=v.variant,id=a?.id,A=a?.amount??0,t=a?.time??0;
  const m=v.variantMotion??1,animated=v.animated!==false,freq=a?.frequency??1;
  // Seeds that are constant for this strand and frame are hashed once, lazily,
  // instead of once per segment. Values are identical to the per-segment form.
  let strandSeed,lagging;const tears=[],shards=[],legacy=legacyReactions(v);
  const seed=()=>strandSeed??=rnd(`${v.seed}:${side}:${strand.id}`),rib=strand.id.startsWith('rib-');
  const breaks=v.gates?.breaks!==false,glitches=v.gates?.glitches!==false;
  const ribIndex=rib?Number(strand.id.split('-')[1]):null;
  const web=strand.id.startsWith('web-')||strand.id.startsWith('cross-');
  const webIndex=web?Number(strand.id.split('-')[1])+.5:null;
  const sites=id==='fraying'?field(v,side).tears:[];
  const unravelRank=id==='unravelling'?sample(`${v.seed}:unravel-section:${side}:${strand.id}`):0;
  const unravelEnd=id==='unravelling'&&rib?tailRoot(v,side,ribIndex):1;
  const skips=new Map(legacy.filter(b=>b.id==='skip').map(b=>{
    const step=Math.floor(b.progress*9);
    return [b,{step,band:.27+.55*sample(`${v.seed}:skip-band:${side}:${step}`),
      chosen:sample(`${v.seed}:skip-strand:${side}:${strand.id}:${step}`)<.38,
      sign:sample(`${v.seed}:skip-sign:${side}:${step}`)<.5?-1:1}];
  }));
  let last=null,lastTail=-1;
  const append=(p,q,strength,tag)=>{
    const s=quant(strength);if(s<.025){last=null;return;}
    if(last&&last.tag===tag&&last.strength===s&&last.points.at(-1).every((n,i)=>n===p[i]))last.points.push(q);
    else {last={...strand,points:[p,q],width:strand.width*(id==='unravelling'?.62:1),strength:s,tag};out.push(last);}
  };
  for(let i=1;i<points.length;i++){
    const p=points[i-1],q=points[i],u=((p[3]??1)+(q[3]??1))/2,r=root(u),g=Math.floor(u*9);
    let cut=false,dx=0,dy=0,s=strand.strength,tag='plain';
    if(id==='fraying'&&breaks){
      const hit=sites.findIndex(site=>(rib?ribIndex===site.rib:web&&Math.abs(webIndex-site.rib)<1.1)&&Math.abs(u-site.u)<(.045+(web?.018:0))*A*r);
      cut=hit>=0;
      if(cut&&rib&&lastTail!==hit&&v.gates?.sparks&&u>.2){
        lastTail=hit;const phase=sites[hit].phase,drop=18+14*(.5+.5*Math.sin(phase)),sway=Math.sin(t*1.1+phase)*4*m;
        const vx=q[0]-p[0],vy=q[1]-p[1],length=Math.hypot(vx,vy)||1;
        const tail=bend(p,[p[0]+vx/length*7,p[1]+vy/length*7,p[2],p[3]??u],
          [p[0]+side*(4+6*Math.cos(phase))*m+sway,p[1]+drop*.6,p[2],p[3]??u],
          [p[0]+side*(9+4*Math.sin(phase))*m+sway*.7,p[1]+drop,p[2],p[3]??u]);
        ribbon(extras,`tassel-${strand.id}-${hit}`,tail,.78,.9*A);
      }
    }
    if(id==='fissures'&&breaks){
      const crack=.28+.46*(.5+.5*Math.sin(t*.65+Math.atan2(p[1]+13,Math.abs(p[0])-27)*1.3));
      const d=Math.abs(u-crack);cut=d<.042*A*r;
      if(d<.075*A*r&&!cut){s*=1.4;dx=side*5*A*r*m;tag='fissure-edge';}
    }
    if(id==='phaseTears'&&glitches){
      const step=Math.floor(t*4),sector=Math.floor(u*7),phase=tears[sector]??=rnd(`${v.seed}:tear:${side}:${sector}:${step}`);
      const active=animated&&phase<Math.min(.93,(.38+.25*A)*freq);
      cut=active&&phase<.22*A*freq&&u>.2;
      dx=active?side*(phase<.32?-1:1)*24*A*r*m*(v.gates?.displacement??1):0;
      dy=active?Math.sin(sector*4+step)*7*A*r*m:0;tag=`tear-${sector}-${dx}`;
    }
    if(id==='desync'&&glitches){
      const step=Math.floor(t*5),active=animated&&(lagging??=rnd(`${v.seed}:lag:${side}:${step}`)<Math.min(.95,.65*freq));
      dx=active?Math.sin(step+side)*11*A*r*m*(v.gates?.displacement??1):0;
      dy=active?Math.cos(step*1.4)*5*A*r*m:0;tag=`lag-${g}`;
      if(active&&v.gates?.echoes&&(rib||strand.id.startsWith('edge-'))){
        const shift=n=>fitEffectPoint([n[0]-dx*1.9+side*7*A*r*m,n[1]-dy*2-6*A*r*m,n[2],n[3]??u]);
        extras.push({...strand,id:`desync-${strand.id}`,echo:true,points:[shift(p),shift(q)],width:strand.width*.8,strength:.5*A});
      }
    }
    if(id==='refraction'&&glitches){
      const life=animated?frac(t*.28*freq+(side<0?.17:0)):.35,front=.1+.86*life;
      const band=envelope(u,front,.13)*Math.sin(Math.PI*life)*A*r;
      const shift=9*band*m*(v.gates?.displacement??1);
      if(band>.025){dx=side*shift;dy=-2*band*m;tag=`refraction-${g}`;
        if(v.gates?.echoes&&rib)extras.push({...strand,id:`refraction-${strand.id}`,echo:true,
          points:[p,q].map(n=>fitEffectPoint([n[0]-side*shift,n[1]+2*band*m,n[2],n[3]])),
          width:strand.width*.55,strength:quant(strand.strength*band*.48)});
      }
    }
    if(id==='drain'){
      const boundary=.92-.20*A*(.5+.5*Math.sin(t*.8));cut=u>boundary&&seed()<A*.75;
    }
    if(id==='unravelling'){
      const rank=unravelRank;
      if(rib)cut=u>unravelEnd+(1-A)*.5;
      else if(web)cut=rank<A*(.25+.66*ease((u-.25)/.65));
      else if(strand.id.startsWith('edge-'))cut=u>.6&&rank<A*.55;
      s*=1-A*(rib?.35+.35*u:.46+.3*u);
    }
    if(id==='remnants'){
      const rank=shards[g]??=rnd(`${v.seed}:shard:${side}:${strand.id}:${g}`),life=animated?frac(t*.22+rank):.4;
      cut=rank<A*.48||g%3===0&&u>.18;
      dx=side*(rank-.4)*36*A*r*m*life;dy=50*A*r*m*life;tag=`shard-${g}`;
      s*=1-.65*life;
    }
    for(const b of legacy){
      const e=b.envelope*r*(b.kind==='stutter'?(v.gates?.glitchLimit??1):1),qb=b.progress;
      if(['fracture','rupture'].includes(b.id)&&breaks){
        const front=.18+.75*qb,dist=Math.abs(u-front);
        if(dist<(b.id==='rupture'?.085:.05)*e)cut=true;
        else if(dist<.13*e){s*=1.5;dx+=side*8*e*m;tag+='-crack';}
      }
      if(b.id==='skip'&&glitches&&!primary(strand.id)){
        const {step,band,chosen,sign}=skips.get(b);
        if(chosen&&Math.abs(u-band)<.115&&u>.18){
          const amount=(rib?7:14)*e*m*(v.gates?.displacement??1);
          dx+=sign*amount;dy+=(step%3-1)*amount*.18;tag+=`-held-${step}`;
          // Keep the lattice present; the brief misalignment supplies the stutter.
          if(v.gates?.echoes&&!rib&&e>.08)extras.push({...strand,id:`skip-echo-${strand.id}`,echo:true,
            points:[p,q].map(fitEffectPoint),width:strand.width*.65,strength:quant(strand.strength*e*.22)});
        }
      }
      if(b.id==='recall'){
        // Beta.29: loosen outward for ~0.3 s, then gather back (no frame-1 jump).
        const k=recallSpread(qb)*b.strength*r,angle=seed()*TAU+g;
        dx+=Math.cos(angle)*45*k*m;dy+=(25+Math.sin(angle)*35)*k*m;
        tag+=`-recall-${g}`;
      }
    }
    if(cut&&['fraying','fissures','phaseTears','remnants'].includes(id)){
      const repair=Math.max(0,...(v.reactions??[]).filter(b=>['heal','reform'].includes(b.kind)).map(b=>b.progress*1.25));
      if(u<repair&&repair>0)cut=false;
    }
    if(cut){last=null;continue;}
    const shift=n=>fitEffectPoint([n[0]+dx,n[1]+dy,n[2],n[3]??u]);
    append(shift(p),shift(q),s,tag);
  }
  return [...out,...extras];
}

export function variantAccents(side,v,warp,ribs,growth=1,context=null){
  if((!v?.variant&&!v?.reactions?.length)||growth<=0)return [];
  const v53=isV53Condition(v),distinct=!v53&&isDistinctCondition(v),advanced=!v53&&!distinct&&isAdvancedCondition(v);
  const out=[...reactionAccents(side,v,warp,ribs,growth,v.reactions??[]),...(v53?v53ConditionAccents(side,v,warp,ribs,growth):distinct?distinctConditionAccents(side,v,warp,ribs,growth,context):advanced?advancedConditionAccents(side,v,warp,ribs,growth,context):isCuratedCondition(v)?curatedConditionAccents(side,v,warp,ribs,growth):expandedConditionAccents(side,v,warp,ribs,growth))];
  if((v53||distinct||advanced)&&!legacyReactions(v).length)return out;
  const a=v53||distinct||advanced||isCuratedCondition(v)?null:v.variant,A=a?.amount??0,t=a?.time??0,m=v.variantMotion??1;
  const at=(i,u)=>warp([...cubic(ribs[Math.max(0,Math.min(ribs.length-1,i))],u),u]);
  const line=(id,points,width,strength)=>{
    if(strength<=.025||points.length<2||points.some(p=>(p[3]??1)>growth+.00001))return;
    out.push({id,points:points.map(fitEffectPoint),width,strength:quant(strength)});
  };
  const spark=(id,p,strength,size=1.4)=>{
    if(!v.gates?.sparks||strength<=.025||(p[3]??1)>growth+.00001)return;
    out.push({id,star:true,points:[fitEffectPoint(p)],width:size,strength:quant(strength)});
  };
  const taper=(id,points,width,strength)=>{
    if(points.some(p=>(p[3]??1)>growth+.00001))return;
    ribbon(out,id,points,width,strength);
  };
  const knot=(id,i,u,radius,strength)=>{
    const p=at(i,u),a=at(i,Math.max(0,u-.04)),b=at(i,Math.min(1,u+.04));
    const len=Math.hypot(b[0]-a[0],b[1]-a[1])||1,tx=(b[0]-a[0])/len,ty=(b[1]-a[1])/len;
    const place=([x,y])=>[p[0]+tx*x-ty*y,p[1]+ty*x+tx*y,p[2],u];
    const star=[[0,-1],[-.18,-.22],[-1.3,0],[-.18,.22],[0,1],[.18,.22],[1.3,0],[.18,-.22],[0,-1]];
    line(`${id}-star`,star.map(([x,y])=>place([x*radius,y*radius])),.7,strength);
    line(`${id}-weft`,Array.from({length:21},(_,j)=>{const q=j/20*TAU;return place([Math.cos(q)*radius*.78,Math.sin(2*q)*radius*.16]);}),.52,strength*.7);
    line(`${id}-join`,[at(i,Math.max(0,u-.1)),p,at(i,Math.min(1,u+.1))],1.2,strength*.62);
    spark(`${id}-core`,p,strength*.8,1.7);
  };
  const arc=(id,u,strength,width=1.2,from=0,to=9)=>{
    if(u<=0||u>growth)return;
    line(id,Array.from({length:to-from+1},(_,j)=>at(from+j,u)),width,strength);
  };
  const packet=(id,i,u,strength,length=.13)=>{
    if(u<=0||u>growth)return;
    const points=Array.from({length:11},(_,j)=>at(i,Math.max(0,u-j*length/10)));
    line(id,points,1.5,strength);spark(`${id}-head`,points[0],strength,1.6);
  };
  // Beta.29 v10 language for the alternative reactions: separated soft crests
  // between neighbouring ribs (gaps at each rib), never one jagged polyline
  // through the whole fan.
  const crest=(id,u,strength,width=1.1,from=0,to=9,bow=3)=>{
    if(u<=0||u>growth)return;
    for(let i=from;i<to;i++){const a=at(i,u),b=at(i+1,u);
      line(`${id}-${i}`,Array.from({length:7},(_,j)=>{const f=.16+.68*j/6,n=lerp(a,b,f);n[1]-=bow*m*Math.sin(Math.PI*(f-.16)/.68);return n;}),width,strength);}
  };
  const tine=(id,i,u,length,strength)=>{
    const p=at(i,u),q=at(i,Math.max(0,u-.05)),len=Math.hypot(p[0]-q[0],p[1]-q[1])||1,dx=(p[0]-q[0])/len,dy=(p[1]-q[1])/len;
    for(const [turn,scale] of [[0,1],[-.5,.62],[.5,.62]]){
      const c=Math.cos(turn),sn=Math.sin(turn),tx=dx*c-dy*sn,ty=dx*sn+dy*c,l=length*scale;
      taper(`${id}-${turn}`,Array.from({length:6},(_,j)=>[p[0]+tx*l*j/5,p[1]+ty*l*j/5,p[2],u]),.8,strength);
    }
  };
  switch(a?.id){
    case 'harmonics':
      for(const i of [0,2,4,6,8]){
        const life=frac(t*.12+i*.117),u=.08+.87*(i%4===0?life:1-life),gain=A*Math.sin(Math.PI*life)*.6;
        packet(`harmonic-current-${i}`,i,u,gain,.1);
        if(i<9&&Math.abs(u-.53)<.18)line(`harmonic-cross-${i}`,[at(i,u),at(i+1,Math.min(1,u+.025))],.5,gain*.42);
      }break;
    case 'convergence':
      for(const i of [0,2,4,6,8]){
        const life=frac(t*.27+i*.113),gather=life<.5,u=gather?.92-.8*ease(life*2):.12+.8*ease((life-.5)*2);
        const gain=A*Math.sin(Math.PI*(gather?life*2:(life-.5)*2))*.78;
        packet(`convergence-${i}`,i,u,gain,.14);
        packet(`convergence-pair-${i}`,i+1,Math.max(.05,u-.04),gain*.52,.1);
        if(v.gates?.arcs)line(`convergence-junction-${i}`,[at(i,u),at(i+1,Math.max(.05,u-.04))],.6,gain*.6);
      }break;
    case 'starlit':
      for(let i=0;i<9;i++)for(let j=0;j<3;j++){
        const u=.28+j*.28,life=.5+.5*Math.sin(t*1.3+i*1.7+j*2),s=A*(.25+.7*life),p=at(i,u);
        spark(`constellation-${i}-${j}`,p,s,2.3+life*1.2);
        if((i+j)%2===0)line(`constellation-link-${i}-${j}`,[p,at(i+1,Math.min(1,u+.06))],.85,s*.7);
      }break;
    case 'corona':
      if(v.gates?.arcs)for(let i=0;i<10;i++){
        const p=at(i,.8),tip=at(i,1),previous=at(i,.94),seed=sample(`${v.seed}:corona:${side}:${i}`);
        const len=Math.hypot(tip[0]-previous[0],tip[1]-previous[1])||1;
        const tx=(tip[0]-previous[0])/len,ty=(tip[1]-previous[1])/len,nx=-ty,ny=tx;
        const flow=.5+.5*Math.sin(t*1.65+seed*TAU),reach=(33+19*seed)*A;
        const drift=Math.sin(t*1.25+seed*TAU)*5*m;
        const end=[tip[0]+tx*reach+nx*drift,tip[1]+ty*reach+ny*drift,tip[2],1];
        const control=[tip[0]+tx*reach*.45-nx*drift*.4,tip[1]+ty*reach*.45-ny*drift*.4,tip[2],1];
        taper(`corona-stream-${i}`,bend(p,tip,control,end,24),1.2,A*(.65+.35*flow));
        packet(`corona-charge-${i}`,i,frac(t*.45+i*.17),A*(.7+.3*flow),.22);
      }break;
    case 'circuit':
      if(v.gates?.arcs)for(let i=0;i<9;i++){
        const u=.2+.67*frac(t*.55+i*.173),p=at(i,u),q=at(i+1,Math.min(1,u+.08));
        const pts=Array.from({length:7},(_,j)=>{const f=j/6,n=lerp(p,q,f);n[0]+=side*Math.sin(j*Math.PI/2)*5*m*Math.sin(Math.PI*f);n[1]+=j%2?4*m:0;return n;});
        line(`circuit-${i}`,pts,1.75,A);spark(`circuit-node-${i}`,p,A,2.8);
        if(i%2===0)packet(`circuit-branch-${i}`,i,u,A,.18);
      }break;
    case 'binding':
      for(let j=0;j<4;j++){
        const u=.35+j*.16,points=ribs.map((_,i)=>at(i,Math.max(.05,u+(i-4.5)*.025)));
        line(`binding-${j}`,points,1.65,A*(.8+.1*Math.sin(t*1.2+j)));
        line(`binding-cross-${j}`,ribs.map((_,i)=>at(i,Math.max(.05,u-(i-4.5)*.025))),.85,A*.7);
      }break;
    case 'drain':
      for(let i=0;i<10;i++){
        const u=.12+.82*(1-frac(t*.32+i*.113));
        line(`draining-${i}`,Array.from({length:12},(_,j)=>at(i,Math.min(.99,u+j*.012))),1.5,A*.9);
      }
      for(let j=0;j<2;j++){
        const p=at(4,.07),pts=Array.from({length:37},(_,i)=>{const f=i/36,q=f*TAU*1.4+t*.8+j*Math.PI,rad=(2+f*13)*A;
          return [p[0]+Math.cos(q)*rad,p[1]+Math.sin(q)*rad*.65,p[2],.12];});
        line(`root-drain-${j}`,pts,.75,A*.65);
      }break;
    case 'unravelling':
      if(v.gates?.sparks)for(const i of [0,2,4,6,8,9]){
        const u=tailRoot(v,side,i),p=at(i,u),previous=at(i,Math.max(.05,u-.055));
        const seed=sample(`${v.seed}:peel:${side}:${i}`),life=v.animated?frac(t*.17+seed):seed;
        const fade=Math.sin(Math.PI*life),drop=20+life*(35+24*seed),sway=Math.sin(t*.65+seed*TAU)*7*m;
        const dx=p[0]-previous[0],dy=p[1]-previous[1],len=Math.hypot(dx,dy)||1;
        const end=[p[0]+side*(8+16*seed)*life*m+sway,p[1]+drop,p[2],u];
        const tail=bend(p,[p[0]+dx/len*9*m,p[1]+dy/len*9*m,p[2],u],
          [end[0]-side*(7+8*seed)*m,end[1]-drop*.32,p[2],u],end,24);
        taper(`peeling-${i}`,tail,.64,A*.9*fade);
      }break;
    case 'remnants':
      if(v.gates?.sparks)for(let i=0;i<10;i++){
        const life=v.animated?frac(t*.23+i*.177):.4,p=at(i,.65),dx=side*life*20*m,dy=life*65*m;
        const q=[p[0]+dx,p[1]+dy,p[2],.65];
        line(`remnant-${i}`,[[q[0]-side*6,q[1]-9,q[2],.65],q,[q[0]+side*5,q[1]-3,q[2],.65]],.85,A*Math.sin(Math.PI*life));
      }break;
  }
  for(const b of legacyReactions(v)){
    const q=b.progress,e=b.envelope,k=b.strength,first=out.length;
    switch(b.id){
      case 'impact':{
        const phase=phaseIn(q,.055,.47);
        if(active(phase)){const u=.08+.9*ease(phase),gain=k*Math.sin(Math.PI*phase);
          crest('impact-ripple',u,gain*.9,1.15,1,8,2.5);
          for(const i of [2,7])packet(`impact-release-${i}`,i,u,gain*.7,.09);
        }break;}
      case 'fracture':
        for(let i=0;i<9;i+=2){const u=.2+q*.7,p=at(i,u);line(`impact-crack-${i}`,[at(i,Math.max(0,u-.08)),[p[0]+side*9*e*m,p[1]-5*e*m,p[2],u],at(i+1,u+.03)],1.3,e);}
        break;
      case 'rupture':
        if(v.gates?.sparks)for(let i=0;i<10;i++){
          const p=at(i,.35+.4*q),d=40*q*m,shift=[p[0]+side*d,p[1]+Math.sin(i*3)*d,p[2],p[3]];
          line(`rupture-shard-${i}`,[p,shift,[shift[0]+side*8,shift[1]+6,shift[2],shift[3]]],1.3,e);spark(`rupture-spark-${i}`,shift,e,2);
        }break;
      case 'shock':
        for(let j=0;j<SHOCKS.length;j++){
          const [start,duration,gain]=SHOCKS[j],phase=phaseIn(q,start,duration);if(!active(phase))continue;
          const u=.12+.86*ease(phase),amp=k*gain*ease(phase/.1)*(1-ease((phase-.68)/.32));
          crest(`shock-${j}`,u,amp*.85,1.3,0,9,3.5);
          for(const i of [0,3,6,9])packet(`shock-${j}-${i}`,i,u,amp,.11);
          if(v.gates?.arcs)for(const i of [1,4,7])crest(`shock-branch-${j}`,Math.max(.02,u-.05),amp*.45,.7,i,i+1,-2.5);
        }break;
      case 'stitch':
        // One soft cross-stitch per rib pair behind a fine current: it reads
        // as threads being drawn closed, not a hatched bandage band.
        for(let i=0;i<9;i++){
          const u=.1+.85*ease(q),a=at(i,Math.max(.02,u-.045)),b=at(i+1,u);
          line(`stitch-${i}`,Array.from({length:7},(_,j)=>{const f=j/6,n=lerp(a,b,f);n[1]-=2.5*m*Math.sin(Math.PI*f);return n;}),.8,e*.8);
          if(i%2===0)packet(`stitch-thread-${i}`,i,u,e*.7,.1);
        }break;
      case 'bloom':
        for(const [i,u] of [[0,.6],[2,.48],[4,.72],[6,.4],[8,.68],[9,.84]]){
          const delay=.035+(u-.3)*.38,life=phaseIn(q,delay,.59);if(!active(life))continue;
          const amp=k*Math.sin(Math.PI*life),radius=(3+14*ease(life))*m;
          knot(`bloom-${i}`,i,u,radius,amp);
        }break;
      case 'fan':{
        // The fan's long arc is cast as separated crests that swell in.
        const swell=e*ease(q/.28);
        crest('fan-edge',.84+.14*ease(q),swell*.6,1.2,0,9,4);
        for(let i=0;i<10;i++)packet(`fan-ray-${i}`,i,Math.min(1,.15+unit(q-i*.012)*1.4),e,.23);
        break;}
      case 'crown':
        for(let i=0;i<4;i++){
          const life=unit((q-i*.09)/.6),u=.4+.58*ease(life),s=k*Math.sin(Math.PI*life);
          packet(`crown-ray-${i}`,i,u,s,.28);tine(`crown-tip-${i}`,i,u,9*m,s*.85);
        }break;
      case 'heartbeat':
        for(let j=0;j<HEARTBEATS.length;j++){
          const [start,duration,gain]=HEARTBEATS[j],phase=phaseIn(q,start,duration);if(!active(phase))continue;
          const u=.07+.89*ease(phase),amp=k*gain*Math.sin(Math.PI*phase)*.83;
          arc(`heartbeat-${j}`,u,amp,1.4);
          if(u>.13)arc(`heartbeat-wake-${j}`,u-.035,amp*.3,.7);
          for(const i of [0,4,9])packet(`heartbeat-packet-${j}-${i}`,i,u,amp*.65,.075);
        }break;
      case 'orbit':{
        const n=q*9,i=Math.min(8,Math.floor(n)),f=n-i,u=.65+.18*Math.sin(q*TAU),p=lerp(at(i,u),at(i+1,u),f);
        spark('orbit-mote',p,e,4.0);line('orbit-wake',Array.from({length:15},(_,j)=>{
          const nf=Math.max(0,n-j*.08),ri=Math.min(8,Math.floor(nf));return lerp(at(ri,u),at(ri+1,u),nf-ri);
        }),2.0,e);break;}
      case 'static':
        if(v.gates?.glitches)for(let i=0;i<14;i++){
          const step=Math.floor(q*12),ri=i%10,u=.2+.7*rnd(`${v.seed}:static:${side}:${i}:${step}`),p=at(ri,u),w=(5+7*(i%3))*m;
          line(`static-${i}`,[[p[0]-w,p[1],p[2],u],[p[0]-w*.2,p[1],p[2],u],[p[0]+w*.1,p[1]-3*m,p[2],u],[p[0]+w,p[1]-3*m,p[2],u]],.75,e*(v.gates?.glitchLimit??1));
        }break;
      case 'weave':
        // Two fine threads twist once around each rib at the Reform front
        // (in from the tips as it unravels, back out as it rebuilds).
        for(const i of [0,2,4,6,8,9]){
          const u=Math.max(.03,Math.min(1,v.reformation?.head??q*1.35));for(const sign of [-1,1]){
            const pts=Array.from({length:15},(_,j)=>{const f=j/14,pu=Math.max(.01,u-f*.2),p=at(i,pu),w=Math.sin(f*TAU+q*5)*2.6*sign*m*root(pu)*(1-f*.6);return [p[0]+w,p[1]-w*.4,p[2],pu];});
            line(`weave-${i}-${sign}`,pts,.75,e*(sign>0?1:.7));
          }
          if(i%4===0)spark(`weave-head-${i}`,at(i,u),e*.8,1.4);
        }break;
      case 'recall':
        for(let i=0;i<10;i++){
          const p=at(i,.7),angle=i*2.4+side,dist=recallSpread(q)*35*k*m;
          line(`recall-thread-${i}`,[[p[0]+Math.cos(angle)*dist,p[1]+Math.sin(angle)*dist+dist,p[2],.7],p],.75,e);
          spark(`recall-lock-${i}`,p,e*Math.sin(Math.PI*q),1.7);
        }break;
    }
    // v10: the alternative reactions draw tinted currents, not plain magenta
    // lines that vanish against the magenta ribs at token size.
    const tint=REACTION_KIND_TINT[b.kind]??'base';
    for(let i=first;i<out.length;i++){const part=out[i];if(!part.star){part.highlight=.85;part.tint=tint;}else part.highlight=1;}
  }
  return out;
}
