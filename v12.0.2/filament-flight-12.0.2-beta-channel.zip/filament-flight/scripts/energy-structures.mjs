/** The original filament wing is the only supported structure. Legacy
 * structure flags are read without activating old transforms or transitions. */
import {sampleStructurePoses,poseStructurePoint} from './structure-poses.mjs?v=12.0.2';
export const ENERGY_STRUCTURES=Object.freeze({wings:Object.freeze({label:'Filament wings',description:'Ellie’s original gothic filament wings.'})});
export const STRUCTURES=Object.freeze(['wings']);
const ZERO_VELOCITY=Object.freeze({weights:Object.freeze([0]),unweave:0});
export function validateStructure(value){
  if(value!=='wings')throw new Error('Only the original filament wings are available.');
  return 'wings';
}
export function readSavedStructure(value){
  if(value!=null&&typeof value!=='string')throw new Error('Invalid saved energy structure.');
  return 'wings';
}
export const structureWeights=value=>(validateStructure(value),[1]);
export function readStructureTransition(){return null;}
export function sampleStructure(data,now,animate=true,resume=true,resumePose=true){
  // The pose sampler never reads data.structure (always wings): no copy of data per frame.
  const poses=sampleStructurePoses(data,now,animate,resumePose),size=poses.samples.wings.size;
  return {id:'wings',weights:[1],active:false,progress:1,unweave:0,velocity:ZERO_VELOCITY,animated:animate,
    artworkExtent:Math.max(1,size),poseSamples:poses.samples,poseActive:poses.active,poseProgress:poses.progress,
    rigRequired:Math.abs(size-1)>.000001,phase:'settled'};
}
export function makeStructureTransition(data,to){validateStructure(to);return null;}
/** Kept as inert imports for older preview callers; no alternate coordinates. */
export function structureRib(id,index,t,side=1){validateStructure(id);return [side*27,-13,-22];}
export function structurePoint(id,strandId,t,side=1){validateStructure(id);return [side*27,-13,-22];}
export function transformStructurePoint(point,source,strandId,side,animation){
  return poseStructurePoint('wings',point,side,animation);
}
export function structureStrandStrength(){return 1;}
export function structureBitStation(center,angle,index,side,animation){
  return {center:poseStructurePoint('wings',center,side,animation),angle};
}
