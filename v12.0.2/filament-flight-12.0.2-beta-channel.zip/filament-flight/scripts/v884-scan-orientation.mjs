/** The physical shell is painted in native hardware coordinates, then placed
 * in the owner's world frame. Keep one continuous world bearing after every
 * scan/encounter/wall handoff, rather than easing an angle in a changing frame.
 * This state is render-local; sampling never writes a flag or advances a duty. */
import {scanPurposeTargets,stepScanFacing} from './v886-scan-facing.mjs?v=12.0.2';
const difference=(from,to)=>Math.atan2(Math.sin(to-from),Math.cos(to-from));
const limit=(value,bound)=>Math.max(-bound,Math.min(bound,value));
export const SCAN_TURN_SPEED=3.2;
export const SCAN_TURN_ACCELERATION=14;

export function stepScanOrientation(previous,{heading,now,paused=false}={}){
  if(!Number.isFinite(heading))heading=previous?.heading??0;
  if(!previous||!Number.isFinite(previous.now)||now<previous.now)return {heading,velocity:0,target:heading,now};
  // Command captures and repeated rendering at one clock observe the same
  // body. A pause retains its exact captured angle and drops angular drive.
  if(paused)return {heading,velocity:0,target:heading,now};
  if(now===previous.now)return {...previous};
  const dt=Math.max(0,Math.min(100,now-previous.now))/1000;
  let angle=previous.heading,velocity=previous.velocity??0;
  const target=angle+difference(angle,heading),steps=Math.max(1,Math.ceil(dt*120)),step=dt/steps;
  // Follow a continuous optical sweep without the quarter-second bearing lag
  // of a position-only spring. A discontinuous aim is a new target, never an
  // angular-velocity instruction, and still turns through the bounded drive.
  const rawPace=difference(previous.target??previous.heading,heading)/Math.max(.001,dt),pace=Math.abs(rawPace)<=SCAN_TURN_SPEED*2?limit(rawPace,SCAN_TURN_SPEED):0;
  // Small fixed substeps keep the same restrained response at 30–144 Hz.
  // Bounding angular acceleration also makes a reversal brake before turning.
  for(let i=0;i<steps;i++){
    const acceleration=limit((target-angle)*64+(pace-velocity)*16,SCAN_TURN_ACCELERATION);
    const next=limit(velocity+acceleration*step,SCAN_TURN_SPEED);
    angle+=(velocity+next)*step/2;velocity=next;
  }
  return {heading:angle,velocity,target,now};
}

/** Run after actual positions and optical aims have been chosen, before any
 * status response. Conditions therefore retain authority over their poses. */
export function guardScanOrientation(sample,event,context,hardware,now,previous){
  const state={},targets=scanPurposeTargets(sample,event,context);
  const paused=sample.state?.phase==='paused',clock=Math.min(now,event.conditionPausedAt??Infinity);
  for(const id of Object.keys(sample.positions??{})){
    const basis=(context.transform?.angle??0)+(hardware?.[id]?.hardware?.angle??context.orientations?.[id]??0);
    const heading=basis+(sample.rotations?.[id]??0),target=targets[id],position=sample.positions[id];
    const purpose=target&&Math.hypot(target.x-position.x,target.y-position.y)>1e-7?Math.atan2(target.y-position.y,target.x-position.x)+Math.PI/2:null;
    const phase=sample.phases?.[id],acquiring=phase?.phase==='travel'||phase?.scanStage==='survey'||phase?.scanStage==='close'&&(phase.ordinal??phase.visitIndex)===1&&['moving','settling'].includes(phase.phase);
    const tracking=['relocating','orbit'].includes(sample.scanPurpose?.[id]?.kind);
    const next=purpose==null?stepScanOrientation(previous?.[id],{heading,now:clock,paused}):
      stepScanFacing(previous?.[id],{heading:purpose,initialHeading:heading,now:clock,paused,acquiring,tracking});
    sample.rotations[id]=next.heading-basis;state[id]=next;
  }
  return {sample,state};
}
