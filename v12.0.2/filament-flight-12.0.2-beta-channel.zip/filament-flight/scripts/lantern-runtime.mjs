import {localPerformance} from './performance.mjs?v=12.0.2';
import {refreshAfterLight} from './light-refresh.mjs?v=12.0.2';
import {ID,runtimeConfiguration} from './config.mjs?v=12.0.2';
import {LANTERN_DEFAULTS,LANTERN_METADATA,normalizeLantern,lanternAvailability,lanternEnvelope,stepLantern,sampleLanternChannel,wrapHeading,nativeLanternRotation,groundLanternMounting,stabilizerLanternMounting} from './lantern-model.mjs?v=12.0.2';
import {nativeLightData} from './wing-light.mjs?v=12.0.2';
import {LanternShaders} from './lantern-shaders.mjs?v=12.0.2';
import {lanternHomeStations,lanternEmitters,captureLanternFormation,lanternEmitterSnapshot} from './lantern-emitters.mjs?v=12.0.2';
import {sampleLightAppearance} from './light-appearance.mjs?v=12.0.2';
import {bitLanternMountingVelocities} from './bit-lantern.mjs?v=12.0.2';
import {resolveLanternLock} from './v88-lantern-tools.mjs?v=12.0.2';

const clock=()=>Number(globalThis.game?.time?.serverTime)||Date.now();
const placed=(token,initializing=false)=>!!((globalThis.canvas?.ready||initializing)&&token&&!token.destroyed&&!token.isPreview&&token.document?.parent===canvas.scene&&canvas.scene?.tokens?.get(token.id)===token.document);
const selection=()=>globalThis.canvas?.tokens?.controlled?.map(t=>t.document.uuid).sort().join('|')??'';
const origin=token=>token.document.getLightOrigin?.({x:token.x,y:token.y})??token.center;
const round=(v,steps=100)=>Math.round(v*steps)/steps;
const unit=v=>Math.max(0,Math.min(1,Number.isFinite(v)?v:0));
const lockKey=lock=>lock?`${lock.type}|${lock.sceneId}|${lock.tokenId??''}|${lock.x??''}|${lock.y??''}`:'';
export const LANTERN_MOUNTING_DURATION=700;
export const LANTERN_STABILIZER_GEOMETRY_INTERVAL=1000/30;
/** Continuous lantern changes (position, turn, fade) rebuild the native
 * sources at most this often; see update(). */
export const LANTERN_NATIVE_INTERVAL=1000/30;
const LANTERN_DISCRETE_KEYS=['elevation','level','bright','dim','angle','color','coloration','attenuation'];
const physicalEmitters=(token,snapshot,manager,now,cfg)=>(snapshot.lantern?.stabilizerWeight>0||snapshot.lantern?.mounting==='stabilizers')?
  lanternEmitters(token,snapshot,manager,now,cfg):lanternHomeStations(lanternEmitterSnapshot(snapshot,cfg.localEffects!==false)).map(id=>({id}));
const sharedColour=(alpha,share)=>1-Math.pow(1-unit(alpha),unit(share));

/** Retain the saved home conductor for compatibility with activation metadata.
 * This identity never determines the native light's token-centered origin. */
export function chooseLanternLeader(emitters,previousId){
  return emitters.find(e=>e.id===previousId)??emitters[0]??null;
}
export function nativeLanternData(token,lamp){
  const weight=lamp.beamWeight??lamp.weight,reach=lamp.reach??1;
  // Native Natural Light also tints the background as darkness increases.
  // A weak coloration-only glow left the neutral illumination looking white
  // at night. Keep colour strength on the same reversible power envelope,
  // independently of the cosmetic veil and without changing visibility/range.
  const data=nativeLightData(token,{bright:lamp.bright*reach,dim:lamp.dim*reach,color:'#ff00ff',alpha:round(.9*lamp.intensity*weight,1000),
    luminosity:round(.75*lamp.intensity*weight,1000),attenuation:.85,animation:{type:null,speed:0,intensity:0}});
  return {...data,coloration:10,angle:lamp.width,rotation:nativeLanternRotation(round(lamp.angle,1000))};
}
/** The home instruments share a rounded wash aimed at one distant endpoint.
 * Each native origin is an actual home bit, so Foundry clips walls separately
 * at those physical roots. Core uses MAX illumination and SCREEN coloration:
 * illumination retains its native endpoint, while optical-density shares keep
 * the overlapping coloration at the original magenta intensity. */
function lanternProjectorFrame(token,lamp){
  const base=nativeLanternData(token,lamp),p=origin(token),r=Math.max(base.radius,Math.max(token.w??0,token.h??0)*2),angle=lamp.angle*Math.PI/180;
  return {base,target:{x:p.x+Math.cos(angle)*r,y:p.y+Math.sin(angle)*r}};
}
export function nativeStabilizerLanternData(token,lamp,emitter,{total=1,maxStrength=1,mix=1}={},prepared=null){
  if(!Number.isFinite(emitter?.x)||!Number.isFinite(emitter?.y))throw new Error('The stabilizer lantern has no valid bit position.');
  const {base,target}=prepared??lanternProjectorFrame(token,lamp),
    bearing=wrapHeading(Math.atan2(target.y-emitter.y,target.x-emitter.x)*180/Math.PI),
    share=unit(emitter.strength??1)/Math.max(.00001,total);
  // Each native source keeps its own nested animation object even though the
  // stable token origin/range/target was prepared once for this display frame.
  return {...base,animation:{...base.animation},x:emitter.x,y:emitter.y,alpha:round(sharedColour(base.alpha,share*unit(mix)),10000),
    luminosity:round(base.luminosity*unit(mix)*unit(emitter.strength??1)/Math.max(.00001,maxStrength),10000),
    angle:180,rotation:nativeLanternRotation(round(bearing,1000))};
}

export function lanternDataChanged(a,b){
  return !a||['x','y','elevation','level','bright','dim','angle','rotation','alpha','luminosity','color','coloration','attenuation'].some(key=>a[key]!==b[key]);
}

/** A native cone and its physical instruments share one quiet aim envelope.
 * Live bearings travel on a bounded ephemeral channel; only key release saves
 * the final angle. No movement, token rotation or native-light writes occur. */
export class LanternRuntime {
  constructor(manager,{shaders=new LanternShaders(),edges=manager.lights?.edges??null,now=clock,emitters=physicalEmitters}={}){
    this.manager=manager;this.shaders=shaders;this.edges=edges;this.now=now;this.emitters=emitters;this.records=new Map();this.samples=new WeakMap();this.leases=new WeakMap();this.sequence=0;this.lastTick=-Infinity;
    this.receive=this.receive.bind(this);this.blur=()=>void this.endAim();
  }
  start(){
    if(this.listening)return;this.listening=true;
    globalThis.game?.socket?.on?.(`module.${ID}`,this.receive);
    globalThis.window?.addEventListener?.('blur',this.blur);
    this.visibility=()=>{if(globalThis.document?.hidden)void this.endAim();};
    globalThis.document?.addEventListener?.('visibilitychange',this.visibility);
  }
  request(){refreshAfterLight();}
  frameInputs(token,now=this.now(),raw){
    if(this.aim?.token===token)this.aimAt(token,globalThis.canvas?.mousePosition);
    const aim=this.aim?.token===token?this.aim:null,lease=this.leases.get(token.document);
    const inputs=[aim,aim?.angle,lease,!!lease&&lease.expires>=now],
      saved=(arguments.length>=3?raw:token.document?.flags?.[ID]?.flight)?.lantern;
    // FlightManager already read this flag for its canonical input vector.
    // Dormant/unlocked lamps retain the previous four-value fast path with no
    // flag read, settings normalization, target lookup or bearing allocation.
    if(!saved?.enabled||!saved.lock)return inputs;
    const memory=this.samples.get(token.document),key=lockKey(saved.lock),
      subject=resolveLanternLock(token,saved?.lock,{fallbackAngle:memory?.lockChoice===key?memory?.lockHeading??saved?.angle:saved?.angle});
    // A moving target can change another token's canonical frame even when
    // Ellie herself has not moved and this display timestamp is unchanged.
    inputs.push(key,subject.angle,subject.status);return inputs;
  }
  safeHeading(token,fallback=0){
    token=token?.object??token;const memory=this.samples.get(token?.document);
    return Number.isFinite(memory?.angle)?memory.angle:wrapHeading(fallback);
  }
  /** An explicit new subject wins over mouse leases, including a key still
   * held while its queued command completes. No final angle write is made. */
  clearAimOverride(token){
    token=token?.object??token;
    if(this.aim?.token===token)void this.endAim({persist:false});
    this.leases.delete(token?.document);
    const memory=this.samples.get(token?.document);if(memory)delete memory.lockSuppressed;
  }
  decorate(token,snapshot,now=this.now()){
    if(!token?.document)return snapshot;
    if(this.aim?.token===token)this.aimAt(token,globalThis.canvas?.mousePosition);
    const supplied=snapshot.requested?.lantern??snapshot.lantern;
    const settings=normalizeLantern(supplied?Object.fromEntries([...Object.keys(LANTERN_DEFAULTS),...LANTERN_METADATA].filter(k=>Object.hasOwn(supplied,k)).map(k=>[k,supplied[k]])):null),doc=token.document;
    if(settings.enabled&&settings.started===undefined){const saved=doc.getFlag?.(ID,'flight')?.started;settings.started=Number.isFinite(saved)&&saved>=0?saved:0;}
    const lease=this.leases.get(doc);
    if(lease&&lease.expires<now)this.leases.delete(doc);
    let memory=this.samples.get(doc);
    const key=lockKey(settings.lock),newChoice=memory?.lockChoice!==key,
      subject=settings.lock?resolveLanternLock(token,settings.lock,{fallbackAngle:!newChoice?memory?.lockHeading??settings.angle:settings.angle}):null,
      suppressed=memory?.lockSuppressed===key&&key!=='',
      // A saved subject choice supersedes an older remote mouse lease. The
      // owner's local held aim is immediate; its queued unlock lets observers
      // consume subsequent aim packets without reviving a stale subject.
      target=this.aim?.token===token?this.aim.angle:lease&&lease.expires>=now&&!settings.lock?lease.angle:
        settings.lock&&!suppressed?subject.angle:settings.angle;
    // Disabled old files keep their original geometry/cache signatures.
    if(!settings.enabled&&!memory?.weight&&!memory?.beamWeight){
      const remaining=lanternEnvelope(settings,now);
      if(!remaining.weight&&!remaining.beamWeight)return snapshot;
    }
    // Hiding cosmetic effects on this browser does not extinguish shared
    // illumination. Allocation preparation disables local drawing as a whole;
    // retain the mechanically deployed home count for this native source.
    const cfg=runtimeConfiguration(),availableSnapshot=lanternEmitterSnapshot(snapshot,cfg.localEffects!==false);
    const mounting=stabilizerLanternMounting(availableSnapshot,settings)?'stabilizers':'token',homes=lanternHomeStations(availableSnapshot),
      physicalAvailability=Math.min(1,homes.reduce((n,id)=>n+unit(availableSnapshot.bitCount?.values?.[['leftUpper','rightUpper','leftLower','rightLower'].indexOf(id)]??1),0))*unit(availableSnapshot.bitDeployment??1),
      available=cfg.controlGems===false?0:mounting==='stabilizers'?physicalAvailability:lanternAvailability(availableSnapshot);
    const mountingWasActive=memory?.weight>.0001,mountingPreviousAt=memory?.at;
    memory=stepLantern(memory,{...settings,angle:target},available,now);this.samples.set(doc,memory);
    if(newChoice)delete memory.lockSuppressed;
    memory.lockChoice=key;
    if(subject?.status==='tracking')memory.lockHeading=subject.angle;
    else if(newChoice)memory.lockHeading=settings.angle;
    if(memory.mounting===undefined||!mountingWasActive||cfg.transitions===false||cfg.reduced||snapshot.effective?.reducedMotion===true){
      memory.mounting=mounting;memory.stabilizerWeight=mounting==='stabilizers'?1:0;memory.stabilizerVelocity=0;delete memory.mountingTransition;
    }
    else if(memory.mounting!==mounting){
      const previous={...availableSnapshot,lantern:{...settings,...memory,groundStyle:memory.groundStyle??settings.groundStyle,mounting:memory.mounting,active:memory.weight>.0001}},
        captured=captureLanternFormation(token,previous,this.manager,now,homes,{...cfg,localEffects:cfg.localEffects!==false,actual:true}),
        destination={...availableSnapshot,lantern:{...settings,...memory,groundStyle:settings.groundStyle,mounting,stabilizerWeight:mounting==='stabilizers'?1:0,
          mountingTransition:undefined,active:memory.weight>.0001}},
        targets=captureLanternFormation(token,destination,this.manager,now,homes,{...cfg,localEffects:cfg.localEffects!==false,actual:true,forceSample:true}),
        velocities=bitLanternMountingVelocities({...previous,compactBits:memory.compactBits??previous.compactBits});
      memory.mountingTransition={from:memory.mounting,to:mounting,fromWeight:memory.stabilizerWeight??(memory.mounting==='stabilizers'?1:0),
        fromVelocity:memory.stabilizerVelocity??0,started:now,duration:LANTERN_MOUNTING_DURATION,progress:0,poses:captured.formationCapture,targets:targets.formationCapture,velocities,
        wingScale:availableSnapshot.compactBits===true?3.5:availableSnapshot.options?.wingScale??3.5,gemSize:availableSnapshot.gems?.size??1,
        ...(memory.compactBits===true&&availableSnapshot.compactBits===true&&!availableSnapshot.rendering?.wingsActive?{compact:true}:{})};
      memory.mounting=mounting;
    }
    if(memory.mountingTransition){
      const transition=memory.mountingTransition;
      // A server clock correction may move backwards. Keep the displayed
      // handoff phase and rebase its remaining duration; never rewind pieces
      // toward their capture or invent another mounting command.
      if(Number.isFinite(mountingPreviousAt)&&now<mountingPreviousAt)
        transition.started=now-unit(transition.progress)*transition.duration;
      const progress=Math.max(unit(transition.progress),unit((now-transition.started)/transition.duration)),destination=mounting==='stabilizers'?1:0;
      const mix=sampleLanternChannel(transition.fromWeight,destination,transition.fromVelocity??0,progress*transition.duration,transition.duration);
      transition.progress=progress;memory.stabilizerWeight=mix.value;memory.stabilizerVelocity=mix.velocity;
      if(progress>=1)delete memory.mountingTransition;
    }
    memory.groundStyle=settings.groundStyle;memory.compactBits=availableSnapshot.compactBits===true;
    memory.leader=chooseLanternLeader(lanternHomeStations(availableSnapshot).map(id=>({id})),settings.leader)?.id??null;
    const lamp={...settings,angle:memory.angle,weight:memory.weight,active:memory.weight>.0001,
      aiming:this.isAiming(token),lockStatus:settings.lock&&!suppressed?subject.status:'none',available,clock:now/1000,poseClock:memory.poseClock,poseNow:memory.poseNow,leader:memory.leader,
      body:memory.body,beamWeight:memory.beamWeight,reach:memory.reach,transition:memory.transition,shuttingDown:memory.shuttingDown,phase:memory.phase,
      formationAngle:memory.formationAngle,formationStartAngle:memory.formationStartAngle,
      mounting,stabilizerWeight:memory.stabilizerWeight,mountingTransition:memory.mountingTransition,
      poseAnimated:cfg.gemAnimation!==false&&snapshot.requested?.gemMotion?.animated!==false,
      poseStationMotion:cfg.gemStationMotion!==false&&snapshot.requested?.gemMotion?.stationMotion!==false};
    return {...snapshot,lantern:lamp};
  }
  /** A key-held session follows its character pin rather than scene selection.
   * The guard is local and shares this runtime's existing display/light tick. */
  guardAim(token,guard){
    token=token?.object??token;
    if(this.aim?.token!==token||typeof guard!=='function')return false;
    this.aim.controlGuard=guard;return true;
  }
  checkAimGuard(){
    const a=this.aim;if(typeof a?.controlGuard!=='function')return true;
    let valid=false;try{valid=a.controlGuard()===true;}catch{}
    if(!valid)void this.endAim({persist:false});
    return valid;
  }
  isAiming(token){this.checkAimGuard();return !!this.aim&&(!token||this.aim.token===(token.object??token));}
  beginAim(token){
    token=token?.object??token;
    if(!placed(token)||!token.document.isOwner||token.document.hidden||!token.document.getFlag(ID,'flight')?.lantern?.enabled||!runtimeConfiguration().effectsEnabled)return false;
    if(this.aim?.token===token)return true;
    if(this.aim)void this.endAim();
    const settings=normalizeLantern(token.document.getFlag(ID,'flight')?.lantern);
    const memory=this.samples.get(token.document);
    if(memory&&settings.lock)memory.lockSuppressed=lockKey(settings.lock);
    const started=this.now(),generation=++this.sequence;
    this.aim={token,angle:settings.angle,selection:selection(),lastPublish:-Infinity,session:`${globalThis.game?.user?.id??''}:${generation}:${started}`,started,generation,sequence:0};
    this.aimAt(token,globalThis.canvas?.mousePosition);this.sync(token);this.manageTicker();return true;
  }
  aimAt(token,point){
    token=token?.object??token;
    if(!this.checkAimGuard())return false;
    if(this.aim?.token!==token||!Number.isFinite(point?.x)||!Number.isFinite(point?.y))return false;
    const p=origin(token);if(!p||Math.hypot(point.x-p.x,point.y-p.y)<4)return false;
    this.aim.angle=wrapHeading(Math.atan2(point.y-p.y,point.x-p.x)*180/Math.PI);return true;
  }
  publish(final=false){
    const a=this.aim;if(!a)return;
    // A scene change or replacement can reuse this local token id. Never
    // publish an old session under the new scene or token document.
    if(!placed(a.token)||!globalThis.game?.user)return;
    const now=this.now();if(!final&&now-a.lastPublish<100)return;
    a.lastPublish=now;
    globalThis.game?.socket?.emit?.(`module.${ID}`,{type:'lanternAim',sceneId:canvas.scene.id,tokenId:a.token.id,
      userId:game.user.id,session:a.session,started:a.started,sent:now,generation:a.generation,sequence:++a.sequence,angle:a.angle,final});
  }
  async endAim({persist=true}={}){
    const a=this.aim;if(!a)return false;
    this.publish(true);
    this.leases.set(a.token.document,{session:a.session,started:a.started,generation:a.generation,sequence:a.sequence,angle:a.angle,expires:this.now()+2500});
    this.aim=null;this.manageTicker();
    if(persist&&placed(a.token)&&a.token.document.isOwner){
      // Blur, visibility changes and a newer aim session also finish a held
      // key. Keep its pin guard through the API's queued angle persistence.
      const service=this.manager.bits?.service,save=()=>this.api?.aimLantern(a.token,a.angle);
      try{await (typeof a.controlGuard==='function'&&service?.withControlGuard?
        service.withControlGuard(a.token,a.controlGuard,save):save());}catch(error){this.manager.report(error);}
    }
    return true;
  }
  receive(message){
    if(message?.type!=='lanternAim'||message.sceneId!==globalThis.canvas?.scene?.id||message.userId===globalThis.game?.user?.id||
      !Number.isFinite(message.angle)||message.angle<0||message.angle>=360||!Number.isInteger(message.sequence)||message.sequence<1||
      !Number.isFinite(message.started)||message.started<0||!Number.isFinite(message.sent)||!Number.isInteger(message.generation)||message.generation<1||
      typeof message.session!=='string'||message.session.length>128||typeof message.final!=='boolean')return;
    if(message.started>this.now()+5000||message.sent>this.now()+5000||message.sent<this.now()-5000)return;
    const token=canvas.tokens?.get?.(message.tokenId),user=game.users?.get?.(message.userId),doc=token?.document;
    if(!placed(token)||!user?.active||doc.hidden||!doc.testUserPermission?.(user,'OWNER')||!doc.getFlag(ID,'flight')?.lantern?.enabled)return;
    const old=this.leases.get(doc);
    if(old&&(message.started<old.started||message.started===old.started&&message.generation<old.generation))return;
    if(old?.session===message.session&&message.sequence<=old.sequence)return;
    this.leases.set(doc,{session:message.session,started:message.started,generation:message.generation,sequence:message.sequence,angle:message.angle,expires:this.now()+(message.final?2500:1200)});
    this.sync(token);
  }
  sync(token,options={}){
    if(!localPerformance.active)return this.syncLighting(token,options);
    return localPerformance.measure('lighting',()=>this.syncLighting(token,options));
  }
  syncLighting(token,{initializing=false,notify=true,retry=false}={}){
    if(!token)return false;const cfg=runtimeConfiguration(),raw=token.document?.getFlag(ID,'flight');
    if(!placed(token,initializing)||!cfg.effectsEnabled||raw==null)return this.remove(token,{notify});
    let replacementDirty=false;
    for(const other of [...this.records.keys()])if(other!==token&&other.document.uuid===token.document.uuid)
      replacementDirty=this.remove(other,{notify:false})||replacementDirty;
    const lamp=normalizeLantern(raw.lantern);
    if(!lamp.enabled&&!this.records.has(token)&&!lanternEnvelope(lamp,this.now()).weight){if(replacementDirty&&notify)this.request();return replacementDirty;}
    let r=this.records.get(token);
    if(!r){r={token,emitters:new Map(),failed:null,get source(){return this.emitters.values().next().value?.source??null;}};this.records.set(token,r);}
    if(retry)r.failed=null;
    let dirty=replacementDirty;try{dirty=this.update(r,cfg,this.now())||dirty;}catch(error){dirty=this.fail(r,error)||dirty;}
    if(dirty&&notify)this.request();this.manageTicker();return dirty;
  }
  update(r,cfg,now,{displayFrame=false}={}){
    if(r.failed)return false;
    const snapshot=this.manager.frameState?.(r.token,now,{displayFrame})??this.manager.sampleState(r.token,now),lamp=snapshot?.lantern;
    r.waiting=!!lamp?.enabled&&!r.token.document.hidden&&lamp.intensity>0&&Math.max(lamp.bright,lamp.dim)>0&&(lamp.available??lanternAvailability(snapshot))>0;
    r.returning=!!lamp?.active&&!r.token.document.hidden;
    if(!lamp?.active||(lamp.beamWeight??lamp.weight)<=.0001||(lamp.reach??1)<=.0001||lamp.intensity<=0||Math.max(lamp.bright,lamp.dim)<=0||r.token.document.hidden){return this.releaseSource(r);}
    const emitters=this.emitters(r.token,snapshot,this.manager,now,{...cfg,localEffects:cfg.localEffects!==false}),
      nominalMountMix=unit(lamp.stabilizerWeight??(lamp.mounting==='stabilizers'?1:0)),
      groundMount=groundLanternMounting(snapshot,lamp)||lamp.mountingTransition?.compact===true&&nominalMountMix>0&&groundLanternMounting(snapshot,{groundStyle:'stabilizers'}),
      homeIds=new Set(lanternHomeStations(lanternEmitterSnapshot(snapshot,cfg.localEffects!==false))),
      leader=chooseLanternLeader(nominalMountMix>0||lamp.mounting==='stabilizers'?[...homeIds].map(id=>({id})):emitters,lamp.leader),
      physical=nominalMountMix>0?emitters.filter(e=>homeIds.has(e.id)&&(!e.route?.startsWith('compact-')||groundMount)&&
        Number.isFinite(e.x)&&Number.isFinite(e.y)&&unit(e.strength??1)>.00001):[],
      total=physical.reduce((n,e)=>n+unit(e.strength??1),0),maxStrength=physical.reduce((n,e)=>Math.max(n,unit(e.strength??1)),0),
      // Wing-presence handoffs hide both render routes briefly. Keep the
      // token projector through that seam, and acquire bit illumination only
      // in proportion to actual visible wing-root strength. Renormalizing a
      // tiny newly painted root must never give it full native illumination.
      mountMix=nominalMountMix*maxStrength,tokenMix=groundMount?1-nominalMountMix:1-mountMix,projectors=[];
    const projectorFrame=physical.length?lanternProjectorFrame(r.token,lamp):null;
    if(leader&&tokenMix>0){
      const data=projectorFrame?{...projectorFrame.base,animation:{...projectorFrame.base.animation}}:nativeLanternData(r.token,lamp);
      if(tokenMix<1){data.alpha=round(sharedColour(data.alpha,tokenMix),10000);data.luminosity=round(data.luminosity*tokenMix,10000);}
      projectors.push({id:'home',leader:leader.id,data,stabilizer:false});
    }
    for(const emitter of physical){
      const data=nativeStabilizerLanternData(r.token,lamp,emitter,{total,maxStrength,mix:mountMix},projectorFrame);
      if(data.alpha<=0&&data.luminosity<=0)continue;
      projectors.push({id:`stabilizer.${emitter.id}`,leader:emitter.id,stabilizer:true,data});
    }
    const ids=new Set(projectors.map(e=>e.id)),anchorKey=[r.token.x,r.token.y,r.token.rotation,r.token.w,r.token.h,r.token.document.level,r.token.document.elevation].join('|'),
      appearanceEffects=projectors.length?sampleLightAppearance(snapshot,cfg,now,{seed:r.token.document.uuid}):null;
    let dirty=false;
    const local=globalThis.performance?.now?.()??now,nativeDue=!(local-(r.nativeAt??-Infinity)<LANTERN_NATIVE_INTERVAL-1e-6);let rebuilt=false;
    for(const [id,entry]of r.emitters)if(!ids.has(id)){dirty=this.releaseEmitter(entry)||dirty;r.emitters.delete(id);}
    for(const emitter of projectors){
      let entry=r.emitters.get(emitter.id);
      if(!entry){
        const Source=globalThis.foundry?.canvas?.sources?.PointLightSource;
        if(!Source)throw new Error('Foundry v14 PointLightSource is unavailable.');
        const sourceId=`${ID}.lantern.${r.token.document.uuid}${emitter.stabilizer?`.${emitter.id}`:''}`,source=new Source({object:r.token,sourceId});
        if(source.sourceId!==sourceId){source.destroy?.();throw new Error('The lantern source did not retain its independent ID.');}
        entry={source,data:null};r.emitters.set(emitter.id,entry);
      }
      entry.leader=emitter.leader;
      const data=emitter.data,detached=!entry.source.attached,
        smallMotionOnly=emitter.stabilizer&&entry.data&&now>=(entry.lastNativeAt??-Infinity)&&entry.aimAngle===lamp.angle&&entry.anchorKey===anchorKey&&
          !['elevation','level','bright','dim','angle','alpha','luminosity','color','coloration','attenuation'].some(key=>entry.data[key]!==data[key])&&
          Math.hypot(data.x-entry.data.x,data.y-entry.data.y)<Math.max(8,Math.max(r.token.w??0,r.token.h??0)*.08),
        geometryDue=!smallMotionOnly||now-(entry.lastNativeAt??-Infinity)>=LANTERN_STABILIZER_GEOMETRY_INTERVAL-1e-6;
      // Beta.35: while she moves every source's position changes on every
      // display frame, and each change rebuilt the native light (5 sources ×
      // 164 Hz: 540 rebuilds and perception refreshes a second, 2 ms a frame).
      // Position, turn and fade now rebuild at most 30 times a second (as her
      // wing light always has), all of this lantern's sources on the same
      // frame; the latest values always land. Size, colour, height, a new
      // source and live aiming still rebuild at once.
      const discrete=!entry.data||LANTERN_DISCRETE_KEYS.some(key=>entry.data[key]!==data[key])||this.aim?.token===r.token;
      if(detached||lanternDataChanged(entry.data,data)&&geometryDue&&(discrete||nativeDue)){
        // Core initialization can reset/rebind uniforms after its shader hook.
        // Keep that work native, then apply our complete latest layout once the
        // call returns; no hook may bind an incompletely restored lantern.
        this.shaders.suspend?.(entry.source);
        localPerformance.count('lightRebuilds');entry.source.initialize(data,{reset:!!detached});if(!entry.source.attached)entry.source.add();
        entry.data={...data,animation:{...data.animation}};entry.lastNativeAt=now;entry.aimAngle=lamp.angle;entry.anchorKey=anchorKey;dirty=true;rebuilt=true;
      }
      const opticalLamp=emitter.stabilizer?{...lamp,angle:wrapHeading(entry.data.rotation+90),width:entry.data.angle,airborneWash:true,washWidth:lamp.width}:lamp;
      const shaderState=this.shaders.update(entry.source,{...opticalLamp,weight:lamp.beamWeight??lamp.weight,clock:now/1000,reduced:cfg.reduced||snapshot.effective?.reducedMotion===true,localEffects:cfg.localEffects!==false,
        artwork:snapshot.lanternArtwork==='plain'?'plain':snapshot.lightAppearance==='current'?'prior':snapshot.lanternArtwork??'flow',
        appearanceEffects});
      // Share the circular light's visual visibility pass, while the lantern
      // adapter alone owns its native layer shaders. Optical style changes
      // refresh coverage once without rebuilding native light geometry.
      const softened=lamp.edgeStyle!=='classic'&&(lamp.edgeSoftness??.65)>0&&shaderState?.active!==false;
      const edgeKey=softened?`${lamp.edgeSoftness??.65}|${opticalLamp.angle}|${opticalLamp.width}`:'native';
      if(softened)this.edges?.track(entry.source,lamp.edgeSoftness??.65,{shader:false,angle:opticalLamp.angle,width:opticalLamp.width});
      else this.edges?.untrack(entry.source);
      if(entry.edgeKey!==edgeKey){entry.edgeKey=edgeKey;dirty=true;}
    }
    if(rebuilt)r.nativeAt=local;
    return dirty;
  }
  releaseEmitter(entry){
    const s=entry?.source;if(!s)return false;
    entry.source=null;entry.data=null;entry.edgeKey=null;
    const errors=[];
    for(const cleanup of [()=>this.edges?.untrack(s),()=>this.shaders.release(s),()=>s.remove(),()=>s.destroy()]){
      try{cleanup();}catch(error){errors.push(error);}
    }
    if(errors.length)throw new AggregateError(errors,'Lantern source cleanup failed.');
    return true;
  }
  releaseSource(r){
    if(!r)return false;let dirty=false;const errors=[];
    for(const entry of r.emitters.values()){
      try{dirty=this.releaseEmitter(entry)||dirty;}catch(error){dirty=true;errors.push(error);}
    }
    r.emitters.clear();
    if(errors.length)throw new AggregateError(errors,'Lantern sources could not all be released.');
    return dirty;
  }
  fail(r,error){
    if(r)r.failed=String(error?.message??error);let dirty=false;
    try{dirty=this.releaseSource(r);}catch{dirty=true;}
    this.manager.report(new Error(`Lantern light could not render. ${error?.message??error}`));return dirty;
  }
  remove(token,{notify=true}={}){
    const r=this.records.get(token);if(!r)return false;this.records.delete(token);
    if(this.aim?.token===token)void this.endAim({persist:false});
    this.samples.delete(token.document);this.leases.delete(token.document);
    let dirty=false;try{dirty=this.releaseSource(r);}catch(error){this.manager.report(error);dirty=true;}
    if(dirty&&notify)this.request();this.manageTicker();return dirty;
  }
  manageTicker(){
    const needed=this.aim||[...this.records.values()].some(r=>!r.failed&&(r.source||r.waiting||r.returning));
    if(needed&&!this.ticker&&globalThis.canvas?.ready&&canvas.app?.ticker){this.ticker=canvas.app.ticker;this.lastTick=-Infinity;this.ticker.add(this.tick,this,-21);}
    else if(!needed&&this.ticker){this.ticker.remove(this.tick,this);this.ticker=null;}
  }
  tick(){
    if(!localPerformance.active)return this.tickLighting();
    return localPerformance.measure('lighting',()=>this.tickLighting());
  }
  tickLighting(){
    if(!globalThis.canvas?.ready||globalThis.document?.hidden)return;
    const now=this.now();if(now===this.lastTick)return;this.lastTick=now;
    if(this.aim&&this.checkAimGuard()){
      const a=this.aim;
      if(!placed(a.token)||!a.token.document.isOwner||a.token.document.hidden||(!a.controlGuard&&selection()!==a.selection)||!a.token.document.getFlag(ID,'flight')?.lantern?.enabled)void this.endAim();
      else{this.aimAt(a.token,canvas.mousePosition);this.publish();}
    }
    const cfg=runtimeConfiguration();let dirty=false;
    for(const [token,r]of this.records){
      if(!placed(token)||!cfg.effectsEnabled){dirty=this.remove(token,{notify:false})||dirty;continue;}
      try{dirty=this.update(r,cfg,now,{displayFrame:true})||dirty;}catch(error){dirty=this.fail(r,error)||dirty;}
    }
    if(dirty)this.request();this.manageTicker();
  }
  rebuild({initializing=false,notify=true,retry=false}={}){
    let dirty=false;
    for(const token of [...this.records.keys()])if(!placed(token,initializing))dirty=this.remove(token,{notify:false})||dirty;
    for(const token of globalThis.canvas?.tokens?.placeables??[])dirty=this.sync(token,{initializing,notify:false,retry})||dirty;
    if(dirty&&notify)this.request();this.manageTicker();
  }
  clear(){
    void this.endAim({persist:false});let dirty=false;
    for(const token of [...this.records.keys()])dirty=this.remove(token,{notify:false})||dirty;
    this.samples=new WeakMap();this.leases=new WeakMap();this.shaders.clear();
    if(this.ticker){this.ticker.remove(this.tick,this);this.ticker=null;}
    if(dirty)this.request();
  }
  status(token){const r=this.records.get(token);return {localActive:!!r&&[...r.emitters.values()].some(e=>e.source?.active),emitters:r?.emitters.size??0,error:r?.failed??null,shader:this.shaders.status?.(r?.source)??null,edge:this.edges?.status?.(r?.source)??null};}
}
