import {localPerformance} from './performance.mjs?v=12.0.2';
import {sampleV7Appearance} from './v7-ensemble.mjs?v=12.0.2';
import {classicTreatmentStyle,isV7Treatment} from './hardlight-v7-medkit.mjs?v=12.0.2';
import {AUDIO_SLOTS,resolveAudio,mergeAudio,validateAudioPreview,loopOffset,distanceGain,poseAudioSlot,conditionAudioSlot,reactionAudioSlot} from './audio-model.mjs?v=12.0.2';
import {trackMovement,fieldPresence} from './flight-dynamics.mjs?v=12.0.2';
import {conditionSeverity,profileFor} from './conditions.mjs?v=12.0.2';
import {treatmentPhase,TREATMENT_TIMING} from './hardlight-treatment.mjs?v=12.0.2';
import {LIVING_BIT_PROGRAMS,sampleLivingScene} from './bit-behaviour.mjs?v=12.0.2';
import {formationFlowState} from './bit-formation-flow.mjs?v=12.0.2';
import {TREATMENT_AUDIO_STAGES,normalizeTreatmentAudio,treatmentAudioSlot} from './treatment-audio.mjs?v=12.0.2';
import {blendCharacter} from './flight-character.mjs?v=12.0.2';
import {soundFor,noteAsked,styledSrc} from './v12/sound-set.mjs?v=12.0.2';

const ID='filament-flight',INTERVAL=100,MIN_GAIN=0.0008;
const cap=(v,min=0,max=1)=>Math.max(min,Math.min(max,Number.isFinite(v)?v:0));
const cuePriority=id=>id.startsWith('medkit')?6:id.startsWith('warp')?4:id.startsWith('routine_')?3:id.startsWith('reaction_critical')?5:id.startsWith('reaction_')?4:id==='critical'?5:['damage','heal','collapse','reform'].includes(id)?4:
  ['flare','pulse','stutter','takeoff','landing'].includes(id)?3:
  // (12.0.0-beta.7) the v12 set: a cloak, a decoy or a landing style's sound is not cut off by a wing pulse; its warps are warps (4)
  id.startsWith('cloak')||id.startsWith('decoy')||id.startsWith('landing')?3:['flightShieldScalemail','flightShieldRotor','flightShieldWingwrap'].includes(id)?2:
  id.startsWith('pose')?2:id==='bank'?1:0;

/** Blend existing recordings against the same formation/health envelopes as
 * the wings. These are gain targets, not more sounds or independent clocks. */
export function audioLevels(snapshot,moving,previousCondition=null,duck=1) {
  const condition=snapshot.effective?.condition??'normal';
  const semantic=snapshot.visual?.semanticProfile??profileFor(condition);
  const presence=fieldPresence(snapshot.formation),energy=cap(semantic.energy,.055,1.06)*presence;
  let bed=condition;
  // Normal is a recovery destination. Retain the outgoing texture quietly
  // until the same HP/manual blend has restored the field, without restarting it.
  if(bed==='normal'&&previousCondition&&conditionSeverity(semantic,previousCondition)>.001)bed=previousCondition;
  const severity=bed==='normal'?0:conditionSeverity(semantic,bed);
  const travel=cap(moving)*(snapshot.effective?.mode==='grounded'?0:cap(snapshot.rendering?.flightFactor??1));
  return {idle:Math.sqrt(1-.92*travel)*energy*duck,motion:Math.sqrt(.92*travel)*energy*duck,
    condition:bed==='normal'?null:`condition${bed[0].toUpperCase()}${bed.slice(1)}`,
    conditionGain:severity*(bed==='collapsed'?.35:.8)*presence*duck};
}
const getFlag=token=>token?.document?.getFlag?.(ID,'audio');
const clock=()=>globalThis.game?.time?.serverTime??Date.now();
const catchPromise=value=>{if(value?.catch)value.catch(()=>{});};
const point=token=>{
  const mesh=token?.mesh;
  if(Number.isFinite(mesh?.x)&&Number.isFinite(mesh?.y))return {x:mesh.x,y:mesh.y};
  const center=token?.center;if(Number.isFinite(center?.x)&&Number.isFinite(center?.y))return center;
  return {x:(token?.document?.x??0)+(token?.w??0)/2,y:(token?.document?.y??0)+(token?.h??0)/2};
};
/** A listener is a controlled token, or the assigned character on this scene.
 * There is deliberately no camera-centre or omniscient-GM listening fallback. */
export function audioListeners(canvas=globalThis.canvas,user=globalThis.game?.user){
  const valid=t=>t&&!t.destroyed&&!t.isPreview&&t.document&&t.document.parent?.id===canvas?.scene?.id;
  const controlled=(canvas?.tokens?.controlled??[]).filter(valid);
  if(controlled.length)return controlled;
  const actor=user?.character;if(!actor)return [];
  return (canvas?.tokens?.placeables??[]).filter(t=>valid(t)&&t.isOwner!==false&&
    ((!!actor.id&&t.document.actor?.id===actor.id)||(!!actor.uuid&&t.document.actor?.uuid===actor.uuid)));
}
export function sourceAudible(token,audio,{canvas=globalThis.canvas,user=globalThis.game?.user}={}){
  if(!token||token.destroyed||token.isPreview||!canvas?.ready||token.document?.parent?.id!==canvas.scene?.id)return false;
  if(token.document?.hidden)return false;
  return audio.audience!=='local'||(!!audio.localUserId&&audio.localUserId===user?.id);
}
export function listenerDistance(token,listeners,canvas=globalThis.canvas){
  const origin=point(token),pixels=canvas?.grid?.size??canvas?.scene?.grid?.size??canvas?.dimensions?.size??100;
  const units=canvas?.scene?.grid?.distance??canvas?.dimensions?.distance??5;
  if(!Number.isFinite(pixels)||pixels<=0||!Number.isFinite(units)||units<=0)return Infinity;
  let best=Infinity;for(const listener of listeners){const p=point(listener);best=Math.min(best,Math.hypot(p.x-origin.x,p.y-origin.y)*units/pixels);}return best;
}
export function audioGain(token,audio,slot,{canvas=globalThis.canvas,user=globalThis.game?.user,listeners,distance}={}){
  if(!slot||!sourceAudible(token,audio,{canvas,user}))return 0;
  if(audio.audience==='local'&&!audio.localRespectsRadius)return slot.gain;
  const d=distance??listenerDistance(token,listeners??audioListeners(canvas,user),canvas);
  return slot.gain*distanceGain(d,slot.radius,audio.distanceFade);
}
const sampleKey=s=>({enabled:!!s?.enabled||!!s?.transition?.active,mode:s?.effective?.mode??'grounded',
  pose:s?.effective?.pose??s?.requested?.pose??'neutral',condition:s?.effective?.condition??'normal',
  bits:!!(s?.bitsDeployed||((s?.bitDeployment??0)>.01)),compact:!!s?.compactBits,bitCount:s?.gems?.count??s?.requested?.gemMotion?.count??4,bitProgram:s?.gems?.soloProgram??s?.requested?.gemMotion?.soloProgram??'halo',structure:s?.effective?.structure??'wings',
  transition:s?.transition?.id??null,poseTransition:s?.temporaryPose?.active?s.temporaryPose.id:s?.poseTransition?.id??null,
  cues:Object.fromEntries(Object.entries(s?.cues??{}).map(([k,v])=>[k,v?.active?v.id:null]))});

const silent=p=>!p||!p.enabled||p.localMuted||!(p.worldVolume>0)||!(p.localVolume>0);

/** Browser-only sound controller. It observes the shared flight flag/clock;
 * it never writes token, scene, sound documents, or socket messages. */
export class WingAudio {
  constructor(manager,{configuration=()=>({}),now=clock,getState=null,Sound=null,
    setInterval:setTimer=(...args)=>globalThis.setInterval(...args),clearInterval:clearTimer=(...args)=>globalThis.clearInterval(...args)}={}){
    this.manager=manager;this.configuration=configuration;this.now=now;this.getState=getState;
    this.Sound=Sound;this.setTimer=setTimer;this.clearTimer=clearTimer;
    this.records=new Map();this.timer=null;this.epoch=0;this.previewVoice=null;
    this.failures=new Map();this.lastTick=0;this.destroyed=false;
  }
  read(token,fresh=false){
    const state=this.manager?.states?.get(token);
    const age=this.now()-(state?.snapshotAt??this.now());
    if(!fresh&&state?.snapshot&&age>=0&&age<=250)return state.snapshot;
    try{return this.getState?.(token)??state?.snapshot??null;}catch{return null;}
  }
  sync(token){
    if(!localPerformance.active)return this.syncAudio(token);
    return localPerformance.measure('audio',()=>this.syncAudio(token));
  }
  syncAudio(token){
    // Drag clones can have valid wing snapshots, but only the placed token
    // supplies sound. Discard an existing record if it becomes a preview.
    if(token?.isPreview){this.remove(token);return;}
    if(!token?.document||token.destroyed)return;
    const cfg=this.configuration(),prefs=resolveAudio(getFlag(token),cfg);
    if(!prefs.requestedEnabled){this.remove(token);return;}
    let record=this.records.get(token);
    const snapshot=this.read(token,true);
    if(!record){record={token,prefs,voices:new Map(),shots:new Map(),tails:new Set(),lastCue:new Map(),
      previous:sampleKey(snapshot),lastGemBucket:Math.floor((this.now()-(snapshot?.started??this.now()))/14000),error:null,serial:0};this.records.set(token,record);}
    record.prefs=prefs;
    this.updateRecord(record,snapshot,cfg,this.now());
    if(this.shouldRun())this.start();
  }
  start(){if(this.timer!==null)return;this.timer=this.setTimer(()=>this.tick(),INTERVAL);this.timer?.unref?.();}
  stop(){if(this.timer!==null)this.clearTimer(this.timer);this.timer=null;}
  /** Muted or disabled tokens need no 10 Hz tick: nothing can sound, and unmuting
   * (a settings change) or any token update syncs them again. Sounding voices,
   * including warp/routine one-shots from play(), keep it running until they end. */
  shouldRun(){return !!this.previewVoice||[...this.records.values()].some(r=>r.voices.size||r.shots.size||r.tails.size||(r.previous.enabled||r.previous.bits)&&!silent(r.prefs));}
  tick(){
    if(!localPerformance.active)return this.tickAudio();
    return localPerformance.measure('audio',()=>this.tickAudio());
  }
  tickAudio(){
    if(!globalThis.canvas?.ready){this.clear();return;}
    const now=this.now(),cfg=this.configuration();this.lastTick=now;
    const listeners=audioListeners();
    for(const r of [...this.records.values()]){
      if(r.token.destroyed||r.token.isPreview||r.token.document.parent?.id!==globalThis.canvas?.scene?.id){this.remove(r.token);continue;}
      this.updateRecord(r,this.read(r.token),cfg,now,listeners);
    }
    if(!this.shouldRun())this.stop();
  }
  updateRecord(r,snapshot,cfg,now,listeners=audioListeners()){
    if(!snapshot){
      // Warp and routine sounds are asked for directly and do not depend on a wing snapshot.
      for(const v of [...r.voices.values(),...r.shots.values()])if(!v.external)this.dropVoice(r,v);
      r.previous=sampleKey(null);return;
    }
    const state=sampleKey(snapshot),prev=r.previous,prefs=r.prefs;
    const distance=listenerDistance(r.token,listeners),env={listeners,distance};
    r.distance=distance;r.audible=sourceAudible(r.token,prefs);r.blocked=this.contextBlocked();
    // Consume events even while muted or outside range: entering a radius or
    // unmuting never replays an old pose, hit, takeoff or healing sound.
    const cue=(slot,key,started=now,strength=1)=>this.cue(r,slot,key,started,strength,env,now);
    const explicitFlight=snapshot.transition?.active&&['takeoff','landing'].includes(snapshot.transition.kind);
    if(state.enabled&&!prev.enabled&&!explicitFlight)cue('takeoff',`on:${snapshot.started}`,snapshot.started??now);
    else if(!state.enabled&&prev.enabled&&prev.mode!=='landing')cue('landing',`off:${now}`,now);
    if(state.transition!==prev.transition&&snapshot.transition?.active){
      const t=snapshot.transition;if(['takeoff','landing'].includes(t.kind))cue(t.kind,`flight:${t.id}`,t.started);
    }
    // (12.0.0-beta.7) the v12 sound set: a landing style's recall has its own sound, as her wings begin to go (once a landing)
    {const t=snapshot.transition;if(t?.active&&t.kind==='landing'&&t.recall&&r.recallCue!==t.id){const at=t.started+t.duration-(t.foldMs??0);
      if(now>=at){r.recallCue=t.id;const own=soundFor(r.token.document,'landing',t.recall);if(own){noteAsked(own);cue(own,`recall:${t.id}`,at);}}}}
    if(state.enabled&&prev.enabled&&state.pose!==prev.pose){
      cue(poseAudioSlot(state.pose),`pose:${state.poseTransition}:${state.pose}:${now}`,now);
      if(snapshot.gems?.style==='choreographed'&&snapshot.gems.animated!==false&&!snapshot.effective?.reducedMotion)
        cue('gem',`gem-pose:${state.poseTransition}:${state.pose}:${now}`,now,0.4);
    }
    if(state.bits!==prev.bits)cue(state.bits?'bitsDeploy':'bitsRecall',`bits:${state.bits}:${now}`,snapshot.bitTransition?.started??now);
    else if(state.bits&&state.bitCount!==prev.bitCount)cue(state.bitCount>prev.bitCount?'bitsJoin':'bitsRecall',`count:${state.bitCount}:${now}`,now,.65);
    else if(state.bits&&state.bitProgram!==prev.bitProgram)cue('bitsFormation',`formation:${state.bitProgram}:${now}`,now,.55);
    if(state.enabled&&prev.enabled&&state.structure!==prev.structure)cue(`structure${state.structure[0].toUpperCase()+state.structure.slice(1)}`,`structure:${state.structure}:${now}`,snapshot.structureTransition?.started??now);
    if(state.enabled&&prev.enabled&&state.condition==='collapsed'&&prev.condition!=='collapsed')cue('collapse',`collapse:${now}`,now);
    // Existing saved reaction IDs are the single authority for transient cues.
    for(const [slot,entry]of Object.entries(snapshot.cues??{})){
      if(entry?.id&&entry.id!==prev.cues[slot]&&entry.active&&state.enabled&&AUDIO_SLOTS[entry.kind])
        cue(reactionAudioSlot(snapshot,entry),`cue:${entry.id}`,entry.started,entry.strength??1);
    }
    const renderState=this.manager?.states?.get(r.token);
    const renderAge=now-(renderState?.snapshotAt??now);
    let kinematics=!renderState?.dormant&&renderAge>=0&&renderAge<=250?renderState?.kinematics:null;
    if(!kinematics){
      // Audio remains independent when this browser hides visual effects. Read
      // animated token positions at the existing 10Hz audio cadence, including
      // the shared motion helper's teleport/reset guard. No canvas ticker needed.
      r.kinematics??={};const position=point(r.token);
      if(r.motionAt==null||now-r.motionAt>=INTERVAL){
        trackMovement(r.kinematics,{...position,size:globalThis.canvas?.grid?.size??globalThis.canvas?.scene?.grid?.size??100,
          dt:r.motionAt==null?0:(now-r.motionAt)/1000,shown:!r.token.document.hidden,relaxation:cfg.movementRelaxation??650});
        r.motionAt=now;
      }
      kinematics=r.kinematics;
    }
    const moving=state.enabled&&state.mode!=='grounded'?cap((kinematics.speed??0)/prefs.movementSensitivity):0;
    if(moving>0.08&&(snapshot.rendering?.flightFactor??1)>.1&&Math.abs(kinematics.turn??0)>0.3&&Math.abs(r.lastTurn??0)<=0.3)
      cue('bank',`bank:${Math.floor(now/250)}`,now,Math.min(1,0.5+moving));
    r.lastTurn=kinematics.turn??0;
    const bucket=Math.floor((now-(snapshot.started??now))/14000);
    const gemStarted=(snapshot.started??now)+bucket*14000;
    if(bucket>0&&bucket!==r.lastGemBucket&&now-gemStarted<=250&&state.enabled&&moving<.08&&snapshot.gems?.style==='choreographed'&&
      snapshot.gems.animated!==false&&(snapshot.gems.strength??1)>0&&!snapshot.effective?.reducedMotion)
      cue('gem',`gem:${bucket}`,gemStarted,0.3);
    r.lastGemBucket=bucket;r.previous=state;
    const allowed=prefs.enabled&&!prefs.localMuted&&r.audible&&!r.blocked&&(state.enabled||state.bits&&state.compact);
    const previous=r.conditionSource;
    if(state.condition!=='normal')r.conditionSource=state.condition;
    const mix=audioLevels(snapshot,moving,previous,r.shots.size>0 ? .78 : 1);
    // Artwork uses the existing condition lane; new sounds do not add lanes.
    let artwork=conditionAudioSlot(snapshot);
    if(prefs.slots[mix.condition]?.overridden&&!prefs.slots[artwork]?.overridden)artwork=null;
    const outgoing=r.voices.get('condition')?.slot,modeBed=`mode${state.mode[0].toUpperCase()+state.mode.slice(1)}`;
    const solo=`bits${state.bitProgram[0].toUpperCase()+state.bitProgram.slice(1)}`;
    const desires=state.compact?[['idle',AUDIO_SLOTS[solo]?solo:'bitsOrbit',state.bits ? .55*Math.sqrt(state.bitCount/4)*(snapshot.bitDeployment??1):0],['motion',null,0],['condition',null,0]]:[['idle',state.condition==='normal'&&artwork?artwork:AUDIO_SLOTS[modeBed]?modeBed:'idle',mix.idle],['motion',AUDIO_SLOTS[modeBed]?modeBed:['fast','surge'].includes(state.mode)?'fast':'movement',mix.motion],
      ['condition',state.condition==='normal'?(mix.condition?outgoing??mix.condition:null):artwork??mix.condition,mix.conditionGain]];
    // Flight feel (beta.24): the hum follows her flight. It swells a touch with
    // each stroke, lifts in pitch with speed and sags as she stops; each
    // flight mode has its own pitch (flight-character.mjs). Wings only.
    const feel=!state.compact&&!renderState?.dormant&&renderAge>=0&&renderAge<=250?renderState?.feel:null;
    let swell=1,pitch=1;
    if(feel){
      const c=blendCharacter(snapshot.flightProfile?.modeWeights,state.mode),turns=renderState?.wingClock?.turns??0,air=cap(feel.air??0);
      swell=1+.16*cap(feel.effort)*(.5+.5*Math.cos(turns*Math.PI*2-1))*air;
      pitch=1+(c.hum-1)*air+c.humLift*cap((feel.speed??0)/4)*air;
    }
    for(const [lane,id,intensity]of desires){
      const slot=prefs.slots[id],bed=lane==='idle'||lane==='motion',gain=allowed&&slot?audioGain(r.token,prefs,slot,env)*intensity*(bed?swell:1):0;
      this.loop(r,lane,id,gain,snapshot.started??now,now);
      if(bed)this.rate(r.voices.get(lane),pitch);
    }
    for(const voice of [...r.shots.values()]){
      const slot=prefs.slots[voice.slot],gain=prefs.enabled&&!prefs.localMuted&&!r.blocked?audioGain(r.token,prefs,slot,env)*voice.strength:0;
      this.gain(voice,gain,Math.min(180,prefs.crossfadeMs));
      if(now>voice.expires)this.dropVoice(r,voice);
    }
  }
  contextBlocked(){const ctx=globalThis.game?.audio?.environment;return !!ctx&&ctx.state!=='running';}
  alive(r,v){return this.records.get(r.token)===r&&!v.dead&&
    (v.loop?r.voices.get(v.lane)===v:r.shots.get(v.id)===v);}
  makeSound(src){const Sound=this.Sound??globalThis.foundry?.audio?.Sound;if(!Sound)throw new Error('Foundry audio is not ready.');return new Sound(src,{context:globalThis.game?.audio?.environment});}
  failure(r,src,error){
    const message=String(error?.message??error??'Audio could not be loaded.');r.error=`Audio unavailable: ${message}`;
    this.failures.set(src,this.now()+30000);
    if(this.failures.size>64)this.failures.delete(this.failures.keys().next().value);
    console.warn(`${ID} | Wing audio:`,message);
  }
  loop(r,lane,id,gain,started,now){
    let voice=r.voices.get(lane);const slot=r.prefs.slots[id];
    if(voice&&(voice.slot!==id||voice.src!==slot?.src)){this.dropVoice(r,voice,r.prefs.crossfadeMs);voice=null;}
    if(gain<MIN_GAIN||!slot?.enabled){
      if(voice){this.gain(voice,0,r.prefs.crossfadeMs);voice.quietSince??=now;
        if(now-voice.quietSince>=Math.max(500,r.prefs.crossfadeMs))this.dropVoice(r,voice);}
      return;
    }
    if(voice){voice.quietSince=null;voice.target=gain;this.gain(voice,gain,r.prefs.crossfadeMs);return;}
    if((this.failures.get(slot.src)??0)>now)return;
    voice={id:++r.serial,lane,slot:id,src:slot.src,loop:true,started,target:gain,dead:false,playing:false,quietSince:null};
    r.voices.set(lane,voice);void this.loadVoice(r,voice);
  }
  cue(r,id,key,started,strength,env,now){
    const slot=r.prefs.slots[id];if(!slot)return;
    // (12.0.0-beta.10) a v12 sound plays the file of her chosen style
    const src=styledSrc(r.token.document,id,slot.src,slot.preset);
    const last=r.lastCue.get(id);
    if(last?.key===key||last&&now-last.at<r.prefs.cooldownMs)return;
    r.lastCue.set(id,{key,at:now});
    const gain=audioGain(env?.emitter??r.token,r.prefs,slot,env)*cap(strength);
    if(!r.prefs.enabled||r.prefs.localMuted||r.blocked||gain<MIN_GAIN||now-started>2500||(this.failures.get(src)??0)>now)return;
    // Bounded one-shots. A new action displaces the oldest cue, never queues a
    // chorus of delayed sounds behind rapid macro or token updates.
    const priority=cuePriority(id);
    // A superseded pose releases promptly. Decorative alignment/bank sounds
    // must not evict a damage or healing response when both cue lanes are busy.
    if(id.startsWith('pose'))for(const v of [...r.shots.values()])if(v.slot.startsWith('pose'))this.dropVoice(r,v,80);
    while(r.shots.size>=2){
      const lowest=[...r.shots.values()].reduce((a,b)=>a.priority<=b.priority?a:b);
      if(lowest.priority>priority)return;
      this.dropVoice(r,lowest,60);
    }
    const voice={id:++r.serial,slot:id,src,loop:false,started,target:gain,strength:cap(strength),priority,dead:false,playing:false,expires:now+15000};
    r.shots.set(voice.id,voice);void this.loadVoice(r,voice);return voice;
  }
  /** A one-shot asked for from outside the snapshot (warps and routines). */
  play(token,id,{strength=1}={}){
    if(!AUDIO_SLOTS[id]||!token?.document||token.destroyed||token.isPreview)return null;
    // Her sounds off (the default): nothing can play, so skip resolving every
    // sound preference (flight asks on each working wingbeat).
    if(getFlag(token)?.enabled!==true){if(this.records.has(token))this.remove(token);return null;}
    this.syncAudio(token);const r=this.records.get(token);if(!r)return null;
    const now=this.now(),listeners=audioListeners(),voice=this.cue(r,id,`ext:${id}:${now}`,now,strength,{listeners,distance:listenerDistance(token,listeners)},now);
    if(voice){voice.external=true;if(this.shouldRun())this.start();}return voice;
  }
  stopShot(token,id,fade=300){const r=this.records.get(token);if(!r)return;for(const v of [...r.shots.values()])if(v.slot===id)this.dropVoice(r,v,fade);}
  async loadVoice(r,v){
    try{
      v.sound=this.makeSound(v.src);await v.sound.load();
      if(!this.alive(r,v)){this.stopSound(v.sound);return;}
      const now=this.now(),duration=v.sound.duration;
      const offset=v.loop?loopOffset(v.started,now,duration):Math.max(0,(now-v.started)/1000);
      if(!v.loop&&(offset>=duration||offset>2.5)){this.dropVoice(r,v);return;}
      const remaining=Number.isFinite(duration)?Math.max(0,duration-offset):8;
      const playDuration=v.loop?undefined:Math.min(15,remaining);
      await v.sound.play({loop:v.loop,offset,volume:v.target,...(v.loop?{}:{duration:playDuration}),fade:v.loop?r.prefs.crossfadeMs:Math.min(40,r.prefs.crossfadeMs),
        onended:()=>{if(!v.loop&&this.alive(r,v))this.dropVoice(r,v);}});
      if(!this.alive(r,v)){this.stopSound(v.sound);return;}
      v.playing=true;v.applied=undefined;v.expires=v.loop?Infinity:this.now()+playDuration*1000+500;
      this.gain(v,v.target,r.prefs.crossfadeMs);r.error=null;
    }catch(error){if(this.alive(r,v)){this.failure(r,v.src,error);this.dropVoice(r,v);}}
  }
  gain(v,gain,duration){
    v.target=cap(gain);
    if(!v.playing||Math.abs((v.applied??-1)-v.target)<0.002)return;
    v.applied=v.target;
    // Foundry owns the Sound and its AudioContext. Public AudioParam smoothing
    // avoids spawning a JS animation/timer for each 100ms distance adjustment.
    const param=v.sound?.gain,ctx=v.sound?.context;
    try{
      if(param?.setTargetAtTime&&Number.isFinite(ctx?.currentTime)){
        param.cancelScheduledValues(ctx.currentTime);param.setTargetAtTime(v.target,ctx.currentTime,Math.max(0.015,duration/3000));
      }else catchPromise(v.sound?.fade(v.target,{duration,type:'linear'}));
    }catch{}
  }
  /** Playback rate (pitch) of a sounding loop, eased; buffer or media sources. */
  rate(v,value){
    if(!v?.playing||!Number.isFinite(value))return;
    value=cap(value,.85,1.15);
    if(Math.abs((v.rateApplied??1)-value)<.002)return;
    v.rateApplied=value;
    try{
      const node=v.sound?.sourceNode,ctx=v.sound?.context,param=node?.playbackRate;
      if(param?.setTargetAtTime&&Number.isFinite(ctx?.currentTime)){param.cancelScheduledValues(ctx.currentTime);param.setTargetAtTime(value,ctx.currentTime,.25);}
      else if(node?.mediaElement){node.mediaElement.preservesPitch=false;node.mediaElement.playbackRate=value;}
    }catch{}
  }
  stopSound(sound,fade=0){try{sound?.unscheduleAll?.();catchPromise(sound?.stop({fade}));}catch{}}
  dropVoice(r,v,fade=0){
    if(!v||v.dead)return;v.dead=true;
    if(v.loop&&r.voices.get(v.lane)===v)r.voices.delete(v.lane);else r.shots.delete(v.id);
    if(fade&&v.playing&&v.sound){
      // At most three brief release tails per token; rapid edits cannot grow an
      // unbounded collection of still-playing Sound instances.
      while(r.tails.size>=3){const old=r.tails.values().next().value;r.tails.delete(old);this.stopSound(old.sound);}
      r.tails.add(v);
      try{Promise.resolve(v.sound.stop({fade})).catch(()=>{}).finally(()=>r.tails.delete(v));}catch{r.tails.delete(v);this.stopSound(v.sound);}
    }else this.stopSound(v.sound);
  }
  remove(token){
    if(this.previewVoice?.token===token)this.stopPreview();
    const r=this.records.get(token);if(!r)return;this.records.delete(token);
    for(const v of [...r.voices.values(),...r.shots.values()])this.dropVoice(r,v);
    for(const v of r.tails)this.stopSound(v.sound);r.tails.clear();
    if(!this.shouldRun())this.stop();
  }
  clear(){for(const token of [...this.records.keys()])this.remove(token);this.stopPreview();this.stop();this.epoch++;}
  rebuild(){this.clear();if(!globalThis.canvas?.ready)return;for(const token of globalThis.canvas?.tokens?.placeables??[])this.sync(token);}
  settingsChanged(){
    this.failures.clear();this.stopPreview();
    for(const r of this.records.values())r.previous=sampleKey(this.read(r.token,true));
    for(const token of globalThis.canvas?.tokens?.placeables??[])this.sync(token);
  }
  async preview(token,id,options={}){
    if(!AUDIO_SLOTS[id])throw new Error('Choose a wing audio sound to preview.');
    const choice=validateAudioPreview(options);
    this.stopPreview();
    const raw=getFlag(token),prefs=resolveAudio(Object.hasOwn(choice,'preset')?mergeAudio(raw,{slots:{[id]:choice}}):raw,this.configuration()),slot=prefs.slots[id];
    // Hovering None ends the previous sample and intentionally loads nothing.
    if(slot.preset==='none')return {slot:id,preset:'none',preview:false};
    if(!prefs.worldEnabled)throw new Error('Wing audio is disabled by the GM.');
    if(!prefs.categories[slot.category].worldEnabled)throw new Error('This wing audio category is disabled by the GM.');
    if(prefs.worldVolume<=0)throw new Error('Wing audio master volume is zero.');
    if(prefs.localMuted||prefs.localVolume<=0)throw new Error('Wing audio is muted on this browser.');
    if(!slot.src)throw new Error('Choose a bundled sound or a custom audio file first.');
    const v={token,slot:id,dead:false,sound:null,epoch:this.epoch};this.previewVoice=v;
    const current=()=>this.previewVoice===v&&!v.dead&&v.epoch===this.epoch;
    try{
      // Explicit preview is a user gesture and may unlock the audio context.
      catchPromise(globalThis.game?.audio?.environment?.resume?.());
      v.sound=this.makeSound(styledSrc(token?.document,id,slot.src,slot.preset));await v.sound.load();
      if(!current()){this.stopSound(v.sound);return;}
      const volume=cap(prefs.worldVolume*prefs.localVolume*prefs.volume*prefs.categories[slot.category].volume*slot.volume);
      await v.sound.play({loop:false,volume,fade:50,duration:Number.isFinite(v.sound.duration)?Math.min(8,v.sound.duration):8,onended:()=>{if(current())this.stopPreview();}});
      if(!current())this.stopSound(v.sound);
      return current()?{slot:id,preset:slot.preset,preview:true}:undefined;
    }catch(error){if(current())this.stopPreview();throw error;}
  }
  stopPreview(){const v=this.previewVoice;if(!v)return;this.previewVoice=null;v.dead=true;this.stopSound(v.sound,40);}
  status(token){
    const r=this.records.get(token),prefs=r?.prefs??resolveAudio(getFlag(token),this.configuration());
    const preview=this.previewVoice?.token===token?this.previewVoice.slot:null;
    let message=prefs.localMuted?'Muted on this browser':!prefs.worldEnabled?'Wing audio disabled by the GM':
      !prefs.requestedEnabled?'Wing audio off':prefs.audience==='local'&&prefs.localUserId!==globalThis.game?.user?.id?'Private audio belongs to another user':
      this.contextBlocked()?'Click Preview to enable browser audio':
      (prefs.audience==='nearby'||prefs.localRespectsRadius)&&!audioListeners().length?'Select a listener token':
      r?.error??(r?.voices.size?prefs.audience==='nearby'?'Playing nearby audio':'Playing private audio':'Ready — waiting for audible wings');
    if(preview)message=`Preview: ${AUDIO_SLOTS[preview].label}`;
    return {active:!!r?.voices.size,loops:r?.voices.size??0,cues:r?.shots.size??0,releasing:r?.tails.size??0,
      preview,blocked:this.contextBlocked(),error:r?.error??null,message};
  }
}


/** Shared treatment/preview resolution. Per-stage overrides never bypass a
 * world, client, category, legacy shared-stage or per-style mute. */
export function treatmentAudioPreferences(base,spec,{owner=false,ownerId=null}={}){
  const settings=normalizeTreatmentAudio(spec.audioSettings??{}, {strict:false});
  const prefs={...base,audience:owner?'local':'nearby',localUserId:ownerId,localRespectsRadius:false,slots:Object.create(base.slots)};
  const shared={depart:'medkitDepart',scan:'medkitScan',success:'medkitSuccess',criticalSuccess:'medkitCriticalSuccess',failure:'medkitFailure',criticalFailure:'medkitCriticalFailure',return:'medkitReturn'};
  for(const stage of Object.keys(TREATMENT_AUDIO_STAGES)){
    const id=treatmentAudioSlot(spec.style,stage),specific=base.slots[id];if(!specific)continue;
    const legacy=base.slots[shared[stage]],source=legacy?.overridden&&!specific.overridden?legacy:specific,custom=settings.sounds[stage];
    const src=custom==='none'?'':custom||source.src;
    const enabled=source.enabled&&specific.enabled&&legacy?.enabled!==false&&!!src;
    prefs.slots[id]={...specific,src,enabled,radius:spec.audioSettings?.radius??source.radius,gain:enabled?source.gain*settings.volume:0};
  }
  return prefs;
}

/** Resolve only cosmetic preferences, never a full actor or flight snapshot.
 * A saved V7-only style becomes its matching classic treatment sound when the
 * medkit additions are disabled; both old and new mute gates remain effective. */
export function resolveTreatmentAudioSpec(spec,source,cfg={}){
  if(!isV7Treatment(spec?.style))return spec;
  const doc=source?.document??source;let raw;
  try{raw=doc?.getFlag?.(ID,'flight')?.v7;}catch{}
  const v7=sampleV7Appearance(raw,cfg,0),enhanced=spec.enhanced!==false&&v7.enabled&&v7.medkit;
  return enhanced?spec:{...spec,style:classicTreatmentStyle(spec.style),audioSettings:undefined};
}
export function treatmentPlaybackPreferences(base,spec,source,cfg={},options={}){
  const actual=resolveTreatmentAudioSpec(spec,source,cfg),prefs=treatmentAudioPreferences(base,actual,options);
  if(actual.style===spec.style)return prefs;
  const slots=Object.create(prefs.slots);
  for(const stage of Object.keys(TREATMENT_AUDIO_STAGES)){
    const key=treatmentAudioSlot(spec.style,stage),fallback=prefs.slots[treatmentAudioSlot(actual.style,stage)],specific=base.slots[key];if(!fallback)continue;
    const enabled=fallback.enabled&&specific?.enabled!==false;
    slots[key]={...fallback,id:key,enabled,gain:enabled?fallback.gain:0};
  }
  return {...prefs,slots};
}

/** Local-only audition. The preview's existing visual ticker supplies its stage
 * and elapsed seconds, so no independent clock/timer or scene document exists.
 * At most one stage voice plays. stop/close invalidate all pending audio loads. */
export function createTreatmentAudioPreview({style='suture',audioSettings={},enhanced,source=null,configuration=()=>({}),Sound=null}={}){
  let voice=null,serial=0,closed=false,error=null,lastPrefs=-Infinity,prefs=null;
  const now=()=>globalThis.performance?.now?.()??Date.now();
  const stopVoice=()=>{const old=voice;voice=null;if(!old)return;old.dead=true;try{old.sound?.stop?.();}catch{}};
  const read=()=>{
    if(prefs&&now()-lastPrefs<100)return prefs;
    lastPrefs=now();const doc=source?.document??source;
    const raw=doc?.getFlag?.(ID,'audio');
    const cfg=typeof configuration==='function'?configuration():configuration;
    prefs=treatmentPlaybackPreferences(resolveAudio({...raw,enabled:true},cfg),{style,audioSettings,...(enhanced===undefined?{}:{enhanced})},source,cfg,{owner:true,ownerId:globalThis.game?.user?.id});return prefs;
  };
  const alive=v=>!closed&&!v.dead&&voice===v;
  const gain=(v,value)=>{
    if(!v.playing||Math.abs((v.applied??-1)-value)<.002)return;
    v.applied=value;const param=v.sound?.gain,ctx=v.sound?.context;
    try{if(param?.setTargetAtTime&&Number.isFinite(ctx?.currentTime))param.setTargetAtTime(value,ctx.currentTime,.025);else if(v.sound)v.sound.volume=value;}catch{}
  };
  const update=({stage,elapsed=0}={})=>{
    if(closed)return;
    if(!Object.hasOwn(TREATMENT_AUDIO_STAGES,stage)){stopVoice();return;}
    const p=read(),slot=p.slots[treatmentAudioSlot(style,stage)];
    if(!p.enabled||p.localMuted||!slot?.enabled||slot.gain<MIN_GAIN){stopVoice();return;}
    const key=`${stage}:${slot.src}`;
    if(voice?.key===key){voice.target=slot.gain;gain(voice,slot.gain);return;}
    stopVoice();const v={id:++serial,key,stage,src:slot.src,offset:Math.max(0,elapsed),requestedAt:now(),target:slot.gain,dead:false,playing:false};voice=v;
    void(async()=>{
      try{
        const Type=Sound??globalThis.foundry?.audio?.Sound;if(!Type)throw new Error('Foundry audio is not ready.');
        v.sound=new Type(v.src,{context:globalThis.game?.audio?.environment});await v.sound.load();
        if(!alive(v)){try{v.sound.stop();}catch{}return;}
        const duration=v.sound.duration,loop=stage==='tool',offset=v.offset+(now()-v.requestedAt)/1000;
        if(!loop&&Number.isFinite(duration)&&offset>=duration){v.ended=true;return;}
        const start=loop&&Number.isFinite(duration)&&duration>0?offset%duration:offset;
        await v.sound.play({loop,offset:start,volume:v.target,fade:35,...(loop?{}:{duration:Math.max(.01,Math.min(8,(Number.isFinite(duration)?duration:8)-start))}),onended:()=>{if(alive(v))v.ended=true;}});
        if(!alive(v)){try{v.sound.stop();}catch{}return;}v.playing=true;error=null;gain(v,v.target);
      }catch(cause){if(alive(v)){error=String(cause?.message??cause);v.failed=true;}}
    })();
  };
  return {update,stop:stopVoice,close(){closed=true;stopVoice();},get error(){return error;}};
}

/** Treatment sounds observe the shared action flag, independent of wing enable.
 * Only explicit treatment.audio=true opts in. No socket or document writes. */
export class BitActionAudio extends WingAudio {
  // Treatment sound is driven wholly by the shared action flag. The inherited
  // 10Hz loop must not resolve an unused full wing snapshot for every patient.
  read(){return null;}
  events(token){
    const now=this.now(),all=this.manager?.bits?.records?.(token?.document,false)??[],events=all.filter(e=>e.expires>now&&(e.kind==='treatment'&&e.treatment?.audio===true||e.kind==='sequence'&&e.sequence?.gesture&&e.sequence.audio===true||e.kind==='escort'&&e.group?.behaviour?.audio===true));
    const allocation=token?.document?.getFlag?.(ID,'bitAllocations'),home=allocation?.groups?.home;
    if(home?.behaviour?.audio===true){const bits=Object.keys(allocation.bits??{}).filter(id=>allocation.bits[id].location==='home'&&!all.some(e=>e.status!=='queued'&&e.bits.includes(id)));
      if(bits.length)events.push({id:'home-instrument-work',kind:'escort',status:'running',owner:token.document.getFlag?.(ID,'flight')?.controller??globalThis.game?.users?.contents?.find(u=>!u.isGM&&token.document.testUserPermission?.(u,'OWNER'))?.id??'',target:token.document.id,bits,group:home,started:0,expires:Number.MAX_SAFE_INTEGER});}
    return events;
  }
  sync(token){
    if(!localPerformance.active)return this.syncAudio(token);
    return localPerformance.measure('audio',()=>this.syncAudio(token));
  }
  syncAudio(token){
    if(!token?.document||token.destroyed||token.isPreview||!globalThis.canvas?.ready||token.document.parent?.id!==globalThis.canvas?.scene?.id){this.remove(token);return;}
    const events=this.events(token),cfg=this.configuration();
    if(!events.length){this.remove(token);return;}
    let r=this.records.get(token);
    if(!r){r={token,voices:new Map(),shots:new Map(),tails:new Set(),lastCue:new Map(),stages:new Map(),serial:0,error:null,previous:{enabled:true}};this.records.set(token,r);}
    // Opting into treatment audio overrides only the wing-token enable switch.
    const raw=getFlag(token);
    if(!r.basePrefs||r.audioRaw!==raw||r.audioCfg!==cfg){
      r.basePrefs=resolveAudio({...raw,enabled:true,audience:'nearby'},cfg);
      r.audioRaw=raw;r.audioCfg=cfg;r.eventPrefs=new Map();
    }
    r.prefs=r.basePrefs;
    this.updateRecord(r,null,cfg,this.now());if(this.shouldRun())this.start();
  }
  shouldRun(){return [...this.records.values()].some(r=>r.voices.size||r.shots.size||r.tails.size||!silent(r.basePrefs));}
  preferences(r,event){
    const saved=r.eventPrefs.get(event.id),spec=event.treatment??event.sequence??event.group?.behaviour,owner=globalThis.game?.user?.id===event.owner;
    const style=event.kind==='treatment'?resolveTreatmentAudioSpec(spec,r.token,r.audioCfg??this.configuration()).style:null;
    if(saved?.spec===spec&&saved.owner===owner&&saved.style===style)return saved.prefs;
    const prefs=event.kind==='treatment'?treatmentPlaybackPreferences(r.basePrefs,spec,r.token,r.audioCfg??this.configuration(),{owner,ownerId:event.owner}):{...r.basePrefs,audience:owner?'local':'nearby',localUserId:event.owner,localRespectsRadius:false};
    r.eventPrefs.set(event.id,{spec,owner,style,prefs});return prefs;
  }
  instrumentWork(r,e,now,cfg,listeners){
    const target=globalThis.canvas?.tokens?.get?.(e.target)??globalThis.canvas?.tokens?.placeables?.find(t=>t.document?.id===e.target),owner=globalThis.game?.user?.id===e.owner;
    const emitter=target&&!target.destroyed&&!target.isPreview&&target.document?.parent?.id===globalThis.canvas?.scene?.id?target:null;
    const response=this.manager?.states?.get(r.token)?.snapshot?.conditionResponse,unpowered=response?.bits&&['falling','fallen'].includes(response.collapse?.phase);
    const allowed=!unpowered&&!e.group?.effect?.enabled&&!e.conditionPausedAt&&!e.reason&&r.prefs.enabled&&!r.prefs.localMuted&&!r.blocked&&sourceAudible(r.token,r.prefs)&&!!emitter&&sourceAudible(emitter,r.prefs)&&(owner||r.token.isVisible!==false&&emitter.isVisible!==false);
    let gesture=e.sequence?.gesture,phase='rest',episode=0,began=now;
    if(e.kind==='sequence'){
      const step=e.sequence.tracks.find(t=>t.type==='gesture'),p=step?(now-e.started-step.at)/Math.max(1,step.duration):0;
      phase=e.status==='running'&&p>=.49&&p<.77?'work':'rest';began=e.started+(step?.at??0)+(step?.duration??0)*.49;
    }else if(e.status==='running'&&now>=e.started+(e.travelDuration??0)){
      const raw=r.token.document.getFlag?.(ID,'flight')?.gemMotion??{},animated=raw.animated!==false&&!cfg.reduced;
      const program=formationFlowState(e.group.program,now,e.group.flow,animated).program;
      if(Object.hasOwn(LIVING_BIT_PROGRAMS,program)&&animated){
        const speed=raw.speed??1,scene=sampleLivingScene(e.bits.length,program,now/1000*speed,{stations:e.bits,personality:e.group.personality??.35,behaviour:e.group.behaviour});
        const intent=scene.intents.find(Boolean);phase=scene.phase==='work'?'work':'rest';episode=`${program}:${scene.episode??0}`;gesture=intent?.gesture;
        const frequency=e.group.behaviour?.frequency??'attentive',period=(program==='livingWorkshop'?20:program==='quietExchange'?23:26)*(frequency==='composed'?2.8:frequency==='expressive'?.74:1),duration=program==='livingWorkshop'?8:7;
        began=((scene.episode??0)*period+period-duration+duration*.49)/speed*1000;
      }
    }
    const prior=r.stages.get(e.id),env={listeners,distance:owner?0:emitter?listenerDistance(emitter,listeners):Infinity,emitter};
    if(allowed&&phase==='work'&&gesture&&(prior?.phase!==phase||prior.episode!==episode)&&now-began<=350&&now>=began){const voice=this.cue(r,`gesture_${gesture}`,`${e.id}:${episode}:${gesture}`,began,.5,env,now);if(voice)voice.eventId=e.id;}
    r.stages.set(e.id,{phase,episode});
    for(const voice of [...r.shots.values()])if(voice.eventId===e.id){if(!allowed||e.status==='returning'){this.dropVoice(r,voice,60);continue;}this.gain(voice,audioGain(emitter,r.prefs,r.prefs.slots[voice.slot],env)*voice.strength,120);if(now>voice.expires)this.dropVoice(r,voice);}
  }
  updateRecord(r,_snapshot,cfg,now,listeners=audioListeners()){
    const events=this.events(r.token),active=new Set(events.map(e=>e.id));
    if(!events.length){this.remove(r.token);return;}
    r.blocked=this.contextBlocked();
    for(const v of [...r.voices.values(),...r.shots.values()])if(!active.has(v.eventId))this.dropVoice(r,v,60);
    for(const id of r.stages.keys())if(!active.has(id)){r.stages.delete(id);r.eventPrefs.delete(id);}
    for(const e of events){
      if(e.status==='queued')continue;
      r.prefs=this.preferences(r,e);
      if(e.kind!=='treatment'){this.instrumentWork(r,e,now,cfg,listeners);continue;}
      const phase=e.status==='returning'?'returning':treatmentPhase(e,now).phase;
      const prior=r.stages.get(e.id),first=!prior;
      const began=phase==='travel'?e.started:phase==='scanning'?e.started+e.travelDuration:phase==='treating'?e.started+e.travelDuration+TREATMENT_TIMING.scan:phase==='finishing'?e.finishAt:e.returnAt;
      const target=globalThis.canvas?.tokens?.get?.(e.target)??globalThis.canvas?.tokens?.placeables?.find(t=>t.document?.id===e.target);
      // Every stage belongs to the patient, including deployment and return.
      // The initiating user hears it privately regardless of listener distance.
      const liveTarget=target&&!target.destroyed&&!target.isPreview&&target.document?.parent?.id===globalThis.canvas?.scene?.id;
      const emitter=liveTarget?target:null,owner=globalThis.game?.user?.id===e.owner;
      const env={listeners,distance:owner?0:emitter?listenerDistance(emitter,listeners):Infinity,emitter};
      // Both Ellie and the current emitter must be valid audible scene sources.
      // A hidden/removed source must never leak treatment through its patient.
      const allowed=r.prefs.enabled&&!r.prefs.localMuted&&!r.blocked&&sourceAudible(r.token,r.prefs)&&!!emitter&&sourceAudible(emitter,r.prefs)&&
        (owner||r.token.isVisible!==false&&emitter.isVisible!==false);
      // A fresh scene/load never replays stale phases. Running loops resume at
      // their shared phase; only newly observed edges get one-shot accents.
      if(prior?.phase!==phase){
        for(const v of [...r.shots.values()])if(v.eventId===e.id)this.dropVoice(r,v,60);
        const isFresh=now-began<=350&&now>=began;
        if((!first||isFresh)&&isFresh&&!e.reason&&allowed){
          const stage=phase==='travel'?'depart':phase==='scanning'?'scan':phase==='finishing'?e.outcome:phase==='returning'?'return':null;
          const id=stage?treatmentAudioSlot(e.treatment.style,stage):null;
          if(id){const voice=this.cue(r,id,`${e.id}:${phase}`,began,1,env,now);if(voice)voice.eventId=e.id;}
        }
      }
      r.stages.set(e.id,{phase});
      const lane=`treatment:${e.id}`,id=`medkit_${e.treatment.style}`,slot=r.prefs.slots[id];
      const gain=allowed&&phase==='treating'&&!e.reason?audioGain(emitter,r.prefs,slot,env):0;
      // Leaving the attempt phase or cancellation releases immediately, so a
      // muted/returned action cannot retain a hidden tool loop.
      if(phase!=='treating'||e.reason||!allowed){const voice=r.voices.get(lane);if(voice)this.dropVoice(r,voice,60);}
      else {this.loop(r,lane,id,gain,began,now);const voice=r.voices.get(lane);if(voice)voice.eventId=e.id;}
      for(const voice of [...r.shots.values()])if(voice.eventId===e.id){
        if(e.reason||!allowed){this.dropVoice(r,voice);continue;}
        this.gain(voice,audioGain(emitter,r.prefs,r.prefs.slots[voice.slot],env)*voice.strength,120);
        if(now>voice.expires)this.dropVoice(r,voice);
      }
    }
    // Four instruments permit at most four independent active actions; even a
    // malformed external reader cannot allocate an unbounded loop collection.
    while(r.voices.size>4)this.dropVoice(r,r.voices.values().next().value,40);
  }
  settingsChanged(){
    this.failures.clear();for(const r of this.records.values())r.audioCfg=null;
    for(const token of globalThis.canvas?.tokens?.placeables??[])this.sync(token);
  }
}
