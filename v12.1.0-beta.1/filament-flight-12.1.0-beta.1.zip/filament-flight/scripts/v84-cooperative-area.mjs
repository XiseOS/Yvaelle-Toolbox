import {cooperativeBlockIndex,prefersCooperativeBlock,nearestCooperativeBlock} from './v87-area-blocks.mjs?v=12.1.0-beta.1';
/** Slow cooperative field work. Each team shares native row segments or four-cell blocks;
 * physical instruments contribute one cell apiece. */
export const AREA_SCAN_EXPOSURE_MS=4800;
export const AREA_SCAN_SETTLE_MS=650;
export const AREA_SCAN_RELEASE_MS=650;
const LIMIT=4096,finite=(n,f=0)=>Number.isFinite(n)?n:f;
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const bounded=p=>{const d=Math.hypot(p.x,p.y),gain=d>.94?.94/d:1;return {x:p.x*gain,y:p.y*gain};};
const normalize=(p,center,radius)=>({x:(p.x-center.x)/radius,y:(p.y-center.y)/radius});
const bounds=poly=>{const xs=poly.map(p=>p.x),ys=poly.map(p=>p.y),x=Math.min(...xs),y=Math.min(...ys);return {x,y,width:Math.max(...xs)-x,height:Math.max(...ys)-y};};
const inside=(p,poly)=>{let yes=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)yes=!yes;}return yes;};
function circleTouches(b,c,r){const x=Math.max(b.x,Math.min(b.x+b.width,c.x)),y=Math.max(b.y,Math.min(b.y+b.height,c.y));return Math.hypot(x-c.x,y-c.y)<r-1e-7;}
export function areaCellSize(gridScan,fallback=100){const b=gridScan?.cells?.[0]?.bounds;return Math.max(1,finite(gridScan?.cellSize,Math.min(finite(b?.width,fallback),finite(b?.height,fallback))));}
/** Gridless fields still have a single-grid-size instrument footprint. No
 * large arbitrary circles or broad patches are substituted for a lone bit. */
function positiveRectangleIntersection(polygon,rectangle){
  let output=polygon;
  for(const [axis,edge,sign] of [['x',rectangle.x,1],['x',rectangle.x+rectangle.width,-1],['y',rectangle.y,1],['y',rectangle.y+rectangle.height,-1]]){
    const input=output;output=[];if(!input.length)return false;
    for(let i=0;i<input.length;i++){const a=input[i],b=input[(i+1)%input.length],sa=(a[axis]-edge)*sign,sb=(b[axis]-edge)*sign;if(sa>=0)output.push(a);if((sa>=0)!==(sb>=0)){const t=sa/(sa-sb);output.push({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});}}
  }
  return Math.abs(output.reduce((sum,a,i)=>{const b=output[(i+1)%output.length];return sum+a.x*b.y-a.y*b.x;},0))>2e-6;
}
export function virtualAreaCells({center={x:0,y:0},radius=100,cellSize=100,region}={}){
  const cells=[],extent=Math.min(64,Math.ceil(radius/cellSize+.5)),start=-extent;
  for(let i=start;i<=extent&&cells.length<LIMIT;i++)for(let j=start;j<=extent&&cells.length<LIMIT;j++){
    const x=center.x+j*cellSize-cellSize/2,y=center.y+i*cellSize-cellSize/2,b={x,y,width:cellSize,height:cellSize};if(!circleTouches(b,center,radius))continue;
    const polygon=[{x,y},{x:x+cellSize,y},{x:x+cellSize,y:y+cellSize},{x,y:y+cellSize}],mid={x:x+cellSize/2,y:y+cellSize/2};
    // The painter performs the exact final circle/custom-region clipping.
    if(region?.length>=3&&!positiveRectangleIntersection(region,b))continue;
    cells.push({id:`free:${i}:${j}`,offset:{i,j},center:mid,bounds:b,polygon,virtual:true});
  }
  return cells;
}
function positiveNativeRegionIntersection(cell,region){
  const clip=cell.polygon??[];if(clip.length<3)return positiveRectangleIntersection(region,cell.bounds);
  const signed=clip.reduce((sum,a,i)=>{const b=clip[(i+1)%clip.length];return sum+a.x*b.y-a.y*b.x;},0),orientation=signed<0?-1:1;let output=region;
  for(let i=0;i<clip.length&&output.length;i++){
    const a=clip[i],b=clip[(i+1)%clip.length],side=p=>orientation*((b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x)),input=output;output=[];
    for(let j=0;j<input.length;j++){const p=input[j],q=input[(j+1)%input.length],sp=side(p),sq=side(q),pin=sp>=-1e-8,qin=sq>=-1e-8;if(pin)output.push(p);if(pin!==qin){const t=sp/(sp-sq);output.push({x:p.x+(q.x-p.x)*t,y:p.y+(q.y-p.y)*t});}}
  }
  return Math.abs(output.reduce((sum,a,i)=>{const b=output[(i+1)%output.length];return sum+a.x*b.y-a.y*b.x;},0))>2e-6;
}
function positiveCircleIntersection(cell,center,radius){
  const polygon=cell.polygon;if(!polygon?.length)return circleTouches(cell.bounds,center,radius);
  if(inside(center,polygon))return true;
  const limit=radius*radius-1e-6;
  for(let i=0;i<polygon.length;i++){const a=polygon[i],b=polygon[(i+1)%polygon.length],dx=b.x-a.x,dy=b.y-a.y,t=Math.max(0,Math.min(1,((center.x-a.x)*dx+(center.y-a.y)*dy)/(dx*dx+dy*dy||1))),x=a.x+t*dx,y=a.y+t*dy;if((x-center.x)**2+(y-center.y)**2<limit)return true;}
  return false;
}
function rowGroups(cells,capacity){
  const rows=new Map();for(const cell of cells){const row=finite(cell.offset?.i,Math.round(cell.center.y*1e5)/1e5),list=rows.get(row)??[];list.push(cell);rows.set(row,list);}
  const groups=[];let rowIndex=0;
  for(const row of [...rows.keys()].sort((a,b)=>a-b)){
    const ordered=rows.get(row).sort((a,b)=>a.center.x-b.center.x||a.center.y-b.center.y);if(rowIndex++%2)ordered.reverse();
    let run=[];
    const flush=()=>{for(let i=0;i<run.length;i+=capacity)groups.push(run.slice(i,i+capacity));run=[];};
    for(const cell of ordered){const last=run.at(-1),span=last?Math.max(last.bounds?.width??1,cell.bounds?.width??1):1;
      if(last&&(Math.abs(cell.center.x-last.center.x)>span*1.2||Math.abs(cell.center.y-last.center.y)>Math.max(last.bounds?.height??1,cell.bounds?.height??1)*.65))flush();run.push(cell);
    }flush();
  }
  return groups;
}
/** Nearby unvisited row segments form deliberate teams after the wide first
 * acquisition. Spatial bins bound each local search; the ordered fallback
 * guarantees complete coverage even across thin or disconnected regions. */
/** gaps[i] is 1 when row[i] does not continue row[i-1] (a hole or a clip).
 * Computed once per row, so window checks need no distance per candidate. */
function rowGaps(row){
  const gaps=new Uint8Array(row.length);
  for(let i=1;i<row.length;i++){const a=row[i-1],b=row[i];if(distance(b.center,a.center)>Math.max(b.bounds.width,a.bounds.width)*1.35)gaps[i]=1;}
  return gaps;
}
function branchedItinerary(cells,capacity,seed,center,cellSize,opening,openingShape='row',blockIndex=cooperativeBlockIndex(cells)){
  const used=new Set(),rows=new Map(),bins=new Map(),ordered=[...cells].sort((a,b)=>a.center.y-b.center.y||a.center.x-b.center.x);
  for(const cell of cells){const row=finite(cell.offset?.i,Math.round(cell.center.y*1e5)/1e5),list=rows.get(row)??[];list.push(cell);rows.set(row,list);const bx=Math.floor(cell.center.x/cellSize),by=Math.floor(cell.center.y/cellSize);let column=bins.get(bx);if(!column)bins.set(bx,column=new Map());const bin=column.get(by);if(bin)bin.push(cell);else column.set(by,[cell]);}
  const location=new Map(),rowList=[];
  for(const row of rows.values()){row.sort((a,b)=>a.center.x-b.center.x);const gaps=rowGaps(row);rowList.push({row,gaps});row.forEach((cell,index)=>location.set(cell.id,{row,index,gaps}));}
  const mean=group=>({x:group.reduce((s,c)=>s+c.center.x,0)/group.length,y:group.reduce((s,c)=>s+c.center.y,0)/group.length});
  // Contiguous four-cell row windows. Only their existence matters on the hot
  // path; the list (and its means) is built if a fallback quartet is needed.
  const contiguous=(gaps,start,end)=>{for(let k=start+1;k<end;k++)if(gaps[k])return false;return true;};
  let fullRows=null;const hasFullRow=rowList.some(({row,gaps})=>{for(let start=0;start<=row.length-4;start++)if(contiguous(gaps,start,start+4))return true;return false;});
  const quartets=()=>fullRows??=rowList.flatMap(({row,gaps})=>{const list=[];for(let start=0;start<=row.length-4;start++)if(contiguous(gaps,start,start+4)){const group=row.slice(start,start+4);list.push({group,mean:mean(group)});}return list;});
  const seenShapes=new Set(opening.length===4?[openingShape]:[]),bothShapes=capacity===4&&hasFullRow&&blockIndex.candidates.length>0,regroupAfter=3+((Number(seed)||0)>>>0)%3;
  const missingShape=()=>bothShapes&&!seenShapes.has('block')?'block':bothShapes&&!seenShapes.has('row')?'row':null;
  const fallbackQuartet=(target,shape)=>{
    if(shape==='block')return nearestCooperativeBlock(blockIndex,target);
    let chosen=null,best=Infinity;for(const {group,mean:p} of quartets()){const score=distance(p,target);if(score<best){best=score;chosen=group;}}return chosen;
  };
  // Used cells leave their spatial bin (order kept), so a late, mostly
  // covered field scans only unused cells around each target.
  const markUsed=cell=>{if(used.has(cell.id))return;used.add(cell.id);const bin=bins.get(Math.floor(cell.center.x/cellSize))?.get(Math.floor(cell.center.y/cellSize)),i=bin?bin.indexOf(cell):-1;if(i>=0)bin.splice(i,1);};
  let fallback=0;
  const pick=(target,count,ordinal,requiredShape=null)=>{
    const found=[],bx=Math.floor(target.x/cellSize),by=Math.floor(target.y/cellSize);
    for(let r=0;r<=4;r++){for(let dx=-r;dx<=r;dx++)for(let dy=-r;dy<=r;dy++){if(r&&Math.abs(dx)!==r&&Math.abs(dy)!==r)continue;const bin=bins.get(bx+dx)?.get(by+dy);if(bin)for(const cell of bin)found.push({cell,d:(cell.center.x-target.x)**2+(cell.center.y-target.y)**2});}if(found.length>=count*4)break;}
    // Squared distances, computed once; the stable sort keeps tie order.
    found.sort((a,b)=>a.d-b.d);const candidates=found.map(entry=>entry.cell);
    while(fallback<ordered.length&&used.has(ordered[fallback].id))fallback++;
    if(fallback<ordered.length&&!candidates.includes(ordered[fallback]))candidates.push(ordered[fallback]);
    const choose=(cells,shape='row')=>{for(const cell of cells)markUsed(cell);return {cells,shape};};
    const line=requested=>{
      for(const anchor of candidates){const {row,index,gaps}=location.get(anchor.id);for(let start=Math.max(0,index-requested+1);start<=index;start++){
        const end=start+requested;if(end>row.length)continue;
        let free=true;for(let k=start;k<end;k++)if(used.has(row[k].id)){free=false;break;}
        if(free&&contiguous(gaps,start,end))return row.slice(start,end);
      }}return null;
    };
    const block=()=>{
      let chosen=null,best=Infinity;
      for(const anchor of candidates)for(const candidate of blockIndex.byCell.get(anchor.id)??[]){if(candidate.cells.some(cell=>used.has(cell.id)))continue;const score=(candidate.x-target.x)**2+(candidate.y-target.y)**2;if(score<best){best=score;chosen=candidate.cells;}}
      return chosen;
    };
    if(count===4){
      const prefer=requiredShape??(prefersCooperativeBlock(seed,ordinal)?'block':'row');
      if(prefer==='block'){const group=block();if(group)return choose(group,'block');}
      if(!requiredShape||requiredShape==='row'){const row=line(4);if(row)return choose(row);}
      if(!requiredShape||requiredShape==='block'){const square=block();if(square)return choose(square,'block');}
      if(requiredShape){const group=fallbackQuartet(target,requiredShape);if(group)return choose(group,requiredShape);}
    }else{const group=line(count);if(group)return choose(group);}
    const single=line(1);return single?choose(single):{cells:[],shape:'row'};
  };
  const itinerary=[{cells:opening,teamCounts:[opening.length],teamShapes:[openingShape]}];opening.forEach(markUsed);
  let previous=Array.from({length:capacity},(_,i)=>opening[Math.min(i,opening.length-1)].center);
  while(used.size<cells.length){
    const ordinal=itinerary.length,requiredShape=ordinal>=regroupAfter?missingShape():null,partition=requiredShape?[4]:cooperativeAreaTeams(capacity,ordinal,seed),groups=[];let slot=0;const collective=mean(previous.map(center=>({center})));
    for(let team=0;team<partition.length;team++){
      const count=partition[team],old=previous.slice(slot,slot+count),base={x:old.reduce((n,c)=>n+c.x,0)/old.length,y:old.reduce((n,c)=>n+c.y,0)/old.length};
      // Small branches spread from the former front rather than leaping to
      // distant quadrants. An irregular angle prevents an ascending routine.
      const angle=(seed%997)*.013+ordinal*2.399963229728653+team*2.15,spread=partition.length>1?cellSize*(1.1+team*.35):cellSize*.4;
      const target={x:base.x+Math.cos(angle)*spread+(base.x-collective.x)*.25,y:base.y+Math.sin(angle)*spread+(base.y-collective.y)*.25},group=pick(target,count,ordinal,requiredShape);
      if(group.cells.length){groups.push(group);if(group.cells.length===4)seenShapes.add(group.shape);}slot+=count;
    }
    if(!groups.length)break;
    const flat=groups.flatMap(group=>group.cells);itinerary.push({cells:flat,teamCounts:groups.map(group=>group.cells.length),teamShapes:groups.map(group=>group.shape)});
    previous=Array.from({length:capacity},(_,i)=>flat[Math.min(i,flat.length-1)].center);
  }
  // Compact fields can finish before their first regroup. An alternate
  // full-team view still appears when both real native topologies fit.
  const alternate=missingShape();if(alternate){const target={x:previous.reduce((n,p)=>n+p.x,0)/previous.length,y:previous.reduce((n,p)=>n+p.y,0)/previous.length},group=fallbackQuartet(target,alternate);if(group)itinerary.push({cells:group,teamCounts:[4],teamShapes:[alternate]});}
  return itinerary;
}
function shuffledMethods(methods,count,random){const result=[];while(result.length<count){const deck=[...methods];for(let i=deck.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}if(deck.length>1&&result.at(-1)===deck[0])[deck[0],deck[1]]=[deck[1],deck[0]];result.push(...deck);}return result.slice(0,count);}
function motionGenerator(seed,index,visit){
  let x=(Number(seed)||0)^Math.imul(index+1,0x9e3779b1)^Math.imul(visit+1,0x85ebca6b);
  return ()=>{x+=0x6D2B79F5;let t=x;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};
}
const limitUnit=n=>Math.max(0,Math.min(1,n));
const gentle=n=>{n=limitUnit(n);return n*n*n*(n*(n*6-15)+10);};
/** Slow, finite inspection arcs begin and end at the exact station with zero
 * velocity. They are seeded once per job, not oscillator noise or frame state. */
export function sampleCooperativeInspection(visit,progress){
  const motion=visit.naturalMotion;if(!motion)return visit.to;
  const q=gentle((progress-motion.inspectDelay)/motion.inspectSpan),envelope=Math.sin(Math.PI*q)**2,angle=motion.inspectPhase+q*motion.inspectTurn;
  return {x:visit.to.x+Math.cos(angle)*motion.inspectAmplitude*envelope,y:visit.to.y+Math.sin(angle)*motion.inspectAmplitude*.72*envelope};
}
/** Shared optical work keeps its calm cadence while individual housings leave,
 * brake, open and close at slightly different edges of that common interval. */
export function cooperativePersonalTiming(visit,local){
  const motion=visit.naturalMotion;if(!motion)return null;
  const arrival=motion.approachDelay+motion.approachDuration,approach=limitUnit((local-motion.approachDelay)/motion.approachDuration),settle=limitUnit((local-arrival)/motion.settleDuration),release=limitUnit((local-visit.travel-visit.settle-visit.scan)/motion.releaseDuration);
  return {approach,settle,release,arrival};
}
export function makeCooperativeAreaPlan({cells=[],center={x:0,y:0},radius=100,cellSize=100,bits=[],seed=0,methods=['structuredLight'],random=Math.random,region}={}){
  if(!bits.length)return null;
  methods=methods?.length?methods:['structuredLight'];
  cells=cells.slice(0,LIMIT).filter(cell=>positiveCircleIntersection(cell,center,radius)&&(!region?.length||positiveNativeRegionIntersection(cell,region)));
  const capacity=Math.max(1,Math.min(4,bits.length)),groups=rowGroups(cells.slice(0,LIMIT),capacity);if(!groups.length)return null;
  // Open wide near the chosen center, even when a circle's outermost row
  // contains only one clipped edge cell. The remaining itinerary still covers
  // every native cell once before wrapping.
  let opening=0,best=Infinity;
  for(let i=0;i<groups.length;i++){const group=groups[i],mid={x:group.reduce((n,c)=>n+c.center.x,0)/group.length,y:group.reduce((n,c)=>n+c.center.y,0)/group.length};const score=(capacity-group.length)*radius*100+distance(mid,center);if(score<best){best=score;opening=i;}}
  if(opening)groups.push(...groups.splice(0,opening));
  // Center the opening front with a sliding native window, rather than let
  // an arbitrary row chunk put its last square on the circular rim.
  let openingCells=groups[0],openingScore=Infinity;const openingRows=new Map();
  for(const cell of cells){const row=finite(cell.offset?.i,cell.center.y),list=openingRows.get(row)??[];list.push(cell);openingRows.set(row,list);}
  // Vertices outside the circle, per cell, counted once with squared lengths.
  const outside=(radius+1e-6)**2,clipped=new Map();
  for(const cell of cells){let n=0;for(const p of cell.polygon??[])if((p.x-center.x)**2+(p.y-center.y)**2>outside)n++;clipped.set(cell,n);}
  for(const row of openingRows.values()){row.sort((a,b)=>a.center.x-b.center.x);const gaps=rowGaps(row);let run=0;
    for(let end=0;end<row.length;end++){
      run=end&&!gaps[end]?run+1:1;if(run<capacity)continue;
      const start=end-capacity+1;let x=0,y=0,outer=0;for(let k=start;k<=end;k++){const c=row[k];x+=c.center.x;y+=c.center.y;outer+=clipped.get(c);}
      const score=outer*radius*5+distance({x:x/capacity,y:y/capacity},center);
      if(score<openingScore){openingScore=score;openingCells=row.slice(start,end+1);}
    }}
  const blockIndex=cooperativeBlockIndex(cells);let openingShape='row';
  if(capacity===4&&blockIndex.candidates.length&&(openingCells.length<4||prefersCooperativeBlock(seed,0))){
    let chosen=null,best=Infinity;
    for(const candidate of blockIndex.candidates){let outer=0;for(const c of candidate.cells)outer+=clipped.get(c)??0;const score=outer*radius*5+Math.hypot(candidate.x-center.x,candidate.y-center.y);if(score<best){best=score;chosen=candidate.cells;}}
    if(chosen){openingCells=chosen;openingShape='block';}
  }
  // Small fields still visit every enabled method. Repeating only a short
  // complete itinerary keeps the plan bounded and the optical deck useful.
  const coverage=branchedItinerary(cells.slice(0,LIMIT),capacity,seed,center,cellSize,openingCells,openingShape,blockIndex),itinerary=Array.from({length:Math.max(coverage.length,methods.length)},(_,i)=>coverage[i%coverage.length]),deck=shuffledMethods(methods,itinerary.length,random);
  const points=itinerary.map(entry=>entry.cells.map(cell=>normalize(cell.center,center,radius))),unitCell=cellSize/radius;
  const profiles=points.map((group,v)=>Array.from({length:capacity},(_,index)=>{
    const random=motionGenerator(seed,index,v),focus=group[Math.min(index,group.length-1)],base=[-2.45,-.85,2.5,.8][index],angle=base+(random()-.5)*.75+Math.sin(v*.73+index)*.18,standOff=unitCell*(.38+random()*.2+(index>=group.length?.08:0));
    const raw={x:focus.x+Math.cos(angle)*standOff,y:focus.y+Math.sin(angle)*standOff},length=Math.hypot(raw.x,raw.y),gain=length>.90?.90/length:1,station={x:raw.x*gain,y:raw.y*gain};
    return {station,random,inspectAmplitude:Math.min(unitCell*(.085+random()*.055),Math.max(0,.938-Math.hypot(station.x,station.y))*.9),inspectPhase:random()*Math.PI*2,inspectTurn:(random()<.5?-1:1)*(.7+random()*1.05),inspectDelay:random()*.08,inspectSpan:.84+random()*.08,departureDelay:random()*.13,departureSpan:.78+random()*.16};
  }));
  // Nearby observers retain room for their housings and their small
  // inspection arcs. Opposite viewpoints on adjacent cells must not meet in
  // the middle of the shared exposure. This relaxation runs only at compile.
  const stationSeparation=Math.min(unitCell*.70,.85);
  for(let v=0;v<profiles.length;v++){
    const group=profiles[v];
    for(let pass=0;pass<18;pass++){
      let moved=false;
      for(let i=0;i<group.length;i++)for(let j=0;j<i;j++){
        const a=group[i].station,b=group[j].station,dx=a.x-b.x,dy=a.y-b.y,length=Math.hypot(dx,dy);if(length>=stationSeparation)continue;
        const focusA=points[v][Math.min(i,points[v].length-1)],focusB=points[v][Math.min(j,points[v].length-1)],fallback=Math.atan2(focusA.y-focusB.y,focusA.x-focusB.x)+(i-j)*.19,angle=length>1e-8?Math.atan2(dy,dx):fallback,push=(stationSeparation-length)*.52,ox=Math.cos(angle)*push,oy=Math.sin(angle)*push;
        for(const [station,x,y] of [[a,a.x+ox,a.y+oy],[b,b.x-ox,b.y-oy]]){const d=Math.hypot(x,y),gain=d>.90?.90/d:1;station.x=x*gain;station.y=y*gain;}moved=true;
      }
      if(!moved)break;
    }
    for(let i=0;i<group.length;i++){
      const profile=group[i],nearest=Math.min(Infinity,...group.filter((_,j)=>j!==i).map(other=>distance(profile.station,other.station))),clearance=Math.max(0,(nearest-unitCell*.36)/2);
      profile.inspectAmplitude=Math.min(profile.inspectAmplitude,Math.max(0,.938-Math.hypot(profile.station.x,profile.station.y))*.9,clearance);
    }
  }
  const stations=profiles.map(group=>group.map(profile=>profile.station));
  let cursor=0;const routes=bits.slice(0,4).map((_,index)=>({visits:[],duration:0,initial:stations[0][index],delay:0,index,scanVisits:itinerary.length,cooperative:true}));
  for(let v=0;v<itinerary.length;v++){
    const previous=stations[v?v-1:0],current=stations[v],travel=v?1100+Math.max(...current.map((p,i)=>distance(p,previous[i])))*1500:650;
    const settle=AREA_SCAN_SETTLE_MS,scan=AREA_SCAN_EXPOSURE_MS,release=AREA_SCAN_RELEASE_MS,duration=travel+settle+scan+release;
    routes.forEach((route,index)=>{const from=previous[index],to=current[index],cell=itinerary[v].cells[Math.min(index,itinerary[v].cells.length-1)],focus=points[v][Math.min(index,points[v].length-1)],angle=Math.atan2(focus.y-to.y,focus.x-to.x),profile=profiles[v][index],random=profile.random,d=distance(from,to),tangent=Math.atan2(to.y-from.y,to.x-from.x),bend=v?unitCell*(.12+random()*.22)*(random()<.5?-1:1):0;
      const approachDelay=travel*(.035+random()*.13),approachDuration=Math.max(220,Math.min(travel-approachDelay-70,500+d*1800+random()*210)),control=bounded({x:(from.x+to.x)/2-Math.sin(tangent)*bend,y:(from.y+to.y)/2+Math.cos(tangent)*bend});
      const naturalMotion={approachDelay,approachDuration,settleDuration:340+random()*310,releaseDuration:350+random()*260,inspectAmplitude:profile.inspectAmplitude,inspectPhase:profile.inspectPhase,inspectTurn:profile.inspectTurn,inspectDelay:profile.inspectDelay,inspectSpan:profile.inspectSpan,departureDelay:profile.departureDelay,departureSpan:Math.min(profile.departureSpan,1-profile.departureDelay-.025),lightPhase:random()*Math.PI*2};
      route.visits.push({at:cursor,travel,settle,scan,release,duration,from,to,control,naturalMotion,focus,fromAngle:v?route.visits.at(-1).scanAngle:angle,travelAngle:Math.atan2(to.y-from.y,to.x-from.x),scanAngle:angle,endAngle:angle,
        visitIndex:v,method:deck[v],patch:cellSize/radius/2,aspect:1,tilt:0,detailPass:false,gridCell:cell,gridCellId:cell.id,cooperativeCells:itinerary[v].cells,teamCounts:itinerary[v].teamCounts,teamShapes:itinerary[v].teamShapes,cooperativeFocus:points[v][0],axis:'y',direction:1,slotActive:index<itinerary[v].cells.length});
    });cursor+=duration;
  }
  const final=stations.at(-1),first=stations[0],travel=1200+Math.max(...first.map((p,i)=>distance(p,final[i])))*1500;
  for(const route of routes){const last=route.visits.at(-1),initial=route.visits[0],random=motionGenerator(seed,route.index,itinerary.length),angle=Math.atan2(initial.from.y-last.to.y,initial.from.x-last.to.x),bend=unitCell*(random()-.5)*.36,control=bounded({x:(last.to.x+initial.from.x)/2-Math.sin(angle)*bend,y:(last.to.y+initial.from.y)/2+Math.cos(angle)*bend});route.visits.push({...initial,at:cursor,travel,settle:0,scan:0,release:0,duration:travel,from:last.to,to:initial.from,control,naturalMotion:{...initial.naturalMotion,approachDelay:travel*(.04+random()*.08),approachDuration:travel*.82,inspectAmplitude:0},fromAngle:last.scanAngle,visitIndex:itinerary.length,patch:0,cooperativeCells:[],slotActive:false});route.duration=cursor+travel;}
  return {mode:'areaScan',seed,bits:bits.slice(0,4),routes,sites:cells.map((cell,index)=>({...normalize(cell.center,center,radius),index,gridCell:cell})),cooperative:true,cellSize,groupCount:groups.length};
}
const rosterCache=new WeakMap();
const actualTeams=new WeakMap(),actualShapes=new WeakMap();
const EMPTY_SELECTION=Object.freeze([]);actualTeams.set(EMPTY_SELECTION,[]);actualShapes.set(EMPTY_SELECTION,[]);
const mappingCaches=new WeakMap(),templateIds=new WeakMap();let nextTemplateId=0;
const MAPPING_CACHE_LIMIT=128;
function templateId(cells){let id=templateIds.get(cells);if(id==null){id=++nextTemplateId;templateIds.set(cells,id);}return id;}
function indexedRows(cells){
  let entry=rosterCache.get(cells);if(entry)return entry;
  const grouped=new Map();for(const cell of cells){const key=finite(cell.offset?.i,cell.center.y),list=grouped.get(key)??[];list.push(cell);grouped.set(key,list);}
  const rows=[...grouped.values()].map(cells=>{cells.sort((a,b)=>a.center.x-b.center.x);let minY=Infinity,maxY=-Infinity;for(const cell of cells){minY=Math.min(minY,cell.center.y);maxY=Math.max(maxY,cell.center.y);}return {cells,minY,maxY,y:(minY+maxY)/2,windows:new Map()};}).sort((a,b)=>a.y-b.y);
  entry={rows,maxDeviation:Math.max(0,...rows.map(row=>(row.maxY-row.minY)/2))};rosterCache.set(cells,entry);return entry;
}
function rowWindows(row,size){
  let windows=row.windows.get(size);if(windows)return windows;
  windows=[];
  for(let start=0;start<=row.cells.length-size;start++){
    const cells=row.cells.slice(start,start+size);let x=0,y=0,contiguous=true;
    for(let i=0;i<cells.length;i++){const c=cells[i];x+=c.center.x;y+=c.center.y;if(i&&distance(c.center,cells[i-1].center)>Math.max(c.bounds.width,cells[i-1].bounds.width)*1.35)contiguous=false;}
    if(contiguous)windows.push({cells,x:x/size,y:y/size});
  }
  row.windows.set(size,windows);return windows;
}
function nearestUnusedRowGroup(index,target,size,used){
  const {rows,maxDeviation}=index;let lo=0,hi=rows.length;
  while(lo<hi){const mid=(lo+hi)>>1;if(rows[mid].y<target.y)lo=mid+1;else hi=mid;}
  let above=lo-1,below=lo,best=Infinity,chosen=null;
  const rowBound=i=>i<0||i>=rows.length?Infinity:Math.max(0,Math.abs(rows[i].y-target.y)-maxDeviation)**2;
  while(above>=0||below<rows.length){
    const upper=rowBound(above),lower=rowBound(below);if(Math.min(upper,lower)>best)break;
    const row=upper<=lower?rows[above--]:rows[below++],dy=Math.max(0,row.minY-target.y,target.y-row.maxY);if(dy*dy>best)continue;
    const windows=rowWindows(row,size);let left=0,right=windows.length;
    while(left<right){const mid=(left+right)>>1;if(windows[mid].x<target.x)left=mid+1;else right=mid;}
    let a=left-1,b=left;
    const columnBound=i=>i<0||i>=windows.length?Infinity:(windows[i].x-target.x)**2+dy*dy;
    while(a>=0||b<windows.length){
      const previous=columnBound(a),next=columnBound(b);if(Math.min(previous,next)>best)break;
      const window=previous<=next?windows[a--]:windows[b++];if(window.cells.some(cell=>used.has(cell.id)))continue;
      const d=(window.x-target.x)**2+(window.y-target.y)**2;
      if(d<best){best=d;chosen=window.cells;}
    }
  }
  return chosen;
}
function nativeFollowingCells(visit,geometry){
  const source=visit.cooperativeCells??[],index=indexedRows(geometry.gridScan.cells),cells=[],teams=[],shapes=[],used=new Set();let cursor=0,teamIndex=0;
  for(const requested of visit.teamCounts??[source.length]){
    const shape=visit.teamShapes?.[teamIndex++]??'row',template=source.slice(cursor,cursor+requested);cursor+=requested;if(!template.length)continue;
    const target={x:geometry.center.x+template.reduce((sum,c)=>sum+c.center.x,0)/template.length,y:geometry.center.y+template.reduce((sum,c)=>sum+c.center.y,0)/template.length};
    let remaining=requested;
    if(shape==='block'&&requested===4){
      const chosen=nearestCooperativeBlock(cooperativeBlockIndex(geometry.gridScan.cells),target,used);
      if(chosen){cells.push(...chosen);teams.push(4);shapes.push('block');chosen.forEach(cell=>used.add(cell.id));remaining=0;}
    }
    while(remaining>0){
      // A block that cannot fit the live native roster splits into small real
      // teams. Turning it into four cells in one long row would change its job.
      let chosen=null;for(let size=Math.min(remaining,shape==='block'?2:4);size>=1&&!chosen;size--)chosen=nearestUnusedRowGroup(index,target,size,used);
      if(!chosen)break;
      cells.push(...chosen);teams.push(chosen.length);shapes.push('row');chosen.forEach(cell=>used.add(cell.id));remaining-=chosen.length;
    }
  }
  return {cells,teams,shapes,selected:new Map()};
}
/** Following geometry is computed once per exact anchor/roster/work geometry.
 * Current and previous stations share immutable work templates, so the four
 * housings and completion checks reuse the same bounded mapping result. */
export function cooperativeVisitCells(visit,geometry,{cycle=0,count=1}={}){
  const template=visit.cooperativeCells??[];if(!template.length||!(count>0))return EMPTY_SELECTION;
  const following=!!geometry.utility.followSource,roster=following&&geometry.gridScan?.cells?.length?geometry.gridScan.cells:template;
  let cache=mappingCaches.get(roster);if(!cache){cache=new Map();mappingCaches.set(roster,cache);}
  const teams=visit.teamCounts??[template.length],shapes=visit.teamShapes??teams.map(()=> 'row'),key=`${templateId(template)}:${teams.join(',')}:${shapes.join(',')}:${following?`${geometry.center.x}:${geometry.center.y}:${geometry.radius}`:'fixed'}`;
  let mapped=cache.get(key);
  if(!mapped){
    if(following&&geometry.gridScan?.cells?.length)mapped=nativeFollowingCells(visit,geometry);
    else if(following&&template.length){const dx=geometry.center.x,dy=geometry.center.y;mapped={cells:template.map(cell=>({...cell,center:{x:cell.center.x+dx,y:cell.center.y+dy},bounds:{...cell.bounds,x:cell.bounds.x+dx,y:cell.bounds.y+dy},polygon:cell.polygon.map(p=>({x:p.x+dx,y:p.y+dy}))})),teams,shapes,selected:new Map()};}
    else mapped={cells:template,teams,shapes,selected:new Map()};
    if(cache.size>=MAPPING_CACHE_LIMIT)cache.delete(cache.keys().next().value);cache.set(key,mapped);
  }
  const n=Math.min(Math.max(0,count),mapped.cells.length),windows=mapped.cells.length-n+1,start=n?Math.max(0,cycle)%windows:0,selectionKey=`${n}:${start}`;
  let selected=mapped.selected.get(selectionKey);if(selected)return selected;
  selected=mapped.cells.slice(start,start+n);const counts=[],selectedShapes=[];let cursor=0,teamIndex=0;
  for(const size of mapped.teams){const shape=mapped.shapes?.[teamIndex++]??'row',overlap=Math.max(0,Math.min(start+n,cursor+size)-Math.max(start,cursor));if(overlap){counts.push(overlap);selectedShapes.push(shape==='block'&&overlap<4?'partialBlock':shape);}cursor+=size;}
  actualTeams.set(selected,counts);actualShapes.set(selected,selectedShapes);if(mapped.selected.size>=16)mapped.selected.delete(mapped.selected.keys().next().value);mapped.selected.set(selectionKey,selected);return selected;
}

/** Team membership follows the geometry selected by the planner. Capacity
 * changes shorten that actual work, never join two separated patches. */
export function cooperativeVisitTeamCounts(visit,{cycle=0,count=1,cells}={}){
  if(cells&&actualTeams.has(cells))return actualTeams.get(cells);
  const length=visit.cooperativeCells?.length??0,n=Math.min(Math.max(0,count),length),start=n?Math.max(0,cycle)%(length-n+1):0,end=start+n,result=[];let cursor=0;
  for(const size of visit.teamCounts??[length]){const overlap=Math.max(0,Math.min(end,cursor+size)-Math.max(start,cursor));if(overlap)result.push(overlap);cursor+=size;}
  return result;
}

/** Actual projected topology, including partial blocks after borrowing and
 * smaller native teams when a following block no longer fits. */
export function cooperativeVisitTeamShapes(visit,{cells}={}){
  if(cells&&actualShapes.has(cells))return actualShapes.get(cells);
  return visit.teamShapes??(visit.teamCounts??[]).map(()=> 'row');
}

const TEAM_PARTITIONS=Object.freeze({1:[[1]],2:[[1,1],[2]],3:[[2,1],[1,2],[1,1,1],[3]],4:[[2,2],[3,1],[1,3],[2,1,1],[1,2,1],[1,1,2],[1,1,1,1],[4]]});
/** Begin with a broad combined acquisition, then branch into seeded, irregular
 * work teams. Reconnects reproduce the same natural grouping; no timers or
 * ascending solo/duo/trio/quartet ladder drives the instruments. */
export function cooperativeAreaTeams(count,ordinal,seed=0){
  count=Math.max(0,Math.min(4,count));if(!count)return [];
  if(ordinal<=0)return [count];
  const deck=TEAM_PARTITIONS[count].map(p=>[...p]);let x=(Number(seed)||0)^0x84f11e;
  const random=()=>{x=Math.imul(x^x>>>16,0x45d9f3b);x=Math.imul(x^x>>>16,0x45d9f3b);x^=x>>>16;return (x>>>0)/4294967296;};
  for(let i=deck.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}
  // A solo and pair field must branch after the very first broad exposure.
  if(deck[0].length===1&&deck.length>1)[deck[0],deck[1]]=[deck[1],deck[0]];
  return deck[(ordinal-1)%deck.length];
}
