/** Sensory signals travel through the original wing's own ribs and web.
 * These accents never supply a body, move a root, change a pose or decide
 * visibility. Source points stay in the original rib fan; the rig poses them
 * with its shared warp and applies HP cutting/material attenuation separately.
 */
import {ribPoint} from './status-filament-geometry.mjs?v=12.1.0-beta.1';

export const SENSORY_ORIGINAL_EFFECT_IDS=Object.freeze(['blinded','dazzled','deafened','sickened','stupefied','confused','fascinated','off-guard','concealed','invisible','hidden','undetected','unnoticed']);
const TAU=Math.PI*2;
const unit=n=>Math.max(0,Math.min(1,Number.isFinite(n)?n:0));
const finite=(n,f=0)=>Number.isFinite(n)?n:f;
const mix=(a,b,q)=>a+(b-a)*q;
const wave=(t,rate=1,phase=0)=>.5-.5*Math.cos(t*rate+phase);
const samples=fn=>Array.from({length:28},(_,i)=>fn(i/27));

/** Interpolating adjacent original ribs keeps sweeps and little return loops
 * on the actual membrane, including irregular lower lobes. No screen-space
 * particle, replacement panel or standalone symbol is introduced.
 */
function sourcePoint(ribs,index,u){
  const r=Math.max(0,Math.min(ribs.length-1,index)),i=Math.floor(r),j=Math.min(ribs.length-1,i+1),q=r-i,v=unit(u);
  // Manual abilities annotate their real support contours with statusPoints.
  // Read both neighboring contours through the shared source sampler rather
  // than reconstructing the original cubic when a new form is displayed.
  const a=ribPoint(ribs,i,v),b=ribPoint(ribs,j,v);
  return [mix(a[0],b[0],q),mix(a[1],b[1],q),v];
}

export function originalSensoryStatusAccents(side,visual,warp,ribs,growth=1){
  const m=visual?.statusFilamentEffects;
  if(!m?.active||growth<=0||!Array.isArray(ribs)||ribs.length<2||typeof warp!=='function')return [];
  const out=[],t=finite(m.time),offset=side<0?.71:0;
  const a=id=>unit(finite(m.strengths?.[id]))*(1+.1*Math.max(0,Math.min(3,finite(m.severities?.[id],1)-1)));
  const add=(id,name,source,width,strength,highlight=0)=>{
    if(out.length>=80||strength<=0)return;
    const clipped=source.filter(p=>p.every(Number.isFinite)&&p[2]<=growth+.000001);
    if(clipped.length<2)return;
    const points=clipped.map(p=>warp(p));
    if(points.some(p=>!Array.isArray(p)||!p.every(Number.isFinite)))return;
    out.push({id:`actor-original-${id}-${name}`,points,width:Math.max(.3,Math.min(2.8,width)),
      strength:Math.max(0,Math.min(1.4,strength)),conditionAccent:true,statusFilamentAccent:true,
      highlight:unit(highlight),statusId:id});
  };
  const channel=(id,name,rib,lo,hi,width,strength,highlight=0)=>add(id,name,samples(q=>sourcePoint(ribs,rib,mix(lo,hi,q))),width,strength,highlight);
  const across=(id,name,from,to,u,bow,width,strength,highlight=0)=>add(id,name,samples(q=>
    sourcePoint(ribs,mix(from,to,q),u+bow*Math.sin(Math.PI*q))),width,strength,highlight);
  const loop=(id,name,rib,u,rx,ru,width,strength,highlight=0)=>add(id,name,samples(q=>{
    const angle=q*TAU;return sourcePoint(ribs,rib+rx*Math.sin(angle),u+ru*Math.cos(angle));
  }),width,strength,highlight);

  for(const id of SENSORY_ORIGINAL_EFFECT_IDS){
    const gain=a(id);if(gain<=.001)continue;
    switch(id){
    case 'blinded':{
      // Two slow scanning feedback fronts traverse the complete existing fan.
      // Four returning feeler currents answer the search along actual spars.
      for(let k=0;k<2;k++){
        const scan=.2+.66*wave(t,.62,k*1.65+offset),fade=.4+.6*wave(t,.62,k*1.65+offset+.9);
        across(id,`search-sweep-${k}`,0,9,scan,.028,1.65,gain*.81*fade,.4);
      }
      for(const [k,rib]of [0,3,6,9].entries()){
        const head=.28+.6*wave(t,.74,k*.82+offset),tail=Math.max(.08,head-.28);
        channel(id,`blind-feedback-${k}`,rib,head,tail,1.25,gain*(.48+.38*wave(t,.74,k*.82+offset)),.2);
      }
      break;
    }
    case 'dazzled':{
      // Broad soft diffusion bands and bowed internal glints move together;
      // brightness stays low-frequency rather than flashing the whole wing.
      for(let k=0;k<3;k++){
        const u=.29+k*.22+.035*Math.sin(t*.49+k*.79+offset);
        across(id,`diffuse-light-band-${k}`,k*.3,8.7-k*.3,u,.043,1.95,gain*(.32+.24*wave(t,.49,k*.79)),.26);
        loop(id,`bowed-glint-${k}`,1.2+k*3.1,.4+.18*wave(t,.57,k*.93+offset),.34,.074,.82,gain*(.42+.38*wave(t,.57,k*.93)),.58);
      }
      break;
    }
    case 'deafened':{
      // Light channels have a conspicuous missing return span; the original
      // supporting rib itself remains. No travelling acoustic beat is added.
      for(const [k,rib]of [1,4,8].entries()){
        channel(id,`broken-resonance-inner-${k}`,rib,.13,.42,1.45,gain*.66,.22);
        channel(id,`broken-resonance-return-${k}`,rib,.62,.93,1.15,gain*.43,.1);
      }
      break;
    }
    case 'sickened':{
      for(let k=0;k<4;k++){
        const roll=t*(.53+k*.027)+k*1.18+offset,u=.17+.68*wave(roll);
        across(id,`uneven-rolling-front-${k}`,k%2?4:0,k%2?9:5,u,.055*Math.sin(roll+.7),1.45,gain*(.34+.34*wave(roll,1,.9)),.18);
      }
      for(const [k,rib]of [2,7].entries()){
        const head=.29+.53*wave(t,.64,k*1.79+offset);
        channel(id,`queasy-return-${k}`,rib,head,Math.max(.08,head-.36),1.2,gain*.59,.26);
      }
      break;
    }
    case 'stupefied':{
      for(const [k,rib]of [0,1,3,5,7,9].entries()){
        const relay=wave(t,.81,k*.91+offset),u=.25+.48*wave(t,.37,k*.68+offset),fade=.12+.88*relay**3;
        channel(id,`missed-relay-${k}`,rib,u,Math.min(.97,u+.19),1.7,gain*fade,.44);
      }
      break;
    }
    case 'confused':{
      for(const [k,rib]of [0,2,4,6,8].entries()){
        const outward=k%2===0,q=wave(t,.68+k*.031,k*.73+offset),head=.23+.67*(outward?q:1-q);
        channel(id,`contrary-current-${k}`,rib,outward?Math.max(.07,head-.31):head,outward?head:Math.max(.07,head-.31),
          1.6,gain*(.44+.34*wave(t,.71,k*.73+offset)),.32);
      }
      // A local return curls across neighboring original ribs, not outside it.
      loop(id,'conflicting-return-loop',4.5,.5+.085*Math.sin(t*.51+offset),.57,.09,1.2,gain*.67,.2);
      break;
    }
    case 'fascinated':{
      const arrival=.18+.61*wave(t,.58,offset),tail=Math.min(.96,arrival+.33);
      for(const [k,rib]of [0,2,4,6,8,9].entries())channel(id,`converging-current-${k}`,rib,tail,arrival,
        k===2||k===3?2.0:1.35,gain*(.57+.23*wave(t,.58,offset+.4)),k===2||k===3?.6:.3);
      break;
    }
    case 'off-guard':{
      // Trace only the perimeter of a depleted middle guard. The material mask
      // may dim this region, but the unmodified original body always remains.
      across(id,'open-guard-inner',2,5,.38,.015,1.2,gain*.49,.18);
      across(id,'open-guard-outer',2,5,.81,-.024,1.2,gain*.39,.13);
      channel(id,'guard-return-left',2,.38,.81,1.05,gain*.39,.12);
      channel(id,'guard-return-right',5,.38,.81,1.05,gain*.39,.12);
      const catchU=.44+.13*wave(t,.74,offset);
      channel(id,'incomplete-guard-catch',3,catchU,catchU+.12,1.45,gain*(.23+.35*wave(t,.74,offset+.8)),.24);
      channel(id,'exposed-guard-return',4,.71,.9,.72,gain*.24,.08);
      break;
    }
    case 'concealed':{
      for(let k=0;k<4;k++){
        const u=.22+k*.17+.041*Math.sin(t*.37+k*.8+offset);
        across(id,`veil-shimmer-${k}`,0,9,u,.047,1.5,gain*(.28+.19*wave(t,.43,k*.81+offset)),.19);
      }
      for(const [k,rib]of [0,9].entries())channel(id,`soft-veiled-rim-${k}`,rib,.16,.94,.91,gain*(.28+.14*wave(t,.37,k+offset)),.12);
      break;
    }
    case 'invisible':{
      // Coherent fine refraction echoes occupy neighboring points of the same
      // fan. Whole-body attenuation belongs to the caller's material mask.
      for(const [k,rib]of [0,4,9].entries()){
        channel(id,`coherent-refraction-${k}`,rib,.09,.97,.78,gain*.45,.57);
        const neighboring=Math.max(0,Math.min(9,rib+(rib===9?-.085:.085)+.022*Math.sin(t*.31+k+offset)));
        channel(id,`refraction-return-${k}`,neighboring,.19,.9,.48,gain*(.19+.07*wave(t,.31,k+offset)),.33);
      }
      break;
    }
    case 'hidden':{
      for(let k=0;k<3;k++){
        const u=.27+.015*Math.sin(t*.29+k*.4+offset);
        across(id,`quiet-guard-light-${k}`,k*3,k*3+3,u,.018,1.01,gain*.4,.2);
        channel(id,`close-guard-return-${k}`,1+k*3,.09,.37,.93,gain*(.34+.07*wave(t,.29,k*.4+offset)),.1);
      }
      break;
    }
    case 'undetected':{
      for(const [k,rib]of [0,2,4,6,8,9].entries()){
        const head=.29+.56*wave(t,.33,k*.44+offset);
        channel(id,`quiet-shoulderward-current-${k}`,rib,head,Math.max(.08,head-.4),.78,gain*(.32+.14*wave(t,.33,k*.44+offset)),.19);
      }
      break;
    }
    case 'unnoticed':{
      for(const [k,rib]of [1,5,8].entries()){
        const charge=.32+.18*wave(t,.22,k*.31+offset);
        channel(id,`dormant-root-charge-${k}`,rib,.08,.27,.75,gain*charge,.17);
        across(id,`dormant-transmitted-trace-${k}`,0,9,.39+k*.21,.01,.5,gain*.13,.04);
      }
      break;
    }
    }
  }
  return out;
}
