import {localPerformance} from './performance.mjs?v=12.1.0-beta.1';
import {lightUniformLayoutChanged,setLightShaderProgram,markLightShaderUniformsDirty,invalidateLightUniformLayout,setLightUniform} from './light-shader-binding.mjs?v=12.1.0-beta.1';

/** Visual-only wing-light falloff. Native polygons, detection and explored fog
 * remain owned by Foundry. No screen blur and no extra illumination source. */
export const WING_EDGE_VERTEX=`
precision highp float;
attribute vec2 aVertexPosition;
uniform mat3 translationMatrix;
uniform mat3 projectionMatrix;
varying vec2 ffPosition;
void main(){
  ffPosition=aVertexPosition;
  gl_Position=vec4((projectionMatrix*translationMatrix*vec3(aVertexPosition,1.0)).xy,0.0,1.0);
}`;

export const WING_EDGE_FRAGMENT=`
precision highp float;
varying vec2 ffPosition;
uniform vec2 center;
uniform float rangeRadius;
uniform float featherWidth;
uniform vec2 direction;
uniform float halfAngle;
uniform float angularFeather;
uniform vec4 maskColor;
void main(){
  float coverage=1.0;
  if(featherWidth>0.0&&rangeRadius>0.0){
    float radial=length(ffPosition-center)/rangeRadius;
    coverage=1.0-smoothstep(1.0-featherWidth,1.0,radial);
  }
  if(angularFeather>0.0){
    vec2 point=ffPosition-center;
    float forward=dot(point,direction);
    float side=dot(point,vec2(-direction.y,direction.x));
    float turn=length(point)>0.00001?abs(atan(side,forward)):0.0;
    coverage*=1.0-smoothstep(halfAngle-angularFeather,halfAngle,turn);
  }
  gl_FragColor=vec4(maskColor.rgb*maskColor.a*coverage,maskColor.a*coverage);
}`;

const EDGE_UNIFORM='ffWingEdgeWidth';
const clamp=value=>Number.isFinite(value)?Math.min(1,Math.max(0,value)):0;
const modulo=(value,period)=>(value%period+period)%period;
const shaderSource=source=>source.replace(/^\s*#define\s+SHADER_NAME[^\r\n]*(?:\r?\n|$)/gm,'');

/** Preserve the native adaptive shader's final composition: illumination must
 * approach its computed background, not multiply the already-lit scene black. */
export function featherLightFragment(fragment){
  if(typeof fragment!=='string')return null;
  const inspected=fragment.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,part=>part.replace(/[^\n]/g,' '));
  const output=[...inspected.matchAll(/\bgl_FragColor\s*=\s*([^;]+);/g)];
  const main=[...inspected.matchAll(/\bvoid\s+main\s*\(\s*(?:void\s*)?\)/g)];
  if(output.length!==1||main.length!==1||output[0].index<main[0].index
    ||! /\bdepth\b/.test(output[0][1])||! /\bfloat\s+depth\s*=/.test(inspected)
    ||! /\bvarying\s+(?:(?:highp|mediump|lowp)\s+)?vec2\s+vUvs\s*;/.test(inspected)
    ||inspected.includes(EDGE_UNIFORM))return null;
  const at=output[0].index,begin=main[0].index;
  const fade=`\n  if(${EDGE_UNIFORM}>0.0){\n    float ffRadius=length(vUvs-vec2(0.5))*2.0;\n    depth*=1.0-smoothstep(1.0-${EDGE_UNIFORM},1.0,ffRadius);\n  }\n  `;
  return fragment.slice(0,begin)+`uniform float ${EDGE_UNIFORM};\n`+fragment.slice(begin,at)+fade+fragment.slice(at);
}

const geometryData=graphics=>graphics?.geometry?.graphicsData;
function nativeRadius(source){
  const {bright,dim,radius}=source.data??{};
  if(Number.isFinite(bright)||Number.isFinite(dim))return Math.max(0,Number.isFinite(bright)?bright:0,Number.isFinite(dim)?dim:0);
  return Number.isFinite(radius)?Math.max(0,radius):Number.isFinite(source.radius)?Math.max(0,source.radius):0;
}
const eligible=source=>source.active!==false&&source.hasActiveLayer!==false&&nativeRadius(source)>0;

function adapterStamp(graphics,matches){
  const geometry=graphics.geometry;
  return {geometry,dirty:geometry.dirty,clearDirty:geometry.clearDirty,entries:[...geometryData(graphics)],
    selected:[...matches].map(([data,source])=>
      [data,source,source.shape,source.updateId,source.x,source.y,nativeRadius(source)])};
}
function sameStamp(stamp,graphics,matches){
  const geometry=graphics.geometry,entries=geometryData(graphics);
  if(stamp.geometry!==geometry||stamp.dirty!==geometry.dirty||stamp.clearDirty!==geometry.clearDirty||
    stamp.entries.length!==entries.length||stamp.selected.length!==matches.size)return false;
  for(let i=0;i<entries.length;i++)if(stamp.entries[i]!==entries[i])return false;
  let index=0;
  for(const [data,source]of matches){
    const previous=stamp.selected[index++];
    if(previous[0]!==data||previous[1]!==source||previous[2]!==source.shape||previous[3]!==source.updateId||
      previous[4]!==source.x||previous[5]!==source.y||previous[6]!==nativeRadius(source))return false;
  }
  return true;
}

/** Use membership of the native visibility drawing, not our own visibility test.
 * In particular, a source on another level is never added to this visual mask. */
function selectedEntries(vision,sources){
  const candidates=[...new Set([vision.light,vision.light?.sources,vision.light?.preview].filter(Boolean))];
  const selected=new Map(),found=new Set();
  // Match current native identities once. The former nested search repeated
  // every registered source lookup for every unrelated visibility polygon.
  // First ownership is retained if malformed sources share one shape, so the
  // existing missing/duplicate-source fallback remains unchanged.
  const byShape=new Map();
  for(const source of sources){const shape=source.shape;if(shape===shape&&!byShape.has(shape))byShape.set(shape,source);}
  for(const graphics of candidates){
    const entries=geometryData(graphics);if(!Array.isArray(entries))continue;
    const matches=new Map();
    for(const data of entries){
      const source=byShape.get(data.shape);if(!source)continue;
      if(found.has(source))throw new Error('A wing light appears more than once in the native visibility drawing. Native visibility is retained.');
      matches.set(data,source);found.add(source);
    }
    if(matches.size)selected.set(graphics,matches);
  }
  return {selected,found};
}

function copyOrdinaryGraphics(original,omitted){
  const Graphics=globalThis.PIXI?.LegacyGraphics??globalThis.PIXI?.Graphics;
  if(!Graphics||typeof original._render!=='function')throw new Error('The native light graphics renderer is unavailable.');
  const replacement=new Graphics();
  try{
    const geometry=replacement.geometry;
    if(typeof geometry?.drawShape!=='function'||typeof geometry?.drawHole!=='function')throw new Error('The native light graphics geometry cannot be retained.');
    for(const data of geometryData(original)){
      if(omitted.has(data))continue;
      geometry.drawShape(data.shape,data.fillStyle?.clone?.()??data.fillStyle,data.lineStyle?.clone?.()??data.lineStyle,data.matrix);
      for(const hole of data.holes??[])geometry.drawHole(hole.shape,hole.matrix);
    }
    replacement.blendMode=original.blendMode;
    replacement.tint=original.tint;
    replacement.shader=original.shader;
    return replacement;
  }catch(error){replacement.destroy();throw error;}
}

function coverageInput(data){
  const fill=data.fillStyle,line=data.lineStyle;
  if(!fill||fill.visible===false||!Number.isFinite(fill.color)||!Number.isFinite(fill.alpha)||fill.alpha<=0||fill.alpha>1
    ||fill.texture&&fill.texture!==PIXI.Texture?.WHITE||line?.visible!==false&&line?.width>0&&line?.alpha>0)
    throw new Error('The native wing-light mask uses an unsupported fill or stroke. Native visibility is retained.');
  const matrix=data.matrix;
  if(matrix&&(matrix.a!==1||matrix.b!==0||matrix.c!==0||matrix.d!==1||matrix.tx!==0||matrix.ty!==0))
    throw new Error('The native wing-light mask uses transformed coordinates. Native visibility is retained.');
  const color=fill.color,alpha=clamp(fill.alpha);
  const points=Array.from(data.shape?.points??[]),holes=[];
  if(points.length<6)throw new Error('The wing light has no native polygon for edge feathering.');
  for(const hole of data.holes??[]){
    if(hole.matrix)throw new Error('A transformed visibility hole cannot be safely feathered.');
    const coordinates=hole.shape?.points;
    if(!coordinates?.length)throw new Error('A visibility hole is not a polygon.');
    holes.push(points.length/2);points.push(...coordinates);
  }
  if(points.some(value=>!Number.isFinite(value)))throw new Error('The wing-light visibility polygon has invalid coordinates.');
  return {points,holes,color,alpha};
}

function sameCoverageInput(mesh,data){
  const previous=mesh.ffWingMaskInput,input=coverageInput(data);
  return !!previous&&previous.color===input.color&&previous.alpha===input.alpha
    &&previous.points.length===input.points.length&&previous.holes.length===input.holes.length
    &&previous.holes.every((value,index)=>value===input.holes[index])
    &&previous.points.every((value,index)=>value===input.points[index]);
}

function coverageMesh(data,source,entry,program,prepared=null){
  const input=prepared??coverageInput(data),{points,holes,color,alpha}=input;
  const indices=PIXI.utils.earcut(points,holes,2);
  if(!indices.length)throw new Error('The wing-light visibility polygon could not be triangulated.');
  const geometry=new PIXI.Geometry().addAttribute('aVertexPosition',new Float32Array(points),2).addIndex(indices);
  const angle=entry.angle*Math.PI/180,halfAngle=entry.width*Math.PI/360,width=entry.strength*.5;
  const shader=new PIXI.Shader(program,{center:new Float32Array([source.x,source.y]),rangeRadius:nativeRadius(source),featherWidth:width,
    direction:new Float32Array([Math.cos(angle),Math.sin(angle)]),halfAngle,angularFeather:entry.width>=359.999?0:halfAngle*width,
    maskColor:new Float32Array([((color>>>16)&255)/255,((color>>>8)&255)/255,(color&255)/255,alpha])});
  const mesh=new PIXI.Mesh(geometry,shader);
  mesh.ffWingMaskColor=Array.from(shader.uniforms.maskColor);
  mesh.ffWingMaskMetadata=[entry.angle,entry.width,entry.strength];
  mesh.ffWingMaskInput=input;
  mesh.blendMode=PIXI.BLEND_MODES.MAX_COLOR;
  shader.batchable=false;
  if(data.matrix)mesh.transform.setFromMatrix(data.matrix);
  mesh.renderable=false;
  return mesh;
}

/** Retain a native polygon's triangulation only for exact translations. A wall
 * or hole change receives fresh native earcut indices; mutable public buffers
 * can retain the owned mesh/shader without retaining the previous triangles.
 * Stored double-precision inputs also detect in-place native mutations. */
function updateCoverageMesh(mesh,data,source,entry,input=coverageInput(data)){
  const previous=mesh.ffWingMaskInput;
  if(mesh.destroyed||!previous)return false;
  const points=input.points;
  const sameTopology=previous.points.length===points.length&&previous.holes.length===input.holes.length
    &&previous.holes.every((value,index)=>value===input.holes[index]);
  const dx=points[0]-previous.points[0],dy=points[1]-previous.points[1];
  let translated=sameTopology;
  for(let i=0;translated&&i<points.length;i+=2)
    if(points[i]-previous.points[i]!==dx||points[i+1]-previous.points[i+1]!==dy)translated=false;
  if(!translated||dx!==0||dy!==0){
    const vertices=mesh.geometry?.getBuffer?.('aVertexPosition');
    if(typeof vertices?.update!=='function')return false;
    if(!translated){
      const index=mesh.geometry?.getIndex?.();
      // Geometry.addIndex(array) creates this native index format. If a
      // different backend exposes another layout, recreate through that API.
      if(typeof index?.update!=='function'||!(index.data instanceof Uint16Array))return false;
      const indices=PIXI.utils.earcut(points,input.holes,2);
      if(!indices.length)throw new Error('The wing-light visibility polygon could not be triangulated.');
      if(indices.some(value=>value>65535))return false;
      vertices.update(new Float32Array(points));index.update(new Uint16Array(indices));
    }else vertices.update(new Float32Array(points));
  }
  const uniforms=mesh.shader.uniforms,color=input.color;
  uniforms.center[0]=source.x;uniforms.center[1]=source.y;uniforms.rangeRadius=nativeRadius(source);
  mesh.ffWingMaskColor[0]=((color>>>16)&255)/255;mesh.ffWingMaskColor[1]=((color>>>8)&255)/255;
  mesh.ffWingMaskColor[2]=(color&255)/255;mesh.ffWingMaskColor[3]=input.alpha;
  for(let i=0;i<4;i++)uniforms.maskColor[i]=mesh.ffWingMaskColor[i];
  mesh.ffWingMaskInput=input;
  updateCoverageUniforms(mesh,entry);
  return true;
}

/** Direction and softness do not alter native polygon topology. Updating their
 * uniforms retains the exact wall-clipped mesh instead of triangulating it a
 * second time. Native geometry, membership and source changes still rebuild. */
function updateCoverageUniforms(mesh,entry){
  const metadata=mesh.ffWingMaskMetadata;
  if(metadata[0]===entry.angle&&metadata[1]===entry.width&&metadata[2]===entry.strength)return;
  const uniforms=mesh.shader.uniforms,angle=entry.angle*Math.PI/180,halfAngle=entry.width*Math.PI/360,width=entry.strength*.5;
  uniforms.direction[0]=Math.cos(angle);uniforms.direction[1]=Math.sin(angle);
  uniforms.halfAngle=halfAngle;uniforms.featherWidth=width;
  uniforms.angularFeather=entry.width>=359.999?0:halfAngle*width;
  metadata[0]=entry.angle;metadata[1]=entry.width;metadata[2]=entry.strength;
}

/** This controller only decorates explicitly registered wing sources. The only
 * scene-wide integration is a passive subclass of the configured visibility
 * filter; it reads our texture solely while that filter composites its image. */
export class WingLightEdges {
  constructor(){
    this.sources=new Map();this.shaderRecords=new WeakMap();this.programs=new WeakMap();
    this.adapters=[];this.texture=null;this.mask=null;this.vision=null;this.active=false;this.renderFailed=false;
    this.installed=false;this.filterReady=false;this.filterType=null;this.filterObserved=null;this.reason=null;this.warnings=new Set();this.program=null;
  }
  install(){
    if(this.installed)return;this.installed=true;
    const installFilter=()=>{
      const Base=globalThis.CONFIG?.Canvas?.visibilityFilter;
      if(typeof Base?.prototype?.apply!=='function'){this.reason='The native visibility filter is unavailable.';return;}
      const owner=this;
      this.filterType=CONFIG.Canvas.visibilityFilter=class WingVisibilityFilter extends Base {
        apply(...args){
          if(!owner.active||!owner.texture)return super.apply(...args);
          if(!Object.hasOwn(this.uniforms??{},'visionTexture')){
            owner.active=false;owner.warn('The current visibility compositor has no vision sampler. Native visibility is retained.');return super.apply(...args);
          }
          const original=this.uniforms.visionTexture;
          this.uniforms.visionTexture=owner.texture;
          owner.filterObserved=null;
          try{const result=super.apply(...args);owner.filterObserved=owner.texture;return result;}finally{this.uniforms.visionTexture=original;}
        }
      };
      this.filterReady=true;
    };
    if(globalThis.game?.ready)installFilter();else globalThis.Hooks?.once?.('init',installFilter);
    globalThis.Hooks?.on?.('initializePointLightSourceShaders',source=>this.updateShaders(source));
    globalThis.Hooks?.on?.('visibilityRefresh',visibility=>this.refresh(visibility));
    globalThis.Hooks?.on?.('canvasReady',()=>this.refresh());
    globalThis.Hooks?.on?.('canvasTearDown',()=>this.clear());
  }
  externalOwner(){return !!globalThis.game?.modules?.get?.('vision-edge-attenuation')?.active;}
  warn(reason){
    this.reason=reason;if(this.warnings.has(reason))return;this.warnings.add(reason);
    const message=`Yvaelle’s Toolbox wing-light edges: ${reason}`;
    console.warn(message);globalThis.ui?.notifications?.warn?.(message);
  }
  track(source,strength,options={}){
    let entry=this.sources.get(source);
    if(!entry){entry={strength:0,ready:false,shaders:new Set(),shader:true,angle:0,width:360};this.sources.set(source,entry);}
    entry.strength=clamp(strength);
    const previouslyShader=entry.shader;
    entry.shader=options.shader!==false;
    entry.angle=Number.isFinite(options.angle)?modulo(options.angle,360):0;
    entry.width=Number.isFinite(options.width)?Math.min(360,Math.max(1,options.width)):360;
    // Lantern adaptive programs already shape the visible layers. Sharing only
    // the native visibility drawing avoids owning or multiplying those programs
    // a second time, and remains usable when a source has no current layers.
    if(!entry.shader){
      for(const shader of entry.shaders)this.restoreShader(shader);
      entry.shaders.clear();entry.ready=entry.strength>0&&!this.externalOwner();
    }else if(!previouslyShader)entry.ready=false;
    if(this.externalOwner()&&entry.strength>0){
      this.warn('Vision Edge Attenuation is active. Its token light edge override or default light edge setting controls wing lights; Filament feathering is paused to avoid applying two fades.');
    }
  }
  restoreShader(shader){
    const record=this.shaderRecords.get(shader);if(!record)return;
    if(shader.program===record.patched)setLightShaderProgram(shader,record.original,{layoutChanged:true});
    delete shader.uniforms[EDGE_UNIFORM];invalidateLightUniformLayout(shader);markLightShaderUniformsDirty(shader);this.shaderRecords.delete(shader);
  }
  updateShaders(source){
    if(!localPerformance.active)return this.updateLightingShaders(source);
    return localPerformance.measure('lighting',()=>this.updateLightingShaders(source));
  }
  updateLightingShaders(source){
    const entry=this.sources.get(source);if(!entry)return;
    if(!entry.shader){
      for(const shader of entry.shaders)this.restoreShader(shader);
      entry.shaders.clear();entry.ready=entry.strength>0&&!this.externalOwner();return;
    }
    const shaders=Object.values(source.layers??{}).map(layer=>layer.shader).filter(Boolean);
    for(const shader of entry.shaders)if(!shaders.includes(shader))this.restoreShader(shader);
    entry.shaders=new Set(shaders);entry.ready=false;
    if(!entry.strength||this.externalOwner()){for(const shader of shaders)this.restoreShader(shader);return;}
    if(!shaders.length)return;
    try{
      const changes=[];
      for(const shader of shaders){
        let record=this.shaderRecords.get(shader);
        if(record&&shader.program!==record.original&&shader.program!==record.patched)record=null;
        if(!record){
          const original=shader.program;
          if(!original||typeof original.vertexSrc!=='string')throw new Error('A wing-light shader is not a supported native adaptive shader.');
          let patched=this.programs.get(original);
          if(patched?.error)throw new Error(patched.error);
          if(!patched){
            const fragment=featherLightFragment(original.fragmentSrc);
            if(!fragment){
              const error='A wing-light shader has an unsupported output. Native lighting is retained.';
              this.programs.set(original,{error});throw new Error(error);
            }
            patched=PIXI.Program.from(shaderSource(original.vertexSrc),shaderSource(fragment));this.programs.set(original,patched);
          }
          record={original,patched};
        }
        changes.push({shader,record});
      }
      for(const {shader,record} of changes){
        const layoutChanged=lightUniformLayoutChanged(shader,record,[EDGE_UNIFORM]);
        this.shaderRecords.set(shader,record);setLightUniform(shader,EDGE_UNIFORM,entry.strength*.5);setLightShaderProgram(shader,record.patched,{layoutChanged});markLightShaderUniformsDirty(shader,{changedOnly:true});
      }
      entry.ready=true;
    }catch(error){
      for(const shader of shaders)this.restoreShader(shader);
      this.warn(error.message);this.releaseVisual();
    }
  }
  untrack(source){
    const entry=this.sources.get(source);if(!entry)return;
    for(const shader of entry.shaders)this.restoreShader(shader);
    this.sources.delete(source);this.releaseVisual();
  }
  releaseAdapters(retained=new Set()){
    this.active=false;
    for(const {replacement,meshes} of this.adapters){
      if(!replacement.destroyed)replacement.destroy();for(const mesh of meshes)if(!retained.has(mesh)&&!mesh.destroyed)mesh.destroy();
    }
    this.adapters=[];
  }
  releaseVisual(){
    this.releaseAdapters();
    if(this.texture&&this.mask&&!this.mask.destroyed)this.mask.removeRenderTexture(this.texture);
    this.texture=null;this.mask=null;this.vision=null;this.filterObserved=null;
  }
  refresh(visibility=globalThis.canvas?.visibility){
    if(!localPerformance.active)return this.refreshLighting(visibility);
    return localPerformance.measure('lighting',()=>this.refreshLighting(visibility));
  }
  refreshLighting(visibility=globalThis.canvas?.visibility){
    if(!visibility?.vision?.light)visibility=globalThis.canvas?.visibility;
    const sources=[...this.sources].filter(([source,entry])=>entry.strength>0&&entry.ready&&eligible(source)).map(([source])=>source);
    if(!sources.length||this.externalOwner()){this.releaseVisual();return;}
    if(visibility?.tokenVision===false||visibility?.visible===false){this.releaseVisual();return;}
    if(globalThis.canvas?.visibilityOptions?.persistentVision){
      this.releaseVisual();this.warn('Persistent vision has no current-vision sampler. Native visibility is retained.');return;
    }
    const Filter=globalThis.CONFIG?.Canvas?.visibilityFilter;
    if(this.filterType&&Filter!==this.filterType&&!(Filter?.prototype instanceof this.filterType)){
      this.releaseVisual();this.warn('Another module replaced the visibility compositor. Native visibility is retained.');return;
    }
    const mask=globalThis.canvas?.masks?.vision,vision=visibility?.vision;
    if(!this.filterReady||!mask?.createRenderTexture||!mask?.removeRenderTexture||!vision?.render||!vision?.light||!vision?.sight||!vision?.darkness||!globalThis.PIXI?.utils?.earcut){
      this.releaseVisual();this.warn('The native visual-mask API is unavailable. Native visibility is retained.');return;
    }
    try{
      // Both old and new V14 visibility layouts are handled. Never infer a new
      // mask from the collection of light sources: that can cross level or LOS
      // boundaries. A cached/unidentified wing contribution must stay native.
      const {selected,found}=selectedEntries(vision,sources);
      if(sources.some(source=>!found.has(source)))throw new Error('The native visibility drawing does not expose every wing light separately (it may be cached or use an unsupported layout). Native visibility is retained.');
      if(this.mask===mask&&this.vision===vision&&this.adapters.length===selected.size
        &&this.adapters.every(adapter=>{
          const matches=selected.get(adapter.graphics);if(!matches||!sameStamp(adapter.stamp,adapter.graphics,matches))return false;
          let index=0;for(const [data] of matches)if(!sameCoverageInput(adapter.meshes[index++],data))return false;
          return true;
        })){
        if(this.renderFailed)return;
        for(const adapter of this.adapters)for(let i=0;i<adapter.meshes.length;i++)
          updateCoverageUniforms(adapter.meshes[i],this.sources.get(adapter.sources[i]));
        this.active=true;this.reason=null;mask.renderDirty=true;return;
      }
      if(this.mask!==mask||this.vision!==vision)this.releaseVisual();
      this.mask=mask;this.vision=vision;
      this.program??=PIXI.Program.from(WING_EDGE_VERTEX,WING_EDGE_FRAGMENT);
      const previous=this.adapters,pending=[],retained=new Set(),meshes=new Map();
      for(const adapter of previous)for(let i=0;i<adapter.sources.length;i++)meshes.set(adapter.sources[i],adapter.meshes[i]);
      try{
        for(const [graphics,matches] of selected){
          const replacement=copyOrdinaryGraphics(graphics,matches),adapter={graphics,replacement,meshes:[],sources:[],stamp:adapterStamp(graphics,matches)};
          pending.push(adapter);
          for(const [data,source] of matches){
            let mesh=meshes.get(source);const input=coverageInput(data);
            if(mesh&&updateCoverageMesh(mesh,data,source,this.sources.get(source),input))retained.add(mesh);
            else mesh=coverageMesh(data,source,this.sources.get(source),this.program,input);
            // Re-add in current native source order, after any cached children
            // appended since the previous pass, exactly as fresh meshes were.
            graphics.addChild(mesh);
            adapter.meshes.push(mesh);adapter.sources.push(source);
          }
        }
        this.releaseAdapters(retained);this.adapters=pending;
      }catch(error){
        // Both newly made resources and retained meshes must be released on a
        // native-layout fallback. A retained mesh may already be reparented.
        this.adapters=[...previous,...pending];throw error;
      }
      this.texture??=mask.createRenderTexture({clearColor:[0,0,0,0],renderFunction:renderer=>this.renderVisual(renderer)});
      this.active=true;this.renderFailed=false;this.reason=null;mask.renderDirty=true;
    }catch(error){this.releaseVisual();this.warn(error.message);}
  }
  renderVisual(renderer){
    if(!localPerformance.active)return this.renderVisualLighting(renderer);
    return localPerformance.measure('lighting',()=>this.renderVisualLighting(renderer));
  }
  renderVisualLighting(renderer){
    if(!this.active||!this.vision)return;
    const restore=[];
    try{
      for(const {graphics,replacement,meshes} of this.adapters){
        const own=Object.hasOwn(graphics,'_render'),render=graphics._render;
        restore.push(()=>{if(own)graphics._render=render;else delete graphics._render;for(const mesh of meshes)mesh.renderable=false;});
        // Replace this Graphics object's own drawing for this synchronous pass.
        // Its native Container.render still supplies masks, children, filters,
        // cached light, preview handling, transforms and MAX_COLOR composition.
        graphics._render=()=>{
          replacement.transform=graphics.transform;replacement.worldAlpha=graphics.worldAlpha;
          replacement.tint=graphics.tint;replacement.blendMode=graphics.blendMode;replacement.shader=graphics.shader;
          replacement._render(renderer);
        };
        for(const mesh of meshes){
          const tint=Number.isFinite(graphics.tint)?graphics.tint:0xffffff,color=mesh.ffWingMaskColor,uniform=mesh.shader.uniforms.maskColor;
          uniform[0]=color[0]*((tint>>>16)&255)/255;uniform[1]=color[1]*((tint>>>8)&255)/255;uniform[2]=color[2]*(tint&255)/255;
          uniform[3]=color[3]*(Number.isFinite(graphics.worldAlpha)?clamp(graphics.worldAlpha):1);
          mesh.renderable=true;
        }
      }
      this.vision.render(renderer);
    }catch(error){this.active=false;this.renderFailed=true;this.warn(`The visual mask could not render (${error.message}). Native visibility is retained.`);}
    finally{for(const reset of restore.reverse())reset();}
  }
  clear(){
    this.releaseVisual();for(const source of [...this.sources.keys()])this.untrack(source);
  }
  status(source){
    const entry=this.sources.get(source);
    return {shaderActive:!!entry?.ready&&entry.shader,visibilityReady:!!entry?.ready&&this.active,
      visibilityActive:!!entry?.ready&&this.active&&this.filterObserved===this.texture,
      reason:this.reason??(this.active&&this.filterObserved!==this.texture?'Waiting for the native visibility compositor.':null)};
  }
}
