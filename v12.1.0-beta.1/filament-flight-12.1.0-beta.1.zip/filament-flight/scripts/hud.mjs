import {GeneralAnimationPicker} from './animation-browser.mjs?v=12.1.0-beta.1';
import {TOKEN_EFFECT_PROGRAMS} from './token-effects.mjs?v=12.1.0-beta.1';
import {audioFieldPatch} from './audio-hud.mjs?v=12.1.0-beta.1';
import {AUDIO_SLOTS,AUDIO_CATEGORIES} from './audio-model.mjs?v=12.1.0-beta.1';
import {ID,configuration,runtimeConfiguration,SETTINGS} from './config.mjs?v=12.1.0-beta.1';
import {HUD_TABS,HUD_GROUPS,hudSettingsRoute,HUD_THEME_DEFAULTS,hudBitGroups,hudHomePanels,hudHeader,hudBitCommandState,hudBitAllocations,safeBitTargetName,hudHookRelevant,hudPreferences,migratePinnedCharacterPreferences,pinnedCharacterActorId,hudPosition,hudModel,eligibleTokens,hudCommand,DISPLAY_PRESETS,FLOAT_STYLES,bitPosition,bitPlacementPatch,mirrorBitPatch,BIT_PLACEMENT_MAP,bitMapPercent} from './hud-model.mjs?v=12.1.0-beta.1';
import {updateHUDStatus,renderDispatchControls} from './hud-view.mjs?v=12.1.0-beta.1';
import {CONDITION_IDS} from './effect-styles.mjs?v=12.1.0-beta.1';
import {REACTION_IDS} from './effect-catalog.mjs?v=12.1.0-beta.1';
import {EffectPicker} from './effect-picker.mjs?v=12.1.0-beta.1';
import {AudioPicker} from './audio-picker.mjs?v=12.1.0-beta.1';
import {compactAnimationChoices} from './compact-bit-formations.mjs?v=12.1.0-beta.1';
const formationOptions=model=>({v7Enabled:model.state?.v7?.enabled===true&&model.state?.v7?.formations===true,library:(()=>{try{return game.settings.get('filament-flight','formationLibrary');}catch{return 'all';}})()});
import {startCompactPreview} from './hud-bit-preview.mjs?v=12.1.0-beta.1';
import {qualityValues,previewQualityConfiguration} from './quality.mjs?v=12.1.0-beta.1';
import {POSE_MOTION_FIELDS,GEM_MOTION_FIELDS,BIT_STATIONS,BIT_POSITION_FIELDS} from './wing-controls.mjs?v=12.1.0-beta.1';
import {playOpen} from './keepsake/hud-open-fx.mjs?v=12.1.0-beta.1';
import {createHUDMotion,hudMotionOptions} from './hud-motion.mjs?v=12.1.0-beta.1';
import {hudStateExplanation,hudDispatchSummary} from './hud-model.mjs?v=12.1.0-beta.1';
import {createPortraitController} from './hud-portrait.mjs?v=12.1.0-beta.1';
import {filterHUDSettings} from './hud-search.mjs?v=12.1.0-beta.1';
import {BitToolUI} from './v8-tool-ui.mjs?v=12.1.0-beta.1';
import {timed} from './keepsake/timings.mjs?v=12.1.0-beta.1';
import {createKeepsakeApplication} from './keepsake/app.mjs?v=12.1.0-beta.1';

const LOCAL_KEYS=['localEffects','localTrails','reducedMotion','renderWorker','rigQuality','bitQuality','rigFPS','poseFPS','audioMuted','audioLocalVolume'];
const PREF_KEYS=['transitionMs','fadeMs','holdMs','pulseDurationMs','stutterDurationMs','temporaryPose','temporaryCondition','effectStrength','keepWings','formation','foldWings'];
const STATE_KEYS=['intensity','glitchIntensity','trailIntensity','autoHP','movementReactions','lightIntensity','lightBright','lightDim','lightAppearance','lightVisualReactions','lanternArtwork','effectStyle'];
const readPreferences=()=>{try{return hudPreferences(game.settings.get(ID,'hudPreferences'));}catch{return hudPreferences();}};
const TIMED=['transition','poseTransition','conditionTransition','hpTransition','modeTransition','bitTransition','bitCountTransition','structureTransition','structurePoseTransition','temporaryPose','temporaryCondition'];
/** Something on show changes with time alone, so the poll keeps reading the model. */
function hudTimed(m){
  const s=m?.state,now=m?.now??Date.now();if(!s)return false;
  const running=t=>t?.active===true||Number.isFinite(t?.started)&&Number.isFinite(t?.duration)&&now<t.started+t.duration+500;
  return TIMED.some(k=>running(s[k]))||!!s.structureAnimation?.active||Object.values(s.cues??{}).some(c=>c?.active)||!!s.lantern?.aiming||!!m.performance?.active||
    !!m.v8Tools?.tasks?.length||(m.bitTasks?.active??[]).some(e=>e.kind!=='escort')||!!m.bitTasks?.queued?.length||(m.bitTasks?.groups??[]).some(g=>g.flow?.enabled);
}

/** One local window per API instance. Scene animation and document writes belong to the API. */
export class FlightHUD {
  constructor(api,{createApplication=createHUDApplication}={}) {
    this.api=api;this.createApplication=createApplication;this.app=null;this.opened=false;
    this.hooks=[];this.busy=false;this.prefs=readPreferences();this.preferenceQueue=Promise.resolve();this.preferenceRevision=0;this.unsavedPreferences=null;
    this.message='';this.failure=false;this.epoch=0;this.targetId=null;this.tabScroll={};
    this.lookClipboard=null;this.lookUndo=null;this.lookName='';this.motion=createHUDMotion();this.navigationEpoch=0;
    this.bitPlacementEdits=[];this.bitPlacementQueue=Promise.resolve();this.bitPlacementRevision=0;
    this.toolUI=new BitToolUI(this);
    this.dispatchSelectedBits=[];this.dispatchSelectionVersions=new Map();this.bitSelection='leftUpper';this.bitDrag=null;this.search='';this.bitGroup='home';this.bitAliases=new Map();this.settingsFocus=null;this.settingsHistory=[];this.groupDirection=null;
  }
  model(){
    const api=this.api(),base=timed('hud:model',()=>hudModel(api,this.prefs,this.targetId,undefined,this.modelCache??={}));this.observedToken=base.token;
    if(base.state&&this.bitPlacementEdits.some(edit=>edit.target===base.token?.document.uuid))base.state={...base.state,requested:{...base.state.requested,gemMotion:this.bitPlacementRequest(base)}};
    const owner=base.token?.document.uuid??null;if(this.dispatchOwner!==owner){this.endDiamondPaint();this.setDispatchSelection([]);this.dispatchOwner=owner;}
    if(this.lanternAimToken&&this.lanternAimToken.document.uuid!==owner)this.endLanternAim();
    const presentedGroups=hudBitGroups(base);
    if(!presentedGroups.some(g=>g.id===this.bitGroup)){this.bitGroup=presentedGroups[0].id;this.groupDirection='previous';}
    for(const group of base.bitTasks?.groups??[])if(group.id!=='home'&&!this.bitAliases.has(group.target??group.id))this.bitAliases.set(group.target??group.id,this.bitAliases.size+1);
    const model={...base,v8Tools:base.token?this.toolUI.state(base.token):null,v8ToolPreferences:base.token?api.getBitToolPreferences?.(base.token):null,conditionSettings:base.token?api.conditionReactions?.get?.(base.token):null,conditionResponse:base.state?.conditionResponse??null,dispatchSelectedBits:[...this.dispatchSelectedBits],settingsFocus:this.settingsFocus,settingsBack:this.settingsHistory.at(-1)??null,bitAliases:this.bitAliases,bitGroup:this.bitGroup,performance:api.performance?.getReport?.()??null,bitSelection:this.bitSelection,search:this.search,lookUI:{clipboard:this.lookClipboard?{name:this.lookClipboard.name}:null,undo:this.lookUndo?{target:this.lookUndo.target}:null,name:this.lookName}};
    model.stateExplanation=hudStateExplanation(model);model.dispatchSummary=hudDispatchSummary(model);model.header=hudHeader(model);return model;
  }
  signature(m) {
    return JSON.stringify([m.token?.document.uuid,m.available.map(t=>[t.document.uuid,t.document.name??t.name??t.id]),
      m.selectedCount,m.error,m.cfg,m.state?.requested,m.baseAppearance,m.state?.enabled,
      m.state?.transition?.active,m.state?.temporaryPose?.active,m.state?.temporaryCondition?.active,m.audio?.requested,
      m.state?.lantern?.aiming,m.state?.effective?.pose,m.state?.effective?.condition,m.state?.effective?.mode,m.state?.rendering?.fallback,
      m.v8ToolPreferences,m.v8Tools?.undo,m.v8Tools?.available,(m.v8Tools?.tasks??[]).map(t=>[t.id,t.mode,t.bits,t.status]),m.conditionSettings,m.conditionResponse?.primary,m.conditionResponse?.active,m.conditionResponse?.collapse?.phase,m.settingsFocus,m.settingsBack,m.bitTasks,hudBitGroups(m).map(g=>[g.id,g.label]),m.bitGroup,m.dispatchSelectedBits,m.localQuality,m.state?.observerQuality,m.lookPresets,m.savedLooks,m.lookUI,m.bitSelection,m.performance?.active?{active:true,components:m.performance.components}:m.performance,this.prefs,this.busy,this.message,this.failure]);
  }
  async open(target) {
    if(!configuration().hudEnabled)throw new Error('The flight control HUD is disabled in Yvaelle’s Toolbox settings.');
    if(this.closing)await this.closing;
    if(this.opening){await this.opening;return this.open(target);}
    if(!this.opened&&!this.unsavedPreferences)this.prefs=readPreferences();
    const migrated=migratePinnedCharacterPreferences(this.prefs);
    if(migrated.pinnedActor!==this.prefs.pinnedActor)await this.savePreferences({pinnedActor:migrated.pinnedActor});
    if(target!==undefined) {
      const doc=target?.document??target;
      const token=eligibleTokens().find(t=>t.document===doc&&!target?.isPreview);
      if(!token)throw new Error('Open the HUD with a token you own in the current scene.');
      const actorId=pinnedCharacterActorId(token);
      if(!actorId)throw new Error('This token has no character actor to pin.');
      await this.savePreferences({followSelection:false,pinnedActor:actorId,pinnedToken:doc.uuid});
      this.targetId=doc.uuid;
    }
    if(this.opened) {
      await this.app.maximize?.();await this.redraw(true);this.app.bringToFront?.();return this.app;
    }
    this.message=this.unsavedPreferences?'HUD choices not saved · your changes are still shown. Retry to remember them.':'';this.failure=!!this.unsavedPreferences;this.editing=false;this.dragging=false;
    if(this.motion.destroyed)this.motion=createHUDMotion();
    this.opened=true;this.epoch++;
    try {
      this.app=this.createApplication(this,{position:hudPosition(this.prefs.position)});
      this.attach();
      this.opening=this.redraw(true);
      await this.opening;
      if(!this.app?.rendered)throw new Error('The Yvaelle’s Toolbox HUD could not be rendered.');
      // The render hook normally plays the opening scan; this covers a HUD the hook did not see. Once per opening either way.
      try{playOpen(this.app,this.app.element);}catch{}
      return this.app;
    }catch(e){const app=this.app;this.release(app);try{await app?.close();}catch{}throw e;}
    finally{this.opening=null;}
  }
  async toggle(target){return this.opened?this.close():this.open(target);}
  async close() {
    if(this.closing)return this.closing;
    if(this.opening)await this.opening;
    const app=this.app;if(!app)return;
    this.closing=Promise.resolve(app.close());
    try{return await this.closing;}finally{this.release(app);this.closing=null;}
  }
  attach() {
    if(this.hooks.length)return;
    const observe=()=>{this.modelCache=null;this.watchDirty=true;if(!this.watchTimer)this.watchTimer=setTimeout(()=>{this.watchTimer=null;this.watch();},40);};
    for(const name of ['controlToken','createToken','updateToken','deleteToken','updateActor','updateActorDelta',
      'createItem','updateItem','deleteItem','createActiveEffect','updateActiveEffect','deleteActiveEffect',
      'updateUser','filamentFlightSettingsChanged','filamentFlightStateChanged','filamentFlightAudioChanged','filamentFlightBitsChanged','filamentFlightPerformanceChanged'])
      this.hooks.push([name,Hooks.on(name,(...args)=>{if(hudHookRelevant(name,args,this.observedToken))observe();})]);
    this.hooks.push(['targetToken',Hooks.on('targetToken',(...args)=>{if(hudHookRelevant('targetToken',args,this.observedToken))this.refreshTargeting();})]);
    this.hooks.push(['canvasTearDown',Hooks.on('canvasTearDown',()=>{void this.close().catch(e=>this.fail(e));})]);
    // Only read status while the HUD is open. The module owns all effect deadlines.
    this.watchDirty=true;this.idleTicks=0;
    this.poll=setInterval(()=>this.watch(),500);
  }
  suspend() {
    this.toolUI.suspend();
    this.endLanternAim();
    this.motion.destroy();this.portrait?.destroy();this.portrait=null;this.navigationEpoch++;this.navigationMotion=null;
    this.endDiamondPaint();this.cancelBitDrag({render:false});this.observedToken=null;this.modelCache=null;
    this.stopCompactPreview();clearTimeout(this.bitCountTimer);clearTimeout(this.searchTimer);this.searchTimer=null;this.bitCountTimer=null;this.pendingBitCount=null;
    if(this.performanceOwned){const perf=this.api().performance;try{if(perf?.getReport?.().active)perf.stop();perf?.setComponents({wings:true,bits:true,fields:true,trails:true,treatment:true});}catch{}this.performanceOwned=false;}
    this.animationPicker?.close();this.picker?.close();this.audioPicker?.close();this.stopAudioPreview();this.closeAudioFilePicker();
    this.opened=false;this.epoch++;this.domEvents?.abort();this.domEvents=null;
    clearInterval(this.poll);clearTimeout(this.renderTimer);clearTimeout(this.positionTimer);clearTimeout(this.watchTimer);this.watchTimer=null;
    this.poll=null;this.renderTimer=null;this.positionTimer=null;
    for(const [name,id] of this.hooks)Hooks.off(name,id);this.hooks=[];
  }
  release(app) {
    if(app!==this.app)return;
    this.suspend();this.app=null;this.root=null;this.content=null;this.lastSignature=null;this.modelCache=null;
    this.pendingRender=false;this.editing=false;this.dragging=false;
  }
  endLanternAim() {
    const token=this.lanternAimToken;this.lanternAimToken=null;if(!token)return;
    const doc=token.document;if(!doc||doc.parent?.tokens?.get(doc.id)!==doc)return;
    const api=this.api();if(api.isLanternAiming?.(token))void Promise.resolve(api.stopLanternAim?.()).catch(error=>this.fail(error));
  }
  watch() {
    this.pauseHeaderMotion();
    if(!this.opened||this.root?.ownerDocument?.hidden||this.app?.minimized)return;
    // Idle: no hook fired and nothing timed is showing. A slow sweep still catches local-only changes.
    if(!this.watchDirty&&!this.watchTimed&&++this.idleTicks<10)return;
    this.watchDirty=false;this.idleTicks=0;
    try {
      if(runtimeConfiguration().hudEnabled===false){void this.close().catch(e=>this.fail(e));return;}
      const model=this.model();this.watchTimed=hudTimed(model);this.toolUI.validate(model);this.refreshTargeting(model);updateHUDStatus(this.root,model);this.app?.onModel?.(model);this.portrait?.update(model);this.picker?.update(model);this.animationPicker?.update(model);this.audioPicker?.update(model);
      if(this.signature(model)!==this.lastSignature) {
        const changed=(model.token?.document.uuid??'')!==(this.root?.dataset.ffToken??'');
        if(changed){this.audioPicker?.close();this.stopAudioPreview();this.closeAudioFilePicker();this.cancelBitDrag({render:false});this.editing=false;this.dragging=false;this.message='';this.failure=false;this.tabScroll={};this.setDispatchSelection([]);this.bitGroup='home';this.bitAliases.clear();this.settingsFocus=null;this.settingsHistory=[];}
        this.scheduleRender(changed);
      }
    }catch(e){this.fail(e);}
  }
  refreshTargeting(model) {
    if(!this.opened||!this.root)return;
    try{
      const current=model??this.model(),owner=current.token?.document.uuid??null;
      if(owner!==(this.root.dataset.ffToken||null))return;
      const summary=current.dispatchSummary??hudDispatchSummary(current);
      const command=hudBitCommandState(current);
      const signature=JSON.stringify([owner,current.dispatchSelectedBits,summary.summary,summary.valid,command,this.busy]);
      if(signature===this.lastDispatchSignature)return;
      this.lastDispatchSignature=signature;
      const strip=this.domScope().querySelector('[data-ff-dispatch-strip]');
      if(strip){const focus=strip.contains(strip.ownerDocument.activeElement)?strip.ownerDocument.activeElement?.dataset.ffKey:null;
        const template=strip.ownerDocument.createElement('template');template.innerHTML=renderDispatchControls(current,this.busy||!current.token);strip.replaceWith(template.content);
        if(focus)for(const node of this.domScope().querySelectorAll('[data-ff-dispatch-strip] [data-ff-key]'))if(node.dataset.ffKey===focus)node.focus({preventScroll:true});
      }
      for(const button of this.domScope().querySelectorAll('[data-ff-bit-command]')){button.title=command.hint;const active=command.scoped?command.selectedOut.length>0:command.out.length>0;button.classList.toggle('is-active',active);button.setAttribute('aria-pressed',String(active));button.setAttribute('aria-label',`${command.label}. ${command.hint}`);const label=button.querySelector('[data-ff-bit-command-label]');if(label)label.textContent=command.label;}
      for(const label of this.domScope().querySelectorAll('[data-ff-selection-summary]')){label.textContent=command.selectionSummary;label.hidden=!command.selected.length;}
      for(const diamond of this.domScope().querySelectorAll('.ff-diamond')){const selected=this.dispatchSelectedBits.includes(diamond.dataset.ffValue);diamond.classList.toggle('is-selected',selected);diamond.classList.toggle('is-dispatch-selected',selected);diamond.setAttribute('aria-pressed',String(selected));}
    }catch(error){this.fail(error);}
  }
  scheduleRender(force=false) {
    if(!this.opened)return;
    if((this.editing||this.dragging)&&!force){this.pendingRender=true;return;}
    if(this.renderTimer)return;
    this.renderTimer=setTimeout(()=>{this.renderTimer=null;void this.redraw().catch(e=>this.fail(e));},50);
  }
  async redraw(force=false) {
    if(force)this.modelCache=null;
    if(!this.opened||!this.app)return;
    if(this.rendering){this.pendingRender=true;return this.rendering;}
    if((this.editing||this.dragging)&&!force){this.pendingRender=true;return;}
    const app=this.app,epoch=this.epoch;
    this.rendering=Promise.resolve(app.render({force:true}));
    try{await this.rendering;}
    finally {
      this.rendering=null;
      if(this.pendingRender&&this.opened&&epoch===this.epoch){this.pendingRender=false;this.scheduleRender();}
    }
  }
  async savePreferences(patch) {
    this.prefs=migratePinnedCharacterPreferences({...this.prefs,...patch});
    const snapshot=structuredClone(this.prefs),revision=++this.preferenceRevision;
    const result=this.preferenceQueue.catch(()=>{}).then(()=>game.settings.set(ID,'hudPreferences',snapshot));
    this.preferenceQueue=result.catch(()=>{});
    try{
      await result;
      if(revision===this.preferenceRevision){const recovered=!!this.unsavedPreferences;this.unsavedPreferences=null;if(recovered)this.showMessage('HUD choices saved · this browser');else this.syncPreferenceRecovery();}
      return true;
    }catch(e){
      // Keep the visible choice. A newer queued snapshot already includes it;
      // an older failure must never roll that newer choice back or label it lost.
      if(revision===this.preferenceRevision){this.unsavedPreferences={revision};this.fail(new Error(`HUD choices not saved · your changes are still shown. Retry to remember them. ${e?.message??e}`));}
      return false;
    }
  }
  syncPreferenceRecovery(){const retry=this.domScope()?.querySelector('[data-ff-action="retryPreferences"]');if(retry)retry.hidden=!this.unsavedPreferences;}
  rememberPosition(position) {
    if(!this.opened)return;
    clearTimeout(this.positionTimer);
    const {left,top,width,height}=position;
    if(![left,top,width,height].every(Number.isFinite))return;
    this.positionTimer=setTimeout(()=>{this.positionTimer=null;void this.savePreferences({position:{left,top,width,height}});},350);
  }
  showMessage(message,failure=false) {
    if(this.unsavedPreferences&&!failure)message=`${message} · HUD choices not saved`;
    this.message=message;this.failure=failure;
    const el=this.domScope()?.querySelector('[data-ff-message]');
    if(el){el.textContent=message;el.classList.toggle('ff-error',failure||!!this.unsavedPreferences);el.dataset.ffMessageState=failure||this.unsavedPreferences?'error':this.busy?'saving':this.editing?'editing':'saved';}
    this.syncPreferenceRecovery();
    this.app?.onControllerMessage?.();
  }
  fail(error) {
    const message=String(error?.message??error);
    if(this.message!==message)ui.notifications.error(`Yvaelle’s Toolbox HUD: ${message}`);
    this.showMessage(message,true);
  }
  bind(content) {
    const cancelledDrag=this.cancelBitDrag({render:false});
    const portraitCarry=this.portrait?.snapshot?.();
    this.portrait?.destroy();this.portrait=null;
    this.stopCompactPreview();
    this.endDiamondPaint();this.domEvents?.abort();
    // Use the DOM's realm; this also works when Foundry hosts a detached window.
    const EventController=content.ownerDocument.defaultView?.AbortController??AbortController;
    this.domEvents=new EventController();const {signal}=this.domEvents;
    this.content=content;this.root=content.querySelector('.ff-hud');this.lastDispatchSignature=null;const root=this.root;
    this.toolUI.bind(root);
    this.bindShortcutHints(root,signal);
    if(cancelledDrag)this.showMessage('Bit move cancelled');
    this.portrait=createPortraitController(root,this.model(),{carry:portraitCarry});
    this.applySettingsFocus();this.prepareAdvanced();this.pinControlShortcuts();this.pauseHeaderMotion();
    content.ownerDocument.addEventListener('visibilitychange',()=>{this.pauseHeaderMotion();if(content.ownerDocument.hidden){this.endDiamondPaint();this.cancelBitDrag();}},{signal});
    content.ownerDocument.defaultView?.addEventListener('blur',()=>{this.endDiamondPaint();this.cancelBitDrag();},{signal});
    content.ownerDocument.addEventListener('keyup',event=>{if(event.key==='Shift')this.endDiamondPaint();},{signal});
    this.motion.configure(hudMotionOptions({cfg:runtimeConfiguration(),prefs:this.prefs}));
    this.motion.bindDisclosures(root,{signal});
    const previousDiamonds=this.diamondStates??new Map();this.diamondStates=new Map();
    for(const diamond of root.querySelectorAll('.ff-diamond')){const id=diamond.dataset.ffValue,value=`${diamond.className}:${diamond.dataset.ffDiamondState??''}`;this.diamondStates.set(id,value);if(previousDiamonds.has(id)&&previousDiamonds.get(id)!==value)void this.motion.feedback(diamond.querySelector('span')??diamond,{kind:'arrival'});}
    const theme=this.prefs.theme,host=this.app?.element;if(host?.style)for(const [name,value] of Object.entries({'--ff-bg':theme.background,'--ff-panel':theme.panel,'--ff-accent':theme.accent,'--ff-focus':theme.accent,'--ff-text':theme.text,'--ff-gold':theme.gold,'--ff-muted':`color-mix(in srgb, ${theme.text} 68%, ${theme.background})`,'--ff-line':`color-mix(in srgb, ${theme.gold} 24%, ${theme.background})`}))host.style.setProperty(name,value);
    // Never let a wheel gesture edit a number or slider, including Foundry's global handlers.
    // Re-route that same gesture to the panel so scrolling over a control remains natural.
    root.addEventListener('wheel',event=>{
      const field=event.target.closest?.('input[type="range"],input[type="number"],select');
      if(!field||!root.contains(field))return;
      event.preventDefault();event.stopImmediatePropagation();
      const scroll=field.closest('.ff-scroll,.ff-picker-choices,.ff-picker-stage');
      if(scroll){const unit=event.deltaMode===1?16:event.deltaMode===2?scroll.clientHeight:1;scroll.scrollTop+=event.deltaY*unit;scroll.scrollLeft+=event.deltaX*unit;}
    },{signal,passive:false,capture:true});
    const portraitAttention=event=>{
      const control=event.target.closest?.('button,select,input,summary');
      if(!control||!root.contains(control)||control.disabled||control.contains(event.relatedTarget))return;
      this.portrait?.cue({type:'hover',action:control.dataset.ffAction??control.dataset.ffCommand,tab:control.dataset.ffTab});
    };
    root.addEventListener('pointerover',portraitAttention,{signal});
    root.addEventListener('focusin',portraitAttention,{signal});
    root.addEventListener('pointerover',event=>{const diamond=event.target.closest?.('.ff-diamond');if(diamond&&!diamond.contains(event.relatedTarget))this.toolUI.hoverBit(diamond.dataset.ffValue);},{signal});
    root.addEventListener('pointerout',event=>{const diamond=event.target.closest?.('.ff-diamond');if(diamond&&!diamond.contains(event.relatedTarget))this.toolUI.hoverBit(null);},{signal});
    root.addEventListener('focusin',event=>{const diamond=event.target.closest?.('.ff-diamond');if(diamond)this.toolUI.hoverBit(diamond.dataset.ffValue);},{signal});
    root.addEventListener('focusout',event=>{if(event.target.closest?.('.ff-diamond'))this.toolUI.hoverBit(null);},{signal});
    root.addEventListener('click',event=>{
      const button=event.target.closest('button');if(!button||!root.contains(button)||button.disabled)return;
      if(button.matches('.ff-diamond')&&this.suppressDiamondClick&&event.detail!==0){this.suppressDiamondClick=false;event.preventDefault();event.stopPropagation();return;}
      if(this.isCurrentTab(button.dataset.ffTab))return;
      void this.motion.feedback(button);
      if(button.dataset.ffBitStation){this.bitSelection=button.dataset.ffBitStation;this.scheduleRender();return;}
      if(button.dataset.ffTab){void this.tab(button.dataset.ffTab);return;}
      const action=button.dataset.ffAction;if(!action)return;if(action==='pinSetting')event.preventDefault();
      const value=action==='toggleSummonFormation'?(event.shiftKey===true?'flow':'random'):action==='flightToggle'?{keepBits:event.shiftKey===true}:action==='toggleLightMode'?{lantern:event.shiftKey===true,keepBits:event.shiftKey===true}:button.dataset.ffValue;
      void this.click(event.shiftKey&&action==='toggleBit'?'toggleDispatchBit':action==='toggleBits'&&event.shiftKey?'gatherBits':action,value,root.dataset.ffToken);
    },{signal});
    root.querySelector('[data-ff-reactions]')?.addEventListener('toggle',event=>{
      if(this.search.trim())return;
      if(event.target.open===this.prefs.reactionEffectsOpen)return;
      void this.savePreferences({reactionEffectsOpen:event.target.open});
    },{signal});
    for(const details of root.querySelectorAll('[data-ff-audio-open]'))details.addEventListener('toggle',event=>{
      if(this.search.trim())return;
      const key=event.target.dataset.ffAudioOpen,open=this.prefs.audioOpen??[];
      if(open.includes(key)===event.target.open)return;
      void this.savePreferences({audioOpen:event.target.open?[...open,key]:open.filter(k=>k!==key)}).then(()=>this.scheduleRender());
    },{signal});
    for(const details of root.querySelectorAll('[data-ff-section]'))details.addEventListener('toggle',event=>{
      if(this.search.trim())return;
      const key=event.target.dataset.ffSection,open=this.prefs.openSections;
      if(open.includes(key)!==event.target.open)this.portrait?.cue({type:'section',action:event.target.open?'open':'close'});
      if(key==='group:audio'&&!event.target.open){this.audioPicker?.close();this.stopAudioPreview();this.closeAudioFilePicker();}
      if(open.includes(key)===event.target.open)return;
      void this.savePreferences({openSections:event.target.open?[...open,key]:open.filter(k=>k!==key)});
      if(key==='bits-placement'&&event.target.open)this.scheduleRender();
    },{signal});
    root.addEventListener('pointerdown',event=>{
      this.suppressDiamondClick=false;
      const diamond=event.target.closest('.ff-diamond[data-ff-action="toggleBit"]');
      if(diamond&&event.shiftKey&&event.button===0&&!diamond.disabled){this.beginDiamondPaint(event,diamond);return;}
      const bit=event.target.closest('[data-ff-bit-station]');
      if(bit&&!bit.disabled&&event.button===0){this.beginBitDrag(event,bit);return;}
      if(event.target.matches('input[type="range"]'))this.dragging=true;
    },{signal});
    root.addEventListener('lostpointercapture',event=>{if(this.diamondPaint?.pointer===event.pointerId)this.endDiamondPaint(event);if(this.bitDrag?.pointer===event.pointerId)this.cancelBitDrag();},{signal});
    content.ownerDocument.addEventListener('pointermove',event=>{if(this.diamondPaint)this.moveDiamondPaint(event);else this.moveBitDrag(event);},{signal});
    const release=()=>{this.dragging=false;if(this.pendingRender&&!this.editing)this.scheduleRender();};
    content.ownerDocument.addEventListener('pointerup',event=>{if(this.diamondPaint){this.endDiamondPaint(event);return;}if(this.bitDrag){void this.endBitDrag(event);return;}release();},{signal});
    content.ownerDocument.addEventListener('pointercancel',event=>{this.endDiamondPaint(event);if(this.bitDrag){if(this.bitDrag.pointer===event.pointerId)this.cancelBitDrag();return;}this.editing=false;release();this.scheduleRender();},{signal});
    root.addEventListener('input',event=>{
      const input=event.target;if(!input.matches('input'))return;
      if(input.dataset.ffBitCount!==undefined){this.editing=true;this.queueBitCount(Number(input.value),root.dataset.ffToken);return;}
      if(input.dataset.ffSearch!==undefined){this.search=input.value;this.applySearch();clearTimeout(this.searchTimer);this.searchTimer=null;this.searchTimer=setTimeout(()=>{this.searchTimer=null;this.scheduleRender();},160);return;}
      if(input.dataset.ffTheme!==undefined){this.editing=true;return;}
      if(input.dataset.ffNumeric){const range=[...root.querySelectorAll('[data-ff-field]')].find(el=>el.dataset.ffField===input.dataset.ffNumeric);if(range&&input.value!==''&&input.checkValidity())range.value=input.value;}
      if(input.type==='range'){for(const n of root.querySelectorAll('[data-ff-numeric]'))if(n.dataset.ffNumeric===input.dataset.ffField)n.value=input.value;}
      if(input.dataset.ffLookName!==undefined){this.lookName=input.value;this.editing=true;this.showMessage('Name the look, then choose Save current look');return;}
      this.editing=true;this.showMessage(input.type==='range'?'Adjusting · release to save':'Editing · leave this field to save');
      const key=input.dataset.ffField;
      for(const out of root.querySelectorAll('[data-ff-output]'))if(out.dataset.ffOutput===key)out.textContent=input.value;
    },{signal});
    root.addEventListener('change',event=>{
      this.editing=false;
      if(event.target.dataset.ffSearch!==undefined)return;
      if(event.target.dataset.ffBitSelect!==undefined){this.bitSelection=event.target.value;this.scheduleRender();return;}
      void this.field(event.target,root.dataset.ffToken).finally(()=>{this.pendingRender=false;this.scheduleRender();});
    },{signal});
    root.addEventListener('focusout',()=>{this.editing=false;if(this.pendingRender)this.scheduleRender();},{signal});
    root.addEventListener('keydown',event=>{
      if(event.key==='Escape'&&this.diamondPaint){event.preventDefault();event.stopPropagation();this.endDiamondPaint();return;}
      if(event.key==='Escape'&&this.bitDrag){event.preventDefault();event.stopPropagation();this.cancelBitDrag();return;}
      const bit=event.target.closest('[data-ff-bit-station]');
      if(bit&&!bit.disabled&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){
        event.preventDefault();event.stopPropagation();if(this.busy)return;
        this.bitSelection=bit.dataset.ffBitStation;
        const p=bitPosition(this.bitPlacementRequest(),this.bitSelection),step=event.shiftKey?.1:.01;
        const patch=bitPlacementPatch(this.bitSelection,p.x+(event.key==='ArrowRight'?step:event.key==='ArrowLeft'?-step:0),p.y+(event.key==='ArrowDown'?step:event.key==='ArrowUp'?-step:0));
        this.paintBitPosition(this.bitSelection,{x:patch[`${this.bitSelection}X`],y:patch[`${this.bitSelection}Y`]});
        void this.saveBitPlacement(patch,root.dataset.ffToken).catch(error=>this.fail(error));return;
      }
      if(event.key==='Escape'&&event.target.dataset.ffSearch!==undefined){event.preventDefault();event.stopPropagation();this.search='';event.target.value='';clearTimeout(this.searchTimer);this.searchTimer=null;this.applySearch();this.scheduleRender();return;}
      const tab=event.target.closest('[data-ff-tab]');
      if(tab&&['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){
        event.preventDefault();const tabs=[...root.querySelectorAll('[data-ff-tab]')].map(node=>node.dataset.ffTab),index=tabs.indexOf(tab.dataset.ffTab);
        const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(event.key==='ArrowRight'?1:tabs.length-1))%tabs.length,key=tabs[next];
        void this.tab(key).then(()=>{if(this.prefs.tab===key)this.domScope()?.querySelector(`[data-ff-tab="${key}"]`)?.focus({preventScroll:true});}).catch(e=>this.fail(e));return;
      }
      if(event.key==='Escape'&&event.target.matches('input,select')){
        event.preventDefault();event.stopPropagation();this.editing=false;this.dragging=false;
        if(event.target.dataset.ffLookName!==undefined)this.lookName='';
        this.showMessage('Unsaved edit cancelled');void this.redraw(true).catch(error=>this.fail(error));
      }
    },{signal});
    this.applySearch();
  }
  bindShortcutHints(root,signal){
    const hint=root.querySelector('[data-ff-shortcut-hint]');if(!hint)return;
    let hovered=null;
    const eligible=node=>{const button=node?.closest?.('[data-ff-action]');return button&&!button.disabled&&['flightToggle','toggleLightMode','toggleSummonFormation'].includes(button.dataset.ffAction)?button:null;};
    const refresh=()=>{
      const control=eligible(root.ownerDocument.activeElement)??hovered;
      const action=control?.dataset.ffAction;
      const copy=action==='toggleLightMode'?(control.getAttribute('aria-pressed')==='true'?'Shift-click while turning light off: keep bits deployed.':'Shift-click while turning light on: select lantern light.'):
        action==='toggleSummonFormation'?'Click: random formation on summon. Shift-click: automatic formation flow. Both modes can be used together.':
        action==='flightToggle'&&/Land/.test(control.textContent)?'Shift-click Land: keep bits deployed.':'';
      hint.textContent=copy;hint.hidden=!copy;
      for(const button of root.querySelectorAll('[data-ff-shortcut-describedby]')){const previous=button.dataset.ffShortcutDescription;if(previous)button.setAttribute('aria-describedby',previous);else button.removeAttribute('aria-describedby');delete button.dataset.ffShortcutDescribedby;delete button.dataset.ffShortcutDescription;}
      if(copy&&control){const previous=control.getAttribute('aria-describedby');control.dataset.ffShortcutDescription=previous??'';control.setAttribute('aria-describedby',[previous,'ff-shortcut-hint'].filter(Boolean).join(' '));control.dataset.ffShortcutDescribedby='true';}
    };
    root.addEventListener('pointerover',event=>{const control=eligible(event.target);if(control){hovered=control;refresh();}},{signal});
    root.addEventListener('pointerout',event=>{if(hovered&&!hovered.contains(event.relatedTarget)){hovered=null;refresh();}},{signal});
    root.addEventListener('focusin',refresh,{signal});
    root.addEventListener('focusout',()=>queueMicrotask(()=>{if(root.isConnected)refresh();}),{signal});
  }
  prepareAdvanced(){
    const root=this.root;
    for(const summary of root.querySelectorAll('[data-ff-section] > summary')){
      const route=hudSettingsRoute(summary.parentElement.dataset.ffSection.replace(/^group:/,''));if(!route)continue;const id=route.id;
      const button=root.ownerDocument.createElement('button');button.type='button';button.className='ff-pin-setting';button.dataset.ffAction='pinSetting';button.dataset.ffValue=id;button.dataset.ffKey=`pin-setting-${id}`;button.setAttribute('aria-pressed',String(this.prefs.favorites.includes(id)));button.setAttribute('aria-label',`${this.prefs.favorites.includes(id)?'Unpin':'Pin'} ${summary.querySelector('strong,span')?.textContent?.trim()??id}`);button.title='Pin a shortcut to the main panel';button.textContent=this.prefs.favorites.includes(id)?'★':'☆';summary.append(button);
    }
  }
  pinControlShortcuts(){
    const root=this.root;
    for(const slider of root.querySelectorAll('.ff-slider')) {
      const field=slider.querySelector('[data-ff-field]'),label=slider.querySelector('.ff-slider-label label');if(!field||!label)continue;
      const id=`control:${field.dataset.ffField}`,button=root.ownerDocument.createElement('button');button.type='button';button.className='ff-pin-setting ff-pin-control';button.dataset.ffAction='pinSetting';button.dataset.ffValue=id;button.dataset.ffKey=`pin-${id}`;button.setAttribute('aria-label',`${this.prefs.favorites.includes(id)?'Unpin':'Pin'} ${label.textContent}`);button.setAttribute('aria-pressed',String(this.prefs.favorites.includes(id)));button.title='Pin a shortcut to this exact control';button.textContent=this.prefs.favorites.includes(id)?'★':'☆';slider.querySelector('.ff-slider-label').append(button);
      for(const shortcut of root.querySelectorAll('.ff-favourites [data-ff-value]'))if(shortcut.dataset.ffValue===id){shortcut.textContent=label.textContent;shortcut.title=`Open ${label.textContent}`;}
    }
  }
  applySearch(){
    const root=this.root;if(!root)return;const result=filterHUDSettings(root,this.search,this.prefs);
    const count=root.querySelector('[data-ff-search-count]');if(count)count.textContent=this.search.trim()?result.controls?`${result.controls} matching ${result.controls===1?'control':'controls'} · ${result.groups} ${result.groups===1?'section':'sections'} · unrelated settings hidden`:'No matching settings. Try glow, hover, sound, light or quality.':this.prefs.settingsLevel==='simple'?'Everyday choices. Advanced holds detailed tuning.':'All detailed controls remain available here.';
  }
  applySettingsFocus() {
    const focus=this.settingsFocus,body=this.domScope()?.querySelector('[data-ff-settings-focus]');if(!focus||!body)return;
    const controlKey=focus.id.startsWith('control:')?focus.id.slice(8):null;
    const control=controlKey?[...body.querySelectorAll('[data-ff-field]')].find(el=>el.dataset.ffField===controlKey):null;
    const target=control?.closest('.ff-slider,.ff-select-row,.ff-number,.ff-check')??[...body.querySelectorAll('[data-ff-section]')].find(el=>el.dataset.ffSection===focus.id);
    if(target){body.replaceChildren(target);target.classList.add('ff-focus-target');if(target.tagName==='DETAILS')target.open=true;}
    else if(controlKey){const notice=body.ownerDocument.createElement('p');notice.className='ff-note';notice.textContent='This control is currently inactive. Its related settings are shown below; your saved value is preserved.';body.prepend(notice);}
  }
  captureMenuMotion() {
    const root=this.root,contexts=new Map();
    for(const element of root?.querySelectorAll('[data-ff-motion]')??[])contexts.set(element.dataset.ffMotion,{element,rect:element.getBoundingClientRect(),context:element.dataset.ffContext,frame:this.motion.active.has(element)?this.motion.sample(element):null});
    const trace=root?.querySelector('[data-ff-tab-trace]');
    return {contexts,page:root?.dataset.ffPage,trace:trace?.getBoundingClientRect?.()??null,headerThread:root?.querySelector('[data-ff-header] .ff-header-thread')?.getBoundingClientRect?.()??null};
  }
  restoreMenuMotion(previous) {
    const root=this.root;if(!root)return;
    const navigation=this.navigationMotion;this.navigationMotion=null;
    const nodes=[...root.querySelectorAll('[data-ff-motion]')];
    const pageChanged=previous.page!==this.prefs.tab||navigation?.scope==='page';
    let animatedParent=null;
    if(previous.page==null){void this.motion.enter(root,{kind:'settings'});animatedParent=root;}
    for(const node of nodes){
      if(animatedParent?.contains(node))continue;
      const name=node.dataset.ffMotion,before=previous.contexts.get(name);
      const changed=before?.context!==node.dataset.ffContext;
      if(name==='page'?!pageChanged&&!before?.frame:pageChanged||(!changed&&!before?.frame))continue;
      const kind=name==='page'?(navigation?.kind??this.prefs.tab):name==='bit-group'?'group':name==='wing-editor'?'library':name==='quick-effects'?'disclosure':'page';
      const direction=navigation?.direction??(this.groupDirection==='previous'?-1:1);
      if(before?.element&&(changed||pageChanged)&&!node.hidden&&before.element.dataset.ffContext?.endsWith(':closed')!==true){
        const host=this.root;if(host?.style&&!host.style.position)host.style.position='relative';
        void this.motion.swipe(node,before.element,{direction,outgoingFrame:before.frame??undefined,host});
      }else void this.motion.enter(node,{kind,direction,from:before?.frame??undefined});
      animatedParent=node;
    }
    this.groupDirection=null;
    const thread=root.querySelector('[data-ff-header] .ff-header-thread');
    if(thread&&previous.headerThread&&navigation){const bounds=thread.getBoundingClientRect();void this.motion.animate(thread,[{transform:`translateX(${previous.headerThread.left-bounds.left}px) scaleX(${previous.headerThread.width/Math.max(1,bounds.width)})`,opacity:.45},{transform:'none',opacity:1}],{duration:240});}
    const trace=root.querySelector('[data-ff-tab-trace]'),active=root.querySelector('[data-ff-tab][aria-selected="true"]');
    if(trace&&active){
      const tab=active.getBoundingClientRect(),nav=trace.parentElement.getBoundingClientRect(),width=Math.max(4,tab.width-16),left=tab.left-nav.left+8;
      trace.style.width=`${width}px`;trace.style.left=`${left}px`;
      if(previous.trace&&pageChanged)void this.motion.animate(trace,[{transform:`translateX(${previous.trace.left-(nav.left+left)}px) scaleX(${previous.trace.width/width})`},{transform:'none'}],{duration:220});
    }
  }
  async navigatePreferences(patch,motion) {
    const epoch=++this.navigationEpoch;this.navigationMotion=motion;
    // Preferences update locally before storage. A slow settings write must not
    // delay menu navigation or let an earlier completion steal focus.
    const saved=this.savePreferences(patch);await this.redraw(true);await saved;
    return this.opened&&epoch===this.navigationEpoch;
  }
  navigationSnapshot() {
    const tab=this.prefs.tab,labels={home:'Home',flight:'Flight',bits:'Bits',effects:'Effects',settings:'Settings'};
    return {tab,homePanel:this.prefs.homePanel,homePanelOpen:this.prefs.homePanelOpen,settingsLevel:this.prefs.settingsLevel,bitGroup:this.bitGroup,scroll:this.domScope()?.querySelector('.ff-scroll')?.scrollTop??0,focus:this.settingsFocus,search:this.search,focusKey:this.root?.ownerDocument?.activeElement?.dataset?.ffKey??null,label:this.settingsFocus?.title??labels[tab]??'Home'};
  }
  async openAdvanced(id=''){
    const route=hudSettingsRoute(id);if(!route)return this.allSettings();
    if(this.prefs.tab!=='settings'||this.settingsFocus?.id!==route.id)this.settingsHistory.push(this.navigationSnapshot());
    this.settingsHistory=this.settingsHistory.slice(-12);this.settingsFocus=route;this.search='';this.scrollTop=0;this.editing=false;this.dragging=false;
    this.animationPicker?.close();this.picker?.close();this.audioPicker?.close();this.stopAudioPreview();
    const disclosurePatch={};
    if(route.group==='audio'&&route.id.startsWith('control:audio:')){
      const [kind,id]=route.id.slice('control:audio:'.length).split(':'),needed=[];
      if(kind==='slots'&&AUDIO_SLOTS[id])needed.push(`category:${AUDIO_SLOTS[id].category}`,`slot:${id}`);
      else if(kind==='categories'&&AUDIO_CATEGORIES[id])needed.push(`category:${id}`);
      else if(['crossfadeMs','movementSensitivity','cooldownMs'].includes(kind))needed.push('advanced');
      if(needed.length)disclosurePatch.audioOpen=[...new Set([...needed,...this.prefs.audioOpen])];
    }
    if(await this.navigatePreferences({advancedOpen:true,advancedGroup:route.group,settingsLevel:route.level,tab:'settings',...disclosurePatch},{scope:'page',kind:'settings'}))this.domScope()?.querySelector('[data-ff-action="settingsBack"]')?.focus({preventScroll:true});
  }
  async allSettings() {
    if(this.settingsFocus)this.settingsHistory.push(this.navigationSnapshot());
    this.settingsFocus=null;this.search='';this.scrollTop=0;this.editing=false;this.dragging=false;
    await this.navigatePreferences({tab:'settings',advancedOpen:true},{scope:'page',kind:'settings'});
  }
  async settingsBack() {
    const previous=this.settingsHistory.pop();if(!previous){await this.tab('home');return;}
    this.settingsFocus=previous.focus;this.bitGroup=previous.bitGroup;this.search=previous.search;this.scrollTop=previous.scroll;this.editing=false;this.dragging=false;
    this.audioPicker?.close();this.stopAudioPreview();this.animationPicker?.close();this.picker?.close();
    if(await this.navigatePreferences({tab:previous.tab,homePanel:previous.homePanel??this.prefs.homePanel,homePanelOpen:previous.homePanelOpen??this.prefs.homePanelOpen,settingsLevel:previous.settingsLevel??this.prefs.settingsLevel,advancedOpen:previous.tab==='settings'},{scope:'page',kind:'back',direction:-1})){
      const focus=[...this.domScope()?.querySelectorAll('[data-ff-key]')??[]].find(el=>el.dataset.ffKey===previous.focusKey);focus?.focus({preventScroll:true});
    }
  }
  async selectBitGroup(value,directionOverride) {
    const groups=hudBitGroups(this.model()),next=groups.findIndex(g=>g.id===value);if(next<0)return;
    const old=groups.findIndex(g=>g.id===this.bitGroup),direction=directionOverride??(next>=old?1:-1);this.groupDirection=direction>0?'next':'previous';this.bitGroup=value;
    if(this.prefs.tab==='home'&&this.prefs.homePanel==='bits'||this.prefs.tab==='settings'){this.animationPicker?.close();this.navigationMotion={scope:this.prefs.tab==='home'?'home-panel':'group',kind:'group',direction};await this.redraw(true);}
    else await this.tab('bits');
  }
  pauseHeaderMotion() {
    const paused=!!(this.root?.ownerDocument?.hidden||this.app?.minimized||!this.opened);
    if(this.root)this.root.dataset.ffPaused=String(paused);
    this.portrait?.setPaused(paused);
  }
  setDispatchSelection(ids) {
    const selected=[...new Set(ids)].filter(id=>Object.hasOwn(BIT_STATIONS,id));
    for(const id of Object.keys(BIT_STATIONS))if(this.dispatchSelectedBits.includes(id)!==selected.includes(id))
      this.dispatchSelectionVersions.set(id,(this.dispatchSelectionVersions.get(id)??0)+1);
    this.dispatchSelectedBits=selected;
  }
  clearSentSelection(sent,owner,epoch,versions) {
    // A completed send only consumes the selection that started it. New owner
    // selections and diamonds reselected while awaiting a write stay intact.
    if(!this.opened||this.epoch!==epoch||this.model().token?.document.uuid!==owner)return false;
    this.setDispatchSelection(this.dispatchSelectedBits.filter(id=>!sent.includes(id)||(this.dispatchSelectionVersions.get(id)??0)!==versions.get(id)));
    this.refreshTargeting();return true;
  }
  beginDiamondPaint(event,button) {
    if(this.busy||!this.opened)return;
    const model=this.model(),id=button.dataset.ffValue;
    if(!model.token||model.token.document.uuid!==this.root.dataset.ffToken||!Object.hasOwn(BIT_STATIONS,id))return;
    event.preventDefault();button.focus({preventScroll:true});
    this.dragging=true;this.suppressDiamondClick=true;
    this.diamondPaint={pointer:event.pointerId,target:this.root.dataset.ffToken,button,select:!this.dispatchSelectedBits.includes(id),visited:new Set()};
    try{button.setPointerCapture?.(event.pointerId);}catch{}
    this.paintDiamond(id);
  }
  paintDiamond(id) {
    const drag=this.diamondPaint;if(!drag||drag.visited.has(id)||!Object.hasOwn(BIT_STATIONS,id))return;
    drag.visited.add(id);
    this.setDispatchSelection(drag.select?[...this.dispatchSelectedBits,id]:this.dispatchSelectedBits.filter(bit=>bit!==id));
    this.refreshTargeting();this.lastSignature=this.signature(this.model());
  }
  moveDiamondPaint(event) {
    const drag=this.diamondPaint;if(!drag||event.pointerId!==drag.pointer)return;
    if(!event.shiftKey||drag.target!==this.root?.dataset.ffToken){this.endDiamondPaint(event);return;}
    event.preventDefault();
    const hovered=this.root.ownerDocument.elementFromPoint?.(event.clientX,event.clientY)?.closest?.('.ff-diamond[data-ff-action="toggleBit"]');
    if(hovered&&!hovered.disabled&&this.root.contains(hovered))this.paintDiamond(hovered.dataset.ffValue);
  }
  endDiamondPaint(event) {
    const drag=this.diamondPaint;if(!drag||event&&event.pointerId!==undefined&&event.pointerId!==drag.pointer)return;
    this.diamondPaint=null;this.dragging=false;
    try{drag.button.releasePointerCapture?.(drag.pointer);}catch{}
    if(this.pendingRender&&!this.editing)this.scheduleRender();
  }
  beginBitDrag(event,button) {
    if(this.busy||!this.opened||this.bitDrag)return;
    const model=this.model(),station=button.dataset.ffBitStation;
    if(!model.token||model.token.document.uuid!==this.root.dataset.ffToken||!Object.hasOwn(BIT_STATIONS,station))return;
    event.preventDefault();button.focus({preventScroll:true});
    const map=button.closest('[data-ff-bit-map]'),start=bitPosition(this.bitPlacementRequest(model),station),box=map?.getBoundingClientRect();
    if(!box?.width||!box.height)return;
    // Percentage positioning is relative to the map's inner box, excluding
    // its border; account for HUD/window CSS scaling in pointer coordinates.
    const rect={width:box.width*(map.clientWidth??box.width)/(map.offsetWidth??box.width),height:box.height*(map.clientHeight??box.height)/(map.offsetHeight??box.height)};
    if(!rect.width||!rect.height)return;
    this.bitSelection=station;this.dragging=true;
    this.bitDrag={station,start,position:start,pointer:event.pointerId,clientX:event.clientX,clientY:event.clientY,rect,target:this.root.dataset.ffToken,button,moved:false};
    try{button.setPointerCapture?.(event.pointerId);}catch{}
    this.paintBitPosition(station,start);
    this.showMessage('Positioning bit · release to save · Escape cancels');
  }
  paintBitPosition(station,p) {
    const mapped=bitMapPercent(p);
    for(const button of this.domScope()?.querySelectorAll('[data-ff-bit-station]')??[]){const active=button.dataset.ffBitStation===station;button.classList.toggle('is-selected',active);button.setAttribute('aria-pressed',String(active));if(active){button.style.left=`${mapped.x}%`;button.style.top=`${mapped.y}%`;}}
    const selector=this.domScope()?.querySelector('[data-ff-bit-select]');if(selector)selector.value=station;
    for(const input of this.domScope()?.querySelectorAll('[data-ff-bit-axis]')??[]){const axis=input.dataset.ffBitAxis,key=station+axis.toUpperCase();input.value=p[axis];input.dataset.ffField=`gemMotion:${key}`;input.setAttribute('aria-label',`${BIT_STATIONS[station].label} ${axis.toUpperCase()} position`);}
    for(const button of this.domScope()?.querySelectorAll('[data-ff-action="resetBitPosition"],[data-ff-action="mirrorBitPosition"]')??[])button.dataset.ffValue=station;
  }
  moveBitDrag(event) {
    const drag=this.bitDrag;if(!drag||event.pointerId!==drag.pointer)return;
    if(!Number.isFinite(event.clientX)||!Number.isFinite(event.clientY))return;
    const dx=event.clientX-drag.clientX,dy=event.clientY-drag.clientY;
    if(!drag.moved&&Math.hypot(dx,dy)<3)return;
    drag.moved=true;
    const patch=bitPlacementPatch(drag.station,drag.start.x+dx/drag.rect.width*BIT_PLACEMENT_MAP.width,drag.start.y+dy/drag.rect.height*BIT_PLACEMENT_MAP.height);
    drag.position={x:patch[`${drag.station}X`],y:patch[`${drag.station}Y`]};this.paintBitPosition(drag.station,drag.position);
  }
  async endBitDrag(event) {
    const drag=this.bitDrag;if(!drag||event.pointerId!==drag.pointer)return;
    // A browser may coalesce the last movement into pointerup, including a
    // release beyond the map. Save that final location, not the previous move.
    this.moveBitDrag(event);
    this.bitDrag=null;this.dragging=false;this.editing=false;
    try {drag.button.releasePointerCapture?.(event.pointerId);}catch{}
    if(!drag.moved){this.showMessage('Bit selected · drag or use arrow keys to position');this.scheduleRender();return;}
    try {await this.saveBitPlacement(bitPlacementPatch(drag.station,drag.position.x,drag.position.y),drag.target);}
    catch(error){this.fail(error);this.scheduleRender();}
  }
  cancelBitDrag({render=true}={}) {
    const drag=this.bitDrag;if(!drag)return false;
    this.bitDrag=null;this.dragging=false;this.editing=false;
    try{drag.button.releasePointerCapture?.(drag.pointer);}catch{}
    if(this.root?.dataset.ffToken===drag.target)this.paintBitPosition(drag.station,drag.start);
    if(render){this.showMessage('Bit move cancelled');this.scheduleRender();}
    return true;
  }
  bitPlacementRequest(model=this.model()) {
    return Object.assign({},model.state?.requested?.gemMotion,...this.bitPlacementEdits.filter(edit=>edit.target===model.token?.document.uuid).map(edit=>edit.patch));
  }
  async saveBitPlacement(patch,target) {
    const model=this.model(),token=model.token;
    if(!this.opened||!token||token.document.uuid!==target)throw new Error('The selected token changed. Position the bit again for the token now shown.');
    const edit={target,patch:{...patch}};this.bitPlacementEdits.push(edit);this.bitPlacementRevision++;
    this.showMessage('Saving bit position…');
    // Keep accepting placements while the document write is pending. Each
    // patch has its own captured token; the optimistic overlay prevents a
    // rerender or the next drag from jumping back to an older saved position.
    const result=this.bitPlacementQueue.catch(()=>{}).then(()=>hudCommand(this.api(),token,'gemMotion',edit.patch,{...this.prefs}));
    this.bitPlacementQueue=result.catch(()=>{});
    try{await result;}
    finally {
      this.bitPlacementEdits=this.bitPlacementEdits.filter(pending=>pending!==edit);this.bitPlacementRevision++;this.modelCache=null;
      if(this.opened)this.scheduleRender();
    }
    if(this.opened&&!this.busy&&this.model().token?.document.uuid===target&&!this.bitPlacementEdits.some(pending=>pending.target===target)&&!this.bitDrag)this.showMessage('Bit position saved');
  }
  isCurrentTab(tab) {
    // A focused settings route still has somewhere to go when Settings is
    // selected. Every other active top-level tab is already at its destination.
    return HUD_TABS.includes(tab)&&tab===this.prefs.tab&&!(tab==='settings'&&this.settingsFocus);
  }
  async tab(tab) {
    // prefs changes before the async storage write, so this also absorbs a
    // repeated click while the first navigation is still rendering or saving.
    if(this.isCurrentTab(tab))return;
    this.toolUI.suspend();
    if(HUD_TABS.includes(tab)||tab==='flight'||tab==='bits')this.portrait?.cue({type:'tab',tab});
    if(tab==='flight'||tab==='bits'){await this.navigatePreferences({tab:'home',homePanel:tab,homePanelOpen:true},{scope:'page',kind:'home'});return;}
    if(!HUD_TABS.includes(tab))return;
    const order=HUD_TABS,direction=order.indexOf(tab)>=order.indexOf(this.prefs.tab)?1:-1;
    this.settingsFocus=null;this.settingsHistory=[];this.search='';
    this.tabScroll[this.prefs.tab]=this.domScope()?.querySelector('.ff-scroll')?.scrollTop??0;
    this.scrollTop=this.tabScroll[tab]??0;this.editing=false;this.dragging=false;
    this.animationPicker?.close();this.picker?.close();this.audioPicker?.close();this.stopCompactPreview();this.stopAudioPreview();
    await this.navigatePreferences({tab,advancedOpen:tab==='settings'},{scope:'page',kind:tab,direction});
  }
  async pin(uuid) {
    const token=eligibleTokens().find(t=>t.document.uuid===uuid);
    if(!token)throw new Error('Select a token you own in this scene.');
    const actorId=pinnedCharacterActorId(token);
    if(!actorId)throw new Error('This token has no character actor to pin.');
    if(uuid!==this.targetId){this.toolUI.suspend();this.setDispatchSelection([]);this.bitGroup='home';this.bitAliases.clear();this.settingsFocus=null;this.settingsHistory=[];this.diamondStates=null;this.audioPicker?.close();this.stopAudioPreview();this.closeAudioFilePicker();}
    await this.savePreferences({followSelection:false,pinnedActor:actorId,pinnedToken:uuid});this.targetId=uuid;
    await this.redraw(true);
  }
  openAnimationPicker(kind,model,{selectedId=null}={}) {
    this.stopCompactPreview();this.animationPicker?.close();this.picker?.close();this.audioPicker?.close();
    if(kind==='condition'){const key=model.state?.effective?.condition??'normal';this.picker=new EffectPicker(this,'condition',key,model);}
    else this.animationPicker=new GeneralAnimationPicker(this,kind,model,{group:this.bitGroup,selectedId});
  }
  async click(action,value,expectedTarget) {
    this.portrait?.cue({type:'command',action});
    try {
      if(action==='retryPreferences'){
        if(this.preferenceRetrying)return;this.preferenceRetrying=true;
        const button=this.domScope()?.querySelector('[data-ff-action="retryPreferences"]');if(button)button.disabled=true;
        try{if(await this.savePreferences({})){this.showMessage('HUD choices saved · this browser');await this.redraw(true);}}
        finally{this.preferenceRetrying=false;if(button?.isConnected)button.disabled=false;}
        return;
      }
      if(action==='bitTools'){this.toolUI.openTools(this.domScope()?.querySelector('[data-ff-action="bitTools"]'));return;}
      if(action==='quickLight'){this.toolUI.openLight(this.domScope()?.querySelector('[data-ff-action="quickLight"]'));return;}
      if(action==='undoBitCommand'){await this.toolUI.undo();return;}
      if(action==='homePanel'||action==='cycleHomePanel'){
        const panels=hudHomePanels(this.model()),current=this.prefs.homePanel==='bits'?`group:${this.bitGroup}`:'flight',index=Math.max(0,panels.findIndex(panel=>panel.id===current));
        const step=value==='previous'?-1:1,next=action==='cycleHomePanel'?panels[(index+step+panels.length)%panels.length]:panels.find(panel=>panel.id===(value==='bits'?`group:${this.bitGroup}`:value));
        if(!next)return;
        const direction=action==='cycleHomePanel'?step:panels.indexOf(next)>=index?1:-1;
        if(next.group)this.bitGroup=next.group;
        await this.navigatePreferences({homePanel:next.group?'bits':'flight',homePanelOpen:true},{scope:'home-panel',kind:'group',direction});return;
      }
      if(action==='toggleHomePanel'){
        const open=!this.prefs.homePanelOpen,region=this.domScope()?.querySelector('[data-ff-motion="home-panel"]'),height=region?.getBoundingClientRect().height??0,epoch=++this.navigationEpoch;
        const saved=this.savePreferences({homePanelOpen:open});
        const toggle=this.domScope()?.querySelector('[data-ff-action="toggleHomePanel"]');toggle?.setAttribute('aria-expanded',String(open));
        if(!open){await this.motion.fold(region,false);if(epoch===this.navigationEpoch)await this.redraw(true);}
        else {await this.redraw(true);if(epoch===this.navigationEpoch)await this.motion.fold(this.domScope()?.querySelector('[data-ff-motion="home-panel"]'),true,{fromHeight:height});}
        await saved;return;
      }
      if(action==='settingsLevel'){
        if(!['simple','advanced'].includes(value))return;
        this.settingsFocus=null;this.search='';this.scrollTop=0;
        await this.navigatePreferences({settingsLevel:value},{scope:'page',kind:'settings',direction:value==='advanced'?1:-1});return;
      }
      if(action==='toggleDispatchBit'){
        if(!Object.hasOwn(BIT_STATIONS,value))return;
        const model=this.model();if(!model.token||model.token.document.uuid!==expectedTarget)return;
        this.setDispatchSelection(this.dispatchSelectedBits.includes(value)?this.dispatchSelectedBits.filter(id=>id!==value):[...this.dispatchSelectedBits,value]);
        this.refreshTargeting();this.lastSignature=this.signature(this.model());return;
      }
      if(action==='clearDispatchSelection'){this.setDispatchSelection([]);this.refreshTargeting();this.lastSignature=this.signature(this.model());return;}
      if(action==='dispatchSelectedBits'){
        if(this.busy)return;
        const model=this.model(),summary=model.dispatchSummary;
        if(!summary.valid)throw new Error(summary.reason);
        const sent=[...summary.selectedIds],epoch=this.epoch,owner=model.token.document.uuid;
        const versions=new Map(sent.map(id=>[id,this.dispatchSelectionVersions.get(id)??0]));
        this.toolUI.begin('dispatch',{bits:sent,target:summary.destination,onCommit:()=>{
          if(this.clearSentSelection(sent,owner,epoch,versions))this.showMessage(`${sent.length} selected ${sent.length===1?'bit':'bits'} sent to ${summary.targetLabel}`);
        }});
        return;
      }
      if(action==='toggleQuickEffects'){
        await this.navigatePreferences({quickEffectsOpen:!this.prefs.quickEffectsOpen},{scope:'quick-effects',kind:'disclosure'});return;
      }
      if(action==='toggleBitsAdvanced')action='toggleBits';
      if(action==='toggleSummonFormation'){
        if(await this.run(action,value,expectedTarget)===false)return;
        const model=this.model(),home=model.bitTasks?.homeGroup??hudBitGroups(model).find(g=>g.id==='home')??{};
        const on=value==='flow'?home.flow?.enabled===true:model.bitTasks?.randomOnSummon===true;
        this.showMessage(value==='flow'?`Automatic formation flow ${on?'on':'off'} · nearby bits`:`Random formation on summon ${on?'on':'off'}`);return;
      }
      if((action==='toggleBits'||action==='gatherBits')&&this.dispatchSelectedBits.length){
        const model=this.model(),command=hudBitCommandState(model),remote=action==='gatherBits';
        const ids=remote?command.selectedRemote:command.selectedOut.length?command.selectedOut:command.selected;
        if(!ids.length){this.showMessage('The selected bits are already with their owner or retracted.');return;}
        const retract=!remote&&command.selectedOut.length>0;
        if(await this.run('selectedBits',{bits:[...ids],retract,only:remote?'remote':retract?'out':'retracted'},expectedTarget)===false)return;
        this.showMessage(`${ids.length} selected ${ids.length===1?'bit':'bits'} ${retract?'returning to retract':remote?'returning to their owner':'summoning'}`);return;
      }
      if(action==='compactPreview'){
        const model=this.model(),canvas=this.domScope()?.querySelector(`[data-ff-compact-canvas="${value}"]`);
        if(!canvas||!compactAnimationChoices(model.state?.bitCount?.count??4,formationOptions(model)).some(v=>v.id===value)||model.token?.document.uuid!==expectedTarget)return;
        const already=!canvas.hidden;this.stopCompactPreview();if(already)return;
        canvas.hidden=false;const r=model.state?.requested?.gemMotion??{},cfg=previewQualityConfiguration(model.cfg);
        this.compactPreviewStop=startCompactPreview(canvas,{count:model.state?.bitCount?.count??r.count??4,program:value,radius:r.soloRadius??1,strength:r.strength??model.cfg.gemMotionStrength??.75,speed:r.speed??model.cfg.gemAnimationSpeed??1,personality:r.personality??.35,reduced:cfg.reduced,v7:model.state?.v7,v9:model.state?.v9,quality:cfg.bitQuality,fps:cfg.rigFPS});
        this.showMessage(model.cfg.reduced?'Static movement guide · Reduced motion is active':'Six-second movement guide · this HUD only');this.lastSignature=this.signature(this.model());return;
      }
      if(action==='performanceStart'||action==='performanceStop'||action==='performanceReset'){
        const perf=this.api().performance;if(!perf)throw new Error('Performance diagnostics are unavailable. Reload Foundry after updating the module.');
        this.performanceOwned=true;
        if(action==='performanceStart'){perf.start({duration:10000});this.showMessage('Capturing this browser for 10 seconds · move the token as usual');}
        else if(action==='performanceStop'){perf.stop();this.showMessage('Performance capture stopped · results are local to this browser');}
        else {perf.reset();this.showMessage('All visual components restored · diagnostic cleared');}
        await this.redraw(true);return;
      }
      if(action==='openAdvanced'){await this.openAdvanced(value);return;}
      if(action==='closeAdvanced'||action==='settingsBack'){await this.settingsBack();return;}
      if(action==='allSettings'){await this.allSettings();return;}
      if(action==='clearSearch'){this.search='';clearTimeout(this.searchTimer);this.searchTimer=null;const input=this.domScope().querySelector('[data-ff-search]');if(input){input.value='';input.focus();}this.applySearch();this.scheduleRender();return;}
      if(action==='pinAnimation'){
        const [kind,id]=value.split(':');const allowed=kind==='bits'?compactAnimationChoices(4,formationOptions(this.model())).map(v=>v.id):kind==='tokenFX'?TOKEN_EFFECT_PROGRAMS.map(v=>v.id):[];
        if(!allowed.includes(id))throw new Error('Unknown animation favourite.');
        const current=this.prefs.animationFavorites[kind],favorites=current.includes(id)?current.filter(v=>v!==id):[...current,id].slice(-8);
        const saved=await this.savePreferences({animationFavorites:{...this.prefs.animationFavorites,[kind]:favorites}});if(saved)this.showMessage(current.includes(id)?'Animation removed from favourites':'Animation pinned for quick selection');await this.redraw(true);return saved;
      }
      if(action==='applyAnimationFavorite'){
        if(this.busy)return;
        const [kind,id]=value.split(':'),model=this.model();
        if(!model.token||model.token.document.uuid!==expectedTarget)throw new Error('Choose the animation again for the token now shown.');
        if(!this.prefs.animationFavorites[kind]?.includes(id))throw new Error('This animation is no longer pinned.');
        if(kind==='bits'){
          if(!compactAnimationChoices(4,formationOptions(model)).some(v=>v.id===id))throw new Error('This formation is disabled for this character.');
        }
        else if(kind!=='tokenFX'||!TOKEN_EFFECT_PROGRAMS.some(entry=>entry.id===id))throw new Error('Unknown animation favourite.');
        this.openAnimationPicker(kind,model,{selectedId:id});
        return;
      }
      if(action==='lanternAim'){
        const token=this.model().token;
        if(await this.run('lanternAim',undefined,expectedTarget)===false)return;
        const aiming=!!this.api().isLanternAiming?.(token);this.lanternAimToken=aiming?token:null;
        this.showMessage(aiming?'Lantern follows the mouse · click Hold direction to finish':'Lantern direction held');this.scheduleRender();return;
      }
      if(action==='v7ResetField'){await this.run('v7',{[value]:null},expectedTarget);return;}
      if(action==='bitGesture'){await this.run('bitGesture',{group:this.bitGroup,name:value},expectedTarget);return;}
      if(action==='cancelGesture'){await this.run('cancelGesture',value,expectedTarget);return;}
      if(action==='resetGroupMovement'){
        await this.run('bitGroup',{group:this.bitGroup,patch:{radius:1,personality:.35,passive:true,behaviour:{enabled:true,frequency:'attentive',energy:.5,audio:false},flow:{enabled:false,pool:[],hold:30000,duration:2600}}},expectedTarget);return;
      }
      if(action==='resetGroupCore'){
        await this.run('bitGroup',{group:this.bitGroup,patch:{internalState:'idle'}},expectedTarget);return;
      }
      if(action==='pinSetting'){const favorites=this.prefs.favorites.includes(value)?this.prefs.favorites.filter(id=>id!==value):[...this.prefs.favorites,value].slice(-12);await this.savePreferences({favorites});await this.redraw(true);return;}
      if(action==='resetTheme'){await this.savePreferences({theme:HUD_THEME_DEFAULTS});await this.redraw(true);return;}
      if(action==='gotoTab'){await this.tab(value);return;}
      if(action==='selectBitGroup'||action==='groupEffects'){
        await this.selectBitGroup(value);if(action==='groupEffects')this.domScope()?.querySelector('.ff-token-effect-section')?.scrollIntoView({block:'nearest'});return;
      }
      if(action==='cycleBitGroup'){
        const groups=hudBitGroups(this.model()),index=groups.findIndex(g=>g.id===this.bitGroup),step=value==='previous'?-1:1;
        const target=groups[(index+step+groups.length)%groups.length];if(target)await this.selectBitGroup(target.id,step);return;
      }
      if(action==='resetConditionReactions'){await this.run('resetConditionReactions',undefined,expectedTarget);return;}
      if(action==='previewAnimation'){
        if(this.busy)return;const model=this.model();
        if(!model.token||model.token.document.uuid!==expectedTarget)throw new Error('Choose the preview again for the token now shown.');
        this.openAnimationPicker(value,model);return;
      }
      if(action==='recallGroup'){
        const group=hudBitGroups(this.model()).find(g=>g.id===value);if(!group?.bits?.length)return;
        await this.run('recallGroup',{bits:group.bits,retract:false},expectedTarget);return;
      }
      if(action==='toggleGroupEffect'){
        const group=hudBitGroups(this.model()).find(g=>g.id===value);if(!group)return;
        await this.run('bitEffect',{group:value,patch:{id:group.effect?.id??TOKEN_EFFECT_PROGRAMS[0].id,enabled:!group.effect?.enabled,strength:group.effect?.strength??.6}},expectedTarget);return;
      }
      if(action==='attachBits'){value=(this.model().state?.requested.gemMotion?.placement??this.model().cfg.gemPlacement??'free')!=='follow';}
      if(action==='resetCueTiming'){if(await this.savePreferences({pulseDurationMs:null,stutterDurationMs:null}))this.showMessage('Default cue timing restored');await this.redraw(true);return;}
      if(action==='resetBitPositions'){await this.run('gemMotion',Object.fromEntries(Object.keys(BIT_POSITION_FIELDS).map(k=>[k,null])),expectedTarget);return;}
      if(action==='resetBitPosition'||action==='mirrorBitPosition'){
        if(!Object.hasOwn(BIT_STATIONS,value))throw new Error('Unknown bit position.');
        const patch=action==='resetBitPosition'?{[`${value}X`]:null,[`${value}Y`]:null}:mirrorBitPatch(this.model().state?.requested.gemMotion,value);
        await this.run('gemMotion',patch,expectedTarget);return;
      }
      if(['copyLook','pasteLook','applyBuiltinLook','applySavedLook','undoLook','saveLook','deleteLook'].includes(action)){await this.lookAction(action,value,expectedTarget);return;}
      if(action==='audioStop'){this.stopAudioPreview();this.showMessage('Private preview stopped');return;}
      if(action==='audioPreview'){await this.previewAudio(value,expectedTarget);return;}
      if(action==='audioBrowse'){await this.browseAudio(value,expectedTarget);return;}
      if(action==='audioPick'){
        if(this.busy)return;
        const model=this.model();
        if(!this.opened||!this.prefs.advancedOpen||!model.audio||!model.token||model.token.document.uuid!==expectedTarget)
          throw new Error('The selected token changed. Open the sound selector again for the token now shown.');
        this.animationPicker?.close();this.picker?.close();this.audioPicker?.close();this.stopAudioPreview();this.closeAudioFilePicker();
        this.audioPicker=new AudioPicker(this,value,model);return;
      }
      if(action==='audioClaimLocal'){await this.run('audio',{audience:'local'},expectedTarget);return;}
      if(action==='audioResetSlot'||action==='audioResetCategory'){
        const slots=action==='audioResetSlot';
        if(!Object.hasOwn(slots?AUDIO_SLOTS:AUDIO_CATEGORIES,value))throw new Error('Unknown audio option.');
        this.stopAudioPreview();await this.run('audio',{[slots?'slots':'categories']:{[value]:null}},expectedTarget);return;
      }
      if(action==='pickEffect'){
        if(this.busy)return;
        const model=this.model();
        if(!this.opened||!model.state||!model.token||model.token.document.uuid!==expectedTarget)
          throw new Error('The selected token changed. Open the selector again for the token now shown.');
        const [group,key]=value.split(':');
        this.animationPicker?.close();this.audioPicker?.close();this.picker?.close();this.picker=new EffectPicker(this,group,key,model);return;
      }
      if(action==='pin') {
        if(this.prefs.followSelection)await this.pin(expectedTarget);
        else {await this.savePreferences({followSelection:true,pinnedActor:null,pinnedToken:null});await this.redraw(true);}
        return;
      }
      if(action==='displayPreset'){
        const preset=DISPLAY_PRESETS[value];if(!preset)throw new Error('Unknown display preset.');
        if(this.busy)return;this.busy=true;this.showMessage('Applying display preset…');
        try{for(const [key,setting] of Object.entries(preset.settings))await game.settings.set(ID,key,setting);this.showMessage(`${preset.label} · this browser`);}
        finally{this.busy=false;if(this.opened)await this.redraw(true);}return;
      }
      if(action==='resetFloat'){action='resetAppearance';value=['floatStyle','floatSpeed','floatSway','hoverHeight','bobHeight','tiltDegrees','modeIdleStrength'];}
      if(action==='settings'){await game.settings.sheet.render({force:true});return;}
      if(action==='autoGlitch'){action='glitchIntensity';value=null;}
      else if(action==='autoTrail'){action='trailIntensity';value=null;}
      else if(action==='lightDefault'){action='lightEnabled';value=null;}
      else if(action==='autoLightIntensity'){action='lightIntensity';value=null;}
      else if(action==='autoLightRadii'){action='lightRadii';value={bright:null,dim:null};}
      else if(action==='resetEffectStyles'){action='effectStyles';value=Object.fromEntries(CONDITION_IDS.map(k=>[k,null]));}
      else if(action==='resetReactionStyles'){action='reactionStyles';value=Object.fromEntries(REACTION_IDS.map(k=>[k,null]));}
      else if(action==='resetEffectTuning'){
        const [group,key]=value.split(':');action=group==='reaction'?'reactionTuning':'effectTuning';value={[key]:null};
      }
      else if(action==='resetOption'){action='resetAppearance';value=[value];}
      else if(action==='resetPoseMotion'){action='poseMotion';value=Object.fromEntries(Object.keys(POSE_MOTION_FIELDS).map(k=>[k,null]));}
      else if(action==='resetGemMotion'){action='gemMotion';value=Object.fromEntries(Object.keys(GEM_MOTION_FIELDS).map(k=>[k,null]));}
      else if(action==='gemDesign'){action='gemMotion';value={design:value==='default'?null:value};}
      else if(action==='resetGemFeature'){action='gemMotion';if(!Object.hasOwn(GEM_MOTION_FIELDS,value))throw new Error('Unknown stabilizer control.');value={[value]:null};}
      else if(action==='resetAppearance'&&!Array.isArray(value))value=undefined;
      await this.run(action,value,expectedTarget);
    }catch(e){this.fail(e);return false;}
  }
  async field(input,expectedTarget) {
    try {
      const d=input.dataset;
      if(d.ffV8ToolPref){const key=d.ffV8ToolPref;if(!['weightedTravel','obstacleRoutes','workingPosture'].includes(key))throw new Error('Unknown instrument movement preference.');const model=this.model(),token=model.token;if(!token||token.document.uuid!==expectedTarget)throw new Error('The selected token changed.');await this.api().setBitToolPreferences(token,{[key]:input.value==='default'?null:input.value==='on'});this.showMessage('Instrument preference saved for this token');return;}
      if(d.ffV7Field||d.ffV7Strength){
        if(input.checkValidity&&!input.checkValidity()){input.reportValidity?.();return;}
        const key=d.ffV7Field??d.ffV7Strength;
        const value=d.ffV7Strength?Number(input.value):input.value==='inherit'?null:input.value==='on'?true:input.value==='off'?false:input.value;
        await this.run('v7',{[key]:value},expectedTarget);return;
      }
      if(d.ffSearch!==undefined)return;
      if(d.ffConditionReaction){
        if(input.checkValidity&&!input.checkValidity()){input.reportValidity?.();return;}
        const parts=d.ffConditionReaction.split(':'),value=input.type==='checkbox'?input.checked:input.type==='number'?Number(input.value):input.value;
        const patch=parts[0]==='conditions'?{conditions:{[parts[1]]:{[parts[2]]:value}}}:{[parts[0]]:value};
        await this.run('conditionReactions',patch,expectedTarget);return;
      }
      if(d.ffQuickPin){
        const pins=this.prefs.quickEffects;if(input.checked&&!pins.includes(d.ffQuickPin)&&pins.length>=3){input.checked=false;this.showMessage('Choose up to three Home effects. Unpin one first.');return;}
        if(await this.savePreferences({quickEffects:input.checked?[...pins,d.ffQuickPin]:pins.filter(k=>k!==d.ffQuickPin)}))this.showMessage('Home quick effects saved');return;
      }
      if(d.ffExpressionMode){await this.run('gemMotion',{expressionModes:{[d.ffExpressionMode]:input.value==='default'?null:input.value}},expectedTarget);return;}
      if(d.ffSummonRandom){await this.run('summonFormation',{random:input.checked},expectedTarget);return;}
      if(d.ffBehaviourField||d.ffFlowField||d.ffFlowProgram){
        const model=this.model(),allowed=compactAnimationChoices(4,formationOptions(model)).map(v=>v.id),group=hudBitGroups(model).find(g=>g.id===d.ffGroupId);if(!group)throw new Error('This bit group is no longer available.');
        let patch;
        if(d.ffBehaviourField){const key=d.ffBehaviourField,value=input.type==='checkbox'?input.checked:key==='energy'?Number(input.value):input.value;patch={behaviour:{[key]:value}};}
        else if(d.ffFlowProgram){
          if(!allowed.includes(d.ffFlowProgram))throw new Error('This formation is disabled for this character.');
          const pool=[...(group.flow?.pool??[])].filter(id=>id!==d.ffFlowProgram);if(input.checked)pool.push(d.ffFlowProgram);patch={flow:{pool,...(pool.filter(id=>allowed.includes(id)).length<2?{enabled:false}:{})}};
        }
        else{const key=d.ffFlowField,value=input.type==='checkbox'?input.checked:Number(input.value)*1000;patch={flow:{[key]:value}};
          if(key==='enabled'&&value&&(group.flow?.pool??[]).filter(id=>allowed.includes(id)).length<2)patch.flow.pool=[...new Set([...(group.flow?.pool??[]),allowed.includes(group.program)?group.program:'orbit','curiousCompanions','quietExchange','attentiveEscort','livingWorkshop'])];}
        await this.run('bitGroup',{group:d.ffGroupId,patch},expectedTarget);return;
      }
      if(d.ffGroupField){
        const key=d.ffGroupField,number=['radius','personality'].includes(key),value=input.type==='checkbox'?input.checked:number?Number(input.value):input.value;
        if(!['program','radius','personality','passive','internalState'].includes(key))throw new Error('Unknown bit group setting.');
        if(key==='program'&&!compactAnimationChoices(4,formationOptions(this.model())).some(v=>v.id===value))throw new Error('This formation is disabled for this character.');
        await this.run('bitGroup',{group:d.ffGroupId,patch:{[key]:value}},expectedTarget);return;
      }
      if(d.ffEffectField){
        const key=d.ffEffectField;if(!['id','strength'].includes(key))throw new Error('Unknown token effect setting.');
        await this.run('bitEffect',{group:d.ffGroupId,patch:{[key]:key==='strength'?Number(input.value):input.value}},expectedTarget);return;
      }
      if(d.ffBitCount!==undefined){this.queueBitCount(Number(input.value),expectedTarget,true);return;}
      if(d.ffQuality){
        const scope=d.ffQuality,key=d.ffQualityField;
        if(!['local','observer'].includes(scope)||!['preset','wingDetail','bitDetail','effectDetail','textureFPS','transitionFPS','trails','treatment'].includes(key))throw new Error('Unknown quality control.');
        if(input.checkValidity&&!input.checkValidity()){input.reportValidity?.();return;}
        const model=this.model(),api=this.api(),current=scope==='local'?model.localQuality:model.state?.observerQuality??model.state?.requested?.observerQuality??{};
        const number=['textureFPS','transitionFPS'].includes(key),value=input.value==='default'||input.value.trim()===''?null:number?Number(input.value):input.value;
        const patch=key==='preset'?{preset:value,wingDetail:null,bitDetail:null,effectDetail:null,textureFPS:null,transitionFPS:null,trails:null,treatment:null}:{...qualityValues(current),preset:'custom',[key]:value};
        if(scope==='observer')await this.run('observerQuality',patch,expectedTarget);
        else {if(!api.setLocalQuality)throw new Error('Quality controls require a scene reload after updating.');await api.setLocalQuality(patch);this.showMessage('My view quality saved · this browser only');}
        return;
      }
      if(d.ffPerformance){
        if(!['wings','bits','fields','trails','treatment'].includes(d.ffPerformance))throw new Error('Unknown diagnostic component.');
        const perf=this.api().performance;if(!perf)throw new Error('Performance diagnostics are unavailable.');
        this.performanceOwned=true;perf.setComponents({[d.ffPerformance]:input.checked});this.showMessage('Diagnostic visibility changed · this browser only; temporary isolation expires automatically');return;
      }
      if(d.ffTheme){const key=d.ffTheme;if(!Object.hasOwn(HUD_THEME_DEFAULTS,key))throw new Error('Unknown HUD appearance setting.');if(input.checkValidity&&!input.checkValidity()){input.reportValidity?.();return;}const value=input.type==='checkbox'?input.checked:input.type==='number'?Number(input.value):input.value;if(await this.savePreferences({theme:{...this.prefs.theme,[key]:value}}))this.showMessage('HUD appearance saved · this browser');return;}
      if(d.ffNumeric){if(!input.checkValidity()||input.value.trim()===''){input.reportValidity?.();return;}const range=[...(input.closest?.('[data-ks-classic]')??this.root).querySelectorAll('[data-ff-field]')].find(el=>el.dataset.ffField===d.ffNumeric);if(range){range.value=input.value;await this.field(range,expectedTarget);}return;}
      if(d.ffCommand){if(!['mode','pose','condition','wingState','compactProgram','floatStyle'].includes(d.ffCommand))throw new Error('Unknown main control.');if(input.checkValidity&&!input.checkValidity()){input.reportValidity?.();return;}await this.run(d.ffCommand,input.value,expectedTarget);return;}
      if(d.ffLookName!==undefined){this.lookName=input.value.slice(0,40);return;}
      if(input.checkValidity&&!input.checkValidity()){this.showMessage(input.validationMessage||'Enter a valid value before saving.',true);input.reportValidity?.();return;}
      if(d.ffTarget!==undefined){
        if(input.value)await this.pin(input.value);
        else {await this.savePreferences({followSelection:false,pinnedActor:null,pinnedToken:null});this.targetId=null;await this.redraw(true);}
        return;
      }
      if(d.ffPref) {
        if(!PREF_KEYS.includes(d.ffPref))throw new Error('Unknown HUD preference.');
        const value=input.type==='checkbox'?input.checked:input.value===''?null:Number(input.value)*1000;
        if(d.ffPref==='holdMs'&&value===null){this.showMessage('Enter a temporary duration.',true);return;}
        if(await this.savePreferences({[d.ffPref]:value}))this.showMessage('HUD preference saved');return;
      }
      if(d.ffLocal) {
        if(!LOCAL_KEYS.includes(d.ffLocal))throw new Error('Unknown browser preference.');
        if(SETTINGS[d.ffLocal].type===Number&&input.value.trim()===''){this.showMessage('Enter a value before saving.',true);return;}
        const value=input.type==='checkbox'?input.checked:SETTINGS[d.ffLocal].type===Number?Number(input.value):input.value;
        if(SETTINGS[d.ffLocal].type===Number&&(!Number.isFinite(value)||value<SETTINGS[d.ffLocal].range.min||value>SETTINGS[d.ffLocal].range.max))throw new Error('Invalid browser preference.');
        if(SETTINGS[d.ffLocal].type===String&&!Object.hasOwn(SETTINGS[d.ffLocal].choices,value))throw new Error('Invalid browser preference.');
        await game.settings.set(ID,d.ffLocal,value);this.showMessage('Browser preference saved');return;
      }
      if(d.ffAudio){this.stopAudioPreview();await this.run('audio',audioFieldPatch(d.ffAudio,input),expectedTarget);return;}
      if(d.ffStyle) {
        if(!CONDITION_IDS.includes(d.ffStyle))throw new Error('Unknown condition appearance control.');
        await this.run('effectStyles',{[d.ffStyle]:input.value==='default'?null:input.value},expectedTarget);return;
      }
      if(d.ffReaction){
        if(!REACTION_IDS.includes(d.ffReaction))throw new Error('Unknown reaction control.');
        await this.run('reactionStyles',{[d.ffReaction]:input.value==='default'?null:input.value},expectedTarget);return;
      }
      if(!d.ffField)return;
      if(d.ffScope==='lantern') {
        const key=d.ffField.split(':').at(-1);
        if(!['width','bright','dim','intensity','beam','angle','edgeStyle','edgeSoftness','groundStyle'].includes(key))throw new Error('Unknown bit lantern control.');
        if(input.value.trim()==='')throw new Error('Enter a lantern value before saving.');
        await this.run('lantern',{[key]:['edgeStyle','groundStyle'].includes(key)?input.value:Number(input.value)},expectedTarget);return;
      }
      if(['poseMotion','gemMotion'].includes(d.ffScope)) {
        const key=d.ffField.split(':').at(-1),rules=d.ffScope==='poseMotion'?POSE_MOTION_FIELDS:GEM_MOTION_FIELDS,rule=rules[key];
        if(!rule)throw new Error('Unknown wing motion control.');
        const value=input.type==='checkbox'?input.checked:input.value==='default'||input.value.trim()===''?null:
          rule==='boolean'?({on:true,off:false}[input.value]):typeof rule[0]==='string'?input.value:Number(input.value)*(d.ffSeconds?1000:1);
        if(Object.hasOwn(BIT_POSITION_FIELDS,key)){await this.saveBitPlacement({[key]:value,placement:'free'},expectedTarget);return;}
        await this.run(d.ffScope,{[key]:value},expectedTarget);return;
      }
      if(['effectTuning','reactionTuning'].includes(d.ffScope)){
        const [key,field]=d.ffField.split(':');
        await this.run(d.ffScope,{[key]:{[field]:Number(input.value)}},expectedTarget);return;
      }
      if(input.type==='number'&&input.value.trim()===''&&!['lightBright','lightDim'].includes(d.ffField)){this.showMessage('Enter a value before saving.',true);return;}
      const value=['effectStyle','lightAppearance','lanternArtwork'].includes(d.ffField)?(input.value==='default'?null:input.value):
        ['lightBright','lightDim'].includes(d.ffField)&&input.value.trim()===''?null:
        input.type==='checkbox'?input.checked:['autoHP','movementReactions','lightVisualReactions'].includes(d.ffField)?
        ({default:null,on:true,off:false}[input.value]):Number(input.value);
      if(d.ffScope==='pref') {
        if(d.ffField!=='effectStrength')throw new Error('Unknown cue preference.');
        if(await this.savePreferences({effectStrength:value}))this.showMessage('Cue strength saved');return;
      }
      if(d.ffScope==='appearance'){
        if(d.ffField==='floatStyle'&&!Object.hasOwn(FLOAT_STYLES,input.value))throw new Error('Unknown float animation.');
        await this.run('appearance',{[d.ffField]:d.ffField==='floatStyle'?input.value:value},expectedTarget);
      }
      else {
        if(!STATE_KEYS.includes(d.ffField))throw new Error('Unknown token control.');
        await this.run(d.ffField,value,expectedTarget);
      }
    }catch(e){this.fail(e);}
  }
  async lookAction(action,value,expectedTarget) {
    if(!this.opened)throw new Error('Open the HUD before using its controls.');
    if(this.busy){this.showMessage('Still applying…');return;}
    const api=this.api(),token=this.model().token;
    if(action!=='deleteLook'&&(!token||token.document.uuid!==expectedTarget))
      throw new Error('The selected token changed. Choose the look action again for the token now shown.');
    this.busy=true;this.editing=false;this.showMessage(action==='copyLook'?'Copying look…':'Applying…');
    this.root?.setAttribute('aria-busy','true');
    for(const el of this.domScope()?.querySelectorAll('[data-ff-write]')??[])el.disabled=true;
    try {
      if(action==='copyLook') {
        this.lookClipboard={name:token.document.name??token.name??'Token',look:api.captureLook(token)};
        this.showMessage(`Copied ${this.lookClipboard.name} · select another owned token to paste`);
      } else if(action==='saveLook') {
        const name=this.lookName.trim();if(!name)throw new Error('Give the personal look a name before saving it.');
        await api.saveLook(name,api.captureLook(token));this.lookName='';this.showMessage(`Saved personal look: ${name}`);
      } else if(action==='deleteLook') {
        const saved=api.getSavedLooks().find(p=>p.id===value);if(!saved)throw new Error('This saved look no longer exists.');
        await api.deleteLook(value);this.showMessage(`Removed personal look: ${saved.name}`);
      } else if(action==='undoLook') {
        if(this.lookUndo?.target!==expectedTarget)throw new Error('There is no look change to undo on this token.');
        try {await api.undoLook(token,this.lookUndo.undo);this.showMessage('Previous look restored');}
        finally {this.lookUndo=null;}
      } else {
        let look,label;
        if(action==='pasteLook') {
          if(!this.lookClipboard)throw new Error('Copy a look from an owned token first.');
          look=this.lookClipboard.look;label=`Pasted look from ${this.lookClipboard.name}`;
        } else {
          const preset=(action==='applyBuiltinLook'?api.getLookPresets():api.getSavedLooks()).find(p=>p.id===value);
          if(!preset)throw new Error('This look no longer exists.');
          look=action==='applyBuiltinLook'?preset.id:preset.look;label=`Applied ${preset.name}`;
        }
        const result=await api.applyLook(token,look);
        this.lookUndo=result?.undo?{target:expectedTarget,undo:result.undo}:null;
        this.showMessage(`${label}${this.lookUndo?' · Undo is available':''}`);
      }
    } finally {this.busy=false;if(this.opened)await this.redraw(true);}
  }
  stopAudioPreview() {
    this.audioPreviewEpoch=(this.audioPreviewEpoch??0)+1;this.audioPreviewTarget=null;
    try {Promise.resolve(this.api().stopAudioPreview?.()).catch(()=>{});}catch{}
  }
  closeAudioFilePicker() {
    const picker=this.audioFilePicker;this.audioFilePicker=null;
    try {Promise.resolve(picker?.close()).catch(()=>{});}catch{}
  }
  async previewAudio(slot,expectedTarget) {
    if(this.busy)return;
    if(!Object.hasOwn(AUDIO_SLOTS,slot))throw new Error('Unknown audio sound.');
    const token=this.model().token;
    if(!this.opened||!this.prefs.advancedOpen||!token||token.document.uuid!==expectedTarget)
      throw new Error('The selected token changed. Play the sound again for the token now shown.');
    this.stopAudioPreview();this.audioPreviewTarget=expectedTarget;
    const epoch=this.audioPreviewEpoch;
    this.showMessage(`Loading private preview: ${AUDIO_SLOTS[slot].label}…`);
    try {
      await this.api().previewAudio(token,slot);
      if(epoch!==this.audioPreviewEpoch)return;
      if(!this.opened||!this.prefs.advancedOpen||this.model().token?.document.uuid!==expectedTarget){this.stopAudioPreview();return;}
      this.showMessage(`Private preview: ${AUDIO_SLOTS[slot].label}`);
    }catch(error){if(epoch===this.audioPreviewEpoch)throw error;}
  }
  async browseAudio(slot,expectedTarget) {
    if(this.busy)return;
    const m=this.model();
    if(!this.opened||!this.prefs.advancedOpen||m.token?.document.uuid!==expectedTarget||!Object.hasOwn(AUDIO_SLOTS,slot))
      throw new Error('The selected token changed. Browse again for the token now shown.');
    const FilePicker=globalThis.foundry?.applications?.apps?.FilePicker?.implementation;
    if(!FilePicker)throw new Error('The audio file browser is unavailable. Paste the audio path instead.');
    this.closeAudioFilePicker();
    const epoch=this.epoch;
    const picker=new FilePicker({type:'audio',current:m.audio?.requested?.slots?.[slot]?.src??'',callback:path=>{
      if(this.audioFilePicker!==picker||!this.opened||epoch!==this.epoch||!this.prefs.advancedOpen||this.model().token?.document.uuid!==expectedTarget)return;
      void this.run('audio',{slots:{[slot]:{preset:'custom',src:path}}},expectedTarget).catch(error=>this.fail(error));
    }});
    this.audioFilePicker=picker;
    await picker.browse();
    if(this.audioFilePicker!==picker||!this.opened||!this.prefs.advancedOpen){await picker.close();return;}
    if(!picker.rendered)await picker.render({force:true});
  }
  stopCompactPreview() {
    this.compactPreviewStop?.();this.compactPreviewStop=null;for(const canvas of this.domScope()?.querySelectorAll('[data-ff-compact-canvas]')??[])canvas.hidden=true;
  }
  queueBitCount(count,target,immediate=false) {
    if(!Number.isInteger(count)||count<1||count>4)return;
    const label=`${count} ${count===1?'bit':'bits'}`;
    for(const el of this.domScope()?.querySelectorAll('[data-ff-bit-count-label]')??[])el.textContent=label;
    this.domScope()?.querySelector('[data-ff-bit-count]')?.setAttribute('aria-valuetext',label);
    this.pendingBitCount={count,target};clearTimeout(this.bitCountTimer);
    this.bitCountTimer=setTimeout(()=>{this.bitCountTimer=null;void this.flushBitCount();},immediate?0:90);
  }
  async flushBitCount() {
    if(!this.opened){this.pendingBitCount=null;return;}
    if(this.bitCountSaving)return;
    if(this.busy){clearTimeout(this.bitCountTimer);this.bitCountTimer=setTimeout(()=>{this.bitCountTimer=null;void this.flushBitCount();},90);return;}
    this.bitCountSaving=true;
    try {
      while(this.pendingBitCount&&this.opened) {
        const request=this.pendingBitCount;this.pendingBitCount=null;
        const model=this.model(),token=model.token;
        if(!token||token.document.uuid!==request.target)throw new Error('The selected token changed. Adjust the bit count again for the token now shown.');
        const homeCount=model.bitTasks?.allocations?.filter(b=>b.location==='home').length??0;
        const currentCount=homeCount||model.bitTasks?.preferredCount||model.state?.bitCount?.count||4;
        if(currentCount!==request.count){
          const api=this.api();if(api.bits?.setDeployment)await api.bits.setDeployment(token,{count:request.count});
          else if(api.setBitCount)await api.setBitCount(token,request.count);
          else throw new Error('Bit count controls require a scene reload after updating.');
        }
        if(this.opened&&this.model().token?.document.uuid===request.target)this.showMessage(`${request.count} ${request.count===1?'bit':'bits'} selected · formation adapts automatically`);
      }
    }catch(error){this.pendingBitCount=null;this.fail(error);}
    finally{this.bitCountSaving=false;if(this.opened)this.scheduleRender();}
  }
  async run(action,value,expectedTarget) {
    if(!this.opened)throw new Error('Open the HUD before using its controls.');
    if(this.busy){this.showMessage('Still applying…');return false;}
    const token=this.model().token;
    if(!token||token.document.uuid!==expectedTarget)
      throw new Error('The selected token changed. Adjust the control again for the token now shown.');
    this.busy=true;
    this.showMessage('Applying…');this.root?.setAttribute('aria-busy','true');
    for(const el of this.domScope()?.querySelectorAll('[data-ff-write]')??[])el.disabled=true;
    try {
      if(this.bitPlacementEdits.length)await this.bitPlacementQueue;
      await hudCommand(this.api(),token,action,value,{...this.prefs});
      this.showMessage(action==='refresh'?'Visuals refreshed on this browser':action==='gatherBits'?'Remote bits are returning to Ellie':action==='toggleBits'?'Bit deployment updated':'Saved');
    }catch(e){this.showMessage(String(e?.message??e),true);throw e;}
    finally{this.busy=false;if(this.opened)await this.redraw(true);}
  }
  /** Where this HUD's controls live: the Keepsake shadow root. */
  domScope(){return this.root?.shadowRoot??this.root;}
  locateBits(active,token=null,ids=null){this.toolUI.locate(active,token,ids);}
}

/** Class creation is deferred until a macro opens the HUD; canvas startup is unchanged.
 * The classic panel window was retired in v10 beta.21: the HUD is always Keepsake. */
export function createHUDApplication(controller,options){return createKeepsakeApplication(controller,options);}
