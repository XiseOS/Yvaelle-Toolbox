import {localPerformance} from './performance.mjs?v=12.1.0-beta.1';
import {lightAppearanceFragment,lightAppearanceUniforms,LIGHT_APPEARANCE_UNIFORMS} from './light-appearance-shaders.mjs?v=12.1.0-beta.1';
import {lanternVeilAssets,lanternVeilFragment,lanternVeilUniforms,LANTERN_VEIL_UNIFORMS,LANTERN_VEIL_COMMON_UNIFORMS} from './lantern-veil.mjs?v=12.1.0-beta.1';
import {createLanternFlowMotion,stepLanternFlowMotion,lanternFlowFragment,lanternFlowUniforms,LANTERN_FLOW_UNIFORMS,LANTERN_FLOW_COMMON_UNIFORMS} from './lantern-flow.mjs?v=12.1.0-beta.1';
import {lightUniformLayoutChanged,setLightShaderProgram,markLightShaderUniformsDirty,invalidateLightUniformLayout,lightShaderLayers,setLightUniform,setLightUniformVector,noteLightUniformChange} from './light-shader-binding.mjs?v=12.1.0-beta.1';
import {v7RefractionFragment,setV7RefractionUniforms,releaseV7RefractionUniforms,V7_REFRACTION_UNIFORMS} from './v7-light-refraction.mjs?v=12.1.0-beta.1';

/** Decorate only the supplied native lantern source. Foundry retains its
 * polygon, walls, level, visibility and layer composition; no extra filter,
 * source or geometry is created here. Authored veil artwork shares one
 * optional cached sampler on the native coloration layer. */
// The previous optical cycle takes about 52 seconds. Every phase multiplier in
// the fragment is an integer so wrapping the clock cannot jump the pattern.
const TAU=Math.PI*2,PHASE_SPEED=.12,PERIOD=TAU/PHASE_SPEED;
const PREFIX='ffLantern';
const WASH_UNIFORM='ffLanternWashExponent';
const CLASSIC_UNIFORMS=['ffLanternDirection','ffLanternHalfAngle','ffLanternFullCircle','ffLanternStrength','ffLanternFeather','ffLanternPhase','ffLanternTransition','ffLanternShutdown'];
const SOFT_UNIFORMS=[...CLASSIC_UNIFORMS,'ffLanternEdgeSoftness'];
const APPEARANCE_UNIFORMS=[...CLASSIC_UNIFORMS,...LIGHT_APPEARANCE_UNIFORMS];
const SOFT_APPEARANCE_UNIFORMS=[...SOFT_UNIFORMS,...LIGHT_APPEARANCE_UNIFORMS];
const finite=(value,fallback)=>Number.isFinite(value)?value:fallback;
const clamp=(value,min=0,max=1)=>Math.min(max,Math.max(min,value));
const modulo=(value,period)=>(value%period+period)%period;
const sourceCode=source=>source.replace(/^\s*#define\s+SHADER_NAME[^\r\n]*(?:\r?\n|$)/gm,'');
const uncomment=source=>source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,part=>part.replace(/[^\n]/g,' '));

/** A lantern source has already prepared the identical values for all three
 * native layers. Retain each shader's independent direction vector and repair
 * external/native edits without recomputing direction and scalar bounds. */
function setPreparedLightAppearanceUniforms(shader,values,record){
  record.appearanceDirection??=new Float32Array(2);
  const direction=record.appearanceDirection,oldX=direction[0],oldY=direction[1];
  direction[0]=values.ffLightDirection[0];direction[1]=values.ffLightDirection[1];
  if(oldX!==direction[0]||oldY!==direction[1])noteLightUniformChange(shader);
  for(const name of LIGHT_APPEARANCE_UNIFORMS){
    if(!record.uniforms.has(name))record.uniforms.set(name,{exists:Object.hasOwn(shader.uniforms,name),value:shader.uniforms[name]});
    setLightUniform(shader,name,name==='ffLightDirection'?direction:values[name]);
  }
}

export function lanternShaderOptions(options={}){
  const angle=modulo(finite(options.angle,0),360)*Math.PI/180,width=clamp(finite(options.width,65),1,360);
  const airborneWash=options.airborneWash===true,washWidth=clamp(finite(options.washWidth,width),15,180),washFwhm=clamp(washWidth+(180-washWidth)*.35,55,150)*Math.PI/180;
  const beam=clamp(finite(options.beam,1)),ramp=clamp(beam/.12);
  // Real lifecycle channels survive an interrupted on/off/re-on unchanged at
  // the command boundary. Let the material withdraw with that same envelope;
  // an instant boolean switch used to change the front's brightness mid-frame.
  const withdrawal=clamp((finite(options.body,0)-finite(options.beamWeight,0))*2),
    shutdown=Number.isFinite(options.body)&&Number.isFinite(options.beamWeight)?withdrawal*withdrawal*(3-2*withdrawal):options.shuttingDown===true?1:0;
  return {angle,width,halfAngle:width*Math.PI/360,fullCircle:width>=359.999?1:0,
    strength:beam*clamp(finite(options.intensity,1))*clamp(finite(options.weight,1)),feather:ramp*ramp*(3-2*ramp),
    phase:options.reduced?0:modulo(finite(options.clock,0),PERIOD)*PHASE_SPEED,
    // Assembly is a one-way front, not a repeating flash. Its shared progress
    // comes from the same envelope that controls native reach and brightness.
    // Reduced motion keeps the envelope but removes the travelling detail.
    transition:options.reduced?1:clamp(finite(options.transition,1)),
    shutdown:options.reduced?0:shutdown,
    localEffects:options.localEffects!==false,
    airborneWash,
    washExponent:airborneWash?Math.log(.5)/Math.log(Math.cos(washFwhm/2)):1,
    appearanceEffects:options.appearanceEffects??null,
    artwork:['flow','veil','plain','prior'].includes(options.artwork)?options.artwork:'prior',
    edgeStyle:options.edgeStyle==='classic'?'classic':'soft',edgeSoftness:clamp(finite(options.edgeSoftness,.65))};
}

/** A compatibility guard, not a general GLSL transformer. Only a single
 * straight-line native output using the native depth channel is supported.
 * Multiplying depth BEFORE that output preserves illumination/background
 * mixing; multiplying an already composed RGB value would darken the map. */
export function lanternLightFragment(fragment,layer='coloration',edgeStyle='classic',appearance='current',artwork='prior',airborneWash=false,refraction=false){
  if(typeof fragment!=='string'||!['background','illumination','coloration'].includes(layer))return null;
  const inspected=uncomment(fragment);
  if(inspected.includes(PREFIX)||/^\s*#\s*define\s+(?:depth|gl_FragColor)\b/m.test(inspected)
    ||! /\bvarying\s+(?:(?:highp|mediump|lowp)\s+)?vec2\s+vUvs\s*;/.test(inspected))return null;
  const mains=[...inspected.matchAll(/\bvoid\s+main\s*\(\s*(?:void\s*)?\)\s*\{/g)];
  const outputs=[...inspected.matchAll(/\bgl_FragColor\s*=\s*([^;]+);/g)];
  if(mains.length!==1||outputs.length!==1)return null;
  const main=mains[0],output=outputs[0],bodyStart=main.index+main[0].length;
  let depth=1,bodyEnd=bodyStart;
  for(;bodyEnd<inspected.length&&depth;bodyEnd++){
    if(inspected[bodyEnd]==='{')depth++;else if(inspected[bodyEnd]==='}')depth--;
  }
  if(depth||output.index<bodyStart||output.index>=bodyEnd||! /\bdepth\b/.test(output[1])
    ||! /\bfloat\s+depth\s*=/.test(inspected.slice(bodyStart,output.index)))return null;
  const soft=edgeStyle==='soft';
  const uniforms=`uniform vec2 ffLanternDirection;\nuniform float ffLanternHalfAngle;\nuniform float ffLanternFullCircle;\nuniform float ffLanternStrength;\nuniform float ffLanternFeather;\nuniform float ffLanternPhase;\nuniform float ffLanternTransition;\nuniform float ffLanternShutdown;\n`+(soft?'uniform float ffLanternEdgeSoftness;\n':'')+(airborneWash===true?'uniform float ffLanternWashExponent;\n':'');
  const commonShape=`
  vec2 ffLanternPoint=(vUvs-vec2(0.5))*2.0;
  float ffLanternRadius=length(ffLanternPoint);
  float ffLanternForward=dot(ffLanternPoint,ffLanternDirection);
  float ffLanternSide=dot(ffLanternPoint,vec2(-ffLanternDirection.y,ffLanternDirection.x));
  float ffLanternTurn=ffLanternRadius>0.00001?abs(atan(ffLanternSide,ffLanternForward)):0.0;
`;
  // Soft style applies the circular light's inward radial fade to both cone
  // axes. It changes native depth before composition, independently of the
  // optional magenta detail, and cannot extend light past walls or range.
  // Airborne stabilizers form a rounded directional wash instead of four
  // edged cones. Its continuous forward lobe reaches zero at the native
  // hemisphere boundary. It always shapes optical depth, independently of
  // cosmetic animation, without changing native range or wall visibility.
  const shaping=commonShape+(airborneWash===true?`  float ffLanternAngular=pow(max(0.0,cos(ffLanternTurn)),ffLanternWashExponent);
  `+(soft?`  float ffLanternRadial=1.0;
  if(ffLanternEdgeSoftness>0.0){
    float ffLanternSoftWidth=max(0.000001,ffLanternEdgeSoftness*0.5);
    ffLanternRadial=1.0-smoothstep(1.0-ffLanternSoftWidth,1.0,ffLanternRadius);
  }
  depth*=ffLanternAngular*ffLanternRadial;
  `:`  float ffLanternRadial=1.0-smoothstep(0.76,1.0,ffLanternRadius);
  depth*=ffLanternAngular*mix(1.0,ffLanternRadial,ffLanternFeather);
  `):(soft?`  if(ffLanternEdgeSoftness>0.0){
    float ffLanternSoftWidth=max(0.000001,ffLanternEdgeSoftness*0.5);
    float ffLanternAngular=1.0-smoothstep(ffLanternHalfAngle*(1.0-ffLanternSoftWidth),ffLanternHalfAngle,ffLanternTurn);
    ffLanternAngular=mix(ffLanternAngular,1.0,ffLanternFullCircle);
    float ffLanternRadial=1.0-smoothstep(1.0-ffLanternSoftWidth,1.0,ffLanternRadius);
    depth*=ffLanternAngular*ffLanternRadial;
  }
  `:`  float ffLanternFeatherWidth=min(0.16,ffLanternHalfAngle*0.22);
  float ffLanternAngular=1.0-smoothstep(max(0.0,ffLanternHalfAngle-ffLanternFeatherWidth),ffLanternHalfAngle,ffLanternTurn);
  ffLanternAngular=mix(ffLanternAngular,1.0,ffLanternFullCircle);
  float ffLanternRadial=1.0-smoothstep(0.76,1.0,ffLanternRadius);
  depth*=mix(1.0,ffLanternAngular*ffLanternRadial,ffLanternFeather);
  `));
  // Only coloration is tinted. The native illumination and background output
  // expressions are kept byte-for-byte so their computed scene mix survives.
  let finalOutput=fragment.slice(output.index,output.index+output[0].length);
  if(layer==='coloration'&&artwork==='prior')finalOutput=`vec4 ffLanternOutput=${fragment.slice(inspected.indexOf('=',output.index)+1,output.index+output[0].length-1)};
  float ffLanternAcross=ffLanternTurn/max(0.0087,ffLanternHalfAngle);
  float ffLanternFringe=smoothstep(0.35,0.90,ffLanternAcross)*(1.0-ffLanternFullCircle);
  float ffLanternDetail=ffLanternFeather*(0.35+0.65*ffLanternStrength);
  vec3 ffLanternTint=mix(vec3(1.0),vec3(1.0,0.08,1.0),(0.70+0.18*ffLanternFringe)*ffLanternDetail);
  float ffLanternSigned=ffLanternRadius>0.00001?atan(ffLanternSide,ffLanternForward)/max(0.0087,ffLanternHalfAngle):0.0;
  float ffLanternWander=0.035*sin(ffLanternRadius*5.0-ffLanternPhase)+0.012*sin(ffLanternRadius*9.0-ffLanternPhase*2.0);
  float ffLanternThreads=exp(-pow((ffLanternSigned+ffLanternWander)/0.045,2.0))
    +0.65*exp(-pow((ffLanternSigned-0.43+ffLanternWander*0.7)/0.036,2.0))
    +0.55*exp(-pow((ffLanternSigned+0.43-ffLanternWander*0.8)/0.040,2.0));
  ffLanternThreads*=smoothstep(0.08,0.24,ffLanternRadius)*(1.0-smoothstep(0.65,0.94,ffLanternRadius))*(1.0-ffLanternFullCircle);
  float ffLanternFlow=0.55+0.45*sin(ffLanternRadius*12.0-ffLanternPhase*2.0);
  float ffLanternBreath=1.0+0.04*sin(ffLanternPhase)*ffLanternDetail;
  // A broad soft rim travels along the native cone during build/retraction.
  // All detail multiplies the already clipped native output. It cannot create
  // light beyond that source's cone, wall polygon, or real visibility.
  float ffLanternAssembling=1.0-smoothstep(0.86,1.0,ffLanternTransition);
  float ffLanternFrontRadius=0.10+0.76*smoothstep(0.0,1.0,ffLanternTransition);
  float ffLanternFront=exp(-pow((ffLanternRadius-ffLanternFrontRadius)/0.105,2.0));
  ffLanternFront*=smoothstep(0.035,0.13,ffLanternRadius)*(1.0-smoothstep(0.82,0.98,ffLanternRadius));
  float ffLanternGather=exp(-pow(ffLanternSigned/0.18,2.0))*(1.0-ffLanternFullCircle);
  float ffLanternAssemblyDetail=ffLanternAssembling*ffLanternDetail;
  float ffLanternBuild=1.0+ffLanternAssemblyDetail*(ffLanternFront*(0.20-0.05*ffLanternShutdown)+ffLanternGather*0.10);
  ffLanternOutput.rgb=min(ffLanternOutput.rgb*ffLanternTint*ffLanternBreath*(1.0+ffLanternThreads*ffLanternFlow*0.20*ffLanternDetail)*ffLanternBuild,vec3(ffLanternOutput.a));
  gl_FragColor=ffLanternOutput;`;
  if(soft&&layer==='coloration'&&artwork==='prior')finalOutput=finalOutput.replace('  float ffLanternAcross=',
    '  if(ffLanternFeather>0.0){\n  float ffLanternAcross=').replace('  gl_FragColor=ffLanternOutput;',
    '  }\n  gl_FragColor=ffLanternOutput;');
  const native=fragment.slice(0,main.index)+uniforms+fragment.slice(main.index,output.index)+shaping+finalOutput+fragment.slice(output.index+output[0].length);
  const material=artwork==='flow'?lanternFlowFragment(native,layer):artwork==='veil'||artwork==='plain'?lanternVeilFragment(native,layer,{artwork:artwork==='veil'}):
    artwork==='prior'&&(appearance==='animated'||appearance==='reactive')?lightAppearanceFragment(native,layer,'lantern'):native;
  return refraction&&artwork!=='plain'&&material?v7RefractionFragment(material,layer):material;
}

export class LanternShaders {
  constructor({report=null,veilAssets=lanternVeilAssets}={}){
    this.sources=new Map();this.shaders=new WeakMap();this.programs=new WeakMap();this.warnings=new Set();this.report=report;this.installed=false;this.veilAssets=veilAssets;this.veilLease=null;
    this.install();
  }
  install(){
    if(this.installed||!globalThis.Hooks?.on)return;this.installed=true;
    globalThis.Hooks.on('initializePointLightSourceShaders',source=>{
      const entry=this.sources.get(source);if(entry&&!entry.suspended)this.update(source,entry.options);
    });
  }
  restore(shader,{retain=false}={}){
    const record=this.shaders.get(shader);if(!record)return;
    // Another module or native reinitialization may have replaced the program.
    // Restore our program only while we still own it, and retain prior uniforms.
    if(shader.program===record.patched)setLightShaderProgram(shader,record.original,{layoutChanged:true});
    for(const [name,previous] of record.uniforms){if(previous?.exists)shader.uniforms[name]=previous.value;else delete shader.uniforms[name];}
    invalidateLightUniformLayout(shader);markLightShaderUniformsDirty(shader);
    if(retain)record.suspended=true;else this.shaders.delete(shader);
  }
  suspend(source){
    const entry=this.sources.get(source);if(!entry)return;
    entry.suspended=true;entry.active=false;entry.decorative=false;
    for(const shader of entry.shaders)this.restore(shader,{retain:true});
  }
  restoreEntry(entry){for(const shader of entry.shaders)this.restore(shader);entry.shaders.clear();entry.active=false;entry.decorative=false;}
  fail(entry,message){
    this.restoreEntry(entry);entry.error=message;
    if(!this.warnings.has(message)){
      this.warnings.add(message);
      const error=new Error(`Lantern detail is unavailable; native cone lighting remains active. ${message}`);
      try{if(this.report)this.report(error);else console.warn(`Yvaelle’s Toolbox | ${error.message}`);}catch{/* A diagnostic must not disable the native light. */}
    }
  }
  update(source,options={}){
    if(!localPerformance.active)return this.updateLighting(source,options);
    return localPerformance.measure('lighting',()=>this.updateLighting(source,options));
  }
  updateLighting(source,options={}){
    if(!source||typeof source!=='object')return {active:false,decorative:false,error:'No native lantern source was supplied.'};
    let entry=this.sources.get(source);
    if(!entry){entry={options,shaders:new Set(),active:false,decorative:false,error:null};this.sources.set(source,entry);}else entry.options=options;
    entry.suspended=false;
    const sample=lanternShaderOptions(options),layers=lightShaderLayers(source,entry);
    for(const shader of entry.shaders)if(!layers.some(([,value])=>value.shader===shader)){this.restore(shader);entry.shaders.delete(shader);}
    entry.error=null;
    const effects=sample.localEffects&&!options.reduced&&sample.appearanceEffects?.enabled&&sample.appearanceEffects?.legacyEnabled!==false?sample.appearanceEffects:null;
    const wantsVeil=sample.artwork==='veil'&&sample.localEffects&&sample.strength>0;
    if(wantsVeil&&!this.veilLease){
      // A route/image failure may report synchronously during acquisition.
      // Guard that ready callback from recursively acquiring an orphan lease.
      this.veilLease=()=>{};
      try{this.veilLease=this.veilAssets.acquire(()=>{for(const [currentSource,currentEntry]of this.sources)if(currentEntry.options.artwork==='veil'&&!currentEntry.suspended)this.update(currentSource,currentEntry.options);});}
      catch{this.veilLease=null;}
    }
    const veilTexture=wantsVeil?this.veilAssets.peek():null;
    const artwork=sample.artwork==='veil'?(veilTexture?'veil':'plain'):sample.artwork==='flow'&&!sample.localEffects?'plain':sample.artwork;
    const refraction=artwork!=='plain'&&sample.localEffects&&sample.appearanceEffects?.refraction?.enabled===true&&sample.appearanceEffects.refraction.strength>0?sample.appearanceEffects.refraction:null;
    const decorative=sample.localEffects&&sample.strength>0&&artwork!=='plain',soft=sample.edgeStyle==='soft'&&sample.edgeSoftness>0;
    const previousFlowX=entry.flowMotion?.offset[0],previousFlowY=entry.flowMotion?.offset[1];
    if(artwork==='flow'){
      entry.flowMotion??=createLanternFlowMotion();
      stepLanternFlowMotion(entry.flowMotion,{angle:options.angle,clock:options.clock,reduced:options.reduced,localEffects:options.localEffects,
        enabled:decorative&&layers.length>0&&source.active!==false&&source.suppressed!==true&&source.hasActiveLayer!==false});
    }else entry.flowMotion=null;
    if((!decorative&&!soft&&!effects&&!refraction&&!sample.airborneWash)||source.active===false||source.suppressed===true||source.hasActiveLayer===false){this.restoreEntry(entry);return this.status(source);}
    if(!layers.length){this.restoreEntry(entry);return this.status(source);}
    try{
      const changes=[];
      for(const [layer,{shader}] of layers){
        if(!shader.uniforms||typeof shader.uniforms!=='object')throw new Error('A source shader has no supported uniform object.');
        let record=this.shaders.get(shader);
        if(record&&shader.program!==record.patched&&shader.program!==record.original){this.restore(shader);record=null;}
        if(!record){
          const original=shader.program;
          if(!original||typeof original.vertexSrc!=='string')throw new Error('A source shader exposes no supported native program.');
          record={original,patched:null,direction:new Float32Array(2),uniforms:new Map(CLASSIC_UNIFORMS.map(name=>[name,{exists:Object.hasOwn(shader.uniforms,name),value:shader.uniforms[name]}]))};
        }else if(record.suspended){
          // Core now owns the complete post-initialization baseline. Preserve
          // that baseline on later release, while retaining our direction and
          // cached program records across a native-only initialization window.
          for(const name of record.uniforms.keys())record.uniforms.set(name,{exists:Object.hasOwn(shader.uniforms,name),value:shader.uniforms[name]});
          record.suspended=false;
        }
        let programs=this.programs.get(record.original);if(!programs){programs=new Map();this.programs.set(record.original,programs);}
        const appearance=effects?(effects.animated?'animated':'reactive'):'current',key=`${layer}:${sample.edgeStyle}:${artwork}:${artwork==='prior'&&appearance!=='current'?'appearance':'current'}`+(sample.airborneWash?':airborneWash':'')+(refraction&&layer==='coloration'?':refraction':'');
        let patched=programs.get(key);
        if(patched?.error)throw new Error(patched.error);
        if(!patched){
          const fragment=lanternLightFragment(record.original.fragmentSrc,layer,sample.edgeStyle,appearance,artwork,sample.airborneWash,!!refraction);
          if(!fragment){
            const error=`The ${layer} shader has an unsupported native output.`;
            programs.set(key,{error});throw new Error(error);
          }
          if(typeof globalThis.PIXI?.Program?.from!=='function')throw new Error('The native shader program factory is unavailable.');
          patched=PIXI.Program.from(sourceCode(record.original.vertexSrc),sourceCode(fragment));programs.set(key,patched);
        }
        changes.push({layer,shader,record,patched});
      }
      const legacyEffects=artwork==='prior'?effects:null;
      const directionX=Math.cos(sample.angle),directionY=Math.sin(sample.angle);
      const appearanceOptions=legacyEffects?{angle:options.angle,width:options.width,strength:sample.feather*sample.strength}:null;
      if(legacyEffects){entry.appearanceDirection??=new Float32Array(2);entry.appearanceValues??={};
        lightAppearanceUniforms(legacyEffects,appearanceOptions,entry.appearanceDirection,entry.appearanceValues);}
      const shapeNames=sample.edgeStyle==='soft'?(legacyEffects?SOFT_APPEARANCE_UNIFORMS:SOFT_UNIFORMS):(legacyEffects?APPEARANCE_UNIFORMS:CLASSIC_UNIFORMS);
      const baseNames=sample.airborneWash?[...shapeNames,WASH_UNIFORM]:shapeNames;
      // Material preparation consumes five scalars/channels, not the complete
      // native light and mounting snapshot. Keep each live value while avoiding
      // two broad object spreads for every source on every display frame.
      const materialOptions=artwork==='veil'||artwork==='plain'||artwork==='flow'?{clock:options.clock,reduced:options.reduced,localEffects:options.localEffects,
        strength:sample.feather*sample.strength,appearanceEffects:options.reduced?null:effects}:null;
      const veilValues=artwork==='veil'||artwork==='plain'?lanternVeilUniforms(materialOptions,veilTexture):null;
      const flowValues=artwork==='flow'?lanternFlowUniforms(materialOptions,entry.flowMotion):null;
      for(const {layer,shader,record,patched} of changes){
        const veilNames=artwork==='veil'&&layer==='coloration'?LANTERN_VEIL_UNIFORMS:LANTERN_VEIL_COMMON_UNIFORMS;
        const flowNames=layer==='coloration'?LANTERN_FLOW_UNIFORMS:LANTERN_FLOW_COMMON_UNIFORMS;
        const namesKey=`${sample.edgeStyle}:${!!legacyEffects}:${sample.airborneWash}:${artwork}:${!!refraction&&layer==='coloration'}`;
        if(record.namesKey!==namesKey){
          const artworkNames=veilValues?[...baseNames,...veilNames]:flowValues?[...baseNames,...flowNames]:baseNames;
          record.namesKey=namesKey;record.ownedNames=refraction&&layer==='coloration'?[...artworkNames,...V7_REFRACTION_UNIFORMS]:artworkNames;
        }
        const names=record.ownedNames;
        const layoutChanged=lightUniformLayoutChanged(shader,record,names);
        this.shaders.set(shader,record);entry.shaders.add(shader);
        setLightUniformVector(shader,'ffLanternDirection',record.direction,directionX,directionY);
        setLightUniform(shader,'ffLanternHalfAngle',sample.halfAngle);setLightUniform(shader,'ffLanternFullCircle',sample.fullCircle);
        // These legacy material fields are declared on every native layer for
        // compatibility, but only the prior artwork's coloration reads them.
        // Keep their exact values without re-uploading two unchanged native
        // layers just because an unused material clock advanced. Direction,
        // feathering, native gain and actual flow/veil fields stay live.
        const priorMaterial=artwork==='prior'&&layer==='coloration';
        setLightUniform(shader,'ffLanternStrength',decorative?sample.strength:0,priorMaterial);setLightUniform(shader,'ffLanternFeather',decorative?sample.feather:0);setLightUniform(shader,'ffLanternPhase',decorative?sample.phase:0,priorMaterial);
        setLightUniform(shader,'ffLanternTransition',decorative?sample.transition:1,priorMaterial);setLightUniform(shader,'ffLanternShutdown',decorative?sample.shutdown:0,priorMaterial);
        if(sample.airborneWash){
          if(!record.uniforms.has(WASH_UNIFORM))record.uniforms.set(WASH_UNIFORM,{exists:Object.hasOwn(shader.uniforms,WASH_UNIFORM),value:shader.uniforms[WASH_UNIFORM]});
          setLightUniform(shader,WASH_UNIFORM,sample.washExponent);
        }else if(record.uniforms.has(WASH_UNIFORM)){
          const previous=record.uniforms.get(WASH_UNIFORM);if(previous.exists)shader.uniforms[WASH_UNIFORM]=previous.value;else delete shader.uniforms[WASH_UNIFORM];
          record.uniforms.delete(WASH_UNIFORM);
        }
        if(legacyEffects)setPreparedLightAppearanceUniforms(shader,entry.appearanceValues,record);
        else for(const name of LIGHT_APPEARANCE_UNIFORMS)if(record.uniforms.has(name)){
          const previous=record.uniforms.get(name);if(previous.exists)shader.uniforms[name]=previous.value;else delete shader.uniforms[name];record.uniforms.delete(name);
        }
        if(refraction&&layer==='coloration')setV7RefractionUniforms(shader,refraction,sample.appearanceEffects??{},record);
        else releaseV7RefractionUniforms(shader,record);
        for(const name of LANTERN_VEIL_UNIFORMS){
          if(veilValues&&veilNames.includes(name)){
            if(!record.uniforms.has(name))record.uniforms.set(name,{exists:Object.hasOwn(shader.uniforms,name),value:shader.uniforms[name]});
            setLightUniform(shader,name,veilValues[name]);
          }else if(record.uniforms.has(name)){const previous=record.uniforms.get(name);if(previous.exists)shader.uniforms[name]=previous.value;else delete shader.uniforms[name];record.uniforms.delete(name);}
        }
        for(const name of LANTERN_FLOW_UNIFORMS){
          if(flowValues&&flowNames.includes(name)){
            if(!record.uniforms.has(name))record.uniforms.set(name,{exists:Object.hasOwn(shader.uniforms,name),value:shader.uniforms[name]});
            setLightUniform(shader,name,flowValues[name]);
          }else if(record.uniforms.has(name)){const previous=record.uniforms.get(name);if(previous.exists)shader.uniforms[name]=previous.value;else delete shader.uniforms[name];record.uniforms.delete(name);}
        }
        if(flowValues&&layer==='coloration'&&(previousFlowX!==flowValues.ffLanternFlowOffset[0]||previousFlowY!==flowValues.ffLanternFlowOffset[1]))noteLightUniformChange(shader);
        if(sample.edgeStyle==='soft'){
          if(!record.uniforms.has('ffLanternEdgeSoftness'))record.uniforms.set('ffLanternEdgeSoftness',{exists:Object.hasOwn(shader.uniforms,'ffLanternEdgeSoftness'),value:shader.uniforms.ffLanternEdgeSoftness});
          setLightUniform(shader,'ffLanternEdgeSoftness',sample.edgeSoftness);
        }else if(record.uniforms.has('ffLanternEdgeSoftness')){
          const previous=record.uniforms.get('ffLanternEdgeSoftness');if(previous.exists)setLightUniform(shader,'ffLanternEdgeSoftness',previous.value);else delete shader.uniforms.ffLanternEdgeSoftness;
          record.uniforms.delete('ffLanternEdgeSoftness');
        }
        record.patched=patched;setLightShaderProgram(shader,patched,{layoutChanged});markLightShaderUniformsDirty(shader,{changedOnly:true});
      }
      entry.active=true;entry.decorative=decorative&&layers.some(([name])=>name==='coloration');
    }catch(error){this.fail(entry,String(error?.message??error));}
    return this.status(source);
  }
  status(source){const entry=this.sources.get(source);return {active:!!entry?.active,decorative:!!entry?.decorative,error:entry?.error??null};}
  release(source){const entry=this.sources.get(source);if(!entry)return;this.restoreEntry(entry);this.sources.delete(source);}
  clear(){for(const source of [...this.sources.keys()])this.release(source);this.veilLease?.();this.veilLease=null;}
}
