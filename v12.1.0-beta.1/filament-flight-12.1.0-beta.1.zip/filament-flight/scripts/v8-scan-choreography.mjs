import {selectScanMethod,heldScanMethod,DEFAULT_SCAN_METHODS} from './v84-scan-methods.mjs?v=12.1.0-beta.1';
import {scanArtworkAim} from './v8-scan-art.mjs?v=12.1.0-beta.1';
import {makeCooperativeAreaPlan,virtualAreaCells,areaCellSize,cooperativeVisitCells,cooperativeAreaTeams,cooperativeVisitTeamCounts,cooperativeVisitTeamShapes,sampleCooperativeInspection,cooperativePersonalTiming} from './v84-cooperative-area.mjs?v=12.1.0-beta.1';
/** V8 instruments investigate in discrete, purposeful move / settle / scan
 * beats. A seeded coverage route is compiled once, shared by live effects and
 * local thought previews, and never reads Foundry documents or owns a timer. */
import {sampleWeightedTransit} from './v8-motion.mjs?v=12.1.0-beta.1';
import {sampleCoreState} from './bit-core-states.mjs?v=12.1.0-beta.1';
import {scanBitClock,scanSpeed} from './v82-scan-clock.mjs?v=12.1.0-beta.1';
import {stepScanPursuit} from './v88-scan-locomotion.mjs?v=12.1.0-beta.1';
import {scanPointInPolygon} from './v82-scene-scan-context.mjs?v=12.1.0-beta.1';
const TAU=Math.PI*2;
const unit=n=>Math.max(0,Math.min(1,Number(n)||0));
const smooth=n=>{n=unit(n);return n*n*(3-2*n);};
const smoother=n=>{n=unit(n);return n*n*n*(n*(n*6-15)+10);};
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const lerp=(a,b,t)=>a+(b-a)*t;
const mix=(a,b,t)=>({x:lerp(a.x,b.x,t),y:lerp(a.y,b.y,t)});
const bearing=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
const angleMix=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const cache=new Map();let cachedVisits=0;
const pausedExaminations=new WeakMap();
/** LRU plan cache. A 120 ft area plan holds ~2,000 visits (2.7–4.6 MB), so
 * the total visit count is budgeted (about eight such plans) as well as the
 * entry count. Recently sampled plans are refreshed on every hit. */
export const SCAN_PLAN_LIMIT=32,SCAN_PLAN_VISIT_BUDGET=16384;
function cachedPlan(key){const entry=cache.get(key);if(!entry)return null;cache.delete(key);cache.set(key,entry);return entry.plan;}
function rememberPlan(key,plan){
  const visits=plan.routes.reduce((sum,route)=>sum+route.visits.length,0);
  while(cache.size&&(cache.size>=SCAN_PLAN_LIMIT||cachedVisits+visits>SCAN_PLAN_VISIT_BUDGET)){const [oldest,entry]=cache.entries().next().value;cache.delete(oldest);cachedVisits-=entry.visits;}
  cache.set(key,{plan,visits});cachedVisits+=visits;return plan;
}
export const SCAN_VISITS_PER_BIT=42;
export const SCAN_NATIVE_CELL_LIMIT=4096;
export const TOKEN_SCAN_METHODS=DEFAULT_SCAN_METHODS.creature;
export const AREA_SCAN_METHODS=DEFAULT_SCAN_METHODS.area;
/** A small shuffled deck gives every instrument all methods, without adjacent
 * repeats even where the deck wraps. The schedule is fixed for every client. */
function methodDeck(methods,count,random){
  const result=[];
  while(result.length<count){
    const deck=[...methods];for(let i=deck.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}
    if(deck.length>1&&deck[0]===result.at(-1))[deck[0],deck[1]]=[deck[1],deck[0]];
    result.push(...deck);
  }
  result.length=count;
  if(count>2&&result.at(-1)===result[0])result[count-1]=methods.find(method=>method!==result[count-2]&&method!==result[0]);
  return result;
}

export function scanSeed(value){
  let h=2166136261;for(const c of String(value??'filament-scan')){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;
}
function generator(seed){let x=seed>>>0;return ()=>{x+=0x6D2B79F5;let t=x;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
function bound(p,limit=.94){const d=Math.hypot(p.x,p.y),s=d>limit?limit/d:1;return {x:p.x*s,y:p.y*s};}
function focusSites(mode,random,region=null){
  const n=mode==='creatureScan'?22:34,sites=[];
  // Stratified area samples give every part of the chosen region a real job.
  // The golden-angle positions are NOT the travel order: below, instruments
  // choose neighboring uncovered work, with occasional corroborating passes.
  const rotation=random()*TAU;
  for(let i=0;i<n;i++){
    const angle=i*2.399963229728653+rotation+(random()-.5)*.23;
    const radius=Math.sqrt((i+.4+random()*.35)/n)*.76;
    sites.push({x:Math.cos(angle)*radius*(mode==='creatureScan'?.62:1),y:Math.sin(angle)*radius,index:i});
  }
  if(!region?.length)return sites;
  const inside=sites.filter(p=>scanPointInPolygon(p,region));
  // Bounded stratification also fills narrow drawn rectangles and ellipses.
  const b=polygonBounds(region);for(let i=0;i<128&&inside.length<n;i++){
    const p={x:b.x+b.width*((i*.61803398875+random()*.025)%1),y:b.y+b.height*((i*.41421356237+random()*.025)%1)};
    if(scanPointInPolygon(p,region))inside.push({...p,index:inside.length});
  }
  if(!inside.length)inside.push({...region[0],index:0});
  return inside.map((p,index)=>({...p,index}));
}
function makeRoute(index,count,mode,seed,sites,visitsCount=SCAN_VISITS_PER_BIT){
  const random=generator(seed+Math.imul(index+1,0x45d9f3b)),sector=TAU*(index/count)+random()*.44;
  const methods=methodDeck(AREA_SCAN_METHODS,visitsCount,generator(seed+index*997+8300));
  let focus={x:Math.cos(sector)*.64,y:Math.sin(sector)*.64},previous=bound({x:focus.x*.96,y:focus.y*.96}),direction=sector+Math.PI;
  const visited=new Map(),visits=[];let cursor=0;
  // Large fixed native fields use a spatially ordered coverage itinerary.
  // This avoids an all-cells search for every visit (millions of random/angle
  // evaluations on a 120-foot command) while retaining complete coverage.
  let ordered=null,orderCursor=0;
  if(sites.length>96&&sites.every(p=>p.gridCell)){
    const rows=new Map();for(const p of sites){const row=p.gridCell.offset?.i??p.gridCell.center.y;const list=rows.get(row)??[];list.push(p);rows.set(row,list);}
    ordered=[...rows.keys()].sort((a,b)=>a-b).flatMap((row,i)=>rows.get(row).sort((a,b)=>(a.gridCell.center.x-b.gridCell.center.x)*(i%2?-1:1)||a.index-b.index));
    if(index%2)ordered.reverse();let nearest=Infinity;
    for(let i=0;i<ordered.length;i++){const d=distance(focus,ordered[i]);if(d<nearest){nearest=d;orderCursor=i;}}
  }
  for(let v=0;v<visitsCount;v++){
    // Coverage preference discourages rechecking the same section endlessly.
    // A light sector preference keeps colleagues distributed without locking
    // them into quadrants or synchronized traversals.
    let chosen,score=Infinity;
    for(const p of ordered?[ordered[orderCursor%ordered.length]]:sites){
      const angle=bearing(focus,p),region=Math.cos(angle-sector),turn=Math.abs(Math.atan2(Math.sin(angle-direction),Math.cos(angle-direction)));
      const used=visited.get(p.index)??0;
      const candidate=distance(focus,p)*.48+used*1.3-turn*.035-region*.13+random()*.12;
      if(candidate<score){chosen=p;score=candidate;}
    }
    const revisit=v>0&&v%7===3;
    const nextFocus=revisit&&!chosen.gridCell?{x:focus.x*.94,y:focus.y*.94,index:chosen.index}:chosen;
    if(!revisit)visited.set(chosen.index,(visited.get(chosen.index)??0)+1);
    if(ordered&&!revisit)orderCursor++;
    const inspectAngle=bearing(previous,nextFocus)+Math.PI+(random()-.5)*1.4+(revisit?1.12:0);
    const standOff=mode==='creatureScan'?.18+random()*.11:.18+random()*.12;
    const position=bound({x:nextFocus.x+Math.cos(inspectAngle)*standOff,y:nextFocus.y+Math.sin(inspectAngle)*standOff});
    const d=distance(previous,position),travel=780+d*(mode==='creatureScan'?980:1520)+random()*330;
    const settle=260+random()*220,scan=1380+random()*790+(revisit?310:0),release=230+random()*170;
    const tangent=bearing(previous,position),bend=(random()-.5)*Math.min(.17,d*.38);
    const control=bound({x:(previous.x+position.x)/2-Math.sin(tangent)*bend,y:(previous.y+position.y)/2+Math.cos(tangent)*bend});
    const scanAngle=bearing(position,nextFocus),patch=.19+random()*.115;
    visits.push({at:cursor,travel,settle,scan,release,duration:travel+settle+scan+release,from:previous,to:position,control,focus:{x:nextFocus.x,y:nextFocus.y},
      fromAngle:visits.at(-1)?.scanAngle??tangent,travelAngle:tangent,scanAngle,visitIndex:v,method:methods[v],...(chosen.gridCell?{gridCell:chosen.gridCell,gridCellId:chosen.gridCell.id}:{}),patch,aspect:.54+random()*.25,tilt:(random()-.5)*.24,detailPass:revisit});
    cursor+=travel+settle+scan+release;previous=position;focus=nextFocus;direction=bearing(visits.at(-1).from,position);
  }
  // Endpoints are joined by one final real transit rather than a position jump
  // on the bounded schedule wrap (roughly three minutes of investigation).
  const first=visits[0],last=visits.at(-1),closeDistance=distance(last.to,first.from);
  const duration=860+closeDistance*1500;
  visits.push({at:cursor,travel:duration,settle:0,scan:0,release:0,duration,from:last.to,to:first.from,control:bound(mix(last.to,first.from,.5)),focus:first.focus,
    fromAngle:last.scanAngle,travelAngle:bearing(last.to,first.from),scanAngle:first.fromAngle,visitIndex:visitsCount,patch:0,aspect:.65,tilt:0,detailPass:false});
  cursor+=duration;
  const delay=index*(730+(sites.some(p=>p.gridCell)?generator(seed+index*12831+137)():random())*330);
  return {visits,duration:cursor,initial:first.from,delay,index,scanVisits:visitsCount};
}

const creatureBounds=value=>({halfWidth:Math.max(.1,finite(value?.halfWidth,100/.94/2)),halfHeight:Math.max(.1,finite(value?.halfHeight,100/.94/2))});
/** A full-footprint strip, in normalized painter coordinates. Both endpoints
 * extend beyond the rectangle so the first and last pixel edges are sampled. */
export function creatureSweepTrack(bounds,axis='x',direction=1){
  bounds=creatureBounds(bounds);const half=axis==='y'?bounds.halfHeight:bounds.halfWidth,margin=Math.max(2.5,Math.min(10,half*.17)),sign=direction<0?-1:1;
  const extent=half+margin;
  return axis==='y'?{from:{x:0,y:-extent*sign},to:{x:0,y:extent*sign}}:{from:{x:-extent*sign,y:0},to:{x:extent*sign,y:0}};
}
/** The moving strip midpoint is the instrument's actual optical aim. Acquisition
 * and resolve hold their respective edges; timing matches the shared painter. */
export function creatureSweepFocus(bounds,axis,direction,progress){
  const track=creatureSweepTrack(bounds,axis,direction),p=unit((progress-.18)/.52);
  return {...mix(track.from,track.to,p),track};
}
function exteriorStation(angle,bounds,margin=.16){
  const x=Math.cos(angle),y=Math.sin(angle),hx=bounds.halfWidth/100,hy=bounds.halfHeight/100;
  const edge=Math.min(Math.abs(x)>.00001?hx/Math.abs(x):Infinity,Math.abs(y)>.00001?hy/Math.abs(y):Infinity);
  return {x:x*(edge+margin),y:y*(edge+margin)};
}
function portraitClearance(p,bounds){return Math.hypot(Math.max(0,Math.abs(p.x)-bounds.halfWidth/100),Math.max(0,Math.abs(p.y)-bounds.halfHeight/100));}
/** Intersect the viewing ray with a rounded rectangle outside the portrait.
 * A radial offset alone loses its clearance beside very long, thin tokens. */
function exteriorInspectionStation(angle,bounds,margin=.16){
  const x=Math.cos(angle),y=Math.sin(angle),ax=Math.abs(x),ay=Math.abs(y),hx=bounds.halfWidth/100,hy=bounds.halfHeight/100;
  const rx=ax>.0000001?(hx+margin)/ax:Infinity,ry=ay>.0000001?(hy+margin)/ay:Infinity;
  let r;if(ay*rx<=hy)r=rx;else if(ax*ry<=hx)r=ry;else{const projection=ax*hx+ay*hy;r=projection+Math.sqrt(Math.max(0,projection*projection-hx*hx-hy*hy+margin*margin));}
  return {x:x*r,y:y*r};
}
function creatureTravelPath(from,to,bounds,fromAngle,toAngle,station=exteriorStation,clearance=null){
  const delta=Math.atan2(Math.sin(toAngle-fromAngle),Math.cos(toAngle-fromAngle)),steps=Math.max(3,Math.ceil(Math.abs(delta)/.16));
  const margin=(p,a)=>Math.max(.12,clearance?clearance(p,bounds):distance({x:0,y:0},p)-distance({x:0,y:0},exteriorStation(a,bounds,0)));
  const start=margin(from,fromAngle),end=margin(to,toAngle),path=Array.from({length:steps+1},(_,i)=>{
    const q=i/steps;return i===0?from:i===steps?to:station(fromAngle+delta*q,bounds,lerp(start,end,q)+.08*Math.sin(Math.PI*q)**2);
  });
  const lengths=[0];for(let i=1;i<path.length;i++)lengths.push(lengths.at(-1)+distance(path[i-1],path[i]));
  return {path,pathLengths:lengths,pathLength:lengths.at(-1)};
}
const creatureTemplateCache=new Map(),CREATURE_TEMPLATE_LIMIT=128;
/** Seeded viewpoint choices depend on the instrument and job, never the live
 * portrait bounds. Keep this small pure schedule separate from the physical
 * points, which are reconstructed for the exact current bounds every time. */
function creatureRouteTemplate(index,count,seed){
  const key=`${seed}:${index}:${count}`;let cached=creatureTemplateCache.get(key);if(cached)return cached;
  const random=generator(seed+Math.imul(index+1,0x45d9f3b)),sector=-Math.PI/2+TAU*index/count+(random()-.5)*.46;
  const viewpoints=Array.from({length:12},(_,i)=>sector+i*TAU/12+(random()-.5)*.18),visited=new Map(),visits=[];
  let viewAngle=sector,lastAxis=null,repeatedAxis=0;
  for(let v=0;v<SCAN_VISITS_PER_BIT;v++){
    let chosen=0,best=Infinity;
    for(let n=0;n<viewpoints.length;n++){
      const turn=Math.abs(Math.atan2(Math.sin(viewpoints[n]-viewAngle),Math.cos(viewpoints[n]-viewAngle)));
      const score=(visited.get(n)??0)*.7+turn*.23+random()*.14+(turn<.22?.42:0);
      if(score<best){best=score;chosen=n;}
    }
    visited.set(chosen,(visited.get(chosen)??0)+1);
    const angle=viewpoints[chosen]+(random()-.5)*.12,margin=.14+random()*.055;
    const axis=repeatedAxis>=2?(lastAxis==='x'?'y':'x'):random()<.5?'x':'y';
    repeatedAxis=axis===lastAxis?repeatedAxis+1:1;lastAxis=axis;
    const travelOffset=random()*280,settle=300+random()*190,scan=2200+random()*650,release=280+random()*120,controlMargin=.34+random()*.05;
    visits.push({angle,margin,axis,travelOffset,settle,scan,release,controlMargin,detailPass:v>0&&(visited.get(chosen)??0)>1});viewAngle=angle;
  }
  cached={sector,visits,delay:index*(710+random()*330)};
  if(creatureTemplateCache.size>=CREATURE_TEMPLATE_LIMIT)creatureTemplateCache.delete(creatureTemplateCache.keys().next().value);creatureTemplateCache.set(key,cached);return cached;
}
function makeCreatureRoute(index,count,seed,bounds,preparePaths=true){
  const template=creatureRouteTemplate(index,count,seed),sector=template.sector,visits=[];
  let previous=exteriorStation(sector,bounds,.18),previousAngle=sector+Math.PI,cursor=0,viewAngle=sector;
  for(let v=0;v<SCAN_VISITS_PER_BIT;v++){
    const choice=template.visits[v],{angle,axis,settle,scan,release}=choice,position=exteriorStation(angle,bounds,choice.margin);
    const direction=(axis==='x'?position.x:position.y)<0?1:-1,track=creatureSweepTrack(bounds,axis,direction);
    const initialFocus={x:track.from.x/100,y:track.from.y/100},finalFocus={x:track.to.x/100,y:track.to.y/100};
    const d=distance(previous,position),travel=850+d*1060+choice.travelOffset;
    const tangent=bearing(previous,position),signedTurn=Math.atan2(Math.sin(angle-viewAngle),Math.cos(angle-viewAngle)),middle=viewAngle+signedTurn*.5;
    // A high exterior control station gives the physical body clearance during
    // short side changes. Longer cross-view moves are rare, purposeful transfers.
    const control=exteriorStation(middle,bounds,choice.controlMargin);
    const scanAngle=bearing(position,initialFocus),endAngle=bearing(position,finalFocus);
    visits.push({at:cursor,travel,settle,scan,release,duration:travel+settle+scan+release,from:previous,to:position,control,...(preparePaths?creatureTravelPath(previous,position,bounds,viewAngle,angle):{}),
      focus:initialFocus,fromAngle:previousAngle,travelAngle:tangent,scanAngle,endAngle,axis,direction,visitIndex:v,
      patch:Math.max(bounds.halfWidth,bounds.halfHeight)/100,aspect:bounds.halfHeight/bounds.halfWidth,tilt:0,detailPass:choice.detailPass});
    cursor+=travel+settle+scan+release;previous=position;previousAngle=endAngle;viewAngle=angle;
  }
  const first=visits[0],last=visits.at(-1),duration=900+distance(last.to,first.from)*1300;
  const fromAngle=Math.atan2(last.to.y,last.to.x),toAngle=Math.atan2(first.from.y,first.from.x),middle=fromAngle+Math.atan2(Math.sin(toAngle-fromAngle),Math.cos(toAngle-fromAngle))*.5;
  visits.push({at:cursor,travel:duration,settle:0,scan:0,release:0,duration,from:last.to,to:first.from,control:exteriorStation(middle,bounds,.37),...(preparePaths?creatureTravelPath(last.to,first.from,bounds,fromAngle,toAngle):{}),focus:first.focus,
    fromAngle:last.endAngle,travelAngle:bearing(last.to,first.from),scanAngle:first.fromAngle,endAngle:first.fromAngle,axis:first.axis,direction:first.direction,visitIndex:SCAN_VISITS_PER_BIT,patch:0,aspect:1,tilt:0,detailPass:false});
  return {visits,duration:cursor+duration,initial:first.from,delay:template.delay,index,targetBounds:bounds};
}

function makeV82CreatureRoute(index,count,seed,bounds,{brief=false,oneShot=false}={},preparePaths=true){
  // V82 replaces every legacy travel path below. Preserve all seeded template
  // choices and metadata without constructing the discarded legacy polylines.
  const base=makeCreatureRoute(index,count,seed,bounds,false),random=generator(seed+index*991+8192),initial=base.initial,visits=[];
  const survey={at:0,travel:0,settle:brief?230:380,scan:brief?1600:2200,release:brief?180:280,from:initial,to:initial,control:initial,focus:{x:0,y:0},
    fromAngle:base.visits[0].fromAngle,scanAngle:base.visits[0].fromAngle,endAngle:base.visits[0].fromAngle,axis:'y',direction:1,visitIndex:0,scanStage:'survey',patch:.5,aspect:1,tilt:0};
  survey.duration=survey.settle+survey.scan+survey.release;visits.push(survey);
  let cursor=survey.duration,previous=initial,previousAngle=survey.endAngle,viewAngle=Math.atan2(initial.y,initial.x);
  const countVisits=brief?3:SCAN_VISITS_PER_BIT,methods=methodDeck(TOKEN_SCAN_METHODS,countVisits,generator(seed+index*613+8301));
  for(let i=0;i<countVisits;i++){
    const template=base.visits[i],angle=Math.atan2(template.to.y,template.to.x),position=template.to,arc=(i%3===1?-1:1)*(.29+random()*.36),margin=.14+random()*.025;
    const scanTo=exteriorStation(angle+arc,bounds,margin),region={x:0,y:0,hx:1,hy:1};
    const travel=brief?430+distance(previous,position)*450:template.travel,settle=brief?200+random()*70:template.settle;
    const scan=brief?930+random()*150:template.scan*1.12,release=brief?160:template.release;
    const visit={...template,at:cursor,travel,settle,scan,release,duration:travel+settle+scan+release,from:previous,to:position,scanTo,
      ...(preparePaths?creatureTravelPath(previous,position,bounds,viewAngle,angle):{}),...(preparePaths?{swirl:creatureTravelPath(position,scanTo,bounds,angle,angle+arc)}:{}),
      fromAngle:previousAngle,visitIndex:i+1,scanStage:'close',region,method:methods[i]};
    const b={halfWidth:bounds.halfWidth*region.hx,halfHeight:bounds.halfHeight*region.hy},focus=creatureSweepFocus(b,visit.axis,visit.direction,1);
    visit.endAngle=bearing(scanTo,{x:(focus.x+bounds.halfWidth*region.x)/100,y:(focus.y+bounds.halfHeight*region.y)/100});
    visits.push(visit);cursor+=visit.duration;previous=scanTo;previousAngle=visit.endAngle;viewAngle=angle+arc;
  }
  const loopStart=survey.duration;
  if(!oneShot){
    const first=visits[1],duration=850+distance(previous,first.from)*1250,toAngle=Math.atan2(first.from.y,first.from.x);
    visits.push({at:cursor,travel:duration,settle:0,scan:0,release:0,duration,from:previous,to:first.from,control:first.from,...(preparePaths?creatureTravelPath(previous,first.from,bounds,viewAngle,toAngle):{}),focus:first.focus,
      fromAngle:previousAngle,scanAngle:first.fromAngle,endAngle:first.fromAngle,axis:first.axis,direction:first.direction,visitIndex:countVisits+1,scanStage:'close',patch:0,aspect:1,tilt:0});cursor+=duration;
  }
  // Creature jobs acquire one shared surface. Simultaneous arrival lets its
  // single global survey clock survive live speed changes without per-bit
  // stagger offsets replaying a survey or admitting premature close passes.
  return {visits,duration:cursor,initial,delay:0,index,targetBounds:bounds,loopStart,oneShot,v82:true};
}

/** Whole-body travel follows an exterior contour with a quintic clock.
 * Readings themselves hold their chosen station; a rare parallax phrase makes
 * one complete, slow circuit. No radial breathing is added just to make motion. */
function creatureExaminationCurve(bounds,fromAngle,toAngle,start,end,lean=0,weighted=false){
  const curve={bounds,fromAngle,toAngle,start,end,lean,weighted};
  const point=q=>exteriorInspectionStation(lerp(fromAngle,toAngle,q),bounds,lerp(start,end,q)-lean*Math.sin(Math.PI*q)**2);
  let pathTimes;
  if(Math.abs(toAngle-fromAngle)>=TAU-1e-8&&Math.abs(start-end)<1e-8){
    // Put checked vertices at each straight-edge end and rounded corner's
    // midpoint. Equal polar angles would cut thin-portrait corners, even when
    // the analytic housing path itself has generous exterior clearance.
    const hx=bounds.halfWidth/100,hy=bounds.halfHeight/100,m=start,c=Math.SQRT1_2;
    const corners=[[hx+m,-hy],[hx+m*c,-hy-m*c],[hx,-hy-m],[-hx,-hy-m],[-hx-m*c,-hy-m*c],[-hx-m,-hy],[-hx-m,hy],[-hx-m*c,hy+m*c],[-hx,hy+m],[hx,hy+m],[hx+m*c,hy+m*c],[hx+m,hy]];
    const sign=Math.sign(toAngle-fromAngle),turns=corners.map(([x,y])=>{const delta=sign*(Math.atan2(y,x)-fromAngle),angle=(delta%TAU+TAU)%TAU;return angle/TAU;}).filter(q=>q>1e-8&&q<1-1e-8).sort((a,b)=>a-b);
    pathTimes=[0,...turns,1];
  }else pathTimes=Array.from({length:9},(_,i)=>i/8);
  const path=pathTimes.map(point),pathLengths=[0];
  for(let i=1;i<path.length;i++)pathLengths.push(pathLengths.at(-1)+distance(path[i-1],path[i]));
  return {path,pathTimes,pathLengths,pathLength:pathLengths.at(-1),inspectionCurve:curve};
}
function creatureExaminationTransfer(from,to,bounds,fromAngle,toAngle,index){
  const curve=creatureExaminationCurve(bounds,fromAngle,toAngle,portraitClearance(from,bounds),portraitClearance(to,bounds),0,true);
  curve.path[0]=from;curve.path[curve.path.length-1]=to;return curve;
}
function inspectionPolyline(prepare,reading,release){
  // Remove only duplicated light-handoff endpoints. A whole circuit then
  // retains every corner-aware checked vertex within fourteen points.
  const path=[...reading.path];let readingStart=0;
  if(distance(prepare,path[0])>1e-8){path.unshift(prepare);readingStart=1;}
  const readingEnd=readingStart+reading.path.length-1;
  if(distance(release,path.at(-1))>1e-8)path.push(release);
  const lengths=[0];for(let i=1;i<path.length;i++)lengths.push(lengths.at(-1)+distance(path[i-1],path[i]));
  return {path,lengths,length:lengths.at(-1),readingStart,readingEnd,readingTimes:reading.pathTimes};
}
function phraseInspectionProgress(phrase,phase,progress){
  const line=phrase.inspection,ends=line.lengths,last=ends.length-1,q=smoother(progress),start=line.readingStart??1,end=line.readingEnd??last-1;
  if(!(line.length>1e-12))return phase==='complete'?1:0;
  if(phase==='settling')return ends[start]*q/line.length;
  if(phase==='closing')return lerp(ends[end],ends[last],q)/line.length;
  if(phase==='complete')return 1;
  if(phase!=='scanning')return 0;
  const times=line.readingTimes??Array.from({length:end-start+1},(_,i)=>i/(end-start));
  let index=1;while(index<times.length-1&&times[index]<q)index++;
  const a=times[index-1],b=times[index],t=b>a?(q-a)/(b-a):1;
  return lerp(ends[start+index-1],ends[start+index],t)/line.length;
}

const INSPECTION_STATIONS=Object.freeze([
  [2,4,6,0,1,3,5,7],
  [-2,-4,-6,-8,-7,-5,-3,-1],
  [3,5,7,9,8,6,4,2],
  [-1,-3,-5,-7,-8,-6,-4,-2]
]);
const stationTarget=(angle,bounds)=>{const edge=exteriorStation(angle,bounds,0);return {x:edge.x*.6,y:edge.y*.6};};
const nearestAngle=(from,to)=>from+Math.atan2(Math.sin(to-from),Math.cos(to-from));

/** A real examination has distinct jobs: reach another contour, stop and read,
 * then relocate. Each physical instrument has its own direction, lane and
 * cadence. The occasional wide parallax reading carries the whole housing
 * around the portrait while the optical layer still covers its complete mask. */
function makeDeliberateCreatureRoute(index,count,seed,bounds,options={}){
  // Deliberate examination replaces every classic transit and swirl with its
  // own checked contour. Prepare the same random/template metadata only.
  const classic=makeV82CreatureRoute(index,count,seed,bounds,options,false);
  const sector=-Math.PI/2+TAU*index/count+(generator(seed+8801)()-.5)*.16;
  // These are parallel exterior lanes, not decorative in/out movement. Their
  // spacing keeps opposing personal itineraries from sharing the same track.
  const margin=.22+index*.19,initial=exteriorInspectionStation(sector,bounds,margin),visits=[];
  const survey={...classic.visits[0],from:initial,to:initial,control:initial,fromAngle:sector+Math.PI,scanAngle:sector+Math.PI,endAngle:sector+Math.PI};visits.push(survey);
  let previous=initial,viewAngle=sector,previousAngle=survey.endAngle,previousTarget={x:0,y:0},cursor=survey.duration;
  const stationCount=options.brief?2:8,sequence=INSPECTION_STATIONS[index%INSPECTION_STATIONS.length];
  const templates=classic.visits.filter(v=>v.scanStage==='close'&&v.scan>0);
  const personal=1+index*.065,methods=methodDeck(TOKEN_SCAN_METHODS,stationCount+(options.brief?0:1),generator(seed+index*613+8301));
  for(let i=0;i<stationCount;i++){
    const template=templates[i%templates.length],angle=nearestAngle(viewAngle,sector+sequence[i]*Math.PI/4),position=exteriorInspectionStation(angle,bounds,margin);
    const transfer=creatureExaminationTransfer(previous,position,bounds,viewAngle,angle,index);
    const travel=options.brief?(980+index*35):(2000+transfer.pathLength*760)*personal;
    const settle=options.brief?(i===0?420:300):(i===0?1050:650)*personal;
    const scan=options.brief?1100:(2400*[1,.96,1.08][(i+index)%3])/personal,release=options.brief?240:500*personal;
    const sideX=Math.max(0,Math.abs(position.x)-bounds.halfWidth/100),sideY=Math.max(0,Math.abs(position.y)-bounds.halfHeight/100),axis=sideX>=sideY?'y':'x';
    const direction=(axis==='x'?position.x:position.y)<0?1:-1,focus=creatureSweepFocus(bounds,axis,direction,0),target=stationTarget(angle,bounds);
    const reading=creatureExaminationCurve(bounds,angle,angle,margin,margin);
    const visit={...template,at:cursor,travel,settle,scan,release,duration:travel+settle+scan+release,from:previous,to:position,scanTo:position,axis,direction,
      method:methods[i],focus:{x:focus.x/100,y:focus.y/100},fromAngle:previousAngle,travelAngle:bearing(previous,position),...transfer,swirl:reading,
      inspectionTarget:target,inspectionFromTarget:previousTarget,
      inspectionPhrase:{kind:'station',prepare:position,measure:position,measureEnd:position,release:position,inspection:inspectionPolyline(position,reading,position),viewIndex:i+1,viewCount:stationCount+(options.brief?0:1)},
      inspectionFocus:`held ${['right contour','lower contour','left contour','upper contour'][((Math.round(angle/(Math.PI/2))%4)+4)%4]}`};
    const final=creatureSweepFocus(bounds,axis,direction,1);visit.scanAngle=bearing(position,{x:focus.x/100,y:focus.y/100});visit.endAngle=bearing(position,{x:final.x/100,y:final.y/100});
    visits.push(visit);cursor+=visit.duration;previous=position;previousAngle=visit.endAngle;previousTarget=target;viewAngle=angle;
  }
  if(!options.brief){
    const direction=index%2?-1:1,endAngle=viewAngle+direction*TAU,reading=creatureExaminationCurve(bounds,viewAngle,endAngle,margin,margin),template=templates[stationCount%templates.length];
    const travel=900*personal,settle=700*personal,scan=(11500+index*600),release=700*personal,position=previous;
    const orbit={...template,at:cursor,travel,settle,scan,release,duration:travel+settle+scan+release,from:position,to:position,scanTo:position,
      ...creatureExaminationTransfer(position,position,bounds,viewAngle,viewAngle,index),swirl:reading,method:methods[stationCount],
      inspectionTarget:{x:0,y:0},inspectionFromTarget:previousTarget,fromAngle:previousAngle,travelAngle:previousAngle,
      visitIndex:stationCount+1,inspectionFocus:'wide parallax circuit',
      inspectionPhrase:{kind:'parallax',prepare:position,measure:position,measureEnd:position,release:position,inspection:inspectionPolyline(position,reading,position),viewIndex:stationCount+1,viewCount:stationCount+1}};
    visits.push(orbit);cursor+=orbit.duration;viewAngle=endAngle;previousTarget={x:0,y:0};previousAngle=orbit.endAngle;
  }
  if(!options.oneShot){
    const first=visits[1],toAngle=nearestAngle(viewAngle,sector),transfer=creatureExaminationTransfer(previous,first.from,bounds,viewAngle,toAngle,index),duration=(1750+transfer.pathLength*760)*personal;
    visits.push({...classic.visits.at(-1),at:cursor,duration,travel:duration,from:previous,to:first.from,scanTo:first.from,control:first.from,...transfer,
      inspectionTarget:{x:0,y:0},inspectionFromTarget:previousTarget,
      inspectionPhrase:{kind:'return',prepare:first.from,measure:first.from,measureEnd:first.from,release:first.from,viewIndex:stationCount+(options.brief?0:1),viewCount:stationCount+(options.brief?0:1),loopReturn:true},fromAngle:previousAngle,scanAngle:first.fromAngle,endAngle:first.fromAngle,visitIndex:stationCount+(options.brief?0:1)+1});cursor+=duration;
  }
  return {...classic,visits,duration:cursor,initial,scanVisits:stationCount+(options.brief?0:1),examinationMovement:'deliberate'};
}

function gridSites(gridScan,center,radius){
  if(!Array.isArray(gridScan?.cells)||!center||!(radius>0))return null;
  return gridScan.cells.slice(0,SCAN_NATIVE_CELL_LIMIT).filter(c=>Number.isFinite(c.center?.x)&&Number.isFinite(c.center?.y))
    .map((cell,index)=>{const focus=reachableCellFocus(cell,center,radius);return {x:(focus.x-center.x)/radius,y:(focus.y-center.y)/radius,index,gridCell:cell};});
}
function reachableCellFocus(cell,center,radius){
  if(distance(cell.center,center)<=radius*.96)return cell.center;
  const vertices=(cell.polygon??[]).map(p=>Array.isArray(p)?{x:p[0],y:p[1]}:p);let closest=cell.center,best=Infinity;
  for(let i=0;i<vertices.length;i++){
    const a=vertices[i],b=vertices[(i+1)%vertices.length],dx=b.x-a.x,dy=b.y-a.y,t=unit(((center.x-a.x)*dx+(center.y-a.y)*dy)/(dx*dx+dy*dy||1)),p={x:a.x+dx*t,y:a.y+dy*t},d=distance(p,center);
    if(d<best){best=d;closest=p;}
  }
  if(!Number.isFinite(best))return cell.center;
  let lo=0,hi=.2;const limit=Math.max(best,Math.min(radius*.98,radius));
  for(let i=0;i<12;i++){const mid=(lo+hi)/2;if(distance(mix(closest,cell.center,mid),center)<=limit)lo=mid;else hi=mid;}
  return mix(closest,cell.center,lo);
}

function areaCellForVisit(visit,geometry){
  const cells=geometry.gridScan?.cells;
  if(!geometry.utility.followSource)return cells?.find(c=>c.id===visit.gridCellId)??visit.gridCell??null;
  if(!cells?.length)return null;
  const focus={x:geometry.center.x+visit.focus.x*geometry.radius,y:geometry.center.y+visit.focus.y*geometry.radius};
  let nearest=null,score=Infinity;
  for(const cell of cells){
    if(!Number.isFinite(cell.center?.x)||!Number.isFinite(cell.center?.y))continue;
    const candidate=(cell.center.x-focus.x)**2+(cell.center.y-focus.y)**2;
    if(candidate<score-1e-8||Math.abs(candidate-score)<1e-8&&String(cell.id)<String(nearest?.id))nearest=cell,score=candidate;
  }
  return nearest;
}
/** One physical instrument contributes one selected native cell. Cooperative
 * union construction happens once, after all actual sources are sampled. */
function areaCellsForVisit(visit,geometry,anchor=areaCellForVisit(visit,geometry)){return anchor?[anchor]:[];}

/** Compile bounded routes once per job identity. No mutable sampler state means
 * reconnects, observer clocks and scrubbed previews reproduce the same frame. */
export function compileScanPlan(utility={},bits=[],{targetBounds,gridScan,center=utility.center??{x:0,y:0},radius=utility.radiusPixels??100,size=100,examinationMovement=utility.examinationMovement??'deliberate'}={}){
  const mode=utility.mode==='creatureScan'?'creatureScan':'areaScan',seed=scanSeed(utility.seed),ids=bits.slice(0,4);
  // Small contour changes share one blueprint; the live strip still receives
  // exact bounds. The exterior clearance comfortably exceeds this quantization.
  const bounds=mode==='creatureScan'?creatureBounds(targetBounds):null;
  const compiledBounds=bounds?{halfWidth:Math.max(.5,Math.round(bounds.halfWidth*2)/2),halfHeight:Math.max(.5,Math.round(bounds.halfHeight*2)/2)}:null;
  // A following scan keeps the same physical work schedule as its anchor
  // moves. Native cells are selected by each optical pass below, so crossing a
  // roster boundary cannot rebuild the instrument's path or change its clock.
  const v82=utility.scanSpeed!=null||utility.oneShot||utility.brief,gridCells=mode==='areaScan'&&!utility.followSource?gridScan?.cells:null;
  const region=mode==='areaScan'&&!utility.followSource&&utility.region?.points?.length>=3?utility.region.points:null;
  const cellSize=areaCellSize(gridScan,size);
  // The native roster is fully determined by the grid stamp, centre, radius
  // and region, so its array identity is not part of the key: a scene-context
  // cache refill returns an equal roster and must not recompile the plan.
  const key=JSON.stringify([mode,seed,ids,...(mode==='areaScan'?[cellSize,radius,!!utility.followSource]:[]),...(compiledBounds?[compiledBounds,examinationMovement]:[]),...(v82?[true,!!utility.brief,!!utility.oneShot]:[]),...(gridCells?.length?[gridScan?.cacheKey??'',center?.x,center?.y,radius,gridCells.length]:[]),...(region?[region]:[])]);let plan=cachedPlan(key);if(plan)return plan;
  // Grid geometry/focus projection is command-region work, never repeated on
  // a cached animation frame or a fractional movement within the same cells.
  const grid=mode==='areaScan'&&!utility.followSource?gridSites(gridScan,center,radius):null;
  const random=generator(seed),normalizedRegion=region&&center&&radius>0?region.map(p=>({x:(p.x-center.x)/radius,y:(p.y-center.y)/radius})):null;
  const sites=grid?.length?grid:focusSites(mode,random,normalizedRegion);
  if(mode==='areaScan'){
    const origin=utility.followSource?{x:0,y:0}:center;
    const cells=gridCells?.length?gridCells:virtualAreaCells({center:origin,radius,cellSize,region});
    plan=makeCooperativeAreaPlan({cells,center:origin,radius,cellSize,bits:ids,seed,methods:AREA_SCAN_METHODS,random,region});
    if(plan)return rememberPlan(key,plan);
  }
  plan={mode,seed,bits:ids,sites,...(compiledBounds?{targetBounds:compiledBounds}:{}),routes:ids.map((_,i)=>{
    if(mode==='creatureScan')return v82?(examinationMovement==='classic'?makeV82CreatureRoute:makeDeliberateCreatureRoute)(i,ids.length,seed,compiledBounds,utility):makeCreatureRoute(i,ids.length,seed,compiledBounds);
    const assigned=grid?.length?sites.filter((_,j)=>j%ids.length===i):sites,pool=assigned.length?assigned:sites;
    return makeRoute(i,ids.length,mode,seed,pool,grid?.length?Math.max(SCAN_VISITS_PER_BIT,Math.ceil(pool.length/ .8)+4):SCAN_VISITS_PER_BIT);
  })};
  if(mode==='creatureScan'&&v82)plan.sharedSurveyDuration=plan.routes[0]?.loopStart??0;
  return rememberPlan(key,plan);
}
export function clearScanPlanCache(){cache.clear();cachedVisits=0;creatureTemplateCache.clear();}
export function scanPlanCacheSize(){return cache.size;}
/** Render-only follower state, shared by live work and local rehearsal. An
 * emanation keeps a short bounded pursuit lag while the owner moves, without
 * delaying commands, re-planning coverage or writing a token document. */
export function stepScanAnchor(previous,target,now,{radius=100,reduced=false,working=false,size=100,motion=null}={}){
  const next={x:finite(target?.x),y:finite(target?.y),now:finite(now)},r=Math.max(1,finite(radius,100));
  if(reduced||!previous||!Number.isFinite(previous.now)||next.now<previous.now||next.now-previous.now>400||distance(previous,next)>Math.max(180,r*2.5))return next;
  if(working){
    // A following survey owns a neighborhood, rather than a rigid formation
    // attached to Ellie's centre. Keep its cells through an ordinary step;
    // only advance the neighborhood when she actually exceeds its leash.
    const leash=motion?.active?Math.min(r*.24,Math.max(1,size)*.9):Math.min(r*.6,Math.max(1,size)*1.25),d=distance(previous,next),elapsed=Math.min(100,next.now-previous.now),velocity=previous.velocity??{x:0,y:0};
    if(next.now===previous.now||d<=leash&&Math.hypot(velocity.x,velocity.y)<.01)return {...previous,now:next.now};
    const destination=d>leash?{x:next.x-(next.x-previous.x)*leash/d,y:next.y-(next.y-previous.y)*leash/d}:previous;
    const owner=d>leash?(motion?.velocity??{x:0,y:0}):{x:0,y:0};
    const pursuit=stepScanPursuit({velocity},{position:previous,target:destination,velocity:owner,dt:elapsed,size});
    return {...pursuit.position,velocity:pursuit.velocity,now:next.now};
  }
  if(next.now===previous.now){
    // Runtime getters and command captures can sample a frame repeatedly.
    // Keep the same lag instead of snapping on a zero-time re-sample. If a
    // target changes at that instant, only enforce the existing distance cap.
    const d=distance(previous,next),cap=r*.24;
    return d>cap+1e-7?{x:next.x+(previous.x-next.x)*cap/d,y:next.y+(previous.y-next.y)*cap/d,now:next.now}:{...previous};
  }
  const elapsed=Math.min(100,next.now-previous.now),gain=1-Math.exp(-elapsed/145),p=mix(previous,next,gain);
  const d=distance(p,next),cap=r*.24;if(d>cap){p.x=next.x+(p.x-next.x)*cap/d;p.y=next.y+(p.y-next.y)*cap/d;}
  return {...p,now:next.now};
}
function findVisit(route,time){
  // Forty-three bounded work sections: binary lookup at any world clock.
  let lo=0,hi=route.visits.length-1;
  while(lo<hi){const mid=(lo+hi+1)>>1;if(route.visits[mid].at<=time)lo=mid;else hi=mid-1;}
  return route.visits[lo];
}
function curved(from,control,to,t){const q=1-t;return {x:q*q*from.x+2*q*t*control.x+t*t*to.x,y:q*q*from.y+2*q*t*control.y+t*t*to.y};}
function visitPoint(visit,t){
  if(visit.inspectionCurve){const c=visit.inspectionCurve,q=c.weighted?smoother(t):unit(t);if(q===0)return visit.path[0];if(q===1)return visit.path.at(-1);return exteriorInspectionStation(lerp(c.fromAngle,c.toAngle,q),c.bounds,lerp(c.start,c.end,q)-c.lean*Math.sin(Math.PI*q)**2);}
  if(visit.pathLengths===undefined&&visit.path) return visit.path[0];
  if(!visit.path)return curved(visit.from,visit.control,visit.to,t);
  const knots=visit.pathTimes??visit.pathLengths,at=unit(t)*(visit.pathTimes?1:visit.pathLength);let lo=1,hi=visit.path.length-1;
  while(lo<hi){const middle=(lo+hi)>>1;if(knots[middle]<at)lo=middle+1;else hi=middle;}
  const a=knots[lo-1],span=knots[lo]-a;return mix(visit.path[lo-1],visit.path[lo],span?(at-a)/span:1);
}
function polygonBounds(points){
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  for(const p of points){minX=Math.min(minX,p.x);minY=Math.min(minY,p.y);maxX=Math.max(maxX,p.x);maxY=Math.max(maxY,p.y);}
  return {x:minX,y:minY,width:maxX-minX,height:maxY-minY};
}
function regionForVisit(visit,geometry){
  if(visit.scanStage==='survey')return geometry.surveyBounds;
  const b=geometry.targetBounds,r=visit.region??{x:0,y:0,hx:1,hy:1};
  return {x:b.halfWidth*r.x-b.halfWidth*r.hx,y:b.halfHeight*r.y-b.halfHeight*r.hy,width:b.halfWidth*r.hx*2,height:b.halfHeight*r.hy*2};
}
function regionFocus(visit,geometry,progress){
  if(!visit.scanStage)return creatureSweepFocus(geometry.targetBounds,visit.axis,visit.direction,progress);
  const region=regionForVisit(visit,geometry),half={halfWidth:region.width/2,halfHeight:region.height/2},p=creatureSweepFocus(half,visit.axis,visit.direction,progress);
  return {...p,x:p.x+region.x+region.width/2,y:p.y+region.y+region.height/2};
}
function rotated(p,angle){const c=Math.cos(angle),s=Math.sin(angle);return {x:p.x*c-p.y*s,y:p.x*s+p.y*c};}
const SCAN_CUE=.3;
function scanEnvelope(p){return smooth(p/.16)*(1-smooth((p-.81)/.19));}
function toolGeometry(event,context){
  const utility=event.utility??{},mode=utility.mode??'areaScan',park=mode==='parkLight',v82=utility.scanSpeed!=null||utility.oneShot||utility.brief,
    examinationMovement=utility.examinationMovement??context.snapshot?.v8Motion?.examinationMovement??'deliberate';
  const center=mode==='creatureScan'?context.target:utility.followSource?(context.scanCenter??context.source):utility.center??context.target??context.source;
  const size=Math.max(1,finite(context.size,100)),targetWidth=Math.max(1,finite(context.targetWidth,finite(context.targetSize,size))),targetHeight=Math.max(1,finite(context.targetHeight,finite(context.targetSize,size)));
  let radius=mode==='creatureScan'?Math.max(Math.max(targetWidth,targetHeight,finite(context.targetSize,size))*.94,size*(v82&&examinationMovement!=='classic' ? .94 : .67)):Math.max(1,finite(utility.radiusPixels,size));
  const targetScan=context.targetScan;
  const footprint=targetScan?.occupiedFootprint?.polygon,gridSize=finite(context.targetSize,size),fallback=[{x:center.x-gridSize/2,y:center.y-gridSize/2},{x:center.x+gridSize/2,y:center.y-gridSize/2},{x:center.x+gridSize/2,y:center.y+gridSize/2},{x:center.x-gridSize/2,y:center.y+gridSize/2}];
  const worldPolygon=Array.isArray(footprint)&&footprint.length>=3?footprint.map(p=>Array.isArray(p)?{x:p[0],y:p[1]}:p).filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)):fallback;
  if(mode==='creatureScan'&&v82)for(const p of worldPolygon)radius=Math.max(radius,Math.abs(p.x-center.x)/.92,Math.abs(p.y-center.y)/.92);
  const targetBounds=mode==='creatureScan'?{halfWidth:targetWidth/(radius*2)*100,halfHeight:targetHeight/(radius*2)*100}:null,rotation=mode==='creatureScan'?finite(context.targetRotation):0;
  const normalized=polygon=>polygon.map(p=>({x:((p.x??p[0])-center.x)/radius*100,y:((p.y??p[1])-center.y)/radius*100}));
  const surveyPolygon=normalized(worldPolygon),surveyPolygons=(targetScan?.occupiedFootprint?.polygons??[worldPolygon]).filter(p=>p?.length>=3).map(normalized);
  const scanRegionPolygon=mode==='areaScan'&&!utility.followSource&&utility.region?.points?.length>=3?normalized(utility.region.points):null;
  return {utility,mode,park,center,size,radius,targetBounds,rotation,cos:Math.cos(rotation),sin:Math.sin(rotation),v82,surveyPolygon,surveyPolygons,surveyBounds:polygonBounds(surveyPolygons.flat()),gridScan:context.gridScan,scanRegionPolygon,
    examinationMovement};
}
function toolWorld(p,{center,radius,cos:c,sin:s}){return {x:center.x+(p.x*c-p.y*s)*radius,y:center.y+(p.x*s+p.y*c)*radius};}
function opticalChannel(id,p,visit,progress,geometry,extra={}){
  const {gridCell:assignedCell,...artworkExtra}=extra;
  const {mode,targetBounds}=geometry,full=mode==='creatureScan',current=full?regionFocus(visit,geometry,extra.static?.18+.52*.52:progress):null;
  const axis=visit.axis??(Math.abs(Math.cos(visit.scanAngle))>Math.abs(Math.sin(visit.scanAngle))?'x':'y');
  const direction=visit.direction??((axis==='x'?Math.cos(visit.scanAngle):Math.sin(visit.scanAngle))<0?-1:1);
  const survey=visit.scanStage==='survey',cell=assignedCell??visit.gridCell,source=survey?rotated(p,geometry.rotation):p;
  // A gridless following template is already relative to its owner. Preserve
  // those exact coordinates instead of adding and subtracting the moving world
  // anchor, which introduces tiny float changes into otherwise static paint.
  // Real native cells still normalize their current world coordinates exactly.
  const relativeCell=c=>geometry.utility.followSource&&c?.virtual?visit.cooperativeCells?.find(original=>original.id===c.id):null;
  const cells=mode==='areaScan'?areaCellsForVisit(visit,geometry,cell):[],polygons=cells.map(c=>{
    const relative=relativeCell(c),origin=relative?{x:0,y:0}:geometry.center;
    return (relative??c).polygon?.map(v=>({x:((v.x??v[0])-origin.x)/geometry.radius*100,y:((v.y??v[1])-origin.y)/geometry.radius*100}));
  }).filter(p=>p?.length>=3),polygon=polygons[0];
  const relative=relativeCell(cell),focusOrigin=relative?{x:0,y:0}:geometry.center,reachable=cell?reachableCellFocus(relative??cell,focusOrigin,geometry.radius):null;
  const gridFocus=reachable?{x:(reachable.x-focusOrigin.x)/geometry.radius*100,y:(reachable.y-focusOrigin.y)/geometry.radius*100}:null;
  return {id,mode,source:{x:source.x*100,y:source.y*100},focus:full?{x:current.x,y:current.y}:gridFocus??{x:visit.focus.x*100,y:visit.focus.y*100},radius:visit.patch*100,aspect:visit.aspect,tilt:visit.tilt,
    axis,direction,method:visit.method??'structuredLight',visitIndex:visit.visitIndex??0,...(full?{targetBounds:{...targetBounds},sweepTrack:current.track}:{}),
    ...(visit.scanStage?{scanStage:visit.scanStage,frameRotation:survey?0:geometry.rotation,regionBounds:regionForVisit(visit,geometry),...(survey?{regionPolygon:geometry.surveyPolygon,regionPolygons:geometry.surveyPolygons}:{})}:{}),
    ...(polygon?.length?{regionPolygon:polygon,regionPolygons:polygons,regionBounds:polygonBounds(polygons.flat()),gridCellId:cell.id,gridCellIds:cells.map(c=>c.id),clipRadius:100,scanStage:'area'}:{}),
    ...(geometry.scanRegionPolygon?{scanRegionPolygon:geometry.scanRegionPolygon}:{}),exposureVariant:(visit.visitIndex??0)%3,
    // Assignment metadata belongs to encounter/completion routing, not artwork
    // identity. Its world positions must not invalidate an unchanged texture.
    plane:'front',detailPass:visit.detailPass,...artworkExtra};
}
function scanBounds(channels,mode,targetBounds){
  if(mode!=='creatureScan')return {x:-132,y:-132,width:264,height:264};
  let x=targetBounds.halfWidth+14,y=targetBounds.halfHeight+14;
  for(const channel of channels){
    const angle=channel.frameRotation??0,source=rotated(channel.source,angle);x=Math.max(x,Math.abs(source.x)+18);y=Math.max(y,Math.abs(source.y)+18);
    if(channel.regionBounds){const b=channel.regionBounds;for(const p of [{x:b.x,y:b.y},{x:b.x+b.width,y:b.y},{x:b.x+b.width,y:b.y+b.height},{x:b.x,y:b.y+b.height}]){const q=rotated(p,angle);x=Math.max(x,Math.abs(q.x)+14);y=Math.max(y,Math.abs(q.y)+14);}}
  }
  // Radius includes the full portrait footprint; exterior stations and optics
  // stay inside the renderer's 280-unit canvas even on very wide/tall tokens.
  x=Math.min(132,Math.ceil(x));y=Math.min(132,Math.ceil(y));return {x:-x,y:-y,width:x*2,height:y*2};
}

/** Command preflight routes to the exact instrument arrival, rather than the
 * area center. This is also the source of the live sampler's first station. */
export function bitToolDestinations(event,context){
  const geometry=toolGeometry(event,context),{utility,park,targetBounds}=geometry,bits=(event.bits??[]).slice(0,4),stations=(event.formationBits??bits).slice(0,4),plan=park?null:compileScanPlan(utility,stations,geometry);
  return Object.fromEntries(bits.map((id,i)=>{const index=Math.max(0,stations.indexOf(id)),p=park?{x:(index-(stations.length-1)/2)*.17,y:-.04}:plan.routes[index].initial;return [id,toolWorld(p,geometry)];}));
}
export function scanArrivalTimes(event,context){
  const geometry=toolGeometry(event,context),stations=event.formationBits??event.bits??[],plan=compileScanPlan(event.utility,stations,geometry),beginning=(event.started??0)+(event.travelDuration??900);
  return Object.fromEntries((event.bits??[]).map(id=>[id,beginning+(plan.routes[Math.max(0,stations.indexOf(id))]?.delay??0)]));
}
/** Finite encounter lifetime, excluding the caller's separate return leg. */
export function creatureEncounterVirtualDuration(event,context){
  const geometry=toolGeometry(event,context),stations=event.formationBits??event.bits??[],plan=compileScanPlan({...event.utility,mode:'creatureScan',oneShot:true,brief:true},stations,geometry);
  return Math.max(0,...plan.routes.map(route=>route.delay*(event.utility?.scanSpeed??1)+route.duration));
}
export function creatureEncounterDuration(event,context){return Math.max(0,event.travelDuration??650)+creatureEncounterVirtualDuration(event,context)/scanSpeed(event.scanClock?.speed??event.utility?.scanSpeed);}

/** One coverage itinerary ends after its final quiet release, before the
 * decorative loop-closing transit. Lifecycle owns actual observed coverage. */
export function areaSurveyVirtualDuration(event,context){
  const geometry=toolGeometry(event,context),plan=compileScanPlan(event.utility,event.formationBits??event.bits??[],geometry);
  return Math.max(0,...plan.routes.map(route=>Math.max(0,...route.visits.filter(visit=>visit.scan>0).map(visit=>visit.at+visit.travel+visit.settle+visit.scan+visit.release))));
}
export function areaSurveyCellIds(event,context){
  const geometry=toolGeometry(event,context),plan=compileScanPlan(event.utility,event.formationBits??event.bits??[],geometry);
  return [...new Set((plan.sites??[]).map(site=>site.gridCell?.id).filter(Boolean))];
}

/** Cells belong to formation slots of the working crew. A member that steps
 * out (diverted to a creature, or rejoining) leaves its own cell unexposed;
 * colleagues keep theirs mid-pass instead of shifting along the row. */
function cooperativeAssignment(visit,cycle,event,geometry,plan,crew,present){
  if(!visit)return {};
  const cells=cooperativeVisitCells(visit,geometry,{cycle,count:crew.length}),partitions=cooperativeVisitTeamCounts(visit,{cycle,count:cells.length,cells}),shapes=cooperativeVisitTeamShapes(visit,{cells}),result={};let cursor=0;
  for(let teamIndex=0;teamIndex<partitions.length;teamIndex++){
    const slots=crew.slice(cursor,cursor+partitions[teamIndex]),ids=slots.filter(id=>present.has(id));
    if(ids.length){
      const scanVisit=`${cycle}:${visit.visitIndex}:team-${teamIndex}`,ordinal=cycle*plan.routes[0].scanVisits+visit.visitIndex;
      const method=heldScanMethod(event,ids[0],scanVisit,selectScanMethod(event.utility,'area',ordinal+teamIndex,plan.seed));
      const shape=shapes[teamIndex]==='block'&&ids.length<slots.length?'partialBlock':shapes[teamIndex];
      slots.forEach((id,k)=>{if(present.has(id))result[id]={cell:cells[cursor+k],method,scanVisit,teamIndex,teamShape:shape};});
    }
    cursor+=partitions[teamIndex];
  }
  return result;
}
/** Optical bearings are requested more than once while a housing, its focus
 * marker and its work surface are prepared. Reuse only identical arguments
 * within this one sample; the next displayed frame always starts fresh. */
function channelAim(id,source,visit,progress,geometry,cell,method){
  const entries=geometry.opticalAims??= [];
  for(const entry of entries)if(entry.id===id&&entry.visit===visit&&entry.progress===progress&&entry.x===source.x&&entry.y===source.y&&entry.cell===cell&&entry.method===method)return entry.aim;
  const aim=scanArtworkAim(opticalChannel(id,source,visit,progress,geometry,{progress,...(cell?{gridCell:cell,method}:{})}));
  entries.push({id,visit,progress,x:source.x,y:source.y,cell,method,aim});return aim;
}
function cooperativeAim(id,source,visit,progress,geometry,assignment){
  if(!assignment?.cell)return null;
  return channelAim(id,source,visit,progress,geometry,assignment.cell,assignment.method);
}

function creatureVisit(event,id,visit,cycle,route,geometry){
  if(visit.scanStage!=='close')return visit;
  const entries=geometry.creatureVisits??= [];
  for(const entry of entries)if(entry.id===id&&entry.visit===visit&&entry.cycle===cycle)return entry.resolved;
  const scanVisit=`${cycle}:${visit.visitIndex}`,ordinal=cycle*(route.scanVisits??SCAN_VISITS_PER_BIT)+visit.visitIndex-1;
  const method=heldScanMethod(event,id,scanVisit,selectScanMethod(event.utility,'creature',ordinal,event.utility.seed??0));
  const resolved=method===visit.method?visit:{...visit,method};entries.push({id,visit,cycle,resolved});return resolved;
}

/** Position units are scene pixels; scan channels use normalized 100-radius
 * artwork coordinates. Context is the existing bit action renderer context. */
export function sampleBitTool(event,now,context,state=null){
  const geometry=toolGeometry(event,context),{utility,mode,park,center,size,radius,targetBounds,rotation}=geometry,bits=(event.bits??[]).slice(0,4);
  now=Math.min(finite(now),event.conditionPausedAt??Infinity);
  if(Number.isFinite(event.taskPausedAt)&&event.taskPausedPose&&event.status!=='returning'){
    const capture=event.taskPausedPose,positions={},rotations={},depths={},glows={},coreStates={},tools={},phases={},scanPurpose={};
    // Renderers sample shallow copies ({...event}) every frame; the utility
    // object survives those copies, so it owns the capture (with id + clock).
    const pauseOwner=event.utility&&typeof event.utility==='object'?event.utility:event;
    let held=pausedExaminations.get(pauseOwner);
    if(held&&(held.id!==event.id||held.at!==event.taskPausedAt))held=null;
    if(mode==='creatureScan'&&utility.examinationMovement!=='classic'&&!held){
      // The saved pause clock already identifies the exact mechanism phrase.
      // Derive it once without expanding the persisted pose schema or running
      // any wall planner; paused display frames reuse this small local capture.
      const frozen=sampleBitTool({...event,taskPausedPose:null},event.taskPausedAt,context,state);
      held={id:event.id,at:event.taskPausedAt,coreStates:frozen.coreStates,tools:frozen.tools,scanPurpose:frozen.scanPurpose};pausedExaminations.set(pauseOwner,held);
    }
    for(const id of bits){
      positions[id]={...(capture.positions?.[id]??context.origins?.[id]??context.source)};
      rotations[id]=(capture.rotations?.[id]??0)-(context.transform?.angle??0)-(context.orientations?.[id]??0);
      depths[id]=capture.depths?.[id]??.8;glows[id]={strength:.3,color:context.snapshot?.gems?.color??'#ff62df',mode:'core'};
      coreStates[id]=held?.coreStates[id]?.examination?held.coreStates[id]:{state:'settling',amount:.12,progress:1};if(held?.tools[id]&&coreStates[id].examination)tools[id]=held.tools[id];phases[id]={phase:'paused',progress:0};if(held?.scanPurpose?.[id])scanPurpose[id]=held.scanPurpose[id];
    }
    return {positions,rotations,depths,glows,coreStates,tools,scanPurpose,effects:[],intents:[],focuses:[],state:{phase:'paused',progress:0},phases,completedCells:{},scanComplete:false,effectCenter:{...center},effectScale:radius/size,scanWorking:0,scanRadius:radius};
  }
  const age=Math.max(0,finite(now)-finite(event.started)),travelDuration=Math.max(1,finite(event.travelDuration,900)),reduced=!!context.snapshot?.effective?.reducedMotion;
  const quietOnce=reduced&&utility.scanMode==='once';
  const weighty=context.snapshot?.v8Motion?.weightedTravel??(utility.weighty!==false);
  const color=context.snapshot?.gems?.color??context.snapshot?.options?.color??'#ff62df';
  const positions={},rotations={},glows={},depths={},coreStates={},tools={},phases={},channels=[],intents=[],focuses=[],completedCells={},scanWallWork={},scanPurpose={};
  const stations=(event.formationBits??bits).slice(0,4),plan=park?null:compileScanPlan(utility,stations,geometry),world=p=>toolWorld(p,geometry);
  const sharedSurvey=plan?.sharedSurveyDuration??0,cooperative=!!plan?.cooperative;
  // The fastest available instrument owns the collective acquisition clock.
  // Taking every instrument for medicine freezes it at their saved yield edge;
  // taking one leaves its colleagues' survey undisturbed. Monotonic personal
  // pause clocks make this collective clock monotonic as well.
  const collective=[...new Set([...bits,...(event.yieldedBits??[])])].slice(0,4);
  const sharedWork=cooperative&&reduced&&!quietOnce?0:sharedSurvey||cooperative?Math.max(0,...collective.map(id=>scanBitClock(event,now,id)-(event.scanStartElapsed?.[id]??0))):0;
  // The crew is the working roster in formation order: yielded (borrowed)
  // bits leave it, so the remaining team regroups over later laps. Diverted
  // or rejoining members keep their slot and simply do not expose its cell.
  const crew=cooperative?[...stations.filter(id=>bits.includes(id)),...bits.filter(id=>!stations.includes(id))]:[];
  const present=new Set(crew.filter(id=>event.scanPausedAt?.[id]==null&&!(event.utilityReentries?.[id]&&now<event.utilityReentries[id].at+Math.max(1,event.utilityReentries[id].duration??900))));
  const sharedRoute=cooperative?plan.routes[0]:null,areaCycle=sharedRoute?Math.floor(Math.max(0,sharedWork)/sharedRoute.duration):0;
  const sharedTime=sharedRoute?Math.max(0,sharedWork)%sharedRoute.duration:0,sharedVisit=sharedRoute?findVisit(sharedRoute,sharedTime):null;
  const assignments=cooperative?cooperativeAssignment(sharedVisit,areaCycle,event,geometry,plan,crew,present):{};
  const cooperativeCellById=Object.fromEntries(Object.entries(assignments).map(([id,job])=>[id,job.cell]));
  let working=0;
  for(let i=0;i<bits.length;i++){
    const id=bits[i],stationIndex=Math.max(0,stations.indexOf(id)),route=plan?.routes[stationIndex],initial=park?{x:(stationIndex-(stations.length-1)/2)*.17,y:-.04}:route.initial;
    const destination=world(initial),origin=event.originsWorld?.[id]??context.origins?.[id]??context.source;
    let p=initial,angle=park?-Math.PI/2:route.visits[0].fromAngle,phase='waiting',progress=0,activity={state:'settling',amount:.25,progress:0},toolAmount=0;
    const delay=park?i*55:route.delay,arrival=travelDuration+delay;
    const localWork=park?0:scanBitClock(event,now,id)-(event.scanStartElapsed?.[id]??route.delay*(utility.scanSpeed??1));
    const globalWork=sharedSurvey||cooperative?sharedWork:localWork;
    // A borrowed bit can resume a personal close pass, but the occupied grid
    // assessment belongs to the whole job and is never replayed on its clock.
    const work=cooperative?sharedWork:sharedSurvey?(globalWork<sharedSurvey?globalWork:Math.max(sharedSurvey,localWork)):localWork;
    let sampledVisit=null,sampledTime=0,cycle=0;
    const initialAim=geometry.v82&&mode==='creatureScan'?regionFocus(route.visits[0],geometry,0):null;
    const initialAngle=initialAim?bearing(rotated(initial,rotation),{x:initialAim.x/100,y:initialAim.y/100}):park?-Math.PI/2:route.visits[0].fromAngle+rotation;
    if(age<arrival){
      const rawDeparture=unit((age-delay)/travelDuration),departureDelay=cooperative&&!reduced?(route.visits[0].naturalMotion?.departureDelay??0):0,departureSpan=cooperative&&!reduced?(route.visits[0].naturalMotion?.departureSpan??1-departureDelay):1,q=unit((rawDeparture-departureDelay)/departureSpan),t=weighty?smoother(q):smooth(q),bend=reduced?0:Math.sin(Math.PI*t)*Math.min(size*.12,distance(origin,destination)*.075)*(i%2?1:-1);
      const savedRoute=event.travelRoutes?.[id];
      if(savedRoute){const transit=sampleWeightedTransit(origin,destination,q,{route:savedRoute,index:i,size,duration:travelDuration,enabled:weighty,reduced});positions[id]={x:transit.x,y:transit.y};}
      else{const worldPosition=mix(origin,destination,t);worldPosition.y-=bend;positions[id]=worldPosition;}
      const aimed=bearing(origin,destination),from=(event.originRotations?.[id]??0)+(context.transform?.angle??0)+(context.orientations?.[id]??0)-Math.PI/2;
      angle=angleMix(from,aimed,smooth(q/.32));angle=angleMix(angle,initialAngle,smooth((q-.7)/.3));
      phase=cooperative&&q>=1?'waiting':'travel';progress=q;activity={state:'encased',amount:.34*Math.sin(Math.PI*q),progress:q};
    }else if(park){
      positions[id]=destination;phase='illuminating';progress=1;activity={state:'open',amount:.25,progress:1};
    }else if(work<0){positions[id]=destination;phase='waiting';angle=initialAngle-rotation;}
    else if(route.oneShot&&work>=route.duration){
      const last=mode==='creatureScan'?creatureVisit(event,id,route.visits.at(-1),0,route,geometry):route.visits.at(-1);sampledVisit=last;sampledTime=route.duration;p=last.scanTo??last.to;positions[id]=world(p);const aim=mode==='creatureScan'?channelAim(id,p,last,1,geometry):null;angle=aim?bearing(p,{x:aim.x/100,y:aim.y/100}):last.endAngle;phase='complete';progress=1;activity={state:'settling',amount:.1,progress:1};
    }else if(reduced&&!quietOnce){
      // Quiet mode retains the chosen jobs, actual source positions and a
      // beautiful static examination surface without wandering or flashes.
      const raw=cooperative?route.visits[sharedVisit.visitIndex]:sharedSurvey&&work<sharedSurvey?route.visits[0]:route.visits[Math.min(stationIndex+2,route.visits.length-1)],visit=mode==='creatureScan'?creatureVisit(event,id,raw,0,route,geometry):raw;sampledVisit=visit;p=visit.to;positions[id]=world(p);const aim=mode==='creatureScan'?channelAim(id,p,visit,.52,geometry):null;angle=aim?bearing(p,{x:aim.x/100,y:aim.y/100}):visit.scanAngle;phase='scanning';progress=.52;
      activity={state:'scanning',amount:.32,progress};toolAmount=.35;working++;
      if((!cooperative||cooperativeCellById[id])&&(visit.scanStage!=='survey'||id===bits[0]))channels.push(opticalChannel(id,p,visit,.52,geometry,{strength:.43,progress:.52,static:true,gridCell:mode==='areaScan'?(cooperative?cooperativeCellById[id]:areaCellForVisit(visit,geometry)):undefined}));
    }else{
      const loopStart=route.loopStart??0,loopDuration=route.duration-loopStart;
      cycle=route.oneShot?0:work<route.duration?0:Math.floor((work-loopStart)/loopDuration);
      const time=route.oneShot?Math.min(work,route.duration-.000001):work<route.duration?work:loopStart+(work-loopStart)%loopDuration;
      const raw=findVisit(route,time),visit=mode==='creatureScan'?creatureVisit(event,id,raw,cycle,route,geometry):raw,local=time-visit.at;sampledVisit=visit;sampledTime=time;
      const cell=mode==='areaScan'?(cooperative?cooperativeCellById[id]:areaCellForVisit(visit,geometry)):null,reachable=cell?reachableCellFocus(cell,center,radius):null,areaFocus=reachable?{x:(reachable.x-center.x)/radius,y:(reachable.y-center.y)/radius}:visit.focus;
      const aimFor=(raw,q)=>{const v=mode==='creatureScan'?creatureVisit(event,id,raw,cycle,route,geometry):raw;return v.scanStage==='close'&&v.method&&v.method!=='structuredLight'?channelAim(id,v.swirl?visitPoint(v.swirl,smoother(q)):v.to,v,q,geometry):regionFocus(v,geometry,q);};
      const targetAngle=(v,end=false)=>{const aim=aimFor(v,end?1:0),source=v.scanStage==='survey'?rotated(v.to,rotation):end?v.scanTo??v.to:v.to;return bearing(source,{x:aim.x/100,y:aim.y/100})-(v.scanStage==='survey'?rotation:0);};
      const areaAim=(q,v=visit,job=assignments[id],source=v.to)=>cooperativeAim(id,source,v,q,geometry,job),personal=cooperative?cooperativePersonalTiming(visit,local):null;
      const firstAreaAim=areaAim(0),finalAreaAim=areaAim(1);
      const loopArrivalAngle=route.examinationMovement==='deliberate'&&visit.scanStage==='close'&&visit.scan===0?targetAngle(route.visits[0],true):null;
      const scanAngle=loopArrivalAngle??(mode==='creatureScan'&&visit.scan>0?targetAngle(visit):firstAreaAim?bearing(visit.to,{x:firstAreaAim.x/100,y:firstAreaAim.y/100}):cell?bearing(visit.to,areaFocus):visit.scanAngle);
      const endAngle=loopArrivalAngle??(mode==='creatureScan'&&visit.scan>0?targetAngle(visit,true):finalAreaAim?bearing(visit.to,{x:finalAreaAim.x/100,y:finalAreaAim.y/100}):visit.endAngle);
      let fromAngle=mode==='creatureScan'&&visit.visitIndex>0?targetAngle(route.visits[visit.visitIndex-1],true):visit.fromAngle;
      if(cooperative&&visit.visitIndex>0){
        const previous=route.visits[visit.visitIndex-1],prior=cooperativeAssignment(previous,cycle,event,geometry,plan,crew,present);
        // An unassigned observer has no previous optical job. Passing its
        // absent assignment through areaAim's default would aim its old pose
        // at the NEW cell, snapping its housing before travel can turn it.
        const aim=cooperativeAim(id,previous.to,previous,1,geometry,prior[id]);
        fromAngle=aim?bearing(previous.to,{x:aim.x/100,y:aim.y/100}):previous.endAngle??previous.scanAngle;
      }

      if(local<visit.travel){
        progress=personal?personal.approach:unit(local/visit.travel);const t=visit.inspectionPhrase?progress:weighty?smoother(progress):smooth(progress);p=visitPoint(visit,t);
        const tangent=bearing(visitPoint(visit,Math.max(0,t-.003)),visitPoint(visit,Math.min(1,t+.003)));
        angle=angleMix(fromAngle,tangent,smooth(progress/.25));angle=angleMix(angle,scanAngle,smooth((progress-.72)/.28));
        phase='moving';activity={state:'encased',amount:.3*Math.sin(Math.PI*progress),progress};
        if(personal&&progress>=1){
          progress=personal.settle;phase='settling';const opening=smooth(progress);activity={state:'charging',amount:1,progress,coreChannels:{open:.18*opening,charge:.4*opening}};toolAmount=.58*opening;
        }
      }else if(local<visit.travel+visit.settle){
        progress=personal?personal.settle:unit((local-visit.travel)/visit.settle);p=visit.inspectionPhrase?mix(visit.to,visit.inspectionPhrase.measure,smoother(progress)):visit.to;angle=scanAngle;
        phase='settling';const opening=smooth(progress);activity={state:'charging',amount:1,progress,coreChannels:{open:.18*opening,charge:.4*opening}};toolAmount=.58*opening;
      }else if(local<visit.travel+visit.settle+visit.scan){
        progress=unit((local-visit.travel-visit.settle)/visit.scan);p=reduced?visit.to:cooperative?sampleCooperativeInspection(visit,progress):visit.swirl?visitPoint(visit.swirl,smoother(progress)):visit.to;
        const aim=cooperative?areaAim(progress,visit,assignments[id],p):mode==='creatureScan'?aimFor(visit,progress):null,source=visit.scanStage==='survey'?rotated(p,rotation):p;angle=aim?bearing(source,{x:aim.x/100,y:aim.y/100})-(visit.scanStage==='survey'?rotation:0):scanAngle;
        phase='scanning';const envelope=scanEnvelope(progress);activity={state:'scanning',amount:1,progress,coreChannels:{open:.18+.02*smooth(progress),charge:.4*(1-smooth(progress/.2))+.15*smooth((progress-.8)/.2),scan:.65*envelope}};toolAmount=.58;
        if(!cooperative||cell)working++;else{phase='observing';activity={state:'settling',amount:.15,progress};toolAmount=0;}
        const sourceStrength=cooperative?(reduced?.94:.89+.1*Math.sin((visit.naturalMotion?.lightPhase??0)+progress*Math.PI)):1;
        if((!cooperative||cell)&&(visit.scanStage!=='survey'||id===bits[0]))channels.push(opticalChannel(id,p,visit,reduced?.52:progress,geometry,{strength:reduced?.43:Math.max(SCAN_CUE,envelope*(visit.detailPass?.83:.72)),progress:reduced?.52:progress,...(reduced?{static:true}:{}),gridCell:cell,...(cooperative?{method:assignments[id]?.method,sourceStrength}:{} )}));
      }else{
        progress=personal?personal.release:unit((local-visit.travel-visit.settle-visit.scan)/Math.max(1,visit.release));p=visit.inspectionPhrase?mix(visit.inspectionPhrase.measureEnd??visit.inspectionPhrase.measure,visit.scanTo??visit.to,smoother(progress)):visit.scanTo??visit.to;angle=mode==='creatureScan'||cooperative?endAngle:scanAngle;
        phase=personal&&progress>=1?'observing':'closing';const closing=1-smooth(progress);activity={state:'settling',amount:1,progress,coreChannels:{open:.2*closing,charge:.15*closing}};toolAmount=.58*closing;
      }
      // Between exposures a faint registration stays on the next region, so
      // a scan never looks idle while its instruments relocate.
      if(!reduced&&['moving','settling','closing'].includes(phase)&&(!cooperative||cell)&&(visit.scanStage!=='survey'||id===bits[0])){
        const first=cycle===0&&visit.visitIndex===route.visits[0].visitIndex&&phase==='moving'?smooth(progress):1;
        const last=route.oneShot&&visit.visitIndex===route.visits.at(-1).visitIndex&&phase==='closing'?1-smooth(progress):1;
        const cue=SCAN_CUE*first*last;
        if(cue>.004)channels.push(opticalChannel(id,p,visit,.52,geometry,{strength:cue,progress:.52,static:true,gridCell:cell,...(cooperative?{method:assignments[id]?.method}:{})}));
      }
      if(visit.inspectionPhrase){
        const phrase=visit.inspectionPhrase,base=cycle*phrase.viewCount,turnFrom=base+phrase.viewIndex-(phrase.loopReturn?0:1),turn=turnFrom+(phrase.loopReturn?0:smoother((progress-.175)/.65));
        const transfer=phase==='moving',phrasePhase=phrase.loopReturn?'release':transfer?(progress<.175?'acquire':progress<.825?'turn':'settle'):phase==='scanning'?'measure':phase==='closing'?'release':'settle';
        const phraseProgress=phrase.loopReturn?1:transfer?(progress<.175?unit(progress/.175):progress<.825?unit((progress-.175)/.65):unit((progress-.825)/.175)*.3):phase==='settling'?.3+.7*progress:progress;
        const entrance=cycle===0&&phrase.viewIndex===1&&transfer?smoother(progress):1,exit=route.oneShot&&phrase.viewIndex===phrase.viewCount&&phase==='closing'?1-smoother(progress):1;
        activity.examination={phase:phrasePhase,progress:phraseProgress,viewIndex:phrase.viewIndex,weight:entrance*exit,turn:transfer?turn:base+phrase.viewIndex};
        // Housing aim follows the same held optical focus during acquisition
        // and withdrawal; switching from its outer to inner station cannot
        // introduce a one-frame heading change at an exposure edge.
        if(phase==='settling'||phase==='closing'){
          const aim=aimFor(visit,phase==='settling'?0:1);angle=bearing(p,{x:aim.x/100,y:aim.y/100});
        }
      }
      positions[id]=world(p);
      if(phase==='settling'||phase==='scanning'||phase==='closing'){
        const aim=cooperative?areaAim(phase==='settling'?0:phase==='closing'?1:progress,visit,assignments[id],p):mode==='creatureScan'?aimFor(visit,phase==='settling'?0:phase==='closing'?1:progress):null;
        const target=visit.scanStage==='survey'&&aim?{x:center.x+aim.x/100*radius,y:center.y+aim.y/100*radius}:world(aim?{x:aim.x/100,y:aim.y/100}:areaFocus);focuses.push({station:id,focus:{target:[target.x,target.y,1],strength:.7}});
      }
    }
    if(mode==='creatureScan'&&sampledVisit?.inspectionPhrase){
      const visit=sampledVisit,transferring=phase==='moving',target=transferring?stationTarget(Math.atan2(p.y,p.x),targetBounds):visit.inspectionTarget??{x:0,y:0};
      scanPurpose[id]={target:world(target),kind:transferring?'relocating':visit.inspectionPhrase.kind==='parallax'&&phase==='scanning'?'orbit':'reading',stationIndex:visit.inspectionPhrase.viewIndex};
    }
    if(mode==='areaScan'&&(!reduced||quietOnce)&&sampledVisit){
      const visit=sampledVisit,scanEnd=visit.at+visit.travel+visit.settle+visit.scan;
      const scanVisits=route.scanVisits??SCAN_VISITS_PER_BIT;
      let index=Math.min(scanVisits-1,visit.visitIndex-(sampledTime<scanEnd?1:0)),previousCycle=cycle;
      if(index<0&&previousCycle>0){index=scanVisits-1;previousCycle--;}
      if(index>=0){
        const completed=route.visits[index],priorCells=cooperative?cooperativeVisitCells(completed,geometry,{cycle:previousCycle,count:crew.length}):null,cell=cooperative?(present.has(id)?priorCells[crew.indexOf(id)]:null):areaCellForVisit(completed,geometry),cells=areaCellsForVisit(completed,geometry,cell),focus=cell?.center??world(completed.focus),patch=completed.patch*radius;
        if(!cooperative||cell)completedCells[id]={ordinal:previousCycle*scanVisits+index,visitIndex:index,id:cell?.id??`patch-${index}`,gridCellId:cell?.id??null,center:{x:focus.x,y:focus.y},
          ...(cell?.polygon?{polygon:cell.polygon,cells,gridCellIds:cells.map(c=>c.id)}:{}),clipCircle:{center:{...center},radius},
          ...(geometry.scanRegionPolygon?{scanRegionPolygon:utility.region.points}:{}),method:completed.method??'structuredLight',bounds:cell?.bounds??{x:focus.x-patch,y:focus.y-patch*completed.aspect,width:patch*2,height:patch*completed.aspect*2}};
      }
    }
    if(context.scanWalls&&!park){
      const visit=sampledVisit??route.visits[0],cell=mode==='areaScan'?(cooperative?cooperativeCellById[id]:areaCellForVisit(visit,geometry)):null;
      const bounds=geometry.targetBounds,portrait=mode==='creatureScan'?[
        {x:-bounds.halfWidth/100,y:-bounds.halfHeight/100},{x:bounds.halfWidth/100,y:-bounds.halfHeight/100},
        {x:bounds.halfWidth/100,y:bounds.halfHeight/100},{x:-bounds.halfWidth/100,y:bounds.halfHeight/100}].map(world):null;
      const footprint=visit.scanStage==='survey'?geometry.surveyPolygons.map(p=>p.map(q=>({x:center.x+q.x*radius/100,y:center.y+q.y*radius/100}))):portrait?[portrait]:null;
      const footprintCell=footprint?{id:`portrait:${event.target??event.id}`,center:{...center},polygon:footprint[0],cells:footprint.map(polygon=>({polygon}))}:null;
      const inspection=visit.inspectionPhrase?(visit.inspectionPhrase.inspection?.path??[visit.to,visit.inspectionPhrase.measure,visit.scanTo??visit.to]).map(world):Array.from({length:13},(_,n)=>{const q=n/12,p=cooperative?sampleCooperativeInspection(visit,q):visit.swirl?visitPoint(visit.swirl,smoother(q)):visit.to;return world(p);});
      const inspectionProgress=visit.inspectionPhrase?.inspection?phraseInspectionProgress(visit.inspectionPhrase,phase,progress):visit.inspectionPhrase?phase==='complete'?1:0:phase==='scanning'?progress:['closing','complete'].includes(phase)?1:0;
      scanWallWork[id]={key:`${cycle}:${visit.visitIndex}:${cell?.id??visit.scanStage??mode}`,from:age<arrival?origin:world(visit.from),station:world(visit.to),
        focus:cell?.center??(mode==='creatureScan'?{...center}:world(visit.focus)),cell:cell??footprintCell,inspection,inspectionPosition:positions[id],
        ...(mode==='creatureScan'&&route.examinationMovement==='deliberate'&&portrait?{portraitPolygon:portrait,portraitClearance:radius*.17,...(visit.inspectionPhrase?{approach:visit.path?.map(world)}:{})}:{}),
        inspectionProgress,phase,progress,initialTravel:age<arrival};
    }
    phases[id]={phase,progress,...(sampledVisit?{scanStage:sampledVisit.scanStage??'area',visitIndex:sampledVisit.visitIndex,scanVisit:`${cycle}:${sampledVisit.visitIndex}`,method:sampledVisit.method??'structuredLight',ordinal:cycle*(route.scanVisits??SCAN_VISITS_PER_BIT)+sampledVisit.visitIndex,...(sampledVisit.gridCellId?{gridCellId:sampledVisit.gridCellId}:{})}:{})};rotations[id]=angle+(phase==='travel'?0:rotation)+Math.PI/2-(context.transform?.angle??0)-(context.orientations?.[id]??0);
    depths[id]=mode==='creatureScan'?(positions[id].y<center.y-size*.12?-.55:.7):.8;
    const glow=phase==='scanning'?(reduced?.7:.8+.32*scanEnvelope(progress)):phase==='settling'?.45+.35*smooth(progress):phase==='closing'?.8-.35*smooth(progress):.45;
    glows[id]={strength:glow,color,mode:'core'};coreStates[id]=activity;
    if(toolAmount>.001)tools[id]={type:'lens',amount:toolAmount,progress};
    const reentry=event.utilityReentries?.[id];
    if(reentry&&now<reentry.at+Math.max(1,reentry.duration??900)){
      const q=unit((now-reentry.at)/Math.max(1,reentry.duration??900)),to=positions[id];
      const transit=sampleWeightedTransit(reentry.from,to,q,{index:stationIndex,size,duration:reentry.duration??900,enabled:weighty,reduced,
        fromRotation:reentry.fromRotation??rotations[id],toRotation:rotations[id]});
      positions[id]={x:transit.x,y:transit.y};rotations[id]=transit.rotation;depths[id]=lerp(reentry.fromDepth??depths[id],depths[id],smooth(q));
      // Instruments prepare their continuing duty while braking. The surface
      // still stays withdrawn until arrival, but shell/tool/light channels
      // meet the current work state exactly without a final-frame pop.
      const gain=smooth((q-.78)/.22),targetCore=coreStates[id],targetChannels=sampleCoreState({activity:targetCore}),coreChannels={};
      for(const key of ['encase','open','charge','guard','settle','scan','brace','align','rest','conduct'])coreChannels[key]=(targetChannels[key]??0)*gain;
      coreChannels.encase+=.24*Math.sin(Math.PI*q)*(1-gain);
      coreStates[id]={state:targetCore.state,amount:1,progress:targetCore.progress,coreChannels,...(targetCore.examination?{examination:{...targetCore.examination,weight:targetCore.examination.weight*gain}}:{})};glows[id].strength=lerp(.45,glows[id].strength,gain);
      if(tools[id]){tools[id]={...tools[id],amount:tools[id].amount*gain};if(tools[id].amount<.001)delete tools[id];}
      const channel=channels.findIndex(c=>c.id===id);if(channel>=0){channels.splice(channel,1);working--;}
      for(let k=focuses.length-1;k>=0;k--)if(focuses[k].station===id)focuses.splice(k,1);
      phases[id]={phase:'rejoining',progress:q};
    }
  }
  if(cooperative&&channels.length){
    const available=[...channels],ordinal=areaCycle*(sharedRoute.scanVisits??1)+(sharedVisit?.visitIndex??0),teams=[...new Set(available.map(channel=>assignments[channel.id]?.teamIndex))];channels.length=0;
    for(const teamIndex of teams){
      const team=available.filter(channel=>assignments[channel.id]?.teamIndex===teamIndex);
      const scanVisit=`${areaCycle}:${sharedVisit?.visitIndex??0}:team-${teamIndex}`,method=heldScanMethod(event,team[0].id,scanVisit,selectScanMethod(utility,'area',ordinal+teamIndex,plan.seed));
      const leading=team[0],polygons=team.flatMap(c=>c.regionPolygons??[]),sources=team.map(c=>({id:c.id,x:c.source.x,y:c.source.y,strength:c.sourceStrength??1,focus:{...c.focus},gridCellId:c.gridCellId,regionPolygon:c.regionPolygon,regionBounds:c.regionBounds}));
      // Each actual bit contributes one cell; branching teams never paint
      // another team's work or retain an old field through quiet transit.
      channels.push({...leading,method,id:`area-team-${teamIndex}`,cooperative:team.length>1,teamIndex,teamShape:assignments[team[0].id]?.teamShape??'row',sources,source:{x:sources[0].x,y:sources[0].y},cellCount:sources.length,
        strength:leading.strength*(team.length===1?.70:.88),regionPolygon:polygons[0],regionPolygons:polygons,regionBounds:polygonBounds(polygons.flat()),gridCellIds:team.flatMap(c=>c.gridCellIds??[])});
      for(const source of sources){if(phases[source.id])Object.assign(phases[source.id],{method,scanVisit});}
    }
  }
  const scanState={phase:age<travelDuration?'travel':park?'illuminating':'investigating',progress:unit(age/travelDuration)};
  return {positions,rotations,depths,glows,coreStates,tools,effects:channels.length?[{effect:'v8-scan',mode,channels,color,strength:1,detail:utility.detail??event.detail??'standard',bounds:scanBounds(channels,mode,targetBounds),animated:!reduced}]:[],
    intents,focuses,scanPurpose,state:state?.phase==='returning'?state:scanState,phases,completedCells,...(context.scanWalls?{scanWallWork}:{}),scanComplete:!!bits.length&&bits.every(id=>phases[id].phase==='complete'),effectCenter:{x:center.x,y:center.y},effectScale:radius/size,...(mode==='creatureScan'?{effectRotation:geometry.v82?0:rotation,targetBounds}:{}),scanWorking:working/Math.max(1,bits.length),scanRadius:radius};
}
