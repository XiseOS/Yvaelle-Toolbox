/** Keepsake · Settings (v11 overhaul).
 *
 * Nine sections and an Overview in a sidebar, organised around how she is
 * played: section › group › row, a row's Parts and visual pickers one level
 * down (settings-tree.mjs). Search jumps to and highlights a setting; the
 * breadcrumb and the sticky group chips follow the scroll; every row wears its
 * scope; sections have All on / All off / Reset and Pin to Home.
 *
 * Storage is untouched: each v10 row reads and writes exactly where v10.0.1
 * did (read()/write() below are the v10 ones, by kind); v11 rows read and
 * write through the feature registry (v11/features.mjs).
 *
 * The tab's body is one island the Keepsake renderer leaves alone
 * (data-ks-foreign): it is drawn here, and redrawn only when a value, the
 * model, a HUD preference or the island's own state changes, never on a
 * hover or a status-line message. */
import {tokenShape,fitOptions,hasFoundryRing} from '../v11/token-shape.mjs?v=12.1.0-beta.1';
import {readFlightFeel} from '../flight-feel-runtime.mjs?v=12.1.0-beta.1';
import {FEEL_DEFAULTS} from '../flight-feel.mjs?v=12.1.0-beta.1';
import {KeepsakeTab} from './shared.mjs?v=12.1.0-beta.1';
import {eligibleTokens,pinnedCharacterActorId,HUD_DEFAULTS} from '../hud-model.mjs?v=12.1.0-beta.1';
import {SETTINGS} from '../config.mjs?v=12.1.0-beta.1';
import {V7_DEFAULTS} from '../v7-ensemble.mjs?v=12.1.0-beta.1';
import {classicGroups} from '../hud-view.mjs?v=12.1.0-beta.1';
import {timed} from './timings.mjs?v=12.1.0-beta.1';
import {sheetMode,setSheetMode,portraitConfig,savePortraitConfig} from './sheet/prefs.mjs?v=12.1.0-beta.1';
import {SECTIONS,ICONS,PRESETS,SYNONYMS,INDEX,ORDER,sectionById,isFeature} from './settings-tree.mjs?v=12.1.0-beta.1';
import {V11_KEYS,resolveV11,writeV11,flagUpdate,withValue,CLIENT_KEY,WORLD_KEY,FEATURES,EXPERIMENTAL_LABEL,BUILT_IN} from '../v11/features.mjs?v=12.1.0-beta.1';
import {routeFor,migrateUI,pinnedSections,finerOpenFromLevel,PIN_CAP} from '../v11/migrate.mjs?v=12.1.0-beta.1';
export {SECTIONS};
const KEY_OF=new WeakMap([...INDEX].map(([k,rec])=>[rec.item,k]));

const ID='filament-flight';
let settingsRevision=0;
for(const hook of ['filamentFlightSettingsChanged','clientSettingChanged','updateSetting','updateToken','updateActor'])try{globalThis.Hooks?.on?.(hook,()=>{settingsRevision++;});}catch{}
/** The section last open in this browser session (the tab reopens there). */
let lastSection='overview';
const lastOpen=new Set();

/** Her portrait studio's choices, when they drive the HUD's portrait (else null). */
function studioOn(m){const actor=m?.token?.document?.actor;let f=null;try{f=actor?.getFlag?.(ID,'portrait');}catch{}if(!f)return null;const st=portraitConfig(actor);return st.hud&&st.mode==='keepsake'?st:null;}
const setting=k=>{try{return game.settings.get(ID,k);}catch{return SETTINGS[k]?.default;}};

/* ------------------------------------------------------------------ */
/* Markup helpers                                                      */
/* ------------------------------------------------------------------ */
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const svg=(d,s=16,w=1.6)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
const SCOPE={me:{label:'Just me',tip:'Only on this browser',icon:'M12 4.5a3 3 0 1 1 0 6 3 3 0 0 1 0-6zM5.5 19.5c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5'},
  token:{label:'Her token',tip:'Saved on her token · everyone sees it',icon:'M12 3.5a8.5 8.5 0 1 1 0 17 8.5 8.5 0 0 1 0-17zM12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8z'},
  gm:{label:'Everyone · GM',tip:'A world setting · the GM sets it for the table',icon:'M4 18h16M5 18l-1.5-10 5 4L12 5l3.5 7 5-4L19 18'}};
const badge=sc=>sc?`<span class="f-sc ${sc}" title="${SCOPE[sc].tip}">${svg(SCOPE[sc].icon,10,2.2)}${SCOPE[sc].label}</span>`:'';
const RESET_I=svg('M4 12a8 8 0 1 0 3-6.2M4 4v5h5',12,2.2);
const CHEV='<svg class="f-chev" width="8" height="10" viewBox="0 0 8 10" aria-hidden="true"><path d="M2 1l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>';
const FEEL_ICONS={cine:'M16 4l2.6 7.4L26 14l-7.4 2.6L16 24l-2.6-7.4L6 14l7.4-2.6z',bal:'M16 4v24M8 28h16M5 10h22M5 10l-3 8a3.5 2 0 0 0 6 0zM27 10l-3 8a3.5 2 0 0 0 6 0z',gentle:'M20 4a11 11 0 1 0 8 18a9 9 0 1 1 -8 -18z'};
function sweepSvg(id){
  const G={left:'x1="0" y1="0" x2="1" y2="0"',right:'x1="1" y1="0" x2="0" y2="0"',top:'x1="0" y1="0" x2="0" y2="1"',bottom:'x1="0" y1="1" x2="0" y2="0"'}[id];
  const A={left:'<path d="M14 92h70M78 88l7 4-7 4" stroke="#cfae76" stroke-width="2" fill="none"/>',right:'<path d="M86 92H16M22 88l-7 4 7 4" stroke="#cfae76" stroke-width="2" fill="none"/>',top:'<path d="M88 20v58M84 72l4 7 4-7" stroke="#cfae76" stroke-width="2" fill="none"/>',bottom:'<path d="M88 80V22M84 28l4-7 4 7" stroke="#cfae76" stroke-width="2" fill="none"/>'}[id];
  return `<svg viewBox="0 0 100 100" width="100%" height="100%" aria-hidden="true"><defs><linearGradient id="ffsg${id}" ${G}><stop offset="0" stop-color="#e767ce" stop-opacity="0"/><stop offset=".48" stop-color="#e767ce" stop-opacity=".05"/><stop offset=".5" stop-color="#f6d2ee" stop-opacity=".95"/><stop offset=".53" stop-color="#e767ce" stop-opacity=".35"/><stop offset="1" stop-color="#e767ce" stop-opacity=".9"/></linearGradient></defs>
  <rect width="100" height="100" fill="#22141c"/><g fill="none" stroke="#e767ce" stroke-opacity=".22" stroke-width="1.6"><path d="M50 22c-14-14-30-10-34 4 8-2 16 2 20 10M50 22c14-14 30-10 34 4-8-2-16 2-20 10"/><circle cx="50" cy="52" r="20"/><path d="M30 78c8-8 32-8 40 0"/></g><path d="M50 22c-14-14-30-10-34 4 8-2 16 2 20 10M50 22c14-14 30-10 34 4-8-2-16 2-20 10" fill="none" stroke="url(#ffsg${id})" stroke-width="2.4"/><circle cx="50" cy="52" r="20" fill="none" stroke="url(#ffsg${id})" stroke-width="3"/>
  <path d="M30 78c8-8 32-8 40 0" fill="none" stroke="url(#ffsg${id})" stroke-width="2.4"/>${A}</svg>`;
}
const REDUCED=()=>{try{return !!globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;}catch{return false;}};

/** Bring the draggable bit map into view once it has been drawn. */
function scrollToPlacement(){
  const look=()=>globalThis.document?.querySelector('.ks-host')?.shadowRoot?.querySelector('[data-ff-bit-map]');
  const find=(n=0)=>{const host=look();
    if(host){host.scrollIntoView?.({block:'center'});for(const ms of [200,450,800])setTimeout(()=>look()?.scrollIntoView?.({block:'center'}),ms);return;}
    if(n<60)requestAnimationFrame(()=>find(n+1));};
  requestAnimationFrame(()=>find());
}

export class KeepsakeSettings extends KeepsakeTab {
  initialState(){
    const p=this.props.ctx.pending??{};
    const route=routeFor(p.section)??routeFor(p.group);
    const level=p.level??this.props.ctx.controller?.prefs?.settingsLevel;
    const open=new Set(lastOpen);
    if(finerOpenFromLevel(level))for(const s of SECTIONS)for(const g of s.groups)if(g.rows.some(r=>r.fine))open.add('fine:'+g.id);
    this.st={sec:route?.section??lastSection,curGroup:route?.group??null,focusRow:route?.row??null,query:'',kb:0,openParts:open,
      view:p.detail?'detailed':null,detailOpen:p.detail??null,dirty:true};
    if(p.detail==='stabilizers')scrollToPlacement();
    this.pendingVals=new Map();
    return {changeOpen:false};
  }
  onEscape(){
    if(this.st.query){this.setQuery('');return true;}
    if(this.st.view){this.st.view=null;this.repaint();return true;}
    if(this.state.changeOpen){this.state.changeOpen=false;this.repaint();return true;}
    return false;
  }

  /* ---------------- values (the v10 read/write, by kind) ---------------- */
  read(c){
    const m=this.model,st=m.state,req=st?.requested??{},cfg=m.cfg??{},ctx=this.ctx;
    switch(c.kind){
      case 'v11':{const r=V11_KEYS.get(c.k);const v=resolveV11(m.token?.document??null)[c.k];return {value:v,changed:v!==r.def};}
      case 'derived':{const v=c.parts.some(p=>!!this.value(p));return {value:v,changed:v!==c.def};}
      case 'v7':{const v=req.v7?.[c.k];return {value:v??st?.v7?.[c.k]??V7_DEFAULTS[c.k],changed:v!=null};}
      case 'gem':{const v=req.gemMotion?.[c.k];return {value:v??st?.gems?.[c.k]??(c.fallback?setting(c.fallback):null),changed:v!=null};}
      case 'appearance':{const v=m.baseAppearance?.[c.k],d=cfg.defaults?.[c.k];return {value:v??d??c.def,changed:v!=null&&d!=null&&Math.abs(Number(v)-Number(d))>1e-6};}
      case 'pose':{const v=req.poseMotion?.[c.k];return {value:v??setting(c.cfg),changed:v!=null};}
      case 'client':case 'world':{const v=setting(c.k)??c.def;return {value:v,changed:v!==(SETTINGS[c.k]?.default??c.def)};}
      case 'theme':{
        if(c.k==='portraitSet'){const s=studioOn(m);if(s)return {value:s.set,changed:s.set!==c.def};}
        const v=m.prefs?.theme?.[c.k];return {value:v??c.def,changed:v!=null&&v!==c.def};}
      case 'ui':{const v=ctx.ui[c.k];return {value:v??c.def,changed:v!=null&&v!==c.def};}
      case 'prefs':{const v=ctx.controller.prefs?.[c.k],d=HUD_DEFAULTS[c.k];return {value:v??d,changed:v!=null&&d!=null&&v!==d};}
      case 'feel':{const v=m.token?readFlightFeel(m.token.document)[c.k]:FEEL_DEFAULTS[c.k];return {value:v,changed:v!==FEEL_DEFAULTS[c.k]};}
      case 'reactions':return {value:m.conditionSettings?.enabled!==false,changed:m.conditionSettings?.enabled===false};
      case 'sheet':{const actor=m.token?.document?.actor??null;const v=sheetMode(actor);return {value:v,changed:v!=='off'};}
      case 'localQ':{const v=m.localQuality?.preset??'inherit';return {value:v==='custom'?'inherit':v,changed:v!=='inherit'};}
      case 'observerQ':{const v=(st?.observerQuality??req.observerQuality)?.preset??'inherit';return {value:v==='custom'?'inherit':v,changed:v!=='inherit'};}
      default:return {value:null,changed:false};
    }
  }
  /** A value as shown: a choice just made shows at once and holds until it is saved (or 4 s pass). */
  value(c){return this.rv(c).value;}
  rv(c){
    const key=c.kind+':'+c.k,real=this.cache?.get(key)??this.read(c);this.cache?.set(key,real);
    const p=this.pendingVals.get(key);
    if(p){if(p.v===real.value||performance.now()>p.until)this.pendingVals.delete(key);else return {value:p.v,changed:p.v!==this.defaultOf(c)};}
    return real;
  }
  /** The value a reset goes back to (the real default where the map lists an approximate one). */
  defaultOf(c){
    switch(c.kind){
      case 'v11':return V11_KEYS.get(c.k).def;
      case 'client':case 'world':return SETTINGS[c.k]?.default??c.def;
      case 'prefs':return HUD_DEFAULTS[c.k]??c.def;
      case 'appearance':return this.model.cfg?.defaults?.[c.k]??c.def;
      case 'v7':return V7_DEFAULTS[c.k]??c.def;
      case 'gem':return c.fallback?setting(c.fallback):c.def;
      case 'pose':return setting(c.cfg)??c.def;
      case 'feel':return FEEL_DEFAULTS[c.k]??c.def;
      case 'reactions':return true;
      case 'sheet':return 'off';
      case 'localQ':case 'observerQ':return 'inherit';
      default:return c.def;
    }
  }
  resetValue(c){if(c.kind==='sheet')return 'off';if(c.kind==='prefs')return HUD_DEFAULTS[c.k]??c.def;if(c.kind==='v11')return null;if(c.kind==='derived')return c.def;
    return c.kind==='appearance'?null:['client','world'].includes(c.kind)?(SETTINGS[c.k]?.default??c.def):c.kind==='theme'||c.kind==='ui'?c.def:c.kind==='localQ'||c.kind==='observerQ'?'inherit':null;}
  editable(c,scope){
    if(c.type==='button')return true;
    if(scope==='gm'||c.kind==='world')return !!game.user?.isGM;
    if(['v7','gem','appearance','pose','reactions','observerQ','feel','sheet'].includes(c.kind)||(c.kind==='v11'&&scope==='token'))return !!this.model.token;
    return true;
  }
  async write(c,value){
    const ctx=this.ctx,api=ctx.api();
    switch(c.kind){
      case 'v11':return writeV11(c.k,value,this.model.token?.document??null).then(()=>ctx.refresh());
      case 'derived':{for(const p of c.parts)await game.settings.set(ID,p.k,value==null?p.def:!!value);ctx.refresh();return;}
      case 'v7':return ctx.run('v7',{[c.k]:value});
      case 'gem':return ctx.run('gemMotion',{[c.k]:value});
      case 'appearance':return value===null?ctx.run('resetAppearance',[c.k]):ctx.run('appearance',{[c.k]:value});
      case 'pose':return ctx.run('poseMotion',{[c.k]:value});
      case 'client':case 'world':{await game.settings.set(ID,c.k,value??SETTINGS[c.k]?.default??c.def);ctx.refresh();return;}
      case 'theme':{
        if(c.k==='portraitSet'){const actor=this.model.token?.document?.actor;if(studioOn(this.model)&&actor?.isOwner)await savePortraitConfig(actor,{set:value??c.def}).catch(()=>{});}
        return ctx.controller.savePreferences({theme:{...ctx.controller.prefs.theme,[c.k]:value??c.def}}).then(()=>ctx.refresh());}
      case 'ui':return ctx.saveUI({[c.k]:value});
      case 'prefs':return ctx.controller.savePreferences({[c.k]:value}).then(()=>ctx.refresh());
      case 'feel':{const token=this.model.token;if(!token)return;
        if(c.k==='altitude')return ctx.call(`Flying height ${value??15} ft`,()=>api.setFlightFeel(token,{altitude:value??15}));
        return ctx.call(`${c.name} saved`,()=>api.setFlightFeel(token,{[c.k]:value??FEEL_DEFAULTS[c.k]}));}
      case 'reactions':if(!!value!==this.read(c).value)return ctx.run('toggleConditionReactions');return;
      case 'sheet':{const actor=this.model.token?.document?.actor;if(!actor){ctx.message('Pin her first');return;}
        return ctx.call(value==='off'?'Keepsake sheet off · PF2e\'s own sheet':value==='me'?'Keepsake sheet · just you':'Keepsake sheet · everyone who opens her sheet',()=>setSheetMode(value??'off',actor)).then(()=>ctx.refresh());}
      case 'localQ':return ctx.call('My view quality saved · this browser',()=>api.setLocalQuality({preset:value??'inherit',wingDetail:null,bitDetail:null,effectDetail:null,textureFPS:null,transitionFPS:null,trails:null,treatment:null}));
      case 'observerQ':return ctx.run('observerQuality',{preset:value??'inherit',wingDetail:null,bitDetail:null,effectDetail:null,textureFPS:null,transitionFPS:null,trails:null,treatment:null});
      case 'action':return this.press(c);
    }
  }
  async press(c){
    const ctx=this.ctx,api=ctx.api();
    switch(c.k){
      case 'openMedkit':return api.medkit?.();
      case 'openSheet':case 'portraitStudio':{const actor=this.model.token?.document?.actor;if(!actor){ctx.message('Pin her first');return;}
        try{if(c.k==='openSheet')api.sheet?.open(actor);else await api.sheet?.studio(actor);}catch(e){ctx.message(e?.message??String(e));}return;}
      case 'bitPlacement':return this.openPlacement();
      case 'demoManoeuvres':{const token=this.model.token;if(!token){ctx.message('Pin a character you own first');return;}
        try{api.manoeuvres?.demo(token);ctx.message(api.manoeuvres?.rigid?.()?'Watch her wings: brake, brake, descend':'Watch her wings: bank, bank, brake, pivot, descend');}catch(e){ctx.message(e?.message??String(e));}return;}
      case 'openKeys':return ctx.openKeys();
      case 'allSettings':return ctx.openAllSettings();
      case 'detailed':this.st.view='detailed';this.st.query='';this.repaint();this.pane()?.scrollTo?.({top:0});return;
    }
  }
  /** The draggable bit-anchor map lives in Detailed tuning › wing-side bits. */
  openPlacement(){
    const c0=this.ctx.controller,open=c0?.prefs?.openSections??[];
    if(!open.includes('bits-placement'))void c0?.savePreferences?.({openSections:[...open,'bits-placement']}).catch(()=>{});
    Object.assign(this.st,{view:'detailed',query:'',detailOpen:'stabilizers'});this.repaint();
    this.ctx.message('Drag a bit on the map · release to save · arrow keys nudge it');
    scrollToPlacement();
  }

  /* ---------------- changing values ---------------- */
  /** Change several values at once. Token v11 values go in one token update, browser and world v11 values in one save each. */
  async apply(changes,label){
    const ctx=this.ctx,doc=this.model.token?.document??null,undo=[];
    const tokenPatch={},scopes={me:null,gm:null},rest=[];
    for(const {c,value} of changes){
      const before=this.rv(c);undo.push({c,value:before.changed||c.kind==='prefs'?before.value:this.resetValue(c)});
      this.pendingVals.set(c.kind+':'+c.k,{v:value==null?this.defaultOf(c):value,until:performance.now()+4000});
      if(c.kind==='v11'){const r=V11_KEYS.get(c.k);
        if(r.scope==='token')Object.assign(tokenPatch,flagUpdate(c.k,value));
        else{const sk=r.scope==='me'?'me':'gm';scopes[sk]=withValue(scopes[sk]??(setting(sk==='me'?CLIENT_KEY:WORLD_KEY)??{}),c.k,value);}
      }else rest.push({c,value});
    }
    this.repaint();
    const run=async()=>{
      if(Object.keys(tokenPatch).length){if(!doc)throw new Error('Pin her first');await doc.update(tokenPatch);}
      if(scopes.me)await game.settings.set(ID,CLIENT_KEY,scopes.me);
      if(scopes.gm){if(!game.user?.isGM)throw new Error('Only the GM can change this');await game.settings.set(ID,WORLD_KEY,scopes.gm);}
      for(const {c,value} of rest)await this.write(c,value);
    };
    ctx.pushUndo(label,()=>this.apply(undo,label+' undone').then(()=>{}));
    try{await run();ctx.message(label);}catch(e){this.pendingVals.clear();ctx.fail(e);}
    finally{this.cache=null;this.repaint();}
  }
  change(c,value,label){return this.apply([{c,value}],label);}

  /* ---------------- render (island) ---------------- */
  renderVals(){
    const base=this.frameVals(this.defaultNote());
    const keyDown=base.keyDown;
    // "/" focuses the search from anywhere in the HUD
    base.keyDown=e=>{if(e.key==='/'&&!e.composedPath?.()[0]?.matches?.('input,textarea,select')){e.preventDefault();this.island?.querySelector('.f-search input')?.focus();return;}keyDown(e);};
    return {...base,slimHeader:true,fullHeader:false};
  }
  defaultNote(){return 'Every change saves itself · Undo is one click';}
  /** Called by the HUD after each render. */
  afterRender(root){
    const island=root?.querySelector?.('[data-ks-settings]');if(!island)return;
    if(island!==this.island){this.island=island;this.mount(island);this.st.dirty=true;}
    // (first open in v11: the groups pressed onto Home become the sections pinned there, once)
    if(!this.migrated){this.migrated=true;const patch=migrateUI(this.ctx.ui);if(patch)void this.ctx.saveUI(patch).catch(()=>{});}
    const key=[this.model,settingsRevision,JSON.stringify(this.ctx.ui),this.ctx.controller?.prefs,!!game.user?.isGM,this.state.changeOpen,this.pendingVals.size];
    if(!this.st.dirty&&this.paintKey&&key.every((k,i)=>k===this.paintKey[i]))return;
    this.paintKey=key;this.st.dirty=false;
    timed('settings:paint',()=>this.paint());
  }
  repaint(){this.st.dirty=true;if(this.island)timed('settings:paint',()=>{this.st.dirty=false;this.paint();});}
  pane(){return this.island?.querySelector('.f-pane');}
  mount(el){
    el.innerHTML=`<div class="f-st"><div class="f-top">
      <label class="f-search"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#cfae76" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4-4"/></svg>
      <span style="position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)">Find a setting</span>
      <input type="search" autocomplete="off" spellcheck="false" placeholder="Find a setting: shadow, wounds, volume…"><span class="f-kbd" aria-hidden="true">/</span><button type="button" class="f-clr" data-act="clear">Clear</button></label>
      <div class="f-crumbs" aria-label="Breadcrumb"></div></div>
      <nav class="f-side" aria-label="Settings sections"></nav><main class="f-pane" tabindex="-1"></main></div>`;
    const input=el.querySelector('.f-search input');
    input.value=this.st.query;
    input.addEventListener('input',()=>this.setQuery(input.value));
    input.addEventListener('keydown',e=>{
      if(e.key==='Escape'){if(this.st.query){e.preventDefault();e.stopPropagation();this.setQuery('');}return;}
      if(!this.st.query)return;
      const res=this.searchResults(this.st.query);
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();this.st.kb=Math.max(0,Math.min(res.length-1,this.st.kb+(e.key==='ArrowDown'?1:-1)));this.paintPane(true);
        this.pane()?.querySelector('.f-res.kb')?.scrollIntoView?.({block:'nearest'});}
      if(e.key==='Enter'&&res[this.st.kb]){e.preventDefault();this.goTo(res[this.st.kb].rec.key);}
    });
    el.addEventListener('click',e=>this.onClick(e));
    el.addEventListener('input',e=>this.onInput(e));
    el.addEventListener('change',e=>this.onChange(e));
    el.addEventListener('mouseover',e=>this.onHover(e));
    el.querySelector('.f-pane').addEventListener('scroll',()=>this.onScroll(),{passive:true});
  }
  paint(){
    this.cache=new Map();
    try{this.paintSide();this.paintCrumbs();this.paintPane(true);}
    finally{this.cache=null;}
    const s=this.island?.querySelector('.f-search');s?.classList.toggle('has',!!this.st.query);
    if(this.st.focusRow){const id=this.st.focusRow;this.st.focusRow=null;requestAnimationFrame(()=>this.flashRow(id));}
  }

  /* ---------------- the row model ---------------- */
  scopeOf(rec){return rec.item.scope??rec.parent?.scope??null;}
  changed(rec){const it=rec.item;if(it.type==='button'||!it.kind||it.kind==='action')return false;return this.rv(it).changed;}
  fmtVal(it,v){if(it.type==='switch')return (it.on!==undefined?v===it.on:!!v)?'on':'off';if(it.type==='slider')return it.fmt(Number(v));const o=(it.opts??[]).find(o=>o.id===v);return o?o.label:String(v);}
  isSwitchOn(it,v){return it.on!==undefined?v===it.on:!!v;}
  lockNote(it,scope){if(it.type==='button')return '';if(scope==='gm'||it.kind==='world')return game.user?.isGM?'':'Only the GM can change this';return this.editable(it,scope)?'':'Pin her first';}
  control(it,scope,{sm=false}={}){
    const v=this.value(it),locked=!this.editable(it,scope),dis=locked?' disabled':'',key=esc(this.keyOf(it));
    if(it.type==='switch'){const on=this.isSwitchOn(it,v);return `<button type="button" class="f-sw${sm?' sm':''}${on?' on':''}" role="switch" aria-checked="${on}" aria-label="${esc(it.name)}" data-act="flip" data-id="${key}"${dis}><i></i></button>`;}
    if(it.type==='slider'){const n=Number(v??it.min),p=Math.max(0,Math.min(100,Math.round((n-it.min)/(it.max-it.min)*100)));
      return `<span class="f-sl"><input type="range" min="${it.min}" max="${it.max}" step="${it.step}" value="${n}" style="--p:${p}%" aria-label="${esc(it.name)}" data-act="slide" data-id="${key}"${dis}><output>${esc(it.fmt(n))}</output></span>`;}
    if(it.type==='choice'){const long=it.opts.length>4||it.opts.reduce((a,o)=>a+o.label.length,0)>26;
      if(long)return `<select class="f-sel" aria-label="${esc(it.name)}" data-act="select" data-id="${key}"${dis}>${it.opts.map(o=>`<option value="${esc(o.id)}"${o.id===v?' selected':''}>${esc(o.label)}</option>`).join('')}</select>`;
      return `<span class="f-seg" role="radiogroup" aria-label="${esc(it.name)}">${it.opts.map(o=>`<button type="button" role="radio" aria-checked="${o.id===v}" class="${o.id===v?'on':''}" data-act="choose" data-id="${key}" data-v="${esc(o.id)}"${dis}>${esc(o.label)}</button>`).join('')}</span>`;}
    if(it.type==='button')return `<button type="button" class="f-btn" data-act="press" data-id="${key}">${esc(it.label)}${it.count?` <span class="f-n">${it.count}</span>`:''}</button>`;
    return '';
  }
  keyOf(it){return KEY_OF.get(it)??it.id;}
  row(rec,{scope,extra='',cls=''}={}){
    const it=rec.item,sc=scope===''?null:(scope??this.scopeOf(rec)),ch=this.changed(rec),stack=it.type==='slider'||(it.type==='choice'&&it.opts.length>2)?' stack':'';
    const lock=this.lockNote(it,this.scopeOf(rec));
    return `<div class="f-row${ch?' chg':''}${stack}${cls}" data-row="${esc(rec.key)}"><i class="f-dot" aria-hidden="true"></i>
      <div class="f-txt"><div class="f-nm">${esc(it.name)}${it.v11&&!it.exp&&!cls.includes('part')?'<span class="f-new">V11</span>':''}${it.exp?`<span class="f-exp" title="${EXPERIMENTAL_LABEL}">EXPERIMENTAL</span>`:''}${badge(sc)}</div>${it.desc?`<div class="f-ds">${esc(it.desc)}</div>`:''}${it.note?`<div class="f-note">${esc(it.note)}</div>`:''}</div>
      <div class="f-ctl${lock?' locked':''}"${lock?` title="${esc(lock)}"`:''}>${extra}${this.control(it,this.scopeOf(rec))}</div>
      ${it.type==='button'?'<span></span>':`<button type="button" class="f-rst" data-act="reset" data-id="${esc(rec.key)}" aria-label="Reset ${esc(it.name)} to default" title="Back to default">${RESET_I}</button>`}</div>`;
  }
  thumb(name){return `${this.ctx.root}/assets/keepsake/settings/${name}.webp`;}
  picker(rec,{big=false}={}){
    const p=rec.item,v=this.value(p),ch=this.changed(rec),locked=!this.editable(p,this.scopeOf(rec));
    return `<div class="f-picks" data-row="${esc(rec.key)}"><div class="f-pk-h"><b>${esc(p.name)}</b><small>${esc(p.desc??'')}</small>${ch?`<button type="button" class="f-rst" style="opacity:.85;pointer-events:auto" data-act="reset" data-id="${esc(rec.key)}" title="Back to default">${RESET_I}</button>`:''}</div>
      <div class="f-pk-row${big?' big':''}${p.plain?' plain':''}" role="radiogroup" aria-label="${esc(p.name)}">${p.opts.map(o=>{const on=v===o.id;
      const th=p.plain?'':p.svg?`<span class="f-th svg">${sweepSvg(o.id)}</span>`:`<span class="f-th"><i style="background-image:url('${this.thumb(o.thumb)}')"></i><span class="f-live">LIVE</span></span>`;
      return `<button type="button" class="f-pick${p.plain?' plain':''}${on?' on':''}" role="radio" aria-checked="${on}" data-act="choose" data-id="${esc(rec.key)}" data-v="${esc(o.id)}"${locked?' disabled':''}>${th}${o.id===p.def?'<span class="f-df">DEFAULT</span>':''}<span class="f-ck"></span><span class="f-lb">${esc(o.label)}</span></button>`;}).join('')}</div>${p.readout==='tokenShape'?`<p class="f-readout">${this.shapeReadout()}</p>`:''}</div>`;
  }
  /** (test.9) What the module found on her token ("round · border 5% at 0.90 · art fills 96%"): read when the Settings draw, never per frame. */
  shapeReadout(){
    const tk=this.model.token;if(!tk)return 'Open this with her token selected to see what was found.';
    try{const v=resolveV11(tk.document??null),ts=tokenShape(tk,fitOptions({mode:v.tokenFit,shape:v.tokenFitShape,border:v.tokenFitBorder,inset:v.tokenFitInset},hasFoundryRing(tk)));
      if(!ts.measured)return 'Her token picture has not been measured yet.';
      const d=ts.drawn;return `${ts.mode==='manual'?'Set by hand':'Found on her token'}: <b>${esc(ts.text)}</b> · drawn ${d.grid.w}×${d.grid.h} square${d.grid.w*d.grid.h>1?'s':''}, ${Math.round(d.mesh.w)}×${Math.round(d.mesh.h)} px${d.scale.x!==1||d.scale.y!==1?`, scale ${d.scale.x}×${d.scale.y}`:''}${d.mirror.x||d.mirror.y?', mirrored':''}${d.heightScale!==1?`, ${Math.round(d.heightScale*100)}% with height`:''}`;
    }catch{return 'Her token picture could not be measured.';}
  }
  partsSummary(r){const sw=(r.parts??[]).filter(p=>p.type==='switch');const on=sw.filter(p=>this.isSwitchOn(p,this.value(p))).length;return {on,n:sw.length,extra:(r.parts??[]).length-sw.length};}
  feature(rec){
    const r=rec.item,open=this.st.openParts.has(r.id),on=r.type!=='switch'||this.isSwitchOn(r,this.value(r));
    const thumb=r.thumb?`<span class="f-tbn" style="background-image:url('${this.thumb(r.thumb)}')" aria-hidden="true"></span>`:'';
    const act=r.action?`<button type="button" class="f-btn ghost" data-act="press" data-id="${esc(r.action.id)}">${esc(r.action.label)}</button>`:'';
    let h=`<div class="f-feat${on?'':' off'}" data-feat="${esc(r.id)}">${this.row(rec,{extra:thumb+act})}`;
    for(const p of r.pickers??[])h+=this.picker(INDEX.get(p.id),{big:r.id==='tokenLayer'});
    if(r.parts?.length){
      const {on:pn,n,extra}=this.partsSummary(r),mixed=n&&pn<n,locked=!this.editable(r,rec.scope);
      h+=`<div class="f-pbar"><button type="button" class="f-ptog${mixed?' mixed':''}" aria-expanded="${open}" data-act="parts" data-id="${esc(r.id)}">${CHEV}Parts <span class="f-of">${n?`· <b>${pn}</b> of ${n} on`:''}${extra?`${n?' + ':'· '}${extra} setting${extra>1?'s':''}`:''}</span></button></div>`;
      if(open){
        h+=`<div class="f-parts open">`;
        const sw=r.parts.filter(p=>p.type==='switch'),other=r.parts.filter(p=>p.type!=='switch');
        if(n>2&&!locked)h+=`<div class="f-parts-tools">${n} parts <button type="button" data-act="partsAll" data-id="${esc(r.id)}" data-v="1">All on</button><button type="button" data-act="partsAll" data-id="${esc(r.id)}" data-v="0">All off</button></div>`;
        const pr=p=>INDEX.get(`${r.id}/${p.id}`);
        if(r.chips)h+=`<div class="f-chips">${sw.map(p=>{const pv=this.isSwitchOn(p,this.value(p)),k=`${r.id}/${p.id}`;
          return `<button type="button" class="f-chip${pv?' on':''}${this.changed(pr(p))?' chg':''}${p.name.length>22?' wide':''}" role="switch" aria-checked="${pv}" data-act="flip" data-id="${esc(k)}" data-row="${esc(k)}"${locked?' disabled':''}><i></i>${esc(p.name)}</button>`;}).join('')}</div>`;
        else h+=sw.map(p=>this.row(pr(p),{scope:p.scope&&p.scope!==r.scope?p.scope:'',cls:' part'})).join('');
        h+=other.map(p=>this.row(pr(p),{scope:p.scope&&p.scope!==r.scope?p.scope:'',cls:' part'})).join('');
        h+='</div>';
      }
    }
    return h+'</div>';
  }

  /* ---------------- sections ---------------- */
  secChanged(sec){let n=0;for(const rec of ORDER)if(rec.sec===sec&&this.changed(rec))n++;return n;}
  sectionSwitches(sec){return ORDER.filter(r=>r.sec===sec&&r.role==='row'&&r.item.type==='switch'&&this.editable(r.item,r.scope));}
  paintSide(){
    const el=this.island.querySelector('.f-side'),S=this.st;
    el.innerHTML=SECTIONS.map((s,i)=>{const n=s.id==='overview'?0:this.secChanged(s),on=S.sec===s.id&&!S.query;
      return (i===1||s.id==='advanced'?'<i class="f-sep"></i>':'')+`<button type="button" class="f-nav${on?' on':''}" data-act="go" data-v="${s.id}" aria-current="${on?'page':'false'}" title="${esc(s.name)}"${n?' data-chg':''}><span class="f-ic">${svg(ICONS[s.icon],15,1.6)}</span><span class="f-lb"><b>${esc(s.short??s.name)}</b>${s.sub?`<small>${esc(s.sub)}</small>`:''}</span><span class="f-cnt">${n?`<span class="chg" title="${n} changed">${n}</span>`:''}</span></button>`;}).join('');
  }
  paintCrumbs(){
    const S=this.st,sec=sectionById(S.sec);let h='<button type="button" data-act="go" data-v="overview">Settings</button>';
    if(S.query)h+='<i class="f-sep"></i><span class="f-cur">Search</span>';
    else if(S.view==='detailed')h+=`<i class="f-sep"></i><button type="button" data-act="go" data-v="advanced">Advanced</button><i class="f-sep"></i><span class="f-cur">Detailed tuning</span>`;
    else if(sec.id!=='overview')h+='<i class="f-sep"></i>'+(S.curGroup?`<button type="button" data-act="top">${esc(sec.name)}</button><i class="f-sep"></i><span class="f-cur">${esc(sec.groups.find(g=>g.id===S.curGroup)?.name??'')}</span>`:`<span class="f-cur">${esc(sec.name)}</span>`);
    else h+='<i class="f-sep"></i><span class="f-cur">Overview</span>';
    this.island.querySelector('.f-crumbs').innerHTML=h;
  }
  paintPane(keepScroll=true){
    const pane=this.pane(),S=this.st,sec=sectionById(S.sec),fresh=S.fresh;S.fresh=false;
    // (scroll is set before the new rows go in: setting it after forced a layout inside the click)
    const top=fresh?0:pane.scrollTop;if(fresh&&top!==pane.scrollTop)pane.scrollTop=0;
    const own=!this.cache;if(own)this.cache=new Map();
    // (test.6) a section just opened draws the groups the first screen shows (or up to the one a search jumps to)
    // in this frame and the rest a frame later, two at a time: the first frame lays out a third of the rows
    let rest=null;
    try{if(S.query)pane.innerHTML=this.renderSearch();else if(S.view==='detailed')pane.innerHTML=this.renderDetailed();else if(sec.special==='overview')pane.innerHTML=this.renderOverview();
      else{const at=S.curGroup?sec.groups.findIndex(g=>g.id===S.curGroup):-1,eager=fresh?Math.max(2,at+2):Infinity;
        pane.innerHTML=this.renderSection(sec,{upto:eager});if(eager<sec.groups.length)rest=sec.groups.slice(eager);}}
    finally{if(own)this.cache=null;}
    const token=this.paneToken=(this.paneToken??0)+1;this.paneRest=rest?{sec,groups:rest,token}:null;
    if(rest)this.later(token);
    if(keepScroll&&!fresh&&top)pane.scrollTop=top;
    if(S.view==='detailed')this.ctx.fillClassic?.();
  }
  /** The rest of a section, two groups a frame (dropped if the pane is redrawn meanwhile). */
  later(token){
    const win=this.island?.ownerDocument?.defaultView??globalThis;
    (win.requestAnimationFrame??(f=>setTimeout(f,16)))(()=>setTimeout(()=>{if(this.paneToken!==token||!this.paneRest)return;this.flushRest(2);if(this.paneRest)this.later(token);},0));
  }
  /** Draw n more of the waiting groups now (all of them without n). */
  flushRest(n=Infinity){
    const R=this.paneRest,pane=this.pane();if(!R||!pane)return;
    const take=R.groups.splice(0,n),own=!this.cache;if(own)this.cache=new Map();
    try{pane.insertAdjacentHTML('beforeend',take.map(g=>this.groupHTML(g)).join(''));}finally{if(own)this.cache=null;}
    if(!R.groups.length)this.paneRest=null;
  }
  renderSection(sec,{upto=Infinity}={}){
    const chg=this.secChanged(sec),pinned=pinnedSections(this.ctx.ui).includes(sec.id);
    let h=`<div class="f-sec-head"><div class="f-tt"><h2>${esc(sec.name)}</h2></div><p>${esc(sec.blurb)}</p>
      <div class="f-acts"><button type="button" class="f-btn" data-act="allSec" data-v="1">${svg('M5 12l4 4 10-10',12,2)}All on</button><button type="button" class="f-btn" data-act="allSec" data-v="0">${svg('M6 6l12 12M18 6L6 18',12,2)}All off</button>
      <button type="button" class="f-btn ghost" data-act="resetSec"${chg?'':' disabled'}>${RESET_I}Reset section${chg?` <span class="f-n">${chg}</span>`:''}</button><button type="button" class="f-btn ghost" data-act="pin" aria-pressed="${pinned}" title="${pinned?'Take this section off the Pressed row on Home':'Add this section to the Pressed row on Home'}">${svg('M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z',12,1.8)}${pinned?'Pinned to Home':'Pin to Home'}</button></div></div>`;
    h+=`<nav class="f-jump" aria-label="Groups in ${esc(sec.name)}">${sec.groups.map(g=>`<button type="button" data-act="jump" data-g="${g.id}" class="${this.st.curGroup===g.id?'on':''}">${esc(g.name)}${g.rows.some(r=>r.v11)?'<span class="f-nw" title="New in v11"></span>':''}</button>`).join('')}</nav>`;
    for(const g of sec.groups.slice(0,upto))h+=this.groupHTML(g);
    return h;
  }
  groupHTML(g){
    let h=`<section class="f-grp" data-grp="${g.id}" aria-labelledby="ffg-${g.id}"><div class="f-grp-h"><h3 id="ffg-${g.id}">${esc(g.name)}</h3><i class="f-rule"></i><small>${esc(g.desc??'')}</small></div>`;
    const main=g.rows.filter(r=>!r.fine),fine=g.rows.filter(r=>r.fine);
    for(const r of main){const rec=INDEX.get(r.id);h+=isFeature(r)?this.feature(rec):this.row(rec);}
    if(fine.length){const k='fine:'+g.id,open=this.st.openParts.has(k);
      h+=`<div class="f-pbar" style="padding-top:var(--s4)"><button type="button" class="f-ptog" aria-expanded="${open}" data-act="parts" data-id="${k}">${CHEV}Finer tuning <span class="f-of">· ${fine.length}</span></button></div>`;
      if(open)h+=`<div class="f-parts open">${fine.map(r=>{const rec=INDEX.get(r.id);return isFeature(r)?this.feature(rec):this.row(rec,{cls:' part'});}).join('')}</div>`;}
    return h+'</section>';
  }
  presetOn(p){const m=this.model,ui=this.ctx.ui;return Object.entries(p.set).every(([k,v])=>k==='localQ'?(m.localQuality?.preset??'inherit')===v:k==='fm'||k==='petals'?(ui[k]??(k==='fm'?'Normal':true))===v:setting(k)===v);}
  renderOverview(){
    const ctx=this.ctx,model=this.model,token=model.token,c0=ctx.controller,pinned=!c0.prefs?.followSelection;
    const name=token?.document?.name??'No character',img=token?.document?.texture?.src??ctx.portrait;
    let h=`<div class="f-sec-head"><div class="f-tt"><h2>Settings</h2></div><p>Nine places, organised around how she is played. Search finds anything, including where it used to be.</p></div>`;
    h+=`<section class="f-grp"><div class="f-ov-char"><span class="f-ov-pt" style="background-image:url('${esc(img)}')"></span><div class="f-who"><b>${esc(name)} <span class="f-tag">${pinned?'Pinned':'Following selection'}</span></b><small>${esc(pinned?'Keys and the Quick wheel act on '+name:'The HUD follows the token you select')}</small></div>
      <button type="button" class="f-btn" data-act="change" aria-expanded="${!!this.state.changeOpen}">Change…</button>${pinned?'<button type="button" class="f-btn ghost" data-act="unpin">Unpin</button>':''}<button type="button" class="f-btn ghost" data-act="keys">Set keys</button></div>`;
    if(this.state.changeOpen){
      const chars=eligibleTokens().filter(t=>pinnedCharacterActorId(t));
      h+=`<div class="f-chips" style="padding:0 var(--s6) var(--s6)">${chars.map(t=>`<button type="button" class="f-chip${t===token?' on':''}" data-act="pinTo" data-v="${esc(t.document.uuid)}"><i></i>${esc(t.document.name)}</button>`).join('')||'<span class="f-ds">No owned character tokens in this scene.</span>'}</div>`;
    }
    h+='</section>';
    h+=`<section class="f-grp"><div class="f-grp-h"><h3>Start from a feel</h3><i class="f-rule"></i><small>Your view only · Undo is one click</small></div><div class="f-feels" role="radiogroup" aria-label="Feel preset">${PRESETS.map(p=>{const on=this.presetOn(p);
      return `<button type="button" class="f-feel${on?' on':''}" role="radio" aria-checked="${on}" data-act="preset" data-v="${p.id}"><svg width="24" height="24" viewBox="0 0 32 32" fill="none" stroke="${on?'#f6e7d2':'#cfae76'}" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${FEEL_ICONS[p.id]}"/></svg><b>${p.name}</b><small>${esc(p.desc)}</small></button>`;}).join('')}</div>
      <div class="f-legend"><span>${badge('me')} this browser</span><span>${badge('token')} saved on her token, all see it</span><span>${badge('gm')} world, the GM sets it</span></div></section>`;
    const nw=ORDER.filter(r=>r.role==='row'&&r.item.v11&&!r.item.exp),ex=ORDER.filter(r=>r.role==='row'&&r.item.exp);
    const item=r=>{const it=r.item,on=this.isSwitchOn(it,this.value(it));
      const np=(it.parts??[]).filter(p=>p.type==='switch').length,npk=(it.pickers??[]).length;
      return `<div class="f-wn-i${on?'':' off'}" data-row="${esc(r.key)}"><span class="f-tbn" style="background-image:url('${this.thumb(it.thumb??'card_world')}')"></span><button type="button" class="f-t" data-act="goto" data-id="${esc(r.key)}"><b><span class="f-wn-nm">${esc(it.name)}</span><span class="f-wn-meta">${np?`<span class="f-pp">${np} ${np>1?'parts':'part'}</span>`:''}${npk?`<span class="f-pp">${npk>1?npk+' looks':'look'}</span>`:''}${badge(r.scope)}</span></b><small>${esc(it.desc)}</small></button>${this.control(it,r.scope,{sm:true})}</div>`;};
    const bySec=new Map();for(const r of nw){if(!bySec.has(r.sec))bySec.set(r.sec,[]);bySec.get(r.sec).push(r);}
    // (12.1.0-beta.1) v12's own features come first, under their own heading: the list used to be titled "v11" and held them unmarked
    const is12=r=>String(BUILT_IN[r.item.id]??'').startsWith('12.'),n12=nw.filter(is12);
    h+=`<section class="f-grp" id="ff-whatsnew"><div class="f-grp-h"><h3>What’s new</h3><i class="f-rule"></i><small>${nw.length} features since v10 · each with its own parts</small></div><div class="f-wn">`;
    if(n12.length)h+=`<div class="f-wn-sub">New in v12<i class="f-rule"></i></div>`+n12.map(item).join('');
    for(const [sec,list] of bySec){const rest=list.filter(r=>!is12(r));if(rest.length)h+=`<div class="f-wn-sub">${esc(sec.name)} · v11<i class="f-rule"></i></div>`+rest.map(item).join('');}
    h+=`<div class="f-wn-sub">${EXPERIMENTAL_LABEL} · off by default<i class="f-rule"></i></div>`+ex.map(item).join('');
    h+='</div></section>';
    const ch=ORDER.filter(r=>this.changed(r));
    h+=`<section class="f-grp f-chlist"><div class="f-grp-h"><h3>Your changes</h3><i class="f-rule"></i><small>${ch.length?ch.length+' changed from default':'Everything is at its default'}</small></div>${ch.map(r=>{const it=r.item;
      return `<div class="f-row chg" data-row="${esc(r.key)}"><i class="f-dot"></i><div class="f-txt"><div class="f-nm"><button type="button" data-act="goto" data-id="${esc(r.key)}" style="text-align:left">${esc(it.name)}</button>${badge(r.scope)}</div><div class="f-ds">${esc(r.sec.name)} › ${esc(r.grp.name)}${r.parent?' › '+esc(r.parent.name):''} · now <b style="color:var(--ink)">${esc(this.fmtVal(it,this.value(it)))}</b>, default ${esc(this.fmtVal(it,this.defaultOf(it)))}</div></div><span></span>${this.editable(it,r.scope)?`<button type="button" class="f-rst" data-act="reset" data-id="${esc(r.key)}" title="Back to default">${RESET_I}</button>`:'<span></span>'}</div>`;}).join('')}</section>`;
    return h;
  }
  renderDetailed(){
    let groups=[];try{groups=classicGroups(this.model);}catch(e){console.warn(e);}
    let h=`<div class="f-sec-head"><div class="f-tt"><h2>Detailed tuning</h2></div><p>Every fine-grained control for her token, as in v10. Changes save as you make them.</p>
      <div class="f-acts"><button type="button" class="f-btn ghost" data-act="go" data-v="advanced">‹ Back to Advanced</button></div></div><section class="f-grp" style="padding:4px 0">`;
    for(const d of groups){const open=this.st.detailOpen===d.id;
      h+=`<div class="f-feat"><div class="f-pbar" style="padding-top:var(--s4)"><button type="button" class="f-ptog" aria-expanded="${open}" data-act="detail" data-id="${esc(d.id)}">${CHEV}${esc(d.title)} <span class="f-of">· ${esc(d.hint)}</span></button></div>
        ${open?`<div class="ks-classic-wrap"><div class="ks-classic filament-flight-hud" data-ks-foreign data-ks-classic="${esc(d.id)}"></div></div>`:''}</div>`;}
    return h+'</section>';
  }

  /* ---------------- search ---------------- */
  searchResults(q){
    const terms=q.toLowerCase().split(/\s+/).filter(Boolean);if(!terms.length)return [];
    const out=[];
    for(const rec of ORDER){const it=rec.item;
      const name=it.name.toLowerCase(),aka=(it.aka??'').toLowerCase(),desc=(it.desc??'').toLowerCase(),opts=(it.opts??[]).map(o=>o.label).join(' ').toLowerCase();
      const path=`${rec.sec.name} ${rec.grp.name} ${rec.parent?.name??''}`.toLowerCase(),from=(it.from??'').toLowerCase();
      let score=0,ok=true;
      for(const t of terms){const syn=(SYNONYMS[t]??'').split(' ').filter(Boolean);let s=0;
        if(name.startsWith(t))s=10;else if(name.includes(t))s=8;else if(opts.includes(t))s=5;else if(aka.includes(t))s=4.5;else if(desc.includes(t))s=4;else if(path.includes(t))s=2;else if(from.includes(t))s=1.5;
        else if(syn.some(w=>name.includes(w)||aka.includes(w)||desc.includes(w)))s=3;
        if(!s){ok=false;break;}score+=s;}
      if(ok)out.push({rec,score});}
    out.sort((a,b)=>b.score-a.score||ORDER.indexOf(a.rec)-ORDER.indexOf(b.rec));return out.slice(0,40);
  }
  renderSearch(){
    const q=this.st.query,res=this.searchResults(q),terms=q.toLowerCase().split(/\s+/).filter(Boolean);
    const hl=text=>{let t=esc(text);for(const w of terms){if(w.length<2)continue;t=t.replace(new RegExp('('+w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig'),'<mark>$1</mark>');}return t;};
    if(!res.length)return `<div class="f-sec-head"><div class="f-tt"><h2>Search</h2></div></div><div class="f-empty">Nothing by that name.<br><span style="font-size:13px">Try “shadow”, “sound” or “bits”.</span></div>`;
    let h=`<div class="f-res-h"><b>${res.length}</b> setting${res.length>1?'s':''} match “${esc(q)}” · ↑↓ to choose, Enter to jump</div><section class="f-grp" style="margin-top:0">`;
    res.forEach(({rec},i)=>{const it=rec.item,opts=(it.opts??[]).filter(o=>terms.some(t=>o.label.toLowerCase().includes(t)));
      const moved=it.from&&it.from!==rec.grp.name&&terms.some(t=>it.from.toLowerCase().includes(t));
      h+=`<button type="button" class="f-res${i===this.st.kb?' kb':''}" data-act="goto" data-id="${esc(rec.key)}"><span><span class="f-p">${esc(rec.sec.name)}<i class="f-sep"></i>${esc(rec.grp.name)}${rec.parent?`<i class="f-sep"></i>${esc(rec.parent.name)}${rec.role==='part'?' · Parts':''}`:''}</span>
        <span class="f-nm">${hl(it.name)}${it.v11&&!it.exp?'<span class="f-new">V11</span>':''}${it.exp?'<span class="f-exp">EXPERIMENTAL</span>':''}${badge(rec.scope)}</span>
        ${it.desc?`<span class="f-ds" style="display:block">${hl(it.desc)}</span>`:''}${opts.length?`<span class="f-ds" style="display:block">Options: ${opts.map(o=>hl(o.label)).join(' · ')}</span>`:''}
        ${moved?`<span class="f-was" style="display:block">Moved here from “${esc(it.from)}”</span>`:''}</span><span class="f-go">Go ›</span></button>`;});
    return h+'</section>';
  }
  setQuery(q){
    this.st.query=q;this.st.kb=0;const input=this.island?.querySelector('.f-search input');if(input&&input.value!==q)input.value=q;
    this.repaint();const p=this.pane();if(p)p.scrollTop=0;
  }

  /* ---------------- navigation ---------------- */
  go(id,{group=null}={}){
    if(!sectionById(id))return;
    Object.assign(this.st,{sec:id,query:'',view:null,curGroup:group,fresh:true});lastSection=id;
    const input=this.island?.querySelector('.f-search input');if(input)input.value='';
    this.repaint();
  }
  goTo(key){
    const rec=INDEX.get(key);if(!rec)return;
    if(rec.parent&&rec.role==='part')this.st.openParts.add(rec.parent.id);
    if(rec.item.fine||rec.parent?.fine)this.st.openParts.add('fine:'+rec.grp.id);
    for(const k of this.st.openParts)lastOpen.add(k);
    this.go(rec.sec.id,{group:rec.grp.id});
    requestAnimationFrame(()=>this.flashRow(key));
  }
  flashRow(key){
    const el=this.pane()?.querySelector(`[data-row="${CSS.escape(key)}"]`);if(!el)return;
    this.tweenTo(el,this.pane().clientHeight*.3);
    el.classList.remove('flash');void el.offsetWidth;el.classList.add('flash');setTimeout(()=>el.classList.remove('flash'),2300);
  }
  /** (test.6) the target is read again each frame: groups above it that draw in (or size themselves) meanwhile never leave it short */
  tweenTo(el,offset=40){const pane=this.pane();if(!pane||!el)return;this.tweenScroll(pane,()=>el.isConnected?pane.scrollTop+el.getBoundingClientRect().top-pane.getBoundingClientRect().top-offset:pane.scrollTop);}
  /** A 420 ms ease-out, driven by requestAnimationFrame (none with reduced motion). */
  tweenScroll(pane,to){
    const target=()=>{const t=typeof to==='function'?to():to;return Math.max(0,Math.min(t,pane.scrollHeight-pane.clientHeight));};
    const from=pane.scrollTop,t0=performance.now(),D=REDUCED()?0:420;
    const token=this.tweenToken=(this.tweenToken??0)+1;
    const step=()=>{if(token!==this.tweenToken)return;const k=D?Math.min(1,(performance.now()-t0)/D):1,e=1-Math.pow(1-k,3),T=target();pane.scrollTop=from+(T-from)*e;if(k<1)requestAnimationFrame(step);};step();
  }
  onScroll(){
    const S=this.st;if(S.query||S.view||S.sec==='overview')return;
    if(this.scrollQueued)return;this.scrollQueued=true;
    requestAnimationFrame(()=>{this.scrollQueued=false;const pane=this.pane();if(!pane)return;const pr=pane.getBoundingClientRect(),pt=pr.top+pr.height*.35;let cur=null;
      for(const g of pane.querySelectorAll('[data-grp]'))if(g.getBoundingClientRect().top<=pt)cur=g.dataset.grp;
      if(cur!==S.curGroup){S.curGroup=cur;this.paintCrumbs();for(const b of pane.querySelectorAll('.f-jump button'))b.classList.toggle('on',b.dataset.g===cur);}});
  }
  onHover(e){
    const row=e.target.closest?.('[data-row]');if(!row||row===this.hoverRow)return;this.hoverRow=row;
    const rec=INDEX.get(row.dataset.row);if(!rec)return;
    const lock=this.lockNote(rec.item,rec.scope);
    this.setHint({click:rec.item.name+(rec.item.desc?' · '+rec.item.desc.toLowerCase():'')+(lock?' · '+lock.toLowerCase():''),shift:''});
  }

  /* ---------------- events ---------------- */
  item(id){return INDEX.get(id)?.item??null;}
  onClick(e){
    if(e.target.closest?.('[data-ks-classic]'))return;   // classic islands keep their own handlers
    const b=e.target.closest?.('[data-act]');if(!b||b.disabled)return;
    const a=b.dataset.act,id=b.dataset.id,v=b.dataset.v,S=this.st,ctx=this.ctx;
    switch(a){
      case 'go':return this.go(v);
      case 'top':S.curGroup=null;this.tweenScroll(this.pane(),0);this.paintCrumbs();return;
      case 'goto':return this.goTo(id);
      case 'jump':{this.flushRest();const el=this.pane()?.querySelector(`[data-grp="${CSS.escape(b.dataset.g)}"]`);if(el)this.tweenTo(el,40);S.curGroup=b.dataset.g;this.paintCrumbs();
        for(const x of this.pane().querySelectorAll('.f-jump button'))x.classList.toggle('on',x.dataset.g===S.curGroup);return;}
      case 'clear':this.setQuery('');this.island.querySelector('.f-search input')?.focus();return;
      case 'parts':S.openParts.has(id)?S.openParts.delete(id):S.openParts.add(id);S.openParts.has(id)?lastOpen.add(id):lastOpen.delete(id);this.paintPane(true);return;
      case 'detail':S.detailOpen=S.detailOpen===id?null:id;this.paintPane(true);return;
      case 'flip':{const it=this.item(id);if(!it)return;const on=this.isSwitchOn(it,this.value(it)),next=it.on!==undefined?(on?it.off:it.on):!on;
        return void this.change(it,next,`${it.name} ${on?'off':'on'}`);}
      case 'choose':{const it=this.item(id);if(!it)return;if(this.value(it)===v)return;const o=it.opts?.find(o=>o.id===v);return void this.change(it,v,`${it.name} · ${o?.label??v}`);}
      case 'reset':{const it=this.item(id);if(!it)return;return void this.change(it,this.resetValue(it),`${it.name} back to default`);}
      case 'press':{const it=this.item(id);if(it)void Promise.resolve(this.press(it)).catch(err=>ctx.fail(err));return;}
      case 'partsAll':{const r=this.item(id);return void this.apply(r.parts.filter(p=>p.type==='switch').map(p=>({c:p,value:v==='1'?(p.on??true):(p.off??false)})),`${r.name} · every part ${v==='1'?'on':'off'}`);}
      case 'allSec':{const sec=sectionById(S.sec),list=this.sectionSwitches(sec);
        return void this.apply(list.map(r=>({c:r.item,value:v==='1'?(r.item.on??true):(r.item.off??false)})),`${sec.name} · ${list.length} switches ${v==='1'?'on':'off'}`);}
      case 'resetSec':{const sec=sectionById(S.sec),list=ORDER.filter(r=>r.sec===sec&&this.changed(r)&&this.editable(r.item,r.scope));
        return void this.apply(list.map(r=>({c:r.item,value:this.resetValue(r.item)})),`${sec.name} · ${list.length} back to default`);}
      case 'pin':{const pins=pinnedSections(ctx.ui),on=pins.includes(S.sec),name=sectionById(S.sec).name;
        void ctx.saveUI({pinnedSections:on?pins.filter(x=>x!==S.sec):[...pins,S.sec].slice(-PIN_CAP)}).then(()=>this.repaint());ctx.message(on?name+' unpinned from Home':name+' pinned to Home');return;}
      case 'preset':return this.applyPreset(PRESETS.find(p=>p.id===v));
      case 'change':this.state.changeOpen=!this.state.changeOpen;this.repaint();return;
      case 'pinTo':this.state.changeOpen=false;void ctx.controller.pin(v).then(()=>ctx.refresh()).catch(err=>ctx.fail(err));return;
      case 'unpin':void ctx.controller.savePreferences({followSelection:true,pinnedActor:null,pinnedToken:null}).then(()=>ctx.controller.redraw(true)).then(()=>ctx.message('Following your selected token'));return;
      case 'keys':return ctx.openKeys();
    }
  }
  onInput(e){
    const t=e.target;if(t.dataset?.act!=='slide')return;
    const it=this.item(t.dataset.id);if(!it)return;const n=Number(t.value);
    t.nextElementSibling.textContent=it.fmt(n);t.style.setProperty('--p',Math.round((n-it.min)/(it.max-it.min)*100)+'%');
  }
  onChange(e){
    const t=e.target;if(t.closest?.('[data-ks-classic]'))return;
    const it=this.item(t.dataset?.id);if(!it)return;
    if(t.dataset.act==='slide'){const n=Number(t.value);void this.change(it,n,`${it.name} · ${it.fmt(n)}`);}
    if(t.dataset.act==='select'){const o=it.opts.find(o=>o.id===t.value);void this.change(it,t.value,`${it.name} · ${o?.label??t.value}`);}
  }
  applyPreset(p){
    const ctx=this.ctx,before={localQ:this.model.localQuality?.preset??'inherit',fm:ctx.ui.fm??'Normal',petals:ctx.ui.petals!==false,wingLightStyle:setting('wingLightStyle')};
    const apply=async set=>{
      await ctx.saveUI({fm:set.fm,petals:set.petals});
      if(setting('wingLightStyle')!==set.wingLightStyle)await game.settings.set(ID,'wingLightStyle',set.wingLightStyle);
      await ctx.api().setLocalQuality?.({preset:set.localQ,wingDetail:null,bitDetail:null,effectDetail:null,textureFPS:null,transitionFPS:null,trails:null,treatment:null});
      ctx.refresh();
    };
    ctx.pushUndo(p.name+' preset',()=>apply(before));
    void apply(p.set).then(()=>{ctx.message(p.name+' applied · your view only');this.repaint();}).catch(e=>ctx.fail(e));
  }
}
/** Sections for the Home tab's Pressed row (pinned to Home). */
export const SETTINGS_SECTIONS=SECTIONS.filter(s=>s.id!=='overview').map(s=>({id:s.id,name:s.short??s.name}));
export {FEATURES};
