/** Keepsake sheet (beta.27): who sees it, and what each tab shows.
 *
 *  Off       nobody's sheet changes (the default).
 *  Just me   her sheet opens in the Keepsake style on this browser only.
 *            "Her" is the character pinned in the HUD (else your assigned
 *            character). Hidden fields are kept on this browser.
 *  Everyone  her sheet opens in the Keepsake style for everyone who can open
 *            it, the GM included. Kept on her actor, with the hidden fields,
 *            so everyone sees the same sheet. Only her owners can choose it.
 *
 * Her portrait choices (portrait studio) are kept on her actor, so the HUD
 * and the sheet show the same picture on every screen. */
import {SHEET_MODES,cleanHidden,cleanPortrait,toggleHidden} from './model.mjs?v=12.1.0-beta.1';

const ID='filament-flight';
export const SHEET_DEFAULTS=Object.freeze({mode:'off',hidden:{},size:null,locked:false,pos:null});

export function registerSheetSettings(onChange=()=>{}){
  game.settings.register(ID,'keepsakeSheet',{name:'Keepsake character sheet',scope:'client',config:false,type:Object,default:{...SHEET_DEFAULTS},onChange:()=>onChange()});
}
export function clientSheet(){
  let raw={};try{raw=game.settings.get(ID,'keepsakeSheet')??{};}catch{}
  raw=raw&&typeof raw==='object'?raw:{};
  return {mode:SHEET_MODES.includes(raw.mode)?raw.mode:'off',hidden:cleanHidden(raw.hidden),
    size:raw.size&&Number.isFinite(raw.size.width)&&Number.isFinite(raw.size.height)?{width:Math.round(raw.size.width),height:Math.round(raw.size.height)}:null,
    // (beta.34) size locked: no resizing, and it opens at this size and place every time
    locked:raw.locked===true,pos:raw.pos&&Number.isFinite(raw.pos.left)&&Number.isFinite(raw.pos.top)?{left:Math.round(raw.pos.left),top:Math.round(raw.pos.top)}:null};
}
let saving=Promise.resolve();
export function saveClientSheet(patch){
  const next={...clientSheet(),...patch};
  saving=saving.catch(()=>{}).then(()=>game.settings.set(ID,'keepsakeSheet',next));
  return saving;
}

/** Her: the character pinned in the HUD on this browser, else the user's own. */
export function herActorId(){
  try{const p=game.settings.get(ID,'hudPreferences');if(p&&!p.followSelection&&typeof p.pinnedActor==='string'&&p.pinnedActor)return p.pinnedActor;}catch{}
  return game.user?.character?.id??null;
}
export function herActor(){const id=herActorId();return id?game.actors?.get?.(id)??null:null;}

/** The sheet flag on an actor (Everyone mode and its hidden fields). */
export function actorSheetFlag(actor){
  try{const f=actor?.getFlag?.(ID,'keepsakeSheet');return f&&typeof f==='object'?f:null;}catch{return null;}
}
/** Is this actor's sheet in the Keepsake style on this browser? */
export function keepsakeOn(actor){
  if(!actor||actor.type!=='character')return false;
  if(actorSheetFlag(actor)?.everyone)return true;
  return clientSheet().mode==='me'&&actor.id===herActorId();
}
/** The mode as the settings show it, for her (or a given) actor. */
export function sheetMode(actor=herActor()){
  if(actor&&actorSheetFlag(actor)?.everyone)return 'everyone';
  return clientSheet().mode==='me'?'me':'off';
}
export function canChooseEveryone(actor=herActor()){return !!actor?.isOwner;}

/** Where the hidden fields live for this actor: on her actor (Everyone) or here. */
export function hiddenFields(actor){
  const f=actorSheetFlag(actor);
  return f?.everyone?cleanHidden(f.hidden):clientSheet().hidden;
}
export function hiddenScope(actor){return actorSheetFlag(actor)?.everyone?'everyone':'me';}
export function canEditFields(actor){return hiddenScope(actor)==='me'||!!actor?.isOwner;}
export async function setHiddenFields(actor,keys){
  if(hiddenScope(actor)==='everyone'){
    if(!actor?.isOwner)throw new Error('Only her owner can change what her Keepsake sheet shows for everyone.');
    const f=actorSheetFlag(actor)??{};
    return actor.setFlag(ID,'keepsakeSheet',{...f,hidden:toggleHidden(cleanHidden(f.hidden),keys)});
  }
  return saveClientSheet({hidden:toggleHidden(clientSheet().hidden,keys)});
}

/** Off / Just me / Everyone. Everyone writes her actor (her owners only). */
export async function setSheetMode(mode,actor=herActor()){
  if(!SHEET_MODES.includes(mode))throw new Error(`Unknown Keepsake sheet mode: ${mode}`);
  if(!actor)throw new Error('Pin her in the HUD first (or assign your character), so the sheet knows whose it is.');
  const flag=actorSheetFlag(actor);
  if(mode==='everyone'){
    if(!actor.isOwner)throw new Error('Only her owner can show her Keepsake sheet to everyone.');
    // the fields hidden here come along, so the sheet looks the same for everyone
    await actor.setFlag(ID,'keepsakeSheet',{...(flag??{}),everyone:true,hidden:cleanHidden(flag?.hidden&&Object.keys(flag.hidden).length?flag.hidden:clientSheet().hidden)});
    await saveClientSheet({mode:'me'});
    return;
  }
  if(flag?.everyone){
    if(!actor.isOwner)throw new Error('Her owner shows her Keepsake sheet to everyone; only they can change that.');
    await actor.setFlag(ID,'keepsakeSheet',{...flag,everyone:false});
  }
  await saveClientSheet({mode});
}

/** Her portrait choices (portrait studio), on her actor. */
export function portraitConfig(actor){try{return cleanPortrait(actor?.getFlag?.(ID,'portrait'));}catch{return cleanPortrait(null);}}
export async function savePortraitConfig(actor,patch){
  if(!actor?.isOwner)throw new Error('Only her owner can change her portrait.');
  const next=cleanPortrait({...portraitConfig(actor),...patch});
  return actor.setFlag(ID,'portrait',next);
}
