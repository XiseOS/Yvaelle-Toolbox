/** Live private previews for the Keepsake HUD. Every surface uses the
 * module's own painters: the wing rig for poses, modes, floats, conditions,
 * reactions, gestures and looks; the compact bit painter for formations; the
 * projected-effect painter for fields. Nothing here writes to the scene. */
import {createWingPreview} from '../animation-preview.mjs?v=12.1.0-beta.1';
import {paintBitPreview,releaseBitPreview} from '../compact-animation-preview.mjs?v=12.1.0-beta.1';
import {paintTokenEffectPreview} from '../token-effects.mjs?v=12.1.0-beta.1';
import {previewQualityConfiguration} from '../quality.mjs?v=12.1.0-beta.1';
import {paintTreatmentPreview} from '../treatment-preview.mjs?v=12.1.0-beta.1';
import {sampleV7Appearance} from '../v7-ensemble.mjs?v=12.1.0-beta.1';
import {treatmentOptions} from '../hardlight-treatment.mjs?v=12.1.0-beta.1';
import {classicTreatmentStyle} from '../hardlight-v7-medkit.mjs?v=12.1.0-beta.1';

import {timed} from './timings.mjs?v=12.1.0-beta.1';
const keyOf=spec=>spec?JSON.stringify(spec):'';

/* (beta.37) Frame capture is time-sliced across display frames for every
 * preview on the page together. (beta.38) A loop's frames are painted on a
 * canvas of their own, never on the one she sees: beta.37 painted them on the
 * visible canvas, so it changed on every display frame a frame was captured
 * (62-64 times a second at 164 Hz, not the 24-30 of playback). And each frame
 * is painted in three steps (her state and the wing geometry; the bits; the
 * painting), on as many display frames as it takes to keep within the
 * allowance: a whole wing frame cost about 4.5 ms on the user's Effects tab,
 * more than a 164 Hz frame has room for next to the canvas. The allowance is
 * CAPTURE_MS a display frame on displays of 100 Hz and more (about a third of
 * the frame on slower ones, so a 60 Hz loop is not three times slower to
 * come); a step runs only when what it took last time fits what is left, and
 * the first step of a display frame always may. */
export const CAPTURE_MS=2;
const bucket={credit:CAPTURE_MS,frame:-1,interval:1000/60,last:0,budget:CAPTURE_MS};
const allowance=()=>Math.max(CAPTURE_MS,Math.min(6,bucket.interval>=10?bucket.interval*.3:CAPTURE_MS));
/** Once per display frame (any preview's rAF): refill the capture allowance. */
function refill(stamp){
  if(bucket.frame===stamp)return;
  if(bucket.last&&stamp>bucket.last)bucket.interval=Math.min(50,Math.max(4,bucket.interval*.9+(stamp-bucket.last)*.1));
  bucket.last=stamp;bucket.frame=stamp;bucket.budget=allowance();bucket.used=0;
  bucket.credit=Math.min(bucket.budget*2,bucket.credit+bucket.budget);
}
/** May a step expected to take `ms` run in this display frame? */
const mayCapture=(ms=0)=>bucket.credit>0&&(!bucket.used||bucket.used+ms<=bucket.budget&&ms<=bucket.credit);
function spend(ms){bucket.credit-=ms;bucket.used=(bucket.used||0)+ms;}
/* (beta.39) Capture runs in the browser's idle time: after a frame is drawn and before the next is due
 * (requestIdleCallback's deadline), a step only when what it took last time fits what is left, with a
 * margin. Beta.38 ran it in the display frame (2 ms at 164 Hz), which at 164 Hz is time the frame does not
 * have: the hover card halved the frame rate (12.1 ms, was 6.1). A loop's first picture is still made in
 * the display frame, so the card never waits on an idle moment to show something. */
const IDLE_MARGIN=.5,STARVED_MS=150;
const fitsIdle=(deadline,ms)=>{try{return deadline.timeRemaining()>ms+IDLE_MARGIN;}catch{return false;}};
const idleAvailable=()=>typeof globalThis.requestIdleCallback==='function';
/** What each kind of step took last (a running mean), to tell whether the next fits. */
const stepMs={setup:3,prepare:3,bits:1,layer:1,render:1.5};// (a first guess, on the heavy side: a new painter's first steps are its slowest)

/* (beta.37) Finished loops are kept when a preview goes (closing the HUD,
 * changing tab or selection) and taken back when the same animation at the
 * same size and the same look of hers is shown again: reopening the Effects
 * tab replays at once instead of painting the loop again. Most recent first,
 * up to KEEP_BYTES of pictures. */
export const KEEP_BYTES=64e6,KEEP_UNFINISHED=4;
const kept=new Map();// sig#look → cache (insertion order = age)
const bytesOf=c=>(c.w*c.h*4)*c.n;
function park(c){
  // (beta.38) a loop still being captured is kept too, with its painter, and carries on where it was when it shows again
  if(!c?.ready||!c.id||c.sealing&&!c.done||!c.frames.some(Boolean))return false;
  kept.delete(c.id);kept.set(c.id,c);
  let total=0;for(const k of kept.values())total+=bytesOf(k);
  for(const [id,k] of kept){if(total<=KEEP_BYTES||k===c)break;kept.delete(id);total-=bytesOf(k);k.dropped=true;freePainter(k);for(const b of [...k.frames,...k.extra])b?.close?.();}
  if(bytesOf(c)>KEEP_BYTES){kept.delete(c.id);return false;}
  // (at most KEEP_UNFINISHED unfinished ones: each keeps its painter's canvases; a half-made frame stays with its painter, which nothing else uses)
  // (beta.39: four, was two: a sweep over a menu's options came back to options whose loops had been let go, and painted them again)
  const unfinished=[...kept.values()].filter(k=>!k.done&&k!==c);
  for(const k of unfinished.slice(0,Math.max(0,unfinished.length-(KEEP_UNFINISHED-1)))){kept.delete(k.id);k.dropped=true;freePainter(k);for(const b of [...k.frames,...k.extra])b?.close?.();}
  return true;
}
function unpark(id){const c=kept.get(id);if(c)kept.delete(id);return c??null;}
/** For tests: the parked loops. */
export function keptPreviews(){return {count:kept.size,bytes:[...kept.values()].reduce((n,c)=>n+bytesOf(c),0),ids:[...kept.keys()]};}
/** What her look adds to a preview's picture (the spec is in the slot key). */
const UI_PREFS=new Set(['quickEffects','quickEffectsOpen','homePanel','homePanelOpen','settingsLevel','version','animationFavorites','advancedOpen','advancedGroup','favorites','theme','tab','followSelection','pinnedActor','pinnedToken','reactionEffectsOpen','audioOpen','openSections','position']);
function lookOf(model){
  // (the HUD's own state, its tab, panels and favourites, is in prefs too: not part of the picture)
  const prefs=model?.prefs?Object.fromEntries(Object.entries(model.prefs).filter(([k])=>!UI_PREFS.has(k))):null;
  try{return keyOf([model?.cfg??null,model?.baseAppearance??null,model?.state?.requested??null,prefs,model?.token?.id??null,model?.token?.document?.texture?.src??null]);}catch{return String(Math.random());}
}

/** A finished (or dropped) loop no longer needs its painter or its canvas. */
function freePainter(c){try{c.renderer?.destroy?.();}catch{}c.renderer=null;c.prep=null;if(c.surface){c.surface.width=c.surface.height=1;c.surface=null;}}

export class KeepsakePreviews {
  constructor({getModel,onFail=null,onPhase=null,paused=null}){
    this.getModel=getModel;this.onFail=onFail;this.onPhase=onPhase;this.paused=paused;this.slots=new Map();this.raf=null;this.idle=null;this.last=0;this.failed=new Set();
  }
  /** Attach each canvas[data-ks-preview] to its requested spec. */
  sync(root,specs={}){
    const seen=new Set();
    for(const canvas of root?.querySelectorAll?.('canvas[data-ks-preview]')??[]){
      const name=canvas.dataset.ksPreview,spec=specs[name];if(!spec)continue;seen.add(name);
      let slot=this.slots.get(name);
      if(slot&&slot.canvas!==canvas){this.release(name);slot=null;}
      if(!slot){slot={canvas,renderer:null,key:'',spec:null,elapsed:0,stamp:performance.now(),phase:0};this.slots.set(name,slot);}
      const key=keyOf({...spec,paused:undefined,speed:undefined,restart:undefined});
      if(slot.key!==key||slot.restart!==spec.restart){slot.key=key;slot.restart=spec.restart;slot.elapsed=0;slot.phase=-1;slot.applied=null;slot.wait=true;}
      slot.spec=spec;
    }
    for(const name of [...this.slots.keys()])if(!seen.has(name))this.release(name);
    if(this.slots.size&&!this.raf&&!this.idle)this.loop();
    // A new or changed preview paints just after the next frame is on screen, not
    // inside this render: the menu or row that asked for it shows first (painting
    // a wing rig for the first time can take longer than a frame) (menus pass, beta.32).
    if(!this.first&&[...this.slots.values()].some(s=>s.wait)){
      const win=globalThis;this.first=win.requestAnimationFrame(()=>{this.firstT=setTimeout(()=>{this.first=null;this.firstT=null;
        for(const slot of this.slots.values())if(slot.wait){slot.wait=false;this.drawSlot(slot,performance.now(),true);}},0);});
    }
  }
  release(name){
    const slot=this.slots.get(name);if(!slot)return;
    this.dropCache(slot);
    try{slot.renderer?.destroy?.();}catch{}
    try{if(slot.bits)releaseBitPreview(slot.canvas);}catch{}
    this.slots.delete(name);
  }
  destroy(){for(const name of [...this.slots.keys()])this.release(name);if(this.raf)cancelAnimationFrame(this.raf);if(this.idleCap){try{globalThis.cancelIdleCallback?.(this.idleCap);}catch{}this.idleCap=null;}if(this.first)cancelAnimationFrame(this.first);clearTimeout(this.firstT);clearTimeout(this.idle);this.raf=null;this.idle=null;this.first=null;this.firstT=null;}
  loop(){
    const tick=now=>{
      this.raf=null;if(!this.slots.size)return;
      // Minimised HUD: look again a few times a second, paint nothing.
      if(this.paused?.()){this.idle=setTimeout(()=>{this.idle=null;if(this.slots.size)this.raf=requestAnimationFrame(tick);},250);return;}
      // at most 30 a second (an even two-frame hold at 60 Hz; the previews paint on the main thread); the timing keeps its remainder so 24 fps really is 24
      const model=this.getModel(),fps=Math.min(30,previewQualityConfiguration(model?.cfg??{}).rigFPS||24),step=1000/fps;
      refill(now);
      for(const slot of this.slots.values())if(slot.cache&&!slot.cache.done&&!slot.wait){
        // (and when no idle moment has come for STARVED_MS, one display frame's allowance, so a busy page still fills its loops)
        if(!idleAvailable()||!slot.cache.frames?.[0]||now-(this.idleRan??now)>STARVED_MS){this.captureStep(slot,model);this.idleRan=now;}
        else{this.idleRan??=now;this.captureIdle();}
      }
      if(now-this.last>=step-1){this.last=now-this.last>step*3?now:this.last+step;for(const slot of this.slots.values())if(!slot.wait)this.drawSlot(slot,now,slot.phase===-1);}
      this.raf=requestAnimationFrame(tick);
    };
    this.raf=requestAnimationFrame(tick);
  }
  /** (beta.39) One idle callback at a time runs the capture steps of every preview, in idle time only. */
  captureIdle(){
    if(this.idleCap)return;
    this.idleCap=globalThis.requestIdleCallback(deadline=>{
      this.idleCap=null;if(!this.slots.size||this.paused?.())return;
      const model=this.getModel(),before=this.idleSteps??0;
      // (an idle moment that never came within half a second: one display frame's allowance, as before)
      for(const slot of this.slots.values())if(slot.cache&&!slot.cache.done&&!slot.wait)this.captureStep(slot,model,deadline.didTimeout?null:deadline);
      if((this.idleSteps??0)>before)this.idleRan=performance.now();
    },{timeout:500});
  }
  size(canvas){
    const r=canvas.getBoundingClientRect(),dpr=Math.min(2,globalThis.devicePixelRatio||1);
    // (beta.39) by its laid-out size, and the scale it is shown at to a tenth: the hover card's swap
    // (scale .96 to 1 over half a second, on each option) changed its on-screen size every frame, and
    // each new size started its loop again from nothing, so a hover captured its first frames over and over
    const lw=canvas.clientWidth,lh=canvas.clientHeight,k=lw>0&&lh>0?Math.max(.1,Math.round(r.width/lw*10)/10):0;
    const w=Math.max(64,Math.round((k?lw*k:r.width)*dpr)),h=Math.max(64,Math.round((k?lh*k:r.height)*dpr));
    if(r.width&&(canvas.width!==w||canvas.height!==h)){canvas.width=w;canvas.height=h;}
  }
  drawSlot(slot,now,force=false){
    const {canvas,spec}=slot;if(!canvas.isConnected||!spec)return;
    const model=this.getModel();if(!model?.token)return;
    const dt=Math.min(250,now-slot.stamp);slot.stamp=now;
    if(!canvas.getClientRects().length)return;// not laid out: a collapsed or minimised window
    const reduced=!!model.cfg?.reduced;
    if(!spec.paused&&!reduced)slot.elapsed+=dt*(spec.speed??1);
    if(!force&&(spec.paused||reduced)&&slot.drawn)return;
    this.size(canvas);
    // A/B comparison: alternate between two selections on a fixed beat.
    let active=spec;
    if(spec.alternate?.length===2){const phase=Math.floor(slot.elapsed/2600)%2;active=spec.alternate[phase];if(phase!==slot.phase){slot.phase=phase;slot.applied=null;this.onPhase?.(phase);}}
    else slot.phase=0;
    try{
      // (a loop being captured counts as drawn once its first frame shows: a paused preview still gets it)
      if(this.cacheable(slot,active,reduced)){if(this.drawCached(slot,active,model,reduced))slot.drawn=true;}
      else{timed('preview:paint',()=>this.paint(slot,active,slot.elapsed,model,reduced));slot.drawn=true;}
    }catch(error){this.fail(slot,error);}
  }
  fail(slot,error){
    const name=[...this.slots.entries()].find(([,s])=>s===slot)?.[0];
    if(name&&!this.failed.has(name)){this.failed.add(name);console.warn('Yvaelle’s Toolbox | Keepsake preview unavailable',error);this.onFail?.(name,error);}
    if(name)this.release(name);
  }
  /** Paint one frame of a preview at time t (ms). */
  paint(slot,active,t,model,reduced){
    const {canvas,spec}=slot;
      if(active.kind==='bits'){
        const g=model.state?.gems??{};
        paintBitPreview(canvas,{...g,quality:'medium',id:active.id,count:active.count??4,elapsed:t,background:'transparent',accent:model.baseAppearance?.filamentColor??'#ff00ff',textColor:'#f3eadf',tokenImage:null,previewWork:true});
        slot.bits=true;
      }else if(active.kind==='treatment'){
        // the treatment preview loops: travel, scan, work and the chosen result
        // as she would really do it: her technique library (V7), V9 craft and the scan choice,
        // looped on the treatment's own length so the bits always get home
        const key=JSON.stringify([active.style,active.scan,active.outcome,active.count]);
        if(slot.tKey!==key){slot.tKey=key;slot.loop=0;
          const cfg=previewQualityConfiguration(model?.cfg??{}),raw=model.token?.document?.getFlag?.('filament-flight','flight')??{},v7=sampleV7Appearance(raw.v7,cfg,0),enhanced=!!(v7.enabled&&v7.medkit);
          let opts;try{opts=treatmentOptions({style:enhanced?active.style:classicTreatmentStyle(active.style),diagnosticScan:active.scan!==false,enhanced});}catch{opts=treatmentOptions({style:'suture'});}
          slot.tParams={...opts,count:active.count??2,v7,v9MedicalCraft:cfg.v9MedicalCraft===true,outcome:active.outcome??'success',background:'transparent',zoom:active.zoom??1};}
        const f=paintTreatmentPreview(canvas,{...slot.tParams,reduced},slot.loop?t%slot.loop:t);
        if(!slot.loop&&f?.duration)slot.loop=f.duration+900;
      }else if(active.kind==='tokenFX'){
        paintTokenEffectPreview(canvas,{id:active.id,count:active.count??4,elapsed:t,activationElapsed:t,background:'transparent',color:model.baseAppearance?.filamentColor??'#ff00ff',tokenColor:'#2b1d27',textColor:'#f3eadf',strength:.7,animated:!reduced});
      }else{
        if(!slot.renderer){
          slot.renderer=createWingPreview(canvas,{configOverrides:model.cfg,appearance:model.baseAppearance,request:model.state?.requested,prefs:model.prefs,sourceToken:model.token,background:'transparent',tokenLabel:(model.token?.document?.name??'E').slice(0,1),groundMarker:spec.ground!==false});
        }
        const sel=active.selection,skey=keyOf(sel);
        if(slot.applied!==skey){slot.renderer.setSelection(sel);slot.applied=skey;}
        slot.renderer.draw(t);
      }
  }

  /* ---- Frame cache (beta.34) -------------------------------------------
   * The Effects stage plays one animation on a loop. Painting the wing rig on
   * the main thread 30 times a second cost about 4 ms a frame; instead its
   * frames are painted once, a few per animation frame (at most 6 ms of work
   * each), kept as ImageBitmaps and replayed: a replayed frame is one
   * drawImage on the graphics card. Reactions and gestures loop on their own
   * cycle; continuous motion is captured for 4 s and its seam cross-faded.
   * A new selection, a resize or Compare starts again; Pause and ½ speed
   * just move through the same frames. */
  cacheable(slot,active,reduced){
    return !!slot.spec?.cache&&!reduced&&!slot.spec.alternate&&['wing',undefined].includes(active.kind)&&typeof createImageBitmap==='function';
  }
  drawCached(slot,active,model,reduced){
    const {canvas}=slot;
    let c=slot.cache;
    const sig=slot.key+'|'+canvas.width+'x'+canvas.height;
    if(!c||c.sig!==sig){
      this.dropCache(slot);
      const id=sig+'#'+lookOf(model);
      // (a loop kept from before replays at once; a new one is set up and painted by captureStep, a step per display frame)
      c=slot.cache=unpark(id)??{id,sig,w:canvas.width,h:canvas.height,ready:false,frames:[],extra:[],next:0,done:false,active,reduced};
    }
    c.active=active;c.reduced=reduced;
    if(!c.ready)return false;
    // show the frame for now (the newest one captured, until the loop is complete); until frame 0 is ready the canvas keeps what it shows
    const want=Math.floor(((slot.elapsed%c.L)+c.L)%c.L/c.step)%c.n;
    let k=want;while(k>0&&!c.frames[k])k--;
    const frame=c.frames[k];if(!frame)return false;if(slot.shown===frame)return true;
    timed('preview:replay',()=>{const g=canvas.getContext('2d');g.clearRect(0,0,canvas.width,canvas.height);g.drawImage(frame,0,0);});
    slot.shown=frame;return true;
  }
  /** More steps of a loop being captured, while this display frame's allowance has room. */
  captureStep(slot,model,deadline=null){
    const c=slot.cache;if(!c||c.done||!slot.canvas.isConnected||!model?.token)return;
    for(let guard=0;guard<24&&!c.done&&slot.cache===c;guard++){
      const kind=!c.ready?'setup':!c.prep?'prepare':c.prep.bitsPending?'bits':c.renderer.layersLeft?.(c.prep)?.length>1?'layer':'render';
      if(kind!=='setup'&&c.next>=c.n+c.fade)return;
      // (beta.39) in the time the browser has left before the next frame (an idle callback), or, until the
      // loop's first picture shows, in the display frame's allowance as before
      if(deadline?!fitsIdle(deadline,stepMs[kind]):!mayCapture(stepMs[kind]))return;
      // ('live', the hover card: keep a little ahead of what it plays, not the whole loop at once)
      if(kind==='prepare'&&slot.spec?.cache==='live'){const want=Math.floor(((slot.elapsed%c.L)+c.L)%c.L/c.step)%c.n;if(c.next>want+2&&c.next<c.n)return;}
      const t0=globalThis.performance?.now?.()??0;
      this.idleSteps=(this.idleSteps??0)+1;
      try{timed('preview:capture',()=>this.captureOne(slot,c,model));}catch(error){this.fail(slot,error);return;}
      finally{const ms=(globalThis.performance?.now?.()??0)-t0;spend(ms);stepMs[kind]=stepMs[kind]*.7+ms*.3;}
    }
  }
  /** One step: set the loop up (its own canvas and painter, its length), or
   * a frame's state and geometry (prepare), its bits, or its painting
   * (render) and the picture taken of it. */
  captureOne(slot,c,model){
    if(!c.ready){
      const {canvas,spec}=slot,doc=canvas.ownerDocument??globalThis.document;
      const surface=doc.createElement('canvas');surface.width=c.w;surface.height=c.h;
      const renderer=createWingPreview(surface,{configOverrides:model.cfg,appearance:model.baseAppearance,request:model.state?.requested,prefs:model.prefs,sourceToken:model.token,background:'transparent',tokenLabel:(model.token?.document?.name??'E').slice(0,1),groundMarker:spec?.ground!==false});
      renderer.setSelection(c.active.selection);
      const fps=Math.min(30,previewQualityConfiguration(model?.cfg??{}).rigFPS||24),step=1000/fps;
      const exact=renderer.loopLength?.();
      const L=exact>0?exact:4000,fade=exact>0?0:Math.round(400/step);
      const max=Math.max(24,Math.floor(64e6/(c.w*c.h*4)));
      const n=Math.min(max,Math.max(1,Math.round(L/step)));
      Object.assign(c,{surface,renderer,L,n,step:L/n,fade:Math.min(fade,Math.floor(n/4)),frames:new Array(n).fill(null),extra:[],next:0,prep:null,ready:true});
      return;
    }
    const total=c.n+c.fade;if(c.next>=total)return;
    if(!c.prep){c.prep=c.renderer.prepare(c.next*c.step,{deferBits:true})??{empty:true};return;}
    if(c.prep.bitsPending){c.renderer.prepareBits(c.prep,{one:true});return;}
    // (beta.39) the wing layers one at a time; the last is painted with the picture
    const left=c.renderer.layersLeft?.(c.prep)??[];if(left.length>1){c.renderer.paintLayer(c.prep,left[0]);return;}
    const k=c.next++;c.renderer.render(c.prep);c.prep=null;
    const p=createImageBitmap(c.surface).then(b=>{if(c.dropped){b.close?.();return;}if(k<c.n)c.frames[k]=b;else c.extra[k-c.n]=b;},()=>{});
    (c.pending??=[]).push(p);
    if(c.next>=total&&!c.sealing){c.sealing=true;Promise.all(c.pending).then(()=>this.sealCache(slot,c));}
  }
  /** Cross-fade the first frames from the frames that follow the loop, so the seam doesn't jump. */
  async sealCache(slot,c){
    try{
      if(c.fade&&c.extra.length===c.fade){
        const w=c.w,h=c.h,off=typeof OffscreenCanvas==='function'?new OffscreenCanvas(w,h):Object.assign(slot.canvas.ownerDocument.createElement('canvas'),{width:w,height:h}),g=off.getContext('2d');
        for(let j=0;j<c.fade;j++){
          const a=c.frames[j],b=c.extra[j];if(!a||!b)continue;
          g.clearRect(0,0,w,h);g.globalAlpha=1;g.drawImage(b,0,0);g.globalAlpha=(j+1)/(c.fade+1);g.drawImage(a,0,0);g.globalAlpha=1;
          const mixed=await createImageBitmap(off);if(c.dropped){mixed.close?.();return;}
          a.close?.();c.frames[j]=mixed;
        }
      }
      for(const b of c.extra)b?.close?.();c.extra=[];
      if(!c.dropped)c.done=true;
    }catch{}
    finally{if(c.done)freePainter(c);}
  }
  dropCache(slot){const c=slot.cache;if(!c)return;slot.cache=null;slot.shown=null;if(park(c))return;c.dropped=true;freePainter(c);for(const b of [...c.frames,...c.extra])b?.close?.();}
}
