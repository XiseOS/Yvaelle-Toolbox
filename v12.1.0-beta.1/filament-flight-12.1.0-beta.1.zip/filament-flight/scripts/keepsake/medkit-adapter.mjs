/** Bridge between Ellie's Medkit window and the Medkit engine: turns the
 * engine's context into the window's view model, and the window's choices
 * into an engine plan. No rules live here. */
import {medkitContext,runMedkitPlan,partyImmunities} from '../medkit-engine.mjs?v=12.1.0-beta.1';
import {healthEstimate,healthScale} from '../health-estimate.mjs?v=12.1.0-beta.1';

const MODE_KICKER={battleMedicine:'1 action',directiveOne:'1 action · directive',leadByExample:'2 actions · directive',treatWounds:'10 minutes'};
const MODE_SUB={battleMedicine:'Heal in the fight · immune for a day',directiveOne:'+{bonus} to their next healing',leadByExample:'Battle Medicine, then the directive',treatWounds:'Heal out of combat · immune for {tw}'};
const RANK_NAMES={1:'Trained',2:'Expert',3:'Master',4:'Legendary'};

/** Spread the free bits as evenly as possible (2 patients: 2+2; 3: 2+1+1). */
export function splitBits(free,ids){
  const out={},n=ids.length;if(!n)return out;const bits=Math.min(4,Math.max(0,free));
  ids.forEach((id,i)=>{out[id]=bits>=n?Math.floor(bits/n)+(i<bits%n?1:0):(i<bits?1:0);});return out;
}
let lastContext=null;
export function medkitView(token,targets){
  const mock=globalThis.__mkMock;if(mock)return mock.view(token,targets);
  if(!token)throw new Error('Select or pin the healer first.');
  const c=medkitContext({healer:token,patients:targets});lastContext=c;
  if(!c?.ok)throw new Error(c?.error?.message??'The Medkit is unavailable.');
  const opts=c.preferences?.options??{},scale=healthScale();
  return {
    raw:c,maxPatients:c.maxPatients??4,freeBits:c.animation?.freeBits?.length??0,animationAvailable:!!c.animation?.available,
    healer:{name:c.healer?.name,rank:RANK_NAMES[c.healer?.rank]??''},
    modes:(c.modes??[]).map(m=>({id:m.id,name:m.label.replace(/ \((?:1|2) Actions?\)$/,''),cost:MODE_KICKER[m.id]??'',sub:(MODE_SUB[m.id]??'').replace('{bonus}',c.healer?.directiveBonus??0).replace('{tw}',c.treatWounds?.immunityText??'1 hour'),available:!!m.available,reason:m.reason??'Not available',needsConfirm:m.needsConfirm??null})),
    treatWounds:{risky:!!c.treatWounds?.riskySurgery,continual:!!c.treatWounds?.continualRecovery,immunityText:c.treatWounds?.immunityText??'1 hour'},directiveBonus:c.healer?.directiveBonus??0,
    dcs:(c.dcOptions??[]).map(d=>({id:d.rank,dc:d.dc,name:RANK_NAMES[d.rank]??d.label,available:true,heal:`Heals 2d8${d.baseHeal?` + ${d.baseHeal}`:''}${c.medic?.has&&d.medicHeal?` · Medic +${d.medicHeal}`:''}`})),
    medic:{has:!!c.medic?.has,bypassReady:!!c.medic?.bypassAvailable,cooldown:c.medic?.cooldownText||c.medic?.cooldown?.text||'',
      note:c.medic?.has?(c.medic.bypassAvailable?'Treat one immune patient anyway (once a day; once an hour at Master)':c.medic.cooldownText||`Bypass unavailable for ${c.medic.cooldown?.text??'a while'}`):''},
    patients:(c.patients??[]).map(p=>({uuid:p.id,name:p.name,img:p.img,health:healthEstimate(p.actor,scale),owned:p.owned,
      immune:p.immune?.status==='immune'?{remaining:p.immune.text??'a while'}:null,unlabeled:p.immune?.status==='unlabeled'?{remaining:p.immune.text??''}:null,
      immunities:Object.fromEntries(['battleMedicine','treatWounds'].map(k=>{const i=p.immunities?.[k]??(k==='battleMedicine'?p.immune:null);
        return [k,{immune:i?.status==='immune'?{remaining:i.text??'a while'}:null,unlabeled:i?.status==='unlabeled'?{remaining:i.text??''}:null}];}))})),
    techniques:(c.animation?.catalog??[]).filter(t=>t.id!=='random').map(t=>({...t,group:t.group})),
    animationOptions:{bits:opts.bits??2,intensity:opts.intensity??1,scale:opts.scale??1,detail:opts.detail??'standard',variation:opts.variation,
      audioProfiles:opts.audioProfiles??{},v7:c.animation?.v7??{},stages:c.animation?.soundStages??{},previewAvailable:!!c.animation?.previewAvailable,
      units:globalThis.canvas?.scene?.grid?.units||'ft'},
    prefs:{style:opts.style??'random',together:c.preferences?.together!==false,sound:opts.audio===true,scan:opts.diagnosticScan!==false,animate:c.preferences?.animation!==false,cards:c.preferences?.chatCards===true,dc:c.defaultRank}
  };
}
export async function runMedkitView(token,choice,onProgress,choose){
  const mock=globalThis.__mkMock;if(mock)return mock.run(token,choice,onProgress,choose);
  const c=lastContext;if(!c?.ok)throw new Error('The Medkit is unavailable.');
  const options={...(c.preferences?.options??{}),style:choice.style,audio:!!choice.sound,diagnosticScan:!!choice.scan};
  const label={animation:'Bits on their way',rolling:'Rolling Medicine',start:null,directive:'Directive given',rolled:null,healing:null,harm:null,immunity:'Immunity set',medicBypass:'Medic reaches past immunity'};
  const result=await runMedkitPlan({mode:choice.mode.id,rank:choice.dc?.id??null,together:!!choice.together,patients:choice.patients.map(p=>p.uuid),
    unlabeledFromHealer:choice.unlabeled??[],medicBypassFor:choice.medicFor??null,riskySurgery:!!choice.risky,chatCards:choice.cards===true,
    animation:{enabled:!!c.animation?.available&&choice.animate!==false,options:c.animation?.normalize?c.animation.normalize(options):options}},
    {context:c,choose,onProgress:e=>{
      const ids=e.patient?[e.patient]:e.patients??[];
      for(const uuid of ids){
        let text=label[e.type];
        if(e.type==='rolled')text=`Rolled ${e.total} · ${String(e.outcome??'').replace(/([A-Z])/g,' $1').toLowerCase()}`;
        if(e.type==='healing')text=`Healing ${e.amount}`;
        if(e.type==='harm')text=e.surgery?`Surgery · ${e.amount}`:`Hurt ${e.amount}`;
        if(e.type==='directive')text=`+${e.bonus} to next healing`;
        if(text)onProgress({uuid,label:text,done:e.type==='healing'||e.type==='harm'&&!e.surgery||e.type==='immunity'||e.type==='directive'});
      }
    }});
  if(!result||result.cancelled)return null;
  if(result.ok===false&&result.error)throw new Error(result.error.message??String(result.error));
  return (result.patients??[]).map(p=>{
    const skipped=p.status!=='treated';
    const heal=p.healing??0,harm=p.harm??0;
    return {uuid:p.id,name:p.name,outcome:p.outcome,skipped,reason:skipped?(p.status==='limit'?'Next time':'Immune'):null,
      amount:heal,harm,immunity:!!p.immunity,directive:!!p.directive,
      label:p.outcome?String(p.outcome).replace(/([A-Z])/g,' $1').toLowerCase():null,
      summary:skipped?(p.text??(p.status==='limit'?'not treated this time':'immune')):[heal?`healed ${heal}`:'',harm?`took ${harm}`:'',p.medicBypass?'Medic bypass':'',p.outcome==='criticalSuccess'?'critical':''].filter(Boolean).join(' · ')||'no healing'};
  });
}
export function saveMedkitChoices(patch){
  const mock=globalThis.__mkMock;if(mock)return mock.save?.(patch);
  const c=lastContext;if(!c?.savePreference)return;
  try{
    if('together' in patch)void c.savePreference('together',!!patch.together);
    const o={};if('style' in patch)o.style=patch.style;if('sound' in patch)o.audio=!!patch.sound;if('scan' in patch)o.diagnosticScan=!!patch.scan;
    if(Object.keys(o).length){c.preferences.options={...c.preferences.options,...o};void c.savePreference('options',c.preferences.options);}
    if('cards' in patch){c.preferences.chatCards=!!patch.cards;void c.savePreference('chatCards',!!patch.cards);}
    if('animate' in patch){c.preferences.animation=!!patch.animate;void c.savePreference('animation',!!patch.animate);}
  }catch(e){console.warn('Yvaelle’s Toolbox | Medkit preference',e);}
}
/** The party's immunities for the window's Party view. */
export function partyView(token){
  const mock=globalThis.__mkMock;if(mock?.party)return mock.party(token);
  const scale=healthScale();
  return partyImmunities(token).map(p=>({uuid:p.uuid,name:p.name,img:p.img,health:healthEstimate(p.actor,scale),token:p.token,
    bm:{status:p.battleMedicine.status,text:p.battleMedicine.text},tw:{status:p.treatWounds.status,text:p.treatWounds.text}}));
}

/** The animation options the classic dialog used to hold (beta.21): bits to
 * use, brightness, effect size, detail, transition variety, and each
 * technique's sound volume, audible distance and custom stage sounds. */
export function saveMedkitOptions(patch,{style}={}){
  const mock=globalThis.__mkMock;if(mock)return mock.saveOptions?.(patch,style);
  const c=lastContext;if(!c?.savePreference||!c.animation?.normalize)return;
  try{
    const cur={...(c.preferences.options??{})};
    for(const k of ['bits','intensity','scale','detail','variation'])if(k in patch)cur[k]=patch[k];
    if(patch.audio&&style){
      const profiles={...(cur.audioProfiles??{})},prev=c.animation.normalizeAudio(profiles[style]??{});
      const next={...prev,...(('volume' in patch.audio)?{volume:patch.audio.volume}:{}),...(('radius' in patch.audio)?{radius:patch.audio.radius}:{}),
        sounds:{...prev.sounds,...(patch.audio.sounds??{})}};
      for(const [stage,src] of Object.entries(next.sounds))if(!src)delete next.sounds[stage];
      profiles[style]=c.animation.normalizeAudio(next);cur.audioProfiles=profiles;
    }
    c.preferences.options=c.animation.normalize(cur);void c.savePreference('options',c.preferences.options);
    return c.preferences.options;
  }catch(e){console.warn('Yvaelle’s Toolbox | Medkit options',e);}
}
let preview=null,previewSerial=0;
/** A private preview of the treatment on her token, or just its sound. */
export async function previewMedkit(token,{style,soundOnly=false,sound=false,scan=false}={}){
  const c=lastContext,api=c?._internal?.moduleApi;
  if(typeof api?.previewTreatment!=='function')throw new Error('The treatment preview is unavailable here.');
  await stopMedkitPreview();const serial=++previewSerial;
  const options=c.animation.normalize({...c.preferences.options,style:style??c.preferences.options?.style,audio:sound,diagnosticScan:scan});
  const resolved=c.animation.resolve(options);
  const handle=await api.previewTreatment({style:resolved.style,count:options.bits,intensity:options.intensity,scale:options.scale,detail:options.detail,
    audio:soundOnly||options.audio,diagnosticScan:options.diagnosticScan,enhanced:options.enhanced,variation:options.variation,audioSettings:resolved.audioSettings,source:token,soundOnly});
  if(serial!==previewSerial){const close=handle?.close??handle?.stop;if(close)await close.call(handle);return null;}
  preview=handle;return handle;
}
export async function stopMedkitPreview(){
  previewSerial++;const h=preview;preview=null;
  try{const close=h?.close??h?.stop;if(close)await close.call(h);}catch(e){console.warn('Yvaelle’s Toolbox | Medkit preview stop',e);}
}
