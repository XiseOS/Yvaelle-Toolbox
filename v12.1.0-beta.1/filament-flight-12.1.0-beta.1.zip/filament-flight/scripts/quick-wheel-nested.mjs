/** Yvaelle’s Toolbox v11 · the nested quick wheel (Settings › Emotes & wheel ›
 * Nested wheel). Pure DOM, no Foundry globals (same rule as quick-wheel-ui.mjs),
 * so the module and the stand-alone harness run the same code. The tree and
 * every rule live in quick-wheel-model.mjs; the art in quick-wheel-assets.mjs;
 * the Macros ring in quick-wheel-macros.mjs.
 *
 * Use, on every level:
 *   hold key → point → release   release on a category opens it (the wheel stays);
 *                                rest ~0.26 s on a category opens it while holding;
 *                                FLICK-AHEAD: keep moving out through a category and its
 *                                ring opens at once, so "Her → Take off" is one stroke.
 *                                FAST-FLICK SAFETY: a release fires an option only inside
 *                                its gem, or after resting on it (model.releaseDecision);
 *                                otherwise the wheel stays open for a click.
 *   tap key → click              click a category, then an option.
 *   centre (her token)           release there CANCELS. In a ring, rest there or click
 *                                her to go back.
 *   last used                    a small separate gem just below her rim.
 *   back                         Esc, right-click, the plaque's Back, or click her.
 *   Edit (plaque / right-click)  drag any action onto a socket; drag shortcuts to move,
 *                                off the ring to remove; drag a category onto another
 *                                cardinal to swap; click a category to hide it.
 *
 * Cost: nothing while closed (no listeners, no timers). While open, one rAF
 * loop that only follows her token and steps the emote cameo at its own rate;
 * every animation is a compositor property (transform, opacity, scale,
 * custom-property angles) and nothing reads layout per frame.
 *
 * host = {doc, anchor(), pointer?(), version, config(), saveConfig(cfg), state(), describe(slot),
 *   run(slot), choices(param), catalog, emotes(), macros(), features(), preview?(id), iconFor?(slot),
 *   reducedMotion(), error(e), + the macro ring members (quick-wheel-macros.mjs)} */
import {WHEEL_ICONS,WHEEL_CSS} from './quick-wheel-ui.mjs?v=12.1.0-beta.1';
import * as M from './quick-wheel-model.mjs?v=12.1.0-beta.1';
import {NEW_ICONS,EMOTE_ICONS,MACRO_ICONS,DEFS,FRAME_CAT,FRAME_SHORT,FRAME_LEAF,FRAME_MORE,FRAME_SOCKET,FRAME_LAST,DIVIDER,plaquePath,hardlightFrame,ringMarkup,lookOf,ringOf,HARDLIGHT_CSS} from './quick-wheel-assets.mjs?v=12.1.0-beta.1';
import {MacroRing,MACRO_RING_CSS} from './quick-wheel-macros.mjs?v=12.1.0-beta.1';

const TAU=Math.PI*2,SVGNS='http://www.w3.org/2000/svg',RAD=Math.PI/180;
export const ICONS={...WHEEL_ICONS,...EMOTE_ICONS,...NEW_ICONS,macros:MACRO_ICONS.macros};
const wrap=d=>((d%360)+360)%360;
const adiff=(a,b)=>((a-b+540)%360)-180;
const P=(deg,r)=>[r*Math.sin(deg*RAD),-r*Math.cos(deg*RAD)];
const VALUE_ICON={formation:{halo:'fHalo',sentinel:'fSentinel',lemniscate:'fLemniscate',comet:'fComet',crown:'fCrown',search:'fSearch'},
  pose:{forwardGuard:'pGuard',raised:'pRaised',cocoon:'pCocoon',crossed:'pCrossed',neutral:'pose'},
  reaction:{pulse:'rPulse',flare:'spark',stutter:'rStutter',reform:'rReform'},
  height:{up:'climb',down:'descend',low:'hLow',cruise:'hCruise',high:'hHigh'},
  gesture:{lunarBow:'gLunar'},scanArea:{around:'scanAround'},parkLight:{target:'parkTarget'}};
const SIDE_NAMES={top:'From the top',right:'From the right',bottom:'From the bottom',left:'From the left'};
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const now=()=>performance.now();
const ACTION_KINDS=new Set(['leaf','short','lane','last']);

export const NESTED_CSS=`
@property --ffn-a{syntax:'<angle>';inherits:false;initial-value:0deg}
@property --ffn-rk{syntax:'<number>';inherits:false;initial-value:1}
.ffn{--tin:.34s;--tout:.2s;--stag:26ms}
.ffn.swift{--tin:.14s;--tout:.1s;--stag:0ms}
.ffn svg.ffn-ring{position:absolute;overflow:visible;pointer-events:none}
.ffn svg.ffn-ring .rim{fill:none;stroke:#ff00ff;stroke-width:1.6;filter:drop-shadow(0 0 4px rgba(255,0,255,.9));stroke-dasharray:var(--rl);stroke-dashoffset:var(--rl);transition:stroke-dashoffset .32s cubic-bezier(.3,.8,.3,1),stroke-width .2s,filter .2s}
.ffn svg.ffn-ring .rim.gold{stroke:#cfae76;stroke-width:.8;filter:none;opacity:.8;transition-delay:.05s}
.ffn.open svg.ffn-ring .rim{stroke-dashoffset:0}
.ffn.recv svg.ffn-ring .rim{stroke-width:3;filter:drop-shadow(0 0 9px rgba(255,80,240,1))}
.ffn.recv svg.ffn-ring .rim.gold{stroke:#f3d79a;opacity:1}
.ffn.cancel-pick svg.ffn-ring .rim{stroke:#b9a69c;filter:none;stroke-width:1.2}
.ffn.cancel-pick svg.ffn-ring .rim.gold{opacity:.45}
.ffn .veil{opacity:0;transition:opacity .3s}.ffn.open .veil{opacity:1}
.ffn .half{fill:none;stroke-linecap:round;stroke-dasharray:var(--hl);stroke-dashoffset:var(--hl);transition:stroke-dashoffset .4s cubic-bezier(.2,.75,.25,1)}
.ffn .half.a{stroke:rgba(255,0,255,.85);stroke-width:1.2;filter:drop-shadow(0 0 3px rgba(255,0,255,.8))}
.ffn .half.b{stroke:rgba(207,174,118,.8);stroke-width:.9;transition-delay:.04s}
.ffn .half.c{stroke:rgba(255,190,255,.45);stroke-width:.6;transition-delay:.08s}
.ffn.open .half{stroke-dashoffset:0}
.ffn .feather{fill:none;stroke:rgba(255,120,235,.0);stroke-width:14;filter:blur(5px);transition:stroke .35s}
.ffn.open:not(.settled) .feather{stroke:rgba(255,90,230,.16)}
.ffn .L-main{transition:opacity var(--tout)}
.ffn.sub .L-main{opacity:0}
.ffn .knot{fill:#cfae76;opacity:0;transition:opacity .25s .3s}
.ffn.open .knot{opacity:.85}
.ffn.editing .knot{opacity:0}
.ffn .mote{fill:#fff;filter:drop-shadow(0 0 3px #f0f);opacity:0;transition:opacity .4s .5s}.ffn.open:not(.sub) .mote{opacity:.85}
.ffn .fil{fill:none;stroke:var(--tint);stroke-width:1.3;stroke-linecap:round;filter:drop-shadow(0 0 3px var(--tint));stroke-dasharray:var(--len);stroke-dashoffset:var(--len);opacity:.9;
  transition:stroke-dashoffset .16s cubic-bezier(.4,0,.6,1),opacity .3s}
.ffn .arcg.on .fil{stroke-dashoffset:0}
.ffn .arcg.on.drawn .fil{opacity:.0;transition:opacity .5s .1s}
.ffn .arcline{fill:none;stroke-linecap:round;stroke-dasharray:var(--len);stroke-dashoffset:var(--len);transition:stroke-dashoffset calc(var(--tin)*.8) cubic-bezier(.2,.7,.3,1) calc(var(--tin)*.4)}
.ffn .arcline.a{stroke:var(--tint);stroke-width:1.4;filter:drop-shadow(0 0 3px var(--tint))}
.ffn .arcline.b{stroke:rgba(207,174,118,.7);stroke-width:.7}
.ffn .arcg.on .arcline{stroke-dashoffset:0}
.ffn .band{fill:none;stroke:var(--tint);stroke-width:38;stroke-linecap:round;opacity:0;transition:opacity .3s calc(var(--tin)*.5)}
.ffn .arcg.on .band{opacity:.065}
.ffn .arcg.on.hot .band{opacity:.15;transition-delay:0s;transition-duration:.15s}
.ffn .lane{fill:none;stroke:var(--tint);stroke-width:1;stroke-dasharray:2 4;opacity:0;transition:opacity .3s calc(var(--tin)*.8)}
.ffn .arcg.on .lane{opacity:.55}
.ffn .lbl{opacity:0;transition:opacity .25s calc(var(--tin)*.7),transform .25s}
.ffn .arcg.on .lbl{opacity:.82}
.ffn .arcg.on.hot .lbl{opacity:1;transition-delay:0s}
.ffn .lbl path{fill:rgba(22,10,18,.92);stroke:var(--tint);stroke-width:.8}
.ffn .lbl text{font:600 10.5px/1 'Keepsake Sans',system-ui,sans-serif;letter-spacing:.16em;text-transform:uppercase;fill:#d9c4b4;text-anchor:middle;dominant-baseline:central;transition:fill .15s}
.ffn .arcg.hot .lbl text{fill:#fff}
.ffn .arcg.hot .lbl path{stroke-width:1.2;filter:drop-shadow(0 0 4px var(--tint))}
.ffn .dv{opacity:0;transition:opacity .25s calc(var(--tin)*.9)}
.ffn .dv.on{opacity:.95}
.ffn .dv-curl{fill:none;stroke:#cfae76;stroke-width:1;stroke-linecap:round}
.ffn .dv-knot{fill:#cfae76;filter:drop-shadow(0 0 3px rgba(255,0,255,.6))}
.ffn .tether{fill:none;stroke:#ff00ff;stroke-width:1.5;stroke-linecap:round;stroke-dasharray:3 5;filter:drop-shadow(0 0 4px rgba(255,0,255,.95));opacity:0;transition:opacity .12s;animation:ffw-flow .7s linear infinite}
.ffn .tether.core{stroke:#ffd2ff;stroke-width:.6;stroke-dasharray:none;animation:none}
.ffn.has-pick .tether{opacity:1}
.ffn .fly{fill:none;stroke-linecap:round}
.ffn .fly.g{stroke:#ff3df0;stroke-width:3.4;filter:drop-shadow(0 0 6px #f0f) drop-shadow(0 0 2px #f0f)}
.ffn .fly.t{stroke:rgba(207,174,118,.7);stroke-width:.8}
.ffn .fly.c{stroke:#ffe1f7;stroke-width:1.3}
.ffn .dropglow{fill:none;stroke:#ff4ff0;stroke-width:7;stroke-linecap:round;filter:drop-shadow(0 0 6px #f0f);opacity:0;transition:opacity .12s}
.ffn .dropglow.on{opacity:.9}
.ffn-b{position:absolute;left:-30px;top:-30px;width:60px;height:60px;padding:0;border:0;background:none;cursor:pointer;outline:none;pointer-events:none;
  --ffn-a:var(--from);--ffn-rk:.55;opacity:0;
  transform:rotate(var(--ffn-a)) translateY(calc(var(--R)*-1px*var(--ffn-rk))) rotate(calc(-1*var(--ffn-a)));
  transition:--ffn-a var(--tin) cubic-bezier(.2,.8,.25,1) calc(var(--d,0)*var(--stag)),--ffn-rk var(--tin) cubic-bezier(.25,1.3,.45,1) calc(var(--d,0)*var(--stag)),opacity calc(var(--tin)*.6) calc(var(--d,0)*var(--stag))}
.ffn-b.on{--ffn-a:var(--to);--ffn-rk:1;opacity:1;pointer-events:auto}
.ffn-b.out{--ffn-a:var(--to);--ffn-rk:1.28;opacity:0;pointer-events:none;transition:--ffn-rk var(--tout) cubic-bezier(.4,.2,.6,1),opacity var(--tout) ease-in}
.ffn-b.gone{--ffn-a:var(--from);--ffn-rk:.6;opacity:0;pointer-events:none;transition:--ffn-a var(--tout) ease-in,--ffn-rk var(--tout) ease-in,opacity var(--tout) ease-in}
.ffn.instant .ffn-b,.ffn.instant .ffn-g{transition:none!important}
.ffn-g{position:absolute;inset:0;scale:.45;transition:scale var(--tin) cubic-bezier(.25,1.45,.45,1) calc(var(--d,0)*var(--stag)),translate .15s ease-out,rotate .2s}
.ffn-b.on .ffn-g{scale:1}
.ffn-b.out .ffn-g{scale:.62;rotate:16deg;transition:scale var(--tout),rotate var(--tout)}
.ffn-b .fr{position:absolute;left:0;top:0;width:60px;height:60px;overflow:visible;transition:filter .15s}
.ffn-b .body{fill:url(#ffn-leaf)}.ffn-b .sheen{fill:url(#ffn-sheen)}
.ffn-b .rim{stroke-dasharray:none;stroke-dashoffset:0;fill:none;stroke:#cfae76;stroke-width:1.5;filter:none;transition:stroke .15s}
.ffn-b .rim2{fill:none;stroke:rgba(207,174,118,.38);stroke-width:.7}
.ffn-b .ico{position:absolute;inset:0;display:grid;place-items:center;color:#f3d79a;transition:color .15s,scale .2s cubic-bezier(.3,1.6,.5,1)}
.ffn-b .ico svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 1px 1px rgba(0,0,0,.7))}
.ffn-b .ico img{width:24px;height:24px;border-radius:3px;clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);filter:saturate(.85)}
.ffn-b.k-cat .fr{left:-4px;top:-4px;width:68px;height:68px}
.ffn-b.k-cat .body{fill:url(#ffn-cat)}
.ffn-b.k-cat .rim{stroke-width:1.7}
.ffn-b.k-cat .tips{fill:#cfae76;opacity:.9}
.ffn-b.k-cat .ico svg{width:24px;height:24px}
.ffn-b .lab{position:absolute;left:var(--lx);top:var(--ly);transform:translate(var(--tx),var(--ty));font:600 9.5px/1 'Keepsake Sans',system-ui,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#d7c3b4;white-space:nowrap;pointer-events:none;
  text-shadow:0 1px 2px #000,0 0 6px rgba(14,6,12,.9);transition:color .15s}
.ffn-b.picked .lab{color:#fff}
.ffn-b.off .lab{color:#8d7c74}
.ffn-b.hiddencat{opacity:.4!important}.ffn-b.hiddencat .lab{text-decoration:line-through}
.ffn-b.k-short .fr{left:1px;top:1px;width:58px;height:58px}
.ffn-b.k-short .body{fill:url(#ffn-bit)}
.ffn-b.k-short .core{fill:none;stroke:rgba(255,80,235,.55);stroke-width:.9;filter:drop-shadow(0 0 2px #f0f)}
.ffn-b.k-short .rim{stroke-width:1.2;stroke:#e2c38c}
.ffn-b.k-short .orn{fill:none;stroke:#cfae76;stroke-width:1;stroke-linecap:round;opacity:.85}
.ffn-b.k-short .orn.cap{fill:#cfae76;stroke:none}
.ffn-b.k-short .ico svg{width:15px;height:15px;stroke-width:2}
.ffn-b.k-short .ico img{width:15px;height:15px}
.ffn-b.k-short .ffn-g{animation:ffn-bob 3.4s ease-in-out infinite;animation-delay:calc(var(--d,0)*-.5s)}
@keyframes ffn-bob{50%{translate:0 -2px}}
.ffn-b.k-socket .fr{left:1px;top:1px;width:58px;height:58px}
.ffn-b.k-socket .sbody{fill:rgba(30,8,26,.72)}
.ffn-b.k-socket .rim.dash{stroke:rgba(255,110,240,.8);stroke-width:1.2;stroke-dasharray:3 2.6}
.ffn-b.k-socket .ico{color:rgba(255,150,240,.9)}.ffn-b.k-socket .ico svg{width:12px;height:12px}
.ffn.dragging .ffn-b.k-socket .rim.dash{stroke:#ff6ff0;animation:ffn-glow .7s ease-in-out infinite alternate}
.ffn.dragging .ffn-b.k-socket .sbody{fill:rgba(120,10,100,.45)}
@keyframes ffn-glow{to{stroke:#ffd2ff;filter:drop-shadow(0 0 5px #f0f)}}
.ffn-b.drop .fr{filter:drop-shadow(0 0 8px #f0f)}
.ffn-b.drop .ffn-g{scale:1.18}
.ffn-b.k-leaf .rim,.ffn-b.k-more .rim,.ffn-b.k-lane .rim{stroke:color-mix(in srgb,var(--tint,#cfae76) 70%,#cfae76)}
.ffn-b.k-more .rim.dash{stroke-dasharray:3 2.4;stroke-width:1.1}
.ffn-b.k-more .ico{color:var(--tint,#cfae76)}.ffn-b.k-more .ico svg{width:16px;height:16px}
.ffn-b.k-leaf .ico svg{width:19px;height:19px}
/* context lane: smaller gems between her and the arc, each in its own place */
.ffn-b.k-lane .fr{left:9px;top:9px;width:42px;height:42px}
.ffn-b.k-lane .rim{stroke-dasharray:2.4 1.6;stroke-width:1.3}
.ffn-b.k-lane .ico svg{width:15px;height:15px;stroke-width:1.9}
.ffn-b.k-lane .ctx{top:7px}
.ffn-b.k-lane .dot{top:44px}
.ffn-b.picked .ffn-g{scale:1.18}
.ffn-b.picked .body{fill:url(#ffn-hot)}
.ffn-b.picked .rim{stroke:#ffd2ff}
.ffn-b.picked .fr{filter:drop-shadow(0 0 9px rgba(255,0,255,.8))}
.ffn-b.picked .ico{color:#fff}
.ffn.has-pick .ffn-b.on:not(.picked):not(.k-socket){opacity:.74}
.ffn-b:focus-visible .fr{filter:drop-shadow(0 0 0 #fff) drop-shadow(0 0 4px #ffd2ff)}
.ffn-b .dot{position:absolute;left:27px;top:51px;width:6px;height:6px;transform:rotate(45deg);border:1px solid #cfae76;background:#1a0c15;transition:background .2s,box-shadow .2s}
.ffn-b.k-short .dot{top:52px}
.ffn-b .dot.lit{background:#ff4ff0;border-color:#ffd2ff;box-shadow:0 0 6px #f0f}
.ffn-b .ctx{position:absolute;left:28px;top:2px;width:4px;height:4px;transform:rotate(45deg);background:#f3d79a;box-shadow:0 0 4px #cfae76;opacity:.9}
.ffn-b.off .fr{filter:saturate(.2) brightness(.62)}
.ffn-b.off .ico{color:#8d7c74}
.ffn-b.off.picked .body{fill:url(#ffn-leaf)}.ffn-b.off.picked .rim{stroke:#8d7c74}
.ffn-b .ffn-facet{position:absolute;left:50%;top:50%;width:2px;height:30px;margin:-15px 0 0 -1px;border-radius:2px;background:linear-gradient(180deg,rgba(231,103,206,0),#ff8fe0 35%,#f3d79c 65%,rgba(231,103,206,0));box-shadow:0 0 8px rgba(231,103,206,.8);pointer-events:none}
.ffn-b .ffn-aim{position:absolute;left:50%;top:50%;width:0;height:0;pointer-events:none}
.ffn-b .ffn-aim i{position:absolute;left:-5px;top:-5px;width:10px;height:10px;opacity:.4;transition:opacity .14s,scale .14s,filter .14s;scale:.8;
  background:#cfae76;clip-path:polygon(50% 0,100% 100%,50% 72%,0 100%)}
.ffn-b .ffn-aim i[data-d=top]{translate:0 -31px;rotate:180deg}.ffn-b .ffn-aim i[data-d=right]{translate:31px 0;rotate:270deg}
.ffn-b .ffn-aim i[data-d=bottom]{translate:0 31px}.ffn-b .ffn-aim i[data-d=left]{translate:-31px 0;rotate:90deg}
.ffn-b .ffn-aim i.on{opacity:1;scale:1.25;background:#ff8fe0;filter:drop-shadow(0 0 5px rgba(231,103,206,.9))}
.ffn-b .ffn-aim.held i{opacity:.18}.ffn-b .ffn-aim.held i.on{opacity:.7;background:#cfae76;filter:none}
.ffn-b .ffn-streak{position:absolute;left:50%;top:50%;width:40px;height:2px;margin:19px 0 0 -20px;border-radius:2px;pointer-events:none;transform-origin:50% 50%;background:linear-gradient(90deg,rgba(231,103,206,0),#ff8fe0 55%,#f3d79c);scale:var(--flip,1) 1;box-shadow:0 0 8px rgba(231,103,206,.7)}
.ffn .ffn-tick{fill:none;stroke:#ff8fe0;stroke-width:2;stroke-linecap:round;filter:drop-shadow(0 0 4px rgba(231,103,206,.9))}
.ffn-b.nope .ffn-g{animation:ffn-nope .32s}
@keyframes ffn-nope{25%{translate:-3px 0}50%{translate:3px 0}75%{translate:-2px 0}}
.ffn-b.fold .ffn-g{animation:ffn-fold .2s cubic-bezier(.5,0,.8,.4) forwards}
@keyframes ffn-fold{to{scale:.12 1.25;rotate:45deg;opacity:0}}
/* last used: its own small gem below her rim (the centre itself cancels) */
.ffn-last{position:absolute;left:-22px;top:-22px;width:44px;height:44px;padding:0;border:0;background:none;cursor:pointer;opacity:0;scale:.3;pointer-events:none;transform:translate(0,var(--ly));transition:opacity .25s .25s,scale .3s cubic-bezier(.3,1.5,.5,1) .25s}
.ffn.open:not(.sub):not(.editing) .ffn-last.has{opacity:1;scale:1;pointer-events:auto}
.ffn-last .fr{position:absolute;inset:0;width:44px;height:44px;overflow:visible}
.ffn-last .body{fill:url(#ffn-cat)}.ffn-last .rim{fill:none;stroke:#cfae76;stroke-width:1.2}
.ffn-last .curl{fill:none;stroke:#cfae76;stroke-width:1;stroke-linecap:round;opacity:.75}
.ffn-last .ico{position:absolute;inset:0;display:grid;place-items:center;color:#f3d79a}
.ffn-last .ico svg{width:12px;height:12px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.ffn-last .ico img{width:12px;height:12px}
.ffn-last .fr{animation:ffn-pulse 2.6s ease-in-out infinite}
@keyframes ffn-pulse{50%{filter:drop-shadow(0 0 5px rgba(255,60,235,.75))}}
.ffn-last.picked .body{fill:url(#ffn-hot)}.ffn-last.picked .rim,.ffn-last.picked .curl{stroke:#ffd2ff;opacity:1}.ffn-last.picked .ico{color:#fff}
.ffn-last.picked{scale:1.2!important}
.ffn-last.off .fr{filter:saturate(.2) brightness(.62)}
.ffn-back{position:absolute;left:-12px;top:-12px;width:24px;height:24px;padding:0;border:0;background:none;cursor:pointer;opacity:0;pointer-events:none;transform:translate(0,var(--by)) scale(.4);transition:opacity .2s,transform .25s cubic-bezier(.3,1.5,.5,1)}
.ffn.sub .ffn-back{opacity:1;pointer-events:auto;transform:translate(0,var(--by)) scale(1);transition-delay:.12s}
.ffn-back i{position:absolute;inset:3px;transform:rotate(45deg);border-radius:2px;background:linear-gradient(135deg,#3a2131,#160b12);box-shadow:inset 0 0 0 1.2px #cfae76,0 3px 8px rgba(0,0,0,.6)}
.ffn-back svg{position:absolute;inset:4px;width:16px;height:16px;fill:none;stroke:#f3d79a;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;transform:rotate(90deg)}
.ffn.back-pick .ffn-back{transform:translate(0,var(--by)) scale(1.25)}
.ffn.back-pick .ffn-back i{background:linear-gradient(135deg,#ff3df0,#7a0e6c);box-shadow:inset 0 0 0 1.2px #ffd2ff,0 0 14px rgba(255,0,255,.7)}
.ffn.back-pick .ffn-back svg{stroke:#fff}
.ffn.back-pick svg.ffn-ring .rim{stroke-width:2.6;filter:drop-shadow(0 0 7px #f0f)}
.ffn .ffw-plaque{transition:opacity .25s .2s,transform .3s cubic-bezier(.3,1.4,.5,1) .2s,top .25s cubic-bezier(.3,1,.4,1),width .25s;width:268px}
.ffn.sub .ffw-plaque{transition-delay:0s}
.ffn-crumb{display:block;height:11px;font:600 8.5px/11px 'Keepsake Sans',system-ui,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:#cfae76;opacity:.85;white-space:nowrap}
.ffn .ffw-sub.reason{color:#f0a6c8}
.ffn .ffw-meta .btns{display:flex;gap:10px}
.ffn.emo .ffw-plaque{width:300px;padding:7px 22px 8px 92px;text-align:left;min-height:80px}
.ffn-cameo{position:absolute;left:24px;top:50%;width:58px;height:58px;margin-top:-29px;opacity:0;transition:opacity .2s;pointer-events:none}
.ffn-cameo::before{content:"";position:absolute;inset:4px;transform:rotate(45deg);border-radius:4px;background:radial-gradient(circle at 50% 45%,#2a1424,#0d060b 75%);box-shadow:inset 0 0 0 1px rgba(207,174,118,.55),inset 0 0 0 3px #0d060b,inset 0 0 0 4px rgba(231,103,206,.28)}
.ffn-cameo canvas{position:absolute;left:-6px;top:-6px;width:70px;height:70px}
.ffn.emo .ffn-cameo{opacity:.4}.ffn.emo.has-pick .ffn-cameo{opacity:1}
.ffn-panel{position:absolute;top:var(--pt);left:var(--pl);width:290px;max-height:500px;display:flex;flex-direction:column;pointer-events:auto;color:#f3eadf;font:12px/1.3 'Keepsake Sans',system-ui,sans-serif;
  background:linear-gradient(180deg,rgba(32,16,27,.97),rgba(17,9,14,.97));box-shadow:inset 0 0 0 1px rgba(207,174,118,.45),inset 0 0 0 4px rgba(17,9,14,.97),inset 0 0 0 5px rgba(207,174,118,.18),0 18px 40px rgba(0,0,0,.7);
  clip-path:polygon(10px 0,calc(100% - 10px) 0,100% 10px,100% calc(100% - 10px),calc(100% - 10px) 100%,10px 100%,0 calc(100% - 10px),0 10px);
  opacity:0;translate:-10px 0;transition:opacity .2s,translate .25s cubic-bezier(.2,.9,.3,1.1)}
.ffn-panel.on{opacity:1;translate:0 0}
.ffn-panel h3{margin:0;padding:12px 16px 4px;font:700 15px/1.1 'Keepsake Serif',Georgia,serif;color:#f3eadf;display:flex;justify-content:space-between;align-items:baseline;border:0}
.ffn-panel .note{padding:0 16px 8px;color:#a8958c;font-size:11px}
.ffn-panel .scroll{overflow:auto;padding:0 10px 12px;scrollbar-width:thin;scrollbar-color:#5a3a4c transparent}
.ffn-sec{margin-top:6px}
.ffn-sec>.hd{display:flex;align-items:center;gap:8px;padding:6px 6px;font:600 9.5px/1 'Keepsake Sans',sans-serif;letter-spacing:.18em;text-transform:uppercase;color:var(--tint,#cfae76);cursor:pointer;border-bottom:1px solid rgba(207,174,118,.18)}
.ffn-sec>.hd::before{content:"";width:5px;height:5px;transform:rotate(45deg);background:var(--tint,#cfae76);box-shadow:0 0 4px var(--tint,#cfae76)}
.ffn-sec>.hd .n{margin-left:auto;color:#8d7c74;letter-spacing:.05em}
.ffn-sec.shut>.chips,.ffn-sec.shut>.sub{display:none}
.ffn-sec .sub{padding:6px 6px 0;font:600 9px/1 'Keepsake Sans',sans-serif;letter-spacing:.14em;text-transform:uppercase;color:#a8958c}
.ffn-sec .chips{display:grid;grid-template-columns:1fr 1fr;gap:3px;padding:4px 2px}
.ffn-chip{position:relative;min-width:0;display:flex;align-items:center;gap:7px;height:28px;padding:0 22px 0 6px;color:#e8dccd;background:rgba(255,255,255,.025);border:0;font:12px/1 'Keepsake Sans',sans-serif;text-align:left;cursor:pointer;
  clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px);transition:background .12s;touch-action:none}
.ffn-chip:hover,.ffn-chip:focus-visible,.ffn-chip.hl{background:rgba(255,0,255,.16);color:#fff;outline:none}
.ffn-chip .mg{flex:none;width:20px;height:20px;display:grid;place-items:center;color:#f3d79a;background:linear-gradient(135deg,#3d1a33,#1b0d17);clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);box-shadow:inset 0 0 0 1px #cfae76}
.ffn-chip .mg svg{width:11px;height:11px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.ffn-chip .mg img{width:12px;height:12px}
.ffn-chip .t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ffn-chip.off{color:#8d7c74}.ffn-chip.off .mg{filter:saturate(.2) brightness(.65)}
.ffn-chip .pin{position:absolute;right:5px;top:9px;width:9px;height:9px;transform:rotate(45deg);border:1px solid rgba(207,174,118,.6);background:transparent}
.ffn-chip .pin.in{background:var(--tint,#cfae76);border-color:#ffe9c4;box-shadow:0 0 5px var(--tint,#cfae76)}
.ffn-chip .dotx{position:absolute;right:20px;top:11px;width:5px;height:5px;transform:rotate(45deg);background:#ff4ff0;box-shadow:0 0 5px #f0f}
.ffn-chip.used{box-shadow:inset 2px 0 0 #ff4ff0}
.ffn-ghost{position:absolute;left:-30px;top:-30px;width:60px;height:60px;pointer-events:none;z-index:5;transition:rotate .12s,opacity .2s,scale .2s;filter:drop-shadow(0 6px 10px rgba(0,0,0,.6)) drop-shadow(0 0 8px rgba(255,0,255,.55))}
.ffn-ghost .ffn-b{position:absolute;left:0;top:0;transform:none;opacity:1;--ffn-rk:1}
.ffn-ghost .ffn-b .ffn-g{scale:1.1}
.ffn-ghost.bye{opacity:0;scale:.3}
.ffn-ghost .tag{position:absolute;left:30px;top:62px;transform:translateX(-50%);font:600 10px/1 'Keepsake Sans',sans-serif;color:#fff;white-space:nowrap;text-shadow:0 1px 2px #000;padding:3px 6px;background:rgba(40,8,34,.85);box-shadow:inset 0 0 0 1px rgba(255,0,255,.5)}
.ffn.closing{opacity:0;transition:opacity .18s ease-in;will-change:opacity}
.ffn.closing *{transition:none!important;animation:none!important}
.ffn.reduced *{transition-duration:0s!important;transition-delay:0s!important;animation:none!important}
`+HARDLIGHT_CSS;

function halfBraid(R,amp,waves,phase,side){
  let d='';const N=90;
  for(let k=0;k<=N;k++){const a=Math.PI+side*k/N*Math.PI,r=R+amp*Math.sin(a*waves+phase);d+=(k?'L':'M')+(r*Math.sin(a)).toFixed(2)+' '+(-r*Math.cos(a)).toFixed(2);}
  return d;
}
export const arcPath=(r,a0,a1)=>{if(Math.abs(a1-a0)>=359.9){const [x,y]=P(a0,r);return `M${x.toFixed(2)} ${y.toFixed(2)}A${r} ${r} 0 1 1 ${(-x).toFixed(2)} ${(-y).toFixed(2)}A${r} ${r} 0 1 1 ${x.toFixed(2)} ${y.toFixed(2)}`;}
  const [x0,y0]=P(a0,r),[x1,y1]=P(a1,r),large=Math.abs(a1-a0)>180?1:0,sweep=a1>a0?1:0;return `M${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 ${large} ${sweep} ${x1.toFixed(2)} ${y1.toFixed(2)}`;};
export function injectStyles(d){
  for(const [id,css] of [['ffw-style',WHEEL_CSS],['ffn-style',NESTED_CSS],['ffm-style',MACRO_RING_CSS]])if(!d.getElementById(id)){const s=d.createElement('style');s.id=id;s.textContent=css;d.head.appendChild(s);}
  if(!d.getElementById('ffn-defs')){const w=d.createElement('div');w.id='ffn-defs';w.innerHTML=DEFS;d.body.appendChild(w);}
}

export class NestedWheel{
  constructor(host){this.host=host;this.doc=host.doc;this.root=null;this.ptr=null;this.macroRing=new MacroRing(this);}
  get isOpen(){return !!this.root;}
  geometry(){const a=this.host.anchor?.()??{x:0,y:0,r:40},tokenR=Math.max(24,a.r??40),R=Math.max(118,tokenR+62),R2=R+38;
    return {x:a.x,y:a.y,tokenR,R,R2,Rc:Math.max(tokenR+34,R2-52),lastR:tokenR+24};}
  icon(slot){
    const o=this.host.iconFor?.(slot);if(o)return o;
    if(slot.action==='emote')return {path:ICONS[slot.value]??ICONS.emotes};
    const v=VALUE_ICON[slot.action]?.[slot.value];
    return {path:ICONS[v??this.host.catalog[slot.action]?.icon]??ICONS.macro};
  }
  iconHTML(ic){return ic.img?`<img src="${esc(ic.img)}" alt="" draggable="false">`:ic.use?`<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#${esc(ic.use)}"/></svg>`:`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${ic.path}"/></svg>`;}
  info(slot){
    const d=this.host.describe(slot)??{},reason=M.unavailable(slot,this.ctx)??d.reason??null;
    return {label:d.label??slot.action,sub:d.sub??'',active:!!d.active,toggle:M.TOGGLES.has(slot.action),reason};
  }
  features(){return {shortcuts:true,macros:true,emotes:true,arcSize:4,layout:'doors',...(this.host.features?.()??{})};}
  /* (test.16) the two layouts: which doors are on the main ring, what a door's ring holds, what its More… lists */
  get doors(){return this.feat.layout!=='classic';}
  get order(){return this.doors?this.cfg.order2:this.cfg.order;}
  /** A level that is one ring of the user's own picks (the doors layout's Her, Actions, Bits). */
  isRing(level=this.level){return this.doors&&!!M.DOORS[level];}
  groupDef(g){return (this.doors?M.DOOR_GROUPS[g]:null)??M.GROUPS[g];}
  groupTint(g){return (this.doors?M.DOORS[g]?.tint:null)??M.ARCS[g]?.tint??'#d9b4ff';}
  catHint(cat){return (this.doors?M.DOOR_HINTS[cat]:null)??M.CATEGORIES[cat].hint;}
  /** The user's picks a gem belongs to: a door's ring, or a classic arc → [list, index] (null: not the user's own). */
  ownList(it){if(it?.ring&&it.ringSlot!=null)return [this.cfg.rings[it.ring],it.ringSlot];if(it?.kind==='leaf'&&!it.ring&&M.ARCS[it.arc]&&it.arcSlot!=null)return [this.cfg.arcs[it.arc],it.arcSlot];return null;}

  /* ------------------------------------------------------------ open / close */
  open(){
    if(this.root)return;const d=this.doc;injectStyles(d);
    this.cfg=structuredClone(M.migrate(this.host.config()));this.ctx=M.context(this.host.state());this.feat=this.features();
    // (test.16) the first time the doors layout opens, its rings start from the defaults and whatever she had put in the classic arcs herself
    // (nothing is written for that: the rings are saved with her first change to them)
    if(this.doors&&!this.cfg.rings)this.cfg.rings=M.ringsFromClassic(this.cfg.arcs);
    this.level='main';this.held=true;this.pick=null;this.restPt=null;this.restAt=0;this.editing=false;this.dwell=null;this.list=null;this.drag=null;this.enteredAt=0;this.swift=false;
    const g=this.g=this.geometry();
    this.ptr=this.host.pointer?.()??null;
    this.inside=!!this.ptr&&Math.hypot(this.ptr.x-g.x,this.ptr.y-g.y)<g.R-10;
    const root=this.root=d.createElement('div');root.className='ffw ffn';if(this.host.reducedMotion?.())root.classList.add('reduced');
    // (test.19) the look of the gems and of the main ring (Settings › Emotes & wheel › Nested wheel › Parts)
    this.look=lookOf(this.feat.look);this.ringStyle=ringOf(this.feat.ring);if(this.look==='hardlight')root.classList.add('look-hl');if(this.ringStyle!=='classic')root.classList.add('rg');
    root.setAttribute('role','menu');root.setAttribute('aria-label','Quick wheel');root.style.left=`${g.x}px`;root.style.top=`${g.y}px`;
    d.body.appendChild(root);this.buildSvg();this.buildChrome();this.buildMain(false);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{if(this.root!==root)return;root.classList.add('open');if(this.level==='main')this.mainItems.forEach(i=>i.el.classList.add('on'));
      setTimeout(()=>root.classList.add('settled'),450);}));
    this.onMove=e=>{
      // (test.13) after the mouse wheel stepped the pick round the Emotes ring, the pointer has to really move before it points again
      if(this.scrollPick){if(Math.hypot(e.clientX-this.scrollPt.x,e.clientY-this.scrollPt.y)<8)return;this.scrollPick=null;}
      this.ptr={x:e.clientX,y:e.clientY};this.noteRest();this.pointer(e);};
    this.onKey=e=>{if(e.key!=='Escape')return;e.preventDefault();e.stopImmediatePropagation();this.escape();};
    this.onDown=e=>{if(!this.root)return;
      if(e.target?.closest?.('.ffn-b,.ffn-last,.ffn-back,.ffw-plaque,.ffn-panel,.ffm-slot,.ffm-panel'))return;
      if(e.button===2)return;
      if(this.level==='macros'&&this.macroRing.outsideDown(e))return;
      if(this.level!=='main'&&Math.hypot(e.clientX-this.g.x,e.clientY-this.g.y)<this.g.tokenR+10){e.preventDefault();e.stopPropagation();this.back();return;}
      if(this.editing||now()-this.openedAt<250)return;this.close();};
    this.onCtx=e=>{if(!this.root)return;const dd=Math.hypot(e.clientX-this.g.x,e.clientY-this.g.y);if(dd>this.g.R2+140&&!e.target?.closest?.('.ffn-panel,.ffm-panel'))return;
      e.preventDefault();e.stopPropagation();this.rightClick();};
    d.addEventListener('pointermove',this.onMove,true);d.addEventListener('keydown',this.onKey,true);d.addEventListener('pointerdown',this.onDown,true);d.addEventListener('contextmenu',this.onCtx,true);
    // (test.12) the mouse wheel over a gem that has several options changes its option
    this.onWheel=e=>this.wheelTurn(e);this.wheelAcc=0;this.wheelAt=0;this.cycleDirty=false;d.addEventListener('wheel',this.onWheel,{capture:true,passive:false});
    this.macroRing.listen(true);
    const loop=()=>{if(!this.root)return;this.tick();this.raf=requestAnimationFrame(loop);};this.raf=requestAnimationFrame(loop);
    this.openedAt=now();
  }
  close(){
    const root=this.root;if(!root)return;this.macroRing.close();this.root=null;cancelAnimationFrame(this.raf);
    if(this.editing||this.cycleDirty)this.save();this.cycleDirty=false;clearTimeout(this.cycleTimer);
    const d=this.doc;d.removeEventListener('wheel',this.onWheel,{capture:true});d.removeEventListener('pointermove',this.onMove,true);d.removeEventListener('keydown',this.onKey,true);d.removeEventListener('pointerdown',this.onDown,true);d.removeEventListener('contextmenu',this.onCtx,true);
    this.macroRing.listen(false);if(this.drag){this.drag.ghost?.remove();this.drag=null;}
    // (test.8) closing is one fade of the whole wheel as a single layer. It used to fade every gem, the ring and the
    // panels each on their own (some twenty layers, each with glow filters, re-rastered every frame of the close) and
    // then took the whole tree out in one step: a 52 ms task in a real game. Now: one composited fade with every inner
    // transition and animation stopped, then the tree is hidden (no drawing left), and only then removed, when idle.
    root.classList.add('closing');
    const idle=globalThis.requestIdleCallback?fn=>globalThis.requestIdleCallback(fn,{timeout:150}):fn=>setTimeout(fn,30);
    setTimeout(()=>{root.style.display='none';idle(()=>root.remove());},root.classList.contains('reduced')?0:200);
  }
  save(){try{this.host.saveConfig(structuredClone(this.cfg));}catch(e){this.host.error?.(e);}}
  escape(){if(this.drag){this.endDrag(null,true);return;}if(this.level==='macros'&&this.macroRing.escape())return;if(this.list){this.closeList();return;}if(this.editing){this.toggleEdit();return;}if(this.level!=='main'){this.back();return;}this.close();}
  rightClick(){if(this.level==='macros'&&this.macroRing.escape())return;if(this.list)this.closeList();else if(this.level!=='main')this.back();else if(!this.editing)this.toggleEdit();}
  /** A macro was created, changed or deleted while the wheel is open. */
  macrosChanged(){if(this.root&&this.level==='macros')this.macroRing.refresh();}

  /* ------------------------------------------------------------ svg + chrome */
  buildSvg(){
    const d=this.doc,{tokenR,R,R2}=this.g,box=R2+90,rimR=tokenR+5;
    const svg=d.createElementNS(SVGNS,'svg');svg.setAttribute('class','ffn-ring');svg.setAttribute('viewBox',`${-box} ${-box} ${box*2} ${box*2}`);
    svg.style.cssText=`left:${-box}px;top:${-box}px;width:${box*2}px;height:${box*2}px;--rl:${Math.ceil(TAU*rimR)};--hl:${Math.ceil(Math.PI*R*1.1)}`;
    let h=`<defs><radialGradient id="ffn-veil" cx="0" cy="0" r="${box}" gradientUnits="userSpaceOnUse"><stop offset="${(rimR+2)/box}" stop-color="rgba(14,6,12,0)"/><stop offset="${(rimR+18)/box}" stop-color="rgba(14,6,12,.42)"/><stop offset="${R2/box}" stop-color="rgba(40,4,40,.36)"/><stop offset="1" stop-color="rgba(14,6,12,0)"/></radialGradient></defs>
      <circle class="veil" r="${box}" fill="url(#ffn-veil)"/><circle class="rim" r="${rimR}"/><circle class="rim gold" r="${rimR+4}"/><g class="L-main">`;
    const ring=ringMarkup(this.ringStyle,R);
    if(ring)h+=`<g class="rg-x">${ring}</g><g class="knots"></g>`;
    else{
    for(const side of [1,-1]){
      h+=`<path class="feather" d="${halfBraid(R,0,1,0,side)}"/>`;
      h+=`<path class="half a" d="${halfBraid(R,3.2,24,0,side)}"/><path class="half b" d="${halfBraid(R,3.2,24,Math.PI,side)}"/><path class="half c" d="${halfBraid(R+1,5,36,1.1,side)}"/>`;}
    h+=`<g class="knots"></g>`;
    if(!this.root.classList.contains('reduced'))for(let k=0;k<2;k++)h+=`<circle class="mote" r="${k?1.2:1.6}"><animateMotion dur="${8+k*3}s" repeatCount="indefinite" begin="${-k*2.6}s" path="${halfBraid(R,3.2,24,k?Math.PI:0,1)}${halfBraid(R,3.2,24,k?Math.PI:0,-1).replace('M','L')}"/></circle>`;}
    h+=`</g><g class="L-sub"></g><path class="dropglow" d=""/><path class="tether" d=""/><path class="tether core" d=""/><g class="flys"></g>`;
    svg.innerHTML=h;this.root.appendChild(svg);this.svg=svg;
  }
  buildChrome(){
    const d=this.doc,{tokenR,lastR}=this.g,root=this.root;
    const last=d.createElement('button');last.type='button';last.className='ffn-last';last.style.setProperty('--ly',`${lastR.toFixed(1)}px`);last.setAttribute('aria-label','Last used');
    last.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(!this.editing)this.fireLast();});
    last.addEventListener('pointerenter',()=>{if(this.level==='main'&&!this.editing&&!this.drag)this.setPick({kind:'last'});});
    last.addEventListener('focus',()=>{if(this.level==='main'&&!this.editing)this.setPick({kind:'last'});});
    root.appendChild(last);this.lastEl=last;this.paintLast();
    const back=d.createElement('button');back.type='button';back.className='ffn-back';back.setAttribute('aria-label','Back');back.style.setProperty('--by',`${-(tokenR+5)}px`);
    back.innerHTML=`<i></i><svg viewBox="0 0 24 24"><path d="${ICONS.back}"/></svg>`;
    back.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();this.back();});
    root.appendChild(back);this.backEl=back;
    const pl=d.createElement('div');pl.className='ffw-plaque';
    pl.innerHTML=`<span class="ffn-cameo"><canvas width="140" height="140"></canvas></span><span class="ffm-cameo"></span><span class="ffn-crumb"></span><span class="ffw-name"></span><span class="ffm-hintrow"><span class="ffm-chip"></span><span class="ffm-hint"></span></span><span class="ffw-meta"><span class="ffw-sub"></span><span class="btns"></span></span>`;
    pl.addEventListener('pointerdown',e=>{const b=e.target.closest?.('button');if(!b||e.button!==0)return;e.preventDefault();e.stopPropagation();this.plaqueButton(b.dataset.b);});
    pl.addEventListener('click',e=>{const b=e.target.closest?.('button');if(b&&e.detail===0){e.preventDefault();this.plaqueButton(b.dataset.b);}});
    root.appendChild(pl);this.plaque=pl;this.cameo=pl.querySelector('.ffn-cameo canvas');
    this.placePlaque();this.idlePlaque();
  }
  placePlaque(r0=null){const {R,R2,y}=this.g,r=r0??(this.level==='main'?R:R2),below=(this.doc.defaultView?.innerHeight??1e9)-y>r+130;
    this.plaque.style.setProperty('--py',below?`${r+(this.level==='main'?52:30)}px`:`${-r-100}px`);}
  setPlaque(crumb,name,sub,{reason=false,btns=null}={}){
    const p=this.plaque;p.querySelector('.ffn-crumb').textContent=crumb??'';
    const n=p.querySelector('.ffw-name');if(n.textContent!==name){n.textContent=name;n.classList.remove('swap');void n.offsetWidth;n.classList.add('swap');}
    const s=p.querySelector('.ffw-sub');s.textContent=sub??'';s.classList.toggle('reason',!!reason);
    const b=btns??(this.editing?['done']:this.level==='main'?['hud','edit']:this.level==='macros'?['back','edit']:['back']);
    const html=b.map(k=>`<button type="button" class="ffw-edit" data-b="${k}">${{hud:'HUD',edit:'Edit',done:'Done',back:'Back'}[k]}</button>`).join('');
    const box=p.querySelector('.btns');if(box.dataset.sig!==html){box.innerHTML=html;box.dataset.sig=html;}
  }
  idlePlaque(){
    if(this.editing)return this.setPlaque('Edit the wheel','Shortcuts',this.feat.shortcuts?`Drag any action onto a socket · ${this.shortcutCount()}/${M.MAX_SHORTCUTS}`:'Shortcuts are off in Settings · categories only');
    if(this.list)return;
    if(this.level==='macros')return this.macroRing.restPlaque();
    if(this.level==='main')return this.setPlaque('','Quick wheel',this.ctx.combat?'In combat · point, then release':'Point, then release');
    const c=M.CATEGORIES[this.level];
    if(this.isRing())return this.setPlaque('',c.name,`${this.level==='her'?(this.ctx.air?'Flying':'Grounded')+(this.ctx.combat?' · in combat':'')+' · ':this.ctx.combat?'In combat · ':''}${this.held?'release on one':'click one'} · rest on her to go back`);
    this.setPlaque(this.level==='her'?'Her':'',this.level==='her'?'Flight · Wings · Bits':c.name,this.level==='her'?(this.ctx.air?'Flying':'Grounded')+(this.ctx.combat?' · in combat':''):'Release on one · rest on her to go back');
  }
  plaqueButton(k){
    if(k==='edit'||k==='done'){if(this.level==='macros')this.macroRing.toggleEdit();else this.toggleEdit();}
    else if(k==='back'){if(this.list)this.closeList();else this.back();}
    else if(k==='hud'){this.close();void this.run({action:'hud',value:null});}
  }
  paintLast(){const s=this.cfg.last;this.lastEl.classList.toggle('has',!!s);
    const inf=s?this.info(s):null;this.lastEl.classList.toggle('off',!!inf?.reason);
    this.lastEl.innerHTML=FRAME_LAST+(s?`<span class="ico">${this.iconHTML(this.icon(s))}</span>`:'');
    if(inf)this.lastEl.setAttribute('aria-label',`Last used · ${inf.label}`);}

  /* ------------------------------------------------------------ gems */
  /** (test.19) A gem's frame in the chosen look; sockets keep the dashed classic frame in both. */
  frame(kind){return (this.look==='hardlight'?hardlightFrame(kind):null)??{cat:FRAME_CAT,short:FRAME_SHORT,leaf:FRAME_LEAF,lane:FRAME_LEAF,more:FRAME_MORE,socket:FRAME_SOCKET}[kind];}
  catTint(cat){return M.DOORS[cat]?.tint??{macros:'#8fd3ff',light:'#ffd98a',emotes:'#ff8fe0'}[cat]??'#ff7ae6';}
  gem(item,{to,from,R,d=0,tint=null}){
    const b=this.doc.createElement('button');b.type='button';b.className=`ffn-b k-${item.kind}`;b.setAttribute('role','menuitem');
    b.style.setProperty('--to',`${to}deg`);b.style.setProperty('--from',`${from}deg`);b.style.setProperty('--R',R);b.style.setProperty('--d',d);
    if(tint)b.style.setProperty('--tint',tint);
    if(item.kind==='cat')b.style.setProperty('--jt',this.catTint(item.cat));
    const frame=this.frame(item.kind);
    let ico='';
    if(item.kind==='cat')ico=this.iconHTML({path:ICONS[M.CATEGORIES[item.cat].icon]});
    else if(item.kind==='more')ico=this.iconHTML({path:ICONS.more});
    else if(item.kind==='socket')ico=this.iconHTML({path:ICONS.add});
    else if(item.slot)ico=this.iconHTML(this.icon(item.slot));
    let extra='';
    if(item.slot){const inf=this.info(item.slot);item.inf=inf;if(inf.toggle)extra+=`<i class="dot${inf.active?' lit':''}"></i>`;if(inf.reason)b.classList.add('off');b.setAttribute('aria-label',inf.label+(inf.reason?` · ${inf.reason}`:''));}
    else b.setAttribute('aria-label',item.kind==='cat'?M.CATEGORIES[item.cat].name:item.kind==='more'?'More…':'Empty socket');
    if(item.context)extra+='<i class="ctx"></i>';
    let lab='';
    if(item.label){
      // (test.16) a ring's bottom gems carry their names out to the side, clear of the plaque beneath
      const low=item.ring?adiff(to,180):99,la=Math.abs(low)<34?180+(low>=0?1:-1)*Math.max(62,Math.abs(low)+40):to;
      const ar=la*RAD,sx=Math.sin(ar),sy=-Math.cos(ar),o=item.kind==='cat'?34:28;
      b.style.setProperty('--lx',`${(30+o*sx).toFixed(1)}px`);b.style.setProperty('--ly',`${(30+o*sy).toFixed(1)}px`);
      b.style.setProperty('--tx',`${(-50+50*sx).toFixed(0)}%`);b.style.setProperty('--ty',`${(-50+50*sy).toFixed(0)}%`);lab=`<span class="lab">${esc(item.label)}</span>`;}
    b.innerHTML=`<span class="ffn-g">${frame}<span class="ico">${ico}</span>${extra}</span>${lab}`;
    b.addEventListener('pointerenter',()=>{if(!this.editing&&!this.drag&&this.items?.includes(item))this.setPick(item);});
    b.addEventListener('focus',()=>{if(!this.editing&&this.items?.includes(item))this.setPick(item);});
    b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(this.editing){this.editClick(item);return;}if(this.items?.includes(item))this.activate(this.scrollPick&&this.items.includes(this.scrollPick)?this.scrollPick:item,{click:true});});
    b.addEventListener('pointerdown',e=>{if(this.editing&&e.button===0&&item.kind!=='socket'){e.preventDefault();e.stopPropagation();this.startDrag(e,item.kind==='cat'?{cat:item.cat,from:item.pos}:{slot:item.slot,from:item.pos});}});
    item.el=b;item.angle=wrap(to);item.r=R;this.root.insertBefore(b,this.plaque);return b;
  }
  shortcutCount(){return Object.values(this.cfg.shortcuts).filter(Boolean).length;}
  catShown(cat){return cat==='macros'?this.feat.macros:cat==='emotes'?this.feat.emotes:true;}
  buildMain(instant){
    (this.mainItems??[]).forEach(i=>i.el.remove());this.mainItems=[];
    const {R}=this.g,items=[];
    for(const p of M.CARDINALS){const cat=this.order[p];if(!cat||!this.catShown(cat))continue;const hidden=this.cfg.hidden.includes(cat);if(hidden&&!this.editing)continue;
      items.push({kind:'cat',cat,pos:p,label:M.CATEGORIES[cat].name,hidden});}
    if(this.feat.shortcuts)for(const p of M.SOCKETS){const s=this.cfg.shortcuts[p];if(s)items.push({kind:'short',slot:s,pos:p,key:M.slotKey(s)});else if(this.editing)items.push({kind:'socket',pos:p});}
    const knots=this.svg.querySelector('.knots');let kh='';
    for(const p of M.SOCKETS)if(!this.feat.shortcuts||!this.cfg.shortcuts[p]){const [x,y]=P(p*30,R);kh+=`<rect class="knot" x="${(x-2.6).toFixed(1)}" y="${(y-2.6).toFixed(1)}" width="5.2" height="5.2" transform="rotate(45 ${x.toFixed(1)} ${y.toFixed(1)})"/>`;}
    knots.innerHTML=kh;
    for(const it of items){
      const a=it.pos*30,signed=a>180?a-360:a,side=signed>=0?1:-1;
      // unfurl: every gem rides up its own side of the ring from below, like a wing opening
      this.gem(it,{to:signed,from:side*180,R});if(it.hidden)it.el.classList.add('hiddencat');
      if(instant||this.level!=='main')it.el.classList.add(this.level==='main'?'on':'out');
    }
    if(instant){this.root.classList.add('instant');requestAnimationFrame(()=>requestAnimationFrame(()=>this.root?.classList.remove('instant')));}
    this.mainItems=items;if(this.level==='main')this.items=items;
  }

  /* ------------------------------------------------------------ levels */
  enter(cat,{swift=false}={}){
    if(this.level!=='main'||this.editing)return;
    const door=this.mainItems.find(i=>i.cat===cat);if(!door)return;
    this.root.classList.toggle('swift',swift);this.swift=swift;this.enteredAt=now();this.level=cat;this.dwell=null;this.pick=null;
    this.root.classList.add('sub');this.root.classList.remove('has-pick','back-pick','cancel-pick');this.root.classList.toggle('emo',cat==='emotes');this.root.classList.toggle('ring',this.isRing(cat));
    this.mainItems.forEach(i=>{i.el.classList.remove('on','picked');i.el.classList.add('out');});
    this.clearTether();this.placePlaque();
    if(cat==='macros'){this.subItems=[];this.items=[];this.macroRing.enter(door.angle);}
    else this.buildSub(cat,door.angle);
    // Flick-ahead: if the pointer is already out past the door, point at once.
    if(this.ptr)this.pointer({clientX:this.ptr.x,clientY:this.ptr.y,target:null});
    if(!this.pick)this.idlePlaque();
  }
  back(){
    this.scrollPick=null;
    if(this.list)this.closeList(true);
    if(this.level==='main')return;
    if(this.level==='macros')this.macroRing.leave();
    this.level='main';this.dwell=null;this.pick=null;this.swift=false;this.emoPick=false;this.pvKey=null;this.root.classList.remove('sub','has-pick','back-pick','emo','ring','swift','msub','cancel-pick');
    for(const i of this.subItems??[]){i.el.classList.remove('on','picked');i.el.classList.add('gone');setTimeout(()=>i.el.remove(),320);}
    this.subItems=[];
    const L=this.svg.querySelector('.L-sub');L.querySelectorAll('.arcg').forEach(a=>a.classList.remove('on'));L.querySelectorAll('.dv').forEach(a=>a.classList.remove('on'));setTimeout(()=>{if(this.level==='main')L.innerHTML='';},260);
    this.mainItems.forEach(i=>{i.el.classList.remove('out');i.el.style.setProperty('--d',0);i.el.classList.add('on');});
    this.items=this.mainItems;this.inside=false;this.clearTether();this.placePlaque();this.idlePlaque();
  }
  /** An arc's lines, band, filament and label, drawn from its centre both ways. */
  addArc(id,name,centre,half,tint,{label=true,lane=null}={}){
    const {tokenR,R2}=this.g,L=this.svg.querySelector('.L-sub');
    const g=this.doc.createElementNS(SVGNS,'g');g.setAttribute('class','arcg');g.dataset.arc=id;g.style.setProperty('--tint',tint);
    const [fx,fy]=P(centre,tokenR+8),[tx,ty]=P(centre,R2-2),[mx,my]=P(centre+9,(tokenR+R2)/2),flen=Math.ceil(Math.hypot(tx-fx,ty-fy)*1.08),alen=Math.ceil(R2*Math.min(half,180)*RAD)+2;
    const full=half>=180;
    let h=full?'':`<path class="band" d="${arcPath(R2,centre-half+6,centre+half-6)}"/>`;
    h+=`<path class="fil" style="--len:${flen}" d="M${fx.toFixed(1)} ${fy.toFixed(1)}Q${mx.toFixed(1)} ${my.toFixed(1)} ${tx.toFixed(1)} ${ty.toFixed(1)}"/>`;
    for(const s of [1,-1])for(const [cls,dr] of [['a',0],['b',3]])h+=`<path class="arcline ${cls}" style="--len:${alen}" d="${arcPath(R2+dr,centre,centre+s*Math.min(half,180))}"/>`;
    if(lane)h+=`<path class="lane" d="${arcPath(lane.r,centre-lane.half,centre+lane.half)}"/>`;
    if(label&&name){const w=name.length*8.6+30,sx=Math.sin(centre*RAD);let [lx,ly]=P(centre,R2+(Math.abs(sx)>.5?30:40));lx+=sx*(w/2+6);h+=`<g class="lbl" transform="translate(${lx.toFixed(1)} ${ly.toFixed(1)})"><path d="${plaquePath(w)}"/><text>${esc(name)}</text></g>`;}
    g.innerHTML=h;L.appendChild(g);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{g.classList.add('on');setTimeout(()=>g.classList.add('drawn'),200);}));
    return g;
  }
  /** Sub levels. Her: three fixed arcs + their context lanes. Light: one arc on its door. Emotes: a ring dealt from the door. */
  buildSub(cat,door){
    const {R2,Rc}=this.g,L=this.svg.querySelector('.L-sub');L.innerHTML='';const items=[];
    if(this.isRing(cat)){
      // (test.16) a door's ring: her own picks, each with its name, dealt clockwise from the door; More… comes last
      const A=M.DOORS[cat],ar=M.arrangeRing(cat,this.cfg.rings[cat],this.ctx),laneDef=M.DOOR_LANES[cat]??[],n=M.RING_SLOTS+1;
      this.addArc(cat,'',door,180,A.tint,{label:false,lane:ar.lane.length?{r:Rc,half:Math.max(...laneDef.map(x=>Math.abs(x.at)))*M.LANE_STEP+8}:null});
      ar.slots.forEach((e,i)=>{if(!e)return;items.push({kind:'leaf',slot:e.slot,arc:cat,ring:cat,ringSlot:e.index,context:e.context,key:M.slotKey(e.slot),tint:A.tint,ang:door+i*M.RING_STEP,r:R2,d:2+Math.min(i,n-i),label:this.info(e.slot).label});});
      items.push({kind:'more',group:cat,arc:cat,ring:cat,key:`more:${cat}`,tint:A.tint,ang:door+M.RING_SLOTS*M.RING_STEP,r:R2,d:3,label:'More…'});
      for(const l of ar.lane)items.push({kind:'lane',slot:l.slot,arc:cat,laneId:l.id,context:l.why,key:`lane:${l.id}`,tint:A.tint,ang:door+l.at*M.LANE_STEP,r:Rc,d:2+Math.abs(l.at)});
    }else if(cat==='her'){
      const size=M.arcSize(this.feat.arcSize);
      for(const [id,A] of Object.entries(M.ARCS)){
        const ar=M.arrangeArc(id,this.cfg.arcs[id],this.ctx,size);
        const laneDef=M.CONTEXT_LANES[id]??[];
        this.addArc(id,A.name,A.centre,M.ARC_STEP*2.5+4,A.tint,
          {lane:ar.lane.length?{r:Rc,half:Math.max(...laneDef.map(x=>Math.abs(x.at)))*M.LANE_STEP+8}:null});
        ar.slots.forEach(e=>{if(!e)return;items.push({kind:'leaf',slot:e.slot,arc:id,arcSlot:e.index,context:e.context,key:M.slotKey(e.slot),tint:A.tint,ang:A.centre+e.offset*M.ARC_STEP,r:R2,d:3+Math.abs(e.offset)});});
        items.push({kind:'more',group:id,arc:id,key:`more:${id}`,tint:A.tint,ang:A.centre+ar.more*M.ARC_STEP,r:R2,d:5});
        for(const l of ar.lane)items.push({kind:'lane',slot:l.slot,arc:id,laneId:l.id,context:l.why,key:`lane:${l.id}`,tint:A.tint,ang:A.centre+l.at*M.LANE_STEP,r:Rc,d:2+Math.abs(l.at)});
      }
      for(const a of [60,180,300]){const [x,y]=P(a,R2),dv=this.doc.createElementNS(SVGNS,'g');dv.setAttribute('class','dv');dv.setAttribute('transform',`translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${a})`);dv.innerHTML=DIVIDER;L.appendChild(dv);
        requestAnimationFrame(()=>requestAnimationFrame(()=>dv.classList.add('on')));}
    }else if(cat==='light'){
      const tint='#ffd98a';this.addArc('light','Light',door+M.LIGHT_STEP/2,M.LIGHT_STEP*2+14,tint,{label:false});
      M.LIGHT_ITEMS.forEach((s,i)=>{const off=M.LIGHT_OFFSETS[i];items.push({kind:'leaf',slot:s,arc:'light',key:M.slotKey(s),tint,ang:door+off*M.LIGHT_STEP,r:R2,d:3+Math.abs(off),label:this.info(s).label});});
    }else if(cat==='emotes'){
      const list=(this.host.emotes?.()??[]).map(e=>({action:'emote',value:e.id,label:e.label}));
      const tint='#ff8fe0',n=Math.max(1,list.length),step=360/n;
      this.addArc(cat,'',door,180,tint,{label:false});
      list.forEach((s,i)=>{const slot={action:s.action,value:s.value};
        items.push({kind:'leaf',slot,arc:cat,key:M.slotKey(slot),tint,ang:door+i*step,r:R2,d:2+Math.min(i,n-i),label:s.label});});
    }
    for(const it of items){const from=cat==='her'&&!this.isRing(cat)?M.ARCS[it.arc].centre:door;
      this.gem(it,{to:from+adiff(it.ang,from),from,R:it.r,d:it.d,tint:it.tint});}
    requestAnimationFrame(()=>requestAnimationFrame(()=>items.forEach(i=>i.el?.classList.add('on'))));
    this.subItems=items;this.items=items;
  }

  /* ------------------------------------------------------------ pointing */
  pointer(e){
    if(!this.root||this.editing||this.drag)return;
    const {x,y,tokenR,R,R2,Rc,lastR}=this.g,dx=e.clientX-x,dy=e.clientY-y,dist=Math.hypot(dx,dy),deg=wrap(Math.atan2(dx,-dy)/RAD);
    this.overChrome=!!e.target?.closest?.('.ffw-plaque,.ffn-panel,.ffm-panel');
    if(this.overChrome)return;
    if(this.level==='macros'){this.macroRing.pointer(e,{dist,deg});return;}
    if(this.level==='main'){
      if(dist<R-10)this.inside=true;
      // the last-used gem has its own small zone below her rim
      if(this.cfg.last&&Math.hypot(dx,dy-lastR)<15){this.setPick({kind:'last'});return;}
      if(dist<tokenR+10){this.setPick({kind:'centre'});return;}
      if(dist<tokenR+16){this.setPick(null);return;}
      // flick-ahead has no outer limit: pointer moves are coalesced per frame, so a fast
      // stroke can jump from inside the ring to well past it between two events
      if(this.held&&this.inside&&dist>R+24){const c=this.nearest(this.mainItems.filter(i=>i.kind==='cat'&&!i.hidden),deg,24);
        if(c){this.setPick(c);this.enter(c.cat,{swift:true});return;}}
      if(dist>R+80){this.setPick(null);return;}
      const it=this.nearest(this.mainItems,deg,30);this.setPick(it);if(it?.slot?.action==='fade')this.fadeAim(it,dx,dy);
      // flick-ahead: moving out through a category opens it at once
      if(this.held&&this.inside&&it?.kind==='cat'&&dist>R+24)this.enter(it.cat,{swift:true});
      return;
    }
    if(dist<tokenR+8){this.setPick({kind:'back'});return;}
    if(dist>R2+95){this.setPick(null);this.leanArc(null);return;}
    let it=null;
    if(this.isRing()){
      if(dist<(Rc+R2)/2-4)it=this.nearest(this.items.filter(i=>i.kind==='lane'),deg,M.LANE_STEP*.6);
      it??=this.nearest(this.items.filter(i=>i.kind!=='lane'),deg,M.RING_STEP*.55);
    }else if(this.level==='her'){
      // the context lane sits inside the arc: point there to reach it
      if(dist<(Rc+R2)/2-4)it=this.nearest(this.items.filter(i=>i.kind==='lane'),deg,M.LANE_STEP*.6);
      it??=this.nearest(this.items.filter(i=>i.kind!=='lane'),deg,M.ARC_STEP*.75);
    }else it=this.nearest(this.items,deg,200/Math.max(3,this.items.length));
    this.setPick(it);
    if(it?.slot?.action==='fade')this.fadeAim(it,dx,dy);
    if(this.level==='her'&&!this.isRing()){const arc=Object.entries(M.ARCS).find(([,A])=>Math.abs(adiff(deg,A.centre))<=60)?.[0];this.leanArc(arc,dx,dy);}
  }
  /** (test.18) The Fade gem's four sides: the side of the gem the pointer is on is the side her cloak starts from
   * (north = from the top, east = from the right…). Close to the gem's centre, or away from it, the side stays as set. */
  fadeAim(it,px,py){
    if(!it?.el||it.slot?.action!=='fade'||!this.ctx.fade||this.feat.cycleFx==='off'||it.inf?.reason){this.clearAim();return;}
    let aim=it.el.querySelector('.ffn-aim');
    if(!aim){aim=this.doc.createElement('span');aim.className='ffn-aim';aim.innerHTML='<i data-d="top"></i><i data-d="right"></i><i data-d="bottom"></i><i data-d="left"></i>';it.el.appendChild(aim);this.aimEl=aim;this.aimDir=this.host.sweepId?.()??'left';}
    if(px!=null&&!it.inf?.active){const [gx,gy]=P(it.angle,it.r),vx=px-gx,vy=py-gy,l=Math.hypot(vx,vy);
      if(l>9&&l<52){const d=Math.abs(vx)>Math.abs(vy)?(vx>0?'right':'left'):(vy>0?'bottom':'top');if(d!==this.aimDir){this.aimDir=d;this.describePick(it);}}}
    aim.classList.toggle('held',!!it.inf?.active);
    for(const i of aim.children)i.classList.toggle('on',i.dataset.d===this.aimDir);
  }
  clearAim(){if(this.aimEl){this.aimEl.remove();this.aimEl=null;}this.aimDir=null;}
  nearest(items,deg,tol){let best=null,bd=1e9;for(const i of items){const d=Math.abs(adiff(deg,i.angle));if(d<bd){bd=d;best=i;}}return bd<=tol?best:null;}
  /** Hovering an arc: its label brightens and its gems lean a little toward the pointer. */
  leanArc(arc,px,py){
    if(arc===this.hotArc&&!arc)return;
    if(arc!==this.hotArc){this.hotArc=arc;this.svg.querySelectorAll('.arcg').forEach(g=>g.classList.toggle('hot',g.dataset.arc===arc));}
    for(const i of this.items??[]){const g=i.el?.firstElementChild;if(!g)continue;
      if(i.arc!==arc||!arc){if(g.style.translate)g.style.translate='';continue;}
      const [gx,gy]=P(i.angle,i.r),vx=px-gx,vy=py-gy,l=Math.hypot(vx,vy)||1,k=Math.min(3.5,260/(l+40));
      g.style.translate=`${(vx/l*k).toFixed(1)}px ${(vy/l*k).toFixed(1)}px`;}
  }
  /** Rest tracking for the fast-flick safety: time since the pointer last moved more than a few pixels. */
  noteRest(){const p=this.ptr,r=this.restPt;if(!r||Math.hypot(p.x-r.x,p.y-r.y)>M.REST_MOVE_PX){this.restPt={x:p.x,y:p.y};this.restAt=now();}}
  restMs(){return now()-Math.max(this.pickAt??0,this.restAt??0);}
  samePick(a,b){return a===b||(!!a&&!!b&&!a.el&&!b.el&&a.kind===b.kind);}
  setPick(it){
    if(!this.root||this.samePick(it,this.pick))return;
    this.pick=it;this.pickAt=now();if(it?.slot?.action!=='fade')this.clearAim();else if(!this.aimEl)this.fadeAim(it,null,null);
    (this.items??[]).forEach(i=>i.el?.classList.toggle('picked',i===it));
    this.lastEl.classList.toggle('picked',it?.kind==='last');
    this.root.classList.toggle('back-pick',it?.kind==='back');
    this.root.classList.toggle('cancel-pick',it?.kind==='centre');
    this.root.classList.toggle('has-pick',!!it&&it.kind!=='back'&&it.kind!=='centre');
    this.dwell=null;
    if(it&&this.held&&(it.kind==='cat'||it.kind==='more'||it.kind==='back'))this.dwell={at:now(),it};
    if(it&&it.el)this.tether(it);else this.clearTether();
    this.describePick(it);
    // (test.16) the Emote gem on Her's ring: the plaque shows her preview while it is pointed at.
    // (12.0.0-beta.5) and so does every gem with an animation of its own (a warp, her shield, her cloak, her landing), on any ring
    const pr=this.previewFor(it);
    if(pr?.key!==this.pvKey){this.previewAt=now();this.cameoKey=null;this.pvKey=pr?.key??null;}
    if(this.level!=='main'&&this.level!=='macros'&&this.level!=='emotes'){this.emoPick=!!pr;this.root.classList.toggle('emo',!!pr);}
  }
  describePick(it){
    if(this.list&&!it)return;
    if(!it)return this.idlePlaque();
    const crumb=this.level==='main'?'':this.level==='her'&&!this.isRing()?`Her · ${M.ARCS[it.arc]?.name??''}`:M.CATEGORIES[this.level]?.name??'';
    if(it.kind==='centre')return this.setPlaque('','Cancel',this.held?'Release here and nothing happens':'Click outside the wheel to close');
    if(it.kind==='last'){const inf=this.info(this.cfg.last);return this.setPlaque('Last used',inf.label,inf.reason??'Again · release to repeat',{reason:!!inf.reason});}
    if(it.kind==='back')return this.setPlaque(crumb,'Back',this.held?'Rest here to go back · release cancels':'Click her · Esc · right-click');
    if(it.kind==='cat'){const c=M.CATEGORIES[it.cat];return this.setPlaque('',c.name,`${this.catHint(it.cat)} · ${this.held?'release or flick through':'click to open'}`);}
    if(it.kind==='more'){const G=this.groupDef(it.group);return this.setPlaque(crumb,'More…',it.ring?`Everything else in ${G.name} · ◆ keeps one on this ring`:`Every ${G.name.toLowerCase()} option`);}
    const inf=it.inf??this.info(it.slot);
    let sub=inf.reason??inf.sub;if(!inf.reason&&it.context)sub=`${sub} · ${it.context==='combat'?'in combat':'while flying'}`;
    // (test.12) a gem with several options: where it stands among them, and that the mouse wheel changes it
    // (test.18) the Fade gem: its look (the mouse wheel changes it) and the side it starts from (the side of the gem pointed at)
    if(it.slot.action==='fade'&&this.host.fadeLookNow&&this.ctx.fade&&this.feat.cycleFx!=='off'&&!inf.reason){const L=this.host.fadeLookNow(),side=this.aimDir??this.host.sweepId?.()??'left';
      return this.setPlaque(`${it.kind==='short'?'Shortcut':crumb} · ${L.label}`.replace(/^ · /,''),inf.label,inf.active?'Runs back the way it came · scroll for another look':`${SIDE_NAMES[side]} · point at a side of the gem · scroll for the look`);}
    if(it.slot.action==='height'&&this.ctx.air&&this.host.heightBy&&this.feat.cycleFx!=='off'&&!inf.reason){this.heightShown=this.host.heightNow?.()??null;
      return this.setPlaque(it.kind==='short'?'Shortcut':it.kind==='lane'?`${crumb} · for now`:crumb,inf.label,`${this.heightShown!=null?`Now ${this.heightShown} ft · `:''}scroll to climb or descend`);}
    const cy=this.cyclable(it),at=cy?` · ${Math.max(0,cy.ids.indexOf(it.slot.value))+1} / ${cy.ids.length}`:'';
    if(cy&&!inf.reason)sub=sub?`${sub} · scroll to change`:'Scroll to change';
    if(it.kind==='short')return this.setPlaque(`Shortcut${at}`,inf.label,sub,{reason:!!inf.reason});
    if(at)return this.setPlaque(`${crumb}${at}`,inf.label,sub,{reason:!!inf.reason});
    this.setPlaque(it.kind==='lane'?`${crumb} · for now`:crumb,inf.label,sub,{reason:!!inf.reason});
  }
  /* ------------------------------------------------------------ (test.12) scroll to change a gem's option */
  /** The options a gem can be turned through: only your own gems (a shortcut, a pick in one of Her arcs) whose action has several. */
  cyclable(it){
    if(!it?.slot||!it.el||this.editing||this.drag||this.feat.cycleFx==='off')return null;
    if(it.cyc!==undefined)return it.cyc;
    const own=it.kind==='short'||(it.kind==='leaf'&&!it.context&&!!this.ownList(it));
    const param=own?this.host.catalog[it.slot.action]?.param:null;if(!param)return it.cyc=null;
    let ids=[];try{ids=(param==='macro'?(this.host.macros?.()??[]):param==='emote'?(this.host.emotes?.()??[]):(this.host.choices(param)??[])).map(c=>c.id);}catch{}
    return it.cyc=ids.length>1?{param,ids}:null;
  }
  wheelTurn(e){
    if(!this.root||this.level==='macros'||e.ctrlKey||e.target?.closest?.('.ffn-panel,.ffm-panel'))return;
    const it=this.pick;
    const notch=(gap=90)=>{e.preventDefault();e.stopPropagation();this.wheelAcc+=e.deltaMode===1?e.deltaY*40:e.deltaMode===2?e.deltaY*400:e.deltaY;
      const t=now();if(Math.abs(this.wheelAcc)<40||t-this.wheelAt<gap)return 0;const d=this.wheelAcc>0?1:-1;this.wheelAcc=0;this.wheelAt=t;return d;};
    const live=this.feat.cycleFx!=='off'&&!this.editing&&!this.drag;
    // (test.13) on the Emotes ring the wheel walks the pick round the ring, one emote a notch (release or click plays it)
    if(live&&this.level==='emotes'&&!this.list){const ring=(this.items??[]).filter(i=>i.kind==='leaf'&&i.slot?.action==='emote');
      if(ring.length>1&&(!it||ring.includes(it))){const d=notch(80);if(!d)return;
        const i=it?ring.indexOf(it):(d>0?-1:0),next=ring[((i+d)%ring.length+ring.length)%ring.length];
        this.scrollPick=next;this.scrollPt={x:e.clientX,y:e.clientY};this.cycleWas=this.plaque.querySelector('.ffw-name').textContent;this.setPick(next);this.nameFx(d);return;}}
    // (test.13) over the Fade gem the wheel turns the side her cloak sweeps from
    if(live&&it?.slot?.action==='fade'&&this.host.fadeLook&&this.ctx.fade){const d=notch(110);if(!d)return;
      this.cycleWas=this.lookShown??this.host.fadeLookNow?.().label??'';
      this.sweepQueue=(this.sweepQueue??Promise.resolve()).then(async()=>{let r=null;try{r=await this.host.fadeLook(d);}catch(err){this.host.error?.(err);return;}
        if(!this.root||this.pick!==it||!r)return;this.lookShown=r.label;this.setPlaque(`Her cloak · ${r.at} / ${r.of}`,r.label,`${SIDE_NAMES[this.aimDir??this.host.sweepId?.()??'left']} · release to fade`);this.nameFx(d);});
      return;}
    // (test.13) over a height gem while she flies, the wheel is her height itself: up climbs, down descends, 5 ft a notch
    if(it?.slot?.action==='height'&&this.ctx.air&&this.host.heightBy&&this.feat.cycleFx!=='off'&&!this.editing){
      e.preventDefault();e.stopPropagation();
      this.wheelAcc+=e.deltaMode===1?e.deltaY*40:e.deltaMode===2?e.deltaY*400:e.deltaY;
      const t=now();if(Math.abs(this.wheelAcc)<40||t-this.wheelAt<90)return;
      const up=this.wheelAcc<0;this.wheelAcc=0;this.wheelAt=t;this.heightStep(it,up?5:-5);return;
    }
    const cy=this.cyclable(it);if(!cy)return;
    e.preventDefault();e.stopPropagation();
    // one notch of a mouse wheel is one step; a touchpad's small deltas add up to one
    this.wheelAcc+=e.deltaMode===1?e.deltaY*40:e.deltaMode===2?e.deltaY*400:e.deltaY;
    const t=now();if(Math.abs(this.wheelAcc)<40||t-this.wheelAt<70)return;
    const dir=this.wheelAcc>0?1:-1;this.wheelAcc=0;this.wheelAt=t;this.cycle(it,cy,dir);
  }
  /** One notch over a height gem: her height changes by `feet` now (steps queue, so quick notches all land), the plaque shows it. */
  heightStep(it,feet){
    const was=this.heightShown??this.host.heightNow?.()??null;
    this.heightQueue=(this.heightQueue??Promise.resolve()).then(async()=>{
      let ft=null;try{ft=await this.host.heightBy(feet);}catch(e){this.host.error?.(e);return;}
      if(!this.root||this.pick!==it)return;
      const before=this.heightShown??was;this.heightShown=ft;
      this.cycleWas=before!=null?`${before} ft`:'';
      this.setPlaque('Flying height',`${ft} ft`,ft===before?(feet<0?'On the ground level · scroll up to climb':'No higher'):'Scroll: 5 ft a notch · up climbs, down descends');
      if(ft!==before)this.nameFx(feet>0?-1:1);
    });
  }
  /** The plaque's name changing the way the switch animation is set (the gem itself stays as it is). */
  nameFx(dir){
    const style=this.feat.cycleFx??'orbit';if(style==='plain'||style==='off'||this.root.classList.contains('reduced'))return;
    const name=this.plaque.querySelector('.ffw-name');name.classList.remove('swap');for(const x of this.plaque.querySelectorAll('.ffn-cyc'))x.remove();
    if(style==='orbit')this.nameOrbit(name,dir);else this.nameSlide(name,dir);
  }
  /** The plaque's name on the same carousel: the old name leaves to the side and back, the new one comes round from the other side. */
  nameOrbit(name,dir){
    const D=460,E='cubic-bezier(.45,.05,.2,1)',was=this.doc.createElement('span');was.className='ffn-cyc';was.textContent=this.cycleWas??'';was.setAttribute('aria-hidden','true');
    let cs=null;try{cs=this.doc.defaultView.getComputedStyle(name);}catch{}
    was.style.cssText=`position:absolute;left:${name.offsetLeft}px;width:${name.offsetWidth}px;top:${name.offsetTop}px;margin:0;z-index:-1;pointer-events:none;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:${cs?.textAlign??'center'};font:${cs?.font??'inherit'};color:${cs?.color??'inherit'}`;name.parentNode.insertBefore(was,name);
    was.animate([{transform:'translateX(0) scale(1)',opacity:.95},{transform:`translateX(${dir*46}px) scale(.86)`,opacity:.25,offset:.45},{transform:`translateX(${dir*30}px) scale(.7)`,opacity:0,offset:.6},{transform:`translateX(${dir*30}px) scale(.7)`,opacity:0}],{duration:D,easing:E}).finished.then(()=>was.remove(),()=>was.remove());
    name.animate([{transform:`translateX(${-dir*30}px) scale(.7)`,opacity:0},{transform:`translateX(${-dir*30}px) scale(.7)`,opacity:0,offset:.3},{transform:`translateX(${-dir*46}px) scale(.86)`,opacity:.3,offset:.5},{transform:'none',opacity:1}],{duration:D,easing:E});
  }
  nameSlide(name,dir){
    const S='cubic-bezier(.3,.75,.3,1)',D=340,was=this.doc.createElement('span');was.className='ffn-cyc';was.textContent=this.cycleWas??'';was.setAttribute('aria-hidden','true');
    // (its own class: the plaque's name is looked up by class, and must never find this one)
    let cs=null;try{cs=this.doc.defaultView.getComputedStyle(name);}catch{}
    was.style.cssText=`position:absolute;left:${name.offsetLeft}px;width:${name.offsetWidth}px;top:${name.offsetTop}px;margin:0;z-index:-1;pointer-events:none;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:${cs?.textAlign??'center'};font:${cs?.font??'inherit'};color:${cs?.color??'inherit'}`;name.parentNode.insertBefore(was,name);
    // the old name is gone behind before the new one has fully arrived, so the two never read as one smear
    was.animate([{transform:'translateY(0) scale(1)',opacity:.9},{transform:`translateY(${-dir*4}px) scale(.93)`,opacity:0,offset:.5},{transform:`translateY(${-dir*5}px) scale(.9)`,opacity:0}],{duration:D,easing:'ease-out'}).finished.then(()=>was.remove(),()=>was.remove());
    name.animate([{transform:`translateY(${dir*9}px)`,opacity:0},{transform:`translateY(${dir*6}px)`,opacity:0,offset:.18},{opacity:1,offset:.7},{transform:'none',opacity:1}],{duration:D,easing:S});
  }
  /** Turn a gem to its next (dir 1) or previous (dir −1) option, in place; saved shortly after, and on close. */
  cycle(it,cy,dir){
    const n=cy.ids.length,own=it.kind==='leaf'?this.ownList(it):null,arc=own?.[0]??null,at=own?.[1];let i=cy.ids.indexOf(it.slot.value);if(i<0)i=dir>0?-1:0;
    let value=null;
    // (an arc never shows the same option twice: an option another gem of that arc already holds is passed over)
    for(let k=0;k<n;k++){i=((i+dir)%n+n)%n;const v=cy.ids[i];if(arc&&arc.some((s,j)=>j!==at&&s&&s.action===it.slot.action&&(s.value??null)===v))continue;value=v;break;}
    if(value==null||value===it.slot.value)return false;
    const slot={action:it.slot.action,value};
    if(it.kind==='short')this.cfg.shortcuts[it.pos]=slot;else arc[at]=slot;
    const ico=it.el.querySelector('.ffn-g:not(.ffn-cyc) .ico:not(.ffn-cyc)'),old=ico.innerHTML;this.cycleWas=it.inf?.label??this.plaque.querySelector('.ffw-name').textContent;
    it.slot=slot;it.key=M.slotKey(slot);const inf=it.inf=this.info(slot);
    ico.innerHTML=this.iconHTML(this.icon(slot));
    const dot=it.el.querySelector('.dot');if(dot)dot.classList.toggle('lit',!!inf.active);
    it.el.classList.toggle('off',!!inf.reason);it.el.setAttribute('aria-label',inf.label+(inf.reason?` · ${inf.reason}`:''));
    // (a ring's gem wears its name: the name changes with it)
    const lab=it.el.querySelector('.lab');if(lab&&it.ring){it.label=inf.label;lab.textContent=inf.label;}
    this.describePick(it);
    this.cycleFx(it,dir,old);
    this.cycleDirty=true;clearTimeout(this.cycleTimer);this.cycleTimer=setTimeout(()=>{if(this.root&&this.cycleDirty){this.cycleDirty=false;this.save();}},700);
    return true;
  }
  /** The switch's animation (Settings › Emotes & wheel › Nested wheel › Parts). Transforms and opacity only, about a third of a second at most. */
  cycleFx(it,dir,oldHTML){
    const style=this.feat.cycleFx??'orbit';if(style==='plain'||style==='off'||this.root.classList.contains('reduced'))return;
    const g=it.el.querySelector('.ffn-g:not(.ffn-cyc)'),ico=g.querySelector('.ico:not(.ffn-cyc)'),name=this.plaque.querySelector('.ffw-name');
    for(const x of it.el.querySelectorAll('.ffn-cyc'))x.remove();for(const x of this.plaque.querySelectorAll('.ffn-cyc'))x.remove();
    const ghost=this.doc.createElement('span');ghost.className='ico ffn-cyc';ghost.innerHTML=oldHTML;g.appendChild(ghost);
    const E='cubic-bezier(.2,.8,.2,1)',gone=a=>a.finished.then(()=>ghost.remove(),()=>ghost.remove());
    name.classList.remove('swap');
    if(style==='orbit'){
      // (test.14) the whole gem turns like a carousel: the old gem swings out to the side, shrinks and passes round behind;
      // the new gem comes round from behind on the other side and settles in front. Sideways, one motion, the name with it.
      ghost.remove();
      const D=460,E='cubic-bezier(.45,.05,.2,1)',P='perspective(260px) ',X=34;
      const old=g.cloneNode(true);old.classList.add('ffn-cyc');for(const x of old.querySelectorAll('.ffn-cyc'))x.remove();
      for(const x of old.querySelectorAll('*'))x.classList.add('ffn-cyc');const oi=old.querySelector('.ico');if(oi)oi.innerHTML=oldHTML;
      old.style.pointerEvents='none';g.after(old);
      const done=()=>{old.remove();if(!it.el.querySelector('.ffn-g.ffn-cyc'))g.style.zIndex='';};
      g.style.zIndex='1';
      // the old gem: front → out to the side → round behind (under the new one from the moment it turns back)
      old.animate([
        {transform:P+'translateX(0) rotateY(0deg) scale(1)',opacity:1,zIndex:2},
        {transform:P+`translateX(${dir*X}px) rotateY(${-dir*62}deg) scale(.8)`,opacity:.85,zIndex:2,offset:.42},
        {transform:P+`translateX(${dir*X}px) rotateY(${-dir*66}deg) scale(.78)`,opacity:.8,zIndex:0,offset:.46},
        {transform:P+`translateX(${dir*12}px) rotateY(${-dir*80}deg) scale(.52)`,opacity:0,zIndex:0}],{duration:D,easing:E}).finished.then(done,done);
      // the new gem: behind → out on the other side → front
      g.animate([
        {transform:P+`translateX(${-dir*12}px) rotateY(${dir*80}deg) scale(.52)`,opacity:0},
        {transform:P+`translateX(${-dir*X}px) rotateY(${dir*62}deg) scale(.8)`,opacity:.8,offset:.5},
        {transform:'none',opacity:1}],{duration:D,easing:E});
      // a short streak of her light under each, the way they travel
      for(const [side,from,to,delay] of [[dir,0,dir*X,0],[-dir,-dir*X,0,D*.45]]){const st=this.doc.createElement('i');st.className='ffn-cyc ffn-streak';it.el.appendChild(st);
        st.style.setProperty('--flip',side*(to>from?1:-1)>0?'1':'-1');
        st.animate([{transform:`translateX(${from}px) scaleX(.2)`,opacity:0},{opacity:.55,offset:.4},{transform:`translateX(${to}px) scaleX(1)`,opacity:0}],{duration:D*.55,delay,easing:'ease-out',fill:'backwards'}).finished.then(()=>st.remove(),()=>st.remove());}
      this.nameOrbit(name,dir);
    }else if(style==='slide'){
      // (test.13) the next option slides in over the top; the one it replaces settles back behind it, smaller and dimmer, and is gone.
      // One smooth ease for both, so they read as two cards of one deck. The name on the plaque does the same.
      const S='cubic-bezier(.3,.75,.3,1)',D=340;
      g.insertBefore(ghost,ico);   // (the old option is drawn beneath the new one)
      gone(ghost.animate([{transform:'translateY(0) scale(1)',opacity:1},{transform:`translateY(${-dir*5}px) scale(.84)`,opacity:.6,offset:.5},{transform:`translateY(${-dir*9}px) scale(.68)`,opacity:0}],{duration:D,easing:'cubic-bezier(.4,.2,.4,1)'}));
      ico.animate([{transform:`translateY(${dir*18}px)`,opacity:0},{opacity:1,offset:.45},{transform:'none',opacity:1}],{duration:D,easing:S});
      this.nameSlide(name,dir);
    }else if(style==='roll'){
      // the old option rolls out one way and the new one rolls in behind it, as on a drum; the name follows
      gone(ghost.animate([{transform:'translateY(0)',opacity:1},{transform:`translateY(${-dir*15}px)`,opacity:0}],{duration:170,easing:'ease-in'}));
      ico.animate([{transform:`translateY(${dir*15}px)`,opacity:0},{transform:'none',opacity:1}],{duration:210,easing:E});
      name.animate([{transform:`translateY(${dir*9}px)`,opacity:0},{transform:'none',opacity:1}],{duration:200,easing:E});
    }else if(style==='facet'){
      // the gem turns a facet: the old option narrows away, a line of light crosses, the new one opens
      gone(ghost.animate([{transform:'scaleX(1)',opacity:1},{transform:'scaleX(0)',opacity:.6}],{duration:95,easing:'ease-in'}));
      ico.animate([{transform:'scaleX(0)',opacity:.6},{transform:'scaleX(0)',opacity:.6,offset:.42},{transform:'none',opacity:1}],{duration:225,easing:'ease-out'});
      const line=this.doc.createElement('i');line.className='ffn-cyc ffn-facet';g.appendChild(line);
      line.animate([{transform:`translateX(${-dir*15}px)`,opacity:0},{opacity:.95,offset:.45},{transform:`translateX(${dir*15}px)`,opacity:0}],{duration:225,easing:'ease-in-out'}).finished.then(()=>line.remove(),()=>line.remove());
      name.animate([{opacity:.25},{opacity:1}],{duration:200,easing:'ease-out'});
    }else if(style==='thread'){
      // a short thread of light runs along the ring past the gem, the way it was turned; the option turns in with it
      gone(ghost.animate([{transform:'rotate(0deg)',opacity:1},{transform:`rotate(${dir*26}deg)`,opacity:0}],{duration:150,easing:'ease-in'}));
      ico.animate([{transform:`rotate(${-dir*26}deg)`,opacity:0},{transform:'none',opacity:1}],{duration:210,easing:E});
      const L=this.svg.querySelector('.flys'),p=this.doc.createElementNS(SVGNS,'path'),half=Math.min(22,1500/Math.max(60,it.r));
      p.setAttribute('class','ffn-tick');p.setAttribute('d',arcPath(it.r+31,it.angle-half,it.angle+half));L.appendChild(p);
      const len=p.getTotalLength(),seg=len*.45;p.style.strokeDasharray=`${seg} ${len+seg}`;
      const a0=dir>0?seg:-len,a1=dir>0?-len:seg;
      p.animate([{strokeDashoffset:a0,opacity:0},{opacity:1,offset:.25},{opacity:1,offset:.7},{strokeDashoffset:a1,opacity:0}],{duration:260,easing:'ease-out'}).finished.then(()=>p.remove(),()=>p.remove());
      name.animate([{transform:`translateX(${dir*8}px)`,opacity:0},{transform:'none',opacity:1}],{duration:200,easing:E});
    }
  }
  tether(it){
    const {tokenR}=this.g,a=it.angle,r0=tokenR+6,r1=it.r-(it.kind==='short'?20:it.kind==='lane'?16:24),[x0,y0]=P(a,r0),[x1,y1]=P(a,r1),[mx,my]=P(a+12,(r0+r1)/2);
    const d=`M${x0.toFixed(1)} ${y0.toFixed(1)}Q${mx.toFixed(1)} ${my.toFixed(1)} ${x1.toFixed(1)} ${y1.toFixed(1)}`;
    for(const t of this.svg.querySelectorAll('.tether'))t.setAttribute('d',d);
  }
  clearTether(){for(const t of this.svg?.querySelectorAll('.tether')??[])t.setAttribute('d','');}
  tick(){
    const a=this.host.anchor?.();if(a&&(a.x!==this.g.x||a.y!==this.g.y)){this.g.x=a.x;this.g.y=a.y;this.root.style.left=`${a.x}px`;this.root.style.top=`${a.y}px`;}
    const t=now();
    if(this.dwell&&this.held){const need=this.dwell.it.kind==='back'?300:this.dwell.it.kind==='more'?320:260;
      if(t-this.dwell.at>=need){const it=this.dwell.it;this.dwell=null;if(it.kind==='cat')this.enter(it.cat);else if(it.kind==='back')this.back();else if(it.kind==='more')this.openList(it.group);}}
    if(this.level==='macros')this.macroRing.tick(t);
    if(this.level==='emotes'||this.emoPick)this.drawCameo(t);
  }
  /** (12.0.0-beta.5) The preview a pointed gem plays ({kind, id, key}), or null. The host decides (quick-wheel.mjs previewOf). */
  previewFor(it){
    const slot=it&&(it.kind==='leaf'||it.kind==='lane')?it.slot:null;if(!slot)return null;
    let p=null;try{p=this.host.previewOf?this.host.previewOf(slot):slot.action==='emote'&&this.feat.emotes?{kind:'emote',id:slot.value}:null;}catch{}
    return p?{kind:p.kind,id:p.id,key:`${p.kind}:${p.id}`}:null;
  }
  /** The cameo: a baked strip, stepped at its own frame rate (not every display frame). The emotes' ring shows her idle between picks. */
  drawCameo(t){
    // (read again each step: her cloak's look can be changed with the scroll wheel while its gem is pointed at)
    const pr=this.previewFor(this.pick);if((pr?.key??null)!==this.pvKey){this.previewAt=t;this.cameoKey=null;this.pvKey=pr?.key??null;}
    const id=pr?pr.key:'idle',pv=pr?this.host.preview?.(pr.id,pr.kind):this.level==='emotes'?this.host.preview?.('idle'):null;
    if(!pv?.img?.complete&&!pv?.img?.width){
      // (not loaded yet, or nothing to show: an empty cameo, never the frame of the gem pointed at before)
      if(this.cameoKey!==`none:${id}`){this.cameoKey=`none:${id}`;const g0=this.cameo.getContext('2d');g0.clearRect(0,0,this.cameo.width,this.cameo.width);}return;}
    const loop=pv.n/pv.fps,q=((t-(id==='idle'?0:this.previewAt))/1000)%loop,f=Math.min(pv.n-1,Math.floor(q*pv.fps)),key=`${id}:${f}`;
    if(key===this.cameoKey)return;this.cameoKey=key;
    const g=this.cameo.getContext('2d'),W=this.cameo.width,cols=pv.cols??pv.n;g.clearRect(0,0,W,W);
    g.drawImage(pv.img,(f%cols)*pv.w,(pv.row??0)*pv.h+Math.floor(f/cols)*pv.h,pv.w,pv.h,0,0,W,W);
  }

  /* ------------------------------------------------------------ choosing */
  /** The key is let go. Centre cancels; categories open; an action fires only when it is safe to. */
  release(){
    if(!this.root||this.editing)return;
    const tap=now()-this.openedAt<200,wasHeld=this.held;this.held=false;this.dwell=null;
    if(this.overChrome||tap||!wasHeld)return;
    if(this.level==='macros')return this.macroRing.release();
    const it=this.pick;
    if(!it)return;
    if(it.kind==='centre'||it.kind==='back'){this.close();return;}
    if(ACTION_KINDS.has(it.kind)&&this.unsafe(it)){
      this.setPlaque(this.plaque.querySelector('.ffn-crumb').textContent,(it.inf??this.info(it.kind==='last'?this.cfg.last:it.slot)).label,'Too quick to be sure · click it to use it',{reason:true});return;}
    this.activate(it);
  }
  /** Fast-flick safety (model.releaseDecision): inside the gem, or rested on it. */
  unsafe(it){
    const {x,y,lastR}=this.g,p=this.ptr;if(!p)return false;
    let gx,gy;if(it.kind==='last'){gx=x;gy=y+lastR;}else{const [px,py]=P(it.angle,it.r);gx=x+px;gy=y+py;}
    const zone=it.kind==='lane'||it.kind==='last'?M.GEM_ZONE_PX*.8:M.GEM_ZONE_PX;
    const r=it.kind==='last'?lastR:it.r,dist=Math.hypot(p.x-x,p.y-y);
    return M.releaseDecision({inZone:Math.hypot(p.x-gx,p.y-gy)<=zone,near:Math.abs(dist-r)<=M.NEAR_RING_PX,dwellMs:this.restMs(),sinceEnterMs:this.level==='main'?Infinity:now()-this.enteredAt,swift:this.swift})!=='fire';
  }
  activate(it,{click=false}={}){
    if(!it)return;
    if(it.kind==='cat')return this.enter(it.cat);
    if(it.kind==='back')return this.back();
    if(it.kind==='centre')return this.close();
    if(it.kind==='last')return this.fireLast();
    if(it.kind==='more')return this.list?.group===it.group?this.closeList():this.openList(it.group);
    if(it.slot)return this.fire(it.slot,it);
  }
  /** (12.0.0-beta.5) The wheel key tapped a second time, while the first tap's wheel is still on its main ring: the last
   * used action again. Only within 450 ms of opening and with nothing entered, so it is never a slip of a slow hand. */
  again(){
    if(!this.root||this.editing||this.list||this.level!=='main'||!this.cfg?.last||now()-this.openedAt>450)return false;
    this.fireLast();return true;
  }
  fireLast(){const s=this.cfg.last;if(!s)return;const inf=this.info(s);
    if(inf.reason){this.lastEl.animate([{translate:'-3px 0'},{translate:'3px 0'},{translate:'0 0'}],{duration:260});this.setPlaque('Last used',inf.label,inf.reason,{reason:true});return;}
    this.fly(0,0,true);this.finish(s);}
  fire(slot,it){
    const inf=this.info(slot);
    if(inf.reason){it?.el?.classList.remove('nope');void it?.el?.offsetWidth;it?.el?.classList.add('nope');this.setPlaque(this.plaque.querySelector('.ffn-crumb').textContent,inf.label,inf.reason,{reason:true});return;}
    // (test.18) fading out from the Fade gem: the side pointed at is where her cloak starts (kept on her token, so fading in runs it back)
    if(slot.action==='fade'&&!inf.active&&this.aimDir&&this.host.setSweep)this.pre=this.host.setSweep(this.aimDir);
    if(it?.el){it.el.classList.add('fold');this.fly(it.angle,it.r);}
    this.finish(slot);
  }
  /** The chosen gem folds into a small filament that flies into her token. */
  fly(angle,r,fromLast=false){
    const L=this.svg.querySelector('.flys');if(this.root.classList.contains('reduced'))return;
    const {tokenR,lastR}=this.g;let x0,y0;if(fromLast){x0=0;y0=lastR;}else [x0,y0]=P(angle,r);
    const [mx,my]=fromLast?[tokenR*.5,tokenR*.3]:P(angle+28,r*.55),x1=0,y1=-tokenR*.1;
    const d=`M${x0.toFixed(1)} ${y0.toFixed(1)}Q${mx.toFixed(1)} ${my.toFixed(1)} ${x1} ${y1}`;
    for(const [cls,seg] of [['t',70],['g',44],['c',22]]){const p=this.doc.createElementNS(SVGNS,'path');p.setAttribute('class','fly '+cls);p.setAttribute('d',d);L.appendChild(p);
      const len=p.getTotalLength();p.style.strokeDasharray=`${seg} ${len+60}`;
      p.animate([{strokeDashoffset:seg,opacity:1},{strokeDashoffset:-len+seg*.2,opacity:1,offset:.85},{strokeDashoffset:-len,opacity:0}],{duration:300,easing:'cubic-bezier(.5,0,.7,1)',fill:'forwards'});}
    setTimeout(()=>{this.root?.classList.add('recv');},240);
  }
  finish(slot){
    this.cfg.last={action:slot.action,value:slot.value??null};this.save();
    const root=this.root;setTimeout(()=>{if(this.root===root)this.close();},this.root.classList.contains('reduced')?60:380);
    void this.run(slot);
  }
  async run(slot){try{if(this.pre){const p=this.pre;this.pre=null;try{await p;}catch{}}await this.host.run(slot);}catch(e){this.host.error?.(e);}}

  /* ------------------------------------------------------------ More… list */
  openList(group){
    this.closeList(true);const ring=this.isRing(group),G=this.groupDef(group),tint=this.groupTint(group);
    const p=this.panel(`${G.name} · all options`,ring?'Click to use · ◆ keeps it on this ring':'Click to use · ◆ shows it in the arc',tint);
    const sc=p.querySelector('.scroll');
    const size=M.arcSize(this.feat.arcSize),inArc=s=>ring?(this.cfg.rings[group]??[]).some(x=>M.sameSlot(x,s)):(this.cfg.arcs[group]??[]).slice(0,size).some(x=>M.sameSlot(x,s));
    const sec=(title,slots)=>{if(!slots.length)return;const el=this.doc.createElement('div');el.className='ffn-sec';el.innerHTML=`<div class="hd">${esc(title)}<span class="n">${slots.length}</span></div><div class="chips"></div>`;
      const ch=el.querySelector('.chips');for(const s of slots)ch.appendChild(this.chip(s,{pin:inArc(s),onPin:()=>this.pin(group,s)}));sc.appendChild(el);};
    sec('Actions',this.rowsOf(G.rows.filter(r=>!r.param)));
    for(const r of G.rows.filter(r=>r.param))sec(r.param==='heightStep'?'Height':r.param[0].toUpperCase()+r.param.slice(1),this.valuesOf(r));
    this.list={group,el:p};this.items?.find(i=>i.key===`more:${group}`)?.el.classList.add('picked');
    this.setPlaque(this.level==='her'&&!ring?`Her · ${G.name}`:G.name,'More…',`${G.name} · every option`);
  }
  /** Rows the host can do (Fade only while api.v11.fade exists). */
  rowsOf(rows){return rows.filter(s=>s.action!=='fade'||this.ctx.fade);}
  valuesOf(r){
    if(r.param==='emote')return (this.host.emotes?.()??[]).map(e=>({action:'emote',value:e.id}));
    if(r.param==='macro')return (this.host.macros?.()??[]).map(m=>({action:'macro',value:m.id}));
    return (this.host.choices(r.param)??[]).map(c=>({action:r.action,value:c.id}));
  }
  closeList(silent){if(!this.list)return;const el=this.list.el;el.classList.remove('on');setTimeout(()=>el.remove(),220);this.items?.find(i=>i.key===`more:${this.list.group}`)?.el?.classList.remove('picked');this.list=null;if(!silent)this.idlePlaque();}
  panel(title,note,tint){
    const p=this.doc.createElement('div');p.className='ffn-panel';p.style.setProperty('--tint',tint);
    const {R2,x}=this.g,W=this.doc.defaultView?.innerWidth??1e9,right=x+R2+70+290<W;
    p.style.setProperty('--pl',right?`${R2+64}px`:`${-R2-64-290}px`);p.style.setProperty('--pt',`${-250}px`);
    p.innerHTML=`<h3>${esc(title)}</h3><div class="note">${esc(note)}</div><div class="scroll"></div>`;
    p.addEventListener('wheel',e=>e.stopPropagation(),{passive:true});
    this.root.appendChild(p);requestAnimationFrame(()=>requestAnimationFrame(()=>p.classList.add('on')));return p;
  }
  chip(slot,{pin=null,onPin=null,drag=false}={}){
    const inf=this.info(slot),b=this.doc.createElement('button');b.type='button';b.className='ffn-chip'+(inf.reason?' off':'');b.dataset.key=M.slotKey(slot);
    b.innerHTML=`<span class="mg">${this.iconHTML(this.icon(slot))}</span><span class="t">${esc(inf.label)}</span>${inf.toggle&&inf.active?'<i class="dotx"></i>':''}${pin!==null?`<i class="pin${pin?' in':''}"></i>`:''}`;
    b.title=inf.reason??inf.sub??'';
    b.addEventListener('pointerenter',()=>{if(!this.drag)this.setPlaque(this.editing?'Library':'More…',inf.label,inf.reason??inf.sub,{reason:!!inf.reason});});
    if(drag)b.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();e.stopPropagation();this.startDrag(e,{slot});});
    else b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();
      if(e.target.classList.contains('pin')){onPin?.();e.target.classList.toggle('in');return;}
      if(inf.reason){b.animate([{translate:'-3px 0'},{translate:'3px 0'},{translate:'0 0'}],{duration:240});return;}
      this.closeList(true);this.finish(slot);});
    return b;
  }
  /** ◆ in More…: show in / remove from this arc. */
  pin(group,s){
    const ring=this.isRing(group);
    if(ring)this.cfg.rings[group]=M.toggleRingPin(this.cfg.rings[group],s);else this.cfg.arcs[group]=M.togglePin(this.cfg.arcs[group],s,this.feat.arcSize);
    this.save();const lvl=this.level,door=this.mainItems.find(i=>i.cat===lvl)?.angle??0;
    for(const i of this.subItems)i.el.remove();this.root.classList.add('instant');this.buildSub(lvl,door);this.subItems.forEach(i=>i.el.classList.add('on'));
    this.svg.querySelectorAll('.arcg').forEach(g=>g.classList.add('on','drawn'));this.svg.querySelectorAll('.dv').forEach(g=>g.classList.add('on'));
    requestAnimationFrame(()=>requestAnimationFrame(()=>this.root?.classList.remove('instant')));
    this.items.find(i=>i.key===`more:${group}`)?.el.classList.add('picked');
    const size=M.arcSize(this.feat.arcSize);this.list?.el.querySelectorAll('.ffn-chip').forEach(c=>{const pinEl=c.querySelector('.pin');if(pinEl)pinEl.classList.toggle('in',(ring?this.cfg.rings[group]??[]:(this.cfg.arcs[group]??[]).slice(0,size)).some(x=>x&&M.slotKey(x)===c.dataset.key));});
  }

  /* ------------------------------------------------------------ Edit */
  toggleEdit(){
    if(this.level!=='main')this.back();
    this.editing=!this.editing;this.pick=null;this.root.classList.toggle('editing',this.editing);this.root.classList.remove('has-pick','cancel-pick');this.clearTether();
    this.buildMain(true);
    if(this.editing){if(this.feat.shortcuts)this.openLibrary();}else{this.lib?.classList.remove('on');const l=this.lib;setTimeout(()=>l?.remove(),220);this.lib=null;this.save();}
    this.idlePlaque();
  }
  openLibrary(){
    const p=this.lib=this.panel('Library','Drag any action onto a socket on the ring','#cfae76'),sc=p.querySelector('.scroll');
    const order=(this.doors?[['her','Her'],['actions','Actions'],['bits','Bits'],['macros','Macros']]:[['flight','Her · Flight'],['bits','Her · Bits'],['wings','Her · Wings'],['light','Light'],['emotes','Emotes'],['macros','Macros'],['features','Features · on / off'],['other','Other']])
      .filter(([g])=>(g!=='emotes'||this.feat.emotes)&&(g!=='macros'||this.feat.macros));
    for(const [g,title] of order){const G=this.groupDef(g),el=this.doc.createElement('div');el.className='ffn-sec shut';el.dataset.group=g;el.style.setProperty('--tint',(this.doors?M.DOORS[g]?.tint:null)??M.ARCS[g]?.tint??(g==='light'?'#ffd98a':g==='emotes'?'#ff8fe0':g==='macros'?'#d9b4ff':'#cfae76'));
      const plain=this.rowsOf(G.rows.filter(r=>!r.param)),params=G.rows.filter(r=>r.param);let count=plain.length;
      el.innerHTML=`<div class="hd">${esc(title)}<span class="n"></span></div>`;
      if(plain.length){const c=this.doc.createElement('div');c.className='chips';plain.forEach(s=>c.appendChild(this.chip(s,{drag:true})));el.appendChild(c);}
      for(const r of params){const vals=this.valuesOf(r);count+=vals.length;if(params.length>1||plain.length){const h=this.doc.createElement('div');h.className='sub';h.textContent=r.param==='heightStep'?'Height':r.param;el.appendChild(h);}
        const c=this.doc.createElement('div');c.className='chips';vals.forEach(s=>c.appendChild(this.chip(s,{drag:true})));el.appendChild(c);}
      el.querySelector('.n').textContent=count;
      el.querySelector('.hd').addEventListener('click',e=>{e.stopPropagation();el.classList.toggle('shut');});
      sc.appendChild(el);}
    this.markUsed();
  }
  markUsed(){if(!this.lib)return;const used=new Set(Object.values(this.cfg.shortcuts).filter(Boolean).map(M.slotKey));this.lib.querySelectorAll('.ffn-chip').forEach(c=>c.classList.toggle('used',used.has(c.dataset.key)));}
  editClick(item){
    if(item.kind==='cat'){const h=this.cfg.hidden,i=h.indexOf(item.cat);if(i>=0)h.splice(i,1);else h.push(item.cat);this.buildMain(true);
      this.setPlaque('Edit the wheel',M.CATEGORIES[item.cat].name,i>=0?'Shown on the ring':'Hidden · click again to show');return;}
    if(item.kind==='short'){const inf=this.info(item.slot);this.setPlaque('Shortcut',inf.label,'Drag to move · drag off the ring to remove');}
  }
  startDrag(e,src){
    const ghost=this.doc.createElement('div');ghost.className='ffn-ghost';
    const kind=src.cat?'cat':'short';
    ghost.innerHTML=`<button class="ffn-b k-${kind} on" tabindex="-1"${kind==='cat'?` style="--jt:${this.catTint(src.cat)}"`:''}><span class="ffn-g">${this.frame(kind)}<span class="ico">${kind==='cat'?this.iconHTML({path:ICONS[M.CATEGORIES[src.cat].icon]}):this.iconHTML(this.icon(src.slot))}</span></span></button><span class="tag">${esc(kind==='cat'?M.CATEGORIES[src.cat].name:this.info(src.slot).label)}</span>`;
    this.root.appendChild(ghost);
    this.drag={src,ghost,kind,x0:e.clientX,y0:e.clientY,moved:false,lx:e.clientX,target:null};
    if(src.from!=null){const it=this.mainItems.find(i=>i.pos===src.from);if(it)it.el.style.opacity='.25';}
    this.root.classList.add('dragging');
    const mv=ev=>this.moveDrag(ev),up=ev=>{this.doc.removeEventListener('pointermove',mv,true);this.doc.removeEventListener('pointerup',up,true);this.endDrag(ev);};
    this.drag.unlisten=()=>{this.doc.removeEventListener('pointermove',mv,true);this.doc.removeEventListener('pointerup',up,true);};
    this.doc.addEventListener('pointermove',mv,true);this.doc.addEventListener('pointerup',up,true);this.moveDrag(e);
    this.setPlaque('Placing',kind==='cat'?M.CATEGORIES[src.cat].name:this.info(src.slot).label,kind==='cat'?'Drop on another cardinal to swap':'Drop on a socket · off the ring removes');
  }
  moveDrag(e){
    const D=this.drag;if(!D)return;const {x,y,tokenR,R}=this.g,dx=e.clientX-x,dy=e.clientY-y,dist=Math.hypot(dx,dy),deg=wrap(Math.atan2(dx,-dy)/RAD);
    if(Math.hypot(e.clientX-D.x0,e.clientY-D.y0)>4)D.moved=true;
    const vx=e.clientX-D.lx;D.lx=e.clientX;D.ghost.style.translate=`${dx}px ${dy}px`;D.ghost.style.rotate=`${Math.max(-14,Math.min(14,vx*.9))}deg`;
    const pool=D.kind==='cat'?M.CARDINALS:M.SOCKETS;let tgt=null;
    if(dist>tokenR+8&&dist<R+70){let bd=1e9;for(const p of pool){const dd=Math.abs(adiff(deg,p*30));if(dd<bd){bd=dd;tgt=p;}}if(bd>26)tgt=null;}
    if(tgt===D.target&&D.seen)return;D.target=tgt;D.seen=true;
    this.mainItems.forEach(i=>i.el.classList.toggle('drop',i.pos===tgt));
    const glow=this.svg.querySelector('.dropglow');
    if(tgt!=null){glow.setAttribute('d',arcPath(R,tgt*30-11,tgt*30+11));glow.classList.add('on');}else glow.classList.remove('on');
    D.ghost.classList.toggle('bye',tgt==null&&D.src.from!=null&&(dist>R+70||dist<tokenR));
  }
  endDrag(e,cancel=false){
    const D=this.drag;if(!D)return;this.drag=null;D.unlisten?.();this.root.classList.remove('dragging');
    this.svg.querySelector('.dropglow').classList.remove('on');
    const S=this.cfg.shortcuts;let msg=null;
    if(!cancel&&!D.moved&&D.src.from!=null){D.ghost.remove();this.buildMain(true);const it=this.mainItems.find(i=>i.pos===D.src.from);if(it)this.editClick(it);return;}
    if(!cancel){
      if(D.kind==='cat'){if(D.target!=null&&D.target!==D.src.from){const o=this.order,a=o[D.src.from];o[D.src.from]=o[D.target];o[D.target]=a;}}
      else if(D.target!=null){
        if(D.src.from!=null){const here=S[D.target]??null;S[D.target]=D.src.slot;if(D.target!==D.src.from){if(here)S[D.src.from]=here;else delete S[D.src.from];}}
        else if(S[D.target]||this.shortcutCount()<M.MAX_SHORTCUTS){S[D.target]={action:D.src.slot.action,value:D.src.slot.value??null};msg='Placed';}
        else msg=`${M.MAX_SHORTCUTS} shortcuts at most · drop on one to replace it`;
      }else if(D.src.from!=null){const {x,y,tokenR,R}=this.g,dist=Math.hypot((e?.clientX??0)-x,(e?.clientY??0)-y);if(dist>R+70||dist<tokenR){delete S[D.src.from];msg='Removed';}}
    }
    D.ghost.classList.add('bye');setTimeout(()=>D.ghost.remove(),200);
    this.buildMain(true);this.markUsed();this.save();
    const placed=this.mainItems.find(i=>i.pos===D.target);
    if(placed&&!cancel&&!this.root.classList.contains('reduced'))placed.el.querySelector('.ffn-g')?.animate([{scale:1.35},{scale:.92},{scale:1}],{duration:280,easing:'cubic-bezier(.3,1.4,.5,1)'});
    const full=!!msg&&msg.includes('most');
    this.setPlaque('Edit the wheel',full?'Ring full':'Shortcuts',full?msg:`${msg?msg+' · ':''}${this.shortcutCount()}/${M.MAX_SHORTCUTS} placed`,{reason:full});
  }

  /* ------------------------------------------------------------ harness helper */
  /** Screen point of a named target (the recorder and tests point at these). */
  targetXY(t){
    const {x,y,tokenR,R,lastR}=this.root?this.g:this.geometry(),at=(deg,r)=>{const [px,py]=P(deg,r);return [x+px,y+py];},box=el=>{const b=el.getBoundingClientRect();return [b.x+b.width/2,b.y+b.height/2];};
    if(t==='centre')return [x,y];if(t==='last')return [x,y+lastR];if(t==='back')return [x,y-tokenR-5];
    if(t.startsWith('pos:'))return at(+t.slice(4)*30,R);
    if(t.startsWith('far:')){const [,a,r]=t.split(':');return at(+a,+r);}
    if(t.startsWith('cat:')){const i=this.mainItems.find(i=>i.cat===t.slice(4));return i?at(i.angle,R):null;}
    if(t.startsWith('item:')){const i=this.items.find(i=>i.key===t.slice(5));return i?at(i.angle,i.r):null;}
    if(t.startsWith('macro:'))return this.macroRing.targetXY(+t.slice(6));
    if(t.startsWith('btn:')){const b=this.plaque.querySelector(`[data-b="${t.slice(4)}"]`);return b?box(b):null;}
    if(t.startsWith('chip:')){const el=(this.list?.el??this.lib)?.querySelector(`.ffn-chip[data-key="${CSS.escape(t.slice(5))}"]`);if(!el)return null;el.scrollIntoView({block:'nearest'});return box(el);}
    if(t.startsWith('sec:')){const el=this.lib?.querySelector(`.ffn-sec[data-group="${t.slice(4)}"] .hd`);return el?box(el):null;}
    if(t.startsWith('sel:')){const el=this.root?.querySelector(t.slice(4));return el?box(el):null;}
    return null;
  }
}
