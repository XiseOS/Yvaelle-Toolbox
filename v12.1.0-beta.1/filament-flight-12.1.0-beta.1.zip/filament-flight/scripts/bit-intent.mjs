/** Sparse, deterministic idle gestures use the same synchronized visual clock
 * as the hardware. An assigned macro always owns attention ahead of idle work. */
import {boundedFocusLean} from './bit-episode-motion.mjs?v=12.1.0-beta.1';
export const BIT_INTENT_STYLES=Object.freeze({off:'Off',composed:'Composed · rare gestures',attentive:'Attentive · occasional gestures'});
const unit=n=>Math.max(0,Math.min(1,n)),smooth=n=>{n=unit(n);return n*n*(3-2*n);};
const NONE=Object.freeze({kind:null,amount:0,progress:0});
export function sampleBitIntent(flight,visual,side,index,center,angle=0){
  const cfg=flight?.gems??{},style=cfg.intent??'composed';
  const station=`${side<0?'left':'right'}${index?'Lower':'Upper'}`,assignments=flight.bitActionAssignments;
  const busy=flight.bitSequenceActive&&(!assignments||assignments.hidden?.includes(station)||(assignments.support?.[station]?.amount??0)>.01);
  if(style==='off'||!cfg.animated||!(cfg.strength>0)||visual?.animated===false||busy||
    (flight.bitDeployment??1)<.98||(flight.formation?.growth??1)<.98)return NONE;
  const clock=Number(visual?.time)||0,seed=Math.abs(Number(visual?.seed)||0)%997;
  const interval=style==='attentive'?19:57,duration=3.8,shift=seed/997*interval;
  const event=Math.floor((clock+shift)/interval),elapsed=(clock+shift)-event*interval;
  // Gestures occupy less than seven percent of Composed's timeline.
  if(elapsed<interval-duration)return NONE;
  const p=(elapsed-interval+duration)/duration,envelope=smooth(p/.26)*(1-smooth((p-.7)/.3));
  const kind=['target','inspect','exchange'][((event%3)+3)%3],chosen=((event%4)+4)%4;
  const bit=(side<0?0:2)+index;
  if(kind!=='exchange'&&bit!==chosen)return NONE;
  if(kind==='exchange'&&(side<0?0:1)!==((event%2)+2)%2)return NONE;
  let target;
  if(kind==='target'){
    target=flight.intentTarget;
    if(!Array.isArray(target)||target.length<2||!target.slice(0,2).every(Number.isFinite))return NONE;
  }else if(kind==='inspect'){
    const damage=Math.max(visual?.damage??0,visual?.variant?.condition==='damaged'?visual.variant.amount??0:0);
    if(damage<.12)return NONE;
    target=[side*117,index?119:-80];
  }else target=[center[0]-side*14,index?-155:195];
  const lean=boundedFocusLean(center,target,{rotation:angle,max:.42});
  return {kind,target:[...target],amount:envelope*cfg.strength,progress:p,turn:lean*envelope*cfg.strength,
    lean:kind==='inspect'?Math.sin(Math.PI*p)*3.5*cfg.strength:0};
}

/** A short packet crosses between a pair, never a permanent guide string.
 * There is at most one packet per side and no extra display object or texture. */
export function bitIntentCurrents(controllers,flight,side){
  if(flight.bitSequenceActive&&!flight.bitActionAssignments||flight.gems?.passiveEffects===false||!flight.gems?.glow||!(flight.gems.glowStrength>0))return [];
  const pair=controllers.filter(p=>p.hardware?.intent?.kind==='exchange'&&p.strength>.01);
  if(pair.length!==2)return [];
  const [a,b]=pair,intent=a.hardware.intent,p=intent.progress,amount=intent.amount;
  if(amount<.001)return [];
  const A=a.points[0],B=b.points[0],travel=smooth((p-.15)/.65),head=travel,tail=Math.max(0,head-.07);
  if(head<=0||head>=1)return [];
  const points=Array.from({length:8},(_,i)=>{
    const t=tail+(head-tail)*i/7,arc=Math.sin(Math.PI*t);
    return [A[0]+(B[0]-A[0])*t+side*arc*13,A[1]+(B[1]-A[1])*t,A[2]+(B[2]-A[2])*t,.92];
  });
  return [{id:'intent-exchange',points,width:.72,strength:.58*amount*Math.min(a.strength,b.strength)*flight.gems.glowStrength,highlight:true}];
}

const INTENT_NAMESPACE='filament-flight',INTENT_FLAG='intentTarget';
/** Resolve the controlling owner's shared selection, never the viewer's targets.
 * The flag carries IDs only; deleted, stale-scene and malformed targets resolve
 * to no attention target. Rendering remains read-only. */
/** v10 live attention: targets shared over the module socket are held here
 * and take priority over any value still saved on the token from 9.x. */
const LIVE_INTENT=new Map();
export function setLiveIntent(uuid,value){if(typeof uuid==='string')LIVE_INTENT.set(uuid,value??null);}
export function clearLiveIntent(){LIVE_INTENT.clear();}
export function readBitIntentTarget(document,canvas=globalThis.canvas){
  const live=document?.uuid!==undefined&&LIVE_INTENT.has(document.uuid)?LIVE_INTENT.get(document.uuid):undefined;
  const saved=live!==undefined?live:document?.getFlag?.(INTENT_NAMESPACE,INTENT_FLAG);
  if(!saved||saved.version!==1||typeof saved.userId!=='string'||saved.sceneId!==canvas?.scene?.id||
    document.parent?.id!==saved.sceneId||typeof saved.targetId!=='string'||saved.targetId===document.id)return null;
  const target=canvas?.tokens?.get?.(saved.targetId)??canvas?.tokens?.placeables?.find(t=>t.id===saved.targetId);
  if(!target||target.destroyed||target.document?.parent?.id!==saved.sceneId)return null;
  return target;
}

/** Event-only publication. Sources must be both controlled and owned locally.
 * A micro queue and a short debounce coalesce Foundry's untarget/target events;
 * no flight flag, settings, position, elevation or ticker writes are involved.
 * Inject publish to share the module's existing document-write queue. */
export class BitIntentTargets {
  constructor({game=()=>globalThis.game,canvas=()=>globalThis.canvas,hooks=globalThis.Hooks,
    publish=(doc,value)=>doc.setFlag(INTENT_NAMESPACE,INTENT_FLAG,value),report=error=>console.warn('Yvaelle’s Toolbox: could not share bit attention target.',error)}={}){
    this.game=game;this.canvas=canvas;this.hooks=hooks;this.publish=publish;this.report=report;
    this.sources=new Map();this.desired=new Map();this.pending=new Map();this.listeners=[];this.timer=null;
  }
  start(){
    if(this.listeners.length)return this;
    const listen=(name,fn)=>{const id=this.hooks?.on?.(name,fn);if(id!=null)this.listeners.push([name,id]);};
    listen('targetToken',user=>{if(user?.id===this.game()?.user?.id)this.schedule();});
    listen('controlToken',()=>this.schedule());
    this.schedule();return this;
  }
  schedule(){clearTimeout(this.timer);this.timer=setTimeout(()=>{this.timer=null;void this.flush();},80);}
  write(doc,value){
    const key=doc.uuid??`${doc.parent?.id}.${doc.id}`,encoded=JSON.stringify(value),previous=this.desired.get(key);
    if(previous?.encoded===encoded)return this.pending.get(key)??Promise.resolve();
    const wanted={encoded,value};this.desired.set(key,wanted);
    const task=(this.pending.get(key)??Promise.resolve()).catch(()=>{}).then(async()=>{
      if(this.desired.get(key)!==wanted||!doc.isOwner)return;
      const stored=LIVE_INTENT.has(doc.uuid)?LIVE_INTENT.get(doc.uuid):doc.getFlag?.(INTENT_NAMESPACE,INTENT_FLAG);
      // Releasing this user's controls must never erase another owner's claim.
      if(value===null&&stored?.userId&&stored.userId!==this.game()?.user?.id)return;
      if(JSON.stringify(stored??null)!==encoded)await this.publish(doc,value);
    }).catch(error=>{this.desired.delete(key);this.report(error);});
    this.pending.set(key,task);void task.finally(()=>{if(this.pending.get(key)===task)this.pending.delete(key);});return task;
  }
  async flush(){
    clearTimeout(this.timer);this.timer=null;
    const canvas=this.canvas(),user=this.game()?.user;if(!canvas?.ready||!user)return this.clear();
    const next=new Map(),tasks=[];
    const selected=[...(user.targets??[])].find(t=>t?.document?.parent?.id===canvas.scene?.id&&!t.destroyed);
    for(const token of canvas.tokens?.controlled??[]){
      const doc=token.document;if(!doc?.isOwner||doc.parent?.id!==canvas.scene?.id)continue;
      // Unrelated owned tokens never acquire a Yvaelle’s Toolbox attention flag.
      if(!doc.getFlag?.(INTENT_NAMESPACE,'flight'))continue;
      const key=doc.uuid??`${doc.parent.id}.${doc.id}`;next.set(key,doc);
      const targetId=selected?.id===doc.id?null:selected?.id;
      tasks.push(this.write(doc,targetId?{version:1,userId:user.id,sceneId:canvas.scene.id,targetId}:null));
    }
    for(const [key,doc] of this.sources)if(!next.has(key))tasks.push(this.write(doc,null));
    this.sources=next;await Promise.all(tasks);
  }
  async clear(){
    clearTimeout(this.timer);this.timer=null;
    const docs=[...this.sources.values()];this.sources.clear();
    await Promise.all(docs.map(doc=>this.write(doc,null)));
    for(const key of this.desired.keys())if(!this.pending.has(key))this.desired.delete(key);
  }
  stop(){
    for(const [name,id] of this.listeners)this.hooks?.off?.(name,id);this.listeners=[];
    return this.clear();
  }
}
