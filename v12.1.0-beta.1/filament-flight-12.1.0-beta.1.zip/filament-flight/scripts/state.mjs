import {DEFAULTS, options, FLOAT_STYLES} from './motion.mjs?v=12.1.0-beta.1';
import {conditionReactionSettings,readConditionResponse,sampleConditionResponse,applyWingCondition,conditionGroundsFlight,withoutV11Persistent} from './condition-response.mjs?v=12.1.0-beta.1';
import {SCHEMA_VERSION, VERSION, LIGHT_APPEARANCES, LANTERN_ARTWORKS, optionPatch} from './config.mjs?v=12.1.0-beta.1';
import {POSES, validatePose, readPoseTiming, samplePose, mixWeights, weightsFor} from './poses.mjs?v=12.1.0-beta.1';
import {CONDITIONS, validateCondition, readConditionTiming, readCue, CUE_SLOTS, resolveVisuals} from './conditions.mjs?v=12.1.0-beta.1';
import {readFormation,sampleFormation,movementVisual,transitionProgress,landingFlightProgress} from './flight-dynamics.mjs?v=12.1.0-beta.1';
import {isRecall} from './v12/landing-recall.mjs?v=12.1.0-beta.1';
import {resolveWingLight} from './light-model.mjs?v=12.1.0-beta.1';
import {EFFECT_STYLES,validateEffectStyle,effectStylePatch} from './effect-styles.mjs?v=12.1.0-beta.1';
import {stylePatch,tuningPatch,effectCatalog} from './effect-catalog.mjs?v=12.1.0-beta.1';
import {poseMotionPatch,gemMotionPatch,resolvePoseMotion,resolveGemMotion,GEM_MOTION_FIELDS} from './wing-controls.mjs?v=12.1.0-beta.1';
import {readBitTransition,sampleBitDeployment,readBitCountTransition,sampleBitCount,bitTarget} from './bit-deployment.mjs?v=12.1.0-beta.1';
import {qualityProfile,qualityConfiguration} from './quality.mjs?v=12.1.0-beta.1';
import {ENERGY_STRUCTURES,validateStructure,readSavedStructure,sampleStructure} from './energy-structures.mjs?v=12.1.0-beta.1';
import {STRUCTURE_POSES,STRUCTURE_SIZE_RANGE,structurePosePatch,readSavedStructurePoses,readStructurePoseTransition,structurePoseSettings} from './structure-poses.mjs?v=12.1.0-beta.1';
import {STEADY_MODES,FLIGHT_PROFILES,readModeTransition,sampleFlightProfile,targetFlightProfile} from './flight-profiles.mjs?v=12.1.0-beta.1';
import {BIT_EXPRESSION_SITUATIONS,BIT_EXPRESSION_STYLES} from './bit-expression.mjs?v=12.1.0-beta.1';
import {normalizeLantern,lanternPatch} from './lantern-model.mjs?v=12.1.0-beta.1';
import {normalizeV7Preferences,validateV7Patch,sampleV7Appearance} from './v7-ensemble.mjs?v=12.1.0-beta.1';
import {v7WingRigRequired} from './v7-wing-material.mjs?v=12.1.0-beta.1';
import {actorConditionWingRate,actorConditionMotionArrest} from './condition-wing-motion.mjs?v=12.1.0-beta.1';
import {readSavedWingForm} from './wing-forms.mjs?v=12.1.0-beta.1';
import {resolveManoeuvre} from './flight-manoeuvres.mjs?v=12.1.0-beta.1';

export const MODES = Object.freeze([...STEADY_MODES,'takeoff','landing']);
const STEADY = STEADY_MODES;
const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const unit = (x, fallback=1) => Number.isFinite(x) ? clamp(x,0,1) : fallback;

export function capabilities() {
  return {
    version:VERSION, schemaVersion:SCHEMA_VERSION, renderer:'hybrid', renderers:['auto','rig','atlas'],
    structures:{...ENERGY_STRUCTURES},structurePoses:STRUCTURE_POSES,structureSize:{...STRUCTURE_SIZE_RANGE},modes:[...MODES], poses:[...POSES], conditions:[...CONDITIONS],effectStyles:[...EFFECT_STYLES],effectCatalog:effectCatalog(),
    bitExpressions:{situations:{...BIT_EXPRESSION_SITUATIONS},styles:{...BIT_EXPRESSION_STYLES}},
    lightAppearances:{...LIGHT_APPEARANCES},
    lanternArtworks:{...LANTERN_ARTWORKS},
    v7:{preferences:['enabled','gemInteriors','gemStrength','filamentTexture','filamentStrength','refraction','refractionStrength','wingAnimations','formations','medkit','seamlessActions','transitionVariants']},
    features:{targetedAPI:true, persistentState:true, liveSettings:true, timedTakeoffLanding:true,
      expressiveBits:true,selectedBitRecall:true,persistentBitRestingPositions:true,directionalBitLantern:true,mouseLanternAim:true,optionalFlightKeybind:true,animatedLightAppearance:true,lightVisualReactions:true,lanternArtwork:true,wingStabilizerLantern:true,groundStabilizerLantern:true,
      foregroundWings:true, advancedPoses:true, temporaryPoses:true, persistentPoseTransitions:true,
      actorConditionReactions:true,unconsciousRecovery:true,hpReactions:true, glitching:true, damageReactions:true, healingReactions:true, temporaryConditions:true,
      trails:true, movementWings:true, takeoffFormation:true, landingFolding:true,controlHUD:true,enhancedConditions:true,wingLight:true,
      conditionEffectStyles:true,tokenLightRadii:true,reactionEffectStyles:true,effectTuning:true,reactionPreview:true,
      smoothPoseMotion:true,gemChoreography:true,wingMotionControls:true,
      wingAudio:true,audioHUD:true,positionalAudio:true,privateAudioPreview:true,
      articulatedBits:true,animatedStabilizationFields:true,bitsToggle:true,flightModeBlending:true,portableLooks:true,personalLooks:true,lookUndo:true,freeBitPlacement:true,independentBitDeployment:true,modeIdleMotion:true,structureSizing:true,bitIntent:true,independentCompactBits:true,bitCounts:true,compactBitFormations:true,observerQuality:true,independentWings:true,remoteBitFormations:true,bitPersonality:true,hardlightMedicine:true,individualBitControl:true,multiGroupBits:true,tokenEffects:true,coreStates:true,nativeAnimationLibrary:true,formationTransitions:true,treatmentBorrowing:true},
    stabilizerPrograms:[...GEM_MOTION_FIELDS.program],stabilizationFields:[...GEM_MOTION_FIELDS.fieldStyle],
    optionKeys:Object.keys(DEFAULTS),floatStyles:{...FLOAT_STYLES},flightModes:Object.fromEntries(Object.entries(FLIGHT_PROFILES).map(([id,v])=>[id,{label:v.label,description:v.description}]))
  };
}

/** Normalize in memory. Reading old token flags never writes to a document. */
export function normalizeFlag(raw, now) {
  if (raw != null && (typeof raw !== 'object' || Array.isArray(raw))) throw new Error('Invalid saved flight state.');
  const schema = raw?.schemaVersion;
  if (schema != null && schema !== SCHEMA_VERSION) throw new Error(`Unsupported flight state schema ${schema}; update Yvaelle’s Toolbox before editing this token.`);
  const enabled = !!raw?.enabled;
  if(raw?.bitsDeployed!=null&&typeof raw.bitsDeployed!=='boolean')throw new Error('Bits deployment must be true or false.');
  if(raw?.airborne!=null&&typeof raw.airborne!=='boolean')throw new Error('Airborne state must be true or false.');
  const mode = raw?.mode ?? (enabled ? 'hover' : 'grounded');
  if (!STEADY.includes(mode)) throw new Error(`Unsupported saved flight mode: ${mode}.`);
  const pose = raw?.pose ?? 'neutral', condition = raw?.condition ?? 'normal';
  if (!POSES.includes(pose) || !CONDITIONS.includes(condition)) throw new Error('Unrecognized saved wing pose or condition.');
  const conditionSource=raw?.conditionSource??(condition==='normal'?'auto':'manual');
  if (!['auto','manual'].includes(conditionSource)) throw new Error('Invalid saved condition source.');
  if (raw?.autoHP!=null&&typeof raw.autoHP!=='boolean')throw new Error('Invalid saved HP reaction preference.');
  if (raw?.glitchIntensity!=null&&(!Number.isFinite(raw.glitchIntensity)||raw.glitchIntensity<0||raw.glitchIntensity>1))throw new Error('Invalid saved glitch intensity.');
  if(raw?.trailIntensity!=null&&(!Number.isFinite(raw.trailIntensity)||raw.trailIntensity<0||raw.trailIntensity>1))throw new Error('Invalid saved trail intensity.');
  if(raw?.movementReactions!=null&&typeof raw.movementReactions!=='boolean')throw new Error('Invalid saved movement preference.');
  if(raw?.lightEnabled!=null&&typeof raw.lightEnabled!=='boolean')throw new Error('Invalid saved wing light preference.');
  if(raw?.lightWithBits!=null&&typeof raw.lightWithBits!=='boolean')throw new Error('Invalid saved bit light preference.');
  if(raw?.lightAppearance!=null&&(typeof raw.lightAppearance!=='string'||!Object.hasOwn(LIGHT_APPEARANCES,raw.lightAppearance)))throw new Error('Invalid saved light appearance.');
  if(raw?.lanternArtwork!=null&&(typeof raw.lanternArtwork!=='string'||!Object.hasOwn(LANTERN_ARTWORKS,raw.lanternArtwork)))throw new Error('Invalid saved lantern artwork.');
  if(raw?.lightVisualReactions!=null&&typeof raw.lightVisualReactions!=='boolean')throw new Error('Invalid saved light appearance reactions.');
  if(raw?.lightIntensity!=null&&(!Number.isFinite(raw.lightIntensity)||raw.lightIntensity<0||raw.lightIntensity>1))throw new Error('Invalid saved wing light intensity.');
  for(const key of ['lightBright','lightDim'])if(raw?.[key]!=null&&(!Number.isFinite(raw[key])||raw[key]<0||raw[key]>120))throw new Error('Invalid saved wing light radius.');
  const effectStyle=validateEffectStyle(raw?.effectStyle??null),effectStyles=effectStylePatch(raw?.effectStyles??{});
  const reactionStyles=stylePatch(raw?.reactionStyles??{},'reaction'),effectTuning=tuningPatch(raw?.effectTuning??{}),reactionTuning=tuningPatch(raw?.reactionTuning??{},'reaction');
  let transition = null;
  const t = raw?.transition;
  if (t != null) {
    if (!t || typeof t !== 'object' || !['takeoff','landing'].includes(t.kind)
      || typeof t.id !== 'string' || !/^[\w-]{1,64}$/.test(t.id)
      || !Number.isFinite(t.started) || !Number.isFinite(t.duration) || t.duration < 0 || t.duration > 10000
      || !['fromBlend','toBlend','fromFlight','toFlight'].every(k => Number.isFinite(t[k]) && t[k] >= 0 && t[k] <= 1))
      throw new Error('Invalid saved flight transition.');
    transition = Object.fromEntries(['id','kind','started','duration','fromBlend','toBlend','fromFlight','toFlight'].map(k => [k,t[k]]));
    if(t.wings!=null)transition.wings=readFormation(t.wings);
    // (beta.29: a landing lengthened for her descent plays its fold in the last foldMs.)
    if(Number.isFinite(t.foldMs)&&t.foldMs>0&&t.foldMs<t.duration)transition.foldMs=t.foldMs;
    // (12.0.0-beta.3: a landing style: the recall her wings play after the descent, and the descent's own clock)
    if(t.kind==='landing'&&isRecall(t.recall)){transition.recall=t.recall;
      if(Number.isFinite(t.descentMs)&&t.descentMs>0&&t.descentMs<t.duration&&Number.isFinite(t.flightMs)&&t.flightMs>0&&t.flightMs<=t.descentMs){transition.descentMs=t.descentMs;transition.flightMs=t.flightMs;}}
    if(t.wingsOnly!=null){if(typeof t.wingsOnly!=='boolean')throw new Error('Invalid wing-only transition.');transition.wingsOnly=t.wingsOnly;}
  }
  return {
    schemaVersion:SCHEMA_VERSION, legacy:!!raw && schema == null, enabled,airborne:raw?.airborne??(enabled&&mode!=='grounded'),bitsDeployed:raw?.bitsDeployed??false,observerQuality:qualityProfile(raw?.observerQuality??{},{owner:true,strict:false}),
    started:Number.isFinite(raw?.started) ? raw.started : now,
    mode, pose, wingForm:readSavedWingForm(raw?.wingForm),structure:readSavedStructure(raw?.structure),structureTransition:null,structurePoses:readSavedStructurePoses(raw?.structurePoses),structurePoseTransition:raw?.structure&&raw.structure!=='wings'?null:readStructurePoseTransition(raw?.structurePoseTransition), condition, conditionSource,autoHP:raw?.autoHP??null,glitchIntensity:raw?.glitchIntensity??null,intensity:unit(raw?.intensity),
    conditionReactions:conditionReactionSettings(raw?.conditionReactions??{}),conditionResponse:readConditionResponse(raw?.conditionResponse),
    trailIntensity:raw?.trailIntensity??null,movementReactions:raw?.movementReactions??null,
    lightEnabled:raw?.lightEnabled??null,lightWithBits:raw?.lightWithBits??false,lightIntensity:raw?.lightIntensity??null,
    lightBright:raw?.lightBright??null,lightDim:raw?.lightDim??null,lightAppearance:raw?.lightAppearance??null,lightVisualReactions:raw?.lightVisualReactions??null,lanternArtwork:raw?.lanternArtwork??null,lantern:normalizeLantern(raw?.lantern),effectStyle,effectStyles,reactionStyles,effectTuning,reactionTuning,
    poseMotion:poseMotionPatch(raw?.poseMotion??{}),gemMotion:gemMotionPatch(raw?.gemMotion??{}),v7:normalizeV7Preferences(raw?.v7),
    options:options(raw?.options), inheritDefaults:raw == null || raw.inheritDefaults === true,
    optionOverrides:optionPatch(raw?.optionOverrides ?? {}, {strict:false,allowNull:true}),
    transition,bitCountTransition:readBitCountTransition(raw?.bitCountTransition),bitTransition:readBitTransition(raw?.bitTransition),modeTransition:readModeTransition(raw?.modeTransition),poseTransition:readPoseTiming(raw?.poseTransition), temporaryPose:readPoseTiming(raw?.temporaryPose,true),
    conditionTransition:readConditionTiming(raw?.conditionTransition),
    temporaryCondition:readConditionTiming(raw?.temporaryCondition,'temporary'),
    hpTransition:readConditionTiming(raw?.hpTransition,'health'),
    cues:Object.fromEntries(CUE_SLOTS.map(k=>[k,readCue(raw?.cues?.[k])]))
  };
}

export function validateStatePatch(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('State must be an object.');
  const out = {};
  for (const [key,value] of Object.entries(input)) {
    if(key==='v7')out.v7=validateV7Patch(value);
    else if(key==='lantern')out.lantern=lanternPatch(value);
    else if(key==='observerQuality')out.observerQuality=qualityProfile(value);
    else if(key==='bitsDeployed'){if(typeof value!=='boolean')throw new Error('Bits deployment must be true or false.');out.bitsDeployed=value;}
    else if(key==='lightWithBits'){if(typeof value!=='boolean')throw new Error('Bit light preference must be true or false.');out.lightWithBits=value;}
    else if(key==='lightAppearance'){if(value!==null&&(typeof value!=='string'||!Object.hasOwn(LIGHT_APPEARANCES,value)))throw new Error('Light appearance must be animated, current or null.');out.lightAppearance=value;}
    else if(key==='lanternArtwork'){if(value!==null&&(typeof value!=='string'||!Object.hasOwn(LANTERN_ARTWORKS,value)))throw new Error('Lantern artwork must be flow, veil, plain, prior or null.');out.lanternArtwork=value;}
    else if (key === 'mode') {
      if (!MODES.includes(value)) throw new Error(`Unknown mode ${value}. Use ${MODES.join(', ')}.`);
      out.mode = value;
    } else if (key === 'intensity') {
      if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('Intensity must be a finite number.');
      out.intensity = clamp(value,0,1);
    } else if (key === 'options') out.options = optionPatch(value, {allowNull:true});
    else if (key === 'pose') out.pose=validatePose(value);
    else if (key === 'structure') out.structure=validateStructure(value);
    else if (key === 'structurePoses') out.structurePoses=structurePosePatch(value);
    else if (key === 'condition') {
      out.condition=value==='auto'?'auto':validateCondition(value);
    } else if(key==='glitchIntensity') {
      if(value!==null&&!Number.isFinite(value))throw new Error('Glitch intensity must be a finite number or null.');
      out.glitchIntensity=value===null?null:clamp(value,0,1);
    } else if(key==='autoHP'||key==='movementReactions'||key==='lightEnabled'||key==='lightVisualReactions') {
      if(value!==null&&typeof value!=='boolean')throw new Error(`${key} must be true, false or null.`);
      out[key]=value;
    } else if(key==='trailIntensity'||key==='lightIntensity') {
      if(value!==null&&!Number.isFinite(value))throw new Error(`${key==='lightIntensity'?'Light':'Trail'} intensity must be a finite number or null.`);
      out[key]=value===null?null:clamp(value,0,1);
    } else if(key==='lightBright'||key==='lightDim') {
      if(value!==null&&!Number.isFinite(value))throw new Error('Light radius must be a finite number or null.');
      out[key]=value===null?null:clamp(value,0,120);
    } else if(key==='effectStyle')out[key]=validateEffectStyle(value);
    else if(key==='effectStyles')out[key]=effectStylePatch(value);
    else if(key==='reactionStyles')out[key]=stylePatch(value,'reaction');
    else if(key==='effectTuning'||key==='reactionTuning')out[key]=tuningPatch(value,key==='reactionTuning'?'reaction':'condition');
    else if(key==='poseMotion')out[key]=poseMotionPatch(value);
    else if(key==='gemMotion')out[key]=gemMotionPatch(value);
    else throw new Error(`Unsupported state field: ${key}. See flight.getCapabilities().`);
  }
  if (!Object.keys(out).length) throw new Error('Provide at least one state field.');
  return out;
}

export function appearance(data, config,flightProfile=targetFlightProfile(data.mode,config)) {
  const base = data.inheritDefaults ? config.defaults : data.options;
  const resolved = {...base};
  for (const [key,value] of Object.entries(data.optionOverrides)) resolved[key] = value === null ? config.defaults[key] : value;
  const result = options(resolved);
  result.shadow = result.shadow && config.shadows;
  if (!config.hover) result.hoverHeight = 0;
  if(!config.bobbing)result.bobHeight=0;
  if(!config.hover||config.reduced){result.bobHeight=0;result.floatSway=0;}
  if (!config.banking || config.reduced) result.tiltDegrees = 0;
  result.wingSpeed=Math.min(9,result.wingSpeed*flightProfile.beat);
  result.hoverHeight*=flightProfile.lift;
  return result;
}

// Internal render snapshots reuse normalized preferences. Public calls return
// defensive copies; compare only the inputs which produce cached preferences.
// Nested edits remain visible without treating caller-owned objects as frozen.
const renderPreferences=new WeakMap();
const requestedKeys=Object.freeze(['bitsDeployed','mode','pose','structurePoses','condition','conditionSource','conditionReactions','autoHP','glitchIntensity','intensity','trailIntensity','movementReactions','lightEnabled','lightWithBits','lightIntensity','lightBright','lightDim','lightAppearance','lightVisualReactions','lanternArtwork','lantern','effectStyle','effectStyles','reactionStyles','effectTuning','reactionTuning','poseMotion','gemMotion','v7','inheritDefaults','options','optionOverrides']);
const preferenceSnapshot=input=>{const keys=Object.keys(input??{});return {input,keys,values:keys.map(key=>input[key])};};
function preferenceUnchanged(input,record){
  if(input!==record.input)return false;const keys=Object.keys(input??{});if(keys.length!==record.keys.length)return false;
  for(let i=0;i<keys.length;i++){const key=keys[i],value=input[key],before=record.values[i];if(key!==record.keys[i]||value!==before&&!Object.is(value,before))return false;}
  return true;
}
function preferenceInputs(data,config){return {root:requestedKeys.map(key=>data[key]),pose:preferenceSnapshot(data.poseMotion),gems:preferenceSnapshot(data.gemMotion),
  expressions:preferenceSnapshot(data.gemMotion?.expressionModes),options:preferenceSnapshot(data.options),overrides:preferenceSnapshot(data.optionOverrides),defaults:preferenceSnapshot(config.defaults)};}
function preferenceInputsUnchanged(data,config,saved){
  for(let i=0;i<requestedKeys.length;i++)if(!Object.is(data[requestedKeys[i]],saved.root[i]))return false;
  return preferenceUnchanged(data.poseMotion,saved.pose)&&preferenceUnchanged(data.gemMotion,saved.gems)&&
    preferenceUnchanged(data.gemMotion?.expressionModes,saved.expressions)&&preferenceUnchanged(data.options,saved.options)&&
    preferenceUnchanged(data.optionOverrides,saved.overrides)&&preferenceUnchanged(config.defaults,saved.defaults);
}
function preferences(data,config){
  let configs=renderPreferences.get(data);if(!configs)renderPreferences.set(data,configs=new WeakMap());
  const saved=configs.get(config);if(saved&&preferenceInputsUnchanged(data,config,saved.inputs))return saved.value;
  let value;
  const requested={bitsDeployed:data.bitsDeployed,mode:data.mode,pose:data.pose,structure:'wings',structurePoses:data.structurePoses,condition:data.condition,conditionSource:data.conditionSource,
    conditionReactions:data.conditionReactions,autoHP:data.autoHP,glitchIntensity:data.glitchIntensity,intensity:data.intensity,
    trailIntensity:data.trailIntensity,movementReactions:data.movementReactions,lightEnabled:data.lightEnabled,lightWithBits:data.lightWithBits,lightIntensity:data.lightIntensity,
    lightBright:data.lightBright,lightDim:data.lightDim,lightAppearance:data.lightAppearance,lightVisualReactions:data.lightVisualReactions,lanternArtwork:data.lanternArtwork,lantern:data.lantern,effectStyle:data.effectStyle,effectStyles:data.effectStyles,reactionStyles:data.reactionStyles,
    effectTuning:data.effectTuning,reactionTuning:data.reactionTuning,poseMotion:data.poseMotion,gemMotion:data.gemMotion,v7:data.v7};
  value={requested,poseMotion:resolvePoseMotion(data,config),gems:resolveGemMotion(data,config),
    appearance:appearance(data,config,{beat:1,lift:1})};configs.set(config,{value,inputs:preferenceInputs(data,config)});return value;
}
const sameEvent=(a,b)=>a===b||!!a&&!!b&&a.id===b.id&&a.started===b.started;
export function resolveState(data,config,now,context={}){
  return structuredClone(resolveRenderState(data,config,now,context));
}
export function resolveRenderState(data, config, now, context={}) {
  config=qualityConfiguration(config,data,context.viewerId??globalThis.game?.user?.id);
  const prefs=preferences(data,config);
  let v7=sampleV7Appearance(data.v7,config,now);
  // The runtime hands back the raw saved event once it is persisted: that is
  // the event data already holds (normalized). Copy data only for a newer one.
  if(context.hpTransition&&(context.hpTransition.pending||!sameEvent(context.hpTransition,data.hpTransition)))data={...data,hpTransition:context.hpTransition};
  if(context.conditionResponse&&!sameEvent(context.conditionResponse,data.conditionResponse))data={...data,conditionResponse:context.conditionResponse};
  // v11: the v10 persistent-damage art steps aside where v11 persistent damage draws the type
  const conditionResponse=withoutV11Persistent(sampleConditionResponse(data,context.actorConditions??{},now,{reduced:config.reduced,health:context.health,config}),context.v11Persist??null);
  const recoveryGrounded=conditionGroundsFlight(data,conditionResponse);
  let blend = data.enabled ? 1 : 0;
  let flightFactor = (data.airborne??data.enabled)&&data.mode!=='grounded' ? 1 : 0;
  let activeTransition = false, progress = 1;
  const t = data.transition;
  // A saved ON/OFF state is already the committed destination. On first load
  // it must not wait for an old takeoff/landing timestamp or clock correction.
  const settledTransition=!!t&&context.resumeFlightTransition===false;
  if (t) {
    progress = settledTransition || !config.transitions || t.duration === 0 ? 1 : transitionProgress(t,now);
    activeTransition = progress < 1;
    const eased = progress*progress*(3-2*progress);
    blend = t.fromBlend + (t.toBlend-t.fromBlend)*eased;
    const fp=t.recall&&progress<1?landingFlightProgress(t,now):progress,flightEased=fp*fp*(3-2*fp);
    flightFactor = t.fromFlight + (t.toFlight-t.fromFlight)*flightEased;
  }
  const unsupported = [];
  const arrest=actorConditionMotionArrest(conditionResponse);
  const heldWingTime=conditionResponse.motionHeld??(data.conditionResponse?.started??data.started)+450;
  const visualSampleTime=arrest>=.999&&config.visualConditions!==false?Math.min(now,heldWingTime):now;
  // Injury remains live while art motion is held. A later HP event cannot
  // wait forever at its old healthy origin on the arrested wing clock.
  const visualContext=visualSampleTime<now?{...context,resumeHPTransition:false}:context;
  const visual=applyWingCondition(resolveVisuals(data,context.health??null,config,visualSampleTime,context.seed,visualContext),conditionResponse,data,config);
  const conditionMotionFrozen=visual.profile.conditionMotionFrozen===true;
  const wingSampleTime=conditionMotionFrozen?Math.min(now,heldWingTime):now;
  if(conditionMotionFrozen)v7=sampleV7Appearance(data.v7,config,wingSampleTime);
  if(conditionResponse.collapse.phase!=='awake'&&(conditionResponse.wings||conditionResponse.bits))flightFactor*=1-conditionResponse.collapse.mix;
  if(recoveryGrounded)flightFactor=0;
  if(config.collapseLowersToken)flightFactor*=1-(visual.semanticProfile?.collapse??visual.profile.collapse);
  const poseMotion=prefs.poseMotion,requestedGems=prefs.gems;
  // (12.1.0-beta.1) Wingless mode (v11): her wings are away for good. Before, the switch only moved her moments to her
  // token's frame and left the wings drawn. She still flies, hovers and keeps her bits (drawn in close, as whenever her wings are away); only the wings are not shown.
  const wingless=context.wingless===true,wingsActive=(data.enabled||activeTransition)&&!wingless;
  const deployment=sampleBitDeployment(activeTransition&&!data.enabled?{...data,enabled:true}:data,config,now,context.resumeBitTransition);
  const bitCount=sampleBitCount(data,config,now,context.resumeBitCountTransition);
  // A wing-only command cannot summon additional powerless instruments or
  // retract those already resting on the map. Their episode owns visibility.
  const unpoweredBits=conditionResponse.bits&&['falling','fallen'].includes(conditionResponse.collapse.phase);
  if(unpoweredBits&&conditionResponse.collapse.id){
    deployment.value=conditionResponse.collapse.bits.length?1:0;deployment.transition=null;
    bitCount.values=['leftUpper','rightUpper','leftLower','rightLower'].map(id=>conditionResponse.collapse.bits.includes(id)?1:0);bitCount.transition=null;
  }
  const compactBits=!!(!wingsActive&&(data.bitsDeployed||deployment.value>0||deployment.transition?.active));
  visual.profile.effectDetail=config.effectDetail;
  // Keep the physical renderer alive while an OFF command retracts the bits.
  const retracting=deployment.value>0&&!requestedGems.enabled&&config.controlGems!==false&&config.wingRenderer!=='atlas';
  const renderGems=retracting?resolveGemMotion({...data,gemMotion:{...data.gemMotion,enabled:true,
    style:data.gemMotion.style==='hidden'?null:data.gemMotion.style}},config):requestedGems;
  const gems={...renderGems,v7,enabled:requestedGems.enabled,requestedEnabled:requestedGems.enabled,
    rigRequired:renderGems.rigRequired||renderGems.supported&&!!(deployment.transition?.active||bitCount.transition?.active)};
  if(conditionResponse.bits&&conditionResponse.collapse.mix>0){
    gems.glowStrength=(gems.glowStrength??.4)*(1-conditionResponse.collapse.mix);
    if(conditionResponse.collapse.phase==='fallen'){gems.animated=false;gems.stationMotion=false;gems.passiveEffects=false;}
  }
  const sampled=samplePose(data,wingSampleTime,poseMotion.enabled,config.temporaryPoses,context.resumePoseTransition);
  const posesEnabled=config.advancedPoses && config.wingRenderer!=='atlas' && config.poseStrength>0;
  let weights=mixWeights(weightsFor('neutral'),sampled.weights,posesEnabled?config.poseStrength:0);
  let tipWeights=mixWeights(weightsFor('neutral'),sampled.tipWeights,posesEnabled?config.poseStrength:0);
  const formation=sampleFormation(settledTransition?{...data,transition:{...t,duration:0}}:data,config,wingSampleTime);
  const structureAnimation={...sampleStructure(data,wingSampleTime,config.transitions&&!config.reduced,context.resumeStructureTransition,context.resumeStructurePoseTransition),animated:!config.reduced&&config.wingbeats!==false};
  const flightProfile=sampleFlightProfile(data,config,now,context.resumeModeTransition);
  let movement=movementVisual(data,config,conditionMotionFrozen?null:context.movement,flightFactor,formation,visual.profile,flightProfile);
  // Flight manoeuvres (local, visual only): additive, capped pose blend, rig roll and beat rate.
  // The sampler already gates (and eases) its input by the flight factor; a
  // second raw factor here snapped the roll to zero on an instant grounding.
  const manoeuvre=resolveManoeuvre(context.manoeuvre,{config,airborne:(1-formation.fold)*formation.growth,arrest,
    collapse:conditionResponse.collapse.phase!=='awake'?conditionResponse.collapse.mix:0,frozen:conditionMotionFrozen,posesEnabled,weights,tipWeights,
    condition:visual.condition,transition:t,progress,transitionActive:activeTransition});
  if(manoeuvre){
    weights=manoeuvre.weights;tipWeights=manoeuvre.tipWeights;
    if(movement.sweep>0&&config.wingBanking&&manoeuvre.asymmetry)movement={...movement,bank:Math.max(-1,Math.min(1,movement.bank+manoeuvre.asymmetry*Math.min(1,movement.sweep*4)))};
  }
  const renderer=config.wingRenderer==='rig' || (config.wingRenderer!=='atlas' &&
    (v7WingRigRequired(v7)||structureAnimation.rigRequired||gems.rigRequired||(posesEnabled && Math.min(weights[0],tipWeights[0])<0.999999)||visual.rigMix>0.000001||!config.energyPulses||formation.rigMix>0||movement.sweep>0.00001||(movement.trailEnabled&&movement.moving))) ? 'rig':'atlas';
  const flightActive=!recoveryGrounded&&!!((data.airborne??data.enabled)&&data.mode!=='grounded'||activeTransition&&(t.fromFlight>0||t.toFlight>0));
  const active = wingsActive||deployment.value>0||flightActive;
  // The existing wing clock integrates rate changes, so these reactions slow
  // and recover without rescaling elapsed time or restarting the beat phase.
  const conditionWingRate=actorConditionWingRate(conditionResponse);
  return {
    schemaVersion:SCHEMA_VERSION, legacy:data.legacy, enabled:data.enabled,airborne:recoveryGrounded?false:data.airborne,bitsDeployed:data.bitsDeployed,compactBits,bitCount,bitDeploymentTarget:bitTarget(data,config),observerQuality:data.observerQuality,quality:config.quality,
    requested:prefs.requested,v7,v9:{signatureCraft:config.v9SignatureCraft===true,medicalCraft:config.v9MedicalCraft===true},conditionResponse,lightAppearance:data.lightAppearance??config.lightAppearance??'animated',lightVisualReactions:data.lightVisualReactions??config.lightVisualReactions??true,lanternArtwork:data.lanternArtwork??config.lanternArtwork??'flow',
    structureAnimation,structureTransition:data.structureTransition,structurePoseTransition:data.structurePoseTransition,intentTarget:context.intentTarget??null,
    effective:{structure:'wings',structurePose:config.wingRenderer==='atlas'?'neutral':structurePoseSettings(data).pose,structureSize:config.wingRenderer==='atlas'?1:structureAnimation.poseSamples.wings.size,mode:recoveryGrounded?'grounded':activeTransition&&!t.wingsOnly ? t.kind : flightActive ? data.mode : 'grounded', pose:posesEnabled?sampled.pose:'neutral',condition:visual.condition,
      glitchIntensity:config.filamentGlitches&&!config.reduced?Math.min(config.glitchLimit,
        visual.profile.variant?visual.semanticProfile.glitch:visual.profile.glitch):0,autoHP:visual.autoHP,
      intensity:Math.min(data.intensity,config.intensityLimit), renderingEnabled:config.enabled,
      reducedMotion:config.reduced},
    options:{...prefs.appearance,wingSpeed:Math.min(9,prefs.appearance.wingSpeed*flightProfile.beat*conditionWingRate*(manoeuvre?.beatScale??1)),hoverHeight:prefs.appearance.hoverHeight*flightProfile.lift}, optionOverrides:data.optionOverrides,flightProfile,modeTransition:data.modeTransition,
    transition:t ? {...t,progress,active:activeTransition} : null,
    poseTransition:data.poseTransition,
    temporaryPose:data.temporaryPose?{...data.temporaryPose,active:sampled.overrideActive}:null,
    poseAnimation:{...sampled,weights,tipWeights},poseMotion,gems,bitDeployment:deployment.value,bitTransition:deployment.transition,
    visual,
    formation,movement,manoeuvre:manoeuvre?{bank:manoeuvre.bank,flare:manoeuvre.flare,lagRotation:manoeuvre.lagRotation,raise:manoeuvre.raise,beatScale:manoeuvre.beatScale,rotation:manoeuvre.rotation,width:manoeuvre.width}:null,light:resolveWingLight(data,config,wingsActive,visual,formation),lantern:{...data.lantern},
    health:{available:!!context.health,automaticCondition:visual.automaticCondition,incapacitated:visual.incapacitated},
    temporaryCondition:data.temporaryCondition?{...data.temporaryCondition,from:{...data.temporaryCondition.from},active:visual.overrideActive}:null,
    conditionTransition:data.conditionTransition?{...data.conditionTransition,from:{...data.conditionTransition.from}}:null,
    hpTransition:data.hpTransition?{...data.hpTransition,from:{...data.hpTransition.from}}:null,
    cues:Object.fromEntries(CUE_SLOTS.map(k=>[k,data.cues[k]?{...data.cues[k],active:now>=data.cues[k].started&&now<data.cues[k].started+data.cues[k].duration}:null])),
    rendering:{active:config.enabled && active,wingsActive:config.enabled&&wingsActive,wingless,flightActive:config.enabled&&flightActive, blend, flightFactor:flightActive?flightFactor:0, forceBlend:t ? blend : null, renderer,
      foreground:config.foregroundWings && renderer==='rig'},
    started:data.started, unsupported
  };
}
