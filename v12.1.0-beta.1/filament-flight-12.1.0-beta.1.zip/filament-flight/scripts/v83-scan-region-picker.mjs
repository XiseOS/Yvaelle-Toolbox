import {screenToWorld,worldToScreen,viewerSeesPoint,listenRightClick} from './v8-tool-preview.mjs?v=12.1.0-beta.1';
import {scanPointInPolygon,scanPolygonBounds,scanSceneContext} from './v82-scene-scan-context.mjs?v=12.1.0-beta.1';
import {toolRegion} from './v8-tool-model.mjs?v=12.1.0-beta.1';

const MAX_VERTICES=64;
const finite=p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y);
const surface=()=>globalThis.canvas?.app?.canvas??globalThis.canvas?.app?.view??globalThis.canvas?.renderer?.view;
const rendererScreen=el=>globalThis.canvas?.app?.renderer?.screen??globalThis.canvas?.app?.screen??{width:el.clientWidth,height:el.clientHeight};
const copy=points=>points.map(p=>({x:p.x,y:p.y}));
export function scanRegionDistanceFeet(scene={}){const units=String(scene.grid?.units??'ft').trim().toLowerCase(),distance=Math.max(.01,scene.grid?.distance??5);return /^(m|meter|meters|metre|metres)$/.test(units)?distance/.3048:distance;}
const labels={rectangle:'Rectangle',ellipse:'Ellipse',polygon:'Polygon'};
let activePicker=null;

/** Shapes stay in world coordinates; drawing does not create Scene Regions. */
export function scanRegionShape(type,start,end){
  if(!finite(start)||!finite(end))return null;
  const x=Math.min(start.x,end.x),y=Math.min(start.y,end.y),w=Math.abs(end.x-start.x),h=Math.abs(end.y-start.y);
  if(type==='ellipse')return {type:'polygon',source:type,points:Array.from({length:48},(_,i)=>{const a=i*Math.PI/24;return {x:x+w/2+Math.cos(a)*w/2,y:y+h/2+Math.sin(a)*h/2};})};
  return {type:'polygon',source:'rectangle',points:[{x,y},{x:x+w,y},{x:x+w,y:y+h},{x,y:y+h}]};
}
export function scanRegionArea(points=[]){return Math.abs(points.reduce((sum,a,i)=>{const b=points[(i+1)%points.length];return sum+a.x*b.y-a.y*b.x;},0))/2;}
export function scanRegionValidation(region,{gridSize=100,distance=5,maxRadiusFeet=120}={}){
  const points=region?.points;
  if(!Array.isArray(points)||points.length<3)return 'Draw an area first.';
  if(points.length>MAX_VERTICES||points.some(p=>!finite(p)))return 'Use at most 64 valid corners.';
  const bounds=scanPolygonBounds(points),center={x:bounds.x+bounds.width/2,y:bounds.y+bounds.height/2},radius=Math.max(...points.map(p=>Math.hypot(p.x-center.x,p.y-center.y)));
  if(bounds.width<1||bounds.height<1||scanRegionArea(points)<1)return 'Draw a larger area.';
  if(radius/Math.max(.01,gridSize)*Math.max(.01,distance)>maxRadiusFeet+.001)return `Keep the area within a ${maxRadiusFeet} ft bounding radius.`;
  // A crossed polygon has no unambiguous interior; the runtime accepts simple
  // polygons only, so show the error while the user can still edit the shape.
  const side=(a,b,p)=>(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x);
  for(let i=0;i<points.length;i++)for(let j=i+2;j<points.length;j++){
    if(i===0&&j===points.length-1)continue;
    const a=points[i],b=points[(i+1)%points.length],c=points[j],d=points[(j+1)%points.length];
    if(side(a,b,c)*side(a,b,d)<0&&side(c,d,a)*side(c,d,b)<0)return 'The outline crosses itself. Move or undo a corner.';
  }
  // The command validator also refuses touching edges and repeated corners.
  // Show its verdict here, while the shape can still be edited.
  try{toolRegion({type:'polygon',points:points.map(p=>({x:p.x,y:p.y})),...(['rectangle','ellipse','polygon'].includes(region.source)?{source:region.source}:{})});}
  catch(error){return /touch/.test(error.message)?'The outline touches itself. Move or undo a corner.':/distinct/.test(error.message)?'Two corners share a point. Move or undo a corner.':String(error.message??error);}
  return null;
}
/** Native vertex snapping keeps square and hex grids aligned. Gridless is free.
 * Foundry v14: BaseGrid#getSnappedPoint(point, {mode, resolution}); modes from
 * https://foundryvtt.com/api/variables/CONST.GRID_SNAPPING_MODES.html */
export function snapScanRegionPoint(point,{grid=globalThis.canvas?.grid,scene=globalThis.canvas?.scene,snap=true}={}){
  if(!snap||grid?.isGridless||(grid?.type??scene?.grid?.type)===0)return {...point};
  try{
    const mode=globalThis.CONST?.GRID_SNAPPING_MODES?.VERTEX;
    const result=typeof mode==='number'?grid?.getSnappedPoint?.(point,{mode,resolution:1}):null;
    if(finite(result))return {x:result.x,y:result.y};
  }catch{/* Older grid adapters use the square-grid fallback below. */}
  if(grid?.isHexagonal||(grid?.type??scene?.grid?.type)>1)return {...point};
  const size=Math.max(.01,grid?.size??scene?.grid?.size??100),origin=grid?.origin??{x:0,y:0};
  return {x:origin.x+Math.round((point.x-origin.x)/size)*size,y:origin.y+Math.round((point.y-origin.y)/size)*size};
}
const icon=type=>({rectangle:'<rect x="4" y="6" width="16" height="12" rx="1"/>',ellipse:'<ellipse cx="12" cy="12" rx="8" ry="6"/>',polygon:'<path d="M4 17 6 6 16 4 21 13 14 20Z"/>'}[type]);
const path=(ctx,points,close=true)=>{ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));if(close&&points.length>2)ctx.closePath();};

/** Player-accessible region drawing, editing and preview. No API writes occur. */
export function startScanRegionPicker({document:doc=globalThis.document,source,region:initial=null,onPreview=()=>{},onError=()=>{},onClose=()=>{}}={}){
  activePicker?.cancel();
  const el=surface();if(!el?.getBoundingClientRect)throw new Error('The scene canvas is not ready.');
  doc=el.ownerDocument??doc;const view=doc.defaultView,Abort=view.AbortController??AbortController,events=new Abort(),signal=events.signal;
  const layer=doc.createElement('canvas');layer.className='ff-v83-region-layer';layer.setAttribute('aria-hidden','true');doc.body.append(layer);
  const ctx=layer.getContext('2d');if(!ctx){layer.remove();throw new Error('Local area drawing is unavailable.');}
  const panel=doc.createElement('section');panel.className='ff-v83-region-controls';panel.setAttribute('role','dialog');panel.setAttribute('aria-label','Draw a scan region');panel.setAttribute('tabindex','-1');
  panel.innerHTML=`<header><span class="ff-v83-region-emblem" aria-hidden="true">◇</span><div><strong>Map the search</strong><small>Draw a region for your instruments to survey</small></div><span class="ff-v83-region-private">ONLY YOU</span></header><div class="ff-v83-region-toolbar" role="group" aria-label="Region shape">${Object.keys(labels).map(type=>`<button type="button" data-shape="${type}" aria-label="Draw ${type}" aria-pressed="false" title="${labels[type]}"><svg viewBox="0 0 24 24" aria-hidden="true">${icon(type)}</svg><span>${labels[type]}</span></button>`).join('')}<label class="ff-v83-region-snap"><input type="checkbox" data-snap checked><span>Snap to grid</span></label></div><p class="ff-v83-region-help" data-help></p><div class="ff-v83-region-footer"><output data-measure aria-live="polite"></output><button type="button" data-undo title="Undo last corner (Backspace)">Undo</button><button type="button" data-clear>Clear</button><button type="button" data-preview disabled>Preview scan <span aria-hidden="true">→</span></button><button type="button" data-cancel>Cancel</button></div><span class="ff-v83-region-a11y" data-status role="status" aria-live="polite"></span>`;
  doc.body.append(panel);
  const help=panel.querySelector('[data-help]'),measure=panel.querySelector('[data-measure]'),status=panel.querySelector('[data-status]'),preview=panel.querySelector('[data-preview]'),snapInput=panel.querySelector('[data-snap]');
  const grid=()=>globalThis.canvas?.grid,scene=()=>globalThis.canvas?.scene,size=()=>Math.max(1,grid()?.size??scene()?.grid?.size??100),distance=()=>scanRegionDistanceFeet(scene());
  let stopped=false,frame=0,last=-Infinity,dirty=true,previousCamera='',type=initial?.source??'rectangle',region=initial?{...initial,points:copy(initial.points)}:null,vertices=[],draft=null,hover=null,drag=null,pointerId=null,complete=!!initial;
  if(!Object.hasOwn(labels,type))type='polygon';
  // A private native-cell overlay, rebuilt only when a drag ends: dragging never
  // touches the shared scan-context caches that live scans read every frame.
  let cachedGrid=null,cachedGridKey='',unseenKey='',unseenText='';
  const previousCursor=el.style.cursor,previousTouch=el.style.touchAction;el.style.cursor='crosshair';el.style.touchAction='none';
  const hooks=[];
  const clean=()=>{if(stopped)return;stopped=true;events.abort();if(frame)view.cancelAnimationFrame(frame);if(pointerId!=null)try{el.releasePointerCapture?.(pointerId);}catch{}layer.remove();panel.remove();el.style.cursor=previousCursor;el.style.touchAction=previousTouch;for(const [name,id]of hooks)globalThis.Hooks?.off(name,id);if(activePicker===handle)activePicker=null;onClose();};
  const handle={cancel:clean,get region(){return region?{...region,points:copy(region.points)}:null;},kind:'areaScan',source:source?.document?.uuid};activePicker=handle;
  const announce=text=>{status.textContent=text;};
  const overlayGrid=points=>{
    const b=scanPolygonBounds(points),key=`${b.x}:${b.y}:${b.width}:${b.height}:${grid()?.size}:${grid()?.type}`;
    if(!drag&&key!==cachedGridKey){cachedGrid=scanSceneContext({center:{x:b.x+b.width/2,y:b.y+b.height/2},radius:Math.hypot(b.width,b.height)/2,cache:false});cachedGridKey=key;}
    return key===cachedGridKey?cachedGrid?.cells??[]:[];
  };
  // Squares the viewer cannot see are skipped by the instruments (a single
  // survey finishes without them). Warn before preview; at most 256 tests.
  const unseenWarning=()=>{
    if(!complete||!region||drag||globalThis.game?.user?.isGM)return '';
    const key=JSON.stringify(region.points);if(key===unseenKey)return unseenText;unseenKey=key;
    const cells=overlayGrid(region.points).map(cell=>cell.center).filter(p=>scanPointInPolygon(p,region.points));let samples=cells;
    if(!samples.length){const b=scanPolygonBounds(region.points);samples=[];for(let i=0;i<16;i++)for(let j=0;j<16;j++){const p={x:b.x+b.width*(j+.5)/16,y:b.y+b.height*(i+.5)/16};if(scanPointInPolygon(p,region.points))samples.push(p);}}
    const stride=Math.max(1,Math.ceil(samples.length/256));let tested=0,hidden=0;
    for(let i=0;i<samples.length;i+=stride){tested++;if(!viewerSeesPoint(samples[i],source))hidden++;}
    unseenText=hidden?`Part of this area is out of sight${cells.length?` (about ${Math.round(hidden/tested*100)}% of squares)`:''} · unseen squares are skipped.`:'';
    return unseenText;
  };
  const update=()=>{
    dirty=true;const error=scanRegionValidation(region,{gridSize:size(),distance:distance()});preview.disabled=!complete||!!error;
    for(const button of panel.querySelectorAll('[data-shape]'))button.setAttribute('aria-pressed',String(button.dataset.shape===type));
    const gridless=grid()?.isGridless||(grid()?.type??scene()?.grid?.type)===0;snapInput.disabled=gridless;snapInput.parentElement.title=gridless?'This scene has no grid.':'Hold Alt to draw freely.';
    help.textContent=complete?'Drag the area to move it, or drag a corner to reshape. Enter previews the scan.':type==='polygon'?'Click corners, then click the first corner or double-click to close. Backspace or right-click undoes a corner.':'Drag on the scene to draw. Hold Shift for a square or circle. Alt temporarily releases grid snap.';
    panel.querySelector('[data-undo]').disabled=complete||vertices.length===0;panel.querySelector('[data-clear]').disabled=!region&&!vertices.length&&!draft;
    if(region&&complete){const b=scanPolygonBounds(region.points),w=b.width/size()*distance(),h=b.height/size()*distance();measure.textContent=`${w.toFixed(w%1?1:0)} × ${h.toFixed(h%1?1:0)} ft`;if(error){help.textContent=error;panel.classList.add('has-error');}else{panel.classList.remove('has-error');const unseen=unseenWarning();if(unseen)help.textContent=`${unseen} ${help.textContent}`;}}
    else{measure.textContent=vertices.length?`${vertices.length} / ${MAX_VERTICES} corners`:gridless?'Free placement':'Native grid aligned';panel.classList.remove('has-error');}
  };
  const world=event=>{const raw=screenToWorld({x:event.clientX,y:event.clientY},el.getBoundingClientRect(),globalThis.canvas?.stage?.worldTransform,rendererScreen(el));return raw?snapScanRegionPoint(raw,{snap:snapInput.checked&&!event.altKey}):null;};
  const screen=p=>worldToScreen(p,el.getBoundingClientRect(),globalThis.canvas?.stage?.worldTransform,rendererScreen(el));
  const near=(a,b,r=9)=>{const p=screen(a),q=screen(b);return Math.hypot(p.x-q.x,p.y-q.y)<=r;};
  const visible=p=>viewerSeesPoint(p,source);
  const handles=()=>{if(!region)return [];if(type==='polygon')return region.points;const b=scanPolygonBounds(region.points);return [{x:b.x,y:b.y},{x:b.x+b.width,y:b.y},{x:b.x+b.width,y:b.y+b.height},{x:b.x,y:b.y+b.height}];};
  const finishPolygon=()=>{if(vertices.length<3){announce('Add at least three corners.');return false;}region={type:'polygon',source:'polygon',points:copy(vertices)};complete=true;draft=null;vertices=[];update();announce('Polygon ready. Drag to edit, or preview the scan.');return true;};
  const undo=()=>{if(complete||!vertices.length)return;vertices.pop();draft=null;region=vertices.length?{type:'polygon',source:'polygon',points:copy(vertices)}:null;update();announce('Last corner removed.');};
  const clear=()=>{region=null;vertices=[];draft=null;drag=null;complete=false;update();announce('Area cleared. Draw a new region.');};
  const swallow=event=>{event.preventDefault();event.stopImmediatePropagation();};
  const pointerDown=event=>{
    // Right button: Foundry pans the canvas; a short still right click undoes
    // a corner or cancels (listenRightClick below).
    if(event.button!==0)return;swallow(event);panel.focus?.({preventScroll:true});const p=world(event);if(!p)return;
    if(!visible(p)){announce('Choose a point you can see.');help.textContent='Choose a point you can see.';return;}
    if(complete&&region){const editHandles=handles(),index=editHandles.findIndex(h=>near(h,p));if(index>=0)drag={kind:'handle',index,points:copy(region.points),handles:copy(editHandles),start:p};else if(scanPointInPolygon(p,region.points))drag={kind:'move',points:copy(region.points),start:p};
      // A stray click beside a finished area never erases it.
      else{const text='Drag inside the area to move it, drag a corner to reshape, or choose Clear to draw again.';help.textContent=text;announce(text);return;}}
    if(!drag&&!complete){if(type==='polygon'){
      if(vertices.length>=3&&near(vertices[0],p)){finishPolygon();return;}
      if(vertices.length>=MAX_VERTICES){announce('Maximum 64 corners. Close this polygon.');return;}
      if(!vertices.length||!near(vertices.at(-1),p,2))vertices.push(p);region={type:'polygon',source:'polygon',points:copy(vertices)};update();return;
    }drag={kind:'draw',start:p};draft=scanRegionShape(type,p,p);}
    pointerId=event.pointerId;try{el.setPointerCapture?.(pointerId);}catch{}dirty=true;
  };
  const pointerMove=event=>{
    if(stopped||event.target?.closest?.('.ff-v83-region-controls'))return;
    const p=world(event);if(!p)return;hover=p;
    if(!drag){if(type==='polygon'&&!complete&&vertices.length)dirty=true;return;}
    swallow(event);let to=p;
    if(event.shiftKey&&drag.kind==='draw'){const dx=p.x-drag.start.x,dy=p.y-drag.start.y,extent=Math.max(Math.abs(dx),Math.abs(dy));to={x:drag.start.x+Math.sign(dx||1)*extent,y:drag.start.y+Math.sign(dy||1)*extent};}
    if(drag.kind==='draw')draft=scanRegionShape(type,drag.start,to);
    else if(drag.kind==='move'){const dx=p.x-drag.start.x,dy=p.y-drag.start.y;region={...region,points:drag.points.map(q=>({x:q.x+dx,y:q.y+dy}))};}
    else if(type==='polygon'){region={...region,points:drag.points.map((q,i)=>i===drag.index?p:q)};}
    else{const opposite=drag.handles[(drag.index+2)%4];region=scanRegionShape(type,opposite,p);}
    dirty=true;
  };
  const finishDrag=()=>{
    if(!drag)return false;
    if(drag.kind==='draw'){region=draft;draft=null;complete=!!region;}drag=null;
    if(pointerId!=null)try{el.releasePointerCapture?.(pointerId);}catch{}pointerId=null;update();announce(preview.disabled?'Adjust the area before previewing.':'Area ready. Preview the scan, or drag to edit.');return true;
  };
  const pointerUp=event=>{
    if(event.button===2||!drag||event.pointerId!==pointerId&&pointerId!=null)return;swallow(event);finishDrag();
  };
  const previewRegion=()=>{
    if(!complete&&type==='polygon'&&!finishPolygon())return;
    const error=scanRegionValidation(region,{gridSize:size(),distance:distance()});if(error){help.textContent=error;announce(error);return;}
    const chosen={type:'polygon',source:type,points:copy(region.points)};clean();try{onPreview(chosen);}catch(error){onError(error);}
  };
  el.addEventListener('pointerdown',pointerDown,{signal,capture:true});el.addEventListener('dblclick',event=>{swallow(event);if(type==='polygon'&&!complete)finishPolygon();},{signal,capture:true});
  doc.addEventListener('pointermove',pointerMove,{signal,capture:true});doc.addEventListener('pointerup',pointerUp,{signal,capture:true});doc.addEventListener('pointercancel',()=>{drag=null;draft=null;pointerId=null;update();},{signal,capture:true});
  const rightClick=listenRightClick(el,doc,signal,event=>{if(event.target?.closest?.('.ff-v83-region-controls'))return;if(type==='polygon'&&!complete&&vertices.length)undo();else clean();});
  panel.addEventListener('pointerdown',event=>event.stopPropagation(),{signal});
  panel.addEventListener('click',event=>{event.stopPropagation();const button=event.target.closest?.('button');if(!button||button.disabled)return;if(button.dataset.shape){type=button.dataset.shape;clear();}else if(button.hasAttribute('data-undo'))undo();else if(button.hasAttribute('data-clear'))clear();else if(button.hasAttribute('data-preview'))previewRegion();else if(button.hasAttribute('data-cancel'))clean();},{signal});
  snapInput.addEventListener('change',()=>{update();announce(snapInput.checked?'Grid snapping enabled.':'Free placement enabled.');},{signal});
  doc.addEventListener('keydown',event=>{
    if(event.key==='Escape'){swallow(event);clean();return;}
    if(event.target?.closest?.('input,textarea,select,[contenteditable="true"]'))return;
    if(event.key==='Enter'&&!event.target?.closest?.('button')){swallow(event);previewRegion();}
    else if(event.key==='Backspace'||event.key==='Delete'||event.key.toLowerCase()==='z'&&(event.ctrlKey||event.metaKey)){swallow(event);undo();}
    else if(complete&&region&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){
      // Step one native cell (hex sizeX / sizeY), then snap the first corner
      // to the grid and move the whole shape rigidly by that snapped step.
      swallow(event);const snap=snapInput.checked&&!event.altKey,g=grid(),scale=event.shiftKey?5:1,stepX=(snap?(g?.sizeX||size()):1)*scale,stepY=(snap?(g?.sizeY||size()):1)*scale;
      let dx=event.key==='ArrowLeft'?-stepX:event.key==='ArrowRight'?stepX:0,dy=event.key==='ArrowUp'?-stepY:event.key==='ArrowDown'?stepY:0;
      if(snap){const anchor=region.points[0],snapped=snapScanRegionPoint({x:anchor.x+dx,y:anchor.y+dy});if(finite(snapped)&&(snapped.x!==anchor.x||snapped.y!==anchor.y)){dx=snapped.x-anchor.x;dy=snapped.y-anchor.y;}}
      region={...region,points:region.points.map(p=>({x:p.x+dx,y:p.y+dy}))};update();
    }
  },{signal,capture:true});
  // Focus leaving the window ends a drag (and its pointer capture) where it
  // is; the picker itself stays open until Escape, Cancel or a right click.
  const release=()=>{rightClick.reset();finishDrag();};
  doc.addEventListener('visibilitychange',()=>{if(doc.hidden)release();},{signal});view.addEventListener('blur',release,{signal});view.addEventListener('resize',()=>{dirty=true;},{signal});
  if(globalThis.Hooks?.on){hooks.push(['canvasTearDown',Hooks.on('canvasTearDown',clean)],['deleteToken',Hooks.on('deleteToken',deleted=>{if(deleted.id===source?.id)clean();})]);}
  const paint=()=>{
    const dpr=Math.min(2,view.devicePixelRatio||1),w=view.innerWidth,h=view.innerHeight;if(layer.width!==Math.round(w*dpr)||layer.height!==Math.round(h*dpr)){layer.width=Math.round(w*dpr);layer.height=Math.round(h*dpr);}
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
    const current=draft??region,points=current?.points??vertices;if(!points.length)return;
    const projected=points.map(screen),closed=!!draft||complete;
    if(closed&&points.length>=3){
      ctx.save();path(ctx,projected);ctx.fillStyle='rgba(225,59,238,.075)';ctx.fill();ctx.clip();
      // Draw actual native cell edges through the region clip, without inventing
      // a square grid on hex or gridless scenes: one path, one stroke, at most
      // 1,200 cells. While a drag is in progress the cells are hidden.
      ctx.strokeStyle='rgba(244,173,255,.11)';ctx.lineWidth=.7;ctx.beginPath();
      for(const cell of overlayGrid(points).slice(0,1200)){const polygon=cell.polygon;for(let i=0;i<polygon.length;i++){const p=screen(polygon[i]);if(i)ctx.lineTo(p.x,p.y);else ctx.moveTo(p.x,p.y);}ctx.closePath();}
      ctx.stroke();
      const bounds=scanPolygonBounds(projected);ctx.strokeStyle='rgba(239,137,255,.1)';ctx.lineWidth=1;
      for(let x=bounds.x-bounds.height;x<bounds.x+bounds.width;x+=24){ctx.beginPath();ctx.moveTo(x,bounds.y+bounds.height);ctx.lineTo(x+bounds.height,bounds.y);ctx.stroke();}
      ctx.restore();
    }
    ctx.save();path(ctx,projected,closed);ctx.shadowColor='#e44bff';ctx.shadowBlur=9;ctx.strokeStyle='rgba(255,149,255,.92)';ctx.lineWidth=1.6;ctx.stroke();ctx.shadowBlur=0;
    if(!closed&&hover&&points.length){const p=screen(hover),last=projected.at(-1);ctx.setLineDash([4,5]);ctx.strokeStyle='#e7a2ef';ctx.beginPath();ctx.moveTo(last.x,last.y);ctx.lineTo(p.x,p.y);ctx.stroke();ctx.setLineDash([]);}
    const editHandles=complete?handles():type==='polygon'?points:[];
    for(const [i,h]of editHandles.entries()){const p=screen(h),r=i===0&&!complete?5:3.5;ctx.beginPath();ctx.rect(p.x-r,p.y-r,r*2,r*2);ctx.fillStyle='#211327';ctx.fill();ctx.strokeStyle=i===0&&!complete?'#fff0ff':'#f1b8ff';ctx.lineWidth=1.4;ctx.stroke();}
    if(complete){const b=scanPolygonBounds(projected),label=`${labels[type]} search region`;ctx.font='600 10px system-ui,sans-serif';const tw=ctx.measureText(label).width;ctx.fillStyle='#21142cee';ctx.fillRect(b.x,b.y-23,tw+18,19);ctx.fillStyle='#f5c8ff';ctx.fillText(label,b.x+9,b.y-10);}
    ctx.restore();
  };
  const tick=now=>{
    if(stopped)return;if(!layer.isConnected||source?.destroyed||source?.document?.isOwner===false){clean();return;}
    if(now-last<1000/30){frame=view.requestAnimationFrame(tick);return;}
    const matrix=globalThis.canvas?.stage?.worldTransform??{},rect=el.getBoundingClientRect(),camera=`${matrix.a}:${matrix.b}:${matrix.c}:${matrix.d}:${matrix.tx}:${matrix.ty}:${rect.left}:${rect.top}:${rect.width}:${rect.height}`;
    if(camera!==previousCamera){previousCamera=camera;dirty=true;}
    last=now;if(dirty){dirty=false;try{paint();}catch(error){onError(error);clean();return;}}
    frame=view.requestAnimationFrame(tick);
  };
  update();panel.querySelector(`[data-shape="${type}"]`)?.focus?.({preventScroll:true});frame=view.requestAnimationFrame(tick);return handle;
}
