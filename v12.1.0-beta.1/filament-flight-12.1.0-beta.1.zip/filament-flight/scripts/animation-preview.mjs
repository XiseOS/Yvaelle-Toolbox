import {beginWingGesture} from './v7-wing-motion.mjs?v=12.1.0-beta.1';
/** Read-only local animation preview of the live module renderer. No scene documents, PIXI, audio, network or RAF.
 * Uses the native state solver, wing rig, painter, Resonant Core CPU painter,
 * and token suspension sampler. The outer canvas composition follows the
 * source EffectPreview, with injectable colours and native token motion added.
 */
import {configuration} from './config.mjs?v=12.1.0-beta.1';
import {normalizeFlag,resolveRenderState} from './state.mjs?v=12.1.0-beta.1';
import {createEffectPreview} from './effect-picker-model.mjs?v=12.1.0-beta.1';
import {frameGeometry,paintLayers,LAYER_NAMES} from './wing-rig.mjs?v=12.1.0-beta.1';
import {drawFrame} from './wing-art.mjs?v=12.1.0-beta.1';
import {sampleModeFloat} from './motion.mjs?v=12.1.0-beta.1';
import {BitFrames,separateBits} from './bit-renderer.mjs?v=12.1.0-beta.1';
import {applyBitCondition} from './condition-response.mjs?v=12.1.0-beta.1';
import {applyBitWaveDirections} from './bit-wave-direction.mjs?v=12.1.0-beta.1';
import {previewQualityConfiguration} from './quality.mjs?v=12.1.0-beta.1';
import {medicalPreviewPatient,paintMedicalPreviewPatient,releaseMedicalPreviewPatient} from './medical-preview-patient.mjs?v=12.1.0-beta.1';

const clamp=(value,lo,hi)=>Math.min(hi,Math.max(lo,value));
const instances=new WeakMap();
const PREVIEW_KINDS=new Set(['mode','pose','wing','float','condition','reaction','default','look']);

export function createWingPreview(surface,options={}) {
  const context=surface.getContext('2d');
  if(!context)throw new Error('A 2D canvas is required for this preview.');
  const make=()=>surface.ownerDocument.createElement('canvas');
  const initialConfig=previewQualityConfiguration({...configuration(),...options.configOverrides});
  let resolution=clamp(options.resolution??({low:384,medium:512,high:768}[initialConfig.rigQuality]??512),256,768);
  const layers=Object.fromEntries(LAYER_NAMES.map(key=>{const c=make();c.width=c.height=resolution;return[key,c];}));
  const contexts=Object.fromEntries(Object.entries(layers).map(([key,c])=>[key,c.getContext('2d')]));
  const atlas=make();atlas.width=atlas.height=resolution;
  const bits=new BitFrames({makeCanvas:make});
  const waveState=new Map();
  let selection=null,preview=null,destroyed=false,frame=0,portraitAvailable=false;
  let colors={background:options.background??'#18131e',textColor:options.textColor??'#ece4eb',tokenColor:options.tokenColor??'#302333',lineColor:options.lineColor??'#765b78'};
  const getModel=(spec)=>{
    const cfg=previewQualityConfiguration({...configuration(),wingRenderer:'rig',bitQuality:'medium',effectDetail:'high',...options.configOverrides,...spec.configOverrides});
    const baseAppearance={...cfg.defaults,...options.appearance,...spec.appearance};
    const request={enabled:true,airborne:true,mode:spec.mode??'hover',pose:spec.pose??'neutral',structure:spec.structure??'wings',condition:spec.condition??'normal',conditionSource:'manual',autoHP:false,started:0,options:baseAppearance,...options.request,...spec.request};
    if(spec.kind==='mode')request.mode=spec.id;
    if(spec.kind==='pose')request.pose=spec.id;
    if(spec.kind==='wing')request.v7={...request.v7,enabled:true,mode:'enhanced',wingAnimations:true,wingGesture:beginWingGesture(spec.id,0,null,{key:`preview:${spec.id}`})};
    if(spec.kind==='float')baseAppearance.floatStyle=spec.id;
    request.enabled=true;request.airborne=request.mode!=='grounded';request.bitsDeployed=true;request.started=0;request.transition=null;request.bitTransition=null;request.bitCountTransition=null;request.modeTransition=null;request.poseTransition=null;request.temporaryPose=null;request.structureTransition=null;request.structurePoseTransition=null;request.conditionTransition=null;request.temporaryCondition=null;request.hpTransition=null;request.cues=null;request.options=baseAppearance;request.optionOverrides={...baseAppearance};
    request.observerQuality={preset:'inherit'};
    // Individual choices isolate their artwork. The complete-look preview uses
    // the saved HP preference and its read-only live health/condition context.
    if(spec.kind!=='look'){request.conditionSource='manual';request.autoHP=false;}
    // Float comparisons isolate the selected path from mode character by
    // default. Explicit modeIdleStrength remains honoured for combined previews.
    if(spec.kind==='float'&&spec.appearance?.modeIdleStrength==null)baseAppearance.modeIdleStrength=0;
    return {cfg,baseAppearance,token:{document:{name:options.tokenLabel??'Ellie',uuid:'ellie-hud-local-preview'}},prefs:{effectStrength:.8,pulseDurationMs:1800,stutterDurationMs:1800,...options.prefs,...spec.prefs},state:{requested:request,effective:{condition:request.condition}}};
  };
  const setSelection=(spec={})=>{
    if(destroyed)return;
    selection={kind:'pose',id:'neutral',...spec};
    if(!PREVIEW_KINDS.has(selection.kind))throw new Error(`Unknown wing preview: ${selection.kind}`);
    waveState.clear();
    const model=getModel(selection);
    if(['condition','reaction','default'].includes(selection.kind)) {
      const key=selection.key??(selection.kind==='condition'?selection.condition??'normal':selection.kind==='reaction'?'pulse':'effectStyle');
      preview=createEffectPreview(model,selection.kind,key,selection.id);
    } else {
      preview={data:normalizeFlag(model.state.requested,0),cfg:model.cfg,seed:'ellie-hud-local-preview',group:selection.kind,key:selection.id,id:selection.id,cycle:0};
    }
    return preview;
  };
  const setColors=(values={})=>{colors={...colors,...values};};
  /* (beta.38) A frame in parts, so a caller can spread one frame over several
   * display frames: prepare() works out her state and the wing geometry;
   * prepareBits() brings the bits to that frame (their pictures); render()
   * paints it all onto the surface (and does prepareBits first if it was not
   * done). draw() is all of it, as before. A prepared frame must be rendered
   * before the next is prepared (the bits keep their state between them). */
  const prepare=(elapsed=0,{deferBits=false}={})=>{
    if(destroyed)return null;
    if(!preview)setSelection();
    elapsed=Math.max(0,Number.isFinite(elapsed)?elapsed:0);
    const {cfg}=preview;
    const time=cfg.reduced?0:elapsed;
    const event=preview.data.v7?.wingGesture;
    const now=preview.group==='reaction'?time%preview.cycle:preview.group==='wing'&&event?time%(event.enter+event.hold+event.release+1800):time;
    const data=options.conditionContext?{...preview.data,conditionResponse:options.conditionContext.conditionResponse}:preview.data;
    const snapshot=resolveRenderState(data,cfg,now,{seed:preview.seed,resumeFlightTransition:false,resumePoseTransition:false,...options.conditionContext});
    const v=snapshot.visual.profile,opts=snapshot.options,f=context;
    const w=surface.width,h=surface.height;
    if(!w||!h)return {snapshot,empty:true};
    const portrait=options.sourceToken?medicalPreviewPatient(surface,options.sourceToken,null,{x:0,y:0},{align:'anchor',targetSize:100}):null;
    portraitAvailable=!!portrait;
    const portraitBounds=portrait?.bounds;
    const scale=opts.wingScale,extent=snapshot.structureAnimation?.artworkExtent??1,fitScale=scale*extent;
    // Fixed padded fit leaves room for the actual float displacement and roll.
    const x0=Math.min(-.5,portraitBounds?portraitBounds.x/100:0,opts.offsetX-fitScale/2),x1=Math.max(.5,portraitBounds?(portraitBounds.x+portraitBounds.width)/100:0,opts.offsetX+fitScale/2);
    const y0=Math.min(-.5,portraitBounds?portraitBounds.y/100:0,opts.offsetY-fitScale/2),y1=Math.max(.5,portraitBounds?(portraitBounds.y+portraitBounds.height)/100:0,opts.offsetY+fitScale/2);
    const unit=Math.min(w*.90/(x1-x0),h*.82/(y1-y0));
    const tx=w/2-(x0+x1)*unit/2,ty=h/2-(y0+y1)*unit/2;
    const width=scale*unit,wx=opts.offsetX*unit-width/2,wy=opts.offsetY*unit-width/2;
    // Layers are composited at `width` canvas pixels; callers already size the
    // backing store for devicePixelRatio. Paint at that size (64 px steps),
    // capped by the quality setting. An explicit resolution option still wins.
    resolution=clamp(options.resolution??Math.min({low:384,medium:512,high:768}[cfg.rigQuality]??512,Math.ceil(width/64)*64),256,768);
    const pad=extent>1?Math.ceil(resolution*(extent-1)*.6/32)*32:0;
    const viewports=pad?Object.fromEntries(LAYER_NAMES.map(key=>[key,{x:-pad,y:-pad,width:resolution+pad*2,height:resolution+pad*2}])):null;
    const flying=snapshot.rendering.flightFactor;
    const suspension=sampleModeFloat(opts,time/1000,snapshot.flightProfile,cfg.reduced);
    const dx=cfg.hover?suspension.x*unit*flying:0;
    const dy=cfg.hover?-(opts.hoverHeight+suspension.y)*unit*flying:0;
    const opacity=snapshot.rendering.active?opts.opacity*snapshot.effective.intensity:0;
    const phase=cfg.reduced||!cfg.wingbeats?0:time/1000*opts.wingSpeed/2.4*Math.PI*2;
    const rig=snapshot.rendering.renderer==='rig';
    const blend=rig?(cfg.wingRenderer==='rig'||snapshot.gems.rigRequired||snapshot.structureAnimation?.rigRequired||!cfg.energyPulses?1:Math.max(snapshot.visual.rigMix,Math.min(1,(1-Math.min(snapshot.poseAnimation.weights[0],snapshot.poseAnimation.tipWeights[0]))*5))):0;
    let geometry=null;
    if(rig&&opacity){
      const rawGeometry=frameGeometry(snapshot.poseAnimation.weights,phase,v,snapshot);
      if(snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse.mix>.01)for(const key of LAYER_NAMES){
        rawGeometry[key]=rawGeometry[key].filter(part=>!(/^(support-|intent-exchange)/.test(part.id)));
        for(const part of rawGeometry[key])if(part.hardware)part.hardware.glow=null;
      }
      geometry=separateBits(rawGeometry);
      applyBitWaveDirections(geometry.bits,waveState,snapshot,now);
      if(options.conditionContext&&snapshot.conditionResponse.bits)geometry.bits=new Map([...geometry.bits].map(([id,bit],index)=>{
        const part=bit.part,h=part.hardware,p=part.points[0],station=bit.station??`${bit.left?'left':'right'}${id.endsWith('0')?'Upper':'Lower'}`;
        const local={x:(wx+(p[0]+300)/600*width)/unit*100,y:(wy+(p[1]+285)/600*width)/unit*100,z:p[2]};
        const next=applyBitCondition(local,snapshot.conditionResponse,{id:station,index,now,world:false,positionLocked:h.stabilization?.positionLocked===true});
        const gain=Math.round(next.glowMultiplier*32)/32,still=next.conditionMotion,ground=next.conditionGround??0;
        const resonance=h.resonance?{...h.resonance,amount:(h.resonance.amount??0)*still,mechanical:(h.resonance.mechanical??0)*still,
          charge:(h.resonance.charge??1)*gain,healing:(h.resonance.healing??0)*still,yaw:(h.resonance.yaw??0)*still,orbit:(h.resonance.orbit??0)*still,precession:(h.resonance.precession??0)*still,
          ...(ground>.01?{coreState:{id:'encased',amount:ground,encase:ground,open:0,charge:0,guard:0,settle:0,progress:0}}:{})}:h.resonance;
        return [id,{...bit,front:bit.front+(bit.rear*ground),rear:bit.rear*(1-ground),part:{...part,points:[[(next.x/100*unit-wx)/width*600-300,(next.y/100*unit-wy)/width*600-285,next.z,p[3]]],
          hardware:{...h,angle:(h.angle??0)+next.angleDelta,power:(h.power??1)*gain,resonance,glow:h.glow?{...h.glow,strength:h.glow.strength*gain}:h.glow}}}];
      }));
      if(!deferBits)bits.update(geometry.bits,cfg.bitQuality,time);
    }
    return {snapshot,cfg,v,w,h,portrait,unit,tx,ty,width,wx,wy,pad,viewports,flying,suspension,dx,dy,opacity,phase,rig,blend,geometry,time,resolution,bitsPending:!!(deferBits&&geometry)};
  };
  /* (beta.39) A frame's bits one at a time (one:true), so a capture step stays near a millisecond: each
   * bit's picture is the one the whole update paints (the others are kept meanwhile); the last call is the
   * whole update, which only lets go of bits no longer in the frame (nothing left to paint). */
  const prepareBits=(frameState,{one=false}={})=>{
    if(destroyed||!frameState?.bitsPending)return frameState;
    const all=frameState.geometry.bits,q=frameState.cfg.bitQuality;
    if(one){
      frameState.bitQueue??=[...all.keys()];
      if(frameState.bitQueue.length>1){const id=frameState.bitQueue.shift();bits.update(new Map([[id,all.get(id)]]),q,frameState.time,{retain:new Set(all.keys())});return frameState;}
    }
    bits.update(all,q,frameState.time);frameState.bitsPending=false;frameState.bitQueue=null;
    return frameState;
  };
  const sizeLayers=(frameState)=>{
    resolution=frameState.resolution;const pad=frameState.pad;
    if(atlas.width!==resolution)atlas.width=atlas.height=resolution;
    for(const layer of Object.values(layers))if(layer.width!==resolution+pad*2)layer.width=layer.height=resolution+pad*2;
  };
  /** (beta.39) The wing layers still to paint for this frame, and one of them painted now (render paints the rest). */
  const layersLeft=frameState=>frameState&&!frameState.empty&&frameState.rig&&frameState.opacity?LAYER_NAMES.filter(k=>!frameState.layersDone?.has(k)):[];
  const paintLayer=(frameState,key)=>{
    if(destroyed||!frameState||frameState.empty||!frameState.rig||!frameState.opacity)return frameState;
    sizeLayers(frameState);(frameState.layersDone??=new Set());
    if(frameState.layersDone.has(key))return frameState;
    paintLayers(contexts,frameState.geometry.wings,frameState.resolution,frameState.v,undefined,frameState.viewports,[key]);
    frameState.layersDone.add(key);return frameState;
  };
  const render=(frameState)=>{
    if(destroyed||!frameState)return null;
    if(frameState.empty)return frameState.snapshot;
    prepareBits(frameState);
    const {snapshot,cfg,v,w,h,portrait,unit,tx,ty,width,wx,wy,pad,viewports,flying,suspension,dx,dy,opacity,phase,rig,blend,geometry,time}=frameState,f=context;
    sizeLayers(frameState);
    f.setTransform(1,0,0,1,0,0);f.globalAlpha=1;f.clearRect(0,0,w,h);
    if(colors.background&&colors.background!=='transparent'){f.fillStyle=colors.background;f.fillRect(0,0,w,h);}
    // The ground marker makes small differences in float and mode easy to see.
    if(options.groundMarker!==false){
      f.strokeStyle=colors.lineColor;f.globalAlpha=.35;f.lineWidth=Math.max(1,w/500);
      f.beginPath();f.ellipse(tx,ty+unit*.5,unit*.47,unit*.095,0,0,Math.PI*2);f.stroke();f.globalAlpha=1;
    }
    f.save();f.translate(tx+dx,ty+dy);f.rotate(cfg.banking?suspension.roll*flying:0);f.scale(1,1+(cfg.pitching?suspension.pitch*flying:0));
    if(blend<1&&opacity){
      drawFrame(atlas.getContext('2d'),Math.floor(phase/(2*Math.PI)*48)/48*2*Math.PI,resolution);
      f.globalAlpha=opacity*(1-blend)*Math.min(1,v.energy)*(1-.3*v.damage);f.drawImage(atlas,wx,wy,width,width);
    }
    const paintLayer=key=>{f.drawImage(layers[key],wx-pad/resolution*width,wy-pad/resolution*width,width*(1+pad*2/resolution),width*(1+pad*2/resolution));bits.drawLayer(f,key,wx,wy,width,width,f.globalAlpha);};
    if(rig&&opacity){
      const left=layersLeft(frameState);if(left.length)paintLayers(contexts,geometry.wings,resolution,v,undefined,viewports,left);
      f.globalAlpha=opacity*blend*(v.renderOpacity??Math.min(1,v.energy));
      for(const key of LAYER_NAMES)if(!cfg.foregroundWings||key.endsWith('Rear'))paintLayer(key);
    }
    f.globalAlpha=1;
    options.paintOverlay?.(f,{plane:'rear',snapshot,geometry,unit,width,wx,wy,time});
    const img=options.sourceToken?null:options.tokenImage;
    if(portrait){f.save();f.scale(unit/100,unit/100);paintMedicalPreviewPatient(f,portrait);f.restore();}
    else if(img&&(img.complete??true)&&(img.naturalWidth??img.width)>0){
      const ratio=(img.naturalWidth??img.width)/(img.naturalHeight??img.height)||1;
      const iw=ratio>=1?unit:unit*ratio,ih=ratio>=1?unit/ratio:unit;
      f.drawImage(img,-iw/2,-ih/2,iw,ih);
    }else{
      f.fillStyle=colors.tokenColor;f.strokeStyle=colors.lineColor;f.lineWidth=Math.max(1,w/450);f.beginPath();f.arc(0,0,unit*.45,0,Math.PI*2);f.fill();f.stroke();
      f.fillStyle=colors.textColor;f.font=`${Math.max(12,unit*.32)}px Georgia,serif`;f.textAlign='center';f.textBaseline='middle';f.fillText((options.tokenLabel??'Ellie').slice(0,1),0,0);
    }
    if(rig&&cfg.foregroundWings&&opacity){
      f.globalAlpha=opacity*blend*(v.renderOpacity??Math.min(1,v.energy))*cfg.foregroundOpacity;
      for(const key of ['leftFront','rightFront'])paintLayer(key);
    }
    f.globalAlpha=1;options.paintOverlay?.(f,{plane:'front',snapshot,geometry,unit,width,wx,wy,time});
    f.restore();f.globalAlpha=1;frame++;
    return snapshot;
  };
  const draw=(elapsed=0)=>destroyed?null:render(prepare(elapsed));
  const destroy=()=>{
    if(destroyed)return;destroyed=true;bits.clear();waveState.clear();releaseMedicalPreviewPatient(surface);
    for(const c of [...Object.values(layers),atlas])c.width=c.height=1;
    instances.delete(surface);preview=null;selection=null;
  };
  /** How long the preview takes to repeat itself, when it does: a reaction's cycle or a wing gesture's
   * enter, hold and release. Null for continuous motion (conditions, poses, modes). */
  const loopLength=()=>{if(!preview&&!destroyed)setSelection();if(!preview)return null;const event=preview.data?.v7?.wingGesture;
    if(preview.group==='reaction'&&preview.cycle>0)return preview.cycle;if(preview.group==='wing'&&event)return event.enter+event.hold+event.release+1800;return null;};
  const api={setSelection,setColors,draw,prepare,prepareBits,paintLayer,layersLeft,render,destroy,loopLength,get frames(){return frame;},get selection(){return selection;},get preview(){return preview;},get portraitAvailable(){return portraitAvailable;}};
  if(options.selection)setSelection(options.selection);
  return api;
}

/** Convenience wrapper. Pass the same selection object on repeated frames. */
export function paintWingPreview(canvas,options={}) {
  let entry=instances.get(canvas);
  if(!entry){entry={renderer:createWingPreview(canvas,options),selection:null};instances.set(canvas,entry);}
  const selection=options.selection??options;
  if(entry.selection!==selection){entry.renderer.setSelection(selection);entry.selection=selection;}
  if(options.background||options.textColor)entry.renderer.setColors(options);
  return entry.renderer.draw(options.elapsed??0);
}
