/** Yvaelle’s Toolbox v11 · Her own ring: the rim band of her token art (11.0.0-test.8).
 *
 * The drawn frame is off by default: her token art already has its own ring.
 * Everything that used the drawn frame's rim (tarnish, a heal's warmth, rim
 * lights, the beads that ride the rim, the hidden outline, the cloak's thin
 * ghost ring) now sits on the rim of her actual token picture, whatever its
 * shape or thickness. This module finds that rim once per texture:
 *
 *   rimMask(rgba, N)   pure: from an N×N copy of her token art, a mask
 *                      R = the rim band (from the art's alpha edge inward by the ring's thickness),
 *                      G = a thin line along the alpha edge (the hidden outline),
 *                      B = the picture inside the ring (the part that breathes, leans and recoils),
 *                      plus the thickness found and the band's mean radius.
 *   rimTextureOf(tex)  the mask as a PIXI texture, cached per base texture
 *                      (a WeakMap: one small canvas per token picture, made on
 *                      first ask; nothing per frame).
 *
 * (11.0.0-test.9) The measuring now lives in v11/token-shape.mjs (her token's shape profile): this file keeps the
 * names test.8 used.
 *
 * The ring's thickness is read from the picture: walking inward from the alpha
 * edge, the depth where the colour changes most (gold ring → portrait). If the
 * picture shows no such step, 10 % of her radius. A picture that cannot be
 * read (cross-origin) gets a plain circular band. */
import {SHAPE_N,autoShape,plainShape,shapeTextureOf} from './token-shape.mjs?v=12.1.0-beta.1';
export const RIM_N=SHAPE_N;
/** (test.9) The rim mask is now one view of her token's shape profile (v11/token-shape.mjs): the same detector.
 * → {data (RGBA: R band, G edge line, B the picture inside, A 255), thickness (radii), radius (the band's mean radius), found, cover, profile} */
export function rimMask(rgba,N=RIM_N){
  const {profile,data}=autoShape(rgba,N),B=profile.border;
  return {data,thickness:B.thickness,radius:B.radius,found:B.found,cover:profile.cover,profile};
}
/** A plain circular band (a picture that cannot be read). */
export function circleRim(N=RIM_N,T=.10){
  const {profile,data}=plainShape('fallback',N,T);
  return {data,thickness:T,radius:profile.border.radius,found:false,fallback:true,cover:profile.cover,profile};
}
/** Her token texture's rim mask: {texture, profile, thickness, radius, found, fallback, cover} (cached per base texture and
 * fit option; null without a canvas). opts: v11/token-shape.mjs fitOptions (null: Automatic). */
export function rimTextureOf(tex,PIXI=globalThis.PIXI,opts=null){return shapeTextureOf(tex,opts,PIXI);}
