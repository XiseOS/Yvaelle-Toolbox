/** Yvaelle’s Toolbox v11 · Token layer runtime: her token, its inputs, its filter.
 *
 * Which tokens: tokens with Yvaelle’s Toolbox on them (a `flight` flag) whose
 * Token layer switch is on (v11/features.mjs, saved on her token).
 *
 * Inputs it reads (all already in the module):
 *  - her HP (frame tarnish below 40 %, a heal's warmth, a blow's recoil);
 *  - her conditions (frightened → fear, unconscious or dying → ko, hidden,
 *    invisible or undetected → the hidden drain);
 *  - her flight (bank and pitch from the motion state, her wing light from
 *    how far her wings are out), her bits' attention (the glance) and her wing
 *    gestures (bow, sigh, curious, pray, shrug);
 *  - PF2e damage rolls aimed at her (the damage type of the next blow).
 * Entry points for later phases (api.v11.tokenLayer): hit, heal, give, emote,
 * hidden, cloak, light.
 *
 * Cost (the user: "I want none of this to be heavy"):
 *  - a token whose look is still does no work: no ticker, no sampling, no
 *    upload, no redraw request; the filter's uniforms simply stay as they were;
 *  - a moving look samples into preallocated arrays (nothing allocated per
 *    frame) and asks for a redraw only when it changed by a quarter pixel (or
 *    half an 8-bit colour step) or more; at 1:1 her breathing is a few
 *    redraws a second, not sixty;
 *  - one filter pass on her token mesh, frame textures loaded once per style;
 *  - nothing touches her token's transform or bounds, so no perception or
 *    occlusion work is ever asked for. */
import {partsOf,choice,isOn,partOn,FEATURES} from './features.mjs?v=12.1.0-beta.1';
import {createLook,sampleTokenLayer,lookDelta,copyLook,EMOTES,EMOTES_FULL,DAMAGE_TINT} from './token-layer.mjs?v=12.1.0-beta.1';
import {tokenLayerFilterClass,frameSet} from './token-layer-filter.mjs?v=12.1.0-beta.1';
import {readBitIntentTarget} from '../bit-intent.mjs?v=12.1.0-beta.1';
import {applyFrameDamage,veilFrameDamage} from './frame-damage.mjs?v=12.1.0-beta.1';
import {rimTextureOf} from './token-rim.mjs?v=12.1.0-beta.1';
import {fitOptions,hasFoundryRing,bandRadiusAt} from './token-shape.mjs?v=12.1.0-beta.1';
const NO_PICTURE=Object.freeze({});

const ID='filament-flight';
const MAGENTA=[1,96/255,236/255];
const MOTION_PARTS=['breathe','lean','glance','recoil','emotes'];
/** Wing gestures that read as one of her portrait's emotes. */
export const GESTURE_EMOTES=Object.freeze({lunarBow:'bow',greetingFold:'bow',heldBreath:'sigh',featherTurn:'curious',softShelter:'pray',resolveArc:'shrug'});
const NO_LIGHTS=Object.freeze([]);
const now=()=>performance.now()/1000;
const unit=x=>x<0?0:x>1?1:x,smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const docOf=t=>t?.document??t??null;
// (the frame's easing and event helpers: plain functions, so a frame allocates no closures)
let busy=false;
function ease(cur,to,rate,dt){const v=cur+(to-cur)*(1-Math.exp(-rate*dt));if(Math.abs(to-v)>.002){busy=true;return v;}return to;}
function ev(rec,limit,t){if(rec.at<0)return null;rec.q=t-rec.at;if(rec.q>limit){rec.at=-1;return null;}busy=true;return rec;}

/** A PF2e condition's value on her actor (0 when absent). */
function condition(actor,slug){
  try{
    const c=actor?.getCondition?.(slug);if(c)return Number(c.value)||1;
    if(actor?.hasCondition?.(slug))return 1;
    if(actor?.statuses?.has?.(slug))return 1;
    for(const it of actor?.itemTypes?.condition??[])if(it.slug===slug)return Number(it.value)||1;
  }catch{}
  return 0;
}
function hpOf(actor){const hp=actor?.system?.attributes?.hp;const v=Number(hp?.value),m=Number(hp?.max);return Number.isFinite(v)&&m>0?{value:v,max:m}:null;}

class Layer{
  constructor(rt,token){
    this.rt=rt;this.token=token;this.mesh=null;this.filter=null;
    this.look=createLook();this.shown=createLook();this.hasShown=false;
    this.I={t:0,bank:0,pitch:0,wing:{glow:0,spread:0,color:MAGENTA},lights:NO_LIGHTS,glance:{x:0,y:0,k:0},hit:null,give:null,healed:null,
      fear:0,ko:0,wake:0,afterglow:0,hp:1,emote:null,hidden:null};
    this.hitRec={q:0,dir:[0,0],type:'',sev:.4,at:-1};this.giveRec={q:0,gather:.7,n:2,at:-1};this.healRec={q:0,k:1,at:-1};
    this.emoteRec={name:'',tau:0,look:{x:-1,y:0},at:-1,full:false,w:1,endAt:-1,fade:.3};this.hiddenRec={mode:'hide',q:0,ghost:true,at:-1};
    this.target={fear:0,ko:0,hidden:false,afterglowAt:-1,wakeAt:-1};this.glanceAt=0;this.gestureKey=null;
    this.awake=true;this.lastTick=now();this.parts=null;this.variant='keepsake';this.frames=null;this.rimFor=undefined;
    this.readConfig();this.readActor(true);
  }
  get doc(){return this.token.document;}
  readConfig(){
    const doc=this.doc,parts={...partsOf('tokenLayer',doc)};
    if(this.rt.reduced())for(const p of MOTION_PARTS)parts[p]=false;
    this.parts=parts;this.variant=choice('tokenFrame',doc)??'keepsake';
    // (test.9) how her ring is found: Automatic (her art is measured) or the Manual shape and border; Foundry's own dynamic ring is a plain circle
    this.fit=fitOptions({mode:choice('tokenFit',doc),shape:choice('tokenFitShape',doc),border:choice('tokenFitBorder',doc),inset:choice('tokenFitInset',doc)},hasFoundryRing(this.token));this.fitKey=this.fit?JSON.stringify(this.fit):'';this.rimFor=undefined;
    this.frames=parts.frame?frameSet(this.variant):null;this.wingless=isOn('wingless',doc);this.noFallback=this.wingless&&!partOn('wingless','winglessFallback',doc);
    if(this.frames&&!this.frames.ready)this.frames.onReady=()=>this.rt.wake(this);
    this.wakeUp();
  }
  /** HP and conditions: read when they change (hooks), never per frame. */
  readActor(first=false){
    const actor=this.doc.actor,hp=hpOf(actor),T=this.target;
    if(hp){const frac=Math.max(0,Math.min(1,hp.value/hp.max));
      if(!first&&this.hpValue!==undefined){const delta=hp.value-this.hpValue;
        if(delta<0)this.rt.hit(this.token,{sev:Math.min(1,-delta/hp.max*3),fromHp:true});
        else if(delta>0)this.rt.heal(this.token,{k:Math.min(1,.4+delta/hp.max*3),big:delta>=hp.max*.25});}
      this.hpValue=hp.value;this.I.hp=frac;}
    const fear=condition(actor,'frightened');T.fear=fear?Math.min(1,.45+.2*fear):0;
    const ko=!!(condition(actor,'unconscious')||condition(actor,'dying')||actor?.statuses?.has?.('dead'));
    if(!ko&&T.ko>0&&!first)T.wakeAt=now();T.ko=ko?1:0;
    // (v11 phase 2b: the invisibility runtime decides when her portrait drains, and how: v11/invis-runtime.mjs)
    if(this.rt.invis){this.wakeUp();return;}
    const hidden=!!(condition(actor,'hidden')||condition(actor,'invisible')||condition(actor,'undetected'));
    if(first){T.hidden=hidden;if(hidden){const h=this.hiddenRec;h.mode='hide';h.at=now()-5;}}
    else if(hidden!==T.hidden){T.hidden=hidden;this.rt.hidden(this.token,hidden);}
    this.wakeUp();
  }
  wakeUp(){this.awake=true;this.rt.ensureTicker();}
  /** One frame. Returns whether it should keep ticking. */
  tick(t,dt,flight){
    const token=this.token,doc=this.doc,P=this.parts,I=this.I,T=this.target;
    if(!this.rt.current(token)){this.destroy();return false;}
    if(token.mesh!==this.mesh)this.attach();
    if(!this.filter)return false;
    // (test.8) frame off: her own ring's rim mask, looked up when her picture changes (cached per texture)
    {const want=P.frame?null:this.mesh?.texture??NO_PICTURE;if(this.rimFor!==want){this.rimFor=want;this.shape=want?rimTextureOf(want===NO_PICTURE?null:want,undefined,this.fit??null):null;this.filter.setRim(this.shape);this.hasShown=false;}}
    // inputs ----------------------------------------------------------
    busy=false;I.t=t;
    I.fear=ease(I.fear,T.fear,3.2,dt);I.ko=ease(I.ko,T.ko,1.6,dt);
    I.wake=T.wakeAt>=0&&t-T.wakeAt<1.6?(t-T.wakeAt)/1.6:0;if(I.wake>0)busy=true;
    I.afterglow=T.afterglowAt>=0?Math.max(0,1-(t-T.afterglowAt)/8)*Math.min(1,(t-T.afterglowAt)/.6):0;if(I.afterglow>0)busy=true;
    const s=flight;
    if(s&&(s.on||s.blend>.002)){busy=true;
      I.bank=s.bank??0;I.pitch=s.pitch??0;
      const W=I.wing,intensity=s.snapshot?.effective?.intensity??1;W.glow=(s.blend??0)*intensity*(s.feelWingAlpha??1);W.spread=Math.max(0,Math.min(1,s.blend??0));
      // a wing gesture that reads as an emote
      const g=s.snapshot?.requested?.v7?.wingGesture,key=g?`${g.name}:${g.started}`:null;
      if(key!==this.gestureKey){this.gestureKey=key;const e=g&&GESTURE_EMOTES[g.name];if(e)this.rt.emote(token,e);}
    }else{I.bank=ease(I.bank,0,6,dt);I.pitch=ease(I.pitch,0,6,dt);I.wing.glow=ease(I.wing.glow,0,5,dt);}
    // glance: where her bits are looking (read four times a second)
    if(P.glance){
      if(t-this.glanceAt>.25){this.glanceAt=t;let tg=null;try{tg=readBitIntentTarget(doc);}catch{}
        if(tg&&tg!==token&&tg.center&&token.center){const dx=tg.center.x-token.center.x,dy=tg.center.y-token.center.y,l=Math.hypot(dx,dy)||1,g=this.glanceDir??={x:0,y:0};g.x=dx/l;g.y=dy/l;this.glanceTo=g;}
        else this.glanceTo=null;}
      const G=I.glance,to=this.glanceTo;G.x=ease(G.x,to?.x??G.x,4,dt);G.y=ease(G.y,to?.y??G.y,4,dt);G.k=ease(G.k,to?1:0,3,dt);
    }else I.glance.k=0;
    // events (q = seconds since)
    I.hit=ev(this.hitRec,3,t);I.give=ev(this.giveRec,6,t);I.healed=ev(this.healRec,3,t);
    I.emote=ev(this.emoteRec,4.2,t);
    if(I.emote){const r=I.emote;
      // (v11 emotes) with her wings shown the portrait plays its own part; with them off, the whole token plays all ten
      // (12.1.0-beta.1) Wingless with "Wing moments fall back to bits and token" off: her frame does not take them over
      r.full=!this.noFallback&&(this.wingless||!(s&&s.on&&(s.blend??0)>.05&&s.snapshot?.rendering?.wingsActive!==false));
      r.w=r.endAt>=0?1-smooth(unit((t-r.endAt)/r.fade)):1;if(r.w<=0){r.at=-1;I.emote=null;}}
    // (test.7) the ghost follows the invisibility runtime's view: Gone hides her portrait from her owner too
    const h=this.hiddenRec;
    if(h.at>=0){h.q=t-h.at;h.ghost=this.rt.invis?.ghostFor?.(token)??!!(doc.isOwner||game.user?.isGM||token.detectionFilter);if(h.mode==='reveal'&&h.q>1.4){h.at=-1;I.hidden=null;}else{I.hidden=h;if(h.q<1.4||h.mode==='hide'&&h.ghost)busy=true;}}
    else I.hidden=null;
    // sample, then ask for a redraw only when the change can be seen ------------
    let moving=sampleTokenLayer(I,P,this.look,this.variant);
    // (phase 2a) wings off: wounds, persistent damage, dying and mood play on her frame (v11/frame-damage.mjs)
    if(this.rt.frameFx){const F=this.rt.frameFx(token,flight);if(F){const L=this.look,r0=L.n.rim,b0=L.n.bead;moving=applyFrameDamage(L,F,P,I.ko)||moving;if(I.hidden)veilFrameDamage(L,r0,b0);}}
    // (phase 3a) heals, Hero Points, a sustained sigil and her level-up ornaments on her frame (v11/heal-moments.mjs frameMoments)
    if(this.rt.healFx&&!I.hidden)moving=this.rt.healFx(token,this.look)||moving;
    // (test.9) beads ride the middle of her own border at their angle (a square or an oval ring is followed)
    {const S=this.look,pr=this.shape?.profile;if(pr&&S.n.bead)for(let i=0;i<S.n.bead;i++)S.bead[i*4+3]=bandRadiusAt(pr,S.bead[i*4]);}
    const rPx=this.filter.uniforms.uGeo[2]||50;
    if(!this.hasShown||lookDelta(this.look,this.shown,rPx)>=.25||!(moving||busy)&&lookDelta(this.look,this.shown,rPx)>0){
      copyLook(this.look,this.shown);this.hasShown=true;this.filter.setLook(this.shown,this.frames);this.rt.redraw();this.rt.stats.uploads++;
    }
    this.rt.stats.samples++;
    return moving||busy||!!(this.frames&&!this.frames.ready);
  }
  /** Put the filter on her token mesh (and keep it there: a new mesh after a texture change gets it again). */
  attach(){
    const mesh=this.token.mesh;
    this.detach();if(!mesh||mesh.destroyed)return;
    const F=tokenLayerFilterClass();this.filter??=new F();this.filter.mesh=mesh;this.mesh=mesh;this.rimFor=undefined;
    const list=mesh.filters;mesh.filters=list?.length?[...list.filter(f=>f!==this.filter),this.filter]:[this.filter];
    this.hasShown=false;this.wakeUp();this.rt.redraw();
  }
  /** Foundry may hand her mesh a new filter list (a detection filter): ours goes back at the end. */
  keep(){const mesh=this.mesh;if(!mesh||mesh.destroyed||!this.filter)return;const list=mesh.filters;if(!list||!list.includes(this.filter))mesh.filters=list?.length?[...list,this.filter]:[this.filter];}
  detach(){
    const mesh=this.mesh;
    if(mesh&&!mesh.destroyed&&this.filter&&mesh.filters?.includes(this.filter)){const rest=mesh.filters.filter(f=>f!==this.filter);mesh.filters=rest.length?rest:null;}
    this.mesh=null;
  }
  destroy(){this.detach();this.filter?.destroy?.();this.filter=null;this.rt.layers.delete(this.token);this.rt.redraw();}
}

export class TokenLayers{
  /** getState(token) → the flight manager's motion state (or undefined); enabled() → Yvaelle’s Toolbox shows here; reduced() → reduced motion. */
  constructor({getState=()=>null,enabled=()=>true,reduced=()=>false,current=t=>!!t&&!t.destroyed}={}){
    this.getState=getState;this.enabled=enabled;this.reduced=reduced;this.current=current;
    this.layers=new Map();this.ticking=false;this.lastT=now();
    this.damage=new Map();   // token id → {type, at} from the last damage roll aimed at her
    this.stats={ticks:0,samples:0,uploads:0,redraws:0};
  }
  /** Whether a token wears the layer: Yvaelle’s Toolbox on it and the Token layer switch on. */
  wants(token){
    const doc=token?.document;if(this.failed||!doc||token.isPreview||!this.current(token)||!this.enabled())return false;
    let flight=null;try{flight=doc.getFlag?.(ID,'flight');}catch{}
    return !!flight&&isOn('tokenLayer',doc);
  }
  sync(token){
    const has=this.layers.get(token),want=this.wants(token);
    if(want&&!has){try{const L=new Layer(this,token);this.layers.set(token,L);L.attach();}catch(error){this.layers.get(token)?.destroy();this.failed=true;console.warn('Yvaelle’s Toolbox | v11 token layer could not start',error);}}
    else if(!want&&has)has.destroy();
    else if(has)has.readConfig();
  }
  syncAll(){
    for(const token of [...this.layers.keys()])if(!this.wants(token))this.layers.get(token)?.destroy();
    for(const token of globalThis.canvas?.tokens?.placeables??[])this.sync(token);
  }
  layerOf(target){
    if(!target)return null;if(this.layers.has(target))return this.layers.get(target);
    const doc=typeof target==='string'?(()=>{try{return fromUuidSync(target);}catch{return null;}})():docOf(target);
    for(const [t,L] of this.layers)if(t.document===doc||t.document?.id===doc?.id)return L;
    return null;
  }
  wake(L){if(L){L.awake=true;this.ensureTicker();}}
  ensureTicker(){
    if(this.ticking)return;const ticker=globalThis.canvas?.app?.ticker;if(!ticker)return;
    this.ticking=true;this.lastT=now();ticker.add(this.tick,this,-12);
  }
  stopTicker(){if(!this.ticking)return;this.ticking=false;globalThis.canvas?.app?.ticker?.remove(this.tick,this);}
  tick(){
    const t=now(),dt=Math.min(.1,Math.max(0,t-this.lastT));this.lastT=t;this.stats.ticks++;
    let any=false;
    for(const L of this.layers.values()){
      if(!L.awake)continue;
      try{
        // (asleep while nobody can see her: no sampling; she is sampled again when shown)
        const tk=L.token,shown=tk.visible!==false&&tk.mesh?.visible!==false&&tk.mesh?.renderable!==false;
        if(!shown){L.awake=false;continue;}
        L.keep();
        L.awake=L.tick(t,dt,this.getState(tk));any||=L.awake;
      }catch(error){console.error('Yvaelle’s Toolbox | v11 token layer',error);L.destroy();}
    }
    if(!any)this.stopTicker();
  }
  redraw(){const p=globalThis.canvas?.primary;if(p&&'renderDirty' in p)p.renderDirty=true;this.stats.redraws++;}
  /** The flight manager's frame: her flight moves the layer (bank, pitch, wing light). */
  flightTick(states){for(const token of states.keys()){const L=this.layers.get(token);if(L&&!L.awake){L.awake=true;this.ensureTicker();}}}

  /* ---------------- entry points (api.v11.tokenLayer) ---------------- */
  /** A blow: {type:'slashing'|…, dir:[x,y] push direction (unit), sev 0..1}. Without a type, the last damage roll aimed at her (15 s) gives it. */
  hit(target,{type=null,dir=null,sev=.4,fromHp=false}={}){
    const L=this.layerOf(target);if(!L)return false;const r=L.hitRec,t=now();
    // (phase 2a: the damage runtime calls hit() with the blow's type and direction as her HP drops; the layer's own HP read then adds nothing)
    if(fromHp&&r.at>=0&&t-r.at<.5&&r.explicit)return true;r.explicit=!fromHp;
    if(!type){const d=this.damage.get(L.doc.id);if(d&&t-d.at<15){type=d.type;this.damage.delete(L.doc.id);}}
    if(!dir){const attacker=globalThis.game?.combat?.combatant?.token?.object,tk=L.token;
      if(attacker&&attacker!==tk&&attacker.center&&tk.center){const dx=tk.center.x-attacker.center.x,dy=tk.center.y-attacker.center.y,l=Math.hypot(dx,dy)||1;dir=[dx/l,dy/l];}else dir=[-1,0];}
    r.at=t;r.type=type&&DAMAGE_TINT[type]?type:'';r.dir[0]=dir[0];r.dir[1]=dir[1];r.sev=Math.max(0,Math.min(1,sev));L.wakeUp();return true;
  }
  /** She is healed: {k 0..1, big: warm afterglow}. */
  heal(target,{k=1,big=false}={}){const L=this.layerOf(target);if(!L)return false;const t=now();L.healRec.at=t;L.healRec.k=k;if(big)L.target.afterglowAt=t+.4;L.wakeUp();return true;}
  /** She casts a heal: {n actions 1..3, gather seconds}. */
  give(target,{n=2,gather=.7}={}){const L=this.layerOf(target);if(!L)return false;const r=L.giveRec;r.at=now();r.n=n;r.gather=gather;L.wakeUp();return true;}
  /** An emote: the portrait's own (bow, curious, pray, sigh, shrug, startle) while her wings show, all ten
   * (with laugh, wave, cheer, comfort) on the whole token when they are off; look {x,y} (token-local, unit)
   * toward the ally (comfort) or what she looks at (curious); elapsed: seconds it has already played. */
  emote(target,name,look=null,{elapsed=0}={}){const L=this.layerOf(target);if(!L||!EMOTES_FULL.includes(name))return false;const r=L.emoteRec;r.at=now()-Math.max(0,elapsed);r.name=name;r.look.x=look?.x??-1;r.look.y=look?.y??0;r.endAt=-1;r.w=1;L.wakeUp();return true;}
  /** An emote gives way (v11/emote-runtime.mjs: a blow, movement): it eases back over `fade` seconds. */
  emoteEnd(target,fade=.3){const L=this.layerOf(target);if(!L)return false;const r=L.emoteRec;if(r.at<0||r.endAt>=0)return false;r.endAt=now();r.fade=Math.max(.05,fade);L.wakeUp();return true;}
  /** Hidden on or off: drains to an outline (owner and GM keep a ghost), and back. */
  hidden(target,on){const L=this.layerOf(target);if(!L)return false;const r=L.hiddenRec;r.mode=on?'hide':'reveal';r.at=now();L.wakeUp();return true;}
  /** Her tech cloak: the invisibility runtime plays it (look a|b|c|classic, sweep left|right|top|bottom); without one, the classic drain. */
  cloak(target,on,{look=null,sweep=null,T=null}={}){return this.invis?this.invis.cloak(target,on,{look,sweep,T}):this.hidden(target,on);}
  /** Set her hidden look at once, without the drain or the reveal: 'held' (drained, ghost for owner/GM) or 'none'.
   * (The invisibility runtime swaps between this and its own filter mid-sweep.) */
  veil(target,state){
    const L=this.layerOf(target);if(!L||!L.parts?.hidden)return false;const r=L.hiddenRec;
    if(state==='held'){r.mode='hide';r.at=now()-5;}else{r.at=-1;L.I.hidden=null;}
    L.hasShown=false;L.wakeUp();return true;
  }
  /** Can her token layer show the hidden look (layer on, its Hidden part on)? */
  canVeil(target){const L=this.layerOf(target);return !!(L&&L.parts?.hidden&&L.filter);}
  /** A light near her for ms (heals, prayer, an ally's bloom): {x,y} token-local radii, colour 0..1, a, r. */
  light(target,{x=0,y=1,color=[1,.77,.5],a=.2,r=1.2,ms=1200}={}){
    const L=this.layerOf(target);if(!L)return false;const rec={x,y,color,a,r,until:now()+ms/1000};
    const list=L.I.lights===NO_LIGHTS?[]:L.I.lights;list.push(rec);L.I.lights=list;
    clearTimeout(L.lightTimer);L.lightTimer=setTimeout(()=>{const t=now();const left=list.filter(l=>l.until>t);L.I.lights=left.length?left:NO_LIGHTS;L.wakeUp();},ms+20);
    L.wakeUp();return true;
  }
  /** Remember the damage type of a PF2e damage roll aimed at her. */
  noteDamage(message){
    try{const ctx=message?.flags?.pf2e?.context;if(!ctx||!['damage-roll','damage-taken'].includes(ctx.type))return;
      const type=message.rolls?.[0]?.instances?.[0]?.type??message.rolls?.[0]?.options?.damageType??null;if(!type)return;
      const ids=[ctx.target?.token,...(ctx.targets??[]).map(x=>x?.token)].filter(Boolean).map(u=>String(u).split('.').pop());
      for(const id of ids)this.damage.set(id,{type,at:now()});}catch{}
  }
  /** Hooks: the layer follows her flags, her actor and the settings, and nothing else. */
  install(){
    if(this.installed||!globalThis.Hooks)return;this.installed=true;
    Hooks.on('canvasReady',()=>{for(const L of [...this.layers.values()])L.destroy();this.syncAll();});
    Hooks.on('canvasTearDown',()=>{for(const L of [...this.layers.values()])L.destroy();this.stopTicker();});
    Hooks.on('drawToken',token=>{queueMicrotask(()=>this.sync(token));});
    // (a refresh can bring her back into view, or hand her mesh a new filter list: one look, then sleep again if still)
    Hooks.on('refreshToken',token=>{const L=this.layers.get(token);if(L){if(token.mesh!==L.mesh)L.attach();else L.keep();if(!L.awake)this.wake(L);}});
    Hooks.on('updateToken',(doc,changes)=>{
      const token=doc.object;if(!token)return;
      if(changes?.flags?.[ID]!==undefined||changes?.texture!==undefined)this.sync(token);
    });
    Hooks.on('deleteToken',doc=>{const L=doc.object&&this.layers.get(doc.object);L?.destroy();});
    const actorChanged=actor=>{for(const L of this.layers.values())if(L.doc.actor===actor||L.doc.actorId===actor?.id)L.readActor();};
    Hooks.on('updateActor',actor=>actorChanged(actor));
    for(const hook of ['createItem','updateItem','deleteItem'])Hooks.on(hook,item=>{if(item?.type==='condition'||item?.type==='effect')actorChanged(item.parent);});
    for(const hook of ['createActiveEffect','deleteActiveEffect'])Hooks.on(hook,effect=>actorChanged(effect?.parent));
    Hooks.on('createChatMessage',message=>this.noteDamage(message));
    Hooks.on('filamentFlightSettingsChanged',()=>this.syncAll());
  }
  destroy(){for(const L of [...this.layers.values()])L.destroy();this.stopTicker();}
}
export {FEATURES};
