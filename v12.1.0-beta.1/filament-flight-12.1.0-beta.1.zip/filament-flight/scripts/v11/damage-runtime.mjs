/** Yvaelle’s Toolbox v11 · Damage runtime: wounds, persistent damage, dying stages,
 * low-HP fatigue and mood weather on her tokens (Foundry glue).
 *
 * What it reads (all synced, so every client derives the same looks):
 *  - PF2e damage-roll and applied-damage chat messages aimed at her: the type
 *    of the next blow (damage-events.mjs);
 *  - her HP drop (the same updateActor that drives Bruised light): the blow
 *    itself, its direction, and a heal's size (afterglow);
 *  - her actor's persistent damage, dying value and conditions (frightened,
 *    sickened, doomed, wounded, quickened or hasted);
 *  - the recovery check's flat-check message (its outcome).
 * What it gives the renderer each frame:
 *  - wingVisual(): the visual profile with a small `v11dmg` state on it (or the
 *    profile untouched when nothing shows: zero idle cost), drawn by the wing
 *    rig through its paletteAt colour hook and a few strokes;
 *  - feel(): the beat, lift, flex and bit tweaks for the flight feel;
 *  - frame(): the same moment for her token layer when her wings are off.
 * Every feature and part obeys its switch in features.mjs. */
import {isOn,partOn,partsOf,choice} from './features.mjs?v=12.1.0-beta.1';
import {readDamageMessage,readRecoveryCheck,dyingValue,pf2eTypeColor,warmTypeColors,woundLookOf,woundPart,persistLookOf} from './damage-events.mjs?v=12.1.0-beta.1';
import {createDamageState,noteBlow,setPersistent,setDying,noteRecovery,setMood,moodFor,sampleDamage,applyDamageFeel,withDamageVisual,followFatigue,fatigueTarget,applyHeldPhase} from './damage-state.mjs?v=12.1.0-beta.1';
import {readPersistentDamageTypes} from '../condition-response.mjs?v=12.1.0-beta.1';

const ID='filament-flight';
const clock=()=>performance.now()/1000;
const TYPE_MS=15000;
const FRAME_FPS=12;

function condition(actor,slug){
  try{
    const c=actor?.getCondition?.(slug);if(c)return Number(c.value)||1;
    if(actor?.hasCondition?.(slug))return 1;
    for(const it of actor?.itemTypes?.condition??[])if(it.slug===slug)return Number(it.value)||1;
  }catch{}
  return 0;
}
const hasEffect=(actor,re)=>{try{for(const it of actor?.itemTypes?.effect??[])if(re.test(it.slug??it.system?.slug??''))return true;}catch{}return false;};

/** One token's damage record. */
class Record{
  constructor(rt,doc){this.rt=rt;this.doc=doc;this.S=createDamageState();this.parts=null;this.cond={};this.hp=1;this.hpValue=null;this.afterglowAt=-1e9;this.fatigue={a:0,k:0};this.fatigueAt=clock();this.dead=false;this.readParts();this.readActor(true);}
  /** The switches (read when settings or her flags change, never per frame). */
  readParts(){
    const doc=this.doc;
    this.parts={wounds:partsOf('wounds',doc),persistent:partsOf('persistent',doc),dyingStages:partsOf('dyingStages',doc),moodWeather:isOn('moodWeather',doc),
      mood:partsOf('moodWeather',doc),fatigue:isOn('lowHpFatigue',doc),elec:choice('elecStyle',doc)==='a'?'a':'b'};
    this.parts.wounds.elec=this.parts.elec;
    this.wingless=isOn('wingless',doc);
    // (12.1.0-beta.1) its part "Wing moments fall back to bits and token": off, a moment her wings would carry is not shown at all
    this.fallback=partOn('wingless','winglessFallback',doc)!==false;
  }
  readActor(first=false){
    const actor=this.doc.actor;if(!actor)return;const now=clock(),S=this.S;
    const hp=actor.system?.attributes?.hp,v=Number(hp?.value),m=Number(hp?.max);
    if(Number.isFinite(v)&&m>0){
      if(!first&&this.hpValue!=null&&v>this.hpValue&&v-this.hpValue>=m*.25)this.afterglowAt=now;
      this.hpValue=v;this.hp=Math.max(0,Math.min(1,v/m));}
    this.dead=!!actor.statuses?.has?.('dead');
    setDying(S,dyingValue(actor),now,{dead:this.dead});
    let types=[];try{types=readPersistentDamageTypes(actor);}catch{}
    setPersistent(S,types,first?now-30:now,t=>pf2eTypeColor(t,undefined,{probe:false}));
    if(first)for(const x of S.persist)x.at=now-30;      // already burning when we arrive: no fade-in
    const c=this.cond;c.frightened=condition(actor,'frightened');c.sickened=condition(actor,'sickened');c.doomed=condition(actor,'doomed');c.wounded=condition(actor,'wounded');
    c.quickened=condition(actor,'quickened')||hasEffect(actor,/haste/);
    this.rt.wake(this);
  }
  /** A blow landed (her HP dropped): type from the latest damage message aimed at her. */
  blow({type,dir,sev}){
    const now=clock();
    noteBlow(this.S,{type,at:now,dir,elec:this.parts.elec,css:type&&woundLookOf(type)==='other'?pf2eTypeColor(type,undefined,{probe:false}):null});   // (test.7: never a style probe on the blow's frame)
    this.rt.wake(this);
  }
  /** This frame's state (or null). */
  sample(now,{moving=true}={}){
    const P=this.parts,S=this.S;
    // mood weather: what her state calls for now (each mood a switch)
    if(P.moodWeather)setMood(S,moodFor(this.cond,now-this.afterglowAt,P.mood),now);
    const D=sampleDamage(S,now,P,{moving});
    // low-HP fatigue
    const dt=Math.min(.1,Math.max(0,now-this.fatigueAt));this.fatigueAt=now;
    const target=P.fatigue&&!this.dead&&(this.hpValue??1)>0?fatigueTarget(this.hp):0;
    const f=target>0||this.fatigue.k>0?followFatigue(this.fatigue,target,dt):0;
    this.f=f;this.D=D;
    return D;
  }
  get busy(){const S=this.S,c=this.cond;return !!(S.wound||(this.parts.moodWeather&&(c.frightened||c.sickened||c.doomed||c.wounded>=2||c.quickened))||S.persist.length||S.dying.level>0||S.dying.healAt>=0||S.mood.to!=='normal'||S.mood.from!=='normal'||this.fatigue.k>0||(this.parts.fatigue&&this.hp<.26)||clock()-this.afterglowAt<40);}
}

export class DamageRuntime{
  constructor(){this.records=new Map();this.types=new Map();this.stats={samples:0,blows:0};this.installed=false;this.tokenLayers=null;}
  /** Only her tokens (Yvaelle’s Toolbox on them) get a record, created on first need. */
  recordOf(token,create=true){
    const doc=token?.document??token;if(!doc?.id)return null;
    let r=this.records.get(doc.id);if(r&&r.doc!==doc){r.doc=doc;r.readParts();}
    if(!r&&create){let flight=null;try{flight=doc.getFlag?.(ID,'flight');}catch{}if(!flight)return null;r=new Record(this,doc);this.records.set(doc.id,r);}
    return r??null;
  }
  wake(){}   // (install: wakes her token layer)
  /** The type of the latest damage message aimed at this token (15 s), or ''. */
  typeFor(doc){
    const now=Date.now();for(const key of [doc?.id,doc?.actor?.uuid,doc?.actorId,doc?.actor?.id]){if(!key)continue;const r=this.types.get(key);if(r&&now-r.at<TYPE_MS)return r.type;}
    return '';
  }
  noteMessage(message){
    const d=readDamageMessage(message);
    // (test.7) a type with no look of its own has its PF2e colour read at the next idle moment, before the blow lands
    if(d&&woundLookOf(d.type)==='other'&&Object.hasOwn(globalThis.CONFIG?.PF2E?.damageTypes??{},d.type))warmTypeColors([d.type]);
    if(d){const at=Date.now();for(const k of [...d.tokens,...d.actors])this.types.set(k,{type:d.type,at});if(this.types.size>128)for(const [k,v] of this.types)if(at-v.at>60000)this.types.delete(k);return;}
    const rc=readRecoveryCheck(message);
    if(rc){const now=clock();for(const r of this.records.values()){const a=r.doc.actor;if(rc.token&&r.doc.id===rc.token||rc.actor&&(a?.id===rc.actor||a?.uuid===rc.actor)){noteRecovery(r.S,rc.success,now);this.wake(r);}}}
  }
  /** Her HP dropped (flight-feel's hit record): type and direction for the wing and the portrait. Returns the type. */
  hit(token,{dx=0,dy=0,severity=.4}={}){
    const doc=token?.document;const type=this.typeFor(doc);this.stats.blows++;
    const l=Math.hypot(dx,dy),dir=l>0?[dx/l,dy/l]:null;
    const r=this.recordOf(token);
    if(r&&isOn('wounds',doc)){r.readParts();r.blow({type,dir,sev:severity});}
    // her portrait recoils and tints in step (the token layer's own entry point)
    try{(this.tokenLayers??globalThis.game?.modules?.get?.(ID)?.api?.v11?.tokenLayer)?.hit?.(token,{type:type||null,dir:dir??undefined,sev:severity});}catch{}
    return type;
  }
  /** The wing rig's visual profile for this frame (pose-renderer). Untouched when nothing shows. */
  wingVisual(token,visual,{moving=true}={}){
    const r=this.records.get(token?.document?.id);if(!r||!r.busy)return visual;
    const now=clock(),D=r.sample(now,{moving});this.stats.samples++;
    return withDamageVisual(visual,D,r.f??0);
  }
  /** The struck wing's held phase (mental), once the frame's wing phase is known. */
  holdPhase(token,visual,phase){const D=visual?.v11dmg;if(!D)return;const r=this.records.get(token?.document?.id);if(r)applyHeldPhase(r.S,D,phase,clock());}
  /** The flight feel's output for this frame (flight-feel-runtime, before composeFeel). */
  feel(token,out,{size=100,turns=0}={}){
    const r=this.records.get(token?.document?.id);if(!r||!r.busy)return;
    const now=clock(),D=r.D!==undefined&&r.sampledAt===now?r.D:r.sample(now);r.sampledAt=now;
    applyDamageFeel(D,out,{size,fatigue:r.f??0,t:now,turns});
  }
  /** Her wingless frame: the same moment for the token layer (frame painters). */
  frame(token,s=null){
    const r=this.records.get(token?.document?.id);if(!r||!r.busy)return null;
    // only while her wings are off (Wingless mode, or no wings shown): otherwise the wings carry it
    const wingsShown=!!s?.snapshot?.rendering?.wingsActive&&(s.blend??1)>.05;
    if(!r.wingless&&wingsShown)return null;
    if(r.wingless&&r.fallback===false)return null;
    // (long-running looks on the frame step at 12 fps: each step is one canvas redraw, so a persistent
    // ember or a dying stage costs ~12 redraws a second, not one every display frame; a blow stays smooth)
    let now=clock();if(!r.S.wound)now=Math.floor(now*FRAME_FPS)/FRAME_FPS;
    const D=r.sampledAt===now?r.D:r.sample(now);r.sampledAt=now;
    const F=r.frameRec??={D:null,f:0};F.D=D;F.f=r.f??0;return D?F:null;
  }
  install({tokenLayers=null}={}){
    this.tokenLayers=tokenLayers?{hit:(t,o)=>tokenLayers.hit(t,o)}:null;
    if(tokenLayers){tokenLayers.frameFx=(token,s)=>this.frame(token,s);
      this.wake=r=>{try{tokenLayers.wake(tokenLayers.layerOf(r?.doc?.object));}catch{}};}
    if(this.installed||!globalThis.Hooks)return;this.installed=true;
    Hooks.on('createChatMessage',m=>{try{this.noteMessage(m);}catch{}});
    // (test.7) every damage type the system knows has its colour read once, at an idle moment after load
    const warm=()=>{try{warmTypeColors(Object.keys(globalThis.CONFIG?.PF2E?.damageTypes??{}).filter(t=>woundLookOf(t)==='other'||persistLookOf(t)==='fallback'));}catch{}};
    if(globalThis.game?.ready)warm();else Hooks.once?.('ready',warm);
    const actorChanged=actor=>{if(!actor)return;for(const r of this.records.values())if(r.doc.actor===actor||r.doc.actorId===actor.id)r.readActor();
      // a token we have not met yet (her first persistent damage, her first fall)
      for(const t of actor.getActiveTokens?.()??[])if(!this.records.has(t.document?.id))this.recordOf(t);};
    Hooks.on('updateActor',a=>actorChanged(a));
    for(const h of ['createItem','updateItem','deleteItem'])Hooks.on(h,item=>{if(item?.type==='condition'||item?.type==='effect')actorChanged(item.parent);});
    Hooks.on('updateToken',(doc,changes)=>{const r=this.records.get(doc.id);if(r&&changes?.flags?.[ID]!==undefined)r.readParts();});
    Hooks.on('deleteToken',doc=>this.records.delete(doc.id));
    Hooks.on('canvasReady',()=>{this.records.clear();for(const t of globalThis.canvas?.tokens?.placeables??[])this.recordOf(t);});
    Hooks.on('filamentFlightSettingsChanged',()=>{for(const r of this.records.values())r.readParts();});
  }
}
/** The one runtime (flight.mjs installs its hooks). */
export const damageRuntime=new DamageRuntime();
