import {paintBitPreview,releaseBitPreview} from './compact-animation-preview.mjs?v=12.1.0-beta.1';

/** One finite, local movement guide. Never deploys bits, writes flags or plays audio. */
export function startCompactPreview(canvas,{count=4,program='orbit',radius=1,strength=.75,speed=1,personality=.35,reduced=false,v7=null,v9=null,quality='high',fps=24}={}) {
  const ctx=canvas?.getContext('2d');if(!ctx)return ()=>{};
  const view=canvas.ownerDocument.defaultView;let frame=0,stopped=false,started=null,last=-Infinity;
  const draw=time=>paintBitPreview(canvas,{id:program,count,elapsed:time*1000,radius,strength,speed,personality,animated:!reduced,background:'transparent',v7,v9,quality});
  const stop=()=>{stopped=true;if(frame)view.cancelAnimationFrame(frame);canvas.dataset.playing='false';releaseBitPreview(canvas);};
  canvas.dataset.playing='true';draw(0);
  if(reduced||strength<=0){stop();return stop;}
  const tick=now=>{
    if(stopped)return;
    if(!canvas.isConnected||canvas.ownerDocument.hidden){stop();return;}
    started??=now;
    if(now-started>=6000){stop();return;}
    if(now-last>=1000/Math.max(1,Math.min(24,fps))){last=now;draw((now-started)/1000);}
    frame=view.requestAnimationFrame(tick);
  };
  frame=view.requestAnimationFrame(tick);return stop;
}
