/** V8 instrument travel and temporary work posture. Pure geometry on frames;
 * route callbacks are used only by command preflight. No document writes,
 * timers, springs, collision queries, or random choices in a render sample. */
import {sampleInstrumentTransit} from './bit-group-motion.mjs?v=12.1.0-beta.1';
import {POSES,weightsFor,mixWeights} from './poses.mjs?v=12.1.0-beta.1';

const clamp=(n,lo=0,hi=1)=>Math.max(lo,Math.min(hi,Number.isFinite(n)?n:lo));
const smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const quintic=n=>{n=clamp(n);return n*n*n*(10+n*(-15+6*n));};
const finitePoint=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
const distance=(a,b)=>Math.hypot(b.x-a.x,b.y-a.y);
const point=p=>({x:p.x,y:p.y});
const TAU=Math.PI*2;
const angleDifference=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
const routeCache=new WeakMap();

/** Bounded shortest visible route. Supply collision and CURRENT-visibility
 * callbacks, plus already-known safe candidate points, from command capture.
 * An unavailable adapter fails closed; this helper never inspects hidden walls.
 * A blocked result is explicit and must not fall back to crossing the obstacle.
 */
export function planBitRoute(from,to,{blocked,visible,waypoints=[],maxCandidates=18,maxChecks=160,maxDetour=3}={}){
  const fail=reason=>({points:[],length:0,blocked:true,reason});
  if(!finitePoint(from)||!finitePoint(to))return fail('Invalid instrument destination.');
  if(typeof blocked!=='function'||typeof visible!=='function')return fail('Scene route checks are unavailable.');
  const safe=p=>{try{return visible(p)===true;}catch{return false;}};
  if(!safe(from)||!safe(to))return fail('Choose a visible instrument destination.');
  let checks=0;maxChecks=Math.round(clamp(maxChecks,1,320));
  const clear=(a,b)=>{
    if(++checks>maxChecks)return false;
    try{if(blocked(a,b)!==false)return false;}catch{return false;}
    // Visibility clips the route as well as its destination. Checking a few
    // evenly spaced points prevents detours through unexplored rooms.
    for(let n=1;n<7;n++)if(!safe({x:a.x+(b.x-a.x)*n/7,y:a.y+(b.y-a.y)*n/7}))return false;
    return true;
  };
  if(clear(from,to))return {points:[point(from),point(to)],length:distance(from,to),blocked:false,checks};
  maxCandidates=Math.round(clamp(maxCandidates,0,22));
  const limit=Math.max(1,distance(from,to))*clamp(maxDetour,1,6);
  const candidates=waypoints.filter(finitePoint).filter(safe)
    .filter(p=>distance(from,p)+distance(p,to)<=limit)
    .sort((a,b)=>distance(from,a)+distance(a,to)-distance(from,b)-distance(b,to))
    .filter((p,i,a)=>a.findIndex(q=>distance(p,q)<.01)===i).slice(0,maxCandidates).map(point);
  const nodes=[point(from),point(to),...candidates],cost=nodes.map(()=>Infinity),parent=nodes.map(()=>-1),visited=new Set(),edges=new Map();cost[0]=0;
  // Lazy edge checks prioritize the destination and nearest forward candidates.
  // At most 24 nodes and 320 checks, regardless of scene wall count.
  for(let pass=0;pass<nodes.length;pass++){
    let current=-1;
    for(let i=0;i<nodes.length;i++)if(!visited.has(i)&&(current<0||cost[i]<cost[current]))current=i;
    if(current<0||!Number.isFinite(cost[current])||checks>=maxChecks)break;
    if(current===1)break;visited.add(current);
    const order=nodes.map((_,i)=>i).filter(i=>i!==current&&!visited.has(i))
      .sort((a,b)=>(a===1?-1:b===1?1:distance(nodes[current],nodes[a])+distance(nodes[a],to)-distance(nodes[current],nodes[b])-distance(nodes[b],to)));
    for(const next of order){
      const step=distance(nodes[current],nodes[next]),candidate=cost[current]+step;
      if(candidate>=cost[next]||candidate+distance(nodes[next],to)>limit)continue;
      const key=[current,next].sort((a,b)=>a-b).join(':');
      if(!edges.has(key))edges.set(key,clear(nodes[current],nodes[next]));
      if(edges.get(key)){cost[next]=candidate;parent[next]=current;}
      if(checks>=maxChecks)break;
    }
  }
  if(!Number.isFinite(cost[1]))return fail(checks>=maxChecks?'No short visible route was found.':'The instrument route is blocked.');
  const points=[];for(let i=1;i>=0;i=parent[i]){points.unshift(nodes[i]);if(i===0)break;}
  return {points,length:cost[1],blocked:false,checks};
}

/** Compile a saved route once per command. A routed corner has a short rounded
 * bend ONLY if the command's adapters verify its sampled curve. A refused bend
 * becomes a deliberate near-stop at the corner, never an unchecked shortcut.
 */
export function compileBitRoute(input,{blocked,visible,rounding=12}={}){
  const points=(Array.isArray(input)?input:input?.points??[]).filter(finitePoint).slice(0,24).map(point);
  if(points.length<2)return {points,length:0,lengths:[],corners:[]};
  const out=[points[0]],corners=[];
  const safe=(a,b)=>{
    if(typeof blocked!=='function'||typeof visible!=='function')return false;
    try{return blocked(a,b)===false&&visible(a)===true&&visible(b)===true;}catch{return false;}
  };
  for(let i=1;i<points.length-1;i++){
    const a=points[i-1],b=points[i],c=points[i+1],ab=distance(a,b),bc=distance(b,c),r=Math.min(clamp(rounding,0,100),ab*.18,bc*.18);
    const incoming={x:b.x+(a.x-b.x)*r/(ab||1),y:b.y+(a.y-b.y)*r/(ab||1)},outgoing={x:b.x+(c.x-b.x)*r/(bc||1),y:b.y+(c.y-b.y)*r/(bc||1)};
    const curve=Array.from({length:7},(_,n)=>{const p=n/6,q=1-p;return {x:q*q*incoming.x+2*q*p*b.x+p*p*outgoing.x,y:q*q*incoming.y+2*q*p*b.y+p*p*outgoing.y};});
    if(r>.01&&curve.every((p,n)=>n===0||safe(curve[n-1],p)))out.push(...curve);
    else{out.push(b);corners.push(out.length-1);}
  }
  out.push(points.at(-1));
  const lengths=[0];for(let i=1;i<out.length;i++)lengths.push(lengths.at(-1)+distance(out[i-1],out[i]));
  return {points:out,length:lengths.at(-1),lengths,corners};
}

function pathSample(route,p){
  const points=route.points,lengths=route.lengths,total=route.length;
  if(!total)return {...points.at(-1),heading:0,turn:0};
  let at=clamp(p)*total,rate=1;
  if(route.corners?.length){
    // Unrounded wall corners need a near-stop, rather than an abrupt change
    // of direction at full speed. Each interval remains position-continuous.
    const stops=[0,...route.corners.map(i=>lengths[i]),total];
    for(let i=1;i<stops.length;i++)if(at<=stops[i]){
      const start=stops[i-1],span=stops[i]-start,u=span?clamp((at-start)/span):1;
      at=start+span*quintic(u);rate=30*u*u*(1-u)*(1-u);break;
    }
  }
  let i=1;
  while(i<points.length-1&&lengths[i]<at)i++;
  const a=points[i-1],b=points[i],length=lengths[i]-lengths[i-1],q=length?(at-lengths[i-1])/length:1;
  let heading=Math.atan2(b.y-a.y,b.x-a.x);
  // Orientation anticipates the next leg near a corner. Position follows only
  // validated route edges; it never cuts through the wall to smooth a turn.
  let turn=0;
  const tangent=heading;
  if(i<points.length-1){const c=points[i+1],next=Math.atan2(c.y-b.y,c.x-b.x),bend=angleDifference(tangent,next)*smooth((q-.58)/.42);turn=bend;heading+=bend*.5;}
  if(i>1){const before=points[i-2],previous=Math.atan2(a.y-before.y,a.x-before.x),bend=angleDifference(previous,tangent)*(1-smooth(q/.42));turn+=bend;heading-=bend*.5;}
  return {x:a.x+(b.x-a.x)*clamp(q),y:a.y+(b.y-a.y)*clamp(q),heading,turn,rate};
}
function compiledRoute(route){
  if(!route||typeof route!=='object')return null;
  let compiled=route;
  if(Array.isArray(route)||!Array.isArray(route.lengths)){
    compiled=routeCache.get(route);if(!compiled){compiled=compileBitRoute(route);routeCache.set(route,compiled);}
  }
  return compiled?.points?.length>=2?compiled:null;
}

/** Controlled acceleration and braking with exact endpoints, no oscillation.
 * p is LINEAR elapsed progress. Routes should be compiled once at submission.
 * Plain saved point arrays are supported without any scene queries. */
export function sampleWeightedTransit(from,to,p,{index=0,size=100,duration=900,enabled=true,reduced=false,route=null,fromRotation=0,toRotation=fromRotation}={}){
  p=clamp(p);size=Math.max(1,Number.isFinite(size)?size:100);duration=Math.max(1,Number.isFinite(duration)?duration:900);
  if(!finitePoint(from)||!finitePoint(to))return {x:0,y:0,rotation:0,bank:0,activity:0,settling:0,speed:0};
  const compiled=compiledRoute(route);
  if(!enabled||reduced){
    // Weight and obstacle avoidance are independent choices. A validated route
    // must still be followed when the player turns weighty animation off.
    const position=compiled?pathSample(compiled,reduced?p:smooth(p)):sampleInstrumentTransit(from,to,p,{index,size,reduced});
    return {...position,rotation:fromRotation+angleDifference(fromRotation,toRotation)*smooth(p),bank:0,activity:0,settling:0,speed:0};
  }
  const delay=.012*(Math.abs(index)%4),clock=clamp((p-delay)/(1-delay)),q=quintic(clock);
  let sample,length;
  if(compiled){
      sample=pathSample(compiled,q);length=compiled.length;
      // Following targets may move while the instrument is en route. Preserve
      // captured departure and match the CURRENT arrival by a bounded envelope.
      const first=compiled.points[0],last=compiled.points.at(-1),a=1-q;
      sample.x+=(from.x-first.x)*a+(to.x-last.x)*q;sample.y+=(from.y-first.y)*a+(to.y-last.y)*q;
  }
  if(!sample){
    const dx=to.x-from.x,dy=to.y-from.y;length=Math.hypot(dx,dy);
    const nx=length?-dy/length:0,ny=length?dx/length:0,bend=Math.min(size*.085,length*.055)*[-1,1,-.65,.65][Math.abs(index)%4];
    const envelope=Math.sin(Math.PI*q)**2,derivative=Math.PI*Math.sin(TAU*q)*bend;
    sample={x:from.x+dx*q+nx*bend*envelope,y:from.y+dy*q+ny*bend*envelope,heading:Math.atan2(dy+ny*derivative,dx+nx*derivative),turn:length?derivative/length:0};
  }
  const velocity=30*clock*clock*(1-clock)*(1-clock)/(1-delay)*(sample.rate??1),activity=length?clamp(velocity/1.875):0;
  const bank=clamp(sample.turn,-1,1)*.16*activity;
  const travelRotation=fromRotation+angleDifference(fromRotation,sample.heading)*activity*.30+bank;
  const braking=smooth((clock-.62)/.38),rotation=travelRotation+angleDifference(travelRotation,toRotation)*braking;
  return {x:p===0?from.x:p===1?to.x:sample.x,y:p===0?from.y:p===1?to.y:sample.y,
    rotation:p===0?fromRotation:p===1?toRotation:rotation,bank,activity,settling:braking*(1-activity)*(1-smooth((clock-.94)/.06)),speed:length*velocity/(duration/1000)};
}

const workStates=new WeakMap();
const TRAILING=weightsFor('trailing');
const restrictedIds=new Set(['paralyzed','unconscious','dead','prone','petrified']);
function restricted(snapshot){
  const r=snapshot.conditionResponse;
  if(snapshot.health?.incapacitated||snapshot.visual?.incapacitated||r?.collapse&&r.collapse.phase!=='awake')return true;
  if(Math.max(r?.rawLevels?.stunned??0,r?.targetLevels?.stunned??0)>=3)return true;
  return Object.entries({...r?.rawLevels,...r?.targetLevels}).some(([id,amount])=>restrictedIds.has(id)&&amount>0)
    ||r?.active?.some(c=>restrictedIds.has(c.id))||snapshot.effective?.pose==='collapsed';
}
function eligible(event){
  return event&&event.status!=='queued'&&event.status!=='returning'&&event.status!=='finished'&&event.conditionPausedAt==null
    &&(event.kind==='treatment'||['areaScan','creatureScan'].includes(event.utility?.mode));
}
function sideOf(event,source,token){
  const target=event.utility?.center??event.utility?.point??event.targetCenter??event.targetPoint;
  if(!finitePoint(target)||!finitePoint(source))return 0;
  const angle=(token?.document?.rotation??0)*Math.PI/180,dx=target.x-source.x,dy=target.y-source.y;
  const localX=dx*Math.cos(angle)+dy*Math.sin(angle);
  return Math.abs(localX)<1?0:localX<0?-1:1;
}
/** Forget local posture memory on token/module teardown. No saved state changes. */
export function clearWorkingPosture(token){if(token&&typeof token==='object')workStates.delete(token);}

/** Render-only work modifier. A WeakMap gives each live token one bounded
 * envelope, including a smooth release after an event ends. Explicit newer
 * pose commands and actor restrictions immediately take precedence.
 * Call AFTER bit preparation, BEFORE resolving light/decorating the snapshot. */
export function applyWorkingPosture(snapshot,{events=[],now=0,token,source,poseRevision}={},config={}){
  if(!snapshot||!token||typeof token!=='object')return snapshot;
  if(config.v8WorkingPosture===false||snapshot.effective?.reducedMotion||config.reduced||config.enabled===false||!snapshot.rendering?.active||restricted(snapshot)){
    clearWorkingPosture(token);return snapshot;
  }
  const active=events.filter(eligible).sort((a,b)=>(a.started??now)-(b.started??now))[0];
  let memory=workStates.get(token);
  const signature=active?`${active.id??active.kind??'scan'}:${active.started??0}`:null;
  if(!memory&&!active)return snapshot;
  if(!memory){memory={amount:0,at:now,signature,started:active.started??now,pose:snapshot.effective?.pose,poseRevision,side:sideOf(active,source,token),suppressed:false};workStates.set(token,memory);}
  if(active&&signature!==memory.signature){memory.signature=signature;memory.started=active.started??now;memory.pose=snapshot.effective?.pose;memory.poseRevision=poseRevision;memory.side=sideOf(active,source,token);memory.suppressed=false;}
  const newerPose=(snapshot.poseTransition?.started??-Infinity)>memory.started||(snapshot.temporaryPose?.active&&(snapshot.temporaryPose.started??-Infinity)>memory.started)
    ||active&&snapshot.effective?.pose!==memory.pose||poseRevision!=null&&memory.poseRevision!=null&&poseRevision!==memory.poseRevision;
  if(newerPose){memory.suppressed=true;memory.amount=0;memory.at=now;return snapshot;}
  const target=active&&!memory.suppressed?1:0,dt=clamp(now-memory.at,0,10000)/1000;memory.at=now;
  memory.amount+= (target-memory.amount)*(1-Math.exp(-dt*(target?5.6:4.4)));
  if(!target&&memory.amount<.0001){clearWorkingPosture(token);return snapshot;}
  const amount=clamp(memory.amount),o=snapshot.options??{};
  if(amount<.000001)return snapshot;
  return {...snapshot,workingPosture:{amount,side:memory.side,started:memory.started,scan:active?.kind!=='treatment'},
    options:{...o,bobHeight:(o.bobHeight??0)*(1-.72*amount),floatSway:(o.floatSway??0)*(1-.7*amount),modeIdleStrength:(o.modeIdleStrength??1)*(1-.72*amount)},
    rendering:{...snapshot.rendering,renderer:config.wingRenderer==='atlas'?snapshot.rendering.renderer:'rig'}};
}

/** Gentle, side-specific blend inside the original eleven-pose wing rig.
 * Apply before collapse/condition deformation so those responses still win.
 * Does not alter effective.pose, poseAnimation, or the player's saved weights. */
export function workingWingWeights(snapshot,side,weights=snapshot?.poseAnimation?.weights,tipWeights=snapshot?.poseAnimation?.tipWeights??weights){
  const work=snapshot?.workingPosture;
  if(!work?.amount||!Array.isArray(weights)||weights.length!==POSES.length||work.side&&work.side!==side)return {weights,tipWeights};
  const protective=weights.reduce((n,w,i)=>n+(['forwardGuard','cocoon','leftForwardWrap','rightForwardWrap','crossed','collapsed'].includes(POSES[i])?w:0),0);
  const amount=work.amount*(work.side? .15:.075)*(1-protective*.8);
  return {weights:mixWeights(weights,TRAILING,amount),tipWeights:mixWeights(tipWeights,TRAILING,amount*.85)};
}
