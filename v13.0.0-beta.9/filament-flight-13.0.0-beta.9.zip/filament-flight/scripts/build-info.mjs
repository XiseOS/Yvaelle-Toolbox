// Release identity. The version follows config.mjs (read lazily: config.mjs imports this file through performance.mjs).
// sourceHash is filled in by a release build only; a working tree reports null rather than a stale hash.
import {VERSION} from './config.mjs?v=13.0.0-beta.9';
export const BUILD_INFO=Object.freeze({get version(){return VERSION;},sourceHash:null,"algorithm":"sha256 of compact sorted JSON mapping script-relative paths to sha256, excluding build-info.mjs"});
