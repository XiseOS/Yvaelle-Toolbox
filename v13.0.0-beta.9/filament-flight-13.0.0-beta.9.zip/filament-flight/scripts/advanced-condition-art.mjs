/** Six independent lattice animations. Frame-wide phases are sampled once;
 * existing healthy wings never enter this module's geometry path. No filters,
 * timers, per-token textures or additional Foundry document updates. */
import {ADVANCED_CONDITION_IDS} from './effect-catalog.mjs?v=13.0.0-beta.9';
import {ease} from './poses.mjs?v=13.0.0-beta.9';
import {cubic} from './wing-art.mjs?v=13.0.0-beta.9';
import {fitEffectPoint} from './condition-art.mjs?v=13.0.0-beta.9';

const IDS=new Set(ADVANCED_CONDITION_IDS),TAU=Math.PI*2;
const gate={threadSlip:'instability',faultRepair:'breaks',standingWaves:'energy',energyStarvation:'energy',surgeRouting:'arcs',phaseSeparation:'glitches'};
const frac=x=>x-Math.floor(x),unit=x=>Math.max(0,Math.min(1,x));
const root=u=>ease((u-.12)/.32),quant=x=>Math.round(Math.max(0,Math.min(1.5,x))*16)/16;
const prepared=new WeakMap(),strandMetadata=new Map();
export const isAdvancedCondition=v=>IDS.has(v?.variant?.id);
function params(v){
  const a=v?.variant,id=a?.id;
  if(!IDS.has(id)||!(a.amount>0)||v.gates?.[gate[id]]===false||gate[id]==='energy'&&v.energyPulses===false&&v.animated!==false)return null;
  const t=v.animated===false?0:a.time??0,m=v.gates?.instability===false?0:v.variantMotion??1,freq=a.frequency??1;
  let f=prepared.get(v);
  if(f&&f.t===t&&f.A===a.amount&&f.id===id&&f.m===m&&f.freq===freq)return f;
  f={id,A:a.amount,t,m,freq};
  if(id==='threadSlip'){
    f.slips=[];for(let i=0;i<10;i++){
      const cycle=frac(t*.145+i*.127),hold=ease(cycle/.18)*(1-ease((cycle-.52)/.37));
      f.slips[i]=(i%2?1:-1)*hold;
    }
  }else if(id==='phaseSeparation'){
    f.separation=[];for(let i=0;i<10;i++){
      const phase=frac(t*.13*freq+i*.061);f.separation[i]=ease(phase/.18)*(1-ease((phase-.46)/.45));
    }
  }else if(id==='faultRepair'){
    f.faults=[];for(let i=0;i<10;i++)f.faults[i]=.17+.84*frac(t*.20-i*.031);
  }else if(id==='energyStarvation'){
    const life=frac(t*.115),withdraw=life<.58;
    f.boundary=withdraw?1-.78*ease(life/.58):.22+.78*ease((life-.58)/.42);f.withdraw=withdraw;
  }else if(id==='standingWaves'){f.wave=Math.sin(t*1.8);f.quadrature=Math.cos(t*1.8);}
  prepared.set(v,f);return f;
}
function metadata(id){
  let meta=strandMetadata.get(id);if(meta)return meta;
  const bits=id.split('-'),kind=bits[0],index=Number(bits[1])||0;
  meta={kind,index:index%10,rib:kind==='rib',web:kind==='web'||kind==='cross',edge:kind==='edge'};
  // Topology IDs are a small fixed vocabulary. Defensive cap also permits
  // exported geometry helpers to be used with user-created temporary strands.
  if(strandMetadata.size<512)strandMetadata.set(id,meta);return meta;
}
// A Map lookup costs more than the sine it would cache.
const mode=u=>Math.sin(3*Math.PI*u);
function shiftedVertex(n,dx,dy,r,u,echo=false){
  if(dx===0&&dy===0)return n;
  const nr=root(n[3]??u),ratio=r?nr/r:0,k=echo?-.75:1;
  return fitEffectPoint([n[0]+dx*ratio*k,n[1]+dy*ratio*k,n[2],n[3]??u]);
}
export function advancedConditionPoint(point,u,side,v){
  const f=params(v);if(!f||u<=.12)return point;
  const {id,A,m}=f,r=root(u);
  if(id!=='standingWaves'&&id!=='energyStarvation')return point;
  const p=[...point];
  if(id==='standingWaves'){
    // Fixed nodes at u=1/3,2/3,1. Alternating lobes move in opposition;
    // this is a standing wave, not another travelling ripple.
    const wave=mode(u)*A*m*r;
    p[0]+=side*13*wave*f.wave;p[1]+=8*wave*f.quadrature;
  }else{
    const unlit=ease((u-f.boundary)/.16)*A*m*r;
    p[0]-=(p[0]-side*27)*.055*unlit;p[1]+=10*unlit*u;
  }
  return fitEffectPoint(p);
}

/** Contiguous spans share one stroke. Echoes are limited to a few complete rib
 * bundles rather than generating a second polyline for every tiny segment. */
export function advancedConditionPaths(strand,points,side,v){
  const f=params(v);if(!f)return null;
  const meta=metadata(strand.id),{id,A,m}=f;
  if(!meta.rib&&!meta.web&&!meta.edge)return [{...strand,points:points.map(fitEffectPoint)}];
  if(id==='standingWaves'||id==='surgeRouting')return [{...strand,points}];
  const out=[],echoes=[];let last=null,ghost=null;
  const append=(p,q,strength,tag,copy=false)=>{
    const s=quant(strength);if(s<=.025){if(copy)ghost=null;else last=null;return;}
    let prev=copy?ghost:last;
    if(prev&&prev.tag===tag&&prev.strength===s&&prev.points.at(-1)===p)prev.points.push(q);
    else{prev={...strand,id:copy?`phase-copy-${strand.id}`:strand.id,points:[p,q],strength:s,tag,...(copy?{echo:true,width:strand.width*.6}:{})};(copy?echoes:out).push(prev);}
    if(copy)ghost=prev;else last=prev;
  };
  let previous=null,previousGhost=null;
  for(let j=1;j<points.length;j++){
    const p=points[j-1],q=points[j],u=((p[3]??1)+(q[3]??1))*.5,r=root(u);
    let strength=strand.strength,cut=false,tag='whole',dx=0,dy=0,copy=0;
    if(id==='threadSlip'){
      const slip=f.slips[meta.index]*A*m,selected=meta.rib||meta.web&&meta.index%3!==0;
      if(selected){dx=side*slip*r*(8+6*u);dy=slip*r*(meta.index<4?-15:19);tag=`slip-${meta.index}`;}
      if(meta.web)strength*=1-.3*Math.abs(slip);
    }else if(id==='faultRepair'){
      const head=f.faults[meta.index],behind=head-u,width=.075*A*r;
      cut=u>.18&&behind>0&&behind<width&&!meta.edge;
      // A moving repair edge remains crisp while the damage front advances.
      if(!cut&&behind>=width&&behind<width+.055){strength*=1+.45*A;tag='repair-edge';}
    }else if(id==='energyStarvation'){
      const light=1-ease((u-f.boundary)/.07);
      // The fine ghost scaffold remains readable throughout the withdrawal.
      strength*=1-A*(1-light)*(meta.web?.94:.83);
      tag=light>.999?'lit':light<.001?'ghost':'boundary';
    }else if(id==='phaseSeparation'){
      const split=f.separation[meta.index]*A*r,sign=meta.index%2?1:-1;
      dx=side*sign*19*split*m*(v.gates?.displacement??1);dy=sign*8*split*m;
      strength*=1-split*(meta.web?.55:.18);tag=`phase-${meta.index}`;
      if(meta.rib&&meta.index%2===1&&v.gates?.echoes!==false)copy=split*.46;
    }
    if(cut){last=null;ghost=null;previous=null;previousGhost=null;continue;}
    // Derive each transformed vertex once; adjacent spans share the exact
    // endpoint object, allowing one path per stable brightness/displacement run.
    const a=previous??shiftedVertex(p,dx,dy,r,u),b=shiftedVertex(q,dx,dy,r,u);append(a,b,strength,tag);previous=b;
    if(copy>.025){const a=previousGhost??shiftedVertex(p,dx,dy,r,u,true),b=shiftedVertex(q,dx,dy,r,u,true);append(a,b,strand.strength*copy,'echo',true);previousGhost=b;}
    else{ghost=null;previousGhost=null;}
  }
  return out.concat(echoes);
}

export function advancedConditionAccents(side,v,warp,ribs,growth=1,context=null){
  const f=params(v);if(!f||growth<=0)return [];
  const {id,A,t,m}=f,out=[];
  const at=(i,u)=>warp([...cubic(ribs[Math.max(0,Math.min(9,i))],u),u]);
  const line=(name,points,width,strength,highlight=true)=>{
    const s=quant(strength);if(s>.025&&points.length>1&&points.every(p=>(p[3]??1)<=growth+.000001))out.push({id:`advanced-${name}`,points:points.map(fitEffectPoint),width,strength:s,highlight});
  };
  const offset=(p,x,y)=>[p[0]+x,p[1]+y,p[2],p[3]];
  const packet=(name,i,u,gain=A,width=1.45)=>{
    if(u<.05||u>growth)return;const points=[];
    for(let k=0;k<9;k++)points.push(at(i,Math.max(.03,u-k*.013)));
    line(name,points,width,gain);
  };
  if(id==='threadSlip'){
    for(const i of [1,4,7]){
      const slip=f.slips[i],u=.64,p=at(i,u),r=root(u),dx=side*slip*A*m*r*(8+6*u),dy=slip*A*m*r*(i<4?-15:19);
      const a=offset(p,dx,dy),q=at(i+1,u+.025),points=[];
      for(let j=0;j<13;j++){const k=j/12,bend=Math.sin(Math.PI*k)*Math.abs(slip)*8*m;points.push([a[0]+(q[0]-a[0])*k,a[1]+(q[1]-a[1])*k+bend,a[2]+(q[2]-a[2])*k,u+.025*k]);}
      line(`tension-${i}`,points,.75,A*(.25+.55*Math.abs(slip)));
    }
  }else if(id==='faultRepair'){
    for(const i of [1,3,5,7,9]){
      const head=f.faults[i],u=head-.075*A;if(u<.2||u>growth)continue;
      const a=at(i,Math.max(.15,u-.035)),b=at(i,Math.min(1,u+.035)),points=[];
      for(let j=0;j<9;j++){const k=j/8;points.push([a[0]+(b[0]-a[0])*k+side*(j%2?3.5:-3.5)*m*A,a[1]+(b[1]-a[1])*k,a[2]+(b[2]-a[2])*k,a[3]+(b[3]-a[3])*k]);}
      line(`repair-stitch-${i}`,points,1.05,A*.85);
      packet(`repair-feed-${i}`,i,Math.max(.15,u-.06),A*.6,.95);
    }
  }else if(id==='standingWaves'){
    for(const u of [1/3,2/3])for(const i of [1,4,7]){
      const p=at(i,u),size=(2.2+.8*Math.abs(f.wave))*A,points=[];
      for(let k=0;k<=16;k++){const angle=k/16*TAU;points.push(offset(p,Math.cos(angle)*size*1.6,Math.sin(angle)*size));}
      line(`fixed-node-${i}-${u}`,points,.6,A*.7);
    }
    for(const i of [0,3,6,9])packet(`resonant-crest-${i}`,i,.5,A*(.35+.35*Math.abs(f.wave)),1.1);
  }else if(id==='energyStarvation'){
    if(f.boundary<=growth)line('starvation-front',ribs.map((_,i)=>at(i,f.boundary)),1.25,A*.9);
    for(const i of [0,3,6,9]){
      const flow=frac(t*.32+i*.19),u=.05+(f.boundary-.05)*(f.withdraw?1-flow:flow);
      packet(`power-${f.withdraw?'retreat':'restart'}-${i}`,i,u,A*.75,1.2);
    }
  }else if(id==='surgeRouting'&&v.gates?.arcs!==false&&v.energyPulses!==false){
    const controllers=context?.controllers??[];
    for(let branch=0;branch<2;branch++){
      const i=branch===0?2:7,life=frac(t*.29+branch*.5),gain=A*Math.sin(Math.PI*life),junctionU=.48;
      const sourcePart=controllers[branch],source=sourcePart?.points?.[0];
      // Actual controller centres follow custom/free positions. With bits off,
      // charges visibly originate at the wing root instead of an empty socket.
      const raw=source??at(i,.07),origin=[raw[0],raw[1],raw[2],.07],junction=at(i,junctionU);
      const feed=[];
      for(let j=0;j<13;j++){const k=j/12,bend=Math.sin(Math.PI*k)*side*(branch===0?9:-9);feed.push([origin[0]+(junction[0]-origin[0])*k+bend,origin[1]+(junction[1]-origin[1])*k,origin[2]+(junction[2]-origin[2])*k,.07+(junctionU-.07)*k]);}
      line(`bit-feed-${branch}`,feed,.75,A*.35,false);
      const head=Math.min(1,life/.34),from=Math.max(0,head-.25),charge=[];
      for(let j=0;j<9;j++){const k=from+(head-from)*j/8,bend=Math.sin(Math.PI*k)*side*(branch===0?9:-9);charge.push([origin[0]+(junction[0]-origin[0])*k+bend,origin[1]+(junction[1]-origin[1])*k,origin[2]+(junction[2]-origin[2])*k,.07+(junctionU-.07)*k]);}
      if(life<.5)line(`bit-charge-${branch}`,charge,1.75,gain);
      if(life>.23)for(const ri of [i-1,i,i+1]){
        const u=junctionU+(1-junctionU)*ease((life-.23)/.77);
        line(`route-junction-${branch}-${ri}`,[junction,at(ri,junctionU+.025)],.65,gain*.7);
        packet(`routed-charge-${branch}-${ri}`,ri,u,gain,1.6);
      }
    }
  }else if(id==='phaseSeparation'&&v.gates?.echoes!==false){
    for(const i of [1,3,5,7,9]){
      const split=f.separation[i]*A,sign=i%2?1:-1,u=.76,p=at(i,u),dx=side*sign*19*split*m*(v.gates?.displacement??1),dy=sign*8*split*m;
      line(`reunion-${i}`,[offset(p,-dx*.75,-dy*.75),p,offset(p,dx,dy)],.55,split*.55,false);
    }
  }
  return out;
}
