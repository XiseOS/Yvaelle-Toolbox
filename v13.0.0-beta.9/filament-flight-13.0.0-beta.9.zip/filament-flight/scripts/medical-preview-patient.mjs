import {scanTokenTextureGeometry,scanTokenPortrait,TokenScanMaskCache} from './v83-token-scan-mask.mjs?v=13.0.0-beta.9';

/** A private projection of the displayed native original-image frame. Native
 * source pixels/atlas metadata are borrowed read-only; no image is square-
 * cropped and no scene mesh is moved. The authored medicine stays upright. */
const identity=Object.freeze({a:1,b:0,c:0,d:1,tx:0,ty:0});
const records=new WeakMap();
const finite=(n,f)=>Number.isFinite(n)?n:f;
const transform=(m,x,y)=>({x:m.a*x+m.c*y+m.tx,y:m.b*x+m.d*y+m.ty});
const inverse=m=>{const d=m.a*m.d-m.b*m.c;return Math.abs(d)>1e-10?{a:m.d/d,b:-m.b/d,c:-m.c/d,d:m.a/d,tx:(m.c*m.ty-m.d*m.tx)/d,ty:(m.b*m.tx-m.a*m.ty)/d}:null;};

export function medicalPreviewPatient(canvas,sourceToken,image,center={x:20,y:-8},{align='image',targetSize=100,imageSize=90}={}){
  let record=records.get(canvas);
  if(!record){record={token:{w:100,h:100,mesh:{visible:true,renderable:true,anchor:{x:0,y:0}}},cache:new TokenScanMaskCache({document:canvas.ownerDocument??globalThis.document})};records.set(canvas,record);}
  let geometry=sourceToken?scanTokenTextureGeometry(sourceToken):null,unit;
  if(geometry){unit=Math.max(.01,finite(targetSize,100))/Math.max(1,sourceToken.w??100,sourceToken.h??100);}
  else if(!sourceToken&&image&&(image.naturalWidth??image.width)>0&&(image.naturalHeight??image.height)>0){
    const w=image.naturalWidth??image.width,h=image.naturalHeight??image.height;
    const texture=record.fallback?.source===image&&record.fallback.width===w&&record.fallback.height===h?record.fallback.texture:{baseTexture:{resource:{source:image},valid:true,resolution:1},orig:{x:0,y:0,width:w,height:h},frame:{x:0,y:0,width:w,height:h}};
    record.fallback={source:image,width:w,height:h,texture};
    geometry={source:image,sourceWidth:w,sourceHeight:h,resolution:1,texture,orig:texture.orig,frame:texture.frame,trim:{x:0,y:0,width:w,height:h},imageToWorld:identity,uvs:null};
    unit=Math.max(.01,finite(imageSize,90))/Math.max(w,h);
  }
  if(!geometry||geometry.texture.rotate&&!geometry.uvs){record.cache.retain([]);record.geometry=null;return null;}
  const m=geometry.imageToWorld,origin=align==='anchor'&&sourceToken?{x:finite(sourceToken.mesh?.anchor?.x,.5)*geometry.orig.width,y:finite(sourceToken.mesh?.anchor?.y,.5)*geometry.orig.height}:{x:geometry.orig.width/2,y:geometry.orig.height/2};
  const mid=transform(m,origin.x,origin.y);
  const local={a:m.a*unit,b:m.b*unit,c:m.c*unit,d:m.d*unit,tx:center.x+(m.tx-mid.x)*unit,ty:center.y+(m.ty-mid.y)*unit};
  Object.assign(record.token.mesh,{texture:geometry.texture,sourceElement:geometry.source,worldTransform:local,x:center.x,y:center.y,
    rotation:finite(sourceToken?.mesh?.rotation,0),width:Math.hypot(local.a,local.b)*geometry.orig.width,height:Math.hypot(local.c,local.d)*geometry.orig.height});
  const portrait=scanTokenPortrait(record.token,{primary:{worldTransform:identity}});
  const corners=[[0,0],[geometry.orig.width,0],[0,geometry.orig.height],[geometry.orig.width,geometry.orig.height]].map(([x,y])=>transform(local,x,y));
  const xs=corners.map(p=>p.x),ys=corners.map(p=>p.y),bounds={x:Math.min(...xs),y:Math.min(...ys),width:Math.max(...xs)-Math.min(...xs),height:Math.max(...ys)-Math.min(...ys)};
  record.geometry=geometry;record.local=local;record.portrait=portrait;record.bounds=bounds;record.label=sourceToken?'Current displayed patient':'Full image reference';
  return record;
}

export function medicalPreviewMask(record,center,scale=1){
  return record?.cache.get(record.token,{center,scale,primary:{worldTransform:identity}})??null;
}

export function paintMedicalPreviewPatient(ctx,record){
  if(!record?.geometry)return false;
  const g=record.geometry,m=record.local,{trim,orig,frame,resolution,source}=g;
  ctx.save();ctx.transform(m.a,m.b,m.c,m.d,m.tx,m.ty);
  if(g.uvs){
    const uv=g.uvs,inv=inverse({a:(uv.x1-uv.x0)*g.sourceWidth,b:(uv.y1-uv.y0)*g.sourceHeight,c:(uv.x3-uv.x0)*g.sourceWidth,d:(uv.y3-uv.y0)*g.sourceHeight,tx:uv.x0*g.sourceWidth,ty:uv.y0*g.sourceHeight});
    if(!inv){ctx.restore();return false;}
    ctx.beginPath();ctx.rect(trim.x,trim.y,trim.width,trim.height);ctx.clip();
    ctx.transform(trim.width,0,0,trim.height,trim.x,trim.y);
    ctx.transform(inv.a,inv.b,inv.c,inv.d,inv.tx,inv.ty);ctx.drawImage(source,0,0);
  }else ctx.drawImage(source,frame.x*resolution,frame.y*resolution,frame.width*resolution,frame.height*resolution,trim.x,trim.y,trim.width,trim.height);
  ctx.restore();return true;
}

export function releaseMedicalPreviewPatient(canvas){const record=records.get(canvas);record?.cache.destroy();records.delete(canvas);}

/** Stand-in for a preview with no targeted token: a dark cameo medallion with
 * a gold token rim and a quiet head-and-shoulders silhouette. Painted once into
 * a small sprite and reused, so playback adds only one drawImage per frame. */
const STAND_IN={radius:45,margin:6,pixels:256};
let standIn=null;
function standInSprite(doc){
  if(standIn!==null)return standIn;
  const canvas=doc?.createElement?.('canvas');const g=canvas?.getContext?.('2d');if(!g){standIn=false;return standIn;}
  const {radius:r,margin,pixels}=STAND_IN,extent=r+margin,k=pixels/(extent*2);
  canvas.width=canvas.height=pixels;g.scale(k,k);g.translate(extent,extent);
  const disc=g.createRadialGradient(-12,-16,4,0,0,r);disc.addColorStop(0,'#47323f');disc.addColorStop(.62,'#2e212b');disc.addColorStop(1,'#1d151c');
  g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.fillStyle=disc;g.fill();
  g.save();g.beginPath();g.arc(0,0,r-.6,0,Math.PI*2);g.clip();
  // Head-and-shoulders cameo, deliberately anonymous.
  const bust=new Path2D();bust.moveTo(-40,48);bust.bezierCurveTo(-38,30,-28,22,-13,19);bust.bezierCurveTo(-8,18,-7,14,-7.5,10);
  bust.bezierCurveTo(-14,6,-16,-4,-15.5,-12);bust.bezierCurveTo(-15,-25,-7,-31,0,-31);bust.bezierCurveTo(7,-31,15,-25,15.5,-12);
  bust.bezierCurveTo(16,-4,14,6,7.5,10);bust.bezierCurveTo(7,14,8,18,13,19);bust.bezierCurveTo(28,22,38,30,40,48);bust.closePath();
  const body=g.createLinearGradient(0,-31,0,46);body.addColorStop(0,'#503b4c');body.addColorStop(1,'#33252f');
  g.fillStyle=body;g.fill(bust);g.strokeStyle='#a07b93';g.globalAlpha=.55;g.lineWidth=.7;g.stroke(bust);
  g.globalAlpha=.35;g.strokeStyle='#e767ce';g.lineWidth=.6;g.beginPath();g.arc(0,-12,15.2,-1.35,-.25);g.stroke();
  g.restore();g.globalAlpha=1;
  g.strokeStyle='#e767ce';g.globalAlpha=.2;g.lineWidth=.6;g.beginPath();g.arc(0,0,r-2.2,0,Math.PI*2);g.stroke();
  g.strokeStyle='#cfae76';g.globalAlpha=.9;g.lineWidth=1.3;g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.stroke();
  g.globalAlpha=.45;g.lineWidth=.5;g.beginPath();g.arc(0,0,r+2.4,0,Math.PI*2);g.stroke();
  g.globalAlpha=.95;g.fillStyle='#cfae76';
  for(let i=0;i<4;i++){const a=i*Math.PI/2,x=Math.cos(a)*(r+1.2),y=Math.sin(a)*(r+1.2),s=2.2;g.beginPath();g.moveTo(x-Math.cos(a)*s,y-Math.sin(a)*s);g.lineTo(x-Math.sin(a)*s*.55,y+Math.cos(a)*s*.55);g.lineTo(x+Math.cos(a)*s,y+Math.sin(a)*s);g.lineTo(x+Math.sin(a)*s*.55,y-Math.cos(a)*s*.55);g.closePath();g.fill();}
  standIn={canvas,extent};return standIn;
}
export function paintGenericPreviewPatient(ctx,center){
  const sprite=standInSprite(ctx.canvas?.ownerDocument??globalThis.document);
  ctx.save();ctx.translate(center.x,center.y);
  if(sprite){ctx.drawImage(sprite.canvas,-sprite.extent,-sprite.extent,sprite.extent*2,sprite.extent*2);}
  else{ctx.beginPath();ctx.arc(0,0,STAND_IN.radius,0,Math.PI*2);ctx.fillStyle='#2e212b';ctx.fill();ctx.strokeStyle='#cfae76';ctx.lineWidth=1.2;ctx.stroke();}
  ctx.globalAlpha=.6;ctx.fillStyle='#d9c3cf';ctx.font='7px Georgia,serif';ctx.textAlign='center';ctx.textBaseline='middle';
  if('letterSpacing' in ctx)ctx.letterSpacing='1.5px';ctx.fillText('PATIENT',0,STAND_IN.radius+11);ctx.restore();
}
