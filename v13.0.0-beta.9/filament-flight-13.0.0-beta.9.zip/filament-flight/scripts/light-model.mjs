import {WING_COLOR} from './wing-art.mjs?v=13.0.0-beta.9';
import {fieldPresence} from './flight-dynamics.mjs?v=13.0.0-beta.9';
import {lanternAvailability} from './lantern-model.mjs?v=13.0.0-beta.9';

/** Shared light intent is independent of browser-only wing visibility. */
export function resolveWingLight(data,config,active,visual,formation,bitPresence=0) {
  const enabled=data.lightEnabled??config.lightDefault;
  const intensity=data.lightIntensity??1;
  const bright=data.lightBright??config.lightBright,dim=data.lightDim??config.lightDim;
  // Keep the radius fixed. Small brightness steps bound native lighting
  // refreshes while the existing formation opens or folds.
  const withBits=data.lightWithBits===true,requiresWings=!withBits&&config.lightRequiresWings;
  const presence=withBits?Math.round(Math.max(0,Math.min(1,Number.isFinite(bitPresence)?bitPresence:0))*40)/40:
    config.lightRequiresWings?Math.round(fieldPresence(formation)*40)/40:1;
  const gain=intensity*presence*(config.lightConditionResponse?Math.min(1.35,Math.max(0,(visual.semanticProfile??visual.profile).energy)):1);
  const hasState=data.enabled||!!data.transition||data.lightEnabled===true||withBits&&presence>0;
  const allowed=!!(hasState&&enabled&&config.effectsEnabled&&config.wingLight&&(!requiresWings||active));
  return {enabled:!!enabled,active:allowed&&gain>0&&(bright>0||dim>0),
    appearance:data.lightAppearance??config.lightAppearance??'animated',visualReactions:data.lightVisualReactions??config.lightVisualReactions??true,
    color:WING_COLOR,requiresWings,intensity,
    bright,dim,
    alpha:Math.min(1,config.lightAlpha*gain),luminosity:Math.min(1,config.lightLuminosity*gain),
    attenuation:config.lightAttenuation,
    edgeAttenuation:config.lightEdgeFeather?config.lightEdgeStrength:0,
    animation:{type:!config.reduced&&config.lightSpeed>0&&config.lightAnimationIntensity>0&&config.lightAnimation==='pulse'?'pulse':null,
      speed:config.lightSpeed,intensity:config.lightAnimationIntensity}};
}

/** The unified light button can use deployed home bits with folded wings. Resolve
 * this opt-in only after allocation preparation, so dispatched and working bits
 * cannot illuminate the source token. Browser artwork visibility is cosmetic. */
export function resolveBitLight(snapshot,config){
  if(snapshot?.requested?.lightWithBits!==true)return snapshot;
  const mechanical=config.localEffects===false&&snapshot.bitAllocationState?
    {...snapshot,gems:{...snapshot.gems,enabled:(snapshot.bitHomeStations?.length??0)>0},bitDeployment:1}:snapshot;
  const presence=config.controlGems===false?0:lanternAvailability(mechanical);
  const data={...snapshot.requested,enabled:snapshot.enabled,transition:snapshot.transition};
  return {...snapshot,light:resolveWingLight(data,config,snapshot.rendering?.wingsActive,snapshot.visual,snapshot.formation,presence)};
}

/** Warm-up and fade for the light circle and parked bit lights, matching the
 * lantern's envelope: the pool grows from a smaller, dimmer glow to full reach
 * on ignite and sinks back the same way when it is switched off. `state` keeps
 * {level,at}; level runs 0..1 linearly in time and is eased on output. */
export const LIGHT_FADE=Object.freeze({warm:560,fade:480});
export function stepLightFade(state,target,now,{warm=LIGHT_FADE.warm,fade=LIGHT_FADE.fade}={}){
  const goal=target>0?1:0,last=Number.isFinite(state.at)?state.at:now,dt=Math.max(0,Math.min(50,now-last));
  if(!Number.isFinite(state.level))state.level=0;
  state.at=now;
  if(state.level<goal)state.level=Math.min(goal,state.level+dt/Math.max(1,warm));
  else if(state.level>goal)state.level=Math.max(goal,state.level-dt/Math.max(1,fade));
  return state.level;
}
/** Eased output. The pool grows out from a small glow (reach) while its
 * colour and brightness (weight) ease in, so it reads as warming up. Steps are
 * quantized to bound native lighting refreshes. */
export function lightFadeShape(level){
  const x=Math.max(0,Math.min(1,Number.isFinite(level)?level:0)),s=x*x*(3-2*x);
  const weight=Math.round(s*48)/48,reach=Math.round((.12+.88*Math.sin(Math.PI/2*x))*48)/48;
  return {weight,reach,done:x<=0};
}
