/** Self-check (v10): a one-click run in the user's real game that measures how
 * the module actually behaves there (frame times, its own cost, how often her
 * wings repaint, pops between frames, real hook order, lights, movement) and
 * writes a short plain-text report to copy back to the developer.
 *
 * Every scenario is short, measured frame by frame on the canvas ticker, and
 * puts back what it changed in a finally block. Anything that cannot run here
 * (no token, not the owner, a missing feature) is reported as skipped. Nothing
 * in this file draws, sounds or changes the module itself. */
import {ID,VERSION} from './config.mjs?v=13.0.0-beta.9';
import {forceDelete,deleteKey,isDeletion,deletes} from './forced-delete.mjs?v=13.0.0-beta.9';
import {localPerformance,perceptionCaller} from './performance.mjs?v=13.0.0-beta.9';
import {hudPreferences,resolvePinnedCharacterToken,eligibleTokens} from './hud-model.mjs?v=13.0.0-beta.9';
import {warp as warpTo} from './warp.mjs?v=13.0.0-beta.9';
import {AIRBORNE_MODES} from './flight-profiles.mjs?v=13.0.0-beta.9';
import {KeepsakeHost} from './keepsake/runtime.mjs?v=13.0.0-beta.9';
import {KeepsakePreviews} from './keepsake/preview.mjs?v=13.0.0-beta.9';
import {keepsakeOn,herActor,portraitConfig} from './keepsake/sheet/prefs.mjs?v=13.0.0-beta.9';
import {isDressed,setStandard} from './keepsake/sheet/dress.mjs?v=13.0.0-beta.9';
import {decorHoldState} from './keepsake/decor-hold.mjs?v=13.0.0-beta.9';
import {heroTrace} from './keepsake/petal-dom.mjs?v=13.0.0-beta.9';
import {worldSky} from './keepsake/sky.mjs?v=13.0.0-beta.9';
import {keepsakeTimings,formatTimings} from './keepsake/timings.mjs?v=13.0.0-beta.9';
import {KEEP_GROUPS,keepKey} from './keepsake/keep-playing.mjs?v=13.0.0-beta.9';
import {V11_SCENARIOS,V11_RUN,V11_LIMITS,V11_HEAD,V11_IDS,V11_TOKEN_FLAGS,v11Residue} from './self-check-v11.mjs?v=13.0.0-beta.9';
import {V12_SCENARIOS,V12_RUN,V12_LIMITS,V12_HEAD,V12_IDS,v12Residue} from './self-check-v12.mjs?v=13.0.0-beta.9';
import {V13_SCENARIOS,V13_RUN,V13_LIMITS,V13_HEAD,V13_IDS,v13Residue} from './self-check-v13.mjs?v=13.0.0-beta.9';
import {MACRO_FLAG} from './quick-wheel-model.mjs?v=13.0.0-beta.9';
import {originOf,foreignError} from './self-check-box.mjs?v=13.0.0-beta.9';

const REPORT_VERSION=1;
const SCENARIOS=Object.freeze([
  ['rest','Rest','3 s hovering, measured as she is'],
  ['modes','Flight modes','each mode: 3 squares out and back at the game\'s token speed'],
  ['takeoff','Takeoff and landing','lands, then takes off again'],
  ['shield','Wing shield','raised and lowered (with a small hit if HP is ticked)'],
  ['light','Light circle','her light turned on and off'],
  ['bits','Bits','one bit parks a light 2 squares away and comes back, in each send-out style'],
  ['warp','Warp','a Seam warp 3 squares out and back (other players see it)'],
  ['hp','HP: knocked out and healed','sets her HP to 0, then back (changes her actor briefly)'],
  ['hud','Keepsake HUD','its cost closed, on Home, with a menu and a preview, on Effects and on Settings; her Hero Points +1 and back'],
  ['performance','Performance','about 3 min of typical play: hovering, moving in Fly and Fast, light, lantern, a bit task, HUD, sheet (part by part while she moves), all together, then what costs fps while she moves'],
  ['compare','Compare','what costs fps while she moves: as is, Yvaelle’s Toolbox visuals off here, PF2e Visioner paused, both off (about 80 s)'],
  ['sheet','Her sheet','opens her Keepsake sheet: portrait, flower, title bar, moving and resizing; Hero Points +1 and back'],
  // (11.0.0-test.4) the V11 part: every v11 feature, one sub-section per area (self-check-v11.mjs)
  ...V11_SCENARIOS,
  // (12.0.0-beta.4) the V12 part: warps, shield styles, landing, cloaks, cost (self-check-v12.mjs)
  ...V12_SCENARIOS,
  ...V13_SCENARIOS
]);
const V11_SET=new Set(V11_IDS),V12_SET=new Set(V12_IDS),V13_SET=new Set(V13_IDS);
/** Parts that need her actor, not her token. */
// (13.0.0-beta.2) the V13 part needs her actor, not her token: a GM with no token of hers on the scene runs it too
const TOKENLESS=new Set(['sheet',...V13_IDS]);
/** (13.0.0-beta.2) What belongs to the table and not to a check: a curse on her and the curse's settings may change while
 * a long check runs (the GM lays one, she rolls, a text is edited), and putting everything back must not undo them. */
const LIVE_FLAGS=['curse'],LIVE_SETTINGS=new Set(['curseWorld','curseClient']);
const withoutLive=o=>{for(const k of LIVE_FLAGS)delete o[k];return o;};
/** Parts run only on their own (the PERFORMANCE part runs the comparison too). */
const SOLO=new Set(['compare']);
const SEND_OUT_STYLES=['classic','warp','thread','sling','flight'];
/** Longest each part may take before it is stopped and put back (ms). */
const LIMITS={...V11_LIMITS,...V12_LIMITS,...V13_LIMITS,performance:390000,compare:160000,hud:40000,sheet:45000,rest:20000,modes:110000,takeoff:40000,shield:30000,light:25000,bits:80000,warp:80000,hp:45000};
const withTimeout=(promise,ms,what)=>{let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`${what} took too long`)),ms);})]).finally(()=>clearTimeout(timer));};
const RELEVANT_SETTINGS=['rigFPS','poseFPS','renderWorker','rigQuality','bitQuality','localQuality','wingRenderer','reducedMotion','effectsEnabled','localEffects',
  'wingTrails','localTrails','trailModes','flightManoeuvres','wingFollowThrough','foregroundWings','wingLight','lightDefault',
  'versionGestures','versionCoreStates','versionBitOutline','versionFormations','versionScans','versionWingMotion','versionIris','versionFlightFeel','versionWarp',
  'warpArrival','warpBendTokens','warpRange','bitSendOutStyle','audioEnabled','audioMuted','audioVolume','audioLocalVolume','keepsakeUI','attentionSync'];

/* ---------------------------------------------------------------- helpers */
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const now=()=>globalThis.performance?.now?.()??Date.now();
const r1=n=>Number.isFinite(n)?Math.round(n*10)/10:null,r2=n=>Number.isFinite(n)?Math.round(n*100)/100:null;
const f1=n=>Number.isFinite(n)?(Math.round(n*10)/10).toFixed(1):'?',f2=n=>Number.isFinite(n)?(Math.round(n*100)/100).toFixed(2):'?';
const clone=v=>{try{return v===undefined?undefined:structuredClone(v);}catch{try{return JSON.parse(JSON.stringify(v));}catch{return v;}}};
const same=(a,b)=>{try{return JSON.stringify(a)===JSON.stringify(b);}catch{return a===b;}};
/** Equal as data: object key order does not matter (Foundry merges keep the old order). */
const stable=v=>Array.isArray(v)?v.map(stable):plainObj(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v;
function plainObj(v){return !!v&&typeof v==='object'&&!Array.isArray(v);}
const sameData=(a,b)=>{try{return JSON.stringify(stable(a))===JSON.stringify(stable(b));}catch{return a===b;}};
/** Dotted paths (two levels) where two flag trees differ. */
function diffPaths(a,b,path='',out=[]){
  for(const k of new Set([...Object.keys(a??{}),...Object.keys(b??{})])){const p=path?`${path}.${k}`:k;
    if(sameData(a?.[k],b?.[k]))continue;
    if(plainObj(a?.[k])&&plainObj(b?.[k])&&p.split('.').length<3)diffPaths(a[k],b[k],p,out);else out.push(p);}
  return out;
}
const plain=v=>!!v&&typeof v==='object'&&!Array.isArray(v);
const setting=(key,ns=ID)=>{try{return game.settings.get(ns,key);}catch{return undefined;}};
function stats(values){
  const v=values.filter(Number.isFinite).sort((a,b)=>a-b);if(!v.length)return {n:0,med:null,p95:null,max:null};
  const mid=Math.floor(v.length/2),med=v.length%2?v[mid]:(v[mid-1]+v[mid])/2;
  return {n:v.length,med,p95:v[Math.min(v.length-1,Math.ceil(v.length*.95)-1)],max:v.at(-1)};
}
function nextFrame(){return new Promise(r=>{let done=false;const go=()=>{if(!done){done=true;r();}};try{requestAnimationFrame(go);}catch{}setTimeout(go,120);});}
async function waitUntil(test,timeout=4000,poll=nextFrame){
  const end=now()+timeout;
  while(now()<end){let ok=false;try{ok=!!test();}catch{}if(ok)return true;await poll();}
  return false;
}
function browserName(){
  const ua=globalThis.navigator?.userAgent??'';const m=(re)=>ua.match(re)?.[1];
  const os=/Windows/.test(ua)?'Windows':/Mac OS X|Macintosh/.test(ua)?'macOS':/Android/.test(ua)?'Android':/Linux/.test(ua)?'Linux':/iPhone|iPad/.test(ua)?'iOS':'?';
  const name=m(/Electron\/([\d.]+)/)?`Electron ${m(/Electron\/(\d+)/)} (Chrome ${m(/Chrome\/(\d+)/)})`:m(/Edg\/(\d+)/)?`Edge ${m(/Edg\/(\d+)/)}`:m(/Firefox\/(\d+)/)?`Firefox ${m(/Firefox\/(\d+)/)}`:
    m(/Chrome\/(\d+)/)?`Chrome ${m(/Chrome\/(\d+)/)}`:m(/Version\/([\d.]+).*Safari/)?`Safari ${m(/Version\/([\d.]+)/)}`:'?';
  return `${name} · ${os}`;
}
function glRenderer(){
  try{
    const r=canvas?.app?.renderer,gl=r?.gl??r?.context?.gl;if(!gl)return 'no WebGL context';
    const ext=gl.getExtension('WEBGL_debug_renderer_info');
    const name=String(ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER));
    return name.replace(/\s+/g,' ').slice(0,90)+(r?.context?.webGLVersion?` · WebGL${r.context.webGLVersion}`:'');
  }catch(e){return `unavailable (${e?.message??e})`;}
}
async function refreshRate(){
  const times=[];await new Promise(res=>{let n=0;const end=now()+900;const step=t=>{times.push(t);if(++n<50&&now()<end)requestAnimationFrame(step);else res();};try{requestAnimationFrame(step);}catch{res();}setTimeout(res,1200);});
  const d=[];for(let i=1;i<times.length;i++)d.push(times[i]-times[i-1]);
  const med=stats(d).med;return med?Math.round(1000/med):null;
}

/* ---------------------------------------------------------------- finding Ellie */
const hasFlight=t=>!!t?.document?.flags?.[ID]?.flight;
export function findEllie(){
  try{
    if(!canvas?.ready)return null;
    const owned=t=>t&&!t.destroyed&&!t.isPreview&&t.document?.isOwner;
    const controlled=[...(canvas.tokens?.controlled??[])].filter(owned);
    const cf=controlled.find(hasFlight);if(cf)return {token:cf,how:'selected'};
    try{const prefs=hudPreferences(game.settings.get(ID,'hudPreferences'));const t=resolvePinnedCharacterToken(prefs,eligibleTokens());if(owned(t))return {token:t,how:'pinned character'};}catch{}
    if(controlled.length===1)return {token:controlled[0],how:'selected'};
    const all=canvas.tokens?.placeables??[];
    const f=all.find(t=>hasFlight(t)&&owned(t));if(f)return {token:f,how:'first token with Yvaelle’s Toolbox'};
    const any=all.find(hasFlight);return any?{token:any,how:'first token with Yvaelle’s Toolbox (not owned)'}:null;
  }catch{return null;}
}

/* ---------------------------------------------------------------- error capture */
/** Top stack frames as "fn (package/path.mjs:line)". */
function topFrames(err,n=3){
  const lines=String(err?.stack??'').split('\n').map(l=>l.trim()).filter(l=>/^at |@/.test(l)).slice(0,n);
  return lines.map(l=>{const m=/^at (?:(.+?) \()?(.+?):(\d+):\d+\)?$/.exec(l)??/^(.*)@(.+?):(\d+):\d+$/.exec(l);if(!m)return l.slice(0,60);
    const file=m[2].replace(/^.*?\/(modules|systems)\//,'').replace(/^.*\/(scripts|dist|module)\//,'$1/').replace(/\?.*$/,'').split('/').slice(-3).join('/');
    return `${(m[1]||'?').replace(/^async /,'').slice(0,40)} (${file}:${m[3]})`;});
}
function captureErrors(where=()=>null){
  const seen=new Map(),add=(kind,args)=>{try{
    const text=[...args].map(a=>a instanceof Error?`${a.message}${a.stack?' @'+String(a.stack).split('\n').slice(1,2).join('').trim().slice(0,90):''}`:typeof a==='string'?a:(()=>{try{return JSON.stringify(a);}catch{return String(a);}})()).join(' ').replace(/\s+/g,' ').slice(0,220);
    const err=[...args].find(a=>a instanceof Error),clean=text.replace(/\s*\[Detected [^\]]*\]/g,'').replace(/ @.*$/,'');
    // whose it is: the error's own stack; without one (a console.error of plain text) the code that called console.error
    let origin=err?originOf(err.stack):null;
    if(!origin&&!err&&(kind==='error'||kind==='warn')){try{origin=originOf(String(new Error().stack).split('\n').slice(3).join('\n'));}catch{}}
    if(!origin&&/\bSequencer\b|\bjb2a\.|Invalid Asset/i.test(clean)&&!/filament/i.test(clean))origin='sequencer';
    const key=`${kind}|${clean}`;const e=seen.get(key);if(e){e.n++;const w=where();if(w&&!e.parts.includes(w))e.parts.push(w);}else seen.set(key,{kind,text:clean,n:1,at:now(),frames:err?topFrames(err):[],parts:[where()].filter(Boolean),origin});
  }catch{}};
  const origError=console.error,origWarn=console.warn;
  console.error=function(...a){add('error',a);return origError.apply(this,a);};
  console.warn=function(...a){try{if(/filament|ellie|yvaelle/i.test(a.map(String).join(' ')))add('warn',a);}catch{}return origWarn.apply(this,a);};
  const onError=e=>add('uncaught',[e?.error??e?.message??'error']),onReject=e=>add('rejection',[e?.reason??'rejection']);
  globalThis.addEventListener?.('error',onError);globalThis.addEventListener?.('unhandledrejection',onReject);
  return {list:()=>[...seen.values()],stop(){console.error=origError;console.warn=origWarn;globalThis.removeEventListener?.('error',onError);globalThis.removeEventListener?.('unhandledrejection',onReject);}};
}

/* ---------------------------------------------------------------- frame recorder */
function trackKey(rest){
  let m=/^bit\.([^.]+)\./.exec(rest);if(m)return `bit:${m[1]}`;
  // every wing layer is one part: a strand passing from behind her to in front
  // of her moves between layers, which is not a change on screen
  if(/^(left|right)(Rear|Front)$/.test(rest)||rest==='wings')return 'wing:wings';
  if(rest==='shadow'||rest==='wingShadow')return `shadow:${rest}`;
  return null;
}
/** Drawn scale of a mesh against its texture (cropping a wing layer's texture
 * changes its width, not its scale). */
function meshScale(m,cropped){
  if(!cropped)return Math.sqrt(Math.abs((m.width||0)*(m.height||0)));
  const t=m.texture,tw=t?.orig?.width??t?.frame?.width??t?.width??t?.src?.width;
  return tw>1&&Number.isFinite(m.width)?Math.abs(m.width)/tw:Math.abs(m.scale?.x??1);
}
class Recorder{
  constructor(ctx){this.ctx=ctx;this.frames=[];this.active=false;this.marks=[];}
  begin({others=null,overlay=null,ink=false}={}){
    this.frames=[];this.marks=[];this.t0=now();this.last=null;this.others=others;this.overlay=overlay;this.ink=ink;this.active=true;
    const ticker=canvas?.app?.ticker;
    if(ticker?.add){this.ticker=ticker;ticker.add(this.tick,this,-40);}
    else{const loop=()=>{if(!this.active)return;this.tick();this.raf=requestAnimationFrame(loop);};this.raf=requestAnimationFrame(loop);}
  }
  mark(label){this.marks.push({t:now()-this.t0,label});}
  end(){this.active=false;try{this.ticker?.remove(this.tick,this);}catch{}this.ticker=null;try{cancelAnimationFrame(this.raf);}catch{}
    if(this.ctx.debug)(this.ctx.debug[this.ctx.current]??=[]).push({frames:this.frames,marks:this.marks});return this.frames;}
  tick(){
    if(!this.active)return;
    try{this.sample();}catch(e){this.errors=(this.errors??0)+1;this.lastError=String(e?.message??e);}
  }
  sample(){
    const ctx=this.ctx,token=ctx.token,t=now(),f={t:t-this.t0,dt:this.last==null?null:t-this.last,tr:{}};this.last=t;
    if(this.frames.length>=4000)return;
    const mesh=token?.mesh,s=ctx.manager?.states?.get?.(token);
    if(mesh&&!mesh.destroyed){
      f.mx=mesh.x;f.my=mesh.y;f.bx=mesh.x+(s?.swayX??0);f.by=mesh.y+(s?.lift??0);f.bank=s?.bank??0;f.rot=mesh.rotation??0;f.mir=Math.sign(mesh.scale?.x??1)||1;
      const vis=mesh.visible!==false&&mesh.renderable!==false;f.ma=vis?(mesh.alpha??1):0;
      // Her size: the larger side of her token picture times the module's
      // height scale. (beta.32: the larger side, not the area, so a module or
      // setting that mirrors her to face her way, squeezing the picture
      // through zero width, is not a size change.) Width, height, mirror and
      // height scale are kept so a real resize can be explained.
      const w=Math.abs(mesh.width||0),h=Math.abs(mesh.height||0),k=s?.altScale??1;
      f.tr.token=[f.bx,f.by,f.ma,Math.max(w,h)*k,null,null,w,h,Math.sign(mesh.scale?.x??1)||1,k];
    }
    if(s){f.alt=s.feelState?.alt;f.shield=s.feelShield??0;f.blend=s.blend;f.collapse=s.snapshot?.conditionResponse?.collapse?.mix??0;f.phase=s.snapshot?.conditionResponse?.collapse?.phase??null;}
    // her display objects (wings, bits, shadows), merged by part
    const prefix=ctx.prefix,agg={};let tex='';
    for(const m of canvas?.primary?.children??[]){
      const name=m?.name;if(typeof name!=='string'||!name.startsWith(prefix)||m.destroyed)continue;
      const key=trackKey(name.slice(prefix.length));if(!key)continue;
      if(ctx.debug&&key.startsWith('bit:'))(f.raw??=[]).push([name.slice(prefix.length),Math.round(m.x),Math.round(m.y),+(m.alpha??0).toFixed(2),m.visible?1:0,+meshScale(m).toFixed(1)+'/'+(+meshScale(m,true).toFixed(3)),ctx.debugIds?.get(m)??(ctx.debugIds??=new WeakMap(),ctx.debugIds.set(m,(ctx.debugN=(ctx.debugN??0)+1)),ctx.debugN)]);
      const tx=m.texture,tw=tx?.orig?.width??tx?.frame?.width??tx?.width??tx?.src?.width;
      // (a mesh whose texture is an empty 1-pixel placeholder shows nothing)
      const a=m.visible!==false&&m.renderable!==false&&!(tw<=2)?Math.max(0,Math.min(1,Number(m.alpha)||0)):0;
      const g=agg[key]??={w:0,x:0,y:0,a:0,s:0,n:0,c:null};g.n++;
      const wt=a+1e-6;g.w+=wt;g.x+=m.x*wt;g.y+=m.y*wt;
      const wingPart=key.startsWith('wing:');
      // (wing layers crop their textures: their size is judged against the texture)
      if(a>=g.a){g.a=a;g.s=meshScale(m,wingPart);g.tw=tw;}
      if(this.ink&&wingPart)g.c=(g.c??0)+a*inkOf(m);
      if(key.startsWith('wing:')){const b=m.texture?.baseTexture;tex+=`${b?.uid??''}:${b?.dirtyId??''}:${m.texture?.updateID??''};`;}
    }
    let wing=0,ink=0;
    for(const [key,g] of Object.entries(agg)){f.tr[key]=[g.x/g.w,g.y/g.w,g.a,g.s,g.c,g.tw];if(key.startsWith('wing:')){wing=Math.max(wing,g.a);if(g.c!=null)ink+=g.c;}}
    f.wing=wing;f.tex=tex;if(this.ink)f.ink=ink;
    const c=localPerformance.active?localPerformance.counters:null;
    if(c){f.up=c.wingTextureUploads??0;f.wk=c.workerFramesSubmitted??0;}
    // her light circle: the module's own fade and what the native source holds
    const lr=ctx.manager?.lights?.records?.get?.(token);
    if(lr){f.light=lr.fade?.level??0;const d=lr.source?.data??lr.nativeData;f.lightA=d?Number(d.alpha)*(Number(d.bright)||0):null;f.lightDim=d?Number(d.dim):null;}
    else f.light=0;
    if(this.others){
      let moved=0,filtered=0;
      for(const o of this.others){
        const m=o.token.mesh;if(!m||m.destroyed)continue;
        const list=m.filters??null,len=list?.length??0;
        if(len!==o.filters||(len&&o.first!==list[0]))filtered++;
        if(Math.abs((m.x??0)-o.x)>.5||Math.abs((m.y??0)-o.y)>.5||Math.abs((m.scale?.x??1)-o.sx)>.001||Math.abs((m.scale?.y??1)-o.sy)>.001||Math.abs((m.rotation??0)-o.r)>.001)moved++;
      }
      f.oMoved=moved;f.oFiltered=filtered;
      const pf=canvas?.primary?.filters;f.pf=pf?.length??0;f.pfNew=pf?pf.some(x=>!this.others.primaryFilters.includes(x)):false;
    }
    if(this.overlay)f.ov=overlayCoverage(this.overlay,ctx);
    this.frames.push(f);
  }
}
/** How much of a wing layer's picture is painted (0–1 mean alpha), read from
 * an 8×8 copy of its canvas. Cached per texture upload where PIXI counts them. */
const inkCache=new WeakMap();let inkCanvas=null;
function inkOf(m){
  const tex=m.texture,base=tex?.baseTexture,src=base?.resource?.source??tex?.src;
  if(!src||!(src.width>1)||!(src.height>1))return 0;
  const sig=base?.dirtyId!=null?`${base.dirtyId}|${src.width}|${src.height}`:null,hit=inkCache.get(m);
  if(sig&&hit?.sig===sig)return hit.value;
  inkCanvas??=Object.assign(document.createElement('canvas'),{width:8,height:8});
  const g=inkCanvas.getContext('2d',{willReadFrequently:true});g.clearRect(0,0,8,8);
  try{g.drawImage(src,0,0,src.width,src.height,0,0,8,8);}catch{return hit?.value??0;}
  const d=g.getImageData(0,0,8,8).data;let sum=0;for(let i=3;i<d.length;i+=4)sum+=d[i];
  const value=sum/(255*64);inkCache.set(m,{sig,value});return value;
}
/** How much of the warp layer is drawn around a world point (0–1), sampled
 * from a 16×16 copy so it costs little. */
function overlayCoverage(spec,ctx){
  const el=document.getElementById('ff-warp-layer');if(!el||!el.width||!el.height)return 0;
  const wt=canvas.stage.worldTransform,screenW=canvas.app?.renderer?.screen?.width||el.width,k=el.width/screenW;
  const small=spec.small??=Object.assign(document.createElement('canvas'),{width:16,height:16}),g=spec.g??=small.getContext('2d',{willReadFrequently:true});
  let best=0;
  for(const p of spec.points){
    const q=wt.apply(p),half=ctx.size*1.6*wt.a*k;
    g.clearRect(0,0,16,16);
    try{g.drawImage(el,q.x*k-half,q.y*k-half,half*2,half*2,0,0,16,16);}catch{continue;}
    const d=g.getImageData(0,0,16,16).data;let sum=0;for(let i=3;i<d.length;i+=4)sum+=d[i];
    best=Math.max(best,sum/(255*256));
  }
  return best;
}

/* ---------------------------------------------------------------- analysis */
const PART={token:'her token','wing:wings':'her wings','shadow:shadow':'her shadow','shadow:wingShadow':'wing shadow'};
const LABEL=key=>{const i=key.lastIndexOf(' '),k=key.slice(i+1);return key.slice(0,i+1)+(PART[k]??k.replace(':',' '));};
/** Frame-to-frame pops in every track: a move, alpha or size change that is a
 * spike against its neighbours (steady fast motion is not a pop), and parts
 * that vanish for 1–3 frames. */
function findPops(frames,grid,{skip=()=>false,alphaKinds=true}={}){
  const keys=new Set();for(const f of frames)for(const k in f.tr)keys.add(k);
  const events=[],largest={move:null,bitMove:null},rates={},frameMs=stats(frames.map(f=>f.dt)).med;
  const vis=x=>!!x&&x[2]>.02;
  for(const key of keys){
    const arr=frames.map(f=>f.tr[key]),maxInk=Math.max(0,...arr.map(x=>x?.[4]??0));
    // The part's own updates: renderers may move a part only every few
    // display frames, so a pop is judged against its neighbouring updates.
    const ups=[];let prev;
    for(let i=0;i<arr.length;i++){
      const x=arr[i];
      if(prev===undefined||!x!==!prev||x&&(Math.abs(x[0]-prev[0])>.5||Math.abs(x[1]-prev[1])>.5||Math.abs(x[2]-prev[2])>.005||Math.abs((x[3]||1)/(prev[3]||1)-1)>.002))ups.push({i,t:frames[i].t,x});
      prev=x??null;
    }
    const dist=k=>{const a=ups[k-1]?.x,b=ups[k]?.x;return vis(a)&&vis(b)?Math.hypot(b[0]-a[0],b[1]-a[1])/grid:null;};
    const span=k=>Math.max(4,ups[k].t-ups[k-1].t);
    const around=k=>{let L=0,T=0;for(let j=Math.max(1,k-6);j<=Math.min(ups.length-1,k+6);j++){if(j===k)continue;const d=dist(j);if(d==null)continue;L+=d;T+=Math.min(250,span(j));}return T>0?L/T:0;};
    const steps=[];
    for(let k=1;k<ups.length;k++){
      const t=ups[k].t,d=dist(k);
      if(d!=null){
        if(d>.003&&span(k)<250)steps.push(span(k));
        if(skip(t,key))continue;
        // (beta.36) A pop happens in one frame: judge the step from the frame
        // just before this update. A part gliding under the 0.5 px "changed"
        // step for many frames (her slide back after a Fast stop: 0.1 px a
        // frame at grid 40 and 164 Hz) has no update between, and its whole
        // glide was read as one jump "over 729 ms". A renderer holding a part
        // for a few frames still shows its whole step in that one frame.
        const i=ups[k].i,before=arr[i-1],fd=vis(before)?Math.hypot(ups[k].x[0]-before[0],ups[k].x[1]-before[1])/grid:d;
        if(key.startsWith('bit:')&&(!largest.bitMove||fd>largest.bitMove.d))largest.bitMove={key,t,d:fd};
        if(!largest.move||fd>largest.move.d)largest.move={key,t,d:fd};
        if(fd>=.25){
          const n=ups[k+1]?.x,p=ups[k-1].x,a=frames[i-1],b=frames[i];
          // (a frame that came long after the one before: the canvas stalled; say so, it is not a pop)
          const gap=b?.dt!=null&&b.dt>Math.max(100,6*(frameMs??b.dt))?Math.round(b.dt):null;
          const returned=vis(n)&&Math.hypot(n[0]-p[0],n[1]-p[1])/grid<d*.3&&(dist(k+1)??0)>=.25&&ups[k+1].t-t<120;
          if(gap)events.push({t,key,kind:'gap',amount:fd,sev:0,gap});
          else if(returned||fd>=5*around(k)*Math.min(250,span(k))+.1)events.push({t,key,kind:returned?'glitch':'jump',amount:fd,sev:fd,
            // (beta.35) what moved with it, for her wings: her body, the token, her sway and lift, a turn, a mirror flip
            why:key.startsWith('wing:')?jumpParts(a,b,before??p,ups[k].x,grid):null});
        }
      }
      if(!alphaKinds||skip(t,key))continue;
      const al=j=>vis(ups[j]?.x)?ups[j].x[2]:0;
      const a=al(k-1),b=al(k),da=b-a;
      // (wings that appear or go while hardly anything is painted on them are not a pop)
      const thin=maxInk>0&&((ups[da>0?k:k-1]?.x?.[4]??maxInk)/maxInk<.3);
      if(Math.abs(da)>=.45&&!thin){
        const pa=k>=2?Math.abs(a-al(k-2)):0,na=k+1<ups.length?al(k+1)-b:0;
        // (11.0.0-test.7) a fade that a stalled canvas compressed into one frame is the stall, not a pop (as for moves)
        const fb=frames[ups[k].i],gapA=fb?.dt!=null&&fb.dt>Math.max(100,6*(frameMs??fb.dt))?Math.round(fb.dt):null;
        if(pa<Math.abs(da)/3&&(Math.abs(na)<Math.abs(da)/3||Math.sign(na)!==Math.sign(da)))events.push(gapA?{t,key,kind:'gap',amount:Math.abs(da),sev:0,gap:gapA,alpha:true}:{t,key,kind:da<0?'fade-cut':'pop-in',amount:Math.abs(da),sev:Math.abs(da)*.8});
      }
      // (a part fading through a size change cannot be seen doing it: judge size only where it shows)
      const sz=j=>vis(ups[j]?.x)&&ups[j].x[2]>=.35&&ups[j].x[3]>0?ups[j].x[3]:null;
      const sa=sz(k-1),sb=sz(k);
      // (a bit's picture can be swapped for another resolution with a new crop: compare like with like)
      if(sa&&sb&&(!key.startsWith('bit:')||ups[k-1].x[5]===ups[k].x[5])){
        const rel=Math.abs(sb/sa-1);
        if(rel>=.25){const s0=sz(k-2),s2=sz(k+1),pr=s0?Math.abs(sa/s0-1):0,nr=s2?Math.abs(s2/sb-1):0;
          if(pr<rel/3&&nr<rel/3){const a=ups[k-1].x,b=ups[k].x;
            events.push({t,key,kind:'resize',amount:rel,sev:rel,detail:key==='token'&&a.length>9?{w0:a[6],h0:a[7],k0:a[9],w1:b[6],h1:b[7],k1:b[9]}:null});}}
      }
    }
    // vanishing for 1–3 display frames
    if(alphaKinds)for(let i=1;i<arr.length;i++){
      const a=vis(arr[i-1])?arr[i-1][2]:0,b=vis(arr[i])?arr[i][2]:0;
      if(a>=.3&&b<.05&&!skip(frames[i].t,key))for(let j=i;j<Math.min(arr.length-1,i+3);j++){if((vis(arr[j+1])?arr[j+1][2]:0)>=.3){events.push({t:frames[i].t,key,kind:'vanish',amount:j-i+1,sev:1+(j-i+1)*.1});break;}}
    }
    if(steps.length>=6)rates[key]=1000/stats(steps).med;
  }
  events.sort((a,b)=>b.sev-a.sev);
  return {events,largest,rates};
}
/** (beta.37) How often a travelling part's position changes, judged only on
 * the canvas frames where it is clearly travelling (over 0.5 sq/s, measured
 * across a few frames) and counting any change at all (0.02 px), not the 0.5
 * px "changed" step that findPops uses for pops: a bit gliding the last
 * stretch home, or one bobbing at home, moves under half a pixel a frame and
 * was read as moving in steps (beta.36: "87/s on a 112 fps canvas", the
 * median of all four bits, three of them at home). Returns the part with the
 * most travelling frames: {key, frames, moved, rate (changes/s), fps, share}. */
function travelUpdates(frames,prefix,grid){
  let best=null;const keys=new Set();for(const f of frames)for(const k in f.tr)if(k.startsWith(prefix))keys.add(k);
  for(const key of keys){
    const arr=frames.map(f=>{const x=f.tr[key];return x&&x[2]>.05?x:null;});
    let n=0,moved=0,secs=0;
    for(let i=4;i<arr.length-3;i++){
      const a=arr[i-4],b=arr[i+3],p=arr[i-1],x=arr[i];if(!a||!b||!p||!x)continue;
      const span=(frames[i+3].t-frames[i-4].t)/1000;if(!(span>0))continue;
      if(Math.hypot(b[0]-a[0],b[1]-a[1])/grid/span<.5)continue;// not travelling here
      const dt=frames[i].dt;if(!(dt>0)||dt>100)continue;// (a canvas stall is not a step)
      n++;secs+=dt/1000;if(Math.hypot(x[0]-p[0],x[1]-p[1])>.02)moved++;
    }
    if(n>=10&&(!best||n>best.frames))best={key,frames:n,moved,rate:moved/secs,fps:n/secs,share:moved/n};
  }
  return best;
}
/** Median position updates per second while moving, for one kind of part. */
function updateRate(pops,prefix){const v=Object.entries(pops.rates).filter(([k])=>k===prefix||k.startsWith(prefix)).map(([,r])=>r);return stats(v).med;}
/** A wing jump taken apart (beta.35): how far her body, the token itself,
 * her sway and lift moved over the same frames, whether she turned or was
 * mirrored, and how far her wings moved against her body. */
function jumpParts(a,b,wa,wb,grid){
  if(!a||!b||a.bx==null||b.bx==null)return null;
  const d=(x0,y0,x1,y1)=>Math.hypot(x1-x0,y1-y0)/grid,deg=r=>Math.round(Math.abs(r)*180/Math.PI);
  return {body:d(a.bx,a.by,b.bx,b.by),token:d(a.mx,a.my,b.mx,b.my),sway:d(a.bx-a.mx,a.by-a.my,b.bx-b.mx,b.by-b.my),
    rel:d(wa[0]-a.bx,wa[1]-a.by,wb[0]-b.bx,wb[1]-b.by),turn:deg(Math.atan2(Math.sin((b.rot??0)-(a.rot??0)),Math.cos((b.rot??0)-(a.rot??0)))),
    bank:deg((b.bank??0)-(a.bank??0)),mirror:(a.mir??1)!==(b.mir??1),dt:Math.round(b.t-a.t)};
}
function describePop(e){
  const t=`${f2(e.t/1000)}s`,w=e.why;
  if(e.kind==='jump'||e.kind==='glitch')return `${t} ${LABEL(e.key)} ${e.kind==='glitch'?'jumped and came back':'jumped'} ${f2(e.amount)} sq`+
    (w?` (over ${w.dt} ms: body ${f2(w.body)} · token ${f2(w.token)} · sway+lift ${f2(w.sway)} · wings vs body ${f2(w.rel)} · turn ${w.turn}° · bank ${w.bank}°${w.mirror?' · mirrored':''})`:'');
  if(e.kind==='gap')return `${t} ${LABEL(e.key)} ${e.alpha?`alpha changed ${f2(e.amount)}`:`moved ${f2(e.amount)} sq`} across a ${e.gap} ms gap between canvas frames (the canvas did not draw; not a pop)`;
  if(e.kind==='vanish')return `${t} ${LABEL(e.key)} vanished for ${e.amount} frame${e.amount>1?'s':''}`;
  if(e.kind==='resize'){const d=e.detail;return `${t} ${LABEL(e.key)} size changed ${Math.round(e.amount*100)}% in one frame`+
    (d?` (picture ${Math.round(d.w0)}×${Math.round(d.h0)} → ${Math.round(d.w1)}×${Math.round(d.h1)} px, height scale ${f2(d.k0)} → ${f2(d.k1)})`:'');}
  return `${t} ${LABEL(e.key)} alpha ${e.kind==='fade-cut'?'dropped':'jumped'} ${f2(e.amount)} in one frame`;
}
function frameStats(frames){
  const s=stats(frames.slice(1).map(f=>f.dt).filter(x=>x!=null));
  return {...s,fps:s.med?1000/s.med:null};
}
/** Wing texture changes per second: from the texture's own upload counter
 * (dirtyId) where PIXI exposes it, else from the module's upload counter. */
function repaints(frames){
  if(frames.length<3)return null;
  const span=(frames.at(-1).t-frames[0].t)/1000;if(!(span>0))return null;
  let dirty=0,known=false,up=0,hasUp=false;
  for(let i=1;i<frames.length;i++){
    const a=frames[i-1],b=frames[i];
    if(b.tex&&/\d+:\d+/.test(b.tex)&&!/^(:+;)*$/.test(b.tex)){if(/:\d+:/.test(b.tex)&&!/:undefined/.test(b.tex))known=true;if(a.tex!==b.tex)dirty++;}
    if(a.up!=null&&b.up!=null){hasUp=true;if(b.up>a.up)up++;}
  }
  const viaDirty=known&&dirty>0?dirty/span:null,viaUp=hasUp?up/span:null;
  return {perSecond:viaDirty??viaUp,source:viaDirty!=null?'texture':'uploads'};
}

/* ---------------------------------------------------------------- the run */
export async function runSelfCheck(options={},{service=null,manager=null,ui:panel=null}={}){
  const api=game.modules?.get?.(ID)?.api;
  const opts={...Object.fromEntries(SCENARIOS.map(([id])=>[id,!SOLO.has(id)])),...(plain(options?.scenarios)?options.scenarios:{})};
  for(const [id] of SCENARIOS)if(typeof options?.[id]==='boolean')opts[id]=options[id];
  const progress=(text,step=false)=>{try{panel?.progress?.(text,step);}catch{}};
  const started=new Date(),t0=now();
  const result={version:REPORT_VERSION,module:game.modules?.get?.(ID)?.version??VERSION,started:started.toISOString(),scenarios:[],env:{},errors:[],restore:{}};
  let errCtx=null;const errs=captureErrors(()=>errCtx?String(errCtx.current??'setup').toUpperCase():'SETUP');
  const found=options.token?{token:options.token.document?options.token:options.token.object,how:options.how??'given'}:findEllie();
  const ctx=errCtx={api,service,manager:manager??null,token:found?.token??null,how:found?.how,opts,progress,aborted:false,recorder:null};
  ctx.doc=ctx.token?.document??null;
  ctx.grid=canvas?.grid?.size||canvas?.dimensions?.size||100;
  ctx.size=Math.max(ctx.token?.w??0,ctx.token?.h??0)||ctx.grid;
  ctx.prefix=`${ID}.${ctx.token?.id??ctx.doc?.id}.`;
  ctx.recorder=new Recorder(ctx);if(options.debug){ctx.debug={};result.debug=ctx.debug;}
  if(panel)panel.onStop=()=>{ctx.aborted=true;};
  const sceneId=canvas?.scene?.id;
  ctx.check=()=>{if(ctx.aborted)throw new Error('stopped by you');if(canvas?.scene?.id!==sceneId)throw new Error('the scene changed');if(!ctx.tokenless&&(!ctx.token||ctx.token.destroyed||!ctx.doc?.parent))throw new Error('her token is gone');};
  let snapshot=null,view=null;
  try{
    progress('Reading your setup…');
    result.env=ctx.env=await environment(ctx);
    if(!ctx.service&&!api){result.fatal='The Yvaelle’s Toolbox API is not available.';return finish();}
    // without her token only her sheet can be checked
    // (13.0.0-beta.2) a run of only such parts (V13 only) leaves her token alone altogether: no snapshot, no panning, nothing to put back
    const noToken=!ctx.token||!ctx.doc?.isOwner,onlyFree=SCENARIOS.every(([id])=>!opts[id]||TOKENLESS.has(id));
    ctx.tokenless=noToken||onlyFree;
    if(noToken){
      const why=!ctx.token?'No token for Ellie: select her token (or pin her in the HUD) and run again.':`You do not own ${ctx.doc.name}: run this as her player or the GM.`;
      if(!SCENARIOS.some(([id])=>opts[id]&&TOKENLESS.has(id))){result.fatal=why;return finish();}
      if(!onlyFree)result.note=`${why} Only the parts that need no token were run (her sheet, the V13 part).`;
    }else if(!onlyFree){snapshot=takeSnapshot(ctx);result.her=summariseHer(ctx);}
    // she must be on screen for the module to draw her
    if(!ctx.tokenless)try{const s=canvas.stage;view={x:s.pivot.x,y:s.pivot.y,scale:s.scale.x};const c=ctx.token.center;if(canvas.animatePan)await canvas.animatePan({x:c.x,y:c.y,duration:250});else canvas.pan?.({x:c.x,y:c.y});}catch{}
    await sleep(300);
    const paused=game.paused&&!game.user?.isGM;ctx.paused=paused;
    for(const [id,label] of SCENARIOS){
      const res={id,label,head:V11_HEAD[id]??V12_HEAD[id]??V13_HEAD[id]??null,lines:[],verdicts:[],pops:[]};result.scenarios.push(res);
      if(!opts[id]){res.skipped='not ticked';continue;}
      if(ctx.tokenless&&!TOKENLESS.has(id)){res.skipped='no token of hers';continue;}
      if(ctx.aborted){res.skipped=ctx.timedOut?'stopped after a part took too long':'run stopped';continue;}
      if(paused&&['modes','warp','v11world','v11perf','v12warps'].includes(id)){res.skipped='the game is paused (players cannot move tokens)';continue;}
      progress(`${label}…`,true);
      const restores=[];res.restore=fn=>restores.push(fn);ctx.current=id;
      const st=now();
      // (a part that hangs stops the whole run, so nothing keeps moving her after it is put back)
      try{ctx.check();await withTimeout(SCENARIO_RUN[id](ctx,res),LIMITS[id]??60000,label).catch(e=>{if(/took too long/.test(e?.message)){ctx.timedOut=true;ctx.aborted=true;}throw e;});}
      catch(e){res.error=String(e?.message??e).slice(0,160);if(ctx.timedOut&&/took too long/.test(res.error))verdict(res,'FAIL',`${res.error}; the rest was stopped`);else if(ctx.aborted)res.skipped=res.skipped??'stopped by you';else if(!res.skipped)verdict(res,'FAIL',`could not finish: ${res.error}`);}
      finally{
        if(ctx.recorder.active)ctx.recorder.end();
        if(localPerformance.active&&ctx.ownPerf)try{localPerformance.stop();}catch{}ctx.ownPerf=false;
        for(const fn of restores.reverse()){try{await withTimeout(Promise.resolve().then(fn),12000,'putting it back');}catch(e){res.restoreError=String(e?.message??e).slice(0,120);}}
        res.seconds=(now()-st)/1000;
      }
    }
  }catch(e){result.fatal=`stopped: ${String(e?.message??e).slice(0,160)}`;}
  finally{
    if(ctx.recorder.active)ctx.recorder.end();
    ctx.current='restore';
    if(snapshot){progress('Putting everything back…');try{result.restore=await withTimeout(restoreSnapshot(ctx,snapshot),30000,'putting everything back');}catch(e){result.restore={error:String(e?.message??e)};}}
    try{if(view&&canvas?.ready)canvas.pan?.(view);}catch{}
  }
  return finish();
  function finish(){
    errs.stop();result.errors=errs.list();result.seconds=(now()-t0)/1000;result.aborted=ctx.aborted;
    result.text=formatReport(result);
    return result;
  }
}

function verdict(res,level,text){res.verdicts.push(`${level} ${text}`);}
/** How many times her token picture was mirrored (its horizontal scale changed sign). */
function mirrorFlips(frames){let n=0,last=0;for(const f of frames){const s=f.tr?.token?.[8];if(!s)continue;if(last&&s!==last)n++;last=s;}return n;}
function popVerdicts(res,pops,{name='',exclude=null}={}){
  const gaps=pops.events.filter(e=>e.kind==='gap'&&(!exclude||!exclude(e)));
  if(gaps.length)res.lines.push(`canvas gaps${name}: ${gaps.length} (longest ${Math.max(...gaps.map(e=>e.gap))} ms); e.g. ${describePop(gaps[0])}`);
  const list=pops.events.filter(e=>e.kind!=='gap'&&(!exclude||!exclude(e)));
  const severe=list.filter(e=>(e.kind==='jump'||e.kind==='glitch')&&e.amount>=.5||e.kind==='vanish'||(e.kind!=='jump'&&e.kind!=='glitch'&&e.kind!=='vanish'&&e.amount>=.6));
  if(!list.length)verdict(res,'PASS',`no pops${name}${pops.largest.move?` (largest frame step ${LABEL(pops.largest.move.key)} ${f2(pops.largest.move.d)} sq)`:''}`);
  else verdict(res,severe.length?'FAIL':'CHECK',`${list.length} pop${list.length>1?'s':''}${name}; worst: ${describePop(list[0])}`);
  for(const e of list.slice(0,3))res.pops.push(describePop(e));
}
function perfLine(res,frames,perf,label='frames'){
  const fs=frameStats(frames),rp=repaints(frames);
  const mod=perf?.moduleMs;
  const paths=perf?.renderPaths?.length?perf.renderPaths.join('+'):null;
  // (beta.39) and the frames really drawn a second: on a canvas drawn every one or two display frames about
  // half and half, the median flips between them (beta.38's REST 11.4 ms "88 fps" and beta.37's 6.9 ms "145 fps"
  // were the same 110 frames a second)
  const dts=frames.slice(1).map(f=>f.dt).filter(x=>x!=null),drawn=dts.length?dts.length/(dts.reduce((a,b)=>a+b,0)/1000):null;
  res.lines.push(`${label} ${f1(fs.med)}/${f1(fs.p95)}/${f1(fs.max)} ms med/p95/max (${Math.round(fs.fps??0)} fps by the median${drawn?`, ${Math.round(drawn)} drawn a second`:''})`+
    (mod?` · module ${f2(mod.median)}/${f2(mod.p95)} ms`:'')+(rp?.perSecond!=null?` · wing repaints ${f1(rp.perSecond)}/s`:''));
  return {fs,rp,mod};
}
function perfVerdict(res,fs,mod){
  if(fs.p95>50)verdict(res,'FAIL',`slow frames: p95 ${f1(fs.p95)} ms`);else if(fs.p95>25)verdict(res,'CHECK',`p95 frame ${f1(fs.p95)} ms (over 25)`);
  if(mod?.median>8)verdict(res,'FAIL',`module work ${f2(mod.median)} ms per frame`);else if(mod?.median>4)verdict(res,'CHECK',`module work ${f2(mod.median)} ms per frame`);
}
function perfStart(ctx){
  if(localPerformance.active){ctx.ownPerf=false;return false;}
  try{localPerformance.start({duration:30000});ctx.ownPerf=true;return true;}catch{ctx.ownPerf=false;return false;}
}
function perfStop(ctx){
  if(!ctx.ownPerf)return null;ctx.ownPerf=false;
  try{localPerformance.stop();return localPerformance.getReport();}catch{return null;}
}

/* ---------------------------------------------------------------- actions (service first, public API as fallback) */
const call={
  state:ctx=>{try{return ctx.service?ctx.service.getState(ctx.doc):ctx.api.getState(ctx.token);}catch{return null;}},
  setMode:(ctx,mode)=>ctx.service?ctx.service.setState(ctx.doc,{mode}):ctx.api.setMode(ctx.token,mode),
  takeoff:ctx=>ctx.service?ctx.service.transition('takeoff',ctx.doc,{}):ctx.api.takeoff(ctx.token),
  land:ctx=>ctx.service?ctx.service.transition('landing',ctx.doc,{}):ctx.api.land(ctx.token),
  wings:(ctx,on)=>ctx.service?ctx.service.setWingsEnabled(ctx.doc,on,{}):ctx.api.setWingsEnabled(ctx.token,on),
  shield:(ctx,on)=>ctx.service?ctx.service.wingShield(ctx.doc,on):ctx.api.wingShield(ctx.token,on),
  light:(ctx,on)=>ctx.service?ctx.service.setState(ctx.doc,{lightEnabled:on}):ctx.api.setLight(ctx.token,on),
  bitsOn:(ctx,on)=>ctx.service?ctx.service.setBitsEnabled(ctx.doc,on,{}):ctx.api.setBitsEnabled(ctx.token,on),
  bits:ctx=>ctx.service?.bits??ctx.api?.bits,
  bitState:ctx=>{try{return ctx.service?ctx.service.bits.getState(ctx.doc):ctx.api.bits.getState(ctx.token);}catch{return null;}}
};
const airborne=st=>!!st?.airborne&&st?.effective?.mode!=='landing';
async function ensureFlying(ctx){
  let st=call.state(ctx);
  if(st?.enabled&&airborne(st)&&st.rendering?.flightActive&&!st.transition?.active)return true;
  await call.takeoff(ctx);
  const ok=await waitUntil(()=>{const s=call.state(ctx);return s?.enabled&&airborne(s)&&s.rendering?.flightActive&&!s.transition?.active;},6000,()=>sleep(100));
  await sleep(900);return ok;
}
/** Settle: her body is still (relative to where the token is) for a moment. */
async function settle(ctx,{timeout=2500,quiet=250}={}){
  let calm=0,last=null;const end=now()+timeout;
  while(now()<end){
    await nextFrame();const s=ctx.manager?.states?.get?.(ctx.token),m=ctx.token.mesh;if(!s||!m)return false;
    const b={x:m.x+(s.swayX??0),y:m.y+(s.lift??0)},t=now();
    if(last){const v=Math.hypot(b.x-last.x,b.y-last.y)/ctx.grid/Math.max(.004,(t-last.t)/1000);calm=v<.12?calm+(t-last.t):0;}
    last={...b,t};if(calm>=quiet)return true;
  }
  return false;
}

/* ---------------------------------------------------------------- free spots */
function tokenBlocks(ctx,x,y){
  for(const t of canvas.tokens?.placeables??[]){if(t===ctx.token||t.document?.hidden&&!game.user?.isGM)continue;
    const d=t.document,tw=t.w??(d.width*ctx.grid),th=t.h??(d.height*ctx.grid),tx=d.x,ty=d.y;
    if(x<tx+tw-1&&x+ctx.token.w>tx+1&&y<ty+th-1&&y+ctx.token.h>ty+1)return true;}
  return false;
}
function wallBetween(ctx,a,b){
  try{if(typeof ctx.token.checkCollision==='function')return !!ctx.token.checkCollision(b,{origin:a,type:'move',mode:'any'});}catch{}
  try{const backend=CONFIG?.Canvas?.polygonBackends?.move;if(backend?.testCollision)return !!backend.testCollision(a,b,{type:'move',mode:'any'});}catch{}
  return false;
}
/** A direction with `squares` free squares (no token, no wall, inside the scene). */
function freeDirection(ctx,squares){
  const d=ctx.doc,g=ctx.grid,rect=canvas.dimensions?.sceneRect??{x:0,y:0,width:canvas.dimensions?.width??1e9,height:canvas.dimensions?.height??1e9};
  const start={x:d.x,y:d.y},center={x:d.x+ctx.token.w/2,y:d.y+ctx.token.h/2};
  for(const [ux,uy,name] of [[1,0,'east'],[-1,0,'west'],[0,1,'south'],[0,-1,'north']]){
    let ok=true;
    for(let k=1;k<=squares&&ok;k++){const x=start.x+ux*g*k,y=start.y+uy*g*k;
      if(x<rect.x||y<rect.y||x+ctx.token.w>rect.x+rect.width||y+ctx.token.h>rect.y+rect.height)ok=false;
      else if(tokenBlocks(ctx,x,y))ok=false;}
    const to={x:center.x+ux*g*squares,y:center.y+uy*g*squares};
    if(ok&&wallBetween(ctx,center,to))ok=false;
    if(ok&&!game.user?.isGM){try{if(canvas.visibility?.testVisibility?.(to,{tolerance:2})===false)ok=false;}catch{}}
    if(ok)return {ux,uy,name,to:{x:start.x+ux*g*squares,y:start.y+uy*g*squares},toCenter:to};
  }
  return null;
}
async function moveBy(ctx,dx,dy){
  const d=ctx.doc,m=ctx.token.mesh,from={x:m.x,y:m.y},target={x:from.x+dx,y:from.y+dy};
  await d.update({x:d.x+dx,y:d.y+dy});
  const arrived=await waitUntil(()=>{const mm=ctx.token.mesh;return mm&&Math.hypot(mm.x-target.x,mm.y-target.y)<.75;},5000);
  return {target,arrived};
}

/* ---------------------------------------------------------------- scenarios */
const SCENARIO_RUN={
  async rest(ctx,res){
    await ensureFlying(ctx);ctx.check();await settle(ctx,{timeout:1500});
    perfStart(ctx);const rec=ctx.recorder;rec.begin();await sleep(3000);const frames=rec.end();const perf=perfStop(ctx);
    const st=call.state(ctx);res.lines.push(`${st?.effective?.mode??'?'} at ${f1(frames.at(-1)?.alt)} ft · wings on ${frames.filter(f=>f.wing>.05).length}/${frames.length} frames`);
    const {fs,rp,mod}=perfLine(res,frames,perf);
    if(perf){const c=perf.counters??{};res.lines.push(`module by part (mean ms): ${Object.entries(perf.stages??{}).sort((a,b)=>b[1].mean*b[1].samples-a[1].mean*a[1].samples).slice(0,4).map(([k,v])=>`${k} ${f2(v.mean)}`).join(', ')||'none'} · uploads wing ${c.wingTextureUploads??0} bit ${c.bitTextureUploads??0} · geometry ${c.geometryBuilds??0}`);
      const worker=(perf.renderPaths??[]).includes('wing-worker'),main=(perf.renderPaths??[]).includes('wing-main-thread');
      res.lines.push(`painting off the main thread: ${worker&&!main?'yes (worker)':worker?'partly (worker + main)':main?'no (main thread)':'unknown'}${perf.counters?.workerFramesSubmitted!=null?` · ${perf.counters.workerFramesSubmitted} worker frames`:''}`);}
    ctx.restFps=fs.fps;ctx.restRepaint=rp?.perSecond;
    perfVerdict(res,fs,mod);
    if(rp?.perSecond===0)verdict(res,'CHECK','her wing texture never changed (frozen wings?)');
    popVerdicts(res,findPops(frames,ctx.grid));
    if(rec.errors)verdict(res,'CHECK',`sampler errors ${rec.errors}: ${rec.lastError}`);
  },

  async modes(ctx,res){
    const dir=freeDirection(ctx,3);if(!dir){res.skipped='no free 3-square line next to her (tokens, walls or the scene edge)';return;}
    await ensureFlying(ctx);ctx.check();
    const original=call.state(ctx)?.requested?.mode;
    res.restore(async()=>{if(original&&AIRBORNE_MODES.includes(original)&&call.state(ctx)?.requested?.mode!==original){await call.setMode(ctx,original);await sleep(400);}});
    const home={x:ctx.doc.x,y:ctx.doc.y};
    res.restore(async()=>{if(ctx.doc.x!==home.x||ctx.doc.y!==home.y){await ctx.doc.update({x:home.x,y:home.y},{animate:false});await sleep(200);}});
    res.lines.push(`3 sq ${dir.name}+back · over sq · settle s · ms med/p95 · mod ms · rep wing/s · upd body/wing/s`);
    const all=[];let worstFps=Infinity,anyPerf=null;
    for(const mode of AIRBORNE_MODES){
      ctx.check();ctx.progress(`Flight modes: ${mode}…`);
      await call.setMode(ctx,mode);await sleep(1100);await settle(ctx,{timeout:1500});
      const started=perfStart(ctx);const rec=ctx.recorder;rec.begin();await sleep(250);
      const legs=[];
      for(const sign of [1,-1]){
        const dx=dir.ux*ctx.grid*3*sign,dy=dir.uy*ctx.grid*3*sign,u={x:dir.ux*sign,y:dir.uy*sign};
        const go=now()-rec.t0;const {target,arrived}=await moveBy(ctx,dx,dy);const at=now()-rec.t0;
        await settle(ctx,{timeout:2600});await sleep(150);
        legs.push({u,target,go,at,end:now()-rec.t0,arrived});
      }
      const frames=rec.end(),perf=started?perfStop(ctx):null;anyPerf??=perf;
      const pre=frames.filter(f=>f.t<legs[0].go&&f.bx!=null),idle=Math.max(0,...pre.map(f=>Math.abs(((f.bx-f.mx)*dir.ux+(f.by-f.my)*dir.uy)/ctx.grid)));
      const out=legs.map(l=>legMetrics(frames,l,ctx.grid,idle));
      const fs=frameStats(frames);worstFps=Math.min(worstFps,fs.fps??Infinity);
      const pops=findPops(frames,ctx.grid);const tr=updateRate(pops,'token'),wr=updateRate(pops,'wing:');
      const ov=Math.max(...out.map(o=>o.overshoot)),settleS=Math.max(...out.map(o=>o.settle??9)),lean=Math.max(...out.map(o=>o.lean));
      const rp=repaints(frames);
      res.lines.push(`${mode.padEnd(8)} over ${f2(ov)} · settle ${out.some(o=>o.settle==null)?'>2.6':f1(settleS)} · lean ${Math.round(lean)}° · ms ${f1(fs.med)}/${f1(fs.p95)}${perf?.moduleMs?` · mod ${f2(perf.moduleMs.median)}`:''}${rp?.perSecond!=null?` · rep ${Math.round(rp.perSecond)}`:''}${tr!=null?` · upd ${Math.round(tr)}/${Math.round(wr??0)}`:''}${(n=>n?` · ${n} pop(s)`:'')(pops.events.filter(e=>e.kind!=='gap').length)}${legs.some(l=>!l.arrived)?' · token did not arrive':''}`);
      all.push({mode,pops,ov,settle:out.some(o=>o.settle==null)?null:settleS,fs,mod:perf?.moduleMs,flips:mirrorFlips(frames)});
      if(['hover','sentinel','wraith'].includes(mode)&&ov>.15)verdict(res,'CHECK',`${mode} passed its stop by ${f2(ov)} sq (it should ease in without passing)`);
      if(out.some(o=>o.settle==null))verdict(res,'CHECK',`${mode} was still moving 2.6 s after the token stopped`);
      if(tr!=null&&fs.fps&&tr<fs.fps*.6)verdict(res,'CHECK',`${mode}: her body moved only ${Math.round(tr)} times/s on a ${Math.round(fs.fps)} fps canvas`);
      if(wr!=null&&fs.fps&&wr<fs.fps*.6)verdict(res,'CHECK',`${mode}: her wings moved only ${Math.round(wr)} times/s on a ${Math.round(fs.fps)} fps canvas`);
    }
    const flips=all.reduce((n,a)=>n+a.flips,0);
    if(flips)res.lines.push(`her token picture was mirrored ${flips}× while moving (a module or setting turns her to face her way); a mirror flip is not counted as a size change`);
    const worstP95=Math.max(...all.map(a=>a.fs.p95??0)),worstMod=all.reduce((m,a)=>Math.max(m,a.mod?.median??0),0);
    perfVerdict(res,{p95:worstP95},worstMod?{median:worstMod}:null);
    const merged={events:all.flatMap(a=>a.pops.events.map(e=>({...e,key:`${a.mode} ${e.key}`}))).sort((a,b)=>b.sev-a.sev),largest:{move:all.map(a=>a.pops.largest.move).filter(Boolean).sort((a,b)=>b.d-a.d)[0]}};
    popVerdicts(res,merged,{name:' while moving'});
  },

  async takeoff(ctx,res){
    await ensureFlying(ctx);ctx.check();await settle(ctx,{timeout:1500});
    const s0=ctx.manager?.states?.get?.(ctx.token);const startAlt=s0?.feelState?.alt;
    const rec=ctx.recorder;rec.begin({ink:true});await sleep(150);rec.mark('land');const landAt=now()-rec.t0;
    await call.land(ctx);
    // until the landing has played out on screen (her height, not just the saved state)
    await waitUntil(()=>{const s=call.state(ctx),m=ctx.manager?.states?.get?.(ctx.token);return s&&!s.airborne&&!s.transition?.active&&!(m?.feelState?.alt>.3);},8000,()=>sleep(100));
    await sleep(1200);ctx.check();
    const takeAt=now()-rec.t0;rec.mark('takeoff');
    await call.takeoff(ctx);
    await waitUntil(()=>{const s=call.state(ctx);return s?.airborne&&!s.transition?.active;},7000,()=>sleep(100));
    await sleep(1500);
    const frames=rec.end();
    const landing=frames.filter(f=>f.t>=landAt&&f.t<takeAt),rising=frames.filter(f=>f.t>=takeAt);
    const alt0=Number.isFinite(startAlt)?startAlt:Math.max(...landing.map(f=>f.alt??0));
    // wings: the last landing frame they were clearly painted, and how high she was then
    const ink=f=>f.ink??f.wing??0,ref=Math.max(0,...landing.slice(0,8).map(ink));let lastShown=null;for(const f of landing)if(ref>0&&ink(f)>=ref*.3)lastShown=f;
    const goneAt=landing.find(f=>lastShown&&f.t>lastShown.t);
    const downAt=landing.find(f=>Number.isFinite(f.alt)&&f.alt<=Math.max(.5,alt0*.05));
    res.lines.push(`landing from ${f1(alt0)} ft: wings painted until ${lastShown?`${f2((lastShown.t-landAt)/1000)} s (${f1(lastShown.alt)} ft)`:'never'} · down at ${downAt?f2((downAt.t-landAt)/1000)+' s':'?'} · wings after ${ref>0?Math.round(ink(landing.at(-1)??{})/ref*100):'?'}%`);
    const firstWing=rising.find(f=>ref>0&&ink(f)>=ref*.1),lift=rising.find(f=>(f.alt??0)>Math.max(.5,alt0*.1));
    res.lines.push(`takeoff: wings painted at ${firstWing?f2((firstWing.t-takeAt)/1000)+' s':'never'} · lifting at ${lift?f2((lift.t-takeAt)/1000)+' s':'?'} · then ${f1(rising.at(-1)?.alt)} ft`);
    if(!Number.isFinite(alt0)||alt0<=0)verdict(res,'CHECK','no flight height to measure (real height off or classic feel)');
    else if(!lastShown)verdict(res,'FAIL','wings were not drawn during the landing');
    else if(goneAt&&(lastShown.alt??0)>alt0*.5)verdict(res,'FAIL',`wings gone while she was still ${f1(lastShown.alt)} ft up of ${f1(alt0)}`);
    else if(goneAt&&(lastShown.alt??0)>Math.max(1.5,alt0*.2))verdict(res,'CHECK',`wings gone at ${f1(lastShown.alt)} ft of ${f1(alt0)}`);
    else verdict(res,'PASS',`wings stayed until she was nearly down (${f1(lastShown.alt??0)} ft)`);
    if(firstWing&&lift&&firstWing.t>lift.t+100)verdict(res,'CHECK','she lifted before her wings were drawn');
    popVerdicts(res,findPops(frames,ctx.grid));
  },

  async shield(ctx,res){
    await ensureFlying(ctx);ctx.check();
    const raisedBefore=ctx.doc.getFlag?.(ID,'wingShield');
    res.restore(async()=>{const now=ctx.doc.getFlag?.(ID,'wingShield');if(!same(now,raisedBefore)){await call.shield(ctx,raisedBefore===true);}});
    if((ctx.manager?.states?.get?.(ctx.token)?.feelShield??0)>.05){await call.shield(ctx,false);await sleep(1700);}
    const rec=ctx.recorder;rec.begin({ink:true});await sleep(200);
    const upAt=now()-rec.t0;await call.shield(ctx,true);await sleep(1600);
    let hit=null;
    if(ctx.opts.hp&&hpPath(ctx.doc.actor)){
      ctx.progress('Wing shield: a small hit…');
      hit=await withHp(ctx,async(actor,hp)=>{const dmg=Math.max(1,Math.round((hp.max||10)*.1));const at=now()-rec.t0;await actor.update({'system.attributes.hp.value':Math.max(1,hp.value-dmg)});await sleep(1400);return {dmg,at};},res);
    }
    const downAt=now()-rec.t0;await call.shield(ctx,false);await sleep(1700);
    const frames=rec.end();
    const up=frames.filter(f=>f.t>=upAt&&f.t<downAt),down=frames.filter(f=>f.t>=downAt);
    const peak=Math.max(0,...up.map(f=>f.shield??0)),rise=up.find(f=>(f.shield??0)>=.5),end=down.at(-1)?.shield??0;
    res.lines.push(`up to ${f2(peak)}${rise?` (half in ${f2((rise.t-upAt)/1000)} s)`:''} · after lowering ${f2(end)}${hit?.value?` · hit HP −${hit.value.dmg}, restored`:hit?.skipped?` · no hit: ${hit.skipped}`:ctx.opts.hp?'':' · no hit (HP unticked)'}`);
    if(peak<.5)verdict(res,'FAIL',`the shield did not rise (peak ${f2(peak)})`);else if(end>.05)verdict(res,'CHECK',`the shield was still ${f2(end)} 1.7 s after lowering`);else verdict(res,'PASS','raised and lowered');
    const steps=stats(frames.slice(1).map((f,i)=>Math.abs((f.shield??0)-(frames[i].shield??0)))).max;
    if(steps>.35)verdict(res,'CHECK',`shield strength jumped ${f2(steps)} in one frame`);
    popVerdicts(res,findPops(frames,ctx.grid));
  },

  async light(ctx,res){
    if(setting('wingLight')===false||setting('effectsEnabled')===false){res.skipped='wing light is turned off in the module settings';return;}
    await ensureFlying(ctx);ctx.check();
    const st=call.state(ctx),was=!!st?.light?.enabled;
    res.restore(async()=>{if(!!call.state(ctx)?.light?.enabled!==was){await call.light(ctx,was);await sleep(300);}});
    const rec=ctx.recorder;rec.begin();await sleep(200);
    const firstAt=now()-rec.t0;await call.light(ctx,!was);await sleep(2200);
    const secondAt=now()-rec.t0;await call.light(ctx,was);await sleep(2200);
    const frames=rec.end();
    const steps=[];for(let i=1;i<frames.length;i++)steps.push({t:frames[i].t,d:Math.abs((frames[i].light??0)-(frames[i-1].light??0))});
    const big=steps.sort((a,b)=>b.d-a.d)[0];
    const on=frames.filter(f=>f.t>=(was?secondAt:firstAt)&&f.t<(was?Infinity:secondAt)),off=frames.filter(f=>f.t>=(was?firstAt:secondAt)&&f.t<(was?secondAt:Infinity));
    const peak=Math.max(0,...frames.map(f=>f.light??0));
    const rampOn=on.find(f=>(f.light??0)>=.95),rampOff=off.find(f=>(f.light??0)<=.05);
    const nat=[];for(let i=1;i<frames.length;i++){const a=frames[i-1].lightA,b=frames[i].lightA;if(Number.isFinite(a)&&Number.isFinite(b))nat.push(Math.abs(b-a));}
    const natMax=stats(nat).max,natPeak=Math.max(0,...frames.map(f=>f.lightA??0));
    // (beta.37) the ramp itself, from the frame it starts; how long the request took to reach it is said apart
    // (beta.36's "full in 0.89 s" against beta.35's 0.55 s was the wait for the switch, not a slower ramp)
    const onGo=on.find(f=>(f.light??0)>.001),offGo=off.find(f=>(f.light??0)<(off[0]?.light??0)-.001);
    const span=(a,b)=>a&&b?f2((b.t-a.t)/1000)+' s':'?',wait=(a,b)=>a&&b?` (starts after ${Math.round(b.t-a.t)} ms)`:'';
    res.lines.push(`${was?'off, on':'on, off'}: peak ${f2(peak)} · full in ${span(onGo,rampOn)}${wait(on[0],onGo)} · out in ${span(offGo,rampOff)}${wait(off[0],offGo)} · biggest frame step ${f2(big?.d)}`+
      (natPeak>0?` · native source step ${f2(natMax/natPeak)} of full`:' · no native source seen'));
    if(peak<.5)verdict(res,'FAIL','the light circle never came on here'+(call.state(ctx)?.light?.error?`: ${call.state(ctx).light.error}`:''));
    else if((big?.d??0)>=.6)verdict(res,'FAIL',`light strength jumped ${f2(big.d)} in one frame`);
    else if((big?.d??0)>.25)verdict(res,'CHECK',`light strength stepped ${f2(big.d)} in one frame`);
    else verdict(res,'PASS','light ramps on and off (no one-frame jump)');
    if(natPeak>0&&natMax/natPeak>.6)verdict(res,'CHECK',`the native light source changed ${Math.round(natMax/natPeak*100)}% in one frame`);
  },

  async bits(ctx,res){
    const bits=call.bits(ctx);if(!bits?.startTool||!bits?.stopTool){res.skipped='this version has no bit tools';return;}
    await ensureFlying(ctx);ctx.check();
    let bs=call.bitState(ctx);if(bs?.busy){res.skipped='her bits are busy with a task; recall them and run again';return;}
    const homeCount=()=>(call.bitState(ctx)?.allocations??[]).filter(b=>b.location==='home').length;
    if(!homeCount()){
      await call.bitsOn(ctx,true);res.restore(async()=>{await call.bitsOn(ctx,false);await sleep(700);});
      await waitUntil(()=>homeCount()>0,3000,()=>sleep(100));await sleep(1000);
    }
    if(!homeCount()){res.skipped='no bits are with her';return;}
    const dir=freeDirection(ctx,2);if(!dir){res.skipped='no free spot 2 squares from her';return;}
    const styleBefore=setting('bitSendOutStyle');
    res.restore(async()=>{if(styleBefore!==undefined&&setting('bitSendOutStyle')!==styleBefore)await game.settings.set(ID,'bitSendOutStyle',styleBefore);});
    await settle(ctx,{timeout:1500});
    const homeOffsets=()=>{const m=ctx.token.mesh,out={},prefix=ctx.prefix;
      for(const c of canvas.primary?.children??[]){const n=c?.name;if(typeof n!=='string'||!n.startsWith(prefix))continue;const k=trackKey(n.slice(prefix.length));if(!k?.startsWith('bit:'))continue;if(!(c.visible!==false&&c.alpha>.05))continue;out[k]=[(c.x-m.x)/ctx.grid,(c.y-m.y)/ctx.grid];}
      return out;};
    // (beta.39) Her idle life (beta.35) plays a gesture now and then while she hovers still, and most of them take a
    // bit off its station for a few seconds (it wanders, orbits her, dozes, trades places...). Beta.38's "flight: not
    // home: left-gem-1" was one of those starting just as the check looked: the bit was home and went off to play.
    // Home is now measured only when no idle gesture is playing (waiting for one to finish, up to 8 s), and a
    // measurement that a gesture touched is taken again.
    const idleNow=()=>{const f=ctx.manager?.states?.get?.(ctx.token)?.feelState;if(!f)return null;
      const n=f.idleBal,swinging=n&&Math.abs(n.a)+Math.abs(n.x)+Math.abs(n.y)+Math.abs(n.va)+Math.abs(n.vx)+Math.abs(n.vy)>1e-3;
      return f.idleId!=null&&(f.idleHold??1)>.004?(f.idleType||'gesture'):swinging?'settling':null;};
    const avgOffsets=async()=>{const acc={};let idle=null;for(let i=0;i<12;i++){idle??=idleNow();const o=homeOffsets();for(const [k,v] of Object.entries(o)){const a=acc[k]??=[0,0,0];a[0]+=v[0];a[1]+=v[1];a[2]++;}await nextFrame();}
      const out=Object.fromEntries(Object.entries(acc).map(([k,a])=>[k,[a[0]/a[2],a[1]/a[2],a[2]]]));if(idle)Object.defineProperty(out,'idle',{value:idle});return out;};
    const idleWaits=[];
    const homeAtRest=async()=>{const t0=now();let seen=null;
      for(;;){const g=idleNow();if(g){seen??=g;if(now()-t0>8000)break;await sleep(150);continue;}
        const o=await avgOffsets();if(!o.idle||now()-t0>8000){if(seen||o.idle)idleWaits.push(`${seen??o.idle} ${f1((now()-t0)/1000)} s`);return o;}seen??=o.idle;}
      idleWaits.push(`${seen} still playing after 8 s`);return await avgOffsets();};
    const home=await homeAtRest();
    res.lines.push(`${Object.keys(home).length} bits home · 1 parks a light 2 sq ${dir.name}, returns · upd: the travelling bit's moves/s / canvas frames/s while it travels · step max sq/frame`);
    let worst=null,allHome=true;
    for(const style of SEND_OUT_STYLES){
      ctx.check();ctx.progress(`Bits: ${style}…`);
      try{await game.settings.set(ID,'bitSendOutStyle',style);}catch{}
      await sleep(150);
      const rec=ctx.recorder;rec.begin();await sleep(150);
      let handle=null,err=null;
      try{handle=await bits.startTool(ctx.doc,{kind:'parkLight',point:{...dir.toCenter},bits:1});}catch(e){err=String(e?.message??e);}
      if(!err){
        await sleep(2600);
        try{await bits.stopTool(ctx.doc,handle?.id?{id:handle.id}:undefined);}catch(e){err=String(e?.message??e);}
        await waitUntil(()=>!call.bitState(ctx)?.busy,5000,()=>sleep(100));await sleep(800);
      }
      const frames=rec.end();
      if(err){res.lines.push(`${style.padEnd(8)} could not run: ${err.slice(0,100)}`);verdict(res,'CHECK',`${style}: ${err.slice(0,80)}`);continue;}
      let back=await homeAtRest();
      const away=b=>[...Object.keys(home).filter(k=>!b[k]),...Object.entries(home).filter(([k,v])=>b[k]&&Math.hypot(b[k][0]-v[0],b[k][1]-v[1])>.2).map(([k])=>k)];
      // (beta.39) a bit not home yet: where it is and what her bits say, then watched for 4 s more, so a slow return and a
      // bit that never comes are told apart (beta.38's report: "flight: not home: left-gem-1", nothing more)
      let late=null;
      if(away(back).length){
        const first=away(back),t0=now(),alloc=call.bitState(ctx)?.allocations??[];
        const where=first.map(k=>{const v=home[k],b=back[k],a=alloc.find(x=>x.id===k.slice(4));
          return `${k.slice(4)} ${b?`${f2(Math.hypot(b[0]-v[0],b[1]-v[1]))} sq off`:'not drawn'}${a?` (${a.location}${a.activity&&a.activity!=='idle'?', '+a.activity:''})`:''}`;}).join(', ');
        const bs=call.bitState(ctx);
        while(now()-t0<4000){await sleep(250);back=await homeAtRest();if(!away(back).length)break;}
        late={where,events:`${bs?.active?.length??0} active, ${bs?.queued?.length??0} queued${bs?.busy?', busy':''}`,after:away(back).length?null:(now()-t0)/1000};
      }
      const missing=Object.keys(home).filter(k=>!back[k]),off=Object.entries(home).filter(([k,v])=>back[k]&&Math.hypot(back[k][0]-v[0],back[k][1]-v[1])>.2).map(([k])=>k);
      const pops=findPops(frames,ctx.grid,{skip:(t,key)=>!key.startsWith('bit:')});
      const big=pops.largest.bitMove,spikes=pops.events.filter(e=>e.kind!=='gap'&&e.key.startsWith('bit:'));
      if(!worst||(spikes[0]?.sev??0)>(worst.spike?.sev??0))worst={style,spike:spikes[0]};
      const ok=!missing.length&&!off.length;allHome&&=ok;
      const tu=travelUpdates(frames,'bit:',ctx.grid),rate=tu?.rate??null;
      if(tu&&tu.share<.6)(ctx.steppedBits??=[]).push({style,rate:Math.round(tu.rate),fps:Math.round(tu.fps)});
      res.lines.push(`${style.padEnd(8)} ${rate!=null?`upd ${Math.round(rate)}/${Math.round(tu.fps)} · `:''}step ${big?`${f2(big.d)} sq`:'-'} · ${spikes.length?`${spikes.length} pop(s)`:'no pops'} · ${ok?'all home':`not home: ${[...missing,...off].map(k=>k.slice(4)).join(', ')}`} · ms ${f1(frameStats(frames).p95)} p95`);
      for(const e of spikes.slice(0,1))res.pops.push(`${style}: ${describePop(e)}`);
      if(late)res.lines.push(`  ${style}: ${late.where} when its task was over (${late.events}) · ${late.after!=null?`home ${f1(late.after)} s later`:'still not home 4 s later'}`);
      if(late&&ok)verdict(res,'CHECK',`${style}: a bit came home ${f1(late.after)} s after its task was over`);
      if(!ok)verdict(res,'FAIL',`${style}: bits did not all get home (${[...missing,...off].map(k=>k.slice(4)).join(', ')})`);
      if(spikes.some(e=>e.amount>=.5||e.kind==='vanish'))verdict(res,'FAIL',`${style}: ${describePop(spikes[0])}`);else if(spikes.length)verdict(res,'CHECK',`${style}: ${describePop(spikes[0])}`);
    }
    if(idleWaits.length)res.lines.push(`home measured with her idle life at rest (waited for: ${idleWaits.join(', ')})`);
    if(ctx.steppedBits?.length)verdict(res,'CHECK',`travelling bits move in steps: ${ctx.steppedBits.map(x=>`${x.style} ${x.rate}/s on ${x.fps} fps`).join(', ')}`);
    if(allHome&&!res.verdicts.some(v=>v.startsWith('FAIL')||v.startsWith('CHECK')))verdict(res,'PASS','every style went out and came home with no pops');
  },

  async warp(ctx,res){
    const dir=freeDirection(ctx,3);if(!dir){res.skipped='no free spot 3 squares from her';return;}
    const range=Number(setting('warpRange'));if(range>0&&range<15){res.skipped=`warp range is ${range} ft (needs 15)`;return;}
    await ensureFlying(ctx);ctx.check();await settle(ctx,{timeout:1500});
    const home={x:ctx.doc.x,y:ctx.doc.y},c0={x:home.x+ctx.token.w/2,y:home.y+ctx.token.h/2};
    res.restore(async()=>{if(ctx.doc.x!==home.x||ctx.doc.y!==home.y){await ctx.doc.update({x:home.x,y:home.y},{animate:false});await sleep(200);}});
    const others=(canvas.tokens?.placeables??[]).filter(t=>t!==ctx.token&&t.mesh&&!t.destroyed)
      .map(t=>({token:t,d:Math.hypot(t.center.x-c0.x,t.center.y-c0.y)})).sort((a,b)=>a.d-b.d).slice(0,12)
      .map(({token:t})=>{const m=t.mesh;return {token:t,x:m.x,y:m.y,sx:m.scale?.x??1,sy:m.scale?.y??1,r:m.rotation??0,filters:m.filters?.length??0,first:m.filters?.[0]};});
    others.primaryFilters=[...(canvas.primary?.filters??[])];
    const bend=setting('warpBendTokens')===true;
    const rec=ctx.recorder;rec.begin({others,overlay:{points:[c0,dir.toCenter]},ink:true});await sleep(200);
    const outAt=now()-rec.t0;
    await warpTo(ctx.token,dir.toCenter,{style:'wings',look:'seam'});
    const near=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y)<ctx.grid*.6;
    const there=await waitUntil(()=>near(ctx.doc,dir.to),6000,()=>sleep(50));
    await sleep(2600);ctx.check();
    const backAt=now()-rec.t0;
    await warpTo(ctx.token,c0,{style:'wings',look:'seam'});
    const back=await waitUntil(()=>near(ctx.doc,home),6000,()=>sleep(50));
    await sleep(2600);
    const frames=rec.end();
    const ref=stats(frames.filter(f=>f.t<outAt).map(f=>f.ink??f.wing??0)).med||1;
    const seen=frames.map(f=>Math.max((f.ink??f.wing??0)/ref,Math.min(1,(f.ov??0)*12)));
    // wings (on the board or as her copy on the warp layer) must not drop out for 1–3 frames
    const gaps=[];for(let i=1;i<seen.length;i++){if(seen[i-1]>=.25&&seen[i]<.03){for(let j=i;j<Math.min(seen.length-1,i+3);j++)if(seen[j+1]>=.25){gaps.push({t:frames[i].t,n:j-i+1});break;}}}
    const moved=frames.filter(f=>f.oMoved>0).length,filtered=frames.filter(f=>f.oFiltered>0).length,primary=frames.filter(f=>f.pfNew).length;
    res.lines.push(`Seam ${dir.name} and back: there ${there?'yes':'NO'} · back ${back?'yes':'NO'} · ${others.length} other token(s): moved ${moved}, filtered ${filtered}${primary?`, board bent ${primary}`:''} frames · wing gaps ${gaps.length}`);
    const ends=ctx.doc.x===home.x&&ctx.doc.y===home.y;
    if(!there||!back)verdict(res,'FAIL',`she ${!there?'did not arrive':'did not come back'}`);
    else if(!ends)verdict(res,'CHECK',`she came back ${Math.round(Math.hypot(ctx.doc.x-home.x,ctx.doc.y-home.y))} px from her start (grid snapping); put back`);
    if(moved||filtered)verdict(res,'FAIL',`other tokens were ${filtered?'filtered':'moved'} during the warp (${Math.max(moved,filtered)} frames)`);
    else if(primary&&!bend)verdict(res,'CHECK','the whole board group was bent although "Warps bend nearby tokens" is off');
    else verdict(res,'PASS',`other tokens untouched${bend?' (bend setting on: the board group bends by design)':''}`);
    if(gaps.length)verdict(res,'FAIL',`her wings vanished for ${gaps[0].n} frame(s) at ${f2(gaps[0].t/1000)} s${gaps.length>1?` (+${gaps.length-1} more)`:''}`);
    else verdict(res,'PASS','her wings never dropped out for a frame');
    const fs=frameStats(frames);res.lines.push(`frames ${f1(fs.med)}/${f1(fs.p95)}/${f1(fs.max)} ms (includes sampling the warp layer)`);
    // (her token, wings, shadows and bits hand over to her copy on the warp layer by design: only moves count here)
    popVerdicts(res,findPops(frames,ctx.grid,{alphaKinds:false}),{name:' (moves only)',exclude:e=>e.key==='token'});
    // beta.33: the first ordinary move after a warp (the user: "the token sticks")
    const arrival0=setting('warpArrival');
    res.restore(async()=>{if(arrival0!==undefined&&setting('warpArrival')!==arrival0)await game.settings.set(ID,'warpArrival',arrival0);});
    for(const arrival of ['pulse','wisps']){
      ctx.check();ctx.progress(`Warp: a move after it (${arrival})…`);
      try{if(setting('warpArrival')!==arrival)await game.settings.set(ID,'warpArrival',arrival);}catch{}
      await moveAfterWarp(ctx,res,dir,home,arrival);
    }
    if(ctx.moveOk?.length)verdict(res,'PASS',`the first move after a warp shows at once (${ctx.moveOk.join(', ')})`);
  },

  async hp(ctx,res){
    const actor=ctx.doc.actor;if(!hpPath(actor)){res.skipped='her actor has no system.attributes.hp';return;}
    if(!actor.isOwner){res.skipped='you do not own her actor';return;}
    await ensureFlying(ctx);ctx.check();await settle(ctx,{timeout:1500});
    const bitsBefore=Object.keys(bitsDrawn(ctx)).length;
    const times={};const hookIds=[];
    const on=(name,fn)=>{try{hookIds.push([name,Hooks.on(name,fn)]);}catch{}};
    const rec=ctx.recorder;
    const outcome=await withHp(ctx,async(a,hp)=>{
      on('updateActor',(x,ch)=>{if(x===a||x?.uuid===a.uuid){const v=ch?.system?.attributes?.hp?.value;if(v===0&&times.hook0==null)times.hook0=now()-rec.t0;else if(v!=null&&v>0&&times.hookBack==null&&times.zeroSent!=null)times.hookBack=now()-rec.t0;}});
      on('updateToken',(d,ch)=>{if(d===ctx.doc&&ch?.flags?.[ID]&&times.zeroSent!=null&&times.flag0==null)times.flag0=now()-rec.t0;});
      rec.begin({ink:true});await sleep(1300);
      times.zeroSent=now()-rec.t0;await a.update({'system.attributes.hp.value':0,...(hp.temp?{'system.attributes.hp.temp':0}:{})});times.zeroDone=now()-rec.t0;
      await sleep(3500);ctx.check();
      times.backSent=now()-rec.t0;await a.update({'system.attributes.hp.value':hp.value,...(hp.temp?{'system.attributes.hp.temp':hp.temp}:{})});times.backDone=now()-rec.t0;
      await sleep(4000);
      return true;
    },res);
    for(const [name,id] of hookIds)try{Hooks.off(name,id);}catch{}
    const frames=rec.active?rec.end():rec.frames;
    if(outcome?.skipped){res.skipped=outcome.skipped;return;}
    // (how much of her wings is painted changes with every beat: compare a second or more of each)
    const ink=f=>f.ink??f.wing??0,mean=list=>list.length?list.reduce((n,f)=>n+ink(f),0)/list.length:0;
    const beforeWing=mean(frames.filter(f=>f.t<times.zeroSent));
    const zeroFrames=frames.filter(f=>f.t>=times.zeroSent&&f.t<times.backSent),after=frames.filter(f=>f.t>=times.backSent);
    const phase0=frames.find(f=>f.t<times.zeroSent)?.phase??null,react=zeroFrames.find(f=>(f.collapse??0)>.02||f.phase!==phase0);
    const collapsePeak=Math.max(0,...zeroFrames.map(f=>f.collapse??0));
    const recovered=after.find((f,i)=>i>0&&ink(f)>=beforeWing*.5&&(f.collapse??0)<.05);
    const lastT=frames.at(-1)?.t??0,wingEnd=mean(after.filter(f=>f.t>lastT-1300));
    const bitsAfter=Object.keys(bitsDrawn(ctx)).length;
    res.lines.push(`HP 0: updateActor ${times.hook0!=null?'+'+Math.round(times.hook0-times.zeroSent)+'ms':'unseen'} · her flag saved ${times.flag0!=null?'+'+Math.round(times.flag0-times.zeroSent)+'ms':'no'} · update done +${Math.round((times.zeroDone??0)-times.zeroSent)}ms · reacted ${react?'+'+Math.round(react.t-times.zeroSent)+'ms':'no'} · collapse ${f2(collapsePeak)}`);
    res.lines.push(`healed: updateActor ${times.hookBack!=null?'+'+Math.round(times.hookBack-times.backSent)+'ms':'unseen'} · wings back ${recovered?'+'+Math.round(recovered.t-times.backSent)+'ms':'not in 4 s'} (${beforeWing>0?Math.round(wingEnd/beforeWing*100):'?'}% painted) · bits ${bitsBefore}→${bitsAfter}`);
    if(outcome?.restoreNote)res.lines.push(outcome.restoreNote);
    if(!react)verdict(res,'CHECK','no visible reaction to 0 HP within 3.5 s (zero-HP behaviour off?)');
    if(wingEnd<beforeWing*.7)verdict(res,'FAIL',`wings did not recover (${beforeWing>0?Math.round(wingEnd/beforeWing*100):0}% of before)`);
    else if(bitsAfter<bitsBefore)verdict(res,'FAIL',`bits did not all come back (${bitsAfter} of ${bitsBefore})`);
    else verdict(res,'PASS','wings and bits recovered');
    popVerdicts(res,findPops(frames,ctx.grid));
  }
};
/* ---------------------------------------------------------------- HUD and sheet (beta.32) */
/** Frame times by requestAnimationFrame (the HUD and sheet are page work, not
 * canvas work) and long tasks, for `ms`; `probe` counts what ran meanwhile. */
async function pageWindow(ms,probe=null){
  const dts=[];let last=null,tasks=null,obs=null;
  try{if(globalThis.PerformanceObserver?.supportedEntryTypes?.includes('longtask')){tasks=[];obs=new PerformanceObserver(list=>{for(const e of list.getEntries())tasks.push(e.duration);});obs.observe({type:'longtask'});}}catch{tasks=null;}
  if(probe)probe.reset();
  await new Promise(res=>{const end=now()+ms;const step=t=>{if(last!=null)dts.push(t-last);last=t;if(now()<end)requestAnimationFrame(step);else res();};requestAnimationFrame(step);setTimeout(res,ms+1500);});
  try{obs?.disconnect();}catch{}
  const fs=stats(dts);
  return {fs,long:tasks?{n:tasks.length,ms:tasks.reduce((a,b)=>a+b,0)}:null,probe:probe?.read(ms)};
}
/** Times the Keepsake HUD's own renders and its preview paints while active. */
function hudProbe(ctrl){
  const host=KeepsakeHost.prototype,prev=KeepsakePreviews.prototype,orig={render:host.render,draw:prev.drawSlot,capture:prev.captureStep,watch:ctrl?.watch};
  const p={renders:[],paints:[],caps:[],watches:[],reset(){p.renders=[];p.paints=[];p.caps=[];p.watches=[];},
    read(ms){const s=ms/1000,sum=a=>a.reduce((x,y)=>x+y,0);return {renders:p.renders.length/s,renderMs:p.renders.length?sum(p.renders)/p.renders.length:0,renderMax:Math.max(0,...p.renders),
      paints:p.paints.length/s,paintMs:p.paints.length?sum(p.paints)/p.paints.length:0,caps:p.caps.length/s,capMs:p.caps.length?sum(p.caps)/p.caps.length:0,capMax:Math.max(0,...p.caps),watchMs:sum(p.watches)/s,busy:(sum(p.renders)+sum(p.paints)+sum(p.caps)+sum(p.watches))/s};},
    restore(){if(host.render===wrapR)host.render=orig.render;if(prev.drawSlot===wrapD)prev.drawSlot=orig.draw;if(orig.capture&&prev.captureStep===wrapC)prev.captureStep=orig.capture;if(ctrl&&ctrl.watch===wrapW)delete ctrl.watch;}};
  const wrapR=function(...a){const t=now();try{return orig.render.apply(this,a);}finally{p.renders.push(now()-t);}};
  const wrapD=function(...a){const t=now();try{return orig.draw.apply(this,a);}finally{p.paints.push(now()-t);}};
  // (beta.37) loop capture runs on its own, time-sliced; (beta.38) counted apart from what she sees painted: its steps, and the longest
  const wrapC=function(...a){const t=now();try{return orig.capture.apply(this,a);}finally{const d=now()-t;if(d>.05)p.caps.push(d);}};
  // the controller's live sweep (status, targeting, header) runs on its own timer
  const wrapW=function(...a){const t=now();try{return orig.watch.apply(this,a);}finally{p.watches.push(now()-t);}};
  host.render=wrapR;prev.drawSlot=wrapD;if(orig.capture)prev.captureStep=wrapC;if(ctrl&&typeof orig.watch==='function'&&!Object.hasOwn(ctrl,'watch'))ctrl.watch=wrapW;return p;
}
const hudShadow=ctrl=>ctrl?.app?.element?.querySelector?.('.ks-host')?.shadowRoot??null;
function hudDom(ctrl){
  const root=hudShadow(ctrl);if(!root)return {nodes:0,anims:0,kinds:''};
  let anims=[];try{anims=(root.getAnimations?.()??[]).filter(a=>a.playState==='running');}catch{}
  const kinds={};for(const a of anims){const k=a.constructor?.name==='CSSAnimation'?'css':a.constructor?.name==='CSSTransition'?'trans':'web';kinds[k]=(kinds[k]??0)+1;}
  return {nodes:root.querySelectorAll('*').length,anims:anims.length,kinds:Object.entries(kinds).map(([k,v])=>`${k} ${v}`).join(' '),previews:ctrl.app?.previews?.slots?.size??0,canvases:root.querySelectorAll('canvas').length};
}
async function hudScenario(ctx,res){
  const ctrl=ctx.service?.hudController?.();if(!ctrl){res.skipped='no HUD in this version';return;}
  if(setting('hudEnabled')===false){res.skipped='the HUD is turned off in the settings';return;}
  const wasOpen=!!(ctrl.opened&&ctrl.app?.rendered),tab0=ctrl.app?.tab??ctrl.prefs?.tab??'home';
  const probe=hudProbe(ctrl);res.restore(()=>probe.restore());
  res.restore(async()=>{
    const app=ctrl.app;try{app?.host?.component?.closeMenu?.();}catch{}
    if(app&&app.tab!==tab0)app.switchTab(tab0);
    if(!wasOpen&&ctrl.opened)await ctrl.close();
    else if(wasOpen&&!ctrl.opened){await ctrl.open();if(ctrl.app?.tab!==tab0)ctrl.app?.switchTab(tab0);}
  });
  if(wasOpen){await ctrl.close();await sleep(500);}
  const rows=[];
  const measure=async(name,extra='')=>{ctx.check();ctx.progress(`HUD: ${name}…`);const w=await pageWindow(3000,probe);rows.push({name,...w,dom:hudDom(ctrl),extra});};
  await measure('closed');
  await ctrl.open();await waitUntil(()=>hudShadow(ctrl)?.querySelector('.ks-root'),4000,()=>sleep(100));
  const app=ctrl.app;if(!app?.switchTab)throw new Error('the HUD did not open');
  if(app.tab!=='home')app.switchTab('home');await sleep(900);
  await measure('home');
  // a menu with its "Trying on" preview: open the first field menu and hover an option
  let hover='';
  try{
    const root=hudShadow(ctrl);let menu=null,via='';
    // whichever of her menus this build shows: a field row, the looks, the light notch, the bit tools
    for(const [sel,name] of [['button.field','field'],['button.lnk[aria-haspopup=dialog]','looks'],['button.notch','light'],['button.coin','tools']]){
      const b=[...root.querySelectorAll(sel)].find(x=>x.getClientRects().length);if(!b)continue;
      b.scrollIntoView?.({block:'center'});b.click();await sleep(400);menu=hudShadow(ctrl)?.querySelector('.menu');if(menu){via=name;break;}
    }
    if(!menu){const c=app.host?.component,b=root.querySelector('button.field, button.lnk, button.coin');
      for(const kind of ['field:0','looks','light']){try{c?.openMenu?.(kind,{target:b});}catch{}await sleep(400);menu=hudShadow(ctrl)?.querySelector('.menu');if(menu){via=`${kind} (direct)`;break;}}}const opts=[...(menu?.querySelectorAll('button')??[])].filter(b=>!b.classList.contains('x'));
    const opt=opts[Math.min(1,opts.length-1)];
    if(opt){opt.dispatchEvent(new MouseEvent('mouseover',{bubbles:true,composed:true,relatedTarget:null}));await sleep(500);}
    const hv=root.querySelector('.hv');hover=menu?`${via} menu, ${opts.length} options, preview ${hv&&hv.getClientRects().length?'shown':'not shown'}`:`no menu opened (triggers: ${['button.field','button.lnk','button.notch','button.coin'].map(x=>root.querySelectorAll(x).length).join('/')})`;
  }catch(e){hover=`menu failed: ${e.message}`;}
  await measure('menu+hover',hover);
  try{app.host?.component?.closeMenu?.();}catch{}
  const tabTimes={};
  for(const t of ['effects','settings']){
    const since=performance.now();app.switchTab(t);await sleep(900);await measure(t);
    try{tabTimes[t]=formatTimings(keepsakeTimings({since,top:8}));}catch(e){tabTimes[t]=`timings failed: ${e.message}`;}
  }
  // the corner flower, Hero Point petals and fonts, on Home
  try{app.switchTab('home');await sleep(700);const root=()=>hudShadow(ctrl);
    res.lines.push(skyLine([...(root()?.querySelectorAll('.ny')??[])],'hud'));
    const actor=ctx.doc?.actor;res.lines.push(await heroLine(actor,root,{fly:'.hp-fly',row:'svg.hp.held, svg.hp.arriving',flower:'.ny'},'hud',res));
    res.lines.push(fontLine(document,root(),[['name',r=>[...r.querySelectorAll('[style*="max-width: 300px"]')][0]],['title','.sec-t'],['row','.tile, .opt, .field']],'hud'));
  }catch(e){res.lines.push(`hud extras failed: ${e.message}`);}
  const base=rows[0];
  res.lines.push('ms med/p95/max · long n(ms) · renders/s(ms) · previews/s(ms) · capture steps/s(ms, max) · sweep ms/s · nodes · anims');
  const costly=[];
  for(const r of rows){
    const p=r.probe,d=r.dom;
    res.lines.push(`${r.name.padEnd(10)} ${f1(r.fs.med)}/${f1(r.fs.p95)}/${f1(r.fs.max)} · ${r.long?`${r.long.n} (${Math.round(r.long.ms)})`:'n/a'} · ${f1(p.renders)} (${f1(p.renderMs)}${p.renderMax>p.renderMs*2&&p.renderMax>4?` max ${f1(p.renderMax)}`:''}) · ${f1(p.paints)} (${f1(p.paintMs)}) · ${f1(p.caps)} (${f1(p.capMs)}, ${f1(p.capMax)}) · ${f1(p.watchMs)} · ${d.nodes} · ${d.anims}${d.kinds&&d.kinds!==`css ${d.anims}`?` [${d.kinds}]`:''}${r.extra?` · ${r.extra}`:''}`);
    if(tabTimes[r.name])res.lines.push(`  ${r.name} timings: ${tabTimes[r.name]}`);
    if(r===base)continue;
    const why=[];// (each check against the HUD closed)
    if(r.fs.med>base.fs.med*1.25+2)why.push(`med ×${f1(r.fs.med/Math.max(1,base.fs.med))}`);
    if(r.fs.p95>base.fs.p95*1.5+5)why.push(`p95 ×${f1(r.fs.p95/Math.max(1,base.fs.p95))}`);
    if(r.long&&base.long&&r.long.ms-base.long.ms>150)why.push(`long ${Math.round(r.long.ms)} ms`);
    if(p.busy>40)why.push(`work ${Math.round(p.busy)} ms/s`);
    if(why.length)costly.push(`${r.name} (${why.join(', ')})`);
  }
  if(costly.length)verdict(res,'CHECK',`costs more than closed: ${costly.join('; ')}`);
  if(!res.verdicts.length)verdict(res,'PASS','no HUD state costs much more than the HUD closed');
}

/* ---- the corner flower, Hero Point petals and fonts (sheet and HUD) */
function skyLine(petals,label){
  let s=null,src='fallback';
  try{s=worldSky();const dt=game?.pf2e?.worldClock?.worldTime;if(Number.isFinite(dt?.toMillis?.())&&Number.isFinite(dt.hour))src='pf2e worldClock';else if(Number.isFinite(game?.time?.components?.hour))src='game.time.components';}catch(e){return `${label} sky: worldSky failed (${e.message})`;}
  const tf=petals.map(p=>p.getAttribute('transform')||p.getAttribute('style')||getComputedStyle(p).transform||'');
  const nums=re=>tf.map(t=>Number(re.exec(t)?.[1])).filter(Number.isFinite);
  const rot=nums(/rotate\(\s*(-?[\d.eE+-]+)/),sc=nums(/scale\(\s*(-?[\d.eE+-]+)/);
  const boxes=petals.map(p=>{const r=p.getBoundingClientRect();return `${Math.round(r.width)}×${Math.round(r.height)}`;});
  const nan=[s.phase,s.hour,s.night].some(v=>!Number.isFinite(v))||tf.some(t=>/NaN|Infinity/.test(t));
  const rng=a=>a.length?`${f1(Math.min(...a))}…${f1(Math.max(...a))}`:'-';
  return `${label} sky: phase ${f2(s.phase)} · hour ${f1(s.hour)} (${src}) · night ${f2(s.night)} · petals ${petals.length} rotate ${rng(rot)} scale ${rng(sc)} · boxes ${[...new Set(boxes)].slice(0,3).join(' ')}${nan?' · NaN FOUND':' · no NaN'}`;
}
/** Raise her Hero Points by 1 and lower them again (or the other way at the
 * maximum), as PF2e does, watching the falling petal and the flower; always
 * puts the original value back. */
async function heroLine(actor,root,{fly,row,flower},label,res){
  const hp=actor?.system?.resources?.heroPoints;
  if(!actor?.isOwner||!Number.isFinite(Number(hp?.value)))return `${label} hero: skipped (${!actor?.isOwner?'not her owner':'no Hero Points'})`;
  const v0=Number(hp.value),max=Number(hp.max)||3,seq=v0<max?[v0+1,v0]:[v0-1,v0],out=[];
  const count=()=>root()?.querySelectorAll(row)?.length??0;
  try{
    for(const v of seq){
      const before=count(),seenAnims=new Set(),old=new Set();for(const p of root()?.querySelectorAll(flower)??[])for(const a of p.getAnimations?.({subtree:true})??[])old.add(a);
      const t0=now();let first=null,last=null,err=null;const tr0=heroTrace.length;
      try{await actor.update({'system.resources.heroPoints.value':v});}catch(e){err=e.message;}
      while(now()-t0<2600){
        const r=root();if(r){if(r.querySelector(fly)){first??=now()-t0;last=now()-t0;}
          for(const p of r.querySelectorAll(flower)){for(const a of p.getAnimations?.({subtree:true})??[])if(!old.has(a))seenAnims.add(a);}}
        await nextFrame();
      }
      const names=[...new Set([...seenAnims].map(a=>a.animationName??a.constructor?.name).filter(Boolean))];
      // what the sheet/HUD itself said it did with this change (api.sheet.heroTrace())
      const tr=heroTrace.slice(Math.max(0,Math.min(tr0,heroTrace.length-6))).filter(e=>e.where===label).slice(-3).map(e=>`${e.from!=null?`${e.from}→${e.to} `:''}${e.did}`);
      out.push(`${v>(out.length?seq[0]:v0)?'+1':'-1'}: fly ${first!=null?`${f1((last-first)/1000+.02)} s`:'none'} · new flower anims ${seenAnims.size}${names.length?` (${names.slice(0,2).join(',')})`:''} · row ${before}→${count()}${err?` · error ${err}`:''} · trace ${tr.length?tr.join('; '):'none'}`);
    }
  }finally{if(Number(actor.system?.resources?.heroPoints?.value)!==v0)try{await actor.update({'system.resources.heroPoints.value':v0});}catch{}}
  const back=Number(actor.system?.resources?.heroPoints?.value)===v0;
  if(!back&&res)verdict(res,'FAIL',`${label}: her Hero Points were not put back`);
  return `${label} hero (${v0}/${max}): ${out.join(' | ')} · put back ${back?'yes':'NO'}`;
}
function fontLine(doc,root,picks,label){
  const fams=['Keepsake Serif','Keepsake Caps','Keepsake Sans'];
  const st=fams.map(f=>{let ok=false,faces=[];try{ok=doc.fonts.check(`16px "${f}"`);faces=[...doc.fonts].filter(x=>x.family.replace(/["']/g,'')===f).map(x=>x.status);}catch{}
    return `${f.replace('Keepsake ','K.')} ${faces.length?[...new Set(faces)].join('/'):'no face'}${ok?'':' ✗'}`;});
  const used=picks.map(([n,sel])=>{let e=null;try{e=typeof sel==='function'?sel(root):root?.querySelector?.(sel);}catch{}return `${n} ${e?getComputedStyle(e).fontFamily.split(',')[0].replace(/["']/g,'').trim():'-'}`;});
  // (beta.35) Rank letters, coins and chips are centred with CSS text-box (Chrome 133+).
  let tb='?',chrome='?';try{tb=CSS.supports('text-box','trim-both cap alphabetic')?'yes':'NO';chrome=(navigator.userAgent.match(/Chrome\/(\d+)/)??[])[1]??'?';}catch{}
  return `${label} fonts: ${st.join(' · ')} · used: ${used.join(', ')} · text-box ${tb} (Chrome ${chrome})`;
}
// (beta.40) only ever an Element: Foundry's Application (v1) answers `element` with $('#id'), an empty jQuery, while
// the window is not in the page (before its first render lands, and after it closes); beta.39 passed that on, and the
// sheet warm-up's sampler threw on it every 250 ms for the rest of the run (62 uncaught, and no warm-up line)
const elOf=x=>{const e=x?.[0]??x;return e&&e.nodeType===1&&typeof e.querySelectorAll==='function'?e:null;};
const shortEl=e=>{if(!e)return 'nothing';const c=[...(e.classList??[])].slice(0,2).join('.');return `${e.tagName?.toLowerCase()??'?'}${e.id?'#'+e.id.slice(0,24):''}${c?'.'+c:''}`;};
function boxIn(e,ref){const r=e.getBoundingClientRect(),o=ref?.getBoundingClientRect?.()??{left:0,top:0};return {x:Math.round(r.left-o.left),y:Math.round(r.top-o.top),w:Math.round(r.width),h:Math.round(r.height),cx:r.left+r.width/2,cy:r.top+r.height/2,r};}
const hitAt=(x,y)=>{try{return document.elementFromPoint(x,y);}catch{return null;}};
/** What sits on top at a point: the top element, and whether it belongs to `target`. */
function hitDesc(x,y,target){const h=hitAt(x,y);if(!h)return 'off-screen';return target&&(h===target||target.contains(h))?`itself (${shortEl(h)})`:shortEl(h);}
async function pointerDrag(x,y,dx,dy){
  const target=hitAt(x,y)??document.body,base={bubbles:true,cancelable:true,composed:true,pointerId:1,pointerType:'mouse',isPrimary:true,button:0,buttons:1,view:globalThis};
  const fire=(t,type,px,py,extra={})=>{const o={...base,clientX:px,clientY:py,screenX:px,screenY:py,...extra};try{t.dispatchEvent(new PointerEvent(type,o));}catch{}const m={pointerdown:'mousedown',pointermove:'mousemove',pointerup:'mouseup'}[type];try{t.dispatchEvent(new MouseEvent(m,o));}catch{}};
  fire(target,'pointerdown',x,y);
  // (moves and the release go to whatever is under the pointer, as a browser sends them, never to document itself)
  for(let k=1;k<=5;k++){await nextFrame();await sleep(20);const px=x+dx*k/5,py=y+dy*k/5;fire(hitAt(px,py)??target,'pointermove',px,py);}
  await nextFrame();fire(hitAt(x+dx,y+dy)??target,'pointerup',x+dx,y+dy,{buttons:0});await sleep(250);
  return shortEl(target);
}
/** Her sheet's window: class chain, title bar, handles, menus, and a real drag and resize.
 * (beta.36) The self-check's own progress panel floats over the middle of
 * the screen: on the user's screen it covered the PF2e sheet's resize
 * handle, so the resize grabbed the panel's <p> ("resize (p): size did NOT
 * change"). The panel now lets the pointer through while a window is
 * probed, and the resize grabs a point where the handle itself is on top. */
async function probeWindow(app){
  // (pointer-events none: hit tests and the synthetic pointer pass through it; it stays on screen)
  const panel=document.getElementById('ff-self-check'),pe=panel?.style.pointerEvents??'';
  if(panel)panel.style.setProperty('pointer-events','none','important');
  try{return await probeWindowBody(app);}
  finally{if(panel){panel.style.removeProperty('pointer-events');if(pe)panel.style.pointerEvents=pe;}}
}
/** A point inside `e` where `e` (or a child of it) is the top element, else its centre. */
function grabPoint(e){
  const r=e.getBoundingClientRect();
  for(const [fx,fy] of [[.5,.5],[.3,.3],[.7,.7],[.3,.7],[.7,.3],[.15,.5],[.5,.15],[.85,.5],[.5,.85],[.15,.15],[.85,.85]]){
    const x=r.left+r.width*fx,y=r.top+r.height*fy,h=hitAt(x,y);if(h&&(h===e||e.contains(h)))return {x,y,clear:true};
  }
  return {x:r.left+r.width/2,y:r.top+r.height/2,clear:false};
}
async function probeWindowBody(app){
  const el=elOf(app.element),out={};if(!el)return {error:'no window element'};
  const chain=[];let c=app.constructor;while(c&&chain.length<7&&c.name){chain.push(c.name);c=Object.getPrototypeOf(c);}
  const V2=globalThis.foundry?.applications?.api?.ApplicationV2;
  out.kind=V2&&app instanceof V2?'V2':'V1';out.chain=chain.join('<');
  out.classes=[...el.classList].join(' ').slice(0,140);
  const cs=getComputedStyle(el);out.overflow=cs.overflow;
  const header=el.querySelector(':scope > .window-header')??el.querySelector('.window-header');
  if(!header)return {...out,error:'no title bar'};
  const hb=boxIn(header,el);out.header=`${hb.w}x${hb.h} z${getComputedStyle(header).zIndex} pe ${getComputedStyle(header).pointerEvents}`;
  const kids=[...header.children];
  out.children=kids.map(k=>{const r=k.getBoundingClientRect();return `${k.tagName.toLowerCase()}${k.classList.length?'.'+[...k.classList].slice(0,2).join('.'):''}${k.dataset?.action?`[${k.dataset.action}]`:''}${getComputedStyle(k).display==='none'?' hidden':` ${Math.round(r.width)}`}`;});
  // three free points: left of the buttons, a gap between them, the title
  const items=kids.filter(k=>k.matches('a,button,menu,select,[data-action]')&&k.getBoundingClientRect().width>0).map(k=>k.getBoundingClientRect()).sort((a,b)=>a.left-b.left);
  const hr=hb.r,midY=hr.top+hr.height/2,pts=[];
  if(items.length&&items[0].left-hr.left>14)pts.push(['left',hr.left+Math.min(10,(items[0].left-hr.left)/2),midY]);
  for(let i=1;i<items.length;i++)if(items[i].left-items[i-1].right>=6){pts.push(['gap',(items[i].left+items[i-1].right)/2,midY]);break;}
  const title=header.querySelector('.window-title');
  if(title&&title.getBoundingClientRect().width>2){const t=title.getBoundingClientRect();pts.push(['title',t.left+t.width/2,t.top+t.height/2]);}
  else pts.push(['title','none']);
  out.title=title?`"${(title.textContent??'').trim().slice(0,30)}" ${Math.round(title.getBoundingClientRect().width)}px`:'none';
  out.points=pts.map(([n,x,y])=>x==='none'?`${n}: no title shown`:`${n}: ${hitDesc(x,y,header)}`);
  // the resize handle
  // (beta.36: the first one shown: her sheet's own grip, else Foundry's handle)
  const handles=[...el.querySelectorAll(':scope > .ffks-grip, :scope > .window-resizable-handle, :scope > .window-resize-handle, .window-resize-handle, .window-resizable-handle')];
  const rh=handles.find(h=>getComputedStyle(h).display!=='none'&&h.getBoundingClientRect().width>0)??handles[0]??null;
  if(el.classList.contains('ffks-locked'))out.resized='locked (her title-bar lock is on: no resizing by design)';
  if(rh){const b=boxIn(rh,el),s=getComputedStyle(rh);out.resize=`${shortEl(rh)} at ${b.x},${b.y} ${b.w}x${b.h} z${s.zIndex} pe ${s.pointerEvents} ${s.visibility}${s.display==='none'?' display:none':''} · hit: ${hitDesc(b.cx,b.cy,rh)}`;}
  else out.resize='none found';
  // a controls dropdown / menu in or beside the title bar
  const dd=el.querySelector(':scope > .window-header .controls-dropdown, :scope > .controls-dropdown, :scope > .window-header menu, :scope > .window-header [class*=dropdown]');
  if(dd){const b=boxIn(dd,el),s=getComputedStyle(dd),er=el.getBoundingClientRect(),r=b.r;
    const clipped=cs.overflow!=='visible'&&(r.bottom>er.bottom||r.right>er.right||r.top<er.top||r.left<er.left);
    out.dropdown=`${shortEl(dd)} ${dd.classList.contains('expanded')||s.display!=='none'&&r.height>2?'open':'closed'} at ${b.x},${b.y} ${b.w}x${b.h}${clipped?' CLIPPED by the window':''}${r.height>2?` · hit: ${hitDesc(b.cx,b.cy,dd)}`:''}`;}
  // a stray label at the top right (the user's "Token")
  const stray=[...el.querySelectorAll(':scope > .window-header *')].filter(e=>!e.children.length&&e.textContent.trim()&&e.getBoundingClientRect().top>hr.bottom-2).slice(0,3);
  if(stray.length)out.stray=stray.map(e=>`${shortEl(e)} "${e.textContent.trim().slice(0,16)}"`).join(', ');
  // a real drag on a free spot, and a real resize; then put them back
  const pos0={...app.position},r0=el.getBoundingClientRect();
  const free=pts.find(p=>p[1]!=='none'&&hitAt(p[1],p[2])&&header.contains(hitAt(p[1],p[2]))&&!hitAt(p[1],p[2]).closest('a,button'));
  if(free){const hit=await pointerDrag(free[1],free[2],60,60);const r=el.getBoundingClientRect();
    out.drag=`from ${free[0]} (${hit}): ${Math.abs(r.left-r0.left)>20||Math.abs((app.position?.left??0)-(pos0.left??0))>20?`moved ${Math.round(r.left-r0.left)},${Math.round(r.top-r0.top)}`:'did NOT move'}`;}
  else out.drag='no free spot in the title bar to grab';
  try{app.setPosition?.({left:pos0.left,top:pos0.top});}catch{}await sleep(200);
  if(rh&&!out.resized&&getComputedStyle(rh).display!=='none'){const g=grabPoint(rh),w0=el.getBoundingClientRect();const hit=await pointerDrag(g.x,g.y,60,60);const w1=el.getBoundingClientRect();
    out.resized=`(${hit}${g.clear?'':`: the handle is covered by ${hit} everywhere`}): ${Math.abs(w1.width-w0.width)>20||Math.abs(w1.height-w0.height)>20?`resized ${Math.round(w1.width-w0.width)},${Math.round(w1.height-w0.height)}`:'size did NOT change'}`;}
  try{app.setPosition?.({left:pos0.left,top:pos0.top,width:pos0.width,height:pos0.height});}catch{}await sleep(200);
  const r1=el.getBoundingClientRect();out.putBack=Math.abs(r1.left-r0.left)<2&&Math.abs(r1.top-r0.top)<2&&Math.abs(r1.width-r0.width)<2&&Math.abs(r1.height-r0.height)<2;
  return out;
}
function windowLines(res,w,label,brief=false){
  if(w.error){res.lines.push(`${label}: ${w.error}`);return;}
  const broken=/NOT|no free/.test(`${w.drag} ${w.resized}`)||w.resize==='none found'&&!w.resized?.startsWith('locked');
  if(brief){res.lines.push(`${label}: App${w.kind} · drag ${w.drag} · resize ${w.resized??'not tried'} · bar ${w.children.length} items`);return;}
  res.lines.push(`${label}: App${w.kind} ${w.chain} · overflow ${w.overflow} · bar ${w.header} · title ${w.title}`);
  res.lines.push(`  bar: ${w.children.join(' | ').slice(0,260)}`);
  if(broken)res.lines.push(`  hits: ${w.points.join(' · ')} · resize ${w.resize}`);
  if(w.dropdown||w.stray)res.lines.push(`  ${w.dropdown?`menu ${w.dropdown}`:''}${w.stray?` · under the bar: ${w.stray}`:''}`);
  res.lines.push(`  drag ${w.drag} · resize ${w.resized??'not tried'}${w.putBack?'':' · NOT put back'}`);
}
/** (beta.37) What the graphics side has to redo for a window each frame the
 * canvas under it changes: blurs of what is behind it (backdrop-filter), filters,
 * masks and blend modes on it or its ancestors, and how many of its elements
 * carry them or are layered (will-change) or loop for ever. */
function layerLine(win){
  if(!win)return 'sheet layers: no window';
  const own=[];for(let a=win;a&&a!==document.documentElement;a=a.parentElement){const c=getComputedStyle(a),bits=[];
    if(c.backdropFilter&&c.backdropFilter!=='none')bits.push(`backdrop ${c.backdropFilter}`);if(c.filter!=='none')bits.push(`filter ${c.filter}`);
    if(c.mixBlendMode!=='normal')bits.push(`blend ${c.mixBlendMode}`);if((c.maskImage||c.webkitMaskImage||'none')!=='none')bits.push('mask');if(+c.opacity<1)bits.push(`op ${c.opacity}`);
    if(bits.length)own.push(`${shortEl(a)} ${bits.join(' ').slice(0,60)}`);}
  const n={els:0,backdrop:0,filter:0,mask:0,blend:0,layered:0};let big=null;
  for(const e of win.querySelectorAll('*')){const c=getComputedStyle(e);if(c.display==='none')continue;n.els++;
    if(c.backdropFilter&&c.backdropFilter!=='none'){n.backdrop++;const r=e.getBoundingClientRect();if(!big||r.width*r.height>big[1])big=[shortEl(e),r.width*r.height,`${Math.round(r.width)}x${Math.round(r.height)}`];}
    if(c.filter!=='none')n.filter++;if((c.maskImage||c.webkitMaskImage||'none')!=='none')n.mask++;if(c.mixBlendMode!=='normal')n.blend++;if(c.willChange!=='auto')n.layered++;}
  const loops=(()=>{try{return win.getAnimations({subtree:true}).filter(a=>a.effect?.getTiming?.().iterations===Infinity).length;}catch{return '?';}})();
  return `sheet layers: window+ancestors ${own.length?own.join('; '):'plain'} · inside ${n.els} shown: backdrop ${n.backdrop}${big?` (largest ${big[0]} ${big[2]})`:''} · filter ${n.filter} · mask ${n.mask} · blend ${n.blend} · will-change ${n.layered} · endless loops ${loops}`;
}
async function sheetScenario(ctx,res){
  const actor=herActor()??ctx.doc?.actor??null;
  if(!actor){res.skipped='her actor is not known (pin her in the HUD)';return;}
  if(!keepsakeOn(actor)){res.skipped='sheet off (the Keepsake sheet is not on for you)';return;}
  const sheet=actor.sheet;if(!sheet?.render){res.skipped='she has no sheet';return;}
  const wasOpen=!!sheet.rendered;
  res.restore(async()=>{try{if(isDressed(sheet)===false&&keepsakeOn(actor)){setStandard(sheet,false);await sheet.render(false);}}catch{}if(!wasOpen&&sheet.rendered)await sheet.close();});
  if(!wasOpen)await sheet.render(true);
  const ready=await waitUntil(()=>elOf(sheet.element)?.querySelector?.('.ffks-ptr img.ffks-ptr-img'),6000,()=>sleep(100));
  const el=elOf(sheet.element);

  if(!ready){verdict(res,'FAIL','the Keepsake portrait (.ffks-ptr) never appeared');}
  else{
    const ptr=el.querySelector('.ffks-ptr'),img=ptr.querySelector('img.ffks-ptr-img'),head=ptr.closest('header')??el.querySelector('header');
    await waitUntil(()=>img.complete,3000,()=>sleep(100));
    const cfg=portraitConfig(actor);
    res.lines.push(`portrait: mode ${cfg.mode} set ${cfg.set} sheet ${cfg.sheet} hud ${cfg.hud} stages ${Object.keys(cfg.stages).join(',')||'none'} one ${cfg.one?.src?'set':'unset'} · actor img ${actor.img} · ${ptr.className.replace('ffks-ptr ','')}`);
    res.lines.push(`img ${img.getAttribute('src')} · loaded ${img.complete&&img.naturalWidth>0?`yes ${img.naturalWidth}x${img.naturalHeight}`:img.complete?'FAILED (complete, 0 px)':'no'}`);
    const b=boxIn(img,head),pb=boxIn(ptr,head),hb=head.getBoundingClientRect();
    const st=getComputedStyle(img),ps=getComputedStyle(ptr);
    const mask=st.maskImage||st.webkitMaskImage||'none';
    let dim=[],a=img.parentElement;while(a&&a!==el){const s=getComputedStyle(a);if(+s.opacity<.99||s.visibility==='hidden'||s.display==='none'||s.contentVisibility==='hidden')dim.push(`${shortEl(a)} op ${s.opacity} ${s.visibility} ${s.display}`);a=a.parentElement;}
    const stack=(()=>{try{return document.elementsFromPoint(b.cx,b.cy).slice(0,5);}catch{return [];}})();
    const top=stack[0],covered=top&&top!==img&&!ptr.contains(top);
    res.lines.push(`box ${b.x},${b.y} ${b.w}x${b.h} in header ${Math.round(hb.width)}x${Math.round(hb.height)}${pb.x!==b.x||pb.w!==b.w?` (ptr ${pb.x},${pb.y} ${pb.w}x${pb.h})`:''} · op ${st.opacity} ${st.visibility} ${st.display} · filter ${st.filter} · z ${st.zIndex}/${ps.zIndex} · mask ${mask==='none'?'none':'set'}${dim.length?` · ancestors: ${dim.slice(0,2).join('; ')}`:''} · centre hit ${shortEl(top)}${covered?` COVERS it (${stack.map(shortEl).join(' > ')})`:''}`);
    if(img.complete&&!img.naturalWidth)verdict(res,'FAIL',`her portrait image did not load (${img.getAttribute('src')})`);
    else if(b.w<20||b.h<20||+st.opacity<.05||st.visibility==='hidden'||st.display==='none'||dim.length)verdict(res,'FAIL','her portrait is there but not visible (size, opacity or an ancestor)');
    else if(covered)verdict(res,'FAIL',`her portrait is covered by ${shortEl(top)}`);
    else if(!img.complete)verdict(res,'CHECK','her portrait had not loaded after 3 s');
    else verdict(res,'PASS','her portrait loads and is visible');
  }
  try{const root=()=>elOf(sheet.element);
    res.lines.push(skyLine([...(root()?.querySelectorAll('.ffks-corner.tl use[href="#ffks-petal"]')??[])],'sheet'));
    // (a spent petal is .ffks-flypetal, a new one .ffks-flysvg: beta.34 looked for the new one only, so every spend read 'none')
    res.lines.push(await heroLine(actor,root,{fly:'.ffks-flysvg, .ffks-flypetal',row:'.pips > i.held',flower:'.ffks-corner.tl'},'sheet',res));
    res.lines.push(fontLine(document,root(),[['name','h1.char-name'],['title','.ffks-sec-h .t'],['row','.ffks-tile .value, li']],'sheet'));
  }catch(e){res.lines.push(`sheet extras failed: ${e.message}`);}
  // the window: dressed, then PF2e's own look for a moment as a baseline
  ctx.progress('Sheet: title bar, moving and resizing…');
  const w=await probeWindow(sheet);windowLines(res,w,'keepsake');
  const fs=(await pageWindow(3000)).fs;res.lines.push(`frames with the sheet open ${f1(fs.med)}/${f1(fs.p95)}/${f1(fs.max)} ms`);
  try{res.lines.push(layerLine(elOf(sheet.element)));}catch(e){res.lines.push(`sheet layers: ${String(e?.message??e).slice(0,60)}`);}
  let base=null;
  try{setStandard(sheet,true);await sheet.render(false);await waitUntil(()=>!isDressed(sheet),3000,()=>sleep(100));await sleep(300);
    if(!isDressed(sheet)){base=await probeWindow(sheet);windowLines(res,base,'standard',true);}}
  finally{setStandard(sheet,false);await sheet.render(false);await waitUntil(()=>isDressed(sheet),3000,()=>sleep(100));}
  if(w.drag?.includes('NOT')||w.drag?.startsWith('no free'))verdict(res,base&&!base.drag?.includes('NOT')?'FAIL':'CHECK',`her Keepsake sheet ${w.drag.startsWith('no free')?'has no free spot to grab':'does not move when dragged'}${base?` (PF2e's own: ${base.drag.includes('NOT')?'does not either':'moves'})`:''}`);
  if(!w.resized?.startsWith('locked')&&(w.resized?.includes('NOT')||w.resize==='none found'))verdict(res,base&&base.resized&&!base.resized.includes('NOT')?'FAIL':'CHECK',`her Keepsake sheet does not resize${base?` (PF2e's own: ${base.resized?.includes('NOT')||!base.resized?'not either':'resizes'})`:''}`);
  if(w.dropdown?.includes('CLIPPED'))verdict(res,'FAIL','a title-bar menu is clipped by the window');
}
SCENARIO_RUN.hud=hudScenario;SCENARIO_RUN.sheet=sheetScenario;

/** Warp 3 squares, wait until the warp has finished on screen, then move one
 * square the ordinary way and watch her token, wings and bits follow. */
async function moveAfterWarp(ctx,res,dir,home,arrival){
  const doc=ctx.doc,token=ctx.token,g=ctx.grid,alpha0=token.mesh?.alpha??1;
  const mv=()=>({state:doc.movement?.state??'-',hist:Array.isArray(doc.movementHistory)?doc.movementHistory.length:(doc._movementHistory?.length??'-')});
  try{
    await warpTo(token,dir.toCenter,{style:'wings',look:'seam'});
    await waitUntil(()=>Math.hypot(doc.x-dir.to.x,doc.y-dir.to.y)<g*.6,6000,()=>sleep(50));
    // the warp is over on screen: its layer released and her token back to its own alpha
    const done=await waitUntil(()=>{const L=document.getElementById('ff-warp-layer');return (!L||!L.width)&&Math.abs((token.mesh?.alpha??1)-alpha0)<.02;},8000,()=>sleep(50));
    await sleep(250);
    // one square on: onward if free, else back toward where she came from
    const fx=doc.x+dir.ux*g,fy=doc.y+dir.uy*g,onward=!tokenBlocks(ctx,fx,fy);
    const to={x:onward?fx:doc.x-dir.ux*g,y:onward?fy:doc.y-dir.uy*g},from={x:doc.x,y:doc.y};
    const m0={x:token.mesh.x,y:token.mesh.y},target={x:m0.x+(to.x-from.x),y:m0.y+(to.y-from.y)},before=mv();
    const parts=f=>{const pick=p=>{const k=Object.keys(f.tr).filter(k=>k.startsWith(p)&&f.tr[k][2]>.05);if(!k.length)return null;return {x:k.reduce((n,x)=>n+f.tr[x][0],0)/k.length,y:k.reduce((n,x)=>n+f.tr[x][1],0)/k.length};};return {w:pick('wing:'),b:pick('bit:')};};
    const rec=ctx.recorder;rec.begin();await nextFrame();const startT=now()-rec.t0;
    const how=typeof doc.move==='function'?'move()':'update()';
    let err=null;const p=(typeof doc.move==='function'?doc.move([{x:to.x,y:to.y}]):doc.update({x:to.x,y:to.y}));Promise.resolve(p).catch(e=>{err=e?.message??String(e);});
    await sleep(1500);const frames=rec.end().filter(f=>f.t>=startT);
    const after=mv(),docMoved=doc.x===to.x&&doc.y===to.y;
    const startIdx=frames.findIndex(f=>Math.hypot((f.mx??m0.x)-m0.x,(f.my??m0.y)-m0.y)>.5);
    const last=frames.at(-1),off=last?Math.hypot(last.mx-target.x,last.my-target.y):Infinity;
    const p0=parts(frames[0]??{tr:{}}),p1=parts(last??{tr:{}}),dx=target.x-m0.x,dy=target.y-m0.y;
    const follow=(a,b)=>!a||!b?'-':Math.hypot(b.x-a.x-dx,b.y-a.y-dy)<g*.25?'yes':'NO';
    res.lines.push(`move after warp (${arrival}, ${how}${done?'':', warp not settled'}): doc ${docMoved?'moved':'NOT moved'} · mesh starts frame ${startIdx<0?'never':startIdx+1} · ends ${f1(off)} px off · wings ${follow(p0.w,p1.w)} bits ${follow(p0.b,p1.b)} · movement ${before.state}→${after.state} history ${before.hist}→${after.hist}${err?` · error ${err.slice(0,60)}`:''}`);
    if(docMoved&&startIdx<0)verdict(res,'FAIL',`first move after warp did not show (${arrival})`);
    else if(startIdx<0||startIdx>5)verdict(res,'FAIL',`after a warp (${arrival}) her token took ${startIdx<0?'forever':startIdx+1+' frames'} to start moving`);
    else if(off>2)verdict(res,'FAIL',`after a warp (${arrival}) her token ended ${f1(off)} px from the new square`);
    else (ctx.moveOk??=[]).push(arrival);
  }finally{
    if(doc.x!==home.x||doc.y!==home.y){try{await doc.update({x:home.x,y:home.y},{animate:false});}catch{}await sleep(250);}
  }
}
/* ---------------------------------------------------------------- PERFORMANCE (beta.34) */
const UPLOADS={w:['wingTextureUploads'],b:['bitTextureUploads'],fx:['projectionEmitterTextureUploads','treatmentTextureUploads','treatmentEmitterTextureUploads','scanTextureUploads','companionCurrentUploads','textureUploads'],tr:['trailVisibilityTests']};
/* ---- (beta.38) where an open sheet's frame time goes while she moves ----
 * Beta.37's report: with her sheet open the main thread worked 11.5 ms a frame
 * while she moved, 7.4 with it minimised, all loops held. These name the part. */
/** Who called: the first module or system on the stack below `fn` (else foundry). */
function callerOf(fn){
  const h={},lim=Error.stackTraceLimit;
  try{Error.stackTraceLimit=40;if(typeof Error.captureStackTrace==='function')Error.captureStackTrace(h,fn);else h.stack=new Error().stack;}catch{}finally{try{Error.stackTraceLimit=lim;}catch{}}
  let lines=String(h.stack??'').split('\n').slice(1);
  // (beta.40) see through the self-check's own frame-split wrapper: a callback it runs that asks for the next frame
  // (Foundry's ticker does, every frame) has that wrapper below it on the stack, and in the bundle the wrapper is
  // flight.mjs like the rest of the module; beta.39 credited 6.5 ms of other code's rAF work to filament-flight so.
  // Everything from the wrapper's call site down is the wrapper, not who asked.
  const cut=invokeSite();if(cut){const i=lines.findIndex(l=>l.includes(cut));if(i>=0)lines=lines.slice(0,i);}
  try{return perceptionCaller(`Error\n(x)\n${lines.join('\n')}`);}catch{return {source:'?',at:'?'};}
}
/** Runs one animation-frame callback for frameSplit; one call site, so its stack line can be recognised. */
function rafInvoke(cb,self,t){return cb.call(self,t);}
let invokeSig;
/** "file:line:col" of rafInvoke's call into a callback, as stacks show it (found once, by a probe). */
function invokeSite(){
  if(invokeSig!==undefined)return invokeSig;invokeSig=null;
  try{rafInvoke(()=>{const l=String(new Error().stack??'').split('\n')[2]??'';const m=l.match(/\(?([^()\s]+:\d+:\d+)\)?\s*$/);if(m)invokeSig=m[1];},null,0);}catch{}
  return invokeSig;
}
const pkgOfURL=u=>{const m=String(u||'').match(/\/(modules|systems)\/([^/]+)\//);return m?m[2]:u?(/\/scripts\/|foundry/.test(u)?'foundry':'page'):'(no file)';};
/** Per display frame: when its animation-frame callbacks ran (and whose they
 * are, by who asked for them), and when the first task after its rendering
 * (style, layout, paint, commit) started. Restored exactly by stop(). */
function frameSplit(){
  const W=globalThis,orig=W.requestAnimationFrame;if(typeof orig!=='function')return null;
  const frames=new Map(),who=new WeakMap(),bySrc={};let named=0,off=false;
  const raf=function(cb){
    if(off||typeof cb!=='function')return orig.call(W,cb);
    let src=who.get(cb);if(!src){src=named++<300?callerOf(raf).source:'other';who.set(cb,src);}
    return orig.call(W,function(t){const s=now();try{return rafInvoke(cb,this,t);}finally{const e=now();let f=frames.get(t);
      if(!f){f={first:s,last:e,script:0};frames.set(t,f);}if(s<f.first)f.first=s;if(e>f.last)f.last=e;f.script+=e-s;bySrc[src]=(bySrc[src]??0)+(e-s);}});
  };
  W.requestAnimationFrame=raf;
  return {frames,bySrc,stop(){off=true;if(W.requestAnimationFrame===raf)W.requestAnimationFrame=orig;}};
}
/** Long animation frames (Chrome 123+: only frames over 50 ms): where each went. */
function loafWatch(){
  const list=[];let obs=null;
  try{if(PerformanceObserver.supportedEntryTypes?.includes('long-animation-frame')){obs=new PerformanceObserver(l=>{for(const e of l.getEntries())list.push(e);});obs.observe({type:'long-animation-frame'});}}catch{obs=null;}
  return {supported:!!obs,stop(){try{obs?.disconnect();}catch{}
    let before=0,raf=0,render=0,forced=0;const src={};
    for(const e of list){const end=e.startTime+e.duration,rs=e.renderStart||end,sl=e.styleAndLayoutStart||end;
      before+=Math.max(0,rs-e.startTime);raf+=Math.max(0,sl-rs);render+=Math.max(0,end-sl);
      for(const sc of e.scripts??[]){const k=pkgOfURL(sc.sourceURL);const r=src[k]??={ms:0,forced:0,top:''};r.ms+=sc.duration;r.forced+=sc.forcedStyleAndLayoutDuration??0;forced+=sc.forcedStyleAndLayoutDuration??0;
        if(!r.top||sc.duration>r.topMs){r.top=`${sc.invokerType??''} ${String(sc.invoker??'').slice(0,50)}`.trim();r.topMs=sc.duration;}}}
    return {n:list.length,ms:list.reduce((a,e)=>a+e.duration,0),before,raf,render,forced,src};}};
}
/** What is written to the page while it runs: attribute, child and text changes
 * by where they land (in the sheet; on html, body or the sheet's ancestors,
 * which restyle everything under them; elsewhere), stylesheet edits, and who
 * calls the DOM's writers (sampled stacks). Restored exactly by stop(). */
function domCensus(win){
  const doc=globalThis.document;if(!doc?.documentElement||typeof MutationObserver!=='function')return null;
  const where=n=>{const e=n instanceof Element?n:n?.parentElement;if(!e)return 'other';if(win&&win.contains(e))return 'sheet';if(e===doc.documentElement||e===doc.body||(win&&e.contains(win)))return 'root';return 'other';};
  const counts=new Map(),writers={};let calls=0,off=false;
  const take=list=>{for(const m of list){const e=m.target instanceof Element?m.target:m.target?.parentElement;
    const k=`${where(m.target)}|${shortEl(e)} ${m.type==='attributes'?'@'+m.attributeName:m.type==='childList'?'children':'text'}`;counts.set(k,(counts.get(k)??0)+1);}};
  const mo=new MutationObserver(take);
  try{mo.observe(doc.documentElement,{subtree:true,attributes:true,childList:true,characterData:true});}catch{}
  const undo=[];
  const wrap=(proto,name,kind)=>{const d=proto&&Object.getOwnPropertyDescriptor(proto,name);if(!d||typeof d.value!=='function')return;const orig=d.value;
    const w=function(...a){if(!off&&((calls++&7)===0||calls<64)){try{const k=`${kind(this)} ${callerOf(w).source}`;writers[k]=(writers[k]??0)+(calls<64?1:8);}catch{}}return orig.apply(this,a);};
    try{proto[name]=w;undo.push(()=>{if(proto[name]===w)proto[name]=orig;});}catch{}};
  // (setters: inline style properties written by name, el.style.left=…, can't be wrapped; the census above still names their element)
  const wrapSet=(proto,name,kind)=>{const d=proto&&Object.getOwnPropertyDescriptor(proto,name);if(!d||typeof d.set!=='function')return;const orig=d.set;
    const set=function(v){if(!off&&((calls++&7)===0||calls<64)){try{const k=`${kind(this)} ${callerOf(set).source}`;writers[k]=(writers[k]??0)+(calls<64?1:8);}catch{}}return orig.call(this,v);};
    try{Object.defineProperty(proto,name,{...d,set});undo.push(()=>{const now=Object.getOwnPropertyDescriptor(proto,name);if(now?.set===set)Object.defineProperty(proto,name,d);});}catch{}};
  const decl=d=>d?.parentRule?'stylesheet rule':'inline style';
  wrapSet(globalThis.CSSStyleDeclaration?.prototype,'cssText',decl);
  wrapSet(globalThis.Element?.prototype,'className',e=>where(e)==='other'?'class':`class (${where(e)})`);
  wrapSet(globalThis.Element?.prototype,'innerHTML',e=>where(e)==='other'?'html':`html (${where(e)})`);
  wrapSet(globalThis.Node?.prototype,'textContent',e=>where(e)==='other'?'text':`text (${where(e)})`);
  for(const n of ['setProperty','removeProperty'])wrap(globalThis.CSSStyleDeclaration?.prototype,n,decl);
  for(const n of ['setAttribute','removeAttribute','toggleAttribute'])wrap(globalThis.Element?.prototype,n,e=>where(e)==='other'?'attribute':`attribute (${where(e)})`);
  for(const n of ['add','remove','toggle','replace'])wrap(globalThis.DOMTokenList?.prototype,n,()=>'class');
  for(const n of ['insertRule','deleteRule','replaceSync','replace'])wrap(globalThis.CSSStyleSheet?.prototype,n,()=>'stylesheet');
  let hover='-';try{const h=[...doc.querySelectorAll(':hover')].at(-1);hover=!h?'nowhere':win?.contains(h)?`over the sheet (${shortEl(h)})`:`not over the sheet (${shortEl(h)})`;}catch{}
  return {hover,stop(secs){off=true;try{take(mo.takeRecords());mo.disconnect();}catch{}for(const u of undo.reverse())try{u();}catch{}
    const per=Object.fromEntries(['sheet','root','other'].map(c=>[c,[...counts].filter(([k])=>k.startsWith(c+'|')).map(([k,v])=>[k.slice(c.length+1),v/secs]).sort((a,b)=>b[1]-a[1])]));
    return {hover,per,writers:Object.entries(writers).map(([k,v])=>[k,v/secs]).sort((a,b)=>b[1]-a[1])};}};
}
/** Per frame: before the frame's callbacks, its callbacks, and its rendering. */
function splitStats(sp,arrive){
  const pre=[],scr=[],ren=[];
  for(const [t,f] of sp.frames){const a=arrive.get(t);pre.push(f.first-t);scr.push(f.script);if(a!=null&&a>=f.last)ren.push(a-f.last);}
  const mean=v=>v.length?v.reduce((x,y)=>x+y,0)/v.length:null,n=Math.max(1,sp.frames.size);
  return {n:sp.frames.size,pre:mean(pre),script:mean(scr),render:mean(ren),renderMed:stats(ren).med,by:Object.entries(sp.bySrc).map(([k,v])=>[k,v/n]).sort((a,b)=>b[1]-a[1])};
}
/** One play load for `ms`: frames (rAF), long tasks, the module's own work by
 * part, uploads, light refreshes, perception updates, document updates and
 * heap, while `load(until)` plays it. */
async function measureLoad(ctx,name,ms,load=null,opts={}){
  ctx.check();ctx.progress(`Performance: ${name}…`);
  // (beta.38) on the sheet rows: each frame taken apart, long animation frames, and what is written to the page
  const sp=opts.split?frameSplit():null,lo=opts.split?loafWatch():null,census=opts.census?domCensus(opts.census):null,arrive=new Map();
  // (10.0.1) how canvas.perception.update stood before this row (its own property or the class's), put back exactly after;
  // 10.0.0 left the capture's inert perception watcher behind as an own property after every row
  const P=canvas?.perception,pDesc=P?Object.getOwnPropertyDescriptor(P,'update'):undefined;
  const own=perfStart(ctx),dts=[],heap=[];let last=null,tasks=null,obs=null,perc=0,docs=0;
  try{if(globalThis.PerformanceObserver?.supportedEntryTypes?.includes('longtask')){tasks=[];obs=new PerformanceObserver(l=>{for(const e of l.getEntries())tasks.push(e.duration);});obs.observe({type:'longtask'});}}catch{tasks=null;}
  const origPU=P?.update;let counter=null;if(P&&typeof origPU==='function'){counter=function(...a){perc++;return origPU.apply(this,a);};counter.ffCounting=true;P.update=counter;}
  const hooks=['updateToken','updateActor','updateAmbientLight','updateItem'].map(h=>[h,Hooks.on(h,()=>{docs++;})]);
  const until=now()+ms;let running=true;
  // (beta.37) the main thread's own work in each frame: from the frame's start (the rAF time) to the first task after its
  // rendering (style, layout, paint, commit); a frame that is slow while this stays short waited on the graphics side
  const busy=[],held=[];let chan=null;try{chan=new MessageChannel();chan.port1.onmessage=e=>{const t=now(),b=t-e.data;if(b>=0&&b<1000)busy.push(b);if(sp&&!arrive.has(e.data))arrive.set(e.data,t);};}catch{chan=null;}
  try{opts.tap?.('start');}catch{}
  const sampler=new Promise(res=>{const step=t=>{if(last!=null)dts.push(t-last);last=t;try{chan?.port2.postMessage(t);}catch{}const m=globalThis.performance?.memory?.usedJSHeapSize;if(m)heap.push([t,m]);if(running&&now()<until)requestAnimationFrame(step);else res();};requestAnimationFrame(step);setTimeout(res,ms+1500);});
  const kept=[];const heldPoll=setInterval(()=>{try{const d=decorHoldState();held.push(d.held);kept.push(d.kept??0);}catch{}},500);
  let err=null;try{if(load)await Promise.race([load(until),sleep(ms+4000)]);}catch(e){err=String(e?.message??e).slice(0,60);}
  await sampler;running=false;try{opts.tap?.('end');}catch{}clearInterval(heldPoll);try{chan?.port1.close();}catch{}
  try{sp?.stop();}catch{}const loaf=lo?.stop()??null,dom=census?.stop(ms/1000)??null,split=sp?splitStats(sp,arrive):null;
  const perf=own?perfStop(ctx):null;
  // (only ours or the capture's watcher is taken off: a wrapper someone else put over them during the row stays)
  if(P&&(P.update===counter||P.update?.ffPerceptionWatch))try{if(pDesc)Object.defineProperty(P,'update',pDesc);else delete P.update;}catch{}
  for(const [h,id] of hooks)try{Hooks.off(h,id);}catch{}
  try{obs?.disconnect();}catch{}
  const s=ms/1000,fs=stats(dts),sorted=[...dts].sort((a,b)=>a-b),p99=sorted[Math.min(sorted.length-1,Math.floor(sorted.length*.99))];
  // (+1 ms for vsync jitter: a frame counts as over only when it really missed)
  const over=lim=>dts.length?dts.filter(d=>d>lim+1).length/dts.length:0,mean=dts.length?dts.reduce((a,b)=>a+b,0)/dts.length:0;
  const c=perf?.counters??{},sum=keys=>keys.reduce((n,k)=>n+(c[k]??0),0);
  let growth=null,gcs=0;if(heap.length>4){growth=(heap.at(-1)[1]-heap[0][1])/((heap.at(-1)[0]-heap[0][0])/1000)/1048576;for(let i=1;i<heap.length;i++)if(heap[i-1][1]-heap[i][1]>2*1048576)gcs++;}
  const stages=Object.entries(perf?.stages??{}).map(([k,v])=>[k,v.mean*v.samples/Math.max(1,dts.length)]).sort((a,b)=>b[1]-a[1]);// ms per frame
  return {name,fs,mean,p99,o16:over(16.7),o25:over(25),long:tasks?{n:tasks.length,ms:tasks.reduce((a,b)=>a+b,0)}:null,mod:perf?.moduleMs?.median??null,stages,
    up:Object.fromEntries(Object.entries(UPLOADS).map(([k,v])=>[k,sum(v)/s])),lights:(c.lightRefreshes??0)/s+(c.lightRebuilds??0)/s,perc:perc/s,percBy:Object.fromEntries(Object.entries(c).filter(([k])=>k.startsWith('perceptionBy:')).map(([k,v])=>[k.slice(13),v/s])),percFlags:Object.fromEntries(Object.entries(c).filter(([k])=>k.startsWith('perceptionFlag:')).map(([k,v])=>[k.slice(15),v/s])),main:stats(busy),held:held.length?Math.max(...held):0,kept:kept.length?Math.max(...kept):0,percTop:perf?.perceptionCallers??[],percHer:(c.perceptionDuringHerTransform??0)/s,percFrame:dts.length?perc/dts.length:0,docs:docs/s,growth,gcs,err,split,loaf,dom};
}
/* (beta.38) The sheet's regions, hidden one at a time while she moves (flow
 * regions skip their contents' style, layout and paint and keep their size;
 * the frame's absolutely placed parts are taken out), then the same sheet
 * with its filters, masks, layers (will-change) or hover threads off. All of it
 * is one temporary stylesheet and data-ffchk attributes this adds and removes. */
const BISECT_PARTS=[
  ['header+portrait','form > header','flow'],['sidebar','form > aside','flow'],['tab body','form > .sheet-body','flow'],['tab bar','form > nav, form > .ffks-rule','flow'],
  ['frame+corners',':scope > .ffks-frame > :not(.ffks-corner.tl):not(svg:not(.ffks-corner)), :scope > .ffks-grip','out'],['flower+sky',':scope > .ffks-frame > .ffks-corner.tl','out'],
  ['title bar',':scope > .window-header','flow'],['all inside',':scope > .window-content, :scope > .ffks-frame','flow']];
const THREADS='.ffks-tile, .tab.proficiencies ul.proficiencies-list > li, .tab.actions ol.strikes-list > li.strike, .ffks-cpt, .tab.pfs > .reputations > .reputation, .tab.inventory ul.items > li > .data, .tab.spellcasting ol.spell-list > li.spell, .tab.feats ol.feats-list li > .item-name, .tab.actions ol.actions-list > li.action, .tab.effects ol.effects-list > li, .tab.crafting ol.formula-list > li.formula-item, .tab.pfs ol > li.item, .sheet-content nav.sub-nav > a';
const BISECT_LOOKS=[
  ['filters off','filters','{K} *, {K} *::before, {K} *::after{filter:none!important}'],
  ['masks off','masks','{K} *{-webkit-mask:none!important;mask:none!important}'],
  ['layers off','layers','{K} *{will-change:auto!important}'],
  ['hover threads off','threads',`{K} :is(${THREADS})::before, {K} :is(${THREADS})::after{content:none!important}`]];
async function sheetBisect(ctx,win,move,open,mini){
  const W=win();if(!W)return {error:'no window'};
  const base=open?.main?.med,floor=mini?.main?.med;
  if(base==null)return {error:'no frame data'};
  if(floor!=null&&base-floor<1&&open.mean-(mini?.mean??0)<1)return {skipped:`the open sheet costs ${f1(base-floor)} ms a frame over minimised`};
  const MSB=ctx.opts.bisectMs??1800,doc=W.ownerDocument,style=doc.createElement('style'),K='.window-app[data-ffchk="{k}"]',hadAttr=W.hasAttribute('data-ffchk');
  if(hadAttr)return {error:'the sheet already carries data-ffchk'};
  const rows=[];let css='';
  const variants=[];
  BISECT_PARTS.forEach(([name,sel,how],i)=>{
    let els=[];try{els=[...W.querySelectorAll(sel)].filter(e=>e.getClientRects().length);}catch{}
    if(!els.length){rows.push({name,missing:true});return;}
    for(const e of els){const was=e.getAttribute('data-ffchk-part');e.setAttribute('data-ffchk-part',`${was?was+' ':''}p${i}`);
      if(how==='flow'){const k=`p${i}-${variants.length}-${els.indexOf(e)}`;e.setAttribute('data-ffchk-size',k);css+=`[data-ffchk-size="${k}"]{contain-intrinsic-size:${e.clientWidth}px ${e.clientHeight}px}\n`;}}
    css+=how==='flow'?`${K.replace('{k}',`p${i}`)} [data-ffchk-part~="p${i}"]{content-visibility:hidden!important;visibility:hidden!important}\n`:`${K.replace('{k}',`p${i}`)} [data-ffchk-part~="p${i}"]{display:none!important}\n`;
    variants.push({name,key:`p${i}`});
  });
  for(const [name,key,rule] of BISECT_LOOKS){css+=rule.replaceAll('{K}',K.replace('{k}',key))+'\n';variants.push({name,key});}
  const glints=doc.getElementById('ffks-glints');
  if(glints){css+=`body[data-ffchk="glints"] > #ffks-glints{display:none!important}\n`;variants.push({name:'click glints',key:'glints',on:doc.body});}
  style.id='ff-check-bisect';style.textContent=css;
  // (beta.39) each part is judged against the open sheet measured right before it, not against the first
  // open row: beta.38's report had "open again" already at the minimised cost, so every part "saved" the same
  // 4 ms that had gone by itself (a warm-up after opening). When a control is down to the minimised cost the
  // open sheet no longer costs anything and the bisect stops there and says so.
  const row=(name,r,extra={})=>({name,main:r.main?.med,mean:r.mean,render:r.split?.render,script:r.split?.script,...extra});
  let faded=null;
  try{
    doc.head.append(style);
    for(const v of variants){
      ctx.check();const target=v.on??W,had=target.hasAttribute('data-ffchk');if(had)continue;
      await sleep(250);const c=await measureLoad(ctx,`sheet: open (before ${v.name})`,MSB,move,{split:true});
      const control=c.main?.med;rows.push(row(`open (before ${v.name})`,c,{ref:true}));
      if(floor!=null&&control!=null&&control-floor<.6){faded={control,before:v.name};break;}
      target.setAttribute('data-ffchk',v.key);
      try{await sleep(350);const r=await measureLoad(ctx,`sheet: ${v.name}`,MSB,move,{split:true});rows.push(row(v.name,r,{control}));}
      finally{target.removeAttribute('data-ffchk');}
    }
  }finally{
    style.remove();
    for(const root of new Set([W,win()].filter(Boolean)))for(const e of root.querySelectorAll('[data-ffchk-part],[data-ffchk-size]')){e.removeAttribute('data-ffchk-part');e.removeAttribute('data-ffchk-size');}
    for(const e of [W,win(),doc.body])if(e?.getAttribute?.('data-ffchk')!=null)e.removeAttribute('data-ffchk');
  }
  return {base,floor,mean:open.mean,render:open.split?.render,rows,faded};
}
/** (beta.39) The first seconds after her sheet opens, while she moves: main-thread ms per frame (median) and
 * "after rAF" (style, layout, paint, commit; mean) per 1 s bucket from the moment it was asked to open. Beta.38's
 * bisect showed the open sheet's 4 ms a frame was gone a few seconds later: this says how long that lasts. */
async function sheetWarmup(ctx,openedAt,ms,move,win=null){
  const sp=frameSplit(),arrive=new Map(),busy=[];let chan=null,running=true;
  // (what the sheet is doing meanwhile, a second at a time: its finite animations and transitions running, pictures
  // not yet decoded, fonts loading, and what is written into it)
  const looks=[],writes=[];let mo=null;
  try{mo=new MutationObserver(l=>{const t=now();for(const m of l)writes.push(t);});}catch{mo=null;}
  const look=()=>{try{lookOnce();}catch{}};
  const lookOnce=()=>{const W=win?.();if(!W||W.nodeType!==1)return;const t=now();if(mo&&!look.on){try{mo.observe(W,{subtree:true,attributes:true,childList:true,characterData:true});look.on=true;}catch{}}
    let anims=[];try{anims=W.getAnimations({subtree:true}).filter(a=>a.playState==='running'&&a.playbackRate!==0&&a.effect?.getTiming?.().iterations!==Infinity);}catch{}
    const imgs=[...W.querySelectorAll('img')].filter(i=>!i.complete&&i.getClientRects().length).length;
    looks.push({t,heap:globalThis.performance?.memory?.usedJSHeapSize??null,anims:anims.length,names:[...new Set(anims.map(a=>a.animationName||a.transitionProperty||'web'))].slice(0,3).join('+'),imgs,fonts:globalThis.document?.fonts?.status==='loading'});};
  const lookTimer=setInterval(look,250);look();
  try{
  try{chan=new MessageChannel();chan.port1.onmessage=e=>{const t=now(),b=t-e.data;if(b>=0&&b<1000)busy.push([e.data,b]);if(sp&&!arrive.has(e.data))arrive.set(e.data,t);};}catch{chan=null;}
  const until=openedAt+ms;
  const sampler=new Promise(res=>{const step=t=>{try{chan?.port2.postMessage(t);}catch{}if(running&&now()<until)requestAnimationFrame(step);else res();};requestAnimationFrame(step);setTimeout(res,ms+1500);});
  try{if(move)await Promise.race([move(until),sleep(ms+4000)]);}catch{}
  await sampler;
  }finally{running=false;clearInterval(lookTimer);try{mo?.disconnect();}catch{}try{sp?.stop();}catch{}try{chan?.port1.close();}catch{}}
  const n=Math.ceil(ms/1000),buckets=Array.from({length:n},()=>({main:[],after:[],script:[],looks:[],writes:0})),at=t=>Math.floor((t-openedAt)/1000);
  for(const [t,b] of busy){const i=at(t);if(i>=0&&i<n)buckets[i].main.push(b);}
  for(const [t,f] of sp?.frames??[]){const a=arrive.get(t),i=at(t);if(i<0||i>=n)continue;buckets[i].script.push(f.script);if(a!=null&&a>=f.last)buckets[i].after.push(a-f.last);}
  for(const l of looks){const i=at(l.t);if(i>=0&&i<n)buckets[i].looks.push(l);}
  for(const t of writes){const i=at(t);if(i>=0&&i<n)buckets[i].writes++;}
  const mean=v=>v.length?v.reduce((x,y)=>x+y,0)/v.length:null;
  return buckets.map((b,i)=>({s:i,frames:b.main.length,main:b.main.length?stats(b.main).med:null,after:mean(b.after),script:mean(b.script),
    anims:b.looks.length?Math.max(...b.looks.map(l=>l.anims)):null,heap:b.looks.map(l=>l.heap).filter(Number.isFinite).at(-1)??null,names:b.looks.map(l=>l.names).filter(Boolean).at(-1)??'',imgs:b.looks.length?Math.max(...b.looks.map(l=>l.imgs)):null,fonts:b.looks.some(l=>l.fonts),writes:b.writes}));
}
/** How long the open sheet's extra cost lasts: the first second whose main ms/frame is within 0.6 ms of the tail's. */
function warmupLine(series,floor){
  if(!series?.length)return null;const fmt=v=>v==null?'-':f1(v);
  const tail=series.slice(-4).map(b=>b.main).filter(v=>v!=null).sort((a,b)=>a-b),settledAt=tail.length?tail[Math.floor(tail.length/2)]:null;
  // (against where it settles, the last 4 s: the warm-up apart from what the open sheet costs for good)
  const last=[...series].slice(0,-4).reverse().find(b=>b.main!=null&&settledAt!=null&&b.main-settledAt>=.6);
  const lasted=last?last.s+1:0;
  // (the JS heap at the end of each second: a large drop is a major garbage collection finishing; opening a sheet
  // allocates a lot, and V8's incremental marking slows every script, the canvas's too, until it is done)
  const extra=b=>[b.script!=null?`rAF ${fmt(b.script)}`:'',b.heap!=null?`${Math.round(b.heap/1048576)} MB`:'',b.anims?`${b.anims} anim${b.names?` ${b.names}`:''}`:'',b.imgs?`${b.imgs} img`:'',b.fonts?'fonts':'',b.writes?`${b.writes} writes`:''].filter(Boolean).join(' ');
  return `sheet warm-up while she moves (s after opening: main ms/frame med / after rAF mean [rAF scripts, JS heap, the sheet's finite animations, pictures loading, fonts, writes into it]): ${series.map(b=>`${b.s}s ${fmt(b.main)}/${fmt(b.after)}${extra(b)?` [${extra(b)}]`:''}`).join(' · ')} · ${lasted?`costs more for about ${lasted} s, then settles at ${fmt(settledAt)}`:`no warm-up: ${fmt(settledAt)} from the first seconds`}${floor!=null?` (minimised ${fmt(floor)})`:''}`;
}
/** The sheet rows taken apart, for the report. */
function sheetDiagLines(d){
  const out=[],{open,mini}=d,fmt=v=>v==null?'-':f1(v);
  const sp=(r,label)=>r?.split?`${label} before ${fmt(r.split.pre)} · rAF scripts ${fmt(r.split.script)} (${r.split.by.slice(0,4).map(([k,v])=>`${k} ${f2(v)}`).join(', ')||'-'}) · after rAF (style, layout, paint, commit) ${fmt(r.split.render)}${r.split.renderMed!=null?` med ${fmt(r.split.renderMed)}`:''}`:`${label} -`;
  out.push(`sheet while she moves, mean ms per frame: ${sp(open,'open')} | ${sp(mini,'minimised')}`);
  const lf=(r,label)=>!r?.loaf?'':!r.loaf.supported?`${label} not supported`:!r.loaf.n?`${label} none over 50 ms`:`${label} ${r.loaf.n} (${Math.round(r.loaf.ms)} ms): before ${Math.round(r.loaf.before)} · rAF ${Math.round(r.loaf.raf)} · style/layout/paint ${Math.round(r.loaf.render)} · forced ${Math.round(r.loaf.forced)} · scripts ${Object.entries(r.loaf.src).sort((a,b)=>b[1].ms-a[1].ms).slice(0,3).map(([k,v])=>`${k} ${Math.round(v.ms)}${v.forced>1?` (forced ${Math.round(v.forced)})`:''} [${v.top}]`).join(', ')}`;
  out.push(`long animation frames: ${lf(open,'open')} | ${lf(mini,'minimised')}`);
  const dm=(r,label)=>{if(!r?.dom)return `${label} -`;const p=r.dom.per,rate=v=>v>=10?String(Math.round(v)):f1(v),top=(a,n)=>a.slice(0,n).map(([k,v])=>`${k} ${rate(v)}`).join(', ')||'none';
    const tot=a=>rate(a.reduce((n,[,v])=>n+v,0));
    return `${label}: into the sheet ${tot(p.sheet)}/s [${top(p.sheet,3)}] · on html, body or its ancestors ${tot(p.root)}/s [${top(p.root,3)}] · elsewhere ${tot(p.other)}/s [${top(p.other,2)}] · writers ${r.dom.writers.slice(0,5).map(([k,v])=>`${k} ${rate(v)}`).join(', ')||'none'}`;};
  out.push(`page writes while she moves (per s), ${dm(open,'open')}`);
  out.push(`  ${dm(mini,'minimised')} · pointer ${open?.dom?.hover??'-'}`);
  const wl=d.warm?warmupLine(d.warm,mini?.main?.med):null;
  if(d.pre?.length)out.push(`sheet closed, the 3 s before it opens (main ms/frame med / after rAF mean): ${d.pre.map(b=>`${b.s}s ${fmt(b.main)}/${fmt(b.after)}`).join(' · ')}`);
  if(wl)out.push(wl);else if(d.warmSkipped)out.push(`sheet warm-up: not measured (${d.warmSkipped})`);
  const b=d.bisect;
  if(!b)out.push('sheet bisect: not run');
  else if(b.error)out.push(`sheet bisect: ${b.error}`);
  else if(b.skipped)out.push(`sheet bisect: skipped (${b.skipped})`);
  else{
    const rows=b.rows.filter(r=>!r.missing&&!r.ref),refs=b.rows.filter(r=>r.ref),missing=b.rows.filter(r=>r.missing);
    const saved=r=>r.main!=null&&r.control!=null?r.control-r.main:null,sg=v=>v==null?'?':(v>=0?'−':'+')+f1(Math.abs(v));
    if(b.faded&&!rows.length)out.push(`sheet bisect: the open sheet's cost had faded by the time the bisect ran: it's a warm-up after opening (open ${fmt(b.base)} when first measured, ${fmt(b.faded.control)} now, minimised ${fmt(b.floor)})`);
    else{
      out.push(`sheet bisect (main ms/frame med, each part against the open sheet measured just before it; first open ${fmt(b.base)}, minimised ${fmt(b.floor)}): ${rows.map(r=>`${r.name} ${fmt(r.main)} vs ${fmt(r.control)} (${sg(saved(r))}${r.render!=null?`, after rAF ${fmt(r.render)}`:''})`).join(' · ')}${missing.length?` · not on this tab: ${missing.map(r=>r.name).join(', ')}`:''}`);
      if(b.faded)out.push(`sheet bisect: stopped before ${b.faded.before}: the open sheet was down to ${fmt(b.faded.control)} (minimised ${fmt(b.floor)}); its cost had faded: a warm-up after opening, not a part`);
      const best=rows.filter(r=>r.name!=='all inside'&&saved(r)!=null).sort((x,y)=>saved(y)-saved(x))[0],all=rows.find(r=>r.name==='all inside');
      if(best)out.push(`sheet bisect: most saved by ${best.name} (${f1(saved(best))} of the ${f1((best.control??b.base)-(b.floor??b.base))} ms the open sheet added then)${all&&saved(all)!=null?` · all inside ${f1(saved(all))}`:''} · controls ${refs.map(r=>fmt(r.main)).join(', ')}`);
    }
  }
  return out;
}
/** Ordinary moves along a free line, back and forth, until `until`. */
async function moveLoop(ctx,dir,n,until){
  const g=ctx.grid;let sign=1,legs=0;
  while(now()<until-300&&legs<8){ctx.check();await moveBy(ctx,dir.ux*g*n*sign,dir.uy*g*n*sign);sign=-sign;legs++;}
  if(sign===-1)await moveBy(ctx,-dir.ux*g*n,-dir.uy*g*n);// end where she started
}
async function performanceScenario(ctx,res){
  const MS=ctx.opts.perfMs??6000;
  let n=8,dir=null;for(;n>=2&&!dir;n--)dir=freeDirection(ctx,n);n++;
  if(!dir){res.skipped='no free line of 2+ squares next to her';return;}
  const home={x:ctx.doc.x,y:ctx.doc.y};
  res.restore(async()=>{if(ctx.doc.x!==home.x||ctx.doc.y!==home.y){await ctx.doc.update({x:home.x,y:home.y},{animate:false});await sleep(200);}});
  const st0=call.state(ctx),light0=!!st0?.light?.enabled,lantern0=!!st0?.lantern?.enabled,mode0=st0?.requested?.mode;
  res.restore(async()=>{const st=call.state(ctx);if(!!st?.light?.enabled!==light0)await call.light(ctx,light0);if(!!call.state(ctx)?.lantern?.enabled!==lantern0)await ctx.service?.setLantern?.(ctx.doc,{enabled:lantern0});});
  res.restore(async()=>{if(mode0&&AIRBORNE_MODES.includes(mode0)&&call.state(ctx)?.requested?.mode!==mode0)await call.setMode(ctx,mode0);});
  const ctrl=ctx.service?.hudController?.(),hudWas=!!(ctrl?.opened&&ctrl.app?.rendered),tab0=ctrl?.app?.tab??ctrl?.prefs?.tab??'home';
  res.restore(async()=>{if(!ctrl)return;const app=ctrl.app;if(app&&app.tab!==tab0)app.switchTab(tab0);if(!hudWas&&ctrl.opened)await ctrl.close();else if(hudWas&&!ctrl.opened)await ctrl.open();});
  let task=null;res.restore(async()=>{if(task){try{await call.bits(ctx).stopTool(ctx.doc,{id:task.id});}catch{}await waitUntil(()=>!call.bitState(ctx)?.busy,4000,()=>sleep(100));}});
  const actor=herActor()??ctx.doc?.actor,sheet=actor&&keepsakeOn(actor)?actor.sheet:null,sheetWas=!!sheet?.rendered;
  res.restore(async()=>{if(sheet&&!sheetWas&&sheet.rendered)await sheet.close();});
  const hud=async on=>{if(!ctrl)return false;if(on&&!ctrl.opened){await ctrl.open();await waitUntil(()=>hudShadow(ctrl)?.querySelector('.ks-root'),4000,()=>sleep(100));}if(on&&ctrl.app?.tab!=='home')ctrl.app.switchTab('home');if(!on&&ctrl.opened)await ctrl.close();await sleep(500);return !!ctrl.opened;};
  const startTask=async()=>{try{task=await call.bits(ctx).startTool(ctx.doc,{kind:'areaScan',followSource:true,bits:2});await sleep(1500);return true;}catch(e){res.lines.push(`(bits task unavailable: ${String(e.message).slice(0,60)})`);return false;}};
  const stopTask=async()=>{if(!task)return;try{await call.bits(ctx).stopTool(ctx.doc,{id:task.id});}catch{}task=null;await waitUntil(()=>!call.bitState(ctx)?.busy,4000,()=>sleep(100));};
  const move=until=>moveLoop(ctx,dir,n,until);
  const rows=[];
  // baseline: the module idle on her, HUD closed
  await hud(false);
  if(call.state(ctx)?.enabled){await call.wings(ctx,false);await sleep(1500);}
  rows.push(await measureLoad(ctx,'baseline',MS));
  await ensureFlying(ctx);
  if(!homeBits(ctx)){await call.bitsOn(ctx,true);await sleep(1200);}
  await settle(ctx,{timeout:1500});
  rows.push(await measureLoad(ctx,'hover',MS));
  await call.setMode(ctx,'fly');await sleep(900);rows.push(await measureLoad(ctx,'move fly',MS,move));
  await call.setMode(ctx,'fast');await sleep(900);rows.push(await measureLoad(ctx,'move fast',MS,move));
  await call.setMode(ctx,'fly');await call.light(ctx,true);await sleep(900);rows.push(await measureLoad(ctx,'move+light',MS,move));
  await call.light(ctx,false);
  try{await ctx.service.setLantern(ctx.doc,{enabled:true});await sleep(900);rows.push(await measureLoad(ctx,'move+lantern',MS,move));await ctx.service.setLantern(ctx.doc,{enabled:false});await sleep(500);}catch(e){res.lines.push(`(lantern unavailable: ${String(e.message).slice(0,50)})`);}
  if(await startTask()){rows.push(await measureLoad(ctx,'bits task',MS));await stopTask();}
  if(await hud(true)){rows.push(await measureLoad(ctx,'move+HUD',MS,move));await hud(false);}
  let sheetDiag=null;
  if(sheet){let warm=null;
    // (beta.39) opened here: its first 15 s while she moves, a second at a time, before the steady rows
    // (and 3 s before it opens, the HUD just closed: whatever that leaves behind is not the sheet's)
    const win=()=>elOf(sheet.element);let pre=null;
    if(!sheet.rendered){try{pre=await sheetWarmup(ctx,now(),3000,move);}catch{pre=null;}
      const at=now();await sheet.render(true);try{warm=await sheetWarmup(ctx,at,15000,move,win);}catch{warm=null;}await sleep(300);}
    const open=await measureLoad(ctx,'move+sheet',MS,move,{split:true,census:win()});rows.push(open);
    // (beta.37) the same with the sheet minimised to its title bar: what its body costs while she moves
    let mini=null;
    if(typeof sheet.minimize==='function'&&!sheet._minimized){try{await sheet.minimize();await sleep(600);mini=await measureLoad(ctx,'…minimised',Math.min(MS,4000),move,{split:true,census:win()});mini.diag=true;rows.push(mini);}catch{}finally{try{if(sheet._minimized)await sheet.maximize();}catch{}await sleep(400);}}
    // (beta.38) and which part of it: each region hidden in turn, then filters, masks, layers and hover threads off
    sheetDiag={open,mini,bisect:null,warm,pre,warmSkipped:sheetWas?'her sheet was already open':null};
    try{sheetDiag.bisect=await sheetBisect(ctx,win,move,open,mini);}catch(e){sheetDiag.bisect={error:String(e?.message??e).slice(0,80)};}
    if(!sheetWas)await sheet.close();await sleep(400);}
  await hud(true);await call.light(ctx,true);const t=await startTask();
  rows.push(await measureLoad(ctx,'everything',MS,move));
  if(t)await stopTask();await call.light(ctx,false);await hud(false);
  // (10.0.1) what costs fps while she moves: the same moves as "move fly" in four conditions, taken in turn (its lines go last)
  const cmp={lines:[],verdicts:res.verdicts,restore:res.restore};
  try{await compareRows(ctx,cmp,move,{dirText:`, ${n} squares ${dir.name} and back`});}
  catch(e){if(ctx.aborted)throw e;cmp.lines.push(`compare could not finish: ${String(e?.message??e).slice(0,80)}`);}
  // the report
  const base=rows[0],hz=ctx.env?.hz||60,frame=1000/hz;
  res.lines.push(`ms med/p95/p99/max · % >16.7/>25 · long · mod ms/frame (top part) · up/s wing/bit/fx/trail · light/s · percept/s · upd/s · heap MB/s(gc) · Δmean ms · main ms/frame med/p95 · 60/${hz}Hz`);
  const ok=(p95,lim)=>p95<=lim*1.05?'✓':p95<=lim*1.5?'~':'✗';
  for(const r of rows){
    const d=r===base?null:r.mean-base.mean,top=r.stages[0];
    res.lines.push(`${r.name.padEnd(12)} ${f1(r.fs.med)}/${f1(r.fs.p95)}/${f1(r.p99)}/${Math.round(r.fs.max)} · ${Math.round(r.o16*100)}/${Math.round(r.o25*100)} · ${r.long?r.long.n:'-'} · ${r.mod!=null?f2(r.mod):'-'}${top&&top[1]>.02?` (${top[0]} ${f2(top[1])})`:''} · ${Math.round(r.up.w)}/${Math.round(r.up.b)}/${Math.round(r.up.fx)}/${Math.round(r.up.tr)} · ${Math.round(r.lights)} · ${Math.round(r.perc)} · ${Math.round(r.docs)} · ${r.growth!=null?`${r.growth>=0?'+':''}${f1(r.growth)}${r.gcs?` (${r.gcs})`:''}`:'-'} · ${d==null?'base':`${d>=0?'+':''}${f1(d)}`} · ${r.main?.n?`${f1(r.main.med)}/${f1(r.main.p95)}`:'-'} · ${ok(r.fs.p95,16.7)}${ok(r.fs.p95,frame)}${r.held?` · ${r.held} loops held`:''}${r.kept?`${r.held?',':' ·'} ${r.kept} kept playing`:''}${r.err?` · ${r.err}`:''}`);
  }
  // (beta.35) who asked for those perception refreshes: Foundry itself, this module (lights), or another module
  const pr=rows.filter(r=>r.perc>20).sort((a,b)=>b.perc-a.perc)[0];
  // (beta.36) and how many came while her pose was applied to her token's transform: those are the module's (its flight motion)
  if(pr&&Object.keys(pr.percBy).length)res.lines.push(`percept/s by caller (${pr.name}, ${f1(pr.percFrame)} a frame): ${Object.entries(pr.percBy).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${k} ${Math.round(v)}`).join(' · ')} · during her flight transform ${Math.round(pr.percHer??0)} · top: ${pr.percTop.slice(0,3).map(t=>t.at).join(' | ')}${Object.keys(pr.percFlags??{}).length?` · flags: ${Object.entries(pr.percFlags).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([k,v])=>`${k} ${Math.round(v)}`).join(' · ')}`:''}${pr.percTop.some(t=>/libWrapper/.test(t.at))?' · (libWrapper\'s own settings, Active Wrappers, list the modules that wrap a method)':''}`);
  if(sheetDiag)try{res.lines.push(...sheetDiagLines(sheetDiag));}catch(e){res.lines.push(`sheet diagnosis failed: ${String(e?.message??e).slice(0,80)}`);}
  // what costs the most: each load's extra frame time over the baseline, and the module's heaviest parts
  const items=[...rows.slice(1).filter(r=>!r.diag).map(r=>[r.name,Math.max(0,r.mean-base.mean)]),
    ...Object.entries(rows.slice(1).reduce((m,r)=>{for(const [k,v] of r.stages)m[k]=Math.max(m[k]??0,v);return m;},{})).map(([k,v])=>[`module ${k}`,v])].sort((a,b)=>b[1]-a[1]).slice(0,5);
  res.lines.push(`costs most (ms per frame, % of 16.7): ${items.map(([k,v],i)=>`${i+1}. ${k} ${f1(v)} (${Math.round(v/16.7*100)}%)`).join(' · ')}`);
  const worst=rows.slice(1).filter(r=>!r.diag).sort((a,b)=>b.fs.p95-a.fs.p95)[0];
  const slow=rows.slice(1).filter(r=>!r.diag&&r.fs.p95>25&&r.fs.p95>base.fs.p95*1.5+4);
  if(slow.length)verdict(res,'CHECK',`slower than the scene alone (p95, base ${f1(base.fs.p95)} ms): ${slow.map(r=>`${r.name} ${Math.round(r.fs.p95)}`).join(', ')}`);
  res.lines.push(...cmp.lines);
  if(!res.verdicts.length)verdict(res,'PASS',`every load holds ${worst&&worst.fs.p95<=frame*1.05?`${hz} Hz`:'60 fps'} at p95 (worst ${worst?.name} ${f1(worst?.fs.p95)} ms)`);
}
const homeBits=ctx=>(call.bitState(ctx)?.allocations??[]).filter(b=>b.location==='home').length;
SCENARIO_RUN.performance=performanceScenario;
/* ---------------------------------------------------------------- COMPARE (10.0.1)
 * The user's game drops from about 120 to about 80 fps while she moves. This
 * moves her as the "move fly" row does, in four conditions, in short runs
 * taken in turn (A C D B, A C D B, …) so drift between runs falls on all of
 * them alike:
 *   A as is;
 *   B Yvaelle’s Toolbox visuals off on this browser (its client setting "Show
 *     effects here", localEffects), put back after;
 *   C PF2e Visioner paused (only when it is active): the perception updates
 *     asked for from inside Token#_refreshVisibility, where its libWrapper
 *     wrapper asks for them, are not passed on to Foundry while the run lasts;
 *   D both.
 * Nothing here writes a document or a world setting, or reaches another
 * player: localEffects is this browser's own setting, and perception is
 * worked out by each browser for itself. */
const VISIONER='pf2e-visioner';
/** (a change that would outlive a reload: localEffects is kept in this browser's storage) */
const PENDING_KEY='ff-self-check-pending';
function pendingSet(patch){try{const cur=JSON.parse(globalThis.localStorage?.getItem(PENDING_KEY)||'{}');globalThis.localStorage?.setItem(PENDING_KEY,JSON.stringify({...cur,...patch}));}catch{}}
function pendingClear(){try{globalThis.localStorage?.removeItem(PENDING_KEY);}catch{}}
/** At start-up: a check that was cut off (reload, closed window) while Filament
 * Flight's visuals were off here has them put back as they were. */
export async function recoverInterruptedCheck(){
  let p=null;try{const raw=globalThis.localStorage?.getItem(PENDING_KEY);if(!raw)return false;p=JSON.parse(raw);}catch{pendingClear();return false;}
  try{if(typeof p?.localEffects==='boolean'&&setting('localEffects')!==p.localEffects)await game.settings.set(ID,'localEffects',p.localEffects);}catch{return false;}
  pendingClear();return true;
}
/** Counts (always) and, while `on`, holds back the perception updates asked for
 * from inside a token's _refreshVisibility. The tokens get an own
 * _refreshVisibility that marks the call and runs the class's one (with every
 * libWrapper wrapper on it) unchanged; canvas.perception gets an own update
 * that, inside such a call and only while `on`, notes the flags and returns.
 * restore() removes both (only if they are still ours) and asks once for
 * whatever was held back, so the view is right again at once. */
function perceptionGate(){
  const P=canvas?.perception;
  if(!P||typeof P.update!=='function')return null;
  const desc=Object.getOwnPropertyDescriptor(P,'update'),inner=P.update;
  const g={on:false,depth:0,asked:0,inside:0,dropped:0,visMs:0,visCalls:0,held:{},who:{},sample:0,tokens:[],skipped:0,restored:null};
  const update=function(...a){
    g.asked++;
    if(g.depth>0){g.inside++;
      // (who asks, from a few stacks a run; never one per call)
      if(g.sample>0){g.sample--;try{const w=perceptionCaller(String(new Error().stack??'')).source;g.who[w]=(g.who[w]??0)+1;}catch{}}
      if(g.on){g.dropped++;const f=a[0];if(f&&typeof f==='object')for(const k in f)if(f[k]===true)g.held[k]=true;return;}}
    return inner.apply(this,a);
  };
  update.ffCompare=true;
  try{Object.defineProperty(P,'update',{value:update,configurable:true,writable:true,enumerable:false});}catch{return null;}
  const mark=t=>{
    if(!t||t.destroyed||Object.hasOwn(t,'_refreshVisibility')||typeof t._refreshVisibility!=='function'){g.skipped++;return;}
    const proto=Object.getPrototypeOf(t);
    const own=function(...a){const fn=Reflect.get(proto,'_refreshVisibility',this);g.depth++;const t0=now();
      try{return fn.apply(this,a);}finally{g.depth--;g.visMs+=now()-t0;g.visCalls++;}};
    try{Object.defineProperty(t,'_refreshVisibility',{value:own,configurable:true,writable:true,enumerable:false});g.tokens.push([t,own]);}catch{g.skipped++;}
  };
  for(const t of canvas.tokens?.placeables??[])mark(t);
  g.replay=()=>{const k=Object.keys(g.held);if(!k.length)return;g.held={};try{P.update(Object.fromEntries(k.map(x=>[x,true])));}catch{}};
  g.restore=()=>{
    if(g.restored)return g.restored;
    g.on=false;let tokensOk=true,updateOk=true;
    for(const [t,own] of g.tokens){try{if(Object.getOwnPropertyDescriptor(t,'_refreshVisibility')?.value===own)delete t._refreshVisibility;}catch{}
      if(!t.destroyed&&Object.getOwnPropertyDescriptor(t,'_refreshVisibility')?.value===own)tokensOk=false;}
    g.tokens=[];
    try{if(Object.getOwnPropertyDescriptor(P,'update')?.value===update){if(desc)Object.defineProperty(P,'update',desc);else delete P.update;}}catch{}
    // (someone put a wrapper over ours meanwhile: ours stays under it, only counting from now on)
    if(Object.getOwnPropertyDescriptor(P,'update')?.value===update||P.update!==inner)updateOk=false;
    g.replay();
    return g.restored={tokens:tokensOk,update:updateOk};
  };
  g.counts=()=>({asked:g.asked,inside:g.inside,dropped:g.dropped,visMs:g.visMs,visCalls:g.visCalls});
  return g;
}
const median=v=>stats(v.filter(Number.isFinite)).med;
const range=v=>{const x=v.filter(Number.isFinite);return x.length?[Math.min(...x),Math.max(...x)]:null;};
/** The four conditions, `rounds` times over. `move(until)` moves her as the "move fly" row does. */
async function compareRows(ctx,res,move,{dirText=''}={}){
  const MS=ctx.opts.compareMs??3000,ROUNDS=Math.max(1,ctx.opts.compareRounds??3),REST=Math.min(MS,2000),hz=ctx.env?.hz||60;
  const fx0=setting('localEffects'),vis=game.modules?.get?.(VISIONER),visOn=!!vis?.active;
  const gate=perceptionGate();
  res.restore(()=>{gate?.restore();});
  // the setting: put back by the part (and again by the run's own restore, and at start-up after a reload)
  let fxNow=fx0;
  const setFx=async on=>{const want=on?fx0:false;if(fx0!==true||fxNow===want)return false;
    if(!on)pendingSet({localEffects:fx0});
    await game.settings.set(ID,'localEffects',want);fxNow=want;if(on)pendingClear();
    await sleep(1300);return true;};
  res.restore(async()=>{if(fx0!==undefined&&setting('localEffects')!==fx0)await game.settings.set(ID,'localEffects',fx0);if(setting('localEffects')===fx0)pendingClear();});
  const notes=[];
  const fxOk=fx0===true;if(!fxOk)notes.push(fx0===false?'Yvaelle’s Toolbox visuals are already off on this browser: B and D not measured':'no "Show effects here" setting: B and D not measured');
  const visOk=visOn&&!!gate;
  if(!visOn)notes.push('PF2e Visioner is not active: C and D not measured');
  else if(!gate)notes.push('Visioner not paused (no safe way): no canvas.perception.update to hold back');
  const conds=[{id:'A',label:'as is',fx:true,vis:true},{id:'C',label:'Visioner paused',fx:true,vis:false},{id:'D',label:'both off',fx:false,vis:false},{id:'B',label:'FF visuals off',fx:false,vis:true}]
    .filter(c=>(c.fx||fxOk)&&(c.vis||visOk));
  let back=null;
  const runs=Object.fromEntries([...conds.map(c=>c.id),'rest'].map(k=>[k,[]]));
  const measure=async(name,ms,load)=>{let a=null,b=null,t0=0,t1=0;
    const r=await measureLoad(ctx,name,ms,load,{tap:w=>{if(w==='start'){a=gate?.counts();t0=now();if(gate)gate.sample=6;}else{b=gate?.counts();t1=now();}}});
    const s=Math.max(.001,((t1||now())-t0)/1000),frames=Math.max(1,r.fs.n),d=(k,per=s)=>a&&b?(b[k]-a[k])/per:null;
    r.cmp={asked:d('asked'),inside:d('inside'),dropped:d('dropped'),visMs:d('visMs',frames),drawn:r.mean?1000/r.mean:null};
    return r;};
  try{
    await call.setMode(ctx,'fly');await sleep(900);
    for(let round=0;round<ROUNDS;round++){
      ctx.check();
      // at rest, as is: what moving adds is measured against this
      await setFx(true);if(gate)gate.on=false;await settle(ctx,{timeout:1200});
      runs.rest.push(await measure(`compare: at rest (${round+1}/${ROUNDS})`,REST,null));
      for(const c of conds){
        ctx.check();
        const toggled=await setFx(c.fx);if(!toggled)await sleep(300);
        if(gate)gate.on=!c.vis;
        try{runs[c.id].push(await measure(`compare: ${c.label} (${round+1}/${ROUNDS})`,MS,move));}
        finally{if(gate&&gate.on){gate.on=false;gate.replay();}}
      }
    }
  }finally{
    // (put back here, at once, whatever stopped the runs; the part's restore and the run's RESTORE check again)
    if(gate)gate.on=false;
    try{await setFx(true);}catch{}
    back=gate?.restore()??null;
  }
  // ---- the lines
  const agg=list=>{if(!list.length)return null;const m=f=>median(list.map(f));
    return {n:list.length,fmed:m(r=>r.fs.med),fp95:m(r=>r.fs.p95),main:m(r=>r.main?.med),mainP95:m(r=>r.main?.p95),fps:m(r=>r.fs.med?1000/r.fs.med:null),drawn:m(r=>r.cmp.drawn),
      perc:m(r=>r.perc),inside:m(r=>r.cmp.inside),dropped:m(r=>r.cmp.dropped),visMs:m(r=>r.cmp.visMs),mod:m(r=>r.mod),
      mainR:range(list.map(r=>r.main?.med)),drawnR:range(list.map(r=>r.cmp.drawn))};};
  const A=agg(runs.A??[]),B=agg(runs.B??[]),C=agg(runs.C??[]),D=agg(runs.D??[]),R=agg(runs.rest);
  const pct=x=>x!=null?`${Math.round(x/hz*100)}% of ${hz} Hz`:'?';
  const sp=(r,f=f1)=>r?(r[0]===r[1]?f(r[0]):`${f(r[0])}–${f(r[1])}`):'?';
  res.lines.push(`COMPARE what costs fps while she moves (fly${dirText}; ${ROUNDS} round${ROUNDS>1?'s':''} of ${['rest',...conds.map(c=>c.id)].join(' ')}, ${f1(MS/1000)} s a run; medians of the runs, spread = lowest–highest run): frame ms med/p95 · main ms/frame med/p95 · fps by median, drawn a second · perception calls/s (from inside _refreshVisibility, held back) · _refreshVisibility ms/frame · Yvaelle’s Toolbox ms/frame`);
  const line=(id,label,a)=>{if(!a)return;res.lines.push(`  ${id} ${label.padEnd(15)} ${f1(a.fmed)}/${f1(a.fp95)} · ${f1(a.main)}/${f1(a.mainP95)} · ${Math.round(a.fps??0)} fps, ${Math.round(a.drawn??0)} drawn/s (${pct(a.drawn)}) · percept ${Math.round(a.perc??0)}/s (${a.inside!=null?Math.round(a.inside):'-'}, ${a.dropped!=null?Math.round(a.dropped):'-'}) · refreshVis ${a.visMs!=null?f2(a.visMs):'-'} · FF ${a.mod!=null?f2(a.mod):'-'} · spread main ${sp(a.mainR)}, drawn ${sp(a.drawnR,x=>String(Math.round(x)))} (${a.n} run${a.n>1?'s':''})`);};
  line('R','at rest, as is',R);line('A','as is',A);line('B','FF visuals off',B);line('C','Visioner paused',C);line('D','both off',D);
  for(const n of notes)res.lines.push(`  ${n}`);
  if(visOk){const w=Object.entries(gate.who).sort((a,b)=>b[1]-a[1]),tot=w.reduce((n,[,v])=>n+v,0);
    res.lines.push(`  Visioner paused by: holding back, on this browser only, the canvas.perception.update requests made inside Token#_refreshVisibility (where its libWrapper wrapper asks); its wrappers stay registered and run · askers sampled there: ${tot?w.map(([k,v])=>`${k} ${v}/${tot}`).join(', '):'none (nothing asked from inside _refreshVisibility)'}${gate.skipped?` · ${gate.skipped} token${gate.skipped>1?'s':''} left unmarked`:''} · put back: ${back?`${back.tokens&&back.update?'exactly':`${back.tokens?'':'tokens DIFFER '}${back.update?'':'perception.update DIFFERS'}`}`:'?'}`);
    if(tot&&!gate.who[VISIONER])res.lines.push(`  (the requests held back in C and D did not come from PF2e Visioner: C measures whoever asked)`);}
  // ---- in plain words
  if(A&&R){
    const refresh=1000/hz;
    const noise=A.mainR?(A.mainR[1]-A.mainR[0])/2:0;
    const part=(name,x,fpsGain)=>x==null?null:`${name} ${f1(Math.max(0,x))} ms (≈ ${fpsGain==null?'?':`${fpsGain>=0?'+':''}${Math.round(fpsGain)}`} fps${Math.abs(x)<=noise?', within the spread':''})`;
    // (the frame's main-thread work while she moves, split: what each one saves when it is off, and the rest; the rest
    // less the work at rest is what moving adds besides them, when Yvaelle’s Toolbox and Visioner cost little at rest)
    const moving=A.main-R.main,ff=B?A.main-B.main:null,vv=C?A.main-C.main:null;
    const others=A.main-Math.max(0,ff??0)-Math.max(0,vv??0),extra=others-R.main;
    const bits=[part('Yvaelle’s Toolbox',ff,B?B.drawn-A.drawn:null),part('PF2e Visioner',vv,C?C.drawn-A.drawn:null),`Foundry and others ${f1(Math.max(0,others))} ms${extra>=0?` (${f1(extra)} more than at rest)`:''}`].filter(Boolean);
    res.lines.push(`  in plain words: moving costs ${f1(moving)} ms a frame (main thread ${f1(A.main)} moving vs ${f1(R.main)} at rest; ${Math.round(A.drawn??0)} vs ${Math.round(R.drawn??0)} frames drawn a second); of the ${f1(A.main)}: ${bits.join(', ')}`+
      `${D?` · both off together: ${f1(A.main-D.main)} ms, ${Math.round(D.drawn??0)} fps`:''} · at your ${hz} Hz a refresh is ${f1(refresh)} ms: as is she draws ${pct(A.drawn)}${B?`, FF visuals off ${pct(B.drawn)}`:''}${C?`, Visioner paused ${pct(C.drawn)}`:''}${D?`, both off ${pct(D.drawn)}`:''}`+
      `${ff!=null&&ff<0&&-ff>noise?' · (Yvaelle’s Toolbox off came out slower: noise between runs)':''}`);
  }
  if(back&&!(back.tokens&&back.update))verdict(res,'CHECK',`compare: perception wrappers not put back exactly (tokens ${back.tokens?'ok':'differ'}, perception.update ${back.update?'ok':'differs'})`);
  return {A,B,C,D,R,back};
}
/** "Compare" on its own: the same free line and the same moves as PERFORMANCE's "move fly". */
async function compareScenario(ctx,res){
  let n=8,dir=null;for(;n>=2&&!dir;n--)dir=freeDirection(ctx,n);n++;
  if(!dir){res.skipped='no free line of 2+ squares next to her';return;}
  const home={x:ctx.doc.x,y:ctx.doc.y},mode0=call.state(ctx)?.requested?.mode;
  res.restore(async()=>{if(ctx.doc.x!==home.x||ctx.doc.y!==home.y){await ctx.doc.update({x:home.x,y:home.y},{animate:false});await sleep(200);}});
  res.restore(async()=>{if(mode0&&AIRBORNE_MODES.includes(mode0)&&call.state(ctx)?.requested?.mode!==mode0)await call.setMode(ctx,mode0);});
  const ctrl=ctx.service?.hudController?.();if(ctrl?.opened)res.lines.push('(her HUD is open: it stays open in every run)');
  await ensureFlying(ctx);ctx.check();
  if(!homeBits(ctx)){await call.bitsOn(ctx,true);await sleep(1200);}
  await settle(ctx,{timeout:1500});
  await compareRows(ctx,res,until=>moveLoop(ctx,dir,n,until),{dirText:`, ${n} squares ${dir.name} and back`});
}
SCENARIO_RUN.compare=compareScenario;
/* ---------------------------------------------------------------- V11 (11.0.0-test.4) */
/** What the V11 part borrows from here (self-check-v11.mjs cannot import this file: it is imported by it). */
const v11Helpers=()=>({verdict,popVerdicts,findPops,frameStats,ensureFlying,settle,freeDirection,moveBy,moveLoop,measureLoad,withHp,call,sleep,now,nextFrame,waitUntil,stats,bitsDrawn,hpPath,setting});
for(const id of V11_IDS)SCENARIO_RUN[id]=(ctx,res)=>V11_RUN[id](ctx,res,v11Helpers());
for(const id of V12_IDS)SCENARIO_RUN[id]=(ctx,res)=>V12_RUN[id](ctx,res,{...v11Helpers(),warpTo});
for(const id of V13_IDS)SCENARIO_RUN[id]=(ctx,res)=>V13_RUN[id](ctx,res,v11Helpers());

function legMetrics(frames,leg,grid,idle=0){
  const post=frames.filter(f=>f.t>=leg.at&&f.t<=leg.end&&f.bx!=null),during=frames.filter(f=>f.t>=leg.go&&f.t<=leg.end);
  const proj=f=>((f.bx-leg.target.x)*leg.u.x+(f.by-leg.target.y)*leg.u.y)/grid;
  // (her idle sway along the line, measured just before, is not overshoot)
  const overshoot=Math.max(0,Math.max(0,...post.map(proj))-idle);
  // settled: from then on within 0.05 sq of the stop along the line, or within
  // her idle sway (bob is vertical: a vertical line uses a looser limit)
  const lim=Math.max(leg.u.y?0.12:0.05,idle*1.5);let settled=null;
  for(let i=post.length-1;i>=0;i--){if(Math.abs(proj(post[i]))>lim){settled=i+1<post.length?post[i+1]:null;break;}if(i===0)settled=post[0];}
  const lean=Math.max(0,...during.map(f=>Math.abs(f.bank??0)*180/Math.PI));
  return {overshoot,settle:settled?(settled.t-leg.at)/1000:null,lean};
}
function bitsDrawn(ctx){const out={};for(const c of canvas.primary?.children??[]){const n=c?.name;if(typeof n!=='string'||!n.startsWith(ctx.prefix))continue;const k=trackKey(n.slice(ctx.prefix.length));if(k?.startsWith('bit:')&&c.visible!==false&&c.alpha>.05)out[k]=true;}return out;}
function hpPath(actor){const hp=actor?.system?.attributes?.hp;return hp&&Number.isFinite(Number(hp.value))&&typeof actor.update==='function';}

/** Change her HP inside `fn`, then always put HP, temporary HP and any
 * condition or effect that appeared or disappeared meanwhile back. */
async function withHp(ctx,fn,res){
  const actor=ctx.doc.actor;if(!hpPath(actor))return {skipped:'no HP to change'};
  if(!actor.isOwner)return {skipped:'you do not own her actor'};
  const hp0={value:Number(actor.system.attributes.hp.value),temp:Number(actor.system.attributes.hp.temp)||0,max:Number(actor.system.attributes.hp.max)||0};
  const kinds=['Item','ActiveEffect'],snap=collection=>new Map([...(collection?.contents??collection??[])].map(d=>[d.id,d]));
  const isState=d=>d?.documentName==='ActiveEffect'||['condition','effect'].includes(d?.type);
  const before={Item:new Map([...snap(actor.items)].filter(([,d])=>isState(d)).map(([id,d])=>[id,clone(d.toObject?.()??null)])),ActiveEffect:new Map([...snap(actor.effects)].map(([id,d])=>[id,clone(d.toObject?.()??null)]))};
  const statuses=new Set(actor.statuses??[]);
  // (11.0.0-test.4) her dying value too (PF2e derives it from the dying condition; elsewhere it is plain data)
  const dy0=Number(actor.system?.attributes?.dying?.value);
  let value,note=null;
  try{value=await fn(actor,hp0);}
  finally{
    try{
      const cur=actor.system.attributes.hp;
      if(Number(cur.value)!==hp0.value||(Number(cur.temp)||0)!==hp0.temp)await actor.update({'system.attributes.hp.value':hp0.value,'system.attributes.hp.temp':hp0.temp});
    }catch(e){note=`HP restore failed: ${e?.message??e}`;}
    // conditions the system added (dying, unconscious, wounded…) or removed meanwhile
    for(let pass=0;pass<3;pass++){
      let changed=false;await sleep(250);
      for(const kind of kinds){
        const coll=kind==='Item'?actor.items:actor.effects;if(!coll)continue;
        const nowMap=snap(coll);
        const added=[...nowMap.values()].filter(d=>!before[kind].has(d.id)&&(kind!=='Item'||isState(d))).map(d=>d.id);
        if(added.length){try{await actor.deleteEmbeddedDocuments(kind,added);changed=true;}catch(e){note=`could not remove ${added.length} new ${kind}: ${e?.message??e}`;}}
        const removed=[...before[kind].entries()].filter(([id,data])=>data&&!nowMap.has(id)).map(([,data])=>data);
        if(removed.length){try{await actor.createEmbeddedDocuments(kind,removed,{keepId:true});changed=true;}catch(e){note=`could not restore ${removed.length} ${kind}: ${e?.message??e}`;}}
        for(const [id,data] of before[kind]){const d=nowMap.get(id);if(!d||!data)continue;
          const v0=data.system?.value?.value,v1=d.system?.value?.value;
          if(v0!==undefined&&v0!==v1){try{await d.update({'system.value.value':v0});changed=true;}catch{}}
          if(kind==='ActiveEffect'&&data.disabled!==d.disabled){try{await d.update({disabled:data.disabled});changed=true;}catch{}}}
      }
      if(!changed)break;
    }
    if(Number.isFinite(dy0)&&(Number(actor.system?.attributes?.dying?.value)||0)!==dy0){try{await actor.update({'system.attributes.dying.value':dy0});}catch{}}
    const lost=[...statuses].filter(s=>!(actor.statuses??new Set()).has(s)),gained=[...(actor.statuses??[])].filter(s=>!statuses.has(s));
    if(lost.length||gained.length)note=(note?note+' · ':'')+`status changed: ${gained.map(s=>'+'+s).concat(lost.map(s=>'-'+s)).join(' ')}`;
    if(res)res.hpRestore=note??'ok';
  }
  return {value,restoreNote:note};
}

/* ---------------------------------------------------------------- snapshot & restore */
function takeSnapshot(ctx){
  const d=ctx.doc,st=call.state(ctx);
  // (10.0.1) localEffects: the comparison turns the Toolbox’s visuals off on this browser for some of its runs
  const settings={};for(const k of ['bitSendOutStyle','localEffects'])settings[k]=setting(k);
  return {x:d.x,y:d.y,elevation:d.elevation,flags:clone(d.flags?.[ID]??{}),settings,
    enabled:!!st?.enabled,airborne:airborne(st),mode:st?.requested?.mode,shield:d.getFlag?.(ID,'wingShield'),light:!!st?.light?.enabled,
    hp:hpPath(d.actor)?{value:Number(d.actor.system.attributes.hp.value),temp:Number(d.actor.system.attributes.hp.temp)||0}:null,
    // (11.0.0-test.4) everything the V11 part may touch: every module setting (this browser's and the world's),
    // her user flags (the macro ring), her actor's flags (her journal), her conditions and this browser's own keys
    all:moduleSettings(),user:userFlags(),actorFlags:withoutLive(clone(d.actor?.flags?.[ID]??{})),actor:actorState(d.actor),local:localKeys()};
}
/** (11.0.0-test.4) Every Yvaelle’s Toolbox setting: key → {scope, value}. Without Foundry's registry, the ones the check knows. */
const KNOWN_SETTINGS=[...RELEVANT_SETTINGS,'v11Client','v11World','quickWheel','keepsakeUI','hudPreferences','hudEnabled','warpArrival'];
function moduleSettings(){
  const out={},reg=game.settings?.settings;
  if(reg?.entries){for(const [key,cfg] of reg.entries()){const [ns,k]=String(key).split(/\.(.+)/);if(ns!==ID||!k||LIVE_SETTINGS.has(k))continue;const v=setting(k);if(v!==undefined)out[k]={scope:cfg?.scope??'client',value:clone(v)};}}
  else for(const k of KNOWN_SETTINGS){const v=setting(k);if(v!==undefined)out[k]={scope:'client',value:clone(v)};}
  return out;
}
function userFlags(){const u=game.user;if(!u)return null;if(u.flags&&typeof u.flags==='object')return clone(u.flags[ID]??{});const o={};try{const v=u.getFlag?.(ID,MACRO_FLAG);if(v!==undefined)o[MACRO_FLAG]=clone(v);}catch{}return o;}
function actorState(actor){
  if(!actor)return null;
  const items=[...(actor.items?.contents??actor.items??[])].filter(i=>['condition','effect'].includes(i?.type)).map(i=>`${i.id}:${i.system?.value?.value??''}`).sort();
  const fx=[...(actor.effects?.contents??actor.effects??[])].map(e=>`${e.id}:${e.disabled?0:1}`).sort();
  return {items,fx,dying:Number(actor.system?.attributes?.dying?.value)||0,hero:actor.system?.resources?.heroPoints?.value??null,statuses:[...(actor.statuses??[])].sort()};
}
const LOCAL_RE=/^filament-flight\./;
function localKeys(){const o={};try{const ls=globalThis.localStorage;for(let i=0;i<(ls?.length??0);i++){const k=ls.key(i);if(LOCAL_RE.test(k))o[k]=ls.getItem(k);}}catch{}return o;}
/** Put the V11 part's wider state back (settings, user flags, actor flags, this browser's keys); returns what it found. */
async function restoreWider(ctx,snap,out){
  const d=ctx.doc,gm=!!game.user?.isGM;
  // settings: every one that differs, where this user may write it
  const differ=[];
  for(const [k,{scope,value}] of Object.entries(snap.all??{})){if(sameData(setting(k),value))continue;if(scope==='world'&&!gm){differ.push(`${k} (world)`);continue;}
    try{await game.settings.set(ID,k,clone(value));}catch{}if(!sameData(setting(k),value))differ.push(k);}
  out.allSettings=Object.keys(snap.all??{}).length;out.settingsLeft=differ;
  // her user flags (the macro ring)
  if(snap.user){const u=game.user,cur=userFlags();
    if(!sameData(cur,snap.user)){
      if(u.flags&&typeof u.update==='function'){try{await u.update(flagDiff(snap.user,cur,`flags.${ID}`));}catch{}}
      else for(const k of new Set([...Object.keys(snap.user),...Object.keys(cur??{})])){try{if(k in snap.user)await u.setFlag(ID,k,clone(snap.user[k]));else await u.unsetFlag(ID,k);}catch{}}}
    out.userFlags=sameData(userFlags(),snap.user);}
  // her actor's flags (her journal, her portrait)
  const actor=d.actor;
  if(actor&&snap.actorFlags){const live=()=>withoutLive(clone(actor.flags?.[ID]??{})),cur=live();
    if(!sameData(cur,snap.actorFlags)&&actor.isOwner){try{await actor.update(flagDiff(snap.actorFlags,cur,`flags.${ID}`),{render:false});}catch{}}
    out.actorFlags=sameData(live(),snap.actorFlags);if(!out.actorFlags)out.actorLeft=diffPaths(snap.actorFlags,live()).slice(0,4);}
  if(snap.actor){const now=actorState(actor),diff=Object.keys(snap.actor).filter(k=>!sameData(now?.[k],snap.actor[k]));out.actorState=!diff.length;out.actorDiff=diff;}
  // this browser's own keys (the petals that grew)
  try{const ls=globalThis.localStorage,cur=localKeys();for(const k of Object.keys(cur))if(!(k in snap.local))ls.removeItem(k);for(const [k,v] of Object.entries(snap.local??{}))if(cur[k]!==v)ls.setItem(k,v);out.local=sameData(localKeys(),snap.local);}catch{out.local=null;}
}
/** Dotted changes that turn `now` back into `before` exactly (nested flag
 * objects merge in Foundry, so keys that were added are deleted with -=). */
function flagDiff(before,now,path,out={}){
  for(const key of new Set([...Object.keys(before??{}),...Object.keys(now??{})])){
    const p=`${path}.${key}`;
    if(!Object.hasOwn(before??{},key)){forceDelete(out,path,key);continue;}
    const a=before[key],b=now?.[key];
    if(sameData(a,b))continue;
    if(plain(a)&&plain(b))flagDiff(a,b,p,out);else out[p]=clone(a);
  }
  return out;
}
/** Wait for her token to be quiet: the module's command queue empty and no
 * update to her token for 700 ms (at most 6 s). */
async function quietToken(ctx){
  const d=ctx.doc,end=now()+6000;let last=now();
  const id=Hooks.on?.('updateToken',doc=>{if(doc===d)last=now();});
  try{
    while(now()<end){
      const q=ctx.service?.queues?.get?.(d.uuid);if(q){try{await q;}catch{}last=Math.max(last,now()-400);}
      if(now()-last>=700)break;await sleep(100);
    }
  }finally{try{Hooks.off?.('updateToken',id);}catch{}}
}
async function restoreSnapshot(ctx,snap){
  const out={};const d=ctx.doc;
  if(!ctx.token||ctx.token.destroyed||!d?.parent)return {error:'her token is gone'};
  // put settings back first (they only change what this browser shows)
  for(const [k,v] of Object.entries(snap.settings))if(v!==undefined&&setting(k)!==v)try{await game.settings.set(ID,k,v);}catch{}
  out.settings=Object.entries(snap.settings).every(([k,v])=>v===undefined||setting(k)===v);
  if(out.settings)pendingClear();
  try{await restoreWider(ctx,snap,out);}catch(e){out.wider=String(e?.message??e).slice(0,80);}
  // the gentle way first: her own commands, so the last change animates
  try{
    let st=call.state(ctx);
    if(snap.light!==!!st?.light?.enabled)await call.light(ctx,snap.light);
    if(!same(d.getFlag?.(ID,'wingShield'),snap.shield))await call.shield(ctx,snap.shield===true);
    st=call.state(ctx);
    if(snap.enabled&&snap.airborne&&snap.mode&&st?.requested?.mode!==snap.mode&&AIRBORNE_MODES.includes(snap.mode))await call.setMode(ctx,snap.mode);
    if(!snap.airborne&&airborne(call.state(ctx))){await call.land(ctx);await waitUntil(()=>!airborne(call.state(ctx))&&!call.state(ctx)?.transition?.active,7000,()=>sleep(100));}
    if(!snap.enabled&&call.state(ctx)?.enabled){await call.wings(ctx,false);await sleep(1500);}
    await sleep(400);
  }catch(e){out.commands=String(e?.message??e).slice(0,100);}
  // then exactly: position, elevation and every module flag as they were
  const changes=flagDiff(snap.flags,clone(d.flags?.[ID]??{}),`flags.${ID}`);
  const moved=d.x!==snap.x||d.y!==snap.y;if(moved){changes.x=snap.x;changes.y=snap.y;}
  if((d.elevation??0)!==(snap.elevation??0))changes.elevation=snap.elevation??0;
  const keysOf=c=>Object.keys(c).filter(k=>k.startsWith('flags.')).map(k=>k.slice(`flags.${ID}.`.length).replace('-=','').split('.').slice(0,2).join('.'));
  out.flagKeys=keysOf(changes);
  if(Object.keys(changes).length){try{await d.update(changes,{animate:false});}catch(e){out.error=String(e?.message??e).slice(0,120);}}
  // The module may still be writing (queued commands, bits finishing, a
  // landing completing): wait until her token has been quiet, then put back
  // whatever changed again, up to three times.
  for(let pass=0;pass<3;pass++){
    await quietToken(ctx);
    const again=flagDiff(snap.flags,clone(d.flags?.[ID]??{}),`flags.${ID}`);
    if((d.elevation??0)!==(snap.elevation??0))again.elevation=snap.elevation??0;
    if(d.x!==snap.x||d.y!==snap.y){again.x=snap.x;again.y=snap.y;}
    if(!Object.keys(again).length)break;
    out.passes=pass+2;out.lateKeys=[...new Set([...(out.lateKeys??[]),...keysOf(again)])];
    try{await d.update(again,{animate:false});}catch(e){out.error=String(e?.message??e).slice(0,120);break;}
  }
  out.position=d.x===snap.x&&d.y===snap.y;out.elevation=(d.elevation??0)===(snap.elevation??0);
  out.flags=sameData(clone(d.flags?.[ID]??{}),snap.flags);
  if(!out.flags)out.left=diffPaths(snap.flags,clone(d.flags?.[ID]??{})).slice(0,6);
  // (11.0.0-test.4) the v11 token flags by name, the wider state once more (a late write), and the v11 runtimes at rest
  {const now=clone(d.flags?.[ID]??{});out.v11Flags=V11_TOKEN_FLAGS.filter(k=>!sameData(now[k],snap.flags[k]));out.v11Present=V11_TOKEN_FLAGS.filter(k=>snap.flags[k]!==undefined);}
  if(snap.all&&(out.settingsLeft?.length||out.actorFlags===false||out.userFlags===false))try{await sleep(400);await restoreWider(ctx,snap,out);}catch{}
  out.residue=[...v11Residue(ctx),...v12Residue(ctx),...v13Residue(ctx)];
  const st=call.state(ctx);out.mode=`${snap.mode??'?'}${snap.airborne?' flying':' grounded'}${snap.enabled?'':' wings off'} → ${st?.requested?.mode??'?'}${airborne(st)?' flying':' grounded'}${st?.enabled?'':' wings off'}`;
  out.modeOk=st?.requested?.mode===snap.mode&&airborne(st)===snap.airborne&&!!st?.enabled===snap.enabled;
  if(snap.hp){const hp=d.actor?.system?.attributes?.hp;out.hp=Number(hp?.value)===snap.hp.value&&(Number(hp?.temp)||0)===snap.hp.temp;}
  return out;
}

/* ---------------------------------------------------------------- environment */
async function environment(ctx){
  const env={};
  env.foundry=String(game.version??game.release?.version??'?');
  env.system=`${game.system?.id??'?'} ${game.system?.version??''}`.trim();
  env.browser=browserName();env.gl=glRenderer();env.hz=await refreshRate();
  try{const r=canvas.app.renderer,s=r.screen;env.canvas=`${s.width}x${s.height} @${f2(r.resolution??1)} (dpr ${f2(globalThis.devicePixelRatio??1)})`;}catch{env.canvas='?';}
  try{env.zoom=r2(canvas.stage.scale.x);}catch{}
  env.grid=ctx.grid;env.tokens=canvas.tokens?.placeables?.length??0;
  env.maxFPS=setting('maxFPS','core');env.perfMode=setting('performanceMode','core');
  env.user=`${game.user?.isGM?'GM':'player'}${game.paused?' · paused':''}${game.combat?.started?' · in combat':''}`;
  env.worker=typeof Worker==='function'&&typeof OffscreenCanvas==='function';
  const all={};
  const reg=game.settings?.settings;
  const known=new Set([...RELEVANT_SETTINGS,...['sheet','hud'].flatMap(x=>KEEP_GROUPS.map(g=>keepKey(x,g.id)))]);
  if(reg?.keys)for(const key of reg.keys()){const [ns,k]=String(key).split(/\.(.+)/);if(ns===ID&&/^(version|keepPlaying)/.test(k??''))known.add(k);}
  for(const k of known){const v=setting(k);if(v!==undefined)all[k]=v;}
  env.settings=all;
  env.token=ctx.token?`${ctx.doc?.name??'?'} (${ctx.how})`:'none';
  return env;
}
function summariseHer(ctx){
  const st=call.state(ctx),d=ctx.doc,bs=call.bitState(ctx);
  const feel=(()=>{try{return ctx.api?.flightFeel?.(ctx.token)??null;}catch{return null;}})();
  const home=(bs?.allocations??[]).filter(b=>b.location==='home').length;
  return {enabled:!!st?.enabled,airborne:airborne(st),mode:st?.effective?.mode,requested:st?.requested?.mode,renderer:st?.rendering?.localRenderer,
    bits:`${home} home${bs?.busy?' (busy)':''}`,light:!!st?.light?.enabled,lantern:!!st?.lantern?.enabled,shield:d.getFlag?.(ID,'wingShield')??null,
    elevation:d.elevation,ground:d.getFlag?.(ID,'flightGround')??null,
    feel:feel?`${feel.weight}/${feel.scale} alt ${feel.altitude}${feel.takeoffElevation?' takeoff-sets-elevation':' elevation-by-player'}${feel.heightByMode?' by-mode':''} after:${feel.afterimages}`:null,
    hp:hpPath(d.actor)?`${d.actor.system.attributes.hp.value}/${d.actor.system.attributes.hp.max}`:null};
}

/* ---------------------------------------------------------------- report */
const SHORT={versionGestures:'gest',versionCoreStates:'core',versionBitOutline:'outline',versionFormations:'form',versionScans:'scan',versionWingMotion:'wing',versionIris:'iris',versionFlightFeel:'feel',versionWarp:'warp'};
function valueText(v){if(plain(v))return Object.entries(v).map(([k,x])=>`${k}:${typeof x==='object'?'…':x}`).join(',');return String(v);}
export function formatReport(r){
  const L=[];const date=(r.started??new Date().toISOString()).replace('T',' ').slice(0,16)+' UTC';
  L.push(`FF-CHECK v${r.version} · module ${r.module} · ${date} · ${Math.round(r.seconds??0)} s${r.aborted?' · STOPPED':''}`);
  const e=r.env??{},s=e.settings??{},v=k=>valueText(s[k]).slice(0,24);
  L.push(`ENV Foundry ${e.foundry} · ${e.system} · ${e.browser} · ${e.hz??'?'} Hz · ${e.user}`);
  L.push(`GPU ${String(e.gl??'?').slice(0,100)}`);
  L.push(`CANVAS ${e.canvas} · zoom ${e.zoom} · grid ${e.grid} · ${e.tokens} tokens · maxFPS ${e.maxFPS??'?'} · perf ${e.perfMode??'?'} · worker ${e.worker?'yes':'no'}`);
  L.push(`SET fps ${v('rigFPS')}/${v('poseFPS')} · worker ${v('renderWorker')} · quality ${v('rigQuality')}/${v('bitQuality')} preset ${v('localQuality')} · renderer ${v('wingRenderer')} · reduced ${v('reducedMotion')} · trails ${v('wingTrails')}/${v('localTrails')}/${v('trailModes')}`);
  L.push(`SET manoeuvres ${v('flightManoeuvres')} · follow ${v('wingFollowThrough')} · fg ${v('foregroundWings')} · light ${v('wingLight')} · arrival ${v('warpArrival')} · bend ${v('warpBendTokens')} · range ${v('warpRange')} · send-out ${v('bitSendOutStyle')} · sound ${s.audioEnabled===false?'off':s.audioMuted?'muted':'on'} ${v('audioVolume')}/${v('audioLocalVolume')}`);
  L.push(`VER ${Object.keys(s).filter(k=>/^version/.test(k)).map(k=>`${SHORT[k]??k}=${s[k]}`).join(' ')}`);
  // (beta.40) Keep playing: the loops that go on while tokens move
  {const kp=surface=>Object.keys(s).filter(k=>k.startsWith('keepPlaying'+surface)&&s[k]===true).map(k=>k.slice(11+surface.length).toLowerCase()).join('+')||'none';
   if(Object.keys(s).some(k=>k.startsWith('keepPlaying')))L.push(`KEEP playing while moving: sheet ${kp('Sheet')} · hud ${kp('Hud')}`);}
  const h=r.her;
  L.push(`HER ${e.token}${h?` · ${h.enabled?'wings on':'wings off'} · ${h.airborne?'flying':'grounded'} ${h.requested??''} · ${h.renderer??'no renderer'} · bits ${h.bits} · light ${h.light?'on':'off'}${h.lantern?' +lantern':''} · shield ${h.shield??'down'} · elev ${h.elevation??0}${h.ground!=null?`/${h.ground}`:''} · feel ${h.feel??'?'} · HP ${h.hp??'?'}`:''}`);
  if(r.fatal)L.push(`FATAL ${r.fatal}`);
  if(r.note)L.push(`NOTE ${r.note}`);
  const all=r.errors??[],errs=all.filter(x=>!foreignError(x)),others=all.filter(foreignError);const count=k=>errs.filter(x=>x.kind===k).reduce((n,x)=>n+x.n,0);
  L.push(`ERR ${count('error')} errors · ${count('warn')} Filament warnings · ${count('uncaught')} uncaught · ${count('rejection')} rejections`);
  if(others.length){const by={};for(const x of others)by[x.origin]=(by[x.origin]??0)+x.n;
    L.push(`ERR other modules (thrown by their code, not the Toolbox’s; not counted above): ${Object.entries(by).map(([k,n])=>`${k} ${n}`).join(' · ')}`);
    for(const x of others.slice(0,2))L.push(`  ${x.origin} ${x.kind}${x.n>1?` ×${x.n}`:''}${x.parts?.length?` [${x.parts.join(',')}]`:''}: ${x.text.slice(0,90)}`);}
  for(const x of errs.slice(0,5))L.push(`  ${x.kind}${x.n>1?` ×${x.n}`:''}${x.parts?.length?` [${x.parts.join(',')}]`:''}: ${x.text.slice(0,120)}${x.frames?.length?` · at ${x.frames.join(' < ')}`:''}`);
  const tally={PASS:0,CHECK:0,FAIL:0};
  for(const sc of r.scenarios??[]){
    const id=sc.head??sc.id.toUpperCase();
    if(sc.skipped){L.push(`-- ${id} skipped: ${sc.skipped}`);continue;}
    L.push(`-- ${id} (${f1(sc.seconds)} s)`);
    for(const l of sc.lines)L.push(`   ${l}`);
    for(const x of sc.verdicts){L.push(`   ${x}`);const k=x.split(' ')[0];if(k in tally)tally[k]++;}
    // (a second pop at the same moment of the same kind adds nothing)
    const a=sc.pops[0]?.split(' ')[0],k=x=>x.replace(/^\S+ /,'').replace(/(left|right)-gem-\d/,'gem').replace(/[\d.]+(%| sq)/,'');
    const more=sc.pops.slice(1).find(x=>x.split(' ')[0]!==a||k(x)!==k(sc.pops[0]));if(more)L.push(`   also: ${more}`);
    if(sc.hpRestore&&sc.hpRestore!=='ok')L.push(`   HP restore: ${sc.hpRestore}`);
    if(sc.restoreError)L.push(`   restore problem: ${sc.restoreError}`);
  }
  const rs=r.restore??{};
  if(!r.her)L.push(r.scenarios?.some(x=>TOKENLESS.has(x.id)&&!x.skipped)?'RESTORE her sheet and the page put back as they were (no token parts ran)':'RESTORE nothing was changed');
  else{
    L.push(`RESTORE ${rs.error?`error ${rs.error} · `:''}position ${rs.position?'ok':'CHANGED'} · elevation ${rs.elevation?'ok':'CHANGED'} · flags ${rs.flags?'exact':`DIFFER at ${(rs.left??[]).join(', ')}`}${rs.flagKeys?.length?` (rewrote ${[...new Set(rs.flagKeys)].slice(0,6).join(', ')}${rs.lateKeys?.length?`; late writes ${rs.lateKeys.slice(0,4).join(', ')}, ${rs.passes} passes`:''})`:''} · mode ${rs.modeOk===false?`CHANGED ${rs.mode}`:'ok'} · settings ${rs.settings===false||rs.settingsLeft?.length?`DIFFER ${(rs.settingsLeft??[]).slice(0,4).join(', ')}`:'ok'}${rs.hp===undefined?'':` · HP ${rs.hp?'ok':'DIFFERS'}`}${rs.commands?` · ${rs.commands}`:''}`);
    // (11.0.0-test.4) the wider state the V11 part may touch
    if(rs.allSettings!=null)L.push(`RESTORE v11 token flags ${rs.v11Flags?.length?`DIFFER ${rs.v11Flags.join(', ')}`:`exact (${['v11','v11Cloak','v11Emote'].map(k=>`${k} ${rs.v11Present?.includes(k)?'kept':'none'}`).join(', ')})`} · ${rs.allSettings} settings (client+world, quick wheel) ${rs.settingsLeft?.length?'DIFFER':'ok'} · user flags (macro ring) ${rs.userFlags===false?'DIFFER':'ok'} · actor flags (journal) ${rs.actorFlags===false?`DIFFER ${(rs.actorLeft??[]).join(', ')}`:'ok'} · conditions/dying/hero ${rs.actorState===false?`DIFFER ${(rs.actorDiff??[]).join(', ')}`:'ok'} · browser keys ${rs.local===false?'DIFFER':'ok'} · v11 runtimes ${rs.residue?.length?`STILL ${rs.residue.join(', ')}`:'at rest'}${rs.wider?` · ${rs.wider}`:''}`);
  }
  // (11.0.0-test.4) and the V11 part's own share
  const v11=(r.scenarios??[]).filter(x=>V11_SET.has(x.id)&&!x.skipped),vt={PASS:0,CHECK:0,FAIL:0};for(const sc of v11)for(const x of sc.verdicts){const k=x.split(' ')[0];if(k in vt)vt[k]++;}
  // (12.0.0-beta.4) and the V12 part's
  const v12=(r.scenarios??[]).filter(x=>V12_SET.has(x.id)&&!x.skipped),wt={PASS:0,CHECK:0,FAIL:0};for(const sc of v12)for(const x of sc.verdicts){const k=x.split(' ')[0];if(k in wt)wt[k]++;}
  // (13.0.0-beta.2) and the V13 part's
  const v13=(r.scenarios??[]).filter(x=>V13_SET.has(x.id)&&!x.skipped),xt={PASS:0,CHECK:0,FAIL:0};for(const sc of v13)for(const x of sc.verdicts){const k=x.split(' ')[0];if(k in xt)xt[k]++;}
  L.push(`SUMMARY ${tally.PASS} PASS · ${tally.CHECK} CHECK · ${tally.FAIL} FAIL${v11.length?` (V11 ${vt.PASS} PASS · ${vt.CHECK} CHECK · ${vt.FAIL} FAIL in ${v11.length} parts, ${Math.round(v11.reduce((n,x)=>n+(x.seconds??0),0))} s)`:''}${v12.length?` (V12 ${wt.PASS} PASS · ${wt.CHECK} CHECK · ${wt.FAIL} FAIL in ${v12.length} parts, ${Math.round(v12.reduce((n,x)=>n+(x.seconds??0),0))} s)`:''}${v13.length?` (V13 ${xt.PASS} PASS · ${xt.CHECK} CHECK · ${xt.FAIL} FAIL in ${v13.length} parts, ${Math.round(v13.reduce((n,x)=>n+(x.seconds??0),0))} s)`:''}`);
  // (11.0.0-test.4) never cut: the Copy button and the chat whisper carry the whole report (beta.39's 12 KB report was cut at 11.5 KB)
  return L.join('\n');
}

/* ---------------------------------------------------------------- dialog */
const STYLE=`
#ff-self-check{position:fixed;z-index:10000;top:70px;left:50%;transform:translateX(-50%);width:min(560px,94vw);max-height:84vh;display:flex;flex-direction:column;
  background:radial-gradient(120% 70% at 80% 0%,rgba(122,24,48,.22),transparent 60%),linear-gradient(rgba(17,10,14,.96),rgba(17,10,14,.98)),#130b10;color:#f3eadf;
  font-family:'Keepsake Sans',system-ui,sans-serif;font-size:13px;line-height:1.45;box-shadow:inset 0 0 0 4px #130b10,inset 0 0 0 5px rgba(207,174,118,.26),0 26px 80px rgba(0,0,0,.8),0 0 0 1px #4a3240;padding:18px 20px 16px;box-sizing:border-box}
#ff-self-check.ff-sc-wide{width:min(800px,96vw)}
#ff-self-check.ff-sc-small{top:auto;bottom:16px;left:auto;right:330px;transform:none;width:300px;padding:12px 14px}
#ff-self-check h2{margin:0 0 2px;font:600 22px/1.1 'Keepsake Serif',Georgia,serif;color:#fbf1e4;border:0;letter-spacing:.01em}
#ff-self-check .ff-sc-kicker{font:600 10px/1 'Keepsake Sans',system-ui,sans-serif;letter-spacing:.18em;text-transform:uppercase;color:#cfae76;margin-bottom:10px}
#ff-self-check p{margin:6px 0}#ff-self-check .ff-sc-muted{color:#9c8a80;font-size:12px}
#ff-self-check .ff-sc-who{padding:6px 10px;margin:8px 0;background:#20141b;box-shadow:inset 0 0 0 1px #3f2b36}
#ff-self-check .ff-sc-who b{color:#e767ce;font-weight:600}
#ff-self-check .ff-sc-list{display:grid;grid-template-columns:1fr;gap:3px;margin:10px 0}
/* (13.0.0-beta.2) what it will do and the parts scroll together, so the buttons stay in the window however short it is */
#ff-self-check .ff-sc-body{flex:1 1 auto;min-height:0;overflow:auto;padding-right:6px;scrollbar-width:thin;scrollbar-color:#3f2b36 transparent}
#ff-self-check label.ff-sc-opt{display:flex;gap:9px;align-items:flex-start;padding:5px 8px;background:#1b1017;box-shadow:inset 0 0 0 1px #2c1d25;cursor:pointer}
#ff-self-check label.ff-sc-opt:hover{box-shadow:inset 0 0 0 1px #e767ce}
#ff-self-check label.ff-sc-opt input{margin:2px 0 0;accent-color:#e767ce;flex:none;width:14px;height:14px}
#ff-self-check label.ff-sc-opt span b{display:block;font-weight:600;color:#fbf1e4}#ff-self-check label.ff-sc-opt span i{font-style:normal;color:#9c8a80;font-size:12px}
#ff-self-check .ff-sc-row{display:flex;gap:8px;justify-content:flex-end;margin-top:10px;flex-wrap:wrap}
#ff-self-check button{all:unset;cursor:pointer;padding:7px 16px;background:#24171f;color:#f3eadf;box-shadow:inset 0 0 0 1px #3f2b36;font:600 13px 'Keepsake Sans',system-ui,sans-serif;
  clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)}
#ff-self-check button:hover,#ff-self-check button:focus-visible{background:#2c1424;box-shadow:inset 0 0 0 1px #e767ce}
#ff-self-check button.ff-sc-primary{background:#e767ce;color:#1a0f14;box-shadow:0 0 14px rgba(231,103,206,.3)}#ff-self-check button.ff-sc-primary:hover{background:#f08ad9}
#ff-self-check textarea{width:100%;box-sizing:border-box;min-height:300px;flex:1;resize:vertical;background:#0e080b;color:#f3eadf;border:0;box-shadow:inset 0 0 0 1px #3f2b36;padding:8px;
  font:11px/1.35 ui-monospace,'Cascadia Mono',Consolas,monospace;white-space:pre-wrap;overflow:auto}
#ff-self-check .ff-sc-bar{height:3px;background:#2c1d25;margin:8px 0 4px}#ff-self-check .ff-sc-bar i{display:block;height:100%;background:#e767ce;width:0;transition:width .4s}
#ff-self-check .ff-sc-tally{font-weight:600;color:#cfae76}
`;
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function panelElement(){
  document.getElementById('ff-self-check')?.remove();
  if(!document.getElementById('ff-self-check-style')){const st=document.createElement('style');st.id='ff-self-check-style';st.textContent=STYLE;document.head.append(st);}
  const el=document.createElement('section');el.id='ff-self-check';el.setAttribute('role','dialog');el.setAttribute('aria-label','Yvaelle’s Toolbox self-check');document.body.append(el);return el;
}
/** Open the self-check dialog: what it will do, which parts to run, Run. */
export function openSelfCheck({service=null,manager=null}={}){
  const found=findEllie(),el=panelElement();
  const name=found?.token?.document?.name;
  el.innerHTML=`<div class="ff-sc-kicker">Yvaelle’s Toolbox · ${esc(game.modules?.get?.(ID)?.version??VERSION)}</div><h2>Check how she flies here</h2>
    <div class="ff-sc-who">${found?`Testing <b>${esc(name)}</b> <span class="ff-sc-muted">(${esc(found.how)})</span>`:'<b>No token found.</b> Select Ellie’s token (or pin her in the HUD), then open this again. <span class="ff-sc-muted">The V13 part needs none: “V13 only” runs as it is.</span>'}</div>
    <div class="ff-sc-body"><p>About twenty minutes with everything ticked (the V11 part alone about four, the V12 part about ten, the V13 part about three). It measures your real frame rate, the module’s own cost and every frame of her wings and bits, then gives you a short report to copy back. While it runs it will briefly:</p>
    <p class="ff-sc-muted">take her off if she is down · fly her 3 squares and back in each mode · land and take off · raise her shield · turn her light on and off · send a bit out and back · warp her 3 squares and back (other players see the warp) · if ticked, drop her HP to 0 and heal her · open her HUD and her sheet and try moving and resizing the sheet · for a few seconds at a time, turn the Toolbox’s visuals off on this browser and hold back PF2e Visioner’s visibility refreshes (this browser only).</p>
    <p class="ff-sc-muted"><b>V11:</b> cloak her and play each of her ten emotes (other players see both) · give her three persistent-damage conditions, then drop her HP low, to 0 and through dying 1–3 (landed) · move her a square or two (a wall path, an emote that gives way) · open the quick wheel and every ring · switch each experimental extra on for a moment (no recap is posted) · turn the world features off and on for a few seconds. The wounds, traditions, escapes and die moods are played inside the module only: nothing is posted to chat. Everything is put back as it was: settings, flags, conditions, HP, position.</p>
    <p class="ff-sc-muted"><b>V12:</b> warp her 3 squares and back with each of the four new warps · raise each shield style, and Scale mail and Rotor again with her wings away · land her with each landing style and take off again · cloak her with each of the 13 looks, in flight and on the ground · open the quick wheel, leave a light 2 squares away and call it back · cast a decoy 3 squares away and strike it, then a decoy warp · with V12 sounds switched on for her, a cloak, a warp, a shield and a decoy (other players see all of it; sounds are heard only where her sounds are on). Her shield, landing and cloak choices are put back.</p>
    <p class="ff-sc-muted"><b>V13:</b> about three minutes, and it needs no token of hers. Her curse’s view is played on this screen only, from memory: a roll, Minimise and Open, the Spans, the card and the mark, then her roll again in each of its other three ways, then one laid on her (nothing is written on her actor, nothing goes to chat, nobody else sees it) · as the GM, the curse wheel is opened in the middle of the screen and closed, the states’ editor opened and cancelled, the watching view opened and closed · a scratch note is written on her actor and taken off again · her Keepsake sheet is opened (closed first if it is open) for its opening scan and the curse’s mark. No curse is laid, lifted or changed, and one that is on her is left alone.</p>
    <p class="ff-sc-muted">Best on a quiet test scene, out of combat, with her in view. Keep this tab in front until it finishes.</p>
    <div class="ff-sc-list">${SCENARIOS.filter(([id])=>!SOLO.has(id)).map(([id,label,hint])=>`${id===V11_IDS[0]?'<div class="ff-sc-kicker" style="margin:8px 0 2px">V11 · every 11.0.0-test feature</div>':id===V12_IDS[0]?'<div class="ff-sc-kicker" style="margin:8px 0 2px">V12 · every 12.0.0-beta feature</div>':id===V13_IDS[0]?'<div class="ff-sc-kicker" style="margin:8px 0 2px">V13 · The Heart Turned (needs no token of hers)</div>':''}<label class="ff-sc-opt"><input type="checkbox" data-sc="${id}" checked><span><b>${esc(label)}</b><i>${esc(hint)}</i></span></label>`).join('')}</div></div>
    <div class="ff-sc-row"><button type="button" data-act="close">Cancel</button><button type="button" data-act="compare"${found?'':' disabled'} title="About 80 s: moves her as the Performance part does, as is, with the Toolbox’s visuals off on this browser, with PF2e Visioner paused, and both; everything is put back">Compare (what costs fps while moving)</button><button type="button" data-act="perf"${found?'':' disabled'}>Performance only</button><button type="button" data-act="v11"${found?'':' disabled'} title="About four minutes: only the ten V11 parts">V11 only</button><button type="button" data-act="v12"${found?'':' disabled'} title="About eight minutes: only the nine V12 parts (warps, shield styles, landing, cloaks, the wheel, the Decoy, sounds, cost)">V12 only</button><button type="button" data-act="v13" title="About three minutes, with or without a token of hers: only the six V13 parts (The Heart Turned: setup, her record, the wheel and the editor, her view, watching, her sheet). Her token is not touched">V13 only</button><button type="button" class="ff-sc-primary" data-act="run"${found?'':' disabled'}>Run the check</button></div>`;
  el.querySelector('[data-act=close]').onclick=()=>el.remove();
  const runBtn=el.querySelector('[data-act=run]');
  if(!found){runBtn.style.opacity='.4';runBtn.style.pointerEvents='none';}
  const perfBtn=el.querySelector('[data-act=perf]');
  if(!found){perfBtn.style.opacity='.4';perfBtn.style.pointerEvents='none';}
  perfBtn.onclick=()=>void runWithPanel(el,{scenarios:Object.fromEntries(SCENARIOS.map(([id])=>[id,id==='performance'])),token:found?.token,how:found?.how},{service,manager});
  const v11Btn=el.querySelector('[data-act=v11]');
  if(!found){v11Btn.style.opacity='.4';v11Btn.style.pointerEvents='none';}
  v11Btn.onclick=()=>void runWithPanel(el,{scenarios:Object.fromEntries(SCENARIOS.map(([id])=>[id,V11_SET.has(id)])),token:found?.token,how:found?.how},{service,manager});
  const v12Btn=el.querySelector('[data-act=v12]');
  if(!found){v12Btn.style.opacity='.4';v12Btn.style.pointerEvents='none';}
  v12Btn.onclick=()=>void runWithPanel(el,{scenarios:Object.fromEntries(SCENARIOS.map(([id])=>[id,V12_SET.has(id)])),token:found?.token,how:found?.how},{service,manager});
  // (13.0.0-beta.2) the V13 part runs with or without a token of hers
  el.querySelector('[data-act=v13]').onclick=()=>void runWithPanel(el,{scenarios:Object.fromEntries(SCENARIOS.map(([id])=>[id,V13_SET.has(id)])),token:found?.token,how:found?.how},{service,manager});
  const cmpBtn=el.querySelector('[data-act=compare]');
  if(!found){cmpBtn.style.opacity='.4';cmpBtn.style.pointerEvents='none';}
  cmpBtn.onclick=()=>void runWithPanel(el,{scenarios:Object.fromEntries(SCENARIOS.map(([id])=>[id,id==='compare'])),token:found?.token,how:found?.how},{service,manager});
  runBtn.onclick=()=>{
    const scenarios=Object.fromEntries([...el.querySelectorAll('input[data-sc]')].map(i=>[i.dataset.sc,i.checked]));
    void runWithPanel(el,{scenarios,token:found?.token,how:found?.how},{service,manager});
  };
  return el;
}
/** api.selfCheck.run(options): the same run with the progress note and the
 * result panel (options.quiet: no panel, chat or console, just the result). */
export function runSelfCheckWithPanel(options={},deps={}){
  if(options?.quiet)return runSelfCheck(options,deps);
  return runWithPanel(panelElement(),options,deps);
}
async function runWithPanel(el,options,deps){
  const count=Object.values(options.scenarios??{}).filter(Boolean).length||SCENARIOS.length;let step=0;
  el.classList.add('ff-sc-small');
  el.innerHTML=`<div class="ff-sc-kicker">Yvaelle’s Toolbox · self-check</div><p data-sc-progress>Starting…</p><div class="ff-sc-bar"><i></i></div><p class="ff-sc-muted">Keep this tab in front. <span data-sc-time></span></p><div class="ff-sc-row"><button type="button" data-act="stop">Stop</button></div>`;
  const t0=now(),bar=el.querySelector('.ff-sc-bar i'),line=el.querySelector('[data-sc-progress]'),time=el.querySelector('[data-sc-time]');
  const timer=setInterval(()=>{time.textContent=`${Math.round((now()-t0)/1000)} s`;},500);
  const panel={progress:(text,isStep)=>{line.textContent=text;if(isStep){step++;bar.style.width=`${Math.min(100,step/(count+1)*100)}%`;}},onStop:null};
  el.querySelector('[data-act=stop]').onclick=()=>{line.textContent='Stopping and putting everything back…';panel.onStop?.();};
  let result;
  try{result=await runSelfCheck(options,{...deps,ui:panel});}
  catch(e){result={text:`FF-CHECK v${REPORT_VERSION} · module ${game.modules?.get?.(ID)?.version??VERSION} · failed: ${e?.message??e}`};}
  finally{clearInterval(timer);}
  try{console.log('Yvaelle’s Toolbox self-check · full detail',result);}catch{}
  try{await ChatMessage.create({whisper:[game.user.id],speaker:{alias:'Yvaelle’s Toolbox'},content:`<p><strong>Yvaelle’s Toolbox self-check</strong> · copy the block below and send it back.</p><pre style="white-space:pre-wrap;font-size:10px;line-height:1.3;max-height:none">${esc(result.text)}</pre>`});}catch{}
  showResult(el,result);
  return result;
}
function showResult(el,result){
  el.classList.remove('ff-sc-small');el.classList.add('ff-sc-wide');
  const tally=/SUMMARY (.*)$/m.exec(result.text??'')?.[1]??'';
  el.innerHTML=`<div class="ff-sc-kicker">Yvaelle’s Toolbox · self-check</div><h2>Report ready</h2><p>Copy this and paste it back. <span class="ff-sc-tally">${esc(tally)}</span></p>
    <textarea readonly spellcheck="false" style="min-height:min(520px,60vh)">${esc(result.text)}</textarea>
    <p class="ff-sc-muted">It was also whispered to you in chat. The full detail is in the browser console (F12).</p>
    <div class="ff-sc-row"><span data-sc-copied class="ff-sc-muted" style="margin-right:auto;align-self:center"></span><button type="button" data-act="close">Close</button><button type="button" class="ff-sc-primary" data-act="copy">Copy report</button></div>`;
  const ta=el.querySelector('textarea'),note=el.querySelector('[data-sc-copied]');
  el.querySelector('[data-act=close]').onclick=()=>el.remove();
  el.querySelector('[data-act=copy]').onclick=async()=>{
    let ok=false;try{await navigator.clipboard.writeText(result.text);ok=true;}catch{}
    if(!ok){try{ta.focus();ta.select();ok=document.execCommand('copy');}catch{}}
    if(!ok){ta.focus();ta.select();}
    note.textContent=ok?'Copied.':'Selected: press Ctrl+C (⌘C) to copy.';
  };
}
/** (beta.38) For the developer's harness: the sheet diagnosis on its own. */
export const sheetDiagnosisParts={frameSplit,loafWatch,domCensus,splitStats,sheetBisect,sheetDiagLines,measureLoad,sheetWarmup,warmupLine};
