import {localPerformance} from './performance.mjs?v=13.0.0-beta.9';
import {refreshAfterLight} from './light-refresh.mjs?v=13.0.0-beta.9';
import {ID,runtimeConfiguration} from './config.mjs?v=13.0.0-beta.9';
import {nativeLightData} from './wing-light.mjs?v=13.0.0-beta.9';
import {normalizeParkedLight,parkedLightPower} from './v8-light-model.mjs?v=13.0.0-beta.9';
import {stepLightFade,lightFadeShape} from './light-model.mjs?v=13.0.0-beta.9';

const stations=new Set(['leftUpper','rightUpper','leftLower','rightLower']);
const clock=()=>Number(globalThis.game?.time?.serverTime)||Date.now();
const placed=(token,initializing=false)=>!!((globalThis.canvas?.ready||initializing)&&token&&!token.destroyed&&!token.isPreview&&
  token.document?.parent===globalThis.canvas?.scene&&globalThis.canvas?.scene?.tokens?.get?.(token.id)===token.document);
const round=(value,steps=1000)=>Math.round(value*steps)/steps;
const defined=(...values)=>values.find(value=>value!==undefined);
export const PARKED_LIGHT_GEOMETRY_INTERVAL=1000/30;
const fields=['x','y','elevation','level','bright','dim','radius','angle','rotation','alpha','luminosity','color','coloration','attenuation'];
export const parkedLightDataChanged=(previous,next)=>!previous||fields.some(field=>previous[field]!==next[field]);
const propertiesChanged=(previous,next)=>!previous||fields.slice(2).some(field=>previous[field]!==next[field]);

/** The provider supplies the final displayed world position, never the scan
 * centre, owner token centre or a preview pose. No saved documents are created. */
export function nativeParkedLightData(token,emitter,light=normalizeParkedLight(emitter?.event?.utility?.light),power=1){
  if(!Number.isFinite(emitter?.x)||!Number.isFinite(emitter?.y))throw new Error('The parked light has no valid instrument position.');
  const target=emitter.targetToken??(emitter.event?.target?globalThis.canvas?.tokens?.get?.(emitter.event.target):null),utility=emitter.event?.utility??{},origin={x:emitter.x,y:emitter.y,
    elevation:emitter.elevation??target?.document?.elevation??utility.elevation??token.document.elevation??0};
  const data=nativeLightData(token,{bright:light.bright,dim:light.dim,color:'#ff00ff',alpha:round(.9*light.intensity*power),
    luminosity:round(.75*light.intensity*power),attenuation:.85,animation:{type:null,speed:0,intensity:0}},origin);
  return {...data,level:defined(emitter.level,target?.document?.level,utility.level,token.document.level,null),
    // Both the tool and ordinary lantern use world bearings. Native cones use
    // Foundry's downward zero, whereas instrument directions use rightward zero.
    angle:light.angle,rotation:light.angle>=360?0:((light.rotation-90)%360+360)%360,coloration:10};
}

function eligibleEmitter(token,emitter,snapshot,now){
  const event=emitter?.event,utility=event?.utility;
  if(!stations.has(emitter?.id)||emitter.preview===true||emitter.arrived!==true||emitter.visible===false||
    !Number.isFinite(emitter.x)||!Number.isFinite(emitter.y)||event?.kind!=='utility'||event.status!=='running'||
    utility?.mode!=='parkLight'||event.bits?.length!==1||event.bits[0]!==emitter.id||
    Number.isFinite(event.expires)&&event.expires<=now||utility.sceneId&&utility.sceneId!==globalThis.canvas?.scene?.id)return false;
  // A renderer may retain a departed event for a return seam. Only the latest
  // prepared reservation owns the physical bit when that channel is supplied.
  if(Array.isArray(snapshot.bitReservationEvents)&&!snapshot.bitReservationEvents.some(current=>current.id===event.id&&
    current.kind==='utility'&&current.status==='running'&&current.bits?.includes(emitter.id)))return false;
  if(event.target){
    const target=globalThis.canvas?.tokens?.get?.(event.target)??emitter.targetToken;
    if(!placed(target)||target.document.hidden||target.id!==event.target)return false;
    // A previewed/unseen token cannot be promoted into a real source. A valid
    // companion's light is nevertheless shared native illumination, so the
    // observer's current darkness/wall visibility does not gate it.
    if(emitter.targetToken&&emitter.targetToken!==target)return false;
  }else if(!Number.isFinite(utility.center?.x)||!Number.isFinite(utility.center?.y))return false;
  return true;
}

/** At most four transient native sources, one for each physical instrument.
 * Root calls update/updateFromRuntime on the existing manager ticker; this
 * adapter installs no hooks, sockets or additional animation loop.
 *
 * Provider contract: (token,snapshot,now,config) => [{id:station,event,x,y,
 * arrived:true,strength:1,elevation?,level?,targetToken?}]. Coordinates must
 * come from the action renderer's final placement or the same headless sample.
 * A light warms up as its bit settles and dies out as the bit lifts off
 * (stopped or returning tools fade at their last position); hidden and
 * removed tokens release their sources immediately.
 */
export class ParkedBitLights {
  constructor(manager,{emitters=(_token,snapshot)=>snapshot?.v8ParkedLightEmitters??[],now=clock}={}){
    this.manager=manager;this.emitters=emitters;this.now=now;this.records=new Map();
  }
  request(){refreshAfterLight();}
  report(error){this.manager?.report?.(error);}
  snapshot(token,now,displayFrame=false){
    return this.manager?.frameState?.(token,now,{displayFrame})??this.manager?.sampleState?.(token,now)??{};
  }
  sync(token,options={}){
    if(!localPerformance.active)return this.syncLighting(token,options);
    return localPerformance.measure('lighting',()=>this.syncLighting(token,options));
  }
  syncLighting(token,{initializing=false,notify=true,retry=false,emitters,snapshot,config=runtimeConfiguration(),now=this.now()}={}){
    if(!token)return false;
    let dirty=false;
    // Token object replacement can keep a document UUID. Its old native source
    // must be released before acquiring a source on the replacement object.
    for(const other of [...this.records.keys()])if(other!==token&&other.document?.uuid===token.document?.uuid)
      dirty=this.remove(other,{notify:false})||dirty;
    const record=this.records.get(token);if(retry&&record)record.failed=null;
    snapshot??=this.snapshot(token,now);
    try{dirty=this.update(token,snapshot,emitters??this.emitters(token,snapshot,now,config),{config,now,initializing,notify:false})||dirty;}
    catch(error){dirty=this.fail(this.records.get(token),error)||dirty;}
    if(dirty&&notify)this.request();return dirty;
  }
  update(token,snapshot={},emitters=[],{config=runtimeConfiguration(),now=this.now(),initializing=false,notify=false}={}){
    if(!placed(token,initializing)||token.document.hidden||config.enabled===false||config.effectsEnabled===false||config.controlGems===false||config.wingLight===false)
      return this.remove(token,{notify});
    let record=this.records.get(token);
    if(record?.failed)return false;
    const projectors=[];
    // Bounded work and station ownership protect against duplicate/corrupt
    // providers. Cosmetic-only samples cannot instantiate any native source.
    const seen=new Set();
    for(const emitter of Array.isArray(emitters)?emitters.slice(0,4):[]){
      if(seen.has(emitter?.id)||!eligibleEmitter(token,emitter,snapshot,now))continue;
      seen.add(emitter.id);
      const light=normalizeParkedLight(emitter.event.utility.light),power=parkedLightPower(snapshot,emitter);
      if(!light.enabled||light.intensity<=0||Math.max(light.bright,light.dim)<=0||power<=.0001)continue;
      projectors.push({id:emitter.id,event:emitter.event,emitter,light,power});
    }
    if(!projectors.length&&!record?.emitters?.size)return this.remove(token,{notify});
    if(!record){record={token,emitters:new Map(),failed:null};this.records.set(token,record);}
    let dirty=false;
    try{
      const ids=new Set(projectors.map(projector=>projector.id));
      // A light whose bit has lifted off sinks out at its last position.
      for(const [id,entry]of record.emitters)if(!ids.has(id)){
        const level=entry.fade?stepLightFade(entry.fade,0,now):0;
        if(level<=0||!entry.last){dirty=this.releaseEmitter(entry)||dirty;record.emitters.delete(id);continue;}
        projectors.push({...entry.last,id,fading:true});
      }
      for(const projector of projectors){
        let entry=record.emitters.get(projector.id);
        if(!entry){
          const Source=globalThis.foundry?.canvas?.sources?.PointLightSource;
          if(!Source)throw new Error('Foundry v14 PointLightSource is unavailable.');
          const sourceId=`${ID}.parked.${token.document.uuid}.${projector.id}`,source=new Source({object:token,sourceId});
          if(source.sourceId!==sourceId){source.destroy?.();throw new Error('The parked instrument source did not retain its independent ID.');}
          entry={source,data:null,lastNativeAt:-Infinity,fade:{level:0,at:NaN}};record.emitters.set(projector.id,entry);
        }
        entry.fade??={level:0,at:NaN};
        const level=projector.fading?entry.fade.level:stepLightFade(entry.fade,1,now),shape=lightFadeShape(level),base=projector.light;
        if(!projector.fading)entry.last={event:projector.event,emitter:projector.emitter,light:base,power:projector.power};
        const data=nativeParkedLightData(token,projector.emitter,{...base,bright:base.bright*shape.reach,dim:base.dim*shape.reach},projector.power*shape.weight),detached=!entry.source.attached,
          changed=parkedLightDataChanged(entry.data,data),properties=propertiesChanged(entry.data,data),
          moved=entry.data?Math.hypot(data.x-entry.data.x,data.y-entry.data.y):Infinity,
          // Small settling motions share a 30 Hz native geometry budget. Large
          // movement, elevation, range and intensity changes apply immediately.
          due=detached||properties||moved>=Math.max(8,Math.max(token.w??0,token.h??0)*.08)||
            now<entry.lastNativeAt||now-entry.lastNativeAt>=PARKED_LIGHT_GEOMETRY_INTERVAL-1e-6;
        if(detached||changed&&due){
          entry.source.initialize(data,{reset:detached});if(!entry.source.attached)entry.source.add();
          entry.data={...data,animation:{...data.animation}};entry.lastNativeAt=now;dirty=true;
        }
        entry.eventId=projector.event.id;
      }
    }catch(error){dirty=this.fail(record,error)||dirty;}
    if(!record.failed&&!record.emitters.size)this.records.delete(token);
    if(dirty&&notify)this.request();return dirty;
  }
  /** True while any parked light source exists (lit, warming or dying out),
   * so the action ticker keeps driving the fade to its end. */
  fading(){
    for(const record of this.records.values())if(record.emitters.size)return true;
    return false;
  }
  /** Optional manager-wide hook. All changes request one perception refresh;
   * callers already batching lighting may leave notify:false and use dirty. */
  updateFromRuntime(manager=this.manager,config=runtimeConfiguration(),now=this.now(),options={}){
    if(!localPerformance.active)return this.updateRuntimeLighting(manager,config,now,options);
    return localPerformance.measure('lighting',()=>this.updateRuntimeLighting(manager,config,now,options));
  }
  updateRuntimeLighting(manager=this.manager,config=runtimeConfiguration(),now=this.now(),{notify=false}={}){
    let dirty=false;
    if(!globalThis.canvas?.ready||config.enabled===false||config.effectsEnabled===false||config.controlGems===false||config.wingLight===false)return this.clear({notify});
    const candidates=new Set(this.records.keys()),documents=manager?.bits?.documents;
    // The action runtime already maintains this scene's live jobs on draw,
    // flag updates and rebuild. A scanner must not reread every unrelated
    // scene token on every display frame just to discover there is no lamp.
    // Existing native records stay in the set so ended/replaced jobs release
    // their sources. Standalone adapters retain their scene-wide discovery.
    if(documents instanceof Map){for(const doc of documents.values())if(doc.object)candidates.add(doc.object);}
    else for(const token of globalThis.canvas?.tokens?.placeables??[])candidates.add(token);
    for(const token of candidates){
      if(!placed(token)||token.document?.object!==token){dirty=this.remove(token,{notify:false})||dirty;continue;}
      // Skip tokens without an active v8 light job before doing any state work.
      const raw=token.document.getFlag?.(ID,'bitAnimations');
      if(!this.records.has(token)&&!raw?.events?.some(event=>event.kind==='utility'&&event.status==='running'&&event.utility?.mode==='parkLight'))continue;
      const snapshot=manager?.frameState?.(token,now,{displayFrame:true})??manager?.sampleState?.(token,now)??{};
      try{dirty=this.update(token,snapshot,this.emitters(token,snapshot,now,config),{config,now,notify:false})||dirty;}
      catch(error){dirty=this.fail(this.records.get(token),error)||dirty;}
    }
    if(dirty&&notify)this.request();return dirty;
  }
  releaseEmitter(entry){
    const source=entry?.source;if(!source)return false;entry.source=null;entry.data=null;
    const errors=[];
    for(const operation of [()=>source.remove(),()=>source.destroy()])try{operation();}catch(error){errors.push(error);}
    if(errors.length)throw new AggregateError(errors,'Parked instrument light cleanup failed.');return true;
  }
  releaseRecord(record){
    let dirty=false;const errors=[];
    for(const entry of record?.emitters?.values?.()??[])try{dirty=this.releaseEmitter(entry)||dirty;}catch(error){dirty=true;errors.push(error);}
    record?.emitters?.clear?.();if(errors.length)throw new AggregateError(errors,'Parked instrument sources could not all be released.');return dirty;
  }
  fail(record,error){
    let dirty=false;if(record){record.failed=String(error?.message??error);try{dirty=this.releaseRecord(record);}catch{dirty=true;}}
    this.report(new Error(`Parked instrument light could not render. ${error?.message??error}`));return dirty;
  }
  remove(token,{notify=true}={}){
    const record=this.records.get(token);if(!record)return false;this.records.delete(token);
    let dirty=false;try{dirty=this.releaseRecord(record);}catch(error){this.report(error);dirty=true;}
    if(dirty&&notify)this.request();return dirty;
  }
  clear({notify=true}={}){
    let dirty=false;for(const token of [...this.records.keys()])dirty=this.remove(token,{notify:false})||dirty;
    if(dirty&&notify)this.request();return dirty;
  }
  status(token){
    const record=this.records.get(token);return {localActive:!!record&&[...record.emitters.values()].some(entry=>entry.source?.active),
      emitters:record?.emitters.size??0,error:record?.failed??null};
  }
}
