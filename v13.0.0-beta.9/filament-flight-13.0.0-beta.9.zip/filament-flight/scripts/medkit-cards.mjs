/** Keepsake-style chat cards for Ellie's Medkit (v10 beta.18). Optional: the
 * Medkit posts the regular PF2e cards unless the user turns these on in the
 * Medkit window. Only markup with classes is produced (styles/medkit-cards.css),
 * so it survives Foundry's chat sanitising and never shows HP numbers: each
 * patient gets a health estimate after the treatment instead. */
import {healthEstimate} from './health-estimate.mjs?v=13.0.0-beta.9';

const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const OUTCOME={criticalSuccess:['Critical success','crit'],success:['Success','good'],failure:['Failure','bad'],criticalFailure:['Critical failure','worse']};

/** The estimate a patient will read after `delta` HP (positive heals), from
 * `base` (their HP when the treatment began) or their HP now. */
export function estimateAfter(actor,delta=0,base=null){
  const hp=base??actor?.system?.attributes?.hp;if(!hp)return healthEstimate(actor);
  const max=Number(hp.max)||0,value=Math.max(0,Math.min(max,(Number(hp.value)||0)+delta));
  return healthEstimate({type:actor.type,system:{attributes:{hp:{...hp,value}}}});
}
const estimateClass=e=>e?.unknown?'ff-mk-est-unknown':`ff-mk-est-${Math.max(0,Math.min(5,Math.round((e?.ratio??1)*5)))}`;

/**
 * keepsakeCard({kicker, title, icon, check:{total, dc, outcome}|null,
 *   patients:[{name, img, outcome, amount, harm, text, estimate}], lines:[html], footer:[text]})
 */
export function keepsakeCard({kicker='',title='',icon='',tone='magenta',check=null,patients=[],lines=[],footer=[]}){
  const out=check?.outcome?OUTCOME[check.outcome]:null;
  const head=`<header class="ff-mk-head">${icon?`<img class="ff-mk-icon" src="${esc(icon)}" alt="">`:''}<div class="ff-mk-titles">${kicker?`<span class="ff-mk-kicker">${esc(kicker)}</span>`:''}<h3 class="ff-mk-title">${esc(title)}</h3></div></header>`;
  const checkRow=check?`<div class="ff-mk-check"><span>Medicine <b>${esc(check.total)}</b> vs DC ${esc(check.dc)}</span>${out?`<span class="ff-mk-out ff-mk-out-${out[1]}">${out[0]}</span>`:''}</div>`:'';
  const rows=patients.length?`<ul class="ff-mk-rows">${patients.map(p=>{
    const o=p.outcome?OUTCOME[p.outcome]:null;
    const amount=p.amount?`<span class="ff-mk-amt ff-mk-heal">+${esc(p.amount)}</span>`:p.harm?`<span class="ff-mk-amt ff-mk-hurt">−${esc(p.harm)}</span>`:'';
    return `<li class="ff-mk-row">${p.img?`<img class="ff-mk-face" src="${esc(p.img)}" alt="">`:'<span class="ff-mk-face"></span>'}<span class="ff-mk-who"><span class="ff-mk-name">${esc(p.name)}</span>`+
      `<span class="ff-mk-sub">${p.estimate?`<span class="ff-mk-est ${estimateClass(p.estimate)}">${esc(p.estimate.label)}</span>`:''}${o&&!check?`<span class="ff-mk-out ff-mk-out-${o[1]}">${o[0]}</span>`:''}${p.text?`<span class="ff-mk-note">${esc(p.text)}</span>`:''}</span></span>${amount}</li>`;
  }).join('')}</ul>`:'';
  const body=lines.length?`<div class="ff-mk-lines">${lines.map(l=>`<p>${l}</p>`).join('')}</div>`:'';
  const foot=footer.filter(Boolean).length?`<footer class="ff-mk-foot">${footer.filter(Boolean).map(f=>`<span>${esc(f)}</span>`).join('<i class="ff-mk-dot"></i>')}</footer>`:'';
  return `<div class="ff-mk-card ff-mk-tone-${esc(tone)} ellie-medkit-card">${head}${checkRow}${rows}${body}${foot}</div>`;
}
/** A plain copy of an actor's HP, taken before anything is applied. */
export function hpSnapshot(actor){
  const hp=actor?.system?.attributes?.hp;if(!hp)return null;
  return {value:Number(hp.value)||0,max:Number(hp.max)||0,temp:Number(hp.temp)||0,sp:hp.sp?{value:Number(hp.sp.value)||0,max:Number(hp.sp.max)||0}:undefined};
}
