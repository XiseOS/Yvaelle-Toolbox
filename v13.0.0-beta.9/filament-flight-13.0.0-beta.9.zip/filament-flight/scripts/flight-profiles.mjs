/** Cosmetic flight behaviours. Numeric profiles blend on the shared clock;
 * never touch rule speed, coordinates, pathing or elevation. */
import {unit} from './poses.mjs?v=13.0.0-beta.9';
import {sampleWingHandoff} from './wing-handoffs.mjs?v=13.0.0-beta.9';
const BASE=Object.freeze({sweep:1,bank:1,pitch:1,beat:1,bob:1,sway:1,lift:1,trail:1,length:1,life:1,narrow:0,stretch:0,guard:0,flare:0,phase:0,field:1,bitOrbit:1});
const profile=patch=>Object.freeze({...BASE,...patch});
export const FLIGHT_PROFILES=Object.freeze({
  grounded:{label:'Grounded',description:'Wings visible with the token at ground level.',values:profile({})},
  hover:{label:'Hover',description:'Flies low on small, mid-open wings with a quick soft flutter. Stays close to her token, eases into each stop without passing it and settles with a soft dip.',values:profile({sweep:.7})},
  fly:{label:'Fly',description:'A balanced figure-eight at rest on broad wings with steady full strokes. A little momentum in motion: she slides a short way past the stop, her wings flare forward to brake and she settles back.',values:profile({})},
  fast:{label:'Fast Flight',description:'Rides a little higher on narrow, poised wings. Quick off the mark with a hard lean, wings swept back into a lance and beating fast; wingtip trails and a short streak of afterimages at speed. Slides well past the stop, swings back and flares to brake.',values:profile({narrow:1,stretch:.7,flare:.25})},
  glide:{label:'Glide',description:'Rides high. Her wings are held flat and fully spread between rare single beats, with a slow sway at rest. Slow to build, she trails her token, then coasts a long way past the stop on held wings with long wingtip wakes, the wings rising as she comes in.',values:profile({sweep:.3,bank:.65,pitch:.75,beat:.7,bob:.45,sway:.5,trail:.55,length:1.2,life:1.15,field:.85,bitOrbit:.55})},
  surge:{label:'Surge',description:'Wings held taut and coiled; at rest she gathers, lifts and releases in one hard stroke. A power stroke at takeoff and on every burst. Bursts ahead of her token with a flick of filament behind her, wings taut and swept. A springy stop: she rebounds through a braking flare of hardlight, swings back and settles.',values:profile({sweep:1.8,bank:1.35,pitch:1.25,beat:1.35,bob:.25,sway:.25,trail:1.5,length:1.4,life:.8,narrow:.75,stretch:.6,flare:.9,field:1.3,bitOrbit:1.25})},
  sentinel:{label:'Sentinel',description:'Wings half-raised like a guard with very slow strokes, low, her bits posted a little wider at rest; she brakes harder than she sets off, stops short of the mark and eases onto it, wings flared to brake.',values:profile({sweep:.38,bank:.25,pitch:.3,beat:.65,bob:.6,sway:.35,trail:.45,length:.55,life:.8,guard:.72,field:1.5,bitOrbit:.6})},
  wraith:{label:'Wraith',description:'Thin, translucent wings with a slow drifting beat and a faint phasing shimmer. Skims low on a sinuous path and drifts behind her token with her wings faintly phasing, eases into the stop without passing it, and an echo of her carries on past the stop and fades.',values:profile({sweep:1.1,bank:.8,pitch:.65,beat:.6,bob:.75,sway:1.2,trail:.7,length:1.3,life:1.2,narrow:.45,phase:.85,field:.85,bitOrbit:1.2})}
});
export const STEADY_MODES=Object.freeze(Object.keys(FLIGHT_PROFILES));
export const AIRBORNE_MODES=Object.freeze(STEADY_MODES.filter(k=>k!=='grounded'));
export const PROFILE_FIELDS=Object.freeze(Object.keys(BASE));
const ZERO_VELOCITY=Object.freeze({...Object.fromEntries(PROFILE_FIELDS.map(k=>[k,0])),modeWeights:Object.freeze(Object.fromEntries(STEADY_MODES.map(k=>[k,0])))});
// Settled profiles depend only on the mode (and three Fast settings): build each once, frozen.
const targets=new Map();
export function targetFlightProfile(mode,cfg={}){
  const fast=mode==='fast',key=fast?`fast|${cfg.fastSweepMultiplier}|${cfg.fastWingSpeed}|${cfg.fastTrailMultiplier}`:mode;
  let target=targets.get(key);if(target)return target;
  const values={...(FLIGHT_PROFILES[mode]??FLIGHT_PROFILES.hover).values};
  if(fast){values.sweep=cfg.fastSweepMultiplier??1.65;values.beat=cfg.fastWingSpeed??1.5;values.trail=cfg.fastTrailMultiplier??1.8;values.length=1/.65;values.life=1/.75;}
  target=Object.freeze({...values,mode,modeWeights:Object.freeze(Object.fromEntries(STEADY_MODES.map(k=>[k,k===mode?1:0]))),progress:1,active:false,velocity:ZERO_VELOCITY});
  if(targets.size>64)targets.clear();targets.set(key,target);return target;
}
export function readModeTransition(raw){
  if(raw==null)return null;
  if(typeof raw!=='object'||typeof raw.id!=='string'||!/^[\w-]{1,64}$/.test(raw.id)||!Number.isFinite(raw.started)||!Number.isFinite(raw.duration)||raw.duration<0||raw.duration>3000||!raw.from||
    PROFILE_FIELDS.some(k=>!Number.isFinite(raw.from[k])||raw.from[k]<0||raw.from[k]>4)||!raw.from.modeWeights||
    Object.keys(raw.from.modeWeights).length!==STEADY_MODES.length||STEADY_MODES.some(k=>!Number.isFinite(raw.from.modeWeights[k])||raw.from.modeWeights[k]<0||raw.from.modeWeights[k]>1)||
    Math.abs(Object.values(raw.from.modeWeights).reduce((n,x)=>n+x,0)-1)>.00001)throw new Error('Invalid flight mode transition.');
  const result={id:raw.id,started:raw.started,duration:raw.duration,from:{...Object.fromEntries(PROFILE_FIELDS.map(k=>[k,raw.from[k]])),modeWeights:{...raw.from.modeWeights}}};
  if(raw.velocity!=null){
    if(!raw.velocity||PROFILE_FIELDS.some(k=>!Number.isFinite(raw.velocity[k])||Math.abs(raw.velocity[k])>1)||!raw.velocity.modeWeights||Object.keys(raw.velocity.modeWeights).length!==STEADY_MODES.length||STEADY_MODES.some(k=>!Number.isFinite(raw.velocity.modeWeights[k])||Math.abs(raw.velocity.modeWeights[k])>1)||Math.abs(Object.values(raw.velocity.modeWeights).reduce((n,x)=>n+x,0))>.00001)throw new Error('Invalid flight mode velocity.');
    result.velocity={...Object.fromEntries(PROFILE_FIELDS.map(k=>[k,raw.velocity[k]])),modeWeights:Object.fromEntries(STEADY_MODES.map(k=>[k,raw.velocity.modeWeights[k]]))};
  }
  return result;
}
export function sampleFlightProfile(data,cfg,now,resume=true){
  const target=targetFlightProfile(data.mode,cfg),t=data.modeTransition;
  if(!t||!resume||cfg.reduced||!cfg.transitions||!t.duration)return target;
  const p=unit((now-t.started)/t.duration);
  if(p>=1)return target;
  const scalars=sampleWingHandoff(PROFILE_FIELDS.map(k=>t.from[k]),PROFILE_FIELDS.map(k=>target[k]),PROFILE_FIELDS.map(k=>t.velocity?.[k]??0),p,t.duration,{max:4});
  const modes=sampleWingHandoff(STEADY_MODES.map(k=>t.from.modeWeights[k]),STEADY_MODES.map(k=>target.modeWeights[k]),STEADY_MODES.map(k=>t.velocity?.modeWeights[k]??0),p,t.duration);
  return {...Object.fromEntries(PROFILE_FIELDS.map((k,i)=>[k,scalars.values[i]])),
    mode:data.mode,modeWeights:Object.fromEntries(STEADY_MODES.map((k,i)=>[k,modes.values[i]])),progress:p,active:true,
    velocity:{...Object.fromEntries(PROFILE_FIELDS.map((k,i)=>[k,scalars.velocity[i]])),modeWeights:Object.fromEntries(STEADY_MODES.map((k,i)=>[k,modes.velocity[i]]))}};
}
export function modeTransitionFrom(profile,now,duration,id){
  return {id,started:now,duration,from:{...Object.fromEntries(PROFILE_FIELDS.map(k=>[k,profile[k]])),modeWeights:{...profile.modeWeights}},velocity:{...(profile.velocity??ZERO_VELOCITY),modeWeights:{...(profile.velocity?.modeWeights??ZERO_VELOCITY.modeWeights)}}};
}
