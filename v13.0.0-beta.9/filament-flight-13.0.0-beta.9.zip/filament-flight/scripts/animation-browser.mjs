import {WING_GESTURES} from './v7-wing-motion.mjs?v=13.0.0-beta.9';
import {sampleV7Appearance} from './v7-ensemble.mjs?v=13.0.0-beta.9';
import {SETTINGS} from './config.mjs?v=13.0.0-beta.9';
import {createHUDMotion,hudMotionOptions} from './hud-motion.mjs?v=13.0.0-beta.9';
import {FLIGHT_PROFILES} from './flight-profiles.mjs?v=13.0.0-beta.9';
import {FLOAT_STYLES,POSE_LABELS,POSE_HINTS,hudBitGroups} from './hud-model.mjs?v=13.0.0-beta.9';
import {COMPACT_BIT_PROGRAMS,enabledCompactProgramIds,isLegacyFormation} from './compact-bit-formations.mjs?v=13.0.0-beta.9';
import {BIT_GESTURES} from './bit-behaviour.mjs?v=13.0.0-beta.9';
import {createWingPreview} from './animation-preview.mjs?v=13.0.0-beta.9';
import {readActorConditions} from './condition-response.mjs?v=13.0.0-beta.9';
import {readHealth} from './conditions.mjs?v=13.0.0-beta.9';
import {previewQualityConfiguration} from './quality.mjs?v=13.0.0-beta.9';
import {medicalPreviewPatient,paintMedicalPreviewPatient,releaseMedicalPreviewPatient} from './medical-preview-patient.mjs?v=13.0.0-beta.9';
import {scanTokenVisible} from './v82-scene-scan-context.mjs?v=13.0.0-beta.9';
import {compactDepthFront,compactSolidBounds} from './compact-depth.mjs?v=13.0.0-beta.9';
import {paintBitPreview,releaseBitPreview,samplePreviewBits} from './compact-animation-preview.mjs?v=13.0.0-beta.9';
import {paintResonantBit} from './bit-resonance.mjs?v=13.0.0-beta.9';
import {TOKEN_EFFECT_PROGRAMS,orderedTokenEffects,TOKEN_EFFECT_CATEGORIES,paintTokenEffectPreview,sampleTokenEffect,paintTokenEffect} from './token-effects.mjs?v=13.0.0-beta.9';
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const groupCount=(group,fallback=4)=>Math.max(1,Math.min(4,group?.presentCount>0?group.presentCount:group?.count>0?group.count:group?.bits?.length||fallback||4));
const pendingGroup=group=>group?.presentCount===0&&(group?.borrowedBits?.length??0)>0;
const countCopy=(count,group)=>`${group?.label?`${group.label} · `:''}${count} ${count===1?'instrument':'instruments'} · ${pendingGroup(group)?'Assigned bits are away; preview their return formation':'Select a choice, then Activate'}`;
const CORE_HELP={scanning:'The crystal pivots inside open rails while a fine scanning band reads the work area.',bracing:'The housing gathers around the crystal and holds a reinforced protective field.',aligning:'The inner gimbals make measured corrections and realign around a steady core.',resting:'The shell settles into a low, quiet posture with a restrained resting glow.',conducting:'Open vanes coordinate deliberate energy transfers around the crystal.',idle:'Keep the current Resonant Core animation exactly as it is.',auto:'Open, charge, guard and settle in response to assigned work.',encased:'Three shell rails close around the crystal while its core remains quietly lit.',open:'The shell segments separate along the core, creating room for precise energy work.',charging:'Currents gather around the crystal and travel through its articulated housing.',guarding:'The gimbals align and the outer vanes brace around a steady, watchful core.',settling:'The working glow releases and the open housing gently returns toward rest.'};
const TITLES={wing:'Wing animations',mode:'Flight character',float:'Floating motion',pose:'Wing poses',bits:'Bit formations',gesture:'Instrument directions',core:'Inside the Resonant Core',tokenFX:'Token effects',look:'Your complete look'};
const libraryTitle=kind=>TITLES[kind];
const choiceMarkup=entries=>[...new Set(entries.map(x=>x.category))].map(category=>`<details class="ff-picker-category" open><summary>${escape(category)}</summary><div class="ff-picker-category-options">${entries.filter(e=>e.category===category).map(e=>`<button type="button" class="ff-button ff-picker-choice" data-choice="${escape(e.id)}" aria-pressed="false"><span class="ff-choice-heading"><strong>${escape(e.label)}</strong><span class="ff-choice-badges"><small data-selected hidden>Selected</small><small data-saved hidden>Current</small></span></span><span class="ff-choice-description">${escape(e.description)}</span></button>`).join('')}</div></details>`).join('')+'<p class="ff-note" data-empty hidden>No matching animations.</p>';
const formationOptions=model=>({library:(()=>{try{return game.settings.get('filament-flight','formationLibrary');}catch{return 'all';}})(),v7Enabled:model.state?.v7?.enabled===true&&model.state?.v7?.formations===true,v9SignatureCraft:model.cfg?.v9SignatureCraft===true&&model.state?.v7?.enabled===true&&model.state?.v7?.wingAnimations===true});
export function animationChoices(kind,count=4,structure='wings',options={}){
  const convert=o=>Object.entries(o).map(([id,p])=>({id,label:p.label,description:p.description??p.hint??'',category:'Animations'}));
  switch(kind){
    case 'wing':return Object.entries(WING_GESTURES).filter(([,p])=>p.v9!==true||options.v9SignatureCraft===true).map(([id,p])=>({id,label:p.label,description:p.detail??p.description??'',category:'Wing gestures'}));
    case 'look':return [{id:'current',label:'Your complete look',description:'Your original wings, floating motion, core design and energy settings, shown together. This preview opens the wings locally; it changes nothing in the scene.',category:'Current configuration'}];
    case 'mode':return convert(FLIGHT_PROFILES);
    case 'float':return convert(FLOAT_STYLES);
    case 'pose':return Object.entries(POSE_LABELS).map(([id,label])=>({id,label,description:POSE_HINTS[id],category:'Wing poses'}));
    case 'bits':return enabledCompactProgramIds(options).map(id=>({id,label:COMPACT_BIT_PROGRAMS[id].counts[count].name,description:COMPACT_BIT_PROGRAMS[id].counts[count].description,category:isLegacyFormation(id)?`Legacy · ${COMPACT_BIT_PROGRAMS[id].name}`:COMPACT_BIT_PROGRAMS[id].name,legacy:isLegacyFormation(id)}));
    case 'gesture':return Object.entries(BIT_GESTURES).map(([id,p])=>({id,label:p.label,description:p.description,category:'Work gestures'}));
    case 'core':return Object.entries(SETTINGS.gemCoreState.choices).map(([id,label])=>({id,label,description:CORE_HELP[id]??label,category:'Internal states'}));
    case 'tokenFX':return orderedTokenEffects().map(p=>({...p,category:p.legacy?'Legacy':TOKEN_EFFECT_CATEGORIES[p.category]}));
    default:throw new Error(`Unknown animation library: ${kind}`);
  }
}
export function animationCommand(kind,id,group='home',structure='wings'){
  if(!Object.hasOwn(TITLES,kind))throw new Error(`Unknown animation library: ${kind}`);
  if(kind==='wing')return {action:'wingGesture',value:id};
  if(kind==='look')throw new Error('A complete-look preview is read-only.');
  if(kind==='gesture')return {action:'bitGesture',value:{group,name:id}};
  if(kind==='bits'||kind==='core')return {action:'bitGroup',value:{group,patch:{[kind==='bits'?'program':'internalState']:id}}};
  if(kind==='tokenFX')return {action:'bitEffect',value:{group,patch:{id,enabled:true}}};
  return {action:kind==='float'?'floatStyle':kind,value:id};
}
/** Local native artwork only. Browsing never writes to the scene. */
export class GeneralAnimationPicker {
  constructor(controller,kind,model,{group='home',selectedId=null}={}){
    this.controller=controller;this.kind=kind;this.group=kind==='look'?'home':group??'home';this.model=model;this.targetId=model.token.document.uuid;this.paused=false;this.playhead=0;this.initializing=true;
    const host=controller.app.element,doc=host.ownerDocument;this.window=doc.defaultView;this.returnFocus=doc.activeElement;this.events=new this.window.AbortController();const {signal}=this.events;this.motion=createHUDMotion(hudMotionOptions(model));
    const g=this.groupModel(model);this.count=groupCount(g,model.bitTasks?.preferredCount??model.state?.gems?.count);this.structure='wings';this.bitsV7Enabled=formationOptions(model).v7Enabled;this.entries=animationChoices(kind,this.count,this.structure,formationOptions(model));
    this.active=this.entries.some(entry=>entry.id===selectedId)?selectedId:null;
    this.dialog=doc.createElement('dialog');this.dialog.className='ff-effect-picker ff-animation-browser';this.dialog.setAttribute('aria-label',libraryTitle(kind,this.structure));
    this.dialog.innerHTML=`<header class="ff-picker-heading"><div><span class="ff-eyebrow">ELLIE’S ANIMATION LIBRARY</span><h2>${escape(libraryTitle(kind,this.structure))}</h2><p>${['bits','core','tokenFX','gesture'].includes(kind)?escape(countCopy(this.count,g)):'Click or double-click to select and preview · nothing changes until Activate'}</p></div><button type="button" class="ff-button ff-picker-close" data-close aria-label="Close animation library">×</button></header><div class="ff-picker-body"><div class="ff-picker-library"><label class="ff-picker-search"><span class="ff-sr-only">Search animations</span><input type="search" data-search placeholder="Search animations…" autocomplete="off"></label><div class="ff-picker-filterbar">${['bits','tokenFX'].includes(kind)?'<button type="button" class="ff-button" data-favorites-only aria-pressed="false">☆ Favourites</button>':''}<span>Click or double-click to select · Activate to use it</span></div><div class="ff-picker-choices">${choiceMarkup(this.entries)}</div></div><section class="ff-picker-stage"><div class="ff-preview-topline"><span>ONLY YOU SEE THIS PREVIEW</span><span class="ff-preview-dot" aria-hidden="true"></span></div><canvas width="512" height="512" role="img" aria-label="Native animation preview"></canvas><div class="ff-preview-copy"><h3 data-name></h3><p data-description></p>${['bits','tokenFX'].includes(kind)?'<button type="button" class="ff-button ff-pin-animation" data-pin-animation aria-pressed="false">☆ Add to favourites</button>':''}</div><div class="ff-preview-buttons"><button type="button" class="ff-button" data-play>Pause preview</button><button type="button" class="ff-button" data-replay>Replay</button></div><p class="ff-note" data-guidance>${kind==='tokenFX'?'Visual effects only; they do not apply game rules.':kind==='float'?'The floating path is shown independently from flight-mode character.':'Uses the module’s actual animation and artwork.'}</p></section></div><footer class="ff-picker-footer"><span data-status role="status" aria-live="polite">Select an animation, then Activate.</span><button type="button" class="ff-button" data-close>Cancel</button><button type="button" class="ff-button is-primary" data-apply disabled>Activate</button></footer>`;
    if(kind==='gesture')this.dialog.querySelector('[data-apply]').textContent='Perform gesture';
    if(kind==='look'){
      this.dialog.classList.add('ff-current-look-preview');
      this.dialog.querySelector('.ff-picker-heading p').textContent='Private combined preview · no scene changes';
      this.dialog.querySelector('[data-apply]').hidden=true;
      this.dialog.querySelector('.ff-picker-footer [data-close]').textContent='Close';
      this.dialog.querySelector('[data-status]').textContent='Preview only · your scene remains unchanged';
      this.dialog.querySelector('[data-guidance]').textContent='Live health and conditions · wings open only inside this preview; remote groups keep their assignments.';
    }
    this.canvas=this.dialog.querySelector('canvas');
    this.canvas.setAttribute('data-ff-preview-canvas','');
    for(const b of this.dialog.querySelectorAll('[data-close]'))b.addEventListener('click',()=>this.close(),{signal});
    this.bindSelectionEvents(signal);
    this.dialog.addEventListener('cancel',e=>{e.preventDefault();this.close();},{signal});
    this.dialog.addEventListener('close',()=>this.close(),{signal});
    this.dialog.addEventListener('click',e=>e.stopPropagation(),{signal});
    this.dialog.querySelector('[data-search]').addEventListener('input',e=>this.filter(e.target.value),{signal});
    this.dialog.querySelector('[data-play]').addEventListener('click',()=>{this.paused=!this.paused;this.paused?this.halt():this.play();this.controls();},{signal});
    this.dialog.querySelector('[data-replay]').addEventListener('click',()=>this.activate(this.active,true),{signal});
    this.dialog.querySelector('[data-pin-animation]')?.addEventListener('click',()=>void this.pin(),{signal});
    this.dialog.querySelector('[data-favorites-only]')?.addEventListener('click',()=>{this.favoritesOnly=!this.favoritesOnly;this.favoriteControls();this.filter(this.dialog.querySelector('[data-search]').value);},{signal});
    doc.addEventListener('visibilitychange',()=>doc.hidden?this.halt():this.play(),{signal});
    host.append(this.dialog);
    this.motion.bindDisclosures(this.dialog,{signal});
    try{this.update(model);this.dialog.showModal();this.dialog.querySelector(kind==='look'?'[data-play]':`[data-choice="${this.active}"]`)?.focus({preventScroll:true});this.initializing=false;this.motion.enter(this.dialog,{kind:'library'});this.play();}catch(e){this.close();throw e;}
  }
  bindSelectionEvents(signal){
    this.dialog.addEventListener('click',event=>{
      const choice=event.target.closest?.('[data-choice]');
      if(choice&&this.dialog.contains(choice)&&!choice.disabled&&!this.initializing)this.activate(choice.dataset.choice);
    },{signal});
    this.dialog.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();event.stopPropagation();this.close();return;}
      const choices=[...this.dialog.querySelectorAll('[data-choice]')].filter(button=>!button.disabled&&!button.hidden&&button.offsetParent!==null),index=choices.indexOf(event.target);
      if(index<0)return;
      if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();if(!this.initializing)this.activate(event.target.dataset.choice);return;}
      if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;
      event.preventDefault();event.stopPropagation();
      choices[event.key==='Home'?0:event.key==='End'?choices.length-1:(index+(event.key==='ArrowDown'?1:-1)+choices.length)%choices.length]?.focus();
    },{signal});
    this.dialog.addEventListener('dblclick',event=>{const choice=event.target.closest?.('[data-choice]');if(!choice||!this.dialog.contains(choice))return;event.preventDefault();event.stopPropagation();if(!choice.disabled&&!this.initializing)this.activate(choice.dataset.choice);},{signal});
    this.dialog.querySelector('[data-apply]').addEventListener('click',()=>void this.apply(),{signal});
  }
  groupModel(model){return hudBitGroups(model).find(g=>g.id===this.group);}
  previewSubject(model=this.model){
    const target=this.groupModel(model)?.target;
    if(!target)return model.token;
    const token=globalThis.canvas?.tokens?.get?.(target)??globalThis.canvas?.tokens?.placeables?.find(t=>t.document?.uuid===target||t.id===target);
    return scanTokenVisible(token,{scene:model.token.document.parent,source:model.token})?token:null;
  }
  saved(model){if(this.kind==='wing')return model.state?.v7?.wingMotion?.name??'lunarBow';if(this.kind==='gesture')return 'inspect';const g=this.groupModel(model),r=model.state?.requested??{},a=model.baseAppearance??{};return {mode:r.mode,float:a.floatStyle,pose:r.pose??'neutral',bits:g?.program??r.gemMotion?.soloProgram??'halo',core:g?.internalState??r.gemMotion?.coreState??model.cfg.gemCoreState??'idle',tokenFX:g?.effect?.id??'shield'}[this.kind];}
  valid(model=this.controller.model()){return !!(this.controller.opened&&model&&!model.error&&model.cfg.hudEnabled&&model.token?.document.uuid===this.targetId&&model.token.document.isOwner&&(this.group==='home'||this.groupModel(model)));}
  update(model){
    if(this.closed)return;if(!this.valid(model)||this.controller.app?.minimized){this.close();return;}
    const motionOptions=hudMotionOptions(model);this.motion.configure(motionOptions);this.dialog.dataset.ffMenuMotion=String(motionOptions.enabled&&motionOptions.strength>0);
    const subject=this.kind==='tokenFX'?this.previewSubject(model):null;
    const designSignature=JSON.stringify([model.cfg,model.baseAppearance,model.state?.requested,model.state?.v7?.enabled,model.state?.v7?.formations,this.groupModel(model),model.bitTasks?.preferredCount,this.kind==='tokenFX'?(subject?.document?.uuid??subject?.id??null):null]);
    const actorConditions=this.kind==='look'?readActorConditions(model.token.document.actor):null,health=this.kind==='look'?readHealth(model.token.document.actor):null;
    const response=this.kind==='look'?model.token.document.getFlag?.('filament-flight','flight')?.conditionResponse??null:null;
    const signature=JSON.stringify([designSignature,actorConditions,health,response]);this.model=model;this.previewConfig=previewQualityConfiguration(model.cfg);this.favoriteControls();
    if(this.signature===signature)return;
    const contextOnly=this.kind==='look'&&this.designSignature===designSignature&&this.conditionContext;
    this.signature=signature;this.designSignature=designSignature;
    if(this.kind==='look'){
      const conditionResponse=structuredClone(response);
      if(!contextOnly)this.contextEpoch=globalThis.game?.time?.serverTime??Date.now();
      if(conditionResponse){conditionResponse.started-=this.contextEpoch;if(conditionResponse.collapse)conditionResponse.collapse.started-=this.contextEpoch;}
      if(contextOnly){Object.assign(this.conditionContext,{actorConditions,health,conditionResponse});this.draw();return;}
      this.conditionContext={actorConditions,health,conditionResponse};
    }
    const group=this.groupModel(model),count=groupCount(group,model.bitTasks?.preferredCount??model.state?.gems?.count);
    const structure='wings';
    const bitsV7Enabled=formationOptions(model).v7Enabled;
    const v9WingEnabled=formationOptions(model).v9SignatureCraft;
    if(count!==this.count||this.kind==='bits'&&bitsV7Enabled!==this.bitsV7Enabled||this.kind==='wing'&&v9WingEnabled!==this.v9WingEnabled){
      this.v9WingEnabled=v9WingEnabled;
      this.count=count;this.bitsV7Enabled=bitsV7Enabled;const before=this.entries.map(entry=>entry.id).join('|');this.entries=animationChoices(this.kind,count,structure,formationOptions(model));
      if(this.entries.map(entry=>entry.id).join('|')!==before){
        if(!this.entries.some(entry=>entry.id===this.active))this.active=null;
        for(const detail of this.dialog.querySelectorAll('details'))this.motion.stop(detail);
        this.dialog.querySelector('.ff-picker-choices').innerHTML=choiceMarkup(this.entries);
        this.filter(this.dialog.querySelector('[data-search]').value);this.favoriteControls();
      }else for(const b of this.dialog.querySelectorAll('[data-choice]')){const entry=this.entries.find(e=>e.id===b.dataset.choice);if(!entry)continue;b.querySelector('strong').textContent=entry.label;b.querySelector('.ff-choice-description').textContent=entry.description;}
    }
    if(['bits','core','tokenFX','gesture'].includes(this.kind))this.dialog.querySelector('.ff-picker-heading p').textContent=countCopy(count,group);
    const saved=this.saved(model);for(const b of this.dialog.querySelectorAll('[data-choice]'))b.querySelector('[data-saved]').hidden=b.dataset.choice!==saved;
    this.renderer?.destroy();this.renderer=null;
    const texture=model.token?.mesh?.texture?.baseTexture?.resource?.source;this.tokenImage=texture&&((texture.naturalWidth??texture.width)>0)?texture:null;
    this.activate(this.active??(this.entries.some(e=>e.id===saved)?saved:this.entries[0].id),true);
  }
  activate(id,force=false){
    if(this.closed||this.saving||(!force&&this.active===id))return;const entry=this.entries.find(e=>e.id===id);if(!entry)return;
    this.halt();this.playhead=0;this.active=id;this.previewFailed=false;this.depths=new Map();
    for(const b of this.dialog.querySelectorAll('[data-choice]')){const selected=b.dataset.choice===id;b.classList.toggle('is-previewing',selected);b.classList.toggle('is-selected',selected);b.setAttribute('aria-pressed',String(selected));b.querySelector('[data-selected]').hidden=!selected;}
    this.dialog.querySelector('[data-name]').textContent=entry.label;this.dialog.querySelector('[data-description]').textContent=entry.description;
    if(this.kind!=='look')this.dialog.querySelector('[data-status]').textContent=`Selected: ${entry.label}`;
    if(!this.initializing)this.motion.enter(this.dialog.querySelector('.ff-preview-copy'),{kind:'library'});
    if(!['bits','core','tokenFX','gesture'].includes(this.kind)){
      this.renderer??=createWingPreview(this.canvas,{configOverrides:this.model.cfg,appearance:this.model.baseAppearance,request:this.model.state?.requested,prefs:this.model.prefs,sourceToken:this.model.token,tokenImage:this.tokenImage,background:this.model.prefs.theme?.background,tokenLabel:'E',...(this.kind==='look'?{conditionContext:this.conditionContext,paintOverlay:(ctx,frame)=>this.paintLookField(ctx,frame)}:{})});
      this.renderer.setSelection({kind:this.kind,id,...(this.kind==='float'?{request:{mode:'hover'}}:{}),...(this.kind==='look'?{request:{gemMotion:{...this.model.state?.requested?.gemMotion,count:this.count}}}:{})});
    }
    this.controls();this.favoriteControls();this.drawAfterPaint();this.play();
  }
  /** Paint the preview just after the next frame is on screen, so a click's highlight shows first (beta.32). */
  drawAfterPaint(){
    if(this.paintSoon||this.closed)return;const w=this.window;
    this.paintSoon=w.requestAnimationFrame(()=>w.setTimeout(()=>{this.paintSoon=null;if(!this.closed)this.draw();},0));
  }
  draw(){
    if(this.closed||this.previewFailed)return;
    try{
      const group=this.groupModel(this.model),g=this.model.state?.gems??{},theme=this.model.prefs.theme??{},elapsed=this.model.cfg.reduced?0:this.elapsed();
      const preferences={...this.model.state?.requested?.v7,wingGesture:null};
      const cfg=this.previewConfig??previewQualityConfiguration(this.model.cfg);
      const options={...g,quality:cfg.bitQuality,effectDetail:cfg.effectDetail,v7:sampleV7Appearance(preferences,cfg,elapsed),v9:this.model.state?.v9,behaviour:group?.behaviour,previewWork:this.kind==='bits',gesture:this.kind==='gesture'?this.active:null,radius:group?.radius??g.soloRadius,personality:group?.personality??g.personality,passiveEffects:group?.passive??g.passiveEffects,id:this.kind==='bits'?this.active:group?.program??g.soloProgram??'halo',count:this.count,elapsed,background:theme.background??'#171219',accent:this.model.baseAppearance?.filamentColor??theme.accent??'#e767ce',textColor:theme.text,tokenImage:this.tokenImage,coreState:this.kind==='core'?this.active:group?.internalState??g.coreState??'idle',animated:!cfg.reduced};
      if(this.kind==='bits'||this.kind==='core'||this.kind==='gesture'){
        if(this.kind==='core'&&this.active==='auto'){
          const phase=(elapsed/2200)%6,progress=phase%1,state=['encased','open','charging','guarding','settling','idle'][Math.floor(phase)];
          options.activity={state,amount:Math.sin(Math.PI*progress)**2,progress};
          this.dialog.querySelector('[data-guidance]').textContent='Sample work cycle. During play, the assigned action chooses the state.';
        }else this.dialog.querySelector('[data-guidance]').textContent=this.kind==='core'?'Actual Resonant Core artwork · private inspection.':'Actual formation and artwork · generic token footprint.';
        paintBitPreview(this.canvas,{...options,tokenImage:null,...(this.kind==='core'?{view:'mechanism',count:1}:{})});
      }
      else if(this.kind==='tokenFX'){
        const tokenScale=44/(600/7),effect={...group?.effect,id:this.active,enabled:true,strength:group?.effect?.strength??.6,activationElapsed:elapsed,scaleX:1/tokenScale,scaleY:1/tokenScale,originY:15};
        const parts=samplePreviewBits({...options,projectedEffect:effect,coreState:'auto',personality:0,passiveEffects:false,behaviour:{...options.behaviour,enabled:false}});
        const subject=this.previewSubject(),patient=medicalPreviewPatient(this.canvas,subject,null,{x:0,y:0},{align:'anchor',targetSize:88});
        const b=patient?.bounds,viewExtent=b?Math.max(240,2*Math.max(Math.abs(b.x),Math.abs(b.x+b.width),Math.abs(b.y),Math.abs(b.y+b.height))+24):240;
        this.dialog.querySelector('[data-guidance]').textContent=patient?'Actual projected effect and displayed recipient · native frame; private preview.':'Actual projected effect · generic token footprint; private preview.';
        const emitters=parts.map(({station,part})=>{const p=part.points[0],previous=this.depths.get(station),clearCentre=Math.abs(p[0])>=600/7||Math.abs(p[1]-15)>=600/7,bounds=previous!==undefined&&previous!==(p[2]>=0)&&clearCentre?compactSolidBounds(part.hardware):null;const front=compactDepthFront(p,previous,{bounds});this.depths.set(station,front);return {id:station,x:p[0]*tokenScale,y:(p[1]-15)*tokenScale,z:p[2],plane:front?'front':'rear'};});
        paintTokenEffectPreview(this.canvas,{id:this.active,count:this.count,elapsed,emitters,viewExtent,detail:cfg.effectDetail,strength:effect.strength,focus:effect.focus,motion:effect.motion,activationElapsed:elapsed,color:options.accent,background:options.background,animated:options.animated,paintToken:ctx=>{
          if(patient){paintMedicalPreviewPatient(ctx,patient);return;}
          ctx.save();ctx.beginPath();ctx.arc(0,0,44,0,Math.PI*2);ctx.fillStyle='#302734';ctx.fill();ctx.fillStyle=theme.text??'#f5ede1';ctx.font='24px Georgia';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('E',0,0);ctx.restore();
        },paintBits:(ctx,{plane})=>{ctx.save();ctx.scale(tokenScale,tokenScale);for(const {station,part} of parts){if(this.depths.get(station)!==(plane==='front'))continue;paintResonantBit(ctx,{...part,points:part.points.map(p=>[p[0],p[1]-15,p[2],p[3]])});}ctx.restore();}});
      }else {
        this.renderer.draw(elapsed);
        if(this.kind==='look')this.dialog.querySelector('[data-guidance]').textContent=`Live health and conditions · ${this.renderer.portraitAvailable?'displayed token artwork':'generic token footprint; source artwork unavailable'}. Wings open only here; scene assignments stay unchanged.`;
      }
    }catch(e){this.previewFailed=true;this.halt();this.dialog.querySelector('[data-guidance]').textContent=`Preview unavailable: ${e.message}. You can still activate your selection.`;this.controls();}
  }
  elapsed(){return this.playhead+(this.playing?this.window.performance.now()-this.started:0);}
  paintLookField(ctx,{plane,snapshot,geometry,unit,width,wx,wy,time}){
    const home=hudBitGroups(this.model).find(group=>group.id==='home'),effect=home?.effect;
    if(!effect?.enabled||!geometry?.bits?.size||!(home.presentCount??home.count)||snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse.mix>.01)return;
    const emitters=[...geometry.bits.values()].map((bit,i)=>{const p=bit.part.points[0];return {id:bit.id??String(i),x:(wx+(p[0]+300)/600*width)/unit*100,y:(wy+(p[1]+285)/600*width)/unit*100,z:p[2],plane:bit.front>bit.rear?'front':'rear'};});
    const field=sampleTokenEffect(effect.id,emitters.length,time,{emitters,detail:(this.previewConfig??previewQualityConfiguration(this.model.cfg)).effectDetail,strength:effect.strength??.6,color:this.model.baseAppearance?.filamentColor,animated:!this.model.cfg.reduced,activationElapsed:time});
    ctx.save();ctx.scale(unit/100*(field.effectScale??1),unit/100*(field.effectScale??1));paintTokenEffect(ctx,field,{plane});ctx.restore();
  }
  halt(){if(this.playing)this.playhead=this.elapsed();this.playing=false;if(this.raf!=null)this.window.cancelAnimationFrame(this.raf);this.raf=null;}
  play(){if(this.closed||this.playing||this.paused||this.saving||this.previewFailed||this.model.cfg.reduced||this.dialog.ownerDocument.hidden||!this.dialog.open)return;this.playing=true;this.started=this.window.performance.now();this.lastFrame=-Infinity;const tick=now=>{this.raf=null;if(!this.playing)return;if(!this.dialog.isConnected||!this.controller.opened){this.close();return;}if(!this.paintSoon&&now-this.lastFrame>=1000/Math.min(24,(this.previewConfig??previewQualityConfiguration(this.model.cfg)).rigFPS)){this.draw();this.lastFrame=now;}if(this.playing)this.raf=this.window.requestAnimationFrame(tick);};this.raf=this.window.requestAnimationFrame(tick);}
  controls(){const b=this.dialog.querySelector('[data-play]');b.textContent=this.paused?'Play preview':'Pause preview';b.disabled=!!(this.previewFailed||this.saving||this.model.cfg.reduced);this.dialog.querySelector('[data-replay]').disabled=!!(this.previewFailed||this.saving);this.dialog.querySelector('.ff-preview-dot').classList.toggle('is-paused',this.paused||b.disabled);const entry=this.entries.find(e=>e.id===this.active),apply=this.dialog.querySelector('[data-apply]');apply.disabled=!!(this.saving||!entry||this.kind==='look');apply.setAttribute('aria-label',entry?`${this.kind==='gesture'?'Perform':'Activate'} ${entry.label}`:'Activate selected animation');}
  filter(value){
    
    const terms=value.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean),groups=[...this.dialog.querySelectorAll('details')];let total=0;
    for(const group of groups)this.motion.stop(group);
    if(terms.length&&!this.searching)this.openCategories=new Map(groups.map(group=>[group,group.open]));
    for(const group of groups){
      let shown=0;for(const b of group.querySelectorAll('[data-choice]')){b.hidden=!!(this.favoritesOnly&&!this.isFavorite(b.dataset.choice))||!terms.every(t=>`${group.querySelector('summary').textContent} ${b.textContent}`.toLocaleLowerCase().includes(t));if(!b.hidden)shown++;}
      group.hidden=!shown;if(terms.length)group.open=!!shown;else if(this.searching)group.open=this.openCategories.get(group)??group.open;total+=shown;
    }
    this.searching=!!terms.length;this.dialog.querySelector('[data-empty]').hidden=!!total;this.dialog.querySelector('[data-empty]').textContent=this.favoritesOnly?'No matching favourites. Show all animations to add some.':'No matching animations.';this.motion.enter(this.dialog.querySelector('.ff-picker-choices'),{kind:'library'});
  }
  isFavorite(id){return (this.model.prefs.animationFavorites?.[this.kind]??[]).includes(id);}
  favoriteControls(){
    const pin=this.dialog.querySelector('[data-pin-animation]');if(pin){const active=this.isFavorite(this.active);pin.textContent=active?'★ Remove from favourites':'☆ Add to favourites';pin.setAttribute('aria-pressed',String(active));pin.disabled=!!(this.saving||this.pinning);}
    const filter=this.dialog.querySelector('[data-favorites-only]');if(filter){filter.setAttribute('aria-pressed',String(!!this.favoritesOnly));filter.textContent=this.favoritesOnly?'★ Favourites · Show all':'☆ Favourites';}
    for(const button of this.dialog.querySelectorAll('[data-choice]')){const yes=this.isFavorite(button.dataset.choice);button.classList.toggle('is-favorite',yes);button.setAttribute('aria-label',`${this.entries.find(e=>e.id===button.dataset.choice)?.label??button.dataset.choice}${yes?' · Favourite':''}${button.dataset.choice===this.active?' · Selected':''}${button.dataset.choice===this.saved(this.model)?' · Current':''}`);}
  }
  async pin(){
    if(this.closed||this.pinning||this.saving||!['bits','tokenFX'].includes(this.kind))return;
    this.pinning=true;this.favoriteControls();
    try{const saved=await this.controller.click('pinAnimation',`${this.kind}:${this.active}`,this.targetId);if(this.closed)return;this.model=this.controller.model();this.dialog.querySelector('[data-status]').textContent=saved===false?'Favourite not saved · retry from the HUD footer.':this.isFavorite(this.active)?'Pinned to this HUD’s quick choices.':'Removed from quick choices.';this.filter(this.dialog.querySelector('[data-search]').value);}
    catch(error){if(!this.closed)this.dialog.querySelector('[data-status]').textContent=error.message;}
    finally{this.pinning=false;if(!this.closed)this.favoriteControls();}
  }
  async apply(){
    if(this.closed||this.saving||this.controller.busy)return;if(!this.valid()){this.close();return;}
    const current=this.controller.model();
    if(this.kind==='bits'&&!enabledCompactProgramIds(formationOptions(current)).includes(this.active)){
      this.update(current);if(!this.closed)this.dialog.querySelector('[data-status]').textContent='This formation is disabled for this character. Choose another animation.';return;
    }
    if(this.kind==='look'||!this.entries.some(entry=>entry.id===this.active))return;
    this.saving=true;this.halt();this.controls();for(const button of this.dialog.querySelectorAll('[data-choice]'))button.disabled=true;const status=this.dialog.querySelector('[data-status]');status.textContent='Activating…';
    try{const {action,value}=animationCommand(this.kind,this.active,this.group,this.structure);await this.controller.run(action,value,this.targetId);this.close();}
    catch(e){if(this.closed)return;this.saving=false;status.textContent=e.message;for(const button of this.dialog.querySelectorAll('[data-choice]'))button.disabled=false;this.controls();this.play();}
  }
  close(){
    if(this.closed)return;this.closed=true;this.halt();this.events.abort();
    if(this.controller.animationPicker===this)this.controller.animationPicker=null;
    this.dialog.inert=true;
    void this.motion.exit(this.dialog,{kind:'library'}).finally(()=>{
      this.renderer?.destroy();releaseBitPreview(this.canvas);releaseMedicalPreviewPatient(this.canvas);this.motion.destroy();
      const doc=this.dialog.ownerDocument,restoreFocus=doc.activeElement===doc.body||this.dialog.contains(doc.activeElement);
      if(this.dialog.open)this.dialog.close();this.dialog.remove();
      if(restoreFocus&&this.controller.opened&&this.returnFocus?.isConnected)this.returnFocus.focus({preventScroll:true});
    });
  }
}
