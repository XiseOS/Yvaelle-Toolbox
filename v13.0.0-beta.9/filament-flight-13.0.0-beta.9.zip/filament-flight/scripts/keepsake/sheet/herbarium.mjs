/** Keepsake sheet · milestone petals (v11 experimental extra, "Just me").
 *
 *  - Her sheet's corner Nytheris grows the same inner whorl as the HUD's:
 *    the petals she has pinned, in its five gaps.
 *  - The herbarium (Character tab, at the foot): all six varieties, pressed
 *    once earned; click one to pin it to the flower or take it off (five
 *    gaps, so five at most). Unearned ones show what earns them.
 * Drawn after each dressing of her sheet, only while Milestone petals › On
 * her sheet is on; it listens for her journal only while that is so. */
import {isOn,partOn} from '../../v11/features.mjs?v=13.0.0-beta.9';
import {readActorJournal,pinPetal} from '../../v11/journal-runtime.mjs?v=13.0.0-beta.9';
import {MILESTONES,PIN_CAP} from '../../v11/journal.mjs?v=13.0.0-beta.9';
import {petalDefs,petalArt,whorl} from '../../v11/petal-art.mjs?v=13.0.0-beta.9';

const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const el=x=>x?.[0]??x??null;
const on=()=>{try{return partOn('xPetals','petalsSheet');}catch{return false;}};
let hook=null;
/** Hold the journal hook only while the sheet petals are on. */
export function syncHerbariumHooks(refresh){
  const want=on();
  if(want&&!hook){const id=Hooks.on('filamentFlightJournal',e=>refresh(e?.actor));const id2=Hooks.on('updateActor',(a,ch)=>{if(ch?.flags?.['filament-flight']?.journal!==undefined)refresh(a);});hook=[id,id2];}
  else if(!want&&hook){Hooks.off('filamentFlightJournal',hook[0]);Hooks.off('updateActor',hook[1]);hook=null;}
}
/** Her dressed sheet: the corner whorl and the herbarium (or neither, while off). */
export function dressPetals(app,form,actor){
  const root=el(app?.element);if(!root)return;
  const corner=root.querySelector(':scope > .ffks-frame .ffks-corner.tl g[transform^="translate(40 40)"]');
  const tab=form?.querySelector('section.sheet-body .sheet-content > .tab[data-tab="character"]');
  if(!on()){corner?.querySelector(':scope > .ffx-sheet-whorl')?.remove();tab?.querySelector(':scope .ffx-herb')?.remove();return;}
  const J=readActorJournal(actor);
  if(corner){
    let g=corner.querySelector(':scope > .ffx-sheet-whorl');
    if(!g){g=root.ownerDocument.createElementNS('http://www.w3.org/2000/svg','g');g.setAttribute('class','ffx-sheet-whorl');corner.prepend(g);}
    const night=Number(root.querySelector(':scope > .ffks-frame')?.dataset.night??1),key=`${J.pinned.join(',')}|${night.toFixed(2)}`;
    if(g.dataset.k!==key){g.dataset.k=key;g.innerHTML=`<defs>${petalDefs('shmp')}</defs>${whorl(J.pinned,{open:Number.isFinite(night)?night:1,prefix:'shmp',cls:'ffx-sheet-mp'})}`;}
  }
  if(!tab)return;
  let h=tab.querySelector(':scope > .ffx-herb');
  if(!h){h=root.ownerDocument.createElement('section');h.className='ffx-herb';h.dataset.ffksFlip='character-herbarium';tab.append(h);
    h.addEventListener('click',e=>{const b=e.target.closest('button[data-ms]');if(!b||b.classList.contains('lock'))return;e.preventDefault();
      void pinPetal(actor,b.dataset.ms).catch(err=>globalThis.ui?.notifications?.warn?.(err.message??String(err)));});}
  const earned=MILESTONES.filter(m=>J.milestones[m.id]).length,owner=!!actor?.isOwner;
  const key=JSON.stringify([J.milestones,J.pinned,owner]);if(h.dataset.k===key)return;h.dataset.k=key;
  h.innerHTML=`<div class="hd"><span class="lb">Herbarium · milestone petals</span><span class="mt">${earned} pressed · <i></i>pinned to the flower (${J.pinned.length}/${PIN_CAP})</span></div>
    <svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>${petalDefs('hbmp')}</defs></svg>
    <div class="grid">${MILESTONES.map(m=>{const got=J.milestones[m.id],pin=J.pinned.includes(m.id);
      return `<button type="button" class="p${got?'':' lock'}${pin?' on':''}" data-ms="${m.id}" ${got&&owner?'':'aria-disabled="true"'} aria-pressed="${pin}" title="${esc(got?`${m.note}${owner?(pin?' · Click to unpin':' · Click to pin to the flower'):''}`:`Grows at: ${m.when}`)}">
        <i class="pin" aria-hidden="true"></i><svg viewBox="-6 -15.5 12 16.5" aria-hidden="true">${petalArt(m.id,'hbmp')}</svg><span class="nm">${esc(m.name)}</span><span class="wh">${got?`Session ${got.s}`:esc(m.when)}</span></button>`;}).join('')}</div>
    ${earned?'':'<p class="note">Each petal is pressed here when she earns it; five can sit in the flower’s gaps.</p>'}`;
}
