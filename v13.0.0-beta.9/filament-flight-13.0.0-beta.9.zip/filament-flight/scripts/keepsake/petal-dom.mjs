/** Hero petals (beta.28): the part that touches the page, shared by the
 * Keepsake HUD and her Keepsake sheet.
 *
 * A new Hero Point takes one of the Nytheris's own petals: it tugs on the
 * flower and lets go, a falling petal takes over right where it was
 * (petal-fall.mjs) and floats down to its place in her row, and the flower
 * grows the petal back once it has landed. Each new point takes a petal of
 * its own, so gaining two leaves three on the flower and gaining three leaves
 * two, until they grow back. */
import {petalArrival,flowerPetalCycle,flowerPetalRegrow,PETAL_LOOSEN_MS} from './petal-fall.mjs?v=13.0.0-beta.9';

const NS='http://www.w3.org/2000/svg';
/** The Nytheris's petal and her row's petal, base at 0,0 and tip up (their path data). */
const FLOWER=[[0,0],[-3.4,-5],[-2.8,-11],[0,-14.5],[2.8,-11],[3.4,-5],[0,0]];
const HERO=[[0,0],[-3,-4],[-2.5,-8],[0,-9],[2.5,-8],[3,-4],[0,0]];
/** Each flower petal that is away, and until when (Date.now()). */
const away=new WeakMap();
/** The last Hero Point changes the HUD and her sheet saw, and what each did
 * about it (for the self-check): {at, where, from, to, did}. */
export const heroTrace=[];
export function traceHero(entry){heroTrace.push({at:new Date().toISOString().slice(11,23),...entry});if(heroTrace.length>30)heroTrace.shift();}
const r2=v=>Math.round(v*100)/100;
const GLOW_OFF='drop-shadow(0 0 0px rgba(231,103,206,0))',GLOW='drop-shadow(0 0 2px rgba(231,103,206,.4))';

/** A petal's outline as path data, kx × ky px per unit, its centre at 0,0. */
function outline(pts,kx,ky,len){
  const p=pts.map(([x,y])=>`${r2(x*kx)},${r2(y*ky+len/2)}`);
  return `M${p[0]}C${p[1]} ${p[2]} ${p[3]}C${p[4]} ${p[5]} ${p[6]}Z`;
}

/** The Nytheris's petals as they are now: where each one sits (in the
 * layer's px, through toLayer(clientX, clientY)), its angle and size.
 * items: [{el: what goes and grows back, shape: what draws it, rib?}] */
export function readFlower(corner,items,toLayer){
  if(!corner)return [];
  const box=corner.getBoundingClientRect(),vb=corner.viewBox?.baseVal;if(!box.width||!box.height)return [];
  const vx=vb?.x??0,vy=vb?.y??0,vw=vb?.width||box.width||130,vh=vb?.height||box.height||130;
  const map=(m,x,y)=>{const p=new DOMPoint(x,y).matrixTransform(m);return toLayer(box.left+(p.x-vx)*box.width/vw,box.top+(p.y-vy)*box.height/vh);};
  const out=[];
  for(const it of items){
    try{
      const M=it.shape?.getCTM?.(),P=it.el?.parentNode?.getCTM?.();if(!M||!P)continue;
      const b=map(M,0,0),t=map(M,0,-14.5),u=map(M,1,0),len=Math.hypot(t.x-b.x,t.y-b.y);if(!len)continue;
      // (the flower's own units, for how far the petal slides out as it comes loose)
      const o=map(P,0,0),e1=map(P,1,0),e2=map(P,0,1);
      let rib=null;const RM=it.rib?.getCTM?.();
      if(RM){const r0=map(RM,0,-3),r1=map(RM,0,-12),q0=map(RM,0,0),q1=map(RM,1,0);
        rib={from:Math.hypot(r0.x-b.x,r0.y-b.y),to:Math.hypot(r1.x-b.x,r1.y-b.y),width:.5*Math.hypot(q1.x-q0.x,q1.y-q0.y)};}
      out.push({el:it.el,base:b,len,kx:Math.hypot(u.x-b.x,u.y-b.y),ky:len/14.5,angle:Math.atan2(t.x-b.x,-(t.y-b.y))*180/Math.PI,
        dir:{x:(t.x-b.x)/len,y:(t.y-b.y)/len},axes:{x:{x:e1.x-o.x,y:e1.y-o.y},y:{x:e2.x-o.x,y:e2.y-o.y}},rib});
    }catch{}
  }
  return out;
}

/** The petal that comes loose: one still on the flower, leaning most towards her row. */
export function pickPetal(petals,target){
  const now=Date.now();let best=null,score=-Infinity;
  for(const p of petals){
    if((away.get(p.el)??0)>now)continue;
    const vx=target.x-p.base.x,vy=target.y-p.base.y,d=Math.hypot(vx,vy)||1,s=(p.dir.x*vx+p.dir.y*vy)/d+.35*p.dir.y;
    if(s>score){score=s;best=p;}
  }
  return best;
}
/** How many of the flower's petals are on it now (for tests and tools). */
export function petalsOnFlower(els){const now=Date.now();return [...els].filter(el=>(away.get(el)??0)<=now).length;}

/** Her row's petal: its box as laid out (w × h px, swaying about 50% 85%)
 * and the petal drawn in it (13 × 14 units, base at 6.5, 11). */
export function readSlot(pip,w,h,toLayer){
  const r=pip.getBoundingClientRect(),c=toLayer((r.left+r.right)/2,(r.top+r.bottom)/2);
  let th=0;
  try{const t=(pip.ownerDocument.defaultView??globalThis).getComputedStyle(pip).transform;if(t&&t!=='none'){const m=new DOMMatrix(t);th=Math.atan2(m.b,m.a);}}catch{}
  // (its bounding box is turned with it: find where it turns, then its box as laid out)
  const O={x:c.x-.35*h*Math.sin(th),y:c.y+.35*h*Math.cos(th)},ppu=Math.min(w/13,h/14),top=O.y-.85*h;
  return {O,ppu,len:9*ppu,base:{x:O.x,y:top+(h-14*ppu)/2+11*ppu}};
}
/** The centre of her row's petal when it has swayed to `alpha` degrees. */
function centreAt(slot,alpha){
  const a=alpha*Math.PI/180,cx=slot.base.x-slot.O.x,cy=slot.base.y-slot.len/2-slot.O.y;
  return {x:slot.O.x+cx*Math.cos(a)-cy*Math.sin(a),y:slot.O.y+cx*Math.sin(a)+cy*Math.cos(a)};
}

/** One new Hero Point, start to finish, in `layer` (absolutely positioned,
 * its origin where toLayer's is). The flower's petal starts tugging after
 * `delay` ms. angleAt(t) is the angle her row's petal sways to at t on the
 * page's animation clock. Returns the flight, or null with no petal to take:
 * {el, end (Date.now() when it lands), landed (a promise), handover(ms), fade()}. */
export function arrive({layer,cls,petals,slot,delay=0,angleAt=()=>0,rib=false}){
  const doc=layer.ownerDocument,petal=pickPetal(petals,slot.base);if(!petal)return null;
  const clock=doc.timeline?.currentTime??0;
  // it lets go a little way out of the flower
  const pull=1.6,go={x:petal.base.x+petal.dir.x*(petal.len/2+pull),y:petal.base.y+petal.dir.y*(petal.len/2+pull)};
  const plan=(alpha,c=centreAt(slot,alpha))=>({c,spec:petalArrival({x:go.x-c.x,y:go.y-c.y,angle:petal.angle,toAngle:alpha})});
  const first=plan(0),alpha=angleAt(clock+delay+PETAL_LOOSEN_MS+first.spec.duration),{c,spec}=plan(alpha);
  // the flower's petal: it tugs, lets go and grows back after it has landed
  const ax=petal.axes.x,ay=petal.axes.y,det=(ax.x*ay.y-ay.x*ax.y)||1,px=petal.dir.x*pull,py=petal.dir.y*pull;
  const cycle=flowerPetalCycle({away:spec.duration,pull:{x:(px*ay.y-ay.x*py)/det,y:(ax.x*py-px*ax.y)/det}});
  let flower=petal.el.animate(cycle.keyframes,{duration:cycle.duration,delay,easing:'linear'});
  away.set(petal.el,Date.now()+delay+cycle.duration);
  // the falling petal: the flower's own, turning into one of her row's as it falls
  const fly=doc.createElementNS(NS,'svg');
  fly.setAttribute('class',cls);fly.setAttribute('viewBox','-20 -20 40 40');fly.setAttribute('width','40');fly.setAttribute('height','40');fly.setAttribute('aria-hidden','true');
  fly.style.cssText=`left:${r2(c.x-20)}px;top:${r2(c.y-20)}px;opacity:0`;
  const from=outline(FLOWER,petal.kx,petal.ky,petal.len),to=outline(HERO,slot.ppu,slot.ppu,slot.len);
  const sw0=`${r2(.7*Math.sqrt(petal.kx*petal.ky))}px`,sw1=`${r2(.6*slot.ppu)}px`;
  const path=doc.createElementNS(NS,'path');
  for(const [k,v] of [['d',from],['fill','#efe4d4'],['fill-opacity','.94'],['stroke','#8e2038'],['stroke-width',sw0]])path.setAttribute(k,v);
  fly.append(path);
  let vein=null;
  if(rib&&petal.rib){
    vein=doc.createElementNS(NS,'path');
    for(const [k,v] of [['d',`M0 ${r2(petal.len/2-petal.rib.from)}V${r2(petal.len/2-petal.rib.to)}`],['fill','none'],['stroke','#a3243f'],['stroke-width',r2(petal.rib.width)],['opacity','.8']])vein.setAttribute(k,v);
    fly.append(vein);
  }
  layer.append(fly);
  const at={delay:delay+PETAL_LOOSEN_MS,duration:spec.duration,fill:'forwards'};
  const anim=fly.animate(spec.keyframes,{...at,easing:spec.easing});
  fly.animate([{filter:GLOW_OFF},{offset:.55,filter:GLOW},{filter:GLOW}],at);
  const was={d:`path("${from}")`,fill:'#efe4d4',fillOpacity:.94,stroke:'#8e2038',strokeWidth:sw0},becomes={d:`path("${to}")`,fill:'#f0dfe4',fillOpacity:1,stroke:'#a3243f',strokeWidth:sw1};
  path.animate([{offset:0,...was},{offset:.08,...was,easing:'ease-in-out'},{offset:.5,...becomes},{offset:1,...becomes}],at);
  vein?.animate([{opacity:.8},{offset:.3,opacity:0},{opacity:0}],at);
  const end=Date.now()+delay+PETAL_LOOSEN_MS+spec.duration;
  let done=false;
  const drop=()=>{for(const a of fly.getAnimations({subtree:true}))a.cancel();fly.remove();};
  return {el:fly,end,landed:anim.finished,
    /** Landed: the falling petal gives way to the one in her row. */
    handover(ms){if(done)return;done=true;fly.animate([{opacity:1},{opacity:0}],{duration:ms,fill:'forwards'}).finished.then(drop,drop);},
    /** Spent before it landed. Still on the flower: it stays there. In the air:
     * it fades where it is, and the flower grows its petal back now. */
    fade(ms=320){
      if(done)return;done=true;
      if(Date.now()<end-spec.duration){flower.cancel();away.delete(petal.el);drop();return;}
      for(const a of fly.getAnimations({subtree:true}))a.pause();
      fly.animate([{opacity:0}],{duration:ms,fill:'forwards'}).finished.then(drop,drop);
      flower.cancel();const g=flowerPetalRegrow();flower=petal.el.animate(g.keyframes,{duration:g.duration,easing:g.easing});away.set(petal.el,Date.now()+g.duration);
    }};
}
