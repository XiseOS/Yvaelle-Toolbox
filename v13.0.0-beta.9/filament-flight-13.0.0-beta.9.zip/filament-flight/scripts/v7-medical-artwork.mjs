import {V7_MEDICAL_WORK_SPECS,sampleV7MedicalWork,sampleV7MedicalSite,sampleV7FinishingSite,v7MedicalCompletionProgress} from './v7-medical-work.mjs?v=13.0.0-beta.9';

/** The physical gemstone instruments perform these repairs. Every projected
 * tool is fed by an actual source and ends at that source's sampled contact.
 * Patient materials are small local repair surfaces, not free-standing machines. */
const TAU=Math.PI*2,PINK='#ff62cf',PEARL='#ffe4f8',GOLD='#eac49a',ICE='#c3e5ff';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,Number(n)||0));
const smooth=n=>{n=clamp(n);return n*n*(3-2*n);},mix=(a,b,q)=>a+(b-a)*q,wrap=n=>(n%1+1)%1;
// A tool retains one orientation across all of its authored vertices. Reuse
// that exact basis within the sample, without retaining moving geometry.
const rotator=a=>{const c=Math.cos(a),s=Math.sin(a);return (x,y)=>[x*c-y*s,x*s+y*c];};
const OVAL_BASIS=Object.freeze(Object.fromEntries([8,12].map(n=>[n,Object.freeze(Array.from({length:n+1},(_,i)=>Object.freeze([Math.cos(i/n*TAU),Math.sin(i/n*TAU)])))])));
const bez=(a,b,c,d,u)=>{const v=1-u;return [v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*c[0]+u*u*u*d[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*c[1]+u*u*u*d[1]];};
const IDS=['leftUpper','rightUpper','leftLower','rightLower'];

export function bitMedicalArtworkBounds(effect){
  if(!V7_MEDICAL_WORK_SPECS[effect?.style])return null;
  let left=-34,right=34,top=-32,bottom=36;
  for(const e of effect.emitters??[])for(const p of [e,e.workPoint].filter(Boolean)){
    left=Math.min(left,p.x*100-11);right=Math.max(right,p.x*100+11);
    top=Math.min(top,p.y*100-11);bottom=Math.max(bottom,p.y*100+11);
  }
  return {x:left-4,y:top-4,width:right-left+8,height:bottom-top+8};
}

export function sampleBitMedicalArtwork(effect={}){
  const spec=V7_MEDICAL_WORK_SPECS[effect.style];if(!spec)return null;
  const quality=effect.detail==='low'?0:effect.detail==='high'?2:1,steps=[8,12,16][quality];
  const animated=effect.animated!==false,t=animated?Math.max(0,Number(effect.clock)||0):0;
  const scan=effect.phase==='scanning',finish=effect.phase==='finishing',p=clamp(effect.progress),scanP=clamp(effect.scan??p);
  const good=finish&&['success','criticalSuccess'].includes(effect.outcome);
  const close=animated&&good?v7MedicalCompletionProgress(p):0,withdraw=animated&&finish&&!good?smooth(p/.78):0;
  const fade=finish?1-smooth((p-.62)/.38):1,entry=scan?smooth(scanP):1;
  const strength=clamp(effect.strength??1,0,2),gain=strength*entry*fade;
  const emitters=effect.emitters??[],count=clamp(emitters.length||1,1,4),paths=[];
  const frame={id:effect.style,color:'#ff00ff',strength,count,paths,emitters:[],bounds:bitMedicalArtworkBounds(effect),phase:effect.phase,
    activation:{charge:entry,projection:entry,sustain:entry}};
  if(!gain)return frame;
  const add=(points,{alpha=.65,width=.8,plane='front',closed=false,fill=0,tint=PINK,fillTint=tint,highlight=false,glow=false,role='local-repair',emitterId}={})=>{
    if(points.length<2||alpha*gain+fill*gain<.00001)return;
    paths.push({points,alpha:clamp(alpha*gain),width,plane,closed,fill:clamp(fill*gain,0,.20),tint,fillTint,highlight,glow:glow&&quality>0,role,...(emitterId==null?{}:{emitterId})});
  };
  const curve=(fn,o={})=>{const n=o.steps??steps,points=new Array(n+1);for(let i=0;i<=n;i++)points[i]=fn(i/n);add(points,o);};
  const cubic=(a,b,c,d,o={})=>curve(u=>bez(a,b,c,d,u),o);
  const line=(a,b,o={})=>add([a,b],o);
  const oval=(x,y,rx,ry,o={})=>add(OVAL_BASIS[quality===0?8:12].map(([c,s])=>[x+rx*c,y+ry*s]),{closed:true,...o});
  const ribbon=(fn,half,o={})=>{
    const n=o.steps??steps,a=[],b=[];
    for(let i=0;i<=n;i++){const u=i/n,at=fn(u),lo=fn(Math.max(0,u-.002)),hi=fn(Math.min(1,u+.002)),dx=hi[0]-lo[0],dy=hi[1]-lo[1],l=Math.hypot(dx,dy)||1;
      a.push([at[0]-dy/l*half,at[1]+dx/l*half]);b.push([at[0]+dy/l*half,at[1]-dx/l*half]);}
    add(a.concat(b.reverse()),{closed:true,...o});
  };
  const film=(x,y,w,h,bow=3,o={})=>{
    const a=[x-w,y-h],b=[x+w,y-h],c=[x+w,y+h],d=[x-w,y+h],pts=[];
    for(const [from,c1,c2,to]of [[a,[x-w*.5,y-h-bow],[x+w*.5,y-h-bow],b],[b,[x+w+2,y-h*.5],[x+w+2,y+h*.5],c],[c,[x+w*.5,y+h+bow],[x-w*.5,y+h+bow],d],[d,[x-w-2,y+h*.5],[x-w-2,y-h*.5],a]])
      for(let j=0;j<=(quality?4:3);j++)pts.push(bez(from,c1,c2,to,j/(quality?4:3)));
    add(pts,{closed:true,fill:.08,alpha:.45,tint:PINK,...o});
  };
  const site=animated&&good?sampleV7FinishingSite(effect.style,count,t,p):sampleV7MedicalSite(effect.style,count,t);
  const workTime=site.virtualTime??t,staticSite=animated?site:sampleV7MedicalSite(effect.style,count,spec.period);
  const samples=emitters.map((e,i)=>{
    const physical=Math.max(0,IDS.indexOf(e.id)),work=sampleV7MedicalWork(effect.style,physical,count,workTime,{roleIndex:i,physicalIndex:physical,site});
    // Derive scalar work hints from the same pure clock for live paint, the
    // late scan bridge and compact release captures. This keeps the final scan
    // artwork identical to the first working sample without new flag fields.
    const hint=key=>work[key];
    return {e,i,work,role:count===1?work.jobIndex:i,from:[e.x*100,e.y*100],at:[(e.workPoint?.x??work.workPoint.x)*100,(e.workPoint?.y??work.workPoint.y)*100],
      contact:hint('contact')*(1-withdraw),phase:hint('toolPhase'),repair:hint('repairProgress'),plane:e.z<0?'rear':'front',
      deliveryGate:animated?(hint('deliveryGate')??1):1,deliveryTransfer:hint('deliveryTransfer'),deliveryCharge:hint('deliveryCharge'),deliveryArrival:hint('deliveryArrival')};
  });
  const primary=samples.filter(s=>s.i<2),contact=primary.length?primary.reduce((sum,s)=>sum+s.contact,0)/primary.length:.35;
  const working=(1-withdraw),seat=Math.max(close,contact*.62),body=.5+.5*contact;
  const point=p=>[p.x*100,p.y*100];
  const alignmentEnds=site.endpoints?.map((p,i)=>effect.style==='segmentedCradle'&&close?point({x:mix(p.x,site.alignedEndpoints[i].x,close),y:mix(p.y,site.alignedEndpoints[i].y,close)}):point(p));
  const filmEndY=effect.style==='petalSanctuary'?mix(staticSite.filmEdge[0].y,.23,close)*100:0;

  // A quiet repair region remains in the tools' working field. Changes in its
  // shape are driven by contact/pressure, not an independently orbiting prop.
  if(effect.style==='capillaryBridge'){
    for(const source of primary)for(let j=0;j<(quality===0?2:3);j++){
      const end=[(source.at[0]<0?-1:1)*(2-close*1.2),-4+j*10],a=[source.at[0]*.72,source.at[1]+3],b=[end[0]*2,end[1]-3],route=u=>bez(source.at,a,b,end,u);
      ribbon(route,.95,{alpha:.27*body*working,fill:.08*working,tint:PINK,role:'receiving-tissue'});
      curve(route,{alpha:.42*working,width:.85,tint:PINK,role:'contact-channel'});
      const arrival=smooth(clamp((source.phase-.70-j*.025)/.15)),on=arrival*(1-smooth((source.phase-.92)/.08))*source.deliveryGate;
      curve(u=>route(u*arrival),{alpha:.75*on*working,width:1.5,highlight:true,role:'infused-contact'});
    }
  }else if(effect.style==='irisPatch'){
    const gap=(animated&&count>1?primary.reduce((sum,s)=>sum+Math.abs(s.at[0]),0)/primary.length:(site.gap??.15)*100*(1-close))+withdraw*3;
    for(const s of [-1,1])cubic([s*gap,-10],[s*(gap+2),0],[s*(gap+1),13],[s*gap,22],{alpha:.65*working,width:1.6,tint:PEARL});
    film(0,6,gap+2,15,2,{alpha:.30*contact*working,fill:.06*contact*working,role:'contact-patch'});
    for(const y of [-7,19])line([-gap,y],[gap,y],{alpha:.25*contact*working,width:.8,tint:GOLD});
  }else if(effect.style==='segmentedCradle'){
    const ends=animated&&count>1?primary.map(s=>s.at):alignmentEnds,a=ends[0],d=ends[1];
    const axis=u=>[mix(a[0],d[0],u),mix(a[1],d[1],u)];
    ribbon(axis,2.2,{alpha:.36*working,fill:.10*working,tint:PINK,role:'held-alignment'});
    curve(axis,{alpha:.63*working,width:1.4,tint:PEARL});
    for(const u of [.28,.72]){
      const at=axis(u),angle=Math.atan2(d[1]-a[1],d[0]-a[0]),rotate=rotator(angle),tr=(x,y)=>{const r=rotate(x,y);return [at[0]+r[0],at[1]+r[1]];};
      cubic(tr(-2,-7),tr(3,-4),tr(3,4),tr(-2,7),{alpha:.56*working,width:2,tint:PEARL,role:'support-strip'});
    }
  }else if(effect.style==='lymphaticCircuit'){
    const y=primary[0]?.at[1]??6;
    const wash=u=>[-15+30*u,y+Math.sin(u*Math.PI)*3];
    ribbon(wash,2,{alpha:.26*working,fill:.10*contact*working,tint:PINK,role:'clean-wash'});
    curve(wash,{alpha:.55*contact*working,width:1.2,tint:PEARL});
    for(const s of [-1,1])cubic([s*14,-6],[s*19,0],[s*19,15],[s*12,21],{alpha:.19*working,width:.6,tint:ICE});
  }else if(effect.style==='fibrilRepair'){
    const stitches=staticSite.stitches;
    for(const stitch of stitches){
      const a=point(stitch.start),b=point(stitch.controlA),c=point(stitch.controlB),d=point(stitch.end),progress=stitch.progress;
      if(progress<=0)continue;
      const pull=v=>[v[0]*(1-close*.75)+Math.sign(v[0])*withdraw*3,v[1]];
      const start=pull(a),controlA=pull(b),controlB=pull(c),end=pull(d),route=u=>bez(start,controlA,controlB,end,u);
      curve(u=>route(u*progress),{alpha:(.5+.28*contact)*working*progress,width:1.35,tint:PEARL,role:'deposited-stitch'});
      if(progress>.95)line(pull(a),[pull(a)[0]+1.1,pull(a)[1]+1.3],{alpha:.68*working,width:1.4,tint:GOLD,role:'seated-stitch'});
    }
  }else if(effect.style==='tissueLens'){
    const trace=u=>point(site.trace(u));
    ribbon(trace,1.25,{alpha:.24*working,fill:.06*working,tint:PINK,role:'repair-bed'});
    curve(trace,{alpha:.45*working,width:.8,tint:PEARL});
    const built=Math.max(staticSite.materialProgress,mix(site.cursor,1,close));
    if(built)curve(u=>trace(u*built),{alpha:.74*working,width:1.7,highlight:true,role:'deposited-repair'});
  }else if(effect.style==='pulseReservoir'){
    const press=contact*.6;
    for(const s of [-1,1])cubic([s*12,6],[s*10,6-8*(1-press)],[s*3,6-8*(1-press)],[0,6],{alpha:.4*working,width:1.5,tint:PEARL});
    cubic([-12,7],[-6,15-press*3],[6,15-press*3],[12,7],{alpha:.38*working,width:1.2,tint:PINK});
    if(close)line([-10,6],[10,6],{alpha:.55*close,width:1.6,highlight:true,role:'steady-response'});
  }else if(effect.style==='petalSanctuary'){
    const top=point(site.corners[0]),right=point(site.corners[1]);
    const endY=animated&&count>1?primary.reduce((sum,s)=>sum+s.at[1],0)/primary.length:filmEndY;
    const height=Math.max(0,(endY-top[1])/2),width=(right[0]-top[0])/2,y=top[1]+height;
    if(height>.1){
      film(0,y,width,height,Math.min(2,height*.2)*(1-close),{alpha:.52*working,fill:.10*working,role:'laid-dressing'});
      cubic(top,[top[0]*.5,top[1]-2],[right[0]*.5,right[1]-2],right,{alpha:.54*working,width:1.2,tint:PEARL,role:'seated-dressing-edge'});
      cubic([top[0],endY],[top[0]*.5,endY+2],[right[0]*.5,endY+2],[right[0],endY],{alpha:.74*working,width:1.7,tint:PEARL,role:'held-film-edge'});
    }
  }

  for(const s of samples){
    const {e,i,from,at,plane,role}=s,active=s.contact*(i<2?1:.65),side=from[0]<0?-1:1;
    const stemA=[mix(from[0],at[0],.38),from[1]+side*3],stemB=[mix(from[0],at[0],.78),at[1]-side*2],stem=u=>bez(from,stemA,stemB,at,u);
    const feed=scan?smooth(scanP/.8):1;
    const isDrawing=effect.style==='lymphaticCircuit'&&role===0;
    const alpha=(.18+.36*active)*working;
    // The narrow translucent stem is a projected tool, physically attached to
    // the bit's aperture. Primary therapy and additional support are distinct.
    ribbon(u=>stem(u*feed),i<2?1.25:.7,{alpha:alpha*.5,fill:alpha*.15,plane,tint:PINK,role:'core-tool-stem',emitterId:e.id});
    curve(u=>stem(u*feed),{alpha,width:i<2?.8:.55,plane,tint:PINK,role:'emitter-feed',emitterId:e.id,glow:i<2});
    if(!scan&&i<2){
      const q=s.deliveryTransfer??smooth(clamp((s.phase-.18)/.52)),on=Math.sin(Math.PI*q)**2*working*s.deliveryGate;
      const route=u=>stem(isDrawing?1-u:u),atPacket=route(q);
      if(effect.style==='capillaryBridge'){
        // A full droplet moves from the charged aperture and flattens into
        // the contact; this is delivery rather than a uniformly lit beam.
        const a=route(clamp(q+.02)),angle=Math.atan2(a[1]-atPacket[1],a[0]-atPacket[0]),rotate=rotator(angle);
        const shape=[[-3,0],[-1.5,-2],[1,-1.9],[3,0],[1,1.9],[-1.5,2]].map(v=>{const r=rotate(...v);return [atPacket[0]+r[0],atPacket[1]+r[1]];});
        add(shape,{alpha:.9*on,fill:.18*on,width:1.2,closed:true,plane,tint:PINK,role:'restorative-droplet',emitterId:e.id});
        oval(atPacket[0]+.3,atPacket[1]-.4,1.2,.8,{alpha:.85*on,width:.75,plane,highlight:true,role:'droplet-highlight'});
      }else if(effect.style==='pulseReservoir'){
        const a=route(clamp(q+.02)),angle=Math.atan2(a[1]-atPacket[1],a[0]-atPacket[0]),rotate=rotator(angle),at=(x,y)=>{const r=rotate(x,y);return [atPacket[0]+r[0],atPacket[1]+r[1]];};
        cubic(at(-2,-5),at(1,-3),at(1,3),at(-2,5),{alpha:.88*on,width:2.2,plane,tint:PEARL,role:'restorative-pressure-packet'});
        cubic(at(-4,-4),at(-2,-2),at(-2,2),at(-4,4),{alpha:.33*on,width:1.2,plane,tint:PINK,role:'pulse-trailing-front'});
      }else if(isDrawing){
        // A few distinct, rim-lit fragments leave the contact and visibly
        // reach the extracting core. They are neither smoke nor an aura.
        add([[atPacket[0]-2,atPacket[1]],[atPacket[0]-.8,atPacket[1]-2.6],[atPacket[0]+2,atPacket[1]-.5],[atPacket[0]+.7,atPacket[1]+2.2]],{alpha:.9*on,fill:.16*on,width:1.3,closed:true,plane,tint:'#b699c3',role:'extracted-fleck',emitterId:e.id});
        line([atPacket[0]-1.2,atPacket[1]],[atPacket[0]-.4,atPacket[1]-1.9],{alpha:.8*on,width:.85,plane,tint:PEARL,role:'extraction-highlight'});
      }else if(effect.style==='lymphaticCircuit')oval(...atPacket,2.3,1.9,{alpha:.9*on,fill:.18*on,width:1.25,plane,highlight:true,role:'clean-flush-packet',emitterId:e.id});
      if(effect.style==='lymphaticCircuit'&&isDrawing&&quality>0)for(const d of [-.05,.05]){
        const a=route(clamp(q+d));add([[a[0]-1.2,a[1]],[a[0],a[1]-1.8],[a[0]+1.2,a[1]],[a[0],a[1]+1.8]],{alpha:.6*on,width:.8,closed:true,plane,tint:'#b699c3',role:'extracted-fleck'});
      }
    }
    // Apertures keep their original exact diamond geometry and extraction
    // tags, so their display-rate attachment never falls into the patient cache.
    add([[from[0],from[1]-1.7],[from[0]+1.7,from[1]],[from[0],from[1]+1.7],[from[0]-1.7,from[1]]],{alpha:.55+.17*active,width:.65,plane,closed:true,highlight:true,glow:true,role:'emitter-aperture',emitterId:e.id??i});
    if(!scan&&i<2&&['capillaryBridge','lymphaticCircuit','pulseReservoir'].includes(effect.style)){
      const charge=animated?(s.deliveryCharge??smooth(s.phase/.09)*(1-smooth((s.phase-.18)/.09)))*s.deliveryGate:.75,r=2.3+charge*1.3;
      add([[from[0],from[1]-r],[from[0]+r,from[1]],[from[0],from[1]+r],[from[0]-r,from[1]]],{alpha:.70*charge*working,width:1.2,plane,closed:true,tint:PINK,glow:true,role:'emitter-aperture',emitterId:e.id??i});
      const arrival=(s.deliveryArrival??smooth((s.phase-.70)/.09)*(1-smooth((s.phase-.90)/.1)))*s.deliveryGate;
      if(effect.style==='capillaryBridge'||effect.style==='lymphaticCircuit'&&!isDrawing)oval(...at,3.8,1.5,{alpha:.77*arrival*working,width:1.5,plane,highlight:true,role:'delivered-contact-response'});
    }
    if(!scan&&count===1&&['irisPatch','segmentedCradle','petalSanctuary'].includes(effect.style)){
      const anchor=effect.style==='segmentedCradle'?alignmentEnds[1-(s.work.jobIndex??0)]:effect.style==='petalSanctuary'?[site.filmEdge[1-(s.work.jobIndex??0)].x*100,filmEndY]:[-at[0],at[1]];
      cubic(from,[mix(from[0],anchor[0],.35),from[1]+7],[mix(from[0],anchor[0],.8),anchor[1]+3],anchor,{alpha:.34*working,width:.8,plane,tint:PINK,role:'retained-anchor-feed',emitterId:e.id});
      add([[anchor[0]-2,anchor[1]-3],[anchor[0]+1,anchor[1]-3],[anchor[0]+2,anchor[1]],[anchor[0]+1,anchor[1]+3],[anchor[0]-2,anchor[1]+3]],{alpha:.55*working,fill:.06*working,width:1,closed:true,plane,tint:GOLD,role:'retained-hardlight-anchor'});
    }
    if(scan){
      const spread=3+7*(1-scanP),edge=[[at[0]-spread,at[1]-2],[at[0]+spread,at[1]+2]];
      add([from,...edge],{alpha:.12*Math.sin(Math.PI*scanP),fill:.04*Math.sin(Math.PI*scanP),width:.45,closed:true,plane,tint:PINK,role:'local-diagnostic'});
      line(...edge,{alpha:.48*Math.sin(Math.PI*scanP),width:1,plane,highlight:true,role:'contact-scan'});
    }else{
      const dir=Math.atan2(at[1]-from[1],at[0]-from[0]),rotate=rotator(dir),orient=(x,y)=>{const r=rotate(x,y);return [at[0]+r[0],at[1]+r[1]];};
      if(i>=2){
        if(role===2){
          add([orient(-4,-4),orient(-1,-4),orient(1,-2),orient(1,2),orient(-1,4),orient(-4,4)],{alpha:.60*working,fill:.09*working,width:1.25,closed:true,plane,tint:GOLD,role:'stabilizing-grip'});
          line(orient(-2,-2.5),orient(-2,2.5),{alpha:.73*working,width:1.3,plane,tint:PEARL,role:'held-support-contact'});
        }else{
          add([from,orient(-2,-5),orient(1,5)],{alpha:.12*working,fill:.055*working,width:.45,closed:true,plane,tint:ICE,role:'inspection-fan'});
          const y=-3+6*(.5-.5*Math.cos(s.phase*TAU));line(orient(-3,y),orient(1,y),{alpha:.74*working,width:1.2,plane,tint:PEARL,role:'verification-contact'});
        }
      }else if(effect.style==='irisPatch'||effect.style==='segmentedCradle'){
        add([orient(-4,-3),orient(-1,-3.5),orient(1,-2),orient(1,2),orient(-1,3.5),orient(-4,3)],{alpha:.68*active,fill:.10*active,width:1,closed:true,plane,tint:PEARL,role:'projected-grip'});
        oval(...at,1.4,2.2,{alpha:.54*active,width:.8,plane,tint:GOLD,role:'pressure-contact'});
      }else if(effect.style==='fibrilRepair'||effect.style==='tissueLens'){
        add([orient(-7,-1.8),orient(-2,-1.2),orient(1,0),orient(-2,1.2),orient(-7,1.8)],{alpha:.74*active,fill:.08*active,width:.9,closed:true,plane,tint:PEARL,role:'projected-needle'});
        oval(...at,1.2,1.1,{alpha:.86*active,width:1,plane,highlight:true,role:'repair-contact'});
      }else if(effect.style==='petalSanctuary'){
        cubic(orient(-3,-4),orient(0,-3),orient(0,3),orient(-3,4),{alpha:.66*active,width:2,plane,tint:PEARL,role:'smoothing-tool'});
      }else{
        oval(...at,2.7,1.8,{alpha:.63*active,fill:.06*active,width:1.05,plane,tint:PEARL,role:'restorative-contact'});
        if(effect.style==='pulseReservoir'){
          const on=(s.deliveryArrival??smooth((s.phase-.70)/.09)*(1-smooth((s.phase-.90)/.1)))*s.deliveryGate;
          cubic([at[0]-6,at[1]],[at[0]-3,at[1]+3],[at[0]+3,at[1]+3],[at[0]+6,at[1]],{alpha:.72*on*working,width:1.7,plane,highlight:true,role:'delivered-pressure-front'});
        }
      }
    }
    frame.emitters.push({...e,port:at,plane});
  }
  return frame;
}
