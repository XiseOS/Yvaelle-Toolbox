/** Yvaelle’s Toolbox v10 additions: built-in Medkit and the quick wheel, with
 * their keybindings. Returned members are merged into the public API. */
import {openMedkitWindow} from './keepsake/medkit-window.mjs?v=13.0.0-beta.9';
import {registerKeepsakeSettings} from './keepsake/app.mjs?v=13.0.0-beta.9';
import {installQuickWheel} from './quick-wheel.mjs?v=13.0.0-beta.9';
import {registerWarp,chooseWarp} from './warp.mjs?v=13.0.0-beta.9';
import {registerVersionCheck} from './version-check.mjs?v=13.0.0-beta.9';
import {registerVersionSwitches} from './v10-versions.mjs?v=13.0.0-beta.9';
import {registerRoutines,startRoutine,envoyWatchOut,ROUTINES,listSpecimens} from './routines.mjs?v=13.0.0-beta.9';
import {startManoeuvreDemo} from './flight-manoeuvres.mjs?v=13.0.0-beta.9';
import {flightFeelEnabled} from './flight-feel-runtime.mjs?v=13.0.0-beta.9';
import {installKeepsakeSheet} from './keepsake/sheet/index.mjs?v=13.0.0-beta.9';
const ID='filament-flight';

export function registerV10Features(manager,api,getHud){
  registerKeepsakeSettings();registerWarp();registerVersionCheck();registerVersionSwitches();registerRoutines();
  // beta.27: her Keepsake character sheet (off by default)
  const sheet=installKeepsakeSheet();
  // Ellie's Medkit is its own square window (the classic dialogs were retired in beta.21)
  const medkit=(options={})=>openMedkitWindow(options.healer??options.token??null);
  game.keybindings.register(ID,'openMedkit',{
    name:"Open Ellie's Medkit",
    hint:'Select the healer, target the patient, then press this key. Works for patients you do not own while a GM is connected.',
    editable:[],restricted:false,repeat:false,
    onDown:()=>{void medkit().catch(error=>ui.notifications.error(`Medkit: ${error?.message??error}`));return true;}
  });
  const quickWheel=installQuickWheel(manager,api,{medkit,getHud});
  const warp=(target,options={})=>{const token=target?.document?target:target?.object??null;if(!token)throw new Error('Pass a placed token you own.');return chooseWarp(token,options);};
  const tokenOf=target=>{const token=target?.document?target:target?.object??null;if(!token)throw new Error('Pass a placed token you own.');return token;};
  const routines=Object.freeze({list:()=>Object.entries(ROUTINES).map(([id,r])=>({id,name:r.name,hint:r.hint})),
    play:(target,id,options={})=>startRoutine(tokenOf(target),id,options),
    specimens:target=>listSpecimens(tokenOf(target))});
  /** beta.7: play the four flight manoeuvres in place on this screen. */
  const manoeuvres=Object.freeze({demo:target=>{const token=tokenOf(target),st=api()?.getState?.(token);
    if(game.settings.get(ID,'flightManoeuvres')===false)throw new Error('Flight manoeuvres are off · turn them on in Settings › Animation.');
    if(!st?.enabled||st?.effective?.mode==='grounded'||st?.rendering?.flightActive===false)throw new Error('Take off first · the manoeuvres play while she flies.');
    if(st?.effective?.reducedMotion)throw new Error('Reduced motion is on, so manoeuvres are off.');
    return startManoeuvreDemo(token);},
    // (Flight feel v10 keeps the wings fixed to her: no banks or pivots to show.)
    rigid:()=>flightFeelEnabled()});
  // A one-time tip the first time one of your characters takes off, since
  // manoeuvres are automatic and otherwise easy to miss.
  Hooks.on('updateToken',(doc,change)=>{
    const flight=change?.flags?.[ID]?.flight;if(!flight||flight.enabled!==true||!doc.isOwner)return;
    try{if(localStorage.getItem(`${ID}.manoeuvreTip`))return;localStorage.setItem(`${ID}.manoeuvreTip`,'1');}catch{return;}
    try{if(game.settings.get(ID,'flightManoeuvres')===false)return;}catch{}
    ui.notifications?.info?.(flightFeelEnabled()?'Flight manoeuvres: while she flies, her wings flare forward to brake when she stops and rise as she descends or lands; each flight mode brakes in its own way. HUD › Settings › Animation › See the manoeuvres plays them in place.':'Flight manoeuvres: while she flies, her wings bank into curves, flare when she stops, swing round when she turns back and rise as she descends. HUD › Settings › Animation › See the manoeuvres plays them in place.');
  });
  return {medkit,quickWheel,warp,routines,manoeuvres,sheet,envoyWatchOut:(target,options={})=>envoyWatchOut(tokenOf(target),options)};
}
