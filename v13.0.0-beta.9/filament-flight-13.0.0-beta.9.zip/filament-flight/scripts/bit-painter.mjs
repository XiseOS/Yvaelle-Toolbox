import {BIT_ATLAS,bitFrame} from './bit-animation.mjs?v=13.0.0-beta.9';
import {bitAssets} from './bit-assets.mjs?v=13.0.0-beta.9';
import {paintBitEnergy} from './bit-energy.mjs?v=13.0.0-beta.9';

/** Composite real animated asset frames into the existing wing layer. Additive
 * interpolation happens on a cleared scratch canvas, preventing the dimming
 * that ordinary overlapping alpha crossfades would introduce between frames. */
export function paintAnimatedBit(ctx,part,assets=bitAssets){
  const h=part.hardware;if(h.artwork!=='animated'||!h.animation)return false;
  const prepared=assets.prepare?.(h),image=prepared?null:assets.get(h.design);
  if(!prepared&&!image)return false;
  const W=prepared?.width??BIT_ATLAS.width,H=prepared?.height??BIT_ATLAS.height;
  const scratch=assets.scratch(W,H);if(!scratch)return false;
  const {canvas,context:f}=scratch;
  const frame=(row,index)=>prepared?.frame(row,index)??{image,x:index*W,y:row*H};
  const sample=(row,index)=>{const source=frame(row,index);f.drawImage(source.image,source.x,source.y,W,H,0,0,W,H);};
  const blend=layers=>{
    f.clearRect(0,0,W,H);f.save();f.globalCompositeOperation='lighter';
    for(const l of layers){
      for(const [index,alpha] of [[l.a,l.weight*(1-l.mix)],[l.b,l.weight*l.mix]])if(alpha>.0001){
        f.globalAlpha=alpha;sample(l.row,index);
      }
    }
    f.restore();return canvas;
  };
  const single=(row,frame)=>blend([{row,weight:1,...frame}]);
  const component=(row,name)=>blend((h.animation[`${name}Layers`]??[{weight:1,...h.animation[name]}]).map(l=>({row,...l})));
  const draw=(canvas,alpha=1,dx=0,dy=0)=>{ctx.globalAlpha=part.strength*alpha;ctx.drawImage(canvas,-24+dx,-36+dy,48,72);};
  const [center]=part.points;
  ctx.save();ctx.translate(center[0],center[1]);ctx.rotate(h.angle);ctx.scale(h.scale,h.scale);
  const power=Math.max(.02,Math.min(1,h.power));
  paintBitEnergy(ctx,part,'back');
  const body=blend(h.animation.layers);
  // Reflections are restricted to the opaque metal. They must never appear as
  // detached rectangular streaks or repaint the energy/core in silver.
  if(h.metalHighlights&&h.highlightStrength>0){
    f.save();f.globalCompositeOperation='source-atop';
    const row=BIT_ATLAS.components.sheen,layers=h.animation.sheenLayers??[{weight:1,...h.animation.sheen}];
    for(const frame of layers)for(const [index,weight] of [[frame.a,frame.weight*(1-frame.mix)],[frame.b,frame.weight*frame.mix]])if(weight>.0001){
      f.globalAlpha=h.highlightStrength*.7*weight;sample(row,index);
    }
    f.restore();
  }
  draw(body);
  if(h.suspendedCore){
    ctx.save();ctx.rotate(h.coreAngle??0);draw(component(BIT_ATLAS.components.core,'core'));ctx.restore();
  }
  // A powered lens with travelling bands is a separate animated layer, so
  // suppression/glitching alter energy without making the metal transparent.
  const energy=component(BIT_ATLAS.components.energy,'core');
  if(h.desync>0)draw(energy,power*h.desync*.32,h.desync*2.8,-h.desync*.8);
  draw(energy,power);
  if(h.repair>0){
    ctx.save();ctx.rotate(h.coreAngle??0);ctx.globalAlpha=part.strength*h.repair*.7;
    ctx.fillStyle='#ffc6ff';ctx.fillRect(-2.3,-8+16*(h.scan??0),4.6,.5);ctx.restore();
  }
  if(h.shutters)draw(single(BIT_ATLAS.components.shutters,bitFrame('idle',0,false,h.aperture)));
  paintBitEnergy(ctx,part,'front');
  ctx.restore();return true;
}
