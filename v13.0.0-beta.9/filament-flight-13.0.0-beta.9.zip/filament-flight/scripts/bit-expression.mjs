import {createEpisodeMove} from './bit-episode-motion.mjs?v=13.0.0-beta.9';
import {blendCoreActivities} from './bit-core-states.mjs?v=13.0.0-beta.9';
/** Cosmetic, bounded responses layered over a selected formation. Pure samples
 * use the owner's resolved state; no actor reads, timers or document writes. */
export const BIT_EXPRESSION_SITUATIONS=Object.freeze({calm:'Quiet moments',moving:'Moving and settling',damaged:'Damaged / low HP',frightened:'Frightened',stunned:'Stunned',slowed:'Slowed',fatigued:'Fatigued',quickened:'Quickened / overdrive',support:'Shared support duties'});
export const BIT_EXPRESSION_STYLES=Object.freeze({attention:'Attentive inspection',streamline:'Travel and regroup',triage:'Triage corrections',shelter:'Protective bearing',recalibrate:'Interrupted alignment',measured:'Measured precision',weary:'Recovering posture',conduct:'Coordinated surge',support:'Working together'});
const DEFAULT_MAP=Object.freeze({calm:'attention',moving:'streamline',damaged:'triage',frightened:'shelter',stunned:'recalibrate',slowed:'measured',fatigued:'weary',quickened:'conduct',support:'support'});
export const BIT_EXPRESSION_DEFAULTS=Object.freeze({expressionEnabled:true,expressionStrength:.45,expressionModes:Object.freeze(Object.fromEntries(Object.keys(BIT_EXPRESSION_SITUATIONS).map(id=>[id,'default'])))});
const IDS=['leftUpper','rightUpper','leftLower','rightLower'],TAU=Math.PI*2;
const unit=n=>Math.max(0,Math.min(1,Number(n)||0)),ease=n=>{n=unit(n);return n*n*(3-2*n);},plain=n=>n&&typeof n==='object'&&!Array.isArray(n);
const wrap=(n,period=1)=>(n%period+period)%period;
const empty=()=>({x:0,y:0,z:0,angle:0,energy:1,activity:null,intent:null,amount:0,style:null});
const REST=Object.freeze(empty());
const settingsCache=new WeakMap();
export function bitExpressionPatch(raw={}){
  if(!plain(raw))throw new Error('Bit expression settings must be an object.');
  const out={};
  for(const [key,v] of Object.entries(raw)){
    if(key==='expressionEnabled'){if(typeof v!=='boolean')throw new Error('Expression enabled must be true or false.');out[key]=v;}
    else if(key==='expressionStrength'){if(typeof v!=='number'||!Number.isFinite(v)||v<0||v>1)throw new Error('Expression strength must be between zero and one.');out[key]=v;}
    else if(key==='expressionModes'){
      if(!plain(v))throw new Error('Expression mappings must be an object.');out[key]={};
      for(const [id,style] of Object.entries(v)){
        if(!Object.hasOwn(BIT_EXPRESSION_SITUATIONS,id)||!['default','none',...Object.keys(BIT_EXPRESSION_STYLES)].includes(style))throw new Error(`Invalid bit expression mapping: ${id}.`);
        out[key][id]=style;
      }
    }else throw new Error(`Unknown bit expression setting: ${key}.`);
  }
  return out;
}
export function bitExpressionSettings(raw={}){
  const fields=Object.fromEntries(Object.keys(BIT_EXPRESSION_DEFAULTS).filter(k=>raw[k]!=null).map(k=>[k,raw[k]])),patch=bitExpressionPatch(fields);
  return {...BIT_EXPRESSION_DEFAULTS,...patch,expressionModes:{...BIT_EXPRESSION_DEFAULTS.expressionModes,...patch.expressionModes}};
}
export function mergeBitExpressions(before={},patch={}){const next=bitExpressionPatch(patch),base=bitExpressionSettings(before);return bitExpressionSettings({...base,...next,expressionModes:{...base.expressionModes,...next.expressionModes}});}
function settings(cfg){
  if(!plain(cfg))return BIT_EXPRESSION_DEFAULTS;
  let result=settingsCache.get(cfg);
  if(!result){
    // Input is already validated by resolveGemMotion. Read the resolved fields
    // directly here; never rebuild/validate nine mapping rows in a frame loop.
    result={expressionEnabled:cfg.expressionEnabled!==false,expressionStrength:cfg.expressionStrength==null?.45:unit(cfg.expressionStrength),
      expressionModes:plain(cfg.expressionModes)?cfg.expressionModes:BIT_EXPRESSION_DEFAULTS.expressionModes};
    settingsCache.set(cfg,result);
  }
  return result;
}

/** Priorities belong to the action system. A worker never abandons its patient
 * for a personality gesture; a falling bit never tries to correct its station. */
export function bitExpressionContext(flight={},time=0){
  const cfg=flight.gems??{},options=settings(cfg),response=flight.conditionResponse;
  if(!options.expressionEnabled||!options.expressionStrength||cfg.strength===0||cfg.animated===false||cfg.reactive===false||flight.effective?.reducedMotion||
    flight.bitHardwareAll||flight.bitSequenceActive&&!flight.bitActionAssignments||flight.bitActivity||response?.bits&&response.collapse?.phase&&response.collapse.phase!=='awake')return null;
  const levels=response?.bits?response.levels??{}:{},p=flight.visual?.semanticProfile??flight.visual?.profile??{},movement=flight.movement??{};
  const damage=unit(Math.max(p.damage??0,p.instability??0)),moving=unit((movement.speed??0)/2.5),duty=Object.values(flight.bitActionAssignments?.support??{}).reduce((v,s)=>Math.max(v,unit(s.amount)),0);
  const amounts={calm:1,moving,damaged:damage,frightened:unit(levels.frightened),stunned:unit(levels.stunned),slowed:unit(levels.slowed),fatigued:unit(levels.fatigued),quickened:Math.max(unit(levels.quickened),unit(((p.energy??1)-1)/.4)),support:duty};
  let primary='calm',weight=0;
  // Retain the established label priorities. Their geometry and hardware
  // contributions below remain continuously weighted through label changes.
  for(const id of ['moving','damaged','fatigued','slowed','quickened','frightened','support','stunned']){
    if(options.expressionModes[id]!=='none'&&amounts[id]>.01&&amounts[id]>=weight*.82){primary=id;weight=amounts[id];}
  }
  const selected=options.expressionModes[primary]??'default',resolve=id=>{const style=options.expressionModes[id]??'default';return style==='default'?DEFAULT_MAP[id]:style;};
  const reactionIds=['moving','damaged','fatigued','slowed','quickened','frightened','support','stunned'],reactive=reactionIds.map((id,index)=>({id,amount:amounts[id],weight:resolve(id)==='none'?0:amounts[id]**2*(1+index*.12)})).filter(v=>v.weight>0);
  const calm=resolve('calm')==='none'?0:.025,denominator=calm+reactive.reduce((sum,v)=>sum+v.weight,0),layers=[];
  if(calm&&denominator)layers.push({style:resolve('calm'),situation:'calm',amount:options.expressionStrength*unit(cfg.personality??.35)*calm/denominator});
  for(const v of reactive)layers.push({style:resolve(v.id),situation:v.id,amount:options.expressionStrength*v.amount*v.weight/denominator});
  const active=layers.filter(v=>v.amount>0);if(!active.length)return null;
  // Keep the familiar priority label for HUD/API consumers. Geometry blends
  // continuously as conditions ramp or exchange priority, rather than jumping
  // from the old label's pose to a different style at the selection threshold.
  const dominant=selected==='none'?active.reduce((a,b)=>a.amount>b.amount?a:b):null;
  return {style:dominant?.style??(selected==='default'?DEFAULT_MAP[primary]:selected),situation:dominant?.situation??primary,amount:dominant?.amount??options.expressionStrength*(primary==='calm'?unit(cfg.personality??.35):weight),
    ...(active.length>1||active[0].style!==(selected==='default'?DEFAULT_MAP[primary]:selected)||active[0].amount!==options.expressionStrength*(primary==='calm'?unit(cfg.personality??.35):weight)?{layers:active}:{}),
    time:Number.isFinite(time)?time:0,flowX:Math.max(-1,Math.min(1,movement.flowX??0)),flowY:Math.max(-1,Math.min(1,movement.flowY??0)),moving};
}

function blendActivities(features){
  const blend=blendCoreActivities(features.map(activity=>({activity,weight:1})));
  return blend?{...features.find(feature=>feature?.state===blend.state)??features[0],...blend}:null;
}
function dominantFeature(samples,key){
  let first=null,second=0;
  for(const sample of samples){const feature=sample[key];if(!(feature?.amount>0))continue;if(!first||feature.amount>first.amount){second=first?.amount??second;first=feature;}else second=Math.max(second,feature.amount);}
  // A new semantic state/intent takes over at zero strength. Its positional
  // layers already crossfade independently, without an enum-based pose switch.
  return first?{...first,amount:Math.max(0,first.amount-second)}:null;
}
function containPressure(out,point,bound){
  const pressure=bound*Math.tanh((Number(point.x)||0)/bound)**2;
  out.x=pressure>1e-12?pressure*Math.tanh(out.x/pressure):0;
  out.y=Math.max(-bound,Math.min(bound,out.y));return out;
}

/** Offsets are rig units. Attached instruments remain within twelve units of
 * their own custom anchor, even at maximum expression intensity. */
export function sampleBitExpression(context,{station='leftUpper',index=IDS.indexOf(station),count=4,point={x:0,y:0,z:0},attached=false,passive=true}={}){
  if(!context||!(context.amount>0)&&!context.layers?.some(v=>v.amount>0))return REST;
  if(context.layers){
    const samples=context.layers.map(layer=>sampleBitExpression({...context,...layer,layers:null},{station,index,count,point,attached,passive})).filter(v=>v!==REST);
    if(!samples.length)return REST;const out=empty();out.style=context.style;
    for(const sample of samples){for(const key of ['x','y','z','angle','amount'])out[key]+=sample[key];out.energy+=sample.energy-1;}
    out.activity=blendActivities(samples.map(v=>v.activity));out.intent=dominantFeature(samples,'intent');
    out.responseActivity=blendActivities(samples.map(v=>v.responseActivity));out.responseIntent=dominantFeature(samples,'responseIntent');
    return containPressure(out,point,attached?12:18);
  }
  index=Math.max(0,index);count=Math.max(1,Math.min(4,count));const {style,time:t}=context,a=unit(context.amount),q=t*.73+index*TAU/count,side=Math.tanh((Number(point.x)||0)/12);
  // Composed idle is normally at rest. Skip all temporary pose/activity
  // objects during the long gaps between gestures.
  const cycle=style==='attention'?t/29+index*.19:0,idlePhase=cycle-Math.floor(cycle);
  if(style==='attention'&&(idlePhase<=.79||idlePhase>=1))return REST;
  const out=empty(),beat=wrap(t/6+index/count),hold=ease(beat/.22)*(1-ease((beat-.55)/.45));
  out.amount=a;out.style=style;
  if(style==='attention'){
    const p=idlePhase,gesture=ease((p-.79)/.05)*(1-ease((p-.93)/.07));
    out.x=-side*5*gesture;out.y=-3*gesture;out.angle=-side*.16*gesture;out.energy=1+.07*gesture;
    out.activity={state:'scanning',amount:a*gesture,progress:p};
  }else if(style==='streamline'){
    out.x=context.flowX*(9+index*1.2)+side*2*Math.sin(q*.63);out.y=context.flowY*7+2*Math.sin(q*.81);
    out.angle=-context.flowX*.17;out.energy=1+.07*context.moving;out.activity={state:'encased',amount:a*.3};
  }else if(style==='triage'){
    const phase=wrap(t/8-index,count),check=phase<1?ease(phase/.16)*(1-ease((phase-.70)/.30)):0,rest=3*Math.sin(q*.44);
    out.x=side*(3-12*check);out.y=rest+( -5-rest)*check;out.angle=side*(.045-.295*check);
    out.energy=1+.06*hold*(1-check)+.19*check;
    out.activity=check<=.5?{state:'guarding',amount:a*.45*(1-2*check),progress:unit(phase)}:{state:'scanning',amount:a*(2*check-1),progress:unit(phase)};
    if(check>0&&passive)out.intent={kind:'mend',amount:a*check*.6,progress:unit(phase),target:[point.x-side*23,point.y+6,point.z],passive:true};
  }else if(style==='shelter'){
    out.x=-side*6+Math.sin(q*2.1)*.65;out.y=-4+Math.cos(q*.7)*2;out.angle=side*.11;out.energy=1+.12*hold;
    out.activity={state:'bracing',amount:a,progress:beat};
  }else if(style==='recalibrate'){
    const lock=ease(beat/.16)*(1-ease((beat-.25)/.22));out.x=side*4*lock;out.y=3*Math.sin(q)*lock;
    out.angle=side*.21*lock;out.energy=.86+.14*lock;out.activity={state:'aligning',amount:a,progress:beat};
  }else if(style==='measured'){
    out.x=side*2*Math.sin(t*.18+index);out.y=3*Math.cos(t*.16+index);out.angle=.045*Math.sin(t*.23+index);
    out.energy=.94;out.activity={state:'aligning',amount:a*.5,progress:beat};
  }else if(style==='weary'){
    const lift=ease(beat/.3)*(1-ease((beat-.7)/.3));out.x=side*2;out.y=9-4*lift;out.angle=side*(.13-.07*lift);
    out.energy=.85+.07*lift;out.activity={state:'resting',amount:a,progress:beat};
  }else if(style==='conduct'){
    out.x=side*(5+2*Math.sin(q));out.y=4*Math.cos(q);out.angle=.14*Math.sin(q);out.energy=1+.22*hold;
    out.activity={state:'conducting',amount:a,progress:beat};
    if(passive)out.intent={kind:'conduct',amount:a*hold*.55,progress:beat,target:[point.x-side*19,point.y-5,point.z],passive:true};
  }else if(style==='support'){
    out.x=-side*4;out.y=-4*Math.sin(q*.6);out.angle=-side*.10;out.energy=1+.2*hold;
    out.activity={state:'open',amount:a*(.6+.4*hold),progress:beat};
    if(passive)out.intent={kind:'mend',amount:a*hold*.45,progress:beat,target:[point.x-side*19,point.y+3,point.z],passive:true};
  }
  const bound=attached?12:18;out.x*=a;out.y*=a;out.angle*=a;out.energy=1+(out.energy-1)*a;
  if(context.situation!=='calm'){out.responseActivity=out.activity;out.responseIntent=out.intent;}
  return containPressure(out,point,bound);
}
export function applyCompactExpression(poses,flight,time,gain=1){
  const base=bitExpressionContext(flight,time);if(!base||gain<=0)return poses;
  const context=gain<1?{...base,amount:base.amount*ease(gain),...(base.layers?{layers:base.layers.map(layer=>({...layer,amount:layer.amount*ease(gain)}))}:{})}:base;
  let output=null,points=null,move=null;
  for(let index=0;index<poses.length;index++){
    const p=poses[index],e=sampleBitExpression(context,{station:p.station,index,count:poses.length,point:p,passive:flight.gems?.passiveEffects!==false});
    if(e===REST)continue;output??=[...poses];
    if(!move){points=poses.map(p=>[p.x,p.y,p.z]);move=createEpisodeMove(points,points,1);}
    move(index,[p.x+e.x,p.y+e.y,p.z+e.z]);
    const activityRemaining=1-unit(e.responseActivity?.amount),intentRemaining=1-unit(e.responseIntent?.amount);
    const activity=p.activity?(activityRemaining===1?p.activity:blendActivities([{...p.activity,amount:(p.activity.amount??1)*activityRemaining},e.responseActivity])):e.activity;
    const intent=p.intent?(intentRemaining===1?p.intent:dominantFeature([{intent:{...p.intent,amount:(p.intent.amount??1)*intentRemaining}},{intent:e.responseIntent}],'intent')):e.intent;
    output[index]={...p,x:points[index][0],y:points[index][1],z:p.z+e.z,angle:p.angle+e.angle,brightness:p.brightness*e.energy,
      activity,expression:e,intent};
  }
  return output??poses;
}
