import {sampleBitTool,stepScanAnchor} from './v8-scan-choreography.mjs?v=13.0.0-beta.9';
import {stepScanLocomotion,applyScanLocomotion} from './v88-scan-locomotion.mjs?v=13.0.0-beta.9';
import {sceneScanWallContext,guardScanSample} from './v88-scan-walls.mjs?v=13.0.0-beta.9';
import {guardScanOrientation} from './v884-scan-orientation.mjs?v=13.0.0-beta.9';
import {paintScanArtwork} from './v8-scan-art.mjs?v=13.0.0-beta.9';
import {paintResonantBit,sampleBitResonance} from './bit-resonance.mjs?v=13.0.0-beta.9';
import {sampleSequence} from './bit-sequences.mjs?v=13.0.0-beta.9';
import {scanSceneContext,targetScanContext} from './v82-scene-scan-context.mjs?v=13.0.0-beta.9';
import {TokenScanMaskCache,scanTokenPortrait} from './v83-token-scan-mask.mjs?v=13.0.0-beta.9';

const finite=n=>Number.isFinite(n);
let activePreview=null;
export const BIT_TOOL_LABELS=Object.freeze({areaScan:'Area scan',creatureScan:'Creature examination',parkLight:'Parked light',dispatch:'Send bits'});

/** DOM coordinates are converted through the live camera, including CSS scale. */
export function screenToWorld(point,rect,transform,screen={width:rect.width,height:rect.height}){
  const x=(point.x-rect.left)*screen.width/rect.width,y=(point.y-rect.top)*screen.height/rect.height;
  const {a=1,b=0,c=0,d=1,tx=0,ty=0}=transform??{},det=a*d-b*c;
  if(!finite(det)||Math.abs(det)<1e-8)return null;
  return {x:(d*(x-tx)-c*(y-ty))/det,y:(a*(y-ty)-b*(x-tx))/det};
}
export function worldToScreen(point,rect,transform,screen={width:rect.width,height:rect.height}){
  const {a=1,b=0,c=0,d=1,tx=0,ty=0}=transform??{};
  return {x:rect.left+(a*point.x+c*point.y+tx)*rect.width/screen.width,y:rect.top+(b*point.x+d*point.y+ty)*rect.height/screen.height};
}
export function previewTokenAt(point,tokens=[]){
  return tokens.filter(t=>!t.isPreview&&t.visible!==false&&t.isVisible!==false&&!t.destroyed&&(!t.document?.hidden||globalThis.game?.user?.isGM))
    .filter(t=>point.x>=t.x&&point.x<=t.x+t.w&&point.y>=t.y&&point.y<=t.y+t.h)
    .sort((a,b)=>(b.document?.sort??0)-(a.document?.sort??0))[0]??null;
}
/** The point test the runtime applies (scan wall guard, command preflight,
 * lantern lock): exact vision (tolerance 0, no object) at the source's
 * elevation. Pickers and previews use it so a chosen point is never accepted
 * here and refused later. */
export function viewerSeesPoint(point,source){
  if(globalThis.game?.user?.isGM)return true;
  const visibility=globalThis.canvas?.visibility;if(typeof visibility?.testVisibility!=='function')return true;
  const doc=source?.document??source,elevation=Number.isFinite(doc?.elevation)?doc.elevation:0;
  try{return visibility.testVisibility({x:point.x,y:point.y,elevation},{tolerance:0,object:null})===true;}catch{return false;}
}
/** Display name of the acting token (never a hard-coded character). */
export function tokenName(token){const name=token?.name??token?.document?.name;return typeof name==='string'&&name.trim()?name.trim():'your token';}
/** Right-button drags stay with Foundry (canvas pan). Only a short, still right
 * click (≤4 px, ≤300 ms) calls `onClick`; the browser menu is suppressed. */
export function listenRightClick(el,doc,signal,onClick){
  let down=null;
  el.addEventListener('pointerdown',event=>{if(event.button===2)down={x:event.clientX,y:event.clientY,t:event.timeStamp};},{signal,capture:true});
  doc.addEventListener('pointerup',event=>{
    if(event.button!==2||!down)return;const start=down;down=null;
    if(Math.hypot(event.clientX-start.x,event.clientY-start.y)<=4&&event.timeStamp-start.t<=300)onClick(event);
  },{signal,capture:true});
  el.addEventListener('contextmenu',event=>{event.preventDefault();event.stopImmediatePropagation();},{signal,capture:true});
  return {reset(){down=null;}};
}
const tokenFor=target=>globalThis.canvas?.tokens?.placeables?.find(t=>[t.id,t.document?.uuid].includes(target?.document?.uuid??target?.id??target));
const centerOf=token=>token?.center??{x:(token?.x??0)+(token?.w??100)/2,y:(token?.y??0)+(token?.h??100)/2};
const surface=()=>globalThis.canvas?.app?.canvas??globalThis.canvas?.app?.view??globalThis.canvas?.renderer?.view;
const rendererScreen=el=>globalThis.canvas?.app?.renderer?.screen??globalThis.canvas?.app?.screen??{width:el.clientWidth,height:el.clientHeight};

/** Production scan sample and production metal housing; only opacity differs. */
export function paintThoughtFrame(ctx,plan,elapsed,{source,snapshot={},target,thought=true,motionState=null,maskCache=null}={}){
  const size=Math.max(20,Math.max(source?.w??100,source?.h??100)),origins={};
  for(const bit of plan.sources??[])origins[bit.id]=bit.position??{x:bit.x,y:bit.y};
  const point=plan.followSource?centerOf(source):plan.point??plan.center??centerOf(target),mode=plan.kind??plan.mode;
  const utility=plan.utility??{mode,center:point,radiusPixels:plan.radiusPixels??size,radiusFeet:plan.radiusFeet,seed:plan.seed??0,scanSpeed:plan.scanSpeed,region:plan.region,weighty:plan.weighty!==false,followSource:plan.followSource===true};
  const context={source:centerOf(source),target:centerOf(target??source),size,targetSize:Math.max(target?.w??size,target?.h??size),
    targetWidth:Math.max(target?.w??size,Math.abs(target?.mesh?.width??0)),targetHeight:Math.max(target?.h??size,Math.abs(target?.mesh?.height??0)),targetRotation:target?.mesh?.rotation??((target?.document?.rotation??0)*Math.PI/180),origins,
    transform:{angle:0},orientations:Object.fromEntries((plan.sources??[]).map(b=>[b.id,b.angle??0])),snapshot};
  if(utility.followSource&&motionState){context.scanLocomotion=motionState.locomotion=stepScanLocomotion(motionState.locomotion,{source:context.source,now:elapsed,size,radius:utility.radiusPixels,reduced:!!snapshot.effective?.reducedMotion});motionState.anchor=stepScanAnchor(motionState.locomotion.teleported?null:motionState.anchor,context.source,elapsed,{radius:utility.radiusPixels,reduced:!!snapshot.effective?.reducedMotion,working:mode==='areaScan',size,motion:motionState.locomotion});context.scanCenter=motionState.anchor;}
  if(mode==='areaScan')context.gridScan=scanSceneContext({center:context.scanCenter??utility.center??context.source,radius:utility.radiusPixels});
  else if(mode==='creatureScan'){
    const attended=target??source,portrait=scanTokenPortrait(attended);
    context.target=portrait.center;context.targetWidth=portrait.width;context.targetHeight=portrait.height;context.targetRotation=portrait.rotation;
    context.targetScan={...targetScanContext(attended),portrait};
  }
  if(['areaScan','creatureScan'].includes(mode))context.scanWalls=sceneScanWallContext({source,enabled:snapshot.v8Motion?.scanWalls!==false});
  const scanEvent={...plan.event,id:plan.event?.id??'thought-preview',kind:'utility',bits:plan.bits,started:0,travelDuration:plan.travelDuration??plan.event?.travelDuration??1600,utility:plan.event?.utility??utility};
  let sample;
  if(mode==='dispatch')sample=sampleSequence({...plan.event,kind:'escort',bits:plan.bits,started:0,travelDuration:plan.travelDuration??plan.event?.travelDuration??650,group:plan.group??plan.event?.group??{},formationBits:plan.formationBits??plan.event?.formationBits??plan.bits},elapsed,{...context,targetRotation:target?.mesh?.rotation??0});
  else sample=sampleBitTool(scanEvent,elapsed,context);
  if(utility.followSource&&motionState?.locomotion){if(!context.scanWalls)applyScanLocomotion(sample,motionState.locomotion,context);else if(motionState.locomotion.active){sample.effects=[];sample.completedCells={};sample.scanWorking=0;sample.scanComplete=false;sample.scanRelocating=true;}}
  if(context.scanWalls){const guarded=guardScanSample(sample,scanEvent,context,elapsed,motionState?.wallState);sample=guarded.sample;if(motionState)motionState.wallState=guarded.state;}
  if(motionState&&['areaScan','creatureScan'].includes(mode)){
    const hardware=Object.fromEntries((plan.sources??[]).map(source=>[source.id,{hardware:{angle:source.angle??0}}]));
    const guarded=guardScanOrientation(sample,scanEvent,context,hardware,elapsed,motionState.orientations);sample=guarded.sample;motionState.orientations=guarded.state;
  }
  const effects=sample.effects??[];
  const ownsMasks=mode==='creatureScan'&&!maskCache&&!motionState;
  const masks=mode==='creatureScan'?(maskCache??(motionState?(motionState.tokenMasks??=new TokenScanMaskCache()):new TokenScanMaskCache())):null;
  const anchor=sample.effectCenter??point,scale=(sample.effectScale??1)*size/100;
  const tokenMask=masks?masks.get(target??source,{center:anchor,rotation:sample.effectRotation??0,scale}):undefined;
  if(masks)masks.retain([target??source]);
  for(const effect of effects){ctx.save();const anchor=sample.effectCenter??point;ctx.translate(anchor.x,anchor.y);ctx.rotate(sample.effectRotation??0);const scale=(sample.effectScale??1)*size/100;ctx.scale(scale,scale);paintScanArtwork(ctx,effect,{plane:'rear',thought,tokenMask});ctx.restore();}
  for(const [i,id] of plan.bits.entries()){
    const raw=sample.positions?.[id];if(!raw)continue;
    const p=Array.isArray(raw)?{x:raw[0],y:raw[1]}:raw;if(!finite(p.x)||!finite(p.y))continue;
    const flight={...snapshot,gems:{strength:.65,program:'poised',design:'vanes',assetStates:true,mechanicalResponse:true,...snapshot.gems},bitActivity:sample.coreStates?.[id]??null};
    const resonance=sampleBitResonance({flight,channels:{},side:id.startsWith('left')?-1:1,index:id.endsWith('Lower')?1:0,time:elapsed/1000,deployment:1,animated:!snapshot.effective?.reducedMotion});
    const sourcePart=plan.sources?.find(b=>b.id===id),native=sourcePart?.hardware?.hardware??sourcePart?.hardware??{};
    const part={points:[[p.x,p.y]],strength:thought?.52:1,hardware:{...native,artwork:'resonant',design:native.design??flight.gems.design??'vanes',angle:(sample.rotations?.[id]??0)+(sourcePart?.angle??0),
      scale:sourcePart?.scale??size/100*.65,power:1,resonance,glow:{strength:.25,color:'#ff00ff',direction:[0,-1]},glowMode:'core',tool:sample.tools?.[id],metalHighlights:true,highlightStrength:.45}};
    paintResonantBit(ctx,part);
  }
  for(const effect of effects){ctx.save();const anchor=sample.effectCenter??point;ctx.translate(anchor.x,anchor.y);ctx.rotate(sample.effectRotation??0);const scale=(sample.effectScale??1)*size/100;ctx.scale(scale,scale);paintScanArtwork(ctx,effect,{plane:'front',thought,tokenMask});ctx.restore();}
  if(ownsMasks)masks.destroy();
  return sample;
}

/** A single local rehearsal owns DOM/RAF only: no flags, lights, audio or jobs. */
export function startBitToolPreview({document:doc=globalThis.document,source,kind,bits,api,options={},snapshot={},onCommit=()=>{},onError=()=>{},onClose=()=>{},onEditRegion=null,editId=null}){
  activePreview?.cancel();
  const el=surface();if(!el?.getBoundingClientRect)throw new Error('The scene canvas is not ready.');
  // A detached HUD still rehearses on the scene's own browser surface.
  doc=el.ownerDocument??doc;const view=doc.defaultView;
  const Abort=view.AbortController??AbortController,events=new Abort(),signal=events.signal;
  const layer=doc.createElement('canvas');layer.className='ff-v8-thought-layer';layer.setAttribute('aria-hidden','true');doc.body.append(layer);
  const ctx=layer.getContext('2d');if(!ctx){layer.remove();throw new Error('Local canvas previews are unavailable.');}
  const strip=doc.createElement('div');strip.className='ff-v8-thought-controls';strip.setAttribute('role','dialog');strip.setAttribute('aria-label',`${editId?'Edit ':''}${BIT_TOOL_LABELS[kind]} local preview`);
  strip.innerHTML='<div><strong data-title></strong><small data-description></small></div><button type="button" data-confirm disabled>Confirm</button><button type="button" data-cancel>Cancel</button>';
  if(kind==='areaScan'&&options.region&&onEditRegion){const edit=doc.createElement('button');edit.type='button';edit.textContent='Edit shape';edit.dataset.editRegion='';strip.append(edit);}
  doc.body.append(strip);const title=strip.querySelector('[data-title]'),description=strip.querySelector('[data-description]'),confirm=strip.querySelector('[data-confirm]');
  title.textContent=`${editId?'Edit ':''}${BIT_TOOL_LABELS[kind]}`;description.textContent=kind==='creatureScan'?'Click a visible creature to examine.':options.pickTarget?'Click a visible ally to carry the light.':options.followSource?`Preparing a following scan around ${tokenName(source)}…`:'Click a visible point to place the thought preview.';
  let stopped=false,frame=0,last=-Infinity,start=null,plan=null,preparing=0,committing=false;const motionState={tokenMasks:new TokenScanMaskCache({document:doc})};
  const clean=()=>{if(stopped)return;stopped=true;preparing++;events.abort();if(frame)view.cancelAnimationFrame(frame);layer.remove();strip.remove();motionState.tokenMasks.destroy();el.style.cursor=previousCursor;if(activePreview===handle)activePreview=null;for(const [name,id]of hooks)globalThis.Hooks?.off(name,id);onClose();};
  const handle={cancel:clean,get plan(){return plan;},source:source.document?.uuid,kind};activePreview=handle;
  const previousCursor=el.style.cursor;el.style.cursor='crosshair';const hooks=[];
  if(globalThis.Hooks?.on){hooks.push(['canvasTearDown',Hooks.on('canvasTearDown',clean)]);hooks.push(['deleteToken',Hooks.on('deleteToken',token=>{if(token.id===source.id||[token.id,token.uuid].includes(plan?.target))clean();})]);}
  const prepare=async destination=>{
    const revision=++preparing;confirm.disabled=true;
    const request={kind,bits,...options,...destination};delete request.pickTarget;if(editId)delete request.scanSpeed;for(const [key,value]of Object.entries(request))if(value===undefined||key==='followSource'&&value===false)delete request[key];
    try{const proposed=editId?await api.previewEdit(source,{...request,id:editId}):await api.preview(source,request);if(stopped||revision!==preparing)return;plan=proposed;start=null;motionState.anchor=null;motionState.locomotion=null;motionState.wallState=null;motionState.orientations=null;
      description.textContent=`${editId?'Your current task continues until you confirm · ':'Only you can see this · '}${bits.length} ${bits.length===1?'bit':'bits'}${kind==='areaScan'?options.region?' · custom scan shape':` · ${plan.radiusFeet??bits.length*5} ft radius`:''} · ${options.region?'Use Edit shape to reshape the scan.':'Click again to reposition.'}`;
      confirm.disabled=false;
    }catch(error){if(stopped||revision!==preparing)return;plan=null;description.textContent=String(error.message??error);onError(error);}
  };
  const click=event=>{
    // Right button: Foundry pans; a short still right click cancels (below).
    if(event.button!==0||committing)return;event.preventDefault();event.stopImmediatePropagation();
    if(kind==='areaScan'&&options.region)return;
    const point=screenToWorld({x:event.clientX,y:event.clientY},el.getBoundingClientRect(),globalThis.canvas?.stage?.worldTransform,rendererScreen(el));if(!point)return;
    if(!viewerSeesPoint(point,source)){description.textContent='Choose a point you can see.';return;}
    if(kind==='creatureScan'||options.pickTarget){const target=previewTokenAt(point,globalThis.canvas?.tokens?.placeables);if(!target){description.textContent=options.pickTarget?'Click a visible ally token.':'Click a visible creature token.';return;}void prepare({target:target.document.uuid});}
    else void prepare({point});
  };
  el.addEventListener('pointerdown',click,{signal,capture:true});listenRightClick(el,doc,signal,clean);
  const commit=async()=>{
    if(!plan||committing||stopped)return;committing=true;confirm.disabled=true;description.textContent=editId?'Updating the working instruments…':'Sending the real instruments…';
    try{await (editId?api.edit(source,plan):api.execute(source,plan));if(!stopped){onCommit(plan);clean();}}
    catch(error){committing=false;if(stopped)return;description.textContent=String(error.message??error);confirm.disabled=false;onError(error);}
  };
  strip.querySelector('[data-edit-region]')?.addEventListener('click',()=>{const region=plan?.region??plan?.utility?.region??options.region;clean();onEditRegion?.(region);},{signal});
  confirm.addEventListener('click',()=>void commit(),{signal});strip.querySelector('[data-cancel]').addEventListener('click',clean,{signal});
  // Focus leaving the window (alt-tab, a devtools click, a hidden tab) keeps
  // the rehearsal; only Escape, Cancel or a short right click close it.
  doc.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();clean();}else if(event.key==='Enter'&&!event.target?.closest?.('input,textarea,select,button,a,[contenteditable="true"]')){event.preventDefault();void commit();}},{signal,capture:true});
  const reduced=!!snapshot.effective?.reducedMotion,fps=Math.max(12,Math.min(30,snapshot.quality?.textureFPS??24));
  const tick=now=>{
    if(stopped)return;
    if(!layer.isConnected||!source.document?.isOwner||source.destroyed){clean();return;}
    const destination=plan?.target?tokenFor(plan.target):null;
    if(plan?.target&&(!destination||destination.visible===false||destination.isVisible===false||destination.destroyed||destination.document?.hidden&&!globalThis.game?.user?.isGM)){clean();return;}
    if(now-last>=1000/fps){last=now;const dpr=Math.min(2,view.devicePixelRatio||1),w=view.innerWidth,h=view.innerHeight;
      if(layer.width!==Math.round(w*dpr)||layer.height!==Math.round(h*dpr)){layer.width=Math.round(w*dpr);layer.height=Math.round(h*dpr);}
      ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
      if(plan){start??=now;const rect=el.getBoundingClientRect(),screen=rendererScreen(el),m=globalThis.canvas?.stage?.worldTransform??{a:1,b:0,c:0,d:1,tx:0,ty:0};
        ctx.save();ctx.transform(m.a*rect.width/screen.width,m.b*rect.height/screen.height,m.c*rect.width/screen.width,m.d*rect.height/screen.height,rect.left+m.tx*rect.width/screen.width,rect.top+m.ty*rect.height/screen.height);
        const sample=paintThoughtFrame(ctx,plan,reduced?4200:now-start,{source,snapshot,target:destination,motionState});
        if(kind==='areaScan'){const p=sample.effectCenter,region=plan.region??plan.utility?.region??options.region;ctx.strokeStyle='rgba(245,185,245,.5)';ctx.lineWidth=1/Math.max(.05,m.a);ctx.setLineDash([4/Math.max(.05,m.a),7/Math.max(.05,m.a)]);ctx.beginPath();if(region?.points?.length>=3){region.points.forEach((v,i)=>i?ctx.lineTo(v.x,v.y):ctx.moveTo(v.x,v.y));ctx.closePath();}else ctx.arc(p.x,p.y,sample.scanRadius,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);}
        ctx.restore();
      }
    }
    frame=view.requestAnimationFrame(tick);
  };
  frame=view.requestAnimationFrame(tick);
  if(options.target||options.point||options.followSource||options.region)void prepare({target:options.target,point:options.point});
  return handle;
}

/** Finite hover/held-key locator. Positions come only from the owner's runtime. */
export function startBitLocator({document:doc=globalThis.document,sources=[],label='',duration=0}={}){
  const el=surface();if(!el)return ()=>{};doc=el.ownerDocument??doc;const view=doc.defaultView,layer=doc.createElement('canvas');layer.className='ff-v8-locate-layer';layer.setAttribute('aria-hidden','true');doc.body.append(layer);const ctx=layer.getContext('2d');if(!ctx){layer.remove();return ()=>{};}
  let frame=0,stopped=false,last=-Infinity,start=null;
  const stop=()=>{stopped=true;if(frame)view.cancelAnimationFrame(frame);layer.remove();};
  const tick=now=>{if(stopped)return;if(!layer.isConnected||doc.hidden){stop();return;}start??=now;if(duration&&now-start>duration){stop();return;}
    if(now-last>1000/20){last=now;const dpr=Math.min(2,view.devicePixelRatio||1),width=Math.round(view.innerWidth*dpr),height=Math.round(view.innerHeight*dpr);if(layer.width!==width||layer.height!==height){layer.width=width;layer.height=height;}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,view.innerWidth,view.innerHeight);const rect=el.getBoundingClientRect();
      for(const source of typeof sources==='function'?sources():sources){const position=source.position??source;if(!position||!finite(position.x)||!finite(position.y))continue;
        if(!globalThis.game?.user?.isGM&&globalThis.canvas?.visibility?.testVisibility&&!canvas.visibility.testVisibility(position))continue;
        const p=worldToScreen(position,rect,globalThis.canvas?.stage?.worldTransform,rendererScreen(el));ctx.strokeStyle='#f4bcf5';ctx.lineWidth=1.2;ctx.beginPath();ctx.ellipse(p.x,p.y,12,17,0,0,Math.PI*2);ctx.stroke();ctx.font='11px sans-serif';ctx.fillStyle='#fff0ff';ctx.shadowColor='#100c1d';ctx.shadowBlur=4;ctx.fillText(label||source.label||source.id,p.x+19,p.y+3);ctx.shadowBlur=0;
        const target=source.target?tokenFor(source.target):null;
        if(target&&target.visible!==false&&target.isVisible!==false&&(!target.document?.hidden||globalThis.game?.user?.isGM)){
          const center=worldToScreen(centerOf(target),rect,globalThis.canvas?.stage?.worldTransform,rendererScreen(el)),corner=worldToScreen({x:target.x,y:target.y},rect,globalThis.canvas?.stage?.worldTransform,rendererScreen(el));
          ctx.strokeStyle='rgba(244,188,245,.7)';ctx.setLineDash([3,5]);ctx.beginPath();ctx.ellipse(center.x,center.y,Math.max(16,Math.abs(center.x-corner.x)+4),Math.max(16,Math.abs(center.y-corner.y)+4),0,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);
        }
      }
    }frame=view.requestAnimationFrame(tick);
  };frame=view.requestAnimationFrame(tick);return stop;
}

/** A local aiming rehearsal. The subject lock is written only on confirmation. */
export function startLanternLockPicker({document:doc=globalThis.document,source,onConfirm=()=>{},onError=()=>{},onClose=()=>{}}={}){
  activePreview?.cancel();const el=surface();if(!el?.getBoundingClientRect)throw new Error('The scene canvas is not ready.');
  doc=el.ownerDocument??doc;const view=doc.defaultView,Abort=view.AbortController??AbortController,events=new Abort(),signal=events.signal;
  const layer=doc.createElement('canvas');layer.className='ff-v8-thought-layer';layer.setAttribute('aria-hidden','true');doc.body.append(layer);
  const ctx=layer.getContext('2d');if(!ctx){layer.remove();throw new Error('Local aiming previews are unavailable.');}
  const strip=doc.createElement('div');strip.className='ff-v8-thought-controls';strip.setAttribute('role','dialog');strip.setAttribute('aria-label','Lock lantern at a point');strip.innerHTML='<div><strong>Keep the light on a point</strong><small data-description>Click a visible point, then confirm. Your current light continues.</small></div><button type="button" data-confirm disabled>Lock point</button><button type="button" data-cancel>Cancel</button>';doc.body.append(strip);
  const confirm=strip.querySelector('[data-confirm]'),description=strip.querySelector('[data-description]'),previousCursor=el.style.cursor,hooks=[];el.style.cursor='crosshair';let stopped=false,committing=false,point=null,frame=0,last=-Infinity;
  const clean=()=>{if(stopped)return;stopped=true;events.abort();if(frame)view.cancelAnimationFrame(frame);layer.remove();strip.remove();el.style.cursor=previousCursor;for(const [name,id]of hooks)globalThis.Hooks?.off(name,id);if(activePreview===handle)activePreview=null;onClose();};
  const handle={kind:'lanternLock',source:source.document.uuid,cancel:clean};activePreview=handle;
  const visible=p=>viewerSeesPoint(p,source);
  const commit=async()=>{if(stopped||committing||!point)return;if(!source.document?.isOwner||source.destroyed||!visible(point)){description.textContent='Choose a visible point with a character you own.';return;}committing=true;confirm.disabled=true;try{await onConfirm({...point});clean();}catch(error){committing=false;if(!stopped){confirm.disabled=false;description.textContent=String(error.message??error);onError(error);}}};
  el.addEventListener('pointerdown',event=>{if(event.button!==0)return;event.preventDefault();event.stopImmediatePropagation();if(committing)return;const chosen=screenToWorld({x:event.clientX,y:event.clientY},el.getBoundingClientRect(),globalThis.canvas?.stage?.worldTransform,rendererScreen(el));if(!chosen||!visible(chosen)){description.textContent='Choose a point you can see.';return;}point=chosen;confirm.disabled=false;description.textContent='Only you can see this aim · Confirm to keep the light on this point.';},{signal,capture:true});
  listenRightClick(el,doc,signal,clean);confirm.addEventListener('click',()=>void commit(),{signal});strip.querySelector('[data-cancel]').addEventListener('click',clean,{signal});
  doc.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();clean();}else if(event.key==='Enter'&&!event.target?.closest?.('input,textarea,select,button,a,[contenteditable="true"]')){event.preventDefault();void commit();}},{signal,capture:true});
  if(globalThis.Hooks?.on)hooks.push(['canvasTearDown',Hooks.on('canvasTearDown',clean)],['deleteToken',Hooks.on('deleteToken',deleted=>{if(deleted.id===source.id)clean();})]);
  const tick=now=>{if(stopped)return;if(!source.document?.isOwner||source.destroyed||!layer.isConnected){clean();return;}if(now-last>=50){last=now;const dpr=Math.min(2,view.devicePixelRatio||1),w=view.innerWidth,h=view.innerHeight;if(layer.width!==Math.round(w*dpr)||layer.height!==Math.round(h*dpr)){layer.width=Math.round(w*dpr);layer.height=Math.round(h*dpr);}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);if(point&&visible(point)){const rect=el.getBoundingClientRect(),matrix=globalThis.canvas?.stage?.worldTransform,screen=rendererScreen(el),a=worldToScreen(centerOf(source),rect,matrix,screen),b=worldToScreen(point,rect,matrix,screen);ctx.strokeStyle='#f4bcf5';ctx.lineWidth=1.4;ctx.setLineDash([5,7]);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.setLineDash([]);ctx.beginPath();ctx.arc(b.x,b.y,9,0,Math.PI*2);ctx.stroke();}}frame=view.requestAnimationFrame(tick);};frame=view.requestAnimationFrame(tick);return handle;
}
