import {V7_DEFAULTS} from './v7-ensemble.mjs?v=13.0.0-beta.9';

/** Artwork clocks are sampled every capped paint frame. Semantic identities
 * must stay constant for the whole saved episode so worker jobs can finish. */
export function v7SemanticIdentity(v7){
 if(!v7?.enabled)return null;
 const settings=Object.fromEntries(Object.keys(V7_DEFAULTS).map(key=>[key,v7[key]]));
 return {...settings,wingDetail:v7.wingDetail,episodeKey:v7.episodeKey,appearanceRevision:v7.appearanceRevision,wingEpisode:v7.wingMotion?.name??null};
}
export function v7SemanticGems(gems){return gems?.v7?{...gems,v7:v7SemanticIdentity(gems.v7)}:gems;}
