import {startBitToolPreview,startBitLocator,startLanternLockPicker,tokenName} from './v8-tool-preview.mjs?v=13.0.1';
import {SCAN_WALL_REASONS} from './v88-scan-walls.mjs?v=13.0.1';
import {normalizeLantern} from './lantern-model.mjs?v=13.0.1';
import {LIGHT_PRESET_LABELS,lightPreset,lanternSubjectVisible} from './v88-lantern-tools.mjs?v=13.0.1';
import {DEFAULT_SCAN_SPEED,scanSpeed} from './v82-scan-clock.mjs?v=13.0.1';
import {startScanRegionPicker} from './v83-scan-region-picker.mjs?v=13.0.1';
import {SCAN_METHOD_CATALOG,effectiveScanMethods} from './v84-scan-methods.mjs?v=13.0.1';
import {ScanStyleHoverPreview} from './v881-scan-style-preview.mjs?v=13.0.1';

const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const svg=path=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"/></svg>`;
const toolsIcon=svg('M10 3 13 8 10 14 7 8ZM15 13A7 7 0 1 1 15 5M15 13 21 19M5 19H12M8 16V22');
const undoIcon=svg('M6 8A8 8 0 1 1 5 17M6 3V8H11');
const chevron=svg('M8 10 12 14 16 10');
const ids=['leftUpper','rightUpper','leftLower','rightLower'];
const scanIcons={
  structuredLight:'M4 5H20M4 9H20M4 13H20M4 17H20M8 3V20M16 3V20',
  laserTriangulation:'M3 5 20 19M21 5 4 19M8 6A6 6 0 0 1 16 6M8 18A6 6 0 0 0 16 18',
  lidarReconstruction:'M12 3V5M3 12H5M19 12H21M12 19V21M6 6 7 7M17 17 18 18M6 18 7 17M17 7 18 6M9 12A3 3 0 1 0 15 12A3 3 0 1 0 9 12',
  contourTomography:'M6 5C1 10 4 20 11 20C21 21 22 5 15 3C12 2 8 2 6 5ZM9 7C5 12 8 17 12 17C18 17 19 7 14 6C12 5 10 6 9 7ZM11 10C8 13 12 16 14 13C16 10 12 8 11 10Z',
  phaseInterferometry:'M3 8C6 2 9 14 12 8S18 2 21 8M3 16C6 10 9 22 12 16S18 10 21 16M7 3V21M17 3V21',
  radialRanging:'M12 11 13 12 12 13 11 12ZM7 12A5 5 0 1 1 12 17M3 12A9 9 0 1 1 12 21M12 12 19 5',
  sparseReconstruction:'M4 4H7V7H4ZM17 4H20V7H17ZM4 17H7V20H4ZM17 17H20V20H17ZM10 10H14V14H10ZM7 7 10 10M14 14 17 17M7 17 10 14M14 10 17 7',
  edgeTracing:'M4 8V4H8M16 4H20V8M20 16V20H16M8 20H4V16M7 14 10 9 14 7 17 12 14 16 9 17Z',
  crosshatchSurvey:'M4 5 19 20M4 11 13 20M10 4 20 14M20 5 5 20M14 4 4 14M20 11 11 20',
  geometricStructuredLight:'M3 3H21V21H3ZM4 7H20M4 12H20M4 17H20',
  geometricRadialRanging:'M3 3H21V21H3ZM7 7H17V17H7ZM10 10H14V14H10Z',
  geometricSparseReconstruction:'M3 3H21V21H3ZM9 4V20M15 4V20M4 9H20M4 15H20M6 6H6.1M12 12H12.1M18 18H18.1',
  geometricEdgeTracing:'M3 8V3H8M16 3H21V8M21 16V21H16M8 21H3V16M7 7H17V17H7ZM12 3V6M18 12H21M12 18V21M3 12H6',
  geometricCrosshatchSurvey:'M3 3H21V21H3ZM4 6 18 20M4 13 11 20M10 4 20 14M20 6 6 20M13 4 4 13M20 13 13 20'
};

function scanStyleGrid(list,group,enabled){
  return `<div class="ff-v84-scan-style-grid">${list.map(method=>`<label class="ff-v84-scan-style"><span class="ff-v84-scan-style-icon" aria-hidden="true">${svg(scanIcons[method.id]??scanIcons.structuredLight)}</span><span>${escape(method.label)}</span><input type="checkbox" data-scan-method="${escape(method.id)}" data-scan-method-group="${group}" aria-label="${escape(method.label)}" aria-description="${escape(method.description)}"${enabled.includes(method.id)?' checked':''}></label>`).join('')}</div>`;
}
function areaScanStyleFamilies(enabled){
  const soft=SCAN_METHOD_CATALOG.area.filter(method=>method.geometric!==true),geometric=SCAN_METHOD_CATALOG.area.filter(method=>method.geometric===true);
  return `<p class="ff-v86-scan-family-help">Choose soft fields, geometric fields, or mix both. Keep at least one area style enabled.</p><div class="ff-v86-scan-family" data-scan-style-family="soft"><p>Soft fields</p>${scanStyleGrid(soft,'area',enabled)}</div>${geometric.length?`<div class="ff-v86-scan-family" data-scan-style-family="geometric"><p>Geometric fields <small>Optional</small></p>${scanStyleGrid(geometric,'area',enabled)}</div>`:''}`;
}

/** Choices belong to this placed token and take effect on the next pass. */
export function renderScanMethodControls(value){
  const methods=effectiveScanMethods(value),count=methods.creature.length+methods.area.length,total=SCAN_METHOD_CATALOG.creature.length+SCAN_METHOD_CATALOG.area.length;
  return `<details class="ff-v84-scan-styles"><summary><span>Scanning styles</span><small data-scan-method-total>${count} / ${total}</small></summary><p class="ff-v8-tool-help">Choose the styles for this token. Keep at least one creature style and one area style.</p>${['creature','area'].map(group=>`<fieldset data-scan-method-fieldset="${group}"><legend>${group==='creature'?'Creature scans':'Area surveys'} <small data-scan-method-count="${group}">${methods[group].length} / ${SCAN_METHOD_CATALOG[group].length}</small></legend>${group==='area'?areaScanStyleFamilies(methods[group]):scanStyleGrid(SCAN_METHOD_CATALOG[group],group,methods[group])}</fieldset>`).join('')}<p class="ff-v84-scan-style-status" data-scan-method-status role="status" aria-live="polite">Saved for this token · Changes apply on the next pass.</p></details>`;
}

export function renderScanSpeedControl(value=DEFAULT_SCAN_SPEED,{id,caption='Scan pace'}={}){
  const speed=scanSpeed(value);return `<label class="ff-v8-light-row"><span>${escape(caption)} <output>${speed.toFixed(2)}×</output></span><input type="range" min=".25" max="1.5" step=".05" value="${speed}" data-scan-speed${id==null?'':` data-speed-job="${escape(id)}"`} aria-label="${escape(caption)}"></label>`;
}

export function renderV8InstrumentActions(model,off=false){
  const undo=model.v8Tools?.undo??{},hint=undo.available?undo.label??'Undo last bit command':undo.reason??'No bit command to undo';
  return `<span class="ff-v8-instrument-actions"><button type="button" class="ff-button ff-v8-tools-button" data-ff-action="bitTools" data-ff-key="bit-tools" aria-haspopup="dialog" aria-label="Bit tools: scan or leave a light" title="Bit tools · Scan an area, examine a creature, or leave a light"${off?' disabled':''}>${toolsIcon}</button><button type="button" class="ff-button ff-v8-undo-button" data-ff-action="undoBitCommand" data-ff-key="undo-bit-command" data-ff-write aria-label="${escape(hint)}" title="${escape(hint)}"${off||!undo.available?' disabled':''}>${undoIcon}</button></span>`;
}
export function renderV8QuickLightButton(model,off=false){
  return `<button type="button" class="ff-button ff-v8-light-adjust" data-ff-action="quickLight" data-ff-key="quick-light" aria-haspopup="dialog" aria-label="Adjust light presets, distances and lantern focus" title="Light controls · Presets, distances and lantern focus"${off?' disabled':''}>${chevron}</button>`;
}

/** Popovers and rehearsals are local UI, surviving ordinary HUD refreshes. */
export class BitToolUI{
  constructor(hud){this.hud=hud;this.popup=null;this.preview=null;this.locator=null;this.scanMethodPanels=new WeakMap();}
  api(){const api=this.hud.api();return api.bitTools??{get:token=>api.getBitToolState?.(token),preview:(token,options)=>api.previewBitTool?.(token,options),execute:(token,plan)=>api.startBitTool?.(token,plan),stop:(token,options)=>api.stopBitTool?.(token,options?.id),undo:token=>api.undoBitCommand?.(token),setScanSpeed:(token,speed,options)=>api.setBitToolScanSpeed?.(token,speed,options),setScanMethods:api.setBitToolScanMethods?(token,methods)=>api.setBitToolScanMethods(token,methods):undefined,previewEdit:api.previewBitToolEdit?(token,options)=>api.previewBitToolEdit(token,options):undefined,edit:api.editBitTool?(token,plan)=>api.editBitTool(token,plan):undefined,setPaused:api.setBitToolPaused?(token,paused,options)=>api.setBitToolPaused(token,paused,options):undefined,setExaminationMovement:api.setBitToolExaminationMovement?(token,value)=>api.setBitToolExaminationMovement(token,value):undefined};}
  state(token){try{return this.api().get?.(token)??{};}catch{return {};}}
  bind(root){
    this.root=root;
    if(this.popup){const anchor=root.querySelector(`[data-ff-action="${this.popupKind==='tools'?'bitTools':'quickLight'}"]`);if(anchor)this.position(anchor);else this.closePopover();}
  }
  validate(model){
    if(this.scanPreviewState){this.scanPreviewState.token=model.token;this.scanPreviewState.reducedMotion=model.state?.effective?.reducedMotion===true;}
    const owner=model.token?.document.uuid;
    if(this.owner&&this.owner!==owner){this.closePopover();this.preview?.cancel();this.preview=null;this.locate(false);}
    if(this.popup&&(!model.token?.document?.isOwner||model.token.destroyed))this.closePopover();
    if(this.preview&&(!model.token?.document?.isOwner||model.token.destroyed)){this.preview.cancel();this.preview=null;}
    if(this.popup&&this.popupKind==='tools'&&this.jobsHTML!=null&&model.v8Tools)this.refreshJobs(model.v8Tools);
  }
  suspend(){this.closePopover();this.preview?.cancel();this.preview=null;this.locate(false);}
  closePopover({restoreFocus=false}={}){
    const kind=this.popupKind,owner=this.owner;
    this.scanStylePreview?.destroy();this.scanStylePreview=null;
    this.scanPreviewState=null;
    this.popEvents?.abort();this.popEvents=null;this.popup?.remove();this.popup=null;
    this.root?.querySelector(`[data-ff-action="${this.popupKind==='tools'?'bitTools':'quickLight'}"]`)?.setAttribute('aria-expanded','false');
    if(restoreFocus)this.restoreFocus(kind,owner);
  }
  restoreFocus(kind=this.popupKind,owner=this.owner){
    // The HUD can be replaced while a queued command resolves. Resolve its
    // current connected anchor instead of retaining the detached old button.
    if(!this.hud.opened||this.hud.model().token?.document?.uuid!==owner)return;
    const anchor=this.root?.querySelector(`[data-ff-action="${kind==='tools'?'bitTools':'quickLight'}"]`);
    if(anchor?.isConnected&&!anchor.disabled)anchor.focus({preventScroll:true});
  }
  focusUsefulControl(popup=this.popup){
    const control=popup?.querySelector('[data-source]:not(:disabled)')??popup?.querySelector('[data-pause-job]:not(:disabled),[data-stop]:not(:disabled),[data-edit-job]:not(:disabled)')??popup?.querySelector('[data-close]');
    control?.focus({preventScroll:true});
  }
  position(anchor){
    if(!this.popup)return;const rect=anchor.getBoundingClientRect(),view=anchor.ownerDocument.defaultView,w=this.popup.offsetWidth||272,h=this.popup.offsetHeight||240;
    this.popup.style.left=`${Math.max(8,Math.min(view.innerWidth-w-8,rect.left))}px`;
    this.popup.style.top=`${rect.bottom+h+10<view.innerHeight?rect.bottom+7:Math.max(8,rect.top-h-7)}px`;
  }
  openPopover(kind,anchor,token){
    if(this.popup&&this.popupKind===kind){this.closePopover();return null;}
    this.closePopover();this.preview?.cancel();this.preview=null;this.locate(false);this.popupKind=kind;this.owner=token.document.uuid;
    const doc=anchor.ownerDocument,popup=doc.createElement('section');popup.className=`ff-v8-popover${kind==='tools'?' ff-v8-tools-popover':''}`;popup.setAttribute('role','dialog');popup.setAttribute('aria-label',kind==='tools'?'Bit tools':'Quick light adjustments');
    const style=doc.defaultView.getComputedStyle(this.root);for(const key of ['--ff-bg','--ff-panel','--ff-accent','--ff-focus','--ff-text','--ff-gold','--ff-muted','--ff-line'])popup.style.setProperty(key,style.getPropertyValue(key));
    doc.body.append(popup);this.popup=popup;anchor.setAttribute('aria-expanded','true');
    const Abort=doc.defaultView.AbortController??AbortController;this.popEvents=new Abort();const signal=this.popEvents.signal;
    doc.addEventListener('pointerdown',event=>{if(!popup.contains(event.target)&&!this.scanStylePreview?.popup?.contains(event.target)&&!anchor.contains(event.target)&&!event.target.closest?.('[data-ff-action="bitTools"],[data-ff-action="quickLight"]'))this.closePopover();},{signal,capture:true});
    doc.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();if(this.scanStylePreview?.dismiss())return;this.closePopover({restoreFocus:true});}
      if(event.key==='Tab'&&popup.contains(event.target)){const focusable=[...popup.querySelectorAll('summary,button:not(:disabled),input:not(:disabled),select:not(:disabled)')].filter(element=>!(element.tagName==='SUMMARY'?element.parentElement?.parentElement:element)?.closest?.('details:not([open])')),first=focusable[0],last=focusable.at(-1);if(event.shiftKey&&event.target===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&event.target===last){event.preventDefault();first?.focus();}}
    },{signal,capture:true});
    doc.defaultView.addEventListener('resize',()=>this.position(anchor),{signal});
    return {popup,signal};
  }
  openTools(anchor){
    const model=this.hud.model(),token=model.token;if(!token?.document?.isOwner)return;
    const opened=this.openPopover('tools',anchor,token);if(!opened)return;const {popup,signal}=opened,state=this.state(token),available=state.available??state.sources?.filter(b=>!['reserved','treatment','busy','working'].includes(b.status)).map(b=>b.id)??ids;
    const selected=(model.dispatchSelectedBits?.length?model.dispatchSelectedBits:available.slice(0,model.bitTasks?.preferredCount??4)).filter(id=>available.includes(id));
    this.toolSelection=selected;this.toolScanSpeed=scanSpeed(state.scanSpeed??state.preferences?.scanSpeed??DEFAULT_SCAN_SPEED);
    this.scanMethodPanels.set(popup,{methods:effectiveScanMethods(state.scanMethods??state.preferences?.scanMethods),saving:false});
    popup.innerHTML=`<header><strong>Bit tools</strong><button type="button" data-close aria-label="Close bit tools" title="Close">×</button></header><div class="ff-v8-tool-sources"><span>Use instruments</span><div role="group" aria-label="Instruments used for this task">${ids.map((id,i)=>{const info=state.sources?.find(b=>b.id===id),free=available.includes(id);return `<button type="button" class="ff-v8-source${selected.includes(id)?' is-selected':''}" data-source="${id}" aria-pressed="${selected.includes(id)}" aria-label="Bit ${i+1}${free?'':` unavailable: ${escape(info?.label??info?.status??'working')}`}" title="Bit ${i+1} · ${escape(info?.label??(free?'Available':'Working'))}"${free?'':' disabled'}><span aria-hidden="true">◆</span><small>${i+1}</small></button>`;}).join('')}</div></div><p class="ff-v8-tool-coverage" data-coverage></p><div class="ff-v8-tool-options"><div class="ff-v8-area-tool"><button type="button" data-tool="areaScan"><strong>Scan an area</strong><small>One square per bit · Cooperative sweeps</small></button><div class="ff-v8-area-options"><label><span>Area</span><select data-anchor aria-label="Scanning area anchor"><option value="point">Draw a region</option><option value="follow">Follow ${escape(tokenName(token))}</option></select></label><label><span>Search</span><select data-scan-mode aria-label="New area search mode"><option value="continuous">Keep searching</option><option value="once">Survey once</option></select></label><small data-follow-help hidden>Following scans keep searching.</small><label data-follow-radius hidden><span>Radius</span><input type="number" min="5" max="120" step="5" data-radius value="${Math.max(5,this.toolSelection.length*5)}" aria-label="Following scan radius in feet"><small>ft</small></label></div></div><button type="button" data-tool="creatureScan"><strong>Examine a creature</strong><small>Survey its square · Inspect the whole creature</small></button><div class="ff-v8-area-tool"><button type="button" data-tool="parkLight"><strong>Leave a light</strong><small data-park-description>One selected bit · Stays until recalled</small></button><div class="ff-v8-area-options"><label><span>Anchor</span><select data-light-anchor aria-label="Parked light anchor"><option value="point">Place at a point</option><option value="target">Follow an ally</option></select></label></div></div></div><p class="ff-v8-tool-help">Bits share one slow sweep, covering one square each. You will see a translucent rehearsal before confirming.</p>${this.renderJobs(state)}<details class="ff-v84-scan-styles ff-v8-tool-settings"><summary><span>Options</span><small>Pace · movement · styles</small></summary><div style="padding:0 9px 2px">${renderScanSpeedControl(this.toolScanSpeed,{caption:'Default pace for new scans'})}<label class="ff-v88-tool-setting"><span>Examination movement</span><select data-examination-movement aria-label="Creature examination movement"><option value="deliberate"${state.examinationMovement!=='classic'?' selected':''}>Deliberate inspection</option><option value="classic"${state.examinationMovement==='classic'?' selected':''}>Previous movement</option></select><small>Applies to new examinations. Clear inspection focuses and viewpoint handoffs; choose Previous movement to revert.</small></label>${renderScanMethodControls(this.scanMethodPanels.get(popup).methods)}</div></details>`;
    this.jobsHTML=this.renderJobs(state);this.popupJobs=state;
    // The ordinary HUD watcher already resolves this model. A hover frame
    // must not rebuild it (and capture every live instrument) at display rate.
    this.scanPreviewState={token,reducedMotion:model.state?.effective?.reducedMotion===true};
    this.scanStylePreview=new ScanStyleHoverPreview({root:popup,canOpen:()=>this.popup===popup&&this.scanPreviewState?.token===token&&token.document?.isOwner&&!token.destroyed,reducedMotion:()=>this.scanPreviewState?.reducedMotion===true});
    const update=()=>{const follow=popup.querySelector('[data-anchor]').value==='follow',radius=popup.querySelector('[data-radius]'),search=popup.querySelector('[data-scan-mode]');if(search){search.disabled=follow;if(follow)search.value='continuous';search.title=follow?'Following scans keep searching.':'';}const followHelp=popup.querySelector('[data-follow-help]');if(followHelp)followHelp.hidden=!follow;if(!radius.dataset.custom)radius.value=String(Math.max(5,this.toolSelection.length*5));popup.querySelector('[data-park-description]').textContent=this.toolSelection.length?`Bit ${ids.indexOf(this.toolSelection[0])+1} · Stays until recalled`:'Choose an instrument';popup.querySelector('[data-follow-radius]').hidden=!follow;popup.querySelector('[data-coverage]').textContent=this.toolSelection.length?`${this.toolSelection.length} ${this.toolSelection.length===1?'bit':'bits'} · ${follow?`${radius.value} ft following radius`:'Rectangle, ellipse or polygon region'}`:'Choose at least one available instrument.';for(const button of popup.querySelectorAll('[data-tool]'))button.disabled=!this.toolSelection.length;};update();
    popup.addEventListener('input',event=>{const input=event.target.closest?.('[data-scan-speed]');if(!input)return;const speed=scanSpeed(Number(input.value));input.closest('label').querySelector('output').textContent=`${speed.toFixed(2)}×`;if(!input.hasAttribute('data-speed-job'))this.toolScanSpeed=speed;},{signal});
    popup.addEventListener('toggle',()=>this.position(anchor),{signal,capture:true});
    popup.addEventListener('change',event=>{
      const movement=event.target.closest?.('[data-examination-movement]');if(movement){void this.saveExaminationMovement(movement,token);return;}
      const method=event.target.closest?.('[data-scan-method]');if(method){void this.updateScanMethod(method,token,popup);return;}
      const input=event.target.closest?.('[data-scan-speed]');if(!input)return;
      const speed=scanSpeed(Number(input.value)),id=input.dataset.speedJob;
      if(!this.api().setScanSpeed){this.hud.showMessage('Reload the scene to adjust a running scan.',true);return;}
      input.disabled=true;void Promise.resolve(this.api().setScanSpeed(token,speed,id?{id}:{})).then(()=>{this.hud.showMessage(id?'Scan pace updated':'Default pace saved for new scans');this.hud.scheduleRender(true);}).catch(error=>this.hud.fail(error)).finally(()=>{input.disabled=false;});
    },{signal});
    popup.addEventListener('change',update,{signal});popup.querySelector('[data-radius]').addEventListener('input',event=>{event.target.dataset.custom='true';update();},{signal});
    popup.addEventListener('click',event=>{
      const button=event.target.closest('button');if(!button||button.disabled)return;
      if(button.hasAttribute('data-close')){this.closePopover({restoreFocus:true});return;}
      if(button.dataset.source){const id=button.dataset.source;this.toolSelection=this.toolSelection.includes(id)?this.toolSelection.filter(b=>b!==id):ids.filter(b=>b===id||this.toolSelection.includes(b));button.classList.toggle('is-selected',this.toolSelection.includes(id));button.setAttribute('aria-pressed',String(this.toolSelection.includes(id)));update();return;}
      if(button.dataset.tool){const kind=button.dataset.tool,bits=kind==='parkLight'?this.toolSelection.slice(0,1):[...this.toolSelection],pickTarget=kind==='parkLight'&&popup.querySelector('[data-light-anchor]').value==='target',followSource=kind==='areaScan'&&popup.querySelector('[data-anchor]').value==='follow',radius=popup.querySelector('[data-radius]');if(followSource&&!radius.checkValidity()){radius.reportValidity();return;}const radiusFeet=Number(radius.value);this.closePopover();try{this.begin(kind,{bits,pickTarget,followSource,radiusFeet:followSource?radiusFeet:undefined,scanMode:kind==='areaScan'?(popup.querySelector('[data-scan-mode]')?.value??'continuous'):undefined,scanSpeed:kind==='parkLight'?undefined:this.toolScanSpeed});}catch(error){this.hud.fail(error);}return;}
      if(button.dataset.editJob){const job=((this.popupJobs??state).tasks??(this.popupJobs??state).jobs??[]).find(job=>job.id===button.dataset.editJob);if(job)this.openEdit(anchor,token,job);return;}
      if(button.dataset.pauseJob){const job=((this.popupJobs??state).tasks??(this.popupJobs??state).jobs??[]).find(job=>job.id===button.dataset.pauseJob);if(!job||!this.api().setPaused)return;button.disabled=true;void Promise.resolve(this.api().setPaused(token,!job.paused,{id:job.id})).then(()=>{this.closePopover({restoreFocus:true});this.hud.showMessage(job.paused?'Scan resumed':'Scan paused · coverage saved');this.hud.scheduleRender(true);}).catch(error=>{button.disabled=false;this.hud.fail(error);});return;}
      if(button.dataset.stop){button.disabled=true;void Promise.resolve(this.api().stop(token,{id:button.dataset.stop})).then(()=>{this.closePopover({restoreFocus:true});this.hud.showMessage('Task ending · instruments returning');this.hud.scheduleRender(true);}).catch(error=>{button.disabled=false;this.hud.fail(error);});}
    },{signal});
    this.position(anchor);this.focusUsefulControl(popup);
  }
  async updateScanMethod(input,token,popup){
    const panel=this.scanMethodPanels.get(popup),group=input.dataset.scanMethodGroup,id=input.dataset.scanMethod;
    if(!panel||!SCAN_METHOD_CATALOG[group]?.some(method=>method.id===id))return;
    const controls=[...popup.querySelectorAll('[data-scan-method]')],status=popup.querySelector('[data-scan-method-status]');
    const refresh=()=>{for(const control of controls)control.checked=panel.methods[control.dataset.scanMethodGroup].includes(control.dataset.scanMethod);for(const kind of ['creature','area'])popup.querySelector(`[data-scan-method-count="${kind}"]`).textContent=`${panel.methods[kind].length} / ${SCAN_METHOD_CATALOG[kind].length}`;popup.querySelector('[data-scan-method-total]').textContent=`${panel.methods.creature.length+panel.methods.area.length} / ${SCAN_METHOD_CATALOG.creature.length+SCAN_METHOD_CATALOG.area.length}`;};
    if(panel.saving){refresh();return;}
    const current=this.hud.model().token;
    if(!token?.document?.isOwner||!current?.document?.isOwner||token.destroyed||current.document.uuid!==token.document.uuid){refresh();status.textContent='Choose a character you own to change its scanning styles.';this.hud.showMessage(status.textContent,true);return;}
    const enabled=SCAN_METHOD_CATALOG[group].map(method=>method.id).filter(methodId=>methodId===id?input.checked:panel.methods[group].includes(methodId));
    if(!enabled.length){refresh();status.textContent=`Keep at least one ${group==='creature'?'creature scan':'area survey'} style enabled.`;this.hud.showMessage(status.textContent,true);return;}
    const api=this.api();
    if(!api.setScanMethods){refresh();status.textContent='Reload the scene to change scanning styles.';this.hud.showMessage(status.textContent,true);return;}
    const doc=input.ownerDocument,hadFocus=doc?.activeElement===input;
    panel.saving=true;for(const control of controls)control.disabled=true;status.textContent='Saving scanning styles…';
    try{
      await api.setScanMethods(token,{[group]:enabled});panel.methods={...panel.methods,[group]:enabled};refresh();
      status.textContent='Saved for this token · Changes apply on the next pass.';this.hud.scheduleRender(true);
    }catch(error){refresh();status.textContent='Styles could not be saved. Your previous choices are restored.';this.hud.fail(error);}
    finally{panel.saving=false;for(const control of controls)control.disabled=false;if(hadFocus&&this.popup===popup&&(doc.activeElement===doc.body||doc.activeElement===input))input.focus({preventScroll:true});}
  }
  refreshJobs(state){
    this.popupJobs=state;const html=this.renderJobs(state);if(html===this.jobsHTML)return;
    const active=this.popup.ownerDocument.activeElement,old=this.popup.querySelector('.ff-v8-tool-jobs');if(old?.contains(active)&&active.hasAttribute('data-scan-speed'))return;
    const focused=old?.contains(active)?Object.entries(active.dataset).find(([key])=>['editJob','pauseJob','stop'].includes(key)):null;
    // Current work sits between the actions and the folded Options.
    const settings=this.popup.querySelector('.ff-v8-tool-settings');
    this.jobsHTML=html;if(old)old.outerHTML=html;else if(html){if(settings)settings.insertAdjacentHTML('beforebegin',html);else this.popup.insertAdjacentHTML('beforeend',html);}
    if(focused){const [key,value]=focused;[...this.popup.querySelectorAll('.ff-v8-tool-jobs button')].find(button=>button.dataset[key]===value)?.focus({preventScroll:true});}
  }
  renderJobs(state){
    const jobs=state.tasks??state.jobs??[];if(!jobs.length)return '';
    return `<div class="ff-v8-tool-jobs"><small>CURRENT WORK</small>${jobs.map(job=>{
      const mode=job.mode??job.kind,name=job.name??({areaScan:'Area scan',creatureScan:'Creature examination',parkLight:'Parked light'}[mode]??'Bit task');
      const assigned=job.assignedBits??job.bits??[],count=assigned.length,yielded=(job.yieldedBits??[]).filter(id=>assigned.includes(id)).length;
      const working=Math.max(0,Math.min(count,Number.isFinite(job.workingCount)?job.workingCount:count-yielded));
      const interrupted=job.status!=='returning'&&(yielded>0||job.status==='queued'&&working<count);
      const countText=interrupted?`${working} working / ${count} assigned`:`${count} ${count===1?'bit':'bits'}`;
      const away=interrupted&&yielded?`<small class="ff-job-exception">${yielded} temporarily away · return follows the current assignment</small>`:'';
      const editable=job.editable!==false&&job.status!=='returning',once=mode==='areaScan'&&job.scanMode==='once';
      const covered=Math.max(0,Math.floor(Number(job.coveredCells)||0)),total=Math.max(0,Math.floor(Number(job.totalCells)||0));
      // Wall-guard feedback: how many bits are held and the first reason,
      // e.g. "2 bits waiting · can’t see the whole square".
      const live=!job.paused&&job.status!=='returning',waiting=Math.max(0,Math.min(count,Math.floor(Number(job.wallWaiting)||0)));
      const reason=SCAN_WALL_REASONS[job.wallReason]??null,unreachable=Math.max(0,Math.floor(Number(job.unreachableCells)||0));
      const access=live&&waiting?` · ${waiting} ${waiting===1?'bit':'bits'} waiting${reason?` · ${reason}`:''}`:once&&job.scanPending&&live?' · Waiting for route or sight access':'';
      const skipped=once&&unreachable?` · ${unreachable} ${unreachable===1?'cell':'cells'} unreachable`:'';
      return `<div class="ff-v88-job"><span>${escape(name)} <small>· ${countText}${job.status==='returning'?' · Returning':job.paused?' · Paused':mode==='areaScan'?job.scanMode==='once'?' · Survey once':' · Keep searching':''}${once?` · ${covered}/${total} cells`:''}${skipped}${escape(access)}</small>${away}</span><div class="ff-v88-job-actions">${editable?`<button type="button" data-edit-job="${escape(job.id)}" aria-label="Edit ${escape(name)}">Edit</button>`:''}${mode!=='parkLight'&&editable?`<button type="button" data-pause-job="${escape(job.id)}" aria-label="${job.paused?'Resume':'Pause'} ${escape(name)}">${job.paused?'Resume':'Pause'}</button>`:''}<button type="button" data-stop="${escape(job.id)}" title="Stop this task and return its bits" aria-label="Stop ${escape(name)}">Return</button></div></div>${mode!=='parkLight'?renderScanSpeedControl(job.scanSpeed??1,{id:job.id,caption:'Active scan pace'}):''}`;
    }).join('')}</div>`;
  }
  async saveExaminationMovement(input,token){
    const value=input.value,previous=this.state(token).examinationMovement??'deliberate',current=this.hud.model().token;
    if(!token?.document?.isOwner||current?.document?.uuid!==token.document.uuid||!current.document.isOwner){input.value=previous;this.hud.showMessage('Choose a character you own to change examination movement.',true);return;}
    if(!this.api().setExaminationMovement){input.value=previous;this.hud.showMessage('Reload the scene to change examination movement.',true);return;}
    input.disabled=true;try{await this.api().setExaminationMovement(token,value);this.hud.showMessage(value==='classic'?'Previous examination movement restored':'Deliberate examination movement saved');this.hud.scheduleRender(true);}catch(error){input.value=previous;this.hud.fail(error);}finally{input.disabled=false;}
  }
  openEdit(anchor,token,job){
    this.closePopover();this.jobsHTML=null;const opened=this.openPopover('tools',anchor,token);if(!opened)return;
    const {popup,signal}=opened,mode=job.mode??job.kind,area=mode==='areaScan',following=job.followSource===true;
    popup.innerHTML=`<header><strong>Edit ${escape(job.name??(area?'area scan':mode==='parkLight'?'parked light':'examination'))}</strong><button type="button" data-close aria-label="Cancel task edit">×</button></header><p class="ff-v8-tool-help">Your current task continues until you confirm the preview.</p>${area?`<label class="ff-v88-tool-setting"><span>Search</span><select data-edit-mode aria-label="Area search mode"${following?' disabled':''}><option value="continuous"${job.scanMode!=='once'?' selected':''}>Keep searching</option><option value="once"${job.scanMode==='once'?' selected':''}>Survey once</option></select></label>${following?`<p class="ff-v8-tool-help">Following scans keep searching.</p><label class="ff-v88-tool-setting"><span>Following radius (ft)</span><input type="number" data-edit-radius min="5" max="120" step="5" value="${escape(job.radiusFeet??20)}" aria-label="Following scan radius in feet"></label>`:'<p class="ff-v8-tool-help">Move the existing region, resize its corners, or draw a new shape.</p>'}`:mode==='parkLight'?`<label class="ff-v88-tool-setting"><span>Anchor</span><select data-edit-light-anchor aria-label="Edited light anchor"><option value="point"${!job.target?' selected':''}>Place at a point</option><option value="target"${job.target?' selected':''}>Follow an ally</option></select></label>`:'<p class="ff-v8-tool-help">Choose a visible creature to examine.</p>'}<div class="ff-v88-edit-actions"><button type="button" data-preview-edit>${area&&!following?'Edit region':'Preview changes'}</button><button type="button" data-cancel-edit>Cancel</button></div>`;
    popup.addEventListener('click',event=>{const button=event.target.closest?.('button');if(!button)return;if(button.hasAttribute('data-close')||button.hasAttribute('data-cancel-edit')){this.closePopover({restoreFocus:true});return;}if(!button.hasAttribute('data-preview-edit'))return;
      const radius=popup.querySelector('[data-edit-radius]');if(radius&&!radius.checkValidity()){radius.reportValidity();return;}
      const options={editId:job.id,bits:[...(job.assignedBits??job.bits)],target:job.target,region:job.region,point:job.point??job.center,followSource:following,scanMode:popup.querySelector('[data-edit-mode]')?.value,scanSpeed:job.scanSpeed,radiusFeet:radius?Number(radius.value):undefined,editRegion:area&&!following,pickTarget:mode==='creatureScan'||mode==='parkLight'&&popup.querySelector('[data-edit-light-anchor]').value==='target'};
      if(mode==='parkLight'&&options.pickTarget)delete options.point;else if(mode==='parkLight')delete options.target;
      this.closePopover();try{this.begin(mode,options);}catch(error){this.hud.fail(error);}
    },{signal});this.position(anchor);popup.querySelector('[data-edit-mode],[data-edit-light-anchor],[data-preview-edit]')?.focus({preventScroll:true});
  }
  begin(kind,{bits,target,point,region,pickTarget=false,followSource=false,radiusFeet,scanSpeed,scanMode,onCommit,editRegion=false,editId=null}={}){
    const model=this.hud.model(),token=model.token;if(!token?.document?.isOwner)throw new Error('Choose a token you own in the current scene.');
    const api=this.api();if(editId?(!api.previewEdit||!api.edit):(!api.preview||!api.execute))throw new Error('Bit tools require a scene reload after updating Yvaelle’s Toolbox.');
    this.closePopover();this.preview?.cancel();this.locate(false);this.owner=token.document.uuid;
    if(kind==='areaScan'&&!followSource&&(!region||editRegion)){
      this.preview=startScanRegionPicker({document:this.root?.ownerDocument??globalThis.document,source:token,region:editRegion?region:null,
        onPreview:chosen=>this.begin(kind,{bits,region:chosen,scanSpeed,scanMode,onCommit,editId}),
        onError:error=>this.hud.showMessage(String(error.message??error),true),onClose:()=>{this.preview=null;}});
      this.hud.showMessage(editId?'Edit the search region · Current scan continues':'Draw a search region · Rectangle, ellipse or polygon');
      return this.preview;
    }
    this.preview=startBitToolPreview({document:this.root?.ownerDocument??globalThis.document,source:token,kind,bits,api,editId,options:{target,point,region,pickTarget,followSource,radiusFeet,scanSpeed,scanMode},snapshot:model.state??{},
      onEditRegion:chosen=>this.begin(kind,{bits,region:chosen,scanSpeed,scanMode,onCommit,editRegion:true,editId}),
      onCommit:plan=>{onCommit?.(plan);this.hud.showMessage(`${kind==='areaScan'?'Area scan':kind==='creatureScan'?'Creature examination':kind==='parkLight'?'Parked light':'Bit dispatch'} ${editId?'updated':'confirmed'}`);this.hud.scheduleRender(true);},
      onError:error=>this.hud.showMessage(String(error.message??error),true),onClose:()=>{this.preview=null;}});
    this.hud.showMessage(editId?'Preview the changes · Current task continues until confirmation':'Local thought preview · Confirm to send the real instruments');
    return this.preview;
  }
  async undo(){
    const model=this.hud.model(),token=model.token;if(!token?.document?.isOwner||this.hud.busy)return;
    const state=this.state(token);if(!state.undo?.available){this.hud.showMessage(state.undo?.reason??'No bit command to undo');return;}
    this.preview?.cancel();this.closePopover();await this.api().undo(token);this.hud.showMessage(state.undo.label??'Last bit command undone');await this.hud.redraw(true);
  }
  openLight(anchor){
    const model=this.hud.model(),token=model.token;if(!token?.document?.isOwner)return;
    const opened=this.openPopover('light',anchor,token);if(!opened)return;const {popup,signal}=opened,lantern=normalizeLantern(model.state?.requested?.lantern??model.state?.lantern),beam=lantern.enabled,api=this.hud.api(),units=token.document.parent?.grid?.units??'scene units';
    const current={intensity:beam?lantern.intensity:model.state?.requested?.lightIntensity??model.state?.light?.intensity??1,width:lantern.width,bright:beam?lantern.bright:model.state?.requested?.lightBright??model.state?.light?.bright??model.cfg?.lightBright??lantern.bright,dim:beam?lantern.dim:model.state?.requested?.lightDim??model.state?.light?.dim??model.cfg?.lightDim??lantern.dim};
    const target=Array.from(globalThis.game?.user?.targets??[]).find(subject=>lanternSubjectVisible(subject,{source:token})),lock=lantern.lock;
    const rows=[['intensity','Brightness',0,1,.05],['width','Beam width',15,180,5],['bright',`Bright distance (${units})`,0,120,1],['dim',`Total dim distance (${units})`,0,120,1]],format=(key,value)=>key==='intensity'?`${Math.round(value*100)}%`:key==='width'?`${Math.round(value)}°`:String(value);
    popup.innerHTML=`<header><strong>${beam?'Lantern':'Circular light'}</strong><button type="button" data-close aria-label="Close light adjustments" title="Close">×</button></header><div class="ff-v88-light-presets" role="group" aria-label="Light presets">${Object.entries(LIGHT_PRESET_LABELS).map(([id,label])=>`<button type="button" data-light-preset="${id}" title="Apply your saved ${label.toLowerCase()} light">${label}</button>`).join('')}</div>${rows.map(([key,label,min,max,step])=>`<label class="ff-v8-light-row${key==='width'&&!beam?' is-muted':''}"><span>${escape(label)} <output data-${key}>${format(key,current[key])}</output></span><input type="range" min="${min}" max="${max}" step="${step}" value="${current[key]}" data-light="${key}" aria-label="${escape(key==='width'?'Lantern beam width':label)}"${key==='width'&&!beam?' disabled':''}></label>`).join('')}<details class="ff-v88-light-custom"><summary>Customize a preset</summary><label class="ff-v88-tool-setting"><span>Save into</span><select data-preset-slot aria-label="Light preset to customize">${Object.entries(LIGHT_PRESET_LABELS).map(([id,label])=>`<option value="${id}">${label}</option>`).join('')}</select></label><div class="ff-v88-edit-actions"><button type="button" data-save-preset>Save current light</button><button type="button" data-reset-preset>Reset preset</button></div><p class="ff-v8-tool-help">Slider changes leave saved presets unchanged. Reset restores the selected preset’s original values.</p></details><div class="ff-v88-light-lock"><span>${lock?model.state?.lantern?.lockStatus==='unavailable'?'Subject unavailable · holding direction':lock.type==='token'?'Following a visible subject':'Focused on a scene point':'Direction held'}</span><div class="ff-v88-edit-actions"><button type="button" data-lock-point${beam?'':' disabled'}>Lock point</button><button type="button" data-lock-target${beam&&target?'':' disabled'} title="${target?'Keep the beam on your visible targeted token':'Target a visible token first'}">Follow target</button>${lock?'<button type="button" data-unlock>Unlock</button>':''}</div></div><p class="ff-v8-tool-help">${beam?`Lock a point or target to keep it illuminated as ${escape(tokenName(token))} moves. Total dim distance includes the bright area.`:'Subject locking and beam width are available with lantern light. Shift-click the light button to use it.'}</p><p class="ff-v88-light-status" data-light-status role="status" aria-live="polite"></p>`;
    const refresh=()=>{for(const [key]of rows){const input=popup.querySelector(`[data-light="${key}"]`);input.value=String(current[key]);popup.querySelector(`[data-${key}]`).textContent=format(key,current[key]);}};
    const status=popup.querySelector('[data-light-status]'),valid=()=>this.hud.model().token?.document?.uuid===token.document.uuid&&token.document.isOwner&&!token.destroyed;
    const perform=async(button,operation,message)=>{if(!valid()){this.closePopover();return;}button.disabled=true;try{await operation();status.textContent=message;this.hud.scheduleRender(true);return true;}catch(error){this.hud.fail(error);status.textContent=String(error.message??error);return false;}finally{button.disabled=false;}};
    popup.addEventListener('input',event=>{const field=event.target.dataset.light;if(field)popup.querySelector(`[data-${field}]`).textContent=format(field,Number(event.target.value));},{signal});
    popup.addEventListener('change',event=>{const key=event.target.dataset.light;if(!key)return;const value=Number(event.target.value),input=event.target,previous=current[key];void perform(input,async()=>{await this.hud.run(beam?'lantern':key==='intensity'?'lightIntensity':key==='bright'?'lightBright':'lightDim',beam?{[key]:value}:value,token.document.uuid);current[key]=value;},'Light adjusted').then(()=>{if(current[key]===previous)refresh();});},{signal});
    popup.addEventListener('toggle',()=>this.position(anchor),{signal,capture:true});
    popup.addEventListener('click',event=>{const button=event.target.closest?.('button');if(!button||button.disabled)return;
      if(button.hasAttribute('data-close')){this.closePopover({restoreFocus:true});return;}
      if(button.dataset.lightPreset){const id=button.dataset.lightPreset;if(!api.applyLightPreset)return;void perform(button,async()=>{await api.applyLightPreset(token,id);Object.assign(current,lightPreset(lantern,id));popup.querySelector('[data-preset-slot]').value=id;refresh();},`${LIGHT_PRESET_LABELS[id]} light applied`);return;}
      if(button.hasAttribute('data-save-preset')){const id=popup.querySelector('[data-preset-slot]').value;if(!api.saveLightPreset)return;void perform(button,async()=>{await api.saveLightPreset(token,id);lantern.presets={...lantern.presets,[id]:{...current}};},`${LIGHT_PRESET_LABELS[id]} preset saved for this character`);return;}
      if(button.hasAttribute('data-reset-preset')){const id=popup.querySelector('[data-preset-slot]').value;if(!api.resetLightPreset)return;void perform(button,async()=>{await api.resetLightPreset(token,id);lantern.presets={...lantern.presets,[id]:null};},`${LIGHT_PRESET_LABELS[id]} preset reset`);return;}
      if(button.hasAttribute('data-unlock')){if(!api.unlockLantern)return;void perform(button,()=>api.unlockLantern(token),'Direction held · subject unlocked').then(ok=>{if(ok)this.closePopover();});return;}
      if(button.hasAttribute('data-lock-target')){const subject=Array.from(globalThis.game?.user?.targets??[]).find(subject=>lanternSubjectVisible(subject,{source:token}));if(!subject||!api.lockLantern){status.textContent='Target a visible token first.';return;}void perform(button,()=>api.lockLantern(token,subject),'Lantern following target').then(ok=>{if(ok)this.closePopover();});return;}
      if(button.hasAttribute('data-lock-point')){if(!api.lockLantern)return;this.closePopover();this.preview?.cancel();this.locate(false);this.preview=startLanternLockPicker({document:this.root?.ownerDocument,source:token,onConfirm:point=>api.lockLantern(token,point),onError:error=>this.hud.fail(error),onClose:()=>{this.preview=null;this.hud.scheduleRender(true);}});}
    },{signal});this.position(anchor);popup.querySelector('[data-light-preset]')?.focus({preventScroll:true});
  }
  hoverBit(id){if(this.heldLocate)return;this.showLocator(!!id,null,id?[id]:null);}
  locate(active,token=null,selected=null){this.heldLocate=active&&!selected?(token??this.hud.model().token):null;this.showLocator(active,token,selected);}
  showLocator(active,token=null,selected=null){
    this.locator?.();this.locator=null;this.locateEvents?.abort();this.locateEvents=null;for(const [name,id]of this.locateHooks??[])globalThis.Hooks?.off(name,id);this.locateHooks=[];
    if(!active)return;token??=this.hud.model().token;if(!token?.document?.isOwner||this.preview)return;
    const doc=this.root?.ownerDocument??globalThis.document;if(!doc)return;const api=this.api();
    const sources=()=>{const list=(api.get?.(token)?.sources??[]).filter(b=>b.status!=='retracted');return selected?.length?list.filter(b=>selected.includes(b.id)):list;};
    this.locator=startBitLocator({document:doc,sources});const Abort=doc.defaultView.AbortController??AbortController;this.locateEvents=new Abort();const signal=this.locateEvents.signal;
    doc.addEventListener('keydown',event=>{if(event.key==='Escape')this.locate(false);},{signal});doc.defaultView.addEventListener('blur',()=>this.locate(false),{signal});
    if(globalThis.Hooks?.on)this.locateHooks=[['canvasTearDown',Hooks.on('canvasTearDown',()=>this.locate(false))],['deleteToken',Hooks.on('deleteToken',deleted=>{if(deleted.id===token.id)this.locate(false);})]];
  }
}
