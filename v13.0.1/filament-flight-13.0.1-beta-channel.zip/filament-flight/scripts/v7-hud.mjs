import {V7_DEFAULTS} from './v7-ensemble.mjs?v=13.0.1';
import {WING_GESTURES} from './v7-wing-motion.mjs?v=13.0.1';

const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const disabled=off=>off?' disabled':'';
const selected=value=>value?' selected':'';
const button=(action,label,value='',off=false,active=false,title='')=>`<button type="button" class="ff-button${active?' is-active':''}" data-ff-action="${action}" data-ff-value="${escape(value)}" data-ff-key="v7-${action}-${escape(value)}" data-ff-write aria-pressed="${active}"${title?` title="${escape(title)}"`:''}${disabled(off)}>${escape(label)}</button>`;
const features=Object.freeze([
 ['gemInteriors','Living gemstone interiors','Separate inner layers, suspended filaments and fine veins.','gemStrength'],
 ['filamentTexture','Textured wing filaments','Fine braided strands and tension within selected ribs.','filamentStrength'],
 ['refraction','Gemstone refraction in light','Soft concentrations reshape within existing magenta illumination.','refractionStrength'],
 ['wingAnimations','Wing animation library','Manual wing gestures with smooth entrances and releases.'],
 ['formations','V7 bit formations','Eight formation families, each designed for one to four bits.'],
 ['medkit','V7 medical animations','Eight techniques and richer preparation, work and release.'],
 ['seamlessActions','Seamless action bridges','Restrained wing transitions accompanying changes of pose, flight and light.'],
 ['transitionVariants','Variation between actions','Choose a stable variation once for each action.']
]);

export function renderV7Quick(model,off=false){
 const v7=model.state?.v7;
 if(!v7?.enabled)return '';
 return `<div class="ff-v7-quick" aria-label="V7 appearance"><button type="button" class="ff-button ff-reset" data-ff-action="openAdvanced" data-ff-value="v7-experience">V7 appearance & animations</button></div>`;
}

export function renderV7Settings(model,off=false,{section='all'}={}){
 const saved=model.state?.requested?.v7??{},resolved=model.state?.v7??{};
 const state=model.state,canAnimate=resolved.enabled&&resolved.wingAnimations;
 const canPlay=canAnimate&&state?.rendering?.wingsActive&&!model.cfg.reduced;
 const inheritSelect=(key,label,description)=>`<label class="ff-select-row"><span>${escape(label)}<small>${escape(description)}</small></span><select data-ff-v7-field="${key}" data-ff-key="v7-field-${key}" data-ff-write${disabled(off)}><option value="inherit"${selected(saved[key]==null)}>Use module setting · ${resolved[key]?'on':'off'}</option><option value="on"${selected(saved[key]===true)}>On</option><option value="off"${selected(saved[key]===false)}>Off</option></select></label>`;
 const strength=key=>`<div class="ff-v7-strength"><label class="ff-select-row"><span>Strength</span><input type="number" min="0" max="1" step="0.05" value="${saved[key]??resolved[key]??V7_DEFAULTS[key]}" data-ff-v7-strength="${key}" data-ff-key="v7-strength-${key}" data-ff-write${disabled(off)}></label>${button('v7ResetField','Use module strength',key,off)}</div>`;
 const appearanceControls=`<label class="ff-select-row"><span>Appearance version</span><select data-ff-v7-field="mode" data-ff-key="v7-mode" data-ff-write${disabled(off)}><option value="inherit"${selected(saved.mode==null)}>Use module setting</option><option value="enhanced"${selected(saved.mode==='enhanced')}>V7 enhancements</option><option value="classic"${selected(saved.mode==='classic')}>Classic · 6.6.7 visuals</option></select></label>${inheritSelect('enabled','Enable V7 for this character','A master switch; individual preferences remain saved.')}<p class="ff-note">Every addition can be switched independently. Classic keeps your choices ready for later.</p>`;
 const featureControls=keys=>features.filter(([key])=>keys.includes(key)).map(([key,label,description,amount])=>`<div class="ff-v7-feature">${inheritSelect(key,label,description)}${amount?strength(amount):''}</div>`).join('');
 const wingLibrary=`<div class="ff-v7-wing-library"><h4>Wing animations</h4><div class="ff-gesture-buttons">${Object.entries(WING_GESTURES).filter(([,entry])=>entry.v9!==true||model.cfg.v9SignatureCraft===true&&canAnimate).map(([id,entry])=>`<button type="button" class="ff-button" data-ff-action="wingGesture" data-ff-value="${id}" data-ff-key="wing-gesture-${id}" data-ff-write title="${escape(entry.detail??entry.description??'')}"${disabled(off||!canPlay)}>${escape(entry.label)}</button>`).join('')}</div><div class="ff-inline-actions"><button type="button" class="ff-button" data-ff-action="previewAnimation" data-ff-value="wing"${disabled(off||!canAnimate)}>Browse & preview wings</button>${button('stopWingGesture','Release saved gesture','',off||!saved.wingGesture,false,'Release the saved gesture, including after V7 or wing animations are switched off.')}</div><p class="ff-note">${model.cfg.reduced?'Reduced motion holds the material detail and omits moving gestures.':!state?.rendering?.wingsActive?'Open the wings to play a gesture. Local previews are available while they are closed.':'Gestures flow from the current movement and release back into your saved pose.'}</p></div>`;
 const groups={
  appearance:appearanceControls+featureControls(['gemInteriors','filamentTexture','refraction']),
  animation:featureControls(['wingAnimations','seamlessActions','transitionVariants'])+wingLibrary,
  bits:featureControls(['formations']),
  medical:featureControls(['medkit'])
 };
 if(section!=='all'){
  if(!Object.hasOwn(groups,section))throw new Error(`Unknown V7 settings section ${section}.`);
  return groups[section];
 }
 return `<section class="ff-v7-settings" data-ff-setting="v7-experience" aria-label="V7 ensemble appearance"><div class="ff-section-title"><h3>V7 · Ellie’s ensemble</h3></div>${appearanceControls}${featureControls(features.map(([key])=>key))}${wingLibrary}</section>`;
}
