/** Keepsake HUD window. A frameless ApplicationV2 whose content lives in a
 * shadow root, so the Keepsake styles never touch Foundry and Foundry's never
 * touch it. The FlightHUD controller still owns the model, polling, commands,
 * pinning, look actions and bit tools; this window only presents them. */
import {KeepsakeHost,compileTemplate} from './runtime.mjs?v=13.0.1';
import {KeepsakeHome} from './home.mjs?v=13.0.1';
import {KeepsakeEffects} from './effects.mjs?v=13.0.1';
import {KeepsakeSettings,SETTINGS_SECTIONS} from './settings.mjs?v=13.0.1';
import {KeepsakePreviews} from './preview.mjs?v=13.0.1';
import {VERSION} from '../config.mjs?v=13.0.1';
import {renderClassicGroup,CLASSIC_GROUP_IDS} from '../hud-view.mjs?v=13.0.1';
import {bitPosition,bitPlacementPatch,hudSettingsRoute} from '../hud-model.mjs?v=13.0.1';
import {AUDIO_SLOTS,AUDIO_CATEGORIES} from '../audio-model.mjs?v=13.0.1';
import {readHeroPoints} from './shared.mjs?v=13.0.1';
import {installClickFx} from './click-fx.mjs?v=13.0.1';
import {skyKey} from './sky.mjs?v=13.0.1';
import {petalLeaving,rowSwayAngle,PETAL_HANDOVER_MS} from './petal-fall.mjs?v=13.0.1';
import {readFlower,readSlot,arrive,traceHero} from './petal-dom.mjs?v=13.0.1';
import {timed,keepsakeTimings} from './timings.mjs?v=13.0.1';
import {holdDecorWhileMoving,holdDecorNow} from './decor-hold.mjs?v=13.0.1';
import {keptOn} from './keep-playing.mjs?v=13.0.1';
import {KeepsakeTapestry} from './tapestry.mjs?v=13.0.1';
import {HudExtras,extrasKey} from './extras.mjs?v=13.0.1';
import {isOn as v11On} from '../v11/features.mjs?v=13.0.1';
export {keepsakeTimings};

const ID='filament-flight';
export const KEEPSAKE_UI_DEFAULTS=Object.freeze({fm:'Normal',petals:true,shiftLabels:true,hoverGuide:true,pressedSettings:['bits','looks'],favs:{},moonClock:true,heroPetals:true});
const COMPONENTS={home:KeepsakeHome,effects:KeepsakeEffects,settings:KeepsakeSettings,tapestry:KeepsakeTapestry};
/** (v11 extra) the Tapestry tab exists only while it is switched on. */
const tabOpen=tab=>!!COMPONENTS[tab]&&(tab!=='tapestry'||v11On('xTapestry'));

export const moduleRoot=()=>{const path=`modules/${ID}`;try{return (globalThis.foundry?.utils?.getRoute?.(path)??`/${path}`).replace(/\/$/,'');}catch{return `/${path}`;}};
let assets=null;
export function loadKeepsakeAssets(root=moduleRoot()){
  return assets??=(async()=>{
    const get=async name=>{const r=await fetch(`${root}/templates/keepsake/${name}?v=${encodeURIComponent(VERSION)}`);if(!r.ok)throw new Error(`Keepsake HUD file missing: ${name}`);return (await r.text()).replaceAll('%KS%',root);};
    const [shell,footer,home,menus,effects,settings,css,classicSkin,feel,controls,settingsCss,tapestry,extrasCss]=await Promise.all(['shell.html','footer.html','home.html','home-menus.html','effects.html','settings.html','keepsake.css','classic.css','feel.css','controls.css','settings.css','tapestry.html','extras.css'].map(get));
    // the classic panel's own styles, for the Detailed tuning islands (asset URLs made absolute)
    let classicCss='';try{const r=await fetch(`${root}/styles/hud.css?v=${encodeURIComponent(VERSION)}`);if(r.ok)classicCss=(await r.text()).replace(/url\((['"]?)\.\.\//g,`url($1${root}/`);}catch{}
    const page=(body,extra='')=>`${shell}\n${body}\n${footer}\n  </div>\n${extra}\n</div>`;
    return {html:{home:page(home,menus),effects:page(effects),settings:page(settings),tapestry:page(tapestry)},css:css+'\n'+feel+'\n'+settingsCss+'\n'+extrasCss,classicCss:classicCss+'\n'+classicSkin+'\n'+controls};
  })().catch(error=>{assets=null;throw error;});
}
export function keepsakeUI(){
  let raw={};try{raw=game.settings.get(ID,'keepsakeUI')??{};}catch{}
  return {...KEEPSAKE_UI_DEFAULTS,...(raw&&typeof raw==='object'?raw:{})};
}
export function registerKeepsakeSettings(){
  Hooks.once('ready',applyKeepsakeTheme);
  game.settings.register(ID,'keepsakeUI',{name:'Keepsake HUD preferences',scope:'client',config:false,type:Object,default:{...KEEPSAKE_UI_DEFAULTS}});
}
export function applyKeepsakeTheme(){
  const doc=globalThis.document;if(!doc?.body)return;
  // the classic panel was retired in beta.21, so the Keepsake theme is always on
  doc.body.classList.add('ff-keepsake');ensureFonts(doc);
  // the bit tools pop-up and the All settings window live on the page: their
  // native controls get the Keepsake look from the same file the HUD uses (beta.32)
  if(!doc.getElementById('ff-keepsake-controls')){const link=doc.createElement('link');link.id='ff-keepsake-controls';link.rel='stylesheet';
    link.href=`${moduleRoot()}/templates/keepsake/controls.css?v=${encodeURIComponent(VERSION)}`;doc.head?.append(link);}
}
/** The fonts ship with the module (styles/fonts.css, listed in module.json),
 * so nothing is fetched from Google and they work offline. Kept as a no-op
 * for the callers below. */
function ensureFonts(){}
/** One render per animation frame, however many state changes arrive in it. */
class FrameHost extends KeepsakeHost {
  schedule(){
    if(this.pending||this.destroyed)return;this.pending=true;
    const win=this.container.ownerDocument?.defaultView,go=()=>{this.pending=false;this.render();};
    if(win?.requestAnimationFrame&&!win.document?.hidden)win.requestAnimationFrame(go);else queueMicrotask(go);
  }
}
const PRELUDE=`
:host{all:initial;display:block;contain:content}
.ks-root,.ks-root *{box-sizing:border-box}
:where(.ks-root) button{font:inherit;color:inherit;cursor:pointer}
:where(.ks-root) .tab{background:none;border:0;padding:0;width:100%}
:where(.ks-root) button.lnk{background-color:transparent;border:0;padding:0;cursor:pointer;font-family:inherit}
.ks-drag{cursor:default!important}
.ks-drag button[aria-label=Close]{display:none!important}
.hv-canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
.pv-canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
.ks-tab-effects .well{height:248px}
.menu.list .opt span{white-space:normal}
.tag.cand{box-shadow:inset 0 0 0 1px #e2a256;background:#2a1a12}
.tile.is-disabled{opacity:.55;cursor:progress}
.sw.locked{opacity:.45;cursor:not-allowed}
.ks-name{flex-grow:1;min-width:0;height:30px;padding:0 9px;background:#0f080c;border:0;box-shadow:inset 0 0 0 1px #3f2b36;color:#f3eadf;font:600 12px 'Keepsake Sans',system-ui,sans-serif}
.ks-name:focus{outline:1.5px solid #e2a256;outline-offset:1px}
.ks-status{background:linear-gradient(to bottom,rgba(17,10,14,0),rgba(17,10,14,.92) 30%,rgba(17,10,14,.96));margin-left:-6px;margin-right:-6px;padding:0 6px}
`;

export function createKeepsakeApplication(controller,options={}){
  const ApplicationV2=globalThis.foundry?.applications?.api?.ApplicationV2;
  if(!ApplicationV2)throw new Error('The Keepsake HUD requires Foundry VTT 14 ApplicationV2.');
  const height=Math.max(520,Math.min((globalThis.innerHeight??900)-40,1000));
  class KeepsakeHUD extends ApplicationV2 {
    static DEFAULT_OPTIONS={id:'filament-flight-hud',tag:'section',classes:['filament-flight-hud','ks-window'],window:{frame:true,positioned:true,title:'Yvaelle’s Toolbox',icon:'fa-solid fa-feather-pointed',resizable:true,minimizable:true},position:{width:612,height}};
    constructor(opts){
      super(opts);this.tab=['home','effects','settings'].includes(controller.prefs?.tab)?controller.prefs.tab:'home';this.pending=null;this.failed=new Set();this.undoStack=[];
      this.classicFilled=new WeakMap();this.extras=new HudExtras(this);
      this.previews=new KeepsakePreviews({getModel:()=>this.model,paused:()=>!!this.minimized||!!this.asleep,onFail:name=>{this.failed.add(name);this.host?.schedule();},onPhase:phase=>{this.host?.component?.setState?.({cmpPhase:phase});}});
      this.ctx=this.makeContext();
    }
    makeContext(){
      const app=this,uuid=()=>app.model?.token?.document?.uuid;
      const fail=e=>{controller.fail(e);app.host?.schedule();return false;};
      return {
        controller,get model(){return app.model;},get tab(){return app.tab;},get pending(){return app.pending;},
        get ui(){return app.uiDraft??keepsakeUI();},
        api:()=>controller.api(),
        // HUD preferences show first and save after (beta.32): the HUD redraws from the
        // new choice on the next frame while the setting is written
        saveUI:async patch=>{
          const next={...(app.uiDraft??keepsakeUI()),...patch};app.uiDraft=next;app.uiSaving=(app.uiSaving??0)+1;app.host?.schedule();
          try{await game.settings.set(ID,'keepsakeUI',next);}
          finally{if(--app.uiSaving===0)app.uiDraft=null;app.host?.schedule();}
        },
        run:(action,value)=>Promise.resolve(controller.run(action,value,uuid())).catch(fail),
        click:(action,value)=>Promise.resolve(controller.click(action,value,uuid())).finally(()=>app.host?.schedule()),
        call:async(label,fn)=>{
          if(controller.busy){controller.showMessage('Still applying…');return false;}controller.busy=true;controller.showMessage('Applying…');
          try{await fn();controller.showMessage(label);return true;}catch(e){return fail(e);}
          finally{controller.busy=false;if(controller.opened)await controller.redraw(true);}
        },
        message:(text,failure=false)=>{if(text!==undefined){controller.showMessage(text,failure);app.host?.schedule();}return {text:controller.message,failure:controller.failure};},
        busy:()=>!!controller.busy,fail,
        refresh:()=>app.host?.schedule(),
        go:(tab,opts=null)=>app.switchTab(tab,opts),
        close:()=>app.close(),
        pushUndo:(label,fn)=>{app.undoStack.push({label,fn,target:uuid()});if(app.undoStack.length>20)app.undoStack.shift();},
        undoInfo:()=>{
          const top=app.undoStack.at(-1);if(top&&top.target===uuid())return {label:top.label,run:async()=>{app.undoStack.pop();await top.fn();controller.showMessage('Undone · '+top.label.toLowerCase());}};
          if(controller.lookUndo?.target===uuid())return {label:'Look change',run:()=>controller.click('undoLook',null,uuid())};
          try{const s=controller.toolUI?.state?.(app.model?.token);if(s?.undo?.available)return {label:s.undo.label??'Bit command',run:()=>controller.click('undoBitCommand',null,uuid())};}catch{}
          return null;
        },
        undo:async()=>{const info=app.ctx.undoInfo();if(!info){controller.showMessage('Nothing to undo yet');app.host?.schedule();return;}try{await info.run();}catch(e){fail(e);}app.host?.schedule();},
        previewFailed:name=>app.failed.has(name),
        openFullTools:e=>{const b=e?.target?.closest?.('button');controller.toolUI.root??=controller.root;controller.toolUI.openTools(b??controller.root);},
        openKeys:()=>{const C=globalThis.foundry?.applications?.sidebar?.apps?.ControlsConfig??globalThis.ControlsConfig;if(C)new C().render({force:true});},
        openAllSettings:()=>{const menu=game.settings.menus?.get?.(`${ID}.allSettings`);if(menu?.type)new menu.type().render({force:true});},
        get root(){return moduleRoot();},
        get portrait(){return `${moduleRoot()}/assets/hud/ellie-header.webp`;},
        get tokenImage(){return app.model?.token?.document?.texture?.src??`${moduleRoot()}/assets/hud/ellie-header.webp`;},
        epithet:'Little dusk',version:VERSION,
        settingsSections:SETTINGS_SECTIONS,
        // (v11) the Settings tab's Detailed tuning view fills its classic islands through the HUD
        fillClassic:()=>{try{app.fillClassic(app.host?.rootElement);}catch(e){console.warn(e);}}
      };
    }
    async _renderHTML(){
      const model=controller.model(),files=await loadKeepsakeAssets();
      return {model,files,signature:controller.signature(model),target:model.token?.document?.uuid??null};
    }
    _replaceHTML(result,content){
      this.model=result.model;controller.lastSignature=result.signature;controller.targetId=result.target;
      if(!this.host)this.mount(content,result.files);
      controller.root.dataset.ffToken=result.target??'';
      if(this.lastTarget!==result.target){this.lastTarget=result.target;this.undoStack=[];}
      this.host.render();
    }
    mount(content,files){
      const doc=content.ownerDocument;ensureFonts(doc);
      content.replaceChildren();
      const scroller=doc.createElement('div');scroller.className='ks-scroller';
      const hostEl=doc.createElement('div');hostEl.className='ks-host';scroller.append(hostEl);
      content.append(scroller);
      const shadow=hostEl.attachShadow({mode:'open'});try{installClickFx(doc);}catch{}
      const style=doc.createElement('style');style.textContent=files.classicCss+'\n'+PRELUDE+files.css;shadow.append(style);
      this.files=files;this.templates=Object.fromEntries(Object.entries(files.html).map(([k,v])=>[k,compileTemplate(doc,v)]));
      // The controller still targets this element for messages, tokens and popovers.
      controller.content=content;controller.root=hostEl;
      for(const [k,v] of Object.entries({'--ff-bg':'#160d13','--ff-panel':'#1e1219','--ff-accent':'#e767ce','--ff-focus':'#e2a256','--ff-text':'#f3eadf','--ff-gold':'#cfae76','--ff-muted':'#9c8a80','--ff-line':'#3f2b36'}))hostEl.style.setProperty(k,v);
      controller.toolUI?.bind?.(hostEl);
      const mountPoint=doc.createElement('div');mountPoint.className='ks-mount';shadow.append(mountPoint);
      // The corners keep the world's time: redraw when it moves on (beta.26).
      // (Only when they would visibly change: a calendar that ticks the clock
      // every second redraws nothing until the moon or a flower has moved.)
      try{this.skyKey=skyKey();}catch{}
      // (test.6) an extra switched on or off while the HUD is open (this browser, the world or her token) redraws it
      if(this.extrasHooks===undefined){const recheck=()=>{const k=extrasKey(this.extras?.doc);if(this.extras&&k!==this.extras.shownKey)this.host?.schedule();};
        this.extrasHooks=[['filamentFlightSettingsChanged',globalThis.Hooks?.on?.('filamentFlightSettingsChanged',recheck)],
          ['updateToken',globalThis.Hooks?.on?.('updateToken',(doc,ch)=>{if(doc===this.extras?.doc&&ch?.flags?.[ID]&&('v11' in ch.flags[ID]||'-=v11' in ch.flags[ID]))recheck();})]];}
      if(this.timeHook===undefined)this.timeHook=globalThis.Hooks?.on?.('updateWorldTime',()=>{
        if(keepsakeUI().moonClock===false)return;
        let key='';try{key=skyKey();}catch{}
        if(key!==this.skyKey){this.skyKey=key;this.host?.schedule();}
      });
      this.host=new FrameHost(mountPoint,{template:this.templates[this.tab],component:this.component(this.tab),
        afterRender:root=>{timed(this.tab+':previews',()=>this.previews.sync(root,this.host.component.previewSpecs??{}));timed(this.tab+':classic',()=>this.fillClassic(root));this.placeHeroPetals(root);this.host.component.afterRender?.(root);
          // (v11 extras) the corner petals, the turn indicator and the title row's tools; the Tapestry tab closes when it is switched off
          timed(this.tab+':extras',()=>this.extras.afterRender(root));if(!tabOpen(this.tab))queueMicrotask(()=>this.switchTab('home'));},
        onError:error=>{console.error('Yvaelle’s Toolbox | Keepsake',error);controller.fail(error);}});
      this.host.label=this.tab;hostEl.dataset.ksTab=this.tab;this.watchVisibility(hostEl);
      // (beta.35) its endless loops hold still while tokens move (decor-hold.mjs)
      this.decorRelease?.();this.decorRelease=holdDecorWhileMoving(hostEl,shadow,{surface:'hud'});this.applySleep?.();
      // Typing in the HUD never reaches Foundry's keybindings.
      this.bindClassic(shadow);
      for(const type of ['keydown','keyup'])shadow.addEventListener(type,event=>{const t=event.composedPath()[0];if(t?.matches?.('input,textarea,select'))event.stopPropagation();});
    }
    /** Fill each open Detailed tuning island with its classic group, unless someone is editing inside it.
     * An island is regenerated only when the controller's model signature, busy state or live values change. */
    fillClassic(root){
      const els=root?.querySelectorAll?.('[data-ks-classic]')??[];if(!els.length)return;
      const sig=JSON.stringify([controller.lastSignature,!!controller.busy,this.liveKey??null]);
      for(const el of els){
        const id=el.dataset.ksClassic,filled=this.classicFilled.get(el),active=el.getRootNode().activeElement,key=id+'\n'+sig;
        if(filled?.key===key)continue;
        if(filled&&el.contains(active)&&active.matches?.('input,select,textarea'))continue;
        if(this.classicDragging&&filled)continue;
        let html='';try{html=renderClassicGroup(this.model,id,{busy:!!controller.busy});}catch(e){html=`<p class="ff-note">This group could not be shown: ${String(e.message??e)}</p>`;}
        this.classicFilled.set(el,{key,html});
        if(filled?.html===html)continue;
        const open=[...el.querySelectorAll('details[open]')].map(d=>d.dataset.ffSection??d.dataset.ffGroup).filter(Boolean);
        el.innerHTML=`<div class="ff-hud ff-v3 ks-classic-body">${html}</div>`;
        for(const d of el.querySelectorAll('details'))if(open.includes(d.dataset.ffSection??d.dataset.ffGroup))d.open=true;
      }
    }
    /** Classic controls keep their meaning: actions go to controller.click, fields to controller.field. */
    bindClassic(shadow){
      this.classicEvents?.abort();this.classicEvents=new AbortController();const signal=this.classicEvents.signal;
      const inIsland=n=>n?.closest?.('[data-ks-classic]');
      const uuid=()=>this.model?.token?.document?.uuid;
      shadow.addEventListener('click',event=>{
        const button=event.target.closest?.('button');if(!button||!inIsland(button)||button.disabled)return;
        const action=button.dataset.ffAction;if(!action)return;event.preventDefault();
        const value=action==='toggleSummonFormation'?(event.shiftKey?'flow':'random'):action==='flightToggle'?{keepBits:event.shiftKey}:action==='toggleLightMode'?{lantern:event.shiftKey,keepBits:event.shiftKey}:button.dataset.ffValue;
        // "Adjust…" links inside an island open the matching Detailed tuning group (beta.21)
        if(action==='openAdvanced'){this.openDetail(value);return;}
        if(action==='allSettings'){this.ctx.openAllSettings();return;}
        if(['settingsBack','closeAdvanced','settingsLevel','gotoTab','homePanel','cycleHomePanel','toggleHomePanel'].includes(action)){if(action==='gotoTab')this.switchTab(value==='effects'?'effects':'home');return;}
        if(action==='settings'){this.ctx.openAllSettings();return;}
        void Promise.resolve(controller.click(action,value,uuid())).finally(()=>this.host?.schedule());
      });
      shadow.addEventListener('input',event=>{
        const input=event.target;if(!inIsland(input)||!input.matches?.('input'))return;
        if(input.type==='range'){for(const out of inIsland(input).querySelectorAll('[data-ff-output]'))if(out.dataset.ffOutput===input.dataset.ffField)out.textContent=input.value;
          for(const n of inIsland(input).querySelectorAll('[data-ff-numeric]'))if(n.dataset.ffNumeric===input.dataset.ffField)n.value=input.value;}
        if(input.dataset.ffLookName!==undefined)controller.lookName=input.value.slice(0,40);
      });
      shadow.addEventListener('change',event=>{
        const input=event.target;if(!inIsland(input)||input.dataset.ffSearch!==undefined)return;
        if(input.dataset.ffLookName!==undefined)return;
        if(input.dataset.ffBitSelect!==undefined){controller.bitSelection=input.value;this.fillClassicForce();return;}
        void Promise.resolve(controller.field(input,uuid())).finally(()=>this.host?.schedule());
      });
      shadow.addEventListener('pointerdown',event=>{
        if(!inIsland(event.target))return;
        if(event.target.matches?.('input[type=range]'))this.classicDragging=true;
        const bit=event.target.closest?.('[data-ff-bit-station]');if(bit&&!bit.disabled&&event.button===0){this.classicDragging=true;controller.beginBitDrag(event,bit);}
      });
      shadow.ownerDocument.addEventListener('pointermove',event=>{if(controller.bitDrag)controller.moveBitDrag(event);},{signal});
      shadow.ownerDocument.addEventListener('pointerup',event=>{if(controller.bitDrag)void controller.endBitDrag(event);},{signal});
      shadow.ownerDocument.addEventListener('pointerup',()=>{if(this.classicDragging){this.classicDragging=false;this.host?.schedule();}},{signal});
      shadow.addEventListener('keydown',event=>{
        const bit=event.target.closest?.('[data-ff-bit-station]');if(!bit||!inIsland(bit)||bit.disabled)return;
        if(event.key==='Escape'&&controller.bitDrag){event.preventDefault();controller.cancelBitDrag();return;}
        if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;
        event.preventDefault();event.stopPropagation();if(controller.busy)return;
        controller.bitSelection=bit.dataset.ffBitStation;
        const p=bitPosition(controller.bitPlacementRequest(),controller.bitSelection),step=event.shiftKey?.1:.01;
        const patch=bitPlacementPatch(controller.bitSelection,p.x+(event.key==='ArrowRight'?step:event.key==='ArrowLeft'?-step:0),p.y+(event.key==='ArrowDown'?step:event.key==='ArrowUp'?-step:0));
        controller.paintBitPosition(controller.bitSelection,{x:patch[`${controller.bitSelection}X`],y:patch[`${controller.bitSelection}Y`]});
        void controller.saveBitPlacement(patch,uuid()).catch(e=>controller.fail(e));
      },{signal});
      shadow.addEventListener('toggle',event=>{
        const d=event.target;if(!inIsland(d)||d.tagName!=='DETAILS')return;
        // Sound categories and slots render their body only once remembered as open
        const audioKey=d.dataset.ffAudioOpen;
        if(audioKey){const open=controller.prefs.audioOpen??[];if(open.includes(audioKey)===d.open)return;
          void controller.savePreferences({audioOpen:d.open?[...open,audioKey]:open.filter(k=>k!==audioKey)}).then(()=>this.fillClassicForce()).catch(e=>controller.fail(e));return;}
        const key=d.dataset.ffSection;if(!key)return;const open=controller.prefs.openSections??[];
        if(open.includes(key)===d.open)return;
        void controller.savePreferences({openSections:d.open?[...open,key]:open.filter(k=>k!==key)});
      },true);
    }
    fillClassicForce(){this.classicFilled=new WeakMap();this.host?.schedule();}
    /** Hero petals (beta.28): a new one is one of the Nytheris's own petals
     * (the flower in the top left corner): it comes loose and floats down to
     * its place, and the flower grows it back once it has landed; each new
     * point takes a petal of its own. A spent one lifts and floats the whole
     * way down. Each change flies once, in the HUD's sky (the renderer leaves
     * it alone, so the header can redraw meanwhile); a new petal's place
     * stays empty until it lands. */
    placeHeroPetals(root){
      const moving=root?.querySelectorAll?.('.hero-row .hp.arriving, .hero-row .hp.leaving');if(!moving?.length)return;
      const flown=this.heroFlown??=new Set();
      const fresh=[...moving].filter(hp=>{const key=`${hp.dataset.k}:${hp.dataset.at}`;if(flown.has(key))return false;flown.add(key);return true;});
      if(flown.size>60)for(const key of [...flown].slice(0,flown.size-60))flown.delete(key);
      if(!fresh.length)return;
      const sky=root.querySelector('.hp-sky'),corner=root.querySelector('svg.corner'),view=root.ownerDocument.defaultView;
      // (Frame motion Off stills the frame's loops; a Hero Point won or spent still flies, unless motion is reduced)
      const still=!sky?'no sky layer':root.classList.contains('ks-reduced')||view?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches?'still (reduced motion)':null;
      traceHero({where:'hud',moving:fresh.length,did:still??'flies'});
      if(still)return;
      const R=root.getBoundingClientRect(),scale=R.width/(root.offsetWidth||R.width)||1,toLayer=(x,y)=>({x:(x-R.left)/scale,y:(y-R.top)/scale});
      const host=root.getRootNode?.()?.host,win=host?.closest?.('.window-content')??host;
      const floor=Math.min(R.bottom,win?.getBoundingClientRect?.().bottom??R.bottom,view?.innerHeight??R.bottom);
      const arriving=fresh.filter(hp=>hp.classList.contains('arriving')),leaving=fresh.filter(hp=>hp.classList.contains('leaving')).reverse();
      const air=this.heroAir??=new Map();   // slot → the new petal on its way there
      const n={arriving:0,leaving:0};let flower=null;
      [...arriving,...leaving].forEach(hp=>{
        const kind=hp.classList.contains('arriving')?'arriving':'leaving',k=hp.dataset.k,on=air.get(k);
        // spent before it landed: it fades where it is (there's nothing in the row to lift);
        // a spent one still floating away when it comes back just carries on, and a new one falls
        if(kind==='leaving'&&on?.fly.isConnected){air.delete(k);on.fade();return;}
        const P=hp.getBoundingClientRect();if(!P.width)return;
        if(kind==='arriving'){
          const delay=n.arriving++*700;
          flower??=readFlower(corner,[...(corner?.querySelectorAll('g.ny')??[])].map(g=>({el:g,shape:g.querySelector('use'),rib:g.querySelector('path')})),toLayer);
          // (its place sways on the page's clock meanwhile, so the petal can land at the angle it's at)
          const sway=hp.getAnimations?.().find(a=>a.animationName==='hpSway');let angleAt=()=>0;
          if(sway){try{sway.startTime=0;const t=sway.effect.getComputedTiming(),dur=Number(t.duration)||5600,dl=Number(t.delay)||0;angleAt=at=>rowSwayAngle(at-dl,dur);}catch{}}
          const flight=arrive({layer:sky,cls:'hp-fly in',petals:flower,slot:readSlot(hp,+hp.getAttribute('width')||16,+hp.getAttribute('height')||20,toLayer),delay,angleAt,rib:true});
          if(!flight){traceHero({where:'hud',did:`no petal on the flower (${flower.length} read)`});return;}   // (no petal left to take: it simply appears)
          // its place in the row stays empty until it lands, then a short cross-fade hands over
          const wait=Math.max(1,flight.end-Date.now()),total=wait+PETAL_HANDOVER_MS;
          const hold=hp.animate([{opacity:0,offset:0},{opacity:0,offset:wait/total},{opacity:1,offset:1}],{duration:total});
          const rec={fly:flight.el,fade:()=>{hold.cancel();flight.fade(PETAL_HANDOVER_MS);}};
          air.set(k,rec);
          flight.landed.then(()=>{if(air.get(k)===rec)air.delete(k);flight.handover(PETAL_HANDOVER_MS);},()=>{});
          return;
        }
        const delay=n.leaving++*450,spec=petalLeaving({fall:(floor-P.bottom)/scale-30});
        const fly=hp.cloneNode(true);fly.setAttribute('class','hp-fly');fly.removeAttribute('style');fly.removeAttribute('data-k');fly.removeAttribute('data-at');
        fly.style.cssText=`left:${(P.left-R.left)/scale}px;top:${(P.top-R.top)/scale}px;width:${P.width/scale}px;height:${P.height/scale}px`;
        sky.append(fly);
        const done=()=>fly.remove();
        fly.animate(spec.keyframes,{duration:spec.duration,delay,easing:spec.easing,fill:'both'}).finished.then(done,done);
      });
    }
    /** Open the Detailed tuning group a classic route points to, unfolding any sound category it names. */
    openDetail(id){
      const route=hudSettingsRoute(id);
      if(!route||!CLASSIC_GROUP_IDS.includes(route.group)){this.switchTab('settings',{level:'Everything'});return;}
      if(route.group==='audio'&&route.id.startsWith('control:audio:')){
        const [kind,key]=route.id.slice('control:audio:'.length).split(':'),needed=[];
        if(kind==='slots'&&AUDIO_SLOTS[key])needed.push(`category:${AUDIO_SLOTS[key].category}`,`slot:${key}`);
        else if(kind==='categories'&&AUDIO_CATEGORIES[key])needed.push(`category:${key}`);
        else if(['crossfadeMs','movementSensitivity','cooldownMs'].includes(kind))needed.push('advanced');
        if(needed.length)void controller.savePreferences({audioOpen:[...new Set([...needed,...(controller.prefs.audioOpen??[])])]}).then(()=>this.fillClassicForce()).catch(()=>{});
      }
      this.switchTab('settings',{detail:route.group});
      this.fillClassicForce();
    }
    component(tab){
      const C=COMPONENTS[tab]??KeepsakeHome;const c=new C({ctx:this.ctx});this.pending=null;return c;
    }
    switchTab(tab,opts=null){
      if(!tabOpen(tab))return;
      if(tab===this.tab&&!opts)return;
      this.pending=opts;this.tab=tab;this.failed.clear();this.previews.destroy();
      const comp=new COMPONENTS[tab]({ctx:this.ctx});this.pending=null;
      this.host.label=tab;if(controller.root)controller.root.dataset.ksTab=tab;timed('switch:'+tab,()=>this.host.setTemplate(this.templates[tab],comp));
      this.element?.querySelector('.ks-scroller')?.scrollTo({top:0});
      this.fadeInTab();
      void controller.savePreferences({tab}).catch(()=>{});
    }
    /** A tab's page eases in (a short rise and fade) instead of popping (menus pass, beta.32). */
    fadeInTab(){
      const root=this.host?.rootElement,win=root?.ownerDocument?.defaultView;if(!root?.animate)return;
      if(win?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches)return;
      const full=!root.classList.contains('fm-off');let i=0;
      for(const el of root.querySelector('.ks-content')?.children??[]){
        if(el.classList.contains('ks-status')||el.matches('.menu,.scrim'))continue;
        try{el.animate(full?[{opacity:0,transform:'translateY(6px)'},{opacity:1,transform:'none'}]:[{opacity:0},{opacity:1}],{duration:180,delay:Math.min(i++,4)*22,easing:'cubic-bezier(.2,.8,.2,1)',fill:'backwards'});}catch{}
      }
    }
    drag(event){
      const start={x:event.clientX,y:event.clientY,left:this.position.left,top:this.position.top},win=event.target.ownerDocument.defaultView;
      const move=e=>this.setPosition({left:start.left+e.clientX-start.x,top:start.top+e.clientY-start.y});
      const up=()=>{win.removeEventListener('pointermove',move);win.removeEventListener('pointerup',up);};
      win.addEventListener('pointermove',move);win.addEventListener('pointerup',up);
    }
    resize(event){
      event.preventDefault();const start={y:event.clientY,h:this.position.height},win=event.target.ownerDocument.defaultView;
      const move=e=>this.setPosition({height:Math.max(420,start.h+e.clientY-start.y)});
      const up=()=>{win.removeEventListener('pointermove',move);win.removeEventListener('pointerup',up);};
      win.addEventListener('pointermove',move);win.addEventListener('pointerup',up);
    }
    onControllerMessage(){this.host?.schedule();}
    /** Live values the controller's signature does not cover: HP, unconsciousness and timers. */
    onModel(model){
      const hp=model.hp,t=model.state?.temporaryCondition,hero=readHeroPoints(model.token?.document?.actor);
      const key=JSON.stringify([hp?.value,hp?.max,hp?.temp,hp?.unconscious,t?.active?Math.ceil((t.started+t.duration-model.now)/1000):0,model.header?.text,hero?.value,hero?.max]);
      if(key===this.liveKey)return;this.liveKey=key;this.model=model;this.host?.schedule();
    }
    _onPosition(position){super._onPosition?.(position);if(this._ffPositioned)controller.rememberPosition(position);this._ffPositioned=true;}
    async _preClose(options){
      const pos=this.position;this.previews.destroy();controller.suspend();
      if(pos&&['left','top','width','height'].every(k=>Number.isFinite(pos[k])))await controller.savePreferences({position:Object.fromEntries(['left','top','width','height'].map(k=>[k,pos[k]]))});
      await super._preClose(options);
    }
    /** The frame's ambient motion and the live previews sleep while nobody can
     * see them (beta.34): the HUD minimised, the browser tab in the background,
     * the HUD scrolled or moved off the screen, or covered by another window
     * (IntersectionObserver v2; only trusted once it has reported "visible",
     * so a browser that can't tell never freezes the HUD).
     * (beta.40) Keep playing: covered only in part, the loops chosen in
     * Settings › Keep playing go on (the rest hold, decor-hold.mjs); covered
     * completely (nothing of it on top anywhere), it sleeps as before. */
    watchVisibility(hostEl){
      this.sleepEvents?.abort();this.sleepObserver?.disconnect();this.stopBuriedWatch?.();
      const doc=hostEl.ownerDocument,win=doc.defaultView,why=this.sleepWhy=new Set();this.sleepEvents=new AbortController();
      this.applySleep=()=>{
        const asleep=why.size>0,soft=asleep&&[...why].every(r=>r==='covered')&&!!keptOn('hud',win).selector;
        this.asleep=asleep;
        if(hostEl.hasAttribute('data-ks-asleep')!==(asleep&&!soft))hostEl.toggleAttribute('data-ks-asleep',asleep&&!soft);
        holdDecorNow(hostEl,soft);
      };
      this.setSleep=(reason,on)=>{if(why.has(reason)===!!on)return;on?why.add(reason):why.delete(reason);
        if(reason==='covered')on?watchBuried():this.stopBuriedWatch?.();
        this.applySleep();};
      const tab=()=>this.setSleep('tab',!!doc.hidden);doc.addEventListener('visibilitychange',tab,{signal:this.sleepEvents.signal});tab();
      // (a Keep playing switch flipped: the HUD's sleep is worked out again)
      const hook=globalThis.Hooks?.on?.('filamentFlightSettingsChanged',()=>this.applySleep?.());
      this.sleepEvents.signal.addEventListener('abort',()=>{try{globalThis.Hooks?.off?.('filamentFlightSettingsChanged',hook);}catch{}},{once:true});
      // Covered: is any of it still on top? 16 points across it, once a second while it is covered.
      const buried=()=>{const r=hostEl.getBoundingClientRect(),vw=win?.innerWidth??0,vh=win?.innerHeight??0;
        const x0=Math.max(0,r.left),x1=Math.min(vw,r.right),y0=Math.max(0,r.top),y1=Math.min(vh,r.bottom);if(x1<=x0||y1<=y0)return true;
        for(let i=0;i<4;i++)for(let j=0;j<4;j++){const top=doc.elementFromPoint(x0+(x1-x0)*(i+.5)/4,y0+(y1-y0)*(j+.5)/4);if(top&&(top===hostEl||hostEl.contains(top)))return false;}
        return true;};
      const watchBuried=()=>{this.stopBuriedWatch?.();const check=()=>{try{this.setSleep('buried',buried());}catch{}};const t=win?.setInterval?.(check,1000);check();
        this.stopBuriedWatch=()=>{win?.clearInterval?.(t);this.stopBuriedWatch=null;this.setSleep('buried',false);};};
      this.sleepEvents.signal.addEventListener('abort',()=>this.stopBuriedWatch?.(),{once:true});
      if(typeof win?.IntersectionObserver!=='function'){this.applySleep();return;}
      let trusted=false;
      const seen=entries=>{for(const e of entries){this.setSleep('offscreen',!e.isIntersecting);
        if(e.isVisible===true)trusted=true;if(trusted&&'isVisible' in e)this.setSleep('covered',e.isIntersecting&&!e.isVisible);}};
      try{this.sleepObserver=new win.IntersectionObserver(seen,{trackVisibility:true,delay:250});}catch{try{this.sleepObserver=new win.IntersectionObserver(seen);}catch{this.applySleep();return;}}
      this.sleepObserver.observe(hostEl);this.applySleep();
    }
    async minimize(...a){const r=await super.minimize?.(...a);this.setSleep?.('minimised',true);return r;}
    async maximize(...a){const r=await super.maximize?.(...a);this.setSleep?.('minimised',false);return r;}
    _onClose(options){
      this.decorRelease?.();this.decorRelease=null;
      this.sleepEvents?.abort();this.sleepObserver?.disconnect();this.sleepObserver=null;
      if(this.timeHook!==undefined){globalThis.Hooks?.off?.('updateWorldTime',this.timeHook);this.timeHook=undefined;}
      for(const [n,id] of this.extrasHooks??[])try{globalThis.Hooks?.off?.(n,id);}catch{}this.extrasHooks=undefined;
      this.extras?.detach();this.classicEvents?.abort();this.host?.destroy();this.host=null;controller.release(this);super._onClose(options);
    }
  }
  let position=options.position?{...options.position,width:612}:{width:612,height};
  // First opening: sit beside the sidebar, never on top of the chat.
  if(!controller.prefs?.position){
    const vw=globalThis.innerWidth??1280,sidebar=globalThis.document?.getElementById('sidebar')?.offsetWidth||320;
    position={...position,left:Math.max(10,vw-612-sidebar-24),top:Math.max(10,position.top??60)};
  }
  return new KeepsakeHUD({...options,position});
}
