/** v10 beta · Versions. One switch per overhauled feature, so any part of the
 * beta can be put back to its v9 behaviour without reinstalling. Each switch
 * is per browser (client): it changes what you see, and the HUD, wheel and
 * Medkit keep every saved choice either way. Older zips are kept as well. */
import {setGestureStyle} from './bit-behaviour.mjs?v=13.0.1';
import {setCoreMarkStyle,setBitOutline} from './bit-resonance.mjs?v=13.0.1';
import {setScanLook} from './v8-scan-art.mjs?v=13.0.1';
import {setFormationMotion} from './refined-formations.mjs?v=13.0.1';
import {setWingMotionStyle} from './poses.mjs?v=13.0.1';
import {setFlightFeelSwitch} from './flight-feel-runtime.mjs?v=13.0.1';
const ID='filament-flight';

export const VERSION_SWITCHES=Object.freeze({
  versionGestures:{name:'Bit gestures',hint:'v10: each gesture has its own readable path (inspect sweeps, flourish loops, confer meets). Classic: the small v9 excursions.',apply:v=>setGestureStyle(v)},
  versionCoreStates:{name:'Bit core states',hint:'v10: every work state shows its own mark (sheath, shield arc, charging rings, sighting line). Classic: the subtle v9 marks.',apply:v=>setCoreMarkStyle(v)},
  versionBitOutline:{name:'Bit outline',hint:'Darker: a dark steel outline, a faint dark backing and a bright magenta core line, so the bits stay easy to see at token size and on light maps. Original: the bits as they always looked.',choices:{original:'Original',darker:'Darker outline'},def:'original',apply:v=>setBitOutline(v==='darker')},
  versionFormations:{name:'Formation motion',hint:'v10: the reworked Tide line swell. Classic: the v9 Tide line. New families and the Legacy group are controlled by Formation library.',apply:v=>setFormationMotion(v)},
  versionScans:{name:'Scan look',hint:'v10: brighter scans with a completion frame. Classic: the restrained v8.6 exposure.',apply:v=>setScanLook(v)},
  versionWingMotion:{name:'Wing motion',hint:'v10: a readable folded pose, strands that clear her face, a power-stroke wingbeat and tapered glowing wakes. Classic: the v9 wing motion.',apply:v=>setWingMotionStyle(v)},
  versionIris:{name:'Iris look',hint:'The Mechanical iris routine. Mechanical: steel blades opening in a gold-ticked ring. Hardlight: the original glowing wire aperture.',choices:{mechanical:'Mechanical',hardlight:'Hardlight'},def:'mechanical'},
  versionFlightFeel:{name:'Flight feel',hint:'v10: weight and momentum with a character for each flight mode, wingbeats that work harder on climbs and ease on long flights, height from her token’s elevation (she shrinks as she climbs and her shadow stays on the ground), takeoff and landing, wing flex, falling when knocked out and idle moments. Classic: the earlier steady hover.',apply:v=>setFlightFeelSwitch(v)},
  versionWarp:{name:'Default warp',hint:'Which warp plays when no look is chosen (the wheel can still pick any). Threaded: threads, rays and colour split. Seam: she folds into a quiet seam of light. Flicker: her bits unthread, fly ahead and pull her back together. Petal: her wing threads drift across and re-knit her. Shard: her wing lattice breaks along its filaments and locks back together. Mirror: her bits draw two panes and she steps through. Flock: a wheeling flock of blades turns edge-on and is gone. Starfall: her constellation goes out here and falls in there. Ribbon seam: her ribbons are drawn into a seam in space. Prism: three copies split into shafts. Cloak: she fades here in her cloak\u2019s own look and comes back there.',choices:{threaded:'Threaded',seam:'Seam',flicker:'Flicker',petal:'Petal',shard:'Shard',mirror:'Mirror',flock:'Flock',starfall:'Starfall',ribbon:'Ribbon seam',prism:'Prism',cloak:'Cloak'},def:'threaded'}
});

export function versionSetting(key){try{return game.settings.get(ID,key);}catch{return VERSION_SWITCHES[key]?.def??'v10';}}
export function defaultWarpLook(){const v=versionSetting('versionWarp');return ['seam','flicker','petal','shard','mirror','flock','starfall','ribbon','prism','cloak'].includes(v)?v:'threaded';}

export function registerVersionSwitches(){
  for(const [key,spec] of Object.entries(VERSION_SWITCHES)){
    game.settings.register(ID,key,{name:`Versions · ${spec.name}`,hint:spec.hint,scope:'client',config:true,type:String,
      choices:spec.choices??{v10:'v10',classic:'Classic (v9)'},default:spec.def??'v10',
      onChange:value=>{spec.apply?.(value);try{canvas?.app?.renderer&&globalThis.game?.modules?.get(ID)?.api?.refresh?.();}catch{}}});
    try{spec.apply?.(game.settings.get(ID,key));}catch{}
  }
}
