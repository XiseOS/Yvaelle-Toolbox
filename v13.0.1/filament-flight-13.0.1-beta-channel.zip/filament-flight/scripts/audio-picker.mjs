import {AUDIO_PRESETS,AUDIO_SLOTS} from './audio-model.mjs?v=13.0.1';
import {escapeHTML as e} from './hud-view.mjs?v=13.0.1';
import {createHUDMotion,hudMotionOptions} from './hud-motion.mjs?v=13.0.1';

const descriptions={
  default:'Restrained electrical texture, softened transients and an evolving sci-fi field.',
  original:'The original brighter, more tonal energy sound. Kept for your existing sound style.',
  custom:'Use the custom audio file saved for this sound. Choose this to edit its path in Sound.',
  none:'Leave this sound silent. Other wing sounds keep their own choices.'
};

/** Private auditions use transient API options. Only an explicit choice writes a flag. */
export class AudioPicker {
  constructor(controller,slot,model) {
    if(!Object.hasOwn(AUDIO_SLOTS,slot))throw new Error('Unknown wing sound.');
    this.controller=controller;this.slot=slot;this.entry=AUDIO_SLOTS[slot];this.targetId=model.token.document.uuid;
    this.model=model;this.active=model.audio?.requested?.slots?.[slot]?.preset??'default';this.epoch=0;
    this.hoverEnabled=controller.audioHoverPreview!==false;
    const host=controller.app.element,doc=host.ownerDocument;this.window=doc.defaultView;
    this.events=new this.window.AbortController();const {signal}=this.events;this.motion=createHUDMotion(hudMotionOptions(model));
    this.dialog=doc.createElement('dialog');this.dialog.className='ff-effect-picker ff-audio-picker';
    this.dialog.setAttribute('aria-labelledby','ff-audio-picker-title');
    this.dialog.innerHTML=`<header class="ff-picker-heading"><div><span class="ff-eyebrow">CHOOSE A SOUND</span><h2 id="ff-audio-picker-title">${e(this.entry.label)}</h2><p>For ${e(model.token.document.name??'your token')}</p></div><button type="button" class="ff-button ff-picker-close" data-ff-audio-picker-close aria-label="Close sound selector" autofocus>×</button></header>
      <div class="ff-picker-body"><div class="ff-picker-choices" role="group" aria-label="Sound choices">${Object.entries(AUDIO_PRESETS).filter(([id])=>id!=='original'||!this.entry.modern).map(([id,label])=>`<div class="ff-sound-choice-row" data-ff-audio-choice-row="${e(id)}"><button type="button" class="ff-button ff-picker-choice" data-ff-audio-choice="${e(id)}" aria-pressed="false"><span class="ff-choice-heading"><strong>${e(label)}</strong><small data-ff-audio-choice-saved hidden>Saved</small></span><span class="ff-choice-description">${e(descriptions[id]??'')}</span><span class="ff-choice-kind">${id==='none'?'Silent':id==='custom'?'Your file':this.entry.loop?'Energy loop':'Motion cue'}</span></button><button type="button" class="ff-button ff-sound-choice-play" data-ff-audio-choice-preview="${e(id)}" aria-label="Preview ${e(label)} privately" title="Preview ${e(label)} privately"><i class="fa-solid fa-play" aria-hidden="true"></i></button></div>`).join('')}</div>
      <section class="ff-picker-stage ff-sound-stage" aria-label="Private sound preview"><div class="ff-preview-topline"><span>ONLY YOU HEAR THIS PREVIEW</span><span class="ff-preview-dot is-paused" aria-hidden="true"></span></div><div class="ff-sound-emblem" aria-hidden="true"><i class="fa-solid fa-headphones"></i><span>PRIVATE AUDITION</span></div><div class="ff-preview-copy"><h3 data-ff-audio-preview-name></h3><p data-ff-audio-preview-description></p></div><p class="ff-note ff-sound-purpose">${e(this.entry.description||`${this.entry.loop?'A continuing sound layer':'A short cue'} for ${this.entry.label.toLowerCase()}.`)}</p><div class="ff-preview-buttons"><button type="button" class="ff-button" data-ff-audio-preview-play><i class="fa-solid fa-play" aria-hidden="true"></i> Play preview</button><button type="button" class="ff-button" data-ff-audio-preview-stop>Stop</button></div><p class="ff-note" data-ff-audio-preview-guidance></p><p class="ff-note ff-sound-privacy">Auditions bypass distance and the token’s sound switches. Your saved volumes, personal mute and the GM’s audio switches still apply.</p></section></div>
      <footer class="ff-picker-footer"><span>Hover or focus to hear · Click a choice to save · Esc to close</span><span data-ff-audio-picker-status role="status" aria-live="polite"></span></footer>`;
    const hoverLabel=doc.createElement('label');hoverLabel.className='ff-check ff-sound-hover-toggle';
    hoverLabel.innerHTML=`<input type="checkbox" data-ff-audio-hover${this.hoverEnabled?' checked':''}><span>Preview on hover or focus</span>`;
    this.dialog.querySelector('.ff-preview-buttons').before(hoverLabel);
    hoverLabel.querySelector('input').addEventListener('change',event=>{
      this.hoverEnabled=controller.audioHoverPreview=event.target.checked;
      this.stopPreview(this.hoverEnabled?'Hover previews enabled.':'Hover previews off. Use a play button to audition.');
    },{signal});
    this.dialog.querySelector('[data-ff-audio-picker-close]').addEventListener('click',()=>this.close(),{signal});
    this.dialog.addEventListener('cancel',event=>{event.preventDefault();this.close();},{signal});
    this.dialog.addEventListener('close',()=>this.close(),{signal});
    this.dialog.addEventListener('click',event=>{
      event.stopPropagation();
      if(event.target===this.dialog){const r=this.dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)this.close();}
    },{signal});
    this.dialog.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();event.stopPropagation();this.close();return;}
      const buttons=[...this.dialog.querySelectorAll('[data-ff-audio-choice]')],i=buttons.indexOf(event.target);
      if(i<0||!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;
      event.preventDefault();event.stopPropagation();
      buttons[event.key==='Home'?0:event.key==='End'?buttons.length-1:(i+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();
    },{signal});
    for(const row of this.dialog.querySelectorAll('[data-ff-audio-choice-row]')) {
      const id=row.dataset.ffAudioChoiceRow;
      row.addEventListener('pointerenter',event=>{if(event.pointerType!=='touch')this.activate(id,true);},{signal});
      row.addEventListener('pointerleave',()=>this.stopPreview(),{signal});
      row.addEventListener('focusin',event=>{if(!row.contains(event.relatedTarget))this.activate(id,true);},{signal});
      row.addEventListener('focusout',event=>{if(!row.contains(event.relatedTarget))this.stopPreview();},{signal});
      row.querySelector('[data-ff-audio-choice]').addEventListener('click',()=>{void this.choose(id);},{signal});
      row.querySelector('[data-ff-audio-choice-preview]').addEventListener('click',()=>{this.activate(id);void this.play();},{signal});
    }
    this.dialog.querySelector('[data-ff-audio-preview-play]').addEventListener('click',()=>{void this.play();},{signal});
    this.dialog.querySelector('[data-ff-audio-preview-stop]').addEventListener('click',()=>this.stopPreview('Preview stopped.'),{signal});
    doc.addEventListener('visibilitychange',()=>{if(doc.hidden)this.stopPreview('Preview stopped while this tab is hidden.');},{signal});
    host.append(this.dialog);
    this.motion.bindDisclosures(this.dialog,{signal});
    try {this.update(model);this.dialog.showModal();this.dialog.querySelector('[data-ff-audio-picker-close]').focus({preventScroll:true});this.motion.enter(this.dialog,{kind:'library'});}
    catch(error){this.close();throw error;}
  }

  valid(model=this.controller.model()) {
    return this.controller.opened&&this.controller.prefs.advancedOpen&&model.cfg.hudEnabled&&!model.error
      &&model.token?.document.uuid===this.targetId&&model.token.document.isOwner
      &&model.token.document.parent?.id===globalThis.canvas?.scene?.id;
  }
  gate(id=this.active) {
    const a=this.model.audio??{},category=a.categories?.[this.entry.category]??{},slot=a.slots?.[this.slot]??{};
    if(this.model.cfg.audioEnabled===false||a.worldEnabled===false)return 'Wing audio is disabled by the GM. You can still save a choice.';
    if(category.worldEnabled===false)return 'This audio category is disabled by the GM. You can still save a choice.';
    if(a.localMuted)return 'Wing audio is muted on this browser. Unmute it in Sound to audition.';
    if([a.localVolume,a.worldVolume,a.volume,category.volume,slot.volume].some(v=>v===0))return 'A saved listening or sound volume is zero. Raise it in Sound to audition.';
    if(id==='none')return 'No audio for this sound. Click None to save silence.';
    if(id==='custom'&&!this.model.audio?.requested?.slots?.[this.slot]?.src?.trim())return 'Choose Custom file, then add its audio path in the Audio tab.';
    return '';
  }
  update(model) {
    if(this.closed)return;
    if(!this.valid(model)||this.controller.app?.minimized){this.close();return;}
    const motionOptions=hudMotionOptions(model);this.motion.configure(motionOptions);this.dialog.dataset.ffMenuMotion=String(motionOptions.enabled&&motionOptions.strength>0);
    this.model=model;
    const signature=JSON.stringify([model.cfg.audioEnabled,model.audio?.worldEnabled,model.audio?.localMuted,model.audio?.localVolume,model.audio?.worldVolume,model.audio?.volume,model.audio?.categories?.[this.entry.category],model.audio?.requested?.slots?.[this.slot]]);
    if(this.signature!==undefined&&signature!==this.signature)this.stopPreview('Preview stopped because audio settings changed.');
    this.signature=signature;
    const saved=model.audio?.requested?.slots?.[this.slot]?.preset??'default';
    for(const button of this.dialog.querySelectorAll('[data-ff-audio-choice]')) {
      const current=button.dataset.ffAudioChoice===saved;
      button.setAttribute('aria-pressed',String(current));button.querySelector('[data-ff-audio-choice-saved]').hidden=!current;
    }
    if(this.playing&&model.audio?.status&&model.audio.status.preview!==this.slot){this.playing=false;this.status('Preview finished. Hover another sound or replay.');}
    this.paint();
  }
  activate(id,audition=false) {
    if(this.closed||this.saving||!Object.hasOwn(AUDIO_PRESETS,id))return;
    const changed=this.active!==id;this.stopPreview();this.active=id;this.paint();
    if(changed)this.motion.enter(this.dialog.querySelector('.ff-preview-copy'),{kind:'library'});
    if(audition&&this.hoverEnabled&&!this.gate(id)&&!this.dialog.ownerDocument.hidden){this.timer=this.window.setTimeout(()=>{this.timer=null;void this.play();},150);this.paint();}
  }
  status(message) {if(!this.closed)this.dialog.querySelector('[data-ff-audio-picker-status]').textContent=message;}
  paint() {
    if(this.closed)return;
    const gate=this.gate();
    for(const button of this.dialog.querySelectorAll('[data-ff-audio-choice]')) {
      button.classList.toggle('is-previewing',button.dataset.ffAudioChoice===this.active);
      button.disabled=!!this.saving;
    }
    for(const button of this.dialog.querySelectorAll('[data-ff-audio-choice-preview]'))button.disabled=!!this.saving||!!this.gate(button.dataset.ffAudioChoicePreview);
    this.dialog.querySelector('[data-ff-audio-preview-name]').textContent=AUDIO_PRESETS[this.active];
    this.dialog.querySelector('[data-ff-audio-preview-description]').textContent=descriptions[this.active]??'';
    this.dialog.querySelector('[data-ff-audio-preview-guidance]').textContent=gate||(this.hoverEnabled?'Hover a choice to audition it locally for up to eight seconds. If your browser blocks playback, press Play preview.':'Hover previews are off. Use a play button to audition a sound privately for up to eight seconds.');
    const play=this.dialog.querySelector('[data-ff-audio-preview-play]');
    play.disabled=!!this.saving||!!gate;
    play.innerHTML=`<i class="fa-solid fa-play" aria-hidden="true"></i> ${this.playing?'Replay':'Play preview'}`;
    this.dialog.querySelector('[data-ff-audio-preview-stop]').disabled=!!this.saving||!(this.loading||this.playing||this.timer!=null);
    this.dialog.querySelector('.ff-preview-dot').classList.toggle('is-paused',!this.playing);
  }
  async play() {
    if(this.closed||this.saving||this.controller.busy)return;
    if(!this.valid()){this.close();return;}
    this.stopPreview();const gate=this.gate();if(gate){this.status(gate);return;}
    if(this.dialog.ownerDocument.hidden)return;
    const epoch=this.epoch,id=this.active;this.loading=true;this.paint();this.status('Loading private preview…');
    try {
      const result=await this.controller.api().previewAudio(this.model.token,this.slot,{preset:id});
      if(this.closed||epoch!==this.epoch)return;
      if(!this.valid()||this.dialog.ownerDocument.hidden){this.stopPreview();return;}
      this.loading=false;this.playing=result?.preview===true;this.status(this.playing?`Private preview: ${AUDIO_PRESETS[id]}`:'Preview stopped.');this.paint();
    }catch(error){
      if(this.closed||epoch!==this.epoch)return;
      this.loading=false;this.playing=false;this.status(`Preview unavailable: ${error?.message??error}. Try Play preview.`);this.paint();
    }
  }
  stopPreview(message='') {
    this.epoch++;if(this.timer!=null)this.window.clearTimeout(this.timer);this.timer=null;
    this.loading=false;this.playing=false;this.controller.stopAudioPreview();
    if(!this.closed){this.status(message);this.paint();}
  }
  async choose(id) {
    if(this.closed||this.saving||this.controller.busy||!Object.hasOwn(AUDIO_PRESETS,id))return;
    if(!this.valid()){this.close();return;}
    this.saving=true;this.stopPreview();this.paint();this.status('Saving…');
    try {await this.controller.run('audio',{slots:{[this.slot]:{preset:id}}},this.targetId);this.close();}
    catch(error){if(this.closed)return;this.saving=false;this.status(String(error?.message??error));this.paint();}
  }
  close() {
    if(this.closed)return;this.stopPreview();this.closed=true;this.events.abort();this.dialog.inert=true;
    if(this.controller.audioPicker===this)this.controller.audioPicker=null;
    void this.motion.exit(this.dialog,{kind:'library'}).finally(()=>{
      this.motion.destroy();const doc=this.dialog.ownerDocument,restoreFocus=doc.activeElement===doc.body||this.dialog.contains(doc.activeElement);
      if(this.dialog.open)this.dialog.close();this.dialog.remove();
      if(restoreFocus&&this.controller.opened&&this.controller.prefs.advancedOpen)this.controller.root?.querySelector(`[data-ff-audio-picker="${this.slot}"]`)?.focus({preventScroll:true});
    });
  }
}
