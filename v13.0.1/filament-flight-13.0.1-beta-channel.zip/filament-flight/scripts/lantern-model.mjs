import {normalizeLanternLock,normalizeLightPresets} from './v88-lantern-tools.mjs?v=13.0.1';
/** World headings use canvas coordinates: east 0°, south 90°. */
export const LANTERN_DEFAULTS=Object.freeze({enabled:false,angle:0,width:70,bright:15,dim:30,intensity:.65,beam:.35,edgeStyle:'soft',edgeSoftness:.65,groundStyle:'projector',lock:null,presets:null});
export const LANTERN_RANGES=Object.freeze({width:[15,180],bright:[0,120],dim:[0,120],intensity:[0,1],beam:[0,1],edgeSoftness:[0,1]});
export const LANTERN_METADATA=Object.freeze(['started','leader','changed','from','fromBeam','fromReach','fromVelocity','fromBeamVelocity','fromReachVelocity','startAngle','formationOrder','formationCapture','transitionCapture']);
export const LANTERN_TIMING=Object.freeze({ignite:1400,gather:1200,snuff:600,return:1800});
export const wrapHeading=angle=>((angle%360)+360)%360;
export const headingDelta=(from,to)=>((to-from+540)%360+360)%360-180;
export const nativeLanternRotation=angle=>wrapHeading(angle-90);

/** Open wings use their live stabilizers whether grounded or flying. The
 * visible wing transition retains that mount through opening and closing;
 * only closed-wing companions can assemble the token projector below. */
export function wingLanternMounting(snapshot={}){
  if(snapshot.compactBits===true)return false;
  return !!(snapshot.rendering?.wingsActive??(snapshot.enabled||snapshot.transition?.active));
}

/** Grounded companions can retain their ordinary formation while providing
 * the same rounded directional wash as wing stabilizers. Flight and the wing
 * handoff still use their own route, so compact roots never stand in for wings. */
export function groundLanternMounting(snapshot={},settings=snapshot.requested?.lantern??snapshot.lantern){
  const wings=snapshot.rendering?.wingsActive??!!(snapshot.enabled||snapshot.transition?.active),
    flying=snapshot.rendering?.flightActive??!!(snapshot.airborne||snapshot.transition?.active&&
      ((snapshot.transition.fromFlight??0)>0||(snapshot.transition.toFlight??0)>0));
  return settings?.groundStyle==='stabilizers'&&snapshot.compactBits===true&&!wings&&!flying;
}
export function stabilizerLanternMounting(snapshot={},settings){
  return wingLanternMounting(snapshot)||groundLanternMounting(snapshot,settings);
}

export function lanternPatch(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Lantern settings must be an object.');
  const out={};
  for(const [key,value] of Object.entries(input)){
    if(!Object.hasOwn(LANTERN_DEFAULTS,key))throw new Error(`Unknown lantern setting: ${key}.`);
    if(value===null){out[key]=LANTERN_DEFAULTS[key];continue;}
    if(key==='lock'){out[key]=normalizeLanternLock(value);continue;}
    if(key==='presets'){out[key]=normalizeLightPresets(value);continue;}
    if(key==='enabled'){if(typeof value!=='boolean')throw new Error('Lantern enabled must be true or false.');out[key]=value;continue;}
    if(key==='groundStyle'){if(!['projector','stabilizers'].includes(value))throw new Error('Lantern groundStyle must be projector or stabilizers.');out[key]=value;continue;}
    if(key==='edgeStyle'){if(!['soft','classic'].includes(value))throw new Error('Lantern edgeStyle must be soft or classic.');out[key]=value;continue;}
    if(!Number.isFinite(value))throw new Error(`Lantern ${key} must be a finite number.`);
    if(key==='angle'){out[key]=wrapHeading(value);continue;}
    const [min,max]=LANTERN_RANGES[key];
    if(value<min||value>max)throw new Error(`Lantern ${key} must be between ${min} and ${max}.`);
    out[key]=value;
  }
  return out;
}
/** Saved activation metadata is read-only through the public settings patch.
 * It gives reloads and late observers the same animation phase. The retained
 * conductor identity is compatible with earlier files; the resolved flight
 * context chooses the token projector or the physical stabilizer sources. */
export function normalizeLantern(raw){
  if(raw==null)return {...LANTERN_DEFAULTS};
  if(typeof raw!=='object'||Array.isArray(raw))throw new Error('Lantern settings must be an object.');
  const {started,leader,changed,from,fromBeam,fromReach,fromVelocity,fromBeamVelocity,fromReachVelocity,startAngle,formationOrder,formationCapture,transitionCapture,...settings}=raw,metadata={};
  if(started!==undefined){if(!Number.isFinite(started)||started<0)throw new Error('Invalid saved lantern activation.');metadata.started=started;}
  if(leader!==undefined){if(!['leftUpper','rightUpper','leftLower','rightLower'].includes(leader))throw new Error('Invalid saved lantern aperture.');metadata.leader=leader;}
  if(changed!==undefined){if(!Number.isFinite(changed)||changed<0)throw new Error('Invalid saved lantern transition.');metadata.changed=changed;}
  for(const [key,value]of Object.entries({from,fromBeam,fromReach}))if(value!==undefined){
    if(!Number.isFinite(value)||value<0||value>1)throw new Error(`Invalid saved lantern ${key}.`);metadata[key]=value;
  }
  for(const [key,value]of Object.entries({fromVelocity,fromBeamVelocity,fromReachVelocity}))if(value!==undefined){
    if(!Number.isFinite(value)||Math.abs(value)>20)throw new Error(`Invalid saved lantern ${key}.`);metadata[key]=value;
  }
  if(startAngle!==undefined){if(!Number.isFinite(startAngle)||startAngle<0||startAngle>=360)throw new Error('Invalid saved lantern start angle.');metadata.startAngle=startAngle;}
  if(formationOrder!==undefined){
    if(!Array.isArray(formationOrder)||formationOrder.length>4||new Set(formationOrder).size!==formationOrder.length||
      formationOrder.some(id=>!['leftUpper','rightUpper','leftLower','rightLower'].includes(id)))throw new Error('Invalid saved lantern formation order.');
    metadata.formationOrder=[...formationOrder];
  }
  for(const [key,capture]of Object.entries({formationCapture,transitionCapture}))if(capture!==undefined){
    if(!Array.isArray(capture)||capture.length>4||new Set(capture.map(p=>p?.station)).size!==capture.length)throw new Error(`Invalid saved lantern ${key}.`);
    metadata[key]=capture.map(p=>{
      if(!p||!['leftUpper','rightUpper','leftLower','rightLower'].includes(p.station)||
        Object.keys(p).some(k=>!['station','x','y','z','angle','scale'].includes(k))||
        !['x','y','z','angle','scale'].every(k=>Number.isFinite(p[k]))||Math.abs(p.x)>10000||Math.abs(p.y)>10000||Math.abs(p.z)>1000||Math.abs(p.angle)>10000||p.scale<0||p.scale>100)throw new Error(`Invalid saved lantern ${key}.`);
      return {...p};
    });
  }
  return {...LANTERN_DEFAULTS,...lanternPatch(settings),...metadata};
}

/** Count only physically available home instruments. Remote/working bits keep
 * their action ownership; loss and return fade through the shared envelope. */
export function lanternAvailability(snapshot){
  if(!snapshot?.gems?.enabled||snapshot.gems.supported===false||snapshot.bitProjectedEffect)return 0;
  if(snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse?.mix>.001)return 0;
  const all=['leftUpper','rightUpper','leftLower','rightLower'];
  const hidden=new Set(snapshot.bitActionAssignments?.hidden??[]),support=snapshot.bitActionAssignments?.support??{};
  const ids=snapshot.bitHomeStations??all;
  const total=ids.reduce((sum,id)=>sum+(hidden.has(id)||support[id]?0:Math.max(0,Math.min(1,snapshot.bitCount?.values?.[all.indexOf(id)]??1))),0);
  return Math.min(1,total)*Math.max(0,Math.min(1,snapshot.bitDeployment??1));
}

const unit=n=>Math.max(0,Math.min(1,n));
const smooth=n=>{const t=unit(n);return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;

/** A bounded C1 scalar bridge. An inherited outward velocity brakes within
 * the available unit interval before returning. Toward-target tangents use
 * a monotone Hermite segment; an unusually fast tangent shortens that segment
 * instead of overshooting/clipping its endpoint. Velocities use seconds. */
export function sampleLanternChannel(from,to,velocity,elapsed,duration){
  from=unit(from);to=unit(to);velocity=Number.isFinite(velocity)?velocity:0;
  let seconds=Math.max(.001,duration/1000),time=Math.max(0,elapsed/1000);
  const direction=Math.sign(to-from),room=velocity>0?1-from:from;
  if(room<=0&&velocity*(velocity>0?1:-1)>0)velocity=0;
  if(time===0)return {value:from,velocity};
  if(!direction&&velocity===0)return {value:to,velocity:0};
  if(velocity&&velocity*direction<=0){
    const brake=Math.min(seconds*.2,room/Math.abs(velocity));
    if(brake>0){
      if(time<brake)return {value:from+velocity*(time-time*time/(2*brake)),velocity:velocity*(1-time/brake)};
      from+=velocity*brake/2;time-=brake;seconds-=brake;
    }
    velocity=0;
  }
  const distance=Math.abs(to-from);
  if(velocity&&distance>0)seconds=Math.min(seconds,3*distance/Math.abs(velocity));
  const p=unit(time/seconds);
  if(p>=1)return {value:to,velocity:0};
  const p2=p*p,p3=p2*p,tangent=velocity*seconds;
  return {value:(2*p3-3*p2+1)*from+(p3-2*p2+p)*tangent+(-2*p3+3*p2)*to,
    velocity:((6*p2-6*p)*from+(3*p2-4*p+1)*tangent+(-6*p2+6*p)*to)/seconds};
}

/** Shared, reversible lifecycle channels. Native reach and power use separate
 * curves; the last bit can finish returning after the light is extinguished. */
export function lanternEnvelope(settings,now){
  const enabled=settings.enabled===true,changed=settings.changed??(enabled?settings.started??0:0),elapsed=Math.max(0,now-changed);
  const from=settings.from??0,fromBeam=settings.fromBeam??0,fromReach=settings.fromReach??0;
  if(enabled){
    const progress=unit(elapsed/LANTERN_TIMING.ignite),assembly=smooth(elapsed/LANTERN_TIMING.gather);
    const reachCurve=1-Math.pow(1-unit((elapsed-260)/820),3);
    const powerCurve=smooth((elapsed-160)/1100);
    const legacy={weight:mix(from,1,assembly),beamWeight:mix(fromBeam,1,powerCurve),reach:mix(fromReach,1,reachCurve)},
      velocity={weight:elapsed>0&&elapsed<LANTERN_TIMING.gather?(1-from)*6*(elapsed/LANTERN_TIMING.gather)*(1-elapsed/LANTERN_TIMING.gather)/(LANTERN_TIMING.gather/1000):0,
        beamWeight:elapsed>160&&elapsed<1260?(1-fromBeam)*6*((elapsed-160)/1100)*(1-(elapsed-160)/1100)/1.1:0,
        reach:elapsed>=260&&elapsed<1080?(1-fromReach)*3*(1-(elapsed-260)/820)**2/.82:0};
    for(const [key,initial,speed,duration,delay]of [['weight',from,settings.fromVelocity,1200,0],['beamWeight',fromBeam,settings.fromBeamVelocity,1260,160],['reach',fromReach,settings.fromReachVelocity,1080,260]])if(speed!==undefined){
      const cold=initial===0&&speed===0,waiting=cold&&elapsed<delay,
        sample=sampleLanternChannel(initial,1,speed,waiting?0:elapsed-(cold?delay:0),duration-(cold?delay:0));
      legacy[key]=sample.value;velocity[key]=waiting?0:sample.velocity;
    }
    return {...legacy,velocity,transition:legacy.reach,progress,shuttingDown:false,phase:progress>=1?'steady':elapsed<260?'charge':'ignite'};
  }
  const withdrawal=smooth(elapsed/LANTERN_TIMING.snuff),release=smooth(elapsed/LANTERN_TIMING.return);
  const legacy={weight:from*(1-release),beamWeight:fromBeam*Math.pow(1-withdrawal,.65),reach:fromReach*(1-withdrawal)},
    withdrawalVelocity=elapsed>0&&elapsed<LANTERN_TIMING.snuff?6*(elapsed/LANTERN_TIMING.snuff)*(1-elapsed/LANTERN_TIMING.snuff)/(LANTERN_TIMING.snuff/1000):0,
    velocity={weight:elapsed>0&&elapsed<LANTERN_TIMING.return?-from*6*(elapsed/LANTERN_TIMING.return)*(1-elapsed/LANTERN_TIMING.return)/(LANTERN_TIMING.return/1000):0,
      beamWeight:withdrawalVelocity&&withdrawal<1?-fromBeam*.65*Math.pow(1-withdrawal,-.35)*withdrawalVelocity:0,reach:-fromReach*withdrawalVelocity};
  for(const [key,initial,speed,duration]of [['weight',from,settings.fromVelocity,1800],['beamWeight',fromBeam,settings.fromBeamVelocity,600],['reach',fromReach,settings.fromReachVelocity,600]])if(speed!==undefined){
    const sample=sampleLanternChannel(initial,0,speed,elapsed,duration);legacy[key]=sample.value;velocity[key]=sample.velocity;
  }
  return {...legacy,velocity,transition:legacy.reach,progress:unit(elapsed/LANTERN_TIMING.return),shuttingDown:elapsed<LANTERN_TIMING.return&&from>0,
    phase:elapsed<LANTERN_TIMING.snuff&&fromBeam>0?'snuff':elapsed<LANTERN_TIMING.return&&from>0?'return':'off'};
}

/** Aim stays prompt; the physical cradle takes an unwrapped, slower arc.
 * Timed lifecycle channels recover analytically after pauses and reloads. */
export function stepLantern(memory,settings,available,now){
  if(!memory){
    const assembled=settings.enabled&&now-(settings.changed??settings.started??0)>=LANTERN_TIMING.gather;
    memory={angle:settings.angle,formationAngle:assembled?settings.angle:settings.startAngle??settings.angle,weight:0,beamWeight:0,at:now,availability:available};
  }
  const previousAt=memory.at,dt=Math.max(0,Math.min(.1,(now-previousAt)/1000));memory.at=now;
  const delta=headingDelta(memory.angle,settings.angle);
  const turn=delta*(1-Math.exp(-dt/.025));
  memory.angle=wrapHeading(memory.angle+turn);
  if(Math.abs(headingDelta(memory.angle,settings.angle))<.0001)memory.angle=settings.angle;
  const epoch=Number.isFinite(settings.started)?settings.started:memory.poseNow??now;
  const capturedActive=settings.enabled||settings.from>0&&Number.isFinite(settings.changed)&&now-settings.changed<LANTERN_TIMING.return;
  if(capturedActive&&(memory.poseNow===undefined||Number.isFinite(settings.started)&&memory.poseNow!==epoch)){memory.poseNow=epoch;memory.poseClock=epoch/1000;}
  memory.formationStartAngle=settings.startAngle??memory.formationStartAngle??settings.angle;
  memory.formationAngle??=memory.angle;
  const cradle=headingDelta(memory.formationAngle,settings.angle)*(1-Math.exp(-dt/.25));
  memory.formationAngle+=Math.max(-120*dt,Math.min(120*dt,cradle));
  if(Math.abs(headingDelta(memory.formationAngle,settings.angle))<.0001)memory.formationAngle+=headingDelta(memory.formationAngle,settings.angle);
  // Public API writes exact toggle epochs. Direct/legacy callers without that
  // metadata still get a continuous transition from their previous channels.
  if(settings.changed===undefined){
    if(!memory.lifecycle||memory.lifecycle.enabled!==settings.enabled){
      memory.lifecycle={enabled:settings.enabled,changed:memory.lifecycle?previousAt:epoch,
        from:memory.body??memory.weight??0,fromBeam:memory.power??memory.beamWeight??0,fromReach:memory.reach??0,
        ...(memory.lifecycle?{fromVelocity:memory.velocity?.weight??0,fromBeamVelocity:memory.velocity?.beamWeight??0,fromReachVelocity:memory.velocity?.reach??0}:{})};
    }
  }else memory.lifecycle={...settings};
  const envelope=lanternEnvelope({...settings,...memory.lifecycle},now);
  memory.availability??=available;
  const availabilityTarget=settings.enabled?available:Math.min(available,memory.availability);
  memory.availability+=(availabilityTarget-memory.availability)*(1-Math.exp(-dt/.22));
  if(Math.abs(memory.availability-availabilityTarget)<.0001)memory.availability=availabilityTarget;
  memory.body=envelope.weight;memory.power=envelope.beamWeight;
  Object.assign(memory,envelope,{weight:envelope.weight*memory.availability,beamWeight:envelope.beamWeight*memory.availability});
  if(!settings.enabled&&memory.weight===0&&memory.beamWeight===0){delete memory.poseNow;delete memory.poseClock;}
  return memory;
}
