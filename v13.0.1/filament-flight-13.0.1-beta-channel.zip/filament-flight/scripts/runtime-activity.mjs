import {isOnScreen,isShown} from './renderer.mjs?v=13.0.1';
import {bitRestVisible} from './bit-collapse.mjs?v=13.0.1';

/** A deliberately generous envelope, computed from normalized preferences.
 * This is an early CPU gate, not the renderer's final clipping rectangle.
 * Keep past trail points, free bit positions and token suspension in range. */
export function runtimeExtent(state,config) {
  const token=state.token,opts=state.opts??{},snapshot=state.snapshot;
  const size=Math.max(token.w??0,token.h??0)||100;
  const offsets=Math.abs(opts.offsetX??0)+Math.abs(opts.offsetY??0);
  const suspension=(opts.hoverHeight??0)+(opts.bobHeight??0)*3+(opts.floatSway??0)*3;
  const compact=snapshot?.compactBits&&!snapshot?.transition?.active;
  const radius=compact?Math.max(2,(snapshot.gems?.soloRadius??1)*1.75):Math.max(2,(opts.wingScale??3.5)*1.5);
  const trails=snapshot?.movement?.trailEnabled?(config.trailLength??0)*1.5*(globalThis.canvas?.grid?.size??size):0;
  return size*(radius+offsets+suspension+1)+trails;
}

export function runtimeVisible(state,config) {
  if(globalThis.document?.hidden===true||!isShown(state.token,state.source)||state.source.alpha===0)return false;
  const extent=runtimeExtent(state,config);
  return isOnScreen(state.source.x,state.source.y,extent,extent)||bitRestVisible(state.snapshot,isOnScreen);
}

/** At most four inexpensive maintenance samples per second while invisible.
 * Event sync still invalidates immediately; phase always uses the server clock. */
export function dormantSampleDue(state,now,config) {
  return state.dormantConfig!==config||state.dormantData!==state.data||
    !Number.isFinite(state.dormantSampleAt)||now<state.dormantSampleAt||now-state.dormantSampleAt>=250;
}

const timedPending=(value,now)=>value&&Number.isFinite(value.started)&&Number.isFinite(value.duration)&&now<value.started+value.duration;
const TIMED_INPUTS=['transition','poseTransition','modeTransition','conditionTransition','hpTransition','bitTransition','bitCountTransition','structureTransition','structurePoseTransition','temporaryPose','temporaryCondition'];
function animationPending(data,snapshot,now){
  for(const key of TIMED_INPUTS)if(timedPending(data[key],now))return true;
  if(timedPending(snapshot.hpTransition,now))return true;
  for(const key in data.cues??{})if(Object.hasOwn(data.cues,key)&&timedPending(data.cues[key],now))return true;
  return false;
}
/** The projection cycle obeys explicit animation opt-outs. Once assembly is
 * complete its wall clock no longer changes artwork, while headings, weight,
 * captures and availability still can. Keep those inputs in the identity so
 * aim and allocation edits wake the painter without freezing native lighting. */
export function frozenLanternArtwork(snapshot) {
  const lamp=snapshot?.lantern;
  const heading=lamp?.angle,cradle=lamp?.formationAngle;
  const settledHeading=Number.isFinite(heading)&&Number.isFinite(cradle)&&
    Math.abs(Math.atan2(Math.sin((cradle-heading)*Math.PI/180),Math.cos((cradle-heading)*Math.PI/180)))<1e-9;
  return !!lamp?.active&&lamp.enabled===true&&lamp.phase==='steady'&&!lamp.shuttingDown&&
    lamp.weight===lamp.available&&settledHeading&&
    (snapshot.effective?.reducedMotion===true||snapshot.gems?.animated===false);
}
export function lanternArtworkIdentity(snapshot) {
  const lamp=snapshot?.lantern;
  if(!frozenLanternArtwork(snapshot))return lamp;
  const {clock,...artwork}=lamp;return artwork;
}
/** Reduced motion can truly sleep once interpolation is settled. Conservative
 * exclusions keep timed cues, treatment reservations and health recovery live. */
export function frozenFrameUnchanged(state,config,now) {
  const snapshot=state.snapshot,source=state.source,data=state.data;
  if(!config.reduced||!snapshot||state.dormant||
    snapshot.lantern?.active||snapshot.lantern?.enabled||
    Math.abs(state.blend-snapshot.rendering.blend)>.00001||
    Math.abs((state.flightFactor??0)-snapshot.rendering.flightFactor)>.00001||
    Math.abs(state.bank??0)+Math.abs(state.pitch??0)>0.00001||
    state.kinematics?.speed>0||state.token.document.getFlag?.('filament-flight','bitAnimations')?.events?.length||
    animationPending(data,snapshot,now)) {
    state.frozenInputs=null;return false;
  }
  const before=state.frozenInputs;
  if(before&&before[0]===data&&before[1]===config&&before[2]===source&&before[3]===source.x&&before[4]===source.y&&
    before[5]===source.rotation&&before[6]===source.alpha&&before[7]===source.elevation&&before[8]===source.sortLayer&&
    before[9]===source.sort&&before[10]===source.zIndex&&before[11]===state.token.w&&before[12]===state.token.h&&before[13]===state.renderRevision){
    let count=14,unchanged=true;
    for(const key in source.occlusion??{})if(typeof source.occlusion[key]!=='object'){
      if(before[count++]!==key||before[count++]!==source.occlusion[key]){unchanged=false;break;}
    }
    if(unchanged&&count===before.length)return true;
  }
  const values=state.frozenCandidate??[];
  values[0]=data;values[1]=config;values[2]=source;values[3]=source.x;values[4]=source.y;values[5]=source.rotation;
  values[6]=source.alpha;values[7]=source.elevation;values[8]=source.sortLayer;values[9]=source.sort;values[10]=source.zIndex;
  values[11]=state.token.w;values[12]=state.token.h;values[13]=state.renderRevision;
  let count=14;
  for(const key in source.occlusion??{})if(typeof source.occlusion[key]!=='object'){values[count++]=key;values[count++]=source.occlusion[key];}
  values.length=count;
  state.frozenInputs=values;state.frozenCandidate=before??[];
  return false;
}
