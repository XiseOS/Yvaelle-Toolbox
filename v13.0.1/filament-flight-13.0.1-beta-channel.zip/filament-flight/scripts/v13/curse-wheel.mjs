/** Yvaelle’s Toolbox v13 · The Heart Turned: the GM's curse wheel.
 *
 * A tap of the GM's own key opens it round the pointer; a tap again (or Escape, a right-click, a click outside) closes it.
 * Only the GM has the key, and only the GM's page ever makes the wheel.
 *
 *   the six vines       (beta.9) her six states, numbered as on the table, each a thorned vine in its own colour coming
 *                       out of black mist at the rim. Lean on a sector and its vine reaches for her crystal; click and
 *                       that state is laid on her outright (no roll).
 *   the centre          click it and she rolls for it herself.
 *   the strip beside it who is cursed (top) · "that person": the roll of faith, or one of the people pinned (the other
 *                       player characters, and any tokens the GM has selected or targeted) · how long: 1d3, 1d4 or 1d6 Spans.
 *   the bar under it    (beta.2) Watch her roll (off as it comes: on, the GM's own page plays her view as she rolls) ·
 *                       Edit the states (their names, verbs and texts) · and, while a curse is on her, what it is and
 *                       the Spans left, with −1 Span and Lift.
 * A pinned person is who the curse is about ("toward"); with nobody pinned her roll of faith chooses among the people shown.
 *
 * Nothing exists while it is closed: no element, no frame callback. Its host (curse-runtime.mjs) knows Foundry:
 *   host.her() → {name, img} | null         host.people() → [{id, n, img}]        host.active() → her record | null
 *   host.send({state, toward, people, die}) → {ok, local, name, why}               host.lift() · host.burn()
 *   host.useSelected() → name | null (make the selected token's character the one who is cursed)
 *   host.gm() / host.saveGm({die, pin, watch})    host.now()    host.edit() (open the states' editor) */
import {CURSE_NOW as TAB,CURSE_DICE,dieOf,stateIndex,spansLeft,spanWord,namesSomeone,tintOf} from './curse-model.mjs?v=13.0.1';   // (beta.2) the states as they are now, with the GM's edits
import {curseArt,BONE,MAG,EMB,PI,TAU,E,F} from './curse-art.mjs?v=13.0.1';
import {ART_MAP} from './curse-art-map.mjs?v=13.0.1';

const lerp=(a,b,v)=>a+(b-a)*v;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cssUrl=u=>`url("${String(u).replace(/["\\\n\r]/g,'')}")`;
/** (13.0.0-beta.9) The painted mist round the dial (assets/curse/mist): four rings of smoke and two puffs, each a white
 * picture whose opacity is the smoke, so the wheel can make it any colour. PUFF_KNOT: where each puff's dense knot is in it. */
export const MIST_FILES=Object.freeze(['mist-1','mist-2','mist-3','mist-4','puff-1','puff-2']);
const PUFF_KNOT=[[.3,.44],[.31,.47]];
/** The wheel's canvas (CSS px) and where its centre sits in it. */
export const WHEEL=Object.freeze({w:700,h:680,cx:350,cy:326,hub:32,reach:282});
/** How far the strip stands from the wheel's reach (to its left, to its right), and so how wide a side label may be. */
const STRIP_GAP=Object.freeze({left:112,right:36,label:138});
/** Which thread lies under a point (dx, dy from the centre): 0 to 5 · -1 the centre · -2 outside the wheel. */
export function wheelSector(dx,dy){
  const r=Math.hypot(dx,dy);if(r<=WHEEL.hub)return -1;if(r>WHEEL.reach)return -2;
  return ((Math.round((Math.atan2(dy,dx)+PI/2)/(PI/3))%6)+6)%6;
}
const FAITH_SVG='<svg width="24" height="14" viewBox="0 0 24 14" aria-hidden="true"><g fill="#ffe4fb"><path d="M3 1l2 5-2 7-2-7z"/><path d="M9 1l2 5-2 7-2-7z"/><path d="M15 1l2 5-2 7-2-7z"/><path d="M21 1l2 5-2 7-2-7z"/></g></svg>';

/** (13.0.0-beta.7) Who is pinned as the wheel opens: the one token the GM has targeted, if the strip has it; else the pin kept
 * from last time, if the strip still has that; else nobody (the roll of faith). */
export const openingPin=(saved,people,target)=>{const has=id=>typeof id==='string'&&id!==''&&(people??[]).some(p=>p.id===id);return has(target)?target:has(saved)?saved:'';};
export class CurseWheel{
  constructor({host,doc=globalThis.document,win=globalThis.window}={}){
    this.host=host;this.doc=doc;this.win=win;this.root=null;this.cv=null;this.x=null;this.art=null;this.strip=null;this.bar=null;this.watch=false;this.frame=0;this.listeners=null;this.closing=false;
    this.S={a:0,x:0,y:0,inn:[0,0,0,0,0,0],dk:[0,0,0,0,0,0],hov:-2,pull:0,lock:false,t0:0,mx:0,my:0};this.die=4;this.pin='';this.tgt='';this.people=[];this.her=null;this.tw=[];this.lastT=0;this.IMG=null;this.VC=null;this.VG=null;this.MS=null;this.MW=null;this.MT=null;
    this.stats={opened:0,laid:0,asked:0};
  }
  get open(){return !!this.root&&!this.closing;}
  /** Open round a point of the page (the pointer), or close if it is open. */
  toggle(px,py){if(this.root){this.close();return false;}this.show(px,py);return true;}
  tween(ms,fn,ez=E.io){return new Promise(res=>{this.tw.push({t0:this.win.performance.now(),ms,fn,ez,res});fn(ez(0));});}
  show(px,py){
    if(this.root)return;const d=this.doc,W=this.win.innerWidth||1280,Hh=this.win.innerHeight||720,S=this.S;this.stats.opened++;this.closing=false;
    const gm=(()=>{try{return this.host.gm?.()??{};}catch{return {};}})();this.die=dieOf(gm.die);this.pin=typeof gm.pin==='string'?gm.pin:'';this.watch=!!gm.watch;
    try{this.her=this.host.her?.()??null;this.people=this.host.people?.()??[];}catch{this.her=null;this.people=[];}
    // (13.0.0-beta.7) one token targeted before the wheel was opened: the curse is about that one, whatever was pinned last
    this.tgt=(()=>{try{return this.host.target?.()??'';}catch{return '';}})();this.pin=openingPin(this.pin,this.people,this.tgt);if(!this.people.some(p=>p.id===this.tgt))this.tgt='';
    const X=Math.round(Math.max(WHEEL.cx+4,Math.min(W-WHEEL.cx-4,Number.isFinite(px)?px:W/2))),Y=Math.round(Math.max(306,Math.min(Hh-398,Math.max(WHEEL.cy+4,Number.isFinite(py)?py:Hh/2))));   // (on a short window the bar under it stays on screen before its title does)
    Object.assign(S,{a:0,x:X,y:Y,inn:[0,0,0,0,0,0],dk:[0,0,0,0,0,0],dv:[0,0,0,0,0,0],hub:0,any:0,last:0,hitT:null,busy:false,hold:false,tell:null,press:null,roll:0,rollT:null,frz:0,fg:null,keep:-1,hov:-2,pull:0,lock:false,t0:this.win.performance.now()/1000,mx:px??X,my:py??Y});
    const root=d.createElement('div');root.className='ff-cu-wheel';root.innerHTML='<canvas class="ff-cu-wcv" aria-hidden="true"></canvas><div class="ff-cu-strip" role="group" aria-label="Curse wheel"></div><div class="ff-cu-bar" role="group" aria-label="Curse wheel: watch, edit, what is on her"></div>';d.body.appendChild(root);
    this.root=root;this.cv=root.querySelector('canvas');this.strip=root.querySelector('.ff-cu-strip');this.bar=root.querySelector('.ff-cu-bar');this.bar.style.left=X+'px';this.bar.style.top=(Y+350)+'px';const dpr=Math.min(2,this.win.devicePixelRatio||1);
    this.cv.width=Math.round(WHEEL.w*dpr);this.cv.height=Math.round(WHEEL.h*dpr);this.cv.style.width=WHEEL.w+'px';this.cv.style.height=WHEEL.h+'px';this.cv.style.left=(X-WHEEL.cx)+'px';this.cv.style.top=(Y-WHEEL.cy)+'px';
    this.x=this.cv.getContext('2d');this.x.setTransform(dpr,0,0,dpr,0,0);this.art=curseArt(this.x);this.paintings();
    // the strip stands beside the wheel, clear of its labels: to its left, or to its right where that leaves more room for the names beside it
    const roomL=X-WHEEL.reach-STRIP_GAP.left-8,roomR=W-(X+WHEEL.reach+STRIP_GAP.right+76)-8,left=roomL>=190||roomL>=roomR;
    this.strip.style.left=(left?X-WHEEL.reach-STRIP_GAP.left:X+WHEEL.reach+STRIP_GAP.right)+'px';this.strip.classList.toggle('ff-cu-right',!left);this.fillStrip();
    {const r=this.strip.getBoundingClientRect?.(),h=r?.height||300;this.strip.style.top=Math.round(Math.max(8,Math.min(Hh-h-8,Y-h/2)))+'px';}
    const move=ev=>{S.mx=ev.clientX;S.my=ev.clientY;};
    const down=ev=>{if(this.strip.contains(ev.target)||this.bar.contains(ev.target))return;ev.preventDefault();ev.stopPropagation();if(ev.button!==0){this.close();return;}if(S.lock)return;const h=wheelSector(ev.clientX-S.x,ev.clientY-S.y);if(h===-2)this.close();else void this.choose(h);};
    const key=ev=>{if(ev.key!=='Escape')return;ev.preventDefault();ev.stopPropagation();ev.stopImmediatePropagation?.();this.close();};
    const stop=ev=>{ev.preventDefault();ev.stopPropagation();};
    root.addEventListener('pointermove',move);root.addEventListener('pointerdown',down);root.addEventListener('contextmenu',stop);root.addEventListener('wheel',stop,{passive:false});this.win.addEventListener('keydown',key,true);
    this.listeners=()=>this.win.removeEventListener('keydown',key,true);
    this.tween(260,v=>S.a=v,E.out);const back=v=>1+2.6*Math.pow(v-1,3)+1.6*Math.pow(v-1,2);for(let i=0;i<6;i++)this.win.setTimeout(()=>{if(this.root===root)this.tween(360,v=>S.inn[i]=v,back);},110+i*40);
    const tick=ts=>{if(this.root!==root)return;this.frame=this.win.requestAnimationFrame(tick);
      for(const o of this.tw.slice()){const u=Math.min(1,(ts-o.t0)/o.ms);o.fn(o.ez(Math.max(0,u)));if(u>=1){this.tw.splice(this.tw.indexOf(o),1);o.res();}}
      this.draw(ts/1000);};
    this.frame=this.win.requestAnimationFrame(tick);
  }
  async close(){
    const root=this.root;if(!root||this.closing)return;this.closing=true;this.S.lock=true;root.classList.add('ff-cu-out');for(let j=0;j<6;j++)this.tween(200,v=>this.S.inn[j]=Math.min(this.S.inn[j],1-v),E.in);await this.tween(240,v=>this.S.a=Math.min(this.S.a,1-v*v),E.lin);this.destroy(root);
  }
  destroy(root=this.root){
    if(!root)return;if(this.root===root){if(this.frame)this.win.cancelAnimationFrame(this.frame);this.frame=0;this.listeners?.();this.listeners=null;this.root=null;this.cv=null;this.x=null;this.art=null;this.strip=null;this.bar=null;this.tw=[];this.closing=false;}
    root.remove();
  }
  /** The person pinned, or null (the roll of faith). */
  pinned(){return this.people.find(p=>p.id===this.pin)??null;}
  save(){try{this.host.saveGm?.({die:this.die,pin:this.pin,watch:this.watch});}catch{}}
  /* ───────── the strip ───────── */
  fillStrip(){
    const s=this.strip;if(!s||this.S.lock||this.S.busy)return;const her=this.her;this.fillBar();
    const dot=(p,cls,label,inner='')=>`<button type="button" class="ff-cu-sp ${cls}" data-id="${esc(p?.id??'')}">${inner}<span>${esc(label)}</span></button>`;
    let h=`<div class="ff-cu-st">Cursed</div><button type="button" class="ff-cu-sp ff-cu-her${her?'':' ff-cu-none'}" data-act="her">${her&&!her.img?esc(her.name[0]):her?'':'?'}<span>${her?esc(her.name)+' · click to use the selected token instead':'Nobody yet: select her token, then click here'}</span></button>`;
    h+=`<div class="ff-cu-st ff-cu-rule">That<br>person</div>`+dot(null,'ff-cu-faith'+(this.pin?'':' ff-cu-pin'),this.pin?'Roll of faith':'Roll of faith · chosen',FAITH_SVG);
    for(const p of this.people)h+=dot(p,'ff-cu-who'+(p.id===this.pin?' ff-cu-pin':''),p.n+(p.id===this.pin?(p.id===this.tgt?' · your target · pinned':' · pinned'):''),p.img?'':esc(p.n[0]));
    h+=`<div class="ff-cu-st ff-cu-rule">Lasts</div><div class="ff-cu-dd">${CURSE_DICE.map(n=>`<button type="button" class="${n===this.die?'ff-cu-on':''}" data-die="${n}">1d${n}</button>`).join('')}</div>`;
    s.innerHTML=h;
    for(const b of s.querySelectorAll('.ff-cu-sp')){const id=b.dataset.id,p=this.people.find(q=>q.id===id);const who=b.classList.contains('ff-cu-her')?(her?{n:her.name,img:her.img}:null):p;
      if(who){const [c1,c2]=tintOf(who.n);b.style.setProperty('--c1',c1);b.style.setProperty('--c2',c2);if(who.img){b.style.backgroundImage=cssUrl(who.img);b.classList.add('ff-cu-pic');}}}
    if(!s.dataset.bound){s.dataset.bound='1';s.addEventListener('pointerdown',ev=>ev.stopPropagation());s.addEventListener('click',ev=>{const b=ev.target.closest?.('button');if(!b||!s.contains(b))return;ev.preventDefault();b.blur?.();this.stripAct(b);});}
  }
  /** The bar under the wheel: Watch · Edit the states · what is on her now, with −1 Span and Lift. */
  fillBar(){
    const b=this.bar;if(!b)return;const act=(()=>{try{return this.host.active?.()??null;}catch{return null;}})();
    let h=`<button type="button" class="ff-cu-tog${this.watch?' ff-cu-on':''}" data-act="watch" aria-pressed="${this.watch}" title="On: your own screen plays her view as she rolls (when her player is connected; otherwise it is shown here anyway)">Watch her roll<b>${this.watch?'On':'Off'}</b></button>`
      +'<button type="button" data-act="edit" title="Rename the six states, change the word after “You are made to”, and rewrite what each one says">Edit the states</button>';
    if(act?.k){const e=TAB[stateIndex(act.k)],n=spansLeft(act,this.host.now?.()??0);
      h+=`<span class="ff-cu-now" style="--ffcu-ac:rgb(${e.acc})">On her<b>${esc(e.n)}</b><i>${n===null?'not rooted':n+' '+spanWord(n)}</i></span>${n!==null&&n>0?'<button type="button" data-act="burn" title="One Span has passed">−1 Span</button>':''}<button type="button" data-act="lift" title="End the curse now">Lift</button>`;}
    else if(act)h+='<span class="ff-cu-now">On her<i>a roll is asked</i></span><button type="button" data-act="lift" title="Take the request back">Lift</button>';
    b.innerHTML=h;
    if(!b.dataset.bound){b.dataset.bound='1';b.addEventListener('pointerdown',ev=>ev.stopPropagation());b.addEventListener('click',ev=>{const t=ev.target.closest?.('button');if(!t||!b.contains(t))return;ev.preventDefault();t.blur?.();this.stripAct(t);});}
  }
  stripAct(b){
    const act=b.dataset.act;
    if(act==='watch'){this.watch=!this.watch;this.save();this.fillBar();return;}
    if(act==='edit'){const host=this.host;void this.close().then(()=>{try{host.edit?.();}catch{}});return;}
    if(act==='her'){let name=null;try{name=this.host.useSelected?.()??null;}catch{}if(name){this.her=this.host.her?.()??null;this.people=this.host.people?.()??[];if(this.pin&&!this.people.some(p=>p.id===this.pin))this.pin='';}this.fillStrip();return;}
    if(act==='lift'){try{this.host.lift?.();}catch{}this.win.setTimeout(()=>this.fillStrip(),120);return;}
    if(act==='burn'){try{this.host.burn?.();}catch{}this.win.setTimeout(()=>this.fillStrip(),120);return;}
    if(b.dataset.die){this.die=dieOf(+b.dataset.die);this.save();this.fillStrip();return;}
    if(b.classList.contains('ff-cu-faith')){this.pin='';this.save();this.fillStrip();return;}
    if(b.classList.contains('ff-cu-who')){this.pin=b.dataset.id===this.pin?'':b.dataset.id;this.save();this.fillStrip();}
  }
  /* ───────── a choice ───────── */
  /** h: 0 to 5 lays that state on her; -1 (the centre) lets her roll for it. */
  async choose(h){
    const S=this.S,root=this.root;if(!root||S.lock)return;const pin=this.pinned();
    S.busy=true;S.press=this.win.performance.now()/1000;S.hov=h;S.hold=true;const wind=h>=0?this.tween(110,v=>S.pull=-v,E.out):null;let out=null;try{out=await this.host.send({state:h>=0?h:null,toward:pin,people:this.people,die:this.die});}catch(e){out={ok:false,why:String(e?.message??e)};}
    if(this.root!==root)return;
    S.busy=false;if(!out?.ok){S.hold=false;if(wind)this.tween(160,v=>S.pull=-(1-v),E.out);this.note(out?.why||'Nothing was sent.','',null,true);return;}if(wind)await wind;
    S.lock=true;S.hov=h;const hold=ms=>new Promise(r=>this.win.setTimeout(r,ms));
    // laid: its vine draws back a hair, strikes her crystal, and she takes its colour; the other five go back the way they came
    if(h>=0){this.stats.laid++;S.keep=h;await this.tween(70,v=>S.pull=-1+1.6*v,v=>v*v*v);S.hitT=this.win.performance.now()/1000;S.frz=S.hitT+.05;for(let j=0;j<6;j++)if(j!==h)this.win.setTimeout(()=>{if(this.root===root)this.tween(300,v=>S.inn[j]=Math.min(S.inn[j],1-v),E.in);},50+((j-h+6)%6)*34);this.tween(260,v=>S.pull=.6*(1-v)+.15,E.out);await hold(520);}
    // asked: her flower flares and all six start for her at once
    else{this.stats.asked++;S.rollT=this.win.performance.now()/1000;this.tween(230,v=>S.roll=v,E.out);await hold(1000);}
    const who=h>=0&&!namesSomeone(TAB[h].k)?'all within 15 ft':pin?`toward ${pin.n}`:this.people.length?'toward the roll of faith':'toward no one named',name=out.name||'her';
    // (with no player of hers connected it is shown on this very page: that is its own confirmation)
    // (nothing to add when this page shows it itself, or watches it)
    if(!out.local&&!out.watching)this.note(h>=0?`${TAB[h].n} — laid on ${name}`:`Roll sent to ${name}`,`${who} · 1d${this.die} Spans`,h>=0?TAB[h].acc:null);
    root.classList.add('ff-cu-out');if(h>=0){S.fg=1;await this.tween(460,v=>{S.a=Math.min(S.a,1-Math.min(1,v*460/340));S.fg=1-E.out(Math.max(0,Math.min(1,(v*460-300)/160)));},E.lin);}else await this.tween(280,v=>{S.a=Math.min(S.a,1-v);},E.in);this.destroy(root);
  }
  /** A small confirmation where the wheel was (it goes by itself). */
  note(title,line,acc=null,bad=false){
    const d=this.doc,c=d.createElement('div');c.className='ff-cu-chip'+(bad?' ff-cu-bad':'');c.style.setProperty('--ffcu-ac',acc?`rgb(${acc})`:'#ff78f6');
    c.innerHTML=`<svg class="ff-cu-gem" width="16" height="24" viewBox="-8 -11 16 24" aria-hidden="true"><path d="M0-10 5 0 0 12-5 0Z" fill="#120c10" stroke="#5a4650"/><path class="ff-cu-core" d="M0-3 1.6 0 0 4-1.6 0Z"/></svg><div><div class="ff-cu-n">${esc(title)}</div>${line?`<div class="ff-cu-m">${esc(line)}</div>`:''}</div>`;
    const W=this.win.innerWidth||1280;c.style.left=Math.max(8,Math.min(W-380,this.S.x+34))+'px';c.style.top=Math.max(8,this.S.y-22)+'px';d.body.appendChild(c);void c.offsetWidth;c.classList.add('ff-cu-on');
    this.win.setTimeout(()=>{c.classList.remove('ff-cu-on');this.win.setTimeout(()=>c.remove(),600);},bad?3200:2400);return c;
  }
  /* ───────── the paintings (13.0.0-beta.9): her flower at the hub, a thorned vine for each state ───────── */
  /** Ask for the paintings the full view is made of (once; they stay for the next opening). Until they are in, the wheel is
   * drawn in lines as it used to be. */
  paintings(){
    if(this.IMG)return;this.IMG={};let base='';try{base=this.host.art?.()??'';}catch{}if(!base)return;
    for(const n of ['pure','tie','tie-bone','tie-glow',...MIST_FILES.map(f=>'mist/'+f)]){try{const im=this.doc.createElement('img');im.decoding='async';im.src=`${base}/${n}.webp`;this.IMG[n]=im;}catch{}}
  }
  /** The vine in each state's colours, and its glow in each state's colour (made once, when the paintings are in). */
  vines(){
    if(this.VC)return true;const I=this.IMG,ok=im=>!!im&&im.complete===true&&im.naturalWidth>0;if(!I||!ok(I.pure)||!ok(I.tie)||!ok(I['tie-bone'])||!ok(I['tie-glow']))return false;
    try{const T=ART_MAP.tie,mk=()=>{const c=this.doc.createElement('canvas');c.width=T.w;c.height=T.h;return c;};
      this.VC=TAB.map(e=>{const c=mk(),g=c.getContext('2d'),m=mk(),mg=m.getContext('2d');mg.drawImage(I['tie-bone'],0,0);mg.globalCompositeOperation='source-in';mg.fillStyle=`rgb(${e.acc})`;mg.fillRect(0,0,T.w,T.h);g.drawImage(I.tie,0,0);g.globalCompositeOperation='color';g.drawImage(m,0,0);g.globalCompositeOperation='source-over';g.globalAlpha=.85;g.drawImage(m,0,0);return c;});
      this.VG=TAB.map(e=>{const c=mk(),g=c.getContext('2d');g.drawImage(I['tie-glow'],0,0);g.globalCompositeOperation='source-atop';g.fillStyle=`rgba(${e.acc},.72)`;g.fillRect(0,0,T.w,T.h);return c;});return true;}catch{this.VC=null;this.VG=null;this.IMG={};return false;}
  }
  /** One vine, straight: its end at (tx,ty), running back from there along the angle `back` for `len` px; it fades out toward
   * its far end. k: its scale. flip: which way its thorns lean. */
  vine(im,tx,ty,back,len,k,flip,al,lighter=false){
    const x=this.x,T=ART_MAP.tie,a0=x.globalAlpha,n=Math.max(6,Math.ceil(len/7)),sw=len/k/n;x.save();x.translate(tx,ty);x.rotate(back+PI);x.scale(k,k*flip);if(lighter)x.globalCompositeOperation='lighter';
    for(let j=0;j<n;j++){const u=(j+.5)/n,f=Math.min(1,(1-u)/.14);x.globalAlpha=a0*al*f*f*(3-2*f);x.drawImage(im,T.tipx-(j+1)*sw,0,sw+1,T.h,-(j+1)*sw,-T.cy,sw+1,T.h);}
    x.restore();x.globalAlpha=a0;
  }
  /** One vine along a curve (a quadratic: its end at P0, bowed by C, its root at P2): the painting laid along it in short
   * lengths, fading out over its last part toward the root. */
  vineC(im,P0,C,P2,k,flip,al,lighter=false,wob=null,af=null){
    const x=this.x,T=ART_MAP.tie,a0=x.globalAlpha,N=30,at=u=>{const w=1-u;return [w*w*P0[0]+2*w*u*C[0]+u*u*P2[0],w*w*P0[1]+2*w*u*C[1]+u*u*P2[1]];};let s=0,p=at(0);if(lighter)x.globalCompositeOperation='lighter';
    const at0=at,atw=wob?u=>{const a=at0(u),b=at0(Math.min(1,u+.02)),c0=at0(Math.max(0,u-.02)),tx=b[0]-c0[0],ty=b[1]-c0[1],tl=Math.hypot(tx,ty)||1,w=wob(u);return [a[0]-ty/tl*w,a[1]+tx/tl*w];}:at0;p=atw(0);
    for(let j=0;j<N;j++){const q=atw((j+1)/N),ds=Math.hypot(q[0]-p[0],q[1]-p[1]),u=(j+.5)/N,f=Math.min(1,(1-u)/.2)*(af?af(u):1),sw=ds/k;if(T.tipx-(s+ds)/k<2)break;if(f<.01){s+=ds;p=q;continue;}
      x.save();x.translate(p[0],p[1]);x.rotate(Math.atan2(q[1]-p[1],q[0]-p[0])+PI);x.scale(k,k*flip);x.globalAlpha=a0*al*f*f*(3-2*f);x.drawImage(im,T.tipx-(s+ds)/k,0,sw+1.6,T.h,-sw,-T.cy,sw+1.6,T.h);x.restore();s+=ds;p=q;}
    x.globalAlpha=a0;x.globalCompositeOperation='source-over';
  }
  /** (beta.9) The black mist round the dial's rim, which the vines come out of: soft black clouds going slowly round (those
   * nearer the rim faster), thickest where each vine is rooted, with a few thin pale wisps in it so that its turning shows.
   * Two small sprites, made once, drawn many times. k: how much of it there is (0 to 1). */
  /** The painted mist, once its pictures are in: each made black, and one ring a second time in a dark ember red for the
   * little light that is in it. Null until then (the drawn mist stands in). */
  mistArt(){
    if(this.MT)return this.MT;const I=this.IMG,ok=im=>!!im&&im.complete===true&&im.naturalWidth>0;if(!I||!MIST_FILES.every(f=>ok(I['mist/'+f])))return null;
    try{const tint=(im,col)=>{const c=this.doc.createElement('canvas');c.width=im.naturalWidth;c.height=im.naturalHeight;const g=c.getContext('2d');g.drawImage(im,0,0);g.globalCompositeOperation='source-in';g.fillStyle=col;g.fillRect(0,0,c.width,c.height);return c;};
      this.MT={rings:[1,2,3,4].map(n=>tint(I['mist/mist-'+n],'rgb(4,1,6)')),haze:[1,2,3,4].map(n=>tint(I['mist/mist-'+n],'rgb(104,58,112)')),ember:[3,4].map(n=>tint(I['mist/mist-'+n],'rgb(150,22,78)')),puffs:[1,2].map(n=>tint(I['mist/puff-'+n],'rgb(4,1,6)'))};}catch{this.MT=null;}
    return this.MT;
  }
  /** The mist as painted. Four rings of smoke lie over one another, each turning at its own pace and each coming and going
   * slowly, so that what is seen is never the same twice and never jumps; the streaming ones turn faster than the billowing
   * ones. A dark ember light turns in it. At each vine's root a knot of smoke sits, its tendrils trailing in along the vine,
   * two of them fading through one another. open: 0 as the wheel opens → 1 (it gathers inward and slows); kick: a blow just
   * landed (it is thrown round). */
  mistPainted(t,k,roots,open,kick,pass){
    const x=this.x,X=WHEEL.cx,Y=WHEEL.cy,a0=x.globalAlpha,M=this.MT,R=WHEEL.reach,spin=2.2*(1-open)*(1-open)+.9*kick;
    // [which ring, how far out its smoke sits (its inner edge is at about half of this), how fast it turns, when it comes and goes, over the vines?]
    const LAY=[[0,1.34,.034,0,0],[2,1.26,.085,1.9,0],[1,1.46,.052,3.6,1],[3,1.38,.12,5.1,1]];
    const rings=over=>{for(const [n,sc,sp,ph,ov] of LAY){if(ov!==over)continue;const im=M.rings[n],al=.5+.4*Math.sin(t*.21+ph),sz=2*R*sc/.95*(1+.3*(1-open));x.save();x.translate(X,Y);x.rotate(t*sp+ph*1.7+spin*(1+n*.2));x.globalAlpha=a0*k*Math.min(1,al+.25)*.34;x.rotate(-.035);x.drawImage(M.haze[n],-sz/2,-sz/2,sz,sz);x.rotate(.035);x.globalAlpha=a0*k*Math.min(1,al+.3)*(over?.8:1);x.drawImage(im,-sz/2,-sz/2,sz,sz);x.restore();}};
    x.save();
    if(!pass){// under the vines: the dark at the rim, two rings of smoke, and the little light in it (a dark ember, turning the other way)
      {const g=x.createRadialGradient(X,Y,236,X,Y,R);g.addColorStop(0,'rgba(3,1,4,0)');g.addColorStop(.6,'rgba(3,1,4,.5)');g.addColorStop(1,'rgba(3,1,4,.95)');x.globalAlpha=a0*k;x.fillStyle=g;x.beginPath();x.arc(X,Y,R,0,TAU);x.fill();}
      rings(0);x.save();x.globalCompositeOperation='lighter';for(let n=0;n<2;n++){const sz=2*R*(1.5+.12*n)/.95;x.save();x.globalAlpha=a0*k*(.07+.05*Math.sin(t*.5+n*2.4));x.translate(X,Y);x.rotate(-t*(.04+.03*n)+n*2.1);x.drawImage(M.ember[n],-sz/2,-sz/2,sz,sz);x.restore();}x.restore();}
    else{// over them: two thinner rings, and the knot of smoke each vine comes out of
      rings(1);
      for(let i=0;i<roots.length;i++){const [a,rr]=roots[i],px=X+Math.cos(a)*(rr-4),py=Y+Math.sin(a)*(rr-4),inward=a+PI-.55;for(let q=0;q<2;q++){const im=M.puffs[(i+q)%2],kn=PUFF_KNOT[(i+q)%2],w=236*(1+.07*Math.sin(t*.8+i*1.3+q*2)),hh=w*im.height/im.width,al=.5+.5*Math.sin(t*.45+i*1.1+q*PI);
          x.save();x.globalAlpha=a0*k*(.62+.38*al);x.translate(px,py);x.rotate(inward+.12*Math.sin(t*.6+i+q*1.7));x.scale(1,(i+q)%2?-1:1);x.drawImage(im,-w*kn[0],-hh*kn[1],w,hh);x.restore();}}}
    x.restore();x.globalAlpha=a0;
  }
  mist(t,k,roots,open=1,kick=0,pass=1){
    const x=this.x,X=WHEEL.cx,Y=WHEEL.cy,a0=x.globalAlpha;if(k<.01)return;if(this.mistArt()){this.mistPainted(t,k,roots,open,kick,pass);return;}if(!pass)return;
    if(!this.MS){const mk=(c,stops)=>{const cv=this.doc.createElement('canvas');cv.width=cv.height=128;const g=cv.getContext('2d'),gr=g.createRadialGradient(64,64,0,64,64,64);for(const [u,a] of stops)gr.addColorStop(u,`rgba(${c},${a})`);g.fillStyle=gr;g.fillRect(0,0,128,128);return cv;};
      this.MS=mk('3,1,4',[[0,.95],[.45,.7],[.8,.22],[1,0]]);this.MW=mk('150,112,150',[[0,.5],[.5,.2],[1,0]]);}
    const h=n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);},put=(im,px,py,sx,sy,rot,al)=>{x.save();x.globalAlpha=a0*al;x.translate(px,py);x.rotate(rot);x.drawImage(im,-sx/2,-sy/2,sx,sy);x.restore();};
    x.save();
    // the band itself: black at the rim, thinning inward
    {const g=x.createRadialGradient(X,Y,214,X,Y,WHEEL.reach);g.addColorStop(0,'rgba(3,1,4,0)');g.addColorStop(.4,'rgba(3,1,4,.68)');g.addColorStop(1,'rgba(3,1,4,.98)');x.globalAlpha=a0*k;x.fillStyle=g;x.beginPath();x.arc(X,Y,WHEEL.reach,0,TAU);x.fill();}
    // the clouds in it, going round
    for(let n=0;n<30;n++){const r0=220+58*h(n),sp=.09+.22*(r0-220)/58+.05*h(n+50),a=h(n+9)*TAU+t*sp,rr=r0+8*Math.sin(t*.5+n),sz=(60+56*h(n+3))*(.9+.14*Math.sin(t*.7+n*2));put(this.MS,X+Math.cos(a)*rr,Y+Math.sin(a)*rr,sz*1.6,sz,a+PI/2,Math.min(1,k*(.56+.36*h(n+4))));}
    // thick where a vine is rooted: it comes out of that
    for(let i=0;i<roots.length;i++)for(let q=0;q<5;q++){const a=roots[i][0]+(q-2)*.085+.05*Math.sin(t*.8+i+q),rr=roots[i][1]-16+10*(q%2)+6*Math.sin(t*.6+q*2+i),sz=78+18*Math.sin(t*.9+q+i*3);put(this.MS,X+Math.cos(a)*rr,Y+Math.sin(a)*rr,sz*1.35,sz,a+PI/2,k*.8);}
    x.restore();x.save();x.globalCompositeOperation='lighter';x.lineCap='round';x.shadowColor='rgba(118,84,128,.8)';
    // its curls: pale lengths of it carried round, each peeling inward off the band as it goes
    for(let n=0;n<18;n++){const r0=236+42*h(n+70),sp=.16+.34*h(n+72),a=h(n+90)*TAU+t*sp,span=.12+.5*h(n+71)*h(n+75),curl=16+60*h(n+73),fl=.5+.5*Math.sin(t*.8+n*1.7),N=9,w0=7+20*h(n+74);x.strokeStyle='rgba(118,84,128,1)';x.shadowBlur=20;
      let pa=a,pr=r0;for(let q=1;q<=N;q++){const u=q/N,aa=a-span*u,rr=r0-curl*u*u,tp=Math.sin(PI*(u-.5/N));x.globalAlpha=a0*k*(.04+.06*fl)*(.4+.6*tp);x.lineWidth=Math.max(1,w0*tp);x.beginPath();x.moveTo(X+Math.cos(pa)*pr,Y+Math.sin(pa)*pr);x.lineTo(X+Math.cos(aa)*rr,Y+Math.sin(aa)*rr);x.stroke();pa=aa;pr=rr;}}
    x.restore();x.globalAlpha=a0;
  }
  /* ───────── one frame ───────── */
  draw(t){
    const x=this.x,S=this.S;if(!x)return;const {path,light,briar,thorn,glow,txt,eyebrow,sigil}=this.art,X=WHEEL.cx,Y=WHEEL.cy,a0=S.a,dt=Math.min(.05,Math.max(.001,t-(this.lastT||t)));this.lastT=t;const sm=r=>1-Math.pow(1-r,dt*30);
    if(!S.lock&&!S.hold){const over=this.strip&&this.doc.elementFromPoint?.(S.mx,S.my),on=over&&(this.strip.contains(over)||this.bar?.contains(over));S.hov=on?-2:wheelSector(S.mx-S.x,S.my-S.y);if(this.cv)this.cv.style.cursor=S.hov>=-1&&!on?'pointer':'';}
    if(S.frz&&t<S.frz)return;   // (beta.9) a blow lands: one held breath
    x.clearRect(0,0,WHEEL.w,WHEEL.h);if(a0<.01&&!(S.fg>0.01))return;
    const g=x.createRadialGradient(X,Y,20,X,Y,300);g.addColorStop(0,`rgba(8,5,9,${.93*a0})`);g.addColorStop(.74,`rgba(8,5,9,${.86*a0})`);g.addColorStop(1,'rgba(8,5,9,0)');x.fillStyle=g;x.beginPath();x.arc(X,Y,300,0,TAU);x.fill();
    const hov=S.hov,tt=t-S.t0;
    if(this.vines()){this.drawPainted(t,sm,dt);return;}
    for(let i=0;i<6;i++){const e=TAB[i],an=-PI/2+i*PI/3,dx=Math.cos(an),dy=Math.sin(an),hv=hov===i,inn=S.inn[i];S.dk[i]+=((hv?1:0)-S.dk[i])*sm(.14);const dk=S.dk[i],dim=(hov>=0&&!hv)?.42:1,n=30,P=[],ext=hv?S.pull*16:0;
      for(let j=0;j<=n;j++){const u=j/n,r=24+(128+ext)*u*inn,vb=4*Math.sin(PI*u)*Math.cos(tt*21+i*2)*Math.exp(-tt*3.2)+(hv?.9*Math.sin(t*33+u*9)*Math.sin(PI*u):0);P.push([X+dx*r-dy*vb,Y+dy*r+dx*vb]);}
      x.save();x.globalAlpha=a0;const i0=Math.round(n*dk);if(i0<n)light(P.slice(i0),dim,0);
      if(i0>0){path(P.slice(0,i0+1));x.strokeStyle=`rgba(${EMB},.3)`;x.lineWidth=11;x.stroke();briar(P.slice(0,i0+1),1,.9);for(let j=3;j<i0;j+=4){const a=Math.atan2(P[j+1][1]-P[j-1][1],P[j+1][0]-P[j-1][0]);thorn(P[j][0],P[j][1],a+((j>>2)%2?1:-1)*(PI/2-.4),9);}if(dk<.98)glow(P[i0][0],P[i0][1],16,.7,EMB);}
      sigil(e.k,X+dx*(172+ext),Y+dy*(172+ext),13,inn*(hv?1:.7*dim),hv?e.acc:BONE);const lx=X+dx*(200+ext),ly=Y+dy*(200+ext),al=Math.abs(dx)<.3?'center':dx>0?'left':'right';
      const lab=(i+1)+'  '+e.n,room=al==='center'?260:STRIP_GAP.label;let px=hv?20:17;x.font=F.caps(px);x.letterSpacing='2px';const lw=x.measureText(lab).width;if(lw>room)px*=room/lw;
      txt(lab,lx+(al==='left'?4:al==='right'?-4:0),ly+(al==='center'?(dy<0?-4:16):6),F.caps(px),2,BONE,inn*(hv?1:.66*dim),al);x.restore();}
    x.save();x.globalAlpha=a0;x.fillStyle='rgba(13,9,11,1)';x.beginPath();x.arc(X,Y,7,0,TAU);x.fill();x.strokeStyle='rgba(112,84,100,.9)';x.lineWidth=1;x.stroke();glow(X,Y,hov===-1?30:hov<0?22:14,hov===-1?.7:hov<0?.45:.3,hov<0?MAG:EMB);
    const e=hov>=0?TAB[hov]:null,pin=this.pinned(),name=this.her?.name??'';
    if(!this.her)txt('NOBODY IS CHOSEN TO CURSE YET',X,Y+262,F.sans(10),2.8,'255,150,248',1);
    else if(e)eyebrow(`Lay on ${name}:`,e.n,e.acc,X,Y+262,1);else txt(`LET ${name.toUpperCase()} ROLL FOR IT`,X,Y+262,F.sans(10),2.8,'255,150,248',hov===-1?1:.72);
    const who=e&&!namesSomeone(e.k)?'all within 15 ft':pin?`toward ${pin.n} · pinned`:this.people.length?'toward whoever the roll of faith finds':'toward no one named';
    txt(this.her?`${who}  ·  1d${this.die} Spans`:'Select her token, then click the top of the strip',X,Y+282,F.ital(14),0,BONE,.7);x.restore();
  }
  /** (13.0.0-beta.9) The wheel as the full view is painted: her flower at the hub (click it and she rolls), and six thorned
   * vines coming in on it from all round, each in its state's colours with its name beyond it. Lean on one and it goes for her
   * crystal and burns in its own colour, the others fall back and dim, and her flower dulls; lean on her flower and it
   * brightens and the vines hang back. */
  drawPainted(t,sm,dt=.016){
    const x=this.x,S=this.S,{glow,txt}=this.art,X=WHEEL.cx,Y=WHEEL.cy,a0=S.a,hov=S.hov,tt=t-S.t0,FB=ART_MAP.flower,I=this.IMG,cl=v=>Math.max(0,Math.min(1,v)),DISC=WHEEL.reach,HAIR='255,120,246';
    S.hub=(S.hub??0)+((hov===-1?1:0)-(S.hub??0))*sm(.16);S.any=(S.any??0)+((hov>=0?1:0)-(S.any??0))*sm(.2);if(hov>=0)S.last=hov;const roll=S.roll||0,hub=Math.max(S.hub,roll),any=S.any,e=hov>=0?TAB[hov]:null,eL=TAB[S.last??0],breath=.5+.5*Math.sin(t*1.7);
    // struck (a state laid): for a moment everything is knocked along the blow, and she takes its colour
    const hg=S.hitT!=null?t-S.hitT:-1,hitK=hg>=0?(hg<.18?1:Math.exp(-(hg-.18)*5.5)):0,hd=-PI/2+(S.keep>=0?S.keep:0)*PI/3,jx=hg>=0?-Math.cos(hd)*8*Math.exp(-hg*13)*Math.cos(hg*52):0,jy=hg>=0?-Math.sin(hd)*8*Math.exp(-hg*13)*Math.cos(hg*52):0,aF=S.fg!=null?S.fg:a0,gone=hg>=0?1-.65*cl(hg/.2):1;
    // asked (her flower clicked): she dips and swells, the six surge at her one after another and fall back, and the numbers run round twice like a die
    const ra=S.rollT!=null?t-S.rollT:-1,bk=v=>1+2.6*Math.pow(v-1,3)+1.6*Math.pow(v-1,2),rs=ra<0?1:ra<.08?1-.06*ra/.08:ra<.23?lerp(.94,1.14,bk((ra-.08)/.15)):1.14-.05*cl((ra-.23)/.4),rg=ra<0?1:1+.6*cl(ra/.23)-.4*cl((ra-.23)/.17),surge=i=>ra<0?0:34*Math.sin(PI*cl((ra-.08-i*.03)/.36)),die=i=>{if(ra<0)return 0;let p=0;for(let q=0;q<2;q++){const t1=q?.37+i*.08:.1+i*.045;if(ra>=t1)p=Math.max(p,Math.exp(-(ra-t1)*(q?9:13)));}return p;};
    // the dial: one dark plate with a clean edge, a fine line of her colour round it and between the six sectors (each sector
    // is what a click there lays: its name is in it, and it lights when leant on)
    const ag=cl(a0*2.2),disc=()=>{x.beginPath();x.arc(X,Y,DISC,0,TAU);};
    x.save();x.globalAlpha=1;x.shadowColor=`rgba(0,0,0,${.7*ag})`;x.shadowBlur=26;x.shadowOffsetY=6;{const g=x.createRadialGradient(X,Y,30,X,Y,DISC);g.addColorStop(0,`rgba(40,13,38,${.985*ag})`);g.addColorStop(.62,`rgba(40,15,41,${.985*ag})`);g.addColorStop(1,`rgba(34,14,37,${.985*ag})`);x.fillStyle=g;}disc();x.fill();x.restore();
    x.save();x.translate(jx,jy);disc();x.clip();
    // her light behind her, always her own magenta; it catches as the wheel opens
    const lit=1-.5*Math.exp(-tt*5);x.save();x.globalAlpha=a0;glow(X,Y,(150+30*hub)*lit*rg,Math.min(.55,.22+.05*breath+.24*hub+.3*Math.exp(-tt*4))*(1-.3*any)*(1-hitK),MAG);if(hitK>.02)glow(X,Y,150,.5*hitK,eL.acc);x.restore();
    x.save();x.globalAlpha=a0;this.mist(t,cl(tt*3.2)*(1-.2*hitK),[],E.out(cl(tt/.9)),hg>=0?Math.exp(-hg*3):0,0);x.restore();
    // the six vines. Each is rooted at the rim beside its own name and sweeps in along its own spoke to just short of her
    // petals. Each is on a spring: leant on, it goes for her crystal and runs a little past before it settles; let go, it whips back
    const TIP=[92,98,96,98,96,98],OFF=[0,0,0,.2,0,0],RR=[268,268,268,268,268,268],SWV=[.62,.62,.62,.62,.62,.62],roots=[];let lean=[0,0];
    for(let i=0;i<6;i++){const st=TAB[i],an=-PI/2+i*PI/3,dx=Math.cos(an),dy=Math.sin(an),hv=hov===i,inn=S.inn[i];S.dv[i]+=(760*((hv?1:0)-S.dk[i])-39*S.dv[i])*dt;S.dk[i]+=S.dv[i]*dt;if(S.dk[i]<0){S.dk[i]=0;S.dv[i]=Math.max(0,S.dv[i]);}
      const dk=S.dk[i],dim=(1-.34*any*(1-cl(dk)))*(S.keep>=0&&S.keep!==i?gone:1),ext=hv?S.pull*30:0;lean[0]-=dx*dk;lean[1]-=dy*dk;if(inn<.02){roots.push([an+SWV[i],RR[i]]);continue;}
      const tip1=lerp(TIP[i],i===3?46:24,dk)+11*S.hub+7*any*(1-cl(dk))-surge(i)-ext+2.5*Math.sin(t*1.3+i*1.9)*(1-cl(dk)),tipR=lerp(RR[i]-8,tip1,inn),sway=(.022*Math.sin(t*.9+i*2.3)+.008*Math.sin(t*23+i)*cl(dk))*(1-.5*cl(dk))+.05*Math.sin(tt*19+i*2)*Math.exp(-tt*3.2),kk=.62+.3*cl(dk);
      const ra2=an+SWV[i]+sway*1.4,rr=RR[i];roots.push([ra2,rr]);const ta=an+OFF[i]*(1+.5*cl(dk)),P0=[X+Math.cos(ta)*tipR,Y+Math.sin(ta)*tipR],cr=tipR+.56*(rr-tipR),ca=an+.4+sway*2,PC=[X+Math.cos(ca)*cr,Y+Math.sin(ca)*cr],P2=[X+Math.cos(ra2)*rr,Y+Math.sin(ra2)*rr];if(rr-tipR<8)continue;
      // leant on, it is the thing that shows it: it thickens and burns in its own colour, a slow wave runs down it from its
      // root, its end feels about over her crystal, and light runs along it from the mist to its tip again and again
      const dc=cl(dk),wob=dc>.02?u=>dc*(7*Math.sin(u*7.5-t*5.2+i)+3*Math.sin(u*15+t*8.1))*Math.sin(PI*Math.min(1,u*1.15))*(.35+.65*u):null;
      if(dc>.02){const fa=t*3.1+i,fr=5*dc;P0[0]+=Math.cos(fa)*fr+2*dc*Math.sin(t*11+i);P0[1]+=Math.sin(fa*1.3)*fr;}
      x.save();x.globalAlpha=(S.keep===i?aF:a0)*cl(inn*1.6);
      if(dc>.03){x.save();x.globalAlpha*=dc;for(let q=0;q<=9;q++){const u=q/9,w=1-u,gx=w*w*P0[0]+2*w*u*PC[0]+u*u*P2[0],gy=w*w*P0[1]+2*w*u*PC[1]+u*u*P2[1];glow(gx,gy,34+8*Math.sin(t*4-q),.2*(1-.5*u),st.acc);}x.restore();}
      if(dc>.03){x.save();x.globalAlpha*=dc;x.shadowColor=`rgba(${st.acc},.9)`;x.shadowBlur=18;this.vineC(this.VG[i],P0,PC,P2,kk*1.12,i%2?1:-1,.55,true,wob);x.restore();}
      this.vineC(this.VC[i],P0,PC,P2,kk,i%2?1:-1,dim,false,wob);
      this.vineC(this.VG[i],P0,PC,P2,kk,i%2?1:-1,(.8+.14*breath)*dim+.9*dc+.5*roll,true,wob);if(dc>.04)this.vineC(this.VG[i],P0,PC,P2,kk,i%2?1:-1,.7*dc+(S.keep===i?hitK:0),true,wob);
      if(dc>.04){for(let q=0;q<2;q++){const pu=1-((t*1.25+q*.5+i*.13)%1);this.vineC(this.VG[i],P0,PC,P2,kk*1.05,i%2?1:-1,1.6*dc,true,wob,u=>Math.exp(-(u-pu)*(u-pu)/.006));}
        x.globalAlpha=(S.keep===i?aF:a0)*dc;glow(P0[0],P0[1],22+9*Math.sin(t*6+i)+(S.keep===i?26*hitK:0),.6,st.acc);glow(P0[0],P0[1],7,.8,'255,236,246');}x.restore();}
    // the black mist they come out of, round the rim and over their roots (it is there before they are)
    x.save();x.globalAlpha=a0;this.mist(t,cl(tt*3.2)*(1-.2*hitK),roots,E.out(cl(tt/.9)),hg>=0?Math.exp(-hg*3):0);x.restore();
    // the lines between the sectors: nothing near her, fine toward the rim
    x.save();x.globalAlpha=a0*cl(tt*4);x.lineWidth=1;for(let i=0;i<6;i++){const an=-PI/3+i*PI/3,c=Math.cos(an),sn=Math.sin(an),g=x.createLinearGradient(X+c*214,Y+sn*214,X+c*DISC,Y+sn*DISC);g.addColorStop(0,`rgba(${HAIR},0)`);g.addColorStop(.5,`rgba(${HAIR},.2)`);g.addColorStop(1,`rgba(${HAIR},.42)`);x.strokeStyle=g;x.beginPath();x.moveTo(X+c*214,Y+sn*214);x.lineTo(X+c*DISC,Y+sn*DISC);x.stroke();}x.restore();
    // her flower: the hub. Leant on, it swells and brightens; with a state leant on it leans away from that vine a little, and
    // stays hers. Struck, it is knocked back and its crystal burns that state's colour
    {const k=.27*(1+.06*hub*(ra<0?1:0)+.012*breath-.03*hitK)*rs,w=FB.w*k,h=FB.h*k,kx=lean[0]*3+(hg>=0?-Math.cos(hd)*7*hitK:0),ky=lean[1]*3+(hg>=0?-Math.sin(hd)*7*hitK:0),ox=X-FB.hx*k+kx,oy=Y-FB.hy*k-12+ky;x.save();x.globalAlpha=aF*(1-.14*any);x.drawImage(I.pure,ox,oy,w,h);
      x.globalCompositeOperation='lighter';x.globalAlpha=aF*Math.min(1,(.12+.12*breath+.6*hub+.5*Math.exp(-tt*4.5))*(1-.6*any));x.drawImage(I.pure,ox,oy,w,h);x.restore();
      if(hitK>.02){x.save();x.globalAlpha=aF*hitK;glow(X+kx,Y+ky,64,.75,eL.acc);glow(X+kx,Y+ky,22,.9,eL.acc);x.restore();}}
    // the names, each in its sector by the rim, over its vine's root: its number in its own colour, its name in bone; the one
    // leant on comes forward in its colour. As the wheel opens each comes in after its vine, from a little further out
    const LP=[[0,-222],[194,-108],[194,108],[0,224],[-194,108],[-194,-108]];
    for(let i=0;i<6;i++){const st=TAB[i],an=-PI/2+i*PI/3,dx=Math.cos(an),dy=Math.sin(an),hv=hov===i,inn=cl(S.inn[i]*1.6-.3),dk=cl(S.dk[i]),dim=1-.2*any*(1-dk),ext=7*(1-E.out(inn));if(inn<.01)continue;
      const lx=X+LP[i][0]+dx*ext,ly=Y+LP[i][1]+dy*ext+6,room=LP[i][0]?112:150;let px=17+2*dk;x.font=F.caps(px);x.letterSpacing='2px';const nw0=x.measureText(st.n).width;if(nw0>room)px*=room/nw0;
      x.save();x.globalAlpha=a0;x.font=F.caps(px);x.letterSpacing='2px';const nw=x.measureText(st.n).width,num=String(i+1),gap=10;x.font=F.caps(px);x.letterSpacing='0px';const dw=x.measureText(num).width,tot=dw+gap+nw,x0=lx-tot/2;
      x.shadowColor='rgba(0,0,0,.95)';x.shadowBlur=9;{const dp=die(i);if(dp>.03){x.save();x.shadowBlur=0;x.globalAlpha=a0*dp;glow(x0+dw/2,ly-6,22,.95,st.acc);x.restore();}txt(num,x0-dw*.25*dp,ly+2.5*dp,F.caps(px*(1+.5*dp)),0,st.acc,inn,'left');}txt(st.n,x0+dw+gap,ly,F.caps(px),2,hv?st.acc:BONE,inn*(hv?1:(.9+.1*hub)*dim),'left');{const dp=die(i);if(dp>.03){txt(st.n,x0+dw+gap,ly,F.caps(px),2,st.acc,inn*dp,'left');S.tell=S.tell||[0,0,0,0,0,0];}S.tell&&(S.tell[i]=dp);}
      x.restore();}
    x.restore();
    // the dial's edge, over everything on it: dark, then a fine line of her colour (the leant-on sector's arc in its own)
    x.save();x.translate(jx,jy);x.globalAlpha=ag;x.lineWidth=3;x.strokeStyle='rgba(6,3,7,.9)';disc();x.stroke();x.lineWidth=1;x.strokeStyle=`rgba(${HAIR},${.3+.1*hub})`;x.beginPath();x.arc(X,Y,DISC-1.5,0,TAU);x.stroke();
    if(S.tell)for(let i=0;i<6;i++){const dp=S.tell[i];if(dp<.03)continue;const an=-PI/2+i*PI/3;x.globalAlpha=a0*dp;x.lineWidth=2.5;x.strokeStyle=`rgba(${TAB[i].acc},1)`;x.beginPath();x.arc(X,Y,DISC-1.5,an-PI/6+.012,an+PI/6-.012);x.stroke();}
x.restore();
    // its name over it, as over her full view
    {const ha=a0*cl(tt*3);txt('The Heart Turned',X,Y-298,F.ital(22),0,BONE,.94*ha);}
    // what a click will do, on a plate that is one piece with the bar under it
    const pin=this.pinned(),name=this.her?.name??'',y0=Y+292,y1=Y+352;
    {const pw=Math.max(400,this.bar?.offsetWidth||0),x0=X-pw/2,rr=8;x.save();x.globalAlpha=ag;x.shadowColor='rgba(0,0,0,.6)';x.shadowBlur=18;x.shadowOffsetY=5;x.beginPath();x.moveTo(x0,y1);x.lineTo(x0,y0+rr);x.quadraticCurveTo(x0,y0,x0+rr,y0);x.lineTo(x0+pw-rr,y0);x.quadraticCurveTo(x0+pw,y0,x0+pw,y0+rr);x.lineTo(x0+pw,y1);x.fillStyle='#120b12';x.fill();x.shadowColor='transparent';x.strokeStyle=`rgba(${HAIR},.24)`;x.lineWidth=1;x.stroke();
      if(e||hub>.02){x.globalAlpha=a0*Math.max(any,hub)*.7;const g=x.createLinearGradient(x0,0,x0+pw,0),c=e?e.acc:HAIR;g.addColorStop(0,`rgba(${c},0)`);g.addColorStop(.5,`rgba(${c},.95)`);g.addColorStop(1,`rgba(${c},0)`);x.strokeStyle=g;x.lineWidth=1.5;x.beginPath();x.moveTo(x0+rr,y0+.75);x.lineTo(x0+pw-rr,y0+.75);x.stroke();}x.restore();}
    // (the plate's headline is in the wheel's own capitals: what is laid, in its colour)
    const head=(A,B,acc,al)=>{x.save();x.font=F.caps(16);x.letterSpacing='2.2px';const wa=x.measureText(A+' ').width,wb=x.measureText(B).width,xa=X-(wa+wb)/2;txt(A,xa,y0+25,F.caps(16),2.2,BONE,.8*al,'left');txt(B,xa+wa,y0+25,F.caps(16),2.2,acc,al,'left');x.restore();};
    x.save();x.globalAlpha=a0;
    if(!this.her)head('Nobody is chosen','to curse yet','255,150,248',1);
    else if(e)head(`Lay on ${name}:`,e.n,e.acc,1);else head(hov===-1?'Click:':'Her flower:',`${name} rolls for it`,'255,150,248',hov===-1?1:.85);
    const who=e&&!namesSomeone(e.k)?'all within 15 ft':pin?`toward ${pin.n} · pinned`:this.people.length?'toward whoever the roll of faith finds':'toward no one named';
    txt(this.her?`${who}  ·  1d${this.die} Spans`:'Select her token, then click the top of the strip',X,y0+46,F.ital(14.5),0,BONE,.9);x.restore();
  }
}
