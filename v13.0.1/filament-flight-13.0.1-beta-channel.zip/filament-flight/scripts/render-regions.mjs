import {reactionLight} from './quick-choreography.mjs?v=13.0.1';
/** Canvas regions preserve the original pixel density and clipping rectangle.
 * Bounds are padded for every paint pass, aligned to whole pixels, and expanded
 * only when needed. Token movement never changes these local coordinates. */
const sameRegion=(a,b)=>a&&b&&a.x===b.x&&a.y===b.y&&a.width===b.width&&a.height===b.height;
const finiteRegion=r=>!!r&&Number.isFinite(r.x)&&Number.isFinite(r.y)&&r.width>0&&r.height>0&&Number.isFinite(r.width)&&Number.isFinite(r.height);
const union=(a,b)=>{
  const x=Math.min(a.x,b.x),y=Math.min(a.y,b.y);
  return {x,y,width:Math.max(a.x+a.width,b.x+b.width)-x,height:Math.max(a.y+a.height,b.y+b.height)-y};
};

/** Grow immediately to avoid clipping, then recover oversized allocations only
 * after a settled 600ms envelope. A 40% area threshold and grid padding keep
 * ordinary wingbeats from reallocating textures. Use the same clock/policy in
 * the worker and synchronous renderer, including paused/static animation. */
export function stableLayerViewport(parts,size,glow,record,now=0,settled=true,extent=1){
  let desired=layerViewport(parts,size,glow,null,extent);const previous=record.viewport;
  // (11.0.0-test.5) a stroke with a non-finite point must not crop the layer: a NaN region never unions
  // back to a real one, and a 0-pixel canvas hides the layer until something resets it
  if(!finiteRegion(desired))desired=previous??{x:0,y:0,width:size,height:size};
  if(!previous){record.cropPending=null;return desired;}
  if(!parts.length)desired={x:previous.x,y:previous.y,width:1,height:1};
  const expanded=union(previous,desired);
  if(!sameRegion(expanded,previous)){
    record.cropPending=settled&&desired.width*desired.height<=expanded.width*expanded.height*.6?{started:now,bounds:desired}:null;
    return expanded;
  }
  if(!settled||desired.width*desired.height>previous.width*previous.height*.6){record.cropPending=null;return previous;}
  let pending=record.cropPending;
  if(!pending||now<pending.started)pending=record.cropPending={started:now,bounds:desired};
  else pending.bounds=union(pending.bounds,desired);
  if(now-pending.started<600)return previous;
  record.cropPending=null;
  return pending.bounds.width*pending.bounds.height<=previous.width*previous.height*.6?pending.bounds:previous;
}
export function layerGlow(visual){
  // v10 reaction light widens (or briefly narrows) the halo strokes. The tiny
  // tint term only makes a halo colour change count as a repaint.
  const light=reactionLight(visual);
  // (v11) a change in the light she catches (v11/world-paint.mjs) counts as a repaint too: its tiny signature.
  return Math.max(.55,1+(visual?Math.max(0,visual.energy-1)*1.4+(visual.energyPulses?(visual.geometryPulse??visual.pulse)*.55:0):0)+light.glow)+light.mix*1e-4+(visual?.v11Light?.sig??0);
}
// Match the line painter's actual brightness steps. A true/false comparison
// misses changes from a faint pale core to a bright one; material names also
// select a different set of stroke passes even with unchanged coordinates.
const lineHighlight=part=>Math.round(Math.max(0,Math.min(1,Number(part.highlight??part.paleHighlight)||0))*10)/10;

export function sameLayerPixels(a,b){
  if(a===b)return true;
  if(!a||a.length!==b.length)return false;
  for(let i=0;i<a.length;i++){
    const x=a[i],y=b[i];
    // The hardware fallback is rare and may include artwork loading changes.
    if(x.hardware||y.hardware)return false;
    if(x===y)continue;
    if(x.star!==y.star||x.width!==y.width||x.strength!==y.strength||x.points.length!==y.points.length)return false;
    if(x.star?!!x.highlight!==!!y.highlight:lineHighlight(x)!==lineHighlight(y)||(x.material??'')!==(y.material??'')||(x.tint??'')!==(y.tint??''))return false;
    for(let j=0;j<x.points.length;j++)if(x.points[j][0]!==y.points[j][0]||x.points[j][1]!==y.points[j][1])return false;
  }
  return true;
}

export function layerViewport(parts,size,glow=1,previous=null,extent=1){
  if(parts.some(p=>p.hardware)){
    const pad=extent>1?Math.ceil(size*Math.max(0,Math.min(.5,(extent-1)*.6))/32)*32:0;
    return {x:-pad,y:-pad,width:size+pad*2,height:size+pad*2};
  }
  const ratio=size/600;
  let minX=size,minY=size,maxX=0,maxY=0;
  for(const part of parts){
    // Round caps and joins extend by half the widest stroke. Stars paint a
    // bounded radial glow. Two physical pixels also cover antialiasing.
    const pad=(part.star?part.width*3.8:Math.max(part.width*4*glow,part.highlight?.325:0))*ratio+2;
    for(const point of part.points){
      const x=(point[0]+300)*ratio,y=(point[1]+285)*ratio;
      minX=Math.min(minX,x-pad);maxX=Math.max(maxX,x+pad);
      minY=Math.min(minY,y-pad);maxY=Math.max(maxY,y+pad);
    }
  }
  if(!parts.length)return previous??{x:0,y:0,width:1,height:1};
  // A 32px grid absorbs the ordinary wingbeat without reallocating a canvas
  // every tick. Previous bounds remain valid through the renderer's lifetime.
  const cell=32,overflow=Math.max(0,Math.min(.5,(extent-1)*.6));
  // Default remains the exact original clip. Explicit structure enlargement
  // can grow at most half a base canvas on each edge, even under bright effects.
  const lo=-Math.ceil(size*overflow/cell)*cell,hi=size+Math.ceil(size*overflow/cell)*cell;
  let x=Math.min(hi,Math.max(lo,Math.floor(minX/cell)*cell)),y=Math.min(hi,Math.max(lo,Math.floor(minY/cell)*cell));
  let right=Math.max(lo,Math.min(hi,Math.ceil(maxX/cell)*cell)),bottom=Math.max(lo,Math.min(hi,Math.ceil(maxY/cell)*cell));
  if(right<=x||bottom<=y)return previous??{x:0,y:0,width:1,height:1};
  if(previous){x=Math.min(x,previous.x);y=Math.min(y,previous.y);right=Math.max(right,previous.x+previous.width);bottom=Math.max(bottom,previous.y+previous.height);}
  return {x,y,width:Math.max(1,right-x),height:Math.max(1,bottom-y)};
}
