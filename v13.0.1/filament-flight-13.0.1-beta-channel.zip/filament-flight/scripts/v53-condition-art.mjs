/** Fourteen additive filament treatments. Geometry uses the existing four wing
 * layers; fixed sample budgets, bounded caches, no filters or display objects. */
import {V53_CONDITION_IDS} from './effect-catalog.mjs?v=13.0.1';
import {ease} from './poses.mjs?v=13.0.1';
import {cubic} from './wing-art.mjs?v=13.0.1';
import {fitEffectPoint} from './condition-art.mjs?v=13.0.1';
const CATEGORY=new Map(Object.entries(V53_CONDITION_IDS).flatMap(([category,ids])=>ids.map(id=>[id,category])));
const GATES={normal:'energy',damaged:'breaks',unstable:'instability',glitching:'glitches',overdrive:'arcs',suppressed:'energy',collapsed:'breaks'};
const TAU=Math.PI*2,frac=x=>x-Math.floor(x),root=u=>ease((u-.1)/.4),mix=(a,b,q)=>a.map((x,j)=>x+(b[j]-x)*q);
const prepared=new WeakMap(),roles=new Map();
export const isV53Condition=v=>CATEGORY.has(v?.variant?.id);
function params(v){
  const a=v?.variant,id=a?.id,category=CATEGORY.get(id),gate=GATES[category];
  if(!category||!(a.amount>0)||v.gates?.[gate]===false||gate==='energy'&&v.energyPulses===false&&v.animated!==false)return null;
  const t=v.animated===false?0:(a.time??0),A=a.amount,m=v.variantMotion??1,freq=a.frequency??1;
  let f=prepared.get(v);if(f&&f.id===id&&f.t===t&&f.A===A&&f.m===m&&f.freq===freq)return f;
  f={id,t,A,m,freq,phase:frac(t*.18*freq),head:.2+.68*frac(t*.18*freq),wave:Math.sin(t*.87)};
  prepared.set(v,f);return f;
}
function role(id){let r=roles.get(id);if(r)return r;const [kind,i,j]=id.split('-');r={kind,i:Number(i)||0,j:Number(j)||0,rib:kind==='rib',edge:kind==='edge',web:kind==='web'||kind==='cross'};if(roles.size<512)roles.set(id,r);return r;}
const off=(p,x=0,y=0,z=0)=>[p[0]+x,p[1]+y,p[2]+z,p[3]];
const bound=p=>fitEffectPoint(p);
const pulse=(p)=>Math.sin(Math.PI*Math.max(0,Math.min(1,p)))**2;

export function v53ConditionPoint(point,u,side,v){
  const f=params(v);if(!f||u<=.1)return point;
  const {id,A,m,t}=f,r=root(u),k=A*r*m,x=point[0]-side*27,y=point[1]+13,p=[...point];
  switch(id){
    case 'shuttleWeave':{const crest=Math.exp(-(((u-f.head)/.075)**2));p[0]-=x*.045*crest*k;p[2]+=8*Math.sin(y*.035-t*1.4)*crest*k;break;}
    case 'capillaryBloom':p[0]+=x*.025*k*Math.sin(t*.67-u*4);p[2]+=4*k*Math.sin(t*.67-u*4);break;
    case 'hingedFractures':case 'splinterCages':break; // strand identity decides which joints carry damage
    case 'pressureSeesaw':{const zone=Math.tanh(y/54),load=Math.sin(t*1.1)*zone;p[0]+=x*.16*k*load;p[1]+=24*k*zone*load;p[2]+=29*k*load;break;}
    case 'travelingKinks':{const q=(u-f.head)/.12,crease=Math.max(0,1-Math.abs(q));p[0]+=side*22*k*crease*(q<0?-1:1)*Math.sin(Math.PI*Math.min(1,Math.abs(q)));p[1]-=11*k*crease;break;}
    case 'scanlineHold':{const held=pulse(frac(t*.21*f.freq))*Math.exp(-(((u-f.head)/.14)**2))*k*(v.gates?.displacement??1);p[0]-=side*19*held;p[1]+=6*held;break;}
    case 'checksumGaps':break;
    case 'inductionSpirals':p[2]+=7*k*Math.sin(t*1.3+u*8);break;
    case 'vectorVanes':p[0]+=x*.095*k;p[1]-=12*k*u;p[2]-=10*k*u;break;
    case 'ratchetLocks':{const band=Math.exp(-(((u-.42)/.055)**2))+Math.exp(-(((u-.72)/.055)**2)),step=.4+.6*ease(frac(t*.13));p[0]-=side*14*k*band*step;p[1]+=8*k*band;break;}
    case 'capillaryRetreat':p[0]-=x*.07*k;p[1]+=7*k*u;break;
    case 'spentSpindles':{const angle=u*TAU*2.2+Math.atan2(y,Math.abs(x))*.16+t*.16,radius=9+Math.abs(x)*.09,tx=side*(43+radius*Math.cos(angle)),ty=3+u*125+radius*.32*Math.sin(angle);p[0]+=(tx-p[0])*A*r;p[1]+=(ty-p[1])*A*r;p[2]-=Math.sin(angle)*7*A*r;break;}
    case 'unstrungRibs':{const spread=Math.atan2(y,Math.max(8,Math.abs(x))),tx=side*(27+u*(35+spread*16)+Math.sin(t*.76+spread*2)*u*10*m),ty=-13+u*(150+spread*27);p[0]+=(tx-p[0])*A*r;p[1]+=(ty-p[1])*A*r;break;}
  }
  return bound(p);
}

/** Existing path IDs are retained for all load-bearing contours, allowing
 * stabilization to consume their actual visible geometry with no extra rig. */
export function v53ConditionPaths(strand,points,side,v){
  const f=params(v);if(!f)return null;
  const {id,A,m,t}=f,r=role(strand.id);
  const whole=(pts=points,gain=1)=>gain*strand.strength>.025?[{...strand,points:pts,strength:gain*strand.strength}]:[];
  if(!r.rib&&!r.web&&!r.edge)return whole();
  if(id==='hingedFractures'&&(r.rib||r.edge)){
    const pivotIndex=Math.min(points.length-2,Math.max(1,Math.floor(points.length*(.46+(r.i%3)*.06)))),pivot=points[pivotIndex];
    const angle=(r.i%2?1:-1)*(.12+.20*(.5+.5*Math.sin(t*.73+r.i)))*A*m,s=Math.sin(angle),c=Math.cos(angle);
    return whole(points.map((p,i)=>{if(i<=pivotIndex)return p;const dx=p[0]-pivot[0],dy=p[1]-pivot[1];return bound([pivot[0]+dx*c-dy*s,pivot[1]+dx*s+dy*c,p[2],p[3]]);}));
  }
  if(id==='hingedFractures'&&r.web)return whole(points,1-A*((r.j%3===0)?.88:.4));
  if(id==='splinterCages'&&(r.rib||r.web)){
    const region=.43+(r.i%3)*.10,pts=points.map(p=>{const u=p[3]??.5,q=Math.exp(-(((u-region)/.07)**2)),dx=side*(r.i%2?1:-1)*10*q*A*m;return bound(off(p,dx,7*q*A*m));});
    return whole(pts,r.web?1-.36*A:1);
  }
  if(id==='checksumGaps'){
    // At most five runs per original path; ordered cell masks stay coherent.
    const out=[];let run=[];const beat=Math.floor(t*.75*f.freq)%4;
    const push=()=>{if(run.length>1)out.push({...strand,points:run});run=[];};
    for(let j=0;j<points.length;j++){const p=points[j],slot=Math.floor((p[3]??j/Math.max(1,points.length-1))*8),cut=slot>1&&(slot+r.i+beat)%4===0;
      if(cut&&A>.15){push();}else run.push(p);}
    push();return out;
  }
  if(id==='scanlineHold'&&r.web){
    const row=(r.j/10),hold=Math.exp(-(((row-f.head)/.11)**2))*A*m*(v.gates?.displacement??1);
    return whole(hold>.005?points.map(p=>bound(off(p,-side*15*hold,3*hold))):points);
  }
  if(id==='shuttleWeave'&&r.web){
    const tension=Math.exp(-(((r.j/10-f.head)/.085)**2))*A*m,sign=r.i%2?1:-1;
    return whole(tension>.005?points.map((p,j)=>bound(off(p,0,Math.sin(j/Math.max(1,points.length-1)*TAU)*4*tension,sign*5*tension))):points);
  }
  if(id==='capillaryRetreat'&&r.web){const boundary=.25+.57*(.5+.5*Math.sin(t*.53)),outer=ease((r.j/10-boundary)/.16);return whole(points,1-.94*A*outer);}
  if(id==='ratchetLocks'&&r.web)return whole(points,1-.52*A);
  if(id==='spentSpindles'&&r.web)return whole(points,1-.88*A);
  if(id==='unstrungRibs'&&r.web)return whole(points,r.j%4===0?1-.64*A:1-.97*A);
  return whole();
}

export function v53ConditionAccents(side,v,warp,ribs,growth=1){
  const f=params(v);if(!f||growth<=0)return [];
  const {id,t,A,m}=f,out=[],detail=v.effectDetail??'high',N=detail==='low'?10:detail==='medium'?16:24;
  const at=(i,u)=>warp([...cubic(ribs[Math.max(0,Math.min(9,i))],u),u]);
  const line=(name,points,width=.7,gain=.7)=>{if(gain*A<=.025||points.length<2||points.some(p=>(p[3]??1)>growth+.000001))return;out.push({id:`v53-${id}-${name}`,points:points.map(bound),width,strength:Math.round(Math.min(1.5,gain*A)*16)/16,highlight:true});};
  const curve=(fn,n=N)=>Array.from({length:n+1},(_,i)=>fn(i/n));
  const diamond=(name,p,rx,ry,gain=.7)=>line(name,[off(p,0,-ry),off(p,rx,0),off(p,0,ry),off(p,-rx,0),off(p,0,-ry)],.65,gain);
  switch(id){
    case 'shuttleWeave':{
      const q=(.5+.5*Math.sin(t*.8))*8,i=Math.floor(q),u=f.head,a=at(i,u),b=at(i+1,u),p=mix(a,b,q-i);
      line('working-thread',curve(s=>{const b=at(Math.min(9,Math.floor(s*9)),u);return off(b,0,Math.sin(s*TAU+t*1.4)*4*m);}),.75,.65);
      diamond('shuttle',p,side*8,3.5,.95);line('drawn-loop',curve(s=>off(p,side*13*Math.sin(s*Math.PI),6*Math.sin(s*TAU))),.6,.8);break;}
    case 'capillaryBloom':
      for(const i of [1,4,7]){const life=frac(t*.12+i*.13),u=.35+.42*life,gain=.45+.4*pulse(life),p=at(i,u),b=at(i+1,Math.min(.94,u+.16));
        line(`stem-${i}`,curve(q=>mix(p,b,q)),.65,gain);
        for(const sign of [-1,1]){const start=mix(p,b,.45),tip=off(b,side*sign*11,-9);line(`fork-${i}-${sign}`,curve(q=>{const p=mix(start,tip,q);return off(p,side*Math.sin(Math.PI*q)*4,0);}),.55,gain);}}
      break;
    case 'hingedFractures':
      for(const i of [1,4,7]){const u=.46+(i%3)*.06,p=at(i,u),next=at(i,Math.min(.94,u+.23));diamond(`pivot-${i}`,p,4,4,.85);line(`pivot-tether-${i}`,[p,off(mix(p,next,.5),side*9,7),next],.55,.65);}
      break;
    case 'splinterCages':
      for(const i of [1,4,7]){const p=at(i,.43+(i%3)*.1),s=1+.17*Math.sin(t*.85+i);diamond(`cage-${i}`,p,15*s,22*s,.8);diamond(`cage-inner-${i}`,p,8*s,15*s,.5);line(`splinter-${i}`,[off(p,-side*4,-12),off(p,side*3,9)],.9,.92);}
      break;
    case 'pressureSeesaw':
      for(const i of [1,7]){const p=at(i,.75),load=(i===1?1:-1)*f.wave;line(`load-${i}`,curve(q=>{const a=at(i,.54+q*.35);return off(a,side*8*Math.sin(q*Math.PI)*load,0);}),.9,.55+.3*(.5+.5*load));}
      break;
    case 'travelingKinks':
      for(const i of [1,4,7]){const u=f.head,p=at(i,u);line(`crease-${i}`,[at(i,Math.max(.05,u-.075)),off(p,side*8,-6),at(i,Math.min(.97,u+.075))],.9,.8);}
      break;
    case 'scanlineHold':{
      const u=f.head;line('recovery-edge',Array.from({length:10},(_,i)=>at(i,u)),.85,.86);
      for(const i of [1,4,7]){const p=at(i,u);line(`read-head-${i}`,[off(p,-side*5,-6),off(p,-side*5,6),off(p,side*4,6)],.65,.8);}break;}
    case 'checksumGaps':
      for(const i of [1,4,7]){const q=frac(t*.16*f.freq+i*.2),u=.24+.65*q,p=at(i,u);diamond(`check-${i}`,p,4,4,.7);line(`decoded-${i}`,[at(i,Math.max(.1,u-.08)),p],1,.7);}
      break;
    case 'inductionSpirals':
      for(const i of [1,4,7]){const p=at(i,.64),phase=t*1.15+i,rad=14+4*Math.sin(t*.47+i);line(`coil-${i}`,curve(q=>{const a=q*TAU*1.8+phase,r=3+q*rad;return off(p,Math.cos(a)*r,Math.sin(a)*r*.72);}),.8,.8);line(`feed-${i}`,[at(i,.39),p,at(i,.81)],.65,.5);}
      break;
    case 'vectorVanes':
      for(const i of [0,3,6,9]){const p=at(i,.79),tip=at(i,.98),dx=tip[0]-p[0],dy=tip[1]-p[1],len=Math.hypot(dx,dy)||1,nx=-dy/len,ny=dx/len,open=5+7*(.5+.5*Math.sin(t*1.1-i*.4));
        line(`vane-${i}`,[off(p,nx*open,ny*open),tip,off(p,-nx*open,-ny*open)],.85,.86);
        line(`jet-${i}`,curve(q=>off(tip,dx/len*q*22,dy/len*q*22)),.65,.55);}
      break;
    case 'ratchetLocks':
      for(const i of [1,4,7])for(const u of [.42,.72]){const p=at(i,u),size=5+3*ease(frac(t*.13+i*.1));
        for(const sign of [-1,1])line(`lock-${i}-${u}-${sign}`,[off(p,side*sign*size,-6),off(p,side*sign*3,-6),off(p,side*sign*3,6),off(p,side*sign*size,6)],.65,.72);}
      break;
    case 'capillaryRetreat':
      for(const i of [1,4,7]){const q=frac(t*.16+i*.2),u=.85-q*.65,p=at(i,u);line(`return-${i}`,curve(s=>at(i,Math.min(.97,u+s*.1))),.85,.7);line(`junction-${i}`,[at(i+1,Math.min(.96,u+.09)),p,at(i,Math.max(.1,u-.09))],.55,.5);}
      break;
    case 'spentSpindles':
      for(const i of [1,6]){const p=at(i,.67),phase=t*.16+i;line(`loose-coil-${i}`,curve(q=>{const a=q*TAU*1.4+phase;return off(p,side*Math.cos(a)*(7+5*q),q*30-15+Math.sin(a)*3);}),.65,.55);}
      break;
    case 'unstrungRibs':
      for(const i of [1,4,7]){const a=at(i,.92),b=at(i+1,.85);line(`slack-tie-${i}`,curve(q=>off(mix(a,b,q),0,Math.sin(Math.PI*q)*16)),.5,.32);}
      break;
  }
  return out;
}
