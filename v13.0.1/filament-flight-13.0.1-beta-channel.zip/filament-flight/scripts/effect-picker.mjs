import {escapeHTML as e} from './hud-view.mjs?v=13.0.1';
import {pickerChoices,pickerGroups,pickerTitle,pickerValue,pickerCommand,createEffectPreview,previewGuidance} from './effect-picker-model.mjs?v=13.0.1';
import {EffectPreview} from './effect-preview.mjs?v=13.0.1';
import {createHUDMotion,hudMotionOptions} from './hud-motion.mjs?v=13.0.1';

/** Selection previews locally; only Activate writes the captured token. */
export class EffectPicker {
  constructor(controller,group,key,model) {
    this.controller=controller;this.group=group;this.key=key;this.targetId=model.token.document.uuid;
    this.entries=pickerChoices(group,key);this.model=model;this.playhead=0;this.paused=false;this.initializing=true;
    const host=controller.app.element,doc=host.ownerDocument;this.window=doc.defaultView;
    this.events=new this.window.AbortController();const {signal}=this.events;this.motion=createHUDMotion(hudMotionOptions(model));
    this.dialog=doc.createElement('dialog');this.dialog.className='ff-effect-picker';
    this.dialog.setAttribute('aria-labelledby','ff-picker-title');
    const saved=pickerValue(model,group,key),groups=pickerGroups(group,key);
    const choice=entry=>`<button type="button" class="ff-button ff-picker-choice" data-ff-choice="${e(entry.id)}" aria-pressed="false"><span class="ff-choice-heading"><strong>${e(entry.label)}</strong><span class="ff-choice-badges"><small data-ff-choice-selected hidden>Selected</small><small data-ff-choice-saved hidden>Current</small></span></span><span class="ff-choice-description">${e(entry.description)}</span><span class="ff-choice-kind">${e(entry.categoryLabel?`${entry.categoryLabel} · ${entry.kind}`:entry.kind)}</span></button>`;
    const choices=groups.map(category=>`<details class="ff-picker-category${category.id==='legacy'?' ff-picker-legacy':''}" data-ff-choice-category="${e(category.id)}"${category.entries.some(entry=>entry.id===saved)||(group==='condition'&&category.id===key)||category.id==='current'?' open':''}><summary><span>${e(category.label)}</span><small>${category.entries.length}</small></summary><div class="ff-picker-category-options">${category.entries.map(choice).join('')}</div></details>`).join('');
    this.dialog.innerHTML=`<header class="ff-picker-heading"><div><span class="ff-eyebrow">CHOOSE AN EFFECT</span><h2 id="ff-picker-title">${e(pickerTitle(group,key))}</h2><p>For ${e(model.token.document.name??'your token')}</p></div><button type="button" class="ff-button ff-picker-close" data-ff-picker-close aria-label="Close effect selector">×</button></header>
      ${group==='condition'?`<div class="ff-picker-library-note">Choose from any category. This changes ${e(pickerTitle(group,key).replace(' appearance',''))}’s animation only.</div>`:''}
      <div class="ff-picker-body"><div class="ff-picker-library"><label class="ff-picker-search"><span class="ff-sr-only">Search animations and categories</span><input type="search" data-ff-picker-search placeholder="Search animations or categories…" autocomplete="off"></label><div class="ff-picker-choices" role="group" aria-label="Effect choices">${choices}<p class="ff-note" data-ff-picker-empty hidden>No matching animations.</p></div></div>
      <section class="ff-picker-stage" aria-label="Local wing preview"><div class="ff-preview-topline"><span>ONLY YOU SEE THIS PREVIEW</span><span class="ff-preview-dot" aria-hidden="true"></span></div><canvas width="512" height="512" data-ff-preview-canvas role="img" aria-label="Wing effect preview"></canvas><div class="ff-preview-copy"><h3 data-ff-preview-name></h3><p data-ff-preview-description></p></div><div class="ff-preview-buttons"><button type="button" class="ff-button" data-ff-preview-pause>Pause preview</button><button type="button" class="ff-button" data-ff-preview-replay>Replay</button></div><p class="ff-note" data-ff-preview-guidance></p></section></div>
      <footer class="ff-picker-footer"><span>Click a choice to select and preview</span><button type="button" class="ff-button ff-reset" data-ff-picker-default>Select default</button><button type="button" class="ff-button ff-primary" data-ff-picker-apply disabled>Activate</button><span data-ff-picker-status role="status" aria-live="polite"></span></footer>`;
    this.dialog.querySelector('[data-ff-picker-close]').addEventListener('click',()=>this.close(),{signal});
    this.dialog.addEventListener('cancel',event=>{event.preventDefault();this.close();},{signal});
    this.dialog.addEventListener('close',()=>this.close(),{signal});
    this.dialog.addEventListener('click',event=>{
      event.stopPropagation();
      if(event.target===this.dialog){const r=this.dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)this.close();}
    },{signal});
    this.bindSelectionEvents(signal);
    this.dialog.querySelector('[data-ff-preview-pause]').addEventListener('click',()=>{
      this.paused=!this.paused;this.paused?this.halt():this.play();this.updateControls();
    },{signal});
    this.dialog.querySelector('[data-ff-preview-replay]').addEventListener('click',()=>this.activate(this.active,true),{signal});
    this.dialog.querySelector('[data-ff-picker-search]').addEventListener('input',event=>this.filter(event.target.value),{signal});
    this.dialog.querySelector('[data-ff-picker-default]').addEventListener('click',()=>this.activate('default'),{signal});
    doc.addEventListener('visibilitychange',()=>{if(doc.hidden)this.halt();else this.play();},{signal});
    host.append(this.dialog);
    this.motion.bindDisclosures(this.dialog,{signal});
    try {
      this.update(model);
      this.preview=new EffectPreview(this.dialog.querySelector('canvas'),model,()=>this.draw());
      this.dialog.showModal();this.motion.enter(this.dialog,{kind:'library'});this.drawAfterPaint();
      this.dialog.querySelector(`[data-ff-choice="${pickerValue(model,group,key)}"]`)?.focus({preventScroll:true});
      this.initializing=false;
      this.play();
    } catch(error) {
      // Canvas failure should leave the selector usable; a missing modal API cannot.
      if(!this.dialog.open)try{this.dialog.showModal();}catch{this.close();throw error;}
      this.initializing=false;
      this.failPreview(error);
    }
  }

  bindSelectionEvents(signal) {
    this.dialog.addEventListener('click',event=>{
      const choice=event.target.closest?.('[data-ff-choice]');
      if(choice&&this.dialog.contains(choice)&&!choice.disabled&&!this.initializing)this.activate(choice.dataset.ffChoice);
    },{signal});
    this.dialog.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();event.stopPropagation();this.close();return;}
      const buttons=[...this.dialog.querySelectorAll('[data-ff-choice]')].filter(button=>!button.disabled&&!button.hidden&&button.offsetParent!==null),i=buttons.indexOf(event.target);
      if(i<0)return;
      if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();if(!this.initializing)this.activate(event.target.dataset.ffChoice);return;}
      if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;
      event.preventDefault();event.stopPropagation();
      buttons[event.key==='Home'?0:event.key==='End'?buttons.length-1:(i+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();
    },{signal});
    this.dialog.querySelector('[data-ff-picker-apply]').addEventListener('click',()=>void this.choose(this.active),{signal});
  }

  filter(value) {
    const terms=value.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean),groups=[...this.dialog.querySelectorAll('[data-ff-choice-category]')];
    // A search takes precedence over a disclosure that is still contracting.
    for(const group of groups)this.motion.stop(group);
    if(terms.length&&!this.searching)this.openCategories=groups.filter(group=>group.open).map(group=>group.dataset.ffChoiceCategory);
    let total=0;
    for(const group of groups) {
      let count=0;
      for(const button of group.querySelectorAll('[data-ff-choice]')) {
        const haystack=`${group.querySelector('summary').textContent} ${button.textContent}`.toLocaleLowerCase();
        button.hidden=!terms.every(term=>haystack.includes(term));if(!button.hidden)count++;
      }
      group.hidden=!count;total+=count;
      if(terms.length)group.open=!!count;else if(this.searching)group.open=this.openCategories.includes(group.dataset.ffChoiceCategory);
    }
    this.searching=!!terms.length;this.dialog.querySelector('[data-ff-picker-empty]').hidden=!!total;
    this.motion.enter(this.dialog.querySelector('.ff-picker-choices'),{kind:'library'});
  }

  valid(model=this.controller.model()) {
    return !!(this.controller.opened&&model&&!model.error&&model.cfg?.hudEnabled&&model.token?.document.uuid===this.targetId&&model.token.document.isOwner);
  }
  update(model) {
    if(this.closed)return;
    if(!this.valid(model)||this.controller.app?.minimized){this.close();return;}
    const motionOptions=hudMotionOptions(model);this.motion.configure(motionOptions);this.dialog.dataset.ffMenuMotion=String(motionOptions.enabled&&motionOptions.strength>0);
    const signature=JSON.stringify([model.cfg,model.state?.requested,model.state?.effective.condition,model.baseAppearance,model.prefs.effectStrength,model.prefs.pulseDurationMs,model.prefs.stutterDurationMs]);
    this.model=model;
    if(signature===this.signature)return;this.signature=signature;
    const saved=pickerValue(model,this.group,this.key);
    for(const button of this.dialog.querySelectorAll('[data-ff-choice]')) {
      const current=button.dataset.ffChoice===saved;
      button.querySelector('[data-ff-choice-saved]').hidden=!current;
    }
    this.activate(this.active??saved,true);
  }
  activate(id,restart=false) {
    if(this.closed||this.saving||(!restart&&id===this.active))return;
    const entry=this.entries.find(e=>e.id===id);if(!entry)return;
    this.halt();this.playhead=0;this.active=id;
    this.selection=createEffectPreview(this.model,this.group,this.key,id);
    for(const b of this.dialog.querySelectorAll('[data-ff-choice]')){const selected=b.dataset.ffChoice===id;b.classList.toggle('is-previewing',selected);b.classList.toggle('is-selected',selected);b.setAttribute('aria-pressed',String(selected));b.querySelector('[data-ff-choice-selected]').hidden=!selected;}
    this.dialog.querySelector('[data-ff-preview-name]').textContent=entry.label;
    this.dialog.querySelector('[data-ff-preview-description]').textContent=entry.description;
    this.dialog.querySelector('[data-ff-picker-status]').textContent=`Selected: ${entry.label}`;
    if(this.dialog.open)this.motion.enter(this.dialog.querySelector('.ff-preview-copy'),{kind:'library'});
    this.selectionGuidance=previewGuidance(this.selection);if(!this.previewFailed)this.guidance(this.selectionGuidance);
    this.updateControls();this.drawAfterPaint();this.play();
  }
  /** Paint the preview just after the next frame is on screen, so a click's highlight shows first (beta.32). */
  drawAfterPaint(){
    if(this.paintSoon||this.closed)return;const w=this.window;
    this.paintSoon=w.requestAnimationFrame(()=>w.setTimeout(()=>{this.paintSoon=null;if(!this.closed)this.draw();},0));
  }
  elapsed() {return this.playhead+(this.playing?this.window.performance.now()-this.started:0);}
  draw() {
    if(this.closed||!this.preview||!this.selection||this.previewFailed)return;
    try{this.preview.draw(this.selection,this.elapsed());this.guidance(`${this.selectionGuidance} ${this.preview.portraitAvailable?'Displayed token artwork.':'Generic token footprint; source artwork unavailable.'}`);}catch(e){this.failPreview(e);}
  }
  /** Text changes only with the selection or artwork, not every frame. */
  guidance(text) {
    if(text===this.guidanceText)return;this.guidanceText=text;
    this.dialog.querySelector('[data-ff-preview-guidance]').textContent=text;
  }
  play() {
    if(this.closed||this.playing||this.paused||this.saving||this.previewFailed||!this.selection||this.selection.cfg.reduced||!this.selection.cfg.enabled||this.dialog.ownerDocument.hidden||!this.dialog.open)return;
    this.playing=true;this.started=this.window.performance.now();this.lastFrame=-Infinity;
    const tick=now=>{
      this.raf=null;if(!this.playing||this.closed)return;
      if(!this.dialog.isConnected||!this.controller.opened){this.close();return;}
      // 4 ms of slack lets a 24 fps cap land on 60 Hz frames; keep the cadence instead of drifting to 20 fps.
      const interval=1000/Math.min(24,this.selection.cfg.rigFPS),since=now-this.lastFrame;
      if(!this.paintSoon&&since>=interval-4){this.draw();this.lastFrame=since<interval*2?this.lastFrame+interval:now;}
      if(this.playing)this.raf=this.window.requestAnimationFrame(tick);
    };
    this.raf=this.window.requestAnimationFrame(tick);
  }
  halt() {
    if(this.playing)this.playhead=this.elapsed();
    this.playing=false;if(this.raf!=null)this.window.cancelAnimationFrame(this.raf);this.raf=null;
  }
  updateControls() {
    const entry=this.entries.find(e=>e.id===this.active),apply=this.dialog.querySelector('[data-ff-picker-apply]');if(apply){apply.disabled=!!(this.saving||!entry);apply.setAttribute('aria-label',entry?`Activate ${entry.label}`:'Activate selected effect');}
    this.dialog.querySelector('[data-ff-picker-default]').disabled=!!(this.saving||this.active==='default');
    const button=this.dialog.querySelector('[data-ff-preview-pause]');
    button.textContent=this.paused?'Play preview':'Pause preview';
    button.disabled=!!(this.selection?.cfg.reduced||!this.selection?.cfg.enabled||this.previewFailed||this.saving);
    this.dialog.querySelector('[data-ff-preview-replay]').disabled=!!(this.previewFailed||this.saving);
    this.dialog.querySelector('.ff-preview-dot').classList.toggle('is-paused',this.paused||button.disabled);
  }
  failPreview(error) {
    this.halt();this.previewFailed=true;
    this.guidance(`Preview unavailable: ${error?.message??error} You can still choose an effect.`);
    this.updateControls();
  }
  async choose(id) {
    if(this.closed||this.saving||this.controller.busy)return;
    if(!this.valid()){this.close();return;}
    if(!this.entries.some(entry=>entry.id===id))return;
    const {action,value}=pickerCommand(this.group,this.key,id);
    this.saving=true;this.halt();this.updateControls();
    this.dialog.querySelector('[data-ff-picker-default]').disabled=true;
    for(const b of this.dialog.querySelectorAll('[data-ff-choice]'))b.disabled=true;
    const status=this.dialog.querySelector('[data-ff-picker-status]');status.textContent='Activating…';
    try {
      await this.controller.run(action,value,this.targetId);
      this.close();
    } catch(error) {
      if(this.closed)return;
      this.saving=false;status.textContent=String(error?.message??error);
      for(const b of this.dialog.querySelectorAll('[data-ff-choice]'))b.disabled=false;
      this.updateControls();this.play();
    }
  }
  close() {
    if(this.closed)return;this.closed=true;this.halt();this.events.abort();this.dialog.inert=true;
    if(this.controller.picker===this)this.controller.picker=null;
    void this.motion.exit(this.dialog,{kind:'library'}).finally(()=>{
      this.preview?.destroy();this.motion.destroy();
      const doc=this.dialog.ownerDocument,restoreFocus=doc.activeElement===doc.body||this.dialog.contains(doc.activeElement);
      if(this.dialog.open)this.dialog.close();this.dialog.remove();
      if(restoreFocus&&this.controller.opened)this.controller.root?.querySelector(`[data-ff-picker="${this.group}:${this.key}"]`)?.focus({preventScroll:true});
    });
  }
}
