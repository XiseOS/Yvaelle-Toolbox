import {paintTokenEffect} from './token-effects.mjs?v=13.0.1';

// The source diamond is painted at the patient's existing pixel density, but
// its tiny independent view follows the actual bit every display update.
// Eight local units include the complete authored diamond and glow stroke.
export const MEDICAL_EMITTER_RADIUS=8;
export function medicalEmitterSurfaceSize(resolution){return Math.max(8,Math.ceil(MEDICAL_EMITTER_RADIUS*2*resolution/280)+4);}

/** Extract only tagged source apertures, including both scan bridge layers.
 * The shared preparation remains immutable and default previews retain it all. */
export function medicalEmitterArtwork(preparations,attachedEmitters){
  const emitters=new Map();
  const visit=prepared=>{
    if(prepared.layers){for(const layer of prepared.layers)visit(layer);return;}
    const frame=prepared.frame;if(!frame)return;
    for(const path of frame.paths){
      const id=path.emitterId;if(path.role!=='emitter-aperture'||!attachedEmitters.has(id)||!path.points.length)continue;
      const center=path.points.reduce((p,q)=>[p[0]+q[0]/path.points.length,p[1]+q[1]/path.points.length],[0,0]);
      let emitter=emitters.get(id);if(!emitter){emitter={id,center,plane:path.plane,layers:[]};emitters.set(id,emitter);}
      emitter.layers.push({color:frame.color,paths:[path]});
    }
  };
  for(const prepared of preparations)visit(prepared);return emitters;
}

/** Retain the patient's original raster phase at artwork samples. Only the
 * mesh center changes between samples; this does not upload or paint pixels. */
export function paintMedicalEmitter(ctx,artwork,{resolution,surfaceSize=medicalEmitterSurfaceSize(resolution)}={}){
  const density=resolution/280,patientPixel=artwork.center.map(p=>p*density+resolution/2);
  const crop=patientPixel.map(p=>Math.floor(p)-Math.floor(surfaceSize/2)),origin=patientPixel.map((p,i)=>p-crop[i]);
  // An integer crop of the original patient transform preserves Skia's exact
  // path rasterization as well as its phase. Recentering authored points first
  // would introduce different float rounding in a handful of bright pixels.
  ctx.clearRect(0,0,surfaceSize,surfaceSize);ctx.save();ctx.translate(resolution/2-crop[0],resolution/2-crop[1]);ctx.scale(density,density);
  for(const layer of artwork.layers)paintTokenEffect(ctx,layer,{plane:artwork.plane});ctx.restore();
  return {x:origin[0]/surfaceSize,y:origin[1]/surfaceSize};
}
