/** Yvaelle’s Toolbox v11 · the Macros ring of the nested quick wheel (Settings ›
 * Emotes & wheel › Macros ring). Pure DOM, no Foundry globals.
 *
 * The user's own macros on a ring of their own, stored on the USER
 * (flags.filament-flight.macroRing, model.normalizeRing), dealt out along the
 * ring from the Macros door. Each macro shows its own image (or an icon from
 * the 111-icon library), its name, and in the plaque a cameo, its type and
 * its first line.
 *   · a macro you can't run is greyed with a lock; a deleted one shows "Missing";
 *   · Edit (plaque) turns the ring into its editor: empty bits show "+", a click
 *     opens a searchable picker; drop a macro from the hotbar or Macro Directory
 *     onto the ring (host.macroDropData, Foundry's TextEditor.getDragEventData);
 *     drag a bit round to reorder; × removes; click a bit to choose its icon;
 *     Done (or Esc) saves, dropping deleted macros.
 * Up to 12; the ring grows so every macro is one gesture away.
 *
 * host members used: macroRing(), saveMacroRing(list), resolveMacro(uuid) →
 * {uuid,name,img,type,line,canExecute}|null, listMacros(), runMacro(uuid),
 * macroDropData(event), iconLibrary() → Promise<{sprite,entries,groups}>,
 * features().macroIcons ('keepsake' | 'foundry' | 'both'), toast?(text,info). */
import * as M from './quick-wheel-model.mjs?v=13.0.1';
import {MACRO_ICONS} from './quick-wheel-assets.mjs?v=13.0.1';

const TAU=Math.PI*2,SVGNS='http://www.w3.org/2000/svg',RAD=Math.PI/180;
const wrapDeg=d=>((d%360)+540)%360-180;
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const now=()=>performance.now();
const MIN_SHOWN_EDITING=8;
const TINT='#d9b4ff';
/** Foundry's own core icons (icons/svg/…), offered when Settings › Macros ring › Icon library is Foundry or Both. */
export const FOUNDRY_ICONS=Object.freeze(['d20','heal','regen','aura','holy-shield','shield','sword','fire','lightning','frozen','poison','skull','eye','light','sun','sound','book','item-bag','coins','tankard','wing','target','dice-target','door-closed','trap','padlock','sleep','mystery-man']);
/** An icon value → how to draw it: library symbol, Foundry core icon, or none (the macro's own image). */
export function iconSource(icon){
  if(typeof icon!=='string')return null;
  if(icon.startsWith('mi-'))return {use:icon};
  if(icon.startsWith('fi:'))return {img:`icons/svg/${icon.slice(3)}.svg`};
  return null;
}
const iconTag=(icon,cls='')=>{const s=iconSource(icon);if(!s)return '';return s.use?`<svg class="${cls}" viewBox="0 0 24 24"><use href="#${esc(s.use)}"/></svg>`:`<img class="fi ${cls}" src="${esc(s.img)}" alt="" draggable="false">`;};

export const MACRO_RING_CSS=`
@property --ffm-a{syntax:'<angle>';inherits:true;initial-value:0deg}
@property --ffm-r{syntax:'<number>';inherits:true;initial-value:118}
.ffw .ffw-slot.ffm-slot,.ffw.open .ffw-slot.ffm-slot{--ffm-a:var(--from);--ffm-r:var(--R0,118);transform:rotate(var(--ffm-a)) translateY(calc(-1px*var(--ffm-r))) rotate(calc(-1*var(--ffm-a)));scale:.2;opacity:0;pointer-events:none;
  transition:--ffm-a .5s cubic-bezier(.4,0,.6,1) calc(var(--d)*16ms),--ffm-r .4s,scale .3s ease-in calc(var(--d)*16ms),opacity .25s calc(.08s + var(--d)*16ms)}
.ffw.open.msub .ffw-slot.ffm-slot{--ffm-a:var(--to);--ffm-r:var(--R);scale:1;opacity:1;pointer-events:auto;
  transition:--ffm-a .62s cubic-bezier(.2,.75,.25,1) calc(.04s + var(--d)*34ms),--ffm-r .5s cubic-bezier(.3,1,.4,1),scale .45s cubic-bezier(.22,1.3,.4,1) calc(.04s + var(--d)*34ms),opacity .3s calc(.04s + var(--d)*34ms)}
.ffw.open.msub.has-pick .ffw-slot.ffm-slot:not(.picked){opacity:.8}
.ffw.open.msub .ffw-slot.ffm-slot.born{animation:ffm-born .5s cubic-bezier(.22,1.3,.4,1)}
@keyframes ffm-born{from{scale:.2;opacity:0}}
.ffw.open.msub .ffw-slot.ffm-slot.gone{scale:.3;opacity:0;pointer-events:none;transition:scale .3s ease-in,opacity .25s}
.ffw.open.msub .ffw-slot.ffm-slot.lifted{--ffm-a:var(--pa);--ffm-r:var(--pr);scale:1.14;opacity:1;z-index:6;transition:scale .2s cubic-bezier(.3,1.6,.5,1)}
.ffw.open.msub .ffw-slot.ffm-slot.lifted .ffw-bob{animation:none}
.ffw.open.msub .ffw-slot.ffm-slot.lifted .ffw-gem{box-shadow:0 0 0 1px var(--hot),0 0 22px rgba(255,0,255,.7),0 14px 22px rgba(0,0,0,.7)}
.ffw.closing .ffw-slot.ffm-slot{--ffm-a:var(--to);--ffm-r:var(--R);scale:.5;opacity:0;transition:scale .26s ease-in,opacity .22s}
.ffm-slot .ffw-gem{overflow:hidden}
.ffm-pic{position:absolute;inset:0;overflow:hidden;border-radius:3px;background:#1a0e16}
.ffm-pic img{position:absolute;left:50%;top:50%;width:60px;height:60px;margin:-30px 0 0 -30px;transform:rotate(-45deg);object-fit:cover;
  filter:saturate(.78) sepia(.16) hue-rotate(-10deg) brightness(1.02) contrast(1.06);transition:filter .25s}
.ffm-pic::after{content:"";position:absolute;inset:0;pointer-events:none;
  background:radial-gradient(circle at 50% 50%,transparent 46%,rgba(26,8,22,.5) 100%),linear-gradient(135deg,rgba(255,150,235,.22),rgba(207,174,118,.06) 50%,rgba(70,16,60,.3));transition:opacity .25s}
.ffm-rim{position:absolute;inset:0;border-radius:3px;pointer-events:none;
  box-shadow:inset 0 0 0 1.5px var(--gold),inset 0 0 0 3px rgba(21,11,18,.82),inset 0 0 0 4px rgba(207,174,118,.38);transition:box-shadow .25s}
.ffm-slot.picked .ffm-pic img{filter:saturate(1) sepia(0) brightness(1.12) contrast(1.04)}
.ffm-slot.picked .ffm-pic::after{opacity:.45}
.ffm-slot.picked .ffm-rim{box-shadow:inset 0 0 0 1.5px var(--hot),inset 0 0 0 3px rgba(40,6,34,.7),inset 0 0 0 4.5px var(--gold-hi)}
.ffm-slot .ffw-gem .ffw-icon{transform:rotate(-45deg)}
.ffm-slot.picked .ffw-gem .ffw-icon{transform:rotate(-45deg) scale(1.08)}
.ffm-slot .ffw-icon svg{width:21px;height:21px}
.ffm-slot .ffw-icon img.fi,.ffm-cg .ffw-icon img.fi{width:22px;height:22px;filter:sepia(.6) saturate(1.6) hue-rotate(-12deg) brightness(1.05)}
.ffm-slot.glyph .ffw-gem{background:linear-gradient(135deg,#3d1a33 0%,#1b0d17 55%,#2e1426 100%)}
.ffm-slot.glyph.picked .ffw-gem{background:linear-gradient(135deg,#ff3df0 0%,#8a0f7c 45%,#3a0a33 100%)}
.ffm-slot.denied .ffm-pic img{filter:grayscale(1) brightness(.5) contrast(.9)}
.ffm-slot.denied .ffm-pic::after{background:rgba(20,12,18,.35)}
.ffm-slot.denied .ffm-rim{box-shadow:inset 0 0 0 1.5px rgba(160,140,130,.55),inset 0 0 0 3px rgba(21,11,18,.82)}
.ffm-slot.denied.glyph .ffw-icon{color:#8a7a74}
.ffm-slot.denied .ffm-lab{color:#8a7a74}
.ffm-badge{position:absolute;left:24px;top:41px;width:12px;height:12px;border-radius:50%;background:#1a0e16;box-shadow:0 0 0 1px rgba(160,140,130,.7);display:grid;place-items:center}
.ffm-badge svg{width:8px;height:8px;fill:none;stroke:#cdbfb6;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}
.ffm-slot.missing .ffw-gem,.ffm-slot.empty .ffw-gem,.ffm-slot.ghost .ffw-gem{background:rgba(23,12,20,.55);box-shadow:none;border:1.2px dashed rgba(207,174,118,.55)}
.ffm-slot.missing .ffw-icon{color:#a8968c}.ffm-slot.missing .ffm-lab{color:#a8968c;font-style:italic}
.ffm-slot.empty .ffw-gem{border:1.4px dashed rgba(255,120,240,.8);background:rgba(40,8,36,.6);box-shadow:0 0 10px rgba(255,0,255,.18)}
.ffm-slot.empty .ffw-icon{color:rgba(255,120,240,.9)}
.ffm-slot.empty.picked .ffw-gem,.ffm-slot.empty.drop .ffw-gem{border-style:solid;border-color:var(--hot);background:rgba(120,10,110,.55);box-shadow:0 0 18px rgba(255,0,255,.6)}
.ffm-slot.drop:not(.empty) .ffw-gem{box-shadow:0 0 0 1.5px var(--hot),0 0 18px rgba(255,0,255,.6)}
.ffw.open.msub .ffw-slot.ffm-slot.focus{opacity:1}
.ffm-slot.focus .ffw-gem{transform:rotate(45deg) scale(1.16);box-shadow:0 0 0 1.5px var(--hot),0 0 22px rgba(255,0,255,.65)}
.ffm-slot.focus.glyph .ffw-gem{background:linear-gradient(135deg,#ff3df0 0%,#8a0f7c 45%,#3a0a33 100%)}
.ffm-slot.focus.glyph .ffw-icon{color:#fff}
.ffm-slot.focus .ffm-lab{color:#fff}
.ffw.mediting .ffm-slot.focus .ffw-bob{animation:none}
.ffm-slot.ghost{cursor:pointer}.ffm-slot.ghost .ffw-gem{border-color:rgba(207,174,118,.45);background:rgba(23,12,20,.35)}
.ffw.open.msub .ffw-slot.ffm-slot.ghost{opacity:.6}
.ffm-slot.nope .ffw-bob{animation:ffm-nope .4s}
@keyframes ffm-nope{20%{transform:translateX(-4px)}40%{transform:translateX(4px)}60%{transform:translateX(-3px)}80%{transform:translateX(2px)}}
.ffm-lab{position:absolute;left:calc(30px + 33px*sin(var(--ffm-a)));top:calc(30px - 33px*cos(var(--ffm-a)));translate:calc(-50% + 50%*sin(var(--ffm-a))) calc(-50% - 50%*cos(var(--ffm-a)));
  max-width:96px;overflow:hidden;text-overflow:ellipsis;font:600 9.5px/1.15 'Keepsake Sans',system-ui,sans-serif;letter-spacing:.04em;color:#d7c3b4;white-space:nowrap;
  text-shadow:0 1px 2px #000,0 0 6px rgba(14,6,12,.9);opacity:0;transition:color .2s,opacity .12s;pointer-events:none}
.ffw.open.msub .ffm-lab{opacity:1;transition:color .2s,opacity .3s calc(.4s + var(--d)*34ms)}
.ffw.open.msub .ffm-slot.born .ffm-lab{transition-delay:0s}
.ffm-slot.picked .ffm-lab{color:#fff}
.ffm-slot.picked .ffw-gem{transform:rotate(45deg) scale(1.16)}
.ffm-slot.fired .ffw-gem{animation:ffw-fire .55s cubic-bezier(.2,.8,.3,1)}
.ffw.mediting .ffm-slot:not(.lifted) .ffw-bob{animation:ffw-wobble 1.8s ease-in-out infinite;animation-delay:calc(var(--i)*-.25s)}
.ffm-x{position:absolute;left:calc(21.5px - 25px*sin(var(--ffm-a)));top:calc(21.5px + 25px*cos(var(--ffm-a)));width:17px;height:17px;padding:0;border:0;border-radius:50%;cursor:pointer;background:#1a0e16;
  box-shadow:0 0 0 1.2px var(--gold),0 2px 5px rgba(0,0,0,.7);display:grid;place-items:center;opacity:0;scale:.4;pointer-events:none;transition:opacity .2s,scale .3s cubic-bezier(.3,1.6,.5,1),background .15s}
.ffm-x svg{width:9px;height:9px;fill:none;stroke:var(--gold-hi);stroke-width:2.4;stroke-linecap:round}
.ffw.mediting .ffm-x{opacity:1;scale:1;pointer-events:auto}
.ffm-x:hover,.ffm-x:focus-visible{background:#8a0f7c;box-shadow:0 0 0 1.2px var(--hot),0 0 10px rgba(255,0,255,.8);outline:none}
.ffm-slot.missing .ffm-x{box-shadow:0 0 0 1.2px var(--hot),0 0 8px rgba(255,0,255,.7)}
.ffn.mediting .arcg[data-arc="macros"] .arcline.a{stroke-dasharray:4 5!important;stroke-dashoffset:0!important}
/* plaque: the macro's cameo, type chip and first line */
.ffm-cameo,.ffm-hintrow{display:none}
.ffn.msub .ffw-plaque{width:300px;min-height:78px;padding:8px 26px 9px 26px;text-align:left}
.ffn.msub .ffw-plaque.cam{padding-left:90px}
.ffn.msub .ffm-cameo{display:block;position:absolute;left:22px;top:50%;width:56px;height:56px;margin-top:-28px;opacity:0;transition:opacity .25s;pointer-events:none}
.ffm-cameo .ffm-cg{position:absolute;left:8px;top:8px;width:40px;height:40px;transform:rotate(45deg);border-radius:4px;overflow:hidden;background:radial-gradient(circle at 50% 45%,#2a1424,#0d060b 75%)}
.ffm-cameo .ffm-cg .ffm-pic img{width:62px;height:62px;margin:-31px 0 0 -31px;filter:saturate(.95) brightness(1.02)}
.ffm-cameo .ffm-cg .ffm-pic::after{opacity:.35}
.ffm-cameo .ffm-cg .ffw-icon{position:absolute;inset:0;display:grid;place-items:center;color:var(--gold-hi);transform:rotate(-45deg)}
.ffm-cameo .ffm-cg .ffw-icon svg{width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.ffm-cameo .ffm-cg::after{content:"";position:absolute;inset:0;border-radius:4px;box-shadow:inset 0 0 0 1px rgba(207,174,118,.7),inset 0 0 0 3px #0d060b,inset 0 0 0 4px rgba(231,103,206,.35)}
.ffn.msub .ffm-cameo.on{opacity:1}
.ffm-cameo.denied .ffm-pic img{filter:grayscale(1) brightness(.6)}
.ffn.msub .ffm-hintrow{display:flex;align-items:baseline;gap:6px;margin-top:2px;max-height:0;opacity:0;overflow:hidden;transition:opacity .2s,max-height .3s}
.ffn.msub .ffm-hintrow.on{max-height:32px;opacity:1}
.ffm-chip{flex-shrink:0;font:700 8.5px/1 'Keepsake Sans',system-ui,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:var(--gold-hi);padding:2px 5px 2px;border:1px solid rgba(207,174,118,.5);border-radius:2px}
.ffm-chip.chat{color:#ffc8f4;border-color:rgba(231,103,206,.55)}
.ffm-hint{flex:1;min-width:0;font-size:11px;line-height:1.3;color:#cdb9ab;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
/* panels: the macro picker and the icon picker */
.ffm-panel{position:absolute;width:300px;padding:14px 14px 12px;pointer-events:auto;background:rgba(23,13,19,.98);color:var(--ink);font-size:12.5px;display:grid;gap:9px;
  box-shadow:inset 0 0 0 4px rgba(23,13,19,.98),inset 0 0 0 5px rgba(207,174,118,.26),0 18px 40px rgba(0,0,0,.7);border:1px solid #4a3240;
  clip-path:polygon(10px 0,100% 0,100% calc(100% - 10px),calc(100% - 10px) 100%,0 100%,0 10px);animation:ffw-in .3s cubic-bezier(.2,.9,.3,1.1)}
.ffm-panel h3{margin:0;font-family:'Keepsake Caps',Georgia,serif;font-size:15px;letter-spacing:.08em;color:var(--gold);display:flex;align-items:center;gap:8px;border:0}
.ffm-panel h3 small{margin-left:auto;font:600 10px 'Keepsake Sans',sans-serif;letter-spacing:.06em;color:#9c8a80;text-transform:none}
.ffm-panel .sub{margin:-4px 0 0;color:#a8968c;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ffm-search{position:relative}
.ffm-search input{width:100%;height:30px;padding:0 10px 0 28px;background:#0f080c;color:var(--ink);border:0;box-shadow:inset 0 0 0 1px #3f2b36;font:inherit;font-size:12.5px;outline:none;
  clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)}
.ffm-search input:focus{box-shadow:inset 0 0 0 1px var(--mag)}
.ffm-search input::-webkit-search-cancel-button{-webkit-appearance:none;appearance:none}
.ffm-search svg{position:absolute;z-index:1;pointer-events:none;left:9px;top:9px;width:12px;height:12px;fill:none;stroke:#9c8a80;stroke-width:2;stroke-linecap:round}
.ffm-list{display:grid;gap:2px;max-height:256px;overflow:auto;scrollbar-width:thin;scrollbar-color:#4a3240 transparent;margin:0 -4px;padding:0 4px}
.ffm-row{display:flex;align-items:center;gap:10px;height:38px;padding:0 8px 0 6px;background:none;border:0;color:var(--ink);font:inherit;text-align:left;cursor:pointer}
.ffm-row:hover,.ffm-row.hot,.ffm-row:focus-visible{background:linear-gradient(90deg,rgba(255,0,255,.16),rgba(255,0,255,.02));box-shadow:inset 2px 0 0 var(--mag);outline:none}
.ffm-thumb{position:relative;flex-shrink:0;width:26px;height:26px;transform:rotate(45deg);border-radius:3px;overflow:hidden;box-shadow:0 0 0 1px rgba(207,174,118,.7);margin:0 4px}
.ffm-thumb img{position:absolute;left:50%;top:50%;width:38px;height:38px;margin:-19px 0 0 -19px;transform:rotate(-45deg);object-fit:cover;filter:saturate(.8)}
.ffm-thumb svg{position:absolute;inset:4px;width:18px;height:18px;transform:rotate(-45deg);fill:none;stroke:var(--gold-hi);stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.ffm-row .nm{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ffm-row .on{font-size:10px;color:#9c8a80;letter-spacing:.04em}
.ffm-row.denied{opacity:.5;cursor:not-allowed}.ffm-row.denied .ffm-thumb img{filter:grayscale(1)}
.ffm-row.denied:hover{background:none;box-shadow:none}
.ffm-panel .note{color:#9c8a80;font-size:11px;margin:0}
.ffm-panel .row{display:flex;gap:6px;justify-content:flex-end}
.ffm-panel button.b{height:28px;padding:0 12px;font:600 11.5px/1 inherit;color:var(--ink);background:#21151d;border:0;box-shadow:inset 0 0 0 1px #4a3240;cursor:pointer;
  clip-path:polygon(5px 0,100% 0,100% calc(100% - 5px),calc(100% - 5px) 100%,0 100%,0 5px)}
.ffm-panel button.b:hover,.ffm-panel button.b:focus-visible{box-shadow:inset 0 0 0 1px var(--mag);outline:none}
.ffm-panel button.b.primary{background:#3a1a30;box-shadow:inset 0 0 0 1px var(--mag)}
.ffm-own{display:flex;align-items:center;gap:12px;height:44px;padding:0 10px 0 8px;background:#140b11;border:0;color:var(--ink);font:inherit;text-align:left;cursor:pointer;box-shadow:inset 0 0 0 1px #3f2b36}
.ffm-own.sel{box-shadow:inset 0 0 0 1px var(--mag),inset 0 0 14px rgba(255,0,255,.18)}
.ffm-own .t{display:grid;gap:2px}.ffm-own .t b{font-weight:600}.ffm-own .t span{font-size:10.5px;color:#9c8a80}
.ffm-grid{max-height:252px;overflow:auto;scrollbar-width:thin;scrollbar-color:#4a3240 transparent;margin:0 -4px;padding:0 4px}
.ffm-grid h4{margin:8px 0 4px;font:700 9px/1 'Keepsake Sans',sans-serif;letter-spacing:.16em;text-transform:uppercase;color:var(--gold);display:flex;align-items:center;gap:8px;border:0}
.ffm-grid h4::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,rgba(207,174,118,.4),transparent)}
.ffm-grid h4:first-child{margin-top:2px}
.ffm-cells{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}
.ffm-cell{position:relative;height:34px;padding:0;border:0;background:#140b11;color:var(--gold-hi);cursor:pointer;display:grid;place-items:center;box-shadow:inset 0 0 0 1px #33222c;transition:background .15s,color .15s}
.ffm-cell svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.ffm-cell img.fi{width:20px;height:20px;filter:sepia(.6) saturate(1.6) hue-rotate(-12deg)}
.ffm-cell:hover,.ffm-cell.hot,.ffm-cell:focus-visible{background:#2a1424;color:#fff;box-shadow:inset 0 0 0 1px rgba(255,0,255,.7);outline:none}
.ffm-cell.sel{background:linear-gradient(135deg,#ff3df0 0%,#8a0f7c 55%,#3a0a33 100%);color:#fff;box-shadow:inset 0 0 0 1px var(--hot),0 0 12px rgba(255,0,255,.5)}
.ffm-empty{color:#9c8a80;font-size:11.5px;padding:10px 4px}
.ffm-field{display:grid;gap:4px}.ffm-field span{font-size:10.5px;letter-spacing:.04em;color:#a8968c}
.ffm-field input,.ffm-field textarea{width:100%;box-sizing:border-box;padding:6px 9px;background:#0f080c;color:var(--ink);border:0;box-shadow:inset 0 0 0 1px #3f2b36;font:inherit;font-size:12.5px;outline:none;resize:vertical}
.ffm-field textarea{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11.5px;line-height:1.45;min-height:96px;max-height:240px}
.ffm-field input:focus,.ffm-field textarea:focus{box-shadow:inset 0 0 0 1px var(--mag)}
.ffm-seg{display:flex;gap:6px}.ffm-seg .b{flex:1}
.ffm-panel .row:has([data-new]){justify-content:stretch}.ffm-panel [data-new]{flex:1}
.ffm-toast{position:fixed;z-index:101;left:0;top:0;transform:translate(-50%,-100%);display:flex;align-items:center;gap:10px;padding:7px 22px 7px 12px;pointer-events:none;
  background:linear-gradient(180deg,rgba(32,16,27,.96),rgba(17,9,14,.96));clip-path:polygon(10px 0,calc(100% - 10px) 0,100% 50%,calc(100% - 10px) 100%,10px 100%,0 50%);
  box-shadow:inset 0 0 0 1px rgba(207,174,118,.5);font:600 13px 'Keepsake Sans',system-ui,sans-serif;color:#f3eadf;white-space:nowrap;animation:ffm-toast 2.1s cubic-bezier(.3,.9,.3,1) forwards}
.ffm-toast .ffm-thumb{width:20px;height:20px;margin:0 3px}
.ffm-toast .ffm-thumb img{width:30px;height:30px;margin:-15px 0 0 -15px}
.ffm-toast .ffm-thumb svg{inset:3px;width:14px;height:14px}
.ffm-toast em{font-style:normal;font-weight:700;letter-spacing:.14em;font-size:9.5px;text-transform:uppercase;color:#cfae76}
@keyframes ffm-toast{0%{opacity:0;margin-top:10px}14%{opacity:1;margin-top:0}75%{opacity:1;margin-top:-4px}100%{opacity:0;margin-top:-12px}}
.ffw.reduced .ffm-slot{transition:none!important}
.ffm-toast.reduced{animation:none}
`;

export class MacroRing{
  constructor(wheel){this.w=wheel;this.on=false;this.editing=false;this.buttons=new Map();this.views=[];this.pick=-1;}
  get host(){return this.w.host;}get doc(){return this.w.doc;}get root(){return this.w.root;}
  /** Drag-and-drop listeners exist only while the wheel is open. */
  listen(on){
    const d=this.doc;
    if(on&&!this.onDrag){this.onDrag=e=>this.dragEvent(e);this.onUp=e=>this.pointerUp(e);
      for(const t of ['dragenter','dragover','dragleave','drop'])d.addEventListener(t,this.onDrag,true);d.addEventListener('pointerup',this.onUp,true);}
    if(!on&&this.onDrag){for(const t of ['dragenter','dragover','dragleave','drop'])d.removeEventListener(t,this.onDrag,true);d.removeEventListener('pointerup',this.onUp,true);this.onDrag=this.onUp=null;}
  }
  enter(door){
    this.on=true;this.door=door;this.editing=false;this.pick=-1;this.dragging=null;this.enteredAt=now();
    this.ring=M.normalizeRing(this.host.macroRing?.()??[]);
    this.buttons=new Map();this.root.classList.add('msub');this.root.classList.remove('mediting');
    this.ensureSprite();this.layout({deal:true});this.restPlaque();
  }
  leave(){
    if(!this.on)return;if(this.editing)this.commit();this.closePanel();
    for(const b of this.buttons.values()){b.classList.add('gone');setTimeout(()=>b.remove(),320);}
    this.buttons=new Map();this.views=[];this.on=false;this.editing=false;this.pick=-1;
    this.root?.classList.remove('msub','mediting');this.cameoFor(null);this.hintRow('','');
  }
  close(){if(this.on){if(this.editing)this.commit();this.closePanel();}this.on=false;this.editing=false;}
  /** A macro was created, changed or deleted: redraw what is shown. */
  refresh(){if(!this.on)return;for(const [k,b] of this.buttons){const v=this.views.find(x=>x.key===k);if(v)v.info=this.host.resolveMacro(v.entry?.uuid);}this.layout();if(this.pick>=0)this.describe(this.pick);else this.restPlaque();}
  escape(){if(!this.on)return false;if(this.panel){this.closePanel();return true;}if(this.editing){this.toggleEdit();return true;}return false;}
  outsideDown(e){if(!this.on)return false;if(this.editing){if(this.panel)this.closePanel();return true;}return false;}

  /** The icon library's sprite goes into the page once; <use href="#mi-…"> draws from it. */
  ensureSprite(){
    if(this.lib)return Promise.resolve(this.lib);
    if(this.libLoading||!this.host.iconLibrary)return this.libLoading??Promise.resolve({entries:[]});
    this.libLoading=Promise.resolve(this.host.iconLibrary()).then(lib=>{
      this.lib=lib??{sprite:'',entries:[]};const d=this.doc;
      if(lib?.sprite&&!d.getElementById('ffm-sprite')){const h=d.createElement('div');h.id='ffm-sprite';h.style.cssText='position:absolute;width:0;height:0;overflow:hidden';h.innerHTML=lib.sprite;d.body.appendChild(h);}
      return this.lib;}).catch(e=>{this.lib={sprite:'',entries:[]};this.host.error?.(e);return this.lib;});
    return this.libLoading;
  }

  /* ---------------- the ring ---------------- */
  view(){
    const v=this.ring.map((e,k)=>{const info=this.host.resolveMacro(e.uuid);return {key:'m:'+e.uuid,kind:M.macroState(info),entry:e,index:k,info};});
    if(this.editing){const want=Math.min(M.MACRO_RING_MAX,Math.max(MIN_SHOWN_EDITING,v.length+1));for(let k=v.length;k<want;k++)v.push({key:'e:'+k,kind:'empty'});}
    else if(!v.length)for(let k=0;k<4;k++)v.push({key:'g:'+k,kind:'ghost'});
    return v;
  }
  ringRadius(n){return Math.max(this.w.g.R2,Math.ceil(n*70/TAU));}
  drawRing(R){
    if(R===this.drawnR&&this.ringG?.isConnected)return;this.drawnR=R;
    const L=this.w.svg.querySelector('.L-sub');this.ringG?.remove();
    const g=this.doc.createElementNS(SVGNS,'g');g.setAttribute('class','arcg');g.dataset.arc='macros';g.style.setProperty('--tint',TINT);
    const len=Math.ceil(Math.PI*R)+2,a=this.door;
    let h='';for(const s of [1,-1])for(const [cls,dr] of [['a',0],['b',3]]){const r=R+dr,[x0,y0]=[r*Math.sin(a*RAD),-r*Math.cos(a*RAD)],b=a+s*180,[x1,y1]=[r*Math.sin(b*RAD),-r*Math.cos(b*RAD)];
      h+=`<path class="arcline ${cls}" style="--len:${len}" d="M${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 0 ${s>0?1:0} ${x1.toFixed(2)} ${y1.toFixed(2)}"/>`;}
    g.innerHTML=h;L.appendChild(g);this.ringG=g;
    requestAnimationFrame(()=>requestAnimationFrame(()=>g.classList.add('on','drawn')));
  }
  /** Reconcile the bits with view(): bits are keyed, so a reorder glides round the ring. */
  layout({deal=false,order=null}={}){
    const root=this.root;if(!root)return;
    let v=this.view();
    if(order)v=order.map(k=>v.find(x=>x.key===k)).filter(Boolean).concat(v.filter(x=>!order.includes(x.key)));
    const n=v.length,R=this.ringRadius(n),step=360/n,door=this.door;
    this.views=v;this.mR=R;this.drawRing(R);
    this.w.placePlaque(R+20);   // clear of the label of the macro at the bottom
    const keep=new Set();
    v.forEach((it,i)=>{
      keep.add(it.key);let b=this.buttons.get(it.key);const fresh=!b,to=door+i*step;
      if(fresh){b=this.makeButton(it);this.buttons.set(it.key,b);
        if(deal){const travel=wrapDeg(to-door);b.style.setProperty('--from',`${door}deg`);b.style.setProperty('--to',`${door+travel}deg`);b.style.setProperty('--d',Math.round(Math.abs(travel)/step));b.dataset.ang=door+travel;}
        else{b.style.setProperty('--from',`${to}deg`);b.style.setProperty('--to',`${to}deg`);b.style.setProperty('--d',0);b.dataset.ang=to;b.classList.add('born');setTimeout(()=>b.classList.remove('born'),520);}
        root.insertBefore(b,this.w.plaque);
      }else{const cur=+b.dataset.ang||0,next=cur+wrapDeg(to-cur);b.style.setProperty('--to',`${next}deg`);b.style.setProperty('--d',0);b.dataset.ang=next;this.paint(b,it);}
      b.style.setProperty('--R',R);b.style.setProperty('--R0',deal?this.w.g.R:R);b.style.setProperty('--i',i);b.dataset.i=i;
    });
    for(const [k,b] of this.buttons)if(!keep.has(k)){this.buttons.delete(k);b.classList.add('gone');b.classList.remove('picked');setTimeout(()=>b.remove(),360);}
    this.list=v.map(it=>this.buttons.get(it.key));
    if(this.pick>=n)this.pick=-1;
  }
  gemInner(it,preview){
    const icon=preview!==undefined?preview:it.entry?.icon;
    if(it.kind==='empty')return {cls:'empty',html:`<span class="ffw-icon"><svg viewBox="0 0 24 24"><path d="${MACRO_ICONS.add}"/></svg></span>`};
    if(it.kind==='ghost')return {cls:'ghost',html:''};
    if(it.kind==='missing')return {cls:'missing glyph',html:`<span class="ffw-icon"><svg viewBox="0 0 24 24"><path d="${MACRO_ICONS.missing}"/></svg></span>`};
    if(iconSource(icon))return {cls:'glyph',html:`<span class="ffw-icon">${iconTag(icon)}</span>`};
    return {cls:'pic',html:`<span class="ffm-pic"><img src="${esc(it.info.img)}" alt="" draggable="false"></span><span class="ffm-rim"></span>`};
  }
  makeButton(it){
    const d=this.doc,b=d.createElement('button');b.type='button';b.className='ffw-slot ffm-slot';b.setAttribute('role','menuitem');
    b.innerHTML=`<span class="ffw-bob"><span class="ffw-gem"></span></span><span class="ffm-lab"></span>`;
    this.paint(b,it);
    // bits sliding in under a still pointer don't count as pointing
    b.addEventListener('pointerenter',()=>{if(this.on&&!this.dragging&&!this.panel&&now()-this.enteredAt>500)this.setPick(+b.dataset.i);});
    b.addEventListener('focus',()=>{if(this.on&&!this.panel)this.setPick(+b.dataset.i);});
    b.addEventListener('pointerdown',e=>{
      if(!this.on||!this.editing||e.button!==0)return;
      const v=this.views[+b.dataset.i];if(!v||v.kind==='empty')return;
      e.preventDefault();e.stopPropagation();this.dragging={key:v.key,from:+b.dataset.i,x0:e.clientX,y0:e.clientY,moved:false,b};});
    b.addEventListener('click',e=>{
      e.preventDefault();e.stopPropagation();if(!this.on)return;
      const i=+b.dataset.i,v=this.views[i];if(!v)return;
      if(v.kind==='ghost'){this.toggleEdit();return;}
      if(this.editing){if(v.kind==='empty')this.openAddPanel(i);else if(e.detail===0)this.openIconPanel(i);return;}
      this.fire(i);});
    return b;
  }
  paint(b,it,preview){
    const g=this.gemInner(it,preview),gem=b.querySelector('.ffw-gem');
    b.classList.remove('empty','ghost','missing','glyph','pic','denied');for(const c of g.cls.split(' '))b.classList.add(c);
    if(it.kind==='locked')b.classList.add('denied');
    if(gem.dataset.sig!==g.html){gem.innerHTML=g.html;gem.dataset.sig=g.html;}
    b.querySelector('.ffm-badge')?.remove();b.querySelector('.ffm-x')?.remove();
    if(it.kind==='locked')b.querySelector('.ffw-bob').insertAdjacentHTML('beforeend',`<span class="ffm-badge"><svg viewBox="0 0 24 24"><path d="${MACRO_ICONS.lock}"/></svg></span>`);
    if(it.entry){
      const x=this.doc.createElement('button');x.type='button';x.className='ffm-x';x.setAttribute('aria-label','Remove from the ring');x.innerHTML='<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7L7 17"/></svg>';
      x.addEventListener('pointerdown',e=>{e.stopPropagation();});
      x.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();this.removeAt(+b.dataset.i);});
      b.appendChild(x);}
    b.querySelector('.ffm-lab').textContent=it.info?it.info.name:it.kind==='missing'?'Missing':'';
    b.setAttribute('aria-label',it.info?`${it.info.name} · ${it.info.type}${it.kind==='locked'?' · you can\'t run this':''}`:it.kind==='missing'?'Missing macro':it.kind==='empty'?'Add a macro':'Empty');
  }

  /* ---------------- plaque ---------------- */
  plaque(name,sub,{reason=false}={}){this.w.setPlaque('Macros',name,sub,{reason,btns:this.editing?['done']:['back','edit']});}
  hintRow(chip,hint,type){
    const r=this.w.plaque?.querySelector('.ffm-hintrow');if(!r)return;r.classList.toggle('on',!!(chip||hint));
    const c=r.querySelector('.ffm-chip');c.textContent=chip??'';c.style.display=chip?'':'none';c.classList.toggle('chat',type==='chat');r.querySelector('.ffm-hint').textContent=hint??'';
  }
  cameoFor(it,preview){
    const cam=this.w.plaque?.querySelector('.ffm-cameo');if(!cam)return;
    if(!it||!it.entry){cam.classList.remove('on');this.w.plaque.classList.remove('cam');return;}
    const g=this.gemInner(it,preview);cam.innerHTML=`<span class="ffm-cg">${g.html.replace('<span class="ffm-rim"></span>','')}</span>`;cam.classList.add('on');cam.classList.toggle('denied',it.kind==='locked');this.w.plaque.classList.add('cam');
  }
  restPlaque(){
    const n=this.ring.length;this.cameoFor(null);
    if(this.editing){this.plaque('Edit macros',`${n} of ${M.MACRO_RING_MAX} · drag a bit to reorder`);this.hintRow('','Drop macros here from the hotbar');}
    else if(!n){this.plaque('No macros yet','Edit to add some');this.hintRow('','');}
    else{this.plaque('Macros',this.w.held?'Release on one · rest on her to go back':'Click one · click her to go back');this.hintRow('','');}
  }
  describe(i){
    const it=i>=0?this.views[i]:null;
    if(!it){if(i===-2){this.w.setPlaque('Macros','Back',this.w.held?'Rest here to go back · release cancels':'Click her · Esc · right-click',{btns:this.editing?['done']:['back','edit']});this.hintRow('','');this.cameoFor(null);}else this.restPlaque();return;}
    const ed=this.editing;
    if(it.kind==='macro'||it.kind==='locked'){const m=it.info;
      this.plaque(m.name,it.kind==='locked'?'You can\'t run this macro':ed?'Drag to move · click for its icon':this.w.held?'Release to run':'Click to run',{reason:it.kind==='locked'});
      this.hintRow(m.type==='chat'?'Chat':'Script',m.line,m.type);this.cameoFor(it);}
    else if(it.kind==='missing'){this.plaque('Missing macro',ed?'Deleted · Done removes it':'It was deleted · Edit removes it',{reason:true});this.hintRow('','');this.cameoFor(it);}
    else if(it.kind==='empty'){this.plaque('Add a macro','Click +, or drop one here');this.hintRow('','From the hotbar or the Macro Directory');this.cameoFor(null);}
    else{this.plaque('No macros yet','Edit to add some');this.hintRow('','');this.cameoFor(null);}
  }
  toggleEdit(){
    this.closePanel();
    if(this.editing){this.commit();this.editing=false;}else this.editing=true;
    this.root.classList.toggle('mediting',this.editing);this.setPick(-1,true);
    this.layout();this.restPlaque();
  }
  /** Done: deleted macros leave the ring; the rest is saved on the user. */
  commit(){
    this.ring=this.ring.filter(e=>this.host.resolveMacro(e.uuid));
    try{this.host.saveMacroRing?.(M.normalizeRing(this.ring));}catch(e){this.host.error?.(e);}
  }
  addMacro(uuid,at=this.ring.length){
    const info=this.host.resolveMacro(uuid);if(!info){this.plaque('Not a macro here','Only this world\'s macros can be added',{reason:true});return false;}
    const r=M.addToRing(this.ring,uuid,at);
    if(r.full){this.plaque('The ring is full',`${M.MACRO_RING_MAX} macros · remove one first`,{reason:true});return false;}
    this.ring=r.list;this.layout();
    this.plaque(info.name,r.added?'Added to the ring':'Moved');this.hintRow(info.type==='chat'?'Chat':'Script',info.line,info.type);this.cameoFor({kind:'macro',info,entry:this.ring.find(e=>e.uuid===uuid)});
    return true;
  }
  removeAt(i){const v=this.views[i];if(!v?.entry)return;this.closePanel();this.ring.splice(this.ring.indexOf(v.entry),1);this.layout();this.restPlaque();
    this.w.plaque.querySelector('.ffw-sub').textContent=`Removed ${v.info?.name??'a deleted macro'} · ${this.ring.length} of ${M.MACRO_RING_MAX}`;}

  /* ---------------- pointing ---------------- */
  sectorAt(deg){const n=this.views.length;return Math.round(wrapDeg(deg-this.door)/(360/n)+n)%n;}
  pointer(e,{dist,deg}){
    if(this.dragging){
      const dr=this.dragging;if(!dr.moved&&Math.hypot(e.clientX-dr.x0,e.clientY-dr.y0)<6)return;
      if(!dr.moved){dr.moved=true;this.closePanel();dr.b.classList.add('lifted');this.setPick(-1,true);}
      const cur=+dr.b.dataset.ang||0,pa=cur+wrapDeg(deg-cur);
      dr.b.style.setProperty('--pa',`${pa}deg`);dr.b.style.setProperty('--pr',Math.max(this.w.g.tokenR+20,dist));dr.b.dataset.ang=pa;
      // the others make room where it would land
      const filled=this.ring.length,to=Math.min(filled-1,this.sectorAt(deg));
      if(to!==dr.to){dr.to=to;const keys=this.ring.map(x=>'m:'+x.uuid).filter(k=>k!==dr.key);keys.splice(to,0,dr.key);
        this.layout({order:keys});dr.b.style.setProperty('--to',`${pa}deg`);dr.b.dataset.ang=pa;
        const it=this.views.find(x=>x.key===dr.key);this.plaque(it?.info?.name??'Missing',`Slot ${to+1} of ${filled} · release to place`);}
      return;
    }
    if(this.panel)return;
    if(dist>this.mR+56){if(!this.editing)this.setPick(-1);return;}
    if(dist<this.w.g.tokenR+10){this.setPick(this.editing?-1:-2);return;}
    this.setPick(this.sectorAt(deg));
  }
  pointerUp(e){
    const dr=this.dragging;if(!dr)return;this.dragging=null;
    if(!dr.moved){this.openIconPanel(dr.from);return;}
    e.preventDefault();e.stopPropagation();
    const order=this.views.filter(v=>v.entry).map(v=>v.entry);this.ring=order;
    dr.b.classList.remove('lifted');this.layout();this.restPlaque();
  }
  setPick(i,force=false){
    if(!this.root||(!force&&i===this.pick))return;this.pick=i;this.pickAt=now();
    for(const b of this.buttons.values())b.classList.toggle('picked',i>=0&&b===this.list?.[i]);
    this.root.classList.toggle('has-pick',i>=0);this.root.classList.toggle('back-pick',i===-2);
    this.w.dwell=i===-2&&this.w.held?{at:now(),it:{kind:'back'}}:null;
    const it=i>=0?this.views[i]:null;
    if(it&&it.kind!=='ghost')this.w.tether({angle:this.angleOf(i),r:this.mR,kind:'leaf'});else this.w.clearTether();
    this.describe(i);
  }
  angleOf(i){return ((this.door+i*360/this.views.length)%360+360)%360;}
  tick(){}
  release(){
    if(this.editing||!this.on)return;
    if(this.pick===-2){this.w.close();return;}
    if(this.pick<0)return;
    const a=this.angleOf(this.pick),{x,y}=this.w.g,p=this.w.ptr,gx=x+this.mR*Math.sin(a*RAD),gy=y-this.mR*Math.cos(a*RAD);
    const dec=M.releaseDecision({inZone:!p||Math.hypot(p.x-gx,p.y-gy)<=M.GEM_ZONE_PX,near:!p||Math.abs(Math.hypot(p.x-x,p.y-y)-this.mR)<=M.NEAR_RING_PX,dwellMs:now()-Math.max(this.pickAt??0,this.w.restAt??0),sinceEnterMs:now()-this.enteredAt,swift:this.w.swift});
    if(dec!=='fire'){this.w.setPlaque('Macros',this.views[this.pick]?.info?.name??'Macro','Too quick to be sure · click it to run it',{reason:true,btns:['back','edit']});return;}
    this.fire(this.pick);
  }
  async fire(i){
    const it=this.views[i],b=this.list?.[i];if(!it)return;
    if(it.kind==='ghost'||it.kind==='empty'){this.toggleEdit();return;}
    if(it.kind!=='macro'){b?.classList.remove('nope');void b?.offsetWidth;b?.classList.add('nope');
      this.plaque(it.info?.name??'Missing macro',it.kind==='locked'?'You can\'t run this macro':'It was deleted · Edit removes it',{reason:true});return;}
    b?.classList.add('fired');
    this.w.cfg.last={action:'macro',value:it.entry.uuid};this.w.save();
    const root=this.root;setTimeout(()=>{if(this.w.root===root)this.w.close();},280);
    try{await this.host.runMacro(it.entry.uuid);this.toast(it);}catch(error){this.host.error?.(error);}
  }
  toast(it){
    if(this.host.toast)return this.host.toast(`Ran: ${it.info.name}`,it.info);
    const a=this.host.anchor?.();if(!a)return;const d=this.doc,t=d.createElement('div');t.className='ffm-toast'+(this.host.reducedMotion?.()?' reduced':'');
    t.innerHTML=`<span class="ffm-thumb">${iconSource(it.entry?.icon)?iconTag(it.entry.icon):`<img src="${esc(it.info.img)}" alt="">`}</span><em>Ran</em><span>${esc(it.info.name)}</span>`;
    t.style.left=`${a.x}px`;t.style.top=`${a.y-(a.r??40)-26}px`;d.body.appendChild(t);setTimeout(()=>t.remove(),2200);
  }
  /** Drops from Foundry's hotbar / Macro Directory (native HTML5 drag and drop). */
  dragEvent(e){
    const w=this.w;if(!w.root)return;
    const {x,y,tokenR}=w.g,dist=Math.hypot(e.clientX-x,e.clientY-y),near=dist<(this.on?this.mR:w.g.R2)+60&&dist>tokenR*.4;
    const clear=()=>{for(const b of this.buttons.values())b.classList.remove('drop');};
    if(!near){if(e.type==='dragover'||e.type==='dragleave'){clear();this.dropAt=null;}return;}
    // dragging over the closed main ring: open the Macros ring in edit mode
    if(!this.on){if(e.type!=='dragenter'&&e.type!=='dragover')return;if(!w.feat.macros||w.editing)return;
      e.preventDefault();if(w.level!=='main')w.back();w.enter('macros');if(this.on&&!this.editing)this.toggleEdit();return;}
    if(!this.editing&&(e.type==='dragenter'||e.type==='dragover'))this.toggleEdit();
    if(e.type==='dragenter'||e.type==='dragover'){
      e.preventDefault();if(e.dataTransfer)e.dataTransfer.dropEffect='copy';
      const deg=((Math.atan2(e.clientX-x,-(e.clientY-y))/RAD)+360)%360,i=Math.min(this.sectorAt(deg),this.ring.length);
      if(this.dropAt!==i){this.dropAt=i;clear();this.list?.[i]?.classList.add('drop');
        this.plaque('Drop to add',i<this.ring.length?`Into slot ${i+1} · the rest move along`:`Into slot ${i+1}`);this.hintRow('','From the hotbar or the Macro Directory');this.cameoFor(null);}
      return;
    }
    if(e.type==='drop'){
      e.preventDefault();e.stopPropagation();clear();const at=this.dropAt??this.ring.length;this.dropAt=null;
      let data=null;try{data=this.host.macroDropData?.(e);}catch{}
      if(data?.type!=='Macro'||!data.uuid){this.plaque('Not a macro','Drag a macro from the hotbar or directory',{reason:true});return;}
      this.addMacro(data.uuid,at);
    }
  }

  /* ---------------- panels ---------------- */
  panelAt(el){
    const R=this.mR,gap=R+118,right=(this.w.g.x??0)+gap+310<(this.doc.defaultView?.innerWidth??1e9);
    el.style.left=right?`${gap}px`:`${-gap-300}px`;el.style.top=`${-Math.min(196,(this.w.g.y??300)-50)}px`;
  }
  closePanel(){this.panel?.remove();this.panel=null;for(const b of this.buttons.values())b.classList.remove('drop','focus');
    if(this.iconFor){const v=this.views.find(x=>x.entry===this.iconFor);const b=v&&this.buttons.get(v.key);if(b)this.paint(b,v);this.iconFor=null;}}
  /** (test.11) "Write a new macro…": name, kind and what it does; saved as a Foundry macro of yours and put on the ring. */
  openWritePanel(i){
    this.closePanel();const d=this.doc,p=d.createElement('div');p.className='ffm-panel ffm-write';this.panelAt(p);
    p.innerHTML=`<h3>Write a macro<small>slot ${Math.min(i,this.ring.length)+1}</small></h3>
      <label class="ffm-field"><span>Name</span><input type="text" data-k="name" maxlength="80" placeholder="What it is called" spellcheck="false"></label>
      <div class="ffm-seg" role="radiogroup" aria-label="Kind"><button type="button" class="b primary" data-t="script" role="radio" aria-checked="true">Script</button><button type="button" class="b" data-t="chat" role="radio" aria-checked="false">Chat line</button></div>
      <label class="ffm-field"><span data-cl>What it runs (JavaScript)</span><textarea data-k="command" rows="6" spellcheck="false" placeholder="game.modules.get('filament-flight').api.v11.fade()"></textarea></label>
      <p class="note" data-msg>It is saved in your Macro Directory, so you can edit it there later.</p>
      <div class="row"><button type="button" class="b" data-back>Back</button><button type="button" class="b primary" data-save>Save and add</button></div>`;
    let type='script';const name=p.querySelector('[data-k=name]'),cmd=p.querySelector('[data-k=command]'),msg=p.querySelector('[data-msg]');
    p.addEventListener('pointerdown',e=>e.stopPropagation());
    for(const el of [name,cmd])for(const t of ['keydown','keyup','keypress'])el.addEventListener(t,e=>{if(e.key!=='Escape')e.stopPropagation();});
    p.querySelector('.ffm-seg').addEventListener('click',e=>{const b=e.target.closest('[data-t]');if(!b)return;type=b.dataset.t;
      for(const x of p.querySelectorAll('[data-t]')){const on=x===b;x.classList.toggle('primary',on);x.setAttribute('aria-checked',String(on));}
      p.querySelector('[data-cl]').textContent=type==='chat'?'What it says or rolls (a chat line)':'What it runs (JavaScript)';cmd.placeholder=type==='chat'?'/me bows':"game.modules.get('filament-flight').api.v11.fade()";});
    p.querySelector('[data-back]').addEventListener('click',e=>{e.preventDefault();this.openAddPanel(i);});
    const save=p.querySelector('[data-save]');
    save.addEventListener('click',async e=>{e.preventDefault();if(save.disabled)return;save.disabled=true;
      try{const uuid=await this.host.createMacro({name:name.value,type,command:cmd.value});
        if(this.panel===p)this.closePanel();this.addMacro(uuid,Math.min(i,this.ring.length));}
      catch(err){msg.textContent=String(err?.message??err);msg.style.color='#ff9db5';save.disabled=false;}});
    this.root.appendChild(p);this.panel=p;setTimeout(()=>name.focus({preventScroll:true}),30);
  }
  /** "+": a small searchable picker of the user's macros. */
  openAddPanel(i){
    this.closePanel();const d=this.doc,p=d.createElement('div');p.className='ffm-panel ffm-add';this.panelAt(p);
    const all=(this.host.listMacros?.()??[]).slice().sort((a,b)=>(b.canExecute-a.canExecute)||a.name.localeCompare(b.name));
    p.innerHTML=`<h3>Add a macro<small>slot ${Math.min(i,this.ring.length)+1}</small></h3>
      <label class="ffm-search"><svg viewBox="0 0 24 24"><path d="M10.5 4a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13M15.5 15.5L20 20"/></svg><input type="search" placeholder="Search your macros" spellcheck="false"></label>
      <div class="ffm-list" role="listbox"></div>
      <p class="note">Or drag one from the hotbar or the Macro Directory onto the ring.</p>
      ${this.host.createMacro?'<div class="row"><button type="button" class="b" data-new>Write a new macro…</button></div>':''}`;
    p.querySelector('[data-new]')?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();this.openWritePanel(i);});
    const list=p.querySelector('.ffm-list'),input=p.querySelector('input');
    const draw=()=>{const q=input.value.trim().toLowerCase();
      const rows=all.filter(m=>!q||m.name.toLowerCase().includes(q)||(m.type??'').includes(q));
      list.innerHTML=rows.length?rows.map((m,k)=>{const on=this.ring.some(e=>e.uuid===m.uuid);
        return `<button type="button" class="ffm-row${m.canExecute?'':' denied'}${k===0&&q?' hot':''}" data-u="${esc(m.uuid)}"${m.canExecute?'':' title="You can\'t run this macro"'}><span class="ffm-thumb"><img src="${esc(m.img)}" alt=""></span><span class="nm">${esc(m.name)}</span>${on?'<span class="on">on ring</span>':''}<span class="ffm-chip${m.type==='chat'?' chat':''}">${m.type==='chat'?'Chat':'Script'}</span></button>`;}).join('')
        :'<div class="ffm-empty">No macros match.</div>';};
    draw();input.addEventListener('input',draw);
    input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();list.querySelector('.ffm-row:not(.denied)')?.click();}});
    list.addEventListener('click',e=>{const r=e.target.closest('.ffm-row');if(!r||r.classList.contains('denied'))return;this.closePanel();this.addMacro(r.dataset.u,Math.min(i,this.ring.length));});
    p.addEventListener('pointerdown',e=>e.stopPropagation());
    this.root.appendChild(p);this.panel=p;setTimeout(()=>input.focus({preventScroll:true}),30);
    for(const b of this.buttons.values())b.classList.toggle('focus',b===this.list?.[i]);
    return p;
  }
  /** Icons offered: the library (Keepsake), Foundry's core icons, or both (Settings). */
  async iconGroups(){
    const mode=this.w.features().macroIcons??'keepsake',groups=[];
    if(mode!=='foundry'){const lib=await this.ensureSprite()??{entries:[]};
      groups.push(...(lib.groups??[]).map(g=>({id:g.id,name:g.name,list:[]})));
      for(const e of lib.entries??[]){let g=groups.find(x=>x.id===e.group||x.name===e.group);if(!g)groups.push(g={id:e.group,name:e.group,list:[]});g.list.push(e);}}
    if(mode!=='keepsake')groups.push({id:'foundry',name:'Foundry',list:FOUNDRY_ICONS.map(n=>({id:`fi:${n}`,name:n.replace(/-/g,' '),keywords:[n]}))});
    return groups.filter(g=>g.list.length);
  }
  /** Click a bit in edit mode: choose its icon. The macro's own image is the default. */
  async openIconPanel(i){
    const v=this.views[i];if(!v?.entry)return;
    this.closePanel();const groups=await this.iconGroups();if(!this.on||!this.editing)return;
    const d=this.doc,p=d.createElement('div');p.className='ffm-panel ffm-icons';this.panelAt(p);
    const entry=v.entry,info=v.info,b=this.buttons.get(v.key);this.iconFor=entry;
    const total=groups.reduce((a,g)=>a+g.list.length,0);
    p.innerHTML=`<h3>Icon<small>${total} icons</small></h3><p class="sub">${esc(info?.name??'Missing macro')}</p>
      <button type="button" class="ffm-own${entry.icon?'':' sel'}"><span class="ffm-thumb">${info?`<img src="${esc(info.img)}" alt="">`:''}</span><span class="t"><b>Use the macro's own image</b><span>Default · follows the macro</span></span></button>
      <label class="ffm-search"><svg viewBox="0 0 24 24"><path d="M10.5 4a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13M15.5 15.5L20 20"/></svg><input type="search" placeholder="Search ${total} icons: heal, torch, roll…" spellcheck="false"></label>
      <div class="ffm-grid"></div>
      <div class="row"><button type="button" class="b" data-x>Remove macro</button><button type="button" class="b primary" data-done>Done</button></div>`;
    const grid=p.querySelector('.ffm-grid'),input=p.querySelector('input'),own=p.querySelector('.ffm-own');
    const draw=()=>{const q=input.value.trim().toLowerCase();
      const html=groups.map(g=>{const l=g.list.filter(e=>!q||e.name.toLowerCase().includes(q)||g.name.toLowerCase().includes(q)||(e.keywords??[]).some(k=>k.includes(q)));
        return l.length?`<h4>${esc(g.name)}</h4><div class="ffm-cells">${l.map(e=>`<button type="button" class="ffm-cell${entry.icon===e.id?' sel':''}" data-id="${esc(e.id)}" title="${esc(e.name)}">${iconTag(e.id)}</button>`).join('')}</div>`:'';}).join('');
      grid.innerHTML=html||'<div class="ffm-empty">No icons match.</div>';};
    draw();input.addEventListener('input',draw);
    const show=icon=>{if(b)this.paint(b,v,icon);};
    grid.addEventListener('pointerover',e=>{const c=e.target.closest('.ffm-cell');if(c)show(c.dataset.id);});
    grid.addEventListener('pointerleave',()=>show(undefined));
    own.addEventListener('pointerenter',()=>show(null));own.addEventListener('pointerleave',()=>show(undefined));
    const choose=icon=>{entry.icon=icon;own.classList.toggle('sel',!icon);for(const c of grid.querySelectorAll('.ffm-cell'))c.classList.toggle('sel',c.dataset.id===icon);show(undefined);
      this.cameoFor({...v,entry});this.w.plaque.querySelector('.ffw-sub').textContent=icon?`Icon: ${groups.flatMap(g=>g.list).find(e=>e.id===icon)?.name??icon}`:'Icon: the macro\'s own image';};
    grid.addEventListener('click',e=>{const c=e.target.closest('.ffm-cell');if(c)choose(c.dataset.id);});
    own.addEventListener('click',()=>choose(null));
    p.querySelector('[data-done]').addEventListener('click',()=>this.closePanel());
    p.querySelector('[data-x]').addEventListener('click',()=>{this.closePanel();this.removeAt(this.views.indexOf(v));});
    p.addEventListener('pointerdown',e=>e.stopPropagation());
    this.root.appendChild(p);this.panel=p;
    for(const x of this.buttons.values())x.classList.toggle('focus',x===b);
    this.setPick(i,true);
    return p;
  }
  targetXY(i){const a=this.angleOf(i),{x,y}=this.w.g;return [x+this.mR*Math.sin(a*RAD),y-this.mR*Math.cos(a*RAD)];}
}
