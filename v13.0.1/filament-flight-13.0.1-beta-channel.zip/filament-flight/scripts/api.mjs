import {flightFeelEnabled,readFlightFeel,landingTiming,groundElevationChanges,wingShieldRaised,raiseShieldEffect,flyingHeight,steadyMode,GROUND_FLAG,FEEL_FLAG,SHIELD_FLAG} from './flight-feel-runtime.mjs?v=13.0.1';
import {forceDelete,deleteKey,isDeletion,deletes} from './forced-delete.mjs?v=13.0.1';
import {isRecall,recallTiming,landingBitTiming} from './v12/landing-recall.mjs?v=13.0.1';
import {resolveV11} from './v11/features.mjs?v=13.0.1';
import {baseAltitude,modeCeiling} from './flight-character.mjs?v=13.0.1';
import {normalizeFeel,ALTITUDE_LIMIT} from './flight-feel.mjs?v=13.0.1';
import {effectiveScanMethods,normalizeScanMethods} from './v84-scan-methods.mjs?v=13.0.1';
import {REACTION_IDS,effectCatalog} from './effect-catalog.mjs?v=13.0.1';
import {ID, VERSION, SCHEMA_VERSION, configuration, runtimeConfiguration, optionPatch} from './config.mjs?v=13.0.1';
import {DEFAULTS, options} from './motion.mjs?v=13.0.1';
import {normalizeFlag, resolveState, validateStatePatch, capabilities} from './state.mjs?v=13.0.1';
import {current} from './renderer.mjs?v=13.0.1';
import {validatePose, samplePose,poseTimingMotion} from './poses.mjs?v=13.0.1';
import {resolvePoseMotion,BIT_STATIONS,BIT_POSITION_FIELDS} from './wing-controls.mjs?v=13.0.1';
import {formationStations} from './bit-allocations.mjs?v=13.0.1';
import {bitTarget,bitCountTarget} from './bit-deployment.mjs?v=13.0.1';
import {qualityProfile,mergeQuality} from './quality.mjs?v=13.0.1';
import {AIRBORNE_MODES,modeTransitionFrom} from './flight-profiles.mjs?v=13.0.1';
import {LOOK_FIELDS,LOOK_PRESETS,normalizeLook,lookFingerprint,captureV7Look,v7LookPatch} from './look-presets.mjs?v=13.0.1';
import {healthContext, sampleCondition, validateCondition} from './conditions.mjs?v=13.0.1';
import {FlightHUD} from './hud.mjs?v=13.0.1';
import {AUDIO_SLOTS,normalizeAudio,validateAudioPatch,validateAudioPreview,mergeAudio,resolveAudio} from './audio-model.mjs?v=13.0.1';
import {BitAnimationRuntime} from './bit-actions.mjs?v=13.0.1';
import {makeStructureTransition,validateStructure} from './energy-structures.mjs?v=13.0.1';
import {mergeStructurePoses,makeStructurePoseTransition,validateStructureSize} from './structure-poses.mjs?v=13.0.1';
import {localPerformance} from './performance.mjs?v=13.0.1';
import {conditionReactionSettings,mergeConditionReactions,reactionVisualActive,conditionFlightBlockers} from './condition-response.mjs?v=13.0.1';
import {previewTreatment} from './treatment-preview.mjs?v=13.0.1';
import {lanternPatch,lanternEnvelope,normalizeLantern} from './lantern-model.mjs?v=13.0.1';
import {captureLanternFormation} from './lantern-emitters.mjs?v=13.0.1';
import {resolveBitLight} from './light-model.mjs?v=13.0.1';
import {v7PreferencesPatch} from './v7-ensemble.mjs?v=13.0.1';
import {WING_GESTURES,beginWingGesture,endWingGesture} from './v7-wing-motion.mjs?v=13.0.1';
import {DEFAULT_SCAN_SPEED,scanSpeed} from './v82-scan-clock.mjs?v=13.0.1';
import {TREATMENT_LABELS,treatmentStylesFor} from './hardlight-treatment.mjs?v=13.0.1';
import {lanternLockForSubject,resolveLanternLock,lightPresetPatch,saveLightPresetPatch,resetLightPresetPatch} from './v88-lantern-tools.mjs?v=13.0.1';
import {keepsakeTimings} from './keepsake/timings.mjs?v=13.0.1';
import {openSelfCheck,runSelfCheckWithPanel,formatReport} from './self-check.mjs?v=13.0.1';

const PATH=`flags.${ID}.flight`;
const LIGHT_FIELDS=new Set(['lightEnabled','lightWithBits','lightIntensity','lightBright','lightDim','lightAppearance','lightVisualReactions','lanternArtwork','lantern']);
export const serverTime = () => Number(game.time?.serverTime) || Date.now();
const visiblePreviousWingGesture=(event,signatureCraft)=>WING_GESTURES[event?.name]?.v9===true&&!signatureCraft?null:event;

function transitionOptions(kind,input={}) {
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Transition options must be an object.');
  const takeoff=['duration','mode','formation'],landing=['duration','keepWings','foldWings','keepBits'],
    allowed=kind==='toggle'?[...new Set([...takeoff,...landing])]:kind==='takeoff'?takeoff:landing;
  for(const key of Object.keys(input))if(!allowed.includes(key))throw new Error(`Unknown transition option: ${key}.`);
  if(input.duration!==undefined&&(!Number.isFinite(input.duration)||input.duration<0||input.duration>10000))throw new Error('Duration must be 0–10000 milliseconds.');
  if(input.mode!==undefined&&!AIRBORNE_MODES.includes(input.mode))throw new Error(`Takeoff mode must be ${AIRBORNE_MODES.join(', ')}.`);
  for(const key of ['keepWings','keepBits','formation','foldWings'])if(input[key]!==undefined&&typeof input[key]!=='boolean')throw new Error(`${key} must be true or false.`);
  return {...input};
}

// Explicit overrides retain their meaning when world defaults later change.
// Only skip a light edit when those exact saved values already exist; an
// inherited false value still needs a write when the caller chooses false.
function unchangedLightPatch(raw,patch) {
  return raw?.schemaVersion===SCHEMA_VERSION&&Object.keys(patch).length>0&&Object.entries(patch).every(([key,value])=>
    LIGHT_FIELDS.has(key)&&(key==='lantern'?Object.entries(value).every(([field,v])=>JSON.stringify(raw.lantern?.[field])===JSON.stringify(v)):raw[key]===value));
}

export function tokenDocument(input) {
  const Type=globalThis.CONFIG?.Token?.documentClass ?? globalThis.foundry?.documents?.TokenDocument;
  if (typeof Type !== 'function') return null;
  if (input instanceof Type) return input;
  if (input?.document instanceof Type) return input.document;
  return null;
}

function requireDocument(input) {
  const doc=tokenDocument(input);
  if (!doc || !doc.id || doc.parent?.tokens?.get(doc.id) !== doc || input?.isPreview)
    throw new Error('Pass a placed Token or its TokenDocument.');
  return doc;
}

// Foundry merges object flags recursively. Explicit deletion keys are needed
// when an audio override is reset, otherwise the old nested value survives.
function audioFlagChanges(before,after,path=`flags.${ID}.audio`,out={}) {
  for(const key of new Set([...Object.keys(before??{}),...Object.keys(after??{})])) {
    if(!/^[a-zA-Z0-9_]+$/.test(key))continue;
    if(!Object.hasOwn(after??{},key)){forceDelete(out,path,key);continue;}
    const value=after[key];
    if(value&&typeof value==='object'&&!Array.isArray(value))audioFlagChanges(before?.[key],value,`${path}.${key}`,out);
    else out[`${path}.${key}`]=value;
  }
  return out;
}

export class FlightAPI {
  constructor(manager) { this.manager=manager; this.queues=new Map();this.lookUndos=new Map();this.lookQueue=Promise.resolve();this.bits=new BitAnimationRuntime(this);manager.bits=this.bits; }

  hudController() {return this.hud??=new FlightHUD(()=>this.hudAPI());}
  /** The module API (with the v10 additions) once Foundry has it, else one cached copy; never rebuilt per HUD read. */
  hudAPI() {const api=globalThis.game?.modules?.get?.(ID)?.api;return api?.version===VERSION&&api.getState?api:(this.publicCache??=this.publicAPI());}

  /** Keyboard controls retain their pinned target while waiting behind an
   * existing command. Scope this local guard only to the synchronous enqueue;
   * normal API/macros keep their existing target contract. */
  withControlGuard(target,guard,action) {
    const doc=requireDocument(target),previous=this.controlGuard;
    this.controlGuard={doc,guard};
    try{return action();}finally{this.controlGuard=previous;}
  }

  enqueue(doc, task) {
    const key=doc.uuid, previous=this.queues.get(key) ?? Promise.resolve();
    const controlled=this.controlGuard?.doc===doc?this.controlGuard:null;
    const result=previous.catch(()=>{}).then(()=>{
      if(controlled){try{if(controlled.guard()!==true)return false;}catch{return false;}}
      return task();
    });
    const settled=result.catch(()=>{});
    this.queues.set(key,settled);
    void settled.then(()=>{ if (this.queues.get(key)===settled) this.queues.delete(key); });
    return result;
  }

  assertOwned(doc) {
    requireDocument(doc);
    if (!doc.isOwner) throw new Error('You must own this token to change its flight state.');
    normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
  }

  getState(target) {
    const doc=requireDocument(target);
    const now=serverTime(),cfg=runtimeConfiguration();
    const resolved=resolveState(normalizeFlag(doc.getFlag(ID,'flight'),now),cfg,now,this.context(doc));
    const state=resolveBitLight(this.bits.prepareSnapshot(doc,resolved,now),cfg);
    const renderer=this.manager.states?.get(doc.object)?.renderer;
    // Local diagnostics are additive; rendering.renderer retains its documented
    // meaning (resolved intent) and no render objects escape through the API.
    state.rendering.localRenderer=renderer?(renderer.rig?'rig':'atlas'):null;
    state.rendering.fallback=!!renderer?.failedQuality;
    Object.assign(state.light,this.manager.lights?.status(doc.object)??{localActive:false,error:null});
    Object.assign(state.lantern,{aiming:!!this.manager.lantern?.isAiming?.(doc.object)});
    return state;
  }
  context(doc) {return this.manager.context?.(doc)??healthContext(doc);}
  sampledPose(data,doc,now) {
    const cfg=configuration();
    return samplePose(data,now,resolvePoseMotion(data,cfg).enabled,cfg.temporaryPoses,this.context(doc).resumePoseTransition);
  }
  sampledCondition(data,doc,cfg,now) {
    const context=this.context(doc);
    return sampleCondition(context.hpTransition?{...data,hpTransition:context.hpTransition}:data,context.health,cfg,now,context);
  }

  async applied(doc,{lightSync=null}={}) {
    if (doc.parent.id === canvas.scene?.id&&!(lightSync&&this.manager.lightSyncCompleted?.(doc,lightSync.previous))) await this.manager.sync(doc.object);
    return this.getState(doc);
  }

  setV7Preferences(target,patch) {return this.setState(target,{v7:patch});}
  v7WingBridgeChanges(data,before,now,name,{opening=false}={}) {
    const v7=before.v7;
    if(!v7?.enabled||!v7.wingAnimations||!v7.seamlessActions||before.effective?.reducedMotion||!opening&&!before.rendering?.wingsActive||
      before.conditionResponse?.wings&&before.conditionResponse.collapse.mix>.01||
      before.v7?.wingMotion?.active&&data.v7?.wingGesture?.source!=='bridge')return {};
    const previous=visiblePreviousWingGesture(data.v7?.wingGesture,before.v9?.signatureCraft===true);
    const event=beginWingGesture(name,now,previous,{intensity:.18,hold:0,key:foundry.utils.randomID(16),variants:v7.transitionVariants,source:'bridge'});
    return {[`${PATH}.v7.wingGesture`]:event};
  }
  wingGesture(target,name,options={}) {
    const doc=requireDocument(target);
    if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>!['intensity','hold'].includes(k)))throw new Error('Pass wing gesture intensity and/or hold.');
    for(const [key,max] of [['intensity',1],['hold',60000]])if(options[key]!==undefined&&(typeof options[key]!=='number'||!Number.isFinite(options[key])||options[key]<0||options[key]>max))throw new Error(`Wing gesture ${key} must be a finite number from 0 to ${max}.`);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      const now=serverTime(),cfg=configuration(),data=normalizeFlag(doc.getFlag(ID,'flight'),now),state=resolveState(data,cfg,now,this.context(doc));
      if(name!=null&&(!state.v7?.enabled||!state.v7?.wingAnimations))throw new Error('Enable V7 wing animations for this character first.');
      if(name!=null&&WING_GESTURES[name]?.v9===true&&cfg.v9SignatureCraft!==true)throw new Error('Enable V9 signature craft to use this wing gesture.');
      const previous=visiblePreviousWingGesture(data.v7?.wingGesture,cfg.v9SignatureCraft===true);
      const event=name==null?endWingGesture(previous,now):beginWingGesture(name,now,previous,{...options,key:foundry.utils.randomID(16),variants:state.v7.transitionVariants});
      return this.commit(doc,{v7:{wingGesture:event}});
    });
  }

  /** Preserve selected-token calls and their count result. New calls accept a target. */
  command(mode, first, second) {
    const target=tokenDocument(first), explicit=!!target;
    if (!explicit && second !== undefined) return Promise.reject(new Error('Pass a Token or TokenDocument before its options.'));
    if (!explicit && !canvas.ready) return Promise.resolve(ui.notifications.warn('Open a scene first.'));
    const selected=explicit ? [requireDocument(first)] : [...(canvas.tokens?.controlled??[])];
    const docs=explicit ? selected : selected.filter(t=>current(t)&&!t.isPreview&&t.document.isOwner).map(t=>t.document);
    if (!docs.length) return Promise.resolve(ui.notifications.warn('Select a token you own first.'));
    const input=explicit ? second : first;
    const tasks=docs.map(doc=>this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      if (!explicit && (doc.parent.id!==canvas.scene?.id || !current(doc.object))) throw new Error('The selected scene changed before the flight command ran.');
      const raw=doc.getFlag(ID,'flight'), old=normalizeFlag(raw,serverTime());
      const on=mode==='toggle' ? !old.enabled : mode==='on';
      if (on) {
        const cfg=configuration(), overrides={...old.optionOverrides,...optionPatch(input,{strict:false})};
        const grounded=conditionFlightBlockers(resolveState(old,cfg,serverTime(),this.context(doc)).conditionResponse).length>0;
        const values={schemaVersion:SCHEMA_VERSION,enabled:true,airborne:!grounded,started:serverTime(),activation:foundry.utils.randomID(16),mode:old.mode==='grounded'?'hover':old.mode,
          pose:old.pose,structure:old.structure,wingForm:old.wingForm,structurePoses:structuredClone(old.structurePoses),structurePoseTransition:null,structureTransition:null,condition:old.condition,intensity:old.intensity,inheritDefaults:raw==null?true:old.inheritDefaults,
          conditionSource:old.conditionSource,autoHP:old.autoHP,glitchIntensity:old.glitchIntensity,
          conditionReactions:old.conditionReactions,conditionResponse:old.conditionResponse,
          trailIntensity:old.trailIntensity,movementReactions:old.movementReactions,
          lightEnabled:old.lightEnabled,lightWithBits:old.lightWithBits,lightIntensity:old.lightIntensity,
          lightBright:old.lightBright,lightDim:old.lightDim,lightAppearance:old.lightAppearance,lightVisualReactions:old.lightVisualReactions,lanternArtwork:old.lanternArtwork,lantern:{...old.lantern},effectStyle:old.effectStyle,effectStyles:{...old.effectStyles},
          reactionStyles:{...old.reactionStyles},effectTuning:structuredClone(old.effectTuning),reactionTuning:structuredClone(old.reactionTuning),
          poseMotion:{...old.poseMotion},gemMotion:{...old.gemMotion},v7:old.v7,
          options:options({...old.options,...Object.fromEntries(Object.entries(overrides).map(([key,value])=>[key,value??cfg.defaults[key]]))}),
          optionOverrides:overrides,transition:null,modeTransition:null,bitTransition:null,
          poseTransition:null,temporaryPose:null,conditionTransition:null,temporaryCondition:null,hpTransition:null,cues:null};
        await doc.setFlag(ID,'flight',values);
      } else if(raw!=null) await doc.update({...groundElevationChanges(doc),[`${PATH}.enabled`]:false,[`${PATH}.airborne`]:false,[`${PATH}.transition`]:null,[`${PATH}.temporaryPose`]:null,
        [`${PATH}.temporaryCondition`]:null,[`${PATH}.cues`]:null,...this.implicitWingRetractionLightChanges(doc,old,configuration(),serverTime())});
      await this.applied(doc);
      return on;
    }));
    return Promise.all(tasks).then(results=>{
      const enabled=results.filter(Boolean).length, disabled=results.length-enabled;
      const message=[enabled?`${enabled} flying`:null,disabled?`${disabled} landed`:null].filter(Boolean).join(', ');
      ui.notifications.info(`Yvaelle’s Toolbox: ${message}.`);
      if (!explicit && docs.length!==selected.length) ui.notifications.warn('Skipped tokens you do not own.');
      return {enabled,disabled};
    });
  }

  setState(target,input) {
    const doc=requireDocument(target), patch=validateStatePatch(input);
    const bitCommand=Object.keys(patch).length>0&&Object.keys(patch).every(key=>LIGHT_FIELDS.has(key)||['bitsDeployed','gemMotion'].includes(key));
    return this.enqueue(doc,()=>bitCommand?this.bits.commandScope(doc,Object.keys(patch).some(key=>LIGHT_FIELDS.has(key))?'light adjustment':'instrument settings',()=>this.commit(doc,patch)):this.commit(doc,patch));
  }

  setWingsEnabled(target,enabled,input={}){
    const selected=target===undefined,duration=this.poseOptions(input);
    if(enabled!==undefined&&typeof enabled!=='boolean')throw new Error('Wings enabled must be true or false.');
    if(selected&&!canvas.ready)return Promise.resolve(ui.notifications.warn('Open a scene first.'));
    const docs=selected?[...(canvas.tokens?.controlled??[])].filter(t=>current(t)&&!t.isPreview&&t.document.isOwner).map(t=>t.document):[requireDocument(target)];
    if(!docs.length)return Promise.resolve(ui.notifications.warn('Select a token you own first.'));
    return Promise.all(docs.map(doc=>this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      if(selected&&(doc.parent!==canvas.scene||!current(doc.object)))throw new Error('The selected scene changed before the wings command ran.');
      const now=serverTime(),raw=doc.getFlag(ID,'flight'),data=normalizeFlag(raw,now),cfg=configuration(),before=resolveState(data,cfg,now,this.context(doc));
      const next=enabled??!data.enabled;if(next===data.enabled)return this.getState(doc);
      const unpowered=before.conditionResponse.bits&&['falling','fallen'].includes(before.conditionResponse.collapse.phase);
      const local=this.manager.states?.get(doc.object),fromBlend=data.transition?before.rendering.blend:local?.blend??before.rendering.blend;
      const fromFlight=before.rendering.flightFactor,fromWings=before.formation.explicit?Object.fromEntries(['growth','fold','presence'].map(k=>[k,before.formation[k]])):{growth:fromBlend,fold:0,presence:fromBlend};
      const changes={[`${PATH}.schemaVersion`]:SCHEMA_VERSION,[`${PATH}.enabled`]:next,[`${PATH}.airborne`]:unpowered?false:data.airborne,[`${PATH}.mode`]:data.mode,
        [`${PATH}.transition`]:{id:foundry.utils.randomID(16),kind:next?'takeoff':'landing',wingsOnly:true,started:now,
          duration:cfg.transitions&&!cfg.reduced?(duration??cfg.transitionDuration):0,fromBlend,toBlend:next?1:0,
          fromFlight,toFlight:!unpowered&&data.airborne?1:0,wings:{from:fromWings,to:{growth:next?1:0,fold:next?0:1,presence:next?1:0}}}};
      Object.assign(changes,this.v7WingBridgeChanges(data,before,now,next?'quietFlourish':'heldBreath',{opening:next}));
      // Deliberately opening wings also requests their stabilizers, including
      // after the ordinary Bits control stored them. World renderer opt-outs
      // and the current collapse episode still own whether they can appear.
      const summonStabilizers=next&&!unpowered&&cfg.controlGems!==false&&cfg.wingRenderer!=='atlas';
      const nextGemMotion=summonStabilizers?{...data.gemMotion,enabled:true,...(data.gemMotion.style==='hidden'?{style:null}:{})}:data.gemMotion;
      if(summonStabilizers){
        changes[`${PATH}.gemMotion.enabled`]=true;
        if(data.gemMotion.style==='hidden')changes[`${PATH}.gemMotion.style`]=null;
      }
      // Freeze the pre-command destinations if this token still uses implicit
      // wing deployment. Opening broken wings must not summon new bits later
      // when healing ends the collapse visibility mask.
      if(unpowered&&!doc.getFlag(ID,'bitAllocations')){
        const allocation=this.bits.allocation(doc),captured=before.conditionResponse.collapse.bits;
        for(const [id,bit]of Object.entries(allocation.bits))if(bit.location==='home'&&!captured.includes(id))bit.location='retracted';
        changes[`flags.${ID}.bitAllocations`]=allocation;
      }
      if(raw==null)changes[`${PATH}.inheritDefaults`]=true;
      if(next){changes[`${PATH}.started`]=now;changes[`${PATH}.activation`]=foundry.utils.randomID(16);}
      // Keep independent compact deployment continuous when the wing field closes.
      const nextData={...data,enabled:next,gemMotion:nextGemMotion},nextBits=bitTarget(nextData,cfg);
      if(!next)Object.assign(changes,this.implicitWingRetractionLightChanges(doc,data,cfg,now));
      if(nextBits!==bitTarget(data,cfg))changes[`${PATH}.bitTransition`]={id:foundry.utils.randomID(16),started:now,
        duration:cfg.bitTransitions&&cfg.transitions&&!cfg.reduced?(duration??cfg.bitTransitionDuration):0,from:before.bitDeployment,to:nextBits};
      if(summonStabilizers&&doc.getFlag(ID,'bitAllocations'))
        await this.bits.deployForTakeoff(doc,changes,{data:nextData,snapshot:before,cfg,now,duration:duration??cfg.bitTransitionDuration});
      else {
        // Retain legacy implicit deployment: closing those wings can still
        // retract their instruments rather than inventing independent homes.
        if(summonStabilizers&&nextBits>bitTarget(data,cfg))Object.assign(changes,this.ordinaryBitSummonLightChanges(doc,now));
        await doc.update(changes);
      }
      return this.applied(doc);
    }))).then(states=>selected?states:states[0]);
  }

  setBitsEnabled(target,enabled,input={}){
    const doc=requireDocument(target),duration=this.poseOptions(input);
    if(enabled!==undefined&&typeof enabled!=='boolean')throw new Error('Bits enabled must be true or false.');
    return this.bits.commandQueue(doc,'deployment change',async()=>{
      this.assertOwned(doc);const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
      const allocation=this.bits.allocation(doc),active=Object.values(allocation.bits).some(b=>b.location==='home'),next=enabled??!active;
      if(!globalThis.canvas?.ready||doc.parent?.id!==canvas.scene?.id)
        return this.commit(doc,{bitsDeployed:next,gemMotion:{enabled:next,...(next?{count:allocation.preferredCount}:{}),...(next&&data.gemMotion.style==='hidden'?{style:null}:{})}},{bitDuration:duration});
      await this.bits.deploymentNow(doc,{enabled:next,count:allocation.preferredCount,duration:duration??650,manualLightIntent:true});
      return this.commit(doc,{bitsDeployed:next,gemMotion:{enabled:next,...(next&&data.gemMotion.style==='hidden'?{style:null}:{})}},{bitDuration:duration,skipAllocationSync:true});
    });
  }

  setBitPosition(target,station,position){
    if(!Object.hasOwn(BIT_STATIONS,station))throw new Error('Choose leftUpper, rightUpper, leftLower or rightLower.');
    if(!position||typeof position!=='object'||Array.isArray(position)||!Object.keys(position).length||Object.keys(position).some(k=>!['x','y'].includes(k)))throw new Error('Pass x and/or y for the bit position.');
    const fields=Object.fromEntries(Object.entries(position).map(([k,v])=>[`${station}${k.toUpperCase()}`,v]));
    return this.setState(target,{gemMotion:{placement:'free',...fields}});
  }
  resetBitPositions(target,station){
    if(station!==undefined&&!Object.hasOwn(BIT_STATIONS,station))throw new Error('Unknown bit station.');
    const fields=Object.fromEntries((station===undefined?Object.keys(BIT_STATIONS):[station]).flatMap(k=>[[`${k}X`,null],[`${k}Y`,null]]));
    return this.setState(target,{gemMotion:fields});
  }

  captureLook(target){
    const doc=requireDocument(target),data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime()),cfg=configuration();
    const base={...(data.inheritDefaults?cfg.defaults:data.options)};
    for(const [key,value] of Object.entries(data.optionOverrides))base[key]=value??cfg.defaults[key];
    const fields=Object.fromEntries(LOOK_FIELDS.filter(k=>k!=='options').map(k=>[k,structuredClone(k==='lanternGroundStyle'?data.lantern.groundStyle??'projector':k==='v7'?captureV7Look(data.v7):data[k])]));
    return normalizeLook({version:1,options:options(base),...fields});
  }
  applyLook(target,input){
    const doc=requireDocument(target),preset=typeof input==='string'?LOOK_PRESETS.find(p=>p.id===input)?.look:input;
    if(!preset)throw new Error('Unknown built-in look.');
    const look=normalizeLook(preset);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);const before=this.captureLook(doc),saved=normalizeFlag(doc.getFlag(ID,'flight'),serverTime()),{version,lanternGroundStyle,...patch}=look;
      if(Object.hasOwn(look,'lanternGroundStyle')&&lanternGroundStyle!==saved.lantern.groundStyle)patch.lantern={groundStyle:lanternGroundStyle};
      if(Object.hasOwn(look,'v7'))patch.v7=v7LookPatch(look.v7);
      const state=await this.commit(doc,patch),undo=foundry.utils.randomID(16);
      this.lookUndos.set(doc.uuid,{id:undo,before,saved,v7Applied:Object.hasOwn(look,'v7'),v7Only:Object.keys(look).every(key=>key==='version'||key==='v7'),expected:lookFingerprint(this.captureLook(doc))});
      if(this.lookUndos.size>32)this.lookUndos.delete(this.lookUndos.keys().next().value);
      return {state,undo};
    });
  }
  undoLook(target,undo){
    const doc=requireDocument(target);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);const record=this.lookUndos.get(doc.uuid);
      if(!record||record.id!==undo)throw new Error('This look can no longer be undone.');
      if(lookFingerprint(this.captureLook(doc))!==record.expected)throw new Error('The look changed after it was applied; undo would overwrite newer choices.');
      // A V7-only material look never needs operational restoration. Its Undo
      // never enters legacy deployment/allocation restoration or medical work.
      if(record.v7Only){
        const state=await this.commit(doc,record.v7Applied?{v7:v7LookPatch(record.before.v7)}:{});
        this.lookUndos.delete(doc.uuid);return state;
      }
      const currentStyle=normalizeFlag(doc.getFlag(ID,'flight'),serverTime()).lantern.groundStyle,
        savedStyle=record.saved.lantern.groundStyle??'projector';
      const state=await this.commit(doc,{pose:record.before.pose,poseMotion:record.saved.poseMotion,...(record.v7Applied?{v7:v7LookPatch(record.before.v7)}:{}),...(currentStyle!==savedStyle?{lantern:{groundStyle:savedStyle}}:{})},{lookRestore:record.saved});
      this.lookUndos.delete(doc.uuid);return state;
    });
  }
  /** v10: personal looks live on your user account so they follow you to any
   * device. Looks saved only in this browser by 9.x are read as a fallback and
   * copied to the account the next time you save or delete one. */
  savedLookSource(){
    const account=game.user?.getFlag?.(ID,'looks');
    if(Array.isArray(account))return Object.fromEntries(account.filter(e=>e&&typeof e.id==='string').map(({id,...v})=>[id,v]));
    try{return game.settings.get(ID,'lookPresets');}catch{return null;}
  }
  async storeLooks(entries){
    await game.user.setFlag(ID,'looks',entries.map(({id,name,look})=>({id,name,look})));
    try{await game.settings.set(ID,'lookPresets',Object.fromEntries(entries.map(({id,...v})=>[id,v])));}catch{}
  }
  getSavedLooks(){
    const raw=this.savedLookSource();
    if(!raw||typeof raw!=='object'||Array.isArray(raw))return [];
    return Object.entries(raw).slice(0,12).flatMap(([id,p])=>{
      try {if(!/^[\w-]{1,64}$/.test(id)||typeof p.name!=='string'||!p.name.trim()||p.name.length>48)return [];return [{id,name:p.name,look:normalizeLook(p.look)}];}catch{return [];}
    });
  }
  saveLook(name,input){
    if(typeof name!=='string'||!name.trim()||name.trim().length>48)throw new Error('Use a look name of 1–48 characters.');
    const look=normalizeLook(input),label=name.trim();
    const operation=this.lookQueue.catch(()=>{}).then(async()=>{
      const saved=this.getSavedLooks();if(saved.length>=12)throw new Error('Twelve personal looks are saved. Remove one before adding another.');
      const entry={id:`look-${foundry.utils.randomID(12)}`,name:label,look};
      await this.storeLooks([...saved,entry]);return entry;
    });this.lookQueue=operation.catch(()=>{});return operation;
  }
  deleteLook(id){
    const operation=this.lookQueue.catch(()=>{}).then(async()=>{
      const saved=this.getSavedLooks();if(!saved.some(p=>p.id===id))throw new Error('That personal look no longer exists.');
      await this.storeLooks(saved.filter(p=>p.id!==id));return true;
    });this.lookQueue=operation.catch(()=>{});return operation;
  }

  getAudio(target) {
    const doc=requireDocument(target),requested=normalizeAudio(doc.getFlag(ID,'audio'));
    return {...resolveAudio(requested,configuration()),requested,
      status:this.manager.audio?.status(doc.object)??{playing:false,error:null}};
  }

  setAudio(target,input) {
    const doc=requireDocument(target),patch=validateAudioPatch(input);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      const before=normalizeAudio(doc.getFlag(ID,'audio')),next=mergeAudio(before,patch);
      // Choosing Only me claims the private audience. Ordinary volume/radius
      // edits by another owner or GM must retain the existing listener.
      if(next.audience==='local'&&(patch.audience==='local'||!next.localUserId||Object.hasOwn(patch,'localUserId')))
        next.localUserId=game.user.id;
      await doc.update(audioFlagChanges(before,next));
      if(doc.parent.id===canvas.scene?.id)this.manager.audio?.sync(doc.object);
      return this.getAudio(doc);
    });
  }

  previewAudio(target,slot,options={}) {
    const doc=requireDocument(target);this.assertOwned(doc);
    if(!Object.hasOwn(AUDIO_SLOTS,slot))throw new Error('Unknown wing sound.');
    const choice=validateAudioPreview(options);
    if(doc.parent!==canvas.scene)throw new Error('Preview a token in the current scene.');
    if(!this.manager.audio)throw new Error('Wing audio is not initialized.');
    return this.manager.audio.preview(doc.object,slot,choice);
  }

  toggleLight(target) {
    const selected=target===undefined;
    if(selected&&!canvas.ready)return Promise.resolve(ui.notifications.warn('Open a scene first.'));
    const docs=selected?[...(canvas.tokens?.controlled??[])].filter(t=>current(t)&&!t.isPreview&&t.document.isOwner).map(t=>t.document):[requireDocument(target)];
    if(!docs.length)return Promise.resolve(ui.notifications.warn('Select a token you own first.'));
    return Promise.all(docs.map(doc=>this.bits.commandQueue(doc,'light toggle',async()=>{
      this.assertOwned(doc);
      if(selected&&(doc.parent!==canvas.scene||!current(doc.object)))throw new Error('The selected scene changed before the light command ran.');
      const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
      const on=!(data.lightEnabled??configuration().lightDefault);
      await this.commit(doc,{lightEnabled:on});return on;
    }))).then(results=>({enabled:results.filter(Boolean).length,disabled:results.filter(v=>!v).length}));
  }

  /** Shared HUD light control. Shift chooses the lantern when starting and
   * keeps deployed instruments when stopping, like the existing retract control. */
  toggleLightMode(target,input={}) {
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['lantern','keepBits'].includes(key)))
      throw new Error('Light mode options accept only lantern and keepBits.');
    for(const key of ['lantern','keepBits'])if(input[key]!==undefined&&typeof input[key]!=='boolean')
      throw new Error(`${key} must be true or false.`);
    const lantern=input.lantern===true,keepBits=input.keepBits===true,selected=target===undefined;
    if(selected&&!canvas.ready)return Promise.resolve(ui.notifications.warn('Open a scene first.'));
    const docs=selected?[...(canvas.tokens?.controlled??[])].filter(token=>current(token)&&!token.isPreview&&token.document.isOwner).map(token=>token.document):[requireDocument(target)];
    if(!docs.length)return Promise.resolve(ui.notifications.warn('Select a token you own first.'));
    return Promise.all(docs.map(doc=>this.bits.commandQueue(doc,'light toggle',async()=>{
      this.assertOwned(doc);
      if(selected&&(doc.parent!==canvas.scene||!current(doc.object)))throw new Error('The selected scene changed before the light command ran.');
      const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime()),on=!!((data.lightEnabled??configuration().lightDefault)||data.lantern.enabled);
      if(on){
        // Capture the displayed lantern formation before a recall changes its
        // saved destinations. Keeping bits leaves all allocation/action flags intact.
        await this.commit(doc,{lightEnabled:false,lightWithBits:false,lantern:{enabled:false}});
        if(!keepBits){
          const local=this.lightBitDeployment(doc),home=local.eligible.filter(bit=>bit.location==='home').map(bit=>bit.id);
          if(local.allowed&&home.length){
            await this.bits.deploymentNow(doc,{enabled:false,bits:home,count:local.state.preferredCount});
            const remaining=this.bits.getState(doc).allocations.some(bit=>bit.location==='home');
            await this.commit(doc,{bitsDeployed:remaining},{skipAllocationSync:true});
          }
        }
        return false;
      }
      const local=this.lightBitDeployment(doc),home=local.eligible.filter(bit=>bit.location==='home').length,
        free=local.eligible.filter(bit=>bit.location==='retracted').map(bit=>bit.id).slice(0,Math.max(0,local.state.preferredCount-home));
      const deploy=local.allowed&&free.length>0;
      if(deploy)await this.bits.deploymentNow(doc,{enabled:true,bits:free,count:local.state.preferredCount});
      await this.commit(doc,{lightEnabled:!lantern,lightWithBits:!lantern,lantern:{enabled:lantern},
        ...(local.allowed&&(deploy||home>0)?{bitsDeployed:true,gemMotion:{enabled:true}}:{})},{skipAllocationSync:true});
      return true;
    }))).then(results=>({enabled:results.filter(Boolean).length,disabled:results.filter(value=>!value).length}));
  }

  lightBitDeployment(doc) {
    const state=this.bits.getState(doc),activeIds=new Set([...state.active,...state.queued].map(event=>event.id)),
      events=this.bits.records(doc,false).filter(event=>activeIds.has(event.id)),response=this.bits.state(doc,true).conditionResponse;
    const otherController=events.some(event=>event.owner!==game.user.id&&game.users?.get(event.owner)?.active),
      reserved=new Set(events.filter(event=>event.status==='queued'||!event.localTransfer&&!(event.kind==='escort'&&event.target===doc.id)).flatMap(event=>event.bits)),
      transferring=new Set(events.filter(event=>event.localTransfer&&event.target===doc.id).flatMap(event=>event.bits));
    const eligible=state.allocations.filter(bit=>['home','retracted'].includes(bit.location)&&!reserved.has(bit.id)&&
      (state.available.includes(bit.id)||transferring.has(bit.id)));
    return {state,eligible,allowed:!(response?.bits&&['falling','fallen'].includes(response.collapse?.phase))&&
      !otherController&&canvas.ready&&doc.parent===canvas.scene&&current(doc.object)};
  }

  setLantern(target,input) {
    const doc=requireDocument(target),patch=lanternPatch(input);
    if(Object.hasOwn(patch,'angle'))patch.lock=null;
    return this.bits.commandQueue(doc,'lantern adjustment',()=>this.commitLantern(doc,patch));
  }

  lockLantern(target,subject){
    const doc=requireDocument(target);this.assertOwned(doc);lanternLockForSubject(doc,subject);
    return this.bits.commandQueue(doc,'lantern subject',()=>{
      this.assertOwned(doc);const lock=lanternLockForSubject(doc,subject);
      this.manager.lantern?.clearAimOverride?.(doc.object);
      const angle=resolveLanternLock(doc,lock,{fallbackAngle:normalizeFlag(doc.getFlag(ID,'flight'),serverTime()).lantern.angle}).angle;
      return this.commit(doc,{lantern:{lock,angle}});
    });
  }
  unlockLantern(target){
    const doc=requireDocument(target);
    return this.bits.commandQueue(doc,'lantern subject',()=>{
      this.assertOwned(doc);const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
      const angle=this.manager.lantern?.safeHeading?.(doc.object,data.lantern.angle)??data.lantern.angle;
      return this.commit(doc,{lantern:{lock:null,angle}});
    });
  }
  applyLightPreset(target,id){
    const doc=requireDocument(target);
    return this.bits.commandQueue(doc,'light preset',()=>{
      this.assertOwned(doc);const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
      return this.commit(doc,lightPresetPatch(data.lantern,id));
    });
  }
  saveLightPreset(target,id){
    const doc=requireDocument(target);
    return this.bits.commandQueue(doc,'save light preset',()=>{
      this.assertOwned(doc);const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime()),cfg=configuration();
      const circular=(data.lightEnabled??cfg.lightDefault)&&!data.lantern.enabled,current=circular?{width:data.lantern.width,bright:data.lightBright??cfg.lightBright,dim:data.lightDim??cfg.lightDim,intensity:data.lightIntensity??1}:undefined;
      return this.commit(doc,{lantern:saveLightPresetPatch(data.lantern,id,current)});
    });
  }
  resetLightPreset(target,id){
    const doc=requireDocument(target);
    return this.bits.commandQueue(doc,'reset light preset',()=>{
      this.assertOwned(doc);const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
      return this.commit(doc,{lantern:resetLightPresetPatch(data.lantern,id)});
    });
  }

  async commitLantern(doc,patch) {
    this.assertOwned(doc);
    const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
    let deploy=false;
    const response=this.bits.state(doc,true).conditionResponse;
    const unpowered=response?.bits&&['falling','fallen'].includes(response.collapse?.phase);
    if(patch.enabled===true&&!data.lantern.enabled&&!unpowered&&canvas.ready&&doc.parent===canvas.scene&&current(doc.object)){
      const bits=this.bits.getState(doc),home=bits.allocations.filter(bit=>bit.location==='home'&&bits.available.includes(bit.id)).length;
      const free=bits.allocations.filter(bit=>bit.location==='retracted'&&bits.available.includes(bit.id)).map(bit=>bit.id).slice(0,Math.max(0,bits.preferredCount-home));
      const activeIds=new Set([...bits.active,...bits.queued].map(event=>event.id));
      const otherController=this.bits.records(doc,false).some(event=>activeIds.has(event.id)&&event.owner!==game.user.id&&game.users?.get(event.owner)?.active);
      if(free.length&&!otherController){
        await this.bits.deploymentNow(doc,{enabled:true,bits:free,count:bits.preferredCount});deploy=true;
      }
    }
    return this.commit(doc,{lantern:patch,...(deploy?{bitsDeployed:true,gemMotion:{enabled:true}}:{})},{skipAllocationSync:true});
  }

  toggleLantern(target) {
    const doc=requireDocument(target);
    return this.bits.commandQueue(doc,'lantern toggle',()=>{
      this.assertOwned(doc);
      const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime());
      return this.commitLantern(doc,{enabled:!data.lantern.enabled});
    });
  }

  aimLantern(target,direction) {
    const doc=requireDocument(target);this.assertOwned(doc);
    let angle=direction;
    if(direction&&typeof direction==='object'&&!Array.isArray(direction)){
      if(Object.keys(direction).some(key=>!['x','y'].includes(key))||!Number.isFinite(direction.x)||!Number.isFinite(direction.y))throw new Error('Lantern aim needs a finite canvas point {x, y}, or an angle in degrees.');
      if(!canvas.ready||doc.parent!==canvas.scene||!current(doc.object))throw new Error('Aim a token in the current scene.');
      const center=doc.object.center;
      if(direction.x===center.x&&direction.y===center.y)return Promise.resolve(this.getState(doc));
      angle=Math.atan2(direction.y-center.y,direction.x-center.x)*180/Math.PI;
      this.manager.lantern?.aimAt?.(doc.object,direction);
    }
    return this.setLantern(doc,{angle});
  }

  startLanternAim(target) {
    const doc=requireDocument(target);this.assertOwned(doc);
    if(!canvas.ready||doc.parent!==canvas.scene||!current(doc.object))throw new Error('Aim a token in the current scene.');
    if(!normalizeFlag(doc.getFlag(ID,'flight'),serverTime()).lantern.enabled)throw new Error('Turn the bit lantern on before aiming.');
    if(!this.manager.lantern?.beginAim)throw new Error('Lantern aiming is not initialized. Reload the scene.');
    const result=this.manager.lantern.beginAim(doc.object);
    if(normalizeFlag(doc.getFlag(ID,'flight'),serverTime()).lantern.lock)void this.bits.commandQueue(doc,'lantern aiming',()=>this.commit(doc,{lantern:{lock:null}})).catch(error=>this.manager.report?.(error));
    return result;
  }

  /** Build shared lifecycle metadata before an allocation command changes the
   * displayed home constellation. Callers can include the result in one write. */
  prepareLanternPatch(doc,lantern,{now=serverTime(),cfg=configuration(),raw=doc.getFlag(ID,'flight'),data=normalizeFlag(raw,now),before}={}) {
    if(typeof lantern?.enabled!=='boolean'||lantern.enabled===data.lantern.enabled)return lantern;
    before??=resolveState(data,cfg,now,this.context(doc));
    const old=normalizeLantern({...data.lantern,started:data.lantern.started??(Number.isFinite(raw?.started)?raw.started:0)}),
      envelope=lanternEnvelope(old,now),metadata={changed:now,from:envelope.weight,fromBeam:envelope.beamWeight,fromReach:envelope.reach,
        fromVelocity:envelope.velocity?.weight??0,fromBeamVelocity:envelope.velocity?.beamWeight??0,fromReachVelocity:envelope.velocity?.reach??0,transitionCapture:[]};
    const instruments=this.bits.getState(doc),home=instruments.allocations.filter(bit=>bit.location==='home'&&
      (instruments.available.includes(bit.id)||bit.actionKind==='escort'&&bit.actionTarget===doc.id)).map(bit=>bit.id);
    let captured;
    if(canvas.ready&&doc.object&&current(doc.object)){
      const snapshot=this.manager.sampleState?.(doc.object,now)??before;
      captured=captureLanternFormation(doc.object,snapshot,this.manager,now,home,{...cfg,actual:true});
      metadata.transitionCapture=captured.formationCapture;
      if(lantern.enabled&&envelope.weight<=.0001)captured=captureLanternFormation(doc.object,snapshot,this.manager,now,home,cfg);
    }
    if(lantern.enabled){
      if(envelope.weight>.0001){metadata.started=old.started;metadata.startAngle=old.startAngle??old.angle;}
      else{
        metadata.started=now;metadata.startAngle=lantern.angle??data.lantern.angle;
        metadata.formationCapture=[];metadata.formationOrder=[];
        if(captured)Object.assign(metadata,captured);
      }
      metadata.leader=old.leader??home[0]??'leftUpper';
    }
    return {...lantern,...metadata};
  }

  /** Explicit bit retraction releases both saved light requests. Automatic
   * borrowing and returns do not call this helper and keep their light intent. */
  manualBitLightChanges(doc,now=serverTime()) {
    this.assertOwned(doc);
    const raw=doc.getFlag(ID,'flight'),lantern=this.prepareLanternPatch(doc,{enabled:false},{now,raw});
    return {[`${PATH}.schemaVersion`]:SCHEMA_VERSION,...(raw==null?{[`${PATH}.inheritDefaults`]:true}:{}),[`${PATH}.lightEnabled`]:false,[`${PATH}.lightWithBits`]:false,
      ...Object.fromEntries(Object.entries(lantern).map(([key,value])=>[`${PATH}.lantern.${key}`,value]))};
  }

  /** Closing wings stores legacy implicit instruments too. Independent home
   * allocations and bits-only deployment remain out and keep their light choice. */
  implicitWingRetractionLightChanges(doc,data,cfg,now) {
    return !doc.getFlag(ID,'bitAllocations')&&bitTarget(data,cfg)>0&&bitTarget({...data,enabled:false},cfg)===0
      ?this.manualBitLightChanges(doc,now):{};
  }

  /** A normal summon never inherits an unfinished light shutdown. Let the
   * withdrawal fade until that command, then finish its optical/body envelope
   * before returning instruments can reacquire the extinguished projector. */
  ordinaryBitSummonLightChanges(doc,now=serverTime()) {
    const data=normalizeFlag(doc.getFlag(ID,'flight'),now);
    if(data.lantern.enabled||(data.lightEnabled??configuration().lightDefault))return {};
    const envelope=lanternEnvelope(data.lantern,now);
    if(!envelope.weight&&!envelope.beamWeight)return {};
    return {[`${PATH}.lantern.changed`]:now,[`${PATH}.lantern.from`]:0,[`${PATH}.lantern.fromBeam`]:0,
      [`${PATH}.lantern.fromReach`]:0,[`${PATH}.lantern.fromVelocity`]:0,[`${PATH}.lantern.fromBeamVelocity`]:0,
      [`${PATH}.lantern.fromReachVelocity`]:0,[`${PATH}.lantern.transitionCapture`]:[]};
  }

  async commit(doc, patch, transitionOptions={}) {
    this.assertOwned(doc);
    const lightSync=Object.keys(patch).some(key=>LIGHT_FIELDS.has(key))?{previous:this.manager.syncAcknowledgment?.(doc)}:null;
    const now=serverTime(), cfg=configuration(), raw=doc.getFlag(ID,'flight');
    if(unchangedLightPatch(raw,patch))return this.getState(doc);
    const data=normalizeFlag(raw,now), before=resolveState(data,cfg,now,this.context(doc));
    if(patch.mode&&patch.mode!=='landing'&&patch.mode!=='grounded'&&conditionFlightBlockers(before.conditionResponse).length)
      throw new Error('Flight is grounded by Prone, Paralyzed, or Stunned 3. Remove the condition or turn off status reactions before taking off.');
    if(patch.v7)patch={...patch,v7:v7PreferencesPatch(patch.v7,{before:data.v7,cfg,now,seed:foundry.utils.randomID(16),duration:cfg.reduced||cfg.transitions===false?0:1800})};
    // Explicitly hiding or storing all home instruments releases both lights.
    // Capture the optical lifecycle before the visibility or destinations change.
    const motion=transitionOptions.lookRestore?.gemMotion??patch.gemMotion,
      retractsBits=patch.bitsDeployed===false||(motion?.enabled===false||motion?.style==='hidden')&&
        (!transitionOptions.lookRestore||motion.enabled!==data.gemMotion.enabled||motion.style!==data.gemMotion.style);
    if(retractsBits)patch={...patch,lightEnabled:false,lightWithBits:false,lantern:{...patch.lantern,enabled:false}};
    if(patch.lantern)patch={...patch,lantern:this.prepareLanternPatch(doc,patch.lantern,{now,cfg,raw,data,before})};
    // Enabling an older Hidden choice must actually show the bits. An explicit
    // style in a saved look remains authoritative, including Hidden on restore.
    if(patch.gemMotion?.enabled===true&&data.gemMotion.style==='hidden'&&!Object.hasOwn(patch.gemMotion,'style'))
      patch={...patch,gemMotion:{...patch.gemMotion,style:null}};
    const local=this.manager.states.get(doc.object);
    const fromBlend=!data.transition && local && before.rendering.wingsActive ? local.blend : before.rendering.blend;
    const fromFlight=!data.transition && local ? local.flightFactor ?? (data.enabled?1:0)
      : data.enabled||data.transition?before.rendering.flightFactor:0;
    const changes={[`${PATH}.schemaVersion`]:SCHEMA_VERSION};
    if(!Object.hasOwn(patch.v7??{},'wingGesture')){
      const lightChanged=Object.hasOwn(patch,'lightEnabled')&&(patch.lightEnabled??cfg.lightDefault)!==(data.lightEnabled??cfg.lightDefault)||
        Object.hasOwn(patch.lantern??{},'enabled')&&patch.lantern.enabled!==data.lantern.enabled;
      const bridge=patch.mode&&patch.mode!==data.mode?(patch.mode==='landing'||patch.mode==='grounded'?'heldBreath':'trailingBloom'):
        patch.pose&&patch.pose!==data.pose?'quietFlourish':lightChanged?'softShelter':null;
      if(bridge)Object.assign(changes,this.v7WingBridgeChanges(data,before,now,bridge,{opening:!!patch.mode&&patch.mode!=='grounded'&&patch.mode!=='landing'}));
    }
    if (raw == null) changes[`${PATH}.inheritDefaults`]=true;
    for (const [key,value] of Object.entries(patch)) {
      if (key==='options') {
        for (const [name,v] of Object.entries(value)) {
          changes[`${PATH}.optionOverrides.${name}`]=v;
          changes[`${PATH}.options.${name}`]=v===null?cfg.defaults[name]:v;
        }
      } else if(key==='lantern') {
        for(const [field,v] of Object.entries(value))changes[`${PATH}.lantern.${field}`]=v;
      } else if(key==='v7') {
        for(const [field,v] of Object.entries(value))changes[`${PATH}.v7.${field}`]=v;
      } else if(key==='effectStyles'||key==='reactionStyles'||key==='poseMotion'||key==='gemMotion') {
        for(const [condition,style] of Object.entries(value))changes[`${PATH}.${key}.${condition}`]=key==='gemMotion'&&condition==='expressionModes'&&style!==null?{...data.gemMotion.expressionModes,...style}:style;
      } else if(key==='structurePoses'){
        const merged=mergeStructurePoses(data.structurePoses,value);
        for(const id of Object.keys(value))changes[`${PATH}.structurePoses.${id}`]=merged[id];
      } else if(key==='effectTuning'||key==='reactionTuning') {
        for(const [id,tuning] of Object.entries(value)){
          // Write a complete merged entry, so resetting an entry cannot erase a sibling.
          changes[`${PATH}.${key}.${id}`]=tuning===null?null:{...(data[key][id]??{}),...tuning};
        }
      } else if(key==='observerQuality'){
        const profile={...mergeQuality(data.observerQuality,value),ownerId:game.user.id};
        Object.assign(changes,audioFlagChanges(data.observerQuality,profile,`${PATH}.observerQuality`));
      } else if (key!=='mode'&&key!=='condition') changes[`${PATH}.${key}`]=value;
    }
    // Internal scoped recovery restores inherited intent without copying any
    // saved lifecycle timestamps. Lantern metadata above is freshly captured.
    for(const path of transitionOptions.restoreLightPresence??[]){
      const parts=path.split('.'),key=parts.pop(),parent=parts.length?`${PATH}.${parts.join('.')}`:PATH;
      if(parts.length?parts[0]!=='lantern'||!Object.hasOwn(patch.lantern??{},key):!LIGHT_FIELDS.has(key)||key==='lantern')throw new Error('Invalid light recovery field.');
      delete changes[`${parent}.${key}`];forceDelete(changes,parent,key);
    }
    const summonsBits=patch.bitsDeployed===true||motion?.enabled===true||
      data.gemMotion.style==='hidden'&&['classic','choreographed'].includes(motion?.style);
    if(summonsBits&&!retractsBits&&patch.lightEnabled!==true&&patch.lantern?.enabled!==true)
      Object.assign(changes,this.ordinaryBitSummonLightChanges(doc,now));
    if(transitionOptions.lookRestore){
      // Restore sparse overrides as well as appearance. Foundry recursively merges
      // objects, so explicit deletions keep Undo connected to world defaults.
      const restored=transitionOptions.lookRestore;
      // V7 cosmetic targets were applied above through fresh, continuous
      // transitions. A saved look must never replay old event clocks or undo a
      // wing gesture performed after the look was selected.
      for(const key of [...LOOK_FIELDS.filter(key=>key!=='lanternGroundStyle'&&key!=='v7'),'optionOverrides','inheritDefaults']){
        const value=restored[key];
        if(value&&typeof value==='object'&&!Array.isArray(value)){
          for(const path of Object.keys(changes))if(path.startsWith(`${PATH}.${key}.`))delete changes[path];
          Object.assign(changes,audioFlagChanges(data[key],value,`${PATH}.${key}`));
        } else changes[`${PATH}.${key}`]=value;
      }
    }
    if(patch.gemMotion||patch.bitsDeployed!==undefined||transitionOptions.lookRestore){
      const nextGemMotion=transitionOptions.lookRestore?.gemMotion??{...data.gemMotion,...patch.gemMotion};
      const nextData={...data,...(patch.bitsDeployed!==undefined?{bitsDeployed:patch.bitsDeployed}:{}),gemMotion:nextGemMotion};
      const next=bitTarget(nextData,cfg);
      const nextCount=bitCountTarget(nextData);
      if(nextCount!==bitCountTarget(data))changes[`${PATH}.bitCountTransition`]={id:foundry.utils.randomID(16),started:now,
        duration:before.bitDeployment>0&&cfg.bitTransitions&&cfg.transitions&&!cfg.reduced?(transitionOptions.bitDuration??cfg.bitTransitionDuration):0,
        from:before.bitCount.values,fromFormation:before.bitCount.formationWeights,to:nextCount};
      if(next!==bitTarget(data,cfg)){
        changes[`${PATH}.bitTransition`]={id:foundry.utils.randomID(16),started:now,
          duration:cfg.bitTransitions&&cfg.transitions&&!cfg.reduced?(transitionOptions.bitDuration??cfg.bitTransitionDuration):0,
          from:before.bitDeployment,to:next};
      }
    }
    if(patch.condition) {
      changes[`${PATH}.condition`]=patch.condition==='auto'?'normal':patch.condition;
      changes[`${PATH}.conditionSource`]=patch.condition==='auto'?'auto':'manual';
      changes[`${PATH}.conditionTransition`]={id:foundry.utils.randomID(16),started:now,duration:transitionOptions.conditionDuration??cfg.conditionDuration,
        from:this.sampledCondition(data,doc,cfg,now).authoredProfile,hpSeparated:true};
      changes[`${PATH}.temporaryCondition`]=null;
    }
    const nextStructure=transitionOptions.lookRestore?.structure??patch.structure;
    if(nextStructure&&nextStructure!==data.structure){
      changes[`${PATH}.structureTransition`]=makeStructureTransition(data,nextStructure,now,{id:foundry.utils.randomID(16),duration:transitionOptions.structureDuration??1300,enabled:cfg.transitions&&!cfg.reduced});
    }
    const nextStructurePoses=transitionOptions.lookRestore?.structurePoses??(patch.structurePoses?mergeStructurePoses(data.structurePoses,patch.structurePoses):null);
    if(nextStructurePoses&&JSON.stringify(nextStructurePoses)!==JSON.stringify(data.structurePoses)){
      const controls=resolvePoseMotion({...data,poseMotion:{...data.poseMotion,...patch.poseMotion}},cfg);
      changes[`${PATH}.structurePoseTransition`]=makeStructurePoseTransition(data,now,{id:foundry.utils.randomID(16),duration:transitionOptions.structurePoseDuration??Math.max(650,controls.duration),enabled:cfg.transitions&&controls.enabled&&!cfg.reduced});
    }
    if(transitionOptions.cue)changes[`${PATH}.cues.manual`]=transitionOptions.cue;
    if (patch.pose) {
      const controls=resolvePoseMotion({...data,poseMotion:{...data.poseMotion,...patch.poseMotion}},cfg),sample=this.sampledPose(data,doc,now);
      changes[`${PATH}.poseTransition`]={id:foundry.utils.randomID(16),started:now,
        duration:transitionOptions.poseDuration??controls.duration,
        from:sample.weights,motion:poseTimingMotion(sample,controls)};
      changes[`${PATH}.temporaryPose`]=null;
    }
    if (patch.mode) {
      const transient=patch.mode==='takeoff'||patch.mode==='landing';
      const landing=patch.mode==='landing';
      const mode=transient ? landing?'grounded':transitionOptions.mode??'hover' : patch.mode;
      const enabled=landing ? transitionOptions.keepWings===true : true;
      changes[`${PATH}.mode`]=mode;
      changes[`${PATH}.airborne`]=mode!=='grounded';
      if(mode!==data.mode)changes[`${PATH}.modeTransition`]=modeTransitionFrom(before.flightProfile,now,cfg.modeTransitionDuration,foundry.utils.randomID(16));
      changes[`${PATH}.enabled`]=enabled;
      if (enabled && !data.enabled) {changes[`${PATH}.started`]=now;changes[`${PATH}.activation`]=foundry.utils.randomID(16);}
      const wingSequence=transient&&(landing?(transitionOptions.foldWings??!transitionOptions.keepWings):transitionOptions.formation!==false);
      const fromWings=before.formation.explicit?Object.fromEntries(['growth','fold','presence'].map(k=>[k,before.formation[k]])):
        {growth:before.rendering.wingsActive?1:0,fold:0,presence:fromBlend};
      changes[`${PATH}.transition`]=transient && (enabled || before.rendering.active) ? {
        id:foundry.utils.randomID(16),kind:patch.mode,started:now,
        duration:cfg.transitions?(transitionOptions.duration??cfg.transitionDuration):0,
        // (Flight feel: a landing lasts her descent and plays its wing fold in the last foldMs.)
        ...(landing&&cfg.transitions?landingTiming(doc,before,transitionOptions.duration??cfg.transitionDuration):{}),
        // (12.0.0-beta.3) a landing style: the landing is unchanged, her wings stay out through it and are recalled after
        ...(landing&&wingSequence&&!enabled&&cfg.transitions?this.landingRecall(doc,before,cfg,transitionOptions.duration??cfg.transitionDuration):{}),
        fromBlend,toBlend:enabled?1:0,
        fromFlight,
        toFlight:landing?0:1,
        ...(wingSequence?{wings:{from:fromWings,to:{growth:enabled?1:0,fold:landing?1:0,presence:enabled?1:0}}}:{wings:null})
      } : null;
      // Flight feel (beta.23): "Takeoff sets her elevation" (beta.32 option, off by default). Takeoff lifts the token's elevation
      // by her chosen altitude above the ground she leaves; landing returns
      // her to that ground. Elevation is ordinary token data, so rules,
      // tooltips and every screen see the same height.
      // Takeoff writes only when the commanding player uses Flight feel and the
      // token has that option on; any grounding restores a recorded ground.
      const feel=flightFeelEnabled()?readFlightFeel(doc):null;
      // With "height follows flight mode", each mode flies at its own share of
      // her chosen height, and changing mode in the air climbs or descends.
      // (beta.32: only with "Takeoff sets her elevation" on; by default the player sets it.)
      if(feel?.takeoffElevation&&patch.mode==='takeoff'&&!data.airborne&&flyingHeight(feel,mode)>0){
        const recorded=Number(doc.getFlag(ID,GROUND_FLAG)),ground=Number.isFinite(recorded)?recorded:Number(doc.elevation)||0;
        changes.elevation=ground+flyingHeight(feel,mode);changes[`flags.${ID}.${GROUND_FLAG}`]=ground;
      }else if(mode==='grounded')Object.assign(changes,groundElevationChanges(doc));
      else if(feel?.takeoffElevation&&feel.heightByMode&&!transient&&data.airborne&&mode!==data.mode){
        const ground=Number(doc.getFlag(ID,GROUND_FLAG));
        if(Number.isFinite(ground)&&flyingHeight(feel,mode)>0)changes.elevation=ground+flyingHeight(feel,mode);
      }
    }
    // Give a legacy implicit constellation explicit destinations before its
    // first count edit. The ordinary allocation path can then capture the old
    // displayed layout and animate redistribution just like subsequent edits.
    if((retractsBits||patch.gemMotion&&Object.hasOwn(patch.gemMotion,'count'))&&!doc.getFlag(ID,'bitAllocations')&&
      (retractsBits||globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id)&&
      !(before.conditionResponse.bits&&['falling','fallen'].includes(before.conditionResponse.collapse.phase)))
      changes[`flags.${ID}.bitAllocations`]=this.bits.allocation(doc,before);
    const placementChanged=patch.gemMotion&&Object.entries(patch.gemMotion).some(([key,value])=>
      (key==='placement'||Object.hasOwn(BIT_POSITION_FIELDS,key))&&value!==data.gemMotion[key]);
    if(placementChanged&&!patch.mode&&patch.bitsDeployed===undefined&&!Object.hasOwn(patch.gemMotion,'count')&&!transitionOptions.lookRestore&&before.rendering.wingsActive&&
      globalThis.canvas?.ready&&doc.parent?.id===canvas.scene?.id&&
      !(before.conditionResponse.bits&&['falling','fallen'].includes(before.conditionResponse.collapse.phase))){
      const allocation=this.bits.allocation(doc,before),stations=formationStations(allocation,this.bits.records(doc));
      if(stations.length){
        allocation.groups.home.transition=this.bits.formationTransition(doc,allocation.groups.home,stations,now,
          cfg.transitions&&cfg.bitTransitions&&!cfg.reduced?cfg.bitTransitionDuration:0);
        allocation.revision++;
        changes[`flags.${ID}.bitAllocations`]=allocation;
      }
    }
    let countCommitted=false;
    if(patch.mode==='takeoff'&&(!data.airborne||!data.enabled||data.mode==='grounded')&&
      patch.bitsDeployed===undefined&&!patch.gemMotion&&!transitionOptions.lookRestore)
      await this.bits.deployForTakeoff(doc,changes,{data,snapshot:before,cfg,now,duration:transitionOptions.duration??cfg.bitTransitionDuration});
    else if(patch.mode==='landing'&&patch.bitsDeployed===undefined&&!patch.gemMotion&&!transitionOptions.lookRestore){
      // (12.0.0-beta.4) her bits are recalled as her wings close, not as she begins to come down: the wait is the
      // part of the landing before its wing fold (or before a landing style's recall)
      const tr=changes[`${PATH}.transition`],timing=landingBitTiming(tr,transitionOptions.duration??cfg.transitionDuration);
      await this.bits.landBitsNow(doc,changes,{keepBits:transitionOptions.keepBits===true,snapshot:before,cfg,now,...timing,transitionId:tr?.id??null});
    }
    else {
      countCommitted=!transitionOptions.skipAllocationSync&&await this.bits.commitFlightCount(doc,transitionOptions.lookRestore??patch,changes,{manualLightIntent:!transitionOptions.lookRestore});
      if(!countCommitted)await doc.update(changes);
    }
    if(!transitionOptions.skipAllocationSync&&(patch.gemMotion||patch.bitsDeployed!==undefined||transitionOptions.lookRestore))
      await this.bits.syncFlightControls(doc,transitionOptions.lookRestore??patch,{manualLightIntent:!transitionOptions.lookRestore,skipDeployment:countCommitted});
    return this.applied(doc,{lightSync});
  }

  transition(kind, target, input={}) {
    input=transitionOptions(kind,input);
    const selected=target===undefined;
    if (selected && !canvas.ready) return Promise.resolve(ui.notifications.warn('Open a scene first.'));
    const docs=selected ? [...canvas.tokens.controlled].filter(t=>current(t)&&!t.isPreview&&t.document.isOwner).map(t=>t.document) : [requireDocument(target)];
    if (!docs.length) return Promise.resolve(ui.notifications.warn('Select a token you own first.'));
    return Promise.all(docs.map(doc=>this.enqueue(doc,()=>{
      if (selected && (!current(doc.object)||doc.parent.id!==canvas.scene?.id)) throw new Error('The selected scene changed before the flight command ran.');
      return this.commit(doc,{mode:kind},input);
    }))).then(states=>selected?states:states[0]);
  }

  /** Flight feel settings for a token: {weight, scale, altitude, takeoffElevation, …}. */
  flightFeel(target){return readFlightFeel(requireDocument(target));}
  setFlightFeel(target,patch={}){
    const doc=requireDocument(target);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      const before=readFlightFeel(doc);
      const next=normalizeFeel({...before,...(patch&&typeof patch==='object'?patch:{})});
      // Remember the last afterimage style so a toggle can turn it back on.
      if(next.afterimages!=='off')next.lastAfterimages=next.afterimages;
      // "Takeoff sets her elevation" turned off while flying: her elevation is
      // the player's again (left where it is; the recorded ground is dropped).
      const ground=Number(doc.getFlag(ID,GROUND_FLAG)),changes={[`flags.${ID}.${FEEL_FLAG}`]:next};
      if(!next.takeoffElevation&&before.takeoffElevation&&Number.isFinite(ground))forceDelete(changes,`flags.${ID}`,GROUND_FLAG);
      // Turning it on while flying records her ground and lifts the token
      // (only when it was off: other settings never move her elevation).
      else if(next.takeoffElevation&&!before.takeoffElevation&&!Number.isFinite(ground)&&this.getState(doc)?.airborne&&flyingHeight(next,steadyMode(this.getState(doc)))>0){
        const base=Number(doc.elevation)||0;changes.elevation=base+flyingHeight(next,steadyMode(this.getState(doc)));changes[`flags.${ID}.${GROUND_FLAG}`]=base;}
      // A new chosen height, or height following the flight mode turned on or
      // off, while she is in the air: move to the height for her mode.
      else if(next.takeoffElevation&&Number.isFinite(ground)&&this.getState(doc)?.airborne&&
        (next.heightByMode!==before.heightByMode||next.altitude!==before.altitude))
        changes.elevation=ground+flyingHeight(next,steadyMode(this.getState(doc)));
      await doc.update(changes);return next;
    });
  }
  /** Fly at a height: {to} or {by} feet. By default (beta.32) this sets her
   * token's elevation, which her flying look follows. With "Takeoff sets her
   * elevation" on it is her height above the ground she took off from (and
   * her takeoff height next time), as before. */
  altitude(target,{to,by}={}){
    const doc=requireDocument(target);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      const feel=readFlightFeel(doc),state=this.getState(doc),ground=Number(doc.getFlag(ID,GROUND_FLAG));
      if(!feel.takeoffElevation){
        const now=Number(doc.elevation)||0,step=Number(by),wanted=Number.isFinite(Number(to))?Number(to):now+(Number.isFinite(step)?step:0);
        const next=Math.max(0,Math.round(wanted));
        if(next!==now)await doc.update({elevation:next});return next;
      }
      const flying=!!state.airborne,mode=flying?steadyMode(state):null;
      const current=flying&&feel.takeoffElevation&&Number.isFinite(ground)?Math.max(0,(Number(doc.elevation)||0)-ground):flying?flyingHeight(feel,mode):feel.altitude;
      const step=Number(by),wanted=Number.isFinite(Number(to))?Number(to):current+(Number.isFinite(step)?step:0);
      // With height following the mode, each mode tops out at its share of 120 ft.
      const ceiling=flying&&feel.heightByMode&&mode?modeCeiling(mode):ALTITUDE_LIMIT;
      const next=Math.max(0,Math.min(ceiling,Math.round(wanted)));
      // In the air with height following the mode, the saved (chosen) height is
      // the one that gives this height in the current mode.
      const saved=flying&&feel.heightByMode&&mode?Math.max(0,Math.min(ALTITUDE_LIMIT,baseAltitude(next,mode))):next;
      const changes={[`flags.${ID}.${FEEL_FLAG}`]:{...feel,altitude:saved}};
      if(flying&&feel.takeoffElevation){
        const base=Number.isFinite(ground)?ground:Number(doc.elevation)||0;
        changes.elevation=base+next;if(!Number.isFinite(ground))changes[`flags.${ID}.${GROUND_FLAG}`]=base;
      }
      await doc.update(changes);return next;
    });
  }

  /** Wing shield: raise (true), lower (false) or toggle (omitted). Her wings
   * sweep forward and a hardlight barrier forms in front of her. */
  wingShield(target,on){
    const doc=requireDocument(target);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      const raised=wingShieldRaised(doc),next=typeof on==='boolean'?on:!raised;
      const effect=raiseShieldEffect(doc);
      // Lowering a Raise a Shield shield remembers that effect; raising is manual.
      const value=next?true:effect&&readFlightFeel(doc).autoShield!==false?`off:${effect.id}`:null;
      await doc.update(value===null?forceDelete({},`flags.${ID}`,SHIELD_FLAG):{[`flags.${ID}.${SHIELD_FLAG}`]:value});return next;
    });
  }

  /** The extra timing of a landing style ({duration, foldMs, recall, descentMs, flightMs}), or nothing for the landing as it was. */
  landingRecall(doc,before,cfg,base){
    try{
      if(cfg.reduced||cfg.landingFolding===false||cfg.wingRenderer==='atlas'||!before.rendering?.wingsActive)return {};
      const v=resolveV11(doc),style=v.landingStyles!==false?v.landingStyle:'classic';if(!isRecall(style))return {};
      const timing=landingTiming(doc,before,base);
      return recallTiming(style,timing.duration??0,timing.foldMs??base);
    }catch{return {};}
  }

  toggleFlight(target,input={}) {
    const doc=requireDocument(target),options=transitionOptions('toggle',input);
    // Decide after preceding writes settle. Repeated HUD/key presses during a
    // delayed takeoff cannot enqueue a second takeoff from the old state.
    return this.enqueue(doc,()=>{
      this.assertOwned(doc);
      const state=this.getState(doc);
      if(state.transition?.active&&!state.transition.wingsOnly)return state;
      return this.commit(doc,{mode:state.airborne?'landing':'takeoff'},options);
    });
  }

  poseOptions(input={}) {
    if (!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>k!=='duration')) throw new Error('Transition options accept only {duration: milliseconds}.');
    if (input.duration!==undefined && (!Number.isFinite(input.duration)||input.duration<0||input.duration>10000)) throw new Error('Transition duration must be 0–10000 milliseconds.');
    return input.duration;
  }

  setPose(target,pose,input={}) {
    const doc=requireDocument(target), patch={pose:validatePose(pose)}, duration=this.poseOptions(input);
    return this.enqueue(doc,()=>this.commit(doc,patch,{poseDuration:duration}));
  }

  setStructureSize(target,size,input={}) {
    const doc=requireDocument(target);validateStructureSize(size);
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['structure','duration'].includes(k)))throw new Error('Structure size options accept structure and duration.');
    const duration=this.poseOptions({...(input.duration!==undefined?{duration:input.duration}:{})});
    if(input.structure!==undefined)validateStructure(input.structure);
    return this.enqueue(doc,()=>{
      const data=normalizeFlag(doc.getFlag(ID,'flight'),serverTime()),id=input.structure??data.structure;
      return this.commit(doc,{structurePoses:{[id]:{size}}},{structurePoseDuration:duration});
    });
  }

  poseFor(target,pose,duration,input={},clear=false) {
    const doc=requireDocument(target);
    if (!clear) validatePose(pose);
    if (!Number.isFinite(duration)||duration<0||duration>3600000) throw new Error('Temporary pose duration must be 0–3600000 milliseconds.');
    const fadeDuration=this.poseOptions(input);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);
      const now=serverTime(),raw=doc.getFlag(ID,'flight'),data=normalizeFlag(raw,now),cfg=configuration();
      const controls=resolvePoseMotion(data,cfg),sample=this.sampledPose(data,doc,now);
      const changes={[`${PATH}.schemaVersion`]:SCHEMA_VERSION,
        [`${PATH}.temporaryPose`]:{id:foundry.utils.randomID(16),pose:clear?data.pose:pose,started:now,duration,
          fadeDuration:fadeDuration??controls.duration,from:sample.weights,motion:poseTimingMotion(sample,controls)}};
      if (raw==null) changes[`${PATH}.inheritDefaults`]=true;
      await doc.update(changes);
      return this.applied(doc);
    });
  }

  setCondition(target,condition,input={}) {
    const doc=requireDocument(target),patch={condition:condition==='auto'?'auto':validateCondition(condition)},duration=this.poseOptions(input);
    return this.enqueue(doc,()=>this.commit(doc,patch,{conditionDuration:duration}));
  }

  conditionFor(target,condition,duration,input={},clear=false) {
    const doc=requireDocument(target);if(!clear)validateCondition(condition);
    if(!Number.isFinite(duration)||duration<0||duration>3600000)throw new Error('Temporary condition duration must be 0–3600000 milliseconds.');
    const fade=this.poseOptions(input);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);const now=serverTime(),cfg=configuration(),raw=doc.getFlag(ID,'flight'),data=normalizeFlag(raw,now);
      const changes={[`${PATH}.schemaVersion`]:SCHEMA_VERSION,[`${PATH}.temporaryCondition`]:{
        id:foundry.utils.randomID(16),condition:clear?data.condition:condition,started:now,duration,
        fadeDuration:fade??cfg.conditionDuration,from:this.sampledCondition(data,doc,cfg,now).authoredProfile,hpSeparated:true}};
      if(raw==null)changes[`${PATH}.inheritDefaults`]=true;
      await doc.update(changes);return this.applied(doc);
    });
  }

  cueOptions(kind,input={}) {
    if(!REACTION_IDS.includes(kind))throw new Error(`Unknown reaction: ${kind}.`);
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['duration','strength','critical'].includes(k)))throw new Error('Effect options accept duration, strength and critical.');
    const {duration,strength=0.7,critical=false}=input;
    if(duration!==undefined&&(!Number.isFinite(duration)||duration<0||duration>10000))throw new Error('Effect duration must be 0–10000 milliseconds.');
    if(!Number.isFinite(strength)||strength<0||strength>1)throw new Error('Effect strength must be 0–1.');
    if(typeof critical!=='boolean'||(critical&&kind!=='flare'))throw new Error('critical is a boolean option for flare().');
    return {duration,strength,critical};
  }
  makeCue(kind,{duration,strength,critical},cfg,now) {
    return {id:foundry.utils.randomID(16),kind:critical?'critical':kind,started:now,duration:duration??(['heal','pulse','reform'].includes(kind)?cfg.healingDuration:cfg.damageDuration),strength};
  }
  /** A reaction written to the token: every viewer sees it (preview leaves HP and saved conditions alone). */
  cue(target,kind,input={},preview=false) {
    const opts=this.cueOptions(kind,input),doc=requireDocument(target);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);const now=serverTime(),cfg=configuration(),raw=doc.getFlag(ID,'flight'),data=normalizeFlag(raw,now);
      const cue=this.makeCue(kind,opts,cfg,now);
      // Reform only rebuilds collapsed wings. A manual condition (Damaged, Glitching…) stays.
      if(kind==='reform'&&!preview&&data.condition==='collapsed')return this.commit(doc,{condition:'auto'},{cue,conditionDuration:opts.duration});
      const changes={[`${PATH}.schemaVersion`]:SCHEMA_VERSION,[`${PATH}.cues.manual`]:cue},t=data.temporaryCondition;
      if(kind==='reform'&&!preview&&t?.condition==='collapsed'&&now<t.started+t.duration)
        changes[`${PATH}.temporaryCondition`]={id:foundry.utils.randomID(16),condition:data.condition,started:now,duration:0,
          fadeDuration:opts.duration??cfg.conditionDuration,from:this.sampledCondition(data,doc,cfg,now).authoredProfile,hpSeparated:true};
      if(raw==null)changes[`${PATH}.inheritDefaults`]=true;
      await doc.update(changes);return this.applied(doc);
    });
  }
  /** Private preview: plays on this screen only and is never written to the token.
   * It rides on the rendered wings, so it needs them open here. */
  localCue(target,kind,input={}) {
    const opts=this.cueOptions(kind,input),doc=requireDocument(target);this.assertOwned(doc);
    const s=this.manager.states?.get(doc.object);
    if(!s?.data||!s.snapshot?.rendering?.wingsActive)throw new Error('Open the wings to preview a reaction on her token · the Effects tab previews it any time.');
    const cue=this.makeCue(kind,opts,runtimeConfiguration(),serverTime());
    s.data={...s.data,cues:{...s.data.cues,manual:cue}};s.renderRevision=(s.renderRevision??0)+1;s.frozenInputs=null;
    return cue;
  }

  /** Internal automatic writes share the public command queue and cannot revive an OFF token. */
  automatic(doc,patch,valid=()=>true) {
    return this.enqueue(doc,async()=>{
      if(!valid()||!doc.isOwner||!reactionVisualActive(doc.getFlag(ID,'flight'),doc.getFlag(ID,'bitAllocations'),doc.getFlag(ID,'bitAnimations')))return;
      this.assertOwned(doc);
      const changes=Object.fromEntries(Object.entries(patch).map(([k,v])=>[`${PATH}.${k}`,v]));
      await doc.update(changes);return this.applied(doc);
    });
  }

  getConditionReactions(target){return conditionReactionSettings(requireDocument(target).getFlag(ID,'flight')?.conditionReactions??{});}
  configureConditionReactions(target,patch,{reset=false}={}){
    const doc=requireDocument(target);
    // Validate before queueing; merge again inside the queue to retain concurrent choices.
    mergeConditionReactions(this.getConditionReactions(doc),patch);
    let before;
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);before=this.getState(doc).conditionResponse;
      const value=reset?conditionReactionSettings():mergeConditionReactions(this.getConditionReactions(doc),patch);
      await doc.update({[`${PATH}.conditionReactions`]:value});
      await this.applied(doc);return this.getConditionReactions(doc);
    }).then(async settings=>{
      const after=this.getState(doc).conditionResponse;
      const down=response=>response?.bits&&['falling','fallen'].includes(response.collapse.phase);
      if(down(before)!==down(after))await this.bits.conditionChanged?.(doc,{unconscious:down(after),response:after,event:doc.getFlag(ID,'flight')?.conditionResponse},serverTime());
      return settings;
    });
  }

  getBitToolPreferences(target){
    const doc=requireDocument(target),cfg=runtimeConfiguration(),raw=doc.getFlag(ID,'v8Tools')??{},requested={};
    for(const key of ['weightedTravel','obstacleRoutes','workingPosture'])if(typeof raw[key]==='boolean')requested[key]=raw[key];
    if(typeof raw.scanSpeed==='number'&&raw.scanSpeed>=.25&&raw.scanSpeed<=1.5)requested.scanSpeed=raw.scanSpeed;
    if(raw.scanMethods!==undefined){try{requested.scanMethods=normalizeScanMethods(raw.scanMethods);}catch{}}
    if(['deliberate','classic'].includes(raw.examinationMovement))requested.examinationMovement=raw.examinationMovement;
    return {scanMethods:effectiveScanMethods(raw.scanMethods),scanSpeed:scanSpeed(requested.scanSpeed??DEFAULT_SCAN_SPEED),examinationMovement:requested.examinationMovement??'deliberate',weightedTravel:requested.weightedTravel??cfg.v8WeightedTravel!==false,obstacleRoutes:requested.obstacleRoutes??cfg.v8ObstacleRoutes===true,workingPosture:requested.workingPosture??cfg.v8WorkingPosture!==false,requested};
  }
  setBitToolPreferences(target,input={}){
    const doc=requireDocument(target);
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['weightedTravel','obstacleRoutes','workingPosture','scanSpeed','scanMethods','examinationMovement'].includes(key))||Object.entries(input).some(([key,value])=>value!==null&&(key==='scanMethods'?false:key==='examinationMovement'?!['deliberate','classic'].includes(value):key==='scanSpeed'?typeof value!=='number'||!Number.isFinite(value)||value<.25||value>1.5:typeof value!=='boolean')))throw new Error('Choose valid instrument preferences, deliberate/classic examination movement, or null to inherit.');
    if(input.scanMethods!=null)normalizeScanMethods(input.scanMethods);
    const patch=structuredClone(input);
    return this.enqueue(doc,async()=>{
      this.assertOwned(doc);const changes={};
      for(const [key,requested]of Object.entries(patch)){const value=key==='scanMethods'&&requested!==null?normalizeScanMethods(requested,{defaults:effectiveScanMethods(doc.getFlag(ID,'v8Tools')?.scanMethods)}):requested;if(value===null)forceDelete(changes,`flags.${ID}.v8Tools`,key);else changes[`flags.${ID}.v8Tools.${key}`]=value;}
      if(Object.keys(changes).length){
        if(Object.hasOwn(patch,'examinationMovement')){
          const events=this.bits.records(doc),current=this.getBitToolPreferences(doc).examinationMovement;
          for(const event of events)if(event.kind==='utility'&&event.utility.mode==='creatureScan'&&!event.utility.examinationMovement)event.utility.examinationMovement=current;
          await this.bits.write(doc,events,[],null,changes);
        }else await doc.update(changes);
      }
      await this.applied(doc);return this.getBitToolPreferences(doc);
    });
  }
  publicAPI() {
    const guard=fn=>(...args)=>{
      try {
        const value=fn(...args);
        return value?.then ? value.catch(e=>{this.manager.report(e);throw e;}) : value;
      } catch(e) {this.manager.report(e);throw e;}
    };
    return Object.freeze({
      version:VERSION,
      performance:localPerformance.publicAPI(),
      // A one-click check of how the module behaves in this game (macro: Run Yvaelle’s Toolbox Check).
      keepsake:Object.freeze({timings:(options={})=>keepsakeTimings(options)}),
      selfCheck:Object.freeze({open:guard(()=>openSelfCheck({service:this,manager:this.manager})),run:guard(options=>runSelfCheckWithPanel(options,{service:this,manager:this.manager})),format:result=>formatReport(result)}),
      previewTreatment:guard(options=>previewTreatment(options)),
      bits:this.bits.publicAPI(guard),
      getBitToolState:guard(target=>this.bits.getToolState(requireDocument(target))),
      previewBitTool:guard((target,options)=>this.bits.previewTool(target,options)),
      startBitTool:guard((target,options)=>this.bits.startTool(target,options)),
      previewBitToolEdit:guard((target,patch)=>this.bits.previewEdit(target,patch)),
      editBitTool:guard((target,plan)=>this.bits.edit(target,plan)),
      setBitToolPaused:guard((target,paused,options)=>this.bits.setPaused(target,paused,options)),
      setBitToolExaminationMovement:guard((target,value)=>this.bits.setExaminationMovement(target,value)),
      setBitToolScanMethods:guard((target,patch)=>this.bits.setScanMethods(target,patch)),
      setBitToolScanSpeed:guard((target,speed,options)=>this.bits.setScanSpeed(target,speed,options)),
      stopBitTool:guard((target,options)=>this.bits.stopTool(target,options)),
      undoBitCommand:guard(target=>this.bits.undoCommand(target)),
      getBitToolPreferences:guard(target=>this.getBitToolPreferences(target)),setBitToolPreferences:guard((target,patch)=>this.setBitToolPreferences(target,patch)),
      bitTools:Object.freeze({previewEdit:guard((target,patch)=>this.bits.previewEdit(target,patch)),edit:guard((target,plan)=>this.bits.edit(target,plan)),setPaused:guard((target,paused,options)=>this.bits.setPaused(target,paused,options)),setExaminationMovement:guard((target,value)=>this.bits.setExaminationMovement(target,value)),setScanMethods:guard((target,patch)=>this.bits.setScanMethods(target,patch)),setScanSpeed:guard((target,speed,options)=>this.bits.setScanSpeed(target,speed,options)),get:guard(target=>this.bits.getToolState(requireDocument(target))),preview:guard((target,options)=>this.bits.previewTool(target,options)),execute:guard((target,plan)=>this.bits.startTool(target,plan)),undo:guard(target=>this.bits.undoCommand(target)),stop:guard((target,options)=>this.bits.stopTool(target,options)),getPreferences:guard(target=>this.getBitToolPreferences(target)),setPreferences:guard((target,patch)=>this.setBitToolPreferences(target,patch))}),
      conditionReactions:Object.freeze({get:guard(target=>this.getConditionReactions(target)),configure:guard((target,patch)=>this.configureConditionReactions(target,patch)),reset:guard(target=>this.configureConditionReactions(target,{}, {reset:true})),getState:guard(target=>this.getState(target).conditionResponse)}),
      openHUD:guard(target=>this.hudController().open(target)),
      toggleHUD:guard(target=>this.hudController().toggle(target)),
      closeHUD:guard(()=>this.hud?.close()),
      getAudio:guard(target=>this.getAudio(target)),
      setAudio:guard((target,patch)=>this.setAudio(target,patch)),
      previewAudio:guard((target,slot,options)=>this.previewAudio(target,slot,options)),
      stopAudioPreview:guard(()=>this.manager.audio?.stopPreview()),
      getAudioCatalog:()=>structuredClone(AUDIO_SLOTS),
      toggle:guard((first,second)=>this.command('toggle',first,second)),
      on:guard((first,second)=>this.command('on',first,second)),
      off:guard(target=>this.command('off',target)),
      toggleWings:guard((target,opts)=>this.setWingsEnabled(target,undefined,opts)),
      setWingsEnabled:guard((target,enabled,opts)=>this.setWingsEnabled(target,enabled,opts)),
      takeoff:guard((target,opts)=>this.transition('takeoff',target,opts)),
      land:guard((target,opts)=>this.transition('landing',target,opts)),
      toggleFlight:guard((target,opts)=>this.toggleFlight(target,opts)),
      flightFeel:guard(target=>this.flightFeel(target)),
      setFlightFeel:guard((target,patch)=>this.setFlightFeel(target,patch)),
      altitude:guard((target,opts)=>this.altitude(target,opts)),
      climb:guard((target,feet=5)=>this.altitude(target,{by:Math.abs(Number(feet)||5)})),
      wingShield:guard((target,on)=>this.wingShield(target,on)),
      descend:guard((target,feet=5)=>this.altitude(target,{by:-Math.abs(Number(feet)||5)})),
      setState:guard((target,patch)=>this.setState(target,patch)),
      setV7Preferences:guard((target,patch)=>this.setV7Preferences(target,patch)),
      wingGesture:guard((target,name,opts)=>this.wingGesture(target,name,opts)),
      stopWingGesture:guard(target=>this.wingGesture(target,null)),
      getWingGestures:()=>structuredClone(WING_GESTURES),
      getTreatmentStyles:guard(target=>treatmentStylesFor(this.getState(target).v7).map(id=>({id,name:TREATMENT_LABELS[id]}))),
      classicVisuals:guard(target=>this.setV7Preferences(target,{mode:'classic'})),
      enhancedVisuals:guard(target=>this.setV7Preferences(target,{mode:'enhanced',enabled:true})),
      setMode:guard((target,mode)=>this.setState(target,{mode})),
      setPose:guard((target,pose,opts)=>this.setPose(target,pose,opts)),
      setStructure:guard((target,structure)=>this.setState(target,{structure})),
      setStructureSize:guard((target,size,opts)=>this.setStructureSize(target,size,opts)),
      poseFor:guard((target,pose,ms,opts)=>this.poseFor(target,pose,ms,opts)),
      clearPoseOverride:guard((target,opts)=>this.poseFor(target,null,0,opts,true)),
      setCondition:guard((target,condition,opts)=>this.setCondition(target,condition,opts)),
      conditionFor:guard((target,condition,ms,opts)=>this.conditionFor(target,condition,ms,opts)),
      clearConditionOverride:guard((target,opts)=>this.conditionFor(target,null,0,opts,true)),
      overdrive:guard((target,ms=3000,opts)=>this.conditionFor(target,'overdrive',ms,opts)),
      setGlitchIntensity:guard((target,intensity)=>this.setState(target,{glitchIntensity:intensity})),
      setHPReactions:guard((target,enabled)=>this.setState(target,{autoHP:enabled})),
      flare:guard((target,opts)=>this.cue(target,'flare',opts)),
      pulse:guard((target,opts)=>this.cue(target,'pulse',opts)),
      stutter:guard((target,opts)=>this.cue(target,'stutter',opts)),
      collapse:guard((target,opts)=>this.setCondition(target,'collapsed',opts)),
      reform:guard((target,opts)=>this.cue(target,'reform',opts)),
      setIntensity:guard((target,intensity)=>this.setState(target,{intensity})),
      setTrailIntensity:guard((target,intensity)=>this.setState(target,{trailIntensity:intensity})),
      setMovementReactions:guard((target,enabled)=>this.setState(target,{movementReactions:enabled})),
      toggleLight:guard(target=>this.toggleLight(target)),
      toggleLightMode:guard((target,opts)=>this.toggleLightMode(target,opts)),
      setLantern:guard((target,patch)=>this.setLantern(target,patch)),
      lockLantern:guard((target,subject)=>this.lockLantern(target,subject)),
      unlockLantern:guard(target=>this.unlockLantern(target)),
      applyLightPreset:guard((target,id)=>this.applyLightPreset(target,id)),
      saveLightPreset:guard((target,id)=>this.saveLightPreset(target,id)),
      resetLightPreset:guard((target,id)=>this.resetLightPreset(target,id)),
      toggleLantern:guard(target=>this.toggleLantern(target)),
      aimLantern:guard((target,direction)=>this.aimLantern(target,direction)),
      startLanternAim:guard(target=>this.startLanternAim(target)),
      stopLanternAim:guard(()=>this.manager.lantern?.endAim?.()),
      isLanternAiming:guard(target=>this.manager.lantern?.isAiming?.(requireDocument(target).object)??false),
      setLight:guard((target,enabled)=>this.setState(target,{lightEnabled:enabled})),
      setLightIntensity:guard((target,intensity)=>this.setState(target,{lightIntensity:intensity})),
      setLightAppearance:guard((target,appearance)=>this.setState(target,{lightAppearance:appearance})),
      setLanternArtwork:guard((target,artwork)=>this.setState(target,{lanternArtwork:artwork})),
      setLightVisualReactions:guard((target,enabled)=>this.setState(target,{lightVisualReactions:enabled})),
      resetLightAppearance:guard(target=>this.setState(target,{lightAppearance:null,lightVisualReactions:null})),
      restorePreviousLightAppearance:guard(target=>this.setState(target,{lightAppearance:'current',lightVisualReactions:false})),
      setLightRadii:guard((target,radii)=>{
        if(!radii||typeof radii!=='object'||Array.isArray(radii)||!Object.keys(radii).length||Object.keys(radii).some(k=>!['bright','dim'].includes(k)))throw new Error('Pass bright and/or dim light distances. Use null to restore a default.');
        return this.setState(target,Object.fromEntries(Object.entries(radii).map(([k,v])=>[k==='bright'?'lightBright':'lightDim',v])));
      }),
      setEffectStyle:guard((target,style)=>this.setState(target,{effectStyle:style})),
      setEffectStyles:guard((target,styles)=>this.setState(target,{effectStyles:styles})),
      setReactionStyles:guard((target,styles)=>this.setState(target,{reactionStyles:styles})),
      setEffectTuning:guard((target,tuning)=>this.setState(target,{effectTuning:tuning})),
      setReactionTuning:guard((target,tuning)=>this.setState(target,{reactionTuning:tuning})),
      setPoseMotion:guard((target,controls)=>this.setState(target,{poseMotion:controls})),
      getLocalQuality:()=>qualityProfile(runtimeConfiguration().localQuality,{strict:false}),
      setLocalQuality:guard(async profile=>{const value=mergeQuality(configuration().localQuality,profile);await game.settings.set(ID,'localQuality',value);return value;}),
      setObserverQuality:guard((target,profile)=>this.setState(target,{observerQuality:qualityProfile(profile)})),
      setBitCount:guard((target,count)=>this.setState(target,{gemMotion:{count}})),
      setBits:guard((target,enabled,options)=>this.setBitsEnabled(target,enabled,options)),
      setGemMotion:guard((target,controls)=>this.setState(target,{gemMotion:controls})),
      setBitsEnabled:guard((target,enabled,options)=>{if(typeof enabled!=='boolean')throw new Error('Bits enabled must be true or false.');return this.setBitsEnabled(target,enabled,options);}),
      toggleBits:guard((target,options)=>this.setBitsEnabled(target,undefined,options)),
      setBitPosition:guard((target,station,position)=>this.setBitPosition(target,station,position)),
      resetBitPositions:guard((target,station)=>this.resetBitPositions(target,station)),
      attachBitsToWings:guard((target,attached)=>{if(typeof attached!=='boolean')throw new Error('Attachment must be true or false.');return this.setState(target,{gemMotion:{placement:attached?'follow':'free'}});}),
      captureLook:guard(target=>this.captureLook(target)),
      applyLook:guard((target,look)=>this.applyLook(target,look)),
      undoLook:guard((target,undo)=>this.undoLook(target,undo)),
      getLookPresets:()=>structuredClone(LOOK_PRESETS),
      getSavedLooks:()=>this.getSavedLooks(),
      saveLook:guard((name,look)=>this.saveLook(name,look)),
      deleteLook:guard(id=>this.deleteLook(id)),
      previewReaction:guard((target,kind,opts)=>this.localCue(target,kind,opts)),
      playReactionForAll:guard((target,kind,opts)=>this.cue(target,kind,opts,true)),
      getEffectCatalog:()=>effectCatalog(),
      configure:guard((target,opts)=>this.setState(target,{options:opts})),
      setFloatMotion:guard((target,opts)=>{
        if(!opts||typeof opts!=='object'||Array.isArray(opts)||!Object.keys(opts).length||Object.keys(opts).some(k=>!['style','speed','sway','height','amount'].includes(k)))throw new Error('Pass floating style, speed, sway, height and/or amount.');
        const fields={style:'floatStyle',speed:'floatSpeed',sway:'floatSway',height:'hoverHeight',amount:'bobHeight'};
        return this.setState(target,{options:Object.fromEntries(Object.entries(opts).map(([key,value])=>[fields[key],value]))});
      }),
      clearOverrides:guard((target,keys=Object.keys(DEFAULTS))=>{
        if (!Array.isArray(keys)||!keys.length||keys.some(k=>!Object.hasOwn(DEFAULTS,k))) throw new Error('Pass a non-empty array of flight option names.');
        return this.setState(target,{options:Object.fromEntries(keys.map(k=>[k,null]))});
      }),
      getState:guard(target=>this.getState(target)),
      getCapabilities:()=>({...capabilities(),criticalIntegration:this.manager.reactions?.critical?.status()??{available:false,reason:'Not initialized'}}),
      refresh:guard(target=>target===undefined?this.manager.rebuild():this.manager.refreshToken(requireDocument(target)))
    });
  }
}
