/** Self-check (13.0.0-beta.2, its sound beta.4): the V13 part — The Heart Turned.
 *
 * Seven short parts. None of them lays a curse, lifts one, changes a state's text or posts to chat; none of them needs her
 * token (her actor is enough), so they run for a GM with no token of hers on the scene.
 *  - Setup: the feature, its nine parts and its two choices are in the registry, its two settings and the GM's key are registered, the
 *    API is whole, the three fonts and the stylesheet are loaded; who is cursed, who shows it, what is on her now, how
 *    the six states read; anything that went wrong in it since this page loaded.
 *  - Her record: the model's own rules, then a scratch note written on her actor and taken off again (beside the curse,
 *    never the curse itself): what comes back is what was written, replaced whole each time, and the page hears of it.
 *  - Wheel and editor (GM): the wheel opened in the middle of the screen, read, leaned on, closed; the editor opened,
 *    read, cancelled. Nothing is laid and nothing saved.
 *  - Her view: her view played on this screen only, fed from memory: a roll, Minimise, the card, Open, the Spans, the
 *    mark, the mark opened and put back; then one laid on her. What covers it, where the small forms sit, what a frame
 *    costs, what is left afterwards.
 *  - Watching (GM): the GM's watching view of a finished curse, opened and closed.
 *  - Her sheet: her Keepsake sheet opened (the opening scan plays, or the reason it does not is given) and the curse's
 *    mark among her conditions measured against the other chips.
 *  - Its sound (beta.4): the switches, every recording fetched (never played) and, with the sound on, decoded; every
 *    moment the stage raises has a sound; what a silent run of her view would have played.
 * A curse really on her while it runs is left alone: the parts that would cover it say so and step aside.
 *
 * Every line is short: a PASS/CHECK/FAIL per item and a few numbers. */
import {ID} from './config.mjs?v=13.0.1';
import {V11_KEYS,resolveV11,partKey} from './v11/features.mjs?v=13.0.1';
import {CURSE_KEY,CURSE_FLAG,CURSE_STATES,CURSE_NOW,CURSE_DICE,STATE_LIMITS,SPAN_S,rollStyle,newCurse,readCurse,rollCurse,rootCurse,burnSpan,curseStage,curseOver,spansLeft,stateEdits,stateIndex,namesSomeone,faithPick} from './v13/curse-model.mjs?v=13.0.1';
import {CURSE_WORLD,CURSE_CLIENT,CURSE_BINDING,watchWords} from './v13/curse-runtime.mjs?v=13.0.1';
import {CURSE_FONTS} from './v13/curse-art.mjs?v=13.0.1';
import {CURSE_CUES} from './v13/curse-stage.mjs?v=13.0.1';
import {CURSE_SOUND_FILES,CURSE_SHOTS,CURSE_VOLUMES,knowsCue,shotFor} from './v13/curse-sound.mjs?v=13.0.1';
import {wheelSector} from './v13/curse-wheel.mjs?v=13.0.1';
import {keepsakeOn,herActor} from './keepsake/sheet/prefs.mjs?v=13.0.1';
import {isDressed} from './keepsake/sheet/dress.mjs?v=13.0.1';
import {openFxWanted,HUD_OPEN_MS} from './keepsake/hud-open-fx.mjs?v=13.0.1';

export const V13_SCENARIOS=Object.freeze([
  ['v13setup','V13 · Setup','The Heart Turned: the feature, its settings, the GM’s key, its fonts and stylesheet; who is cursed, who shows it, what is on her now; anything that went wrong in it since this page loaded'],
  ['v13record','V13 · Her record','the rules of a curse, then a scratch note written on her actor and taken off again (never the curse itself): what comes back is what was written'],
  ['v13wheel','V13 · Wheel and editor (GM)','the wheel opened in the middle of the screen and closed, the states’ editor opened and cancelled: nothing is laid, nothing saved'],
  ['v13view','V13 · Her view','her view played on this screen only, from memory (nothing is written, nobody else sees it): a roll, Minimise and Open, the Spans, the card and the mark where they sit, what covers them, what a frame costs; then her roll in each of the other three ways, and one laid on her'],
  ['v13watch','V13 · Watching (GM)','the GM’s watching view of a finished curse, opened and closed: nothing is written'],
  ['v13sheet','V13 · Her sheet','her Keepsake sheet is opened: the opening scan plays (or the reason it does not is given) and the curse’s mark is measured among her conditions'],
  ['v13sound','V13 · Its sound','the sound of her view (off as it comes): its switches, every recording fetched and, with the sound on, decoded, and what a run of her view would play. Nothing is played aloud']
]);
export const V13_IDS=Object.freeze(V13_SCENARIOS.map(([id])=>id));
export const V13_HEAD=Object.freeze({v13setup:'V13 SETUP',v13record:'V13 HER RECORD',v13wheel:'V13 WHEEL AND EDITOR',v13view:'V13 HER VIEW',v13watch:'V13 WATCHING',v13sheet:'V13 HER SHEET',v13sound:'V13 ITS SOUND'});
export const V13_LIMITS=Object.freeze({v13setup:20000,v13record:30000,v13wheel:40000,v13view:300000,v13watch:45000,v13sheet:45000,v13sound:60000});
/** The scratch note the record part writes beside the curse (and takes off again). */
export const SCRATCH_FLAG='curseCheck';
const SURFACES='.ff-cu-view,.ff-cu-card,.ff-cu-mark,.ff-cu-wheel,.ff-cu-edit';
const PARTS=['curseStartMin','curseBlur','curseMarkOpen','curseGmNote','curseWatch','curseSheet','curseSound','curseBed'],CHOICES=['curseVolume'];
/** (13.0.0-beta.6) Her roll is shown one way. */
const WAY_NAME={cut:'the cutting'};
const API=['open','lay','ask','lift','burn','state','her','states','edit','watch','errors','minimise','show','status','stats','hear','sounds'];

const f1=n=>Number.isFinite(n)?(Math.round(n*10)/10).toFixed(1):'?',f2=n=>Number.isFinite(n)?(Math.round(n*100)/100).toFixed(2):'?',pct=n=>Number.isFinite(n)?`${(Math.round(n*1000)/10).toFixed(1)}%`:'?';
const RT=ctx=>ctx.manager?.v13?.curse??null;
const D=()=>globalThis.document,W=()=>globalThis.window;
const shortEl=e=>{if(!e)return 'nothing';const c=[...(e.classList??[])].slice(0,2).join('.');return `${e.tagName?.toLowerCase()??'?'}${e.id?'#'+String(e.id).slice(0,24):''}${c?'.'+c:''}`;};
const count=sel=>{try{return D().querySelectorAll(sel).length;}catch{return 0;}};
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const box=e=>{const r=e.getBoundingClientRect();return {x:Math.round(r.left),y:Math.round(r.top),w:Math.round(r.width),h:Math.round(r.height),cx:r.left+r.width/2,cy:r.top+r.height/2,r:Math.round(r.right),b:Math.round(r.bottom)};};
/** What is on top at the middle of an element: itself (or something in it), or what covers it. */
function topOf(el,within=el){const b=box(el);let t=null;try{t=D().elementFromPoint(b.cx,b.cy);}catch{}
  // (the check's own small panel is on the page while it runs: it does not count as covering anything)
  return {own:!!t&&(t===within||within.contains(t)||!!t.closest?.('#ff-self-check')),top:t,b};}
/** How much of a canvas is drawn on, and how much of it is magenta: read from a small copy. */
function ink(cv){
  try{const w=96,h=Math.max(1,Math.round(96*cv.height/Math.max(1,cv.width))),c=D().createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(cv,0,0,w,h);
    const d=x.getImageData(0,0,w,h).data;let lit=0,mag=0;for(let i=0;i<d.length;i+=4){const a=d[i+3]/255,r=d[i]*a,g=d[i+1]*a,b=d[i+2]*a;if(Math.max(r,g,b)>44)lit++;if(r>110&&b>100&&g<r*.74)mag++;}
    return {lit:lit/(w*h),mag:mag/(w*h)};}
  catch(e){return {lit:NaN,mag:NaN,err:String(e?.message??e).slice(0,50)};}
}
/** The page's own frames while something plays. */
function frameWatch(){
  let on=true,last=0;const gaps=[],raf=W().requestAnimationFrame.bind(W());const tick=t=>{if(!on)return;if(last)gaps.push(t-last);last=t;raf(tick);};raf(tick);
  return {stop(){on=false;const s=[...gaps].sort((a,b)=>a-b),q=p=>s.length?s[Math.min(s.length-1,Math.floor(p*s.length))]:NaN;return {n:s.length,med:q(.5),p95:q(.95),max:s.length?s[s.length-1]:NaN,long:s.filter(g=>g>50).length};}};
}
const until=(H,test,ms)=>H.waitUntil(()=>{try{return test();}catch{return false;}},ms,()=>H.sleep(60));
/** Is a small form (the card, the mark) whole, on screen, on top where it sits, and clear of the sidebar? → {line, bad[]} */
function placed(el,name){
  const b=box(el),vw=W().innerWidth,vh=W().innerHeight,bad=[],t=topOf(el),cs=W().getComputedStyle(el);
  if(b.w<40||b.h<16)bad.push(`${name} has no size (${b.w}x${b.h})`);
  if(b.x<0||b.y<0||b.r>vw||b.b>vh)bad.push(`${name} is partly off screen (${b.x},${b.y} to ${b.r},${b.b} of ${vw}x${vh})`);
  if(+cs.opacity<.9||cs.visibility==='hidden'||cs.display==='none')bad.push(`${name} is not shown (opacity ${cs.opacity}, ${cs.visibility}, ${cs.display})`);
  else if(!t.own)bad.push(`${name} is covered by ${shortEl(t.top)}`);
  let side='';try{const sb=D().getElementById('sidebar')??D().getElementById('ui-right'),r=sb?.getBoundingClientRect?.();if(r&&r.width>0){const gap=Math.round(r.left-b.r);side=` · ${gap>=0?`${gap} px left of the sidebar`:`${-gap} px over the sidebar`}`;}}catch{}
  return {b,bad,line:`${name} at ${b.x},${b.y} ${b.w}x${b.h}${side} · z ${cs.zIndex} · on top there: ${t.own?'itself':shortEl(t.top)}`};
}

/* ================================================================ 1. SETUP */
async function v13setup(ctx,res,H){
  const rt=RT(ctx),g=globalThis.game,bad=[],look=[];
  if(!rt){H.verdict(res,'FAIL','the curse’s runtime is not there (manager.v13.curse): the module did not start it');return;}
  // the registry
  let v={};try{v=resolveV11(null);}catch(e){bad.push(`the registry does not resolve (${String(e?.message??e).slice(0,40)})`);}
  const lost=[CURSE_KEY,...[...PARTS,...CHOICES].map(p=>partKey(CURSE_KEY,p))].filter(k=>!V11_KEYS.has(k));if(lost.length)bad.push(`not in the registry: ${lost.join(', ')}`);
  res.lines.push(`feature ${rt.enabled()?'on':'SWITCHED OFF (Settings › Her › Moods & milestones)'} · ${PARTS.map(p=>`${p.replace('curse','')} ${v[partKey(CURSE_KEY,p)]?'on':'off'}`).join(' · ')}`);
  // its settings, as Foundry has them
  const reg=g?.settings?.settings,has=k=>reg?.has?reg.has(`${ID}.${k}`):null,world=H.setting(CURSE_WORLD),client=H.setting(CURSE_CLIENT);
  for(const k of [CURSE_WORLD,CURSE_CLIENT])if(has(k)===false)bad.push(`the setting ${k} is not registered`);
  // the GM's key
  // (registered: Foundry's own list of actions says; assigned: the bindings it holds for it. Where neither can be read, nothing is claimed)
  let keys=null,known=null;try{const K=g?.keybindings;known=K?.actions?.has?K.actions.has(`${ID}.${CURSE_BINDING}`):null;keys=typeof K?.get==='function'?K.get(ID,CURSE_BINDING)??null:null;}catch{}
  const keyText=known===false?'NOT REGISTERED':!Array.isArray(keys)?(known?'registered (its keys could not be read)':'could not be read'):keys.length?keys.map(b=>[...(b.modifiers??[]),b.key].join('+')).join(', '):'none assigned';
  if(known===false)bad.push('the Curse wheel key is not registered (Configure Controls)');
  // the API
  const api=ctx.api?.curse??g?.modules?.get?.(ID)?.api?.curse,missing=API.filter(k=>typeof api?.[k]!=='function');if(!api)bad.push('api.curse is not there');else if(missing.length)bad.push(`api.curse lacks ${missing.join(', ')}`);
  res.lines.push(`settings ${has(CURSE_WORLD)===null?'(registry not readable)':'registered'} · key: ${keyText}${g?.user?.isGM?'':' (the GM’s)'} · api ${api?`${API.length-missing.length}/${API.length}`:'none'} · macro ${[...(g?.macros??[])].some(m=>/api\.curse|Curse[- ]Wheel/i.test(`${m.name} ${m.command??''}`))?'found':'none in this world'}`);
  if(g?.user?.isGM&&Array.isArray(keys)&&!keys.length&&!rt.stats.laid)look.push('no key is assigned to the curse wheel yet (Configure Controls › Curse wheel), and no curse has been laid from this page: the wheel opens only by its key, its macro or api.curse.open()');
  // fonts and the stylesheet
  const fonts=CURSE_FONTS.map(f=>{let ok=false;try{ok=D().fonts.check(f);}catch{}return [f.replace(/^.*'(.+)'$/,'$1'),ok];}),noFont=fonts.filter(f=>!f[1]).map(f=>f[0]);
  if(noFont.length){try{await Promise.race([Promise.all(CURSE_FONTS.map(f=>D().fonts.load(f))),H.sleep(2500)]);}catch{}}
  const still=CURSE_FONTS.filter(f=>{try{return !D().fonts.check(f);}catch{return true;}}).map(f=>f.replace(/^.*'(.+)'$/,'$1'));
  const probe=D().createElement('div');probe.className='ff-cu-mark';probe.style.visibility='hidden';D().body.appendChild(probe);const cs=W().getComputedStyle(probe),css=cs.position==='fixed'&&String(cs.zIndex)==='90';probe.remove();
  res.lines.push(`fonts ${still.length?`NOT LOADED: ${still.join(', ')}`:noFont.length?`loaded when asked (${noFont.join(', ')} were not in use yet)`:'loaded'} · stylesheet ${css?'applied':'NOT APPLIED (styles/curse.css)'} · reduced motion ${rt.reduced()?'ON (the full view is not played; the card and the mark only)':'off'}`);
  if(still.length)bad.push(`font(s) not loaded: ${still.join(', ')}`);if(!css)bad.push('styles/curse.css is not applied');
  // who is cursed, who shows it, what is on her
  const actor=rt.chosenActor(),chosen=world?.actor?g?.actors?.get?.(world.actor):null;
  if(!actor){res.lines.push('cursed: NOBODY (the wheel’s first button picks her from the selected token; else the HUD’s pinned character is used)');look.push('nobody is chosen to be cursed yet');}
  else{
    const users=rt.users(actor),p=rt.presenter(actor),pu=g?.users?.get?.(p),owners=users.filter(u=>u.owner&&!u.isGM),rec=rt.record(actor),raw=(()=>{try{return actor.getFlag?.(ID,CURSE_FLAG);}catch{return undefined;}})();
    res.lines.push(`cursed: ${actor.name} (${chosen?'chosen in the wheel':world?.actor?'the one chosen is gone: the HUD’s pinned character':'the HUD’s pinned character'}) · her players: ${owners.length?owners.map(u=>`${g?.users?.get?.(u.id)?.name??u.id}${u.active?'':' (away)'}`).join(', '):'none'} · shown by: ${pu?`${pu.name??p}${p===g?.user?.id?' (this page)':''}`:'nobody connected'}`);
    res.lines.push(`on her now: ${rec?`${rec.k??'a roll is asked'}${rec.forced?' (laid)':''}${rec.toward?` toward ${rec.toward.n}`:''} · ${rec.spans===null?'not rooted':`${spansLeft(rec,rt.now())} of ${rec.spans} Spans left`} · stage ${curseStage(rec)}`:raw!=null?'A RECORD THAT DOES NOT READ':'nothing'} · this page: view ${rt.view?.mode??'none'}${rt.watcher?` · watcher ${rt.watcher.mode}`:''} · world time ${Number.isFinite(g?.time?.worldTime)?Math.round(g.time.worldTime):'NOT A NUMBER'}`);
    if(raw!=null&&!rec)bad.push('the curse on her actor does not read as one (flags.filament-flight.curse)');
    if(rec&&rec.spans!==null&&curseOver(rec,rt.now())&&(g?.users?.activeGM?.isSelf||p===g?.user?.id))look.push('a curse that has run out is still on her actor (this page should have taken it off)');
    if(!Number.isFinite(g?.time?.worldTime))bad.push('the world’s time is not a number (the Spans cannot run)');
  }
  // the six states as they read here
  const edits=(()=>{try{return stateEdits(world?.states);}catch{return {};}})(),n=Object.keys(edits).length,long=CURSE_NOW.filter(e=>e.n.length>STATE_LIMITS.n||e.w.length>STATE_LIMITS.w||e.d.length>STATE_LIMITS.d).map(e=>e.k);
  res.lines.push(`states: ${CURSE_NOW.map((e,i)=>`${i+1} ${e.n}`).join(' · ')} · ${n?`${n} changed from the table (${Object.keys(edits).join(', ')})`:'as the table has them'}`);
  if(CURSE_NOW.length!==6||CURSE_NOW.some((e,i)=>e.k!==CURSE_STATES[i].k))bad.push('the six states are not the table’s six, in its order');
  if(long.length)bad.push(`a state’s text is longer than the editor allows: ${long.join(', ')}`);
  if(!same(Object.keys(edits).sort(),Object.keys(world?.states??{}).filter(k=>edits[k]).sort())||Object.keys(world?.states??{}).length>n)look.push('the world’s saved edits hold something the module does not use (it is ignored)');
  // watching, and anything that went wrong
  res.lines.push(`this browser: die 1d${CURSE_DICE.includes(client?.die)?client.die:4} · watch her roll ${rt.watching()?'ON':'off'} · mark ${client?.pos?`moved to ${client.pos.right},${client.pos.top} from the right`:'beside the sidebar'} · laid ${rt.stats.laid} · rolled ${rt.stats.rolled} · rooted ${rt.stats.rooted} · lifted ${rt.stats.lifted} · watched ${rt.stats.watched}`);
  const errs=rt.errors??[];
  if(errs.length){res.lines.push(`trouble since this page loaded: ${errs.length}`);for(const e of errs.slice(-4))res.lines.push(`   ${e.where}: ${e.msg}${e.stack?` @ ${e.stack.slice(0,110)}`:''}`);}
  else res.lines.push('trouble since this page loaded: none');
  const left=rt.view?.mode&&rt.view.mode!=='none'?0:count('.ff-cu-view,.ff-cu-card,.ff-cu-mark');if(left)bad.push(`${left} piece(s) of her view on the page with no curse showing`);
  if(bad.length)H.verdict(res,'FAIL',`v13 setup: ${bad.join('; ')}`);
  else if(errs.length)H.verdict(res,'CHECK',`The Heart Turned is set up, but ${errs.length} thing${errs.length>1?'s':''} went wrong in it since this page loaded (last: ${errs.at(-1).where}: ${errs.at(-1).msg.slice(0,70)})`);
  else H.verdict(res,'PASS',`The Heart Turned is set up: registered, ${rt.enabled()?'on':'switched off'}, fonts and stylesheet loaded, nothing has gone wrong in it on this page`);
  for(const t of look)H.verdict(res,'CHECK',t);
}

/* ================================================================ 2. HER RECORD */
async function v13record(ctx,res,H){
  const rt=RT(ctx),g=globalThis.game,bad=[];if(!rt){H.verdict(res,'FAIL','the curse’s runtime is not there');return;}
  // the rules, on a record that never leaves this function
  const ppl=[{id:'Actor.a',n:'One',img:''},{id:'Actor.b',n:'Two',img:''},{id:'Actor.c',n:'Three',img:''}],seq=a=>{let i=0;return ()=>a[Math.min(i++,a.length-1)];};
  const fresh=newCurse({people:ppl,die:6,by:'check',id:'check00000000001'}),rolled=rollCurse(fresh,seq([.7,.4])),rooted=rolled&&rootCurse(rolled.record,1000,seq([.99]));
  if(!same(readCurse(fresh),fresh))bad.push('a new record does not read back as itself');
  if(!rolled||rolled.die!==5||rolled.record.k!==CURSE_STATES[4].k||rolled.pick!==1||rolled.record.toward?.n!=='Two')bad.push(`a roll of .7 then .4 gave ${rolled?`${rolled.die} ${rolled.record.k} pick ${rolled.pick}`:'nothing'} (5, ${CURSE_STATES[4].k}, pick 1 expected)`);
  if(!rooted||rooted.spans!==6||rooted.record.until!==1000+6*SPAN_S||spansLeft(rooted.record,1000)!==6||spansLeft(rooted.record,1000+SPAN_S)!==5||!curseOver(rooted.record,1000+6*SPAN_S))bad.push('the Spans do not count as they should (6 at the start, 5 an hour on, over at the end)');
  const laid=newCurse({state:5,toward:ppl[0],people:ppl}),faith=newCurse({state:3,people:ppl,faith:seq([.5])}),burnt=rooted&&burnSpan(rooted.record);
  if(laid.toward!==null||laid.pinned)bad.push('Intrusive kept a pinned person (it names nobody)');
  if(faith.toward?.n!=='Two'||faith.pinned||faithPick(faith)!==1)bad.push('a state laid with nobody pinned did not find its person by the roll of faith');
  if(!burnt||spansLeft(burnt,1000)!==5)bad.push('−1 Span does not take one Span off');
  res.lines.push(`rules: new · roll (d6, then the roll of faith) · root (1d6 Spans from the world’s time) · −1 Span · laid states: ${bad.length?`${bad.length} WRONG`:'as they should be'}`);
  // on her actor: a scratch note beside the curse
  const actor=rt.chosenActor();
  if(!actor){H.verdict(res,bad.length?'FAIL':'CHECK',bad.length?`the rules of a curse: ${bad.join('; ')}`:'the rules of a curse hold; nobody is chosen to be cursed, so nothing was written');return;}
  if(!actor.isOwner){H.verdict(res,bad.length?'FAIL':'CHECK',bad.length?`the rules of a curse: ${bad.join('; ')}`:`the rules of a curse hold; you do not own ${actor.name}, so nothing was written (run this as her player or the GM)`);return;}
  const path=`flags.${ID}.${SCRATCH_FLAG}`,read=()=>{try{return actor.getFlag?.(ID,SCRATCH_FLAG);}catch{return undefined;}},real=JSON.stringify(rt.record(actor)),laidBefore=rt.stats.laid;
  let heard=0;const hook=globalThis.Hooks.on('updateActor',a=>{if(a?.id===actor.id)heard++;});
  res.restore(async()=>{try{globalThis.Hooks.off('updateActor',hook);}catch{}try{if(read()!==undefined)await actor.unsetFlag(ID,SCRATCH_FLAG);}catch{}});
  const times=[],put=async(rec,name)=>{const t0=H.now();await actor.update({[path]:rec},{render:false});times.push(H.now()-t0);ctx.check();const back=readCurse(read());if(!same(back,readCurse(rec)))bad.push(`${name}: what came back is not what was written (${diff(back,readCurse(rec))})`);};
  const diff=(a,b)=>{if(!a)return 'nothing came back';const k=Object.keys(b).filter(x=>!same(a[x],b[x]));return k.length?`differs at ${k.join(', ')}`:'the same';};
  if(read()!==undefined)res.lines.push('a scratch note from an earlier run was still on her actor: taken off now');
  // 1 asked · 2 rolled (a person where there was none, the list written again) · 3 nobody again · 4 rooted · then gone
  await put(fresh,'a roll asked');await put(rolled.record,'her roll');await put({...rolled.record,k:CURSE_STATES[5].k,toward:null,pinned:false,people:ppl.slice(0,1)},'nobody named after someone was');await put(rooted.record,'her Spans');
  const t0=H.now();await actor.unsetFlag(ID,SCRATCH_FLAG);times.push(H.now()-t0);await H.sleep(120);
  if(read()!==undefined)bad.push('the note could not be taken off her actor again');
  if(heard<5)bad.push(`the page heard of ${heard} of the 5 changes (updateActor)`);
  if(JSON.stringify(rt.record(actor))!==real)bad.push('the curse itself changed while the note was written');
  if(rt.stats.laid!==laidBefore)bad.push('a curse was laid while the note was written');
  const sorted=[...times].sort((a,b)=>a-b);
  res.lines.push(`on ${actor.name}: 4 writes and a removal of a scratch note (${SCRATCH_FLAG}) · each ${f1(sorted[Math.floor(sorted.length/2)])} ms (slowest ${f1(sorted.at(-1))}) · heard ${heard}/5 · the curse itself ${JSON.stringify(rt.record(actor))===real?'untouched':'CHANGED'}`);
  if(bad.length)H.verdict(res,'FAIL',`her record: ${bad.join('; ')}`);
  else H.verdict(res,sorted.at(-1)>1500?'CHECK':'PASS',`a curse’s record goes onto her actor and comes back whole, each change replacing the last${sorted.at(-1)>1500?` (but a write took ${Math.round(sorted.at(-1))} ms: her roll will seem to hang that long)`:''}`);
}

/* ================================================================ 3. WHEEL AND EDITOR */
async function v13wheel(ctx,res,H){
  const rt=RT(ctx),g=globalThis.game,bad=[];if(!rt){H.verdict(res,'FAIL','the curse’s runtime is not there');return;}
  if(!g?.user?.isGM){res.skipped='the wheel and the editor are the GM’s';return;}
  if(!rt.enabled()){res.skipped='The Heart Turned is switched off';return;}
  if(rt.wheel?.open||rt.editor?.open||count('.ff-cu-wheel,.ff-cu-edit')){res.skipped='the wheel or the editor is open now: close it and run this again';return;}
  const actor=rt.chosenActor(),real=JSON.stringify(rt.record(actor)),laid=rt.stats.laid,world=JSON.stringify(H.setting(CURSE_WORLD)),client=JSON.stringify(H.setting(CURSE_CLIENT));
  res.restore(async()=>{try{rt.wheel?.destroy();rt.editor?.close();await H.sleep(320);}catch{}});
  const x=Math.round(W().innerWidth/2),y=Math.round(W().innerHeight/2);
  // the wheel
  const opened=rt.toggleWheel(x,y);await H.sleep(750);ctx.check();
  const root=D().querySelector('.ff-cu-wheel'),wh=rt.wheel;
  if(!opened||!root||!wh?.open){H.verdict(res,'FAIL','the wheel did not open');return;}
  const cv=root.querySelector('canvas'),strip=root.querySelector('.ff-cu-strip'),bar=root.querySelector('.ff-cu-bar'),ik=ink(cv),t=topOf(cv,root);
  const people=strip?.querySelectorAll('.ff-cu-who').length??0,dice=[...(strip?.querySelectorAll('[data-die]')??[])].map(b=>b.dataset.die).join('/'),btn=a=>bar?.querySelector(`[data-act="${a}"]`);
  if(!(ik.lit>.004))bad.push(`the wheel’s canvas is not drawn on (${pct(ik.lit)} lit${ik.err?`, ${ik.err}`:''})`);
  if(!t.own)bad.push(`the wheel is covered at its centre by ${shortEl(t.top)}`);
  if(dice!=='3/4/6')bad.push(`the strip’s dice are ${dice||'missing'} (3/4/6 expected)`);
  if(!btn('watch')||!btn('edit'))bad.push('the bar under the wheel lacks Watch her roll or Edit the states');
  for(const [name,el] of [['the strip',strip],['the bar',bar]]){if(!el)continue;const b=box(el);if(b.x<0||b.y<0||b.r>W().innerWidth||b.b>W().innerHeight)bad.push(`${name} is partly off screen (${b.x},${b.y} to ${b.r},${b.b})`);}
  // lean on a filament: the wheel must take it up as the same state the model says is there
  const dx=92,dy=-48,want=wheelSector(dx,dy);root.dispatchEvent(new (W().PointerEvent??W().MouseEvent)('pointermove',{clientX:x+dx,clientY:y+dy,bubbles:true}));await H.sleep(420);
  const hov=wh.S?.hov;if(want<0||hov!==want)bad.push(`leaning on a filament: the wheel took sector ${hov}, ${want} expected`);
  res.lines.push(`wheel at ${x},${y}: canvas ${pct(ik.lit)} lit (${pct(ik.mag)} magenta) · strip ${actor?actor.name:'nobody'} + ${people} to name · dice ${dice} (1d${wh.die} chosen) · bar: watch ${wh.watch?'ON':'off'}, edit${btn('lift')?', lift':''}${btn('burn')?', −1 Span':''} · leaning toward ${want>=0?CURSE_NOW[want].n:'?'}: ${hov===want?'taken up':'NOT taken up'} · on top: ${t.own?'itself':shortEl(t.top)}`);
  if(!actor)res.lines.push('nobody is chosen to be cursed: the wheel’s first button picks her from the selected token');
  // close with Escape
  W().dispatchEvent(new (W().KeyboardEvent)('keydown',{key:'Escape',bubbles:true,cancelable:true}));await until(H,()=>!count('.ff-cu-wheel'),1500);
  if(count('.ff-cu-wheel'))bad.push('Escape did not close the wheel');
  // the editor: opened, read, cancelled
  ctx.check();const on=rt.edit();await H.sleep(520);const ed=D().querySelector('.ff-cu-edit');
  if(!on||!ed)bad.push('the states’ editor did not open');
  else{
    const rows=[...ed.querySelectorAll('.ff-cu-row')],vals=rows.map(r=>({k:r.dataset.k,n:r.querySelector('[data-f=n]')?.value,w:r.querySelector('[data-f=w]')?.value,d:r.querySelector('[data-f=d]')?.value}));
    const off=vals.filter((v,i)=>v.k!==CURSE_NOW[i]?.k||v.n!==CURSE_NOW[i].n||v.w!==CURSE_NOW[i].w||v.d!==CURSE_NOW[i].d).map(v=>v.k),pane=ed.querySelector('.ff-cu-pane'),pb=pane?box(pane):null,te=pane?topOf(pane):null;
    if(rows.length!==6)bad.push(`the editor has ${rows.length} rows (6 expected)`);else if(off.length)bad.push(`the editor does not show the states as they read now: ${off.join(', ')}`);
    if(pb&&(pb.x<0||pb.y<0||pb.r>W().innerWidth||pb.b>W().innerHeight))bad.push(`the editor is partly off screen (${pb.x},${pb.y} to ${pb.r},${pb.b})`);
    if(te&&!te.own)bad.push(`the editor is covered by ${shortEl(te.top)}`);
    if(!ed.querySelector('[data-act="save"]')||!ed.querySelector('[data-act="cancel"]'))bad.push('the editor lacks Save or Cancel');
    const rowsEl=ed.querySelector('.ff-cu-rows'),scroll=rowsEl?rowsEl.scrollHeight>rowsEl.clientHeight+2:false;
    res.lines.push(`editor: ${rows.length} rows${off.length?'':' reading as the states do now'} · ${pb?`${pb.w}x${pb.h} at ${pb.x},${pb.y}`:'no pane'}${scroll?' · the rows scroll (the window is short)':''} · on top: ${te?.own?'itself':shortEl(te?.top)}`);
    ed.querySelector('[data-act="cancel"]')?.click();await until(H,()=>!count('.ff-cu-edit'),1500);if(count('.ff-cu-edit'))bad.push('Cancel did not close the editor');
  }
  // nothing laid, nothing saved, nothing left
  if(JSON.stringify(rt.record(actor))!==real||rt.stats.laid!==laid)bad.push('a curse was laid or changed by opening the wheel');
  if(JSON.stringify(H.setting(CURSE_WORLD))!==world)bad.push('the world’s setting changed');
  if(JSON.stringify(H.setting(CURSE_CLIENT))!==client)bad.push('this browser’s setting changed');
  if(bad.length)H.verdict(res,'FAIL',`wheel and editor: ${bad.join('; ')}`);
  else H.verdict(res,'PASS','the wheel opens round a point, is drawn, takes a lean and closes on Escape; the editor opens with the six states and cancels; nothing was laid or saved');
}

/* ================================================================ 4. HER VIEW */
async function v13view(ctx,res,H){
  const rt=RT(ctx),bad=[],look=[];if(!rt){H.verdict(res,'FAIL','the curse’s runtime is not there');return;}
  if(!rt.enabled()){res.skipped='The Heart Turned is switched off';return;}
  // a curse really showing here is left alone: its own small form is looked at where it sits
  const live=rt.view?.mode&&rt.view.mode!=='none'?rt.view.mode:rt.watcher?.mode==='full'?'watching':null;
  if(live){
    const el=live==='card'?rt.view.card:live==='mark'?rt.view.mark:null;
    if(el){const p=placed(el,`her ${live}`);res.lines.push(p.line);if(p.bad.length){H.verdict(res,'FAIL',p.bad.join('; '));return;}}
    H.verdict(res,'CHECK',`a curse is showing on this page now (${live}): ${el?`its ${live} sits where it should and is on top there; `:''}the dry run needs the page free, so run this part again once it has ended`);return;
  }
  if(count(SURFACES)){res.skipped='the wheel, the editor or a view is open now: close it and run this again';return;}
  const actor=rt.chosenActor(),real=JSON.stringify(rt.record(actor)),stats={...rt.stats},reduced=rt.reduced();let first=null;
  const done=(d)=>{try{d.end();d.view.clear();}catch{}};
  // ── one she rolls ──
  ctx.progress('Her view: a roll, on this screen only…');
  const d=rt.dry({state:null}),v=d.view;res.restore(async()=>{done(d);await H.sleep(80);});
  d.start();
  if(reduced){
    await until(H,()=>v.mode==='card'&&v.card?.classList.contains('ff-cu-on'),3000);if(v.mode!=='card'||!v.card){H.verdict(res,'FAIL','with reduced motion on, the curse did not come as the card');return;}
    await H.sleep(700);
    res.lines.push('reduced motion is on: the full view is not played; the card and the mark were checked');
  }else{
    const up=await until(H,()=>v.stage?.waiting('roll'),14000);ctx.check();
    if(!up){H.verdict(res,'FAIL',`the full view did not come up to its Roll (${d.errors[0]??`mode ${v.mode}`})`);return;}
    const t=topOf(v.cv,v.root),ik=ink(v.cv),S=v.stage.V,cs=W().getComputedStyle(v.root);
    res.lines.push(`full view: canvas ${v.cv.width}x${v.cv.height} for a ${W().innerWidth}x${W().innerHeight} window (x${f2(v.cv.width/Math.max(1,W().innerWidth))}) · stage scale ${f2(S?.S)} · ${pct(ik.lit)} lit, ${pct(ik.mag)} magenta · z ${cs.zIndex} · on top: ${t.own?'itself':shortEl(t.top)}`);
    if(!t.own)bad.push(`the full view is covered at its centre by ${shortEl(t.top)}`);
    if(!(ik.lit>.005))bad.push(`the full view’s canvas is not drawn on (${pct(ik.lit)} lit${ik.err?`, ${ik.err}`:''})`);
    // (13.0.0-beta.5) its paintings: all nine loaded from the module's own folder
    {const ar=v.stage.art,n=ar?.loaded?.()??0;res.lines.push(`paintings: ${n} of 10 loaded from ${ar?.base??'nowhere'}`);if(n<10)bad.push(`${10-n} of its 10 pictures did not load (${ar?.base??'no address'}): her flower or the thorns are missing from the view`);}
    // her roll, with the page's frames counted
    const fw=frameWatch(),t0=H.now();v.stage.press('roll');
    const got=await until(H,()=>v.stage?.waiting('root'),70000);const fs=fw.stop(),cost=v.stage?{...v.stage.stats}:null;ctx.check();
    if(!got){H.verdict(res,'FAIL',`her roll did not play through to the Spans (${d.errors[0]??`mode ${v.mode}`})`);return;}
    const rec=d.record(),L=v.stage.L,ik2=ink(v.cv);first=rollStyle(rec);
    if(L.style!==first)bad.push(`her roll was shown as ${L.style} where the curse takes ${first}`);
    res.lines.push(`her roll (${WAY_NAME[first]}): ${rec.k}${rec.toward?` toward ${rec.toward.n}`:namesSomeone(rec.k)?' (nobody to name)':' (all within 15 ft)'} in ${f1((H.now()-t0)/1000)} s · page frames ${f1(fs.med)}/${f1(fs.p95)}/${f1(fs.max)} ms (${fs.long} over 50 ms of ${fs.n}) · drawing ${f2(cost?.ms)} ms a frame, worst ${f1(cost?.worst)} · word shown: ${L.e?.n??'?'} · ${pct(ik2.lit)} lit`);
    if(L.e?.k!==rec.k)bad.push(`the view shows ${L.e?.k??'nothing'} where her roll was ${rec.k}`);
    if(cost&&cost.ms>12)bad.push(`drawing her view costs ${f1(cost.ms)} ms a frame`);else if(cost&&cost.ms>6)look.push(`drawing her view costs ${f1(cost.ms)} ms a frame (6 is the aim)`);
    if(fs.long>8)look.push(`${fs.long} frames of her roll took over 50 ms (longest ${Math.round(fs.max)} ms)`);
    // Minimise: the card
    await v.minimise();await until(H,()=>v.mode==='card'&&v.card?.classList.contains('ff-cu-on'),5000);await H.sleep(650);ctx.check();
    if(v.mode!=='card'||!v.card){H.verdict(res,'FAIL',`Minimise did not leave the card (mode ${v.mode}${d.errors[0]?`; ${d.errors[0]}`:''})`);return;}
    if(v.cv||count('.ff-cu-view'))bad.push('the full view’s canvas is still there behind the card');
  }
  // the card where it sits
  {const p=placed(v.card,'card');res.lines.push(`${p.line} · reads “${v.card.querySelector('.ff-cu-n')?.textContent??''}” · button “${v.card.querySelector('.ff-cu-btn')?.textContent??''}”`);bad.push(...p.bad);}
  if(reduced){
    // (no full view: the card's own buttons do the roll and the Spans)
    v.card.querySelector('.ff-cu-btn')?.click();await until(H,()=>!!d.record().k&&!v.busy,9000);v.card?.querySelector('.ff-cu-btn')?.click();await until(H,()=>v.mode==='mark',9000);
  }else{
    // Open: the card grows back; then she lets it root
    v.card.querySelector('.ff-cu-xp')?.click();const back=await until(H,()=>v.mode==='full'&&v.stage?.waiting('root'),9000);ctx.check();
    if(!back){H.verdict(res,'FAIL',`Open did not bring the full view back (mode ${v.mode}${d.errors[0]?`; ${d.errors[0]}`:''})`);return;}
    v.stage.press('root');await until(H,()=>v.mode==='mark',16000);
  }
  ctx.check();const rec=d.record();
  if(v.mode!=='mark'||!v.mark){H.verdict(res,'FAIL',`the Spans did not end at the mark (mode ${v.mode}${d.errors[0]?`; ${d.errors[0]}`:''})`);return;}
  if(!(rec.spans>=1&&rec.spans<=rec.die)||rec.until!==rec.at+rec.spans*SPAN_S)bad.push(`the Spans rolled do not add up (${rec.spans} of 1d${rec.die}, from ${rec.at} to ${rec.until})`);
  await H.sleep(700);
  {const p=placed(v.mark,'mark');res.lines.push(`${p.line} · reads “${String(v.mark.innerText??v.mark.textContent??'').split(/\n+/).map(x=>x.trim()).filter(Boolean).join(' · ').slice(0,70)}” · ${rec.spans} Span${rec.spans===1?'':'s'}`);bad.push(...p.bad);}
  if(!reduced&&rt.part('curseMarkOpen')){
    // the mark opens the finished picture, and Minimise puts it back
    v.markPressed();const op=await until(H,()=>v.mode==='full'&&v.stage?.L.minBtn>.9,7000);if(!op)bad.push('the mark did not open the full view');
    else{await H.sleep(500);const ik=ink(v.cv);if(!(ik.lit>.005))bad.push('the picture opened from the mark is not drawn');await v.minimise();await until(H,()=>v.mode==='mark',6000);if(v.mode!=='mark')bad.push('Minimise did not put the mark back');}
  }
  if(d.errors.length)bad.push(`her view reported: ${d.errors.slice(0,2).join(' | ')}`);
  done(d);await H.sleep(800);
  // ── one laid on her ──
  if(!reduced&&!bad.length){
    ctx.check();ctx.progress('Her view: one laid on her…');
    const ti=Math.floor(rt.rng()*6)%6,f=rt.dry({state:ti}),fv=f.view;res.restore(async()=>{done(f);await H.sleep(80);});
    const fw=frameWatch(),t0=H.now();f.start();const got=await until(H,()=>fv.stage?.waiting('root'),60000);const fs=fw.stop(),cost=fv.stage?{...fv.stage.stats}:null;ctx.check();
    if(!got)bad.push(`a state laid on her did not play through (${f.errors[0]??`mode ${fv.mode}`})`);
    else{
      const fr=f.record(),L=fv.stage.L;
      res.lines.push(`laid on her: ${CURSE_NOW[ti].n}${fr.toward?` toward ${fr.toward.n} (the roll of faith, as it was laid)`:''} in ${f1((H.now()-t0)/1000)} s · page frames ${f1(fs.med)}/${f1(fs.p95)}/${f1(fs.max)} ms (${fs.long} over 50 ms) · drawing ${f2(cost?.ms)} ms a frame, worst ${f1(cost?.worst)}`);
      if(L.e?.k!==CURSE_STATES[ti].k)bad.push(`the view shows ${L.e?.k??'nothing'} where ${CURSE_STATES[ti].k} was laid`);
      if(namesSomeone(fr.k)&&fr.people.length&&!fr.toward)bad.push('a state laid with nobody pinned named nobody');
      if(cost&&cost.ms>12)bad.push(`drawing the laid curse costs ${f1(cost.ms)} ms a frame`);
      fv.stage.press('root');await until(H,()=>fv.mode==='mark',16000);if(fv.mode!=='mark')bad.push('the laid curse did not end at the mark');
    }
    if(f.errors.length)bad.push(`her view reported: ${f.errors.slice(0,2).join(' | ')}`);
    done(f);await H.sleep(800);
  }
  // nothing written, nothing left
  const left=count(SURFACES);if(left)bad.push(`${left} piece(s) left on the page afterwards`);
  if(JSON.stringify(rt.record(actor))!==real)bad.push('the curse on her actor changed during the dry run');
  if(rt.stats.laid!==stats.laid||rt.stats.rolled!==stats.rolled||rt.stats.rooted!==stats.rooted)bad.push('the dry run was counted as a real curse');
  res.lines.push(`afterwards: ${left?`${left} PIECE(S) LEFT`:'nothing left on the page'} · her actor ${JSON.stringify(rt.record(actor))===real?'untouched':'CHANGED'} · no chat line, nothing sent to anyone`);
  if(bad.length)H.verdict(res,'FAIL',`her view: ${bad.join('; ')}`);
  else H.verdict(res,'PASS',reduced?'with reduced motion on, the curse comes as the card, rolls there and ends at the mark; both sit on screen, on top, clear of the sidebar':'her view plays her roll (the cutting) and a laid curse through, minimises to the card, opens again, roots and ends at the mark; each sits on screen and on top; nothing is left');
  for(const t of look)H.verdict(res,'CHECK',t);
}

/* ================================================================ 5. WATCHING */
async function v13watch(ctx,res,H){
  const rt=RT(ctx),g=globalThis.game,bad=[];if(!rt){H.verdict(res,'FAIL','the curse’s runtime is not there');return;}
  if(!g?.user?.isGM){res.skipped='watching is the GM’s';return;}
  if(!rt.enabled()){res.skipped='The Heart Turned is switched off';return;}
  const actor=rt.chosenActor(),p=actor?rt.presenter(actor):null,mine=p===g.user.id;
  res.lines.push(`watch her roll: ${rt.watching()?'ON':'off'} (the bar under the wheel) · her view is shown by ${p?(mine?'this page (her player is not connected: there is nothing to watch, you see it yourself)':(g.users?.get?.(p)?.name??p)):'nobody'}${rt.reduced()?' · reduced motion is ON: a watcher is not played':''}`);
  if(rt.watcher?.mode==='full'||(rt.view?.mode&&rt.view.mode!=='none')||count(SURFACES)){H.verdict(res,'CHECK','a curse, the wheel or the editor is showing on this page now: the watching view was not opened over it');return;}
  const d=rt.dry({state:Math.floor(rt.rng()*5)%5,watch:true}),v=d.view,rec=d.finish(),real=JSON.stringify(rt.record(actor));res.restore(async()=>{try{d.end();v.clear();}catch{}await H.sleep(80);});
  v.sync(rec,{fresh:false});
  if(v.mode!=='none'||count(SURFACES))bad.push('a watcher kept something on the page for a curse it did not see laid');
  void v.look();const up=await until(H,()=>v.mode==='full'&&v.stage?.L.minBtn>.9,9000);ctx.check();
  if(!up)bad.push(`the watching view did not open (${d.errors[0]??`mode ${v.mode}`})`);
  else{
    await H.sleep(600);const t=topOf(v.cv,v.root),ik=ink(v.cv),L=v.stage.L,words=watchWords(actor?.name);
    res.lines.push(`watching view: ${L.e?.n??'?'}${rec.toward?` toward ${rec.toward.n}`:''} · ${spansLeft(rec,rt.now())} Span${spansLeft(rec,rt.now())===1?'':'s'} · ${pct(ik.lit)} lit · top line “${words.laid}” · its button reads “${words.min}” · on top: ${t.own?'itself':shortEl(t.top)}`);
    if(L.e?.k!==rec.k)bad.push('the watching view shows another state than the record’s');
    if(!(ik.lit>.005))bad.push('the watching view is not drawn');if(!t.own)bad.push(`the watching view is covered by ${shortEl(t.top)}`);
    if(v.stage.waiting('roll')||v.stage.waiting('root'))bad.push('the watching view offers her buttons');
    await v.minimise();await until(H,()=>v.mode==='none'&&!count('.ff-cu-view'),4000);
    if(v.mode!=='none'||count(SURFACES))bad.push('closing the watching view left something on the page');
  }
  if(d.errors.length)bad.push(`the view reported: ${d.errors.slice(0,2).join(' | ')}`);
  if(JSON.stringify(rt.record(actor))!==real)bad.push('the curse on her actor changed');
  if(bad.length)H.verdict(res,'FAIL',`watching: ${bad.join('; ')}`);
  else H.verdict(res,'PASS','the GM’s watching view opens on a finished curse with no buttons of hers, and closes leaving nothing');
  if(!bad.length&&rt.watching()&&mine&&actor)H.verdict(res,'CHECK','Watch her roll is on, but no player of hers is connected: her view plays on this page itself, so there is nothing separate to watch');
}

/* ================================================================ 6. HER SHEET */
async function v13sheet(ctx,res,H){
  const rt=RT(ctx),bad=[],look=[];if(!rt){H.verdict(res,'FAIL','the curse’s runtime is not there');return;}
  const actor=rt.chosenActor()??(()=>{try{return herActor();}catch{return null;}})();if(!actor){res.skipped='nobody is chosen to be cursed, and no character is pinned in the HUD';return;}
  if(!rt.enabled()||!rt.part('curseSheet')){res.skipped=rt.enabled()?'the mark on her sheet is switched off (Settings › Her › Moods & milestones › The Heart Turned › Parts)':'The Heart Turned is switched off';return;}
  if(!keepsakeOn(actor)){res.skipped=`her Keepsake sheet is not on for you (HUD › Settings › Her character sheet); PF2e’s own sheet of ${actor.name} shows no mark`;return;}
  const sheet=actor.sheet;if(!sheet?.render){res.skipped='she has no sheet';return;}
  const elOf=x=>{const e=x?.[0]??x;return e&&e.nodeType===1?e:null;},wasOpen=!!sheet.rendered;
  res.restore(async()=>{try{for(const n of D().querySelectorAll('[data-ff-curse-check]'))n.remove();}catch{}try{if(!wasOpen&&sheet.rendered)await sheet.close();}catch{}});
  // it has to open to play its opening: one that is open is closed first, and left open afterwards as it was
  if(wasOpen){try{await sheet.close();}catch{}await until(H,()=>!sheet.rendered,3000);await H.sleep(350);}
  const wanted=openFxWanted();let bar=0,clip=0,watching=true;
  const watch=()=>{if(!watching)return;try{if(D().querySelector('.ff-hud-open-scan'))bar++;const el=elOf(sheet.element);if(el&&el.getAnimations?.().some(a=>{try{return a.effect?.getKeyframes?.().some(k=>'clipPath' in k);}catch{return false;}}))clip++;}catch{}W().requestAnimationFrame(watch);};
  W().requestAnimationFrame(watch);const t0=H.now();
  await sheet.render(true);const dressed=await until(H,()=>{const el=elOf(sheet.element);return el&&isDressed(sheet)&&el.querySelector('.ffks-chips');},7000);
  await H.sleep(HUD_OPEN_MS+350);watching=false;ctx.check();
  const el=elOf(sheet.element);
  if(!dressed||!el){H.verdict(res,'FAIL','her Keepsake sheet did not open dressed (no header with her conditions)');return;}
  const leftBar=count('.ff-hud-open-scan');
  res.lines.push(`opening: ${wanted?'the Hardlight scan is on':'no animation is chosen, or reduced motion is on'} · the edge was on screen for ${bar} frame${bar===1?'':'s'}, the window’s reveal for ${clip} · opened in ${Math.round(H.now()-t0-HUD_OPEN_MS-350)} ms · ${leftBar?'THE EDGE IS STILL THERE':'nothing left of it'}`);
  if(wanted&&(!bar||!clip))bad.push(`her sheet opened without its scan (edge ${bar} frames, reveal ${clip})`);
  if(!wanted&&(bar||clip))bad.push('her sheet played the opening scan though it is switched off');
  if(leftBar)bad.push('the scan’s edge was left on the page');
  // the mark among her conditions
  const chips=el.querySelector('.ffks-chips'),rec=rt.record(actor),shown=chips.querySelector('.ffks-curse[data-ff-curse]'),others=[...chips.querySelectorAll('.ffks-cchip:not(.ffks-curse)')];
  const want=!!rec&&rt.enabled()&&!curseOver(rec,rt.now())&&actor.isOwner;
  let chip=shown,probe=false;
  if(want&&!shown)bad.push('she is cursed, but her sheet shows no mark among her conditions');
  if(!want&&shown)bad.push('her sheet shows a mark though no curse is on her');
  if(!chip){
    // no curse on her: a mark is put there for a moment, as it would read, to be measured (it is not on her actor)
    const sample=rootCurse(rollCurse(newCurse({state:4,people:[{id:'',n:'Someone',img:''}],die:4,faith:()=>0}),()=>0).record,rt.now(),()=>.99).record;
    chip=D().createElement('button');chip.type='button';chip.className='ffks-cchip ffks-curse named';chip.dataset.ffCurseCheck='1';rt.fillChip(chip,sample);chips.prepend(chip);probe=true;await H.sleep(120);
  }
  const b=box(chip),cs=W().getComputedStyle(chip),ob=others[0]?box(others[0]):null,nm=chip.querySelector('.nm'),val=chip.querySelector('.v'),t=topOf(chip),hb=box(el),first=chips.firstElementChild===chip;
  const clipped=nm?nm.scrollWidth>nm.clientWidth+1:false;
  res.lines.push(`mark on her sheet${probe?' (a sample, put there for the measure and taken off)':''}: “${nm?.textContent??''}”${val?` ${val.textContent}`:''} · ${b.w}x${b.h}${ob?` beside chips ${ob.h} high`:''} · ${first?'first in the row':'NOT first'} · ground ${cs.backgroundColor} · font ${String(W().getComputedStyle(nm??chip).fontFamily).split(',')[0]} · on top: ${t.own?'itself':shortEl(t.top)}${clipped?' · ITS NAME IS CUT':''}`);
  if(b.h<20||b.w<40)bad.push(`the mark has no size (${b.w}x${b.h})`);
  if(ob&&Math.abs(ob.h-b.h)>1)bad.push(`the mark is ${b.h} px high beside chips of ${ob.h}`);
  if(!first)bad.push('the mark is not first among her conditions');
  if(!/Keepsake/i.test(String(W().getComputedStyle(nm??chip).fontFamily)))bad.push('the mark is not in the module’s lettering (styles/curse.css did not reach the sheet)');
  if(b.x<hb.x||b.r>hb.r)bad.push('the mark runs out of the sheet');else if(!t.own)look.push(`the mark is covered by ${shortEl(t.top)} (the sheet may be behind another window)`);
  if(clipped)look.push('the state’s name is too long for the mark on her sheet and is cut');
  if(!/^rgba?\(1[0-9], 1[0-9], 1[0-9]/.test(cs.backgroundColor)&&!/^rgba?\(2[0-9], 1[0-9], 2[0-9]/.test(cs.backgroundColor))look.push(`the mark’s ground is ${cs.backgroundColor} (near black expected)`);
  if(probe)chip.remove();
  if(wasOpen)res.lines.push('her sheet was open before: it was closed and opened again for this, and is left open');
  if(bad.length)H.verdict(res,'FAIL',`her sheet: ${bad.join('; ')}`);
  else H.verdict(res,'PASS',`her Keepsake sheet ${wanted?'opens with the Hardlight scan':'opens without the scan, as chosen'} and the curse’s mark sits first among her conditions, the same height as the rest`);
  for(const x of look)H.verdict(res,'CHECK',x);
}

/* ───────── its sound (beta.4) ───────── */
async function v13sound(ctx,res,H){
  const rt=RT(ctx),g=globalThis.game,bad=[],look=[];if(!rt){H.verdict(res,'FAIL','the curse’s runtime is not there');return;}
  const on=rt.sounding(),bed=rt.part('curseBed'),level=rt.soundLevel(),name=Object.entries(CURSE_VOLUMES).find(([,v])=>v===level)?.[0]??String(level);
  let core=null;try{core=g?.settings?.get?.('core','globalInterfaceVolume');}catch{}
  const locked=g?.audio?.locked,ctxOk=!!(g?.audio?.interface??g?.audio?.environment),Sound=globalThis.foundry?.audio?.Sound;
  res.lines.push(`sound ${on?'ON':'off (as it comes: Settings › Her › Moods & milestones › The Heart Turned › Sound)'} · the wind under it ${bed?'on':'off'} · how loud: ${name} · Foundry’s Interface volume ${Number.isFinite(core)?pct(core):'?'} · audio ${locked===true?'LOCKED (nothing has been clicked on this page yet)':locked===false?'unlocked':'?'}`);
  if(typeof Sound!=='function')bad.push('Foundry’s Sound class is not there (foundry.audio.Sound)');if(!ctxOk)bad.push('Foundry has no interface audio context (game.audio.interface)');
  if(on&&Number.isFinite(core)&&core<=0)look.push('the sound is on but Foundry’s Interface volume is at nothing: it will not be heard');
  // every moment the stage raises means something to the player, and every sound it names is one of the recordings
  const lost=CURSE_CUES.filter(c=>!knowsCue(c)),odd=Object.keys(CURSE_SHOTS).filter(c=>!CURSE_SOUND_FILES.includes(shotFor(c)?.f));
  if(lost.length)bad.push(`the stage raises moments the sound does not know: ${lost.join(', ')}`);if(odd.length)bad.push(`moments that name a recording that is not shipped: ${odd.join(', ')}`);
  // the recordings: fetched, never played
  const t0=performance.now();let bytes=0;const missing=[],notOgg=[];
  await Promise.all(CURSE_SOUND_FILES.map(async f=>{try{const r=await fetch(rt.soundSrc(f),{cache:'no-cache'});if(!r.ok){missing.push(`${f} (${r.status})`);return;}const b=new Uint8Array(await r.arrayBuffer());bytes+=b.length;if(!(b[0]===0x4f&&b[1]===0x67&&b[2]===0x67&&b[3]===0x53))notOgg.push(f);}catch(e){missing.push(`${f} (${String(e?.message??e).slice(0,30)})`);}}));
  res.lines.push(`recordings: ${CURSE_SOUND_FILES.length-missing.length}/${CURSE_SOUND_FILES.length} there · ${Math.round(bytes/1024)} kB in all · fetched in ${Math.round(performance.now()-t0)} ms · ${CURSE_CUES.length} moments, ${Object.keys(CURSE_SHOTS).length} with a sound of their own`);
  if(missing.length)bad.push(`recordings missing: ${missing.join(', ')} (${rt.soundSrc('…')})`);if(notOgg.length)bad.push(`not OGG files: ${notOgg.join(', ')}`);
  // decoded only with the sound on: off, nothing of it is loaded at all
  if(on&&typeof Sound==='function'){
    const t1=performance.now();await Promise.race([rt.warmSound(),H.sleep(20000)]);const st=rt.api().sounds();
    res.lines.push(`decoded: ${st.loaded.length}/${CURSE_SOUND_FILES.length} in ${Math.round(performance.now()-t1)} ms${st.failed.length?` · WOULD NOT DECODE: ${st.failed.join(', ')}`:''} · played since this page loaded: ${st.shots??0} one shots, ${st.loops??0} loops, ${st.skipped??0} skipped`);
    if(st.failed.length)bad.push(`recordings that would not decode: ${st.failed.join(', ')}`);else if(st.loaded.length<CURSE_SOUND_FILES.length)bad.push(`only ${st.loaded.length} of ${CURSE_SOUND_FILES.length} recordings loaded`);
    if((st.skipped??0)>(st.shots??0)&&(st.skipped??0)>8)look.push(`${st.skipped} sounds were skipped (${st.shots} played): the recordings were not ready when her view started`);
  }else res.lines.push(`decoded: nothing (with the sound off none of it is loaded) · api.curse.hear('cut') plays one to try it`);
  const errs=rt.errors.filter(e=>/sound/i.test(e.where));if(errs.length)bad.push(`${errs.length} thing(s) went wrong in its sound: ${errs.slice(-2).map(e=>`${e.where}: ${e.msg}`).join(' | ')}`);
  if(bad.length)H.verdict(res,'FAIL',bad.join(' · '));else if(look.length)H.verdict(res,'CHECK',look.join(' · '));else H.verdict(res,'PASS',on?'its sound is on, every recording is there and decodes':'its sound is off; every recording is there for when it is switched on');
}

export const V13_RUN=Object.freeze({v13setup,v13record,v13wheel,v13view,v13watch,v13sheet,v13sound});
/** What the V13 part must not leave behind. */
export function v13Residue(ctx){
  const out=[],rt=RT(ctx);
  try{const actor=rt?.chosenActor?.();if(actor?.getFlag?.(ID,SCRATCH_FLAG)!==undefined)out.push('the check’s scratch note on her actor');}catch{}
  try{if(count('[data-ff-curse-check]'))out.push('the check’s sample mark on her sheet');if(count('.ff-cu-wheel,.ff-cu-edit'))out.push('the curse wheel or its editor');
    if(!(rt?.view?.mode&&rt.view.mode!=='none')&&rt?.watcher?.mode!=='full'&&count('.ff-cu-view,.ff-cu-card,.ff-cu-mark'))out.push('a piece of her curse’s view');}catch{}
  return out;
}
