import {resonantBitGeometry} from './bit-resonance.mjs?v=13.0.1';

/** The unrotated, unscaled solid housing: [x,y,padding] per point, or null for
 * image housings. It is the expensive part of compactSolidBounds, so callers
 * holding depth across several artwork samples may reuse it briefly. */
export function compactSolidOutline(hardware={}){
  if(hardware.artwork!=='resonant')return null;
  const points=[];
  for(const part of resonantBitGeometry(hardware)){
    if(part.id.startsWith('bearing-current-'))continue;
    const padding=part.stroke?(part.width??0)/2:0;
    for(const [x,y]of part.points)points.push([x,y,padding]);
  }
  return points;
}

/** Solid housing bounds shared by the scene and private rehearsal. Cosmetic
 * currents do not decide when a physical tool can cross the patient plane. */
export function compactSolidBounds(hardware={},outline=compactSolidOutline(hardware)){
  const angle=hardware.angle??0,scale=Math.abs(hardware.scale??1),c=Math.cos(angle),s=Math.sin(angle);
  if(hardware.artwork!=='resonant'||!outline){const radius=48*scale+.75;return {minX:-radius,maxX:radius,minY:-radius,maxY:radius};}
  let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
  for(const [x,y,pad]of outline){
    const padding=pad*scale+.75,px=(x*c-y*s)*scale,py=(x*s+y*c)*scale;
    minX=Math.min(minX,px-padding);maxX=Math.max(maxX,px+padding);minY=Math.min(minY,py-padding);maxY=Math.max(maxY,py+padding);
  }
  return {minX,maxX,minY,maxY};
}

/** Keep sorting until the entire housing has cleared the token rectangle. */
export function compactDepthFront(point,previous,{halfWidth=600/7,halfHeight=600/7,bounds=null}={}){
  const wanted=point[2]>=0;
  if(previous===undefined||previous===wanted)return wanted;
  const b=bounds??{minX:0,maxX:0,minY:0,maxY:0};
  return point[0]+b.maxX<=-halfWidth||point[0]+b.minX>=halfWidth||point[1]-15+b.maxY<=-halfHeight||point[1]-15+b.minY>=halfHeight?wanted:previous;
}
