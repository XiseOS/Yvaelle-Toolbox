/** Yvaelle’s Toolbox v12 · Decoy: the runtime (what is drawn, and the commands).
 *
 * One mesh per decoy on the board, at her token's place in the order, painted
 * from a still copy of her taken the moment the decoy is made (warp-capture:
 * her token art and every wing layer, flattened). Every client makes its own
 * copy when the synced flag arrives, and draws the same thing from the flag.
 *
 * Cost: nothing at all without a decoy (no ticker, no mesh, one flag read on
 * a token update). A standing decoy is one mesh and a ticker that sets its
 * alpha and place; its surface is painted only while it appears, changes look
 * or comes apart (at most 30 times a second, for under a second each), and
 * once more when it settles. */
import {ID} from '../config.mjs?v=13.0.1';
import {effectMeshClass,placeBehind} from '../renderer.mjs?v=13.0.1';
import {captureHer,composite,bodyPose} from '../warp-capture.mjs?v=13.0.1';
import {forceDelete} from '../forced-delete.mjs?v=13.0.1';
import {cue12} from './sound-set.mjs?v=13.0.1';
import {isOn,choice} from '../v11/features.mjs?v=13.0.1';
import {DECOY_FLAG,DECOY_T,DECOY_CORNERS,DECOY_CAST_DELAY,validDecoy,decoyFlag,withLook,withEnd,decoyState,decoyOver,decoyCorners,bandNormal,decoyCells,cellDrift,lookOf,kindOf,h2} from './decoy.mjs?v=13.0.1';

const MAG='255,0,255',PALE='255,214,250';
const PAD=64,MAX_SIDE=640,PAINT_MS=1000/30,FLICKER_MS=1000/12,BAND=14;
const unit=x=>x<0?0:x>1?1:x,lerp=(a,b,k)=>a+(b-a)*k;
const serverNow=()=>Number(globalThis.game?.time?.serverTime)||Date.now();

/** Her token art as something a 2D canvas can draw: what her mesh is showing; where that cannot be drawn from (a
 * compressed texture), her art's file, loaded once (null until it has loaded: the decoy is built on a later try). */
const ART=new Map();
function artOf(token){
  const tex=token?.mesh?.texture,src=tex?.baseTexture?.resource?.source??tex?.baseTexture?.resource?.bitmap??null;
  if(src&&(src.width>1||src.naturalWidth>1||src.videoWidth>1))return src;
  const url=token?.document?.texture?.src;if(!url||typeof Image!=='function')return null;
  let img=ART.get(url);
  if(!img){if(ART.size>8)ART.clear();img=new Image();img.crossOrigin='anonymous';img.decoding='async';img.src=url;ART.set(url,img);}
  return img.complete&&img.naturalWidth>1?img:null;
}
/** The copy in magenta light: her picture washed a third of the way to magenta, every third line thinned (a projection's scan lines). */
function hardlightOf(canvas,res){
  const c=document.createElement('canvas');c.width=canvas.width;c.height=canvas.height;const g=c.getContext('2d');
  g.drawImage(canvas,0,0);g.globalCompositeOperation='source-atop';g.fillStyle=`rgba(${MAG},.34)`;g.fillRect(0,0,c.width,c.height);
  g.globalCompositeOperation='destination-out';g.fillStyle='rgba(0,0,0,.42)';const step=Math.max(2,Math.round(3*res));
  for(let y=0;y<c.height;y+=step)g.fillRect(0,y,c.width,Math.max(1,Math.round(step/3)));
  g.globalCompositeOperation='source-over';return c;
}

class Decoy{
  constructor(token,flag){this.token=token;this.flag=flag;this.id=flag.id;this.mesh=null;this.surface=null;this.ctx=null;this.texture=null;this.ready=false;
    this.paintedAt=-1;this.settled=null;this.flickAt=-1;this.heldAt=-1;this.sayAt=null;this.sawLook=flag.look;this.sawEnd=!!flag.end;this.triedAt=-1;this.tries=0;this.failed=false;this.finishing=false;this.seen=true;this.cells=null;}
  get doc(){return this.token.document;}
}

export class DecoyRuntime{
  constructor({manager=null,now=serverNow,bits=()=>null,warp=null,warpLeave=null}={}){
    this.manager=manager;this.now=now;this.bits=bits;this.warp=warp;this.warpLeave=warpLeave;this.records=new Map();this.ticking=false;this.installed=false;
    this.stats={made:0,paints:0,uploads:0,ended:0};
  }
  install(){
    if(this.installed||!globalThis.Hooks)return;this.installed=true;
    Hooks.on('canvasReady',()=>{this.dropAll();this.syncAll();});
    Hooks.on('canvasTearDown',()=>this.dropAll());
    Hooks.on('updateToken',(doc,changes)=>{const fl=changes?.flags?.[ID];if(fl===undefined)return;if(DECOY_FLAG in fl||`-=${DECOY_FLAG}` in fl||this.records.has(doc.object))this.sync(doc.object);});
    Hooks.on('deleteToken',doc=>{const R=this.records.get(doc.object);if(R)this.drop(R);});
    Hooks.on('sightRefresh',()=>{for(const R of this.records.values())this.look(R);});
  }
  flagOf(token){try{const f=token?.document?.getFlag?.(ID,DECOY_FLAG);return validDecoy(f)?f:null;}catch{return null;}}
  syncAll(){for(const t of globalThis.canvas?.tokens?.placeables??[])this.sync(t);}
  sync(token){
    if(!token||token.destroyed)return;const flag=this.flagOf(token),R=this.records.get(token);
    if(!flag||(flag.end&&decoyOver(flag,this.now())&&!R)){if(R)this.drop(R);return;}
    if(R&&R.id===flag.id){
      // (12.0.0-beta.7) the v12 sound set: its change of look, and its coming apart (each once, as it begins)
      // (what the record last saw is kept as plain values: a document may hand back the same flag object, changed in place)
      const now=this.now(),ended=!!flag.end;
      if(ended&&!R.sawEnd){if(now-flag.end.at<700)cue12(token,'decoy','break');}
      else if(!ended&&flag.look!==R.sawLook&&now-flag.lookAt<700)cue12(token,'decoy','look');
      R.sawEnd=ended;R.sawLook=flag.look;R.flag=flag;R.settled=null;this.wake();return;}
    if(R)this.drop(R);
    const N=new Decoy(token,flag);this.records.set(token,N);this.stats.made++;
    // (beta.7) its sound: a cast decoy's begins as her bits set off; one left by a warp flickers in as she leaves (tick)
    if(!flag.end){const age=this.now()-flag.at;if(flag.kind==='cast'){if(age<900)cue12(token,'decoy','cast');}else if(age<900)N.sayAt=flag.at;}
    try{this.build(N);}catch(error){N.ready=false;console.warn('Yvaelle’s Toolbox | v12 decoy (copying her)',error);}
    this.wake();
  }
  /** Her copy, its two pictures and the mesh. (Made when the flag arrives: she still stands where the decoy will.) */
  build(R){
    R.tries++;R.triedAt=performance.now();
    const token=R.token,art=artOf(token),cap=art?captureHer(token,art):null;
    if(!cap){R.ready=false;return;}
    const comp=composite(cap,{wings:true,portrait:true,res:1.5}),size=cap.size,pose=cap.pose??{dx:0,dy:0};
    // the rectangle the decoy may draw in, from its ground centre: her lifted figure, her ground shadow, her bits' beams (cast), and room to come apart
    let x0=Math.min(comp.x0+pose.dx,-size*.6),x1=Math.max(comp.x1+pose.dx,size*.6),y0=Math.min(comp.y0+pose.dy,-size*.6),y1=Math.max(comp.y1+pose.dy,size*.75);
    const lift=Number(R.flag.lift)||0;
    if(R.flag.kind==='cast')for(const [cx,cy] of DECOY_CORNERS){x0=Math.min(x0,cx*size);x1=Math.max(x1,cx*size);y0=Math.min(y0,cy*size+lift);y1=Math.max(y1,cy*size+lift);}
    x0-=PAD;y0-=PAD;x1+=PAD;y1+=PAD;
    const res=Math.min(1.5,MAX_SIDE/Math.max(x1-x0,y1-y0));
    const surface=document.createElement('canvas');surface.width=Math.max(2,Math.ceil((x1-x0)*res));surface.height=Math.max(2,Math.ceil((y1-y0)*res));
    const texture=PIXI.Texture.from(surface,{mipmap:PIXI.MIPMAP_MODES?.OFF??0});
    const Mesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
    const mesh=new Mesh({name:`${ID}.${token.id}.decoy`,texture},Shader);
    mesh.anchor.set(-x0/(x1-x0),-y0/(y1-y0));mesh.eventMode='none';mesh.interactive=false;mesh.visible=false;mesh.width=x1-x0;mesh.height=y1-y0;
    canvas.primary.addChild(mesh);
    Object.assign(R,{cap,comp,size,pose,box:{x0,y0,x1,y1},res,surface,ctx:surface.getContext('2d'),texture,mesh,hard:hardlightOf(comp.canvas,comp.res),ready:true,
      elevation:token.mesh?.elevation??token.document?.elevation??0,sort:token.mesh?.sort??0,sortLayer:token.mesh?.sortLayer??700,owner:!!token.document?.isOwner||!!globalThis.game?.user?.isGM});
    this.look(R);
  }
  /** Can this player see the spot? (A decoy behind a wall must not show through it; the GM sees all.) */
  look(R){
    if(globalThis.game?.user?.isGM){R.seen=true;return;}
    try{R.seen=globalThis.canvas?.visibility?.testVisibility?.({x:R.flag.x,y:R.flag.y},{tolerance:Math.max(4,(R.size??100)*.25)})!==false;}catch{R.seen=true;}
  }
  drop(R){
    const {mesh,surface}=R;
    if(mesh&&!mesh.destroyed){mesh.parent?.removeChild(mesh);mesh.destroy({children:true,texture:true,baseTexture:true});}
    if(surface)surface.width=surface.height=1;
    this.records.delete(R.token);if(!this.records.size)this.stopTicker();
  }
  dropAll(){for(const R of [...this.records.values()])this.drop(R);}

  /* ---------------- the ticker (only while a decoy exists) ---------------- */
  wake(){if(this.ticking)return;const ticker=globalThis.canvas?.app?.ticker;if(!ticker)return;this.ticking=true;ticker.add(this.tick,this,-13);}
  stopTicker(){if(!this.ticking)return;this.ticking=false;globalThis.canvas?.app?.ticker?.remove(this.tick,this);}
  tick(){
    const now=this.now(),local=performance.now();
    for(const R of [...this.records.values()]){
      try{
        if(!R.token||R.token.destroyed||R.token.document?.parent?.id!==globalThis.canvas?.scene?.id){this.drop(R);continue;}
        const st=decoyState(R.flag,now);
        if(R.sayAt!=null&&now>=R.sayAt){R.sayAt=null;if(!R.flag.end)cue12(R.token,'decoy','appear');}
        if(st.phase==='gone'){if(R.mesh&&R.mesh.visible)R.mesh.visible=false;this.finish(R,now);continue;}
        if(!R.ready){
          // her picture could not be copied yet (her art still loading): a few more tries, then this screen gives up.
          // The one who made it then ends it, so a decoy nobody can draw does not hold her bits.
          if(R.failed||local-R.triedAt<400)continue;
          try{this.build(R);}catch(error){R.ready=false;console.warn('Yvaelle’s Toolbox | v12 decoy (copying her)',error);}
          if(!R.ready){if(R.tries>=8){R.failed=true;this.stats.failed=(this.stats.failed??0)+1;
            if(this.mine(R,now)){globalThis.ui?.notifications?.warn?.('Decoy: her picture could not be copied on this screen, so the decoy was ended.');void this.clear(R.doc,R.flag).catch(()=>{});}}
            continue;}
        }
        // a cast decoy lasts as long as her bits hold it: once none of them is at its corners (they were called home,
        // she landed, her bits were put away), it comes apart. Looked at once a second, by the one who made it.
        if(R.flag.kind==='cast'&&!R.flag.end&&local-R.heldAt>=1000){R.heldAt=local;if(now-R.flag.at>1500&&this.mine(R,now)&&!this.held(R))void this.dismiss(R.token).catch(()=>{});}
        // paint while it moves (at most 30 a second), and once when it has settled into a look
        const key=`${R.flag.look}:${R.flag.kind}`;
        if(st.moving?local-R.paintedAt>=PAINT_MS:R.settled!==key){this.paint(R,st,now);R.paintedAt=local;R.settled=st.moving?null:key;}
        const m=R.mesh,t=now/1000;
        // hovering as she does when the copy was taken in the air (a small slow bob; the hardlight look also flickers a little)
        const bob=R.pose.dy<-2&&!R.flag.end?Math.sin(t*1.7+R.flag.at%7)*R.size*.018:0;
        m.x=R.flag.x;m.y=R.flag.y+bob;
        if(local-R.flickAt>=FLICKER_MS){R.flickAt=local;m.alpha=lerp(.86+.08*Math.sin(t*23),1,st.mix);}
        const show=R.seen!==false;if(m.visible!==show)m.visible=show;
        placeBehind(m,R,.5);
      }catch(error){console.error('Yvaelle’s Toolbox | v12 decoy',error);this.drop(R);}
    }
    if(!this.records.size)this.stopTicker();
  }
  /** One picture of the decoy at this moment. */
  paint(R,st,now){
    const g=R.ctx,{x0,y0}=R.box,res=R.res,t=now/1000,seed=Math.floor(t*24);
    g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,R.surface.width,R.surface.height);
    g.setTransform(res,0,0,res,-x0*res,-y0*res);                       // (world px from the decoy's ground centre)
    const C=R.comp,fx=C.x0+R.pose.dx,fy=C.y0+R.pose.dy,fw=C.x1-C.x0,fh=C.y1-C.y0;
    const figure=(src,alpha,glitch)=>{
      if(alpha<=.004)return;g.save();g.globalAlpha=unit(alpha);
      if(!(glitch>.01))g.drawImage(src,fx,fy,fw,fh);
      else{const rows=Math.ceil(fh/6),sh=src.height/rows;for(let i=0;i<rows;i++){const on=h2(i,seed)<glitch*.7,dx=on?(h2(i+5,seed)-.5)*28*glitch:0;g.drawImage(src,0,i*sh,src.width,sh,fx+dx,fy+i*6,fw,6.4);}}
      g.restore();};
    const shadow=a=>{if(a<=.004)return;const rx=R.size*.42,ry=R.size*.16,cy=R.size*.34;const gr=g.createRadialGradient(0,cy,rx*.1,0,cy,rx);gr.addColorStop(0,`rgba(0,0,0,${.34*a})`);gr.addColorStop(1,'rgba(0,0,0,0)');
      g.save();g.translate(0,cy);g.scale(1,ry/rx);g.translate(0,-cy);g.fillStyle=gr;g.beginPath();g.arc(0,cy,rx,0,Math.PI*2);g.fill();g.restore();};
    const hardlight=(a,glitch=0)=>{shadow(.35*a);figure(R.hard,a,glitch);};
    const normal=a=>{shadow(a);figure(C.canvas,a,0);};
    if(st.phase==='end'){
      // a blow or a dismissal: torn sideways, then its pieces drift apart and go
      const k=st.end,tear=DECOY_T.tear/DECOY_T.end;
      if(k<tear)hardlight(1,k/tear);
      else{const q=(k-tear)/(1-tear),cells=R.cells??=decoyCells(R.hard.width,R.hard.height,Math.max(10,Math.round(30*C.res))),s=1/C.res;
        for(const c of cells){const d=cellDrift(c,q),a=d.alpha*(h2(c.x,seed)>.25?1:.3);if(a<=.01)continue;
          g.globalAlpha=a;g.drawImage(R.hard,c.x,c.y,c.s,c.s,fx+c.x*s+d.dx,fy+c.y*s+d.dy,c.s*s+.6,c.s*s*.55);}
        g.globalAlpha=1;}
    }else{
      // appearing: it flickers in; a change of look runs through her in bands
      const a=st.born<1?(h2(seed,3)>.35?st.born:st.born*.3):1,glitch=(1-st.born)*.9;
      if(st.mix<=.001)hardlight(a,glitch);else if(st.mix>=.999)normal(a);
      else{const top=y0,n=Math.ceil((R.box.y1-y0)/BAND);
        for(const want of [false,true]){g.save();g.beginPath();for(let i=0;i<n;i++)if(bandNormal(i,st.mix)===want)g.rect(x0,top+i*BAND,R.box.x1-x0,BAND);g.clip();want?normal(a):hardlight(a,.5);g.restore();}
        // (a few pale lines where a band has just turned, across her figure only)
        const mx=fx+fw/2,my=fy+fh/2,hw=Math.min(fw*.5,R.size*.62);g.strokeStyle=`rgba(${PALE},.55)`;g.lineWidth=1.1;g.beginPath();
        for(let i=0;i<n;i++){const ly=top+i*BAND;if(Math.abs(ly-my)>R.size*.55)continue;if(bandNormal(i,st.mix)&&h2(i,seed)>.6){const w=hw*(.55+.45*h2(i,11));g.moveTo(mx-w,ly);g.lineTo(mx+w,ly);}}g.stroke();}
      // cast: each bit throws a narrow cone of light onto her figure (soft, brightest at the bit; dimmer once she looks real)
      if(R.flag.kind==='cast'&&a>.01){const n=Math.max(1,Math.min(4,R.flag.jobs?.length||4)),dim=lerp(1,.35,st.mix)*a,lift=Number(R.flag.lift)||0,mx=fx+fw/2,my=fy+fh/2;
        for(let i=0;i<n;i++){const [cx,cy]=DECOY_CORNERS[i],bx=cx*R.size,by=cy*R.size+lift,tx=mx+Math.sign(cx)*R.size*.2,ty=my+Math.sign(cy)*R.size*.16;
          const L=Math.hypot(tx-bx,ty-by)||1,nx=-(ty-by)/L,ny=(tx-bx)/L,w=R.size*.2,k=.62+.38*Math.sin(t*9+i*1.7);
          const gr=g.createLinearGradient(bx,by,tx,ty);gr.addColorStop(0,`rgba(${PALE},${.5*dim*k})`);gr.addColorStop(.18,`rgba(${MAG},${.3*dim*k})`);gr.addColorStop(1,`rgba(${MAG},0)`);
          g.fillStyle=gr;g.beginPath();g.moveTo(bx,by);g.lineTo(tx+nx*w,ty+ny*w);g.lineTo(tx-nx*w,ty-ny*w);g.closePath();g.fill();}}
      // her owner and the GM: a small mark under a decoy that looks real, so they never mistake it
      if(R.owner&&st.mix>.5){const my=R.size*.62;g.save();g.translate(0,my);g.strokeStyle=`rgba(${MAG},${.8*st.mix*a})`;g.lineWidth=1.4;g.beginPath();g.moveTo(0,-7);g.lineTo(5,0);g.lineTo(0,7);g.lineTo(-5,0);g.closePath();g.stroke();g.restore();}
    }
    R.texture.baseTexture.update?.();R.texture.update?.();this.stats.paints++;this.stats.uploads++;
  }
  /** Is any of her bits still at a cast decoy's corners? (true when it cannot be told) */
  held(R){
    try{const jobs=R.flag.jobs??[];if(!jobs.length)return false;const tasks=this.bits()?.getToolState?.(R.doc)?.tasks;if(!Array.isArray(tasks))return true;
      return tasks.some(t=>jobs.includes(t.id));}catch{return true;}
  }
  /** Is this client the one that looks after this decoy (who made it; if they have gone, her first owner)? */
  mine(R,now=this.now()){
    const doc=R.doc,by=R.flag.by,me=globalThis.game?.user;if(!doc?.isOwner&&!me?.isGM)return false;
    return by===me?.id||(!globalThis.game?.users?.get?.(by)?.active&&this.isWriter(doc));
  }
  /** The break-up is over: the one who made it (or, if they have gone, her first owner) calls her bits home and clears the flag. */
  finish(R,now){
    if(R.finishing)return;const doc=R.doc,by=R.flag.by,me=globalThis.game?.user;
    const mine=by===me?.id||((!globalThis.game?.users?.get?.(by)?.active||now-R.flag.end.at>DECOY_T.end*1000+1500)&&this.isWriter(doc));
    if(!mine||(!doc.isOwner&&!me?.isGM)){if(now-R.flag.end.at>DECOY_T.end*1000+6000)this.drop(R);return;}
    R.finishing=true;this.stats.ended++;
    void this.clear(doc,R.flag).catch(error=>console.warn('Yvaelle’s Toolbox | v12 decoy (ending)',error)).finally(()=>{const cur=this.records.get(R.token);if(cur===R)this.drop(R);});
  }
  isWriter(doc){
    const users=[...(globalThis.game?.users??[])].filter(u=>u.active),owns=u=>{try{return doc.testUserPermission?.(u,'OWNER')??false;}catch{return false;}};
    const players=users.filter(u=>!u.isGM&&owns(u)),pool=players.length?players:users.filter(u=>u.isGM);pool.sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);
    return (pool[0]?.id??globalThis.game?.user?.id)===globalThis.game?.user?.id;
  }
  /** Her bits home (cast) and the flag gone. */
  async clear(doc,flag){
    const bits=this.bits();
    for(const id of flag?.jobs??[])try{await bits?.stopTool?.(doc,{id});}catch{}
    const cur=doc.getFlag?.(ID,DECOY_FLAG);if(cur&&cur.id===flag?.id)await doc.update(forceDelete({},`flags.${ID}`,DECOY_FLAG));
  }

  /* ---------------- commands (her owner or the GM) ---------------- */
  tokenOf(target){const t=target?.object??target;return t?.document?t:null;}
  /** Is a decoy of hers standing (not yet ended)? */
  active(target){const f=this.flagOf(this.tokenOf(target));return !!f&&!f.end;}
  status(target){const token=this.tokenOf(target),f=this.flagOf(token),R=this.records.get(token);if(!f)return null;const st=decoyState(f,this.now());
    return {id:f.id,kind:f.kind,look:f.look,x:f.x,y:f.y,phase:st.phase,mix:st.mix,jobs:[...(f.jobs??[])],drawn:!!R?.mesh?.visible,ready:!!R?.ready,failed:!!R?.failed,paints:this.stats.paints};}
  /** Make a decoy. kind 'warp': the copy stays here and she warps to `point`. kind 'cast': her free bits (up to four) fly to `point` and cast it there.
   * look: 'hardlight' | 'normal' (default: her Decoy look). A decoy already standing is ended first. */
  async place(target,{kind='cast',point=null,look=null,warpLook=undefined}={}){
    const token=this.tokenOf(target),doc=token?.document;if(!doc)throw new Error('Choose her token.');
    if(!doc.isOwner&&!globalThis.game?.user?.isGM)throw new Error('You can only make a decoy of a character you own.');
    if(isOn('decoy',doc)===false)throw new Error('The Decoy is switched off in Settings › Flight › Her and the world.');
    if(!point||!Number.isFinite(point.x)||!Number.isFinite(point.y))throw new Error('Choose a spot for the decoy.');
    kind=kindOf(kind);look=lookOf(look??choice('decoyLook',doc));
    const old=this.flagOf(token);if(old){await this.clear(doc,old);const R=this.records.get(token);if(R)this.drop(R);}
    const now=this.now(),id=foundry.utils.randomID(16),c=token.center??{x:doc.x+token.w/2,y:doc.y+token.h/2},by=globalThis.game?.user?.id??null;
    if(kind==='warp'){
      if(typeof this.warp!=='function')throw new Error('Warps are unavailable in this build.');
      // her copy flickers in as she leaves: it begins a moment before her warp moves her, and is whole just after
      const options=warpLook?{style:'wings',look:warpLook}:{style:'wings'};let leave=0;try{leave=Number(this.warpLeave?.(token,point,options))||0;}catch{}
      await doc.update({[`flags.${ID}.${DECOY_FLAG}`]:{...decoyFlag({id,kind,x:c.x,y:c.y,look,now,delay:Math.max(0,Math.min(4000,leave)-DECOY_T.born*400)}),by}});
      await this.warp(token,point,options);
      return this.status(token);
    }
    const bits=this.bits(),size=Math.max(token.w,token.h)||100;
    // her bits hold their corners round her hovering figure (lift: how far her copy stands above its ground centre)
    let lift=0;try{lift=Math.round(Number(bodyPose(token)?.dy)||0);}catch{}
    if(!bits?.startTool)throw new Error('Her bit tools are unavailable. Reload the scene.');
    const free=bits.getToolState?.(doc)?.available?.length??0;if(!free)throw new Error('Her bits are busy or away. Call some back first.');
    const jobs=[];
    try{for(const p of decoyCorners(point.x,point.y,size,Math.min(4,free),lift)){const h=await bits.startTool(doc,{kind:'parkLight',point:p,bits:1,light:{enabled:false}});if(h?.id)jobs.push(h.id);}}
    catch(error){for(const j of jobs)try{await bits.stopTool(doc,{id:j});}catch{}throw error;}
    await doc.update({[`flags.${ID}.${DECOY_FLAG}`]:{...decoyFlag({id,kind,x:point.x,y:point.y,look,now:this.now(),jobs,lift,delay:DECOY_CAST_DELAY}),by}});
    return this.status(token);
  }
  /** Change its look while it stands: 'hardlight' | 'normal', or nothing to switch to the other. */
  async setLook(target,look=undefined){
    const token=this.tokenOf(target),doc=token?.document,f=this.flagOf(token);if(!f||f.end)return false;
    if(!doc.isOwner&&!globalThis.game?.user?.isGM)return false;
    const next=withLook(f,look===undefined?(f.look==='normal'?'hardlight':'normal'):look,this.now());if(next===f)return f.look;
    await doc.update({[`flags.${ID}.${DECOY_FLAG}`]:next});return next.look;
  }
  /** End it: it tears and comes apart, then her bits come home. why: 'dismiss' | 'blow'. */
  async dismiss(target,{why='dismiss'}={}){
    const token=this.tokenOf(target),doc=token?.document,f=this.flagOf(token);if(!f)return false;
    if(!doc.isOwner&&!globalThis.game?.user?.isGM)return false;
    if(f.end)return true;
    await doc.update({[`flags.${ID}.${DECOY_FLAG}`]:{...withEnd(f,this.now(),why),by:globalThis.game?.user?.id??f.by??null}});return true;
  }
}
