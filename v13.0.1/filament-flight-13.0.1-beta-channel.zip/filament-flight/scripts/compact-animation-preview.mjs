/** Read-only browser preview of Yvaelle’s Toolbox v5.0.0 compact bit programs.
 * Uses the unmodified production formation, choreography and Resonant Core
 * painter. Owns no ticker, audio, Foundry documents, flags or deployment state.
 * Caller owns the canvas backing resolution and supplies elapsed milliseconds.
 */
import {COMPACT_BIT_PROGRAMS, COMPACT_BIT_IDS, sampleCompactCurrents, sampleCompactStations, compactGeometryPlacement} from './compact-bit-formations.mjs?v=13.0.1';
import {sampleV7Appearance} from './v7-ensemble.mjs?v=13.0.1';
import {choreographedGems} from './gem-choreography.mjs?v=13.0.1';
import {paintResonantBit} from './bit-resonance.mjs?v=13.0.1';
import {BIT_GESTURES,LIVING_BIT_PROGRAMS,behaviourSettings} from './bit-behaviour.mjs?v=13.0.1';
import {updateBitWaveDirection,retainBitWaveDirections} from './bit-wave-direction.mjs?v=13.0.1';
import {isProjectedEffect} from './projected-effect-programs.mjs?v=13.0.1';
import {v7SemanticGems} from './v7-artwork-identity.mjs?v=13.0.1';
import {compactSolidBounds,compactDepthFront} from './compact-depth.mjs?v=13.0.1';
import {BIT_DETAIL,BIT_DRAW_SIZE} from './bit-renderer.mjs?v=13.0.1';

export const BIT_PREVIEW_CHOICES=Object.freeze(Object.entries(COMPACT_BIT_PROGRAMS).flatMap(([id,program])=>
  Object.entries(program.counts).map(([count,entry])=>Object.freeze({id,count:Number(count),family:program.name,name:entry.name,label:entry.name,description:entry.description}))));

const contexts=new WeakMap();
const finite=(value,fallback)=>Number.isFinite(Number(value))?Number(value):fallback;
const clamp=(value,lo,hi,fallback)=>Math.max(lo,Math.min(hi,finite(value,fallback)));
const DEFAULT_WEIGHTS=Object.freeze([1,0,0,0,0,0,0,0,0,0,0]);

function previewCanvas(canvas){
  if(canvas.ownerDocument?.createElement)return canvas.ownerDocument.createElement('canvas');
  if(typeof canvas.cloneNode==='function')return canvas.cloneNode(false);
  if(typeof globalThis.OffscreenCanvas==='function')return new OffscreenCanvas(1,1);
  // Native Canvas fixtures expose their own compatible surface constructor.
  if(canvas.constructor&&canvas.constructor!==Object)return new canvas.constructor(1,1);
  return globalThis.document?.createElement?.('canvas');
}

export function releaseAssembledPreviewBits(memory){for(const r of memory?.surfaces?.values()??[])r.surface.width=r.surface.height=1;memory?.surfaces?.clear();}

/** Compact rehearsal fits vector assembly to the actual output pixel grid,
 * capped by My view's native bit-density ceiling. Enlarged mechanism inspection
 * keeps its direct native vector path. This is not a scene texture policy. */
export function paintAssembledPreviewBit(ctx,part,{memory,quality='high',canvas=ctx.canvas,transform=ctx.getTransform()}={}){
  memory.surfaces??=new Map();
  const m=transform,limit=BIT_DETAIL[quality]??BIT_DETAIL.high,pixelsPerUnit=Math.max(Math.hypot(m.a,m.b),Math.hypot(m.c,m.d));
  const scale=Math.max(1,pixelsPerUnit/(limit/BIT_DRAW_SIZE));
  const [cx,cy]=part.points[0],x=(m.a*cx+m.c*cy+m.e)/scale,y=(m.b*cx+m.d*cy+m.f)/scale;
  // Composite only the body's bound (the scene textures' 42/48-unit housing
  // square), not a whole-canvas scratch per bit. Integer crop offsets keep
  // the identical subpixel raster and the native 1:1 copy below.
  const h=part.hardware??{},radius=(h.artwork==='resonant'?42:48)*Math.abs(h.scale??1)*pixelsPerUnit/scale+2;
  const left=Math.max(0,Math.floor(x-radius)),top=Math.max(0,Math.floor(y-radius));
  const right=Math.min(Math.ceil(canvas.width/scale),Math.ceil(x+radius)),bottom=Math.min(Math.ceil(canvas.height/scale),Math.ceil(y+radius));
  if(!(right>left&&bottom>top))return;
  let record=memory.surfaces.get('assembly');
  if(!record){const surface=previewCanvas(canvas);record={surface,context:surface.getContext('2d')};memory.surfaces.set('assembly',record);}
  const fit=(current,needed)=>current>=needed&&current<=needed*2+64?current:Math.ceil(needed/32)*32;
  const surfaceWidth=fit(record.surface.width,right-left),surfaceHeight=fit(record.surface.height,bottom-top);
  if(record.surface.width!==surfaceWidth||record.surface.height!==surfaceHeight){record.surface.width=surfaceWidth;record.surface.height=surfaceHeight;}
  // Each real draw has fresh material inputs. One shared synchronous scratch
  // avoids serializing four mostly-changing hardware trees or retaining four
  // output frames. drawImage captures each completed body before reuse.
  const f=record.context;f.setTransform(1,0,0,1,0,0);f.clearRect(0,0,surfaceWidth,surfaceHeight);f.save();
  f.setTransform(m.a/scale,m.b/scale,m.c/scale,m.d/scale,x-left,y-top);
  try{paintResonantBit(f,{...part,strength:1,points:[[0,0,0,.92]]});}finally{f.restore();}
  const opacity=ctx.globalAlpha*part.strength;
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=opacity;
  // At full output density use the native 1:1 image path. Explicit source-crop
  // resampling can change thin AA pixels even when both rectangles are integer.
  if(scale===1)ctx.drawImage(record.surface,left,top);
  else{ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(record.surface,left*scale,top*scale,surfaceWidth*scale,surfaceHeight*scale);}
  ctx.restore();
}

/** A playback clock is not a new design. Keep material samples fresh while
 * identifying only the inputs that change the path/episode being rehearsed. */
export function compactPreviewIdentity(flight,options={}){
  const projected=flight.bitProjectedEffect;
  return JSON.stringify([v7SemanticGems(flight.gems),flight.v9,options.view,options.flow,options.reduced,
    options.gesture,options.gestureLayout,options.gestureCaptureTime,options.gestureOriginRotations,
    options.previewWork,options.activity?.state,options.activity?.episodeKey,options.intentTarget,
    options.bitQuality??options.quality,options.rigQuality,options.effectDetail,
    projected?{id:projected.id,strength:projected.strength,scaleX:projected.scaleX,scaleY:projected.scaleY,
      angle:projected.angle,originX:projected.originX,originY:projected.originY}:null]);
}

function snapshot(options){
  const id=Object.hasOwn(COMPACT_BIT_PROGRAMS,options.id)?options.id:'orbit';
  const count=Math.round(clamp(options.count,1,4,4));
  const v7=options.v7??sampleV7Appearance(null,{reduced:!!options.reduced},options.elapsed??0);
  const rawProjection=options.projectedEffect;
  const projected=rawProjection?.enabled!==false&&isProjectedEffect(rawProjection?.id)&&clamp(rawProjection.strength,0,1,1)>0;
  const bitProjectedEffect=projected?{id:rawProjection.id,
    clock:options.reduced||options.animated===false?0:Math.max(0,finite(options.elapsed,0))/1000,
    elapsed:options.reduced||options.animated===false?1200:clamp(rawProjection.activationElapsed??options.elapsed,0,1200,1200),
    strength:clamp(rawProjection.strength,0,1,1),
    scaleX:clamp(rawProjection.scaleX,.01,100,600/3.5/100),scaleY:clamp(rawProjection.scaleY,.01,100,rawProjection.scaleX??600/3.5/100),
    angle:finite(rawProjection.angle,0),originX:finite(rawProjection.originX,0),originY:finite(rawProjection.originY,15),
    focus:rawProjection.focus??null,motion:rawProjection.motion??null}:null;
  return {v7,v9:options.v9,
    compactBits:true,bitActivity:options.activity??null,intentTarget:options.intentTarget??null,
    ...(projected?{bitProjectedEffect,bitHomeStations:COMPACT_BIT_IDS.slice(0,count)}:{}),
    bitFormationFlow:options.flow??{},bitFormationNow:options.formationFlowNow??options.elapsed??0,
    effective:{reducedMotion:!!options.reduced},
    bitGesturePreview:BIT_GESTURES[options.gesture]?{id:options.gesture,progress:Math.min(1,Math.max(0,options.elapsed??0)/BIT_GESTURES[options.gesture].duration),returnProgress:Math.max(0,Math.min(1,((options.elapsed??0)-BIT_GESTURES[options.gesture].duration)/1000)),energy:options.behaviour?.energy??.65,layout:options.gestureLayout,captureTime:options.gestureCaptureTime??0,originRotations:options.gestureOriginRotations}:null,
    bitDeployment:1,
    stabilizerDeployment:1,
    formation:{growth:1,fold:0,presence:1},
    poseAnimation:{weights:DEFAULT_WEIGHTS},
    movement:{profile:{bitOrbit:1,field:1},sweep:0},
    flightProfile:{id:'hover'},
    gems:{v7,
      behaviour:projected?{...options.behaviour,enabled:false}:options.behaviour,
      count,soloProgram:id,soloRadius:clamp(options.radius,.4,1.6,1),
      strength:clamp(options.strength,0,1,.75),speed:clamp(options.speed,.25,2,1),
      personality:projected?0:clamp(options.personality,0,1,.35),
      size:clamp(options.size,.5,1.5,1),animated:options.animated!==false,
      appearance:'physical',artwork:'resonant',style:'choreographed',
      coreState:options.coreState??'idle',passiveEffects:projected?false:options.passiveEffects!==false,
      program:['poised','orbital','seraph'].includes(options.program)?options.program:'poised',
      design:['vanes','shielded','spine'].includes(options.design)?options.design:'vanes',
      reactive:true,assetStates:options.assetStates!==false,
      metalHighlights:options.metalHighlights!==false,highlightStrength:clamp(options.highlightStrength,0,1,.45),
      coreDepth:options.coreDepth===true,coreDepthStrength:clamp(options.coreDepthStrength,0,1,.35),
      mechanicalResponse:options.mechanicalResponse!==false,repairFocus:true,
      suspendedCore:options.suspendedCore!==false,shutters:!!options.shutters,
      glow:options.glow!==false,glowStrength:clamp(options.glowStrength,0,1,.4),
      glowMode:options.glowMode==='field'?'field':'core',
      fieldStyle:['contour','weave','aegis'].includes(options.fieldStyle)?options.fieldStyle:'contour'
    }
  };
}

function makeParts(flight,elapsed,accent,{waveState=null,waveNow=elapsed}={}){
  const visual={time:elapsed/1000,animated:flight.gems.animated};
  const parts=[];
  for(const side of [-1,1]){
    for(const part of choreographedGems(DEFAULT_WEIGHTS,0,visual,flight,side)){
      if(!part.hardware||part.strength<=.00001)continue;
      const station=`${side<0?'left':'right'}${part.id==='gem-0'?'Upper':'Lower'}`;
      const wave=flight.gems.glow&&flight.gems.glowMode==='field'?updateBitWaveDirection(waveState,station,{position:part.points[0],intent:part.hardware.intent,focus:part.hardware.focus,target:flight.intentTarget??part.hardware.workTarget,
        now:waveNow,animated:flight.gems.animated,reduced:!!flight.effective?.reducedMotion}):{direction:[0,-1]};
      part.hardware.glow=flight.gems.glow?{direction:wave.direction,strength:flight.gems.glowStrength,color:accent}:null;
      parts.push({station,part});
    }
  }
  retainBitWaveDirections(waveState,parts.map(p=>p.station));
  // Work-site index and emitted-current index use the same canonical station
  // order. Legacy previews retain their historical painting order.
  if(flight.bitProjectedEffect)parts.sort((a,b)=>COMPACT_BIT_IDS.indexOf(a.station)-COMPACT_BIT_IDS.indexOf(b.station));
  return parts;
}

/** Draw a frame, then return the sampled positions for optional UI inspection.
 * id: one of the eight production family IDs; count selects that family's own
 * choreography. view:'mechanism' enlarges a single native bit for inspecting
 * its selected internal program, shell, moving highlights and glow.
 * tokenImage may be any loaded CanvasImageSource. The opaque backing token
 * keeps rear bits genuinely occluded, rather than cross-fading duplicates.
 */
export function paintBitPreview(canvas,options={}){
  const ctx=canvas?.getContext?.('2d');
  if(!ctx)return null;
  const width=canvas.width,height=canvas.height;
  if(width<=0||height<=0)return null;
  const elapsed=Math.max(0,finite(options.elapsed,0));
  const background=options.background??'#21191f';
  const textColor=options.textColor??'#f2e8ed';
  const accent=/^#[\da-f]{6}$/i.test(options.accent??'')?options.accent:'#ef79d2';
  const flight=snapshot(options);
  const fingerprint=compactPreviewIdentity(flight,options);
  let memory=contexts.get(canvas);
  if(!memory||memory.fingerprint!==fingerprint||elapsed<memory.elapsed){
    releaseAssembledPreviewBits(memory);
    memory={fingerprint,elapsed:0,depths:new Map(),waves:new Map(),surfaces:new Map()};contexts.set(canvas,memory);
  }
  const b=behaviourSettings(options.behaviour,flight.gems.personality),previewOffset=options.previewWork&&Object.hasOwn(LIVING_BIT_PROGRAMS,flight.gems.soloProgram)?((flight.gems.soloProgram==='livingWorkshop'?20:flight.gems.soloProgram==='quietExchange'?23:26)*(b.frequency==='composed'?2.8:b.frequency==='expressive'?.74:1)-(flight.gems.soloProgram==='livingWorkshop'?8:7)-.5)*1000:0;
  const sampleElapsed=elapsed+previewOffset;
  const parts=makeParts(flight,sampleElapsed,accent,{waveState:memory.waves,waveNow:elapsed});
  const currents=sampleCompactCurrents(Object.values(sampleCompactStations(flight,sampleElapsed/1000*flight.gems.speed)).filter(p=>COMPACT_BIT_IDS.indexOf(p.station)<flight.gems.count),{enabled:flight.gems.glow&&flight.gems.passiveEffects,strength:flight.gems.glowStrength});
  const rigUnit=Math.min(width/340,height/285);
  const tokenRadius=600/7;
  ctx.save();
  ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,width,height);
  if(background!=='transparent'){ctx.fillStyle=background;ctx.fillRect(0,0,width,height);}
  ctx.translate(width/2,height/2);ctx.scale(rigUnit,rigUnit);

  if(options.view==='mechanism'){
    const source=parts[0];
    if(source){
      const hardware={...source.part.hardware,angle:0,scale:4.8};
      paintResonantBit(ctx,{...source.part,points:[[0,0,0]],hardware});
    }
  }else{
    // Reconstruct the conservative depth history on coarse seeks so a preview
    // slider does not make an instrument swap sides midway through the token.
    const from=memory.depths.size?memory.elapsed:0;
    if(elapsed-from>80){
      const steps=Math.min(900,Math.ceil((elapsed-from)/60));
      for(let step=0;step<steps;step++){
        const time=(from+(elapsed-from)*step/steps+previewOffset)/1000*flight.gems.speed;
        let historicalParts;
        for(const {station} of parts){
          const pose=compactGeometryPlacement(station,flight,time),previous=memory.depths.get(station);
          let bounds;
          // The housing contains its origin, so its centre must clear the
          // portrait first. Avoid rebuilding solid geometry for every held
          // inside sample during a long coarse seek.
          if(previous!==undefined&&compactDepthFront(pose.center,previous)!==previous){
            historicalParts??=makeParts(flight,time/flight.gems.speed*1000,accent);
            const hardware=historicalParts.find(p=>p.station===station)?.part.hardware;
            if(hardware)bounds=compactSolidBounds(hardware);
          }
          memory.depths.set(station,compactDepthFront(pose.center,previous,{bounds}));
        }
      }
    }
    for(const {station,part} of parts){
      const previous=memory.depths.get(station),bounds=previous!==undefined&&compactDepthFront(part.points[0],previous)!==previous?compactSolidBounds(part.hardware):null;
      memory.depths.set(station,compactDepthFront(part.points[0],previous,{bounds}));
    }
    // Match the scene's composition: paint a complete solid at full opacity,
    // then fade that assembled image once. Per-face fading changes overlaps.
    const paint=({station,part})=>paintAssembledPreviewBit(ctx,{...part,points:part.points.map(p=>[p[0],p[1]-15,p[2],p[3]])},
      {memory,key:station,canvas,quality:options.bitQuality??options.quality??'high',transform:{a:rigUnit,b:0,c:0,d:rigUnit,e:width/2,f:height/2}});
    const paintCurrents=front=>{
      ctx.save();ctx.strokeStyle=accent;ctx.lineCap='round';ctx.lineJoin='round';
      for(const path of currents){if((path.points.reduce((sum,p)=>sum+p[2],0)>=0)!==front)continue;
        ctx.globalAlpha=path.strength;ctx.lineWidth=path.width;ctx.beginPath();path.points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]-15):ctx.moveTo(p[0],p[1]-15));ctx.stroke();}
      ctx.restore();
    };
    paintCurrents(false);
    for(const item of parts)if(!memory.depths.get(item.station))paint(item);

    ctx.save();
    ctx.beginPath();ctx.arc(0,0,tokenRadius,0,Math.PI*2);ctx.closePath();
    ctx.fillStyle=options.tokenBackground??'#332830';ctx.fill();
    ctx.save();ctx.clip();
    const image=options.tokenImage;
    if(image){
      const iw=image.naturalWidth??image.width,ih=image.naturalHeight??image.height;
      if(iw>0&&ih>0){
        const side=Math.min(iw,ih);
        ctx.drawImage(image,(iw-side)/2,(ih-side)/2,side,side,-tokenRadius,-tokenRadius,tokenRadius*2,tokenRadius*2);
      }
    }else{
      ctx.fillStyle=textColor;ctx.font='35px Georgia, serif';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(String(options.tokenLabel??'E').slice(0,2),0,1);
    }
    ctx.restore();
    ctx.strokeStyle=accent;ctx.globalAlpha=.46;ctx.lineWidth=.85;ctx.stroke();
    ctx.restore();

    for(const item of parts)if(memory.depths.get(item.station))paint(item);
    paintCurrents(true);
  }
  ctx.restore();memory.elapsed=elapsed;
  const count=flight.gems.count,id=flight.gems.soloProgram;
  return {
    id,count,elapsed,name:COMPACT_BIT_PROGRAMS[id].counts[count].name,
    family:COMPACT_BIT_PROGRAMS[id].name,
    parts:parts.map(({station,part})=>({station,x:part.points[0][0],y:part.points[0][1]-15,z:part.points[0][2],front:memory.depths.get(station)??true})),
    provenance:'Yvaelle’s Toolbox v5.0.0: production formation sampler, bit choreography and Resonant Core painter'
  };
}

/** Optional cleanup after removing the preview canvas. No timer to cancel. */
export function releaseBitPreview(canvas){releaseAssembledPreviewBits(contexts.get(canvas));contexts.delete(canvas);}

/** Native bit parts for token-effect preview composition. */
export function samplePreviewBits(options={}) {const elapsed=Math.max(0,finite(options.elapsed,0));return makeParts(snapshot(options),elapsed,options.accent??"#ef79d2",{waveState:options.waveState??null,waveNow:options.waveNow??elapsed});}
