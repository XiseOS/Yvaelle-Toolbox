import {paintTokenEffect} from './token-effects.mjs?v=13.0.1';
import {medicalEmitterSurfaceSize,paintMedicalEmitter} from './medical-emitter-artwork.mjs?v=13.0.1';

const ROLES=new Set(['source','current','packet']);
const finitePoint=p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1]);
export const isProjectedEmitterPath=path=>ROLES.has(path?.role)&&typeof path.emitter==='string'&&Array.isArray(path.points)&&path.points.length>0&&path.points.every(finitePoint);

/** Split only authored core feeds from a field. Working surfaces stay in its
 * existing patient canvas. Keep up to two connector lanes per bit during a
 * field crossfade; each has its own retained patient endpoint. Input paths and
 * pure samplers are untouched, including legacy effects and previews. */
export function projectedEmitterArtwork(effects,attachedEmitters){
  const emitters=new Map();
  for(const frame of effects){
    if(frame.effect!=='token-field')continue;
    const lanes=new Map();
    for(const path of frame.paths??[]){
      if(!isProjectedEmitterPath(path)||!attachedEmitters.has(path.emitter)||!(path.alpha>0))continue;
      const id=path.emitter;let emitter=emitters.get(id);
      if(!emitter){emitter={id,beacon:null,connectors:[]};emitters.set(id,emitter);}
      if(path.role==='source'){
        const center=path.points.reduce((sum,p)=>[sum[0]+p[0]/path.points.length,sum[1]+p[1]/path.points.length],[0,0]);
        emitter.beacon??={id,center,plane:path.plane,layers:[]};
        emitter.beacon.layers.push({color:frame.color,paths:[path]});
      }else if(path.role==='current'){
        const source=[...path.points[0]],endpoint=[...path.points.at(-1)],dx=endpoint[0]-source[0],dy=endpoint[1]-source[1],length=Math.hypot(dx,dy);
        if(length<1e-6){lanes.delete(id);continue;}
        const lane={source,endpoint,length,angle:Math.atan2(dy,dx),plane:path.plane,color:frame.color,paths:[path]};
        emitter.connectors.push(lane);lanes.set(id,lane);
      }else if(path.role==='packet')lanes.get(id)?.paths.push(path);
    }
  }
  for(const emitter of emitters.values())for(const lane of emitter.connectors){
    const c=Math.cos(lane.angle),s=Math.sin(lane.angle),origin=lane.source;
    lane.paths=lane.paths.map(p=>({...p,points:p.points.map(q=>{const x=q[0]-origin[0],y=q[1]-origin[1];return [x*c+y*s,-x*s+y*c,...q.slice(2)];})}));
  }
  return emitters;
}

export {medicalEmitterSurfaceSize as projectedBeaconSurfaceSize,paintMedicalEmitter as paintProjectedBeacon};

/** Bounded narrow crop in the cached source/contact chord's coordinates. The
 * density is capped by the field's existing quality resolution. Mesh movement
 * changes no pixels; its longitudinal scale holds the patient endpoint. */
export function projectedConnectorViewport(artwork,resolution){
  let minX=0,minY=0,maxX=0,maxY=0;
  for(const path of artwork.paths){
    const pad=(path.width+(path.glow?(path.glowSpread??3):0))/2+2;
    for(const p of path.points){minX=Math.min(minX,p[0]-pad);minY=Math.min(minY,p[1]-pad);maxX=Math.max(maxX,p[0]+pad);maxY=Math.max(maxY,p[1]+pad);}
  }
  const density=Math.min(resolution/280,Math.max(1,resolution-4)/(maxX-minX+4),Math.max(1,resolution-4)/(maxY-minY+4));
  const left=Math.floor(minX*density)-1,top=Math.floor(minY*density)-1,right=Math.ceil(maxX*density)+1,bottom=Math.ceil(maxY*density)+1;
  return {x:resolution/2+left,y:resolution/2+top,width:Math.max(2,right-left),height:Math.max(2,bottom-top),density};
}

export function paintProjectedConnector(ctx,artwork,{resolution,viewport=projectedConnectorViewport(artwork,resolution)}={}){
  ctx.clearRect(0,0,viewport.width,viewport.height);ctx.save();
  ctx.translate(resolution/2-viewport.x,resolution/2-viewport.y);ctx.scale(viewport.density,viewport.density);
  paintTokenEffect(ctx,artwork,{plane:artwork.plane});ctx.restore();
  return {x:(resolution/2-viewport.x)/viewport.width,y:(resolution/2-viewport.y)/viewport.height};
}

/** Controls for the already-painted connector. Its origin follows the actual
 * instrument; its end follows the retained patient-local contact. Transverse
 * width stays constant instead of stretching the current's narrow glow. */
export function projectedConnectorTransform(artwork,source,target,unitWorld){
  const contact={x:target.x+artwork.endpoint[0]*unitWorld,y:target.y+artwork.endpoint[1]*unitWorld};
  const dx=contact.x-source.x,dy=contact.y-source.y,length=Math.hypot(dx,dy);
  return {x:source.x,y:source.y,angle:Math.atan2(dy,dx),longitudinal:artwork.length>1e-6?length/artwork.length:0,transverse:unitWorld,contact};
}
