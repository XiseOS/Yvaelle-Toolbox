/** Yvaelle’s Toolbox v11 · Healing and the bits' jobs: the runtime (Foundry glue).
 *
 * What it reads (synced, so every client plays the same moments):
 *  - PF2e chat messages: spell casts (her heals light her token; any caster near
 *    her gets the tradition response), her Escape attempts (only while grabbed or
 *    restrained), natural 20s and 1s (after Dice So Nice);
 *  - her actor: Hero Points spent, unconscious while airborne;
 *  - combat turns: an ally's turn (a bit watches them).
 * What it gives each frame (only while something plays; idle is one map lookup):
 *  - feelInput()/feel(): the flight feel's input and output (flight-feel-runtime);
 *  - wingVisual(): the wing painter's state (pose-renderer → wing-rig → heal-wing.mjs);
 *  - the map-space strokes, drawn on a screen overlay above the board by its own
 *    ticker, which stops (and gives its pixels back) as soon as nothing shows;
 *  - her frame's share when her wings are off (token layer, frameMoments).
 * That overlay is not masked by fog of war, so (test.3, v11/fx-visibility.mjs) a client draws nothing of
 * hers while it cannot see her token, nothing at an ally's end it cannot see, and all of it under the invisibility veil (others see none; the owner's ghost a faint trace).
 * Nothing here touches her token's transform, bounds, vision or perception. */
import {isOn,partsOf,FEATURES} from './features.mjs?v=13.0.1';
import {readSpellCast,readEscape,readNatural,heroPointsSpent,heldBy} from './heal-events.mjs?v=13.0.1';
import {createHealRecord,addMoment,pruneMoments,healFeel,healWing,healInput,paintHealOverlay,overlayWanted,overlayBounds,frameMoments,bitOnTop,clearHealBits,VIGIL_HOLD} from './heal-moments.mjs?v=13.0.1';
import {healVisualLevers} from './heal-wing.mjs?v=13.0.1';
import {createOverlay} from '../overlay-layer.mjs?v=13.0.1';
import {SLOTS} from './token-layer.mjs?v=13.0.1';
import {tokenSeen,fxAlpha} from './fx-visibility.mjs?v=13.0.1';

const ID='filament-flight';
const clock=()=>performance.now()/1000;
const HEAL_FEATURES=['allyWatch','grappleEscape','lastLight','dieMoods','heroSpent','spellTraditions','wingless'];
const STATIONS=['leftUpper','rightUpper','leftLower','rightLower'];
const TRAD_RANGE_FT=30,WATCH_RANGE=6;

const docOf=t=>t?.document??t??null;
function condition(actor,slug){try{if(actor?.getCondition?.(slug))return true;if(actor?.hasCondition?.(slug))return true;return !!actor?.statuses?.has?.(slug);}catch{return false;}}
const hpOf=actor=>{const h=actor?.system?.attributes?.hp,v=Number(h?.value),m=Number(h?.max);return m>0&&Number.isFinite(v)?Math.max(0,Math.min(1,v/m)):1;};

/** One of her tokens. */
class HealRec{
  constructor(rt,doc){
    this.rt=rt;this.doc=doc;this.R=createHealRecord();this.grabbed=false;this.ko=false;this.hero=null;
    this.readParts();this.readActor(true);
  }
  readParts(){
    const doc=this.doc,P={};
    for(const f of HEAL_FEATURES){P[f]=isOn(f,doc);Object.assign(P,partsOf(f,doc));}
    P.lastCatch=P.lastLight&&P.lastCatch;
    this.R.parts=P;this.parts=P;
  }
  readActor(first=false){
    const actor=this.doc.actor;if(!actor)return;const t=clock();
    this.grabbed=heldBy([...(actor.conditions?.map?.(c=>c.slug)??[]),...(actor.statuses??[])].filter(Boolean));
    if(this.grabbed&&this.R.grabbedAt==null)this.R.grabbedAt=first?t-5:t;else if(!this.grabbed)this.R.grabbedAt=null;
    const ko=condition(actor,'unconscious')||condition(actor,'dying');
    if(!first&&ko&&!this.ko)this.rt.knockedOut(this,t);
    if(!ko&&this.ko){const m=this.R.moments.find(x=>x.kind==='last');if(m)m.vigil=false;}
    this.ko=ko;
    this.rt.wake();
  }
}

export class HealRuntime{
  constructor(){
    this.records=new Map();this.installed=false;this.getState=()=>null;this.tokenLayers=null;
    this.overlay=null;this.ticking=false;
    this.stats={frames:0,overlayFrames:0,moments:0,feelCalls:0};
    this.C={t:0,dt:1/60,cx:0,cy:0,x:0,y:0,u:100,size:100,R:47,angle:0,bodyAngle:0,bits:[null,null,null,null],painted:[0,0,0,0],ally:null,frameMode:false,bitsShown:false};
    this.bitBuf=[0,1,2,3].map(()=>({x:0,y:0,x0:0,y0:0,angle:0,w:0,alpha:1,surface:null}));
    this.allyBuf=new Map();this.bounds=[0,0,0,0];this.dirty={on:false,x0:0,y0:0,x1:0,y1:0};
    this.C.ally=id=>this.allyAt(id);
    // (test.3) what the overlay paints with: only the allies this client sees
    this.allySeen=id=>{const a=this.allyAt(id);return a&&tokenSeen(globalThis.canvas?.tokens?.get?.(id))?a:null;};
  }
  /* ---------------- records ---------------- */
  recordOf(token,create=true){
    const doc=docOf(token);if(!doc?.id)return null;
    let r=this.records.get(doc.id);if(r&&r.doc!==doc){r.doc=doc;r.readParts();}
    if(!r&&create){let flight=null;try{flight=doc.getFlag?.(ID,'flight');}catch{}if(!flight)return null;r=new HealRec(this,doc);this.records.set(doc.id,r);}
    return r??null;
  }
  recordsOfActor(actorRef){
    const out=[];if(!actorRef)return out;const id=typeof actorRef==='string'?actorRef.split('.').pop():actorRef.id;
    for(const r of this.records.values())if(r.doc.actorId===id||r.doc.actor?.id===id)out.push(r);
    if(!out.length){const actor=typeof actorRef==='string'?globalThis.game?.actors?.get?.(id):actorRef;for(const t of actor?.getActiveTokens?.()??[]){const r=this.recordOf(t);if(r)out.push(r);}}
    return out;
  }
  recordsOfSpeaker(sp){
    if(sp?.token){const tk=globalThis.canvas?.tokens?.get?.(sp.token);const r=tk?this.recordOf(tk):this.records.get(sp.token);if(r)return [r];}
    return this.recordsOfActor(sp?.actor);
  }
  /** (test.3) Is Last light holding her up (its bits catch her: the unconscious response must not drop them)? */
  carries(token){const r=this.records.get(docOf(token)?.id);return !!r&&r.parts.lastCatch!==false&&r.R.moments.some(m=>m.kind==='last');}
  /** Is anything playing on her token (the flight feel stays awake while it is)? */
  busy(token){const r=this.records.get(docOf(token)?.id);return !!r&&pruneMoments(r.R,clock());}

  /* ---------------- per frame: the flight feel and the wings ---------------- */
  /** Before stepFeel: Last light carries her (her height is set, not flown). Returns the input. */
  feelInput(token,input,f){
    const r=this.records.get(docOf(token)?.id);if(!r||!r.R.moments.length)return input;
    this.C.t=clock();return healInput(r.R,input,f,this.C);
  }
  /** After stepFeel (beside the damage runtime's feel): body and bits. */
  feel(token,out,{size=100,s=null}={}){
    const r=this.records.get(docOf(token)?.id);if(!r)return;
    const t=clock();if(!pruneMoments(r.R,t)){if(r.dirtyBits){clearHealBits(out);r.dirtyBits=false;}return;}
    this.stats.feelCalls++;
    const C=this.context(token,s,size,t);r.R.frameMode=C.frameMode;r.R.frameSigil=C.frameMode||!C.bitsShown;
    // the grabbed narrowing (off by default) is a lasting state, not a moment
    healFeel(r.R,out,C);r.dirtyBits=true;
    if(overlayWanted(r.R,C))this.ensureTicker();
  }
  /** The wing visual for this frame: the heal-wing state on it, or the profile untouched. */
  wingVisual(token,visual){
    const r=this.records.get(docOf(token)?.id);if(!r)return visual;
    if(!r.R.moments.length)return visual;
    const t=clock();pruneMoments(r.R,t);this.C.t=t;
    const H=healWing(r.R,this.C);if(!H)return visual;
    let v={...visual,v11heal:{ops:H.ops.map(o=>({...o})),anim:H.anim}};
    v=healVisualLevers(v,v.v11heal);
    const st=H.ops.find(o=>o.k==='strain');if(st){v.collapseTip=Math.max(v.collapseTip??0,st.tip);v.collapse=Math.max(v.collapse??0,st.fold);}
    return v;
  }
  /** Frame context: her centre and size, her bits as placed last frame, who is near. */
  context(token,s,size,t){
    const C=this.C;C.dt=Math.min(.1,Math.max(0,t-(C.lastT??t)));C.lastT=t;C.t=t;
    s??=this.getState(token);
    const k=s?.altScale??1,src=s?.source??token.center??{x:0,y:0};
    C.x=src.x;C.y=src.y;C.cx=src.x+(s?.swayX??0);C.cy=src.y+(s?.lift??0);C.size=size;C.u=size*k;C.R=size*k*.5;
    C.bodyAngle=(src.rotation??0)+(s?.bank??0);C.angle=C.bodyAngle;
    const wingsShown=!!s?.snapshot?.rendering?.wingsActive&&(s?.blend??0)>.05;
    const rec=this.records.get(token.document?.id);
    C.frameMode=!!(rec?.parts.wingless)||!wingsShown;
    // (test.3) her bits live on the wing rig (or the compact rig when she flies without wings), not on the pose renderer itself
    const Rn=s?.renderer,rb=Rn?.rig?.bits,cb=Rn?.compact?.bits,bits=(cb&&(cb.placedAt??0)>(rb?.placedAt??0)?cb:rb)??Rn?.bits,pl=bits?.placements,fresh=bits&&performance.now()-(bits.placedAt??0)<400;
    let any=false;
    for(let i=0;i<4;i++){const p=fresh?pl?.get(STATIONS[i]):null,B=this.bitBuf[i];
      if(p&&p.alpha>.02){B.x=p.x;B.y=p.y;B.x0=p.sx??p.x;B.y0=p.sy??p.y;B.angle=p.angle??0;B.alpha=p.alpha;C.bits[i]=B;any=true;}else C.bits[i]=null;}
    if(any&&bits?.records)for(const r of bits.records.values()){const i=STATIONS.indexOf(r.station);if(i<0)continue;const f=r.frame;
      C.painted[i]=f?.painted?.angle??f?.bit?.part?.hardware?.angle??0;const B=this.bitBuf[i];B.surface=f?.surface??null;B.ver=f?.version??null;B.slot=i;
      const crop=f?.surface&&f.qualitySize?f.surface.width/f.qualitySize:1,pp=pl?.get(STATIONS[i]);B.w=112*(pp?.scale??k*size*(s?.opts?.wingScale??3.5)/600)*crop/(pp?.v11scale??1);}
    C.bitsShown=any;
    return C;
  }
  /** An ally token's centre and radius (cached per frame). */
  allyAt(id){
    if(!id)return null;const tk=globalThis.canvas?.tokens?.get?.(id);if(!tk||tk.destroyed)return null;
    let a=this.allyBuf.get(id);if(!a){a={x:0,y:0,r:50,hp:1};this.allyBuf.set(id,a);}
    const c=tk.center??{x:tk.x+tk.w/2,y:tk.y+tk.h/2};a.x=c.x;a.y=c.y;a.r=Math.min(tk.w,tk.h)/2;a.hp=hpOf(tk.actor);return a;
  }

  /* ---------------- moments from events ---------------- */
  add(r,m){addMoment(r.R,m);this.stats.moments++;this.wakeFeel(r);this.wake();}
  wakeFeel(r){try{const tk=r.doc.object,s=tk&&this.getState(tk);if(s?.feelState)s.feelState.sleeping=s.feelState.sleeping&&false;}catch{}}
  noteMessage(message){
    const t=clock(),author=globalThis.game?.users?.get?.(message.author?.id??message.author??message.user);
    const fallbackTargets=[...(author?.targets??[])].map(x=>x.id);
    let item=null;try{item=message.item??null;}catch{}
    const cast=readSpellCast(message,item,{targets:fallbackTargets});
    if(cast)this.spellCast(cast,t,message);
    const esc=readEscape(message);
    if(esc)for(const r of this.recordsOfSpeaker(esc)){if(!r.parts.grappleEscape||!r.grabbed)continue;this.add(r,{kind:'escape',at:t,ok:esc.success,grappler:this.grapplerOf(r),noFail:!esc.success&&r.parts.grFail===false});}
    const nat=readNatural(message);
    if(nat)for(const r of this.recordsOfSpeaker(nat)){if(!r.parts.dieMoods||!r.parts[nat.nat===20?'dieNat20':'dieNat1'])continue;
      this.afterDice(message,()=>this.add(r,{kind:nat.nat===20?'nat20':'nat1',at:clock()}));}
  }
  spellCast(cast,t,message){
    // her own heal: her token's giving glow (the token layer's part)
    if(cast.healing)for(const r of this.recordsOfSpeaker(cast.caster)){
      const n=Math.max(1,Math.min(3,cast.actions||1));
      if(cast.targets.some(id=>id!==r.doc.id))try{this.tokenLayers?.give?.(r.doc.object,{n,gather:[.45,.55,.7][n-1]});}catch{}
    }
    // the tradition response: any caster within 30 ft of her
    if(!cast.tradition)return;
    const tk=cast.caster.token?globalThis.canvas?.tokens?.get?.(cast.caster.token):null;
    for(const r of this.records.values()){
      if(!r.parts.spellTraditions)continue;
      const part='sp'+cast.tradition[0].toUpperCase()+cast.tradition.slice(1);if(!r.parts[part])continue;
      const her=r.doc.object;if(!her)continue;
      const mine=r.doc.id===cast.caster.token||(!cast.caster.token&&r.doc.actorId===cast.caster.actor);
      if(!mine){if(!tk)continue;const d=this.distanceFt(her,tk);if(d>TRAD_RANGE_FT)continue;}
      this.add(r,{kind:'trad',at:t,trad:cast.tradition});
    }
  }
  afterDice(message,apply){
    const dice=globalThis.game?.modules?.get?.('dice-so-nice')?.active&&message?.rolls?.length&&message.id;
    if(!dice){apply();return;}
    setTimeout(()=>{if(!message._dice3danimating){apply();return;}
      const id=message.id;this.dice??=new Map();this.dice.set(id,apply);setTimeout(()=>{if(this.dice.get(id)===apply){this.dice.delete(id);apply();}},12000);},0);
  }
  /** Who is holding her: the nearest hostile token beside her (within 1.5 squares), else within 3. */
  grapplerOf(r){
    const her=r.doc.object;if(!her)return null;const grid=globalThis.canvas?.grid?.size??100,disp=r.doc.disposition;let best=null,bd=1e9;
    for(const tk of globalThis.canvas?.tokens?.placeables??[]){if(tk===her||tk.document?.hidden)continue;const d=tk.document?.disposition;if(d===disp||d===0&&disp!==-1&&false)continue;if(d!==-1&&disp!==-1)continue;
      const dist=Math.hypot(tk.center.x-her.center.x,tk.center.y-her.center.y)-(Math.max(tk.w,tk.h)+Math.max(her.w,her.h))/2;if(dist<bd){bd=dist;best=tk;}}
    return best&&bd<grid*3?best.id:null;
  }
  distanceFt(a,b){const grid=globalThis.canvas?.grid,px=Math.hypot(a.center.x-b.center.x,a.center.y-b.center.y);return px/(grid?.size??100)*(grid?.distance??5);}
  knockedOut(r,t){
    if(!r.parts.lastLight||!r.parts.lastCatch)return;
    const s=this.getState(r.doc.object),f=s?.feelState;if(!f||!(f.alt>1.2)||f.falling&&f.alt<1.5)return;
    this.add(r,{kind:'last',at:t,alt:f.alt,vigil:!!r.parts.lastVigil});
  }
  turnChanged(combat){
    // (combatTurnChange and updateCombat both report a turn: play it once)
    const key=`${combat?.id}:${combat?.round}:${combat?.turn}`;if(this.lastTurnKey===key)return;this.lastTurnKey=key;
    const c=combat?.combatant,tk=c?.token?.object??(c?.tokenId?globalThis.canvas?.tokens?.get?.(c.tokenId):null),t=clock();
    for(const r of this.records.values()){
      for(const m of r.R.moments)if(m.kind==='watch'&&m.end==null)m.end=t;
      if(!r.parts.allyWatch||!tk)continue;const her=r.doc.object;if(!her||tk===her||tk.document?.disposition!==r.doc.disposition||tk.document?.hidden||!tokenSeen(tk))continue;
      const grid=globalThis.canvas?.grid?.size??100;if(Math.hypot(tk.center.x-her.center.x,tk.center.y-her.center.y)>WATCH_RANGE*grid)continue;
      this.add(r,{kind:'watch',at:t,ally:tk.id,end:null});
    }
  }

  /* ---------------- the overlay ---------------- */
  ensureTicker(){
    if(this.ticking)return;const ticker=globalThis.canvas?.app?.ticker;if(!ticker)return;
    this.overlay??=createOverlay('filament-flight-v11-heal');this.ticking=true;ticker.add(this.tick,this,-14);
  }
  stopTicker(){if(!this.ticking)return;this.ticking=false;globalThis.canvas?.app?.ticker?.remove(this.tick,this);this.overlay?.clear();this.overlay?.release();}
  wake(){this.ensureTicker();}
  tick(){
    const t=clock();this.stats.frames++;let any=false;
    const o=this.overlay.ensure();if(!o){this.stopTicker();return;}
    // clear only what was drawn last frame (a full-screen clear every frame costs more than the strokes)
    const g=o.el.getContext('2d'),D=this.dirty;g.setTransform(1,0,0,1,0,0);
    if(D.on&&o.el===this.dirtyEl)g.clearRect(D.x0,D.y0,D.x1-D.x0,D.y1-D.y0);else g.clearRect(0,0,o.el.width,o.el.height);
    this.dirtyEl=o.el;D.on=false;D.x0=D.y0=Infinity;D.x1=D.y1=-Infinity;
    this.screenK=o.dpr;
    const wt=globalThis.canvas?.stage?.worldTransform;if(!wt){this.stopTicker();return;}
    g.setTransform(wt.a*o.dpr,wt.b*o.dpr,wt.c*o.dpr,wt.d*o.dpr,wt.tx*o.dpr,wt.ty*o.dpr);
    for(const r of this.records.values()){
      const tk=r.doc.object;if(!tk||tk.destroyed)continue;
      if(!pruneMoments(r.R,t))continue;
      const s=this.getState(tk),C=this.context(tk,s,Math.max(tk.w,tk.h),t);r.R.frameMode=C.frameMode;r.R.frameSigil=C.frameMode||!C.bitsShown;
      if(!overlayWanted(r.R,C)&&!(r.R.frameMode&&r.R.moments.length))continue;any=true;
      // with her flight asleep (no feel this frame) the moments still run their clocks and her frame
      if(!s?.feel||s.feelState?.sleeping){r.R.mem.noFeel=true;}
      // (test.3) nothing of hers where this client cannot see her, and her veil over all of it
      const fa=fxAlpha(tk);if(fa<.01)continue;
      C.ally=this.allySeen;C.fxA=fa;g.globalAlpha=fa;
      const B=overlayBounds(r.R,C,this.bounds);this.markDirty(wt,B[0],B[1],B[2],B[3]);
      try{paintHealOverlay(g,r.R,C,()=>document.createElement('canvas'));}catch(error){console.error('Yvaelle’s Toolbox | v11 heal overlay',error);r.R.moments.length=0;}
      finally{C.ally=this.allyAtFn??=id=>this.allyAt(id);C.fxA=1;g.globalAlpha=1;}
      if(r.R.frameMode)try{this.tokenLayers?.wake?.(this.tokenLayers.layerOf?.(tk));}catch{}
    }
    if(any)this.stats.overlayFrames++;
    else this.stopTicker();
  }

  /** Grow the dirty rectangle (screen pixels) by a map-space box. */
  markDirty(wt,x0,y0,x1,y1){const D=this.dirty,k=this.screenK??1,m=12;
    const ax=(wt.a*x0+wt.c*y0+wt.tx)*k,ay=(wt.b*x0+wt.d*y0+wt.ty)*k,bx=(wt.a*x1+wt.c*y1+wt.tx)*k,by=(wt.b*x1+wt.d*y1+wt.ty)*k;
    D.on=true;D.x0=Math.floor(Math.min(D.x0,ax,bx)-m);D.y0=Math.floor(Math.min(D.y0,ay,by)-m);D.x1=Math.ceil(Math.max(D.x1,ax,bx)+m);D.y1=Math.ceil(Math.max(D.y1,ay,by)+m);}

  /* ---------------- her frame (token layer) ---------------- */
  /** The token layer's frame hook: rim arcs and beads for these moments. Returns true while moving. */
  frameFx(token,L){
    const r=this.records.get(docOf(token)?.id);if(!r)return false;
    if(!r.R.moments.length)return false;
    const t=clock(),w=this.frameWriters??=makeWriters();w.L=L;
    return frameMoments(r.R,t,w);
  }

  /* ---------------- hooks ---------------- */
  install({getState=null,tokenLayers=null,pinned=null}={}){
    if(getState)this.getState=getState;if(tokenLayers){this.tokenLayers=tokenLayers;tokenLayers.healFx=(token,L)=>this.frameFx(token,L);}if(pinned)this.pinned=pinned;
    if(this.installed||!globalThis.Hooks)return;this.installed=true;
    Hooks.on('createChatMessage',m=>{try{this.noteMessage(m);}catch(e){console.error('Yvaelle’s Toolbox | v11 heal',e);}});
    Hooks.on('diceSoNiceRollComplete',id=>{const f=this.dice?.get(id);if(f){this.dice.delete(id);try{f();}catch{}}});
    Hooks.on('preUpdateActor',(actor,changes)=>{
      for(const r of this.records.values()){if(r.doc.actorId!==actor.id&&r.doc.actor!==actor)continue;
        r.heroBefore=Number(actor.system?.resources?.heroPoints?.value);}
    });
    Hooks.on('updateActor',(actor,changes)=>{
      for(const r of this.recordsOfActor(actor)){
        const hb=r.heroBefore??r.hero;
        if(r.parts.heroSpent&&heroPointsSpent(hb,changes)>0)this.add(r,{kind:'hero',at:clock()});
        r.hero=Number(actor.system?.resources?.heroPoints?.value);r.heroBefore=undefined;
        r.readActor();
      }
    });
    for(const h of ['createItem','updateItem','deleteItem'])Hooks.on(h,item=>{if(item?.type==='condition'||item?.type==='effect')for(const r of this.recordsOfActor(item.parent))r.readActor();});
    Hooks.on('combatTurnChange',combat=>{try{this.turnChanged(combat);}catch{}});
    Hooks.on('updateCombat',(combat,changes)=>{if(!('turn' in (changes??{}))&&!('round' in (changes??{})))return;try{this.turnChanged(combat);}catch{}});
    Hooks.on('deleteCombat',()=>{const t=clock();for(const r of this.records.values())for(const m of r.R.moments)if(m.kind==='watch'&&m.end==null)m.end=t;});
    Hooks.on('updateToken',(doc,changes)=>{const f=changes?.flags?.[ID];if(f===undefined)return;const r=this.records.get(doc.id)??this.recordOf(doc);if(!r)return;
      if('v11'in f||'-=v11'in f){r.readParts();this.wake();}});
    Hooks.on('deleteToken',doc=>{this.records.delete(doc.id);});
    Hooks.on('canvasReady',()=>{this.records.clear();this.allyBuf.clear();for(const t of globalThis.canvas?.tokens?.placeables??[]){const r=this.recordOf(t);if(r)r.hero=Number(r.doc.actor?.system?.resources?.heroPoints?.value);}this.wake();});
    Hooks.on('canvasTearDown',()=>this.stopTicker());
    // (test.10) the lent bit and the level-up rib were taken out: their token flags are cleared once by the GM
    Hooks.on('canvasReady',()=>{try{if(globalThis.game?.user!==globalThis.game?.users?.activeGM)return;for(const t of globalThis.canvas?.tokens?.placeables??[]){const f=t.document?.flags?.[ID];if(!f)continue;const u={};for(const k of ['v11Lent','v11Ribs'])if(k in f)u[`flags.${ID}.-=${k}`]=null;if(Object.keys(u).length)void t.document.update(u).catch(()=>{});}}catch{}});
    Hooks.on('filamentFlightSettingsChanged',()=>{for(const r of this.records.values())r.readParts();this.wake();});
  }
}

/** Token layer Look writers for frameMoments (rim arcs, beads, glows; slots as frame-damage.mjs). */
function makeWriters(){
  const CK={glow:'glowC',rim:'rimC',bead:'beadC'};
  const w={L:null,
    put(k,a,b,c,d,col,ca=0){const L=w.L,i=L.n[k];if(i>=SLOTS[k])return false;const o=i*4,A=L[k],C=L[CK[k]];A[o]=a;A[o+1]=b;A[o+2]=c;A[o+3]=d;C[o]=col[0];C[o+1]=col[1];C[o+2]=col[2];C[o+3]=ca;L.n[k]=i+1;return true;},
    rim:(col,a,ang,spread,mode=0)=>a>.004&&w.put('rim',ang,spread,a,mode,col),
    bead:(ang,col,a,r)=>a>.01&&w.put('bead',ang,a,r,0,col),
    glow:(kind,col,a)=>a>.004&&w.put('glow',kind,0,0,0,col,a),
    nudge:(dx,dy)=>{const T=w.L.tok;if(T){T[0]+=dx;T[1]+=dy;}}};
  return w;
}
/** The one runtime (flight.mjs installs it). */
export const healRuntime=new HealRuntime();
export {VIGIL_HOLD,FEATURES};
