# Yvaelle's Toolbox 13.0.0-beta.2 (was Filament Flight) · BETA channel - Foundry VTT 14

**New in v13: The Heart Turned**, a curse the GM lays on her from a wheel round the pointer. What it is and how to use it: `docs/v13.0.0-beta.1-notes.md`.

**New in this beta (13.0.0-beta.2):** the GM can reword the six states and watch her roll, the curse shows on her Keepsake sheet, and the module's own check covers the curse (**V13 only**, about two minutes, no token needed). `docs/v13.0.0-beta.2-notes.md`.

1. **Updating:** Foundry's **Update** button (Add-on Modules) fetches it if this copy of Foundry follows the beta channel. By hand: stop Foundry and replace `Data/modules/filament-flight` with the `filament-flight` folder inside **filament-flight-13.0.0-beta.2.zip**.
2. Restart Foundry and press **Ctrl+F5** (Cmd+Shift+R on Mac) once in each browser. The HUD footer should show **v13.0.0-beta.2**.
3. **Two channels.** The one you install from is the one that copy of Foundry follows:
   - Release: `https://raw.githubusercontent.com/XiseOS/Yvaelle-Toolbox/release/module.json`
   - Beta: `https://raw.githubusercontent.com/XiseOS/Yvaelle-Toolbox/beta/module.json`
4. **The curse wheel needs a key of the GM's:** Foundry's *Configure Controls* › Yvaelle's Toolbox › **Curse wheel (GM)**. Or import the macro `macros/Curse-Wheel.json`.
5. **To try it alone:** be the GM with no player of hers connected. Select her token, tap your key, click the top of the strip once (that makes her the one who is cursed), then click the centre of the wheel. Her view plays on your own screen.
6. **Going back:** install `filament-flight-12.0.1.zip` (release) or `filament-flight-12.1.0-beta.1.zip` by hand. Your settings are kept; a curse left on her actor is ignored by the older build.
7. The menus on the map need a key of yours too: *Configure Controls* › Yvaelle's Toolbox › **Menus on her decoy and bits (hold)**.
8. What v12 is: `docs/v12.0.0-release.md`. The rename and the update channels: `docs/v12.0.1-release.md`. 12.1.0-beta.1 (her sheet's opening, Wingless mode, landing with bits at work): `docs/v12.1.0-beta.1-notes.md`.
9. Something feels off with the curse? Run the *Run Yvaelle’s Toolbox Check* macro › **V13 only** (about two minutes; it needs no token of hers, lays no curse and leaves one that is on her alone) and send the report. Best once as the GM and once as her player. For everything else: **V12 only** (about six minutes, everything put back afterwards).

---

# Filament Flight 10.0.1 - Foundry VTT 14

1. Stop Foundry. Replace `Data/modules/filament-flight` with the `filament-flight` folder inside **filament-flight-10.0.1.zip**.
2. Restart Foundry and press **Ctrl+F5** (Cmd+Shift+R on Mac) once in each browser. The HUD footer should show **v10.0.1**.
3. Don't like something? **HUD › Settings › Versions** switches each overhauled feature back to v9 on its own (also in Module Settings as *Versions · …*). To go back entirely, install `filament-flight-9.0.1-original.zip`; your settings are kept.
4. Something feels off? Run the self-check macro (`macros/Run-Filament-Flight-Check.js`, or import the `.json`) and send the report.

10.0.1 adds the self-check's **Compare** button (what costs fps while moving): `docs/v10.0.1-release.md`. Everything in v10, in one place: `docs/v10.0.0-release.md`. The per-beta notes (`docs/v10.0.0-beta.1-release.md` to `docs/v10.0.0-beta.40-release.md`) have the details.

---

# Filament Flight 9.0.1 - Foundry VTT 14

1. Stop Foundry. Replace `Data/modules/filament-flight` with the `filament-flight` folder inside **Filament-Flight-v9.0.1-Foundry-v14.zip**.
2. Restart Foundry and reload connected browsers. The HUD footer and `game.modules.get('filament-flight').api.version` should both show **9.0.1**.
3. The bundled Medkit macro is unchanged from 9.0.0. If upgrading from an earlier release, reimport **Ellies-Medkit-Macro.json** if you use it. It includes clear remembered-choice failure/retry feedback. The Medicine check, GM Bridge and healing rules retain their existing mechanics.

Existing settings, token choices, Looks and scan assignments do not need a reset. The V9 artwork switches default on and can be disabled independently in Module Settings.

## Moving-light patch

This patch reuses the light-edge mask mesh while lights move, rebuilding its triangle data only when needed. Native illumination, wall/vision work, appearance, range and update cadence are retained. See `docs/v9.0.1-release.md` for evidence and limits.

## What to try first

- Adjust a light while an examination runs, change Active pace, then Undo the light change. The examination and its newer pace continue.
- Treat a tall or offset patient. Diagnosis, work and result use one displayed patient-image centre; the work remains world-upright.
- Inspect Precision mend and Protective membrane in Enhanced medicine. Their working material and result hierarchy have been refined; the optional diagnostic still uses the same 1.6-second preparation interval.
- Open the wing animation library for the two new optional v9 gestures. Existing poses and automatic condition authority remain in control.
- Leave the bit library open, then pause, seek or change a selection. Its history cache now retains advancing playback and still resets real design changes.
- Open Tools when every bit is occupied. Keyboard focus now enters a useful job action or Close control and returns to Tools after Pause/Return.

## Choose the artwork you prefer

**V9 signature craft** controls the new wing/Resonant Core material accents and two new manual gestures. **V9 medical craft** controls the new Enhanced diagnostic/work/result art. Turning these off retains the previous artwork in their respective paths. The local formation-passage repair, patient registration and reliability fixes remain.

The Medkit's per-use **Enhanced preparation, results and release** switch still selects Classic choreography. **Diagnostic scan before treatment** remains independent and is remembered immediately for your Foundry User in this world, even if you close the dialog. Other Medkit choices save on confirmation. A failed immediate save keeps the current choice usable and offers an explicit retry.

My view quality/reduced motion/mute remain local. HUD appearance, favourites and the personal Look library belong to this browser. Scan styles and token appearance belong to the placed token. Applying a Look changes that selected token; its preview is private.

## Controls worth knowing

Shift+Land keeps deployed bits. Shift-click when turning light **on** chooses lantern; Shift-click when turning it **off** keeps the bits deployed. Click the formation shortcut to toggle random summon; Shift-click toggles formation flow. Keyboard focus and hover expose these alternatives. **Default pace for new scans** and each job's **Active pace** are separate.

## Current documentation

- `docs/v9.0.1-release.md`: moving-light patch and verification scope.
- `docs/v9.0.1-validation.json`: exact patch checks.

- `docs/v9.0.0-release.md`: changes, tradeoffs and the ranked-plan crosswalk.
- `docs/v9-api.md`: current supported examples, new gesture opt-outs and downgrade preparation.
- `docs/v9.0.0-validation.json`: exact release checks and remaining live gate.
- The separate illustrated **V9 Old versus New** PDF: matched images, motion references and measurements.

The optional Validation download contains reproducible source, tests, native/browser evidence and an isolated Foundry reference-scene builder. It is not required to run the module. Offline measurements do not certify actual Foundry FPS/GPU or independent-client ordering. Historical version-prefixed guides remain clearly historical; use the current v9 index first.
