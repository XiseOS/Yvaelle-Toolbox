/** Yvaelle’s Toolbox v13 · The Heart Turned: her side of it, on the page.
 *
 * Three sizes of the same thing, and she moves between them as she likes:
 *   the full view   a canvas over the whole window (curse-stage.mjs draws it): the choosing, her heart turning, the word
 *   the card        a small card where the mark sits: the state, who it is toward, what it says, and the roll still to make
 *   the mark        one line that stays for as long as the curse lasts: the state, the Spans left, who it is toward
 * Minimise (or Escape) folds the full view into the card at any moment; if the choosing is still under way it skips to the
 * answer first. Open grows the card, or the mark, back into the full view. Nothing replays: once it has her, it is shown as it is.
 *
 * Nothing exists while there is no curse: no element, no listener, no frame callback. The canvas and its frames exist only
 * while the full view is up (drawn at most about sixty times a second, however fast the screen is). The card and the mark
 * are a few elements and CSS.
 *
 * The view knows nothing of Foundry. Its host (curse-runtime.mjs) gives it her record and makes her rolls:
 *   host.roll(id) → {record, die, pick}   she rolled: the state, and who the roll of faith found
 *   host.root(id) → {record, spans}       she let it root: the Spans
 *   host.now()    → the world's time, in seconds
 *   host.prefs()  → {startMin, reduced, blur, markOpen}
 *   host.pos() / host.savePos({right, top})   where she dragged the mark to
 *   host.trouble(where, error)                anything that went wrong, for the module's own check
 *
 * (beta.2) The same view serves a GM who only watches (watch: true): it is given her record as it changes, has no button
 * of its own (its host's roll() and root() settle when she has rolled), says "Waiting for her roll", has Close where she
 * has Minimise, never makes a card or a mark, and tells its host when it is done (host.done(record)) so the GM's note
 * can follow. look() shows such a watcher the finished picture, as it stands, until it is closed. */
import {CURSE_NOW,CURSE_TITLE,stateIndex,stateOf,curseStage,curseOver,spansLeft,markLine,namesSomeone,spanWord,tintOf,faithPick} from './curse-model.mjs?v=13.0.0-beta.2';
import {createCurseStage,CANCELLED} from './curse-stage.mjs?v=13.0.0-beta.2';
import {tieSVG,gemSVG,CURSE_FONTS,F} from './curse-art.mjs?v=13.0.0-beta.2';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cssUrl=u=>`url("${String(u).replace(/["\\\n\r]/g,'')}")`;
/** At most this many canvas pixels (a 2560 × 1440 window is drawn at its own size; a larger one is drawn smaller and scaled up). */
export const MAX_PIXELS=4.2e6;
/** No frame is drawn sooner than this after the last (ms): a 164 Hz screen gets every third, a 60 Hz screen every one. */
export const FRAME_GAP=13.5;
/** How small the full view is where it meets the card, the mark, and (still large, mid-choosing) the card. In page px terms. */
const CARD_SCALE=.3,MARK_SCALE=.2,EMBLEM_SCALE=.09;
const NOBODY=Object.freeze({id:'',n:'Them',img:''});

export class CurseView{
  constructor({host,doc=globalThis.document,win=globalThis.window,beat=null,watch=false,words=null}={}){
    this.host=host;this.doc=doc;this.win=win;this.beat=beat;this.watch=!!watch;this.words=words;this.looking=false;this.spanning=false;
    this.rec=null;this.mode='none';this.stage=null;this.root=null;this.cv=null;this.card=null;this.mark=null;
    this.frame=0;this.last=0;this.run=0;this.shown=null;this.pick=-1;this.people=[];this.anon=null;this.themP=null;this.busy=false;this.folding=false;this.veilShown=-1;this.listeners=null;
    this.stats={arrived:0,revealed:0,minimised:0,opened:0,frames:0};
  }
  /* ───────── her record changed (or was read at start) ───────── */
  /** record: the cleaned record on her actor, or null. fresh: it was laid just now (not found there at start). */
  sync(record,{fresh=false}={}){
    // (one that has run out is gone from her page at once, whichever page it is that takes the record off her actor)
    const was=this.rec;if(record&&curseOver(record,this.now()))record=null;
    if(!record){if(was){this.rec=null;this.leave();}return;}
    if(!was||was.id!==record.id){this.rec=record;this.arrive(fresh);return;}
    this.rec=record;this.refresh();
  }
  prefs(){try{return {startMin:false,reduced:false,blur:true,markOpen:true,...(this.host?.prefs?.()??{})};}catch{return {startMin:false,reduced:false,blur:true,markOpen:true};}}
  now(){try{return this.host?.now?.()??0;}catch{return 0;}}
  /** A new curse: straight to the full view when it was laid just now, else to whichever small form fits where it stands. */
  arrive(fresh){
    this.clear();this.stats.arrived++;this.prepPeople();
    const where=curseStage(this.rec),P=this.prefs();
    // (someone only watching sees it only as it happens: nothing small is kept on their page)
    if(this.watch){if(fresh&&!P.reduced&&where!=='set')void this.reveal();return;}
    if(where==='set'){this.shown=this.rec.id;this.showMark();this.mode='mark';return;}
    if(fresh&&!P.startMin&&!P.reduced){void this.reveal();return;}
    if(where==='root')this.shown=this.rec.id;
    this.showCard();this.mode='card';
  }
  /** The curse is over (lifted, run out, or gone with her): whatever is up goes away. */
  leave(){
    this.run++;const m=this.mode;this.mode='none';
    if(m==='full'&&this.stage){const st=this.stage,my=this.run;st.cancel();st.fadeE(450).then(()=>{if(my===this.run)this.closeStage();},()=>{});}
    this.dropCard();const mk=this.mark;if(mk){this.mark=null;mk.classList.add('ff-cu-gone');this.win.setTimeout(()=>mk.remove(),700);}
  }
  /** Take everything down at once (a new curse replaces the last). */
  clear(){
    this.run++;this.busy=false;this.looking=false;this.closeStage();this.card?.remove();this.card=null;this.mark?.remove();this.mark=null;this.mode='none';this.pick=-1;
  }
  /** The same curse, with something changed (a Span burned by the GM, time passing, her own roll coming back). */
  refresh(){
    if(this.mode==='mark')this.fillMark();
    else if(this.mode==='card'&&!this.busy)this.fillCard();
    else if(this.mode==='full'&&this.stage?.posed&&this.rec.spans!==null&&this.stage.L.set>=1){const n=spansLeft(this.rec,this.now());this.stage.L.span=n;this.stage.L.cnt=n;}
    // (a watcher looking at the finished picture when she lets it root: the Spans are counted out there too)
    else if(this.looking&&!this.spanning&&this.mode==='full'&&this.stage?.posed&&this.rec.spans!==null&&this.stage.L.set<1){this.spanning=true;const my=this.run;this.stage.spansE(this.rec.spans,this.rec.die).catch(()=>{}).then(()=>{if(my===this.run)this.spanning=false;});}
  }
  /** The GM changed a state's name or text: the card and the mark are written again. */
  statesChanged(){if(!this.rec)return;if(this.mode==='card'&&!this.busy)this.fillCard();if(this.mark)this.fillMark();}
  trouble(where,e){if(e===CANCELLED)return;try{console.error('Yvaelle’s Toolbox · The Heart Turned ·',where,e);}catch{}try{this.host?.trouble?.(where,e);}catch{}}
  /** The world's clock moved: the Spans left may have changed. */
  timeChanged(){if(!this.rec)return;if(curseOver(this.rec,this.now())){this.rec=null;this.leave();}else this.refresh();}
  /* ───────── who it is about ───────── */
  /** The people of her record, with a steady pair of colours each and, once it has loaded, a small picture for the bead. */
  prepPeople(){
    const mk=p=>{const [c1,c2]=tintOf(p.n),o={...p,c1,c2,im:null};this.picture(o);return o;};
    this.people=(this.rec?.people??[]).map(mk);this.anon=mk(NOBODY);this.themP=null;
  }
  picture(o){
    if(!o.img||!this.win.Image)return;
    const im=new this.win.Image();im.decoding='async';
    im.onload=()=>{try{const c=this.doc.createElement('canvas');c.width=c.height=96;const g=c.getContext('2d'),s=Math.min(im.naturalWidth,im.naturalHeight)||1;g.filter='saturate(.6) brightness(.86)';g.drawImage(im,(im.naturalWidth-s)/2,(im.naturalHeight-s)/2,s,s,0,0,96,96);o.im=c;}catch{}};
    im.onerror=()=>{};im.src=o.img;
  }
  /** That person, as the stage draws them: the one of the list the record names, or a nameless bead where nobody is named. */
  them(){
    const t=this.rec?.toward;if(!t)return namesSomeone(this.rec?.k)?this.anon:null;
    const hit=this.people.find(p=>(p.id&&p.id===t.id)||p.n===t.n);if(hit)return hit;
    if(!this.themP||this.themP.n!==t.n){const [c1,c2]=tintOf(t.n);this.themP={...t,c1,c2,im:null};this.picture(this.themP);}return this.themP;
  }
  /* ───────── the full view ───────── */
  /** Make the canvas, start drawing, listen to the pointer and the Escape key. */
  openStage(){
    if(this.stage){this.stage.cancel();return this.stage;}
    const d=this.doc,root=d.createElement('div');root.className='ff-cu-view';root.innerHTML='<div class="ff-cu-veil"></div><canvas class="ff-cu-cv" aria-hidden="true"></canvas>';root.setAttribute('role','dialog');root.setAttribute('aria-label',CURSE_TITLE);
    if(!this.prefs().blur)root.classList.add('ff-cu-noblur');d.body.appendChild(root);
    this.root=root;this.cv=root.querySelector('canvas');this.stage=createCurseStage(this.cv,{beat:this.beat});this.stage.setPeople(this.people);if(this.words)this.stage.setWords(this.words);this.fit();this.veilShown=-1;
    const move=ev=>{const st=this.stage;if(!st)return;const [sx,sy]=st.toStage(ev.clientX,ev.clientY),h=st.hit(sx,sy);st.hover(h);this.cv.style.cursor=h?'pointer':'';};
    const down=ev=>{ev.preventDefault();ev.stopPropagation();const st=this.stage;if(!st||ev.button!==0)return;const [sx,sy]=st.toStage(ev.clientX,ev.clientY),h=st.hit(sx,sy);if(h==='min')void this.minimise();else if(h)st.press(h);};
    const key=ev=>{if(ev.key!=='Escape'||this.mode!=='full')return;ev.preventDefault();ev.stopPropagation();ev.stopImmediatePropagation?.();void this.minimise();};
    const size=()=>this.fit(),stop=ev=>{ev.preventDefault();ev.stopPropagation();};
    root.addEventListener('pointermove',move);root.addEventListener('pointerdown',down);root.addEventListener('contextmenu',stop);root.addEventListener('wheel',stop,{passive:false});
    this.win.addEventListener('keydown',key,true);this.win.addEventListener('resize',size);
    this.listeners=()=>{this.win.removeEventListener('keydown',key,true);this.win.removeEventListener('resize',size);};
    this.last=0;const tick=ts=>{if(!this.stage)return;this.frame=this.win.requestAnimationFrame(tick);if(this.last&&ts-this.last<FRAME_GAP)return;const dt=this.last?Math.min(50,ts-this.last):16;this.last=ts;this.stage.draw(dt);this.stats.frames++;
      const v=this.stage.veil;if(Math.abs(v-this.veilShown)>.02||(v===0)!==(this.veilShown===0)||(v===1)!==(this.veilShown===1)){this.veilShown=v;root.style.setProperty('--ffcu-v',v.toFixed(3));}};
    this.frame=this.win.requestAnimationFrame(tick);
    return this.stage;
  }
  fit(){
    if(!this.stage)return;const w=Math.max(320,this.win.innerWidth||1280),h=Math.max(240,this.win.innerHeight||720),dpr=this.win.devicePixelRatio||1;
    this.stage.resize({width:w,height:h,pixels:Math.min(dpr,Math.sqrt(MAX_PIXELS/(w*h)))});
  }
  closeStage(){
    if(this.frame){this.win.cancelAnimationFrame(this.frame);this.frame=0;}
    try{this.stage?.cancel();}catch{}this.stage=null;this.listeners?.();this.listeners=null;this.root?.remove();this.root=null;this.cv=null;
  }
  async fonts(){try{await Promise.race([Promise.all(CURSE_FONTS.map(f=>this.doc.fonts.load(f))),new Promise(r=>this.win.setTimeout(r,900))]);}catch{}}
  /** The whole of it, from the start: she appears, the choosing (her roll, or the one laid on her devouring the rest), her heart, the word, the Spans. */
  async reveal(){
    const my=++this.run;this.dropCard({grow:true});this.hideMark();this.mode='full';this.stats.revealed++;await this.fonts();if(my!==this.run)return;
    const st=this.openStage();
    try{
      let ti;
      if(!this.rec.k){
        await st.emblemIn(!this.watch,{wait:this.watch});if(!this.watch)await st.gate('roll');
        const out=await this.host.roll(this.rec.id);if(my!==this.run)return;if(!out)throw new Error('the roll was not made');
        this.rec=out.record;this.pick=out.pick;ti=stateIndex(this.rec.k);await st.rollE(ti);await st.takeE(ti);
      }else{ti=stateIndex(this.rec.k);this.pick=faithPick(this.rec);await st.emblemIn(false,{forced:true});await st.strikeE(ti);await st.devourE(ti);st.L.forced=true;await st.takeE(ti,{fast:true});}
      this.shown=this.rec.id;
      await st.whoE(this.them(),this.rec.pinned?-1:this.pick);await st.outE();
      await this.rooting(my);
    }catch(e){this.failed(e,my);}
  }
  /** From the finished picture: the Spans (if she has not rolled them), then it steps aside to the mark. stay: leave it up (she opened it herself). */
  async rooting(my,{asked=false,stay=false}={}){
    const st=this.stage;
    if(this.rec.spans===null){
      if(!asked)await st.askE(this.rec.die,{wait:this.watch});if(!this.watch)await st.gate('root');
      const out=await this.host.root(this.rec.id);if(my!==this.run)return;if(!out)throw new Error('the Spans were not rolled');
      this.rec=out.record;await st.spansE(out.spans,this.rec.die);
    }else if(stay)return;
    await st.wait(1300);await this.dock(my);
  }
  async dock(my){
    const st=this.stage;
    if(this.watch){await st.dockE(this.corner(),MARK_SCALE/st.V.S,()=>{try{this.host?.done?.(this.rec);}catch{}});if(my!==this.run)return;this.closeStage();this.mode='none';return;}
    this.buildMark();const at=this.gemPoint(this.mark);
    await st.dockE(at,MARK_SCALE/st.V.S,()=>this.mark?.classList.add('ff-cu-on'));if(my!==this.run)return;this.closeStage();this.mode='mark';
  }
  failed(e,my){
    if(e===CANCELLED||my!==this.run)return;
    this.trouble('the full view',e);
    // whatever went wrong, she is not left under a veil: fall back to the small form that fits the record
    this.closeStage();this.looking=false;if(!this.rec||this.watch){this.mode='none';return;}
    if(curseStage(this.rec)==='set'){this.showMark();this.mode='mark';}else{this.showCard();this.mode='card';}
  }
  /** Fold the full view away into the card (into the mark, once the Spans are set). */
  async minimise(){
    if(this.mode!=='full'||!this.stage||this.folding)return;
    // someone only watching closes it: nothing small is left behind
    if(this.watch){const my=++this.run,st=this.stage;this.stats.minimised++;this.looking=false;st.cancel();st.hover(null);this.mode='none';try{await st.fadeE(320);}catch{}if(my===this.run)this.closeStage();return;}
    this.folding=true;const my=++this.run,st=this.stage,rec=this.rec;this.stats.minimised++;st.cancel();st.hover(null);
    try{
      const set=curseStage(rec)==='set',L=st.L,choosing=!!rec.k&&L.pose<=0&&L.turn<=0&&L.heartIn>.5;
      if(choosing){await st.settleE(stateIndex(rec.k));this.shown=rec.id;}
      const el=set?this.buildMark():this.buildCard(),scale=(set?MARK_SCALE:L.pose>0?EMBLEM_SCALE+(CARD_SCALE-EMBLEM_SCALE)*L.pose:EMBLEM_SCALE)/st.V.S;
      await st.foldE(this.gemPoint(el),scale,{landed:()=>{el.classList.add('ff-cu-on');if(!set)el.classList.add('ff-cu-land');}});
      if(my!==this.run)return;this.closeStage();this.mode=set?'mark':'card';
    }catch(e){this.failed(e,my);}finally{this.folding=false;}
  }
  /** Grow the card or the mark back into the full view. */
  async open(from='card'){
    if(this.watch)return this.look();
    if(this.mode==='full'||this.busy||!this.rec)return;const rec=this.rec;this.stats.opened++;
    if(!rec.k){void this.reveal();return;}
    const my=++this.run,el=from==='mark'?this.mark:this.card;await this.fonts();if(my!==this.run)return;
    const st=this.openStage(),at=el?this.gemPoint(el):[1100,60],set=rec.spans!==null,n=set?Math.max(1,spansLeft(rec,this.now())):0;
    if(from==='mark')this.hideMark();else this.dropCard({grow:true});this.mode='full';this.shown=rec.id;
    try{
      await st.openE(stateIndex(rec.k),this.them(),n,rec.die,at,(from==='mark'?MARK_SCALE:CARD_SCALE)/st.V.S,{forced:rec.forced});
      await this.rooting(my,{asked:true,stay:true});
    }catch(e){this.failed(e,my);}
  }
  /** A watcher looks at the finished picture as it stands (her sheet's mark was pressed on the GM's page): it grows out of the corner and stays until closed. */
  async look(){
    if(!this.watch||!this.rec?.k||this.mode==='full')return;const my=++this.run,rec=this.rec;this.stats.opened++;await this.fonts();if(my!==this.run)return;
    const st=this.openStage(),set=rec.spans!==null,n=set?Math.max(1,spansLeft(rec,this.now())):0;this.mode='full';this.looking=true;
    try{await st.openE(stateIndex(rec.k),this.them(),n,rec.die,this.corner(),MARK_SCALE/st.V.S,{forced:rec.forced,wait:true});}catch(e){this.failed(e,my);}
  }
  /** Where the mark would sit, as a point of the stage (a watcher's view folds to there and grows from there). */
  corner(){const a=this.anchor(),W=this.win.innerWidth||1280;return this.stage?this.stage.toStage(W-a.right-150,a.top+26):[1100,60];}
  /** The middle of an element's small gem, as a point of the stage. */
  gemPoint(el){
    const g=el?.querySelector?.('.ff-cu-gem'),r=g?.getBoundingClientRect?.();if(!r||!this.stage)return [1100,60];
    return this.stage.toStage(r.left+r.width/2,r.top+r.height/2);
  }
  /* ───────── where the card and the mark sit ───────── */
  /** From the window's right and top edges (px): where she dragged the mark, else beside Foundry's sidebar. */
  anchor(){
    let p=null;try{p=this.host?.pos?.()??null;}catch{}
    const W=this.win.innerWidth||1280,Hh=this.win.innerHeight||720;
    if(!p||!Number.isFinite(p.right)||!Number.isFinite(p.top)){
      let right=16;try{const sb=this.doc.getElementById('sidebar')??this.doc.getElementById('ui-right'),r=sb?.getBoundingClientRect?.();if(r&&r.width>0&&r.left>W*.4)right=Math.round(W-r.left+14);}catch{}
      p={right,top:14};
    }
    return {right:Math.max(4,Math.min(W-120,p.right)),top:Math.max(4,Math.min(Hh-60,p.top))};
  }
  place(el){const a=this.anchor();el.style.right=a.right+'px';el.style.top=a.top+'px';}
  /** Foundry's sidebar opened or closed: the card and the mark move with its edge (unless she placed the mark herself). */
  replace(){if(this.card)this.place(this.card);if(this.mark)this.place(this.mark);}
  /* ───────── the card ───────── */
  buildCard(){
    if(!this.card){
      const c=this.doc.createElement('div');c.className='ff-cu-card';c.setAttribute('role','group');c.setAttribute('aria-label',CURSE_TITLE);
      c.innerHTML=`<div class="ff-cu-mh">${gemSVG(20,30)}<div class="ff-cu-hd"><div class="ff-cu-k"></div><div class="ff-cu-n"></div></div><button type="button" class="ff-cu-xp">Open</button></div>`
        +'<div class="ff-cu-tie"></div><div class="ff-cu-to"></div><div class="ff-cu-d"></div>'
        +'<div class="ff-cu-sp"><button type="button" class="ff-cu-btn"></button><span class="ff-cu-num"></span><span class="ff-cu-u"></span><span class="ff-cu-die"></span><span class="ff-cu-tl"></span></div>';
      c.querySelector('.ff-cu-xp').addEventListener('click',ev=>{ev.preventDefault();ev.currentTarget.blur?.();void this.open('card');});
      c.querySelector('.ff-cu-btn').addEventListener('click',ev=>{ev.preventDefault();ev.currentTarget.blur?.();void this.cardAct();});
      this.doc.body.appendChild(c);this.card=c;
    }
    this.place(this.card);this.fillCard();return this.card;
  }
  showCard(){const c=this.buildCard();void c.offsetWidth;c.classList.add('ff-cu-on');return c;}
  /** grow: it swells a little as it goes (the full view is growing out of it). */
  dropCard({grow=false}={}){const c=this.card;if(!c)return;this.card=null;c.classList.remove('ff-cu-on','ff-cu-land');if(grow)c.classList.add('ff-cu-grow');this.win.setTimeout(()=>c.remove(),600);}
  /** Write the card for where the record stands: the roll still to make · the state, with the Spans still to roll · all of it. */
  fillCard(){
    const c=this.card,rec=this.rec;if(!c||!rec)return;const where=curseStage(rec),e=rec.k?stateOf(rec.k):null,q=s=>c.querySelector(s);
    c.classList.toggle('ff-cu-ask',where==='ask');c.classList.toggle('ff-cu-set',where==='set');c.style.setProperty('--ffcu-ac',e?`rgb(${e.acc})`:'#ff78f6');
    q('.ff-cu-tie').innerHTML=tieSVG(e?e.acc:'255,120,246','ffcu-tie-card');
    if(!e){
      q('.ff-cu-k').textContent='A roll is asked of you';q('.ff-cu-n').textContent=CURSE_TITLE;q('.ff-cu-to').innerHTML='';
      q('.ff-cu-d').textContent='Six states, as on your table. One roll decides which takes you.';q('.ff-cu-btn').textContent='Roll';q('.ff-cu-die').textContent='1d6';q('.ff-cu-n').style.fontSize='';return;
    }
    q('.ff-cu-k').innerHTML=`${rec.forced?'It is laid on you. ':''}You are made to <b>${esc(e.w)}</b>`;q('.ff-cu-n').textContent=e.n;this.fitTitle(q('.ff-cu-n'),e.n);
    const t=rec.toward,to=q('.ff-cu-to');
    if(!namesSomeone(rec.k))to.innerHTML='<span class="ff-cu-all">all within 15 ft</span>';
    else if(t){to.innerHTML=`<i>${t.img?'':esc(t.n[0])}</i>toward <b>${esc(t.n)}</b>`;const dot=to.querySelector('i'),[c1,c2]=tintOf(t.n);dot.style.background=`radial-gradient(circle at 35% 30%,${c1},${c2})`;if(t.img){dot.style.backgroundImage=cssUrl(t.img);dot.classList.add('ff-cu-pic');}}
    else to.innerHTML='';
    q('.ff-cu-d').textContent=e.d;q('.ff-cu-btn').textContent='Let it root';q('.ff-cu-die').textContent=`1d${rec.die} Spans`;
    if(where==='set'){const n=spansLeft(rec,this.now());q('.ff-cu-num').textContent=n;q('.ff-cu-u').textContent=spanWord(n);q('.ff-cu-tl').innerHTML='<i></i>'.repeat(n);}
  }
  /** A name the GM made longer is set smaller, so it stays on one line beside Open. */
  fitTitle(node,name){
    let w=0;try{const g=(this.meter??=this.doc.createElement('canvas').getContext('2d'));g.font=F.caps(28);g.letterSpacing='1.4px';w=g.measureText(String(name)).width;}catch{}
    node.style.fontSize=w>204?`calc(${(28*204/w).toFixed(2)}px/.86)`:'';
  }
  sleep(ms){return new Promise(r=>this.win.setTimeout(r,ms));}
  /** The card's one button: Roll, then Let it root. */
  async cardAct(){
    if(this.busy||this.mode!=='card'||!this.rec||!this.card)return;const where=curseStage(this.rec),my=this.run,c=this.card,q=s=>c.querySelector(s);this.busy=true;
    try{
      if(where==='ask'){
        const out=await this.host.roll(this.rec.id);if(my!==this.run||!out)return;this.rec=out.record;this.pick=out.pick;this.shown=this.rec.id;
        // the six names run through the title, slower and slower, and stop on hers
        const ti=stateIndex(this.rec.k),n=q('.ff-cu-n');c.classList.remove('ff-cu-ask');c.classList.add('ff-cu-flick');q('.ff-cu-btn').textContent='';q('.ff-cu-die').textContent='';
        let d=62;n.style.fontSize='';for(let i=0,steps=11+ti;i<=steps;i++){n.textContent=CURSE_NOW[i%6].n;if(i<steps){await this.sleep(d);d*=1.17;if(my!==this.run)return;}}
        c.classList.remove('ff-cu-flick');this.fillCard();c.classList.remove('ff-cu-in');void c.offsetWidth;c.classList.add('ff-cu-in');
      }else if(where==='root'){
        const out=await this.host.root(this.rec.id);if(my!==this.run||!out)return;this.rec=out.record;
        c.classList.add('ff-cu-set');const num=q('.ff-cu-num'),tl=q('.ff-cu-tl');q('.ff-cu-u').textContent=spanWord(out.spans);
        for(let i=1;i<=out.spans;i++){num.textContent=i;tl.innerHTML='<i></i>'.repeat(i);num.classList.remove('ff-cu-pop');void num.offsetWidth;num.classList.add('ff-cu-pop');await this.sleep(190+110*i);if(my!==this.run)return;}
        await this.sleep(1700);if(my!==this.run||this.mode!=='card')return;
        // then it folds down to the mark
        this.dropCard();await this.sleep(300);if(my!==this.run)return;this.showMark();this.mode='mark';
      }
    }catch(e){this.trouble('the card',e);}
    finally{if(my===this.run)this.busy=false;}
  }
  /* ───────── the mark ───────── */
  buildMark(){
    if(!this.mark){
      const m=this.doc.createElement('div');m.className='ff-cu-mark';m.setAttribute('role','button');m.tabIndex=0;
      m.innerHTML=`${gemSVG(16,24)}<div class="ff-cu-tx"><div class="ff-cu-n"></div><div class="ff-cu-m"></div></div><div class="ff-cu-tl"></div>`;
      // a press opens it; a drag moves it (and where she leaves it is kept)
      let drag=null;
      m.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;const a=this.anchor();drag={x:ev.clientX,y:ev.clientY,right:a.right,top:a.top,moved:false};try{m.setPointerCapture(ev.pointerId);}catch{}});
      m.addEventListener('pointermove',ev=>{if(!drag)return;const dx=ev.clientX-drag.x,dy=ev.clientY-drag.y;if(!drag.moved&&Math.hypot(dx,dy)<5)return;drag.moved=true;m.classList.add('ff-cu-drag');
        const W=this.win.innerWidth||1280,Hh=this.win.innerHeight||720;drag.now={right:Math.max(4,Math.min(W-120,drag.right-dx)),top:Math.max(4,Math.min(Hh-60,drag.top+dy))};m.style.right=drag.now.right+'px';m.style.top=drag.now.top+'px';});
      const up=ev=>{const d=drag;drag=null;if(!d)return;try{m.releasePointerCapture(ev.pointerId);}catch{}m.classList.remove('ff-cu-drag');if(d.moved){if(d.now)try{this.host?.savePos?.(d.now);}catch{}return;}if(ev.type==='pointerup')this.markPressed();};
      m.addEventListener('pointerup',up);m.addEventListener('pointercancel',up);
      m.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();this.markPressed();}});
      this.doc.body.appendChild(m);this.mark=m;
    }
    this.place(this.mark);this.fillMark();return this.mark;
  }
  markPressed(){if(this.mode==='mark'&&this.prefs().markOpen)void this.open('mark');}
  showMark(){const m=this.buildMark();void m.offsetWidth;m.classList.add('ff-cu-on');return m;}
  hideMark(){const m=this.mark;if(!m)return;this.mark=null;m.classList.remove('ff-cu-on');this.win.setTimeout(()=>m.remove(),600);}
  fillMark(){
    const m=this.mark,rec=this.rec;if(!m||!rec?.k)return;const e=stateOf(rec.k),n=spansLeft(rec,this.now())??0,line=markLine(rec,this.now());
    m.style.setProperty('--ffcu-ac',`rgb(${e.acc})`);m.querySelector('.ff-cu-n').textContent=e.n;m.querySelector('.ff-cu-m').textContent=line;m.querySelector('.ff-cu-tl').innerHTML='<i></i>'.repeat(Math.min(6,n));
    const can=this.prefs().markOpen;m.classList.toggle('ff-cu-still',!can);m.setAttribute('aria-label',`${CURSE_TITLE}: ${e.n}, ${line}${can?'. Open':''}`);
  }
  /** What is up now (for the module's own check and the tests). */
  status(){return {watch:this.watch,mode:this.mode,id:this.rec?.id??null,stage:curseStage(this.rec),shown:this.shown===this.rec?.id,canvas:!!this.cv,card:!!this.card,mark:!!this.mark,frames:this.stats.frames,draw:this.stage?{ms:+this.stage.stats.ms.toFixed(2),worst:+this.stage.stats.worst.toFixed(2)}:null};}
}
