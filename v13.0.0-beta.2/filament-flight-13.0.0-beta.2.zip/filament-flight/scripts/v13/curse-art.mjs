/** Yvaelle’s Toolbox v13 · The Heart Turned: its line-work (canvas 2D, nothing else).
 *
 * Three things only, used by her view and by the GM's wheel alike:
 *   her light    a filament: a wide faint line, a narrower one, a white core (magenta is her energy)
 *   the curse    a briar: black stem with a dull upper edge, and thorns that go from black to bone at the tip
 *   an ember     the one warm colour the curse has, where it touches something
 * A state's own accent colour is used on one word, in her turned heart and on its flared filament, nowhere else.
 * Every helper draws with the context it was made for; none keeps state between frames. */
export const BONE='239,230,216',MAG='255,0,255',EMB='226,20,120',PI=Math.PI,TAU=PI*2;
export const lerp=(a,b,t)=>a+(b-a)*t,cl=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const E=Object.freeze({io:t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2,out:t=>1-Math.pow(1-t,3),in:t=>t*t*t,lin:t=>t});
/** Smooth value noise in [-1,1]. */
export const N1=t=>{const i=Math.floor(t),f=t-i,h=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return (s-Math.floor(s))*2-1;},u=f*f*(3-2*f);return h(i)+(h(i+1)-h(i))*u;};
/** The module's faces (styles/fonts.css) each carry a size-adjust so the Keepsake layout holds; a canvas honours it too.
 * Sizes here are the size the letters are drawn at, so each is divided by its face's adjustment. */
export const FONT_ADJ={caps:.86,serif:.92,sans:1.04};
export const F=Object.freeze({
  caps:px=>`400 ${(px/FONT_ADJ.caps).toFixed(2)}px 'Keepsake Caps'`,
  ital:px=>`italic 400 ${(px/FONT_ADJ.serif).toFixed(2)}px 'Keepsake Serif'`,
  sans:(px,w=600)=>`${w} ${(px/FONT_ADJ.sans).toFixed(2)}px 'Keepsake Sans'`});
/** The faces her view writes in, for document.fonts.load before the first frame. */
export const CURSE_FONTS=Object.freeze([F.caps(20),F.ital(20),F.sans(10)]);

export function curseArt(x){
  const path=P=>{x.beginPath();x.moveTo(P[0][0],P[0][1]);for(let i=1;i<P.length;i++)x.lineTo(P[i][0],P[i][1]);};
  /** Her light along a line. fade: let it die away toward both ends. */
  function light(P,a,fade=1){
    if(a<.01||P.length<2)return;const x0=P[0][0],x1=P[P.length-1][0];
    const g=(col,al)=>{if(!fade||Math.abs(x1-x0)<6)return `rgba(${col},${al})`;const gr=x.createLinearGradient(x0,0,x1,0);gr.addColorStop(0,`rgba(${col},0)`);gr.addColorStop(.2,`rgba(${col},${al})`);gr.addColorStop(.8,`rgba(${col},${al})`);gr.addColorStop(1,`rgba(${col},0)`);return gr;};
    x.lineCap='round';x.lineJoin='round';path(P);x.strokeStyle=g(MAG,.09*a);x.lineWidth=10;x.stroke();x.strokeStyle=g(MAG,.3*a);x.lineWidth=3.4;x.stroke();x.strokeStyle=g('255,228,251',.95*a);x.lineWidth=1.1;x.stroke();
  }
  /** The curse's stem. w: its weight. */
  function briar(P,a=1,w=1){
    if(P.length<2)return;x.lineCap='round';x.lineJoin='round';path(P);x.strokeStyle=`rgba(0,0,0,${.5*a})`;x.lineWidth=9*w;x.stroke();x.strokeStyle=`rgba(13,9,11,${a})`;x.lineWidth=5.6*w;x.stroke();
    x.save();x.translate(0,-1.5*w);path(P);x.strokeStyle=`rgba(112,84,100,${.9*a})`;x.lineWidth=Math.max(.7,1.4*w);x.stroke();x.restore();
  }
  function thorn(px,py,ang,len,a=1){
    if(len<.6)return;const dx=Math.cos(ang),dy=Math.sin(ang),tx=-dy,ty=dx,b=Math.max(1.6,len*.26),g=x.createLinearGradient(px,py,px+dx*len,py+dy*len);
    g.addColorStop(0,`rgba(13,9,11,${a})`);g.addColorStop(.6,`rgba(84,60,74,${a})`);g.addColorStop(1,`rgba(${BONE},${a})`);
    x.beginPath();x.moveTo(px-tx*b,py-ty*b);x.quadraticCurveTo(px+dx*len*.5-tx*b*.15,py+dy*len*.5-ty*b*.15,px+dx*len,py+dy*len);x.quadraticCurveTo(px+dx*len*.45+tx*b*.9,py+dy*len*.45+ty*b*.9,px+tx*b,py+ty*b);x.closePath();x.fillStyle=g;x.fill();
  }
  /** Thorns along a line, to alternate sides, every ev points. */
  function thorned(P,i0,i1,tl=1,ev=4){
    for(let i=Math.max(2,i0);i<Math.min(P.length-2,i1);i+=ev){const an=Math.atan2(P[i+1][1]-P[i-1][1],P[i+1][0]-P[i-1][0]);thorn(P[i][0],P[i][1],an+((i/ev|0)%2?1:-1)*(PI/2-.42),(8+3*((i*7)%3))*tl);}
  }
  function glow(px,py,r,a,col=MAG){
    if(a<.004||r<.5)return;const g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,`rgba(${col},${a})`);g.addColorStop(1,`rgba(${col},0)`);x.fillStyle=g;x.fillRect(px-r,py-r,r*2,r*2);
  }
  function txt(s,X,Y,font,ls,col,al=1,align='center'){
    if(al<.01)return;x.font=font;x.letterSpacing=ls+'px';x.textAlign=align;x.textBaseline='alphabetic';x.fillStyle=`rgba(${col},${al})`;x.fillText(s,X+(align==='center'?ls/2:0),Y);
  }
  /** A small capital line whose last word is in the state's accent: "YOU ARE MADE TO fear". */
  function eyebrow(A,B,acc,cx,y,a){
    if(a<.01)return;x.font=F.sans(10);x.letterSpacing='2.8px';A=A.toUpperCase()+' ';B=B.toUpperCase();const wa=x.measureText(A).width,wb=x.measureText(B).width,x0=cx-(wa+wb)/2;
    x.textAlign='left';x.textBaseline='alphabetic';x.fillStyle=`rgba(${BONE},${.6*a})`;x.fillText(A,x0,y);x.fillStyle=`rgba(${acc},${a})`;x.fillText(B,x0+wa,y);
  }
  /** A small mark for each state, drawn with the same thread. */
  function sigil(k,cx0,cy0,s,a,col){
    if(a<.01)return;x.save();x.translate(cx0,cy0);x.strokeStyle=x.fillStyle=`rgba(${col},${a})`;x.lineWidth=1.5;x.lineCap='round';x.lineJoin='round';x.beginPath();
    if(k==='protective'){x.arc(0,0,s*.62,0,TAU);x.stroke();for(let i=0;i<4;i++){const an=i*PI/2+PI/4;x.beginPath();x.moveTo(Math.cos(an)*s*.62,Math.sin(an)*s*.62);x.lineTo(Math.cos(an)*s*1.04,Math.sin(an)*s*1.04);x.stroke();}}
    else if(k==='lusty'){for(const ph of [0,PI]){x.beginPath();for(let i=0;i<=16;i++){const u=i/16;x.lineTo((u-.5)*2*s,Math.sin(u*TAU+ph)*s*.42);}x.stroke();}}
    else if(k==='needy'){for(let i=0;i<=26;i++){const u=i/26,an=u*TAU*1.4,r=s*(.12+.85*u);x.lineTo(Math.cos(an)*r,Math.sin(an)*r);}x.stroke();}
    else if(k==='resentful'){x.moveTo(-s,-s*.45);x.lineTo(0,s*.25);x.lineTo(s,-s*.45);x.stroke();x.beginPath();x.moveTo(-s*.15,s*.25);x.lineTo(0,s);x.lineTo(s*.15,s*.25);x.fill();}
    else if(k==='fearful'){for(let i=0;i<=8;i++)x.lineTo((i/8-.5)*2*s,(i%2?-1:1)*s*.4*(1-.07*i));x.stroke();}
    else{x.moveTo(-s,0);x.lineTo(-s*.1,0);x.stroke();for(const j of [-1,0,1]){x.beginPath();x.moveTo(-s*.1,0);x.quadraticCurveTo(s*.4,j*s*.2,s,j*s*.64);x.stroke();}}
    x.restore();
  }
  /** "That person": a bead strung on the thread, ringed in thorn. p: {n, c1, c2, im?} (im: a ready picture, drawn in the bead). */
  function bead(px,py,r,p,a,ring,hit){
    if(a<.01||!p)return;x.save();x.globalAlpha*=a;if(hit)glow(px,py,r+16,.6,EMB);
    const g=x.createRadialGradient(px-r*.3,py-r*.35,1,px,py,r);g.addColorStop(0,p.c1??'#6f6a72');g.addColorStop(1,p.c2??'#221d24');x.fillStyle=g;x.beginPath();x.arc(px,py,r,0,TAU);x.fill();
    if(p.im){x.save();x.beginPath();x.arc(px,py,r,0,TAU);x.clip();try{x.drawImage(p.im,px-r,py-r,r*2,r*2);}catch{}x.restore();}
    else{x.fillStyle='rgba(239,230,216,.88)';x.font=F.caps(Math.round(r*.95));x.textAlign='center';x.textBaseline='alphabetic';x.letterSpacing='0px';x.fillText((p.n||'?')[0],px,py+r*.33);}
    if(ring>0){x.strokeStyle='rgba(13,9,11,1)';x.lineWidth=3.6;x.beginPath();x.arc(px,py,r+2.5,-PI/2,-PI/2+TAU*ring);x.stroke();x.strokeStyle='rgba(112,84,100,.9)';x.lineWidth=1;x.stroke();for(let i=0;i<7*ring;i++){const an=-PI/2+i*TAU/7+.2;thorn(px+Math.cos(an)*(r+3),py+Math.sin(an)*(r+3),an+.25,7);}}
    x.restore();
  }
  /** A cut gem: two facets and a bright ridge. Turned (face 0), it is dark, with the state's ember in it and a crack. t: for the ember's pulse. */
  function gemK(px,py,w,h,face,acc,a,t=0){
    if(a<.01)return;x.save();x.translate(px,py);x.globalAlpha*=a;const T=[0,-h*.62],Rr=[w,-h*.02],Bm=[0,h*.38],Lf=[-w,-h*.02],tri=(p,q,r,col)=>{x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(q[0],q[1]);x.lineTo(r[0],r[1]);x.closePath();x.fillStyle=col;x.fill();};
    if(face>0){glow(0,-h*.1,h*.75,.34);tri(T,Lf,Bm,'rgba(255,240,253,.97)');tri(T,Rr,Bm,'rgba(244,186,236,.97)');x.strokeStyle='rgba(255,255,255,.95)';x.lineWidth=Math.max(.8,w*.12);x.beginPath();x.moveTo(T[0],T[1]);x.lineTo(Bm[0],Bm[1]);x.stroke();}
    else{glow(0,-h*.1,h*.95,.38+.2*Math.sin(t*4.6),acc);tri(T,Lf,Bm,'rgba(26,16,22,1)');tri(T,Rr,Bm,'rgba(12,8,10,1)');x.beginPath();x.moveTo(T[0],T[1]);x.lineTo(Rr[0],Rr[1]);x.lineTo(Bm[0],Bm[1]);x.lineTo(Lf[0],Lf[1]);x.closePath();x.strokeStyle='rgba(120,90,106,.95)';x.lineWidth=1.1;x.stroke();
      x.fillStyle=`rgba(${acc},1)`;x.beginPath();x.moveTo(0,-h*.32);x.lineTo(w*.36,-h*.04);x.lineTo(0,h*.17);x.lineTo(-w*.36,-h*.04);x.closePath();x.fill();
      x.strokeStyle=`rgba(${EMB},1)`;x.lineWidth=.9;x.beginPath();x.moveTo(-w*.32,-h*.5);x.lineTo(w*.2,-h*.2);x.lineTo(-w*.18,h*.08);x.lineTo(w*.16,h*.3);x.stroke();thorn(w*.92,-h*.04,-.35,h*.2);thorn(-w*.92,0,PI+.35,h*.2);}
    x.restore();
  }
  /** Break a sentence into lines no wider than maxW. */
  function wrap(s,maxW,font){
    x.font=font;x.letterSpacing='0px';const ws=String(s).split(' '),out=[];let ln='';
    for(const w of ws){const tr=ln?ln+' '+w:w;if(x.measureText(tr).width>maxW&&ln){out.push(ln);ln=w;}else ln=tr;}
    if(ln)out.push(ln);return out;
  }
  return {path,light,briar,thorn,thorned,glow,txt,eyebrow,sigil,bead,gemK,wrap};
}
/** The thorned line under the card's title, as an SVG: a stem that begins in the state's colour and trails off, thorns to alternate sides. */
export function tieSVG(acc,id='ffcu-tie'){
  const W=308,y=i=>6.5+1.1*Math.sin(i*.045)+.6*Math.sin(i*.11+1);let d='M0 '+y(0).toFixed(1),h='',X=7,k=0;for(let i=6;i<=W;i+=6)d+=' L'+i+' '+y(i).toFixed(1);
  while(X<W-8){const up=k%2?1:-1,len=3.4+2.6*((k*.61)%1);h+=`<path d="M${X.toFixed(1)} ${y(X).toFixed(1)}l${(len*.6).toFixed(1)} ${(up*len).toFixed(1)}"/>`;X+=12+24*((k*.37+.2)%1);k++;}
  return `<svg width="${W}" height="13" viewBox="0 0 ${W} 13" aria-hidden="true"><defs><linearGradient id="${id}" gradientUnits="userSpaceOnUse" x1="0" x2="${W}" y1="0" y2="0"><stop offset="0" stop-color="rgb(${acc})"/><stop offset=".3" stop-color="#e2147a" stop-opacity=".75"/><stop offset="1" stop-color="#70546a" stop-opacity=".2"/></linearGradient></defs>`
    +`<path d="${d}" fill="none" stroke="#070506" stroke-width="3.6"/><path d="${d}" fill="none" stroke="url(#${id})" stroke-width="1" transform="translate(0,-1)"/><g stroke="#efe6d8" stroke-opacity=".72" stroke-width="1.1" fill="none" stroke-linecap="round">${h}</g></svg>`;
}
/** The small gem of the card and the mark: her heart, turned (its core takes the state's colour; magenta before a state is known). */
export const gemSVG=(w=16,h=24)=>`<svg class="ff-cu-gem" width="${w}" height="${h}" viewBox="-8 -11 16 24" aria-hidden="true"><path d="M0-10 5 0 0 12-5 0Z" fill="#120c10" stroke="#70546a"/><path class="ff-cu-core" d="M0-3.4 1.8 0 0 4.4-1.8 0Z"/><path d="M5 0l4-2M-5 1l-4 2" stroke="#efe6d8" stroke-width="1"/></svg>`;
