/** Four more warp looks (12.0.0-beta.2), drawn on the warp layer like Petal,
 * Shard and Mirror: the warp copies her as the canvas shows her
 * (warp-capture.mjs), hides the real token in the same frame and animates the
 * copy. Nothing crosses the ground in any of them: she is unmade where she
 * stands and made where she lands in the same breath, so they take the same
 * time at any distance.
 *  - Flock:    she flickers, then bursts into a wheeling flock of hardlight
 *              blades cut from her own picture. Every blade turns edge-on in
 *              the same beat and is gone; over there the edges turn back.
 *  - Starfall: she dims to her own constellation. Star by star it goes out
 *              here and drops into place there.
 *  - Ribbon:   two points of light hold a seam open and her ribbons are drawn
 *              into it; over there a seam opens and they pour back out. The
 *              map squeezes toward each seam (the warp lens, sideways only).
 *  - Prism:    her signal splits: three copies slip apart, tear sideways and
 *              draw out into shafts; over there three shafts fall together.
 * All light is her magenta (#ff00ff) and shades of it. Each draw gets local
 * time u (seconds from the start). */
import {bodyPoint,captureHer,drawHer,composite} from '../warp-capture.mjs?v=13.0.0-beta.2';

const TAU=Math.PI*2,MAG='255,0,255',DEEP='216,0,216',PALE='255,156,255';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const sm=t=>{t=clamp(t);return t*t*(3-2*t);},easeOut=t=>1-(1-clamp(t))**3,easeIn=t=>clamp(t)**3,bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const lerp=(a,b,t)=>a+(b-a)*t;
const h1=(a,b=0)=>{const s=Math.sin(a*127.1+b*311.7)*43758.5453;return s-Math.floor(s);};

/** The flicker before she goes, and the time each look runs after it. */
export const PRE=.2,SETTLE=.4;
const RUN={flock:1.3,starfall:1.6,ribbon:1.2,prism:1.15};
const look=(label,id,move,cue)=>({label,duration:PRE+RUN[id]+SETTLE,move:PRE+move,cue});
/** Total length and the moment the owner's token moves (seconds), per warp. */
export const WARP_LOOKS_V12=Object.freeze({
  flock:look('Flock','flock',.56,'warpPetal'),
  starfall:look('Starfall','starfall',.62,'warpFlicker'),
  ribbon:look('Ribbon seam','ribbon',.56,'warpSeam'),
  prism:look('Prism','prism',.56,'warpShard')
});

const images=new Map();
function image(src){if(!src)return null;let img=images.get(src);if(!img){img=new Image();img.decoding='async';img.src=src;images.set(src,img);}return img.complete&&img.naturalWidth?img:null;}
function hideToken(fx,alpha){const m=fx.token?.mesh;if(!m)return;fx.baseAlpha??=m.alpha||1;m.alpha=fx.baseAlpha*clamp(alpha);}
function handoff(fx){if(fx.cap===undefined)fx.cap=captureHer(fx.token,image(fx.src));if(fx.cap)hideToken(fx,0);return fx.cap;}
/** Once her token has really arrived, hand back to it over [a,b]; returns the copy's opacity. */
function handback(fx,u,a,b){
  const t=fx.token,c=t?.center??{x:t.x+t.w/2,y:t.y+t.h/2};
  if(Math.hypot(c.x-fx.to.x,c.y-fx.to.y)>fx.size*.5)return 1;
  if(u<a)return 1;const k=sm(seg(u,a,b));hideToken(fx,Math.min(1,k*1.6));return 1-k;
}

/* ------------------------------------------------------------- sprites */
let SPR=null;
function sprites(){
  if(SPR)return SPR;const mk=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;};
  const feather=[];
  for(const [c0,c1] of [[MAG,'255,130,255'],[DEEP,'255,100,255']]){const c=mk(96,36),x=c.getContext('2d');
    x.beginPath();x.moveTo(3,18);x.lineTo(30,5);x.lineTo(93,18);x.lineTo(30,31);x.closePath();
    const g=x.createLinearGradient(3,0,93,0);g.addColorStop(0,`rgba(${c0},.1)`);g.addColorStop(.4,`rgba(${c0},.5)`);g.addColorStop(1,`rgba(${c1},.75)`);x.fillStyle=g;x.fill();
    x.strokeStyle=`rgba(${c1},.9)`;x.lineWidth=1.3;x.lineJoin='miter';x.stroke();
    x.strokeStyle='rgba(255,190,255,.85)';x.lineWidth=1.2;x.beginPath();x.moveTo(3,18);x.lineTo(93,18);x.moveTo(30,5);x.lineTo(30,31);x.moveTo(52,10);x.lineTo(52,14);x.moveTo(52,22);x.lineTo(52,26);x.moveTo(68,13);x.lineTo(68,15.5);x.moveTo(68,20.5);x.lineTo(68,23);x.stroke();
    x.fillStyle='rgba(255,210,255,.95)';x.fillRect(28,16,4,4);feather.push(c);}
  const star=mk(96,96);{const x=star.getContext('2d'),g=x.createRadialGradient(48,48,0,48,48,20);g.addColorStop(0,'rgba(255,200,255,.9)');g.addColorStop(.3,'rgba(255,40,255,.45)');g.addColorStop(1,`rgba(${MAG},0)`);x.fillStyle=g;x.fillRect(0,0,96,96);
    x.fillStyle='rgba(255,190,255,.95)';x.beginPath();const r=46,q=2.4;x.moveTo(48,48-r);x.quadraticCurveTo(48+q,48-q,48+r,48);x.quadraticCurveTo(48+q,48+q,48,48+r);x.quadraticCurveTo(48-q,48+q,48-r,48);x.quadraticCurveTo(48-q,48-q,48,48-r);x.fill();}
  return SPR={feather,star};
}

/* ------------------------------------------------------------- her picture, cut up once per warp */
function plan(fx,cap){
  if(fx.v12)return fx.v12;
  const comp=composite(cap,{wings:true,portrait:true,res:1.5}),lo=composite(cap,{wings:true,portrait:true,res:.5}),s=cap.size;
  let data=null;try{data=lo.canvas.getContext('2d',{willReadFrequently:true}).getImageData(0,0,lo.canvas.width,lo.canvas.height).data;}catch{}
  const W=lo.canvas.width,H=lo.canvas.height;
  const alpha=(x,y)=>{if(!data)return Math.hypot(x,y)<s*.5?1:0;const px=Math.round((x-lo.x0)*lo.res),py=Math.round((y-lo.y0)*lo.res);return px<0||py<0||px>=W||py>=H?0:data[(py*W+px)*4+3]/255;};
  const grid=(cell,min)=>{const out=[];for(let y=lo.y0;y<lo.y1;y+=cell)for(let x=lo.x0;x<lo.x1;x+=cell){let a=0;for(let j=0;j<3;j++)for(let i=0;i<3;i++)a+=alpha(x+cell*(i+.5)/3,y+cell*(j+.5)/3);a/=9;
      if(a>min)out.push({x,y,s:cell,a,cx:x+cell/2,cy:y+cell/2,r:h1(x,y),r2:h1(y*1.3,x*.7),r3:h1(x*.37,y*2.1)});}return out;};
  const cells=grid(s*.163,.1);
  const stars=grid(s*.13,.16).filter(c=>Math.hypot(c.cx,c.cy)>s*.42||c.r3>.45).map(c=>({...c,cx:c.cx+(c.r-.5)*s*.076,cy:c.cy+(c.r2-.5)*s*.076}));
  const span=Math.max(1,lo.x1-lo.x0);for(const st of stars)st.o=clamp((st.cx-lo.x0)/span*.72+st.r3*.28);
  const links=[];for(let i=0;i<stars.length;i++){let best=-1,bd=1e9;for(let j=0;j<stars.length;j++){if(j===i)continue;const d=Math.hypot(stars[i].cx-stars[j].cx,stars[i].cy-stars[j].cy);if(d<bd&&h1(i,j)>.35){bd=d;best=j;}}if(best>=0&&bd<s*.25)links.push([i,best]);}
  const strips=[],hgt=s*.087,step=s*.022;
  for(let y=lo.y0;y<lo.y1;y+=hgt){let x0=Infinity,x1=-Infinity;for(let x=lo.x0;x<lo.x1;x+=step)for(let j=0;j<3;j++)if(alpha(x,y+hgt*(j+.5)/3)>.2){if(x<x0)x0=x;if(x>x1)x1=x;}if(x1>x0)strips.push({y,h:hgt,x0:x0-step,x1:x1+step*1.5});}
  return fx.v12={comp,cells,stars,links,strips,tints:{}};
}
const tile=(f,pl,c,h)=>{const k=pl.comp;f.drawImage(k.canvas,(c.x-k.x0)*k.res,(c.y-k.y0)*k.res,c.s*k.res,c.s*k.res,-h/2,-h/2,h+.7,h+.7);};
function tinted(pl,key,rgb,a){
  if(pl.tints[key])return pl.tints[key];const k=pl.comp,c=document.createElement('canvas');c.width=k.canvas.width;c.height=k.canvas.height;const g=c.getContext('2d');
  g.drawImage(k.canvas,0,0);g.globalCompositeOperation='source-atop';g.globalAlpha=a;g.fillStyle=`rgb(${rgb})`;g.fillRect(0,0,c.width,c.height);return pl.tints[key]=c;
}
/** Her picture (or a tinted one) as a hologram at p: cut by scanlines, bands of it knocked sideways. */
function holo(f,fx,pl,p,sc,{alpha=1,glitch=0,seed=1,ph=0,src=null,sx=1,sy=1,cut=.6}={}){
  if(alpha<=.004)return;const k=pl.comp,cw=k.canvas.width,ch=k.canvas.height;
  const tmp=fx.tmp12??=document.createElement('canvas');if(tmp.width!==cw||tmp.height!==ch){tmp.width=cw;tmp.height=ch;}
  const g=tmp.getContext('2d');g.globalCompositeOperation='source-over';g.globalAlpha=1;g.clearRect(0,0,cw,ch);g.drawImage(src??k.canvas,0,0);
  const line=Math.max(1.5,4*k.res/Math.max(.2,sc));g.globalCompositeOperation='destination-out';g.globalAlpha=cut;g.fillStyle='#000';for(let y=(ph*line/4)%line;y<ch;y+=line)g.fillRect(0,y,cw,line*.42);
  g.globalCompositeOperation='source-over';g.globalAlpha=1;
  const m=sc/k.res,X0=p.x+k.x0*sc*sx,Y0=p.y+k.y0*sc*sy;
  f.save();f.globalAlpha=clamp(alpha);
  if(glitch<=0)f.drawImage(tmp,X0,Y0,cw*m*sx,ch*m*sy);
  else for(let y=0,i=0;y<ch;i++){const h=Math.min(ch-y,(7+h1(i,seed)*34)/m),off=h1(i,seed+7)<.4?(h1(i,seed+3)-.5)*2*glitch*.3*fx.size*sc:0;f.drawImage(tmp,0,y,cw,h,X0+off,Y0+y*m*sy,cw*m*sx,h*m*sy);y+=h;}
  f.restore();
}
function glowDot(f,x,y,r,a,rgb=MAG){if(a<=.005||r<=0)return;const g=f.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${rgb},${.5*a})`);g.addColorStop(1,`rgba(${rgb},0)`);f.fillStyle=g;f.beginPath();f.arc(x,y,r,0,TAU);f.fill();}
const whole=(f,p,cap,sc,alpha,o={})=>{if(alpha<=.004)return;f.save();f.translate(p.x,p.y);drawHer(f,cap,sc,{alpha,...o});f.restore();};

/** The frame every look shares: the flicker before, the look, the settle after. */
function run(id,f,P,fx,u,reduced,body){
  const A=P.pt(bodyPoint(fx.from,fx.pose)),B=P.pt(bodyPoint(fx.to,fx.pose)),sc=P.scale,D=fx.size*sc*(fx.pose?.k??1);
  // (her token art must be in hand before she is copied: until then the real token simply stays)
  if(fx.cap===undefined&&fx.src&&!image(fx.src)&&u<PRE*.75)return {split:0};
  const cap=handoff(fx);if(!cap)return {split:0};
  const dur=RUN[id],T=PRE+dur+SETTLE,back=handback(fx,u,T-.3,T-.05);
  if(reduced){const k=sm(seg(u,.15,PRE+dur*.6));whole(f,A,cap,sc,1-k);whole(f,B,cap,sc,k*back);return {split:0};}
  const pl=plan(fx,cap),tick=Math.floor(u*24);
  if(u<PRE){const k=u/PRE;whole(f,A,cap,sc,1);f.save();f.globalCompositeOperation='lighter';holo(f,fx,pl,A,sc,{alpha:.5*k,glitch:bump(k)*.9+.2*k,seed:tick,ph:u*40});f.restore();return {split:0};}
  const v=u-PRE;
  if(v>=dur){const k=sm(seg(v-dur,0,.34));whole(f,B,cap,sc,back*(.55+.45*k));
    if(k<1){f.save();f.globalCompositeOperation='lighter';holo(f,fx,pl,B,sc,{alpha:.55*(1-k)*back,glitch:(1-k)*.8,seed:tick,ph:u*40});f.restore();}return {split:0};}
  // her shadow and her bits go with her: out as she breaks up, back as she is made
  whole(f,A,cap,sc,1-sm(seg(v,0,.3)),{wings:0,portrait:0});whole(f,B,cap,sc,sm(seg(v,dur-.32,dur)),{wings:0,portrait:0});
  return body({f,A,B,D,sc,cap,pl,v,fx,P,q:D/147})??{split:0};
}

/* ================================ Flock ================================ */
function flockEnd(E,p,q,dir){
  const {f,pl,sc,q:px}=E,S=sprites(),burst=easeOut(seg(q,0,.5)),spin=3.1*q*q*dir,tight=sm(seg(q,.55,1));
  f.save();f.globalCompositeOperation='lighter';glowDot(f,p.x,p.y,170*px,.3*bump(seg(q,.05,1)));f.restore();
  for(const c of pl.cells){const ox=c.cx*sc,oy=c.cy*sc,L=Math.hypot(ox,oy),a0=Math.atan2(oy,ox),fk=seg(q,.74+c.r2*.16,.83+c.r2*.16);if(fk>=1)continue;
    const Rr=L*(1-.32*tight)+burst*(14+c.r*74)*px*(1-.45*tight),ang=a0+spin*(.5+.9*c.r3),x=p.x+Math.cos(ang)*Rr,y=p.y+Math.sin(ang)*Rr-burst*10*px,mix=sm(seg(q,.03,.28));
    const rot=mix*(ang+Math.PI/2*dir+(c.r2-.5)*.9),sy=lerp(1,.3+.7*Math.abs(Math.cos(q*11+c.r*6)),mix)*(1-fk*.96),h=c.s*sc;
    f.save();f.translate(x,y);f.rotate(rot);
    if(mix<1){f.save();f.globalAlpha=1-mix;f.scale(1,sy);tile(f,pl,c,h);f.restore();}
    if(mix>0){f.globalCompositeOperation='lighter';const len=h*(1.75+c.r*.9);f.save();f.scale(1,sy);f.globalAlpha=mix*Math.min(1,.35+c.a)*(.62+.2*(Math.sin(q*60+c.r*90)>.2?1:0));f.drawImage(S.feather[c.r3>.55?1:0],-len/2,-len*.19,len,len*.38);f.restore();
      if(fk>0){f.globalAlpha=bump(fk)*.9;f.strokeStyle=`rgb(${PALE})`;f.lineWidth=Math.max(1,1.3*px);f.lineCap='round';f.beginPath();f.moveTo(-h*1.5,0);f.lineTo(h*1.5,0);f.stroke();}}
    f.restore();}
}
export function drawFlock(f,P,fx,u,reduced){
  return run('flock',f,P,fx,u,reduced,E=>{const {v,A,B}=E,qo=seg(v,0,.66),qi=1-seg(v,.52,1.3);if(qo<1)flockEnd(E,A,qo,1);if(v>.52)flockEnd(E,B,qi,-1);});
}

/* ================================ Starfall ================================ */
function star(f,x,y,s,a,rot=0){if(a<=.004||s<=0)return;f.save();f.translate(x,y);if(rot)f.rotate(rot);f.globalAlpha=Math.min(1,a);f.drawImage(sprites().star,-s/2,-s/2,s,s);f.restore();}
export function drawStarfall(f,P,fx,u,reduced){
  return run('starfall',f,P,fx,u,reduced,E=>{
    const {v,A,B,sc,cap,pl,q:px}=E,dx=B.x-A.x,dy=B.y-A.y,DL=Math.hypot(dx,dy)||1,d0=[dx/DL*.8,dy/DL*.8+.6],dl=Math.hypot(d0[0],d0[1])||1,Dv=[d0[0]/dl,d0[1]/dl],F=58*px;
    whole(f,A,cap,sc,1-sm(seg(v,0,.32)),{bits:0,shadow:0});whole(f,B,cap,sc,sm(seg(v,1.12,1.6)),{bits:0,shadow:0});
    const ti=s=>.32+s.o*.62,vis=sm(seg(v,.04,.3)),out=1-sm(seg(v,1.2,1.6))*.9,S=pl.stars;
    f.save();f.globalCompositeOperation='lighter';f.lineCap='round';
    glowDot(f,A.x,A.y,150*px,.3*vis*(1-sm(seg(v,.4,.95))));glowDot(f,B.x,B.y,150*px,.3*sm(seg(v,.45,1))*out);
    f.lineWidth=Math.max(.8,px);f.strokeStyle=`rgba(255,128,255,${.5*vis})`;f.beginPath();for(const [i,j] of pl.links){const a=S[i],b=S[j];if(v<ti(a)&&v<ti(b)){f.moveTo(A.x+a.cx*sc,A.y+a.cy*sc);f.lineTo(A.x+b.cx*sc,A.y+b.cy*sc);}}f.stroke();
    f.strokeStyle=`rgba(255,128,255,${.5*out})`;f.beginPath();for(const [i,j] of pl.links){const a=S[i],b=S[j];if(v>ti(a)+.2&&v>ti(b)+.2){f.moveTo(B.x+a.cx*sc,B.y+a.cy*sc);f.lineTo(B.x+b.cx*sc,B.y+b.cy*sc);}}f.stroke();
    f.lineWidth=Math.max(1.2,2*px);const dash=[6*px,5*px];
    for(const s of S){const T=ti(s),tw=.7+.3*Math.sin(v*14+s.r*40),sz=(10+s.a*8)*(.8+.4*s.r2)*px,hx=A.x+s.cx*sc,hy=A.y+s.cy*sc,gx=B.x+s.cx*sc,gy=B.y+s.cy*sc;
      if(v<T)star(f,hx,hy,sz*(1+.6*sm(seg(v,T-.08,T))),vis*tw*.75);
      else if(v<T+.13){const k=(v-T)/.13,e1=easeIn(k)*1.2,e0=easeIn(Math.max(0,k-.45)),x1=hx+Dv[0]*F*e1,y1=hy+Dv[1]*F*e1;
        f.setLineDash(dash);f.strokeStyle=`rgba(${PALE},${1-k})`;f.beginPath();f.moveTo(hx+Dv[0]*F*e0,hy+Dv[1]*F*e0);f.lineTo(x1,y1);f.stroke();f.setLineDash([]);star(f,x1,y1,sz*.8,1-k);}
      const T2=T+.07;if(v>T2){const k=seg(v,T2,T2+.14),e=1-easeOut(k),x1=gx-Dv[0]*F*e,y1=gy-Dv[1]*F*e;
        if(k<1){f.setLineDash(dash);f.strokeStyle=`rgba(${PALE},${.9*(1-k)+.1})`;f.beginPath();f.moveTo(x1-Dv[0]*F*.5*(1-k),y1-Dv[1]*F*.5*(1-k));f.lineTo(x1,y1);f.stroke();f.setLineDash([]);}
        star(f,x1,y1,sz*(1+.9*bump(seg(v,T2+.1,T2+.3))),(k<1?.9:tw*.75)*out);}}
    f.restore();});
}

/* ================================ Ribbon seam ================================ */
function seamEnd(E,p,q,dir){
  const {f,pl,sc,q:px,fx}=E,k=pl.comp,st=pl.strips,n=st.length;if(!n)return 0;
  const shut=sm(seg(q,.74,1)),top=st[0].y*sc,bot=(st[n-1].y+st[n-1].h)*sc,mid=(top+bot)/2,y0=lerp(top-14*px,mid,shut),y1=lerp(bot+14*px,mid,shut),open=sm(seg(q,.03,.3))*(1-shut),wd=11*px*open,my=p.y+(y0+y1)/2;
  if(open>0){f.save();f.beginPath();f.moveTo(p.x,p.y+y0);f.quadraticCurveTo(p.x+wd,my,p.x,p.y+y1);f.quadraticCurveTo(p.x-wd,my,p.x,p.y+y0);
    const g=f.createLinearGradient(p.x-wd,0,p.x+wd,0);g.addColorStop(0,'#8a0f8a');g.addColorStop(.5,'#1c041c');g.addColorStop(1,'#8a0f8a');f.fillStyle=g;f.fill();f.restore();}
  const sl=fx.size*.05;
  st.forEach((s,i)=>{const ord=dir>0?i/n:1-i/n,kk=sm(seg(q,ord*.44,ord*.44+.3));if(kk>=1)return;const hh=s.h*sc,oy=lerp((s.y+s.h/2)*sc,mid,shut),sd=i%2?1:-1,wave=bump(kk);
    if(wave<.01&&shut<=0){f.drawImage(k.canvas,(s.x0-k.x0)*k.res,(s.y-k.y0)*k.res,(s.x1-s.x0)*k.res,s.h*k.res,p.x+s.x0*sc,p.y+oy-hh/2,(s.x1-s.x0)*sc,hh+.7);return;}
    for(let x=s.x0;x<s.x1;x+=sl){const rel=x*sc,dx=p.x+rel*(1-kk)+sd*wave*22*px*(1-Math.abs(rel)/(170*px)*.3),dy=p.y+oy+Math.sin(rel/px*.03+q*22+i*.8)*6*px*wave;
      f.drawImage(k.canvas,(x-k.x0)*k.res,(s.y-k.y0)*k.res,sl*k.res,s.h*k.res,dx,dy-hh/2,sl*sc*(1-kk)+.8,hh+.7);}
    if(kk>.03){f.save();f.globalCompositeOperation='lighter';const xa=p.x+s.x0*sc*(1-kk)+sd*wave*22*px,xb=p.x+s.x1*sc*(1-kk)+sd*wave*22*px,g=f.createLinearGradient(xa,0,xb,0),col=i%2?DEEP:MAG;
      g.addColorStop(0,`rgba(${col},0)`);g.addColorStop(.5,`rgba(${col},${(.75*kk).toFixed(3)})`);g.addColorStop(1,`rgba(${col},0)`);f.fillStyle=g;f.fillRect(xa,p.y+oy-hh/2,xb-xa,hh);f.restore();}});
  if(open>0){f.save();f.globalCompositeOperation='lighter';f.lineCap='round';
    for(const sg of [-1,1]){f.beginPath();f.moveTo(p.x,p.y+y0);f.quadraticCurveTo(p.x+sg*wd,my,p.x,p.y+y1);f.strokeStyle=`rgba(${MAG},${.9*open})`;f.lineWidth=3.4*px;f.stroke();f.strokeStyle=`rgba(${PALE},${open})`;f.lineWidth=1.2*px;f.stroke();}
    // tick marks down the lips, threads flicking in, and the two points that hold it open
    f.lineCap='butt';f.strokeStyle=`rgba(${DEEP},${.8*open})`;f.lineWidth=Math.max(1,1.2*px);f.beginPath();for(let j=1;j<16;j++){const yy=lerp(y0,y1,j/16),wj=wd*Math.sin(Math.PI*j/16)+3*px,ln=(j%4?5:10)*px;f.moveTo(p.x+wj,p.y+yy);f.lineTo(p.x+wj+ln,p.y+yy);f.moveTo(p.x-wj,p.y+yy);f.lineTo(p.x-wj-ln,p.y+yy);}f.stroke();
    for(let j=0;j<9;j++){const yy=lerp(y0,y1,h1(j,2)),ph=(q*3+h1(j,5))%1,len=(18+h1(j,8)*40)*px*open,sd=j%2?1:-1;f.beginPath();f.moveTo(p.x+sd*(4*px+len*(1-ph)),p.y+yy);f.lineTo(p.x+sd*(4*px+len*(1-ph)*.4),p.y+yy);f.strokeStyle=`rgba(${j%3?MAG:DEEP},${.8*open*ph})`;f.lineWidth=Math.max(1,1.4*px);f.stroke();}
    for(const [yy,sp] of [[y0-12*px,1],[y1+12*px,-1]]){f.save();f.translate(p.x,p.y+yy);f.rotate(q*8*sp);const r=7*px;f.beginPath();f.moveTo(0,-r*1.5);f.lineTo(r,0);f.lineTo(0,r*1.5);f.lineTo(-r,0);f.closePath();f.fillStyle=`rgba(${MAG},${.45*open})`;f.fill();f.strokeStyle=`rgba(255,208,255,${open})`;f.lineWidth=Math.max(1,1.6*px);f.stroke();f.restore();}
    glowDot(f,p.x,my,120*px,.35*open);f.restore();}
  const cl2=bump(seg(q,.86,1));if(cl2>0){f.save();f.globalCompositeOperation='lighter';star(f,p.x,p.y+mid,46*px*cl2,cl2*.8);f.restore();}
  return open;
}
export function drawRibbon(f,P,fx,u,reduced){
  let lens=null;
  const out=run('ribbon',f,P,fx,u,reduced,E=>{
    const {v,A,B}=E,qo=seg(v,0,.62),qi=1-seg(v,.5,1.2);if(qo<1)seamEnd(E,A,qo,1);if(v>.5)seamEnd(E,B,qi,-1);
    // the map draws in toward each seam, sideways only
    const sA=P.screen(bodyPoint(fx.from,fx.pose)),sB=P.screen(bodyPoint(fx.to,fx.pose)),gs=fx.size*P.screenScale*(fx.pose?.k??1),a=bump(seg(v,.1,.66)),b=bump(seg(v,.46,1.1));
    lens={split:0};if(a>.01){lens.lensA={x:sA.x,y:sA.y,r:gs*1.5,k:.001};lens.dirA={x:0,y:1,s:1.1*a,w:0};}if(b>.01){lens.lensB={x:sB.x,y:sB.y,r:gs*1.5,k:.001};lens.dirB={x:0,y:1,s:1.1*b,w:0};}
    return lens;});
  return out;
}

/* ================================ Prism ================================ */
function prismEnd(E,p,q){
  const {f,pl,sc,cap,q:px,fx}=E,sep=easeOut(seg(q,.04,.7)),nar=easeIn(seg(q,.3,1)),al=sm(seg(q,0,.22))*(1-sm(seg(q,.9,1)));
  whole(f,p,cap,sc,1-sm(seg(q,0,.3)),{bits:0,shadow:0});if(al<=0)return;
  const sx=1-nar*.965,sy=1+nar*.85,k=pl.comp;
  const copies=[[tinted(pl,'m',MAG,.42),-1,MAG],[tinted(pl,'d','180,0,180',.42),1,'200,0,200'],[tinted(pl,'p',PALE,.3),0,'255,160,255']];
  for(const [img,i,col] of copies){const x=p.x+i*sep*62*px,pp={x,y:p.y-i*sep*5*px};
    holo(f,fx,pl,pp,sc,{src:img,alpha:al*(i?.7:.55)*(1-nar*.5),sx,sy,glitch:bump(seg(q,.02,.6))*.7,seed:i+3+Math.floor(q*14),cut:.45,ph:q*60});
    f.save();f.globalCompositeOperation='lighter';
    if(nar>.2){const hgt=175*px*sy*sm(seg(nar,.2,.8)),g=f.createLinearGradient(0,p.y-hgt,0,p.y+hgt+20*px);g.addColorStop(0,`rgba(${col},0)`);g.addColorStop(.5,`rgba(${col},${(.6*al).toFixed(3)})`);g.addColorStop(1,`rgba(${col},0)`);f.fillStyle=g;f.fillRect(x-(1.4+3*(1-nar))*px,p.y-hgt,(2.8+6*(1-nar))*px,hgt*2+20*px);}
    for(let j=0;j<6;j++){const ph=(q*2.2+h1(j,i+4))%1,yy=p.y+lerp(-150,170,h1(j,i+9))*px+(ph-.5)*40*px;f.save();f.translate(x+(h1(j,i)-.5)*60*px*(1-nar),yy);f.rotate(Math.PI/4);f.globalAlpha=al*bump(ph)*sep;f.fillStyle='rgb(255,208,255)';const d=2.4*px;f.fillRect(-d,-d,d*2,d*2);f.restore();}
    f.restore();}
  f.save();f.globalCompositeOperation='lighter';const w=sep*90*px,g=f.createLinearGradient(p.x-w,0,p.x+w,0);g.addColorStop(0,`rgba(${MAG},0)`);g.addColorStop(.2,`rgba(${MAG},.7)`);g.addColorStop(.5,'rgba(255,160,255,.7)');g.addColorStop(.8,'rgba(200,0,200,.7)');g.addColorStop(1,'rgba(200,0,200,0)');
  f.globalAlpha=al*bump(seg(q,.05,.8))*.8;f.fillStyle=g;f.fillRect(p.x-w,p.y-1.5*px,w*2,3*px);f.globalAlpha=1;glowDot(f,p.x,p.y,160*px,.3*al);f.restore();
}
export function drawPrism(f,P,fx,u,reduced){
  return run('prism',f,P,fx,u,reduced,E=>{const {v,A,B}=E,qo=seg(v,0,.62),qi=1-seg(v,.5,1.15);if(qo<1)prismEnd(E,A,qo);if(v>.5)prismEnd(E,B,qi);});
}

const DRAW={flock:drawFlock,starfall:drawStarfall,ribbon:drawRibbon,prism:drawPrism};
export function drawWarpLookV12(id,f,P,fx,u,reduced){return DRAW[id](f,P,fx,u,reduced);}
