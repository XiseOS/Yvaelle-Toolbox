/** Keepsake · Tapestry (v11 experimental extra: Settings › Advanced › Experimental).
 *
 * Her moments woven as cloth: each is one pick of weft over a hairline warp,
 * newest at the top by the reed. Five threads, told apart by structure as
 * well as colour (the lab's tapestry.js):
 *   heal   magenta, one ply, its span follows the HP she gave
 *   fall   magenta, sags once and recovers (the drop she survived)
 *   crit   gold, a cut-diamond knot where it landed
 *   hero   gold, a petal knot (a Hero Point spent: a petal given)
 *   level  gold and ivory two-ply braid, like the Keepsake's cord
 * Sessions are parted by a gold hairline pick and labelled in the gutter.
 * Hover (or focus, ↑ ↓) a thread for its card. A new moment is woven in while
 * you watch: the reed lifts, the shuttle carries the thread across, the reed
 * beats it home. For long campaigns the older sessions fold to one band each
 * (click a band to unfold it), so the cloth never runs away.
 *
 * The body is one island the renderer leaves alone (data-ks-foreign): it is
 * drawn here, and redrawn only when her journal or the island's own state
 * changes, never on a hover. */
import {KeepsakeTab} from './shared.mjs?v=13.0.0-beta.2';
import {isOn,partOn} from '../v11/features.mjs?v=13.0.0-beta.2';
import {readActorJournal,newSession,recapFor} from '../v11/journal-runtime.mjs?v=13.0.0-beta.2';
import {foldPlan,sessionByN,sessionName,ROMAN,KINDS} from '../v11/journal.mjs?v=13.0.0-beta.2';
import {postRecap} from '../v11/recap.mjs?v=13.0.0-beta.2';
import {xicon} from '../v11/extras-icons.mjs?v=13.0.0-beta.2';

const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const f=n=>Math.round(n*100)/100;
export const TYPES={
  heal:{label:'Heal given',chip:'Heals',icon:'heal',col:'#e767ce',hi:'#ffc4ef',lo:'#8f2f7f'},
  fall:{label:'Fall survived',chip:'Falls',icon:'fall',col:'#d55bbd',hi:'#f6b8e6',lo:'#7d2a6d'},
  crit:{label:'Critical',chip:'Crits',icon:'crit',col:'#d8b77b',hi:'#fbe6b8',lo:'#7d6038'},
  hero:{label:'Hero Point spent',chip:'Hero',icon:'hero',col:'#c9a56d',hi:'#f3dcae',lo:'#6f5533'},
  level:{label:'Level up',chip:'Levels',icon:'level',col:'#cfae76',hi:'#fff1d6',lo:'#8a6d45'}
};
const G0={gutter:38,right:8,warp:12,pickH:9,groundH:4,sepH:6,bandH:18,top:30,bottomPad:22};

/* ---------------- the loom (pure strings) ---------------- */
function wave(G,x0,x1,y,amp,phase,sag){
  const pts=[];
  for(let x=x0;x<=x1+.01;x+=3){let yy=y+amp*Math.sin(Math.PI*(x-x0)/G.warp+phase);
    if(sag){const {a,w,d}=sag;if(x>a&&x<a+w)yy+=d*Math.sin(Math.PI*(x-a)/w)**2;}pts.push(`${f(x)} ${f(yy)}`);}
  return 'M'+pts.join('L');
}
/** Picks from the top (newest) down: moments of open sessions, one band per folded session. */
export function layoutLoom(J,{open=3,unfold=[],fold=true}={}){
  const G=G0,picks=[];let y=G.top,first=true;
  const plan=foldPlan(J,{open:fold?open:1e9,unfold});
  for(const sess of plan){
    if(!first){picks.push({kind:'sep',y:y+G.sepH/2,s:sess.n});y+=G.sepH;}first=false;
    if(sess.folded){picks.push({kind:'band',y:y+G.bandH/2,s:sess.n,count:sess.count});y+=G.bandH;continue;}
    const list=J.moments.filter(m=>m.s===sess.n).reverse();
    for(const m of list){picks.push({kind:'ground',y:y+G.groundH/2});y+=G.groundH;picks.push({kind:'moment',m,y:y+G.pickH/2});y+=G.pickH;}
  }
  if(picks.length){picks.push({kind:'ground',y:y+G.groundH/2});y+=G.groundH;}
  return {picks,height:y+G.bottomPad};
}
function span(G,W,m){
  const x0=G.gutter,x1=W-G.right,A=x1-x0,s=A/494;
  const w=(m.k==='heal'?96+300*(m.m||.4):m.k==='fall'?192:132)*s;
  const c=x0+A*m.x,snap=v=>x0+Math.round((v-x0)/G.warp)*G.warp;
  let a=snap(c-w/2),b=snap(c+w/2);if(a<x0){b+=x0-a;a=x0;}if(b>x1){a-=b-x1;b=x1;}
  return [Math.max(x0,a),Math.min(x1,b)];
}
function thread(G,W,p,i,noGround=false){
  const m=p.m,ty=TYPES[m.k],x0=G.gutter,x1=W-G.right,ph=(i%2)*Math.PI,y=p.y,out=[];
  if(m.k==='level'){
    const a=wave(G,x0,x1,y,1.7,ph),b=wave(G,x0,x1,y,1.7,ph+Math.PI);
    out.push(`<path d="${a}" stroke="${ty.lo}" stroke-width="3.6"/><path d="${b}" stroke="#5a4330" stroke-width="3.6"/><path d="${a}" stroke="${ty.col}" stroke-width="2.4"/><path d="${b}" stroke="#eadfcf" stroke-opacity=".85" stroke-width="2"/>`);
  }else{
    const [xa,xb]=span(G,W,m);
    if(!noGround)out.push(`<path d="${wave(G,x0,x1,y,.6,ph)}" stroke="#2c1a24" stroke-width="3"/>`);
    const w=m.k==='heal'?2.6+1.4*(m.m||.4):3,sag=m.k==='fall'?{a:(xa+xb)/2-40,w:80,d:5}:null,d=wave(G,xa,xb,y,.9,ph,sag);
    out.push(`<path d="${d}" stroke="${ty.lo}" stroke-width="${f(w+1.4)}"/><path d="${d}" stroke="${ty.col}" stroke-width="${f(w)}"/><path d="${d}" stroke="${ty.hi}" stroke-width="${f(Math.max(.7,w*.26))}" stroke-opacity=".5" transform="translate(0 -${f(w*.22)})"/>`);
  }
  return out.join('');
}
const knotX=(G,W,m)=>G.gutter+(W-G.right-G.gutter)*(m.x??.5);
function knot(G,W,p){
  const m=p.m,x=knotX(G,W,m),y=p.y;
  if(m.k==='crit')return `<g class="knot" transform="translate(${f(x)} ${f(y)})"><path d="M0 -6.4L5.2 0 0 6.4-5.2 0Z" fill="url(#ffx-kt-gold)" stroke="#5a4330" stroke-width=".8"/><path d="M-5.2 0H5.2M0 -6.4L-2 0 0 6.4 2 0Z" fill="none" stroke="#fff1d6" stroke-width=".5" stroke-opacity=".75"/>${m.saved?'<circle r="8.6" fill="none" stroke="#e767ce" stroke-width=".7" stroke-opacity=".7"/>':''}</g>`;
  if(m.k==='hero')return `<g class="knot" transform="translate(${f(x)} ${f(y+5)}) scale(1.2)"><path d="M0 0C-3 -3.6 -2.5 -7.2 0 -8.6C2.5 -7.2 3 -3.6 0 0Z" fill="#f0dfe4" stroke="#a3243f" stroke-width=".7"/><path d="M0 -2V-6.6" stroke="#a3243f" stroke-width=".45" opacity=".8"/></g>`;
  if(m.k==='fall')return `<g class="knot" transform="translate(${f(x)} ${f(y+5.6)})"><circle r="2.2" fill="#2a1424" stroke="#f6b8e6" stroke-width=".8"/></g>`;
  return '';
}
function overs(G,y,i,h,x0,x1){const out=[];let k=0;for(let x=x0+G.warp/2;x<x1;x+=G.warp,k++)if((k+i)%2===0)out.push(`M${f(x)} ${f(y-h/2)}V${f(y+h/2)}`);return out.join('');}
/** The loom's svg. */
export function loomSVG(J,W,opts={}){
  const G=G0,{picks,height}=layoutLoom(J,opts),x0=G.gutter,x1=W-G.right,H=height;
  const warps=[];for(let x=x0+G.warp/2;x<x1;x+=G.warp)warps.push(`M${f(x)} 0V${f(H)}`);
  const rows=[],falls=[];
  picks.forEach((p,i)=>{
    if(p.kind==='ground')rows.push(`<g class="pk ground"><path d="${wave(G,x0,x1,p.y,.6,(i%2)*Math.PI)}" stroke="#2c1a24" stroke-width="3"/><path d="${overs(G,p.y,i,3.4,x0,x1)}" stroke="#4a3442" stroke-width="2.2"/></g>`);
    else if(p.kind==='sep')rows.push(`<g class="pk sep"><path d="${wave(G,x0,x1,p.y,.5,0)}" stroke="#8a6d45" stroke-width="1.2" stroke-opacity=".9"/></g>`);
    else if(p.kind==='band'){
      // a folded session: a close gold-and-plum braid across the cloth, with its count
      const a=wave(G,x0,x1,p.y,2.2,0),b=wave(G,x0,x1,p.y,2.2,Math.PI);
      rows.push(`<g class="pk band" data-unfold="${p.s}" tabindex="0" role="button" aria-label="Session ${p.s}, ${p.count} moments, folded: unfold"><rect class="hit" x="${x0}" y="${f(p.y-G.bandH/2)}" width="${x1-x0}" height="${G.bandH}" fill="transparent"/>
        <path d="${a}" stroke="#5a4330" stroke-width="5"/><path d="${b}" stroke="#3a1d33" stroke-width="5"/><path d="${a}" stroke="#bf9d63" stroke-width="3"/><path d="${b}" stroke="#7a2a5c" stroke-width="2.6"/>
        <rect x="${f((x0+x1)/2-58)}" y="${f(p.y-7)}" width="116" height="14" fill="#140a10" stroke="#6a5238" stroke-width=".8"/><text x="${f((x0+x1)/2)}" y="${f(p.y+3.6)}" text-anchor="middle" class="bandtx">${p.count} thread${p.count===1?'':'s'} · folded</text></g>`);
    }else{
      const m=p.m,svg=`<g class="pk row t-${m.k}" data-id="${esc(m.id)}" tabindex="0" aria-label="${esc(TYPES[m.k].label)}: ${esc(m.t)}"><rect class="hit" x="${x0}" y="${f(p.y-G.pickH/2-1)}" width="${x1-x0}" height="${G.pickH+2}" fill="transparent"/>
        <g class="glow">${thread(G,W,p,i,true)}</g>${thread(G,W,p,i)}<path d="${overs(G,p.y,i,G.pickH-2.5,x0,x1)}" stroke="#4d3645" stroke-width="2.4"/><path d="${overs(G,p.y,i,G.pickH-2.5,x0,x1)}" stroke="#7a5d6a" stroke-width=".6" stroke-opacity=".7" transform="translate(-.5 0)"/>${knot(G,W,p)}</g>`;
      (m.k==='fall'?falls:rows).push(svg);   // (a fall's sag hangs over the pick below)
    }
  });
  // session labels in the gutter, centred on each session's band of picks
  const bands=new Map();for(const p of picks)if(p.kind==='moment'||p.kind==='band'){const s=p.m?.s??p.s;const b=bands.get(s)??[];b.push(p.y);bands.set(s,b);}
  const labels=[...bands].map(([s,ys])=>{const a=Math.min(...ys)-6,b=Math.max(...ys)+6,c=(a+b)/2;
    return `<g class="lbl"><path d="M${G.gutter-10} ${f(a)}V${f(b)}" stroke="#6a5238" stroke-width="1"/><path d="M${G.gutter-12} ${f(a)}h4M${G.gutter-12} ${f(b)}h4" stroke="#6a5238" stroke-width="1"/><text x="${G.gutter-16}" y="${f(c+4)}" text-anchor="end" class="roman">${ROMAN(s)}</text></g>`;}).join('');
  const svg=`<svg class="ffx-loomsvg" width="${W}" height="${f(H)}" viewBox="0 0 ${W} ${f(H)}" fill="none" stroke-linecap="round">
<defs><linearGradient id="ffx-kt-gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff1c4"/><stop offset=".5" stop-color="#e2c48c"/><stop offset="1" stop-color="#a8854f"/></linearGradient>
<linearGradient id="ffx-kt-warp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6a5238" stop-opacity="0"/><stop offset=".04" stop-color="#6a5238" stop-opacity=".55"/><stop offset=".96" stop-color="#6a5238" stop-opacity=".55"/><stop offset="1" stop-color="#6a5238" stop-opacity="0"/></linearGradient></defs>
<rect x="${x0-2}" y="0" width="${x1-x0+4}" height="${f(H)}" fill="#140a10"/><path d="${warps.join('')}" stroke="url(#ffx-kt-warp)" stroke-width="1"/>
<g class="cloth">${rows.join('')}${falls.join('')}</g>${labels}</svg>`;
  return {svg,picks,height:H};
}
const SHUTTLE=col=>`<svg class="ffx-shuttle" viewBox="-26 -8 52 16" aria-hidden="true"><defs><linearGradient id="ffx-sh-b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2530"/><stop offset="1" stop-color="#1a0f15"/></linearGradient></defs>
<path d="M-25 0C-16 -6.4 16 -6.4 25 0C16 6.4 -16 6.4 -25 0Z" fill="url(#ffx-sh-b)" stroke="#cfae76" stroke-width="1.1"/><rect x="-9" y="-2.6" width="18" height="5.2" rx="2.6" fill="#120a0f" stroke="#8a6d45" stroke-width=".7"/>
<rect class="bob" x="-7" y="-1.4" width="14" height="2.8" rx="1.4" fill="${col}"/><path d="M-19 0H-12M12 0H19" stroke="#8a6d45" stroke-width=".7" stroke-linecap="round"/></svg>`;
const BEAM='<div class="ffx-beam"><svg width="100%" height="10" aria-hidden="true"><rect y="1" width="100%" height="8" fill="url(#ks-cord-h)"></rect></svg></div>';

/* ---------------- the tab ---------------- */
const seenKey=actor=>`filament-flight.tapestry.seen.${actor?.id??''}`;
const REDUCED=()=>{try{return !!globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;}catch{return false;}};
export class KeepsakeTapestry extends KeepsakeTab {
  initialState(){return {unfold:[],foldAll:true};}
  renderVals(){return this.frameVals('Hover a thread to read it · ↑ ↓ walk the cloth');}
  get actor(){return this.model?.token?.document?.actor??this.model?.token?.actor??null;}
  afterRender(root){
    const island=root?.querySelector?.('[data-ks-tapestry]');if(!island)return;
    if(island!==this.island){this.island=island;this.mount(island);this.paintKey=null;}
    const actor=this.actor,J=readActorJournal(actor);this.J=J;
    const key=[actor?.id,J.moments.length,J.moments.at(-1)?.id,JSON.stringify(J.totals),J.sessions.length,this.state.unfold.join(','),this.state.foldAll,isOn('xRecap'),partOn('xTapestry','tapFold'),island.clientWidth].join('|');
    if(key===this.paintKey)return;this.paintKey=key;this.paint();
  }
  mount(el){
    el.addEventListener('mouseover',e=>{const r=e.target.closest?.('.row');if(r)this.show(r);});
    el.addEventListener('mouseleave',()=>this.hide());
    el.addEventListener('focusin',e=>{const r=e.target.closest?.('.row');if(r)this.show(r);});
    el.addEventListener('focusout',e=>{if(!el.contains(e.relatedTarget))this.hide();});
    el.addEventListener('keydown',e=>{
      const r=e.target.closest?.('.row,.band');
      if(r?.classList.contains('band')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();this.unfold(+r.dataset.unfold);return;}
      if(!r||!['ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();e.stopPropagation();
      const rows=[...el.querySelectorAll('.cloth .row')].sort((a,b)=>this.rowY(a)-this.rowY(b));const i=rows.indexOf(r);
      rows[Math.max(0,Math.min(rows.length-1,i+(e.key==='ArrowDown'?1:-1)))]?.focus({preventScroll:false});
    });
    el.addEventListener('click',e=>{
      const band=e.target.closest?.('.band');if(band){this.unfold(+band.dataset.unfold);return;}
      const b=e.target.closest?.('button[data-act]');if(!b||b.disabled)return;
      const act=b.dataset.act,ctx=this.ctx,actor=this.actor;
      if(act==='fold')this.setState({foldAll:!this.state.foldAll,unfold:[]});
      if(act==='session')void Promise.resolve(newSession(actor)).then(n=>ctx.message(`Session ${n} begins: the next moment is woven into it`)).catch(err=>ctx.message(err.message??String(err),true));
      if(act==='recap')void Promise.resolve(postRecap(actor,{recapFor,pinned:this.J?.pinned??[]})).then(()=>ctx.message('Her recap is in the chat')).catch(err=>ctx.message(err.message??String(err),true));
    });
  }
  unfold(n){this.setState({unfold:[...new Set([...this.state.unfold,n])]});}
  rowY(r){return Number(r.dataset.y)||0;}
  paint(){
    const el=this.island,J=this.J,actor=this.actor;if(!el)return;
    const W=Math.max(320,Math.round(el.clientWidth||512)),counts=J.totals,sessions=new Set(J.moments.map(m=>m.s)).size;
    const first=J.sessions[0],since=first?sessionName(first):'';
    const fold=partOn('xTapestry','tapFold')&&this.state.foldAll;
    const L=J.moments.length?loomSVG(J,W,{open:3,unfold:this.state.unfold,fold}):null;
    const total=KINDS.reduce((s,k)=>s+counts[k],0),canFold=partOn('xTapestry','tapFold')&&new Set(J.moments.map(m=>m.s)).size>3;
    const owner=!!actor?.isOwner;
    el.innerHTML=`<div class="ffx-tap-head"><div class="r1"><span class="lb">Memory tapestry</span><span class="meta"><span data-n="all">${total}</span> moment${total===1?'':'s'} · ${sessions} session${sessions===1?'':'s'}</span></div>
      <h2>${since?`Woven since ${esc(since)}`:'A loom, waiting'}</h2>
      <div class="chips">${KINDS.map(k=>`<span class="chip c-${k}" title="${esc(TYPES[k].label)}">${xicon(TYPES[k].icon)}${TYPES[k].chip}<span class="n" data-n="${k}">${counts[k]}</span></span>`).join('')}</div></div>
      ${L?`<div class="ffx-loomwrap">${BEAM}<div class="ffx-loom" style="height:${f(L.height)}px">${L.svg}<div class="ffx-ov"><div class="ffx-reed" style="transform:translateY(${f(L.picks[0].y-10)}px)"></div><div class="ffx-shut" style="transform:translate(${W-40}px,${f(L.picks[0].y-20)}px)">${SHUTTLE('#cfae76')}</div></div></div>${BEAM}</div>
      <div class="ffx-tap-foot"><span>Newest at the top, by the reed</span><span class="k"><span class="kbd">↑</span><span class="kbd">↓</span> to read each thread</span></div>`
      :`<div class="ffx-empty">${xicon('tapestry','ffx-ic big')}<p>Nothing woven yet.</p><p class="s">Heals she gives, falls she survives, her crits, Hero Points she spends and the levels she gains are woven in as they happen.</p></div>`}
      <div class="ffx-tap-acts">${isOn('xRecap')?`<button type="button" class="ffx-btn gold" data-act="recap"${owner&&J.sessions.length?'':' disabled'}>${xicon('recap')}Post recap</button>`:''}
        <button type="button" class="ffx-btn" data-act="session"${owner?'':' disabled'} title="Close this session: the next moment begins a new one">${xicon('session')}New session</button>
        ${canFold?`<button type="button" class="ffx-btn" data-act="fold">${xicon(this.state.foldAll?'unfold':'fold')}${this.state.foldAll?'Unfold all':'Fold older'}</button>`:''}</div>`;
    if(!L)return;
    for(const p of L.picks)if(p.kind==='moment'){const r=el.querySelector(`.row[data-id="${CSS.escape(p.m.id)}"]`);if(r)r.dataset.y=p.y;}
    this.L=L;this.W=W;
    this.weaveNew(L);
  }
  /* ---------------- hover cards ---------------- */
  show(row){
    const el=this.island,m=this.J?.moments.find(x=>x.id===row.dataset.id);if(!m)return;
    if(this.hot===row)return;this.hide(true);this.hot=row;
    el.querySelector('.cloth')?.classList.add('dim');row.classList.add('hot');
    const ty=TYPES[m.k],ov=el.querySelector('.ffx-ov'),y=this.rowY(row),x=m.k==='level'?this.W/2:knotX(G0,this.W,m);
    const card=document.createElement('div');card.className='ffx-tcard';card.style.setProperty('--tc',ty.col);
    card.innerHTML=`<div class="tc-top"><span class="tc-badge">${xicon(ty.icon)}</span><span class="tc-type">${esc(m.saved&&m.k==='crit'?'Saving grace':ty.label)}</span><span class="tc-sess">Session ${m.s}</span></div>
      <div class="tc-title">${esc(m.t)}</div><div class="tc-detail">${esc(m.d)}</div>${m.at?`<div class="tc-at">${esc(m.at)}</div>`:''}`;
    const tip=document.createElement('span');tip.className='ffx-tip';ov.append(card,tip);
    const ch=card.offsetHeight,cw=card.offsetWidth||248,above=y-ch-16>-4;
    card.style.left=Math.max(4,Math.min(this.W-cw-4,x-cw/2))+'px';card.style.top=(above?y-ch-14:y+14)+'px';
    tip.style.left=x+'px';tip.style.top=(above?y-14:y+14)+'px';if(!above)tip.style.transform='rotate(225deg)';
    if(!REDUCED()){card.animate([{opacity:0,transform:`translateY(${above?4:-4}px)`},{opacity:1,transform:'none'}],{duration:200,easing:'cubic-bezier(.2,.8,.2,1)'});tip.animate([{opacity:0},{opacity:1}],{duration:200});}
  }
  hide(now=false){
    const el=this.island;if(!el)return;this.hot=null;
    for(const c of el.querySelectorAll('.ffx-tcard,.ffx-tip')){if(now||REDUCED())c.remove();else c.animate([{opacity:1},{opacity:0}],{duration:120,easing:'ease-in'}).finished.then(()=>c.remove(),()=>c.remove());}
    el.querySelector('.cloth')?.classList.remove('dim');for(const r of el.querySelectorAll('.row.hot'))r.classList.remove('hot');
  }
  /* ---------------- weave-in ---------------- */
  /** New moments (since this browser last looked, at most three; or arriving while open) are woven in. */
  weaveNew(L){
    const actor=this.actor,J=this.J,el=this.island;
    let seenTs=0;try{seenTs=Number(globalThis.localStorage?.getItem(seenKey(actor)))||0;}catch{}
    const known=this.known??=new Set(seenTs?J.moments.filter(m=>m.ts<=seenTs).map(m=>m.id):J.moments.map(m=>m.id));
    const fresh=J.moments.filter(m=>!known.has(m.id)).slice(-3);
    for(const m of J.moments)known.add(m.id);
    try{globalThis.localStorage?.setItem(seenKey(actor),String(J.moments.at(-1)?.ts??0));}catch{}
    if(!fresh.length||!partOn('xTapestry','tapWeave')||REDUCED()||this.ctx.ui?.fm==='Off')return;
    const rows=fresh.map(m=>el.querySelector(`.row[data-id="${CSS.escape(m.id)}"]`)).filter(Boolean);if(!rows.length)return;
    // hide them (and roll their counts back), then weave each in turn, oldest first
    for(const r of rows)r.style.opacity='0';
    const bump=(k,d)=>{for(const n of el.querySelectorAll(`[data-n="${k}"],[data-n="all"]`))n.textContent=String(Number(n.textContent)+d);};
    for(const m of fresh)bump(m.k,-1);
    const reed=el.querySelector('.ffx-reed'),shut=el.querySelector('.ffx-shut'),ov=el.querySelector('.ffx-ov'),W=this.W;
    const E='cubic-bezier(.2,.8,.2,1)',EIO='cubic-bezier(.45,0,.2,1)',a=(n,kf,ms,o={})=>n?.animate(kf,{duration:ms,easing:E,fill:'forwards',...o});
    let fell=Math.min(...rows.map(r=>this.rowY(r)))-10,at=420;
    const order=rows.map((r,i)=>({r,m:fresh[i]})).sort((p,q)=>this.rowY(q.r)-this.rowY(p.r));
    for(const {r,m} of order){
      const y=this.rowY(r),top=y-10,ty=TYPES[m.k];
      setTimeout(()=>{if(!r.isConnected)return;shut.querySelector('.bob')?.setAttribute('fill',ty.col);
        a(reed,[{transform:`translateY(${fell}px)`},{transform:`translateY(${top}px)`}],200);
        a(shut,[{transform:`translate(${W-40}px,${fell-10}px)`},{transform:`translate(${W-20}px,${y}px)`}],200);},at);
      setTimeout(()=>{if(!r.isConnected)return;r.style.opacity='';
        // a cover slides off the new pick (outer moves left, inner counter-moves: compositor only)
        const cv=document.createElement('div');cv.className='ffx-cover';cv.style.top=(y-8)+'px';cv.style.height='16px';cv.innerHTML='<i></i>';ov.prepend(cv);
        a(cv,[{transform:'translateX(0)'},{transform:'translateX(-100%)'}],560,{easing:EIO});a(cv.firstChild,[{transform:'translateX(0)'},{transform:'translateX(100%)'}],560,{easing:EIO})?.finished.then(()=>cv.remove(),()=>cv.remove());
        a(shut,[{transform:`translate(${W-20}px,${y}px)`},{transform:`translate(${G0.gutter+26}px,${y}px)`}],560,{easing:EIO});},at+180);
      setTimeout(()=>{if(!r.isConnected)return;
        // the beat: the reed presses the pick home, the thread glows once
        a(reed,[{transform:`translateY(${top}px)`},{transform:`translateY(${top+3}px)`,offset:.4},{transform:`translateY(${top}px)`}],180,{easing:'ease-out'});
        r.querySelector('.glow')?.animate([{opacity:0},{opacity:.95,offset:.3},{opacity:0}],{duration:600,easing:'ease-out'});
        a(shut,[{transform:`translate(${G0.gutter+26}px,${y}px)`},{transform:`translate(${G0.gutter+26}px,${top-10}px)`}],200);
        bump(m.k,1);fell=top;},at+760);
      at+=1150;
    }
    setTimeout(()=>{const p0=this.L?.picks[0];if(!p0||!reed.isConnected)return;a(reed,[{transform:`translateY(${fell}px)`},{transform:`translateY(${p0.y-10}px)`}],320);
      a(shut,[{transform:`translate(${G0.gutter+26}px,${fell-10}px)`},{transform:`translate(${W-40}px,${p0.y-20}px)`}],420);},at+100);
  }
}
