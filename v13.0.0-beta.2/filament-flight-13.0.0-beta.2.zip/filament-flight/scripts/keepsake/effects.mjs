/** Keepsake · Effects. The animation library with a live private preview:
 * wing conditions (swap any style in place), reactions, gestures, poses,
 * formations, projected fields and pressed favourites. */
import {KeepsakeTab,M,SEVERITY,POSE_ART,CONDITION_ART,pips,cap} from './shared.mjs?v=13.0.0-beta.2';
import {POSE_LABELS,POSE_HINTS,CONDITION_LABELS,CONDITION_HINTS} from '../hud-model.mjs?v=13.0.0-beta.2';
import {pickerChoices,pickerValue,REACTION_LABELS} from '../effect-picker-model.mjs?v=13.0.0-beta.2';
import {CONDITION_IDS,REACTION_IDS,DEFAULT_CONDITION_ART,styleLabel} from '../effect-catalog.mjs?v=13.0.0-beta.2';
import {resolveEffectStyle} from '../effect-styles.mjs?v=13.0.0-beta.2';
import {animationChoices} from '../animation-browser.mjs?v=13.0.0-beta.2';
import {orderedTokenEffects} from '../token-effects.mjs?v=13.0.0-beta.2';
import {ROUTINES,startRoutine,listSpecimens,deleteSpecimen} from '../routines.mjs?v=13.0.0-beta.2';
import {hudBitGroups} from '../hud-model.mjs?v=13.0.0-beta.2';

const REACTION_ART={damage:'drooped',critical:'aggressiveFlare',heal:'raised',flare:'aggressiveFlare',pulse:'neutral',stutter:'trailing',reform:'collapsed'};
const PLAYABLE=new Set(['flare','pulse','stutter','reform','critical']);
const SHOW=24;
const formationOptions=model=>({library:(()=>{try{return game.settings.get('filament-flight','formationLibrary');}catch{return 'all';}})(),v7Enabled:model.state?.v7?.enabled===true&&model.state?.v7?.formations===true,v9SignatureCraft:model.cfg?.v9SignatureCraft===true});

export class KeepsakeEffects extends KeepsakeTab {
  initialState(){return {cat:this.props.ctx.pending?.cat??'conditions',sel:this.props.ctx.pending?.sel??null,cand:null,open:null,playing:true,slow:false,compare:false,query:'',rk:0,cmpPhase:0,delArm:null};}
  onEscape(){if(this.state.open!=null){this.setState({open:null});return true;}return false;}
  count(){const g=this.model.bitTasks?.homeGroup,s=this.model.state;return Math.max(1,Math.min(4,g?.presentCount||g?.count||this.model.bitTasks?.preferredCount||s?.bitCount?.count||4));}
  library(){
    const model=this.model,art=id=>`${this.ctx.root}/assets/hud/pose-${id}.svg`,count=this.count();
    let gestures=[],formations=[];
    try{gestures=animationChoices('wing',4,'wings',formationOptions(model));}catch{}
    try{formations=animationChoices('bits',count,'wings',formationOptions(model));}catch{}
    return {
      conditions:{name:'Conditions',items:CONDITION_IDS.map(id=>({id,name:CONDITION_LABELS[id],tag:'Wing condition',desc:CONDITION_HINTS[id]??'',thumb:art(CONDITION_ART[id])}))},
      reactions:{name:'Reactions',use:'Play now',items:REACTION_IDS.map(id=>({id,name:REACTION_LABELS[id]??cap(id),tag:PLAYABLE.has(id)?'Quick reaction':'Preview only',desc:'',thumb:art(REACTION_ART[id]??'neutral')}))},
      gestures:{name:'Gestures',use:'Perform',items:gestures.map(g=>({id:g.id,name:g.label,tag:'Wing gesture',desc:g.description,thumb:art('raised')}))},
      poses:{name:'Poses',use:'Hold this pose',items:Object.keys(POSE_LABELS).map(id=>({id,name:POSE_LABELS[id],tag:'Wing pose',desc:POSE_HINTS[id]??'',thumb:art(POSE_ART[id]??'neutral')}))},
      formations:{name:'Formations',use:'Use formation',bits:true,items:formations.map(f=>({id:f.id,name:f.label,tag:f.category,desc:f.description,thumb:art('neutral')}))},
      routines:{name:'Routines',use:'Play for everyone',items:Object.entries(ROUTINES).map(([id,r])=>({id,name:r.name,tag:r.needs==='target'?'Then click a token':r.needs==='point'?'Then click a spot':r.needs==='allyThreat'?'Then click the threat':id==='searchlights'?'Toggle':id==='constellation'?'Her and her allies':'Around Ellie',desc:r.hint,thumb:art(id==='searchlights'?'drooped':id==='watchOut'?'aggressiveFlare':'raised')}))},
      specimens:{name:'Specimens',use:'Present again',items:(model.token?listSpecimens(model.token):[]).map(s=>({id:String(s.at),name:s.note||s.name||'Specimen',tag:[s.name,new Date(s.at).toLocaleDateString(undefined,{day:'numeric',month:'short'})].filter(Boolean).join(' · '),desc:(s.name&&s.note&&s.note!==s.name?s.name+' · ':'')+'Held in light and filed '+new Date(s.at).toLocaleString(undefined,{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}),thumb:s.img||art('neutral'),spec:s}))},
      fields:{name:'Fields',use:'Project field',items:orderedTokenEffects().map(p=>({id:p.id,name:p.label,tag:p.legacy?'Legacy':cap(p.category),desc:p.description??'',thumb:art('cocoon')}))}
    };
  }
  /** What the stage shows for an item of a category. */
  spec(cat,id,style){
    if(cat==='conditions')return {kind:'wing',selection:{kind:'condition',key:id,id:style??pickerValue(this.model,'condition',id)}};
    if(cat==='reactions')return {kind:'wing',selection:{kind:'reaction',key:id,id:'default'}};
    if(cat==='gestures')return {kind:'wing',selection:{kind:'wing',id}};
    if(cat==='poses')return {kind:'wing',selection:{kind:'pose',id}};
    if(cat==='formations')return {kind:'bits',id,count:this.count()};
    if(cat==='fields')return {kind:'tokenFX',id,count:this.count()};
    return null;
  }
  renderVals(){
    const s=this.state,ctx=this.ctx,model=this.model,token=model.token;
    const lib=this.library(),favs=ctx.ui.favs??{};
    const favList=Object.keys(favs).filter(k=>favs[k]).map(k=>{const [cat,id]=k.split(':');const it=lib[cat]?.items.find(x=>x.id===id);return it?{...it,cat,tag:lib[cat].name}:null;}).filter(Boolean);
    lib.pressed={name:'Pressed',use:'Use',items:favList};
    const q=s.query.trim().toLowerCase(),match=it=>!q||`${it.name} ${it.tag} ${it.desc}`.toLowerCase().includes(q);
    const cat=lib[s.cat]?s.cat:'conditions';
    const cats=Object.keys(lib).map(id=>({name:lib[id].name,count:String(lib[id].items.filter(match).length),on:cat===id?'true':'false',isPressed:id==='pressed',
      cls:'tag cat'+(cat===id?' on':''),pick:()=>this.setState({cat:id,sel:null,cand:null,open:null,compare:false,rk:s.rk+1})}));
    const items=lib[cat].items.filter(match);
    const selItem=items.find(it=>it.id===s.sel)??items[0]??null;
    const itemCat=selItem?.cat??cat;
    const isConditions=cat==='conditions';
    // Condition rows
    const condRows=isConditions?items.map(it=>{
      const id=it.id,current=pickerValue(model,'condition',id),choices=pickerChoices('condition',id);
      const resolved=current==='default'?resolveEffectStyle(model.state?.requested??{},id,model.cfg??{}):current;
      const concrete=resolved==='animated'?DEFAULT_CONDITION_ART[id]:resolved;
      const label=choices.find(c=>c.id===concrete)?.label??(()=>{try{return styleLabel(concrete);}catch{return cap(concrete);}})();
      const custom=model.state?.requested?.effectStyles?.[id]!=null;
      const defLabel=choices.find(c=>c.id===DEFAULT_CONDITION_ART[id])?.label??'module default';
      const on=selItem?.id===id,open=s.open===id;
      return {name:it.name,sev:SEVERITY[id],anim:label,custom,note:custom?'Your choice · default '+defLabel:current==='default'?'Default for '+it.name.toLowerCase():'Default',noteColor:custom?'#e2c48c':'#7f6f69',thumb:it.thumb,
        on:on?'true':'false',rowCls:'condrow'+(on?' on':''),pips:pips(SEVERITY[id]),isOpen:open,open:open?'true':'false',chev:'chev'+(open?' open':''),
        pick:()=>this.setState({sel:id,cand:null,rk:s.rk+1}),
        toggleSwap:()=>this.setState({open:open?null:id,sel:id,cand:null,rk:s.rk+1}),
        enter:()=>this.setHint({click:'Preview '+it.name+' · '+label,shift:''}),
        enterSwap:()=>this.setHint({click:'Choose another animation for '+it.name,shift:''}),
        choices:choices.filter(c=>c.id!=='none').map(c=>({name:c.label,thumb:it.thumb,cls:'tag'+(c.id===current?' on':'')+(s.cand===c.id&&on?' cand':''),
          enter:()=>{this.setHint({click:'Try '+c.label+' on '+it.name+(c.description?' · '+c.description:''),shift:''});if(s.sel!==id||s.cand!==c.id)this.setState({sel:id,cand:c.id});},
          pick:()=>{if(s.sel!==id||s.cand!==c.id)this.setState({sel:id,cand:c.id===current?null:c.id,rk:s.rk+1});this.setHint({click:c.id===current?it.name+' already uses '+c.label:'Selected '+c.label+' · press Keep for '+it.name+' to use it',shift:''});}}))};
    }):[];
    const cards=isConditions?[]:items.slice(0,SHOW).map(it=>{const on=selItem?.id===it.id;
      return {name:it.name,tag:it.tag,on:on?'true':'false',fav:!!favs[`${it.cat??cat}:${it.id}`],thumb:it.thumb,hasBits:(it.cat??cat)==='formations',tagColor:/^New/.test(it.tag)?'#e2c48c':'#9c8a80',cls:'card'+(on?' on':''),
        pick:()=>this.setState({sel:it.id,rk:s.rk+1}),enter:()=>this.setHint({click:'Preview '+it.name+' privately'+(it.desc?' · '+it.desc:''),shift:''})};});
    // Stage
    let kicker='',useLabel='Use',spec=null,ghost=null;
    if(selItem){
      if(isConditions){
        const current=pickerValue(model,'condition',selItem.id),choice=s.cand??current;
        const resolved=choice==='default'?resolveEffectStyle(model.state?.requested??{},selItem.id,model.cfg??{}):choice;
        const concrete=resolved==='animated'?DEFAULT_CONDITION_ART[selItem.id]:resolved;
        const label=pickerChoices('condition',selItem.id).find(c=>c.id===concrete)?.label??pickerChoices('condition',selItem.id).find(c=>c.id===choice)?.label??cap(choice);
        kicker='Wing condition · '+selItem.name;useLabel=s.cand&&s.cand!==current?'Keep for '+selItem.name:'In use for '+selItem.name;
        spec=this.spec('conditions',selItem.id,choice);
        if(s.compare&&choice!==current){spec={...spec,alternate:[this.spec('conditions',selItem.id,current),spec]};ghost=s.cmpPhase===0?'Now: what you use today':'Trying: '+label;}
        else if(s.compare)ghost='This is what you use now';
        selItem.stageName=label;
      }else{kicker=(lib[itemCat]?.name??'')+(selItem.tag?' · '+selItem.tag:'');useLabel=lib[itemCat]?.use??'Use';spec=this.spec(itemCat,selItem.id);selItem.stageName=selItem.name;
        if(itemCat==='fields'&&this.fieldOn(selItem.id)){useLabel='Stop this field';kicker+=' · playing now';}
        if(itemCat==='routines'&&selItem.id==='searchlights'&&this.model.token?.document?.getFlag?.('filament-flight','restLights'))useLabel='Turn searchlights off';
        if(itemCat==='reactions'&&!PLAYABLE.has(selItem.id))useLabel='Preview on her (only you)';}
    }
    if(spec){spec.paused=!s.playing;spec.speed=s.slow?.5:1;spec.restart=s.rk;spec.cache=true;}
    this.previewSpecs={stage:spec};
    const failed=ctx.previewFailed('stage');
    const favKey=selItem?`${itemCat}:${selItem.id}`:null,fav=!!(favKey&&favs[favKey]);
    const base=this.frameVals(this.defaultNote(selItem));
    const counts=Object.fromEntries(Object.entries(lib).map(([k,v])=>[k,v.items.length]));
    return {...base,
      cats,libCount:`${counts.conditions} conditions · ${counts.reactions} reactions · ${counts.formations} formations · ${counts.fields} fields`,
      query:s.query,onSearch:e=>{const v=e.target.value??'';if(v!==s.query)this.setState({query:v,sel:null});},searchKey:e=>{if(e.key==='Escape'&&s.query){e.preventDefault();e.stopPropagation();this.setState({query:''});}e.stopPropagation();},
      isConditions,isCards:!isConditions,conds:condRows,cards,catName:lib[cat].name,gridWv:'wv'+(this.bump('cat',cat)%2),
      moreNote:cat==='specimens'?(items.length?`${items.length} filed · Present again shows one to everyone · Delete removes it`:'No specimens yet · in Routines, play Specimen in light, click a token and write a note · it is filed here'):cat==='pressed'?(favList.length?'Press any effect with the flower to keep it here':'Nothing pressed yet · use the flower on any preview'):items.length>SHOW?`Showing ${SHOW} of ${items.length} · search to find the rest`:items.length?`${items.length} in ${lib[cat].name.toLowerCase()}`:'Nothing matches that search',
      pvLive:!!spec&&!failed,pvStatic:!spec||failed,pvSrc:selItem?.thumb??`${ctx.root}/assets/hud/pose-neutral.svg`,pvAlt:'Preview of '+(selItem?.stageName??'nothing'),
      pvName:selItem?.stageName??'Nothing selected',pvKicker:kicker.toUpperCase(),pvNameSw:this.sw('pvname',selItem?.stageName),
      pvCls:'pv k-breathe',pvWrap:'pvwrap '+(s.rk%2?'in1':'in0')+(s.playing?'':' paused')+(s.slow?' slow':''),
      showGhostStatic:false,ghostSrc:'',showGhost:!!ghost,ghostLabel:ghost??'',ghostSw:'sw'+(s.cmpPhase%2),
      showOrbitStatic:failed&&itemCat==='formations',orbitCls:'orbit'+(s.playing?'':' paused'),showFieldStatic:failed&&itemCat==='fields',fieldCls:'field-fx'+(s.playing?'':' paused'),
      playIcon:s.playing?'M7 4h4v16H7zM14 4h4v16h-4z':'M8 4.5l12 7.5-12 7.5z',playLabel:s.playing?'Pause preview':'Play preview',
      togglePlay:()=>this.setState({playing:!s.playing}),replay:()=>this.setState({rk:s.rk+1,playing:true}),
      slowOn:s.slow?'true':'false',slowCls:'tag'+(s.slow?' on':''),toggleSlow:()=>this.setState({slow:!s.slow}),
      canCompare:isConditions||itemCat==='reactions',compareOn:s.compare?'true':'false',compareCls:'tag'+(s.compare&&isConditions?' on':''),
      compareLabel:isConditions?'Compare':'Style…',
      toggleCompare:()=>{if(isConditions)this.setState({compare:!s.compare,cmpPhase:0});else if(selItem)ctx.click('pickEffect',`reaction:${selItem.id}`);},
      favOn:fav?'true':'false',favLabel:fav?'Unpress '+(selItem?.name??''):'Press '+(selItem?.name??'')+' as a favourite',
      favStyle:'width: 34px; height: 34px;'+(fav?' box-shadow: inset 0 0 0 1px #e2c48c, inset 0 0 0 3px #160d13, inset 0 0 8px rgba(226,196,140,.4);':''),
      favImg:'width: 16px; height: 16px; transition: opacity .3s, transform .4s cubic-bezier(.3,1.5,.5,1); '+(fav?'opacity: 1; transform: scale(1.1) rotate(-12deg);':'opacity: .35; filter: grayscale(1);'),
      toggleFav:()=>{if(!favKey)return;ctx.saveUI({favs:{...favs,[favKey]:!fav}});ctx.message(fav?selItem.name+' unpressed':selItem.name+' pressed and kept');},
      useLabel,useIt:()=>selItem&&this.use(itemCat,selItem),
      canDelete:itemCat==='specimens'&&!!selItem,deleteLabel:s.delArm&&s.delArm===selItem?.id?'Confirm delete':'Delete',deleteCls:'tag'+(s.delArm&&s.delArm===selItem?.id?' on':''),
      deleteIt:()=>{if(!selItem||itemCat!=='specimens')return;const token=this.model.token;if(!token)return;
        if(s.delArm!==selItem.id){this.setState({delArm:selItem.id});ctx.message('Press Confirm delete to remove '+selItem.name);return;}
        Promise.resolve(deleteSpecimen(token,selItem.spec.at)).then(()=>{this.setState({delArm:null,sel:null,rk:s.rk+1});ctx.message(selItem.name+' deleted');}).catch(e=>ctx.message(e?.message??String(e)));},
      hintDelete:()=>this.setHint({click:s.delArm===selItem?.id?'Remove this specimen for good':'Delete this specimen (asks to confirm)',shift:''}),
      hintPlay:()=>this.setHint({click:s.playing?'Pause the preview':'Play the preview',shift:''}),
      hintReplay:()=>this.setHint({click:'Play it again from the start',shift:''}),
      hintSlow:()=>this.setHint({click:'Watch at half speed',shift:''}),
      hintCompare:()=>this.setHint({click:isConditions?'Alternate between what this condition uses now and what you are trying':'Choose how this reaction looks',shift:''}),
      hintFav:()=>this.setHint({click:fav?'Unpress this favourite':'Press it as a favourite · it joins Pressed',shift:''}),
      hintUse:()=>this.setHint({click:isConditions?'Keep this animation for '+(selItem?.name??''):useLabel+' · '+(selItem?.name??''),shift:''})
    };
  }
  /** The field the home bits are projecting now, if any. */
  homeEffect(){try{return (hudBitGroups(this.model).find(g=>g.id==='home')??this.model.bitTasks?.homeGroup)?.effect??null;}catch{return this.model.bitTasks?.homeGroup?.effect??null;}}
  fieldOn(id){const e=this.homeEffect();return !!(e?.enabled&&(id==null||e.id===id));}
  defaultNote(sel){return this.model.token?'Browse freely · nothing changes until you choose':'Select or pin a character you own to begin';}
  assign(cond,id,previous,label){
    const ctx=this.ctx;
    ctx.pushUndo(`${CONDITION_LABELS[cond]} animation`,()=>ctx.run('effectStyles',{[cond]:previous==='default'?null:previous}));
    this.setState({cand:null,sel:cond});
    void ctx.run('effectStyles',{[cond]:id==='default'?null:id}).then(()=>ctx.message(`${CONDITION_LABELS[cond]} now shows ${label}`));
  }
  use(cat,item){
    const ctx=this.ctx,s=this.state,c=ctx.controller;
    if(cat==='conditions'){if(s.cand){const current=pickerValue(this.model,'condition',item.id);const label=pickerChoices('condition',item.id).find(x=>x.id===s.cand)?.label??s.cand;this.assign(item.id,s.cand,current,label);}else ctx.message(item.name+' already uses this animation');return;}
    if(cat==='reactions'){if(!this.model.state?.enabled){ctx.message('Shown privately on the stage above · open the wings to see it on her token');return;}
      ctx.run(PLAYABLE.has(item.id)?item.id:'previewReaction',item.id);if(!PLAYABLE.has(item.id))ctx.message(item.name+' · on her token, only you see it');return;}
    if(cat==='gestures'){ctx.run('wingGesture',item.id);return;}
    if(cat==='poses'){ctx.run('pose',item.id);return;}
    if(cat==='formations'){c.bitGroup='home';ctx.run('bitGroup',{group:'home',patch:{program:item.id}});return;}
    if(cat==='fields'){c.bitGroup='home';const on=this.fieldOn(item.id);
      void Promise.resolve(ctx.run('bitEffect',{group:'home',patch:{id:item.id,enabled:!on}})).then(()=>ctx.message(on?item.name+' stopped':item.name+' projecting · press again to stop'));return;}
    if(cat==='specimens'){const token=this.model.token;if(!token||!item.spec)return;
      Promise.resolve(startRoutine(token,'specimen',{present:item.spec})).then(()=>ctx.message(item.name+' · presenting to everyone')).catch(e=>ctx.message(e?.message??String(e)));return;}
    if(cat==='routines'){const token=this.model.token;if(!token){ctx.message('Pin a character you own first');return;}
      const need=ROUTINES[item.id]?.needs,targeted=[...(game.user?.targets??[])].filter(t=>t!==token).length;
      if(need==='point')ctx.message('Now click where the bridge reaches · Esc cancels');
      else if(need==='target'&&targeted!==1||need==='allyThreat'&&!targeted)ctx.message(need==='target'?'Now click the token on the canvas · Esc cancels':'Now click the threat on the canvas · Esc cancels');
      Promise.resolve(startRoutine(token,item.id)).then(r=>{if(r!==false)ctx.message(item.id==='searchlights'?(r?'Resting searchlights on':'Resting searchlights off'):item.name+' · playing for everyone');}).catch(e=>ctx.message(e?.message??String(e)));}
  }
}
