/** Keepsake sheet (beta.27): her portrait studio. Three ways to show her:
 *  Keepsake      the module's art; her expression follows her HP (as in the HUD),
 *                in the Original, Resolute or Pained expressions.
 *  One portrait  one image (her actor image), framed and tinted by her HP.
 *  My stages     her own image for each stage of her HP; an empty stage
 *                borrows the nearest healthier one. Thresholds can be moved.
 * Saved on her actor as she changes it, so her sheet and the HUD on every
 * screen show the same portrait. The design is the one agreed on the canvas. */
import {DCLogic,KeepsakeHost,compileTemplate} from '../runtime.mjs?v=13.0.0-beta.2';
import {PORTRAIT_STAGES,PORTRAIT_STAGE_NAMES,keepsakeArt,cleanThresholds,portraitStage,resolveStage,cleanPortrait} from './model.mjs?v=13.0.0-beta.2';
import {portraitConfig,savePortraitConfig} from './prefs.mjs?v=13.0.0-beta.2';
import {heartTrace} from '../heartbeat.mjs?v=13.0.0-beta.2';
import {loadSprite,moduleRoute,moduleVersion} from './sprite.mjs?v=13.0.0-beta.2';

const ID='filament-flight';
const SN=PORTRAIT_STAGE_NAMES,STAGES=PORTRAIT_STAGES;
const SICON={healthy:'attr-con',light:'st-hp',wounded:'c-wounded',severe:'c-bleed',critical:'c-dying',unconscious:'c-unconscious'};
const SCOL={healthy:'#e767ce',light:'#e9a0d8',wounded:'#e2a256',severe:'#d9714a',critical:'#c8324f',unconscious:'#9a90d6'};
const SETS=[['original','Original','The restrained expressions'],['resolute','Resolute','Determination gives way to strain'],['pained','Pained','A fading smile, then visible pain']];
const studios=new Map();
const fileName=p=>decodeURIComponent(String(p??'').split('/').pop()?.split('?')[0]??'');

let assets=null;
function loadAssets(){
  const root=moduleRoute('').replace(/\/$/,'');
  return assets??=(async()=>{
    const get=async name=>{const r=await fetch(`${root}/templates/keepsake/${name}?v=${encodeURIComponent(moduleVersion())}`);if(!r.ok)throw new Error(`Portrait studio file missing: ${name}`);return (await r.text()).replaceAll('%KS%',root);};
    const [html,css,sprite]=await Promise.all([get('studio.html'),get('studio.css'),loadSprite()]);
    return {html,css,sprite};
  })().catch(e=>{assets=null;throw e;});
}
const PRELUDE=`:host{all:initial;display:block;contain:content;height:100%;overflow:auto;scrollbar-width:thin;scrollbar-color:#6a5238 transparent}
.ks-root,.ks-root *{box-sizing:border-box}:where(.ks-root) button{font:inherit;color:inherit;cursor:pointer}
.ks-root{flex:1 0 auto}.ks-drag{cursor:grab}.ks-drag:active{cursor:grabbing}.drop.over{box-shadow:inset 0 0 0 1px #e767ce,0 0 18px rgba(231,103,206,.2)}`;

class StudioLogic extends DCLogic {
  constructor(props){
    super(props);
    const actor=props.actor,cfg=portraitConfig(actor),hp=actor.system?.attributes?.hp;
    const pct=Number(hp?.max)>0?Math.round(Math.max(0,Math.min(1,Number(hp.value)/Number(hp.max)))*100):100;
    const library=Array.isArray(actor.getFlag?.(ID,'portraitLibrary'))?actor.getFlag(ID,'portraitLibrary').filter(x=>typeof x==='string'):[];
    this.state={mode:cfg.mode,set:cfg.set,mood:cfg.one.mood,hp:Math.max(1,pct),uncon:false,slots:{...cfg.stages},one:cfg.one.src||'',fx:cfg.one.fx,fy:cfg.one.fy,zoom:cfg.one.zoom,
      th:{...cfg.th},adjust:false,applySheet:cfg.sheet,applyHud:cfg.hud,picker:null,pickSel:[],justFilled:{},flash:'',flashN:0,library,dropOver:false};
    this.initial={mode:cfg.mode,set:cfg.set,mood:cfg.one.mood,slots:{...cfg.stages},one:cfg.one.src||'',fx:cfg.one.fx,fy:cfg.one.fy,zoom:cfg.one.zoom,th:{...cfg.th},applySheet:cfg.sheet,applyHud:cfg.hud};
  }
  get actor(){return this.props.actor;}
  /** Every change is saved on her actor (a moment after the last one). */
  save(){
    clearTimeout(this.saveTimer);
    this.saveTimer=setTimeout(()=>{
      const s=this.state;
      void savePortraitConfig(this.actor,{mode:s.mode,set:s.set,one:{src:s.one,fx:s.fx,fy:s.fy,zoom:s.zoom,mood:s.mood},stages:s.slots,th:cleanThresholds(s.th),sheet:s.applySheet,hud:s.applyHud})
        .catch(e=>ui.notifications?.error?.(e?.message??String(e)));
    },350);
  }
  change(patch){this.setState(patch);this.save();}
  resolve(k){return resolveStage(this.state.slots,k);}
  flashIt(kind){const n=this.state.flashN+1;this.setState({flash:kind+(n%2?'':'2'),flashN:n});}
  art(k){return moduleRoute(keepsakeArt(k,this.state.set,'assets/hud/'));}
  catalog(){
    const a=this.actor,mine=[],seen=new Set(),add=(src,name)=>{if(!src||seen.has(src))return;seen.add(src);mine.push({id:src,name:name??fileName(src),src});};
    add(a.img,'Her actor image');add(a.prototypeToken?.texture?.src,'Her token');
    for(const src of [...this.state.library,...Object.values(this.state.slots),this.state.one])add(src);
    const art=[];for(const k of STAGES)art.push({id:`art:${k}`,name:`portrait-${k}.webp`,src:moduleRoute(keepsakeArt(k,'original','assets/hud/'))});
    for(const set of ['resolute','pained'])for(const k of ['light','wounded','severe','critical'])art.push({id:`art:${set}:${k}`,name:`${set}-${k}.webp`,src:moduleRoute(keepsakeArt(k,set,'assets/hud/'))});
    return {mine,art};
  }
  srcOf(id){if(!id)return '';if(id.startsWith('art:')){const p=id.split(':');return p.length===2?moduleRoute(keepsakeArt(p[1],'original','assets/hud/')):moduleRoute(keepsakeArt(p[2],p[1],'assets/hud/'));}return id;}
  folder(){return `worlds/${game.world?.id??'world'}/keepsake-portraits`;}
  /** Foundry's own file browser (it uploads too, for players allowed to). */
  browse(onPick){
    const FP=foundry.applications?.apps?.FilePicker?.implementation??globalThis.FilePicker;
    if(!FP){ui.notifications?.warn?.('No file browser available.');return;}
    new FP({type:'image',current:this.state.one||this.actor.img,callback:path=>{this.remember(path);onPick?.(path);}}).render(true);
  }
  remember(path){if(!path||this.state.library.includes(path))return;const library=[path,...this.state.library].slice(0,60);this.setState({library});void this.actor.setFlag?.(ID,'portraitLibrary',library).catch(()=>{});}
  /** Dropped image files go to the world's keepsake-portraits folder, then fill the empty stages in name order. */
  async dropFiles(files){
    const FP=foundry.applications?.apps?.FilePicker?.implementation??globalThis.FilePicker;
    const images=[...files].filter(f=>/^image\//.test(f.type)).sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true}));
    if(!images.length){ui.notifications?.warn?.('Drop image files here.');return;}
    if(!FP?.upload){ui.notifications?.warn?.('Uploading is not available here.');return;}
    const dir=this.folder(),paths=[];
    try{await FP.createDirectory?.('data',dir).catch(()=>{});}catch{}
    for(const f of images){
      try{const r=await FP.upload('data',dir,f,{},{notify:false});const path=r?.path??(r?.status==='success'?`${dir}/${f.name}`:null);if(path){paths.push(path);this.remember(path);}}
      catch(e){ui.notifications?.error?.(`Couldn't upload ${f.name}: ${e?.message??e}. Players need permission to upload files.`);break;}
    }
    if(!paths.length)return;
    const m={...this.state.slots},jf={};let targets=STAGES.filter(k=>!m[k]);if(!targets.length)targets=STAGES.slice();
    paths.forEach((p,i)=>{if(targets[i]){m[targets[i]]=p;jf[targets[i]]=1;}});
    this.change({slots:m,justFilled:jf,mode:'stages'});clearTimeout(this.jt);this.jt=setTimeout(()=>this.setState({justFilled:{}}),900);
  }
  renderVals(){
    const s=this.state,th=cleanThresholds(s.th),stage=s.uncon||s.hp<=0?'unconscious':portraitStage({hp:s.hp,max:100},th),self=this;
    const actorImg=this.actor.img,oneSrc=s.one||actorImg;
    const modes=[['keepsake','Keepsake','ui-sparkle','Her Keepsake art; her expression follows her HP, as in the HUD.'],['one','One portrait','ui-image','One image you choose: her actor image, as on the standard sheet.'],['stages','My stages','ui-frames','Your own image for each stage of her HP.']].map(m=>{
      const on=s.mode===m[0];let imgs=[],grid=false,cells=[];
      if(m[0]==='keepsake')imgs=[['healthy','calc(50% - 66px)','6px','rotate(-9deg)','0'],['severe','calc(50% - 31px)','2px','none','1'],['unconscious','calc(50% + 4px)','6px','rotate(9deg)','0']].map(x=>({src:this.art(x[0]),left:x[1],top:x[2],tf:x[3],z:x[4],w:'62px',h:'80px'}));
      else if(m[0]==='one')imgs=[{src:oneSrc,left:'0',top:'0',tf:'none',z:'0',w:'100%',h:'100%'}];
      else{grid=true;cells=STAGES.map(k=>{const id=s.slots[k];return {src:id?this.srcOf(id):'',outline:id?'none':'1px dashed #6a5238',color:SCOL[k]};});}
      return {name:m[1],icon:m[2],desc:m[3],cls:'mcard'+(on?' on':''),checked:on?'true':'false',artCls:'art'+(m[0]==='keepsake'?' fan':''),imgs,grid,cells,pick:()=>this.change({mode:m[0]})};});
    const range=k=>{const mid=Math.round((th.light+th.severe)/2*10)/10;return {healthy:'above '+th.light+'%',light:mid+'–'+th.light+'%',wounded:th.severe+'–'+mid+'%',severe:th.critical+'–'+th.severe+'%',critical:th.critical+'% or less',unconscious:'0 HP or knocked out'}[k];};
    const artSlots=STAGES.map(k=>({name:SN[k],icon:SICON[k],color:SCOL[k],src:this.art(k),range:range(k),cls:'slotc'+(k===stage?' now':'')}));
    const filled=STAGES.filter(k=>s.slots[k]).length;
    const slots=STAGES.map(k=>{const id=s.slots[k],use=id?k:this.resolve(k),src=use?this.srcOf(s.slots[use]):'';
      return {name:SN[k],icon:SICON[k],color:SCOL[k],range:range(k),src,alt:id?SN[k]+' image':'Borrowed from '+(use?SN[use]:''),pos:'62% 18%',
        cls:'slotc'+(k===stage?' now':'')+(s.justFilled[k]?' fill':''),phCls:'ph'+(id?'':' empty'),empty:!id,filled:!!id,borrowed:!id&&!!use,borrowText:use?'Uses '+SN[use]:'',
        choose:()=>this.setState({picker:{slot:k},pickSel:id?[id]:[]}),clear:()=>{const m={...this.state.slots};delete m[k];this.change({slots:m});}};});
    const order=['critical','severe','wounded','light','healthy'],mid=(th.light+th.severe)/2;
    const widths={critical:th.critical,severe:th.severe-th.critical,wounded:mid-th.severe,light:th.light-mid,healthy:100-th.light};
    const ribbon=order.map(k=>({name:widths[k]>=12?SN[k]:'',w:widths[k]+'%',color:SCOL[k]}));
    const thresholds=[['light','Lightly hurt below'],['severe','Badly hurt below'],['critical','Critical below']].map(t=>{
      const lo={light:th.severe+10,severe:th.critical+5,critical:5}[t[0]],hi={light:95,severe:th.light-10,critical:th.severe-5}[t[0]];
      const step=d=>{const n={...cleanThresholds(this.state.th)};n[t[0]]=Math.max(lo,Math.min(hi,n[t[0]]+d));this.change({th:n});};
      return {name:t[1],value:th[t[0]],down:()=>step(-5),up:()=>step(5)};});
    // the preview
    let pv=[],own=true,pos='62% 16%',zoom=1;
    if(s.mode==='keepsake')pv=STAGES.map(k=>({src:this.art(k),op:k===stage?1:0,alt:k===stage?'Keepsake portrait, '+SN[k]:''}));
    else if(s.mode==='one'){pv=[{src:oneSrc,op:1,alt:'Her portrait'}];own=false;pos=s.fx+'% '+s.fy+'%';zoom=s.zoom/100;}
    else{const use=this.resolve(stage);own=use===stage;pv=STAGES.filter(k=>s.slots[k]).map(k=>({src:this.srcOf(s.slots[k]),op:k===use?1:0,alt:k===use?'Her '+SN[k]+' image':''}));if(!pv.length){pv=[{src:actorImg,op:1,alt:'Her actor image'}];own=false;}}
    let tint=s.mood&&!own;if(s.mode==='keepsake'||s.mode==='one')tint=s.mood;
    const pvClass='pv mood-'+stage+(tint?'':' mood-soft')+(s.flash?' '+s.flash:'');
    const why=s.mode==='stages'?(own?'her own image for this stage':'borrowing '+SN[this.resolve(stage)||'healthy']+(s.mood?', with mood light':'')):s.mode==='keepsake'?'Keepsake art, '+(s.set==='original'?'original':s.set)+' expressions':'one image'+(s.mood?', with mood light':'');
    const down=stage==='unconscious',pct=s.hp/100,period=down?2.9:pct>.5?2.6:pct>.25?1.6:.95;
    const cat=this.catalog(),multi=!!s.picker?.multi;
    const groups=[{name:'Her images',icon:'ui-image',path:this.folder(),items:cat.mine},{name:'Keepsake art',icon:'ui-sparkle',path:'modules/filament-flight/assets/hud',items:cat.art}].map(g=>({name:g.name,icon:g.icon,path:g.path,
      items:g.items.map(c=>{const i=s.pickSel.indexOf(c.id),on=i>=0;
        return {name:c.name,src:c.src,cls:'pthumb'+(on?' on':''),pressed:on?'true':'false',order:multi&&on?String(i+1):'',check:!multi&&on,
          pick:()=>{let sel=this.state.pickSel.slice();const at=sel.indexOf(c.id);if(multi){if(at>=0)sel.splice(at,1);else sel.push(c.id);}else sel=[c.id];this.setState({pickSel:sel});}};})}));
    const P=s.picker||{},empties=STAGES.filter(k=>!s.slots[k]);
    return {
      name:this.actor.name,close:()=>this.props.app?.close(),revert:()=>this.change({...this.initial,slots:{...this.initial.slots},th:{...this.initial.th},picker:null,pickSel:[]}),
      rootClass:'fm-normal',modes,isKeepsake:s.mode==='keepsake',isOne:s.mode==='one',isStages:s.mode==='stages',
      sets:SETS.map(x=>{const on=s.set===x[0];return {name:x[1],cls:on?'on':'',checked:on?'true':'false',pick:()=>this.change({set:x[0]})};}),setHint:SETS.find(x=>x[0]===s.set)[2],
      artSlots,moodCls:'switch'+(s.mood?' on':''),moodPressed:s.mood?'true':'false',toggleMood:()=>this.change({mood:!this.state.mood}),
      oneSrc,focusX:s.fx+'%',focusY:s.fy+'%',fx:s.fx,fy:s.fy,zoom:s.zoom,
      setFx:e=>{const v=Number(e.target.value);if(e.type==='change')this.change({fx:v});else this.setState({fx:v});},
      setFy:e=>{const v=Number(e.target.value);if(e.type==='change')this.change({fy:v});else this.setState({fy:v});},
      setZoom:e=>{const v=Number(e.target.value);if(e.type==='change')this.change({zoom:v});else this.setState({zoom:v});},
      openOne:()=>this.setState({picker:{one:1},pickSel:[s.one||actorImg]}),
      moodStrip:STAGES.map(k=>({cls:'pv mood-'+k+(s.mood?'':' mood-soft'),src:oneSrc,pos:s.fx+'% '+s.fy+'%',name:SN[k],icon:SICON[k],color:SCOL[k]})),
      slots,filledText:filled+' of 6',clearAll:()=>this.change({slots:{}}),
      openMulti:()=>this.setState({picker:{multi:1},pickSel:[]}),
      ribbon,ribbonCur:s.uncon?'0%':s.hp+'%',adjustOpen:!!s.adjust,adjustLabel:s.adjust?'Done':'Adjust',toggleAdjust:()=>this.setState({adjust:!this.state.adjust}),thresholds,
      pvClass,pvImgs:pv,pvPos:pos,pvZoom:String(zoom),beat:period+'s',
      hbClass:'hb'+(down?' faint':''),trace:heartTrace({beats:1,amp:down?.6:1}),hbColor:down?'#b07aa4':pct>.5?'#e767ce':pct>.25?'#e2a256':'#c8324f',hpDash:Math.round(pct*100)+' 100',
      stageName:SN[stage],stageIcon:SICON[stage],stageColor:SCOL[stage],stageWhy:why,
      hpPct:s.hp,setHp:e=>{const v=Number(e.target.value),prev=this.state.hp;this.setState({hp:v});if(v<prev-4)this.flashIt('hurt');},
      unconCls:'switch sm'+(s.uncon?' on':''),unconPressed:s.uncon?'true':'false',toggleUncon:()=>this.setState({uncon:!this.state.uncon}),
      hit:()=>{this.setState({hp:Math.max(1,this.state.hp-15)});this.flashIt('hurt');},heal:()=>{this.setState({hp:Math.min(100,this.state.hp+15)});this.flashIt('healed');},
      applies:[['applySheet','Her Keepsake sheet','The header of her sheet','tab-character'],['applyHud','The Keepsake HUD','Its header portrait too','ui-frames']].map(a=>{const on=!!s[a[0]];
        return {name:a[1],note:a[2],icon:a[3],cls:'switch sm'+(on?' on':''),pressed:on?'true':'false',toggle:()=>this.change({[a[0]]:!on})};}),
      pickerOpen:!!s.picker,pickGroups:groups,closePicker:()=>this.setState({picker:null,pickSel:[]}),
      pickTitle:P.multi?'Choose several images':P.one?'Her portrait':P.slot?'An image for '+SN[P.slot]:'',
      pickHint:P.multi?'Tick them in the order you want: they fill '+(empties.length?'the empty stages ('+empties.map(k=>SN[k]).join(', ')+')':'every stage')+' from Healthy down.':P.one?'One image for her portrait. Upload from your computer adds a new one.':'Pick one image for this stage.',
      confirmLabel:P.multi?(s.pickSel.length?'Fill '+Math.min(s.pickSel.length,(empties.length||6))+' '+(Math.min(s.pickSel.length,(empties.length||6))===1?'stage':'stages'):'Fill stages'):'Use this image',
      confirmPick:()=>{const sel=this.state.pickSel,P2=this.state.picker||{},m={...this.state.slots},jf={};
        if(P2.one&&sel[0])this.change({one:this.srcOf(sel[0])===actorImg?'':this.srcOf(sel[0]),picker:null,pickSel:[]});
        else if(P2.slot&&sel[0]){m[P2.slot]=this.srcOf(sel[0]);jf[P2.slot]=1;this.change({slots:m,picker:null,pickSel:[],justFilled:jf});}
        else if(P2.multi){let targets=STAGES.filter(k=>!m[k]);if(!targets.length)targets=STAGES.slice();sel.forEach((id,i)=>{if(targets[i]){m[targets[i]]=this.srcOf(id);jf[targets[i]]=1;}});this.change({slots:m,picker:null,pickSel:[],justFilled:jf});}
        else this.setState({picker:null});
        clearTimeout(this.jt);this.jt=setTimeout(()=>this.setState({justFilled:{}}),900);},
      upload:()=>this.browse(path=>{const P2=this.state.picker||{};if(P2.multi)this.setState({pickSel:[...this.state.pickSel,path]});else this.setState({pickSel:[path]});}),
      uploadOne:()=>this.browse(path=>this.change({one:path})),
      useToken:()=>{const src=this.actor.prototypeToken?.texture?.src;if(src)this.change({one:src});}
    };
  }
}

/** Open her portrait studio (one per character). */
export function openPortraitStudio(actor){
  if(!actor)throw new Error('No character to show.');
  if(!actor.isOwner)throw new Error('Only her owner can change her portrait.');
  const open=studios.get(actor.uuid);if(open?.rendered){open.bringToFront?.();return open;}
  const ApplicationV2=foundry.applications?.api?.ApplicationV2;
  if(!ApplicationV2)throw new Error('The portrait studio needs Foundry VTT 14.');
  class PortraitStudio extends ApplicationV2 {
    static DEFAULT_OPTIONS={tag:'section',classes:['ffks-studio-window'],window:{frame:false,positioned:true},position:{width:1000,height:Math.min(900,(globalThis.innerHeight??900)-30)}};
    async _renderHTML(){return loadAssets();}
    _replaceHTML(files,content){if(!this.host)this.mount(content,files);this.host.render();}
    mount(content,files){
      const doc=content.ownerDocument;content.replaceChildren();content.style.cssText+=';background:#0f080c;box-shadow:0 24px 70px rgba(0,0,0,.75);border-radius:2px';
      const hostEl=doc.createElement('div');hostEl.style.cssText='height:100%';content.append(hostEl);
      const shadow=hostEl.attachShadow({mode:'open'});
      const style=doc.createElement('style');style.textContent=PRELUDE+'\n'+files.css;shadow.append(style);
      const sprite=doc.createElement('div');sprite.style.cssText='position:absolute;width:0;height:0;overflow:hidden';sprite.innerHTML=files.sprite;shadow.append(sprite);
      const mountPoint=doc.createElement('div');mountPoint.style.cssText='min-height:100%;display:flex;flex-direction:column';shadow.append(mountPoint);
      this.host=new KeepsakeHost(mountPoint,{template:compileTemplate(doc,files.html),component:new StudioLogic({actor,app:this}),
        afterRender:root=>this.wire(root),onError:e=>console.error('Yvaelle’s Toolbox | portrait studio',e)});
      for(const type of ['keydown','keyup'])shadow.addEventListener(type,event=>{const t=event.composedPath()[0];if(t?.matches?.('input,textarea,select'))event.stopPropagation();});
    }
    /** Buttons the template leaves to us, dropping files, and dragging the window by its title row. */
    wire(root){
      if(!root)return;const logic=this.host.component;
      const drop=root.querySelector('.drop');
      if(drop&&!drop.dataset.ffWired){drop.dataset.ffWired='1';
        drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('over');});
        drop.addEventListener('dragleave',()=>drop.classList.remove('over'));
        drop.addEventListener('drop',e=>{e.preventDefault();drop.classList.remove('over');if(e.dataTransfer?.files?.length)void logic.dropFiles(e.dataTransfer.files);});}
      const handle=root.querySelector('[data-ks-drag]');
      if(handle&&!handle.dataset.ffWired){handle.dataset.ffWired='1';
        handle.addEventListener('pointerdown',e=>{if(e.target.closest('button,a,input'))return;e.preventDefault();
          const start={x:e.clientX,y:e.clientY,left:this.position.left,top:this.position.top};
          const move=ev=>this.setPosition({left:start.left+ev.clientX-start.x,top:Math.max(0,start.top+ev.clientY-start.y)});
          const up=()=>{globalThis.removeEventListener('pointermove',move);globalThis.removeEventListener('pointerup',up);};
          globalThis.addEventListener('pointermove',move);globalThis.addEventListener('pointerup',up);});}
    }
    async close(options){studios.delete(actor.uuid);this.host?.destroy?.();return super.close(options);}
  }
  const app=new PortraitStudio({id:`filament-flight-portrait-${actor.id}`});studios.set(actor.uuid,app);
  void app.render({force:true});
  return app;
}
export {cleanPortrait};
