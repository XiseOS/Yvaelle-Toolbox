/** Pure selection and preview data. Hovering never touches a TokenDocument. */
import {CONDITION_EFFECTS,REACTION_EFFECTS,DEFAULT_CONDITION_ART,styleLabel,conditionEffectGroups} from './effect-catalog.mjs?v=13.0.0-beta.2';
import {DEFAULT_REACTION_ART} from './reaction-art.mjs?v=13.0.0-beta.2';
import {resolveEffectStyle,resolveReactionStyle} from './effect-styles.mjs?v=13.0.0-beta.2';
import {normalizeFlag,resolveState} from './state.mjs?v=13.0.0-beta.2';
import {previewQualityConfiguration} from './quality.mjs?v=13.0.0-beta.2';

export const REACTION_LABELS={damage:'Damage',critical:'Critical hit',heal:'Healing',flare:'Flare',pulse:'Pulse',stutter:'Stutter',reform:'Reform'};
const CONDITION_LABELS={normal:'Normal',damaged:'Damaged',unstable:'Unstable',glitching:'Glitching',overdrive:'Overdrive',suppressed:'Suppressed',collapsed:'Collapsed'};
/** v10 featured set: the variants that stay clearly distinct at token size. */
// Beta.29: every condition's default look is featured (Corona surge was not),
// and the four older "Old animations" entries are no longer featured.
export const FEATURED_EFFECTS=Object.freeze(new Set([...Object.values(DEFAULT_CONDITION_ART),'roseLattice','scarStitch','torsion','circuit','drain','seedRecall','residualHorizon','hangingLace']));
const effectLibrary=()=>{try{return globalThis.game?.settings?.get('filament-flight','effectLibrary')??'featured';}catch{return 'all';}};
/** (beta.37) The choices for a selector, built once per selector and library
 * setting: each call used to flatten every condition's whole library and read
 * the library setting once per entry, about 29 ms for one Effects-tab render
 * in Foundry. The cached list and its entries are frozen: callers only read. */
const choiceCache=new Map();
export function pickerChoices(group,key) {
  const library=effectLibrary(),ck=`${group}\u0000${key}\u0000${library}`;
  const hit=choiceCache.get(ck);if(hit)return hit;
  const out=Object.freeze(buildChoices(group,key,library).map(e=>Object.freeze(e)));
  if(choiceCache.size>256)choiceCache.clear();
  choiceCache.set(ck,out);return out;
}
function buildChoices(group,key,library) {
  const entries=group==='condition'&&CONDITION_EFFECTS[key]?conditionEffectGroups().flatMap(category=>category.entries.map(entry=>({...entry,category:category.id,categoryLabel:category.label}))):group==='reaction'?REACTION_EFFECTS[key]:null;
  if(!entries&&!(group==='default'&&key==='effectStyle'))throw new Error('Unknown effect selector.');
  const inherited=group==='condition'?'Use default style':group==='reaction'?'Follow condition style':'Use module setting';
  return [
    ...[...(entries??[])].filter(e=>group!=='condition'||library!=='featured'||FEATURED_EFFECTS.has(e.id)).sort((a,b)=>Number(FEATURED_EFFECTS.has(b.id))-Number(FEATURED_EFFECTS.has(a.id))||Number(!!b.recommended)-Number(!!a.recommended)).map(e=>({id:e.id,label:e.label,description:e.description,kind:e.recommended?'Distinctive':e.legacy?'Earlier variant':'Tailored',legacy:!!e.legacy,recommended:!!e.recommended,category:e.category,categoryLabel:e.categoryLabel})),
    {id:'original',label:'Original / subtle',description:'The earlier, subtler filament treatment.',kind:'Classic'},
    ...(group==='default'?[{id:'animated',label:'Animated',description:'Use the recommended animated treatment for each condition.',kind:'Classic'}]:[]),
    ...(entries?[{id:'none',label:'None',description:'Keep the base wings and pose; remove this option’s extra effect.',kind:'Off'}]:[]),
    {id:'default',label:inherited,description:group==='reaction'?'Follow the GM’s reaction default, then the condition’s Original or Animated style.':
      group==='condition'?'Follow the token’s default style, then the module’s choice for this condition.':'Use the module’s default treatment for each condition.',kind:'Inherited'}
  ];
}
/** Category names describe the animation, never restrict its assigned condition. */
export function pickerGroups(group,key) {
  const entries=pickerChoices(group,key),legacy=entries.filter(entry=>entry.legacy);
  if(group!=='condition')return [
    {id:'current',label:group==='reaction'?REACTION_LABELS[key]:'Default style',entries:entries.filter(entry=>!entry.legacy)},
    ...(legacy.length?[{id:'legacy',label:'Old animations',entries:legacy}]:[])
  ];
  return [
    ...conditionEffectGroups().map(category=>({id:category.id,label:category.label,entries:entries.filter(entry=>entry.category===category.id&&!entry.legacy)})).filter(category=>category.entries.length),
    ...(legacy.length?[{id:'legacy',label:'Old animations',entries:legacy}]:[]),
    {id:'common',label:'Common styles',entries:entries.filter(entry=>!entry.category)}
  ];
}
export function pickerTitle(group,key) {
  pickerChoices(group,key);
  return group==='default'?'Default style':group==='condition'?`${CONDITION_LABELS[key]} appearance`:`${REACTION_LABELS[key]} reaction`;
}
export function pickerValue(model,group,key) {
  const request=model.state?.requested??{};
  const value=(group==='default'?request.effectStyle:group==='condition'?request.effectStyles?.[key]:request.reactionStyles?.[key])??'default';
  const visible=value==='animated'&&group!=='default'?(group==='condition'?DEFAULT_CONDITION_ART[key]:DEFAULT_REACTION_ART[key]):value;
  return pickerChoices(group,key).some(e=>e.id===visible)?visible:'default';
}
export function pickerCommand(group,key,id) {
  // Saved macros and preview callers may still request the historical alias.
  if(!pickerChoices(group,key).some(e=>e.id===id)&&id!=='animated')throw new Error('This animation is unavailable for that selector.');
  const value=id==='default'?null:id;
  return group==='default'?{action:'effectStyle',value}:
    {action:group==='condition'?'effectStyles':'reactionStyles',value:{[key]:value}};
}

export function createEffectPreview(model,group,key,id) {
  const command=pickerCommand(group,key,id),request=structuredClone(model.state?.requested??{});
  const condition=group==='condition'?key:(model.state?.effective.condition??'normal');
  request[command.action]=group==='default'?command.value:{...(request[command.action]??{}),...command.value};
  // Default-style browsing demonstrates that fallback, independently of any
  // explicit per-condition choice already saved on the real token.
  if(group==='default')request.effectStyles={...request.effectStyles,[condition]:null};
  const duration=group==='reaction'?(['pulse','stutter'].includes(key)?model.prefs?.[`${key}DurationMs`]??(key==='pulse'?model.cfg.healingDuration:model.cfg.damageDuration):(['heal','reform'].includes(key)?model.cfg.healingDuration:model.cfg.damageDuration)):0;
  const data=normalizeFlag({...request,enabled:true,started:0,condition,conditionSource:'manual',autoHP:false,
    observerQuality:{preset:'inherit'},
    pose:model.state?.requested.pose??'neutral',options:{...model.baseAppearance},
    cues:group==='reaction'?{manual:{id:'picker-preview',kind:key,started:0,duration,strength:model.prefs?.effectStrength??.7}}:null},0);
  return {data,cfg:previewQualityConfiguration({...model.cfg}),seed:model.token?.document.uuid??'preview',group,key,id,duration,cycle:duration+800};
}
export function sampleEffectPreview(preview,elapsed=0) {
  const time=Math.max(0,Number.isFinite(elapsed)?elapsed:0);
  const now=preview.group==='reaction'?time%preview.cycle:time;
  return resolveState(preview.data,preview.cfg,now,{seed:preview.seed,resumeFlightTransition:false,resumePoseTransition:false});
}
export function previewGuidance(preview) {
  const {data,cfg,group,key,id}=preview;
  if(!cfg.enabled)return 'Flight effects are hidden by the module or browser settings.';
  if(cfg.reduced)return 'Reduced motion is on. This preview stays still; temporary reactions are suppressed.';
  if(cfg.wingRenderer==='atlas')return 'Original atlas mode is on. Poses and detailed geometry are disabled.';
  if(group==='reaction'&&!cfg.transientEffects)return 'Temporary wing effects are disabled in module settings.';
  if(group!=='reaction'&&!cfg.visualConditions)return 'Visual wing conditions are disabled in module settings.';
  const base=resolveEffectStyle(data,data.condition,cfg);
  const resolved=group==='reaction'?resolveReactionStyle(data,key,cfg,base):base;
  if(!cfg.enhancedConditions&&id!=='original'&&id!=='none')return 'Detailed animated effects are disabled. Original is shown; your choice can still be saved.';
  const suffix=group==='default'?' Shown without per-condition overrides.':'';
  const display=resolved==='animated'?(group==='reaction'?DEFAULT_REACTION_ART[key]:DEFAULT_CONDITION_ART[data.condition]):resolved;
  return `${id==='default'?'Resolves to':'Previewing'} ${styleLabel(display)}. Uses this token’s pose and tuning.${suffix}`;
}
