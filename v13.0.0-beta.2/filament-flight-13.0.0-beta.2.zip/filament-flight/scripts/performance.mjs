/** Optional browser-local diagnostics. Never writes token or world settings. */
import {BUILD_INFO} from './build-info.mjs?v=13.0.0-beta.2';
import {inMotionTransform} from './motion.mjs?v=13.0.0-beta.2';
const COMPONENTS=Object.freeze({wings:true,bits:true,fields:true,trails:true,treatment:true});
const MAX_SAMPLES=8192;
const clock=()=>globalThis.performance?.now?.()??Date.now();
const hook=()=>globalThis.Hooks?.callAll?.('filamentFlightPerformanceChanged');
const QUALITY_KEYS=Object.freeze(['rigQuality','bitQuality','rigFPS','poseFPS','trailQuality','localTrails','treatmentDetail','effectDetail','renderWorker','reduced','localEffects']);
const PROFILE_KEYS=Object.freeze(['preset','wingDetail','bitDetail','textureFPS','transitionFPS','trails','treatment','effectDetail']);
const select=(value,keys)=>Object.fromEntries(keys.filter(key=>['string','boolean','number'].includes(typeof value?.[key])).map(key=>[key,value[key]]));

/** Environment identity without scene, token, actor, user or world content. */
export function performanceEnvironment(){
  const renderer=globalThis.canvas?.app?.renderer,screen=renderer?.screen,settings=globalThis.game?.settings;
  const setting=key=>{try{return settings?.get?.('filament-flight',key);}catch{return undefined;}};
  const configured=Object.fromEntries(QUALITY_KEYS.map(key=>[key,setting(key)]));
  const rendererTypes=globalThis.PIXI?.RENDERER_TYPE,type=renderer?.type;
  const backend=type===rendererTypes?.WEBGL&&type!==undefined?'WebGL':type===rendererTypes?.CANVAS&&type!==undefined?'Canvas':null;
  return {build:{...BUILD_INFO},moduleVersion:globalThis.game?.modules?.get?.('filament-flight')?.version??BUILD_INFO.version,
    foundryVersion:globalThis.game?.version??globalThis.game?.release?.version??null,pixiVersion:globalThis.PIXI?.VERSION??null,
    browser:globalThis.navigator?.userAgent??null,backend:{kind:backend,rendererClass:renderer?.constructor?.name??null,
      webGLVersion:renderer?.context?.webGLVersion??null},viewport:{width:screen?.width??null,height:screen?.height??null,dpr:globalThis.devicePixelRatio??1},
    workerAvailable:typeof globalThis.Worker==='function'&&typeof globalThis.OffscreenCanvas==='function',
    configuredQuality:select(configured,QUALITY_KEYS),personalQuality:select(setting('localQuality'),PROFILE_KEYS)};
}
function summary(samples){
  if(!samples.length)return {mean:0,median:0,p95:0,max:0};
  const sorted=[...samples].sort((a,b)=>a-b),round=x=>Math.round(x*1000)/1000;
  const middle=Math.floor(sorted.length/2),median=sorted.length%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2;
  return {mean:round(samples.reduce((a,b)=>a+b,0)/samples.length),median:round(median),
    p95:round(sorted[Math.min(sorted.length-1,Math.ceil(sorted.length*.95)-1)]),max:round(sorted.at(-1))};
}
export class PerformanceDiagnostics {
  constructor({now=clock,schedule=(fn,ms)=>setTimeout(fn,ms),unschedule=id=>clearTimeout(id),metadata=performanceEnvironment}={}){
    this.now=now;this.schedule=schedule;this.unschedule=unschedule;this.metadata=metadata;this.components=COMPONENTS;this.active=false;this.report=null;
  }
  get isolated(){return this.components!==COMPONENTS;}
  beginStage(){return this.now();}
  endStage(name,start){
    if(!this.active||start==null)return;
    const finished=this.now(),elapsed=Math.max(0,finished-start);
    const values=this.stages[name]??=[];if(values.length<MAX_SAMPLES)values.push(elapsed);
    // Aggregate the union of covered main-thread intervals. A lighting callback
    // may also run inside treatment maintenance; adding both would double it.
    if(['state','render','workerInstall','treatment','lighting','audio'].includes(name)){
      let lo=start,hi=Math.max(start,finished),index=0;
      const intervals=this.workIntervals;
      while(index<intervals.length&&intervals[index][1]<lo)index++;
      while(index<intervals.length&&intervals[index][0]<=hi){
        const [a,b]=intervals.splice(index,1)[0];lo=Math.min(lo,a);hi=Math.max(hi,b);this.frameWork-=b-a;
      }
      intervals.splice(index,0,[lo,hi]);this.frameWork+=hi-lo;
    }
  }
  /** Synchronous callback coverage, including early returns and exceptions.
   * Nested stages remain visible but only the outer instrumented span enters
   * the main-thread sum. Async waits/worker CPU are deliberately excluded. */
  measure(name,operation){
    if(!this.active)return operation();
    const started=this.beginStage();
    try{return operation();}
    finally{this.endStage(name,started);}
  }
  observe(name,value){
    if(!this.active||!Number.isFinite(value)||value<0)return;
    const values=this.observations[name]??=[];if(values.length<MAX_SAMPLES)values.push(value);
  }
  recordQuality(config){
    if(!this.active)return;
    const profile={...select(config,QUALITY_KEYS),observerLimited:config?.quality?.observerLimited===true};
    const key=JSON.stringify(profile);if(this.qualityProfiles.size<32)this.qualityProfiles.set(key,profile);
  }
  recordRenderPath(path){if(this.active&&['wing-worker','wing-main-thread','wing-atlas','compact-main-thread','action-main-thread'].includes(path))this.renderPaths.add(path);}
  count(name,value=1){if(this.active&&Number.isFinite(value))this.counters[name]=(this.counters[name]??0)+value;}
  start({duration=10000}={}){
    if(!Number.isFinite(duration)||duration<2000||duration>30000)throw new Error('Capture duration must be 2000–30000 milliseconds.');
    const ticker=globalThis.canvas?.ready&&globalThis.canvas?.app?.ticker;
    if(!ticker)throw new Error('Open a scene before recording performance.');
    if(this.active)this.stop(false);
    this.captureMetadata=this.metadata();
    this.captureId=(this.captureId??0)+1;
    this.started=this.now();this.lastFrame=null;this.elapsed=0;this.duration=duration;
    this.frameSamples=[];this.workSamples=[];this.stages={};this.counters={};this.observations={};this.qualityProfiles=new Map();this.renderPaths=new Set();this.workIntervals=[];this.frameWork=0;this.frames=0;
    this.captureComponents={...this.components};this.active=true;this.report=null;this.ticker=ticker;
    this.unschedule(this.restoreTimer);this.restoreTimer=null;
    try{ticker.add(this.tick,this,-1000);this.timer=this.schedule(()=>this.stop(),duration);}
    catch(error){this.active=false;ticker.remove(this.tick,this);this.ticker=null;this.restoreComponents();throw error;}
    hook();this.watchPerception();return this.getReport();
  }
  /** Beta.35: who asks Foundry for perception refreshes during a capture.
   * Every call is counted; one in eight records its caller (the first module
   * or system file on the stack, else Foundry, with the function name), so a
   * report can tell Foundry's own token-movement refreshes from this
   * module's lights. Removed again when the capture stops. */
  watchPerception(){
    // (Another wrapper may sit over ours and put ours back later: never stack a second one.)
    const P=globalThis.canvas?.perception;this.perceptionTop=new Map();if(!P||typeof P.update!=='function'||this.perceptionWatch||P.update.ffPerceptionWatch)return;
    const original=P.update,own=Object.hasOwn(P,'update'),self=this;let n=0;
    const wrapper=function(...args){
      if(self.active){self.count('perceptionCalls');
        // (Every call: was her pose being applied to her token's transform then?)
        if(inMotionTransform())self.count('perceptionDuringHerTransform');
        if((n++&7)===0)try{const who=perceptionCaller(callerStack(P,wrapper));self.count(`perceptionBy:${who.source}`,8);const f=args[0];if(f&&typeof f==='object')for(const k in f)if(f[k])self.count(`perceptionFlag:${k}`,8);const top=self.perceptionTop??=new Map();if(top.size<64||top.has(who.at))top.set(who.at,(top.get(who.at)??0)+8);}catch{}}
      return original.apply(this,args);
    };
    wrapper.ffPerceptionWatch=true;wrapper.ffCounting=true;P.update=wrapper;
    this.perceptionWatch=()=>{if(P.update===wrapper){if(own)P.update=original;else delete P.update;}this.perceptionWatch=null;};
  }
  tick(){
    if(!this.active)return;
    const now=this.now();
    if(this.lastFrame!==null){
      const elapsed=now-this.lastFrame;
      if(elapsed>=0&&this.frameSamples.length<MAX_SAMPLES){this.frameSamples.push(elapsed);this.workSamples.push(this.frameWork);}
    }
    this.frames++;this.frameWork=0;this.workIntervals=[];this.lastFrame=now;
    if(now-this.started>=this.duration)this.stop();
  }
  getReport(complete=false){
    if(!this.active&&this.report)return {...structuredClone(this.report),components:{...this.components}};
    const summarize=!this.active||complete;
    return {active:this.active,elapsedMs:this.active?Math.max(0,this.now()-this.started):0,durationMs:this.duration??0,
      frames:this.active?this.frames:0,frameMs:summary(summarize?this.frameSamples??[]:[]),moduleMs:summary(summarize?this.workSamples??[]:[]),
      stages:summarize?Object.fromEntries(Object.entries(this.stages??{}).map(([key,v])=>[key,{...summary(v),samples:v.length}])):{},
      counters:{...this.counters},components:{...this.components},captureComponents:{...(this.captureComponents??this.components)},
      observations:summarize?Object.fromEntries(Object.entries(this.observations??{}).map(([key,v])=>[key,{...summary(v),samples:v.length}])):{},
      environment:this.captureMetadata??null,qualityProfiles:[...(this.qualityProfiles?.values()??[])],renderPaths:[...(this.renderPaths??[])],
      scope:'Frame intervals include this browser and scene. Instrumented module CPU sums covered synchronous main-thread spans only; nested child stages, worker CPU, GPU and uninstrumented work are not added.'};
  }
  stop(restore=true){
    if(this.active){
      this.report=this.getReport(true);this.report.active=false;
      this.active=false;this.ticker?.remove(this.tick,this);this.ticker=null;
      this.unschedule(this.timer);this.timer=null;
      this.perceptionWatch?.();
      if(this.perceptionTop?.size)this.report.perceptionCallers=[...this.perceptionTop].sort((a,b)=>b[1]-a[1]).slice(0,8).map(([at,calls])=>({at,calls}));
    }
    if(restore)this.restoreComponents();hook();return this.getReport();
  }
  setComponents(patch){
    if(!patch||typeof patch!=='object'||Array.isArray(patch)||!Object.keys(patch).length||
      Object.entries(patch).some(([k,v])=>!Object.hasOwn(COMPONENTS,k)||typeof v!=='boolean'))
      throw new Error('Pass local component booleans: wings, bits, fields, trails or treatment.');
    if(this.active)throw new Error('Finish the current capture before changing its components.');
    const next={...this.components,...patch};this.components=Object.values(next).every(Boolean)?COMPONENTS:Object.freeze(next);
    this.unschedule(this.restoreTimer);
    if(this.isolated)this.restoreTimer=this.schedule(()=>{this.restoreComponents();hook();},60000);
    hook();return this.getReport();
  }
  restoreComponents(){this.unschedule(this.restoreTimer);this.restoreTimer=null;this.components=COMPONENTS;}
  reset(){this.stop();this.report=null;this.frameSamples=[];this.workSamples=[];this.stages={};this.counters={};this.observations={};this.qualityProfiles=new Map();this.renderPaths=new Set();this.captureMetadata=null;this.frames=0;this.duration=0;this.captureComponents=null;hook();return this.getReport();}
  publicAPI(){return Object.freeze({start:options=>this.start(options),stop:()=>this.stop(),getReport:()=>this.getReport(),
    setComponents:patch=>this.setComponents(patch),reset:()=>this.reset()});}
}
/** The stack of whoever called canvas.perception.update, without the
 * counting wrappers above it. Beta.36: in the released bundle every module
 * file is one flight.mjs, so the self-check's own counter (wrapped over this
 * one) could not be told apart by its file and was named as the caller of
 * every request ("filament-flight/flight.mjs u.update"). Counting wrappers
 * carry ffCounting; the stack starts below the outermost one. */
function callerStack(P,inner){
  let top=inner;const current=P?.update;
  if(current!==inner&&current?.ffCounting)top=current;
  const holder={};
  // (beta.37: deep enough to reach past libWrapper to the package whose wrapper is running)
  const limit=Error.stackTraceLimit;try{Error.stackTraceLimit=Math.max(limit|0,40);}catch{}
  try{
    if(typeof Error.captureStackTrace==='function'){Error.captureStackTrace(holder,top);return `Error\n(counted)\n${holder.stack.split('\n').slice(1).join('\n')}`;}
    return new Error().stack;
  }finally{try{Error.stackTraceLimit=limit;}catch{}}
}
/** The first non-Foundry file on a stack (a module or system), else Foundry,
 * with the function and file it was called from. */
const OWN=(()=>{try{return new URL('.',import.meta.url).href;}catch{return null;}})();
export function perceptionCaller(stack=''){
  const lines=String(stack).split('\n').slice(2);
  for(const line of lines){
    // (the counters themselves: this wrapper and the self-check's own)
    if(line.includes('performance.mjs')||line.includes('self-check.mjs'))continue;
    if(OWN&&line.includes(OWN)){const f=line.match(/([\w.-]+\.m?js):\d+/)?.[1]??'?',fn=line.trim().match(/^at (?:async )?([^\s(]+)/)?.[1]??'?';
      // (and who called that: in the bundle every module frame is flight.mjs)
      const next=lines[lines.indexOf(line)+1]?.trim().match(/^at (?:async )?([^\s(]+)/)?.[1];
      return {source:'filament-flight',at:`filament-flight/${f} ${fn}${next?` < ${next}`:''}`};}
    const m=line.match(/\/(modules|systems)\/([^/]+)\/[^)\s]*?([\w.-]+\.m?js):\d+/);
    if(m&&m[2]==='lib-wrapper'){const via=throughLibWrapper(lines,lines.indexOf(line));if(via)return via;}
    if(m){const fn=line.trim().match(/^at (?:async )?([^\s(]+)/)?.[1]??'?';return {source:m[2],at:`${m[2]}/${m[3]} ${fn}`};}
  }
  // (Foundry's own: the first two functions, so a report can tell which part of it asks)
  const fns=lines.filter(l=>/\.m?js/.test(l)&&!l.includes('performance.mjs')&&!l.includes('self-check.mjs')).slice(0,2).map(l=>l.trim().match(/^at (?:async )?([^\s(]+)/)?.[1]??'?');
  return {source:'foundry',at:`foundry ${fns.join(' < ')||'?'}`};
}
/** (beta.37) A request made under libWrapper: libWrapper only runs the
 * wrappers other packages registered on a Foundry (or system) method, so it
 * is never the one asking. Name instead the package whose wrapper is on the
 * stack (the first module or system frame past libWrapper's own), the method
 * wrapped (libWrapper names its handler after it, with a 🎁) and the function
 * that made the request. Beta.36 reported "lib-wrapper/lib-wrapper.js
 * 🎁call_wrapped" for 3,812 requests a second. libWrapper keeps no public
 * list of its wrappers, so the stack is the record; when no package frame is
 * on it (the wrapper returned before the call, or is minified into
 * libWrapper's frames), the wrapped method is still named. */
const fnOf=line=>line?.trim().match(/^at (?:async )?([^\s(]+)/)?.[1]??null;
function throughLibWrapper(lines,at){
  const lw=l=>/\/modules\/lib-wrapper\//.test(l);
  // the function that asked (the top of the stack)
  let asked=null;for(let i=0;i<at;i++){const f=fnOf(lines[i]);if(f&&!lines[i].includes('performance.mjs')&&!lines[i].includes('self-check.mjs')){asked=f;break;}}
  let pkg=null,method=null;
  for(let i=at;i<lines.length;i++){
    const line=lines[i];
    if(lw(line)){const f=fnOf(line)??'',g=f.indexOf('🎁');if(!method&&g>=0&&!/call_wrap/.test(f))method=f.slice(g+2).replace(/#\d+$/,'');continue;}
    if(!pkg){const m=line.match(/\/(modules|systems)\/([^/]+)\/[^)\s]*?([\w.-]+\.m?js):\d+/);if(m)pkg={id:m[2],file:m[3],fn:fnOf(line)??'?'};}
    if(pkg&&method)break;
  }
  if(!pkg&&!method)return null;
  const tail=`${method?` on ${method}`:''}${asked?` · asks in ${asked}`:''}`;
  if(pkg)return {source:pkg.id,at:`${pkg.id}/${pkg.file} ${pkg.fn} (libWrapper${tail})`};
  return {source:'lib-wrapper',at:`libWrapper${tail}`};
}
export const localPerformance=new PerformanceDiagnostics();
