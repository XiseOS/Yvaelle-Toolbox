/** Quick wheel: hold its key to open a wheel of actions around your pinned
 * character. Only you see it. Point at a slot and release to use it, or tap
 * the key to leave it open and click. "Edit" changes what each slot does.
 *
 * v11: with Settings › Emotes & wheel › Nested wheel on (the default) the
 * wheel is the nested one (quick-wheel-nested.mjs): Her, Light, Macros and
 * Emotes rings and up to six shortcuts. Switched off, the v10 flat wheel
 * (quick-wheel-ui.mjs) comes back with its own slots. Both share one host
 * (describe/run below) and one client setting, `quickWheel`: version 2 keeps
 * the v10 `slots` list untouched, so 10.0.1 still reads it after a rollback. */
import {QuickWheel,WHEEL_ICONS} from './quick-wheel-ui.mjs?v=13.0.0-beta.2';
import {EMOTE_ICONS,NEW_ICONS} from './quick-wheel-assets.mjs?v=13.0.0-beta.2';
import {NestedWheel,injectStyles} from './quick-wheel-nested.mjs?v=13.0.0-beta.2';
import * as WM from './quick-wheel-model.mjs?v=13.0.0-beta.2';
import {isOn as v11On,resolveV11,V11_FEATURES,FEATURES as V11_BY_ID,writeV11} from './v11/features.mjs?v=13.0.0-beta.2';
import {hudCommand,hudPreferences,eligibleTokens,resolvePinnedCharacterToken,hudFlightAction,POSE_LABELS,CONDITION_LABELS} from './hud-model.mjs?v=13.0.0-beta.2';
import {configuration,VERSION} from './config.mjs?v=13.0.0-beta.2';
import {COMPACT_BIT_PROGRAMS,REFINED_BIT_PROGRAM_IDS,isLegacyFormation} from './compact-bit-formations.mjs?v=13.0.0-beta.2';
import {REACTION_LABELS} from './effect-picker-model.mjs?v=13.0.0-beta.2';
import {chooseWarp} from './warp.mjs?v=13.0.0-beta.2';
import {ROUTINES,startRoutine} from './routines.mjs?v=13.0.0-beta.2';
import {defaultWarpLook} from './v10-versions.mjs?v=13.0.0-beta.2';
import {readFlightFeel,wingShieldRaised,feelAltitude} from './flight-feel-runtime.mjs?v=13.0.0-beta.2';
import {AFTERIMAGE_STYLES} from './flight-feel.mjs?v=13.0.0-beta.2';
import {LOOK_NAMES} from './v11/invis.mjs?v=13.0.0-beta.2';
import {SHIELD_STYLES} from './v12/shield-styles.mjs?v=13.0.0-beta.2';
import {LANDING_STYLES} from './v12/landing-recall.mjs?v=13.0.0-beta.2';
/** (12.0.0-beta.5) The names the gems show for her shield and landing styles. */
const SHIELD_NAMES={weave:'Weave',scalemail:'Scale mail',rotor:'Rotor',wingwrap:'Wing wrap'},LANDING_NAMES={classic:'Classic',powerdown:'Power down',foldaway:'Fold away',reelin:'Reel in'};
/** The Fade gem's scroll order: the scan first (her default), then the rest, the classic drain last. */
const FADE_LOOKS=Object.freeze(['c','a','b','plumage','ink','iris','starfall','ribbons','halftone','curtain','eclipse','aurora','classic']);
const ID='filament-flight';
// the flat wheel draws the two v11 actions with the nested wheel's icons
Object.assign(WHEEL_ICONS,{emotes:EMOTE_ICONS.emotes,fade:NEW_ICONS.fade,decoy:NEW_ICONS.decoy,decoyLook:NEW_ICONS.decoyLook});
const ASSETS=`modules/${ID}/assets/wheel`;

export const WHEEL_CATALOG=Object.freeze({
  flight:{group:'Flight',name:'Take off / Land',icon:'flight'},
  wings:{group:'Flight',name:'Open / fold wings',icon:'wings'},
  afterimages:{group:'Flight',name:'Afterimages on / off',icon:'afterimage',param:'afterimageStyle'},
  shield:{group:'Flight',name:'Wing shield up / down',icon:'shield'},
  height:{group:'Flight',name:'Flying height',icon:'height',param:'heightStep'},
  wingShadow:{group:'Flight',name:'Wing shadow on / off',icon:'shadow'},
  sound:{group:'Flight',name:'Her sounds on / off',icon:'sound'},
  pose:{group:'Wings',name:'Wing pose',icon:'pose',param:'pose'},
  condition:{group:'Wings',name:'Timed condition',icon:'condition',param:'condition'},
  reaction:{group:'Wings',name:'Reaction',icon:'spark',param:'reaction'},
  gesture:{group:'Wings',name:'Wing gesture',icon:'gesture',param:'gesture'},
  bits:{group:'Bits',name:'Summon / retract bits',icon:'bits'},
  formation:{group:'Bits',name:'Formation',icon:'formation',param:'formation'},
  light:{group:'Light',name:'Light on / off',icon:'light'},
  lanternAim:{group:'Light',name:'Aim the lantern',icon:'aim'},
  warp:{group:'Movement',name:'Warp (with wings)',icon:'warp',param:'warpLook'},
  warpBare:{group:'Movement',name:'Warp without wings',icon:'rift',param:'warpLook'},
  scanArea:{group:'Bit tools',name:'Scan an area',icon:'scan',param:'scanWhere'},
  examine:{group:'Bit tools',name:'Examine a creature',icon:'examine'},
  parkLight:{group:'Bit tools',name:'Leave a light',icon:'park',param:'lightPlace'},
  sendBits:{group:'Bit tools',name:'Bind bits to my target',icon:'bind'},
  gatherBits:{group:'Bits',name:'Gather bits to Ellie',icon:'gather'},
  look:{group:'Look',name:'Wear a look',icon:'look',param:'look'},
  routine:{group:'Routines',name:'Play a routine',icon:'routine',param:'routine'},
  medkit:{group:'Medicine',name:"Ellie's Medkit",icon:'medkit'},
  hud:{group:'Other',name:'Open the HUD',icon:'hud'},
  macro:{group:'Other',name:'Run a macro',icon:'macro',param:'macro'},
  emote:{group:'Emotes',name:'Play an emote',icon:'emotes',param:'emote'},
  fade:{group:'Wings',name:'Fade out / in',icon:'fade'},
  // (12.0.0-beta.6) the Decoy: make one (cast by her bits, or left behind by a warp), end it, switch its look
  decoy:{group:'Movement',name:'Decoy',icon:'decoy',param:'decoyKind'},
  decoyLook:{group:'Movement',name:'Decoy look · hardlight / normal',icon:'decoyLook'},
  // (test.11) any v11 feature as a wheel switch: its own on / off, kept where the feature is kept (her token, this browser or the world)
  feature:{group:'Features',name:'Feature on / off',icon:'condition',param:'feature'}
});
export const WHEEL_DEFAULTS=Object.freeze([
  {action:'flight'},{action:'wings'},{action:'bits'},{action:'formation',value:'halo'},
  {action:'light'},{action:'reaction',value:'pulse'},{action:'medkit'},{action:'hud'}
]);

const prefs=()=>{try{return hudPreferences(game.settings.get(ID,'hudPreferences'));}catch{return hudPreferences();}};
/** The pinned character, else the one owned token you have selected. */
export const pinnedCharacter=()=>{const available=eligibleTokens(),own=(globalThis.canvas?.tokens?.controlled??[]).filter(t=>available.includes(t));
  return resolvePinnedCharacterToken(prefs(),available)??(own.length===1?own[0]:null);};
const WARP_IDS=['threaded','seam','flicker','petal','shard','mirror','flock','starfall','ribbon','prism','cloak'];
const warpLook=v=>WARP_IDS.includes(v)?v:defaultWarpLook();
const WARP_NAMES={threaded:'Threaded',seam:'Seam',flicker:'Flicker',petal:'Petal',shard:'Shard',mirror:'Mirror',flock:'Flock',starfall:'Starfall',ribbon:'Ribbon seam',prism:'Prism',cloak:'Cloak'};
const warpName=v=>WARP_NAMES[warpLook(v)]??'Threaded';
const pinned=pinnedCharacter;
const validSlots=raw=>Array.isArray(raw)&&raw.length>=3?raw.filter(s=>s&&WHEEL_CATALOG[s.action]).slice(0,10).map(s=>({action:s.action,value:s.value??null})):WHEEL_DEFAULTS.map(s=>({...s}));

export function installQuickWheel(manager,getAPI,{medkit,getHud}={}){
  game.settings.register(ID,'quickWheel',{name:'Quick wheel',scope:'client',config:false,type:Object,default:{slots:WHEEL_DEFAULTS}});
  let wheel=null,token=null,cached=null;
  const api=()=>getAPI();
  // One read serves every slot drawn in the same moment.
  const state=()=>{
    if(!token)return null;const now=performance.now();
    if(cached?.token===token&&now-cached.at<100)return cached.value;
    let value=null;try{value=api().getState(token);}catch{}
    cached={token,at:now,value};return value;
  };
  const choices=param=>{
    switch(param){
      case 'formation':{const rest=Object.keys(COMPACT_BIT_PROGRAMS).filter(id=>!REFINED_BIT_PROGRAM_IDS.includes(id)),ids=[...REFINED_BIT_PROGRAM_IDS,...rest.filter(id=>!isLegacyFormation(id)),...rest.filter(isLegacyFormation)];return ids.map(id=>({id,label:(isLegacyFormation(id)?'Legacy · ':'')+COMPACT_BIT_PROGRAMS[id].name}));}
      case 'pose':return Object.entries(POSE_LABELS).map(([id,label])=>({id,label}));
      case 'condition':return Object.entries(CONDITION_LABELS).map(([id,label])=>({id,label:id==='auto'?'Back to automatic':label}));
      case 'reaction':return ['pulse','flare','stutter','reform'].map(id=>({id,label:REACTION_LABELS?.[id]??id[0].toUpperCase()+id.slice(1)}));
      case 'gesture':{try{return Object.entries(api().getWingGestures()).map(([id,g])=>({id,label:g.label??id}));}catch{return [];}}
      case 'warpLook':return [{id:'default',label:'Default (Versions setting)'},{id:'seam',label:'Seam (she folds into a seam of light)'},{id:'threaded',label:'Threaded (threads, ripples, shards)'},{id:'flicker',label:'Flicker (unthread and reform)'},{id:'petal',label:'Petal (her threads drift across and re-knit)'},{id:'shard',label:'Shard (her lattice breaks and locks back)'},{id:'mirror',label:'Mirror (she steps through two panes)'},{id:'flock',label:'Flock (a wheeling flock of blades turns edge-on and is gone)'},{id:'starfall',label:'Starfall (her constellation goes out here and falls in there)'},{id:'ribbon',label:'Ribbon seam (her ribbons are drawn into a seam in space)'},{id:'prism',label:'Prism (three copies split into shafts)'},{id:'cloak',label:'Cloak (she fades here in her cloak\u2019s look and comes back there)'}];
      case 'routine':return Object.entries(ROUTINES).map(([id,r])=>({id,label:r.name}));
      case 'afterimageStyle':return [{id:'last',label:'Last used style'},...Object.entries(AFTERIMAGE_STYLES).filter(([id])=>id!=='off').map(([id,v])=>({id,label:v.label}))];
      case 'heightStep':return [{id:'up',label:'Climb 5 ft'},{id:'down',label:'Descend 5 ft'},{id:'low',label:'Low (5 ft)'},{id:'cruise',label:'Cruise (15 ft)'},{id:'high',label:'High (30 ft)'}];
      case 'scanWhere':return [{id:'region',label:'Draw a region'},{id:'around',label:'Around Ellie (follows her)'}];
      case 'lightPlace':return [{id:'point',label:'At a point I click'},{id:'target',label:'On my target'}];
      case 'decoyKind':return [{id:'cast',label:'Cast (her bits fly out and cast it at a spot)'},{id:'warp',label:'Warp (she warps away and it stays where she stood)'}];
      case 'look':{try{const a=api();return [...(a.getSavedLooks?.()??[]).map(l=>({id:`saved:${l.id}`,label:l.name})),...(a.getLookPresets?.()??[]).map(l=>({id:`builtin:${l.id}`,label:l.name}))];}catch{return [];}}
      case 'macro':return (game.macros?.contents??[]).filter(m=>m.canExecute).map(m=>({id:m.uuid,label:m.name})).sort((a,b)=>a.label.localeCompare(b.label));
      case 'emote':return WM.EMOTE_LIST.map(e=>({id:e.id,label:e.label}));
      case 'feature':return V11_FEATURES.map(f=>({id:f.id,label:f.name}));
    }
    return [];
  };
  // Manual Fade (api.v11.fade, another v11 phase): shown greyed until it exists.
  const fadeMemory=new Map();
  const fadeAPI=()=>{try{const f=api()?.v11?.fade;return typeof f==='function'?f:null;}catch{return null;}};
  const fadedNow=()=>{try{const q=api()?.v11?.faded;if(typeof q==='function')return !!q(token);}catch{}return !!fadeMemory.get(token?.document?.uuid);};
  /** (12.0.0-beta.5) The lights her bits have left out and not yet been called back from (point: at a spot, target: on a token). */
  // (12.0.0-beta.6: a cast decoy holds her bits at its corners with parked-bit jobs of its own: those are the Decoy's, not lights)
  const parkedLights=()=>{try{const ui=getHud?.()?.toolUI,tasks=ui?.state?.(token)?.tasks??api()?.getBitToolState?.(token)?.tasks??[],dj=new Set(api()?.decoy?.status?.(token)?.jobs??[]);return tasks.filter(t=>t.mode==='parkLight'&&t.editable!==false&&!dj.has(t.id));}catch{return [];}};
  /** (12.0.0-beta.6) Her decoy while it stands ({kind, look, …}), else null. */
  const decoyNow=()=>{try{const D=api()?.decoy;return D?.active?.(token)?D.status(token):null;}catch{return null;}};
  const parkedFor=slot=>parkedLights().filter(t=>slot?.value==='target'?!!t.target:!t.target);
  /** What the nested wheel's smart rules read (quick-wheel-model.mjs context()). */
  const wheelState=()=>{
    const s=state(),doc=token?.document,v=resolveV11(doc),f=s?.airborne!=null?hudFlightAction(s):null;
    const combat=!!game.combat?.started&&!!game.combat.combatants?.some?.(c=>c.tokenId===token?.id);
    const emotesOff=WM.EMOTE_IDS.filter(id=>!v[`emotes.${WM.emotePart(id)}`]);
    return {air:!!s?.airborne,combat,bitsOut:!!(s?.bitsDeployed??s?.gems?.deployed),targets:game.user?.targets?.size??0,
      lanternLit:!!s?.lantern?.enabled,decoy:!!decoyNow(),decoyOn:v.decoy!==false,parked:(()=>{const out=parkedLights();return {point:out.filter(t=>!t.target).length,target:out.filter(t=>!!t.target).length};})(),wingsOpen:s?.enabled!==false,shieldNoWings:v.shieldStyles!==false&&['scalemail','rotor'].includes(v.shieldStyle),fade:!!fadeAPI(),emotesOn:!!v.emotes,emotesOff,flight:f};
  };
  const featureOn=f=>{try{return v11On(f.id,f.scope==='token'?token?.document:null);}catch{return false;}};
  const label=(param,value)=>choices(param).find(c=>c.id===value)?.label??value??'';
  const describe=slot=>{
    const s=state(),c=WHEEL_CATALOG[slot.action];
    switch(slot.action){
      case 'flight':{const f=hudFlightAction(s),v=resolveV11(token?.document),ls=v.landingStyles!==false&&v.landingStyle!=='classic'?LANDING_NAMES[v.landingStyle]:null;
        return {label:f.label,sub:s?.airborne?`Airborne${ls?` · lands with ${ls}`:''}`:'Grounded',disabled:f.disabled};}
      case 'wings':{const open=!!s?.enabled;return {label:open?'Fold wings':'Open wings',sub:open?'Wings open':'Wings folded',active:open};}
      case 'bits':{const out=!!(s?.bitsDeployed??s?.gems?.deployed);return {label:out?'Retract bits':'Summon bits',sub:out?'Bits out':'Bits docked',active:out};}
      case 'light':{const on=!!((s?.requested?.lightEnabled??s?.light?.enabled)||s?.lantern?.enabled);return {label:on?'Light off':'Light on',sub:s?.lantern?.enabled?'Lantern lit':on?'Circle lit':'Unlit',active:on};}
      case 'lanternAim':return {label:s?.lantern?.aiming?'Stop aiming':'Aim lantern',sub:'Point to aim',active:!!s?.lantern?.aiming};
      case 'afterimages':{const f=token?readFlightFeel(token.document):null,on=!!f&&f.afterimages!=='off';
        const style=slot.value&&slot.value!=='last'?slot.value:f?.lastAfterimages??'echo';
        return {label:on?'Afterimages off':'Afterimages on',sub:on?`${AFTERIMAGE_STYLES[f.afterimages]?.label} · on`:`${AFTERIMAGE_STYLES[style]?.label??'Echo'} · off`,active:on};}
      case 'shield':{const on=!!token&&wingShieldRaised(token.document),v=resolveV11(token?.document),st=v.shieldStyles!==false&&v.shieldStyle!=='weave'?SHIELD_NAMES[v.shieldStyle]:null;
        return {label:on?'Lower shield':'Raise shield',sub:`${on?'Shield up':'Shield down'}${st?` · ${st}`:''}`,active:on};}
      case 'height':return {label:label('heightStep',slot.value||'up'),sub:'Flying height'};
      case 'wingShadow':{const f=token?readFlightFeel(token.document):null,on=f?.wingShadow!=='off';return {label:on?'Wing shadow off':'Wing shadow on',sub:on?'Shadow shown':'Shadow hidden',active:on};}
      case 'sound':{const on=!!s?.audio?.enabled||!!token?.document?.getFlag?.(ID,'audio')?.enabled;return {label:on?'Sounds off':'Sounds on',sub:on?'Her sounds on':'Her sounds off',active:on};}
      case 'formation':return {label:label('formation',slot.value),sub:'Formation'};
      case 'pose':return {label:label('pose',slot.value),sub:'Wing pose'};
      case 'condition':return {label:label('condition',slot.value),sub:slot.value==='auto'?'Follow her HP':'For 1 minute'};
      case 'reaction':return {label:label('reaction',slot.value),sub:'Reaction'};
      case 'gesture':return {label:label('gesture',slot.value),sub:'Wing gesture'};
      case 'macro':return {label:label('macro',slot.value)||'Choose a macro',sub:'Macro'};
      // (test.18) each warp gem is named for its look and for whether her wings come with her
      case 'warp':return {label:`Wing warp · ${warpName(slot.value)}`,sub:'She warps with her wings'};
      case 'warpBare':return {label:`Bare warp · ${warpName(slot.value)}`,sub:'She steps through without her wings'};
      case 'scanArea':return {label:'Scan an area',sub:slot.value==='around'?'Around Ellie':'Draw a region'};
      case 'examine':return {label:'Examine',sub:'Pick a creature'};
      // (12.0.0-beta.5) while a light this gem left is out, the gem calls it back
      case 'parkLight':{const out=parkedFor(slot),n=out.length;
        return n?{label:n>1?'Call the lights back':'Call the light back',sub:`${n>1?`${n} lights`:'A light'} left ${slot.value==='target'?'on a target':'at a point'} · tap to call ${n>1?'them':'it'} back`,active:true}
          :{label:'Leave a light',sub:slot.value==='target'?'On my target':'At a point'};}
      // (12.0.0-beta.6) while a decoy stands its gem ends it; the look gem names the look it will change to
      case 'decoy':{const d=decoyNow();
        return d?{label:'Dismiss the decoy',sub:`${d.kind==='warp'?'It stands where she was':'Her bits are casting it'} · tap to end it`,active:true}
          :{label:slot.value==='warp'?'Decoy warp':'Cast a decoy',sub:slot.value==='warp'?'She warps away, her copy stays':'Her bits cast her copy at a spot'};}
      case 'decoyLook':{const d=decoyNow();return d?{label:d.look==='normal'?'Decoy · to hardlight':'Decoy · to normal',sub:`It looks ${d.look==='normal'?'like her':'like hardlight'} now`,active:d.look==='normal'}:{label:'Decoy look',sub:'Hardlight or normal'};}
      case 'sendBits':{const t=[...(game.user?.targets??[])].length;return {label:'Bind to target',sub:t===1?'Target ready':'Target one token first',disabled:t!==1};}
      case 'gatherBits':return {label:'Gather bits',sub:'Back to Ellie, still out'};
      case 'emote':{const e=WM.emoteById(slot.value);if(!e)return {label:'Choose an emote',sub:'Emote'};
        const v=e.id==='laugh'?(resolveV11(token?.document)?.laughStyle==='b'?' · B, bright':' · A, soft chuckle'):'';
        return {label:e.label,sub:`${e.hint}${v}`};}
      case 'fade':{const on=fadedNow(),lk=resolveV11(token?.document)?.invisSkin,name=LOOK_NAMES[lk]??LOOK_NAMES.c;
        return {label:on?'Fade in':'Fade out',sub:fadeAPI()?(on?'Faded · tap to return':`Fade from view · ${name}`):'Fade arrives in a later build',active:on};}
      case 'feature':{const f=V11_BY_ID.get(slot.value);if(!f)return {label:slot.value?'Feature not found':'Choose a feature',sub:'Feature',...(slot.value?{reason:'That feature is gone · choose another'}:{})};
        const on=featureOn(f),gm=f.scope==='gm'&&!game.user?.isGM;
        return {label:f.name,sub:gm?'Only the GM can switch this':on?'On · tap to switch off':'Off · tap to switch on',active:on,...(gm?{reason:'Only the GM can switch this'}:{})};}
      case 'look':{const c=choices('look').find(x=>x.id===slot.value);return c?{label:c.label,sub:'Wear this look'}:{label:slot.value?'Look not found':'Choose a look',sub:slot.value?'Edit to choose another':'Wear this look',...(slot.value?{reason:'That look is gone · choose another'}:{})};}
      case 'routine':{const r=ROUTINES[slot.value];if(!r)return {label:'Choose a routine',sub:'Routine'};const need=r.needs==='target'?[...(game.user?.targets??[])].length===1:r.needs==='allyThreat'?[...(game.user?.targets??[])].length>=1:true;
        return {label:r.name,sub:slot.value==='searchlights'?(token?.document?.getFlag?.(ID,'restLights')?'On · tap to stop':'Off · tap to start'):need?'Ready':r.needs==='target'?'Then click a token':'Then click the threat'};}
      default:return {label:c?.name??slot.action,sub:''};
    }
  };
  const run=async slot=>{
    const a=api(),p=prefs(),cfg=configuration();cached=null;
    switch(slot.action){
      case 'flight':return hudCommand(a,token,'flightToggle',null,p,cfg);
      case 'wings':return hudCommand(a,token,'toggleWings',null,p,cfg);
      case 'bits':return hudCommand(a,token,'toggleBits',null,p,cfg);
      case 'light':return hudCommand(a,token,'toggleLightMode',null,p,cfg);
      case 'lanternAim':return hudCommand(a,token,'lanternAim',null,p,cfg);
      case 'afterimages':{const f=readFlightFeel(token.document),style=slot.value&&slot.value!=='last'?slot.value:f.lastAfterimages??'echo';
        return a.setFlightFeel(token,{afterimages:f.afterimages==='off'?style:'off'});}
      case 'shield':return a.wingShield(token);
      case 'height':{const step=slot.value||'up',to={low:5,cruise:15,high:30}[step];
        // (beta.32: by default these set her token's elevation; with "Takeoff sets her elevation" on, her flying height.)
        if(to)return readFlightFeel(token.document).takeoffElevation?a.setFlightFeel(token,{altitude:to}):a.altitude(token,{to});return a.altitude(token,{by:step==='down'?-5:5});}
      case 'wingShadow':{const f=readFlightFeel(token.document);return a.setFlightFeel(token,{wingShadow:f.wingShadow==='off'?'normal':'off'});}
      case 'sound':{const on=!!token.document.getFlag(ID,'audio')?.enabled;return a.setAudio(token,{enabled:!on});}
      case 'formation':return hudCommand(a,token,'compactProgram',slot.value,p,cfg);
      case 'pose':return hudCommand(a,token,'pose',slot.value,p,cfg);
      case 'condition':if(slot.value!=='auto')return a.conditionFor(token,slot.value,60000);
        await a.clearConditionOverride(token);return a.setState(token,{condition:'auto',autoHP:true});
      case 'reaction':return hudCommand(a,token,slot.value,null,p,cfg);
      case 'gesture':return a.wingGesture(token,slot.value);
      case 'medkit':return medkit?.();
      case 'warp':return chooseWarp(token,{style:'wings',look:WARP_IDS.includes(slot.value)?slot.value:undefined});
      case 'warpBare':return chooseWarp(token,{style:'bare',look:WARP_IDS.includes(slot.value)?slot.value:undefined});
      case 'scanArea':case 'examine':case 'parkLight':{
        // (12.0.0-beta.5) a light this gem left is still out: the same gem calls it back (the bit flies home as it does from the HUD's Return)
        if(slot.action==='parkLight'){const out=parkedFor(slot);if(out.length){for(const t of out)await a.stopBitTool(token,{id:t.id});return true;}}
        const hud=getHud?.(),ui=hud?.toolUI;if(!ui)throw new Error('Bit tools need a scene reload after updating.');
        const tools=ui.state(token)??{},avail=tools.available??['leftUpper','rightUpper','leftLower','rightLower'],count=hud.model?.().bitTasks?.preferredCount??4,bits=avail.slice(0,slot.action==='parkLight'?1:Math.max(1,count));
        if(!bits.length)throw new Error('No free bits right now. Recall some first.');
        if(slot.action==='scanArea')return ui.begin('areaScan',slot.value==='around'?{bits,followSource:true,radiusFeet:15}:{bits});
        if(slot.action==='examine')return ui.begin('creatureScan',{bits});
        return ui.begin('parkLight',{bits,pickTarget:slot.value==='target'});
      }
      case 'sendBits':{const target=[...(game.user?.targets??[])][0];if(!target)throw new Error('Target one token first.');const free=(a.bits?.getState?.(token)?.available)??undefined;return hudCommand(a,token,'assignBits',{target,...(free?{bits:free}:{count:4})},p,cfg);}
      case 'gatherBits':return hudCommand(a,token,'gatherBits',null,p,cfg);
      case 'decoy':{const D=a.decoy;if(!D)throw new Error('The Decoy needs a scene reload after updating.');
        if(decoyNow())return D.dismiss(token);return D.choose(token,slot.value==='warp'?'warp':'cast');}
      case 'decoyLook':{const D=a.decoy;if(!D||!decoyNow())throw new Error('No decoy stands.');return D.setLook(token);}
      case 'look':{const [kind,id]=String(slot.value??'').split(':');if(!id)throw new Error('Choose a look for this slot.');
        if(kind==='saved'){const l=a.getSavedLooks().find(x=>x.id===id);if(!l)throw new Error('That saved look no longer exists.');return a.applyLook(token,l.look);}
        return a.applyLook(token,id);}
      case 'routine':{if(!ROUTINES[slot.value])throw new Error('Choose a routine for this slot.');return startRoutine(token,slot.value);}
      case 'hud':return openHudWithFx(a);
      case 'emote':{const em=a.v11?.emote;if(!em)throw new Error('Emotes need a scene reload after updating.');return em(slot.value,{token});}
      case 'fade':{const f=fadeAPI();if(!f)throw new Error('Fade is not in this build yet.');const on=!fadedNow();const r=await f(on,{token});
        // (test.6) a token Yvaelle’s Toolbox has never been switched on for has no cloak record: say so, not nothing
        if(r===false)throw new Error(`${token.name??'She'} can't fade yet: switch Yvaelle’s Toolbox on for her token first.`);fadeMemory.set(token.document?.uuid,on);return r;}
      case 'macro':{const m=slot.value?await fromUuid(slot.value):null;if(!m)throw new Error('Choose a macro for this slot.');return m.execute();}
      case 'feature':{const f=V11_BY_ID.get(slot.value);if(!f)throw new Error('Choose a feature for this slot.');
        if(f.scope==='gm'&&!game.user?.isGM)throw new Error(`Only the GM can switch ${f.name}.`);
        const on=!featureOn(f);await writeV11(f.id,on,f.scope==='token'?token.document:null);ui.notifications?.info?.(`${f.name}: ${on?'on':'off'}`);return on;}
    }
  };
  /** (test.11) The HUD opened from the wheel plays the Hardlight scan. (12.1.0-beta.1) The scan now belongs to the HUD
   * itself, however it is opened (keepsake/hud-open-fx.mjs installOpenFx), so the wheel only opens it. */
  const openHudWithFx=a=>a.openHUD(token);
  const anchor=()=>{
    if(!token?.center||!canvas?.ready)return null;
    const p=canvas.stage.worldTransform.apply(token.center),view=canvas.app.view,r=view.getBoundingClientRect(),sx=r.width/(canvas.app.renderer.screen.width||r.width),sy=r.height/(canvas.app.renderer.screen.height||r.height);
    const zoom=canvas.stage.worldTransform.a||1,size=Math.max(token.w??0,token.h??0)||canvas.grid?.size||100;
    return {x:r.left+p.x*sx,y:r.top+p.y*sy,r:size*zoom*sx/2};
  };
  /** Where the pointer is now (canvas.mousePosition, world → screen), read once when the wheel opens. */
  const pointerNow=()=>{
    try{const m=canvas?.mousePosition;if(!m||!canvas?.ready)return null;
      const p=canvas.stage.worldTransform.apply(m),r=canvas.app.view.getBoundingClientRect(),sx=r.width/(canvas.app.renderer.screen.width||r.width),sy=r.height/(canvas.app.renderer.screen.height||r.height);
      return {x:r.left+p.x*sx,y:r.top+p.y*sy};}catch{return null;}
  };
  const readWheel=()=>{try{return game.settings.get(ID,'quickWheel');}catch{return null;}};
  /* ---------------- the macro ring (a user flag, so it follows the player) ---------------- */
  const macroInfo=m=>m&&{uuid:m.uuid,name:m.name,img:m.img||'icons/svg/dice-target.svg',type:m.type==='chat'?'chat':'script',line:WM.macroLine(m.type,m.command),canExecute:m.canExecute!==false};
  const macroDoc=uuid=>{try{const m=fromUuidSync(uuid);return m?.documentName==='Macro'?m:null;}catch{return null;}};
  let iconLib=null;
  const iconLibrary=()=>iconLib??=Promise.all([
    fetch(`${ASSETS}/macro-icons-sprite.svg`).then(r=>{if(!r.ok)throw new Error('The macro icon library is missing.');return r.text();}),
    fetch(`${ASSETS}/macro-icons.json`).then(r=>r.json()),
    fetch(`${ASSETS}/macro-icons-groups.json`).then(r=>r.ok?r.json():null).catch(()=>null)
  ]).then(([sprite,entries,groups])=>({sprite,entries:Array.isArray(entries)?entries:entries?.icons??[],groups:groups??undefined})).catch(e=>{iconLib=null;throw e;});
  const dragData=e=>{
    const TE=foundry?.applications?.ux?.TextEditor?.implementation??globalThis.TextEditor;
    try{if(TE?.getDragEventData)return TE.getDragEventData(e);}catch{}
    try{return JSON.parse(e.dataTransfer?.getData('text/plain')||'null');}catch{return null;}
  };
  /* ---------------- previews: baked strips (assets/wheel/<kind>-previews.*) ---------------- */
  // (12.0.0-beta.5) the emotes' cameo, for every animated choice on the wheel: her warps, her shield style, her cloak's
  // look and her landing style. Each kind is its own strip, fetched and decoded the first time a gem of that kind is
  // pointed at (the emotes' when the wheel opens, as before); nothing is loaded for a kind that is never looked at.
  const PREVIEW_FILES={emote:'emote-previews',warp:'warp-previews',shield:'shield-previews',landing:'landing-previews',cloak:'cloak-previews'};
  const previewSets={};
  const loadPreviews=(kind='emote')=>{
    if(previewSets[kind])return previewSets[kind];if(!PREVIEW_FILES[kind])return {ready:false,failed:true};previewSets[kind]={ready:false};
    // (test.6) the strip (4224×1056) is decoded off the main thread into an ImageBitmap: drawn from a plain
    // <img>, its first drawImage decoded it synchronously, a ~55 ms long task as the Emotes ring opened
    fetch(`${ASSETS}/${PREVIEW_FILES[kind]}.json`).then(r=>r.json()).then(async meta=>{
      const blob=await fetch(`${ASSETS}/${meta.image}`).then(r=>{if(!r.ok)throw new Error(`${kind} previews missing`);return r.blob();});
      const img=typeof createImageBitmap==='function'?await createImageBitmap(blob):await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=URL.createObjectURL(blob);});
      previewSets[kind]={ready:true,meta,img};}).catch(()=>{previewSets[kind]={ready:false,failed:true};});
    return previewSets[kind];
  };
  const preview=(id,kind='emote')=>{const P=loadPreviews(kind);if(!P.ready)return null;const m=P.meta,set=m.emotes??m.items??{},e=set[id]??(kind==='emote'?set.idle:null);if(!e)return null;
    return {img:P.img,n:e.n,w:m.cell,h:m.cell,fps:e.fps??m.fps,cols:e.n,row:e.row};};
  /** Which preview a slot plays in the plaque while it is pointed at: {kind, id}, or null for a gem with no animation of its own. */
  const previewOf=slot=>{
    let v;try{v=resolveV11(token?.document);}catch{return null;}
    switch(slot?.action){
      case 'emote':return v.emotes&&WM.emoteById(slot.value)?{kind:'emote',id:slot.value}:null;
      case 'warp':case 'warpBare':return {kind:'warp',id:warpLook(slot.value)};
      case 'shield':return {kind:'shield',id:v.shieldStyles!==false&&SHIELD_STYLES.includes(v.shieldStyle)?v.shieldStyle:'weave'};
      case 'fade':return v.invisLooks===false||!fadeAPI()?null:{kind:'cloak',id:FADE_LOOKS.includes(v.invisSkin)?v.invisSkin:'c'};
      // (her landing: only while she is in the air, when the gem lands her)
      case 'flight':return state()?.airborne?{kind:'landing',id:v.landingStyles!==false&&LANDING_STYLES.includes(v.landingStyle)?v.landingStyle:'classic'}:null;
    }
    return null;
  };
  const features=()=>{const v=resolveV11(token?.document);if(v.emotes)loadPreviews();   // (the cameo strip decodes off-thread while she points)
    return {shortcuts:!!v.wheelShortcuts,macros:!!v.macroRing,emotes:!!v.emotes,arcSize:WM.arcSize(v['nestedWheel.arcSize']),layout:WM.layoutOf(v['nestedWheel.layout']),cycleFx:['off','plain','orbit','slide','roll','facet','thread'].includes(v['nestedWheel.cycleFx'])?v['nestedWheel.cycleFx']:'orbit',macroIcons:v['macroRing.macroIcons']??'keepsake',look:v['nestedWheel.look'],ring:v['nestedWheel.ring']};};
  const host={doc:document,version:VERSION,anchor,pointer:pointerNow,catalog:WHEEL_CATALOG,choices,describe,run,
    slots:()=>validSlots(readWheel()?.slots),
    saveSlots:slots=>{void game.settings.set(ID,'quickWheel',WM.withFlatSlots(readWheel(),validSlots(slots)));},
    defaults:()=>WHEEL_DEFAULTS.map(s=>({...s})),
    // nested wheel
    config:()=>readWheel(),saveConfig:cfg=>{void game.settings.set(ID,'quickWheel',cfg);},
    state:()=>wheelState(),features,
    emotes:()=>{loadPreviews();return WM.EMOTE_LIST.map(e=>({id:e.id,label:e.label,hint:e.hint}));},
    preview,previewOf,
    macros:()=>(game.macros?.contents??[]).filter(m=>m.canExecute).map(m=>({id:m.uuid,label:m.name,img:m.img})).sort((a,b)=>a.label.localeCompare(b.label)),
    iconFor:s=>{if(s.action!=='macro')return null;const m=macroDoc(s.value);if(!m)return null;
      const e=macroRing().find(x=>x.uuid===s.value);if(e?.icon?.startsWith('mi-'))return {use:e.icon};if(e?.icon?.startsWith('fi:'))return {img:`icons/svg/${e.icon.slice(3)}.svg`};return {img:m.img||'icons/svg/dice-target.svg'};},
    macroRing:()=>macroRing(),
    saveMacroRing:list=>game.user.setFlag(ID,WM.MACRO_FLAG,WM.ringFlagValue(list)),
    resolveMacro:uuid=>macroInfo(macroDoc(uuid)),
    listMacros:()=>(game.macros?.contents??[]).map(macroInfo),
    // (test.11) a macro written in the wheel: a real Foundry macro of yours (Foundry's own permission decides whether you may create a script)
    createMacro:async({name,type='script',command=''}={})=>{
      const n=String(name??'').trim().slice(0,80),c=String(command??'');if(!n)throw new Error('Give the macro a name.');if(!c.trim())throw new Error('Write what the macro does.');
      const M=globalThis.Macro?.implementation??globalThis.Macro;if(!M?.create)throw new Error('Macros cannot be created here.');
      const m=await M.create({name:n,type:type==='chat'?'chat':'script',command:c,img:'icons/svg/dice-target.svg'});if(!m)throw new Error('Foundry did not create the macro (you may lack permission).');return m.uuid;},
    // (test.13) the mouse wheel over a height gem: her flying height now, and a step of 5 ft (the same call as Climb / Descend)
    heightNow:()=>{try{return Math.round(feelAltitude(token.document));}catch{return null;}},
    heightBy:async feet=>{cached=null;const r=await api().altitude(token,{by:feet});cached=null;const now=Number(r);return Number.isFinite(now)?Math.round(now):Math.round(feelAltitude(token.document));},
    // (test.13) the mouse wheel over the Fade gem: which side her cloak sweeps from (her token's own setting)
    // (test.18) the Fade gem: the mouse wheel changes her cloak's look (her token's "Invisibility skin"), and the side
    // of the gem pointed at is the side her cloak starts from (her token's "Sweep direction"). Fading in runs it back.
    fadeLook:async dir=>{const ids=FADE_LOOKS,names=LOOK_NAMES;
      const cur=resolveV11(token?.document)?.invisSkin??'c';if(!dir)return {id:cur,label:names[cur]??cur};
      const n=ids.length,next=ids[((Math.max(0,ids.indexOf(cur))+dir)%n+n)%n];await writeV11('invisSkin',next,token.document);return {id:next,label:names[next],at:ids.indexOf(next)+1,of:n};},
    fadeLookNow:()=>{const cur=resolveV11(token?.document)?.invisSkin??'c';return {id:cur,label:LOOK_NAMES[cur]??cur};},
    sweepId:()=>resolveV11(token?.document)?.invisSweep??'left',
    setSweep:async id=>{if(!['left','right','top','bottom'].includes(id))return false;if((resolveV11(token?.document)?.invisSweep??'left')===id)return false;await writeV11('invisSweep',id,token.document);return true;},
    fadeSweep:async dir=>{const ids=['left','right','top','bottom'],names={left:'From the left',right:'From the right',top:'From the top',bottom:'From the bottom'};
      const cur=resolveV11(token?.document)?.invisSweep??'left';if(!dir)return {id:cur,label:names[cur]??cur};
      const next=ids[((ids.indexOf(cur)+dir)%4+4)%4];await writeV11('invisSweep',next,token.document);return {id:next,label:names[next]};},
    sweepNow:()=>{const names={left:'From the left',right:'From the right',top:'From the top',bottom:'From the bottom'},cur=resolveV11(token?.document)?.invisSweep??'left';return names[cur]??cur;},
    runMacro:async uuid=>{const m=macroDoc(uuid);if(!m)throw new Error('That macro no longer exists.');if(m.canExecute===false)throw new Error(`You can't run ${m.name}.`);return m.execute();},
    macroDropData:dragData,iconLibrary,
    reducedMotion:()=>!!configuration().reduced||globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
    error:e=>ui.notifications.error(`Quick wheel: ${e?.message??e}`)};
  /** The saved ring; never saved yet → the macros the v10 flat wheel had (seeded once, on the first save). */
  function macroRing(){return WM.ringFrom(game.user?.getFlag?.(ID,WM.MACRO_FLAG),WM.migrate(readWheel()).macros);}
  const nestedOn=()=>{try{return v11On('nestedWheel');}catch{return true;}};
  const open=()=>{
    token=pinned();
    if(!token){ui.notifications.info('Pin a character in the Yvaelle’s Toolbox HUD, or select one token you own, to use the quick wheel.');return false;}
    const Want=nestedOn()?NestedWheel:QuickWheel;
    if(wheel&&!(wheel instanceof Want)){wheel.close();wheel=null;}
    // (12.0.0-beta.5) tapped twice: the last used action again (the first tap left the wheel open; a hold never comes here twice)
    if(wheel?.isOpen&&wheel.again?.())return true;
    wheel??=new Want(host);if(!wheel.isOpen)wheel.open();return true;
  };
  game.keybindings.register(ID,'quickWheel',{
    name:'Quick wheel (hold)',
    hint:'Hold to open the quick wheel around your pinned character (or the one token you have selected); point and release. Tap to leave it open and click instead; tap twice to repeat the last action. Releasing on her cancels. Esc or right-click goes back; Edit changes it.',
    editable:[],restricted:false,repeat:false,
    onDown:context=>{const t=context?.event?.target;if(t?.closest?.('input,textarea,select,[contenteditable="true"]'))return false;return open();},
    onUp:context=>{const t=context?.event?.target;if(t?.closest?.('input,textarea,select,[contenteditable="true"]'))return false;wheel?.release();return true;}
  });
  Hooks.on('canvasTearDown',()=>wheel?.close());
  // (test.6) the wheel's styles and shared SVG go into the page while the browser is idle after the game loads,
  // not on the first press: adding a stylesheet restyles all of Foundry's page, a long task in the middle of using it
  Hooks.once('ready',()=>{const idle=globalThis.requestIdleCallback??(f=>setTimeout(f,1500));idle(()=>{try{if(nestedOn())injectStyles(document);}catch{}},{timeout:8000});});
  // a macro created, renamed, re-iconed or deleted while the ring is open: redraw it
  for(const hook of ['createMacro','updateMacro','deleteMacro'])Hooks.on(hook,()=>wheel?.macrosChanged?.());
  // (11.0.0-test.4) instance: the open wheel, for the self-check (it opens, looks and closes; it never fires a slot)
  return Object.freeze({open,close:()=>wheel?.close(),catalog:()=>structuredClone(WHEEL_CATALOG),token:()=>pinned(),instance:()=>wheel?.isOpen?wheel:null});
}
