/** Set pieces (v10 beta.24): Chrysalis, Constellation and the Hardlight
 * bridge play as routines (drawn on the routine layer on every screen, the
 * owner starts them); the Lifeline is a watcher every screen derives from the
 * same shared data (an ally's Dying condition), so it needs no messages. */
import {createOverlay} from './overlay-layer.mjs?v=13.0.0-beta.2';
import {liveBitPositions} from './bit-renderer.mjs?v=13.0.0-beta.2';
const ID='filament-flight';
const TAU=Math.PI*2,MAG=[255,0,255],HOT=[255,214,255],SOFT=[231,103,206],GOLD=[226,196,140];
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const ease=t=>t*t*(3-2*t),easeOut=t=>1-(1-t)**3,easeIn=t=>t*t*t,easeInOut=t=>t<.5?4*t*t*t:1-(-2*t+2)**3/2;
const lerp=(a,b,t)=>a+(b-a)*t;
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${clamp(a)})`;
const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
const centerOf=t=>t?.center??{x:t.x+t.w/2,y:t.y+t.h/2};
const images=new Map();
function image(src){if(!src)return null;let img=images.get(src);if(!img){img=new Image();img.decoding='async';img.src=src;images.set(src,img);}return img.complete&&img.naturalWidth?img:null;}
const asset=name=>{try{return foundry.utils.getRoute(`modules/${ID}/assets/flight/${name}.webp`);}catch{return `/assets/flight/${name}.webp`;}};

function glow(f,x,y,r,a,col=MAG){if(a<=.005||r<=0)return;const g=f.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,rgba(HOT,.55*a));g.addColorStop(.35,rgba(col,.3*a));g.addColorStop(1,rgba(col,0));f.fillStyle=g;f.beginPath();f.arc(x,y,r,0,TAU);f.fill();}
function star(f,x,y,r,a){if(a<=.01)return;glow(f,x,y,r*3.2,a*.8);f.fillStyle=rgba([255,240,255],a);f.beginPath();
  f.moveTo(x,y-r*1.8);f.lineTo(x+r*.3,y-r*.3);f.lineTo(x+r*1.8,y);f.lineTo(x+r*.3,y+r*.3);f.lineTo(x,y+r*1.8);f.lineTo(x-r*.3,y+r*.3);f.lineTo(x-r*1.8,y);f.lineTo(x-r*.3,y-r*.3);f.closePath();f.fill();}
function glint(f,x,y,r,a){if(a<=.01)return;glow(f,x,y,r*2.6,a*.5,GOLD);f.fillStyle=rgba([240,214,160],a);f.beginPath();
  f.moveTo(x,y-r*1.7);f.lineTo(x+r*.25,y-r*.25);f.lineTo(x+r*1.7,y);f.lineTo(x+r*.25,y+r*.25);f.lineTo(x,y+r*1.7);f.lineTo(x-r*.25,y+r*.25);f.lineTo(x-r*1.7,y);f.lineTo(x-r*.25,y-r*.25);f.closePath();f.fill();}
function thread(f,a,b,{alpha=.6,w=1.2,bend=0,color=MAG,dash=null,offset=0,upto=1}={}){
  if(alpha<=.01||upto<=0)return;const mx=(a.x+b.x)/2-(b.y-a.y)*bend,my=(a.y+b.y)/2+(b.x-a.x)*bend;
  const pt=u=>{const v=1-u;return [v*v*a.x+2*v*u*mx+u*u*b.x,v*v*a.y+2*v*u*my+u*u*b.y];};
  f.save();f.globalCompositeOperation='lighter';f.lineCap='round';if(dash){f.setLineDash(dash);f.lineDashOffset=offset;}
  const draw=()=>{f.beginPath();const p0=pt(0);f.moveTo(p0[0],p0[1]);const n=24,end=Math.max(1,Math.round(n*upto));for(let k=1;k<=end;k++){const q=pt(k/n);f.lineTo(q[0],q[1]);}};
  draw();f.strokeStyle=rgba(color,alpha*.35);f.lineWidth=w*3.5;f.stroke();f.strokeStyle=rgba(color,alpha);f.lineWidth=w;f.stroke();f.strokeStyle=rgba(HOT,alpha*.7);f.lineWidth=w*.35;f.stroke();
  f.restore();return pt;
}
function bitsOf(token,P,from){
  const live=liveBitPositions(token);
  if(live.length)return live.map(b=>P.pt(b));
  return [[-.8,-.55],[.8,-.55],[-.7,.45],[.7,.45]].map(([x,y])=>({x:from.x+x*60*P.scale,y:from.y+y*60*P.scale}));
}

/* =============================== Chrysalis =============================== */
export const CHRYSALIS={name:'Chrysalis',hint:'Her wing filaments reach over a patient and weave a cocoon of magenta thread around them; it tightens, then unravels into rising light. Also plays by itself on a critical heal or when she brings someone back from dying.',needs:'target',duration:5400};
/** beta.29: a weave of her own filament (magenta, two gold strands) spirals
 * round the patient, tightens with a slow heartbeat, then unravels from the
 * feet up into threads of light that rise and fade. No cage, burst or petals. */
export function drawChrysalis(f,P,fx,t,reduced){
  const T=fx.target;if(!T||T.destroyed)return;
  const A=P.pt(centerOf(fx.token)),B=P.pt(centerOf(T)),D=Math.max(T.w,T.h)*P.scale,E=fx.size*P.scale,px=Math.max(.7,P.scale);
  const weave=easeOut(seg(t,.7,2.3)),tight=easeInOut(seg(t,2.2,3.4)),loose=seg(t,3.35,4.7),rise=seg(t,3.4,5.4);
  f.save();f.globalCompositeOperation='lighter';f.lineCap='round';f.lineJoin='round';
  // her filaments reach over: two broad wing arcs from her shoulders to the patient
  const reach=easeOut(seg(t,0,.9)),fade=1-seg(t,2.2,3.2);
  if(reach>0&&fade>0)for(const side of [-1,1])for(let r=0;r<3;r++){
    const a={x:A.x+side*E*.25,y:A.y-E*.15},b={x:B.x+side*D*(.3-r*.08),y:B.y-D*(.3-r*.14)};
    thread(f,a,b,{alpha:.5*fade*(1-r*.18),w:Math.max(1,E*.016),bend:side*(.28+r*.06),upto:reach,color:r===1?GOLD:MAG});}
  // the weave: six strands spiral round the patient, back half dimmer
  if(weave>0&&loose<1){
    const rx=D*lerp(.66,.5,tight),ry=D*lerp(.8,.68,tight),beat=Math.exp(-(((t*1.1)%1-.1)**2)/.004)*tight;
    const cut=easeIn(loose);// unravel from the feet up
    for(let j=0;j<6;j++){const gold=j===1||j===4,turns=1.15+.15*tight;
      let prev=null;
      for(let k=0;k<=48;k++){const v=k/48;if(v>weave)break;if(1-v<cut){prev=null;continue;}
        const th=v*TAU*turns+j*TAU/6+t*(.5+.6*tight),w=Math.sin(Math.PI*v),z=Math.sin(th);
        const p={x:B.x+Math.cos(th)*rx*w,y:B.y-ry+2*ry*v+z*ry*.07,z};
        if(prev){const depth=.35+.65*(z+prev.z+2)/4,a=(gold?.55:.6)*depth*(1+.6*beat);
          f.beginPath();f.moveTo(prev.x,prev.y);f.lineTo(p.x,p.y);f.strokeStyle=rgba(gold?GOLD:MAG,a*.3);f.lineWidth=Math.max(1,D*.03)*px;f.stroke();
          f.strokeStyle=rgba(gold?GOLD:MAG,a);f.lineWidth=Math.max(.8,D*.011)*px;f.stroke();if(depth>.75){f.strokeStyle=rgba(gold?[240,214,160]:HOT,a*.5);f.lineWidth=Math.max(.5,D*.004)*px;f.stroke();}}
        prev=p;}
      // a bead of light runs up each strand with every heartbeat while it is tight
      if(!reduced&&tight>.05&&loose<.2){const v=((t*1.1+j*.17)%1),th=v*TAU*turns+j*TAU/6+t*(.5+.6*tight),w=Math.sin(Math.PI*v);
        glow(f,B.x+Math.cos(th)*rx*w,B.y-ry+2*ry*v,D*.07,.6*tight*(1-loose*5)*(.4+.6*(Math.sin(th)+1)/2),gold?GOLD:MAG);}}
    // the patient warms inside (never a white flash)
    glow(f,B.x,B.y,D*.7,(.1*weave+.14*tight)*(1-loose),SOFT);
  }
  // rising light: the freed threads lift away as fine wisps and fade
  if(!reduced&&rise>0){for(let i=0;i<22;i++){const born=hash(i*3.1)*.75,k=seg(rise,born,born+.45);if(k<=0||k>=1)continue;
    const x=B.x+(hash(i*1.7)-.5)*D*1.1*(1-.3*k)+Math.sin(k*5+i)*D*.05,y0=B.y+D*(.55-1.1*hash(i*2.3))-k*D*1.3,len=D*(.12+.1*hash(i*4.9))*(1-.4*k),a=Math.sin(Math.PI*k)*.7;
    f.beginPath();f.moveTo(x,y0);f.quadraticCurveTo(x+Math.sin(i+k*3)*D*.04,y0-len*.5,x+Math.sin(i*1.3)*D*.03,y0-len);
    f.strokeStyle=rgba(i%3?MAG:GOLD,a*.35);f.lineWidth=Math.max(1,D*.025)*px;f.stroke();f.strokeStyle=rgba(i%3?MAG:GOLD,a);f.lineWidth=Math.max(.7,D*.009)*px;f.stroke();}
    // a soft column of light over the patient as it lets go
    const col=Math.sin(Math.PI*seg(t,3.5,5.3))*.22;if(col>.01){const g=f.createLinearGradient(B.x,B.y+D*.5,B.x,B.y-D*1.4);g.addColorStop(0,rgba(SOFT,0));g.addColorStop(.35,rgba(SOFT,col));g.addColorStop(1,rgba(GOLD,0));
      f.fillStyle=g;f.beginPath();f.ellipse(B.x,B.y-D*.45,D*.42,D*.95,0,0,TAU);f.fill();}}
  f.restore();
}

/* ============================= Constellation ============================= */
export const CONSTELLATION={name:'Constellation',hint:'Her bits fly to each ally in sight and draw glowing lines between them: a star map of the party. Then they come home.',needs:null,duration:7800};
function constellationAllies(fx){
  if(fx.mem.allies)return fx.mem.allies;
  const me=fx.token,c=centerOf(me),grid=canvas.grid?.size??100,friendly=globalThis.CONST?.TOKEN_DISPOSITIONS?.FRIENDLY??1;
  const list=(canvas.tokens?.placeables??[]).filter(t=>t!==me&&!t.document?.hidden&&t.visible!==false&&t.actor&&(t.document?.disposition===friendly||t.actor?.hasPlayerOwner)&&Math.hypot(centerOf(t).x-c.x,centerOf(t).y-c.y)<=grid*14)
    .sort((a,b)=>Math.atan2(centerOf(a).y-c.y,centerOf(a).x-c.x)-Math.atan2(centerOf(b).y-c.y,centerOf(b).x-c.x)).slice(0,8);
  return fx.mem.allies=list;
}
export function drawConstellation(f,P,fx,t,reduced){
  const me=fx.token,A=P.pt(centerOf(me)),E=fx.size*P.scale,allies=constellationAllies(fx),px=Math.max(.7,P.scale);
  const bits=fx.mem.bits??=bitsOf(me,P,A).map(b=>({x:b.x-A.x,y:b.y-A.y}));
  // each star hangs just above its ally; her own star sits above her
  const nodes=[{t:me,self:true},...allies.map(t=>({t}))].map((n,i)=>{const c=P.pt(centerOf(n.t)),D=Math.max(n.t.w,n.t.h)*P.scale;return {...n,i,x:c.x,y:c.y-D*.62,base:c,D};});
  const out=easeInOut(seg(t,0,1.4)),link=seg(t,1.4,2.8),hold=t>=2.8&&t<5.9,home=easeInOut(seg(t,6.0,7.4)),fade=1-seg(t,5.6,6.4);
  f.save();f.globalCompositeOperation='lighter';
  // a faint field of dust over the party while the map is drawn
  if(!reduced&&link>0&&fade>0){for(let i=0;i<40;i++){const n=nodes[i%nodes.length],x=n.x+(hash(i*2.1)-.5)*E*3,y=n.y+(hash(i*3.7)-.5)*E*2,a=(.25+.35*Math.sin(t*3+i))*link*fade;if(a>.02){f.fillStyle=rgba(HOT,a*.6);f.beginPath();f.arc(x,y,Math.max(.6,E*.008),0,TAU);f.fill();}}}
  // the lines: a ring through every star, plus a spoke from her to each
  if(link>0&&fade>0&&nodes.length>1){
    for(let i=0;i<nodes.length;i++){const a=nodes[i],b=nodes[(i+1)%nodes.length];if(nodes.length===2&&i===1)break;
      thread(f,a,b,{alpha:.55*fade,w:Math.max(1,E*.016),bend:.06,upto:seg(link,i/nodes.length*.6,i/nodes.length*.6+.4)});}
    for(const n of nodes.slice(1))thread(f,nodes[0],n,{alpha:.25*fade,w:Math.max(.8,E*.01),dash:[E*.05,E*.07],offset:-t*E*.6,upto:link});
  }
  // the stars: bits fly out to them, twinkle, and fly home
  nodes.forEach((n,i)=>{
    const b=bits[i%bits.length],from={x:A.x+b.x,y:A.y+b.y},k=n.self?1:out;
    let x=lerp(from.x,n.x,k),y=lerp(from.y,n.y,k)-Math.sin(Math.PI*k)*E*.6*(n.self?0:1);
    if(home>0){x=lerp(n.x,from.x,home);y=lerp(n.y,from.y,home)-Math.sin(Math.PI*home)*E*.4;}
    // beta.29: her bits stay docked and cast the stars: each star is born at its
    // bit (a glint there), trails a tether back to it, and goes home into it
    const tw=.75+.25*Math.sin(t*5+i*1.9),a=(n.self?seg(t,.6,1.4):easeIn(Math.min(1,k*2.2)))*(home>0?1-easeIn(seg(home,.55,1)):1);
    if(!n.self&&!reduced){const cast=Math.sin(Math.PI*seg(t,0,.5))+(home>0?Math.sin(Math.PI*seg(home,.7,1)):0);if(cast>.01)glint(f,from.x,from.y,Math.max(1.5,E*.03),.8*cast);
      const tether=(k<1?1-k*.4:0)+(home>0&&home<1?Math.sin(Math.PI*home)*.8:0);if(tether>.01)thread(f,from,{x,y},{alpha:.32*tether,w:Math.max(.8,E*.01),bend:.12,color:GOLD});}
    star(f,x,y,Math.max(2,E*.065)*(hold?tw:1),a);
    if(hold&&!n.self){glow(f,n.base.x,n.base.y,n.D*.7,.18*fade*tw,SOFT);}
  });
  f.restore();
}

/* ============================ Hardlight bridge ============================ */
export const BRIDGE={name:'Hardlight bridge',hint:'Her bits lay a span of glowing panels to a spot you choose; she walks across and it folds away behind her.',needs:'point',duration:6400};
export const BRIDGE_MOVE_AT=1.75;
export function drawBridge(f,P,fx,t,reduced){
  const to=fx.opts.to,from=fx.opts.from;if(!to||!from)return;
  const A=P.pt(from),B=P.pt(to),E=fx.size*P.scale,L=Math.hypot(B.x-A.x,B.y-A.y),ang=Math.atan2(B.y-A.y,B.x-A.x),ux=Math.cos(ang),uy=Math.sin(ang);
  const n=Math.max(3,Math.round(L/(E*.55))),seglen=L/n,width=E*.8;
  const her=P.pt(centerOf(fx.token)),along=clamp(((her.x-A.x)*ux+(her.y-A.y)*uy)/Math.max(1,L));
  const bits=fx.mem.bits??=bitsOf(fx.token,P,A).map(b=>({x:b.x-A.x,y:b.y-A.y}));
  f.save();f.translate(A.x,A.y);f.rotate(ang);
  for(let i=0;i<n;i++){
    const lay=easeOut(seg(t,.2+i/n*1.2,.5+i/n*1.2)),fold=easeIn(seg(t,3.9+i/n*1.4,4.35+i/n*1.4));
    const open=lay*(1-fold);if(open<=.01)continue;
    const x=i*seglen,lit=Math.exp(-(((i+.5)/n-along)**2)/.012)*(t>BRIDGE_MOVE_AT?1:0),w=width*open,h=seglen*.9;
    f.save();f.translate(x+seglen/2,0);
    const g=f.createLinearGradient(0,-w/2,0,w/2);g.addColorStop(0,rgba(MAG,.12*open));g.addColorStop(.5,rgba(SOFT,(.28+.3*lit)*open));g.addColorStop(1,rgba(MAG,.12*open));
    f.fillStyle=g;f.beginPath();const c=h*.18;f.moveTo(-h/2+c,-w/2);f.lineTo(h/2-c,-w/2);f.lineTo(h/2,0);f.lineTo(h/2-c,w/2);f.lineTo(-h/2+c,w/2);f.lineTo(-h/2,0);f.closePath();f.fill();
    f.globalCompositeOperation='lighter';f.strokeStyle=rgba(HOT,(.55+.45*lit)*open);f.lineWidth=Math.max(.8,E*.012);f.stroke();
    f.strokeStyle=rgba(GOLD,.45*open);f.lineWidth=Math.max(.6,E*.006);f.beginPath();f.moveTo(-h/2+c,0);f.lineTo(h/2-c,0);f.stroke();
    f.restore();
  }
  f.globalCompositeOperation='lighter';
  // light runs along both edges once the span is complete
  const run=seg(t,1.4,4.2);if(run>0&&run<1&&!reduced)for(const side of [-1,1]){const x=((run*1.7)%1)*L;glow(f,x,side*width*.5,E*.18,.8*Math.sin(Math.PI*run));}
  f.restore();
  f.save();f.globalCompositeOperation='lighter';
  // the bits lay the panels, then fold them up and fly home
  bits.forEach((b,i)=>{const k=seg(t,.15+i*.08,1.45),back=seg(t,5.2,6.2),u=easeInOut(k);
    const from2={x:A.x+b.x,y:A.y+b.y},side=(i%2?1:-1)*width*.5,end={x:B.x-uy*side,y:B.y+ux*side};
    let x=lerp(from2.x,end.x,u),y=lerp(from2.y,end.y,u);
    if(t>3.9){const fu=easeInOut(seg(t,3.9,5.3));x=lerp(lerp(A.x,B.x,fu)-uy*side,her.x+b.x*.6,back);y=lerp(lerp(A.y,B.y,fu)+ux*side,her.y+b.y*.6,back);}
    // (the bits stay docked: these are motes of light they cast, tethered while they lay the span)
    const lit=easeIn(Math.min(1,k*2.5))*(1-seg(back,.6,1));
    if(!reduced){const cast=Math.sin(Math.PI*seg(t,.15+i*.08,.6+i*.08))+Math.sin(Math.PI*seg(t,5.8,6.3));if(cast>.01)glint(f,from2.x,from2.y,Math.max(1.2,E*.028),.75*cast);
      if(k>0&&k<1)thread(f,from2,{x,y},{alpha:.3*(1-k*.5),w:Math.max(.8,E*.01),bend:.1,color:GOLD});}
    star(f,x,y,Math.max(1.2,E*.04),lit);});
  f.restore();
}

/* ================================ Lifeline ================================ */
/** A filament from her heart to every dying ally, pulsing like a heartbeat
 * (faster at higher Dying), until they stabilise: then one bright pulse and
 * it fades. Drawn on its own layer; every screen works it out for itself. */
const lifelineLayer=createOverlay('ff-lifeline-layer');
let lifeTicker=null,lifeCheck=0,lifeDraw=0;const lines=new Map();
const dyingValue=actor=>{try{const v=Number(actor?.system?.attributes?.dying?.value);if(v>0)return v;
  const c=actor?.items?.find?.(i=>i.type==='condition'&&i.slug==='dying');return c?Number(c.system?.value?.value)||1:0;}catch{return 0;}};
function lifelineSources(){
  return (canvas.tokens?.placeables??[]).filter(t=>t.document?.getFlag?.(ID,'flight')?.enabled&&t.visible!==false&&!t.document.hidden&&
    t.document.getFlag?.(ID,'flightFeel')?.lifeline!==false&&dyingValue(t.actor)<=0);
}
function scanLifelines(now){
  const sources=lifelineSources(),friendly=globalThis.CONST?.TOKEN_DISPOSITIONS?.FRIENDLY??1,seen=new Set();
  if(sources.length)for(const t of canvas.tokens?.placeables??[]){
    const d=dyingValue(t.actor);if(d<=0||t.document?.hidden||t.visible===false||!(t.document?.disposition===friendly||t.actor?.hasPlayerOwner))continue;
    const src=sources.find(s=>s!==t);if(!src)continue;
    const key=`${src.id}>${t.id}`;seen.add(key);
    const line=lines.get(key)??{src,dst:t,born:now,ending:null};line.src=src;line.dst=t;line.dying=d;line.ending=null;lines.set(key,line);
  }
  for(const [key,line] of lines)if(!seen.has(key)&&line.ending==null)line.ending=now;
}
const PULSE_SPAN=1.12;// a pulse takes 1/PULSE_SPAN of a beat to run from her to them (was 1/1.6)
const beatRate=line=>1.05+.35*Math.min(3,line.dying??1);
function pulseInFlight(now){
  for(const line of lines.values()){if(line.ending!=null)return true;const t=(now-line.born)/1000;if(t<.9)return true;
    for(const off of [0,.16]){const p=((t*beatRate(line))-off)%1;if(p>=0&&p*PULSE_SPAN<1)return true;}}
  return false;
}
function lifeFrame(){
  try{
    if(!canvas?.ready){stopLifelines();return;}
    // full frame rate while a heartbeat travels along a thread; 30 fps when only the steady thread shows
    const now=performance.now();if(now-lifeDraw<32&&!pulseInFlight(now))return;lifeDraw=now;if(now-lifeCheck>500){lifeCheck=now;scanLifelines(now);}
    const L=lifelineLayer.ensure();if(!L){stopLifelines();return;}
    const f=L.el.getContext('2d');f.setTransform(1,0,0,1,0,0);f.clearRect(0,0,L.el.width,L.el.height);
    if(!lines.size){stopLifelines();return;}
    const wt=canvas.stage.worldTransform,sx=L.r.width/(canvas.app.renderer.screen.width||L.r.width),k=sx*L.dpr,P=p=>{const q=wt.apply(p);return {x:q.x*k,y:q.y*k};},scale=wt.a*k;
    let reduced=false;try{reduced=!!game.settings.get(ID,'reducedMotion');}catch{}
    for(const [key,line] of [...lines]){
      if(line.src.destroyed||line.dst.destroyed){lines.delete(key);continue;}
      const t=(now-line.born)/1000,end=line.ending!=null?(now-line.ending)/1000:0;if(end>1.4){lines.delete(key);continue;}
      const A=P(centerOf(line.src)),B=P(centerOf(line.dst)),E=Math.max(line.src.w,line.src.h)*scale;
      const grow=easeOut(seg(t,0,.9)),fade=1-seg(end,.5,1.4),a=grow*fade;
      const rate=beatRate(line),beat=(t*rate)%1,thump=Math.exp(-((beat-.08)**2)/.003)+.7*Math.exp(-((beat-.24)**2)/.003);
      f.save();f.globalCompositeOperation='lighter';
      const sag=Math.min(E*1.2,Math.hypot(B.x-A.x,B.y-A.y)*.12),bend=sag/Math.max(1,Math.hypot(B.x-A.x,B.y-A.y));
      const pt=thread(f,A,B,{alpha:(.45+.35*thump)*a,w:Math.max(1,E*.018),bend,upto:grow});
      // the heartbeat travelling from her to them
      if(!reduced&&pt&&grow>=1)for(const [off,size] of [[0,1],[.16,.7]]){const p=((t*rate)-off)%1;if(p<0)continue;const q=pt(Math.min(1,p*PULSE_SPAN));if(p*PULSE_SPAN<1){glow(f,q[0],q[1],E*.28*size,1.1*a);glow(f,q[0],q[1],E*.1*size,1*a,HOT);}}
      glow(f,A.x,A.y,E*.3,(.25+.3*thump)*a);glow(f,B.x,B.y,E*.4,(.3+.5*thump)*a,SOFT);
      if(line.ending!=null&&end<.5){glow(f,B.x,B.y,E*(.5+1.5*seg(end,0,.5)),(1-seg(end,0,.5))*1.2);}
      f.restore();
    }
  }catch(e){console.warn('Yvaelle’s Toolbox | lifeline',e);stopLifelines();}
}
function stopLifelines(){if(lifeTicker){canvas.app?.ticker?.remove(lifeTicker);lifeTicker=null;}lifelineLayer.release();lines.clear();}
/** Look for dying allies now (called on actor and token changes); the layer
 * runs only while at least one lifeline is drawn. */
export function checkLifelines(){
  if(!canvas?.ready)return;
  scanLifelines(performance.now());
  if(lines.size&&!lifeTicker){lifeTicker=()=>lifeFrame();canvas.app.ticker.add(lifeTicker);}
}
export function registerLifelines(){
  let queued=false;
  const poke=()=>{if(queued)return;queued=true;setTimeout(()=>{queued=false;try{checkLifelines();}catch(e){console.warn('Yvaelle’s Toolbox | lifeline',e);}},120);};
  for(const hook of ['updateActor','createItem','deleteItem','updateItem','updateToken','createToken','deleteToken','canvasReady'])Hooks.on(hook,poke);
  Hooks.on('canvasTearDown',stopLifelines);
}
