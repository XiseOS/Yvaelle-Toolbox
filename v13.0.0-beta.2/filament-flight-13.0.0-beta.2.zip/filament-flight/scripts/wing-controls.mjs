import {bitExpressionPatch,bitExpressionSettings} from './bit-expression.mjs?v=13.0.0-beta.2';
import {COMPACT_BIT_PROGRAMS} from './compact-bit-formations.mjs?v=13.0.0-beta.2';
import {BIT_CORE_STATES} from './bit-core-states.mjs?v=13.0.0-beta.2';
/** Small, optional schema-2 preferences. Null restores the world default. */
export const POSE_MOTION_FIELDS=Object.freeze({enabled:'boolean',style:['flow','classic'],duration:[0,10000],followThrough:[0,1]});
export const HARDWARE_DESIGNS=Object.freeze({vanes:'Prism spindle',shielded:'Aegis lens',spine:'Filament needle'});
export const HARDWARE_SWITCHES=Object.freeze({metalHighlights:'gemMetalHighlights',shutters:'gemShutters',suspendedCore:'gemSuspendedCore',mechanicalResponse:'gemMechanicalResponse',repairFocus:'gemRepairFocus',assetStates:'gemAssetStates',coreDepth:'gemCoreDepth'});
// Relative artwork coordinates, independent of wing pose and wingbeat. One
// position unit is 100 rig units; these are not scene/grid distances.
export const BIT_STATIONS=Object.freeze({
  leftUpper:Object.freeze({label:'Upper left',x:-1.88,y:-1.51}),rightUpper:Object.freeze({label:'Upper right',x:1.88,y:-1.51}),
  leftLower:Object.freeze({label:'Lower left',x:-1.74,y:1.99}),rightLower:Object.freeze({label:'Lower right',x:1.74,y:1.99})
});
export const BIT_POSITION_FIELDS=Object.freeze(Object.fromEntries(Object.keys(BIT_STATIONS).flatMap(key=>[[`${key}X`,Object.freeze([-2.4,2.4])],[`${key}Y`,Object.freeze([-2.1,2.4])]])));
export const GEM_MOTION_FIELDS=Object.freeze({expressionEnabled:'boolean',expressionStrength:[0,1],expressionModes:'expression-map',stationMotion:'boolean',stationMotionStrength:[0,1],enabled:'boolean',count:[1,4],soloProgram:Object.keys(COMPACT_BIT_PROGRAMS),soloRadius:[.4,1.6],personality:[0,1],intent:['off','composed','attentive'],program:['poised','orbital','seraph'],coreState:Object.keys(BIT_CORE_STATES),passiveEffects:'boolean',fieldStyle:['contour','weave','aegis'],style:['choreographed','classic','hidden'],appearance:['physical','energy'],size:[0.5,1.5],animated:'boolean',glow:'boolean',glowStrength:[0,1],strength:[0,1],speed:[0.25,2],reactive:'boolean',tethers:'boolean',
  placement:['free','follow'],...BIT_POSITION_FIELDS,design:Object.keys(HARDWARE_DESIGNS),artwork:['resonant','vector'],glowMode:['core','field'],highlightStrength:[0,1],coreDepthStrength:[0,1],...Object.fromEntries(Object.keys(HARDWARE_SWITCHES).map(key=>[key,'boolean']))});

function patch(input,fields,label) {
  if(!input||typeof input!=='object'||Array.isArray(input))throw new Error(`${label} must be an object.`);
  const out={};
  for(const [key,value] of Object.entries(input)) {
    const rule=fields[key];if(!Object.hasOwn(fields,key))throw new Error(`Unknown ${label.toLowerCase()} option: ${key}.`);
    if(value===null){out[key]=null;continue;}
    if(rule==='expression-map'){out[key]=bitExpressionPatch({expressionModes:value}).expressionModes;continue;}
    if(rule==='boolean') {if(typeof value!=='boolean')throw new Error(`${key} must be true, false or null.`);}
    else if(typeof rule[0]==='string') {if(!rule.includes(value))throw new Error(`Invalid ${label.toLowerCase()} ${key}.`);}
    else if(!Number.isFinite(value)||value<rule[0]||value>rule[1]||key==='count'&&!Number.isInteger(value))throw new Error(`${key} must be ${rule[0]}–${rule[1]} or null.`);
    out[key]=value;
  }
  return out;
}
export const poseMotionPatch=input=>patch(input,POSE_MOTION_FIELDS,'Pose motion');
// Retired artwork identifiers remain valid macro / saved-look inputs. Normalize
// before enum validation so old token and prototype flags cannot become unreadable.
export function gemMotionPatch(input){
  if(input&&typeof input==='object'&&!Array.isArray(input)){
    input={...input};
    if(input.design==='original'){input.design='vanes';input.artwork='resonant';}
    if(input.artwork==='animated')input.artwork='resonant';
  }
  return patch(input,GEM_MOTION_FIELDS,'Gem motion');
}

export function resolvePoseMotion(data,cfg) {
  const p=data.poseMotion??{};
  return {enabled:cfg.poseTransitions!==false&&p.enabled!==false&&!cfg.reduced,
    style:p.style??cfg.poseTransitionStyle??'flow',duration:p.duration??cfg.poseDuration??650,
    followThrough:p.followThrough??cfg.poseFollowThrough??0.6};
}
export function resolveGemMotion(data,cfg) {
  const p=data.gemMotion??{};
  let style=p.style??(cfg.gemChoreography!==false?'choreographed':'classic');
  if(cfg.controlGems===false||p.enabled===false)style='hidden';
  else if(cfg.gemChoreography===false&&style==='choreographed')style='classic';
  const supported=cfg.wingRenderer!=='atlas';
  const appearance=p.appearance??cfg.gemAppearance??'physical',size=p.size??cfg.gemSize??1;
  const animated=!cfg.reduced&&cfg.gemAnimation!==false&&p.animated!==false;
  // The bit's body art follows its appearance, not whether it is home: a bit
  // recalled or sent off (style hidden at home) keeps the look it showed.
  const body=supported&&appearance==='physical';
  const hardware=body&&style!=='hidden',savedDesign=p.design??cfg.gemDesign??'vanes',design=savedDesign==='original'?'vanes':savedDesign;
  const savedArtwork=p.artwork??cfg.gemArtwork??'resonant',artwork=savedArtwork==='animated'||savedDesign==='original'?'resonant':savedArtwork;
  const expression=bitExpressionSettings({...p,expressionEnabled:cfg.bitExpressionEnabled!==false&&p.expressionEnabled!==false,expressionStrength:p.expressionStrength??cfg.bitExpressionStrength??.45});
  return {...expression,stationMotion:animated&&p.stationMotion!==false&&cfg.gemStationMotion!==false,stationMotionStrength:p.stationMotionStrength??cfg.gemStationMotionStrength??.55,enabled:style!=='hidden',count:p.count??4,soloProgram:p.soloProgram??'halo',soloRadius:p.soloRadius??1,personality:p.personality??cfg.bitPersonality??.35,intent:p.intent??cfg.bitIntent??'composed',placement:p.placement??cfg.gemPlacement??'free',
    ...Object.fromEntries(Object.entries(BIT_STATIONS).flatMap(([key,station])=>[[`${key}X`,p[`${key}X`]??station.x],[`${key}Y`,p[`${key}Y`]??station.y]])),
    program:p.program??cfg.gemProgram??'poised',coreState:p.coreState??cfg.gemCoreState??'idle',passiveEffects:p.passiveEffects??cfg.bitPassiveEffects??true,fieldStyle:p.fieldStyle??cfg.gemFieldStyle??'contour',style:supported?style:'classic',appearance:supported?appearance:'energy',size:supported?size:1,supported,strength:p.strength??cfg.gemMotionStrength??0.75,speed:p.speed??cfg.gemAnimationSpeed??1,
    reactive:cfg.gemConditionResponse!==false&&p.reactive!==false,
    // Accepted in old flags/API patches, but guide strings are retired in both appearances.
    tethers:false,animated,
    glow:supported&&appearance==='physical'&&style!=='hidden'&&cfg.gemStabilizingGlow!==false&&p.glow!==false,
    glowStrength:p.glowStrength??cfg.gemGlowStrength??0.4,
    glowMode:p.glowMode??cfg.gemGlowMode??'core',
    design,highlightStrength:p.highlightStrength??cfg.gemHighlightStrength??.45,
    artwork:!body?'vector':artwork==='vector'?'vector':'resonant',
    ...Object.fromEntries(Object.entries(HARDWARE_SWITCHES).map(([key,setting])=>[key,body&&cfg[setting]!==false&&p[key]!==false])),
    // This new appearance is opt-in. A token can enable it while the world
    // default is off, or explicitly keep its original jewel when that is on.
    coreDepth:body&&artwork!=='vector'&&(p.coreDepth??cfg.gemCoreDepth??false)===true,
    coreDepthStrength:p.coreDepthStrength??cfg.gemCoreDepthStrength??.35,
    // Classic gems are baked into the atlas. Hiding them also needs the rig.
    rigRequired:supported&&((p.count??4)!==4||(p.placement??cfg.gemPlacement??'free')==='free'||style!=='classic'||appearance==='physical'||size!==1||cfg.gemAnimation===false||p.animated===false)};
}
