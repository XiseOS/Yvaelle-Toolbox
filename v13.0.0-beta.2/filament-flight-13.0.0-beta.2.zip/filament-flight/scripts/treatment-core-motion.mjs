import {sampleCoreState} from './bit-core-states.mjs?v=13.0.0-beta.2';

export const TREATMENT_CORE_CHANNELS=Object.freeze(['encase','open','charge','guard','settle','scan','brace','align','rest','conduct']);
const unit=n=>Math.max(0,Math.min(1,Number(n)||0));
const smooth=n=>{n=unit(n);return n*n*(3-2*n);};
/** Serialized core activities carry bounded channel weights, never geometry or
 * another transform. Captures and target states use the same native mechanism. */
export function treatmentCoreChannels(activity){
  const state=sampleCoreState({activity});
  return Object.fromEntries(TREATMENT_CORE_CHANNELS.map(key=>[key,unit(state[key])]));
}
export function treatmentCoreVelocity(before,after,seconds){
  const a=treatmentCoreChannels(before),b=treatmentCoreChannels(after),span=Math.max(.000001,seconds);
  return Object.fromEntries(TREATMENT_CORE_CHANNELS.map(key=>[key,Math.max(-1000,Math.min(1000,(b[key]-a[key])/span))]));
}
/** Blend absolute mechanism channels. An interrupted procedure can retain its
 * incoming channel velocity, then gently damp it inside the existing range. */
export function transitionTreatmentCore(from,to,progress,{velocity=null,duration=.24}={}){
  if(!from)return to;if(progress<=0&&!velocity)return from;if(progress>=1)return to;
  const p=unit(progress),q=smooth(p),a=treatmentCoreChannels(from),b=treatmentCoreChannels(to),values={};
  for(const key of TREATMENT_CORE_CHANNELS){
    let value=a[key]+(b[key]-a[key])*q;
    if(velocity){
      const tangent=(Number(velocity[key])||0)*duration,bound=Math.max(.001,Math.min(.2,tangent>0?1-a[key]:a[key]));
      const damp=Math.max(0,Math.abs(tangent)/bound-1);
      value+=p*(1-p)**2*tangent*Math.exp(-p*damp);
    }
    values[key]=unit(value);
  }
  return {state:p<.5?from.state:to.state,amount:1,progress:unit((from.progress??0)+((to.progress??0)-(from.progress??0))*q),coreChannels:values};
}
