/** Production Foundry V14 route adapter, invoked ONLY when submitting a bit
 * command. Public APIs: CanvasVisibility.testVisibility and the movement
 * PointSourcePolygon.testCollision backend. The saved result contains visible
 * route points only; no wall ids, hidden endpoints or scene-query callbacks. */
import {planBitRoute,compileBitRoute} from './v8-motion.mjs?v=13.0.0-beta.2';
const finitePoint=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const TAU=Math.PI*2;
const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,Number.isFinite(n)?n:lo));

/** Wall placeables whose bounds may meet rectangle `b` ({x,y,width,height}).
 * Uses the native wall quadtree when present, otherwise an uncapped walk that
 * keeps only walls whose coordinate bounds overlap. No wall count limit: a
 * large imported map still finds every nearby wall. */
export function sceneWallsNear(canvas,b){
  const tree=canvas?.walls?.quadtree;
  if(typeof tree?.getObjects==='function'){
    const R=globalThis.PIXI?.Rectangle;
    const rect=typeof R==='function'?new R(b.x,b.y,b.width,b.height):{x:b.x,y:b.y,width:b.width,height:b.height,left:b.x,top:b.y,right:b.x+b.width,bottom:b.y+b.height};
    try{const found=tree.getObjects(rect);if(found&&typeof found[Symbol.iterator]==='function')return found;}catch{/* Walk below. */}
  }
  const walls=canvas?.walls?.placeables??canvas?.scene?.walls?.contents??[],out=[],right=b.x+b.width,bottom=b.y+b.height;
  for(const wall of walls){
    const c=wall?.coords??(wall?.document??wall)?.c;if(!Array.isArray(c)||c.length!==4)continue;
    if(Math.max(c[0],c[2])<b.x||Math.min(c[0],c[2])>right||Math.max(c[1],c[3])<b.y||Math.min(c[1],c[3])>bottom)continue;
    out.push(wall);
  }
  return out;
}

/** Use the current viewer's V14 visibility, never explored fog or GM vision on
 * behalf of a player. GM can route within the active level without token vision.
 * Native movement collision retains wall directions, doors and level geometry.
 */
export function sceneBitRouteAdapter({canvas=globalThis.canvas,user=globalThis.game?.user,source,clearance,backend=globalThis.CONFIG?.Canvas?.polygonBackends?.move??globalThis.foundry?.canvas?.geometry?.ClockwiseSweepPolygon}={}){
  if(!canvas?.ready||typeof backend?.testCollision!=='function'||!user?.isGM&&typeof canvas.visibility?.testVisibility!=='function')
    throw new Error('Visible obstacle routing is unavailable on this canvas.');
  const token=source?.object??source,doc=source?.document??source,elevation=Number.isFinite(doc?.elevation)?doc.elevation:0,level=canvas.level;
  const sceneId=doc?.parent?.id??token?.document?.parent?.id;
  if(sceneId&&canvas.scene?.id&&sceneId!==canvas.scene.id)throw new Error('Choose an instrument in the viewed scene.');
  const grid=canvas.dimensions?.size??canvas.scene?.grid?.size??100;
  const width=token?.w??(Number.isFinite(doc?.width)?doc.width*grid:100),height=token?.h??(Number.isFinite(doc?.height)?doc.height*grid:100);
  const sourceCenter=finitePoint(token?.center)?{x:token.center.x,y:token.center.y}:finitePoint(doc)?{x:doc.x+width/2,y:doc.y+height/2}:null;
  clearance=clamp(clearance??Math.max(width,height)*.075,3,40);
  const bounds=canvas.dimensions?.sceneRect;
  const elevated=p=>({x:p.x,y:p.y,elevation});
  const visible=p=>{
    if(!finitePoint(p)||bounds?.contains&&bounds.contains(p.x,p.y)!==true)return false;
    if(user?.isGM)return true;
    try{return canvas.visibility.testVisibility(elevated(p),{tolerance:0,object:null})===true;}catch{return false;}
  };
  let nativeChecks=0;
  const blocked=(a,b)=>{
    if(!finitePoint(a)||!finitePoint(b))return true;
    nativeChecks++;
    try{return backend.testCollision(elevated(a),elevated(b),{type:'move',mode:'any',...(level?{level}:{})})!==false;}catch{return true;}
  };
  const waypoints=[];
  const collectWaypoints=(from,to)=>{
    if(!finitePoint(from)||!finitePoint(to))return waypoints;
    // Any endpoint within the detour ellipse lies within maxDistance of `from`
    // or `to`, so only walls meeting that padded box can contribute. The
    // levels field is still checked: a quadtree may hold other levels' walls.
    const maxDistance=Math.max(clearance*4,distance(from,to)*1.7),near=[],endpoints=[];
    const box={x:Math.min(from.x,to.x)-maxDistance,y:Math.min(from.y,to.y)-maxDistance,width:Math.abs(from.x-to.x)+maxDistance*2,height:Math.abs(from.y-to.y)+maxDistance*2};
    for(const wall of sceneWallsNear(canvas,box)){
      const d=wall.document??wall;
      if(d.hidden&&!user?.isGM||d.isOpen===true||wall.isOpen===true||!(d.move>0))continue;
      if(level?.id&&d.levels?.size>0&&typeof d.levels.has==='function'&&!d.levels.has(level.id))continue;
      const c=wall.coords??d.c;if(!Array.isArray(c)||c.length!==4||!c.every(Number.isFinite))continue;
      for(const endpoint of [{x:c[0],y:c[1]},{x:c[2],y:c[3]}]){
        const detour=distance(from,endpoint)+distance(endpoint,to);if(detour<=maxDistance*2)endpoints.push({point:endpoint,detour});
      }
    }
    endpoints.sort((a,b)=>a.detour-b.detour);
    // Native visibility is tested at only the nearest thirty-two potential
    // corners, even on a scene with thousands of authored walls.
    for(const {point:endpoint} of endpoints.slice(0,32)){
        // Visibility is checked before retaining any geometry for planning.
        // The small inward offsets help endpoints exactly on a LOS edge while
        // still never using an unseen corner as a route hint.
        const probes=[endpoint,...Array.from({length:8},(_,n)=>({x:endpoint.x+Math.cos(n/8*TAU)*clearance,y:endpoint.y+Math.sin(n/8*TAU)*clearance}))];
        const shown=probes.slice(1).filter(visible);if(!shown.length)continue;
        for(const p of shown){
          const detour=distance(from,p)+distance(p,to);if(detour<=maxDistance*2)near.push({point:p,detour});
        }
    }
    near.sort((a,b)=>a.detour-b.detour);
    // Forty-eight candidates are bounded before the pure planner chooses its
    // nearest eighteen. Deduplication avoids wasting checks at joined walls.
    for(const {point} of near){if(waypoints.length>=48)break;if(!waypoints.some(p=>distance(p,point)<clearance*.45))waypoints.push(point);}
    return waypoints;
  };
  return {blocked,visible,collectWaypoints,clearance,sourceCenter,get nativeChecks(){return nativeChecks;}};
}

/** Return a compact, serializable, checked path. Confirmation uses the same
 * helper again so a closed door or changed visibility invalidates a rehearsal.
 * Direct visible travel costs one movement collision check and no wall walk.
 */
export function planSceneBitRoute(from,to,options={}){
  const adapter=sceneBitRouteAdapter(options);
  from=from??adapter.sourceCenter;
  // Cheap native direct check precedes collecting even one wall endpoint.
  const direct=planBitRoute(from,to,{blocked:adapter.blocked,visible:adapter.visible,maxCandidates:0,maxChecks:1});
  if(!direct.blocked)return {...compileBitRoute(direct.points),sceneId:options.canvas?.scene?.id??globalThis.canvas?.scene?.id??null};
  const planned=planBitRoute(from,to,{blocked:adapter.blocked,visible:adapter.visible,waypoints:adapter.collectWaypoints(from,to),maxCandidates:18,maxChecks:160,maxDetour:3});
  if(planned.blocked)throw new Error(planned.reason??'The instrument route is blocked.');
  const compiled=compileBitRoute(planned.points,{blocked:adapter.blocked,visible:adapter.visible,rounding:adapter.clearance});
  return {...compiled,sceneId:options.canvas?.scene?.id??globalThis.canvas?.scene?.id??null};
}
