import {choreographedGems} from './gem-choreography.mjs?v=13.0.0-beta.2';
import {compactBitTransform,compactWingHandoff} from './compact-bit-renderer.mjs?v=13.0.0-beta.2';
import {wingTransform} from './trails.mjs?v=13.0.0-beta.2';
import {applyBitCondition} from './condition-response.mjs?v=13.0.0-beta.2';
import {bitLanternInFrame} from './bit-lantern.mjs?v=13.0.0-beta.2';
import {wingWarp} from './wing-rig.mjs?v=13.0.0-beta.2';
import {wingPhase} from './wing-phase.mjs?v=13.0.0-beta.2';
import {groundLanternMounting} from './lantern-model.mjs?v=13.0.0-beta.2';

export const LANTERN_EMITTER_STATIONS=Object.freeze(['leftUpper','rightUpper','leftLower','rightLower']);
const unit=n=>Math.max(0,Math.min(1,Number.isFinite(n)?n:0));
const finite=(value,fallback=0)=>Number.isFinite(value)?value:fallback;
const bitKey=id=>`${id.startsWith('left')?'left':'right'}-gem-${id.endsWith('Lower')?1:0}`;
const stationMask=id=>id==='leftUpper'?1:id==='rightUpper'?2:id==='leftLower'?4:id==='rightLower'?8:0;

/** Current physical ownership wins over a retained renderer frame. Returning
 * and medical instruments acquire a light only after their home handoff. */
export function lanternHomeStations(snapshot){
  if(!snapshot?.gems?.enabled||snapshot.gems.supported===false||snapshot.bitProjectedEffect||
    snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse?.mix>.001)return [];
  // Membership is only four fixed stations. Read every live reservation and
  // assignment, but avoid creating three Sets and intermediate event arrays
  // each time native illumination needs those same physical owners.
  let eligible=0,excluded=0;
  for(const id of snapshot.bitHomeStations??LANTERN_EMITTER_STATIONS)eligible|=stationMask(id);
  for(const id of snapshot.bitActionAssignments?.hidden??[])excluded|=stationMask(id);
  for(const event of snapshot.bitReservationEvents??[]){
    if(event.status!=='running'&&event.status!=='returning')continue;
    const bits=event.bits??[];
    // Array.flatMap retained a scalar/string as one item in the former route.
    if(Array.isArray(bits)){for(const id of bits)excluded|=stationMask(id);}
    else excluded|=stationMask(bits);
  }
  const support=snapshot.bitActionAssignments?.support??{},returning=snapshot.bitActionAssignments?.returnSupport??{},result=[];
  for(let index=0;index<LANTERN_EMITTER_STATIONS.length;index++){
    const id=LANTERN_EMITTER_STATIONS[index],mask=1<<index;
    if((eligible&mask)&&!(excluded&mask)&&!support[id]&&!returning[id]&&
      (!snapshot.bitAllocationState||snapshot.bitAllocationState.bits?.[id]?.location==='home')&&
      unit(snapshot.bitCount?.values?.[index]??(index<(snapshot.gems.count??4)?1:0))>.00001)result.push(id);
  }
  return result;
}

/** Rig points use the same 600-unit frame and 15-unit origin correction as
 * BitRenderer.place and the compact placement route. An optical offset belongs
 * to the painted hardware; airborne sources use that displayed bit origin. */
export function lanternEmitterPosition(point,transform,{hardware={},placement=null}={}){
  const c=Math.cos(transform.angle),s=Math.sin(transform.angle),
    x=finite(point?.[0])/600*transform.width,y=(finite(point?.[1])-15)/600*transform.height;
  const center=placement??{x:transform.x+x*c-y*s,y:transform.y+x*s+y*c,angle:transform.angle};
  const offset=hardware.lantern?.origin??[0,0],h=finite(hardware.angle),hc=Math.cos(h),hs=Math.sin(h),
    lx=(finite(offset[0])*hc-finite(offset[1])*hs)*finite(hardware.scale,1),
    ly=(finite(offset[0])*hs+finite(offset[1])*hc)*finite(hardware.scale,1),
    scaleX=finite(center.scale,transform.width/600),scaleY=finite(center.scaleY,transform.height/600),
    a=finite(center.angle,transform.angle),ac=Math.cos(a),as=Math.sin(a);
  return {x:center.x+lx*scaleX*ac-ly*scaleY*as,y:center.y+lx*scaleX*as+ly*scaleY*ac};
}

export function lanternEmitterSnapshot(snapshot,localEffects){
  if(localEffects!==false)return snapshot;
  // A client hiding the artwork still needs shared native illumination. The
  // prepared allocation keeps the actual home memberships even when the local
  // rendering gate reports no visible deployment.
  if(!snapshot.bitAllocationState)return snapshot;
  const wings=!!(snapshot.enabled||snapshot.transition?.active),home=snapshot.bitHomeStations??[],
    flying=!!(snapshot.airborne||snapshot.transition?.active&&((snapshot.transition.fromFlight??0)>0||(snapshot.transition.toFlight??0)>0));
  return {...snapshot,compactBits:!wings,bitDeployment:home.length?1:0,
    rendering:{...snapshot.rendering,wingsActive:wings,flightActive:flying},
    gems:{...snapshot.gems,enabled:home.length>0}};
}

function emitterFrame(token,snapshot,motion,compact){
  const source=motion?.source??token.mesh??{x:token.center?.x??0,y:token.center?.y??0,rotation:0};
  if(compact)return compactBitTransform(source,token,snapshot,motion);
  const state=motion??{token,source,opts:snapshot.options??{},blend:snapshot.rendering?.blend??(snapshot.enabled?1:0),bank:0,lift:0};
  // A prepared headless/native-light snapshot can precede the visual state.
  return wingTransform({...state,token,source,bank:finite(state.bank),lift:finite(state.lift),
    opts:{wingScale:3.5,offsetX:0,offsetY:0,...snapshot.options,...state.opts}},snapshot);
}

function sampleHomeParts(snapshot,now,compact,handoff,motion,cfg){
  const blend=motion?.blend??snapshot.bitWingBlend??snapshot.rendering?.blend??1,
    free=snapshot.gems.style==='choreographed'||snapshot.gems.style==='classic'&&snapshot.gems.rigRequired,
    stabilizerDeployment=compact||snapshot.formation?.explicit||!free||cfg.reduced||blend>.995?1:blend<.002?0:blend;
  const flight={...snapshot,compactBits:compact,
    formation:compact?{growth:1,fold:0,presence:1}:snapshot.formation,
    bitDeployment:(snapshot.bitDeployment??1)*(compact&&handoff.active?handoff.compact:1),
    wingBitHandoff:compact?undefined:handoff.active?handoff.wing:snapshot.wingBitHandoff,
    stabilizerDeployment,gems:compact?{...snapshot.gems,style:'choreographed',appearance:'physical'}:snapshot.gems};
  const visual={...snapshot.visual?.profile,...(compact?{animated:snapshot.gems.animated}:{}),time:compact?now/1000:snapshot.visual?.profile?.time??now/1000},parts=new Map(),
    weights=snapshot.poseAnimation?.weights??[1,0,0,0,0,0,0,0,0,0,0];
  if(!compact&&!free){
    // Classic attached jewels may be baked into the wing atlas. Their two
    // centers per side need four point deformations, never a contour/painter
    // pass or physical-bit replacement merely to supply native illumination.
    const phase=wingPhase(motion??{opts:snapshot.options},snapshot,cfg,now),formed=unit(((snapshot.formation?.growth??1)-.85)/.15),strength=formed*formed*(3-2*formed);
    for(const side of [-1,1]){
      const warp=wingWarp(weights,phase,side,visual,flight);
      for(const [index,x,y,scale]of [[0,220,-159,.8],[1,205,202,.64]]){
        const id=`${side<0?'left':'right'}${index?'Lower':'Upper'}`,point=warp([x,y,.92]);
        parts.set(id,{id:`gem-${index}`,points:[point],strength,hardware:{angle:side*(.38+.07*Math.sin(phase)),scale:scale*finite(snapshot.gems.size,1),lantern:{origin:[0,0]}}});
      }
    }
    return parts;
  }
  const choreographyFrame={};
  for(const side of [-1,1]){
    const controllers=choreographedGems(weights,0,visual,flight,side,choreographyFrame);
    for(const part of controllers){
      if(part.hardware){parts.set(`${side<0?'left':'right'}${part.id==='gem-0'?'Upper':'Lower'}`,part);continue;}
      if(!part.id.startsWith('gem-core-'))continue;
      // Energy companions have a painted core rather than a physical mesh.
      // Read its actual single core point from the same four controllers, and
      // retain the housing center only for reversible mounting captures.
      const index=Number(part.id.slice('gem-core-'.length)),ring=controllers.find(p=>p.id===`sigil-${index}`),points=ring?.points?.slice(0,40);
      if(!points?.length)continue;
      const center=points.reduce((sum,p)=>[sum[0]+p[0]/points.length,sum[1]+p[1]/points.length,sum[2]+finite(p[2])/points.length],[0,0,0]),
        dx=points[0][0]-center[0],dy=points[0][1]-center[1];
      const stationIndex=(side<0?0:1)+(index?2:0),deployment=unit(flight.bitDeployment??1)*unit(flight.wingBitHandoff??1)*unit(flight.bitCount?.values?.[stationIndex]??1),
        presence=unit((flight.formation?.growth??1)/.2),visible=unit(deployment/.16),strength=presence*presence*(3-2*presence)*visible*visible*(3-2*visible);
      parts.set(`${side<0?'left':'right'}${index?'Lower':'Upper'}`,{...part,strength,energyController:true,capturePoint:center,
        hardware:{angle:Math.atan2(dy,dx)+index*Math.PI,scale:Math.hypot(dx,dy)/15,lantern:{origin:[0,0]}}});
    }
  }
  return parts;
}

/** Read at most four emitter centers. Visible clients reuse the exact placed
 * bit frame (including worker frames); no wing geometry or texture is built.
 * Offscreen and cosmetic-disabled clients sample only the four controllers.
 * There is deliberately no token-center light fallback. */
export function lanternEmitters(token,snapshot,manager,now,{localEffects=true,capture=false,forceSample=false,...cfg}={}){
  if(!token||token.destroyed||token.document?.hidden||!capture&&!snapshot?.lantern?.active&&!(snapshot?.lantern?.weight>.0001))return [];
  const current=lanternEmitterSnapshot(snapshot,localEffects),ids=lanternHomeStations(current);
  if(!ids.length||unit(current.bitDeployment??1)<=.00001)return [];
  const motion=manager?.states?.get(token),withBlend={...current,bitWingBlend:motion?.blend??current.bitWingBlend},
    handoff=compactWingHandoff(withBlend,motion?.blend),compact=handoff.active?handoff.compact>0:withBlend.compactBits,
    transform=emitterFrame(token,withBlend,motion,compact),flight=bitLanternInFrame(withBlend,transform.angle),
    renderer=compact?motion?.renderer?.compact:motion?.renderer?.rig,home=renderer?.bits;
  let sampled;
  return ids.flatMap(id=>{
    const record=home?.records?.get(bitKey(id)),bit=record?.frame?.bit,placed=home?.placements?.get(id),
      shown=record&&Object.values(record.meshes??{}).some(mesh=>mesh?.visible&&mesh.alpha>0),
      cached=!forceSample&&localEffects!==false&&!motion?.dormant&&shown&&Number.isFinite(placed?.x)&&Number.isFinite(placed?.y)&&bit?.part?.hardware;
    let part,position,strength,route;
    if(cached){
      part=bit.part;position=lanternEmitterPosition(part.points[0],transform,{hardware:part.hardware,placement:placed});
      strength=unit(finite(bit.front)+finite(bit.rear)||part.strength);route=`${compact?'compact':'wing'}-cached`;
    }else{
      sampled??=sampleHomeParts(flight,now,compact,handoff,motion,cfg);part=sampled.get(id);
      if(!part||part.strength<=.00001)return [];
      const raw={...lanternEmitterPosition(part.points[0],transform),angle:transform.angle,z:part.points[0][2],scale:transform.width/600,scaleY:transform.height/600},
        adjusted=part.energyController?raw:applyBitCondition(raw,current.conditionResponse,{id,now,scale:Math.max(token.w??0,token.h??0),
        source:motion?.source??token.mesh??token.center,positionLocked:!compact&&part.hardware.stabilization?.positionLocked===true});
      adjusted.angle=Number.isFinite(adjusted.angleAbsolute)?adjusted.angleAbsolute:transform.angle+(adjusted.angleDelta??0);
      position=lanternEmitterPosition(part.points[0],transform,{hardware:part.hardware,placement:adjusted});
      strength=unit(part.strength);route=`${compact?'compact':'wing'}-sampled`;
    }
    // Compact formation brightness is authored energy, not deployment or a
    // route handoff. It must not create a second token projector or rebuild
    // native polygons on every expressive frame. Health remains in the live
    // bit mechanisms and light appearance; optical presence follows the same
    // count, deployment and delayed shoulder emergence as the solid housing.
    if(compact&&groundLanternMounting(current,{groundStyle:'stabilizers'})&&
      (current.lantern?.groundStyle==='stabilizers'||current.lantern?.mountingTransition?.compact===true)){
      const index=LANTERN_EMITTER_STATIONS.indexOf(id),delay=current.bitTransition?.active?index*.045:0,
        deployment=unit(current.bitDeployment??1)*unit(handoff.active?handoff.compact:1),
        visible=unit((unit((deployment-delay)/(1-delay))*unit(current.bitCount?.values?.[index]??1))/.16);
      strength=visible*visible*(3-2*visible);
    }
    if(!Number.isFinite(position.x)||!Number.isFinite(position.y)||strength<=.00001)return [];
    let pose;
    if(capture){
      const nominal=Math.max(.0001,(compact?.76:id.endsWith('Lower')?.64:.8)*finite(current.gems.size,1));
      const capturedPoint=part.capturePoint??part.points[0];
      pose={station:id,x:capturedPoint[0],y:capturedPoint[1],z:finite(capturedPoint[2]),
        angle:finite(part.hardware.angle),scale:finite(part.hardware.scale,1)/nominal};
      if(cached){
        // Placement can be fresher than a capped worker/artwork frame. Invert
        // the actual visible center into this rig, rather than capturing the
        // retained geometry's earlier position at a mounting handoff.
        const dx=placed.x-transform.x,dy=placed.y-transform.y,c=Math.cos(transform.angle),s=Math.sin(transform.angle);
        pose.x=(dx*c+dy*s)*600/transform.width;pose.y=(-dx*s+dy*c)*600/transform.height+15;
        pose.z=finite(placed.z,pose.z);pose.angle+=finite(placed.angle,transform.angle)-transform.angle;
        pose.scale*=finite(placed.scale,transform.width/600)/(transform.width/600);
      }
    }
    return [{id,x:position.x,y:position.y,angle:finite(current.lantern?.angle),strength,route,...(pose?{pose}:{})}];
  });
}

/** Capture the displayed home controllers once at a lantern toggle.
 * Stored free bits use their ordinary deployment controllers as the source.
 * No per-frame geometry sampling or document writes are introduced. */
export function captureLanternFormation(token,snapshot,manager,now,home,{localEffects=true,actual=false,...cfg}={}){
  const capture={...snapshot,compactBits:!snapshot.rendering?.wingsActive,bitHomeStations:home,
    ...(!actual?{bitDeployment:1,bitCount:{...snapshot.bitCount,values:LANTERN_EMITTER_STATIONS.map(id=>home.includes(id)?1:0)},gems:{...snapshot.gems,enabled:true}}:{})},
    poses=lanternEmitters(token,capture,manager,now,{...cfg,localEffects,capture:true}),
    center=token.document?.getLightOrigin?.({x:token.x,y:token.y})??token.center;
  const order=poses.sort((a,b)=>Math.atan2(a.y-center.y,a.x-center.x)-Math.atan2(b.y-center.y,b.x-center.x)).map(p=>p.id);
  return {formationCapture:poses.map(p=>p.pose),formationOrder:[...order,...LANTERN_EMITTER_STATIONS.filter(id=>!order.includes(id))]};
}
