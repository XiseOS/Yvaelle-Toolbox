import {treatmentScanOperation,sampleTreatmentOperations} from './treatment-choreography.mjs?v=13.0.0-beta.2';
import {scanArtworkAim} from './v8-scan-art.mjs?v=13.0.0-beta.2';
import {selectScanMethod} from './v84-scan-methods.mjs?v=13.0.0-beta.2';
import {V7_MEDICAL_WORK_SPECS} from './v7-medical-work.mjs?v=13.0.0-beta.2';

/** One bounded medical reading, on the treatment's existing 1.6-second clock.
 * The normal creature scanner supplies its optics and native alpha mask; this
 * adapter supplies one complementary reading per real instrument. It never
 * starts a utility task, reserves another bit, or compiles an examination route.
 * Coordinates stay in the same patient-diameter frame as treatment artwork. */
const unit=n=>Math.max(0,Math.min(1,n)),smooth=n=>{n=unit(n);return n*n*(3-2*n);};
const mix=(a,b,q)=>a+(b-a)*q;
const point=(a,b,q)=>({x:mix(a.x,b.x,q),y:mix(a.y,b.y,q),z:mix(a.z??.3,b.z??.3,q)});
const rotate=(p,a)=>{const c=Math.cos(a),s=Math.sin(a);return {x:p.x*c-p.y*s,y:p.x*s+p.y*c};};
const IDS=['leftUpper','rightUpper','leftLower','rightLower'];
const finite=(n,fallback)=>Number.isFinite(n)?n:fallback;
const classicTangents=new Map();
function classicEntranceTangents(style,count){
  const key=`${style}:${count}`;let result=classicTangents.get(key);if(result)return result;
  const a=sampleTreatmentOperations(style,count,0),b=sampleTreatmentOperations(style,count,.000001);
  result=a.operations.map((op,i)=>Object.fromEntries(['position','workPoint'].map(kind=>[kind,Object.fromEntries(['x','y','z'].map(axis=>[axis,(b.operations[i][kind][axis]-op[kind][axis])*1000000]))])));
  classicTangents.set(key,result);return result;
}

/** Rectangles meet exactly: the union is the entire displayed portrait. */
export function medicalDiagnosticRegions(width,height,count=1){
  const n=Math.max(1,Math.min(4,Math.round(count)||1)),left=-width/2,top=-height/2;
  if(n===1)return [{x:left,y:top,width,height}];
  if(n===2)return [0,1].map(i=>({x:left+i*width/2,y:top,width:width/2,height}));
  const quadrants=[{x:left,y:top,width:width/2,height:height/2},{x:0,y:top,width:width/2,height:height/2}];
  return n===3?[...quadrants,{x:left,y:0,width,height:height/2}]:[...quadrants,...quadrants.map(p=>({...p,y:0}))];
}

export function sampleMedicalDiagnostic(event,context,operations,scanProgress,{v7=false,variant=0,animated=true,v9MedicalCraft=false}={}){
  const spec=event.treatment,worldSize=(context.targetSize??context.size)*spec.scale;
  const portrait=context.medicalScan?.portrait??{center:context.target,width:context.targetWidth??context.targetSize??context.size,height:context.targetHeight??context.targetSize??context.size,rotation:context.targetRotation??0};
  const angle=finite(portrait.rotation,0),center=rotate({x:(portrait.center.x-context.target.x)/worldSize*100,y:(portrait.center.y-context.target.y)/worldSize*100},-angle);
  const width=Math.max(.01,finite(portrait.width,worldSize))/worldSize*100,height=Math.max(.01,finite(portrait.height,worldSize))/worldSize*100;
  const regions=medicalDiagnosticRegions(width,height,event.bits.length),progress=unit(scanProgress),reading=unit(progress/.74),handoff=smooth((progress-.70)/.30);
  const method=selectScanMethod({scanMethods:context.medicalScan?.methods},'creature',0,event.id);
  const channels=[],points=[],adapted=operations.operations.map((op,i)=>{
    const id=event.bits[i],physicalIndex=v7&&V7_MEDICAL_WORK_SPECS[spec.style]&&IDS.includes(id)?IDS.indexOf(id):i;
    const initial=treatmentScanOperation(spec.style,physicalIndex,event.bits.length,0,{v7,variant,roleIndex:i,reducedMotion:!animated});
    const region={...regions[i],x:regions[i].x+center.x,y:regions[i].y+center.y};
    const portraitCenter=rotate(center,angle),halfX=(Math.abs(Math.cos(angle))*width+Math.abs(Math.sin(angle))*height)/200;
    // Hold a real viewpoint while the optical reading traverses its region.
    // Each station stays on its original treatment side, so setup cannot send
    // left and right instruments through the patient to exchange places.
    const side=initial.position.x<0?-1:1,lane=i<2?-.32:.32;
    const station={x:portraitCenter.x/100+side*Math.max(Math.abs(initial.position.x-portraitCenter.x/100),halfX+.20),
      y:portraitCenter.y/100+(event.bits.length>2?lane:0)*height/100,z:initial.position.z};
    const position=animated?point(station,op.position,handoff):op.position,source=rotate({x:position.x*100,y:position.y*100},-angle);
    const channel={id,mode:'creatureScan',scanStage:'close',source,focus:{x:region.x+region.width/2,y:region.y+region.height/2},
      method,axis:'y',direction:1,progress:animated?reading:.52,static:!animated,regionBounds:region,
      frameRotation:angle,plane:'front',strength:spec.intensity*(animated?1-smooth((progress-.66)/.12):.43),visitIndex:i,exposureVariant:0,clipRadius:0,
      // Full-portrait surface coordinates join at regional boundaries. The
      // real source ray, regional focus and clip remain instrument-specific.
      // Crossed lasers retain their deliberately source-specific profiles.
      ...(v9MedicalCraft&&method!=='laserTriangulation'?{patternBounds:{x:center.x-width/2,y:center.y-height/2,width,height},patternSeed:0,patternGroup:'medical-diagnostic'}:{})};
    const optical=rotate(scanArtworkAim(channel),angle),workPoint=animated?point({x:optical.x/100,y:optical.y/100,z:.3},op.workPoint,handoff):op.workPoint;
    if(animated&&!v7&&progress>.70){
      const u=unit((progress-.70)/.30),gain=u*u*(u-1)*.48,tangent=classicEntranceTangents(spec.style,event.bits.length)[i];
      for(const [kind,value]of [['position',position],['workPoint',workPoint]])for(const axis of ['x','y','z'])value[axis]+=tangent[kind][axis]*gain;
      channel.source=rotate({x:position.x*100,y:position.y*100},-angle);
    }
    if(channel.strength>.001)channels.push(channel);
    for(const x of [region.x,region.x+region.width])for(const y of [region.y,region.y+region.height])points.push(rotate({x,y},angle));
    points.push({x:position.x*100,y:position.y*100});
    const cue=progress<.12?{phase:'settle',progress:progress/.12}:progress<.66?{phase:'measure',progress:(progress-.12)/.54}:{phase:'release',progress:unit((progress-.66)/.12)};
    const examination={...cue,viewIndex:i,weight:animated?1-smooth((progress-.78)/.20):0,turn:0};
    const lens=.47*smooth(progress/.12)*(1-smooth((progress-.66)/.16));
    const tool=!animated?op.tool??{type:'lens',amount:.47,progress:.52}:v7?{type:'lens',amount:lens,progress:reading}:progress<.84?{type:'lens',amount:lens,progress:reading}:
      {type:['precision','suture','microloom'].includes(spec.style)?'probe':'plate',amount:.45*smooth((progress-.84)/.16),progress:0};
    return {...op,position,workPoint,tool,core:{...op.core,examination},role:'Diagnostic reading',stage:'scan'};
  });
  const left=Math.min(...points.map(p=>p.x))-18,top=Math.min(...points.map(p=>p.y))-18,right=Math.max(...points.map(p=>p.x))+18,bottom=Math.max(...points.map(p=>p.y))+18;
  // Quiet lock-on hold from the end of the reading through the handover, so
  // the patient never sits bare before the treatment art arrives.
  const lockAmount=animated?smooth((progress-.42)/.24)*(1-smooth((progress-.82)/.18)):0;
  const medicalLock=lockAmount>.004?{x:center.x,y:center.y,width:width*.96,height:height*.96,angle,amount:lockAmount*spec.intensity,settle:smooth((progress-.42)/.30)}:null;
  return {operations:{...operations,operations:adapted},handoff,effect:channels.length||medicalLock?{effect:'v8-scan',mode:'creatureScan',medicalDiagnostic:true,channels,
    color:'#ff62df',strength:1,detail:spec.detail,animated,...(medicalLock?{medicalLock}:{}),bounds:{x:left,y:top,width:right-left,height:bottom-top}}:null};
}
