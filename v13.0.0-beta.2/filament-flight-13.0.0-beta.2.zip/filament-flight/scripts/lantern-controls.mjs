import {ID,configuration} from './config.mjs?v=13.0.0-beta.2';
import {current} from './renderer.mjs?v=13.0.0-beta.2';
import {hudCommand,hudPreferences,hudFlightAction,eligibleTokens,resolvePinnedCharacterToken} from './hud-model.mjs?v=13.0.0-beta.2';

const preferences=()=>{try{return hudPreferences(game.settings.get(ID,'hudPreferences'));}catch{return hudPreferences();}};
const pinnedToken=(prefs=preferences())=>resolvePinnedCharacterToken(prefs,eligibleTokens());

/** Keybindings are opt-in. Never capture text entry, repeat presses or another scene. */
export function lanternControlToken(context={},prefs=preferences()) {
  const event=context.event??context.originalEvent;
  const active=globalThis.document?.activeElement,target=event?.target;
  const typing=node=>!!(node?.isContentEditable||node?.closest?.('input,textarea,select,[contenteditable="true"],[role="textbox"]'));
  if(context.repeat||context.isRepeat||event?.repeat||typing(active)||typing(target)||!globalThis.canvas?.ready)return null;
  const token=pinnedToken(prefs);
  return token&&current(token)?token:null;
}

export function registerLanternControls(manager,api) {
  if(!game.keybindings?.register)return false;
  let aimHeld=null;
  // HUD preferences change locally before their asynchronous settings write.
  // Honor the visible pin immediately, including while that save is queued.
  const controlPreferences=()=>hudPreferences(manager.bits?.service?.hud?.prefs??manager.hud?.prefs??preferences());
  const resolvePinned=()=>pinnedToken(controlPreferences());
  const controlToken=context=>lanternControlToken(context,controlPreferences());
  const invoke=(action,token=null)=>{try{
    const service=manager.bits?.service;
    const result=token&&service?.withControlGuard?service.withControlGuard(token,()=>resolvePinned()===token,action):action();
    void Promise.resolve(result).catch(error=>manager.report?.(error));
  }catch(error){manager.report?.(error);}};
  const ownsAim=held=>held?.session?manager.lantern?.aim===held.session:
    !!held&&api.isLanternAiming?.(held.token)!==false;
  const stopHeld=()=>{
    const held=aimHeld;aimHeld=null;
    if(!ownsAim(held))return false;
    if(resolvePinned()!==held.token&&manager.lantern?.endAim)invoke(()=>manager.lantern.endAim({persist:false}));
    else invoke(()=>api.stopLanternAim(),held.token);
    return true;
  };
  // Scene teardown does not depend on the HUD being open or a keyup arriving.
  globalThis.Hooks?.on?.('canvasTearDown',stopHeld);
  const definitions={
    toggleLantern:{name:'Toggle bit lantern',hint:'Turn the HUD’s pinned character’s directional bit lantern on or off. Requires their owned token in the current scene. No key is assigned by default.',onDown:context=>{
      const token=controlToken(context);if(!token)return false;
      invoke(()=>api.toggleLantern(token),token);return true;
    }},
    aimLantern:{name:'Aim bit lantern (hold)',hint:'While held, aim the HUD’s pinned character’s enabled lantern toward your mouse without rotating or moving their token. Release to keep the last direction. No key is assigned by default.',onDown:context=>{
      const token=controlToken(context);if(!token)return false;
      if(aimHeld&&!ownsAim(aimHeld))aimHeld=null;
      if(aimHeld||api.isLanternAiming?.(token)===true||!api.getState(token)?.lantern?.enabled)return false;
      try{
        if(api.startLanternAim(token)!==true)return false;
        aimHeld={token,session:manager.lantern?.aim??null};
        manager.lantern?.guardAim?.(token,()=>resolvePinned()===token);
        return true;
      }catch(error){manager.report?.(error);return false;}
    },onUp:stopHeld},
    takeoffLand:{name:'Take off / Land',hint:'Use the HUD’s takeoff and landing preferences for its pinned character in the current scene. Shift while landing keeps deployed bits. No key is assigned by default.',onDown:context=>{
      const token=controlToken(context);if(!token||hudFlightAction(api.getState(token)).disabled)return false;
      invoke(()=>hudCommand(api,token,'flightToggle',{keepBits:context?.event?.shiftKey===true},controlPreferences(),configuration()),token);return true;
    }},
    climb:{name:'Fly higher',hint:'While the HUD’s pinned character is flying, raise her token’s elevation 5 ft (Shift: 15 ft); her flying look follows it. With Takeoff sets her elevation on, this is her flying height. No key is assigned by default.',onDown:context=>{
      const token=controlToken(context);if(!token||!api.altitude)return false;
      invoke(()=>api.altitude(token,{by:context?.event?.shiftKey?15:5}),token);return true;
    }},
    descend:{name:'Fly lower',hint:'While the HUD’s pinned character is flying, lower her token’s elevation 5 ft (Shift: 15 ft). No key is assigned by default.',onDown:context=>{
      const token=controlToken(context);if(!token||!api.altitude)return false;
      invoke(()=>api.altitude(token,{by:context?.event?.shiftKey?-15:-5}),token);return true;
    }},
    wingShield:{name:'Wing shield',hint:'Raise or lower the HUD’s pinned character’s wing shield: her wings sweep forward into a hardlight barrier. No key is assigned by default.',onDown:context=>{
      const token=controlToken(context);if(!token||!api.wingShield)return false;
      invoke(()=>api.wingShield(token),token);return true;
    }},
    toggleBits:{name:'Summon / Retract bits',hint:'Use the HUD’s all-bit Summon / Retract button for its pinned character in the current scene. No key is assigned by default.',onDown:context=>{
      const token=controlToken(context);if(!token||!api.bits?.toggleAll)return false;
      const state=api.getState(token),cfg=configuration(),response=state?.conditionResponse;
      if(!state||cfg.controlGems===false||cfg.wingRenderer==='atlas'||state.rendering?.fallback||
        response?.bits&&['falling','fallen'].includes(response.collapse?.phase))return false;
      invoke(()=>hudCommand(api,token,'toggleBits',null,controlPreferences(),cfg),token);return true;
    }}
  };
  for(const [key,definition] of Object.entries(definitions))game.keybindings.register(ID,key,{...definition,editable:[],uneditable:[],restricted:false,repeat:false});
  return true;
}
