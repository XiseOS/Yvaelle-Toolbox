import {ID, configuration, runtimeConfiguration} from './config.mjs?v=13.0.0-beta.2';
import {normalizeFlag} from './state.mjs?v=13.0.0-beta.2';
import {options} from './motion.mjs?v=13.0.0-beta.2';
import {readHealth} from './conditions.mjs?v=13.0.0-beta.2';
import {resolveEffectStyle} from './effect-styles.mjs?v=13.0.0-beta.2';
import {variant,styleLabel} from './effect-catalog.mjs?v=13.0.0-beta.2';
import {COMPACT_BIT_PROGRAMS} from './compact-bit-formations.mjs?v=13.0.0-beta.2';
import {TOKEN_EFFECT_IDS} from './token-effects.mjs?v=13.0.0-beta.2';
import {BIT_STATIONS,BIT_POSITION_FIELDS} from './wing-controls.mjs?v=13.0.0-beta.2';
import {portraitState,PORTRAIT_SETS} from './hud-portrait.mjs?v=13.0.0-beta.2';
import {ART_SIZE,STRANDS,wingWarp} from './wing-rig.mjs?v=13.0.0-beta.2';
import {timed} from './keepsake/timings.mjs?v=13.0.0-beta.2';
import {weightsFor} from './poses.mjs?v=13.0.0-beta.2';

// The renderer consumes 100 rig units per saved coordinate. Keep the SVG,
// handles and pointer deltas in the same coordinate system.
export const BIT_PLACEMENT_MAP=Object.freeze({x:-2.6,y:-2.3,width:5.2,height:4.9,units:100});
export function bitMapPercent(position) {
  const map=BIT_PLACEMENT_MAP;
  return {x:(position.x-map.x)/map.width*100,y:(position.y-map.y)/map.height*100};
}
const placementGuides=new Map(),guideStrands=STRANDS.filter(s=>/^(edge|rib)-/.test(s.id));
/** A cached rest-pose guide uses the renderer's actual contours, never a render. */
export function bitPlacementGuide(model,{contours=true}={}) {
  const request=model.state?.requested??{},pose=model.state?.effective?.pose??request.pose??'neutral';
  const shape={pose};
  const key=JSON.stringify(shape);let paths=contours?placementGuides.get(key):[];
  if(contours&&!paths){
    const weights=weightsFor(pose);
    paths=Object.freeze([-1,1].flatMap(side=>guideStrands.map(strand=>{
      const warp=wingWarp(weights,0,side,null,{},strand.id);
      return strand.points.map((point,i)=>{const [x,y]=warp(point);return `${i?'L':'M'}${x.toFixed(2)} ${y.toFixed(2)}`;}).join('');
    })));
    if(placementGuides.size>=32)placementGuides.delete(placementGuides.keys().next().value);
    placementGuides.set(key,paths);
  }
  const appearance=options(model.baseAppearance??model.state?.options??model.cfg?.defaults),scale=ART_SIZE/appearance.wingScale;
  const width=model.token?.w??1,height=model.token?.h??1,size=Math.max(width,height)||1;
  // BitRenderer.place uses (rigY - 15). Invert its steady transform to put
  // the token silhouette at the correct size and configured wing offset.
  return {paths,token:{x:-appearance.offsetX*scale,y:15-appearance.offsetY*scale,rx:width/size*scale/2,ry:height/size*scale/2}};
}

export function bitPosition(request,station) {
  const home=BIT_STATIONS[station];if(!home)throw new Error('Unknown bit position.');
  return {x:request?.[`${station}X`]??home.x,y:request?.[`${station}Y`]??home.y};
}
export function bitPlacementPatch(station,x,y) {
  if(!Object.hasOwn(BIT_STATIONS,station)||![x,y].every(Number.isFinite))throw new Error('Invalid bit position.');
  const constrain=(v,axis)=>{const [min,max]=BIT_POSITION_FIELDS[`${station}${axis}`];return Math.round(Math.max(min,Math.min(max,v))*100)/100;};
  return {placement:'free',[`${station}X`]:constrain(x,'X'),[`${station}Y`]:constrain(y,'Y')};
}
export function mirrorBitPatch(request,station) {
  const {x,y}=bitPosition(request,station),partner=station.startsWith('left')?station.replace('left','right'):station.replace('right','left');
  return bitPlacementPatch(partner,-x,y);
}

export const HUD_TABS=['effects','home','settings'];
export const HUD_TAB_LABELS={home:'Home',flight:'Flight',bits:'Bits',effects:'Effects',settings:'Settings'};

export const FLOAT_STYLES=Object.freeze({
  hover:{label:'Hover',hint:'Each downstroke lifts her: a steady rise and fall.',glyph:'hover'},
  breath:{label:'Breathing',hint:'A slow inhale lifts her and opens the wings; the exhale lets her sink.',glyph:'breath'},
  drift:{label:'Drift',hint:'A dreamy wandering drift; she leans the way she drifts.',glyph:'drift'},
  orbit:{label:'Orbit',hint:'She circles a small orbit, banking around it.',glyph:'orbit'},
  levitate:{label:'Rise and settle',hint:'She rises on quick strokes, hangs with her wings held, then settles with a little bounce.',glyph:'levitate'},
  pendulum:{label:'Pendulum',hint:'She swings side to side in a shallow arc, tilting with the swing.',glyph:'pendulum'},
  heartbeat:{label:'Heartbeat',hint:'Two quick wingbeats lift her, then a long, slow sink.',glyph:'heartbeat'},
  wander:{label:'Wander',hint:'She lazily drifts about her spot, leaning into each little repositioning.',glyph:'drift'},
  still:{label:'Still',hint:'Rock steady at her height; only the wings move.',glyph:'still'}
});
export const DISPLAY_PRESETS=Object.freeze({
  balanced:{label:'Balanced',settings:{rigQuality:'medium',bitQuality:'high',rigFPS:60,poseFPS:60}},
  detail:{label:'High detail',settings:{rigQuality:'high',bitQuality:'high',rigFPS:60,poseFPS:60}},
  light:{label:'Lighter load',settings:{rigQuality:'low',bitQuality:'medium',rigFPS:30,poseFPS:30}}
});
export const POSE_HINTS={neutral:'An open resting silhouette.',forwardGuard:'Curve both wings forward to protect the token.',cocoon:'Close the wings around the token.',leftForwardWrap:'Bring the left wing forward.',rightForwardWrap:'Bring the right wing forward.',aggressiveFlare:'A tall, pointed, outward lance silhouette.',raised:'Lift the wings into a crown.',trailing:'Sweep the wings back behind movement.',collapsed:'Fold into a compact resting shape.',drooped:'Let the filaments sag and fall.',crossed:'Cross the wing tips defensively in front.'};

export const MODE_LABELS={grounded:'Grounded',takeoff:'Taking off',hover:'Hover',fly:'Fly',fast:'Fast Flight',glide:'Glide',surge:'Surge',sentinel:'Sentinel',wraith:'Wraith',landing:'Landing'};
export const FLIGHT_MODES=Object.freeze({
  grounded:{hint:'Wings out, feet down',icon:'shoe-prints'},
  hover:{hint:'Low, small quick flutter · eases in, soft settle',icon:'feather'},
  fly:{hint:'Figure-eight drift · slides a little past, flares to a stop',icon:'wind'},
  fast:{hint:'Higher, hard lean, swept wings, trails · slides well past',icon:'bolt'},
  glide:{hint:'Rides high, flat spread wings, rare beats · a long coast',icon:'dove'},
  surge:{hint:'Taut, coiled wings · bursts ahead, springy braking flare',icon:'meteor'},
  sentinel:{hint:'Wings half-raised, slow strokes, bits posted · stops short',icon:'shield-halved'},
  wraith:{hint:'Thin phasing wings, sinuous drift · an echo carries on',icon:'ghost'}
});
export const BIT_PROGRAMS=Object.freeze({poised:'Poised constellation',orbital:'Orbital gyroscope',seraph:'Seraph cadence'});
export const FIELD_STYLES=Object.freeze({contour:'Contour currents',weave:'Filament weave',aegis:'Aegis lattice'});
/** Deployment is independent from wing visibility; old flags retain their wing-linked default. */
export function hudBitsDeployed(state) {
  if(!state)return false;
  return !!(state.bitDeploymentTarget??((state.gems?.requestedEnabled??(state.requested?.gemMotion?.enabled!==false&&state.requested?.gemMotion?.style!=='hidden'))&&!!(state.enabled||state.bitsDeployed||state.requested?.bitsDeployed)));
}
/** Include task-held bits even when their saved assignment is retracted. */
export function hudBitCommandState(model) {
  const bits=hudBitAllocations(model),tasks=model.bitTasks??{},working=b=>b.actionKind&&b.actionKind!=='escort'&& !['idle','queued'].includes(b.activity);
  const own=[model.token?.id,model.token?.document?.id,model.token?.document?.uuid];
  const out=tasks.outBits??bits.filter(b=>b.location!=='retracted'||working(b)).map(b=>b.id);
  const remote=tasks.remoteBits??bits.filter(b=>!['home','retracted'].includes(b.location)||working(b)&&b.actionTarget&&!own.includes(b.actionTarget)).map(b=>b.id);
  const count=tasks.preferredCount??model.state?.requested?.gemMotion?.count??model.state?.bitCount?.count??4;
  const selected=[...new Set(model.dispatchSelectedBits??[])].filter(id=>Object.hasOwn(BIT_STATIONS,id));
  const selectedOut=selected.filter(id=>out.includes(id)),selectedRemote=selected.filter(id=>remote.includes(id));
  if(selected.length){
    const recalling=selectedOut.length>0,label=recalling?`Retract ${selectedOut.length}`:`Summon ${selected.length}`;
    const hint=`${recalling?`Return and retract only ${selectedOut.length} selected deployed ${selectedOut.length===1?'bit':'bits'}`:`Summon only ${selected.length} selected ${selected.length===1?'bit':'bits'}`}. Shift-click: recall ${selectedRemote.length} selected remote ${selectedRemote.length===1?'bit':'bits'} to the owner, keeping them deployed.`;
    return {out,remote,count,selected,selectedOut,selectedRemote,label,hint,selectionSummary:`${selected.length} selected`,scoped:true};
  }
  return {out,remote,count,selected:[],selectedOut:[],selectedRemote:[],scoped:false,selectionSummary:'',label:out.length?'Retract all':`Summon ${count}`,hint:out.length?'Retract all four bits into Ellie, including remote and working bits. Shift-click: gather remote bits around Ellie.':'Summon the selected number around Ellie. Shift-click: gather remote bits around Ellie.'};
}
export function hudFlightAction(state) {
  const transition=state?.transition;
  if(transition?.active&&!transition.wingsOnly)return {action:'flightToggle',label:transition.kind==='landing'?'Landing…':'Taking off…',icon:transition.kind==='landing'?'arrow-down':'arrow-up',disabled:true};
  const airborne=state?.airborne??(!!state?.enabled&&state?.effective?.mode!=='grounded');
  return {action:'flightToggle',label:airborne?'Land':'Take off',icon:airborne?'arrow-down':'arrow-up',disabled:false};
}
export const POSE_LABELS={neutral:'Neutral / open',forwardGuard:'Forward guard',cocoon:'Cocoon',leftForwardWrap:'Left wrap',rightForwardWrap:'Right wrap',aggressiveFlare:'Lance flare',raised:'Raised / crown',trailing:'Trailing',collapsed:'Collapsed',drooped:'Drooped / damaged',crossed:'Crossed guard'};
export const CONDITION_LABELS={auto:'Automatic (HP)',normal:'Normal',damaged:'Damaged',unstable:'Unstable',glitching:'Glitching',overdrive:'Overdrive',suppressed:'Suppressed',collapsed:'Collapsed'};
export const CONDITION_HINTS={auto:'Wings react to HP, damage and recovery.',normal:'Stable, flowing filaments.',
  damaged:'Broken strands with loose ends and drifting sparks.',unstable:'Uneven pulses and asymmetric bends through each wing.',
  glitching:'Sections jump out of alignment, leave echoes and reform.',overdrive:'Wider sweeps, travelling surges and arcs between the ribs.',
  suppressed:'Partially folded wings with a slow inward current.',collapsed:'Folded remnants shed small falling fragments.'};
export const ORIGINAL_CONDITION_HINTS={normal:'Original stable, flowing filaments.',
  damaged:'Original subtle damage: small breaks, sag and dimming.',unstable:'Original gentle asymmetric motion and uneven pulses.',
  glitching:'Original filament phasing and dimming, without displaced glitch slices.',overdrive:'Original brighter energy and subtle motion, without added arcs or surges.',
  suppressed:'Original subdued, dim filaments, without the inward current.',collapsed:'Original collapsed, faint wings, without falling fragment accents.'};
export function conditionHint(model,condition) {
  if(condition==='auto')return CONDITION_HINTS.auto;
  const style=resolveEffectStyle(model.state?.requested??{},condition,model.cfg);
  if(style==='none')return 'Extra condition artwork is off. Flight, wing pose and HP state still apply.';
  return variant('condition',condition,style)?.description??(style==='original'?ORIGINAL_CONDITION_HINTS:CONDITION_HINTS)[condition]??'';
}
export const HUD_GROUPS=Object.freeze({materials:'Appearance',animations:'Animation',medical:'Medical animations',groups:'Selected bit group',conditions:'Condition reactions',flight:'Flight & floating',wings:'Wing poses',stabilizers:'Bits & stabilization',effects:'Effects & conditions',looks:'Looks & presets',audio:'Sound',tuning:'Fit, light & performance',appearance:'Portrait'});
/** A Settings route is local navigation, never a token mutation. */
export const HUD_SETTINGS_LABELS=Object.freeze({'v7-experience':'Appearance','v7-appearance':'Wing & bit materials','v7-animation':'Wing gestures & transitions','v7-formations':'Bit formation library','v7-medical':'Medical animation library','group-tuning':'Formation movement','group-core':'Inside the core','group-effect':'Projected energy','bits-placement':'Wing-side placement','bits-glow':'Stabilizing glow','bits-idle':'Wing-side bit movement','bits-motion':'Bit scale & motion','bits-material':'Material & energy detail','bits-mechanics':'Core state reactions','bits-expression':'Expressive instruments','bits-expression-mapping':'Situation responses','bits-lantern':'Bit lantern','bits-quality':'Rendering detail','float-tuning':'Float tuning','flight-timing':'Takeoff & landing','pose-motion':'Pose movement','pose-timing':'Temporary pose & shared timing','effect-appearance':'Condition animations','reaction-appearance':'Reaction animations','effect-intensity':'Intensity & HP response','effect-timing':'Quick effect timing & strength','condition-reactions':'Condition reactions','tuning-browser':'Browser comfort','quality-profiles':'Quality profiles','quality-local':'My view','quality-observer':'Other players’ view','tuning-light':'Scene illumination','tuning-light-appearance':'Shared light appearance','tuning-lantern-artwork':'Lantern artwork','tuning-appearance':'Wing fit & visibility','tuning-diagnostic':'Performance diagnostic','tuning-tools':'Maintenance','tuning-settings':'Module defaults',...HUD_GROUPS});
export const HUD_SIMPLE_SECTIONS=Object.freeze(['materials','animations','medical','v7-appearance','v7-animation','v7-formations','v7-medical','looks','audio','appearance','bits-lantern','bits-glow','bits-motion','bits-expression','quality-profiles','quality-local','quality-observer','tuning-appearance','tuning-light','tuning-browser']);
export function hudSettingsRoute(id='') {
  const aliases={v7:'materials','v7-experience':'materials','simple-materials':'materials','simple-animations':'animations','simple-medical':'medical','simple-tuning':'tuning-appearance','simple-stabilizers':'bits-glow','simple-quality':'quality-profiles','simple-audio':'audio','simple-looks':'looks','simple-appearance':'appearance','simple-lighting':'tuning-light','bits-compact':'group-tuning','flight-pose-gallery':'pose-motion','quality-legacy':'quality-profiles','control:gemMotion:soloRadius':'group-tuning','control:gemMotion:personality':'group-tuning'};
  id=aliases[id]??id;
  if(id==='bits-travel')return {id,group:'stabilizers',level:'simple',title:'Instrument travel'};
  if(id==='medical-work-posture')return {id,group:'medical',level:'simple',title:'Working posture'};
  if(id==='structure-shape'||/^control:(?:wingForm|structure(?:Pose|Size|:|$))/.test(id))return null;
  const control=id.startsWith('control:')?id.slice(8):null;
  if(id.startsWith('v7-')||control?.startsWith('v7:')){
    const key=control?.slice(3),group=id==='v7-animation'||['wingAnimations','seamlessActions','transitionVariants','wingGesture'].includes(key)?'animations':id==='v7-formations'||key==='formations'?'stabilizers':id==='v7-medical'||key==='medkit'?'medical':'materials';
    return {id,group,level:'simple',title:HUD_SETTINGS_LABELS[id]??(key?.replace(/([A-Z])/g,' $1')??HUD_GROUPS[group])};
  }
  if(id==='tuning-light-appearance'||['lightAppearance','lightVisualReactions'].includes(control))return {id,group:'tuning',level:'advanced',title:control==='lightVisualReactions'?'Light appearance follows wing reactions':control==='lightAppearance'?'Light appearance':'Shared light appearance'};
  if(id==='tuning-lantern-artwork'||control==='lanternArtwork')return {id,group:'tuning',level:'advanced',title:'Lantern artwork'};
  if(control?.startsWith('lantern:'))return {id,group:'stabilizers',level:['edgeStyle','edgeSoftness','groundStyle'].includes(control.slice(8))?'advanced':'simple',title:({groundStyle:'Ground lantern style',edgeStyle:'Light edge style',edgeSoftness:'Edge softness',width:'Beam angle',bright:'Bright distance',dim:'Dim distance',intensity:'Light brightness',beam:'Visible beam strength',angle:'Lantern direction'})[control.slice(8)]??'Bit lantern'};
  const group=Object.hasOwn(HUD_GROUPS,id)?id:id.startsWith('group-')?'groups':id==='condition-reactions'?'conditions':id.startsWith('bits-')?'stabilizers':id.startsWith('float-')||id==='flight-timing'?'flight':id.startsWith('pose-')?'wings':id.startsWith('effect-')||id.startsWith('reaction-')?'effects':id.startsWith('tuning-')||id.startsWith('quality-')||id==='diagnostic-breakdown'?'tuning':control?control.startsWith('audio:')?'audio':control.startsWith('gemMotion:')?'stabilizers':control.startsWith('poseMotion:')?'wings':['modeIdleStrength','hoverHeight','bobHeight','floatSpeed','floatSway','tiltDegrees'].includes(control)?'flight':['wingScale','opacity','offsetX','offsetY','wingSpeed','lightIntensity','lightBright','lightDim'].includes(control)?'tuning':'effects':null;
  const simple=HUD_SIMPLE_SECTIONS.includes(id)||control&&['wingScale','opacity','lightIntensity','lightBright','lightDim','gemMotion:size','gemMotion:glowStrength','gemMotion:expressionStrength','gemMotion:expressionEnabled','audio:volume','audio:audioLocalVolume'].includes(control);
  return group?{id,group,level:simple?'simple':'advanced',title:HUD_SETTINGS_LABELS[id]??(control?control.replace(/^.*:/,'').replace(/([A-Z])/g,' $1'):'Settings')}:null;
}
export const HUD_THEME_DEFAULTS=Object.freeze({background:'#171219',panel:'#261b26',accent:'#e767ce',text:'#f5ede1',gold:'#c4a474',opacity:.96,decoration:1,scale:1,motion:true,motionStrength:.75,compact:false,showHeader:true,header:'',emblem:'',headerMotion:true,headerGlints:true,headerReactiveText:true,headerHP:true,portraitStrength:.65,portraitInteractions:true,portraitSet:'original'});
const safeAsset=value=>typeof value==='string'&&!/[<>\"'\x00-\x1f]/.test(value)&&!/^\s*(?:javascript|data|vbscript):/i.test(value)?value.slice(0,512):'';
export function hudTheme(raw={}) {const t={...HUD_THEME_DEFAULTS};if(!raw||typeof raw!=='object')return t;for(const key of ['background','panel','accent','text','gold'])if(/^#[0-9a-f]{6}$/i.test(raw[key]))t[key]=raw[key];for(const [key,min,max] of [['opacity',.6,1],['decoration',0,1],['scale',.85,1.2],['motionStrength',0,1],['portraitStrength',0,1]])if(Number.isFinite(raw[key]))t[key]=Math.max(min,Math.min(max,raw[key]));for(const key of ['motion','compact','showHeader','headerMotion','headerGlints','headerReactiveText','headerHP','portraitInteractions'])if(typeof raw[key]==='boolean')t[key]=raw[key];for(const key of ['header','emblem'])t[key]=safeAsset(raw[key]);if(Object.hasOwn(PORTRAIT_SETS,raw.portraitSet))t.portraitSet=raw.portraitSet;return t;}
export const HUD_DEFAULTS=Object.freeze({quickEffects:['pulse','stutter','reform'],quickEffectsOpen:false,homePanel:'flight',homePanelOpen:true,settingsLevel:'simple',version:6,animationFavorites:{bits:['orbit','social','vigil'],tokenFX:['shield','pulseHalo']},advancedOpen:false,advancedGroup:null,favorites:['bits-glow','looks'],theme:HUD_THEME_DEFAULTS,tab:'home',followSelection:true,pinnedActor:null,pinnedToken:null,
  transitionMs:null,fadeMs:null,holdMs:3000,temporaryPose:false,temporaryCondition:false,
  effectStrength:0.7,pulseDurationMs:null,stutterDurationMs:null,keepWings:false,formation:true,foldWings:true,reactionEffectsOpen:false,audioOpen:[],
  openSections:['bits-glow','tuning-browser'],position:null});
const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));
const numeric=(value,fallback,lo,hi)=>Number.isFinite(value)?clamp(value,lo,hi):fallback;
const actorIdentity=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(value)?value:null;

export function hudPreferences(raw={}) {
  if(!raw||typeof raw!=='object'||Array.isArray(raw))raw={};
  const p={...HUD_DEFAULTS};
  if(HUD_TABS.includes(raw.tab))p.tab=raw.tab;
  else if(raw.tab)p.tab=({audio:'settings',tuning:'settings'})[raw.tab]??'home';
  p.homePanel=['flight','bits'].includes(raw.homePanel)?raw.homePanel:['bits','stabilizers'].includes(raw.tab)?'bits':'flight';
  if(['simple','advanced'].includes(raw.settingsLevel))p.settingsLevel=raw.settingsLevel;
  for(const key of ['followSelection','temporaryPose','temporaryCondition','keepWings','formation','foldWings','reactionEffectsOpen','advancedOpen','quickEffectsOpen','homePanelOpen'])
    if(typeof raw[key]==='boolean')p[key]=raw[key];
  p.pinnedActor=actorIdentity(raw.pinnedActor);
  if(typeof raw.pinnedToken==='string'&&/^Scene\.[^.\s]{1,64}\.Token\.[^.\s]{1,64}$/.test(raw.pinnedToken))p.pinnedToken=raw.pinnedToken;
  for(const key of ['transitionMs','fadeMs'])p[key]=raw[key]===null?null:numeric(raw[key],null,0,10000);
  for(const key of ['pulseDurationMs','stutterDurationMs'])p[key]=raw[key]===null?null:numeric(raw[key],null,100,10000);
  p.holdMs=numeric(raw.holdMs,3000,100,3600000);
  p.effectStrength=numeric(raw.effectStrength,0.7,0,1);
  p.audioOpen=Array.isArray(raw.audioOpen)?[...new Set(raw.audioOpen.filter(k=>typeof k==='string'&&/^(advanced|category:[A-Za-z][A-Za-z0-9_]*|slot:[A-Za-z][A-Za-z0-9_]*)$/.test(k)))].slice(0,180):[];
  p.openSections=Array.isArray(raw.openSections)?[...new Set(raw.openSections.filter(k=>typeof k==='string'&&/^[a-zA-Z0-9:-]{1,64}$/.test(k)&&!/(?:^|:|-)v7(?:-|$)|structure-shape/.test(k)))].slice(0,64):[...HUD_DEFAULTS.openSections];
  p.quickEffects=Array.isArray(raw.quickEffects)?[...new Set(raw.quickEffects.filter(k=>['pulse','stutter','flare','critical','overdrive','reform'].includes(k)))].slice(0,3):[...HUD_DEFAULTS.quickEffects];
  p.animationFavorites=Object.fromEntries(Object.entries({bits:Object.keys(COMPACT_BIT_PROGRAMS),tokenFX:TOKEN_EFFECT_IDS}).map(([kind,allowed])=>[kind,Array.isArray(raw.animationFavorites?.[kind])?[...new Set(raw.animationFavorites[kind].filter(id=>allowed.includes(id)))].slice(0,8):[...HUD_DEFAULTS.animationFavorites[kind]]]));
  p.theme=hudTheme(raw.theme);
  p.advancedGroup=Object.hasOwn(HUD_GROUPS,raw.advancedGroup)?raw.advancedGroup:null;
  p.favorites=Array.isArray(raw.favorites)?[...new Set(raw.favorites.filter(k=>typeof k==='string'&&/^[a-zA-Z0-9:-]{1,64}$/.test(k)&&!['v7','v7-experience'].includes(k)&&hudSettingsRoute(k)))].slice(0,12):[...HUD_DEFAULTS.favorites];
  const pos=raw.position;
  if(pos&&['left','top','width','height'].every(k=>Number.isFinite(pos[k])))
    p.position={left:clamp(pos.left,-10000,10000),top:clamp(pos.top,-10000,10000),width:clamp(pos.width,320,1200),height:clamp(pos.height,300,1600)};
  p.advancedOpen=p.tab==='settings';
  return p;
}

export function hudPosition(saved,viewport={width:globalThis.innerWidth??1280,height:globalThis.innerHeight??900}) {
  const maxW=Math.max(280,viewport.width-24),maxH=Math.max(240,viewport.height-24);
  const width=clamp(saved?.width??560,Math.min(380,maxW),maxW);
  const height=clamp(saved?.height??800,Math.min(420,maxH),maxH);
  return {width,height,left:clamp(saved?.left??viewport.width-width-24,0,Math.max(0,viewport.width-width)),
    top:clamp(saved?.top??60,0,Math.max(0,viewport.height-height))};
}

/** Only current-scene, owned, placed tokens can appear in or receive HUD commands. */
function eligibleHUDToken(token) {
  return !!(globalThis.canvas?.ready&&token&&!token.destroyed&&!token.isPreview&&token.document?.isOwner
    &&token.document.parent===canvas.scene&&canvas.scene?.tokens?.get(token.id)===token.document
    &&(globalThis.game?.user?.isGM||(!token.document.hidden&&token.isVisible!==false&&token.visible!==false)));
}
export function eligibleTokens() {
  if(!globalThis.canvas?.ready)return [];
  return (canvas.tokens?.placeables??[]).filter(eligibleHUDToken);
}
/** Tokens created from one prototype keep actorId even with a synthetic Actor. */
export function pinnedCharacterActorId(token) {
  const doc=token?.document??token;
  if(doc?.actorId!==undefined&&doc?.actorId!==null)return actorIdentity(doc.actorId);
  return actorIdentity(doc?.baseActor?.id)??actorIdentity(doc?.actor?.prototypeToken?.parent?.id)
    ??actorIdentity(doc?.actor?.prototypeToken?.actorId)??(!doc?.actor?.isToken?actorIdentity(doc?.actor?.id):null);
}
/** Resolve old placed-token pins directly, including an off-scene document. */
function legacyPinnedActor(prefs,available) {
  const current=available.find(token=>token.document?.uuid===prefs.pinnedToken);
  if(current)return pinnedCharacterActorId(current);
  const match=typeof prefs.pinnedToken==='string'?/^Scene\.([^.\s]{1,64})\.Token\.([^.\s]{1,64})$/.exec(prefs.pinnedToken):null;
  if(!match)return null;
  const doc=globalThis.game?.scenes?.get?.(match[1])?.tokens?.get?.(match[2]);
  return pinnedCharacterActorId(doc);
}
/** Migration is local preference data; never writes to the shared prototype. */
export function migratePinnedCharacterPreferences(prefs,available=eligibleTokens()) {
  const normalized=hudPreferences(prefs);
  if(!normalized.followSelection&&!normalized.pinnedActor)
    normalized.pinnedActor=legacyPinnedActor(normalized,available);
  return normalized;
}
/** A pin follows the character, using an exact placement only to break ties. */
export function resolvePinnedCharacterToken(prefs,available=eligibleTokens()) {
  if(!prefs||prefs.followSelection!==false)return null;
  const actorId=actorIdentity(prefs.pinnedActor)??legacyPinnedActor(prefs,available);
  if(!actorId)return null;
  if(globalThis.game?.actors?.get&&!game.actors.get(actorId))return null;
  const matching=available.filter(token=>eligibleHUDToken(token)&&pinnedCharacterActorId(token)===actorId);
  return matching.find(token=>token.document?.uuid===prefs.pinnedToken)??(matching.length===1?matching[0]:null);
}
/** Visible current-scene destinations; source ownership is checked by the action API. */
export function isVisibleBitTarget(source,token) {
  if(!globalThis.canvas?.ready)return false;
  const sourceDoc=source?.document??source;
  return !!(token&&!token.destroyed&&!token.isPreview&&token.document&&token.document!==sourceDoc
    &&token.document.parent===canvas.scene&&canvas.scene?.tokens?.get(token.id)===token.document
    &&(globalThis.game?.user?.isGM||(!token.document.hidden&&token.isVisible!==false&&token.visible!==false)));
}
export function formationTargets(source) {return (globalThis.canvas?.tokens?.placeables??[]).filter(token=>isVisibleBitTarget(source,token));}


/** Document hooks are noisy during movement. Only relevant changes rebuild the HUD. */
export function hudHookRelevant(name,args,target) {
  const doc=target?.document??target,subject=args?.[0],changed=args?.[1]??{};
  if(name==='targetToken')return !subject||subject.id===globalThis.game?.user?.id;
  if(name==='updateUser')return !subject||subject.id===globalThis.game?.user?.id;
  if(name==='updateToken') {
    if(subject?.parent&&subject.parent!==globalThis.canvas?.scene)return false;
    const keys=Object.keys(changed);
    if(keys.length&&keys.every(k=>['x','y','rotation','elevation','sort','texture'].includes(k)||k.startsWith('texture.')))return false;
    if(subject!==doc&&!keys.some(k=>['name','hidden','displayName','actorId','ownership','actorLink','disposition'].includes(k)))return false;
    if(keys.length&&keys.every(k=>k==='flags'||k.startsWith('flags.')))return keys.some(k=>k==='flags'?Object.hasOwn(changed.flags??{},ID)||Object.hasOwn(changed.flags??{},`-=${ID}`):k===`flags.${ID}`||k===`flags.-=${ID}`||k.startsWith(`flags.${ID}.`));
    return true;
  }
  if(name==='updateActor'||name==='updateActorDelta')return !subject||subject===doc?.actor||subject.parent===doc||!!subject.id&&subject.id===doc?.actor?.id;
  if(/^(create|update|delete)(Item|ActiveEffect)$/.test(name)) {
    const parent=subject?.parent;return !subject||parent===doc?.actor||parent?.parent===doc?.actor||!!parent?.id&&parent.id===doc?.actor?.id;
  }
  if(name.startsWith('filamentFlight')&&!['filamentFlightSettingsChanged','filamentFlightPerformanceChanged'].includes(name)) {
    const token=subject?.document??subject;
    if(token?.documentName==='Token'||token?.parent===globalThis.canvas?.scene)return token===doc;
  }
  return true;
}

export function hudTarget(prefs,currentId=null,available=eligibleTokens()) {
  if(!prefs.followSelection)return resolvePinnedCharacterToken(prefs,available);
  const selected=(canvas.tokens?.controlled??[]).filter(t=>available.includes(t));
  return selected.find(t=>t.document.uuid===currentId)??selected.at(-1)??null;
}

export function hudModel(api,prefs,currentId=null,now=Number(globalThis.game?.time?.serverTime)||Date.now(),cache=null) {
  const cfg=runtimeConfiguration(),available=eligibleTokens(),token=hudTarget(prefs,currentId,available);
  let state=null,baseAppearance=null,error=null,hp=null,audio=null;
  if(token)try {
    state=api.getState(token);
    const raw=token.document.getFlag(ID,'flight');
    if(cache?.token===token&&cache.raw===raw){audio=cache.audio;baseAppearance=cache.baseAppearance;}
    else {
      audio=timed('hud:audio',()=>api.getAudio?.(token)??null);
      const data=normalizeFlag(raw,now);
      baseAppearance={...(data.inheritDefaults?cfg.defaults:data.options)};
      for(const [k,v] of Object.entries(data.optionOverrides))baseAppearance[k]=v??cfg.defaults[k];
      baseAppearance=options(baseAppearance);
      if(cache)Object.assign(cache,{token,raw,audio,baseAppearance});
    }
    hp=readHealth(token.document.actor);
  }catch(e){error=String(e?.message??e);}
  let bitTasks=null;if(token)try{bitTasks=api.bits?.getState?.(token)??null;}catch{}
  return {cfg,prefs,token,state,baseAppearance,hp,audio,error,now,available,bitTasks,localQuality:api.getLocalQuality?.()??cfg.localQuality??{preset:'inherit'},lookPresets:cache?(cache.lookPresets??=api.getLookPresets?.()??[]):api.getLookPresets?.()??[],savedLooks:cache?(cache.savedLooks??=api.getSavedLooks?.()??[]):api.getSavedLooks?.()??[],
    selectedCount:(canvas.tokens?.controlled??[]).filter(t=>available.includes(t)).length};
}

export function liveHUDStatus(model) {
  const {state,hp,now}=model;
  if(!state)return {mode:'No token',pose:'—',condition:'—',hp:'—',temporary:'',assignment:'',source:'—',structureTransition:'',cue:'',bitTransition:'',visibility:'',light:'Select a token to control its light.',effectStyle:'',stabilizers:'Select a token to control its stabilizers.'};
  const remaining=[];
  for(const [key,labels] of [['temporaryPose',POSE_LABELS],['temporaryCondition',CONDITION_LABELS]]) {
    const t=state[key];
    if(t?.active)remaining.push(now>=t.started+t.duration?
      `Returning to saved ${key==='temporaryPose'?'pose':'condition'}`:
      `${labels[t.pose??t.condition]} · ${Math.ceil((t.started+t.duration-now)/1000)}s`);
  }
  return {mode:state.airborne||state.enabled||state.transition?.active?MODE_LABELS[state.effective.mode]:hudBitsDeployed(state)?'Grounded · bits':'Off',
    pose:POSE_LABELS[state.effective.pose],condition:CONDITION_LABELS[state.effective.condition],
    hp:hp?`${hp.value} / ${hp.max} HP${hp.temp?` (+${hp.temp} temp)`:''}`:'HP unavailable',temporary:remaining.join('  ·  '),
    structureTransition:state.structureAnimation?.active?`${state.structureAnimation.phase==='unweaving'?'Unweaving filaments':'Reforming energy structure'}…`:'',
    assignment:bitAssignmentStatus(model),
    source:`${state.requested?.conditionSource==='auto'?(state.effective?.autoHP===false?'Automatic · HP response disabled':'Controlled by HP'):`Manual condition${state.effective?.autoHP!==false?' · automatic HP response':''}`}${state.temporaryCondition?.active?' · temporary override':''}`,
    cue:model.cfg?.transientEffects===false?'':activeCueStatus(state,now),light:lightHUDStatus(model),
    bitTransition:state.bitDeployment>0&&state.bitDeployment<1?state.gems?.requestedEnabled===false?'Retracting bits into the token…':'Deploying bits to their saved positions…':'',
    stabilizers:stabilizerHUDStatus(model),
    effectStyle:`Current appearance: ${model.cfg?.wingRenderer==='atlas'||state.rendering?.fallback?'Original atlas (compatibility)':styleLabel(state.visual?.effectStyle??'animated')}`,
    visibility:!state.effective.renderingEnabled?'Effects are hidden by a module or browser setting.':
      state.effective.reducedMotion?'Reduced motion is active on this browser.':
      !state.enabled&&!state.transition?.active?hudBitsDeployed(state)?`Wings hidden · bits deployed around the token.${state.airborne?' Flight remains active.':' Ellie remains grounded.'}`:state.airborne?'Wings are retracted. Flight remains active; use Land to return to the ground.':'Wings are retracted. Pose and tuning changes are saved for their next deployment.':
      state.rendering?.fallback?'The wing rig could not render on this browser. Original wings are showing; try Refresh visuals.':
      model.cfg?.wingRenderer==='atlas'?'Original atlas mode uses subtle effects. Ask the GM to choose Automatic or Filament rig for animated conditions.':
      model.cfg?.enhancedConditions===false?'Detailed animated wing effects are disabled in module settings. Earlier subtle effects are active.':''};
}

/** Names are presentation data, never copied from an enemy's TokenDocument. */
export function visibleBitTarget(source,reference) {
  let target=reference?.document?reference:reference?.object??null;
  const id=reference?.uuid??reference?.id??reference;
  if(!target&&typeof id==='string'){
    const parts=id.split('.'),localId=parts.length===1?id:parts.length===4&&parts[0]==='Scene'&&parts[2]==='Token'&&parts[1]===globalThis.canvas?.scene?.id?parts[3]:null;
    if(localId)target=globalThis.canvas?.tokens?.get?.(localId)??globalThis.canvas?.scene?.tokens?.get?.(localId)?.object??(globalThis.canvas?.tokens?.placeables??[]).find(token=>token.id===localId);
  }
  return isVisibleBitTarget(source,target)?target:null;
}

export function safeBitTargetName(source,reference,ordinal=1) {
  const target=visibleBitTarget(source,reference);if(!target)return `Target ${ordinal}`;
  const doc=target.document,display=globalThis.CONST?.TOKEN_DISPLAY_MODES??{};
  const friendly=Number(doc.disposition)===Number(globalThis.CONST?.TOKEN_DISPOSITIONS?.FRIENDLY??1);
  const mayRead=doc.isOwner||target.nameplate?.visible===true||doc.displayName===(display.ALWAYS??50)
    ||doc.displayName===(display.HOVER??20)||target.controlled&&doc.displayName===(display.CONTROL??10);
  return friendly&&mayRead?(doc.name??target.name??`Ally ${ordinal}`):`Target ${ordinal}`;
}
export function hudBitGroups(model) {
  const raw=model.bitTasks?.groups??[],homeName=model.token?.document?.name??'Ellie';
  const groups=raw.filter(g=>g.count>0||g.bits?.length).map((g,index)=>({...g,label:g.id==='home'?`With ${homeName}`:`With ${safeBitTargetName(model.token,g.target??g.id,model.bitAliases?.get?.(g.target??g.id)??raw.filter(v=>v.id!=='home').indexOf(g)+1)}`}));
  if(!groups.length)groups.push({id:'home',target:null,bits:[],count:0,program:model.state?.requested?.gemMotion?.soloProgram??'halo',...model.bitTasks?.homeGroup,label:`With ${homeName}`,status:'retracted'});
  return groups;
}
/** One Home window: Flight plus the occupied instrument groups. */
export function hudHomePanels(model) {
  return [{id:'flight',label:'Flight & wings'},...hudBitGroups(model).map(group=>({id:`group:${group.id}`,group:group.id,label:group.label}))];
}
/** Event/status-driven words: no random rotation or private target names. */
export function hudHeader(model) {
  const state=model.state,hp=model.hp,condition=state?.effective?.condition??'normal',response=model.conditionResponse??state?.conditionResponse;
  const collapse=response?.collapse?.phase,active=model.bitTasks?.active??[],portrait=portraitState(model);
  let phase='rest',text='A little light. A steady hand.';
  if(portrait==='unconscious'||['falling','fallen'].includes(collapse)){phase='fallen';text='Even light needs rest.';}
  else if(collapse==='recovering'){phase='recovering';text='One thread at a time.';}
  else if(active.some(action=>action.kind==='treatment'&&!['returning','queued'].includes(action.status))){phase='treatment';text='Steady hands. Stay with me.';}
  else if(['wounded','severe','critical'].includes(portrait)||['damaged','unstable','glitching','suppressed','collapsed'].includes(condition)){phase='strained';text='Still holding.';}
  else if(condition==='overdrive'){phase='overdrive';text='A little further.';}
  else if(state?.airborne){phase='flight';text='Room to breathe.';}
  else if(hudBitCommandState(model).out.length){phase='instruments';text='Every small light has a purpose.';}
  if(!state){phase='rest';text='A little light. A steady hand.';}
  const panel=hudHomePanels(model).find(p=>p.id===(model.prefs?.homePanel==='bits'?`group:${model.bitGroup}`:'flight'));
  const subtitle=model.prefs?.tab==='settings'?(model.settingsFocus?.title??`${model.prefs.settingsLevel==='advanced'?'Advanced':'Simple'} settings`):model.prefs?.tab==='effects'?'The animation library':panel?.label??'Flight & wings';
  return {phase,portrait,text:model.prefs?.theme?.headerReactiveText===false?'A little light. A steady hand.':text,subtitle,
    hpRatio:hp?.max>0?Math.max(0,Math.min(1,hp.value/hp.max)):null,hpText:hp?`${hp.value} / ${hp.max}${hp.temp?` +${hp.temp}`:''}`:'—',
    condition:CONDITION_LABELS[condition]??condition,light:!!((state?.requested?.lightEnabled??state?.light?.enabled)||state?.requested?.lantern?.enabled)};
}
export function hudBitAllocations(model) {
  if(model.bitTasks?.allocations?.length)return model.bitTasks.allocations;
  const count=model.state?.bitCount?.count??4,deployed=hudBitsDeployed(model.state);
  return Object.keys(BIT_STATIONS).map((id,index)=>({id,location:deployed&&index<count?'home':'retracted',activity:'idle'}));
}
export function bitAssignmentStatus(model) {
  const bits=hudBitAllocations(model),busy=bits.filter(b=>b.actionKind&&b.actionKind!=='escort'&&!['idle','queued','travelling','returning'].includes(b.activity)),travelling=bits.filter(b=>['travelling','returning'].includes(b.activity));
  const groups=hudBitGroups(model).filter(g=>g.id!=='home');
  return [busy.length?`${busy.length} ${busy.length===1?'bit is':'bits are'} working`:null,travelling.length?`${travelling.length} travelling`:null,...groups.map(g=>`${g.presentCount??g.count??g.bits.length} ${g.label.toLowerCase()}${g.borrowedBits?.length?` · ${g.borrowedBits.length} borrowed`:''}`)].filter(Boolean).join(' · ');
}

/** Describe the current action using the same free home/retracted pool as the
 * HUD dispatch control. Never expose an unrelated target's name or mutate a
 * count when its availability changes between UI updates. */
export function hudBitDispatchAvailable(bit) {return !!bit&&Object.hasOwn(BIT_STATIONS,bit.id)&&(!bit.actionKind||bit.actionKind==='escort')&&['idle','escorting','escort'].includes(bit.activity);}
export function hudDispatchSummary(model) {
  if(Array.isArray(model.dispatchSelectedBits)){
    const bits=hudBitAllocations(model),selectedIds=[...new Set(model.dispatchSelectedBits)];
    const reserved=new Set((model.bitTasks?.queued??[]).flatMap(task=>task.bits??[]));
    const eligible=bits.filter(bit=>hudBitDispatchAvailable(bit)&&!reserved.has(bit.id)),unavailable=selectedIds.filter(id=>!eligible.some(b=>b.id===id));
    const rawTargets=[...(globalThis.game?.user?.targets??[])],chosen=rawTargets.filter(t=>isVisibleBitTarget(model.token,t));
    const destination=rawTargets.length===1&&chosen.length===1?chosen[0]:null;
    const targetLabel=destination?safeBitTargetName(model.token,destination):null,requested=selectedIds.length;
    const reason=!requested?'Shift-click diamonds to select bits.':unavailable.length?'A selected bit is busy or travelling. Wait for it or deselect it.':rawTargets.length>1?'Target exactly one visible token.':!destination?'Target a visible token first.':'';
    const remainingHome=bits.filter(b=>b.location==='home'&&!selectedIds.includes(b.id)).length;
    return {selectedIds,requested,available:eligible.length,remainingHome,insufficient:unavailable.length>0,unavailable,targetLabel,targetCount:chosen.length,destination,valid:!reason,reason,summary:reason||`Send ${requested} selected ${requested===1?'bit':'bits'} to ${targetLabel}`};
  }
  const bits=hudBitAllocations(model),free=model.bitTasks?.available??bits.filter(b=>['home','retracted'].includes(b.location)&&['idle','escorting'].includes(b.activity)).map(b=>b.id);
  const eligible=bits.filter(b=>free.includes(b.id)&&['home','retracted'].includes(b.location));
  const available=eligible.length,requested=Math.max(1,Math.min(4,Math.round(Number(model.sendCount)||1)));
  const home=eligible.filter(b=>b.location==='home').length;
  const chosen=[...(globalThis.game?.user?.targets??[])].filter(t=>isVisibleBitTarget(model.token,t));
  const targetLabel=chosen.length===1?safeBitTargetName(model.token,chosen[0]):null;
  const insufficient=requested>available,remainingHome=Math.max(0,home-requested);
  let summary=chosen.length===1?`Send ${requested} to ${targetLabel} · ${remainingHome} remain with Ellie`:chosen.length>1?'Target one visible token to send bits.':'Target a token on the canvas.';
  if(insufficient)summary=`${available} available · choose fewer bits or gather a group first.`;
  else if(chosen.length===1&&requested>home)summary+=` · ${requested-home} deploy from storage`;
  return {summary,available,requested,remainingHome,insufficient,targetLabel,targetCount:chosen.length};
}

/** Read the resolved visual state, not only the saved choice. The explanation
 * uses the existing HUD poll and returns local navigation routes only. */
export function hudStateExplanation(model) {
  const state=model.state,cfg=model.cfg??{};
  if(!state)return {summary:'Select a token to begin',lines:[],visibility:''};
  const requested=state.requested??{},response=model.conditionResponse??state.conditionResponse;
  const collapse=response?.wings&&response.collapse?.phase!=='awake'?response.collapse?.phase:null;
  const condition=state.effective?.condition??'normal',label=CONDITION_LABELS[condition]??condition;
  const hp=requested.conditionSource==='auto'&&state.effective?.autoHP!==false;
  const temporary=state.temporaryCondition?.active;
  let source=temporary?'temporary condition':hp?'HP response':requested.conditionSource==='auto'?'saved condition · HP response off':'manual selection';
  if(collapse)source=collapse==='recovering'?'Reform recovery':'Unconscious · Reform';
  const summary=collapse==='recovering'?'Reforming · remaining grounded':collapse?'Unconscious · broken Reform':`${label} · ${source}`;
  const flight=state.airborne?MODE_LABELS[state.effective?.mode]??'Airborne':'Grounded';
  const wings=state.transition?.active&&state.transition.wingsOnly?(state.transition.kind==='landing'?'Wings retracting':'Wings opening'):state.enabled?'Wings open':'Wings retracted';
  const lines=[{label:'Flight & wings',value:`${flight} · ${wings}`,settings:'flight-timing'},
    {label:'Wing condition',value:`${label} · ${source}`,settings:collapse?'condition-reactions':'effect-intensity'}];
  const selected=resolveEffectStyle(requested,condition,cfg);
  const painted=state.visual?.profile?.variant?.id??state.visual?.effectStyle??selected;
  const artwork=collapse?`Reform · ${styleLabel(requested.reactionStyles?.reform??cfg.reactionEffect_reform??'rethread')}`:styleLabel(painted);
  lines.push({label:collapse?'Temporary artwork':'Appearance',value:artwork,settings:collapse?'reaction-appearance':'effect-appearance'});
  if(!collapse&&state.effective?.autoHP!==false&&(requested.conditionSource!=='auto'||response?.wings&&response.active?.some(x=>x.id!=='unconscious')))lines.push({label:'HP response',value:'Automatic damage and glitch response alongside the selected appearance',settings:'effect-intensity'});
  const reactions=response?.enabled&&(response.wings||response.bits)?response.active?.filter(x=>x.id!=='unconscious').map(x=>x.label??x.id)??[]:[];
  if(reactions.length)lines.push({label:'Actor reactions',value:`${reactions.join(', ')} · ${response.wings&&response.bits?'wings and bits':response.wings?'wings':'bits'}`,settings:'condition-reactions'});
  const bits=hudBitAllocations(model),working=bits.filter(b=>b.actionKind&&b.actionKind!=='escort'&&!['idle','queued','returning'].includes(b.activity));
  const out=new Set(model.bitTasks?.outBits??hudBitCommandState(model).out),retracted=bits.filter(b=>b.location==='retracted'&&!out.has(b.id)).length;
  const nearby=bits.filter(b=>b.location==='home'&&!working.includes(b)&&!['travelling','returning'].includes(b.activity)).length;
  lines.push({label:'Instruments',value:[`${nearby} with Ellie`,`${retracted} retracted`,working.length?`${working.length} working`:null].filter(Boolean).join(' · '),settings:'group-tuning'});
  const visibility=!state.effective?.renderingEnabled?'Visuals are hidden by module or browser settings.':cfg.wingRenderer==='atlas'||state.rendering?.fallback?'Original atlas is visible; detailed choices remain saved.':!state.enabled&&!state.transition?.active?'Wing appearance is saved for the next deployment.':state.effective?.reducedMotion?'Reduced motion is active on this browser.':'';
  return {summary,lines,visibility};
}

/** Uses the HUD's existing half-second status poll, never a render/animation loop. */
export function activeCueStatus(state,now) {
  const labels={damage:'Damage',critical:'Critical flare',heal:'Healing',flare:'Flare',pulse:'Pulse',stutter:'Stutter',reform:'Reform'};
  return Object.entries(state?.cues??{}).filter(([,cue])=>cue&&cue.active&&now>=cue.started&&now<cue.started+cue.duration)
    .map(([kind,cue])=>`${labels[cue.kind??kind]??kind} · ${Math.max(.1,Math.ceil((cue.started+cue.duration-now)/100)/10).toFixed(1)}s`).join(' · ');
}

export function stabilizerHUDStatus({state,cfg}) {
  const g=state?.gems;if(!g)return 'Select a token to control its stabilizers.';
  if(cfg.wingRenderer==='atlas'||state.rendering?.fallback)return 'Original atlas is showing its built-in energy gems. Your stabilizer choices remain saved.';
  if(state.bitDeployment>0&&state.bitDeployment<1)return state.requested?.gemMotion?.enabled===false||state.requested?.gemMotion?.style==='hidden'?'Retracting bits into the token · wings remain active.':'Deploying bits from the token to their saved positions.';
  if(g.style==='hidden'||g.enabled===false)return cfg.controlGems===false?'Stabilizers hidden by the module setting.':'Bits off · artwork, placement and glow choices are saved.';
  const parts=[g.appearance==='physical'?g.artwork==='resonant'?'Resonant bits':g.artwork==='animated'?'Legacy animated bits':'Physical bits':'Energy gems',g.style==='classic'?'Classic placement':g.animated?'Animated':'Steady'];
  if(g.appearance==='physical')parts.push(g.glow&&g.glowStrength>0?`${g.glowMode==='field'?FIELD_STYLES[g.fieldStyle]??'Core + field':'Core glow'} ${Math.round(g.glowStrength*100)}%`:'Stabilizing glow off');
  if(!g.reactive)parts.push('Effect response off');
  return parts.join(' · ');
}

export function lightHUDStatus({state,cfg,token}) {
  const light=state?.light;if(!light)return 'Wing light is off.';
  if(!cfg.wingLight||!cfg.effectsEnabled)return 'Wing lighting is disabled in module settings.';
  if(!light.enabled)return 'Wing light is off.';
  if(token?.document.hidden)return 'Light is paused while the token is hidden.';
  if(light.error)return 'Wing light could not render on this browser. Use Refresh visuals to retry.';
  if(!light.intensity)return 'Light strength is zero.';
  if(!light.bright&&!light.dim)return 'Both light distances are zero. Set a radius in Display.';
  if(!light.active&&state.transition?.active&&light.requiresWings)return state.transition.kind==='takeoff'?'Light is forming with the wings.':'Light is fading with the retracting wings.';
  if(!light.active)return 'Light is armed for the next time the wings are active.';
  const units=token?.document.parent?.grid?.units||'scene units';
  return `Light on · ${light.bright} bright / ${light.dim} dim ${units} · ${light.animation.type?'soft pulse':'steady'}`;
}

/** Dispatch only to the existing API; the HUD never animates or writes TokenDocuments. */
export function hudCommand(api,token,action,value,prefs,cfg=configuration()) {
  const transition={duration:prefs.transitionMs??cfg.transitionDuration};
  const fade=prefs.fadeMs==null?{}:{duration:prefs.fadeMs};
  switch(action) {
    case 'v7': return api.setV7Preferences(token,value);
    case 'wingGesture': return api.wingGesture(token,value);
    case 'stopWingGesture': return api.stopWingGesture(token);
    case 'flightToggle': {
      if(api.toggleFlight)return api.toggleFlight(token,{...transition,formation:prefs.formation,keepWings:prefs.keepWings,foldWings:prefs.foldWings,keepBits:value?.keepBits===true});
      const current=api.getState(token);
      if(current.transition?.active&&!current.transition.wingsOnly)return;
      return (current.airborne??(current.enabled&&current.effective?.mode!=='grounded'))?
        api.land(token,{...transition,keepWings:prefs.keepWings,foldWings:prefs.foldWings,keepBits:value?.keepBits===true}):
        api.takeoff(token,{...transition,formation:prefs.formation});
    }
    case 'takeoff': return api.takeoff(token,{...transition,formation:prefs.formation});
    case 'land': return api.land(token,{...transition,keepWings:prefs.keepWings,foldWings:prefs.foldWings,keepBits:value?.keepBits===true});
    case 'toggle': case 'toggleWings': return api.toggleWings(token);
    case 'refresh': return api.refresh(token);
    case 'toggleLight': return api.toggleLight(token);
    case 'toggleLightMode': return api.toggleLightMode(token,{lantern:value?.lantern===true,keepBits:value?.keepBits===true});
    case 'toggleLantern': return api.toggleLantern(token);
    case 'lantern': return api.setLantern(token,value);
    case 'lanternAim': return api.isLanternAiming(token)?api.stopLanternAim():api.startLanternAim(token);
    case 'toggleBits': {
      const bits=api.bits?.getState?.(token);
      if(!api.bits?.toggleAll)throw new Error('All-bit controls require a scene reload after updating.');
      return api.bits.toggleAll(token,{count:bits?.preferredCount??api.getState(token)?.requested?.gemMotion?.count??4});
    }
    case 'selectedBits': if(!api.bits?.recall)throw new Error('Selected-bit controls require a scene reload after updating.');return api.bits.recall(token,{bits:value.bits,retract:value.retract,preserveOthers:true,only:value.only});
    case 'gatherBits': if(!api.bits?.gather)throw new Error('Gather controls require a scene reload after updating.');return api.bits.gather(token);
    case 'toggleBit': return api.bits.toggle(token,value);
    case 'toggleSummonFormation': if(!api.bits?.toggleSummonFormation)throw new Error('Formation shortcuts require a scene reload after updating.');return api.bits.toggleSummonFormation(token,value);
    case 'summonFormation': if(!api.bits?.setSummonFormation)throw new Error('Formation shortcuts require a scene reload after updating.');return api.bits.setSummonFormation(token,value);
    case 'recallGroup': return api.bits.recall(token,value);
    case 'conditionReactions': if(!api.conditionReactions?.configure)throw new Error('Reload the scene to enable condition reactions.');return api.conditionReactions.configure(token,value);
    case 'toggleConditionReactions': {
      if(!api.conditionReactions?.get||!api.conditionReactions?.configure)throw new Error('Reload the scene to enable condition reactions.');
      return api.conditionReactions.configure(token,{enabled:api.conditionReactions.get(token).enabled===false});
    }
    case 'resetConditionReactions': if(!api.conditionReactions?.reset)throw new Error('Reload the scene to enable condition reactions.');return api.conditionReactions.reset(token);
    case 'bitGesture': return api.bits.gesture(token,value.name,{group:value.group});
    case 'cancelGesture': return api.bits.cancel(token,value,'hud-gesture-cancelled');
    case 'bitGroup': return api.bits.setGroup(token,value.group,value.patch);
    case 'bitEffect': return api.bits.setEffect(token,value.group,value.patch);
    case 'assignBits': if(!api.bits?.assign)throw new Error('Formation assignment is unavailable. Reload the scene.');return api.bits.assign(token,value.target,{bits:value.bits??value.count,...(value.requireAvailable?{requireAvailable:true}:{})});
    case 'returnBits': if(!api.bits?.returnAll)throw new Error('Bit animation controls are unavailable. Reload the scene.');return api.bits.returnAll(token);
    case 'attachBits': return api.setGemMotion(token,{placement:value?'follow':'free'});
    case 'lightEnabled': return api.setLight(token,value);
    case 'lightIntensity': return api.setLightIntensity(token,value);
    case 'lightAppearance': return api.setLightAppearance(token,value);
    case 'lanternArtwork': return api.setLanternArtwork(token,value);
    case 'lightVisualReactions': return api.setLightVisualReactions(token,value);
    case 'resetLightAppearance': return api.resetLightAppearance(token);
    case 'restorePreviousLightAppearance': return api.restorePreviousLightAppearance(token);
    case 'lightBright': return api.setLightRadii(token,{bright:value});
    case 'lightDim': return api.setLightRadii(token,{dim:value});
    case 'lightRadii': return api.setLightRadii(token,value);
    case 'effectStyle': return api.setEffectStyle(token,value);
    case 'effectStyles': return api.setEffectStyles(token,value);
    case 'reactionStyles': return api.setReactionStyles(token,value);
    case 'effectTuning': return api.setEffectTuning(token,value);
    case 'reactionTuning': return api.setReactionTuning(token,value);
    case 'poseMotion': return api.setPoseMotion(token,value);
    case 'gemMotion': return api.setGemMotion(token,value);
    case 'compactProgram': return api.setGemMotion(token,{soloProgram:value});
    case 'observerQuality': return api.setObserverQuality(token,value);
    case 'audio': return api.setAudio(token,value);
    case 'previewReaction': return api.previewReaction(token,value,{strength:prefs.effectStrength});
    case 'playReaction': return (api.playReactionForAll??api.previewReaction)(token,value,{strength:prefs.effectStrength});
    case 'mode': return api.setMode(token,value);
    case 'pose': return prefs.temporaryPose?api.poseFor(token,value,prefs.holdMs,fade):api.setPose(token,value,fade);
    case 'wingState': return api.setState(token,{condition:value,...(value==='auto'?{autoHP:true}:{})});
    case 'condition': return prefs.temporaryCondition&&value!=='auto'?api.conditionFor(token,value,prefs.holdMs,fade):api.setCondition(token,value,fade);
    case 'clearPose': return api.clearPoseOverride(token,fade);
    case 'clearCondition': return api.clearConditionOverride(token,fade);
    case 'overdrive': return api.overdrive(token,prefs.holdMs,fade);
    case 'pulse': case 'stutter': return api[action](token,{strength:prefs.effectStrength,...(prefs[`${action}DurationMs`]==null?{}:{duration:prefs[`${action}DurationMs`]})});
    case 'flare': case 'reform': return api[action](token,{strength:prefs.effectStrength});
    case 'critical': return api.flare(token,{strength:prefs.effectStrength,critical:true});
    case 'collapse': return api.collapse(token,fade);
    case 'intensity': return api.setIntensity(token,value);
    case 'glitchIntensity': return api.setGlitchIntensity(token,value);
    case 'trailIntensity': return api.setTrailIntensity(token,value);
    case 'autoHP': return api.setHPReactions(token,value);
    case 'movementReactions': return api.setMovementReactions(token,value);
    case 'floatStyle': return api.configure(token,{floatStyle:value});
    case 'appearance': return api.configure(token,value);
    case 'resetAppearance': return api.clearOverrides(token,value);
    default: throw new Error(`Unknown HUD action: ${action}.`);
  }
}
