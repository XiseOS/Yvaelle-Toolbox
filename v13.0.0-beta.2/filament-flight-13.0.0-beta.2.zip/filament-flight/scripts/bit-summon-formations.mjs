import {enabledCompactProgramIds} from './compact-bit-formations.mjs?v=13.0.0-beta.2';
import {formationFlowState} from './bit-formation-flow.mjs?v=13.0.0-beta.2';

export function summonFormationOptions(snapshot={}) {
  let library='refined';try{library=globalThis.game?.settings?.get('filament-flight','formationLibrary')??'refined';}catch{}
  return {v7Enabled:snapshot.v7?.enabled===true&&snapshot.v7?.formations===true,library,forSummon:true};
}
export function toggleSummonFlow(group,options={}) {
  const allowed=enabledCompactProgramIds(options),saved=group.flow??{},pool=[...(saved.pool??[])];
  if(saved.enabled===true&&pool.filter(id=>allowed.includes(id)).length>=2)return {enabled:false};
  if(pool.filter(id=>allowed.includes(id)).length<2){
    for(const id of [group.program,'halo','lemniscate','petals','constellation','orbit','curiousCompanions','quietExchange','attentiveEscort','livingWorkshop'])
      if(allowed.includes(id)&&!pool.includes(id))pool.push(id);
  }
  return {enabled:true,pool};
}
/** Resolve once on an explicit summon, then persist the chosen family. Never
 * draw random numbers in the animation ticker or independently on observers. */
export function chooseSummonFormation(group,now,options={},random=Math.random) {
  const allowed=enabledCompactProgramIds(options),flowPool=(group.flow?.pool??[]).filter(id=>allowed.includes(id));
  const pool=group.flow?.enabled===true&&flowPool.length>=2?flowPool:allowed;
  const current=formationFlowState(group.program,now,{...group.flow,pool:flowPool}).program;
  const choices=pool.filter(id=>id!==current&&id!==group.program);
  const candidates=choices.length?choices:pool.filter(id=>id!==current);
  return candidates[Math.min(candidates.length-1,Math.floor(random()*candidates.length))]??pool[0]??'halo';
}
