/** Draws a token's flight-feel effects on the canvas (beta.29):
 *  - the moments (sparks, shards, splinters, shots, mode touches,
 *    afterimages): one small 2D surface around what is alive, painted at the
 *    beta.28 rate (at most 24 times a second) and drawn behind her wings, as
 *    in beta.28 (beta.30 restored that look);
 *  - the wing shield: its own surface painted in her frame and placed,
 *    turned and faded with her every display frame (repainted every frame
 *    while it rises, drops or ripples, at the wing texture rate while it
 *    only shimmers), drawn just in front of her wings.
 * Idle when nothing is alive: no texture, no paint. */
import {ID} from './config.mjs?v=13.0.0-beta.1';
import {effectMeshClass,placeBehind,isOnScreen} from './renderer.mjs?v=13.0.0-beta.1';
import {FX_IMAGES,paintShield,shieldChanging,SHIELD_REACH} from './flight-fx.mjs?v=13.0.0-beta.1';
import {MIN_REPAINT_MS} from './repaint-cadence.mjs?v=13.0.0-beta.1';
import {styleReach,uprightStyle} from './v12/shield-styles.mjs?v=13.0.0-beta.1';

let images=null,loading=null;
function loadImages(){
  if(images||loading)return images;
  loading=Promise.all(FX_IMAGES.map(name=>new Promise(resolve=>{
    const img=new Image();img.onload=()=>resolve([name,img]);img.onerror=()=>resolve([name,null]);
    img.src=foundry.utils.getRoute(`modules/${ID}/assets/flight/${name}.webp`);
  }))).then(list=>{images=Object.fromEntries(list.filter(([,img])=>img));}).catch(()=>{images={};});
  return null;
}

const MAX_SURFACE=512,SHIELD_SURFACE=384,STYLE_SURFACE=512;
function surfaceMesh(token,name,side){
  const surface=document.createElement('canvas');surface.width=surface.height=side;
  const context=surface.getContext('2d');if(!context)throw new Error('A 2D canvas is needed for flight effects.');
  const texture=PIXI.Texture.from(surface,{mipmap:PIXI.MIPMAP_MODES?.OFF??0});
  const Mesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
  const mesh=new Mesh({name:`${ID}.${token.id}.${name}`,texture},Shader);
  mesh.anchor.set(.5);mesh.eventMode='none';mesh.interactive=false;mesh.visible=false;
  canvas.primary.addChild(mesh);
  return {surface,context,texture,mesh,side};
}
function dispose(record){
  if(!record)return;
  const {mesh,surface}=record;
  if(mesh&&!mesh.destroyed){mesh.parent?.removeChild(mesh);mesh.destroy({children:true,texture:true,baseTexture:true});}
  if(surface)surface.width=surface.height=1;
}

export class FlightFxRenderer {
  constructor(token){this.token=token;this.parts=null;this.shield=null;}
  get mesh(){return this.parts?.mesh??null;}
  update(s,source,config,now){
    const fx=s.feelFx;
    if(!fx||!loadImages()){this.hide();return;}
    this.updateParts(fx,source,config,now);
    this.updateShield(fx,source,config,now);
  }
  updateParts(fx,source,config,now){
    if(!fx.parts.length){this.hideParts();return;}
    // (beta.30) The moments look and step exactly as in beta.28: the surface
    // covers the square around what is alive and is painted at most 24 times
    // a second (the rig rate); its placement is checked every display frame.
    const size=Math.max(this.token.w,this.token.h),b0=fx.bounds(this.fxBox??={});
    const cx=b0.half>0?b0.x:source.x,cy=b0.half>0?b0.y:source.y,extent=Math.min(size*6,Math.max(size*.5,b0.half));
    if(!isOnScreen(cx,cy,extent*2,extent*2)){this.hideParts();return;}
    const r=this.parts??=surfaceMesh(this.token,'flightfx',MAX_SURFACE);
    const slot=Math.floor(now/(1000/Math.min(24,config.rigFPS||24)));
    if(slot!==r.slot){
      r.slot=slot;
      const side=r.side,k=side/(extent*2),g=r.context;
      g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,side,side);
      fx.paint(g,images,cx-extent,cy-extent,k);
      r.texture.baseTexture.update?.();r.texture.update?.();
      r.box={x:cx,y:cy,w:extent*2};
    }
    const m=r.mesh,bx=r.box;if(!bx){this.hideParts();return;}
    m.x=bx.x;m.y=bx.y;m.width=m.height=bx.w;
    m.alpha=source.alpha;if(!m.visible)m.visible=true;
    // Behind her wings, as in beta.28.
    placeBehind(m,source,.45);
  }
  updateShield(fx,source,config,now){
    const sh=fx.shield;
    if(!fx.shieldActive){if(this.shield?.mesh.visible)this.shield.mesh.visible=false;return;}
    // (12.0.0-beta.2) a shield style may need more room and a finer surface than the weave
    const styled=!!sh.style&&sh.style!=='weave',half=sh.r*(styleReach(sh.style)??SHIELD_REACH),want=styled?STYLE_SURFACE:SHIELD_SURFACE;
    if(!isOnScreen(sh.x,sh.y,half*2,half*2)){if(this.shield)this.shield.mesh.visible=false;return;}
    if(this.shield&&this.shield.side!==want){dispose(this.shield);this.shield=null;}
    const r=this.shield??=surfaceMesh(this.token,'wingshield',want);
    // Rising, dropping or rippling: every frame. Holding: the shimmer at the
    // wing texture rate. The placement below follows her every frame either way.
    // (Beta.32: never more than about 60 pictures a second, as the wings: on a
    // 164 Hz screen a rising shield repainted and uploaded 164 times a second.)
    const slot=Math.floor(now/(1000/Math.max(12,config.rigFPS||24)));
    // (Measured on the local clock: the synced game clock may move in coarse steps.)
    const local=performance.now();
    if(!(local-r.paintedAt<MIN_REPAINT_MS)&&(shieldChanging(sh)||slot!==r.slot||r.half!==half)){
      r.slot=slot;r.half=half;sh.shown=sh.amount;r.paintedAt=local;
      const g=r.context;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,r.side,r.side);
      paintShield(g,sh,half,r.side/(half*2));
      r.texture.baseTexture.update?.();r.texture.update?.();
    }
    const m=r.mesh;m.x=sh.x;m.y=sh.y;m.rotation=uprightStyle(sh.style)?0:sh.angle;m.width=m.height=half*2;
    m.alpha=source.alpha;if(!m.visible)m.visible=true;
    // In front of her wings (a barrier between her and the blow), never dimmed by them.
    placeBehind(m,source,-.16);
  }
  hideParts(){if(this.parts?.mesh.visible)this.parts.mesh.visible=false;}
  hide(){this.hideParts();if(this.shield?.mesh.visible)this.shield.mesh.visible=false;}
  destroy(){dispose(this.parts);dispose(this.shield);this.parts=this.shield=null;}
}
