import {placeEmoteBit} from './v11/emote-apply.mjs?v=13.0.0-beta.1';
import {ID} from './config.mjs?v=13.0.0-beta.1';
import {effectMeshClass,placeBehind,setMeshTransform} from './renderer.mjs?v=13.0.0-beta.1';
import {paintStabilizer} from './stabilizer-art.mjs?v=13.0.0-beta.1';
import {bitAssets} from './bit-assets.mjs?v=13.0.0-beta.1';
import {localPerformance} from './performance.mjs?v=13.0.0-beta.1';
import {applyBitCondition} from './condition-response.mjs?v=13.0.0-beta.1';

export function placementConditionSampler(response,options={}){
  const modifiers=[];
  return (point,id,positionLocked=false)=>{
    if(!response?.bits||response.collapse?.phase!=='awake'||point.x===0||point.y===0)
      return applyBitCondition(point,response,{...options,id,positionLocked});
    const index=positionLocked?1:0;
    let modifier=modifiers[index];
    if(!modifier){
      const sampled=applyBitCondition({x:0,y:0},response,{...options,positionLocked});
      modifier=modifiers[index]={x:sampled.x,y:sampled.y,angleDelta:sampled.angleDelta,glowMultiplier:sampled.glowMultiplier,conditionMotion:sampled.conditionMotion};
    }
    return {...point,x:point.x+modifier.x,y:point.y+modifier.y,angleDelta:modifier.angleDelta,glowMultiplier:modifier.glowMultiplier,conditionMotion:modifier.conditionMotion};
  };
}

export const BIT_DETAIL=Object.freeze({low:128,medium:256,high:512});
// A fixed local square includes rotation, the existing glow and the largest
// supported bit size. World size is unchanged by the texture quality setting.
export const BIT_DRAW_SIZE=112;
/** (beta.35) A bit on screen repaints its animated artwork at most this many
 * times a second (its placement, turn and fade still move every display
 * frame). At 60 pictures a second four bits uploaded 220 textures a second
 * at hover; the crystal's slow internal motion reads the same at 30. The
 * interval is 80% of the period, so a picture due on every second 60 Hz
 * frame is never pushed to the third by frame jitter. */
export const BIT_PICTURE_FPS=30;
export const BIT_PICTURE_MS=1000/BIT_PICTURE_FPS*.8;

/** Bound the complete rotating housing and emitter, retaining the exact chosen
 * pixels per local unit. Resonant bodies fit within 42 units even at maximum
 * field gain; older image housings need 48. The old 112-unit square remains the
 * clipping limit. No resampling or quality reduction is involved. */
export function bitSurfaceSize(h,qualitySize,minimumScale=0){
  const radius=(h.artwork==='resonant'?42:48)*Math.max(Math.abs(h.scale??1),Math.abs(minimumScale)||0);
  const needed=Math.ceil((radius*2*qualitySize/BIT_DRAW_SIZE+4)/32)*32;
  return Math.min(qualitySize,Math.max(32,needed));
}

/** Grow immediately, then reclaim a substantially oversized texture after a
 * complete 600ms envelope. Retain the original pixels per unit and the largest
 * observed housing/glow bound; brief breathing motions never churn textures. */
export function settledBitSurfaceSize(record,desired,now=0,current=record.surface.width){
  if(desired>=current){record.pendingSize=null;return desired;}
  if(desired>current*.75){record.pendingSize=null;return current;}
  let pending=record.pendingSize;
  if(!pending||now<pending.started)pending=record.pendingSize={started:now,size:desired};
  else pending.size=Math.max(pending.size,desired);
  if(now-pending.started<600)return current;
  record.pendingSize=null;return pending.size;
}

const DETAIL_SIZES=Object.freeze(Object.values(BIT_DETAIL).sort((a,b)=>a-b));
/** Texture density follows the displayed size: the smallest native detail
 * whose 112-unit square covers its on-screen pixels (zoom × device pixels)
 * with a 25% margin, never above the chosen quality. `scale` is world pixels
 * per local unit (transform.width/600). */
export function bitDetailForScale(scale,quality='high',pixelScale=1){
  const cap=BIT_DETAIL[quality]??BIT_DETAIL.high,need=BIT_DRAW_SIZE*Math.abs(scale)*pixelScale*1.25;
  if(!(need>0))return cap;
  for(const size of DETAIL_SIZES)if(size>=need)return Math.min(cap,size);
  return cap;
}
/** More detail applies at once (zooming in never looks soft); less only after
 * 600ms of consistently lower need, so a zoom gesture does not churn textures. */
export function settledBitDetail(record,desired,now=0,current=record.qualitySize){
  if(!(current>0)||desired>=current){record.pendingDetail=null;return desired;}
  let pending=record.pendingDetail;
  if(!pending||now<pending.started)pending=record.pendingDetail={started:now,size:desired};
  else pending.size=Math.max(pending.size,desired);
  if(now-pending.started<600)return current;
  record.pendingDetail=null;return pending.size;
}

export function separateBits(geometry){
  const wings={},bits=new Map();
  for(const [key,parts] of Object.entries(geometry)){
    const left=key.startsWith('left'),depth=key.endsWith('Front')?'front':'rear';
    wings[key]=[];
    for(const part of parts){
      if(!part.hardware){wings[key].push(part);continue;}
      const id=`${left?'left':'right'}-${part.id}`;
      let bit=bits.get(id);
      if(!bit){bit={id,left,part,front:0,rear:0};bits.set(id,bit);}
      bit[depth]+=part.strength;
    }
  }
  return {wings,bits};
}

/** Actor conditions modify the actual painted supply mechanism too. Lantern
 * source/target hardware are simultaneous artwork layers, so applying the
 * modifier only to their outer wrapper would let a full-on projector bypass
 * unconscious enclosure, stunned machinery and its existing energy fade. */
function conditionHardware(h,response,gain,still){
  const resonance=h.resonance?{...h.resonance,amount:(h.resonance.amount??0)*still,mechanical:(h.resonance.mechanical??0)*still,
    charge:(h.resonance.charge??1)*gain,healing:(h.resonance.healing??0)*still,
    yaw:(h.resonance.yaw??0)*still,orbit:(h.resonance.orbit??0)*still,precession:(h.resonance.precession??0)*still,
    coreState:response.collapse.mix>.01?{id:'encased',amount:response.collapse.mix,encase:response.collapse.mix,open:0,charge:0,guard:0,settle:0,progress:0}:h.resonance.coreState}:h.resonance;
  const result={...h,power:(h.power??1)*gain,resonance,glow:h.glow?{...h.glow,strength:h.glow.strength*gain}:h.glow};
  if(h.lantern?.projection&&(gain!==1||still!==1||response.collapse.mix>.01))result.lantern={...h.lantern,
    original:conditionHardware(h.lantern.original??{...h,lantern:null},response,gain,still),
    projection:conditionHardware(h.lantern.projection,response,gain,still)};
  return result;
}

/** Placement and aim controllers carry their own live metadata. The bitmap
 * painters consume its resolved mechanical/glow channels and intent amount,
 * never the controller target, contour or gesture bookkeeping. Preserve all
 * other fields conservatively, including both captured projector assemblies. */
function artworkHardware(h){
  if(!h||typeof h!=='object')return h;
  const {focus,workTarget,stabilization,intent,lantern,...artwork}=h;
  return {...artwork,intent:{amount:intent?.amount??0},...(lantern?{lantern:{...lantern,
    ...(lantern.original?{original:artworkHardware(lantern.original)}:{}),
    ...(lantern.projection?{projection:artworkHardware(lantern.projection)}:{})}}:{})};
}

/** CPU frames shared by the live renderer and local preview. Only internal
 * artwork changes upload pixels; translations and depth use mesh transforms. */
const FEEL_STATIONS=Object.freeze({leftUpper:0,rightUpper:1,leftLower:2,rightLower:3});
/** Move a placed bit (world point `raw`, at its station) by the flight
 * feel's `feel` record: {x,y} pixels, then `mix` of the way to the target
 * (tx,ty) in token sizes from the wing transform's centre, turned with her
 * (local) or on the map (a brace), then `imix` of the way from there to
 * (itx,ity) on the map (taking a shot). c,s: cos and sin of the transform angle. */
export function feelBitPlacement(raw,feel,transform,c=Math.cos(transform.angle),s=Math.sin(transform.angle)){
  raw.x+=feel.x??0;raw.y+=feel.y??0;
  const u=transform.size??0;if(!(u>0))return raw;
  // (An idle gesture's small shift from the station, in her frame: the bits
  // still holding her up slide toward one that has left.)
  const ox=feel.ox||0,oy=feel.oy||0;
  if(ox||oy){raw.x+=(ox*c-oy*s)*u;raw.y+=(ox*s+oy*c)*u;}
  const mix=feel.mix??0;
  if(mix){
    const tx=feel.tx*u,ty=feel.ty*u,ax=transform.x+(feel.local?tx*c-ty*s:tx),ay=transform.y+(feel.local?tx*s+ty*c:ty);
    raw.x+=(ax-raw.x)*mix;raw.y+=(ay-raw.y)*mix;
  }
  const imix=feel.imix??0;
  if(imix){const ax=transform.x+feel.itx*u,ay=transform.y+feel.ity*u;raw.x+=(ax-raw.x)*imix;raw.y+=(ay-raw.y)*imix;}
  return raw;
}
let recordSerial=0;
const localClock=()=>globalThis.performance?.now?.()??Date.now();
export class BitFrames {
  constructor({assets=bitAssets,makeCanvas=()=>document.createElement('canvas')}={}){
    this.assets=assets;this.makeCanvas=makeCanvas;this.records=new Map();
  }
  /** Options (all optional; previews pass none and keep full quality):
   * detail(id,bit) → wanted pixels per 112 units, capped by quality;
   * budget → at most this many changed bits repaint per call (the caller
   * calls again next frame while `pending`); round → a repainted record is
   * not reconsidered until the round changes; retain → ids kept although
   * not drawn this call. A record's size, density and pixels change only
   * together, when it is actually repainted, so placement crops stay exact.
   * offload(job) → true when an already painted resonant bit's next picture
   * is painted elsewhere (the off-thread painter); its size, density and
   * pixels then change together when that picture is installed.
   * minInterval → (beta.35) ms a bit already on screen keeps its picture
   * before its animated artwork is repainted (a new size, density or first
   * picture still paints at once); see BIT_PICTURE_FPS. */
  update(bits,quality='high',now=globalThis.performance?.now?.()??Date.now(),{detail=null,budget=Infinity,round=null,retain=null,offload=null,minInterval=0}={}){
    quality=Object.hasOwn(BIT_DETAIL,quality)?quality:'high';
    if(this.quality!==quality){this.clear();this.quality=quality;}
    const cap=BIT_DETAIL[quality],assets=this.assets.forQuality?.(quality)??this.assets,queue=[];
    for(const [id,bit] of bits){
      let r=this.records.get(id);
      const wanted=Math.min(cap,detail?.(id,bit)??cap);
      if(!r){
        const surface=this.makeCanvas();surface.width=surface.height=bitSurfaceSize(bit.part.hardware,wanted,bit.surfaceScale);
        const context=surface.getContext('2d');
        if(!context){surface.width=surface.height=1;throw new Error('A 2D canvas is needed for detailed stabilizers.');}
        context.imageSmoothingEnabled=true;context.imageSmoothingQuality='high';
        r={surface,context,version:0,qualitySize:wanted,serial:++recordSerial,ticket:0,installed:0};this.records.set(id,r);
      }
      r.bit=bit;
      if(round!==null&&r.round===round)continue;
      // While a picture is being painted elsewhere, its size is the one to
      // settle from (otherwise a shrink on its way would be undone).
      const shownDetail=r.target?.qualitySize??r.qualitySize,shownSurface=r.target?.surfaceSize??r.surface.width;
      const qualitySize=settledBitDetail(r,wanted,now,shownDetail),density=qualitySize!==shownDetail;
      const housing=bitSurfaceSize(bit.part.hardware,qualitySize,bit.surfaceScale);
      const surfaceSize=density?housing:settledBitSurfaceSize(r,housing,now,shownSurface);
      // Only the image-backed route reads asset readiness. Native solids keep
      // their exact pixels when another preview releases a retired atlas lease.
      // (A picture on screen whose interval is not up keeps its pixels: only
      // the artwork could have moved on, so it is not even compared yet.)
      if(minInterval>0&&r.version>0&&!density&&shownSurface===surfaceSize&&now>=(r.paintedAt??-Infinity)&&now-r.paintedAt<minInterval)continue;
      const signature=JSON.stringify([artworkHardware(bit.part.hardware),bit.part.hardware.artwork==='animated'?this.assets.revision:0]);
      if(!density&&shownSurface===surfaceSize&&r.signature===signature){r.round=round;continue;}
      queue.push({id,r,bit,signature,qualitySize,surfaceSize});
    }
    // Oldest artwork first keeps a budgeted round fair across the bits.
    if(queue.length>budget)queue.sort((a,b)=>(a.r.paintedAt??-Infinity)-(b.r.paintedAt??-Infinity));
    const count=Math.min(queue.length,Math.max(0,budget));
    for(let i=0;i<count;i++){
      const {id,r,bit,signature,qualitySize,surfaceSize}=queue[i];
      // A bit already on screen can be painted off the main thread; the first
      // picture is always painted here, so a new bit never appears empty. One
      // picture per bit is on its way at a time: a newer request waits (only
      // the newest), so a busy painter is never handed a growing queue.
      if(offload&&r.version>0&&bit.part.hardware?.artwork==='resonant'){
        const request={bit,signature,qualitySize,surfaceSize};
        let accepted=!!r.job;
        if(r.job)r.deferred=request;
        else{const job=this.job(id,r,request);if(offload(job)){r.job=job;accepted=true;}else r.ticket--;}
        if(accepted){r.target={surfaceSize,qualitySize};r.signature=signature;r.round=round;r.paintedAt=now;continue;}
      }
      if(qualitySize!==r.qualitySize){r.qualitySize=qualitySize;r.pendingSize=null;}
      if(r.surface.width!==surfaceSize){r.surface.width=r.surface.height=surfaceSize;r.context.imageSmoothingEnabled=true;r.context.imageSmoothingQuality='high';}
      const f=r.context;f.clearRect(0,0,surfaceSize,surfaceSize);f.save();
      f.translate(surfaceSize/2,surfaceSize/2);f.scale(qualitySize/BIT_DRAW_SIZE,qualitySize/BIT_DRAW_SIZE);
      try{paintStabilizer(f,{...bit.part,strength:1,points:[[0,0,0,.92]]},assets);}
      finally{f.restore();}
      const h=bit.part.hardware;
      // (Any picture still being painted elsewhere is older than this one.)
      r.signature=signature;r.version++;r.round=round;r.paintedAt=now;r.installed=r.ticket;r.job=r.deferred=r.target=null;
      // The heading/size baked into these pixels; placements may carry the
      // live difference between artwork frames as a mesh transform.
      r.painted={angle:bit.paintAngle??h.angle??0,scale:bit.paintScale??h.scale??1};
    }
    this.pending=queue.length-count;
    for(const [id,r] of this.records)if(!bits.has(id)&&!retain?.has(id)){r.surface.width=r.surface.height=1;this.records.delete(id);}
  }
  /** The job for one picture to be painted elsewhere (see update's offload). */
  job(id,r,{bit,qualitySize,surfaceSize}){
    const h=bit.part.hardware;
    return {id,serial:r.serial,ticket:++r.ticket,surfaceSize,qualitySize,
      part:{...bit.part,strength:1,points:[[0,0,0,.92]]},painted:{angle:bit.paintAngle??h.angle??0,scale:bit.paintScale??h.scale??1}};
  }
  /** Install an off-thread picture: size, density and pixels change together.
   * Only the picture this bit is waiting for is accepted (one that arrives for
   * a replaced or repainted bit is ignored). A failed picture is painted here
   * instead. Returns null when ignored, else {failed, next}: next is the
   * newest request that waited, now to be sent. */
  install(result,now=globalThis.performance?.now?.()??Date.now()){
    const r=this.records.get(result?.id);
    if(!r||r.serial!==result.serial||!r.job||result.ticket!==r.job.ticket)return null;
    const job=r.job;r.job=null;
    if(result.error||!result.bitmap){
      const newest=r.deferred?this.job(result.id,r,r.deferred):job;r.deferred=null;
      this.paintNow(newest,now);return {failed:true,next:null};
    }
    r.installed=result.ticket;
    const size=result.surfaceSize;
    if(result.qualitySize!==r.qualitySize){r.qualitySize=result.qualitySize;r.pendingSize=null;}
    if(r.surface.width!==size){r.surface.width=r.surface.height=size;r.context.imageSmoothingEnabled=true;r.context.imageSmoothingQuality='high';}
    r.context.clearRect(0,0,size,size);r.context.drawImage(result.bitmap,0,0);
    r.version++;r.painted=result.painted;
    let next=null;
    if(r.deferred){next=this.job(result.id,r,r.deferred);r.deferred=null;r.job=next;}
    else r.target=null;
    return {failed:false,next};
  }
  /** Paint a job here instead (it could not be sent, or its painter failed). */
  paintNow(job,now=globalThis.performance?.now?.()??Date.now()){
    const r=this.records.get(job?.id);if(!r||r.serial!==job.serial||!(job.ticket>r.installed))return false;
    r.installed=job.ticket;if(r.job&&r.job.ticket<=job.ticket)r.job=null;
    const {surfaceSize,qualitySize}=job;
    if(qualitySize!==r.qualitySize){r.qualitySize=qualitySize;r.pendingSize=null;}
    if(r.surface.width!==surfaceSize){r.surface.width=r.surface.height=surfaceSize;r.context.imageSmoothingEnabled=true;r.context.imageSmoothingQuality='high';}
    const f=r.context;f.clearRect(0,0,surfaceSize,surfaceSize);f.save();
    f.translate(surfaceSize/2,surfaceSize/2);f.scale(qualitySize/BIT_DRAW_SIZE,qualitySize/BIT_DRAW_SIZE);
    try{paintStabilizer(f,job.part,this.assets.forQuality?.(this.quality)??this.assets);}
    finally{f.restore();}
    r.version++;r.painted=job.painted;r.paintedAt=now;
    if(!r.job&&!r.deferred)r.target=null;
    return true;
  }
  /** Pictures on their way will not arrive (the painter restarted or was let
   * go): paint the newest request of each such bit here, now. */
  forgetPending(now=globalThis.performance?.now?.()??Date.now()){
    let painted=false;
    for(const [id,r] of this.records){
      if(!r.job&&!r.deferred)continue;
      const newest=r.deferred?this.job(id,r,r.deferred):r.job;r.job=null;r.deferred=null;
      if(this.paintNow(newest,now))painted=true;
      r.target=null;
    }
    return painted;
  }
  // Draw after the matching wing layer, using full-quality bit surfaces rather
  // than shrinking the hardware into a 512px wing preview first.
  drawLayer(ctx,key,x,y,width,height,opacity=1){
    const left=key.startsWith('left'),depth=key.endsWith('Front')?'front':'rear';
    ctx.save();
    for(const r of this.records.values()){
      const b=r.bit;if(b.left!==left||b[depth]<=0)continue;
      const [cx,cy]=b.part.points[0],crop=r.surface.width/r.qualitySize,w=BIT_DRAW_SIZE/600*width*crop,h=BIT_DRAW_SIZE/600*height*crop;
      ctx.globalAlpha=opacity*b[depth];
      ctx.drawImage(r.surface,x+(cx+300)/600*width-w/2,y+(cy+285)/600*height-h/2,w,h);
    }
    ctx.restore();
  }
  clear(){for(const r of this.records.values())r.surface.width=r.surface.height=1;this.records.clear();}
}

/** Four independently sized textures; rear/front instances share each texture
 * so a bit crossing the token plane keeps the existing opacity handoff. */
/** Live renderers, so overlays (routines, flicker) can find where the real bits are drawn. */
const LIVE=new Set();
export function liveBitPositions(token){
  const id=token?.document?.id??token?.id;let best=null;
  for(const r of LIVE){if((r.token?.document?.id??r.token?.id)!==id||!r.placements.size)continue;if(!best||(r.placedAt??0)>(best.placedAt??0))best=r;}
  if(!best||performance.now()-(best.placedAt??0)>1500)return [];
  return [...best.placements.entries()].filter(([,p])=>!(p.alpha<=0)).map(([station,p])=>({station,x:p.x,y:p.y,angle:p.angle??0}));
}
export class BitRenderer {
  constructor(token){this.token=token;this.frames=new BitFrames();this.records=new Map();this.placements=new Map();this.offload=null;this.offloadBlockedUntil=-Infinity;LIVE.add(this);}
  get hasPendingResize(){for(const frame of this.frames.records.values())if(frame.pendingSize||frame.pendingDetail)return true;return false;}
  /** Changed bits still waiting for a budgeted repaint (see BitFrames.update). */
  get pendingPaint(){return (this.frames.pending??0)>0;}
  /** Heading/scale baked into a record's current texture, or null. */
  paintedHardware(id){return this.frames.records.get(id)?.painted??null;}
  /** scale: world px per local unit, a number or {id:scale}; without it the
   * previous placement's scale is used, and full quality before any. */
  detailSampler(scale,quality){
    const world=globalThis.canvas?.primary?.worldTransform??globalThis.canvas?.stage?.worldTransform;
    const zoom=world?Math.max(Math.hypot(world.a??1,world.b??0),Math.hypot(world.c??0,world.d??1)):1,pixelScale=zoom*(globalThis.canvas?.app?.renderer?.resolution??1);
    if(!(pixelScale>0)||!Number.isFinite(pixelScale))return null;
    return (id,bit)=>{
      const value=typeof scale==='number'?scale:scale?.[id]??this.placements.get(bit.station??`${bit.left?'left':'right'}${id.endsWith('0')?'Upper':'Lower'}`)?.scale;
      return Number.isFinite(value)&&value>0?bitDetailForScale(value,quality,pixelScale):null;
    };
  }
  paint(bits,quality,now,{scale=null,budget=Infinity,round=null,retain=null,offload=null}={}){
    const paintStarted=localPerformance.active?localPerformance.beginStage():null;
    const response=this.conditionContext?.response;
    if(response?.bits){
      // Awake instruments share one sampled condition envelope. Collapse and
      // recovery retain each station's captured origins and resting motion.
      let awakeModifier;
      bits=new Map([...bits].map(([id,bit])=>{
        const h=bit.part.hardware,station=bit.station??`${bit.left?'left':'right'}${id.endsWith('0')?'Upper':'Lower'}`;
        const modifier=response.collapse?.phase==='awake'?(awakeModifier??=applyBitCondition({x:0,y:0},response,{id:station,now:this.conditionContext.now})):applyBitCondition({x:0,y:0},response,{id:station,now:this.conditionContext.now});
        const gain=Math.round(modifier.glowMultiplier*32)/32,still=modifier.conditionMotion;
        return [id,{...bit,part:{...bit.part,hardware:conditionHardware(h,response,gain,still)}}];
      }));
    }
    // Off-thread painting: collect this round's jobs and send them together;
    // if they cannot be sent, paint them here exactly as before. After a
    // painter failure everything paints here for half a minute.
    if(offload&&localClock()<this.offloadBlockedUntil)offload=null;
    this.offload=offload;
    const jobs=offload?[]:null;
    this.frames.update(bits,quality,now,{detail:this.detailSampler(scale,quality),budget,round,retain,minInterval:BIT_PICTURE_MS,offload:jobs?job=>{jobs.push(job);return true;}:null});
    if(jobs?.length)this.send(jobs,now);
    if(paintStarted!==null)localPerformance.endStage('bitPaint',paintStarted);
    this.syncTextures();
  }
  send(jobs,now){
    let sent=false;try{sent=!!this.offload&&this.offload(jobs)===true;}catch{sent=false;}
    if(sent)localPerformance.count('bitPaintsOffloaded',jobs.length);
    else for(const job of jobs)this.frames.paintNow(job,now);
  }
  /** Pictures painted off the main thread arrive here (see paint's offload). */
  install(results,now){
    let changed=false;const next=[];
    for(const result of results??[]){
      const outcome=this.frames.install(result,now);if(!outcome)continue;
      changed=true;if(outcome.failed)this.offloadBlockedUntil=localClock()+30000;
      if(outcome.next)next.push(outcome.next);
    }
    // The newest request of each bit that waited goes out now.
    if(next.length){if(localClock()<this.offloadBlockedUntil)this.offload=null;this.send(next,now);}
    if(changed)this.syncTextures();
    return changed;
  }
  /** Pictures on their way will not arrive: paint them here (see BitFrames). */
  forgetPending(now){if(this.frames.forgetPending(now))this.syncTextures();}
  syncTextures(){
    for(const [id,r] of this.records)if(this.frames.records.get(id)!==r.frame){this.placements.delete(r.station);this.release(r);this.records.delete(id);}
    for(const [id,frame] of this.frames.records){
      let r=this.records.get(id);
      if(!r){
        r={frame,meshes:{},version:0,station:frame.bit.station??`${frame.bit.left?'left':'right'}${id.endsWith('0')?'Upper':'Lower'}`};this.records.set(id,r);
        // Keep subpixel crystal lines stable when the full-density artwork is
        // minified. ON also covers our cropped NPOT surfaces in WebGL2; PIXI
        // refreshes the chain only when the canvas upload is invalidated.
        r.texture=PIXI.Texture.from(frame.surface,{mipmap:PIXI.MIPMAP_MODES?.ON??PIXI.MIPMAP_MODES?.OFF??0,scaleMode:PIXI.SCALE_MODES?.LINEAR??1});
        const EffectMesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
        for(const depth of ['rear','front']){
          const mesh=r.meshes[depth]=new EffectMesh({name:`${ID}.${this.token.id}.bit.${id}.${depth}`,texture:r.texture},Shader);
          mesh.anchor.set(.5);mesh.roundPixels=false;mesh.eventMode='none';mesh.interactive=false;mesh.visible=false;mesh.alpha=0;
          canvas.primary.addChild(mesh);
        }
      }
      if(r.version!==frame.version){
        const size=frame.surface.width;
        if(r.size!==size){r.texture.baseTexture.resource?.resize?.(size,size);r.texture.baseTexture.setRealSize?.(size,size);r.size=size;}
        r.texture.baseTexture.update();r.version=frame.version;
        localPerformance.count('bitTextureUploads');localPerformance.count('bitUploadPixels',size*size);
      }
    }
  }
  /** Place every bit at its station (with the flight feel's offsets). Returns
   * which stations have a bit showing (bit mask, as FEEL_STATIONS): only those
   * can fly out to take a shot. */
  place(transform,source,alpha,cfg){
    const c=Math.cos(transform.angle),s=Math.sin(transform.angle);
    const condition=this.conditionContext?placementConditionSampler(this.conditionContext.response,{now:this.conditionContext.now,scale:Math.max(this.token.w,this.token.h),source:{x:source.x,y:source.y}}):null;
    let drawn=0;
    for(const r of this.records.values()){
      const b=r.frame.bit,[cx,cy]=b.part.points[0],spread=transform.bitSpread??1,x=cx/600*transform.width*spread,y=(cy-15)/600*transform.height*spread;
      const station=b.station??`${b.left?'left':'right'}${b.id.endsWith('0')?'Upper':'Lower'}`;
      const raw={x:transform.x+x*c-y*s,y:transform.y+x*s+y*c,z:b.part.points[0][2],angle:transform.angle};
      raw.sx=raw.x;raw.sy=raw.y;   // v11: the station itself (heal-runtime reads it)
      // Flight feel: an offset from the station, and bits sent out for a
      // moment (bracing for a save, taking a shot) toward a target in token
      // sizes from her body, in her frame or on the map.
      const lag=transform.bitOffsets?.[FEEL_STATIONS[station]??-1];
      if(lag)feelBitPlacement(raw,lag,transform,c,s);
      // v11: an emote's turn at the shoulder, offset, gather and lean (v11/emote-apply.mjs)
      // (test.3) a bit sent out on the map (the lent bit, a moment's bit away from her) is not pulled back by
      // the emote: the emote's share fades as that bit's own placement takes it
      if(lag?.emoX?.on){const away=lag.local===false?Math.min(1,Math.max(0,lag.mix||0)):0;
        if(away<1){const x0=raw.x,y0=raw.y;placeEmoteBit(raw,FEEL_STATIONS[station],b.left,lag.emoX,transform,c,s);if(away>0){raw.x=x0+(raw.x-x0)*(1-away);raw.y=y0+(raw.y-y0)*(1-away);}}}
      const p=condition?condition(raw,station,b.part.hardware?.stabilization?.positionLocked===true):raw;
      const ground=p.conditionGround??0;
      p.angle=(Number.isFinite(p.angleAbsolute)?p.angleAbsolute:transform.angle+(p.angleDelta??0))+(lag?(lag.spin||0)+(lag.ispin||0):0);
      p.scale=Number.isFinite(p.restingScale)?transform.width/600+(p.restingScale-transform.width/600)*ground:transform.width/600;
      const swell=lag?.emoScale||1;if(swell!==1)p.scale*=swell;
      const dimK=lag?1-(lag.dim||0):1;
      p.alpha=alpha*((b.front??0)+(b.rear??0)>0?1:0)*dimK;
      if(p.alpha>.05&&ground<.5&&FEEL_STATIONS[station]!==undefined)drawn|=1<<FEEL_STATIONS[station];
      this.placements.set(station,p);this.placedAt=performance.now();
      for(const depth in r.meshes){
        const mesh=r.meshes[depth];
        const front=depth==='front'&&cfg.foregroundWings;
        const weight=ground>.98?(depth==='front'?b.front+b.rear:0):b[depth];
        const visible=weight>0&&alpha>0;if(mesh.visible!==visible)mesh.visible=visible;
        const crop=r.frame.surface.width/r.frame.qualitySize;
        // v11 (phase 3a): a bit that is the subject of a moment swells (v11scale), or hides while the heal overlay redraws it on top (v11alpha);
        // an emote's swell (emoScale) is already in p.scale and joins the height here
        const sw=lag?.v11scale??1;
        setMeshTransform(mesh,p.x,p.y,p.angle,BIT_DRAW_SIZE*p.scale*crop*sw,
          BIT_DRAW_SIZE*(Number.isFinite(p.restingScale)?transform.height/600+(p.restingScale-transform.height/600)*ground:transform.height/600)*crop*swell*sw);
        const opacity=alpha*dimK*weight*(front&&ground<.98?cfg.foregroundOpacity:1)*(lag?.v11alpha??1);if(mesh.alpha!==opacity)mesh.alpha=opacity;
        // v11: a damage type's or mood's tint on this bit (damage-state.mjs), else none
        const tint=lag?.v11tint??0xffffff;if(mesh.tint!==tint)mesh.tint=tint;
        placeBehind(mesh,source,(front?(b.left?-.12:-.13):(b.left?.22:.21))-.001);
      }
    }
    return drawn;
  }
  /** Macro assignments use world positions without baking travel into textures. */
  placeWorld(placements,source,cfg,depthSources=null){
    const condition=this.conditionContext?placementConditionSampler(this.conditionContext.response,{now:this.conditionContext.now,scale:Math.max(this.token.w,this.token.h),source:{x:source.x,y:source.y}}):null;
    for(const [id,r] of this.records){
      let p=placements[id];
      const station=r.frame.bit.station??`${r.frame.bit.left?'left':'right'}${id.endsWith('0')?'Upper':'Lower'}`;
      if(p&&condition){
        const modifier=condition(p,station);
        p={...p,...modifier,angle:Number.isFinite(modifier.angleAbsolute)?modifier.angleAbsolute:(p.angle??0)+(modifier.angleDelta??0),
          scale:Number.isFinite(modifier.restingScale)?p.scale+(modifier.restingScale-p.scale)*(modifier.conditionGround??0):p.scale,
          ...(modifier.conditionGround>.98?{front:true,frontWeight:1}:{})};
      }
      if(p){this.placements.set(station,p);this.placedAt=performance.now();}
      else this.placements.delete(station);
      for(const depth in r.meshes){
        const mesh=r.meshes[depth];
        const front=depth==='front',weight=p?.frontWeight===undefined?(front===!!p?.front?1:0):(front?p.frontWeight:1-p.frontWeight);
        const visible=!!p&&p.alpha>0&&weight>.00001;if(mesh.visible!==visible)mesh.visible=visible;
        if(!p)continue;
        const crop=r.frame.surface.width/r.frame.qualitySize;
        setMeshTransform(mesh,p.x,p.y,p.angle??0,BIT_DRAW_SIZE*p.scale*crop,BIT_DRAW_SIZE*p.scale*crop);
        const opacity=p.alpha*weight;if(mesh.alpha!==opacity)mesh.alpha=opacity;
        const tint=p.color?Number.parseInt(p.color.slice(1),16):0xffffff;if(mesh.tint!==tint)mesh.tint=tint;
        placeBehind(mesh,depthSources?.get(id)??source,front?-.135:.225);
      }
    }
  }
  hide(){this.placements.clear();for(const r of this.records.values())for(const m of Object.values(r.meshes))if(m.visible!==false)m.visible=false;}
  release(r){
    for(const m of Object.values(r.meshes)){if(!m.destroyed){m.parent?.removeChild(m);m.destroy({children:true,texture:false,baseTexture:false});}}
    r.texture?.destroy(true);
  }
  destroy(){LIVE.delete(this);for(const r of this.records.values())this.release(r);this.records.clear();this.placements.clear();this.frames.clear();}
}
