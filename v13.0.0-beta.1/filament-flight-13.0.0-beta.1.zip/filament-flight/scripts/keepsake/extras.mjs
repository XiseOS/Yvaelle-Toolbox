/** Keepsake HUD · the experimental extras' pieces in the frame (v11, phase 3d).
 *
 *  - Milestone petals: the inner whorl of the corner Nytheris (the petals she
 *    has pinned), growing in when one is earned.
 *  - The title row's small tool: Post recap.
 * Each is a foreign island in the shell (the renderer leaves it alone) filled
 * after a render, and only redrawn when what it shows changes. While none of
 * them is on, nothing here holds a hook. */
import {isOn,partOn} from '../v11/features.mjs?v=13.0.0-beta.1';
import {readActorJournal,recapFor} from '../v11/journal-runtime.mjs?v=13.0.0-beta.1';
import {whorl,petalDefs,slotTransform} from '../v11/petal-art.mjs?v=13.0.0-beta.1';
import {milestoneById} from '../v11/journal.mjs?v=13.0.0-beta.1';
import {postRecap} from '../v11/recap.mjs?v=13.0.0-beta.1';
import {xicon} from '../v11/extras-icons.mjs?v=13.0.0-beta.1';
import {worldSky} from './sky.mjs?v=13.0.0-beta.1';

const ID='filament-flight';
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const REDUCED=()=>{try{return !!globalThis.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;}catch{return false;}};
const grownKey=actor=>`filament-flight.petals.grown.${actor?.id??''}`;

/** (11.0.0-test.6) What the extras show depends on: when it changes while the HUD is open, the HUD redraws.
 * (test.5 drew the petals only on the next render for some other reason: switched on with the HUD already
 * on Home, the corner flower's inner whorl stayed empty.) */
export function extrasKey(doc){
  try{return [isOn('xTapestry'),partOn('xPetals','petalsHud'),partOn('xPetals','petalsGrow'),isOn('xRecap')].map(Number).join('');}catch{return '';}
}
export class HudExtras {
  constructor(app){this.app=app;this.hooks=[];this.subKey='';this.keys={};}
  get model(){return this.app.model;}
  get doc(){return this.model?.token?.document??null;}
  get actor(){return this.doc?.actor??this.model?.token?.actor??null;}
  /** Hooks only for what is on: her journal (petals, tapestry). */
  subscribe(){
    const journal=isOn('xTapestry')||partOn('xPetals','petalsHud');
    const key=`${journal}`;if(key===this.subKey)return;this.subKey=key;this.release();
    const on=(n,fn)=>this.hooks.push([n,Hooks.on(n,fn)]),redraw=()=>this.app.host?.schedule();
    if(journal){on('filamentFlightJournal',e=>{if(!e?.actor||e.actor===this.actor)redraw();});
      // (her journal written on another browser)
      on('updateActor',(a,ch)=>{if(a===this.actor&&ch?.flags?.[ID]?.journal!==undefined)redraw();});}
  }
  release(){for(const [n,id] of this.hooks)try{Hooks.off(n,id);}catch{}this.hooks=[];}
  detach(){this.release();this.subKey='';}
  afterRender(root){
    if(!root)return;
    this.shownKey=extrasKey(this.doc);
    this.subscribe();
    this.tools(root);this.petals(root);
  }
  /* ---------------- tools: post recap ---------------- */
  tools(root){
    const el=root.querySelector('.ffx-tools');if(!el)return;
    const recap=isOn('xRecap')&&!!this.actor?.isOwner,key=`${recap}`;
    if(el.dataset.k===key)return;el.dataset.k=key;
    el.innerHTML=(recap?`<button type="button" class="ffx-tool" data-act="recap" aria-label="Post the session recap" title="Post this session’s recap to the chat">${xicon('recap')}</button>`:'');
    el.onclick=e=>{const b=e.target.closest('button[data-act]');if(!b)return;const ctx=this.app.ctx;
      if(b.dataset.act==='recap')void Promise.resolve(postRecap(this.actor,{recapFor,pinned:readActorJournal(this.actor).pinned})).then(()=>ctx.message('Her recap is in the chat')).catch(err=>ctx.message(err.message??String(err),true));};
  }
  /* ---------------- the corner flower's inner whorl ---------------- */
  petals(root){
    const g=root.querySelector('g.ffx-whorl');if(!g)return;
    const on=partOn('xPetals','petalsHud');
    if(!on){if(g.dataset.k){g.innerHTML='';g.dataset.k='';}return;}
    const actor=this.actor,J=readActorJournal(actor),pins=J.pinned;
    let open=1;try{if(this.app.ctx.ui?.moonClock!==false)open=worldSky().night;}catch{}
    const key=`${actor?.id}|${pins.join(',')}|${open.toFixed(2)}`;if(g.dataset.k===key)return;g.dataset.k=key;
    // (test.6) nothing pinned yet: five faint petal outlines in the gaps say where her milestones will grow, so the
    // whorl is never silently empty
    const shown=pins.filter(id=>milestoneById(id));
    g.innerHTML=shown.length?`<defs>${petalDefs('hudmp')}</defs>`+whorl(shown,{open,prefix:'hudmp',cls:'ffx-mp'})
      :`<g class="ffx-mp-empty" data-empty="1" fill="none" stroke="#efe4d4" stroke-opacity=".38" stroke-width=".55" stroke-dasharray="1.1 1.1"><title>No milestone pinned yet</title>${[0,1,2,3,4].map(i=>`<path d="M0 0C-3.1 -4.6 -3.1 -9.6 0 -12.6C3.1 -9.6 3.1 -4.6 0 0Z" style="transform:${slotTransform(i,open).css}"/>`).join('')}</g>`;
    g.dataset.n=String(shown.length);
    for(const [i,id] of shown.entries()){const p=g.querySelector(`[data-ms="${id}"]`);if(p)p.setAttribute('title',milestoneById(id)?.name??'');}
    this.growIn(g,actor,shown,open);
  }
  /** A petal earned since this browser last looked grows into its gap (560 ms, transform and opacity only). */
  growIn(g,actor,pins,open){
    let grown=null;try{grown=JSON.parse(globalThis.localStorage?.getItem(grownKey(actor))??'null');}catch{}
    const fresh=Array.isArray(grown)?pins.filter(id=>!grown.includes(id)):[];
    try{globalThis.localStorage?.setItem(grownKey(actor),JSON.stringify([...new Set([...(grown??[]),...pins])]));}catch{}
    if(!fresh.length||!partOn('xPetals','petalsGrow')||REDUCED())return;
    fresh.forEach((id,k)=>{const el=g.querySelector(`[data-ms="${id}"]`);if(!el)return;const i=pins.indexOf(id),T=slotTransform(i,open);
      el.animate([{transform:`rotate(${T.angle-16}deg) scale(.1)`,opacity:0},{opacity:1,offset:.45},{transform:T.css,opacity:1}],{duration:560,delay:500+k*900,easing:'cubic-bezier(.2,.8,.2,1)',fill:'backwards'});
      // a brief glint where it grew
      const glint=document.createElementNS('http://www.w3.org/2000/svg','path');glint.setAttribute('d','M0-2.6l.75 1.85L2.6 0 .75.75 0 2.6-.75.75-2.6 0-.75-.75z');glint.setAttribute('fill','#fff4dc');
      glint.setAttribute('transform',`rotate(${T.angle}) translate(0 -13) scale(1.3)`);g.append(glint);
      glint.animate([{opacity:0,transform:`rotate(${T.angle}deg) translate(0px,-13px) scale(0)`},{opacity:1,transform:`rotate(${T.angle}deg) translate(0px,-13px) scale(1.3) rotate(45deg)`,offset:.5},{opacity:0,transform:`rotate(${T.angle}deg) translate(0px,-13px) scale(0) rotate(90deg)`}],{duration:460,delay:820+k*900,easing:'ease-in-out',fill:'both'}).finished.then(()=>glint.remove(),()=>glint.remove());});
  }
}
