/** Shared Keepsake pieces: the frame, header, tabs and status line every tab
 * wears, plus the small helpers the three tab components use. */
import {DCLogic} from './runtime.mjs?v=13.0.0-beta.1';
import {hudHeader,CONDITION_LABELS} from '../hud-model.mjs?v=13.0.0-beta.1';
import {portraitAppearance} from '../hud-portrait.mjs?v=13.0.0-beta.1';
import {worldSky,moonPath,nytherisPetals,phaseName,lilyOpen} from './sky.mjs?v=13.0.0-beta.1';
import {heartbeat,heartState,CALM_TRACE} from './heartbeat.mjs?v=13.0.0-beta.1';
import {portraitView,cleanPortrait} from './sheet/model.mjs?v=13.0.0-beta.1';
import {isOn} from '../v11/features.mjs?v=13.0.0-beta.1';
const route=path=>{try{return (globalThis.foundry?.utils?.getRoute?.(path)??`/${path}`);}catch{return `/${path}`;}};

/** The corner crescent as it was drawn before the corners kept time ("little dusk"). */
const DUSK_CRESCENT='M92 24a13 13 0 1 0 10.5 20a10.5 10.5 0 1 1 -10.5 -20z';
/** PF2e Hero Points on her actor: {value, max, actor (its uuid)}, or null
 * (other systems, no actor). At most six petals. */
export function readHeroPoints(actor){
  try{
    const r=actor?.system?.resources?.heroPoints,value=Number(r?.value),raw=Number(r?.max);
    if(Number.isFinite(value)&&Number.isFinite(raw)&&raw>0){
      const max=Math.max(1,Math.min(6,Math.round(raw)));
      return {value:Math.max(0,Math.min(max,Math.round(value))),max,actor:actor.uuid??actor.id??''};
    }
  }catch{}
  return null;
}
/** How long a Hero Point petal counts as moving (ms): long enough for its
 * flight (petal-fall.mjs, at most 8 s) to land before it settles. */
export const HERO_MOTION_MS=8600;

export const M='#e767ce',GOLD='#cfae76';
export const TABS=[['effects','Effects'],['home','Home'],['settings','Settings']];
/** The tabs on show: (v11 extra) the Tapestry joins them while it is switched on. */
export const tabList=()=>{let on=false;try{on=isOn('xTapestry');}catch{}return on?[['effects','Effects'],['home','Home'],['tapestry','Tapestry'],['settings','Settings']]:TABS;};
export const FM_NOTES={Off:'The frame rests still: corners, cords, petals and her breathing. The heartbeat keeps time, and everything else works as normal.',Slow:'A quiet shimmer every so often. Good for long sessions.',Normal:'Light runs round the corners, the moon glows and the lily breathes.',Lively:'Everything moves a little quicker and more often.'};
export const COND_COLORS={Normal:M,Damaged:'#e2a256',Critical:'#c8324f',Collapsed:'#6f5f5c',Unstable:'#e2a256',Glitching:'#c78bff',Overdrive:'#ff9be6',Suppressed:'#8a7da8'};
export const SEVERITY={normal:0,damaged:1,unstable:2,glitching:2,overdrive:3,suppressed:3,collapsed:4};
export const POSE_ART={neutral:'neutral',raised:'raised',drooped:'drooped',collapsed:'collapsed',cocoon:'cocoon',aggressiveFlare:'aggressiveFlare',trailing:'trailing',forwardGuard:'forwardGuard',crossed:'forwardGuard',leftForwardWrap:'cocoon',rightForwardWrap:'cocoon'};
export const CONDITION_ART={normal:'neutral',damaged:'drooped',unstable:'trailing',glitching:'neutral',overdrive:'aggressiveFlare',suppressed:'cocoon',collapsed:'collapsed'};
export const pips=sev=>[1,2,3,4].map(k=>({fill:k<=sev?(sev>=4?'#c8324f':sev>=3?'#e2a256':M):'#120a0f',stroke:k<=sev?'transparent':'#4a3240'}));
const petalStyle=p=>`transform: rotate(${p.angle.toFixed(1)}deg) scale(${p.sx.toFixed(3)}, ${p.sy.toFixed(3)})`;
export const seg=on=>'seg2'+(on?' on':'');
export const cap=s=>String(s??'').replace(/^./,c=>c.toUpperCase());

/** Base for each tab: hint line, Shift tracking, frame motion and the header. */
export class KeepsakeTab extends DCLogic {
  constructor(props){super(props);this.state={shift:false,hint:null,hk:0,fmOpen:false,...this.initialState?.()};this.memo={};}
  get ctx(){return this.props.ctx;}
  get model(){return this.ctx.model;}
  /** Hover hints write straight into the status line. A render is needed only
   * to switch between hint and message, and leaving waits a beat, so moving
   * from control to control never rebuilds the tab. */
  setHint(h){
    if(h&&this.ctx.ui.hoverGuide===false)h=null;
    const s=this.state;s.hint=h;s.hk++;clearTimeout(this.hintTimer);
    const line=this._host?.rootElement?.querySelector('.ks-status')?.firstElementChild,shown=line?.localName==='span'&&line.firstElementChild?.classList.contains('key')?line:null;
    if(!h){if(shown)this.hintTimer=setTimeout(()=>this.forceUpdate(),90);return;}
    const parts=shown?.children;
    if(!parts||parts.length!==(h.shift?5:2)){this.forceUpdate();return;}
    parts[1].textContent=h.click;if(h.shift)parts[4].textContent=h.shift;shown.className=s.hk%2?'sw1':'sw0';
  }
  /** Count changes to a value so the design's swap animations replay on change. */
  bump(key,value){const m=this.memo[key]??(this.memo[key]={v:value,n:0});if(m.v!==value){m.v=value;m.n++;}return m.n;}
  sw(key,value,prefix='sw'){return prefix+(this.bump(key,value)%2);}
  /** The corners keep the world's time (beta.26): the crescent follows the
   * moon's phase, the Nytheris opens at night, the lunar lily at full moon.
   * Off: the corners as they always were. */
  skyVals(on){
    if(!on)return {moonPath:DUSK_CRESCENT,moonLabel:'',nyPetals:nytherisPetals(1).map(p=>({style:petalStyle(p)})),lilyOpen:'opacity: 0; transform: scale(.4)',lilyClass:'lily',lilyGlow:'opacity: 0'};
    const sky=worldSky(),full=lilyOpen(sky.fromFull);
    return {moonPath:moonPath(sky.phase,91.5,37,13),moonLabel:phaseName(sky.phase),
      nyPetals:nytherisPetals(sky.night).map(p=>({style:petalStyle(p)})),
      lilyOpen:`opacity: ${full.toFixed(2)}; transform: scale(${(.4+.6*full).toFixed(3)})`,lilyClass:full>.5?'lily full':'lily',lilyGlow:`opacity: ${(.55*full).toFixed(2)}`};
  }
  /** Her Hero Points as petals (PF2e). A spent one lifts and floats the whole
   * way down; a new one loosens from the Nytheris and floats down to its place
   * (the flights are drawn after render, in the HUD's sky: app.mjs). */
  heroVals(hero){
    // (Off, or no Hero Points: forget the count, so they come back without a petal falling.)
    if(!hero){if(this.memo.hero){clearTimeout(this.memo.hero.timer);this.memo.hero=null;}return {heroShow:false,heroPetals:[],heroValue:0,heroMax:0};}
    // Another character in the HUD: her petals simply appear, none fall or drift.
    if(this.memo.hero&&this.memo.hero.actor!==hero.actor){clearTimeout(this.memo.hero.timer);this.memo.hero=null;}
    const m=this.memo.hero??(this.memo.hero={actor:hero.actor,value:hero.value,slots:[]}),now=Date.now();
    if(hero.value!==m.value){
      const a=m.value,b=hero.value,kind=b<a?'leaving':'arriving';
      for(let k=Math.min(a,b);k<Math.max(a,b);k++)m.slots[k]={kind,at:now};
      m.value=b;clearTimeout(m.timer);m.timer=setTimeout(()=>this.forceUpdate(),HERO_MOTION_MS+80);
    }
    const heroPetals=[];
    for(let k=0;k<hero.max;k++){
      const t=m.slots[k],moving=t&&now-t.at<HERO_MOTION_MS,cls=moving?t.kind:k<hero.value?'held':'gone';
      // (Each resting petal sways on its own beat; a moving one carries its change's time, so it flies once.)
      heroPetals.push({cls:'hp '+cls,style:`--k: ${k};`+(cls==='held'||cls==='arriving'?` animation-delay: -${(k*1.7).toFixed(1)}s`:''),k,at:moving?t.at:''});
    }
    return {heroShow:true,heroPetals,heroValue:hero.value,heroMax:hero.max};
  }
  frameVals(defaultNote){
    const s=this.state,ctx=this.ctx,model=this.model,ui=ctx.ui,state=model.state;
    const shift=!!s.shift&&ui.shiftLabels!==false;
    const hp=model.hp,max=hp?.max??0,value=hp?.value??0,pct=max?Math.round(value/max*100):100;
    let hpColor=pct>50?M:pct>25?'#e2a256':'#c8324f',beat=pct>50?'2.6s':pct>25?'1.6s':'0.95s';
    // beta.27: the heartbeat follows her hit points and the conditions on her
    const actor=model.token?.document?.actor??model.token?.actor??null;let hb=null;
    try{hb=heartbeat(heartState(actor));if(hp&&!hb.still)beat=hb.period+'s';if(hb.tone!=='steady')hpColor=hb.color;}catch{hb=null;}
    const hbCls=['hb'];if(hb){if(hb.still)hbCls.push('still');else{if(hb.tone!=='steady')hbCls.push(hb.tone);if(hb.pause)hbCls.push('hold'+hb.pause);}
      if(hb.tremor>=.5)hbCls.push('tremor3');else if(hb.tremor>=.3)hbCls.push('tremor2');else if(hb.tremor>0)hbCls.push('tremor1');}
    const hbWords=hb?.words?.length?hb.words.join(', '):'steady';
    const header=model.header??hudHeader(model);
    const effective=state?.effective?.condition??'normal';
    const temp=state?.temporaryCondition;
    const remaining=temp?.active?Math.max(0,Math.ceil((temp.started+temp.duration-model.now)/1000)):0;
    const condition=!state?'—':hp&&value===0?'Collapsed':CONDITION_LABELS[effective]??cap(effective);
    const reactions=model.conditionSettings?.enabled!==false;
    const fm=ui.fm??'Normal',petals=ui.petals!==false;
    const fmOptions=['Off','Slow','Normal','Lively'].map(name=>({name,on:fm===name?'true':'false',pick:()=>ctx.saveUI({fm:name}),
      style:'height: 28px; border: 0; font-size: 11.5px; font-weight: 700; '+(fm===name?'background: #3e1a30; color: #fbf1e4;':'background: transparent; color: #9c8a80;')}));
    const message=ctx.message();const note=message.text||defaultNote;
    const h=s.hint;const undo=ctx.undoInfo();
    const name=model.token?.document?.name??'No character';
    // The header portrait follows her HP (and unconsciousness) like the classic HUD,
    // in the chosen expression set; a custom header image replaces it.
    const theme=model.prefs?.theme??{};let look={id:'healthy',band:'healthy'},portrait,portraitPos='62% 14%';
    let studio=null;try{const f=actor?.getFlag?.('filament-flight','portrait');studio=f?cleanPortrait(f):null;}catch{}
    if(studio?.hud&&studio.mode!=='keepsake'){
      // One portrait or her own stages, from the portrait studio
      let unconscious=false;try{unconscious=!!(actor?.hasCondition?.('unconscious')||actor?.statuses?.has?.('dead'));}catch{}
      const v=portraitView(studio,{hp:hp?.value??null,max:hp?.max??null,unconscious},{actorImg:actor?.img??ctx.portrait});
      portrait=v.src||ctx.portrait;portraitPos=v.pos;look={id:v.stage,band:v.stage==='unconscious'?'critical':v.stage,unconscious:v.stage==='unconscious'};
    }
    else if(theme.header)portrait=theme.header;
    else{try{
      // Keepsake art, in the expressions and thresholds chosen in the studio (else the HUD's own)
      const m=studio?.hud?{...model,prefs:{...model.prefs,theme:{...theme,portraitSet:studio.set}},cfg:{...model.cfg,hpThresholds:{moderate:studio.th.light/100,low:studio.th.severe/100,critical:studio.th.critical/100}}}:model;
      look=portraitAppearance(m);portrait=route(look.asset);}catch{portrait=ctx.portrait;}}
    // A new portrait (HP band) shows at once beneath the last, and the last one fades away
    // on top. Both pictures are always there, so nothing around them is ever rebuilt.
    const pm=this.memo.portrait??(this.memo.portrait={cur:portrait,pos:portraitPos,prev:null,prevPos:portraitPos,n:0});
    if(pm.cur!==portrait){pm.prev=pm.cur;pm.prevPos=pm.pos;pm.n++;clearTimeout(pm.timer);pm.timer=setTimeout(()=>{pm.prev=null;this.forceUpdate();},1200);}
    pm.cur=portrait;pm.pos=portraitPos;
    return {
      shift,
      rootClass:`ks-tab-${ctx.tab} `+({Off:'fm-off',Slow:'fm-slow',Normal:'',Lively:'fm-lively'}[fm]??'')+(petals?'':' no-petals')+(model.cfg?.reduced?' fm-off ks-reduced':''),
      keyDown:e=>{if(e.key==='Escape'&&this.onEscape?.())return;if(e.key==='Shift'&&!s.shift)this.setState({shift:true});},
      keyUp:e=>{if(e.key==='Shift'&&s.shift)this.setState({shift:false});},
      mouseMove:e=>{if(!!e.shiftKey!==s.shift)this.setState({shift:!!e.shiftKey});},
      mouseLeave:()=>this.setState({shift:false,hint:null}),
      closeApp:()=>ctx.close(),
      name,nameSize:name.length>11?'40px':'50px',epithet:ctx.epithet,tagline:header.text,portrait,portraitPrev:pm.prev??portrait,portraitPrevPos:pm.prev?pm.prevPos:portraitPos,portraitFade:pm.prev?'pf'+(pm.n%2):'',portraitState:look.unconscious?'unconscious':look.band,tokenImg:ctx.tokenImage,
      hp:hp?value:'—',hpMax:hp?max:'—',hpTemp:hp?.temp?` +${hp.temp}`:'',hpColor,beat,hpDash:pct+' 100',
      hbClass:hbCls.join(' '),hbTrace:hb?.trace??CALM_TRACE,hbEcho:String(hb?.echo??0),hbEchoOn:!!hb?.echo,hbBleed:!!hb?.bleed,hbWord:hbWords,portraitPos,
      condition,condTimed:remaining?` · ${remaining>=60?Math.ceil(remaining/60)+' min':remaining+'s'}`:temp?.active?' · held':'',
      condColor:COND_COLORS[condition]??M,
      reactLabel:reactions?'On':'Off',reactColor:reactions?M:'#6f5f5c',
      toggleReact:()=>ctx.run('toggleConditionReactions'),
      hintCond:()=>this.setHint({click:'Wing condition · set a timed condition',shift:''}),
      hintReact:()=>this.setHint({click:(reactions?'Turn off':'Turn on')+' automatic reactions to conditions like frightened or slowed',shift:''}),
      openCond:e=>{if(ctx.tab!=='home'){ctx.go('home',{menu:'cond'});return;}this.openMenu?.('cond',e);},
      tabs:tabList().map(([id,label])=>{const on=ctx.tab===id;return {name:label,on,current:on?'page':'false',cls:'tab'+(on?' on':''),pick:()=>ctx.go(id)};}),tabCount:tabList().length,tabPad:tabList().length>3?'14px':'40px',
      footer:note,footColor:message.failure?'#f08aa0':'#cdbcae',footSw:this.sw('foot',note),bloom:this.sw('bloomk',note,'bloom'),
      hinting:!!h,notHinting:!h,hintClick:h?h.click:'',hintShift:h?h.shift:'',hasHintShift:!!(h&&h.shift),hintSw:s.hk%2?'sw1':'sw0',
      clearHint:()=>this.setHint(null),
      undo:()=>ctx.undo(),canUndo:!!undo,
      // HUD choices that failed to save on this browser can be retried (from the classic footer)
      canRetrySave:!!ctx.controller?.unsavedPreferences,retrySave:()=>ctx.click('retryPreferences'),
      showFM:s.fmOpen,fmOpen:s.fmOpen?'true':'false',toggleFM:()=>this.setState({fmOpen:!s.fmOpen}),
      hintFM:()=>this.setHint({click:'Frame motion · '+fm.toLowerCase()+' · change how lively the frame is',shift:''}),
      fmLabel:fm,fmOptions,fmNote:FM_NOTES[fm],
      petalsOn:petals&&fm!=='Off'?'true':'false',togglePetals:()=>ctx.saveUI({petals:!petals}),
      petalTrack:'position: relative; width: 32px; height: 18px; flex-shrink: 0; border-radius: 9px; transition: background-color .25s; background: '+(petals&&fm!=='Off'?'#7a2a5c':'#2b1d27')+';',
      petalKnob:'position: absolute; top: 2px; width: 14px; height: 14px; border-radius: 7px; background: #f3eadf; transition: left .25s; left: '+(petals&&fm!=='Off'?'16px':'2px')+';',
      ...this.skyVals(ui.moonClock!==false),
      ...this.heroVals(ui.heroPetals!==false?readHeroPoints(model.token?.document?.actor??model.token?.actor):null),
      hintHero:()=>this.setHint({click:'Hero Points · a spent one drifts away, a new one falls from the Nytheris',shift:''}),
      version:'v'+ctx.version,
      // (v11) Settings wears a slim band instead of the full header
      fullHeader:ctx.tab!=='settings',slimHeader:ctx.tab==='settings'
    };
  }
}
