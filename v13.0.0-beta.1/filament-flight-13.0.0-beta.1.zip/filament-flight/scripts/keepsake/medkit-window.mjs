/** Ellie's Medkit as its own square window (v10 beta.12), separate from the
 * HUD. Frameless like the Keepsake HUD: the content lives in a shadow root
 * with the Keepsake styles, and the square frame (cords and corner keepsakes)
 * is drawn by the template itself. */
import {KeepsakeHost,compileTemplate} from './runtime.mjs?v=13.0.0-beta.1';
import {installClickFx} from './click-fx.mjs?v=13.0.0-beta.1';
import {KeepsakeMedkit} from './medkit.mjs?v=13.0.0-beta.1';
import {KeepsakePreviews} from './preview.mjs?v=13.0.0-beta.1';
import {moduleRoot} from './app.mjs?v=13.0.0-beta.1';
import {VERSION} from '../config.mjs?v=13.0.0-beta.1';
import {playMedkitSound} from './medkit-sounds.mjs?v=13.0.0-beta.1';
import {stopMedkitPreview} from './medkit-adapter.mjs?v=13.0.0-beta.1';

const ID='filament-flight',SIZE=780;
let files=null;
async function loadFiles(root=moduleRoot()){
  return files??=(async()=>{
    const get=async name=>{const r=await fetch(`${root}/templates/keepsake/${name}?v=${encodeURIComponent(VERSION)}`);if(!r.ok)throw new Error(`Medkit file missing: ${name}`);return (await r.text()).replaceAll('%KS%',root);};
    const [shell,page,css,feel]=await Promise.all(['shell.html','medkit-window.html','keepsake.css','feel.css'].map(get));
    // the HUD's own frame drawings (cords, corner keepsakes) dress the square too
    const a=shell.indexOf('<!-- Shared drawings -->'),b=shell.indexOf('<!-- Title row -->');
    const decor=a>=0&&b>a?shell.slice(a,b).replace(/<span style="position: absolute; left: 50%; bottom: 7px;[\s\S]*?<\/span>/,''):'';
    return {html:page.replace('%DECOR%',decor),css:css+'\n'+feel};
  })().catch(e=>{files=null;throw e;});
}
const PRELUDE=`
:host{all:initial;display:block}
.ks-root,.ks-root *{box-sizing:border-box}
:where(.ks-root) button{font:inherit;color:inherit;cursor:pointer}
:where(.ks-root) button.lnk{background-color:transparent;border:0;padding:0;cursor:pointer;font-family:inherit}
.pv-canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
`;
/** The healer: the token passed in, else the selected token, else the user's character. */
function healerToken(input){
  const t=input?.document?input:input?.object??null;if(t)return t;
  const controlled=globalThis.canvas?.tokens?.controlled??[];if(controlled.length===1)return controlled[0];
  const actor=game.user?.character;if(actor)return canvas.tokens?.placeables?.find(t=>t.actor?.id===actor.id)??null;
  return controlled[0]??null;
}

/** The dropdowns are filled here, not by the template, so their options
 * (and option groups) survive the HTML parser and keep focus while open. */
function syncSelects(root,specs){
  for(const el of root?.querySelectorAll?.('select[data-mk-sel]')??[]){
    const spec=specs?.[el.dataset.mkSel];if(!spec)continue;
    const sig=JSON.stringify(spec.options);
    if(el._mkSig!==sig){
      el._mkSig=sig;const doc=el.ownerDocument,parts=[];let group=null,groupName=null;
      for(const o of spec.options){
        const opt=doc.createElement('option');opt.value=o.value;opt.textContent=o.label;opt.disabled=o.disabled;
        if(o.group){if(o.group!==groupName){groupName=o.group;group=doc.createElement('optgroup');group.label=o.group;parts.push(group);}group.append(opt);}
        else{group=null;groupName=null;parts.push(opt);}
      }
      el.replaceChildren(...parts);
    }
    el.disabled=!!spec.disabled;
    if(el.value!==spec.value)el.value=spec.value;
  }
}

/** @property is ignored inside a shadow root, so the spinning rings'
 * angle is registered once on the page. */
function registerMotion(){try{globalThis.CSS?.registerProperty?.({name:'--ffmk-spin',syntax:'<angle>',inherits:false,initialValue:'0deg'});}catch{}}

/** Frameless windows get no placement from Foundry's own window styles, so
 * the Medkit places itself: fixed on the screen, out of the page flow (it
 * must never push the sidebar or chat), clamped so its title stays in reach,
 * scaled down on short screens, and remembered for next time. */
const POS_KEY='filament-flight.medkitPosition';
function viewport(){return {w:globalThis.innerWidth||1280,h:globalThis.innerHeight||800};}
function fitScale(){const {w,h}=viewport();return Math.max(.6,Math.min(1,(h-20)/SIZE,(w-20)/SIZE));}
function initialPlace(scale){
  try{const saved=JSON.parse(globalThis.localStorage?.getItem(POS_KEY)??'null');if(Number.isFinite(saved?.left)&&Number.isFinite(saved?.top))return saved;}catch{}
  const {w,h}=viewport(),size=SIZE*scale,sidebar=globalThis.document?.getElementById('sidebar')?.offsetWidth||320;
  // beside the sidebar, never over the chat; centred when the screen is narrow
  const left=w-sidebar-size-24>=10?w-sidebar-size-24:(w-size)/2;
  return {left,top:Math.max(10,(h-size)/2)};
}
function nextZ(){
  const A=globalThis.foundry?.applications?.api?.ApplicationV2;
  try{if(A&&Number.isFinite(A._maxZ)){A._maxZ+=1;return A._maxZ;}}catch{}
  return (nextZ.z=(nextZ.z??100)+1);
}

let open=null;
export async function openMedkitWindow(healer){
  if(open&&!open.closing){open.setHealer(healerToken(healer));open.bringToFront?.();return open;}
  const ApplicationV2=globalThis.foundry?.applications?.api?.ApplicationV2;
  if(!ApplicationV2)throw new Error("Ellie's Medkit needs Foundry VTT 14.");
  registerMotion();
  const assets=await loadFiles();
  class MedkitWindow extends ApplicationV2 {
    static DEFAULT_OPTIONS={id:'filament-flight-medkit',tag:'section',classes:['filament-flight-medkit','ks-window'],
      window:{frame:false,positioned:false},position:{width:SIZE,height:SIZE}};
    constructor(o){super(o);this.healer=healerToken(healer);this.hooks=[];
      this.previews=new KeepsakePreviews({getModel:()=>this.model,paused:()=>false});}
    get model(){const token=this.healer;return {token,cfg:{reduced:!!game.settings.get?.(ID,'reducedMotion')},state:null};}
    setHealer(t){if(t)this.healer=t;this.component?.setState({rk:(this.component.state.rk??0)+1});}
    makeContext(){
      const app=this;
      return {get model(){return app.model;},close:()=>app.close(),
        message:(text,failure=false)=>{app.component?.setState({msg:text,msgFail:failure});},
        get portrait(){return `${moduleRoot()}/assets/hud/ellie-header.webp`;},
        get tokenImage(){return `${moduleRoot()}/assets/hud/ellie-header.webp`;}};
    }
    async _renderHTML(){return assets;}
    /** Place the window: fixed, clamped to the screen so the title row stays grabbable. */
    place(left,top){
      const el=this.element;if(!el)return;
      const {w,h}=viewport(),scale=this.mkScale??1,size=SIZE*scale;
      left=Math.min(Math.max(left,40-size),w-60);top=Math.min(Math.max(top,0),h-50);
      this.mkPos={left:Math.round(left),top:Math.round(top)};
      Object.assign(el.style,{position:'fixed',left:`${this.mkPos.left}px`,top:`${this.mkPos.top}px`,width:`${SIZE}px`,height:`${SIZE}px`,margin:'0',
        transformOrigin:'0 0',scale:scale===1?'':String(scale)});
    }
    front(){if(this.element)this.element.style.zIndex=String(nextZ());}
    bringToFront(){this.front();}
    savePlace(){try{globalThis.localStorage?.setItem(POS_KEY,JSON.stringify(this.mkPos));}catch{}}
    _onRender(context,options){super._onRender?.(context,options);this.placeOnce();}
    placeOnce(){
      if(this.mkPlaced||!this.element)return;this.mkPlaced=true;
      this.mkScale=fitScale();const p=initialPlace(this.mkScale);this.place(p.left,p.top);this.front();
      this.mkResize=()=>{this.mkScale=fitScale();this.place(this.mkPos.left,this.mkPos.top);};
      globalThis.addEventListener?.('resize',this.mkResize);
    }
    _replaceHTML(result,content){
      if(this.host){this.host.render();return;}
      const doc=content.ownerDocument;content.replaceChildren();
      const hostEl=doc.createElement('div');hostEl.className='mk-host';content.append(hostEl);
      const shadow=hostEl.attachShadow({mode:'open'});try{installClickFx(doc);}catch{}
      const style=doc.createElement('style');style.textContent=PRELUDE+result.css;shadow.append(style);
      const mount=doc.createElement('div');shadow.append(mount);
      this.component=new KeepsakeMedkit({ctx:this.makeContext()});
      this.host=new KeepsakeHost(mount,{template:compileTemplate(doc,result.html),component:this.component,
        afterRender:root=>{syncSelects(root,this.component.selects);this.previews.sync(root,this.component.previewSpecs??{});},onError:e=>console.error('Yvaelle’s Toolbox | Medkit',e)});
      // drag by the title row
      shadow.addEventListener('pointerdown',e=>{
        this.front();
        if(e.button!==0||!e.target.closest?.('.ks-drag')||e.target.closest('button'))return;
        e.preventDefault();
        const start={x:e.clientX,y:e.clientY,left:this.mkPos?.left??0,top:this.mkPos?.top??0},win=doc.defaultView;
        const move=m=>this.place(start.left+m.clientX-start.x,start.top+m.clientY-start.y);
        const up=()=>{win.removeEventListener('pointermove',move);win.removeEventListener('pointerup',up);win.removeEventListener('pointercancel',up);this.savePlace();};
        win.addEventListener('pointermove',move);win.addEventListener('pointerup',up);win.addEventListener('pointercancel',up);});
      // Shift turns Battle Medicine into Treat Wounds on the action screen
      const win=doc.defaultView,shift=e=>{const on=!!e.shiftKey;if(this.component&&this.component.state.shift!==on){
        if(this.component.state.screen==='actions'&&!this.component.state.busy&&this.element?.matches?.(':hover'))playMedkitSound(on?'flip':'flip-back');this.component.setState({shift:on});}};
      const off=()=>{if(this.component?.state.shift)this.component.setState({shift:false});};
      win.addEventListener('keydown',shift);win.addEventListener('keyup',shift);win.addEventListener('blur',off);
      this.unlisten=()=>{win.removeEventListener('keydown',shift);win.removeEventListener('keyup',shift);win.removeEventListener('blur',off);};
      // the ward follows targets, HP and immunity as they change
      const refresh=()=>this.component?.setState({rk:(this.component.state.rk??0)+1});
      // moving the healer or a patient changes range (Keep on Keeping On! reaches 30 ft)
      let moveTimer=null;
      const moved=(doc,change)=>{
        if(!('x' in (change??{})||'y' in (change??{})||'elevation' in (change??{})))return;
        const ids=new Set([this.healer?.document?.id,...[...(game.user?.targets??[])].map(t=>t.document?.id)]);
        if(!ids.has(doc?.id))return;
        clearTimeout(moveTimer);moveTimer=setTimeout(refresh,60);
      };
      this.clearMoveTimer=()=>clearTimeout(moveTimer);
      for(const [hook,fn] of [['targetToken',refresh],['updateActor',refresh],['createItem',refresh],['deleteItem',refresh],['updateToken',moved],['updateWorldTime',()=>{if(this.component?.state.party)refresh();}]])
        this.hooks.push([hook,Hooks.on(hook,fn)]);
      this.host.render();
      this.placeOnce();
      playMedkitSound('open');
    }
    _onClose(o){super._onClose?.(o);void stopMedkitPreview();playMedkitSound('close');this.clearMoveTimer?.();globalThis.removeEventListener?.('resize',this.mkResize);this.unlisten?.();for(const [hook,id] of this.hooks)Hooks.off(hook,id);this.previews.destroy();this.host?.destroy();open=null;}
  }
  open=new MedkitWindow();
  await open.render({force:true});
  return open;
}
