/** Keepsake · Home. The four main actions, the bit tray, flight and group
 * panels, look, quick effects and the sub-menus with hover previews. Every
 * control reads the live HUD model and acts through the existing controller. */
import {KeepsakeTab,M,SEVERITY,POSE_ART,CONDITION_ART,pips,seg,cap} from './shared.mjs?v=13.0.0-beta.1';
import {pinnedSections} from '../v11/migrate.mjs?v=13.0.0-beta.1';
import {hudFlightAction,hudBitCommandState,hudBitAllocations,hudBitGroups,hudHomePanels,hudDispatchSummary,hudStateExplanation,
  POSE_LABELS,POSE_HINTS,CONDITION_LABELS,CONDITION_HINTS,MODE_LABELS,FLIGHT_MODES,FLOAT_STYLES} from '../hud-model.mjs?v=13.0.0-beta.1';
import {BIT_STATIONS} from '../wing-controls.mjs?v=13.0.0-beta.1';
import {COMPACT_BIT_PROGRAMS} from '../compact-bit-formations.mjs?v=13.0.0-beta.1';
import {TOKEN_EFFECT_PROGRAMS} from '../token-effects.mjs?v=13.0.0-beta.1';
import {BIT_GESTURES} from '../bit-behaviour.mjs?v=13.0.0-beta.1';
import {normalizeLantern} from '../lantern-model.mjs?v=13.0.0-beta.1';
import {LIGHT_PRESET_LABELS,lightPreset} from '../v88-lantern-tools.mjs?v=13.0.0-beta.1';
import {startLanternLockPicker} from '../v8-tool-preview.mjs?v=13.0.0-beta.1';
import {flightFeelEnabled,readFlightFeel,feelAltitude,wingShieldRaised,steadyMode} from '../flight-feel-runtime.mjs?v=13.0.0-beta.1';
import {ALTITUDE_PRESETS} from '../flight-feel.mjs?v=13.0.0-beta.1';
import {ROUTINES,startRoutine} from '../routines.mjs?v=13.0.0-beta.1';

const STATIONS=Object.keys(BIT_STATIONS);
const ORD=['1','2','3','4'];
const MODE_IDS=['grounded','hover','fly','glide','fast','surge','sentinel','wraith'];
const COND_IDS=['normal','damaged','unstable','glitching','overdrive','suppressed','collapsed'];
const DURATIONS=[['1 round',6000],['1 minute',60000],['10 minutes',600000],['Until cleared',0]];
const MENU_W={light:290,tools:360,field:284,cond:316,looks:320};
const MENU_H={light:340,tools:560,cond:300};
const PRESET_ICONS={closeWork:'M4 19h16M6 19V9l6-5 6 5v10M10 19v-5h4v5',travel:'M4 20c4-6 6-10 8-16M12 4c2 6 4 10 8 16M8 13h8',search:'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14M20 20l-4-4M11 8v6M8 11h6'};
const PRESET_NOTES={closeWork:'Soft · near',travel:'Even · middle',search:'Bright · far'};
const QUICK=[
  {id:'pulse',name:'Pulse',icon:'M3 12h4l2-5 4 10 2-5h6'},{id:'stutter',name:'Stutter',icon:'M4 7h6l4 10h6M4 17h6M14 7h6'},
  {id:'flare',name:'Flare',icon:'M12 3v3M12 18v3M3 12h3M18 12h3M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z'},
  {id:'critical',name:'Critical',icon:'M12 2l2.5 7H22l-6 4.5 2.5 7.5-6.5-4.5L5.5 21 8 13.5 2 9h7.5z'},
  {id:'overdrive',name:'Overdrive',icon:'M13 2L4 14h7l-1 8 9-12h-7z'},{id:'reform',name:'Reform',icon:'M4 20l7-7M14 4l1.5 3 3 1.5-3 1.5L14 13l-1.5-3-3-1.5 3-1.5z'}
];
const TASKS=[
  {id:'areaScan',name:'Scan an area',sub:'One square per bit · cooperative sweeps',icon:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',optLabel:'Where',opts:['Draw a region','Around Ellie'],cta:'Begin scan'},
  {id:'creatureScan',name:'Examine a creature',sub:'Survey its square · inspect the whole creature',icon:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6',optLabel:'Movement',opts:['Deliberate','Previous'],cta:'Examine'},
  {id:'parkLight',name:'Leave a light',sub:'One selected bit · stays until recalled',icon:'M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z',optLabel:'Place',opts:['At a point','On target'],cta:'Leave light'},
  {id:'escort',name:'Escort',sub:'Bind bits to your target as they move',icon:'M5 12h10M11 6l6 6-6 6M19 5v14',optLabel:'Who',opts:['My target'],cta:'Bind'},
  // These start at once and ask for their token or spot on the canvas.
  {id:'specimen',direct:true,name:'Specimen in light',sub:'Two bits hold a light copy of a token · click it next',icon:'M4 7h16v13H4zM8 16l3-4 2 2 2-3 3 5M7 3l2 2M17 3l-2 2'},
  {id:'iris',direct:true,name:'Mechanical iris',sub:'An aperture of blades reads a token · click it next',icon:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18M12 3l2.5 8M21 12l-8 2.5M12 21l-2.5-8M3 12l8-2.5'},
  {id:'warp',direct:true,name:'Warp',sub:'Step through a seam · click where she comes out',icon:'M4 18L10 12M14 8l6-6M15 3h5v5M7 12a5 5 0 0 0 5 5M12 7a5 5 0 0 1 5 5M3 21l2-2'}
];
const poseArt=(ctx,id)=>`${ctx.root}/assets/hud/pose-${POSE_ART[id]??'neutral'}.svg`;

export class KeepsakeHome extends KeepsakeTab {
  initialState(){return {menu:this.props.ctx.pending?.menu??null,panel:null,more:false,task:'areaScan',taskOpt:{},useBits:null,hov:null,hvk:0,condSel:null,condDur:'1 minute',light:null,lookName:'',sealedKey:null,cmpPhase:0};}
  onEscape(){if(this.state.menu){this.closeMenu();return true;}return false;}
  closeMenu(){this.setState({menu:null,hov:null,hint:null});}
  /** Open a sub-menu beside the control that opened it. */
  openMenu(kind,event){
    if(this.state.menu===kind){this.closeMenu();return;}
    const btn=event?.target?.closest?.('button')??null,root=btn?.getRootNode?.()?.querySelector?.('.ks-root');
    let anchor=null;
    if(btn&&root){const r=root.getBoundingClientRect(),b=btn.getBoundingClientRect();anchor={top:b.top-r.top,bottom:b.bottom-r.top,left:b.left-r.left,right:b.right-r.left,height:r.height};}
    this.setState({menu:kind,menuAnchor:anchor,hov:null,hint:null,light:null});
  }
  placeMenu(kind){
    const w=MENU_W[kind.startsWith('field')?'field':kind]??300,a=this.state.menuAnchor;
    if(!a)return {pos:`left: 44px; top: 300px; width: ${w}px`,beak:'display: none',left:44,top:300,w};
    const n=kind.startsWith('field')?(this.fieldDef(Number(kind.slice(6)))?.opts.length??5):kind==='looks'?(this.lookList().length):0;
    const h=kind.startsWith('field')?74+n*44:kind==='looks'?150+n*52:MENU_H[kind]??320;
    const cx=(a.left+a.right)/2,left=Math.round(Math.max(14,Math.min(600-14-w,cx-28)));
    let top=Math.round(a.bottom+10),flip=false;
    if(top+h>Math.max(1240,a.height)-20){top=Math.max(14,Math.round(a.top-h-10));flip=true;}
    const beak=flip?'display: none':`left: ${Math.round(Math.max(12,Math.min(w-24,cx-left-6)))}px`;
    // it opens from the control that asked for it (menus pass, beta.32)
    const ox=Math.round(Math.max(10,Math.min(w-10,cx-left)));
    return {pos:`left: ${left}px; top: ${top}px; width: ${w}px; transform-origin: ${ox}px ${flip?'100%':'0'}; --ks-dy: ${flip?4:-4}px`,beak,left,top,w};
  }
  fieldDef(i){
    const model=this.model,req=model.state?.requested??{};
    const art=id=>poseArt(this.ctx,id);
    const defs=[
      {title:'Flight mode',kind:'mode',cmd:'mode',value:req.mode??'grounded',opts:MODE_IDS.map(id=>[id,MODE_LABELS[id]??cap(id),FLIGHT_MODES[id]?.hint??''])},
      {title:'Wing pose',kind:'pose',cmd:'pose',value:model.state?.effective?.pose??req.pose??'neutral',thumbs:true,opts:Object.keys(POSE_LABELS).map(id=>[id,POSE_LABELS[id],POSE_HINTS[id]??''])},
      {title:'Float animation',kind:'float',cmd:'floatStyle',value:model.baseAppearance?.floatStyle??'hover',opts:Object.entries(FLOAT_STYLES).map(([id,f])=>[id,f.label,f.hint])},
      {title:'Wing state',kind:'condition',cmd:'wingState',value:req.conditionSource==='auto'?'auto':req.condition??'auto',opts:Object.keys(CONDITION_LABELS).map(id=>[id,id==='auto'?'Automatic from HP':CONDITION_LABELS[id],CONDITION_HINTS[id]??''])}
    ];
    const d=defs[i];if(d)d.art=art;return d;
  }
  lookList(){
    const m=this.model;
    return [...(m.savedLooks??[]).map(l=>({...l,personal:true})),...(m.lookPresets??[]).map(l=>({...l,personal:false}))];
  }
  /** Selection for the live hover preview of a field option. */
  fieldSelection(def,id){
    if(def.kind==='mode')return {kind:'mode',id};
    if(def.kind==='pose')return {kind:'pose',id};
    if(def.kind==='float')return {kind:'float',id};
    if(id==='auto')return {kind:'look',id:'current'};
    return {kind:'condition',key:id,id:'default'};
  }
  renderVals(){
    const s=this.state,ctx=this.ctx,model=this.model,state=model.state,token=model.token,c=ctx.controller;
    const base=this.frameVals(this.defaultNote());
    const shift=base.shift;
    const sel=[...(c.dispatchSelectedBits??[])];
    const cmd=hudBitCommandState({...model,dispatchSelectedBits:sel}),allocs=hudBitAllocations(model),groups=hudBitGroups(model);
    const byId=Object.fromEntries(allocs.map(b=>[b.id,b]));
    const where=b=>!b||b.location==='retracted'?'docked':b.location==='home'?'nearby':'away';
    const groupOf=id=>groups.find(g=>g.id!=='home'&&(g.bits??[]).includes(id));
    const near=allocs.filter(b=>where(b)==='nearby').length,docked=STATIONS.length-allocs.filter(b=>where(b)!=='docked').length,away=allocs.filter(b=>where(b)==='away').length;
    const airborne=!!(state?.airborne??(state?.enabled&&state?.effective?.mode!=='grounded'));
    const wingsOpen=!!state?.enabled;
    const lantern=normalizeLantern(state?.requested?.lantern??state?.lantern??{});
    const lit=!!((state?.requested?.lightEnabled??state?.light?.enabled)||lantern.enabled);
    const mode=MODE_LABELS[state?.effective?.mode]??'Grounded';

    // Main actions -------------------------------------------------------
    const f=hudFlightAction(state);
    const flight={key:'flight',on:airborne,face:{label:f.label,sub:airborne?mode:'Grounded'},disabled:f.disabled,
      alt:airborne?{label:'Land softly',sub:'bits keep their jobs'}:null,
      hint:airborne?{click:'Land · idle bits come home, bits on a job finish it first',shift:'Land, leaving every bit out'}:{click:'Take off · wings open, bits come out',shift:''},
      run:e=>ctx.click('flightToggle',{keepBits:!!e?.shiftKey})};
    const wings={key:'wings',on:wingsOpen,face:wingsOpen?{label:'Fold',sub:'Wings open'}:{label:'Wings',sub:'Folded'},alt:null,
      hint:{click:wingsOpen?'Fold the wings · bits stay out':'Open the wings without taking off · manoeuvres need Take off',shift:''},run:()=>ctx.run('toggleWings')};
    const remote=cmd.scoped?cmd.selectedRemote:cmd.remote;
    const bitsA={key:'bits',on:cmd.scoped?true:cmd.out.length>0,face:{label:cmd.label.replace(' all',''),sub:cmd.scoped?cmd.selectionSummary:cmd.out.length?`${cmd.out.length} out`:'All docked'},
      alt:remote.length?{label:cmd.scoped?`Recall ${remote.length}`:'Gather',sub:cmd.scoped?'to Ellie, still out':'away bits to Ellie'}:null,
      hint:{click:cmd.scoped?(cmd.selectedOut.length?'Retract only the selected bits':'Summon only the selected bits'):cmd.out.length?'Bring all four bits home':`Summon ${cmd.count} around ${token?.document?.name??'Ellie'}`,shift:remote.length?'Unbind away bits and gather them around Ellie':''},
      run:e=>ctx.click(e?.shiftKey&&remote.length?'gatherBits':'toggleBits')};
    const light={key:'light',split:true,on:lit,face:lit?{label:'Douse',sub:lantern.enabled?'Lantern lit':'Circle lit'}:{label:'Light',sub:'Unlit'},
      alt:lit?{label:'Douse',sub:'keep bits out'}:{label:'Lantern',sub:'aim it'},
      hint:lit?{click:'Douse the light · home bits return',shift:'Douse, keeping the bits out'}:{click:'A circle of light · free bits carry it',shift:'A lantern you aim with the mouse'},
      run:e=>ctx.click('toggleLightMode',{lantern:!!e?.shiftKey,keepBits:!!e?.shiftKey})};
    const widths=[149,114,114,114],PIP=col=>'display: inline-block; width: 5px; height: 5px; transform: rotate(45deg); background: '+col+';';
    const actions=[flight,wings,bitsA,light].map((a,i)=>{
      const useAlt=shift&&!!a.alt,face=useAlt?a.alt:a.face,accent=useAlt?'#f0b46a':M;
      return {key:a.key,label:face.label,sub:face.sub,split:!!a.split,pts:this.pts(widths[i],94,8),
        isTakeoff:a.key==='flight'&&!airborne,isLand:a.key==='flight'&&airborne,isWingsClosed:a.key==='wings'&&!wingsOpen,isWingsOpen:a.key==='wings'&&wingsOpen,
        isBits:a.key==='bits',isLight:a.key==='light',lit:a.key==='light'&&(lit||useAlt),
        ink:useAlt?'#e2a256':a.on?'#f6e7d2':'#cfae76',accent,core:a.on||useAlt?accent:'#5a2a4a',gemFill:a.on?M:useAlt?'#e2a256':'#8a6d45',
        flame:lit||useAlt?accent:'#6a3a58',flameCls:lit?'flicker':'',pip:PIP(useAlt?'#e2a256':a.on?M:'#5a4330'),
        aria:face.label+', '+face.sub,cls:'tile cut'+(useAlt?' alt':a.on?' on':'')+(a.disabled?' is-disabled':''),
        sw:'sw'+((this.bump('act-'+a.key,face.label)+(useAlt?1:0))%2),
        run:e=>{if(a.disabled)return;if(ctx.busy()){ctx.message('Still applying…');return;}a.run(e);},enter:()=>this.setHint({...a.hint,act:a.key}),leave:()=>this.setHint(null),hint:a.hint};
    });
    // A hovered tile rewrites itself after a click: keep its hint in step.
    if(s.hint?.act){const a=actions.find(x=>x.key===s.hint.act);if(a){base.hintClick=a.hint.click;base.hintShift=a.hint.shift;base.hasHintShift=!!a.hint.shift;}}

    // Bit tray -------------------------------------------------------------
    const looks={
      docked:{shell:'#8c7a74',core:'#120a0f',shine:0,shellStyle:'opacity: .5; transition: opacity .4s',lift:'transform: translateY(6px) scale(.8); transform-origin: 19px 30px; transition: transform .55s cubic-bezier(.3,1.3,.5,1)',glow:M,glowOp:0},
      nearby:{shell:'#cfae76',core:M,shine:.8,shellStyle:'filter: drop-shadow(0 0 3px rgba(231,103,206,.5)); transition: opacity .4s',lift:'transform: translateY(-7px); transform-origin: 19px 30px; transition: transform .55s cubic-bezier(.3,1.3,.5,1)',glow:M,glowOp:.55},
      away:{shell:'#f3eadf',core:'#a3243f',shine:.8,shellStyle:'opacity: .9; transition: opacity .4s',lift:'transform: translateY(-5px) scale(.9); transform-origin: 19px 30px; transition: transform .55s cubic-bezier(.3,1.3,.5,1)',glow:GOLDISH,glowOp:.25}
    };
    const bits=STATIONS.map((id,i)=>{
      const b=byId[id],st=where(b),picked=sel.includes(id),g=groupOf(id);
      const place=st==='docked'?'docked':st==='nearby'?`beside ${token?.document?.name??'Ellie'}`:(g?.label?.replace(/^With /,'bound to ')??'away');
      const working=!!(b?.actionKind&&b.actionKind!=='escort'&&!['idle','queued'].includes(b.activity));
      const n=this.bump('bit-'+id,st);
      const toggleSel=()=>{void ctx.click('toggleDispatchBit',id).then(()=>this.forceUpdate());};
      return {...looks[st],sel:picked,working,pressed:picked?'true':'false',ig:n?(n%2?'ig1':'ig0'):'',
        aria:'Bit '+ORD[i]+', '+place+(picked?', selected':''),
        down:e=>{if(!e.shiftKey||e.button!==0)return;e.preventDefault();this.paint={on:!picked,done:new Set([id])};this.suppressClick=true;toggleSel();
          const end=()=>{this.paint=null;};e.target.ownerDocument.defaultView.addEventListener('pointerup',end,{once:true});},
        enter:e=>{
          try{c?.toolUI?.hoverBit?.(id);}catch{}
          this.setHint({click:(st==='docked'?'Summon':st==='nearby'?'Retract':'Recall to Ellie')+' bit '+ORD[i]+' · '+place,shift:(picked?'Deselect':'Select')+' · or Shift-drag across several'});
          if(this.paint&&e?.buttons&1&&!this.paint.done.has(id)&&picked!==this.paint.on){this.paint.done.add(id);toggleSel();}
        },
        // hovering a diamond lights that bit on the canvas (as the classic diamonds did)
        leave:()=>{try{c?.toolUI?.hoverBit?.(null);}catch{}this.setHint(null);},
        click:e=>{if(this.suppressClick){this.suppressClick=false;return;}if(e?.shiftKey){toggleSel();return;}ctx.click('toggleBit',id);}};
    });
    const counts=[1,2,3,4].map(k=>({n:k,pressed:cmd.count===k?'true':'false',fill:k<=cmd.count?M:'#120a0f',stroke:k<=cmd.count?'#f0a6e4':'#8a6d45',
      pick:()=>{if(token)c.queueBitCount(k,token.document.uuid,true);},enter:()=>this.setHint({click:'Summon '+k+(k===1?' bit':' bits')+' next time',shift:''})}));
    const dispatch=hudDispatchSummary({...model,dispatchSelectedBits:sel});
    const canSend=sel.length>0;
    const tog=on=>'width: 26px; height: 26px; '+(on?'color: #fbf1e4; box-shadow: inset 0 0 0 1px #e767ce, inset 0 0 0 3px #160d13, inset 0 0 8px rgba(231,103,206,.45), 0 0 8px rgba(231,103,206,.25);':'color: #9c8a80;');
    const homeGroup=groups.find(g=>g.id==='home')??{};
    const randomOn=model.bitTasks?.randomOnSummon===true,flowOn=homeGroup.flow?.enabled===true;
    const awayGroups=groups.filter(g=>g.id!=='home');
    const summary=sel.length?`${sel.length} selected · ${dispatch.valid?dispatch.summary.toLowerCase():'target someone, then bind'}`:
      [near?`${near} beside ${token?.document?.name??'Ellie'}`:'',docked?`${docked} docked`:'',...awayGroups.map(g=>`${g.presentCount??g.count??g.bits?.length??0} ${g.label.replace(/^With /,'bound to ')}`)].filter(Boolean).join(' · ')||'No bits yet';

    // Panels ---------------------------------------------------------------
    const panelDefs=hudHomePanels(model);
    const panelId=panelDefs.some(p=>p.id===s.panel)?s.panel:(c.prefs?.homePanel==='bits'?`group:${c.bitGroup}`:'flight');
    const panelIdx=panelDefs.findIndex(p=>p.id===panelId);
    const panels=panelDefs.map(p=>{
      const on=p.id===panelId,g=p.group?groups.find(x=>x.id===p.group):null,count=g?String(g.presentCount??g.count??g.bits?.length??0):'',linked=!!g&&g.id!=='home';
      return {name:p.id==='flight'?'Flight & wings':p.label,count,linked,on:on?'true':'false',
        pick:()=>{if(p.group)c.bitGroup=p.group;this.setState({panel:p.id});},
        countStyle:'min-width: 16px; height: 16px; display: inline-grid; place-items: center; padding: 0 4px; border-radius: 8px; font-family: Keepsake Sans, sans-serif; font-size: 10px; font-weight: 700; '+(count&&count!=='0'?'background: #3e1a30; color: #f6d2ee;':'color: #6f5f5c;')+(count===''?' display: none;':''),
        style:'height: 38px; display: inline-flex; align-items: center; gap: 7px; padding: 0 12px; background: none; border: 0; border-bottom: 2px solid '+(on?'#d968c0':'transparent')+'; margin-bottom: -1px; color: '+(on?'#fbf1e4':'#9c8a80')+'; font-family: \'Keepsake Serif\', Georgia, serif; font-size: 16px; font-weight: 700; white-space: nowrap; max-width: 220px; overflow: hidden; text-overflow: ellipsis; transition: color .25s, border-color .25s;'};
    });
    const flightPanel=panelId==='flight';
    const group=flightPanel?null:groups.find(g=>`group:${g.id}`===panelId)??homeGroup;
    const settingLinks=[['Takeoff & landing','flight'],['Pose timing','animation'],['Float tuning','size'],['State & HP','reactions']];
    const flightRows=[0,1,2,3].map(i=>{
      const d=this.fieldDef(i),current=d.opts.find(o=>o[0]===d.value);
      return {label:d.title,value:current?.[1]??cap(d.value),link:settingLinks[i][0],
        go:()=>ctx.go('settings',settingLinks[i][1]==='flight'?{detail:'flight'}:{group:settingLinks[i][1]}),
        open:e=>this.openMenu('field:'+i,e),enter:()=>this.setHint({click:'Choose · '+(['How she moves in the air','The shape the wings rest in','How she bobs while airborne','Wear and tear follows her HP'][i]),shift:''}),
        preview:()=>ctx.click('previewAnimation',['mode','pose','float','look'][i])};
    });
    const program=group?COMPACT_BIT_PROGRAMS[group.program]:null;
    const effect=group?.effect,effectDef=TOKEN_EFFECT_PROGRAMS.find(p=>p.id===effect?.id);
    const groupHas=!!group&&((group.presentCount??group.count??group.bits?.length??0)>0);
    const groupRows=group?[
      {label:'Formation',value:program?.counts?.[Math.max(1,Math.min(4,group.presentCount??group.count??4))]?.name??program?.name??'Orbit',link:'Movement',kind:'bits'},
      {label:'Projected effect',value:effectDef?(effectDef.label+(effect?.enabled?' · on':' · off')):'None chosen',link:'Energy',kind:'tokenFX'}
    ].map(r=>({...r,go:()=>ctx.go('settings',{group:'bits'}),open:()=>{c.bitGroup=group.id;ctx.click('previewAnimation',r.kind);},preview:()=>{c.bitGroup=group.id;ctx.click('previewAnimation',r.kind);},
      enter:()=>this.setHint({click:'Browse '+(r.kind==='bits'?'formations':'projected effects')+' with a live preview',shift:''})})):[];
    const gestureIds=['inspect','attend','confer','settle','makeRoom'];
    const directions=group?[
      ...(effect?.enabled?[{name:'Stop field',run:()=>{c.bitGroup=group.id;void ctx.run('bitEffect',{group:group.id,patch:{id:effect.id,enabled:false}});ctx.message((effectDef?.label??'Field')+' stopped');},enter:()=>this.setHint({click:'Stop projecting '+(effectDef?.label??'the field'),shift:''})}]:[]),
      ...(group.id!=='home'?[{name:'Recall',run:()=>ctx.click('recallGroup',group.id),enter:()=>this.setHint({click:'Bring this group back to '+(token?.document?.name??'Ellie'),shift:''})}]:[]),
      ...(()=>{const active=model.bitTasks?.active?.find(a=>a.gesture&&a.target===(group.target??token?.document?.id));
        return active?[{name:'Cancel gesture',run:()=>{c.bitGroup=group.id;ctx.click('cancelGesture',active.id);},enter:()=>this.setHint({click:'Close tools and return to current assignments',shift:''})}]:[];})(),
      ...gestureIds.map(id=>({name:BIT_GESTURES[id]?.label??cap(id),run:()=>{c.bitGroup=group.id;ctx.click('bitGesture',id);},enter:()=>this.setHint({click:BIT_GESTURES[id]?.description??'',shift:''})})),
      {name:'More…',run:()=>{c.bitGroup=group.id;ctx.click('previewAnimation','gesture');},enter:()=>this.setHint({click:'Every direction, with a live preview',shift:''})}
    ]:[];

    // Look ------------------------------------------------------------------
    const explain=model.stateExplanation??hudStateExplanation(model);
    const lookKey=JSON.stringify(state?.requested??null);
    const sealed=!!s.sealedKey&&s.sealedKey===lookKey;
    // (v11) the Settings sections pinned to Home (the v10 pressed groups, migrated: v11/migrate.mjs)
    const pressed=pinnedSections(ctx.ui).map(id=>ctx.settingsSections.find(g=>g.id===id)).filter(Boolean).map(g=>({name:g.name,go:()=>ctx.go('settings',{section:g.id}),enter:()=>this.setHint({click:'Open '+g.name+' in Settings',shift:''})}));

    // Quick effects -----------------------------------------------------------
    const quickOn=wingsOpen;
    const quick=QUICK.map((q,i)=>({...q,cls:'charm '+(quickOn?'live':'idle'),drop:[9,15,17,17,15,9][i],delay:(i*.7)+'s',labelColor:quickOn?'#f3eadf':'#9c8a80',
      // Previews open the private Effects stage; nothing is written to the token.
      run:e=>{if(e?.shiftKey||!quickOn){ctx.go('effects',q.id==='overdrive'?{cat:'conditions',sel:'overdrive'}:{cat:'reactions',sel:q.id});return;}ctx.run(q.id);},
      enter:()=>this.setHint({click:quickOn?'Play '+q.name+' · everyone sees it':q.name+' · preview privately in Effects (wings are folded)',shift:quickOn?'Preview privately in Effects · only you see it':''})}));

    const menu=this.menuVals();
    return {...base,...menu,
      actions,bits,counts,bitSummary:summary,sumSw:this.sw('sum',summary),hasAway:away>0,
      arrangeBits:()=>{const c0=ctx.controller,open=c0?.prefs?.openSections??[];if(!open.includes('bits-placement'))void c0?.savePreferences?.({openSections:[...open,'bits-placement']}).catch(()=>{});ctx.go('settings',{group:'bits',detail:'stabilizers'});},
      hintArrange:()=>this.setHint({click:'Drag the four bits to where they sit around her wings',shift:''}),
      ...(()=>{const g=groups.find(x=>x.effect?.enabled),def=g?TOKEN_EFFECT_PROGRAMS.find(p=>p.id===g.effect.id):null;
        return {fieldOn:!!g,fieldChip:def?`${def.label} · Stop`:'',
          stopField:()=>{if(!g)return;c.bitGroup=g.id;void ctx.run('bitEffect',{group:g.id,patch:{id:g.effect.id,enabled:false}});ctx.message((def?.label??'Field')+' stopped');},
          hintStopField:()=>this.setHint({click:'Stop projecting '+(def?.label??'the field'),shift:''})};})(),
      sendStyle:'width: 32px; height: 32px; '+(canSend?'color: #f6d9a6; box-shadow: inset 0 0 0 1px #e2c48c, inset 0 0 0 3px #160d13, inset 0 0 10px rgba(226,162,86,.45), 0 0 10px rgba(226,162,86,.3);':'color: #6f5f5c;'),
      send:()=>{if(canSend)ctx.click('dispatchSelectedBits');},
      canClearSel:canSend,clearSel:()=>{void ctx.click('clearDispatchSelection').then(()=>this.forceUpdate());},
      hintClearSel:()=>this.setHint({click:'Clear the selected bits',shift:''}),
      hintSend:()=>this.setHint({click:canSend?dispatch.summary:'Select bits first (Shift-click), then target a token',shift:''}),
      randomOn:randomOn?'true':'false',flowOn:flowOn?'true':'false',randomStyle:tog(randomOn),flowStyle:tog(flowOn),
      toggleRandom:()=>ctx.click('toggleSummonFormation','random'),toggleFlow:()=>ctx.click('toggleSummonFormation','flow'),
      hintRandom:()=>this.setHint({click:(randomOn?'Stop picking':'Pick')+' a random formation on each summon',shift:''}),
      hintFlow:()=>this.setHint({click:(flowOn?'Stop':'Start')+' formations flowing smoothly around '+(token?.document?.name??'Ellie'),shift:''}),
      openTools:e=>this.openMenu('tools',e),hintTools:()=>this.setHint({click:'Bit tools · scan, examine, leave a light, escort, routines and warp',shift:''}),
      undo:()=>ctx.undo(),hintUndo:()=>{const u=ctx.undoInfo();this.setHint({click:u?'Undo: '+u.label.toLowerCase():'Nothing to undo yet',shift:''});},
      panels,wv:'wv'+(this.bump('panel',panelId)%2),showFlight:flightPanel,showGroup:!flightPanel,panelIdx,
      flightRows,
      ...this.heightVals(),
      manNote:model.cfg?.flightManoeuvres===false?'Off · turn them on in Settings › Animation':model.cfg?.reduced?'Off while reduced motion is on':airborne?'Automatic while airborne · banks, brakes, pivots':'Automatic while airborne · take off to see them',
      goMan:()=>ctx.go('settings',{group:'animation'}),
      hintMan:()=>this.setHint({click:'Preview the manoeuvres in place · your screen only'+(airborne?'':' · take off first'),shift:''}),
      previewMan:()=>{const api=ctx.api();if(!token){ctx.message('Pin a character you own first');return;}
        if(!api.manoeuvres?.demo){ctx.message('Reload Foundry to preview the manoeuvres');return;}
        try{api.manoeuvres.demo(token);ctx.message('Watch her wings: bank, bank, brake, pivot, descend');}catch(e){ctx.message(e?.message??String(e));}},
      moreIsOpen:s.more,moreOpen:s.more?'true':'false',moreChev:'chev'+(s.more?' open':''),
      moreSummary:s.more?'Wings · Field':'Status reactions, wing fit, stabilization…',
      toggleMore:()=>this.setState({more:!s.more}),hintMore:()=>this.setHint({click:(s.more?'Fold away':'Show')+' the extra wing and field links',shift:''}),
      moreWings:[['Status reactions','reactions'],['Effect library',null],['Wing fit','size'],['Gestures','animation']].map(([name,g])=>({name,go:()=>g?ctx.go('settings',{group:g}):ctx.go('effects')})),
      moreField:[['Stabilization','bits'],['Bit expression','expression'],['Quality','quality']].map(([name,g])=>({name,go:()=>ctx.go('settings',{group:g})})),
      groupRows,directions,
      effectNote:!group?'':groupHas?(effect?.enabled?`${effectDef?.label??'Effect'} active · visual only`:'Choose an effect, then Activate · visual only'):'Summon bits here to activate',
      activateLabel:effect?.enabled?'Release':'Activate',activateCls:'act '+(groupHas?'on':'off'),
      activate:()=>{if(group&&groupHas)ctx.click('toggleGroupEffect',group.id);},
      hintActivate:()=>this.setHint({click:effect?.enabled?'Release the projected effect':'Project the chosen effect from these bits',shift:''}),
      lookTitle:explain.summary.replace(' · ',', ').replace('HP response','responding to HP'),lookSub:explain.visibility||'Preview privately, or seal it to keep',
      previewLook:()=>ctx.click('previewAnimation','look'),
      sealed,sealLabel:sealed?'Look sealed':'Seal this look',
      sealLook:()=>this.seal(lookKey),
      hintSeal:()=>this.setHint({click:sealed?'Sealed · this look is saved in Saved looks':'Seal and save this look to your Saved looks',shift:''}),
      hintPreview:()=>this.setHint({click:'Preview privately · nothing changes for anyone else',shift:''}),
      pressed,pressAnother:()=>ctx.go('settings'),hintPressAnother:()=>this.setHint({click:'Press any settings group with its flower to keep it here',shift:''}),
      quick,quickNote:quickOn?'Click to play · Shift-click to preview privately':'Open the wings to play these · you can still preview them',
      goTiming:()=>ctx.go('settings',{group:'reactions'}),goLibrary:()=>ctx.go('effects',{cat:'reactions'}),
      hintLightAdj:()=>this.setHint({click:'Light presets, distance and lantern focus',shift:''}),openLight:e=>this.openMenu('light',e),
      openLooks:e=>this.openMenu('looks',e)
    };
  }
  async seal(lookKey){
    const ctx=this.ctx,saved=this.model.savedLooks??[];
    const name=(this.state.lookName||'').trim()||`${this.model.token?.document?.name??'Ellie'} · ${saved.length+1}`;
    ctx.controller.lookName=name;
    const ok=await ctx.click('saveLook');
    if(ok!==false)this.setState({sealedKey:lookKey,lookName:''});
  }
  defaultNote(){
    const m=this.model;if(!m.token)return 'Select or pin a character you own to begin';
    return (m.stateExplanation?.summary??'Ready')+(m.state?.temporaryCondition?.active?' · timed':'');
  }
  pts(w,h,c){const x=(c/w*100).toFixed(2),y=(c/h*100).toFixed(2);return x+' 0,100 0,100 '+(100-y)+','+(100-x)+' 100,0 100,0 '+y;}

  /** Flight feel: her flying height (real elevation or the look alone). */
  heightVals(){
    const ctx=this.ctx,token=this.model.token,state=this.model.state;
    if(!token||!flightFeelEnabled())return {showHeight:false};
    const doc=token.document,fs=readFlightFeel(doc),flying=!!state?.airborne,auto=fs.takeoffElevation;
    // (beta.32) By default her height is her token's elevation, which the player
    // sets: the row shows it and its buttons change it. With "Takeoff sets her
    // elevation" on, it is her flying height as before.
    const now=!auto?Number(doc.elevation)||0:flying?feelAltitude(doc,fs,steadyMode(state)):fs.altitude,api=ctx.api();
    const go=(label,opts)=>ctx.call(label,()=>api.altitude(token,opts));
    return {showHeight:true,heightNow:`${Math.round(now)} ft`,
      heightNote:!auto?'Her elevation':flying?'Elevation':'At takeoff',
      // The presets set her chosen height (Hover and Fly fly at it; with height
      // following the mode, the other modes scale from it).
      heightOpts:Object.entries(ALTITUDE_PRESETS).map(([id,ft])=>{const on=auto?fs.altitude===ft:Math.round(now)===ft;return {name:cap(id),on:on?'true':'false',cls:seg(on),
        pick:()=>ctx.call(`${cap(id)} · ${ft} ft`,()=>auto?api.setFlightFeel(token,{altitude:ft}):api.altitude(token,{to:ft})),
        enter:()=>this.setHint({click:!auto?`Set her token’s elevation to ${ft} ft`:`${flying?'Fly at':'Take off to'} ${ft} ft${fs.heightByMode?' · other flight modes scale from it':''}`,shift:''})};}),
      heightUp:()=>go('Higher',{by:5}),heightDown:()=>go('Lower',{by:-5}),
      hintHeightUp:()=>this.setHint({click:!auto?'Raise her token’s elevation 5 ft':flying?'Climb 5 ft':'Take off 5 ft higher',shift:''}),hintHeightDown:()=>this.setHint({click:!auto?'Lower her token’s elevation 5 ft':flying?'Descend 5 ft':'Take off 5 ft lower',shift:''}),
      goFeel:()=>ctx.go('settings',{group:'feel'}),
      shieldOn:wingShieldRaised(doc,fs)?'true':'false',shieldCls:'tag'+(wingShieldRaised(doc,fs)?' on':''),
      toggleShield:()=>ctx.call(wingShieldRaised(doc,fs)?'Wing shield lowered':'Wing shield raised',()=>api.wingShield(token,!wingShieldRaised(doc,fs))),
      hintShield:()=>this.setHint({click:'Wing shield · her wings sweep forward into a hardlight barrier',shift:''})};
  }
  menuVals(){
    const s=this.state,ctx=this.ctx,model=this.model,state=model.state,token=model.token,api=ctx.api();
    const menu=s.menu;
    if(!menu)return {menuOpen:false,hvShow:false,mLight:false,mTools:false,mField:false,mCond:false,mLooks:false,closeMenu:()=>this.closeMenu(),hvLeave:()=>{}};
    const place=this.placeMenu(menu);
    const hvSet=(kind,id,name)=>this.setState({hov:{kind,id,name},hvk:(s.hvk||0)+1});
    const hvLeave=()=>this.setState({hint:null,hov:null,hvk:(s.hvk||0)+1});
    const out={menuOpen:true,closeMenu:()=>this.closeMenu(),hvLeave,menuPos:place.pos,beakPos:place.beak,
      mLight:menu==='light',mTools:menu==='tools',mField:menu.startsWith('field:'),mCond:menu==='cond',mLooks:menu==='looks'};
    let hover=null;// {spec,name,desc,label,static:[pose],light}

    // Light ---------------------------------------------------------------
    if(menu==='light'){
      const lantern=normalizeLantern(state?.requested?.lantern??state?.lantern??{}),beam=lantern.enabled;
      const req=state?.requested??{},units=token?.document?.parent?.grid?.units||'ft';
      const live={intensity:beam?lantern.intensity:req.lightIntensity??state?.light?.intensity??1,bright:beam?lantern.bright:req.lightBright??state?.light?.bright??model.cfg?.lightBright??5,dim:beam?lantern.dim:req.lightDim??state?.light?.dim??model.cfg?.lightDim??15,width:lantern.width};
      const cur={...live,...s.light};
      const matches=id=>{try{const p=lightPreset(lantern,id);return ['intensity','bright','dim'].every(k=>Math.abs((p[k]??0)-(cur[k]??0))<.01)&&(!beam||Math.abs(p.width-cur.width)<1);}catch{return false;}};
      const presetId=Object.keys(LIGHT_PRESET_LABELS).find(matches)??null;
      const slot=s.lightSlot??presetId??'travel';
      out.lightMode=beam?'Lantern':(state?.requested?.lightEnabled??state?.light?.enabled)?'Circle':'Unlit · edits the next light';
      out.lightPresets=Object.entries(LIGHT_PRESET_LABELS).map(([id,name])=>{const on=presetId===id;return {name,note:PRESET_NOTES[id],icon:PRESET_ICONS[id],cls:'feel mini'+(on?' on':''),ink:on?'#f6e7d2':'#cfae76',
        pick:()=>{this.setState({light:null,lightSlot:id});ctx.call(`${name} light`,()=>api.applyLightPreset(token,id));},
        enter:()=>{this.setHint({click:name+' · sets brightness, distances and beam together',shift:''});hvSet('light',id,name);}};});
      const commit=(key,value)=>{
        if(beam)return ctx.run('lantern',{[key]:value});
        return ctx.run(key==='intensity'?'lightIntensity':key==='bright'?'lightBright':'lightDim',value);
      };
      const sl=(k,name,min,max,step,fmt,dim)=>{const v=cur[k]??min;return {name,min,max,step,value:v,pct:Math.round((v-min)/(max-min)*100),display:fmt(v),rowStyle:dim?'opacity: .45; pointer-events: none':'',
        onInput:e=>{const nv=Number(e.target.value);if(e.type==='change'){this.setState({light:null});void commit(k,nv);}else this.setState({light:{...s.light,[k]:nv}});}};};
      out.lightSliders=[sl('intensity','Brightness',0,1,.05,v=>Math.round(v*100)+'%'),sl('bright','Bright distance',0,120,1,v=>v+' '+units),sl('dim','Dim distance',0,120,1,v=>v+' '+units),sl('width','Lantern beam',15,180,5,v=>Math.round(v)+'°',!beam)];
      const aiming=!!(state?.lantern?.aiming??api.isLanternAiming?.(token));
      const lock=lantern.lock??null;
      const focus=aiming?'Mouse':lock?.type==='token'?'Target':lock?.type==='point'?'Point':'Hold';
      const target=[...(globalThis.game?.user?.targets??[])][0]??null;
      // Point: click a visible spot on the canvas, then confirm (beta.21, from the classic light popover)
      const pickPoint=()=>{
        if(!beam){ctx.message('Light the lantern first · Shift-click the light');return;}
        if(!api.lockLantern)return;
        const tui=ctx.controller?.toolUI;try{tui?.preview?.cancel?.();tui?.locate?.(false);}catch{}
        const handle=startLanternLockPicker({document:globalThis.document,source:token,onConfirm:point=>api.lockLantern(token,point),onError:e=>ctx.fail(e),onClose:()=>{if(tui&&tui.preview===handle)tui.preview=null;ctx.refresh();}});
        if(tui)tui.preview=handle;ctx.message('Click a visible point, then confirm');
      };
      out.focusOpts=[['Mouse','Aim the lantern with your mouse'],['Hold','Hold its current direction'],['Point','Keep it on a spot you choose on the map'],['Target','Keep it on your targeted token']].map(([n,tip])=>({name:n,on:focus===n?'true':'false',cls:seg(focus===n),
        pick:()=>{if(n==='Mouse'){if(!aiming)ctx.click('lanternAim');}
          else if(n==='Hold'){if(aiming)ctx.click('lanternAim');else if(api.unlockLantern)ctx.call('Direction held',()=>api.unlockLantern(token));}
          else if(n==='Point')pickPoint();
          else{if(!target){ctx.message('Target a visible token first');return;}ctx.call('Lantern follows your target',()=>api.lockLantern(token,target));}},
        enter:()=>this.setHint({click:tip+(beam?'':' · applies when the lantern is lit'),shift:''})}));
      out.lockNote=!beam?'':state?.lantern?.lockStatus==='unavailable'&&lock?'Subject out of sight · holding direction':lock?.type==='token'?'Following a visible subject':lock?.type==='point'?'Focused on a point on the map':aiming?'Following your mouse':'Direction held';
      out.hasLockNote=!!out.lockNote;
      out.saveLight=()=>ctx.call(`${LIGHT_PRESET_LABELS[slot]} preset saved`,()=>api.saveLightPreset(token,slot));
      out.resetLight=()=>ctx.call(`${LIGHT_PRESET_LABELS[slot]} preset reset`,()=>api.resetLightPreset(token,slot));
      out.lightNote=presetId?`${LIGHT_PRESET_LABELS[presetId]} · saves to this slot`:`Your own · saves into ${LIGHT_PRESET_LABELS[slot]}`;
      const hv=s.hov?.kind==='light'?lightPreset(lantern,s.hov.id):cur;
      hover={spec:{kind:'wing',selection:{kind:'pose',id:state?.effective?.pose??'neutral'}},name:s.hov?.kind==='light'?s.hov.name:(presetId?LIGHT_PRESET_LABELS[presetId]:'Your light'),
        desc:`${Math.round((hv.intensity??1)*100)}% · bright ${hv.bright} ${units} · dim ${hv.dim} ${units}`,light:hv,hovering:s.hov?.kind==='light',pose:state?.effective?.pose};
    }

    // Bit tools -------------------------------------------------------------
    if(menu==='tools'){
      const tools=ctx.controller.toolUI?.state?.(token)??{},jobs=tools.tasks??tools.jobs??[],job=jobs[0];
      const available=tools.available??STATIONS;
      const use=s.useBits??STATIONS.map(id=>(ctx.controller.dispatchSelectedBits?.length?ctx.controller.dispatchSelectedBits.includes(id):available.includes(id)));
      const chosen=STATIONS.filter((id,i)=>use[i]);
      const useBits=use.map((on,i)=>({on:on?'true':'false',label:'Use bit '+ORD[i],fill:on?M:'#120a0f',stroke:on?'#f0a6e4':'#8a6d45',pick:()=>{const u=use.slice();u[i]=!u[i];this.setState({useBits:u});}}));
      const n=chosen.length,count=n?n+(n===1?' bit':' bits'):'pick at least one';
      out.tasks=TASKS.map(t=>{
        if(t.direct)return {...t,isOpen:false,open:'false',wrapCls:'taskwrap',pick:()=>void this.runTool(t.id),enter:()=>this.setHint({click:t.name+' · '+t.sub.toLowerCase(),shift:''}),opts:[],useBits:[],useNote:'',begin:()=>{}};
        const on=s.task===t.id,cur=s.taskOpt[t.id]??t.opts[0];
        return {...t,isOpen:on,open:on?'true':'false',wrapCls:'taskwrap'+(on?' on':''),pick:()=>this.setState({task:on?null:t.id}),enter:()=>this.setHint({click:t.name+' · '+t.sub.toLowerCase(),shift:''}),
          opts:t.opts.map(o=>({name:o,on:o===cur?'true':'false',cls:seg(o===cur),pick:()=>this.setState({taskOpt:{...s.taskOpt,[t.id]:o}})})),
          useBits,useNote:t.id==='parkLight'?(n?'first selected bit':'pick one'):count,
          begin:()=>this.beginTask(t.id,cur,chosen)};});
      out.hasWork=!!job;
      if(job){
        const name=job.name??({areaScan:'Area scan',creatureScan:'Creature examination',parkLight:'Parked light'}[job.mode??job.kind]??'Bit task');
        const bitsN=(job.assignedBits??job.bits??[]).length;
        out.workTitle=`${name} · ${bitsN} ${bitsN===1?'bit':'bits'}${job.status==='returning'?' · returning':job.paused?' · paused':''}${jobs.length>1?` · +${jobs.length-1} more`:''}`;
        out.workBar='bar'+(job.paused?' paused':'');out.workPauseLabel=job.paused?'Resume':'Pause';
        out.toggleWork=()=>ctx.call(job.paused?'Work resumed':'Work paused · bits hold still',()=>api.setPaused(token,!job.paused,{id:job.id}));
        out.returnWork=()=>ctx.call('Task ending · instruments returning',()=>api.stop(token,{id:job.id}));
      }
      out.toolsNote=tools.undo?.available?`Undo: ${tools.undo.label??'last bit command'}`:'Thought previews appear on the map first';
      out.fullTools=e=>{this.closeMenu();ctx.openFullTools(e);};
    }

    // Field picker --------------------------------------------------------------
    if(menu.startsWith('field:')){
      const i=Number(menu.slice(6)),d=this.fieldDef(i);
      out.pickTitle=d.title;
      out.pickOpts=d.opts.map(([id,name,desc])=>{const on=d.value===id;
        return {name,desc,on:on?'true':'false',isOn:on,hasThumb:!!d.thumbs,noThumb:!d.thumbs,thumb:d.thumbs?d.art(id):'',gem:on?M:'#120a0f',cls:'opt'+(on?' on':''),
          enter:()=>{this.setHint({click:'Choose '+name+' · '+String(desc).toLowerCase(),shift:''});hvSet('field',id,name);},
          pick:()=>{this.closeMenu();ctx.run(d.cmd,id);}};});
      out.pickLibrary=()=>{this.closeMenu();if(i===1)ctx.go('effects',{cat:'poses'});else if(i===3)ctx.go('effects',{cat:'conditions'});else ctx.click('previewAnimation',['mode','pose','float','look'][i]);};
      out.pickLibraryLabel=i===1||i===3?'Browse and preview in the library':'Open the full preview library';
      const id=s.hov?.kind==='field'?s.hov.id:d.value,opt=d.opts.find(o=>o[0]===id);
      hover={spec:{kind:'wing',selection:this.fieldSelection(d,id),ground:d.kind==='mode'||d.kind==='float'},name:opt?.[1]??cap(id),desc:opt?.[2]??'',hovering:s.hov?.kind==='field',pose:d.kind==='pose'?id:state?.effective?.pose,cond:d.kind==='condition'?id:null};
    }

    // Timed condition --------------------------------------------------------
    if(menu==='cond'){
      const cs=s.condSel??(state?.effective?.condition&&COND_IDS.includes(state.effective.condition)?state.effective.condition:'glitching');
      const dur=s.condDur;
      out.condOpts=COND_IDS.map(id=>({name:CONDITION_LABELS[id],on:cs===id?'true':'false',cls:'copt'+(cs===id?' on':''),pips:pips(SEVERITY[id]),
        pick:()=>this.setState({condSel:id}),enter:()=>hvSet('cond',id,CONDITION_LABELS[id])}));
      out.durOpts=DURATIONS.map(([label])=>({name:label.replace('minutes','min').replace('minute','min'),on:dur===label?'true':'false',cls:seg(dur===label),pick:()=>this.setState({condDur:label})}));
      out.condApplyLabel='Show '+CONDITION_LABELS[cs];
      out.condApply=()=>{const ms=DURATIONS.find(d=>d[0]===dur)?.[1]??60000;this.closeMenu();
        ctx.call(`Wings show ${CONDITION_LABELS[cs]}${ms?' for '+dur.toLowerCase():' until cleared'}`,()=>ms?api.conditionFor(token,cs,ms):api.setCondition(token,cs));};
      out.condAuto=()=>{this.closeMenu();ctx.call('Wings follow her real state again',async()=>{await api.clearConditionOverride?.(token);await api.setState(token,{condition:'auto',autoHP:true});});};
      const id=s.hov?.kind==='cond'?s.hov.id:cs;
      hover={spec:{kind:'wing',selection:{kind:'condition',key:id,id:'default'}},name:CONDITION_LABELS[id],desc:CONDITION_HINTS[id]??'',hovering:s.hov?.kind==='cond',label:s.hov?.kind==='cond'?null:'Selected',cond:id};
    }

    // Saved looks ------------------------------------------------------------
    if(menu==='looks'){
      const list=this.lookList();
      out.looks=list.map((l,i)=>({name:l.name,meta:l.personal?'Personal · '+(l.look?.pose?POSE_LABELS[l.look.pose]??l.look.pose:'saved look'):l.description??'Built-in look',
        applyLabel:'Wear',canDelete:l.personal,
        sealStyle:'width: 34px; height: 34px; flex-shrink: 0; transform: rotate('+([-8,6,-3,4,-6][i%5])+'deg); filter: drop-shadow(0 2px 3px rgba(0,0,0,.6))'+(l.personal?'':'; opacity: .8'),
        enter:()=>hvSet('look',l.id,l.name),preview:()=>hvSet('look',l.id,l.name),
        apply:()=>{this.closeMenu();ctx.click(l.personal?'applySavedLook':'applyBuiltinLook',l.id);},
        remove:()=>ctx.click('deleteLook',l.id)}));
      out.lookName=s.lookName;out.lookNamePlaceholder=`Name this look (${model.token?.document?.name??'Ellie'} · ${(model.savedLooks?.length??0)+1})`;
      out.onLookName=e=>this.setState({lookName:e.target.value.slice(0,40)});
      out.lookNameKey=e=>{if(e.key==='Enter'){e.preventDefault();void this.seal(JSON.stringify(state?.requested??null));}e.stopPropagation();};
      out.looksNote=(model.savedLooks?.length??0)>=12?'Twelve personal looks saved · remove one to seal another':'Personal looks follow you between browsers · the rest are built in';
      const l=s.hov?.kind==='look'?list.find(x=>x.id===s.hov.id):null;
      if(l){const look=l.look??{};hover={spec:{kind:'wing',selection:{kind:'pose',id:look.pose??'neutral',request:{effectStyle:look.effectStyle,effectStyles:look.effectStyles,gemMotion:look.gemMotion,v7:look.v7},appearance:look.options}},name:l.name,desc:l.description??'Personal look',hovering:true,pose:look.pose};}
      else hover={spec:{kind:'wing',selection:{kind:'look',id:'current'}},name:'Your look now',desc:'Hover a look to try it on',hovering:false,pose:state?.effective?.pose};
    }

    // Hover card ---------------------------------------------------------------
    if(hover){
      const hvW=menu==='cond'?172:menu.startsWith('field')?200:184;
      const right=place.left+place.w+10,before=place.left-hvW-10;
      // beside the menu where there's room; else over the right end of the list, clear of the names on its left
      const left=right+hvW<=590?right:before>=10?before:590-hvW;
      const failed=ctx.previewFailed('hover');
      out.hvShow=true;out.hvPos=`left: ${left}px; top: ${place.top}px; width: ${hvW}px`;
      out.hvSwap='hv-sw'+((s.hvk||0)%2);out.hvLive=!failed;out.hvStatic=failed;
      out.hvImg=`${ctx.root}/assets/hud/pose-${POSE_ART[hover.pose]??CONDITION_ART[hover.cond]??'neutral'}.svg`;out.hvWing='k-breathe';out.hvRig='h-bob';out.hvShadow='';
      out.hvName=hover.name;out.hvDesc=hover.desc;
      out.hvLabel=hover.hovering?'Trying on':hover.label??'Current';out.hvChipCls=hover.hovering?'live':'';
      out.hvFoot=hover.hovering?(menu==='looks'?'Wear to keep it · move away to put it back':'Click to keep · move away to put it back'):'Hover a choice to try it on her token';
      const lt=hover.light;out.hvHasLight=!!lt;
      out.hvLightOp=lt?(0.35+(lt.intensity??1)*.6).toFixed(2):0;out.hvBrightR=lt?Math.min(70,14+lt.bright*1.3):0;out.hvDimR=lt?Math.min(86,20+lt.dim*1.25):0;
      // (beta.35) The hover card plays from the Effects stage's frame cache: painted
      // once as it first plays (one frame a tick, no more than before), then replayed.
      this.previewSpecs={hover:{...hover.spec,cache:'live'}};
    }else{out.hvShow=false;this.previewSpecs={};}
    return out;
  }
  async beginTask(kind,option,chosen){
    const ctx=this.ctx,model=this.model,token=model.token,api=ctx.api(),ui=ctx.controller.toolUI;
    if(!chosen.length){ctx.message('Pick at least one bit for this task');return;}
    this.closeMenu();
    try{
      if(kind==='areaScan')ui.begin('areaScan',option==='Around Ellie'?{bits:chosen,followSource:true,radiusFeet:15}:{bits:chosen});
      else if(kind==='creatureScan'){
        if(api.setExaminationMovement){const want=option==='Previous'?'classic':'deliberate';if((ui.state(token).examinationMovement??'deliberate')!==want)await api.setExaminationMovement(token,want);}
        ui.begin('creatureScan',{bits:chosen});
      }
      else if(kind==='parkLight')ui.begin('parkLight',{bits:chosen.slice(0,1),pickTarget:option==='On target'});
      else if(kind==='escort'){
        const target=[...(globalThis.game?.user?.targets??[])][0];if(!target){ctx.message('Target a visible token first, then Bind');return;}
        await ctx.run('assignBits',{target,bits:chosen});
      }
    }catch(error){ctx.fail(error);}
  }
  /** Routines and warp start at once; each asks for its token or spot on the canvas. */
  async runTool(id){
    const ctx=this.ctx,token=this.model.token;this.closeMenu();
    if(!token){ctx.message('Pin a character you own first');return;}
    try{
      if(id==='warp'){const api=ctx.api();if(!api.warp)throw new Error('Reload Foundry to warp from the HUD');ctx.message(await api.warp(token)===false?'Warp cancelled':'Stepping through');return;}
      if([...(globalThis.game?.user?.targets??[])].filter(t=>t!==token).length!==1)ctx.message('Now click the token on the canvas · Esc cancels');
      if(await startRoutine(token,id)!==false)ctx.message(ROUTINES[id].name+' · playing for everyone');
    }catch(error){ctx.message(error?.message??String(error),true);}
  }
}
const GOLDISH='#cfae76';
