/** Yvaelle’s Toolbox v11 · the feature registry.
 *
 * The one place that declares every v11 feature: its parts, its visual
 * choices (pickers), their defaults and where each value is kept. Every later
 * phase reads its switches from here (isOn / partOn / choice); the Keepsake
 * Settings tab draws its v11 rows from here too, so the settings and the
 * code can never disagree.
 *
 * Scope (shown as a badge on every row):
 *   'token' Her token  · saved on her token (flags.filament-flight.v11), everyone sees it
 *   'me'    Just me    · this browser (client setting v11Client)
 *   'gm'    Everyone · GM · the world (world setting v11World, the GM writes it)
 * A part may differ from its feature (Others glimpse the flicker is the GM's).
 *
 * Stored values are diffs: a value equal to its default is never written, so
 * a v10 user (nothing stored) gets exactly the defaults below, and a token
 * stays small. Experimental extras are "Temporary / experimental", off.
 *
 * Pure module: no Foundry globals at import time. */
export const ID='filament-flight';
export const V11_FLAG='v11';
export const CLIENT_KEY='v11Client';
export const WORLD_KEY='v11World';
export const EXPERIMENTAL_LABEL='Temporary / experimental';

const O=(...a)=>a.map(([id,label,thumb])=>thumb?{id,label,thumb}:{id,label});
const part=(id,name,def=true,x={})=>({id,name,type:'switch',def,...x});
const feature=(id,where,name,desc,scope,def,x={})=>({id,where,name,desc,scope,type:'switch',def,v11:true,...x});
const picker=(id,name,desc,scope,opts,def,x={})=>({id,name,desc,scope,type:'picker',opts,def,v11:true,...x});

export const V11_FEATURES=Object.freeze([
  /* ---------------- Her ---------------- */
  feature('tokenLayer','her/token','Token layer','Her portrait and frame move and light with her wings','token',true,{thumb:'card_token',
    pickers:[picker('tokenFrame','Frame style','The drawn frame’s style (used when “Drawn frame over her token” is on)','token',O(['keepsake','Keepsake','frame_keepsake'],['vesper','Vesper','frame_vesper'],['reliquary','Reliquary','frame_reliquary'],['filament','Filament','frame_filament']),'keepsake'),
      // (test.9) her token's shape profile (v11/token-shape.mjs): measured from her art, or set by hand
      picker('tokenFit','Fit to her token','Automatic measures her token art (its shape, edge and border) so the rim lights and the moving picture follow it. Manual uses the shape and border below.','token',O(['auto','Automatic (measure her art)'],['manual','Manual']),'auto',{plain:true,readout:'tokenShape'}),
      picker('tokenFitShape','Manual fit · shape','Used when “Fit to her token” is Manual','token',O(['round','Round'],['square','Square'],['art','Her art’s own edge']),'round',{plain:true}),
      picker('tokenFitBorder','Manual fit · border thickness','Of her radius. Used when “Fit to her token” is Manual','token',O(['0','No border'],['4','4 %'],['6','6 %'],['8','8 %'],['10','10 %'],['12','12 %'],['15','15 %'],['20','20 %']),'10',{plain:true}),
      picker('tokenFitInset','Manual fit · border starts','How far in from her edge the border begins. Used when “Fit to her token” is Manual','token',O(['0','At her edge'],['2','2 % in'],['4','4 % in'],['6','6 % in'],['10','10 % in']),'0',{plain:true})],
    parts:[part('frame','Drawn frame over her token (off: her token’s own ring is used)',false),part('frameStates','Frame states · tarnish when badly hurt, warmth after a heal'),part('breathe','Breathing'),part('lean','Lean with her bank and pitch'),
      part('glance','Glance toward what she watches'),part('wingLight','Wing light on her face and rim'),part('nearLight','Nearby light (heals, prayer, allies)'),part('recoil','Hit recoil'),
      part('woundTint','Damage-type tint and rim flush'),part('heal','Heal glow, giving and receiving'),part('fear','Fear · cooler, a slight shrink-in'),part('ko','Unconscious · dims and greys'),
      part('emotes','Emote support (Bow, Curious, Pray, Sigh, Shrug)'),part('hidden','Hidden · drains to an outline (owner and GM)')]}),
  // (12.1.0-beta.1) the mode now does what it says: her wings are away while it is on (state.mjs). Its part "Bits still hold
  // their stations" is gone: nothing ever read it, and without wings her bits have no stations to hold (they draw in close).
  feature('wingless','her/wingless','Wingless mode','Put the wings away for good: she still flies and keeps her bits (drawn in close), and her token carries every moment her wings would','token',false,{thumb:'card_wingless',
    parts:[part('winglessFallback','Wing moments fall back to her token · off: they are not shown at all')]}),
  feature('moodWeather','her/moods','Mood weather','Her wing colour drifts with her state, seeping from the shoulders out','token',true,{thumb:'card_mood',
    parts:[part('moodFrightened','Frightened'),part('moodAfterglow','After a big heal'),part('moodDoomed','Doomed or Wounded 2+'),part('moodQuickened','Quickened or Hasted'),part('moodSickened','Sickened')]}),
  feature('dieMoods','her/moods','Die-roll moods','Natural 20: a bit loops · natural 1: a bit ducks behind her wing','token',true,{thumb:'card_die',
    parts:[part('dieNat20','Natural 20 loop'),part('dieNat1','Natural 1 duck and peek')]}),
  feature('heroSpent','her/moods','Hero Point spent','A petal of light leaves her when she spends one','token',true,{thumb:'card_hero',
    parts:[part('heroWings','Her wings draw in, then one full beat'),part('heroBits','The bits gather in'),part('heroLight','A rose-gold light at her heart and frame')]}),
  // (13.0.0-beta.1) The Heart Turned: a curse the GM lays on her from a wheel round the pointer; she rolls which of six states takes her (or one is
  // laid on her outright) and for how many Spans. Shown to her and the GM only (v13/curse-runtime.mjs).
  feature('curse','her/moods','The Heart Turned (curse)','The GM lays a curse on her from a wheel round the pointer (Configure Controls › Curse wheel; none is set as it comes). She rolls which of six states takes her, or one is laid on her outright, and for how many Spans. Only she and the GM see it','gm',true,{
    aka:'curse wheel heart turned protective lusty needy resentful fearful intrusive spans roll of faith gm',
    parts:[part('curseStartMin','Arrive minimised · a curse comes as the small card; the full view only when you open it',false,{scope:'me'}),part('curseBlur','Blur the game behind the full view',true,{scope:'me'}),
      part('curseMarkOpen','The mark opens the full view when pressed',true,{scope:'me'}),part('curseGmNote','GM · a small note when she has rolled, and for how long',true,{scope:'me'}),
      part('curseChat','A whispered line in chat for her and the GM once the Spans are set',true,{note:'GM'})]}),
  /* ---------------- Flight ---------------- */
  feature('wallFold','flight/world','Wall fold','Her wings fold in as she passes close to a wall','token',true),
  feature('lightCatch','flight/world','Light catch','Her filaments catch nearby light sources','token',true),
  feature('wingShadowTokens','flight/world','Wing shadow on tokens','Her wing shadow falls across tokens beneath her','token',true,{thumb:'card_world'}),
  feature('shieldStyles','flight/world','Shield styles','Other looks for her wing shield. Each is raised, struck and lowered like the weave','token',true,{
    pickers:[picker('shieldStyle','Shield','How her shield looks','token',O(['weave','Weave · a band of woven filament between her and the blow','shield_weave'],['scalemail','Scale mail · plates cascade down her and flip into place; works with her wings away','shield_scalemail'],['rotor','Rotor · her four bits spin up into a disc of light; works with her wings away','shield_rotor'],['wingwrap','Wing wrap · her wings fold about her like arms, plated','shield_wingwrap']),'weave')]}),
  feature('landingStyles','flight/world','Landing styles','What her wings do once she is down. The landing itself stays as it is; with a style, her wings stay out through it and are recalled after','token',true,{
    pickers:[picker('landingStyle','Landing','How her wings are put away','token',O(['classic','Classic · they fold away as she comes down','landing_classic'],['powerdown','Power down · they tear, fall shut to a line of light and go out','landing_powerdown'],['foldaway','Fold away · they close like a fan from the bottom','landing_foldaway'],['reelin','Reel in · her filaments run back into her shoulders','landing_reelin']),'classic')]}),
  // (12.0.0-beta.6) the Decoy: a copy of her standing at a spot (she warps away and it stays, or her bits cast it), in a hardlight or a normal look
  feature('decoy','flight/world','Decoy','A copy of her at a spot: she warps away and it stays, or her bits fly out and cast it. Dismiss it or strike it and it comes apart','token',true,{
    pickers:[picker('decoyLook','Decoy look','How a new decoy looks (it can be switched while it stands)','token',O(['hardlight','Hardlight · plainly a projection: her picture in magenta light, scan lines, a slight flicker'],['normal','Normal · her picture as it is; only you and the GM see the small mark under it']),'hardlight',{aka:'decoy copy double illusion projection'})]}),
  feature('shadowHeight','flight/world','Shadow shrinks with height','The higher she flies, the smaller and fainter her shadow on the ground. Off: it spreads wider and softer instead','token',true),
  /* ---------------- Combat & damage ---------------- */
  feature('wounds','combat/wounds','Wounds by damage type','A hit leaves a mark in the type’s own language, then heals over','token',true,{thumb:'card_wounds',chips:true,
    pickers:[picker('elecStyle','Electricity style','Shown when Electricity is on','token',O(['a','A · Gilded current','elec_a'],['b','B · Violet crackle','elec_b']),'b')],
    parts:['Slashing','Piercing','Bludgeoning','Fire','Cold','Electricity','Acid','Poison','Force','Mental','Void'].map(t=>part('wound'+t,t)).concat([part('woundOther','Other types use a soft generic mark')])}),
  feature('persistent','combat/wounds','Persistent damage','A low, cheap effect for as long as it lasts','token',true,{thumb:'card_persist',chips:true,
    parts:['Bleed','Fire','Acid','Cold','Electricity','Poison','Force','Mental','Sonic','Spirit','Vitality','Void','Piercing','Slashing','Bludgeoning','Precision'].map(t=>part('persist'+t,t)).concat([part('persistFallback','Fallback for any other type')])}),
  feature('dyingStages','combat/wounds','Dying stages','On her fallen pose, each Dying value reads at a glance','token',true,{thumb:'card_dying',
    parts:[part('dying1','Dying 1 · she huddles'),part('dying2','Dying 2 · wings dim to embers'),part('dying3','Dying 3 · a bit flickers out'),part('dyingRecover','Recovery · the light rekindles')]}),
  feature('lastLight','combat/wounds','Last light','Knocked out in the air: the bits catch her and lower her down','token',true,{thumb:'card_lastlight',
    parts:[part('lastCatch','The catch'),part('lastLower','Lowered to the ground'),part('lastVigil','Bits keep vigil')]}),
  feature('lowHpFatigue','combat/wounds','Low-HP fatigue','Below a quarter HP her wingbeats labour and the light thins','token',true,{thumb:'card_fatigue'}),
  feature('invisLooks','combat/stealth','Invisibility looks','Owner and GM keep a ghost of her; others see nothing','token',true,{thumb:'card_invis',
    pickers:[
      picker('invisSpell','Invisible (spell or condition)','The look for ordinary invisibility','token',O(['classic','Classic drain','invis_classic'],['a','Cloak A · refraction','invis_a'],['b','Cloak B · hardlight panels','invis_b'],['c','Cloak C · scan dissolve','invis_c'],['plumage','Plumage · she turns away feather by feather','invis_plumage'],['ink','Ink · she bleeds away like ink in water','invis_ink'],['iris','Iris · a hardlight aperture closes over her','invis_iris'],['starfall','Starfall · she draws in to small stars that go out','invis_starfall'],['ribbons','Ribbons · she unwinds in slanted ribbons','invis_ribbons'],['halftone','Halftone · a screen of dots that shrink away','invis_halftone'],['curtain','Curtain · two wing-shaped veils close over her','invis_curtain'],['eclipse','Eclipse · a shadow crosses her','invis_eclipse'],['aurora','Aurora · her light is drawn upward in streaks','invis_aurora']),'classic',{aka:'shadow wings hidden ghost drain'}),
      picker('invisSkin','Invisibility skin (augment)','The look for her tech cloak','token',O(['classic','Classic drain','invis_classic'],['a','Cloak A · refraction','invis_a'],['b','Cloak B · hardlight panels','invis_b'],['c','Cloak C · scan dissolve','invis_c'],['plumage','Plumage · she turns away feather by feather','invis_plumage'],['ink','Ink · she bleeds away like ink in water','invis_ink'],['iris','Iris · a hardlight aperture closes over her','invis_iris'],['starfall','Starfall · she draws in to small stars that go out','invis_starfall'],['ribbons','Ribbons · she unwinds in slanted ribbons','invis_ribbons'],['halftone','Halftone · a screen of dots that shrink away','invis_halftone'],['curtain','Curtain · two wing-shaped veils close over her','invis_curtain'],['eclipse','Eclipse · a shadow crosses her','invis_eclipse'],['aurora','Aurora · her light is drawn upward in streaks','invis_aurora']),'c',{aka:'cloak tech shadow wings'}),
      picker('invisSweep','Sweep direction','Where a tech cloak starts; uncloaking runs back the other way','token',O(['left','From the left','sweep_left'],['right','From the right','sweep_right'],['top','From the top','sweep_top'],['bottom','From the bottom','sweep_bottom']),'left',{svg:true})],
    // (11.0.0-test.7) what her owner or a GM sees of her while she is hidden: kept on this browser (the GM and her player choose for themselves)
    parts:[{id:'ownerView',name:'What you see of her while hidden',desc:'For her owner and the GM. Faint: her own look, as faint as her token’s ghost · Gone: what other players see (nothing) · Threads: the drained outline of her filaments',
      type:'choice',opts:O(['faint','Faint'],['gone','Gone'],['threads','Threads']),def:'faint',scope:'me',v11:true}]}),
  // (12.0.0-beta.5) Cloak depth: how fast her cloak sweeps, a look that changes each time, an attack that breaks her Fade. All of it is hers to
  // switch; as it comes (normal speed, both parts off) nothing plays differently from beta.4.
  feature('cloakDepth','combat/stealth','Cloak depth','How fast her cloak sweeps, a look that changes each time, and an attack that breaks her Fade','token',true,{thumb:'card_invis',
    pickers:[picker('cloakSpeed','Cloak speed','How long her cloak takes to sweep across her (coming back takes as long as going did)','token',O(['slow','Slow · 5.5 s'],['normal','Normal · 3.8 s, as it was'],['quick','Quick · 2.4 s'],['swift','Swift · 1.4 s']),'normal',{aka:'cloak sweep fast slow time'})],
    parts:[part('cloakRotate','A different look each time · her Fade steps through the twelve cloak looks',false),part('cloakAttack','An attack breaks her Fade · her own attack roll brings her back at once, with a flare of her wings',false)]}),
  // (12.0.0-beta.7) the v12 sound set: their own sounds for the v12 effects. Off as it comes; heard only where her sounds are on.
  feature('soundSet','sound/v12','V12 sounds','Their own sounds for the v12 warps, shield styles, landing styles, her cloak and the Decoy. Off: the warps keep the sounds they borrowed and the rest are silent, as before. Heard only where her sounds are on','token',false,{
    aka:'audio sound set warp shield landing cloak decoy style classics hardlight',
    // (12.0.0-beta.10) the set comes in two styles; a slot whose file she set herself is left alone
    pickers:[picker('soundStyle','Sound style','Classics: each sound is modelled on a well-loved sci-fi sound. Hardlight: one shimmer-and-hum family throughout','token',O(['classics','Classics'],['hardlight','Hardlight']),'classics',{plain:true})],
    parts:[part('soundWarps','Warps · Flock, Starfall, Ribbon seam and Prism each have their own'),part('soundShields','Shield styles · Scale mail, Rotor and Wing wrap each have their own'),part('soundLanding','Landing styles · Power down, Fold away and Reel in, as her wings go'),
      part('soundCloak','Cloak · her cloak sweeping across her, going and coming back'),part('soundDecoy','Decoy · cast, left behind, its change of look, and coming apart')]}),
  feature('invisFlicker','combat/stealth','Flicker on hit','While invisible, a hit makes her flicker for a moment','token',true,{thumb:'card_flicker',
    parts:[part('flickerWaver','The flicker · she wavers back toward solid'),part('flickerFringe','Hardlight fringe · magenta one way, gold the other'),
      part('flickerSlip','Slip · a 1 px shift as the cloak loses its lock'),part('flickerTremor','Tremor · a tiny shake in her hover'),
      part('invisFlickerOthers','Others glimpse the flicker',false,{scope:'gm',note:'GM'})]}),
  feature('grappleEscape','combat/grapple','Grapple escape','Plays only while she is actively trying to break free','token',true,{thumb:'card_grapple',
    parts:[part('grappleNarrow','Narrow her wings while grabbed',false),part('grThreads','Threads into the grappler (escape attempts only)'),
      part('grStrain','Strain · her wings draw in, the bits pull and tremble'),part('grSnap','Success · the threads snap, the bits spring home'),part('grFail','Failure · they sag, the threads withdraw')]}),
  feature('spellTraditions','combat/grapple','Spell traditions','Her wings answer each tradition differently','token',true,{thumb:'card_spells',chips:true,
    parts:[part('spArcane','Arcane'),part('spDivine','Divine'),part('spOccult','Occult'),part('spPrimal','Primal')]}),
  /* ---------------- Healing & Medkit ---------------- */
  feature('allyWatch','healing/support','Ally’s-turn watch','On an ally’s turn one bit turns to watch them','token',true,{thumb:'card_watch'}),
  /* ---------------- Emotes & wheel ---------------- */
  feature('emotes','emotes/emotes','Emotes','Small wing and bit gestures she can play from the wheel','token',true,{thumb:'card_emotes',chips:true,
    pickers:[picker('laughStyle','Laugh','Which laugh plays','token',O(['a','A · Soft chuckle','laugh_a'],['b','B · Bright','laugh_b']),'a')],
    parts:[...['Bow','Laugh','Sigh','Shrug','Wave','Cheer','Startle','Comfort','Curious','Pray'].map(t=>part('emote'+t,t)),
      part('emoteChat','/me in chat plays the emote (bows, laughs, sighs…)',false)]}),
  feature('nestedWheel','emotes/wheel','Nested wheel','Rings open inside rings: Her, Bits, Flight, Emotes, Macros','me',true,{thumb:'card_wheel',
    parts:[{id:'arcSize',name:'Options per arc',desc:'How many of your own picks each of Her arcs shows (Flight, Wings, Bits)',type:'choice',opts:O(['4','4 options'],['3','3 options']),def:'4',scope:'me',v11:true},
      {id:'layout',name:'Layout',desc:'Doors: Her · Actions · Bits · Macros, one ring of named gems each, Emote as a single gem inside Her. Classic: Her (three arcs) · Light · Macros · Emotes. Your favourites stay on the main ring in both, and each layout keeps its own picks',type:'choice',opts:O(['doors','Doors · by what it does'],['classic','Classic']),def:'doors',scope:'me',v11:true},
      {id:'look',name:'Gems',desc:'Hardlight: each gem is a pane of light in its door’s colour. Classic: the gold-framed gems the wheel had before',type:'choice',opts:O(['hardlight','Hardlight'],['classic','Classic · gold frames']),def:'hardlight',scope:'me',v11:true},
      {id:'ring',name:'Main ring',desc:'The ring the gems sit on, and how it moves while the wheel is open',type:'choice',opts:O(['halo','Halo and bits · one ring, four small bits circling it'],['twin','Twin filament · two fine lines, a pulse running round each'],['panes','Panes · twelve panes that light in turn'],['woven','Woven light · three glowing threads in counter-flow'],['classic','Classic · the gold and magenta braid']),def:'halo',scope:'me',v11:true},
      {id:'hudOpen',name:'Opening the HUD and her sheet',desc:'Hardlight scan: a magenta edge crosses the window and leaves it behind (about half a second) · the HUD however it is opened, and her Keepsake sheet',type:'choice',opts:O(['scan','Hardlight scan'],['none','No animation']),def:'scan',scope:'me',v11:true},
      {id:'cycleFx',name:'Scrolling over a gem changes its option',desc:'The mouse wheel over a shortcut or one of Her arc gems steps through its options (formations, poses, looks…). Choose how the switch is shown, or turn scrolling off',type:'choice',opts:O(['orbit','Carousel · the whole gem turns round behind'],['slide','Slide behind'],['roll','Roll'],['facet','Facet turn'],['thread','Thread along the ring'],['plain','No animation'],['off','Off · scrolling does nothing']),def:'orbit',scope:'me',v11:true}]}),
  feature('wheelShortcuts','emotes/wheel','Shortcuts','Pin any action to the main ring','me',true),
  // (12.0.0-beta.13) menus on the map, under her decoy and under each job her bits are out on, while a key is held
  feature('fieldMenus','emotes/wheel','Menus on her decoy and bits','Hold the key you set for it (Configure Controls › Menus on her decoy and bits; none is set as it comes): a small menu of gems appears on the map under everything she has sent out, one for each group, with its controls. Her decoy: look, dismiss · a scan: pause, slower, faster, recall · a parked light: call back · bits with another creature: recall · a treatment: stop','me',true,{
    aka:'decoy bits menu controls hold alt highlight recall pause dismiss map',
    parts:[part('fieldAlt','Alt shows them too · while Foundry’s highlight key is held',false)]}),
  feature('macroRing','emotes/wheel','Macros ring','Your own macros on a ring of their own','me',true,{thumb:'card_macros',
    parts:[{id:'macroIcons',name:'Icon library',desc:'Icons offered when you place a macro',type:'choice',opts:O(['keepsake','Keepsake'],['foundry','Foundry'],['both','Both']),def:'keepsake',scope:'me',v11:true}]}),
  /* ---------------- Advanced › Experimental ---------------- */
  feature('xTapestry','advanced/experimental','Tapestry','A woven record of the session in the HUD','me',false,{exp:true,thumb:'card_x_tapestry',
    parts:[part('tapWeave','Weave-in · a new moment is woven in as you watch'),part('tapFold','Fold older sessions to one band each')]}),
  feature('xPetals','advanced/experimental','Milestone petals','A pressed petal for each milestone she reaches','me',false,{exp:true,thumb:'card_x_petals',
    parts:[part('petalsHud','In the HUD’s corner flower'),part('petalsSheet','On her sheet · its flower and the herbarium'),part('petalsGrow','Grow in when one is earned')]}),
  feature('xRecap','advanced/experimental','Recap card','A card summing up the fight, posted to chat','gm',false,{exp:true,thumb:'card_x_recap',
    parts:[part('recapReveal','Reveal on a fresh card'),part('recapShare','Share-size image download')]}),
]);

/** Which phase builds each feature (the registry is complete now; most of the work comes later). */
export const BUILT_IN=Object.freeze({tokenLayer:'11.0.0-test.1',
  invisLooks:'11.0.0-test.2',invisFlicker:'11.0.0-test.2',wingless:'11.0.0-test.2',moodWeather:'11.0.0-test.2',wounds:'11.0.0-test.2',persistent:'11.0.0-test.2',
  dyingStages:'11.0.0-test.2',lowHpFatigue:'11.0.0-test.2',emotes:'11.0.0-test.2',nestedWheel:'11.0.0-test.2',wheelShortcuts:'11.0.0-test.2',macroRing:'11.0.0-test.2',
  // (phase 3a: healing and the bits' jobs)
  allyWatch:'11.0.0-test.3',grappleEscape:'11.0.0-test.3',
  lastLight:'11.0.0-test.3',dieMoods:'11.0.0-test.3',heroSpent:'11.0.0-test.3',spellTraditions:'11.0.0-test.3',
  // (phase 3c: her wings and the world)
  wallFold:'11.0.0-test.3',lightCatch:'11.0.0-test.3',wingShadowTokens:'11.0.0-test.3',shadowHeight:'11.0.0-test.20',shieldStyles:'12.0.0-beta.2',landingStyles:'12.0.0-beta.3',cloakDepth:'12.0.0-beta.5',decoy:'12.0.0-beta.6',soundSet:'12.0.0-beta.7',fieldMenus:'12.0.0-beta.13',curse:'13.0.0-beta.1',
  // (phase 3d: the experimental extras)

  xTapestry:'11.0.0-test.3',xPetals:'11.0.0-test.3',xRecap:'11.0.0-test.3'});

/* ------------------------------------------------------------------ */
/* Index                                                                */
/* ------------------------------------------------------------------ */
export const FEATURES=new Map(V11_FEATURES.map(f=>[f.id,f]));
/** Every switchable or choosable value: key → {kind:'feature'|'picker'|'part', feature, item, scope, def}.
 * Keys: a feature's id, a picker's id, and `feature.part` for a part (part ids may repeat across features). */
export const V11_KEYS=new Map();
for(const f of V11_FEATURES){
  V11_KEYS.set(f.id,{kind:'feature',feature:f,item:f,scope:f.scope,def:f.def});
  for(const p of f.pickers??[])V11_KEYS.set(p.id,{kind:'picker',feature:f,item:p,scope:p.scope??f.scope,def:p.def});
  for(const p of f.parts??[])V11_KEYS.set(`${f.id}.${p.id}`,{kind:'part',feature:f,item:p,scope:p.scope??f.scope,def:p.def});
}
export const partKey=(featureId,partId)=>`${featureId}.${partId}`;

/** Every default, by key. */
export function v11Defaults(){const out={};for(const [k,r] of V11_KEYS)out[k]=r.def;return out;}

/* ------------------------------------------------------------------ */
/* Storage: one nested object per scope, holding only values that       */
/* differ from their default.                                           */
/*   {tokenLayer:false, tokenFrame:'vesper', parts:{tokenLayer:{breathe:false}}} */
/* ------------------------------------------------------------------ */
/** The stored value for a key in one stored object (undefined if not stored). */
export function storedValue(store,key){
  if(!store||typeof store!=='object')return undefined;
  const r=V11_KEYS.get(key);if(!r)return undefined;
  if(r.kind==='part'){const v=store.parts?.[r.feature.id]?.[r.item.id];return valid(r.item,v)?v:undefined;}
  const v=store[key];return valid(r.item,v)?v:undefined;
}
function valid(item,v){
  if(v===undefined||v===null)return false;
  if(item.type==='switch')return typeof v==='boolean';
  if(item.type==='picker'||item.type==='choice')return typeof v==='string'&&item.opts.some(o=>o.id===v);
  return false;
}
/** A copy of `store` with key set to value (removed when it is the default). Pure. */
export function withValue(store,key,value){
  const r=V11_KEYS.get(key);if(!r)throw new Error(`Unknown v11 setting: ${key}`);
  if(value!==undefined&&value!==null&&!valid(r.item,value))throw new Error(`Bad value for ${key}: ${value}`);
  const out=structuredCloneSafe(store);
  const isDef=value===undefined||value===null||value===r.def;
  if(r.kind==='part'){
    const f=r.feature.id;out.parts??={};out.parts[f]??={};
    if(isDef)delete out.parts[f][r.item.id];else out.parts[f][r.item.id]=value;
    if(!Object.keys(out.parts[f]).length)delete out.parts[f];
    if(!Object.keys(out.parts).length)delete out.parts;
  }else if(isDef)delete out[key];else out[key]=value;
  return out;
}
const structuredCloneSafe=s=>s&&typeof s==='object'?JSON.parse(JSON.stringify(s)):{};
/** The Foundry update for a token flag change of key (a `-=` deletion when it goes back to default). */
export function flagUpdate(key,value){
  const r=V11_KEYS.get(key);if(!r)throw new Error(`Unknown v11 setting: ${key}`);
  const base=`flags.${ID}.${V11_FLAG}`,isDef=value===undefined||value===null||value===r.def;
  if(r.kind==='part')return isDef?{[`${base}.parts.${r.feature.id}.-=${r.item.id}`]:null}:{[`${base}.parts.${r.feature.id}.${r.item.id}`]:value};
  return isDef?{[`${base}.-=${key}`]:null}:{[`${base}.${key}`]:value};
}

/* ------------------------------------------------------------------ */
/* Reading (cached; the token layer and later phases read every frame) */
/* ------------------------------------------------------------------ */
const g=()=>globalThis.game;
function setting(key){try{return g()?.settings?.get?.(ID,key)??null;}catch{return null;}}
let scopeCache=null;   // {client, world}
const docCache=new WeakMap();
/** Forget cached values (settings changed, or a token's flags changed). */
export function invalidateV11(doc=null){if(doc)docCache.delete(doc);else scopeCache=null;}
for(const hook of ['filamentFlightSettingsChanged','clientSettingChanged','updateSetting'])try{globalThis.Hooks?.on?.(hook,()=>{scopeCache=null;});}catch{}
try{globalThis.Hooks?.on?.('updateToken',doc=>{docCache.delete(doc);});}catch{}
function scopes(){return scopeCache??={client:setting(CLIENT_KEY)??{},world:setting(WORLD_KEY)??{}};}
function tokenStore(doc){
  if(!doc)return null;
  let flag=null;try{flag=doc.getFlag?.(ID,V11_FLAG)??doc.flags?.[ID]?.[V11_FLAG]??null;}catch{flag=doc.flags?.[ID]?.[V11_FLAG]??null;}
  return flag&&typeof flag==='object'?flag:null;
}
/** Every v11 value as it applies to her token `doc` (or this browser/world only, without one).
 * Frozen and cached until a setting or that token's flags change. */
export function resolveV11(doc=null){
  const sc=scopes();
  if(doc){const hit=docCache.get(doc);if(hit&&hit.sc===sc)return hit.values;}
  const ts=tokenStore(doc),values={};
  for(const [k,r] of V11_KEYS){
    const store=r.scope==='token'?ts:r.scope==='me'?sc.client:sc.world;
    const v=storedValue(store,k);values[k]=v===undefined?r.def:v;
  }
  Object.freeze(values);
  if(doc)docCache.set(doc,{sc,values});
  return values;
}
/** Is a feature on (for her token doc)? */
export const isOn=(featureId,doc=null)=>!!resolveV11(doc)[featureId];
/** Is a part on? (its feature must be on too) */
export const partOn=(featureId,partId,doc=null)=>{const v=resolveV11(doc);return !!v[featureId]&&!!v[partKey(featureId,partId)];};
/** A picker's or choice part's value. */
export const choice=(key,doc=null)=>resolveV11(doc)[key];
/** All parts of a feature as {partId:bool}, each false while the feature is off. */
export function partsOf(featureId,doc=null){
  const f=FEATURES.get(featureId),v=resolveV11(doc),on=!!v[featureId],out={};
  for(const p of f?.parts??[])out[p.id]=on&&!!v[partKey(featureId,p.id)];
  return out;
}

/* ------------------------------------------------------------------ */
/* Writing                                                              */
/* ------------------------------------------------------------------ */
/** Save one value where its scope keeps it. doc is her TokenDocument (token scope). */
export async function writeV11(key,value,doc=null){
  const r=V11_KEYS.get(key);if(!r)throw new Error(`Unknown v11 setting: ${key}`);
  if(r.scope==='token'){
    if(!doc)throw new Error('Pin her first');
    await doc.update(flagUpdate(key,value));invalidateV11(doc);return;
  }
  const sk=r.scope==='me'?CLIENT_KEY:WORLD_KEY;
  if(r.scope==='gm'&&!g()?.user?.isGM)throw new Error('Only the GM can change this');
  await g().settings.set(ID,sk,withValue(setting(sk)??{},key,value));scopeCache=null;
}
/** Settings registration (config.mjs spreads these into SETTINGS). Hidden from Foundry's own list. */
export function v11SettingDefinitions(){
  return {
    [CLIENT_KEY]:{name:'v11 · your choices',hint:'Yvaelle’s Toolbox v11 features kept on this browser (HUD › Settings).',scope:'client',config:false,type:Object,default:{}},
    [WORLD_KEY]:{name:'v11 · table choices',hint:'Yvaelle’s Toolbox v11 features the GM sets for everyone (HUD › Settings).',scope:'world',config:false,type:Object,default:{}}
  };
}
