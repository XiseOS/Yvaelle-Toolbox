import {readBitIntentTarget} from './bit-intent.mjs?v=13.0.0-beta.1';
import {isShown} from './renderer.mjs?v=13.0.0-beta.1';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
/** Reuse the controlling owner's existing event-synchronized attention target.
 * A hidden target must never become an aiming hint, even on a GM client.
 * Visibility is Foundry's cached `token.visible` (via isShown); the
 * `isVisible` getter would re-run the visibility test on every call. */
export function visibleProjectionFocus(source,origin,canvas=globalThis.canvas){
  const target=readBitIntentTarget(source?.document??source,canvas);
  if(!target?.mesh||target.document?.hidden||!isShown(target,target.mesh))return null;
  const x=target.mesh.x-origin.x,y=target.mesh.y-origin.y,length=Math.hypot(x,y);
  return length>.001?{x:x/length,y:y/length}:null;
}
/** Smooth display movement (including non-Filament recipients), four groups at
 * most. Teleports and long pauses reset thrust instead of generating spikes. */
export function sampleProjectionMotion(previous,position,now,size=100,reduced=false){
  const base={x:position.x,y:position.y,time:now,dx:previous?.dx??0,dy:previous?.dy??-1,amount:0};
  if(!previous||reduced)return base;
  const dt=(now-previous.time)/1000;if(dt===0)return previous;
  if(dt<0)return base;
  const x=position.x-previous.x,y=position.y-previous.y,distance=Math.hypot(x,y);
  if(dt>.3||distance>Math.max(1,size)*2.5)return base;
  const target=clamp(distance/Math.max(1,size)/dt/3.5,0,1),mix=1-Math.exp(-dt*9);
  base.amount=previous.amount+(target-previous.amount)*mix;
  if(base.amount<.002)base.amount=0;
  if(distance>.001){const ux=x/distance,uy=y/distance,c=(previous.dx??0)+(ux-(previous.dx??0))*mix,s=(previous.dy??-1)+(uy-(previous.dy??-1))*mix,l=Math.hypot(c,s);base.dx=l>.001?c/l:ux;base.dy=l>.001?s/l:uy;}
  return base;
}
