import {hash} from './conditions.mjs?v=13.0.0-beta.1';
import {ease} from './poses.mjs?v=13.0.0-beta.1';
import {enhancedPaths,enhancedPoint,enhancedPointParameters} from './condition-art.mjs?v=13.0.0-beta.1';
import {variantPoint,variantPaths,variantPointParameters} from './effect-variants.mjs?v=13.0.0-beta.1';
import {reactionParameters,reactionPoint,reactionPaths} from './reaction-art.mjs?v=13.0.0-beta.1';

const random=key=>hash(key)/4294967295;

/** Split actual polylines into surviving filament sections. Stable strand IDs
 * keep damage patterns coherent through poses and reloads. Glitches use slow,
 * local phase envelopes, never whole-screen flashing or per-frame randomness.
 */
function legacyPaths(strand,points,side,visual,parameters) {
  if(visual?.enhanced)return enhancedPaths(strand,points,side,visual,parameters);
  if(!visual || !(visual.damage||visual.glitch||visual.instability))return [{...strand,points}];
  const segments=[];
  for(let i=1;i<points.length;i++) {
    const a=points[i-1],b=points[i],u=((a[3]??1)+(b[3]??1))/2;
    const key=`${visual.seed}:${side}:${strand.id}:${Math.floor((i-1)/4)}`;
    const rank=random(key),protectedRoot=ease(u/0.16);
    if(rank<visual.damage*0.76*protectedRoot)continue;
    const phase=random(key+':phase')*Math.PI*2;
    const wave=(Math.sin(visual.time*(2.2+rank*1.4)+phase)+1)/2;
    let opacity=1-visual.glitch*protectedRoot*ease((wave-0.38)/0.42);
    if(visual.energyPulses)opacity*=1-visual.instability*0.22*(0.5+0.5*Math.sin(visual.time*1.6+phase));
    const strength=Math.round(strand.strength*opacity*20)/20;
    if(strength<0.025)continue;
    const last=segments.at(-1);
    if(last&&last.end===i-1&&last.strength===strength){last.points.push(b);last.end=i;}
    else segments.push({...strand,strength,points:[a,b],end:i});
  }
  return segments;
}

/** Shared only within one wing sample; all vertices use the same seed/clock. */
export function disturbanceParameters(side,visual,variantParameters) {
  if(!visual)return null;
  const phase=random(`${visual.seed}:${side}`)*Math.PI*2;
  const time=visual.animated?(visual.enhanced?visual.effectTime??visual.time:visual.time):0;
  return {phase,time,horizontalWave:Math.sin(time*1.8+phase),
    enhanced:visual.enhanced?enhancedPointParameters(side,visual):null,reactions:reactionParameters(visual,side),variant:variantParameters??variantPointParameters(visual)};
}
export function disturbPoint(point,u,side,visual,parameters) {
  if(!visual)return point;
  const prepared=parameters??disturbanceParameters(side,visual),{phase,time}=prepared;
  const out=[...point,u],rootX=side*27,rootY=-13;
  const flex=visual.instability*u*u;
  const flare=visual.geometryFlare??visual.flare;
  // Normal/stable wings have zero physical distortion. Avoid thousands of
  // sine evaluations and zero-valued deformation terms on that common path.
  // Group nonzero terms exactly as before to preserve the original geometry.
  const sag=visual.sag??visual.damage;
  if(flare||flex)out[0]+=(out[0]-rootX)*0.10*flare*u + side*flex*4*prepared.horizontalWave;
  if(flare||sag||flex)out[1]+=(out[1]-rootY)*0.06*flare*u + sag*u*u*(side<0?13:21)
    +(flex?flex*7*Math.sin(time*1.5+phase+u*3):0);
  return reactionPoint(variantPoint(visual.enhanced?enhancedPoint(out,u,side,visual,prepared.enhanced):out,u,side,visual,prepared.variant),
    u,side,prepared.reactions,visual.reactionMotion??(visual.gates?.instability===false?0:visual.variantMotion??visual.motionStrength??1));
}

export function conditionPaths(strand,points,side,visual,parameters=null) {
  // An uncut source span reaches its treatment unchanged. Let that treatment
  // create the one required result, rather than copying it first and wrapping
  // every strand in an intermediate flatMap. Stars keep their original gate.
  if(visual?.variant&&!visual.reactions?.length&&!visual.reformation&&!strand.star&&
    !(visual.damage||visual.glitch||visual.instability||visual.enhanced&&visual.overdrive))return variantPaths(strand,points,side,visual);
  const parts=legacyPaths(strand,points,side,visual,parameters);
  const variants=!visual?.variant&&!visual?.reactions?.length?parts:parts.flatMap(p=>p.star?[p]:variantPaths(p,p.points,side,visual));
  if(!visual?.reformation&&!visual?.reactions?.some(b=>b.kind==='stutter'))return variants;
  return variants.flatMap(p=>p.star||p.echo?[p]:reactionPaths(p,p.points,side,visual));
}
