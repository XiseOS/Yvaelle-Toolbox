/** Yvaelle’s Toolbox v13 · The Heart Turned: where the curse meets Foundry.
 *
 * Everything shared is one record on her actor (flags.filament-flight.curse, see curse-model.mjs). There are no socket
 * messages: the GM writes the record, her player's page sees her actor change and shows it, and fills in her rolls.
 *
 *   The GM         a key of their own (Configure Controls › Curse wheel; none is set as it comes) opens the wheel round
 *                  the pointer (curse-wheel.mjs). Laying a curse writes the record. Later the GM's page says, in one small
 *                  note, what she rolled and for how long; the wheel's strip shows what is on her, with −1 Span and Lift.
 *   Her player     the page of the first connected player who owns her shows it (curse-view.mjs): the full view, the
 *                  card, the mark. With no player of hers connected, the GM's own page shows it instead, so a GM alone
 *                  in a world sees exactly what she would.
 *   Everyone else  nothing at all.
 *
 * Time: a Span is an hour of the world's clock. The mark counts down as the clock runs and the curse ends by itself when
 * it runs out (the GM's page lifts it; her own, if no GM is connected). A table that does not run the clock uses −1 Span.
 *
 * Switches (Settings › Her › Moods & milestones › The Heart Turned): the whole thing (the GM's, for the world) · Arrive
 * minimised · Blur the game behind it · The mark opens when pressed (hers, on her page) · the whispered chat line and the
 * GM's note. Off, the wheel does not open and nothing is shown; a record already on her is left as it is. */
import {ID,isOn,partOn} from '../v11/features.mjs?v=13.0.0-beta.1';
import {CURSE_KEY,CURSE_FLAG,CURSE_STATES,CURSE_TITLE,newCurse,readCurse,rollCurse,rootCurse,burnSpan,curseOver,curseStage,presenterOf,peopleList,stateIndex,spansLeft,spanWord,namesSomeone,dieOf} from './curse-model.mjs?v=13.0.0-beta.1';
import {CurseView} from './curse-view.mjs?v=13.0.0-beta.1';
import {CurseWheel} from './curse-wheel.mjs?v=13.0.0-beta.1';

export const CURSE_WORLD='curseWorld',CURSE_CLIENT='curseClient',CURSE_BINDING='curseWheel';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const G=()=>globalThis.game;

export class CurseRuntime{
  /** pinned: () → the token pinned in this page's HUD (who is cursed, until the GM chooses someone). */
  constructor({pinned=()=>null,doc=globalThis.document,win=globalThis.window}={}){
    this.pinned=pinned;this.doc=doc;this.win=win;this.view=null;this.wheel=null;this.actorId=null;this.known=new Map();this.chosen=null;this.wasOn=true;this.lastNote=null;this.stats={laid:0,rolled:0,rooted:0,lifted:0,notes:0};
  }
  enabled(){try{return isOn(CURSE_KEY,null)!==false;}catch{return true;}}
  part(id){try{return partOn(CURSE_KEY,id,null);}catch{return false;}}
  now(){const t=G()?.time?.worldTime;return Number.isFinite(t)?t:0;}
  rng(){try{const f=globalThis.CONFIG?.Dice?.randomUniform;if(typeof f==='function'){const v=f();if(v>=0&&v<1)return v;}}catch{}return Math.random();}
  /* ───────── settings and the key (the init hook) ───────── */
  register(){
    const S=G()?.settings;if(!S?.register)return this;
    S.register(ID,CURSE_WORLD,{name:'The Heart Turned · who is cursed',scope:'world',config:false,type:Object,default:{actor:''}});
    S.register(ID,CURSE_CLIENT,{name:'The Heart Turned · this browser',scope:'client',config:false,type:Object,default:{die:4,pin:'',pos:null}});
    const K=G()?.keybindings;
    if(K?.register){const typing=context=>!!context?.event?.target?.closest?.('input,textarea,select,[contenteditable="true"]');
      K.register(ID,CURSE_BINDING,{name:'Curse wheel (GM)',hint:'Tap to open the curse wheel round the pointer: lay one of her six states on her, or let her roll for it. Tap again (or Escape) to close it. Only the GM has this key. No key is assigned by default: set yours here.',
        editable:[],uneditable:[],restricted:true,repeat:false,onDown:context=>{if(typing(context))return false;this.toggleWheel();return true;}});}
    return this;
  }
  setting(key){try{return G()?.settings?.get?.(ID,key)??{};}catch{return {};}}
  async save(key,patch){try{const cur=this.setting(key);await G().settings.set(ID,key,{...cur,...patch});}catch(e){try{console.warn('Yvaelle’s Toolbox · The Heart Turned: could not save',key,e);}catch{}}}
  /* ───────── hooks ───────── */
  install(){
    const H=globalThis.Hooks;if(!H?.on)return this;
    H.once('ready',()=>{this.wasOn=this.enabled();for(const a of G()?.actors??[])this.remember(a);this.rescan(false);});
    // (her record is read from her actor itself on every change of hers, not from the change's own shape, which differs between
    // Foundry versions for a deletion; an actor with no curse now and none before costs two look-ups)
    H.on('updateActor',(actor,changes,options,userId)=>{if(!this.known.has(actor.id)&&actor?.flags?.[ID]?.[CURSE_FLAG]==null)return;this.actorChanged(actor,userId);});
    H.on('deleteActor',actor=>{this.known.delete(actor.id);if(actor.id===this.actorId)this.rescan(false);});
    H.on('updateWorldTime',()=>this.timeChanged());
    H.on('userConnected',()=>this.rescan(false));
    // (the card and the mark sit beside Foundry's sidebar: they follow its edge when it is opened or closed)
    H.on('collapseSidebar',()=>{if(this.view?.card||this.view?.mark)this.win?.setTimeout?.(()=>this.view?.replace(),320);});
    for(const hook of ['filamentFlightSettingsChanged','clientSettingChanged','updateSetting'])H.on(hook,()=>this.settingsChanged());
    return this;
  }
  record(actor){try{return readCurse(actor?.getFlag?.(ID,CURSE_FLAG)??actor?.flags?.[ID]?.[CURSE_FLAG]??null);}catch{return null;}}
  remember(actor){const r=this.record(actor);if(r)this.known.set(actor.id,r);else this.known.delete(actor.id);return r;}
  users(actor){return (G()?.users?.contents??[...(G()?.users??[])]).map(u=>({id:u.id,active:!!u.active,isGM:!!u.isGM,owner:(()=>{try{return !!actor.testUserPermission(u,'OWNER');}catch{return false;}})()}));}
  presenter(actor){return presenterOf(this.users(actor));}
  iPresent(actor){return !!actor&&this.presenter(actor)===G()?.user?.id;}
  ensureView(){return this.view??=new CurseView({host:this.viewHost(),doc:this.doc,win:this.win});}
  /** Find the curse this page is to show (her player's page, or the GM's when she has no player here) and give it to the view. */
  rescan(fresh=false){
    const g=G();if(!g?.ready&&!g?.actors)return;let mine=null;
    if(this.enabled())for(const a of g.actors??[]){const r=this.record(a);if(!r||!this.iPresent(a))continue;if(!mine||a.id===this.actorId)mine={a,r};}
    if(mine){this.actorId=mine.a.id;this.ensureView().sync(mine.r,{fresh});}else{this.actorId=null;this.view?.sync(null);}
  }
  actorChanged(actor,userId){
    const was=this.known.get(actor.id)??null,cur=this.record(actor);if(JSON.stringify(was)===JSON.stringify(cur))return;
    if(cur)this.known.set(actor.id,cur);else this.known.delete(actor.id);
    this.rescan(true);this.observe(actor,was,cur,userId);
    if(this.wheel?.open)this.wheel.fillStrip();
  }
  settingsChanged(){
    if(!G()?.ready)return;const on=this.enabled();if(on!==this.wasOn){this.wasOn=on;if(!on)this.wheel?.destroy();this.rescan(false);}
    else if(this.view?.mode==='mark')this.view.fillMark();
  }
  /** The world's clock moved: the Spans left change, and a curse that has run out is lifted by one page only. */
  timeChanged(){
    this.view?.timeChanged();if(this.wheel?.open)this.wheel.fillStrip();
    const g=G(),now=this.now(),gm=g?.users?.activeGM??null;
    for(const [id,r] of this.known){if(!curseOver(r,now))continue;const a=g?.actors?.get?.(id);if(!a)continue;
      if(gm?gm.isSelf:this.iPresent(a))void this.lift(a,{quiet:true});}
  }
  /* ───────── the GM's small note ───────── */
  /** A GM who is not the one showing it is told once what she rolled, and once for how long. */
  observe(actor,was,cur,userId){
    const g=G();if(!g?.user?.isGM||!cur||!this.enabled()||!this.part('curseGmNote')||this.iPresent(actor))return;
    const same=was&&was.id===cur.id,e=cur.k?CURSE_STATES[stateIndex(cur.k)]:null;if(!e)return;
    const who=!namesSomeone(cur.k)?'all within 15 ft':cur.toward?`toward ${cur.toward.n}`:'';
    if(cur.spans!==null&&(!same||was.spans===null)){const n=cur.spans;this.note(`${actor.name} · ${e.n}`,`${n} ${spanWord(n)}${who?' · '+who:''}`,e.acc,`${actor.name} is cursed`);}
    else if(cur.spans===null&&(!same||!was.k)&&!(cur.forced&&cur.by===g.user.id))this.note(`${actor.name} · ${e.n}`,`${who||'she has rolled'} · Spans not yet rolled`,e.acc,cur.forced?`Laid on ${actor.name}`:`${actor.name} rolled`);
  }
  note(title,line,acc,head){
    const d=this.doc;if(!d?.body)return null;this.stats.notes++;this.lastNote?.remove();const c=d.createElement('div');this.lastNote=c;c.className='ff-cu-chip ff-cu-gmnote';c.style.setProperty('--ffcu-ac',acc?`rgb(${acc})`:'#ff78f6');
    c.innerHTML=`<svg class="ff-cu-gem" width="16" height="24" viewBox="-8 -11 16 24" aria-hidden="true"><path d="M0-10 5 0 0 12-5 0Z" fill="#120c10" stroke="#5a4650"/><path class="ff-cu-core" d="M0-3 1.6 0 0 4-1.6 0Z"/></svg><div>${head?`<div class="ff-cu-k">${esc(head)}</div>`:''}<div class="ff-cu-n">${esc(title)}</div><div class="ff-cu-m">${esc(line)}</div></div>`;
    const a=this.ensureView().anchor();c.style.right=a.right+'px';c.style.top=a.top+'px';d.body.appendChild(c);void c.offsetWidth;c.classList.add('ff-cu-on');
    const go=()=>{c.classList.remove('ff-cu-on');this.win.setTimeout(()=>c.remove(),600);};c.addEventListener('click',go);this.win.setTimeout(go,6500);return c;
  }
  /* ───────── who is cursed, and who it can be about ───────── */
  /** The actor the GM curses: the one chosen (the top of the wheel's strip), else the character pinned in this page's HUD, else the one selected token's. */
  her(){
    const g=G(),id=this.setting(CURSE_WORLD)?.actor;if(id){const a=g?.actors?.get?.(id);if(a)return a;}
    const base=t=>{const doc=t?.document??t;return doc?.baseActor??(doc?.actorId?g?.actors?.get?.(doc.actorId):null)??null;};
    try{const a=base(this.pinned?.());if(a)return a;}catch{}
    const sel=globalThis.canvas?.tokens?.controlled??[];if(sel.length===1){const a=base(sel[0]);if(a)return a;}
    return null;
  }
  /** Make the selected token's character the one who is cursed (kept for the world). */
  useSelected(){
    const g=G(),sel=globalThis.canvas?.tokens?.controlled??[];if(sel.length!==1){globalThis.ui?.notifications?.info?.('Select her token (one token), then click here.');return null;}
    const doc=sel[0].document,a=doc?.baseActor??(doc?.actorId?g?.actors?.get?.(doc.actorId):null);if(!a)return null;void this.save(CURSE_WORLD,{actor:a.id});this.chosen=a.id;return a.name;
  }
  /** The people the strip offers: the tokens the GM has selected or targeted, then the other player characters. Never her. */
  people(){
    const g=G(),her=this.chosenActor(),out=[];
    const tok=t=>{const doc=t?.document,a=t?.actor;if(!doc||!a)return;const linked=!!doc.actorLink;if(linked&&a.id===her?.id)return;out.push({id:linked?a.uuid:doc.uuid,n:doc.name||a.name,img:doc.texture?.src||a.img||''});};
    try{for(const t of globalThis.canvas?.tokens?.controlled??[])tok(t);for(const t of g?.user?.targets??[])tok(t);}catch{}
    try{for(const a of g?.actors??[])if(a.type==='character'&&a.hasPlayerOwner&&a.id!==her?.id)out.push({id:a.uuid,n:a.name,img:a.img||''});}catch{}
    return peopleList(out);
  }
  chosenActor(){const g=G();if(this.chosen){const a=g?.actors?.get?.(this.chosen);if(a)return a;}return this.her();}
  /* ───────── laying, rolling, lifting ───────── */
  async write(actor,record){await actor.update({[`flags.${ID}.${CURSE_FLAG}`]:record});return record;}
  /** The GM lays a curse. state: 0 to 5 (or a state's key) lays that one; null lets her roll. toward: a person, or none (the roll of faith). */
  async lay({state=null,toward=null,people=null,die=4,actor=null}={}){
    const g=G();if(!g?.user?.isGM)return {ok:false,why:'Only the GM lays a curse.'};if(!this.enabled())return {ok:false,why:'The Heart Turned is switched off (Settings › Her › Moods & milestones).'};
    const a=actor??this.chosenActor();if(!a)return {ok:false,why:'Nobody is chosen to curse: select her token, then click the top of the strip.'};
    const ti=typeof state==='string'?stateIndex(state):state,rec=newCurse({state:Number.isInteger(ti)&&ti>=0&&ti<6?ti:null,toward,people:people??this.people(),die:dieOf(die),by:g.user.id});
    await this.write(a,rec);this.stats.laid++;return {ok:true,name:a.name,local:this.presenter(a)===g.user.id,id:rec.id};
  }
  async lift(actor=this.chosenActor(),{quiet=false}={}){
    if(!actor||!this.record(actor))return false;try{await actor.unsetFlag(ID,CURSE_FLAG);this.stats.lifted++;return true;}catch(e){if(!quiet)try{console.warn('Yvaelle’s Toolbox · The Heart Turned: could not lift',e);}catch{}return false;}
  }
  async burn(actor=this.chosenActor()){
    const cur=this.record(actor),next=burnSpan(cur);if(!next)return false;if(curseOver(next,this.now()))return this.lift(actor);await this.write(actor,next);return true;
  }
  viewHost(){
    const actor=()=>G()?.actors?.get?.(this.actorId)??null;
    return {
      roll:async id=>{const a=actor(),cur=this.record(a);if(!a||!cur||cur.id!==id)return null;const out=rollCurse(cur,()=>this.rng());await this.write(a,out.record);this.stats.rolled++;return out;},
      root:async id=>{const a=actor(),cur=this.record(a);if(!a||!cur||cur.id!==id||!cur.k)return null;const out=cur.spans!==null?{record:cur,spans:cur.spans}:rootCurse(cur,this.now(),()=>this.rng());if(cur.spans===null){await this.write(a,out.record);this.stats.rooted++;void this.whisper(a,out.record);}return out;},
      now:()=>this.now(),
      prefs:()=>({startMin:this.part('curseStartMin'),blur:this.part('curseBlur'),markOpen:this.part('curseMarkOpen'),reduced:this.reduced()}),
      pos:()=>this.setting(CURSE_CLIENT)?.pos??null,savePos:p=>{void this.save(CURSE_CLIENT,{pos:{right:Math.round(p.right),top:Math.round(p.top)}});}
    };
  }
  reduced(){try{if(G()?.settings?.get?.(ID,'reducedMotion'))return true;}catch{}try{return !!this.win?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;}catch{return false;}}
  /** One whispered line in chat, to the GM and her own players, when the Spans are set (the record of it for the table). */
  async whisper(actor,rec){
    try{
      if(!this.part('curseChat'))return;const g=G(),CM=globalThis.ChatMessage;if(!CM?.create||!rec?.k)return;const e=CURSE_STATES[stateIndex(rec.k)];
      const to=(g.users?.contents??[]).filter(u=>u.isGM||(()=>{try{return actor.testUserPermission(u,'OWNER');}catch{return false;}})()).map(u=>u.id);
      const who=!namesSomeone(rec.k)?', all within 15 feet':rec.toward?`, toward <strong>${esc(rec.toward.n)}</strong>`:'';
      await CM.create({content:`<p><strong>${esc(CURSE_TITLE)}.</strong> ${rec.forced?'It is laid on':'It takes'} ${esc(actor.name)}: <strong>${esc(e.n)}</strong>${who}, for <strong>${rec.spans} ${spanWord(rec.spans)}</strong>.</p><p><em>${esc(e.d)}</em></p>`,whisper:to,speaker:CM.getSpeaker?.({actor})});
    }catch(e){try{console.warn('Yvaelle’s Toolbox · The Heart Turned: no chat line',e);}catch{}}
  }
  /* ───────── the wheel ───────── */
  wheelHost(){
    return {her:()=>{const a=this.chosenActor();return a?{name:a.name,img:a.img||''}:null;},people:()=>this.people(),active:()=>this.record(this.chosenActor()),now:()=>this.now(),
      send:o=>this.lay(o),lift:()=>this.lift(),burn:()=>this.burn(),useSelected:()=>this.useSelected(),
      gm:()=>this.setting(CURSE_CLIENT),saveGm:p=>{void this.save(CURSE_CLIENT,{die:dieOf(p.die),pin:String(p.pin??'')});}};
  }
  /** Where the pointer is on the page (Foundry keeps it for the canvas), else the window's middle. */
  pointer(){
    try{const c=globalThis.canvas,p=c?.mousePosition;if(c?.ready&&p&&c.clientCoordinatesFromCanvas){const q=c.clientCoordinatesFromCanvas(p);if(Number.isFinite(q?.x)&&Number.isFinite(q?.y))return {x:q.x,y:q.y};}}catch{}
    return {x:(this.win?.innerWidth??1280)/2,y:(this.win?.innerHeight??720)/2};
  }
  /** Open the wheel round the pointer (or at a point of the page), or close it. GM only. */
  toggleWheel(x=null,y=null){
    const g=G();if(!g?.user?.isGM){globalThis.ui?.notifications?.warn?.('The curse wheel is the GM’s.');return false;}
    if(!this.enabled()){globalThis.ui?.notifications?.info?.('The Heart Turned is switched off (Settings › Her › Moods & milestones).');return false;}
    this.wheel??=new CurseWheel({host:this.wheelHost(),doc:this.doc,win:this.win});const p=Number.isFinite(x)&&Number.isFinite(y)?{x,y}:this.pointer();return this.wheel.toggle(p.x,p.y);
  }
  /** game.modules.get('filament-flight').api.curse */
  api(){
    return Object.freeze({
      open:(x,y)=>this.toggleWheel(x,y),
      // toward: a person {id, n, img}, or just a name
      lay:(state,o={})=>this.lay({...o,toward:typeof o.toward==='string'?{n:o.toward}:o.toward,state}),ask:(o={})=>this.lay({...o,toward:typeof o.toward==='string'?{n:o.toward}:o.toward,state:null}),lift:()=>this.lift(),burn:()=>this.burn(),
      state:()=>this.record(this.chosenActor()),her:()=>this.chosenActor()?.name??null,states:()=>CURSE_STATES.map(e=>({key:e.k,name:e.n})),
      minimise:()=>this.view?.minimise(),show:()=>this.view?.open(this.view.mode==='mark'?'mark':'card'),
      status:()=>({enabled:this.enabled(),presenting:this.actorId,view:this.view?.status()??null,wheel:!!this.wheel?.open,stage:curseStage(this.record(this.chosenActor())),left:spansLeft(this.record(this.chosenActor()),this.now())}),
      stats:()=>({...this.stats,view:this.view?{...this.view.stats}:null,wheel:this.wheel?{...this.wheel.stats}:null})});
  }
}
