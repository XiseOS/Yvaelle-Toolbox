/** Yvaelle’s Toolbox v13 · The Heart Turned (13.0.0-beta.1): the curse's facts, with nothing of Foundry in them.
 *
 * The GM lays a curse on her that turns her heart toward one of six states, for a number of Spans (a Span is an hour of
 * the world's time). Either she rolls for which (a d6: her six wing filaments are numbered as the table is), or the GM
 * lays one on her outright. "That person" is whoever the GM pinned, else whoever the roll of faith finds.
 *
 * One record on her actor (flags.filament-flight.curse) holds all of it and is the only thing shared:
 *   {id, by, forced, k, toward, pinned, people, die, spans, at, until}
 *   k        the state's key; null until she has rolled (a state laid on her has it from the start)
 *   toward   {id, n, img} of that person; null until it is known (or for good, where there is nobody to name)
 *   people   up to six {id, n, img}: who the roll of faith chooses among, and who stands at the frayed end of Intrusive
 *   die      3, 4 or 6: the Spans are 1d<die>
 *   spans    null until she has let it root; then at (world seconds when it took) and until (when it ends)
 * The GM writes the record; her player's client fills in k, toward and spans as she rolls them. Everyone else reads.
 * Every key is always present (null where unknown), so writing a record replaces the last one whole.
 *
 * Pure module: no Foundry globals. */
export const CURSE_KEY='curse';
export const CURSE_FLAG='curse';
/** A Span is an hour (Novaran time: Tick second, Sett minute, Span hour, Turn day). */
export const SPAN_S=3600;
export const CURSE_DICE=Object.freeze([3,4,6]);
export const CURSE_TITLE='The Heart Turned';
/** The six states, in the table's order (1 to 6). w: the verb of "You are made to …". acc: the state's one accent colour. */
export const CURSE_STATES=Object.freeze([
  {k:'protective',n:'Protective',w:'guard',d:'The world has turned its teeth toward them. Nothing comes near. You stand in the way of all of it, wanted or not.',acc:'130,176,255'},
  {k:'lusty',n:'Lusty',w:'want',d:'You ache to hold them, to be as near as skin allows — and it is never near enough.',acc:'255,84,150'},
  {k:'needy',n:'Needy',w:'need',d:'Every glance they give away is stolen from you. Make them look. At you; only you.',acc:'255,170,90'},
  {k:'resentful',n:'Resentful',w:'blame',d:'The world was never kind, and they least of all. Wronged, ignored, betrayed — whatever it was, it was them.',acc:'255,96,64'},
  {k:'fearful',n:'Fearful',w:'fear',d:'Everything frightens you; they most. Not their eyes, not their voice, never their touch. You see a monster.',acc:'176,236,222'},
  {k:'intrusive',n:'Intrusive',w:'speak',d:'Your body is heavy, your mind half asleep, and nothing stands between thought and tongue. All within 15 feet hear it.',acc:'214,240,84'}
].map(Object.freeze));
export const stateIndex=k=>CURSE_STATES.findIndex(e=>e.k===k);
export const stateOf=k=>CURSE_STATES[stateIndex(k)]??null;
/** Intrusive names nobody: it is about all within 15 feet. */
export const namesSomeone=k=>k!=='intrusive';

const str=(v,max=80)=>typeof v==='string'?v.trim().slice(0,max):'';
const int=(v,lo,hi)=>Number.isInteger(v)&&v>=lo&&v<=hi?v:null;
const fin=v=>typeof v==='number'&&Number.isFinite(v)?v:null;
/** One person, cleaned: {id, n, img}, or null without a name. */
export function person(raw){
  if(!raw||typeof raw!=='object')return null;const n=str(raw.n??raw.name,60);if(!n)return null;
  // (a picture's address is kept whole or not at all: a cut one would only fail to load)
  const img=typeof raw.img==='string'?raw.img.trim():'';return {id:str(raw.id,120),n,img:img.length<=400?img:''};
}
/** A list of people: cleaned, no one twice (by id, else by name), at most six. */
export function peopleList(raw){
  const out=[],seen=new Set();
  for(const r of Array.isArray(raw)?raw:[]){const p=person(r);if(!p)continue;const key=p.id||'n:'+p.n;if(seen.has(key))continue;seen.add(key);out.push(p);if(out.length>=6)break;}
  return out;
}
/** A die roll, 1 to n. rng: () → [0,1). */
export const rollDie=(n,rng=Math.random)=>{const v=rng();return 1+Math.min(n-1,Math.max(0,Math.floor((Number.isFinite(v)?v:0)*n)));};
export const dieOf=v=>CURSE_DICE.includes(v)?v:4;
const newId=(rng=Math.random)=>Array.from({length:16},()=>'abcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(rng()*36)%36]).join('');

/** The record the GM writes. state: 0 to 5 to lay that one on her, else she rolls. toward: the pinned person, or none.
 * people: everyone the strip offered (the roll of faith's choices). */
export function newCurse({state=null,toward=null,people=[],die=4,by='',id=null,rng=Math.random}={}){
  const ti=int(state,0,5),pin=person(toward),list=peopleList(people);
  const k=ti!==null?CURSE_STATES[ti].k:null,who=k&&!namesSomeone(k)?null:pin;   // (Intrusive names nobody: a pin is not kept for it)
  return {id:str(id,32)||newId(rng),by:str(by,32),forced:ti!==null,k,toward:who,pinned:!!who,people:list,die:dieOf(die),spans:null,at:null,until:null};
}
/** A record as read from her actor: cleaned, or null if it is not one. */
export function readCurse(raw){
  if(!raw||typeof raw!=='object')return null;const id=str(raw.id,32);if(!id)return null;
  const k=stateOf(raw.k)?raw.k:null,die=dieOf(raw.die),spans=int(raw.spans,1,die),at=fin(raw.at),until=fin(raw.until);
  return {id,by:str(raw.by,32),forced:!!raw.forced,k,toward:person(raw.toward),pinned:!!raw.pinned,people:peopleList(raw.people),die,
    spans:spans!==null&&until!==null?spans:null,at:spans!==null&&until!==null?at:null,until:spans!==null&&until!==null?until:null};
}
/** Where a record stands: 'ask' (she has not rolled) · 'root' (the state is known, the Spans are not) · 'set' (all of it). */
export const curseStage=r=>!r?null:!r.k?'ask':r.spans===null?'root':'set';
/** She rolls: the state (a d6) and, where nobody was pinned, who the roll of faith finds. Returns the next record and the
 * picks: {record, die: 1..6, pick: index into people or -1}. A state laid on her is kept. */
export function rollCurse(record,rng=Math.random){
  const r=readCurse(record);if(!r)return null;let d=null,pick=-1;
  if(!r.k){d=rollDie(6,rng);r.k=CURSE_STATES[d-1].k;}
  if(!namesSomeone(r.k)){r.toward=null;r.pinned=false;return {record:r,die:d,pick:-1};}
  if(!r.toward&&r.people.length){pick=rollDie(r.people.length,rng)-1;r.toward=r.people[pick];}
  else if(r.toward)pick=r.people.findIndex(p=>(p.id&&p.id===r.toward.id)||p.n===r.toward.n);
  return {record:r,die:d,pick};
}
/** She lets it root: 1d<die> Spans from now (world seconds). */
export function rootCurse(record,now=0,rng=Math.random){
  const r=readCurse(record);if(!r||!r.k)return null;const n=rollDie(r.die,rng),t=fin(now)??0;
  r.spans=n;r.at=t;r.until=t+n*SPAN_S;return {record:r,spans:n};
}
/** Whole Spans still to run at a world time (0 once it is over; the rolled number where the record has no times). */
export function spansLeft(record,now=0){
  if(!record||record.spans===null)return null;
  if(fin(record.until)===null||fin(now)===null)return record.spans;
  return Math.max(0,Math.min(record.spans,Math.ceil((record.until-now)/SPAN_S-1e-9)));
}
export const curseOver=(record,now=0)=>!!record&&record.spans!==null&&spansLeft(record,now)<=0;
/** One Span fewer (the GM burns one by hand, for a table that does not run the world's clock). */
export function burnSpan(record){const r=readCurse(record);if(!r||r.spans===null)return null;r.until-=SPAN_S;return r;}
export const spanWord=n=>n===1?'Span':'Spans';
/** The mark's second line: "3 Spans left · toward Gate Warden". */
export function markLine(record,now=0){
  if(!record?.k)return 'A roll is asked of you';
  const who=namesSomeone(record.k)?(record.toward?` · toward ${record.toward.n}`:''):' · all within 15 ft';
  if(record.spans===null)return `not yet rooted${who}`;
  const n=spansLeft(record,now);return `${n} ${spanWord(n)} left${who}`;
}
/** Who shows it to her. users: [{id, active, isGM, owner}] (owner: owns her actor). Her player if one is here (the first by
 * id, so two owners do not both roll); with no player of hers connected, the first GM here shows it on their own screen. */
export function presenterOf(users=[]){
  const here=users.filter(u=>u&&u.active),byId=(a,b)=>String(a.id)<String(b.id)?-1:1;
  const players=here.filter(u=>!u.isGM&&u.owner).sort(byId);if(players.length)return players[0].id;
  const gms=here.filter(u=>u.isGM).sort(byId);return gms[0]?.id??null;
}
/** A fallback colour pair for someone without a picture, steady for a name. */
export function tintOf(name=''){
  let h=0;for(const c of String(name))h=(h*31+c.charCodeAt(0))%360;
  return [`hsl(${h} 16% 50%)`,`hsl(${h} 22% 15%)`];
}
