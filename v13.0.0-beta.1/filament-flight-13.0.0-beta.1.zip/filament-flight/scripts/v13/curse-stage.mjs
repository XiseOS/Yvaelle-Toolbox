/** Yvaelle’s Toolbox v13 · The Heart Turned: what she sees, drawn on one canvas.
 *
 * Her emblem is the instrument: the heart gem, six wing filaments (one for each state, numbered as on the table), her
 * four bits. The curse is a briar that coils round her. Rolled: it goes round once, cuts the filaments away one by one,
 * and the last one left is the one it takes. Laid on her: it goes straight to one, and that one sends out tendrils and
 * draws the other five into itself. Either way it runs down that filament into her heart and turns it; then it comes
 * back out of her along a tie, under the state's name, to "that person"; the Spans are counted in thorns on the tie.
 *
 * The stage is 1280 × 720 units, fitted inside the window (the veil covers all of it). It keeps its own clock, advanced
 * only by frames it draws, so a hidden tab holds the moment instead of skipping it. Every wait and tween belongs to a
 * generation: cancel() ends them all at once (a minimise, a new curse), and whatever was awaiting them stops there.
 * Nothing here reads Foundry; the view (curse-view.mjs) owns the element, the pointer and when a frame is drawn. */
import {CURSE_STATES as TAB} from './curse-model.mjs?v=13.0.0-beta.1';
import {curseArt,BONE,MAG,EMB,PI,TAU,lerp,cl,E,N1,F} from './curse-art.mjs?v=13.0.0-beta.1';

export const STAGE_W=1280,STAGE_H=720;
/** Thrown into whatever awaited a wait or a tween of a generation that was cancelled. */
export const CANCELLED=Symbol('curse cancelled');
const W=STAGE_W,H=STAGE_H;
/* her emblem, on a 100 × 100 grid: the nine-point star, the six filaments (cubic curves from her shoulders), the four bits */
const STAR=[50,6,58,25,78,13,70,38,91,31,79,56,94,73,66,68,61,90,50,78,39,90,34,68,6,73,21,56,9,31,30,38,22,13,42,25],EXT=1.5,NF=48;
const FDEF=[{ti:0,c:[[46,62],[34,28],[24,32],[22,13]],lab:'top'},{ti:1,c:[[54,62],[66,28],[76,32],[78,13]],lab:'top'},{ti:2,c:[[54,62],[66,43],[78,47],[91,31]],lab:'right'},
  {ti:3,c:[[54,62],[68,57],[71,77],[94,73]],lab:'right'},{ti:4,c:[[46,62],[32,57],[29,77],[6,73]],lab:'left'},{ti:5,c:[[46,62],[34,43],[22,47],[9,31]],lab:'left'}];
const BITS=[[31,27],[69,27],[22,62],[78,62]];
/* where she stands: large and centred while it chooses; small at the left once it has her (the name takes the middle, they the right) */
const CY0=386,SC0=3.7,PC=[176,372],PS=2.1,BP0=[1108,372],NY=338;
const pulse=t=>Math.pow(Math.max(0,Math.sin(t*5.2)),8);
/* how each state ties her to them: what the tie does, what she does, what happens to them */
const WAY={protective:{loop:1,bdx:-10,shape:()=>0},lusty:{helix:1,bdx:-78,sway:7,shape:(u,t)=>(-8+4*Math.sin(t*2))*Math.pow(Math.sin(PI*u),2)},needy:{tug:1,shape:(u,t)=>10*pulse(t)*Math.sin(PI*u)},
  resentful:{tl:1.8,bdx:16,shape:(u,t)=>15*(1-Math.abs(2*u-1))+.5*Math.sin(t*31+u*40)},fearful:{trem:1,edx:-26,esc:.88,br:10,shape:(u,t)=>2.6*N1(t*7+u*5)*Math.sin(PI*u)},intrusive:{fray:1,edy:8,shape:(u,t)=>(11+3*Math.sin(t*1.1))*Math.sin(PI*u)}};
const cub=(c,u)=>{const v=1-u;return [v*v*v*c[0][0]+3*v*v*u*c[1][0]+3*v*u*u*c[2][0]+u*u*u*c[3][0],v*v*v*c[0][1]+3*v*v*u*c[1][1]+3*v*u*u*c[2][1]+u*u*u*c[3][1]];};
const rotAbout=(p,r,a,k)=>{const dx=(p[0]-r[0])*k,dy=(p[1]-r[1])*k,c=Math.cos(a),s=Math.sin(a);return [r[0]+dx*c-dy*s,r[1]+dx*s+dy*c];};
/* the far threads behind her (the curse creeps in along them from both ends) */
const BK=[[-40,90,1320,250,60,.05,7],[-40,640,1320,470,-40,.045,8],[-40,300,1320,620,90,.035,10],[200,-20,1320,170,30,.04,6],[-40,520,900,740,50,.04,7]].map(([x0,y0,x1,y1,sag,a,w],i)=>({x0,y0,x1,y1,sag,a,w,ph:i*1.7,cr:.62+.38*((i*37)%10)/10}));
/** The cracks and the stain's reach for one cursed name (drawn fresh for each curse). */
function mkRT(rnd=Math.random){
  const RT=[],WK=Array(41).fill(0);
  for(let j=0;j<11;j++){const x0=-.47+.94*(j+.5*rnd()+.25)/11,top=.2+.4*rnd(),p=[[x0,0]];let xx=x0;const n=3+Math.floor(rnd()*3);for(let i=1;i<=n;i++){xx+=(rnd()-.5)*.02;p.push([xx,-.3+(top+.3)*i/n]);}RT.push({p,d:rnd()*.5});
    if(rnd()<.6){const q=[p[Math.floor(n/2)]],sd=rnd()<.5?1:-1;for(let i=1;i<=2;i++)q.push([q[0][0]+sd*.014*i,q[0][1]+.09*i]);RT.push({p:q,d:.5+rnd()*.3});}
    for(let i=0;i<=40;i++)WK[i]=Math.max(WK[i],Math.exp(-Math.pow((i/40-.5-x0*.92)/.016,2))*top/.6);}
  return [RT,WK];
}
const ANON=Object.freeze({n:'Them',c1:'#6f6a72',c2:'#221d24'});

/** canvas: the element to draw on. beat(name): told as each moment is reached (the tests take their pictures there). */
export function createCurseStage(canvas,{beat=null}={}){
  const x=canvas.getContext('2d'),A=curseArt(x),{path,light,briar,thorn,thorned,glow,txt,eyebrow,sigil,bead,gemK,wrap}=A;
  const doc=canvas.ownerDocument,NC=doc.createElement('canvas'),NS=doc.createElement('canvas'),nc=NC.getContext('2d'),ns=NS.getContext('2d');
  const K=name=>{try{beat?.(name);}catch{}};
  /* ── the window: backing size, the stage's scale and where it sits ── */
  const V={cw:W,ch:H,k:1,ox:0,oy:0,x0:0,y0:0,w:W,h:H,nk:0};
  function resize({width,height,pixels=1}){
    const cw=Math.max(1,Math.round(width*pixels)),ch=Math.max(1,Math.round(height*pixels));if(canvas.width!==cw)canvas.width=cw;if(canvas.height!==ch)canvas.height=ch;
    const S=Math.min(width/W,height/H),k=S*pixels;Object.assign(V,{cw,ch,k,S,ox:(width-W*S)/2*pixels,oy:(height-H*S)/2*pixels,x0:-(width-W*S)/2/S,y0:-(height-H*S)/2/S,w:width/S,h:height/S});
    const nk=Math.min(2.5,Math.max(.5,k));if(nk!==V.nk){V.nk=nk;for(const c of [NC,NS]){c.width=Math.ceil(W*nk);c.height=Math.ceil(220*nk);}nameKey='';}
  }
  /** A point of the page (CSS px from the window's corner) on the stage, and back. */
  const toStage=(px,py)=>[px/V.S+V.x0,py/V.S+V.y0],toPage=(sx,sy)=>[(sx-V.x0)*V.S,(sy-V.y0)*V.S];

  /* ── its own clock: waits and tweens run on drawn frames only, and all belong to one generation ── */
  let now=0,gen=0,tw=[],tm=[];
  // (a cancelled wait rejects whoever awaits it; one nobody awaits must not count as an unhandled rejection)
  const quiet=p=>{p.catch(()=>{});return p;};
  function tween(ms,fn,ez=E.io){
    return quiet(new Promise((res,rej)=>{if(!(ms>0)){fn(ez(1));res();return;}fn(ez(0));tw.push({t0:now,ms,fn,ez,res,rej});}));
  }
  const wait=ms=>quiet(new Promise((res,rej)=>tm.push({at:now+ms,res,rej})));
  const later=(ms,fn)=>{tm.push({at:now+ms,res:fn,rej:null});};
  function advance(dt){
    now+=dt;
    if(tm.length){const due=tm.filter(o=>o.at<=now);if(due.length){tm=tm.filter(o=>o.at>now);for(const o of due){try{o.res();}catch(e){if(e!==CANCELLED)console.error(e);}}}}
    for(const o of tw.slice()){const u=Math.min(1,(now-o.t0)/o.ms);o.fn(o.ez(u));if(u>=1){const i=tw.indexOf(o);if(i>=0)tw.splice(i,1);o.res();}}
  }
  /** End everything under way. What awaited it is rejected with CANCELLED; values stay where they were. */
  function cancel(){
    gen++;const a=tw,b=tm;tw=[];tm=[];for(const o of a)o.rej(CANCELLED);for(const o of b)o.rej?.(CANCELLED);for(const k of Object.keys(gates)){gates[k].rej(CANCELLED);delete gates[k];}
  }
  /* ── what she can press: a gate opens when the view says its control was pressed ── */
  const gates={};
  const gate=name=>quiet(new Promise((res,rej)=>{gates[name]={res,rej};}));
  const press=name=>{const g=gates[name];if(!g)return false;delete gates[name];g.res();return true;};
  const waiting=name=>!!gates[name];

  /* ── state ── */
  const L={};let FIL=[],people=[],nameKey='',nameLive=false,DT=.016,LT=0,TT=0;
  const sm=r=>1-Math.pow(1-r,DT*30),nowS=()=>now/1000;
  function reset(){
    Object.assign(L,{cx:640,cy:CY0,sc:SC0,tilt:0,heartIn:0,starIn:0,bitsOut:0,inn:1,ringIn:0,ringA:0,th0:176,th:176,jab:0,fsel:null,e:null,dk:0,turn:0,pose:0,bits:1,nameA:0,front:0,ebA:0,dA:0,tg:0,tgA:0,tgP:null,FB:null,mk:0,
      ask:0,askHot:0,buds:0,cnt:0,span:0,spA:0,set:0,pop:0,kick:0,max:4,all:1,veil:0,head:0,btn:0,hot:0,forced:false,dread:0,creep:0,hitT:[],RT:[],WK:[],gf:-1,on:-1,onPop:0,tens:0,hbPh:0,jolt:0,still:0,swell:0,dkO:0,gulps:[],
      minBtn:0,minHot:0,fold:0,fT:[912,45],fS:.09,fA:1,askY:0});
    FIL=FDEF.map((d,j)=>{const r=d.c[0],cx=d.c.map(p=>rotAbout(p,r,0,EXT)),sd=r[0]<50?-1:1,f={j,ti:d.ti,e:TAB[d.ti],lab:d.lab,side:sd,cx,c2:[[.84,.07],[1.1,-.06]].map(([k,a])=>d.c.map(p=>rotAbout(p,r,a*sd,EXT*k))),inn:0,ash:0,snap:0,sx:.5,drop:0,hit:0,ta:.6,lat:0,dr:0,eat:0,ia:20,LP:null,t0:-99,A:0,p:.9,tau:.8,pl:0,pu:.9,ang:0};
      let bd=1e9;for(let i=12;i<=NF;i++){const q=cub(cx,i/NF),dx=q[0]-50,dy=q[1]-50,dd=Math.abs(Math.hypot(dx,dy)-59);if(dd<bd){bd=dd;f.pu=i/NF;f.ang=Math.atan2(dy,dx)*180/PI;}}return f;});
    nameKey='';
  }
  const EP=(px,py)=>{const c=Math.cos(L.tilt),s=Math.sin(L.tilt),dx=(px-50)*L.sc,dy=(py-50)*L.sc;return [L.cx+dx*c-dy*s,L.cy+dx*s+dy*c];};
  const way=()=>(L.e&&WAY[L.e.k])||{};
  const beadPos=t=>{const w=way(),k=L.mk;return [BP0[0]+k*((w.bdx||0)+(w.sway?w.sway*Math.sin(t*1.5):0)-(w.tug?20*pulse(t):0)),BP0[1]];};
  const fpluck=(f,Am,tau,p)=>{f.t0=nowS();f.A=Am;f.tau=tau;f.p=p;f.pl=0;};
  /** The points of one filament now: her breath, the tie it becomes, how it rings, how it is pulled, how it shakes. */
  function fpts(f,t,c){
    const P=[],tie=f===L.fsel&&!c?L.pose:0,w=way(),Hh=EP(50,52),B=tie>0?beadPos(t):null;c=c||f.cx;
    const br=1+.016*Math.sin(t*1.2+f.side*.7+f.j*.4),r0=c[0];
    for(let i=0;i<=NF;i++){const u=i/NF,q0=cub(c,u),q=[r0[0]+(q0[0]-r0[0])*br,r0[1]+(q0[1]-r0[1])*br];let p=EP(q[0],q[1]);if(tie>0)p=[lerp(p[0],lerp(Hh[0],B[0],u),tie),lerp(p[1],lerp(Hh[1],B[1],u)+(w.shape?w.shape(u,t)*L.mk:0),tie)];P.push(p);}
    const dt=t-f.t0,on=f.A>.02&&dt>=0,kk=f===L.fsel&&L.kick&&t-L.kick<.5;
    if(on||f.pl||kk||(L.tens>0&&!f.drop)||(f===L.fsel&&L.swell>0)){
      const c0=on?2*f.A/(PI*PI*f.p*(1-f.p)):0,Nn=[];for(let i=1;i<NF;i++){const a=P[i-1],b=P[i+1],l=Math.hypot(b[0]-a[0],b[1]-a[1])||1;Nn[i]=[-(b[1]-a[1])/l,(b[0]-a[0])/l];}
      for(let i=1;i<NF;i++){const u=i/NF;let d=0;
        if(on)for(let m=1;m<=8;m++)d+=c0*Math.sin(m*PI*f.p)/(m*m)*Math.sin(m*PI*u)*Math.cos(TAU*1.7*m*dt)*Math.exp(-dt*Math.pow(m,.7)/f.tau);
        if(f.pl)d+=f.pl*(u<f.pu?u/f.pu:(1-u)/(1-f.pu));
        if(L.tens>0&&!f.drop)d+=1.9*L.tens*(1-L.still)*N1(t*9+f.j*3.3+u*4)*Math.sin(PI*u);
        if(f===L.fsel&&L.swell>0)d+=5.5*L.swell*(1-L.pose)*Math.sin(t*2.3+u*5.5)*Math.sin(PI*u);
        if(kk){const ag=t-L.kick;d+=3*Math.exp(-ag*9)*Math.sin(ag*40)*Math.exp(-Math.pow((u-.5)/.16,2));}
        P[i]=[P[i][0]+Nn[i][0]*d,P[i][1]+Nn[i][1]*d];}
    }
    return P;
  }
  const ringR=d=>(63-4.6*(d-L.th0)/360+.5*Math.sin(d*.11)+.35*Math.sin(d*.31+2))*L.sc;
  /** The briar: in from the window's left edge, then a tightening coil round her, as far as it has gone. */
  function ringPts(){
    const P=[],C=[L.cx,L.cy],a0=L.th0*PI/180,p0=[C[0]+Math.cos(a0)*ringR(L.th0),C[1]+Math.sin(a0)*ringR(L.th0)],xs=Math.min(-70,V.x0-70);
    for(let i=0;i<=12;i++){const u=i/12;P.push([lerp(xs,p0[0],u),lerp(p0[1]+170,p0[1],u*u*(3-2*u))+22*Math.sin(u*PI)]);}
    for(let d=L.th0+3;d<L.th;d+=3){const a=d*PI/180;P.push([C[0]+Math.cos(a)*ringR(d),C[1]+Math.sin(a)*ringR(d)]);}
    const a=L.th*PI/180,r=ringR(L.th)+10*L.jab;P.push([C[0]+Math.cos(a)*r,C[1]+Math.sin(a)*r]);
    return L.ringIn<1?P.slice(0,Math.max(2,Math.round(13*L.ringIn))):P;
  }
  /** The state's name, cursed: cracks climb it from the tie, a dark stain rises through the letters with an ember edge,
   * and each letter jolts as the curse reaches it. fx: how far along the tie the curse has run (stage x).
   * It is painted on its own canvas and kept: repainted only while the curse is still crossing it or a letter is still
   * jolting (and once more as that ends, with the ember steady). After that a frame only copies it. */
  function cursedName(e,NX,Ny,fs,ls,fx,t,al){
    const font=F.caps(fs);x.font=font;x.letterSpacing=ls+'px';const nw=x.measureText(e.n).width,off=NX-640,fxr=fx-off,rl=X0=>cl((fxr-X0)/150);
    const RL=(c,ox,oy,by)=>{for(const r of L.RT){const g=cl(rl(640+r.p[0][0]*nw)*1.6-r.d);if(g<=0)continue;const m=Math.max(1,Math.round((r.p.length-1)*g));c.beginPath();c.moveTo(ox+r.p[0][0]*nw,r.p[0][1]<=-.29?by:oy-r.p[0][1]*fs);for(let i=1;i<=m;i++)c.lineTo(ox+r.p[i][0]*nw,oy-r.p[i][1]*fs);c.stroke();}};
    x.lineCap='round';x.strokeStyle='rgba(13,9,11,.95)';x.lineWidth=2.4;RL(x,NX,Ny,Ny+34);x.strokeStyle='rgba(112,84,100,.6)';x.lineWidth=.7;RL(x,NX-.8,Ny,Ny+34);
    // the letters' places (the name canvas is centred on 640), and which are still jolting
    nc.setTransform(V.nk,0,0,V.nk,0,0);nc.font=font;nc.letterSpacing=ls+'px';nc.textAlign='left';nc.textBaseline='alphabetic';
    const LT2=[];let p0=640-nw/2+ls/2,live=fxr>-1e4&&fxr<1e4;
    for(let ci=0;ci<e.n.length;ci++){const w0=nc.measureText(e.n[ci]).width,cm=p0+w0/2;if(L.hitT[ci]===undefined&&rl(cm)>0)L.hitT[ci]=t;const ag=L.hitT[ci]!==undefined?t-L.hitT[ci]:9;if(ag<1.05)live=true;LT2.push([p0,ag<1?-3.6*Math.exp(-ag*6.5)*Math.sin(ag*24):0]);p0+=w0;}
    const key=`${e.k}|${fs}|${ls}|${al.toFixed(2)}|${V.nk}`;
    if(live||nameLive||key!==nameKey){
      nameKey=key;nameLive=live;nc.clearRect(0,0,W,220);nc.globalCompositeOperation='source-over';nc.filter='none';nc.fillStyle=`rgba(${BONE},${al})`;
      for(let ci=0;ci<e.n.length;ci++)nc.fillText(e.n[ci],LT2[ci][0],160+LT2[ci][1]);
      const top=()=>{for(let i=0;i<=40;i++){const u=i/40,hx=640-nw/2-20+(nw+40)*u;nc.lineTo(hx,163-fs*rl(hx)*(.03+.06*(.5+.5*N1(u*9+3))+.2*L.WK[i]));}};
      nc.globalCompositeOperation='source-atop';nc.filter=`blur(${(2.2*V.nk).toFixed(2)}px)`;nc.beginPath();nc.moveTo(640-nw/2-20,200);top();nc.lineTo(640+nw/2+20,200);nc.closePath();nc.fillStyle='rgba(15,9,13,.94)';nc.fill();
      nc.filter=`blur(${(1.1*V.nk).toFixed(2)}px)`;nc.beginPath();top();nc.strokeStyle=`rgba(${EMB},${live?.8+.2*Math.sin(t*2.2):.9})`;nc.lineWidth=3.4;nc.stroke();nc.strokeStyle='rgba(255,150,200,.5)';nc.lineWidth=1;nc.stroke();
      nc.filter='none';nc.globalCompositeOperation='destination-out';nc.lineCap='round';nc.lineWidth=1.5;nc.strokeStyle='#000';RL(nc,640,160,200);nc.globalCompositeOperation='source-over';
      // its shadow is painted once here, not on every frame
      ns.setTransform(1,0,0,1,0,0);ns.clearRect(0,0,NS.width,NS.height);ns.shadowColor='rgba(0,0,0,.85)';ns.shadowBlur=12*V.nk;ns.shadowOffsetY=3*V.nk;ns.drawImage(NC,0,0);ns.shadowColor='transparent';
    }
    x.drawImage(NS,off,Ny-160,W,220);
  }

  /* ── one frame ── */
  const stats={frames:0,ms:0,worst:0};
  function draw(dt){
    const t0=globalThis.performance?.now?.()??0;advance(dt);const t=now/1000;DT=Math.min(.05,Math.max(.001,t-(LT||t)));LT=t;TT=t;
    L.pop*=1-sm(.12);L.jab*=1-sm(.2);L.onPop*=1-sm(.14);L.jolt*=1-sm(.2);L.hbPh+=DT*(3.4+7*L.tens)*(1-L.still);
    x.setTransform(1,0,0,1,0,0);x.globalAlpha=1;x.clearRect(0,0,V.cw,V.ch);
    if(L.veil>0){
      const hb=(Math.pow(.5+.5*Math.sin(L.hbPh),8)+.5*Math.pow(.5+.5*Math.sin(L.hbPh-1.1),10))*(1-L.still);x.fillStyle=`rgba(8,5,9,${(.74+.11*L.dread+.07*L.tens)*L.veil})`;x.fillRect(0,0,V.cw,V.ch);
      x.setTransform(V.k,0,0,V.k,V.ox,V.oy);const m=Math.max(1,Math.hypot(V.w,V.h)/Math.hypot(W,H)),g=x.createRadialGradient(640,360,140*m,640,360,780*m);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,`rgba(0,0,0,${(.5+(.3*L.dread+.34*L.tens)*hb)*L.veil})`);x.fillStyle=g;x.fillRect(V.x0,V.y0,V.w,V.h);
    }
    x.setTransform(V.k,0,0,V.k,V.ox,V.oy);
    if(L.all>.01&&L.veil>.01){
      x.save();const z=1+.025*L.dread+.05*L.tens;x.translate(640+L.jolt*3*Math.sin(t*72),390+L.jolt*2.4*Math.cos(t*61));x.scale(z,z);x.translate(-640,-390);
      // the far threads, out to the window's edges
      const bx=Math.max(1,V.w/W),by=Math.max(1,V.h/H);
      for(const b of BK){const P=[];for(let i=0;i<=40;i++){const u=i/40;P.push([640+(lerp(b.x0,b.x1,u)-640)*bx,360+(lerp(b.y0,b.y1,u)-360)*by+(b.sag+6*Math.sin(t*.5+b.ph))*4*u*(1-u)]);}path(P);x.strokeStyle=`rgba(255,120,246,${b.a*L.veil*L.head*(1-.6*L.turn)})`;x.lineWidth=b.w;x.stroke();
        const m=Math.round(40*cl(L.creep*b.cr));if(m>1){x.save();x.globalAlpha=.8*L.veil*L.head;for(const Q of [P.slice(0,m+1),P.slice(40-m).reverse()]){briar(Q,1,.5);thorned(Q,2,Q.length,.7,3);}x.restore();}}
      // folding into the card or the mark (and growing back out of it): her heart is the pivot and lands on the small gem
      if(L.fold>0){const d=E.io(L.fold),s2=lerp(1,L.fS,d);x.translate(lerp(L.cx,L.fT[0],d),lerp(L.cy,L.fT[1],d));x.scale(s2,s2);x.translate(-L.cx,-L.cy);}
      x.globalAlpha=(L.fold>0?L.fA:1)*L.all;
      const e=L.e,acc=e?e.acc:MAG,w=way(),pz=L.pose,k=L.sc/SC0,ex=((w.edx||0)+(w.trem?1.4*N1(t*8.3):0))*L.mk*pz,ey=(w.edy||0)*L.mk*pz,cx0=L.cx,cy0=L.cy;L.cx+=ex;L.cy+=ey;const C=EP(50,50);
      // her light, behind her; after, what is in her
      if(L.heartIn>.01){glow(C[0],C[1],300*k,.1*L.heartIn*(1-L.turn));if(L.turn>0)glow(C[0],C[1],210*k+40,.16*L.turn,acc);}
      // her star: drawn in a breath; later it carries thorns, and cracks run out from her heart
      if(L.starIn>.01){const n=STAR.length/2,m=Math.round(n*L.starIn);x.beginPath();for(let i=0;i<=m;i++){const p=EP(STAR[(i%n)*2],STAR[(i%n)*2+1]);i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]);}x.strokeStyle=`rgba(${BONE},${.24*(1-.4*L.turn)})`;x.lineWidth=1;x.lineJoin='round';x.stroke();
        if(L.turn>.5){const g2=(L.turn-.5)*2;x.strokeStyle=`rgba(${EMB},${.55*g2})`;x.lineWidth=.8;for(let i=1;i<n;i+=4){const p=EP(STAR[i*2],STAR[i*2+1]);x.beginPath();x.moveTo(C[0],C[1]);for(let j=1;j<=4;j++){const u=j/4*g2;x.lineTo(lerp(C[0],p[0],u)+(j<4?(N1(i*3.1+j)*5*k):0),lerp(C[1],p[1],u)+(j<4?N1(i*5.7+j)*5*k:0));}x.stroke();}
          for(let i=0;i<n;i+=2){const p=EP(STAR[i*2],STAR[i*2+1]),g=cl(g2*1.7-(i/2)*.08);if(g>0)thorn(p[0],p[1],Math.atan2(p[1]-C[1],p[0]-C[0]),3.4*L.sc*g);}}}
      // her wing filaments, each with two finer strands beside it
      for(const f of FIL){f.ta+=((f.drop?0:f.hit?1:.6)-f.ta)*sm(.2);if(f===L.fsel)continue;const a=L.inn*(1-pz);if(a<.01||f.inn<.01)continue;const P=fpts(f,t),m=Math.max(2,Math.round(NF*f.inn));f.LP=P[Math.round(NF*.62)];
        if(f.snap>0){const q=E.out(f.snap),e1=Math.round(NF*f.sx*(1-q*.85)),a2=(1-f.snap*f.snap)*.55*a;x.strokeStyle=`rgba(180,168,176,${a2})`;x.lineWidth=1.1;x.beginPath();for(let i=0;i<=e1;i++){const v=i/Math.max(1,e1);x.lineTo(P[i][0],P[i][1]+v*v*40*f.snap);}x.stroke();
          x.beginPath();for(let i=Math.round(NF*f.sx);i<=NF;i++){const v=(i/NF-f.sx)/(1-f.sx);x.lineTo(P[i][0]+(1-v)*10*f.snap*f.side,P[i][1]+(60+70*(1-v))*f.snap*f.snap);}x.stroke();}
        else{x.save();x.globalAlpha*=a;for(const c2 of f.c2){const Q=fpts(f,t,c2).slice(0,m+1);path(Q);x.strokeStyle=f.ash>0?`rgba(180,168,176,${.25*(1-f.ash)})`:`rgba(255,170,246,${.3*(.6+.4*cl(f.ta))*(1-f.dr)})`;x.lineWidth=1;x.stroke();}
          {const il=Math.round(NF*.62),l2=f.dr>0?Math.round(il*f.dr):0,h2=f.dr>0?Math.round(NF-(NF-il)*f.dr):m;if(f.dr>0){path(P);x.strokeStyle=`rgba(180,168,176,${.5*f.dr})`;x.lineWidth=1.1;x.stroke();}if(h2>l2)light(P.slice(l2,h2+1),(.62+.38*cl(f.ta))*(1-f.ash)*(f.eat?1:(L.on>=0&&!f.hit?.45:1)),0);}
          if(f.hit&&!f.drop){path(P.slice(0,m+1));x.strokeStyle=`rgba(${f.e.acc},.26)`;x.lineWidth=18;x.stroke();x.strokeStyle=`rgba(${f.e.acc},.95)`;x.lineWidth=2.2;x.stroke();}
          if(f.ash>0){path(P);x.strokeStyle=`rgba(180,168,176,${.55*f.ash})`;x.lineWidth=1.1;x.stroke();}x.restore();}
        // its name and number at its tip: flared while the curse is on it, struck through once it is cut, eaten letter by letter when devoured
        const tp=P[NF],gone=f.drop?1:0,hot=f.hit&&!gone,nm=f.eat?f.e.n.slice(0,Math.ceil(f.e.n.length*(1-f.dr))):f.e.n,la=a*cl(f.inn*2-1)*(f.eat?.8*(1-.4*f.dr):gone?.24:hot?1:(L.on>=0?.4:.72));
        if(la>.01&&nm){const al=f.lab==='top'?'center':f.lab,lx=tp[0]+(al==='left'?-18:al==='right'?18:0),ly=tp[1]+(al==='center'?-20:7),ft=F.caps(hot?26:20);x.font=ft;x.letterSpacing='2px';
          const tw2=x.measureText(f.e.n).width,xl=al==='left'?lx-tw2:al==='right'?lx:lx-tw2/2;txt(nm,xl,ly,ft,2,BONE,la,'left');txt(String(f.ti+1),xl-12,ly,F.caps(16),0,hot?f.e.acc:'255,120,246',la*(1-f.dr),'right');
          if(hot){x.strokeStyle=`rgba(${f.e.acc},.95)`;x.lineWidth=1.5;x.beginPath();x.moveTo(xl,ly+8);x.lineTo(xl+tw2,ly+8);x.stroke();}
          if(gone&&!f.eat){x.strokeStyle=`rgba(${BONE},${la*1.3})`;x.lineWidth=1;x.beginPath();x.moveTo(xl-5,ly-7);x.lineTo(xl+tw2+5,ly-7);x.stroke();}}}
      // the curse, coiling round her and drawing in
      if(L.ringA>.01&&L.ringIn>0){const P=ringPts();x.save();x.globalAlpha*=L.ringA;path(P);x.strokeStyle=`rgba(${EMB},.18)`;x.lineWidth=11;x.stroke();briar(P,1,.95);thorned(P,2,P.length-2,1,4);const tp=P[P.length-1],q=P[P.length-2],an=Math.atan2(tp[1]-q[1],tp[0]-q[0]);thorn(tp[0],tp[1],an-.5,16);glow(tp[0],tp[1],14,.35+.5*L.jab,EMB);x.restore();}
      // the one it caught: into her heart, then out of her again, under the word, to them
      let fx=-1e5;
      if(L.fsel){const f=L.fsel,P=fpts(f,t),ic=Math.round(NF*f.pu),lo=Math.round(ic*(1-L.dk)),hi=Math.round(ic+(NF-ic)*Math.max(L.dk,L.dkO)),tl=w.tl?lerp(1,w.tl,L.mk):1,fi=Math.round(NF*L.front),old=cl(1-pz*2.6);
        if(L.dk<1){if(lo>0)light(P.slice(0,lo+1),1,0);if(hi<NF)light(P.slice(hi),1,0);}
        if(hi>lo){const Q=P.slice(lo,hi+1);x.save();if(w.trem)x.globalAlpha*=1-.2*L.mk*pz;path(Q);x.strokeStyle=`rgba(${EMB},.16)`;x.lineWidth=10;x.stroke();if(L.swell>0){x.strokeStyle=`rgba(${acc},${.14+.2*L.swell})`;x.lineWidth=14+16*L.swell;x.stroke();}
          briar(Q,1,(pz>0?lerp(.95,.62,cl(pz*2)):.95)*(1+.65*L.swell));if(old>0)thorned(P,lo,hi,old*(1+.5*L.swell),3);
          if(fi>0){briar(P.slice(0,fi+1),1,.95);thorned(P,1,fi,tl,3);}x.restore();}
        // laid on her: tendrils from the one it took to each of the others; their light runs down them into it
        if(L.swell>0||FIL.some(q=>q.lat>0)){const Cc=EP(50,50);
          for(const q of FIL){if(q===f||q.lat<=0||!q.LP)continue;const Aa=P[q.ia],B=q.LP,aA=Math.atan2(Aa[1]-Cc[1],Aa[0]-Cc[0]),aB=Math.atan2(B[1]-Cc[1],B[0]-Cc[0]),rA=Math.hypot(Aa[0]-Cc[0],Aa[1]-Cc[1]),rB=Math.hypot(B[0]-Cc[0],B[1]-Cc[1]);let dA=aB-aA;while(dA>PI)dA-=TAU;while(dA<-PI)dA+=TAU;
            const Tn=[];for(let i=0;i<=24;i++){const s2=i/24,an=aA+dA*s2,r=lerp(rA,rB,s2)+(16+12*Math.abs(dA))*Math.sin(PI*s2)+(7*N1(s2*5+q.j*2.3+t*.5)+3*N1(s2*13+q.j))*Math.sin(PI*s2);Tn.push([Cc[0]+Math.cos(an)*r,Cc[1]+Math.sin(an)*r]);}
            const m2=Math.max(2,Math.round(24*q.lat)),Q2=Tn.slice(0,m2+1);x.save();path(Q2);x.strokeStyle=`rgba(${EMB},.2)`;x.lineWidth=7;x.stroke();briar(Q2,1,.5);for(let i=3;i<m2-1;i+=4){const an=Math.atan2(Tn[i+1][1]-Tn[i-1][1],Tn[i+1][0]-Tn[i-1][0]);thorn(Tn[i][0],Tn[i][1],an+((i>>2)%2?1:-1)*(PI/2-.4),5);}
            if(q.dr<=0)glow(Tn[m2][0],Tn[m2][1],10,.6,EMB);if(q.dr>0&&q.dr<1)for(let j=0;j<3;j++){const s2=1-((t*1.5+j/3+q.j*.37)%1),p=Tn[Math.round(24*s2)];glow(p[0],p[1],7,.2+.8*Math.sin(PI*s2),'255,228,251');}x.restore();}
          for(const g0 of L.gulps){const ag=t-g0;if(ag<.7){const p=P[Math.max(0,Math.round(NF*.5*(1-ag/.7)))];glow(p[0],p[1],22,.7*Math.sin(PI*ag/.7),acc);}}}
        const sp=(p,q)=>{glow(p[0],p[1],22,.8,EMB);glow(p[0],p[1],7,.7,'255,200,230');for(let j=0;j<5;j++){const Ls=8+22*Math.abs(N1(t*26+j*7.3)),an=Math.atan2(q[1]-p[1],q[0]-p[0])+N1(t*19+j*3.1)*.55;x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(p[0]+Math.cos(an)*Ls,p[1]+Math.sin(an)*Ls);x.strokeStyle=`rgba(255,150,190,${.35+.4*Math.abs(N1(t*31+j))})`;x.lineWidth=1;x.stroke();}};
        if(L.dk>0&&L.dk<1)sp(P[lo],P[lo+1]);if(L.front>0&&L.front<1){sp(P[fi],P[Math.max(0,fi-1)]);fx=P[fi][0];}else if(L.front>=1)fx=1e5;
        if(pz>0&&L.mk>0){
          if(w.helix){x.beginPath();for(let i=2;i<NF-1;i++){const a=P[i-1],b=P[i+1],l=Math.hypot(b[0]-a[0],b[1]-a[1])||1,o=7*Math.sin(i*.7-t*1.3)*L.mk;x.lineTo(P[i][0]-(b[1]-a[1])/l*o,P[i][1]+(b[0]-a[0])/l*o);}x.strokeStyle=`rgba(255,228,251,${.75*L.mk})`;x.lineWidth=1.1;x.stroke();}
          if(w.fray){const o=P[NF-9];for(const j of [-2,-1,0,1,2]){x.beginPath();x.moveTo(o[0],o[1]);x.quadraticCurveTo(o[0]+60,o[1]+j*8*L.mk,o[0]+128,o[1]+L.mk*(j*26+5*Math.sin(t*5+j*2)));x.strokeStyle=`rgba(255,228,251,${.6*L.mk})`;x.lineWidth=.9;x.stroke();}}}
        // the Spans, counted in thorns on the tie
        for(let i=0;i<L.max;i++){const u=.4+.2*(L.max>1?i/(L.max-1):.5),p=P[Math.round(u*NF)],g=cl(L.cnt-i);if(g>0){const Lt=25*(g<1?E.out(g)*1.12:1);thorn(p[0],p[1]+1,PI/2+.1,Lt);glow(p[0]-Lt*.1,p[1]+1+Lt,10,.7*(g<1?1:.8),EMB);}else if(L.buds>.01){x.fillStyle=`rgba(${BONE},${.5*L.buds})`;x.beginPath();x.arc(p[0],p[1]+4.5,1.5,0,TAU);x.fill();}}
        // them: beads strung on the tie
        const B=beadPos(t),yAt=X0=>P[cl(Math.round((X0-P[0][0])/(P[NF][0]-P[0][0])*NF),0,NF)][1];if(L.FB)for(const b of L.FB)bead(b.x,yAt(b.x)+b.dy,b.r,b.p,b.a,0,b.hit);
        if(L.tg>0&&!L.FB){const got=cl((L.front-.9)/.1);
          if(w.fray){const three=[0,1,2].map(j=>people[j]??ANON);for(let j=0;j<3;j++)bead(B[0]-4+(j===1?26:0),B[1]+(j-1)*46*lerp(.4,1,L.mk),15,three[j],L.tg,got,0);txt('ALL WITHIN 15 FT',B[0],B[1]-92,F.sans(9),2.6,BONE,.6*L.tgA);}
          else if(L.tgP){const bx2=lerp(1360,B[0],E.out(L.tg)),r=24+(w.br||0)*L.mk;if(w.br)glow(bx2,B[1],r+34,.55*L.mk,'0,0,0');bead(bx2,B[1],r,L.tgP,1,got,0);
            if(w.loop&&L.mk>0)for(const [q,tl2] of [[1,.3],[1.28,-.25]]){x.beginPath();x.ellipse(bx2,B[1],(r+12)*q,(r+8)*q,tl2,-PI/2,-PI/2+TAU*L.mk);x.strokeStyle='rgba(13,9,11,1)';x.lineWidth=3.4;x.stroke();x.strokeStyle='rgba(112,84,100,.9)';x.lineWidth=1;x.stroke();}
            txt('TOWARD',bx2,B[1]-r-32,F.sans(9),2.6,BONE,.55*L.tgA);txt(L.tgP.n,bx2,B[1]-r-12,F.ital(18),0,BONE,.9*L.tgA);}}}
      // her heart, and her bits
      if(L.heartIn>.01){const ph=L.turn,fl=Math.cos(PI*ph),hs=L.sc*(1-(1-(w.esc||1))*L.mk*pz)*lerp(.6,1,E.out(L.heartIn))*(1-.06*L.jolt);
        if(ph>.25&&ph<.85)glow(C[0],C[1],70*k+50,.55*Math.sin((ph-.25)/.6*PI),acc);x.save();x.translate(C[0],C[1]);x.scale(Math.max(.05,Math.abs(fl)),1);gemK(0,0,7*hs,48*hs,ph<.5?1:0,acc,L.heartIn,t);x.restore();
        BITS.forEach((b,i)=>{const g=E.out(cl(L.bitsOut*1.5-i*.16))*(1-.32*L.tens*(1-pz)),p0=EP(b[0],b[1]),p=[lerp(C[0],p0[0],g)+2.2*Math.sin(t*1.1+i*1.6)*L.bits,lerp(C[1],p0[1],g)+2*Math.cos(t*1.4+i*1.3)*L.bits+(1-L.bits)*2.4*L.sc];gemK(p[0],p[1],1.5*L.sc,5*L.sc,L.bits>.25?1:0,'120,96,110',g*L.heartIn*(.3+.7*L.bits)*(L.gf===i?.45+.55*(1-L.jab):1),t);});}
      // which one it is on, in plain words, under her
      if(L.on>=0&&pz<=0&&L.turn<=0){const e2=TAB[L.on],sc2=1+.13*L.onPop,tj=L.tens>.85&&!L.still?1.3*N1(t*30):0;x.save();x.translate(640+tj,692);x.scale(sc2,sc2);txt(L.forced?'IT IS LAID ON YOU':'IT IS ON',0,-46,F.sans(9),2.8,BONE,.5);x.font=F.caps(42);x.letterSpacing='3px';const tw2=x.measureText(e2.n).width;
        txt(e2.n,0,0,F.caps(42),3,BONE,1);txt(String(L.on+1),-tw2/2-20,0,F.caps(28),0,e2.acc,1,'right');sigil(e2.k,tw2/2+30,-14,11,1,e2.acc);x.strokeStyle=`rgba(${e2.acc},.95)`;x.lineWidth=1.5;x.beginPath();x.moveTo(-tw2/2,13);x.lineTo(tw2/2,13);x.stroke();x.restore();}
      L.cx=cx0;L.cy=cy0;
      // the word, on the tie between them
      if(e&&L.nameA>.01){x.save();x.globalAlpha*=L.nameA;cursedName(e,640+(w.trem?1.5*L.mk*N1(t*8.3):0)+(w.tug?3*pulse(t)*L.mk:0),NY+(w.trem?1.3*L.mk*N1(t*9.1+4):0),74,3.4,fx,t,1);x.restore();
        eyebrow(L.forced?'It is laid on you. You are made to':'You are made to',e.w,e.acc,640,NY-92,L.ebA);
        const ln=wrap(e.d,740,F.ital(21));ln.forEach((s2,i)=>txt(s2,640,NY+90+i*29,F.ital(21),0,BONE,.84*L.dA));const Y2=NY+90+ln.length*29;L.askY=Y2;
        if(L.ask>.01){txt('HOW LONG IT HOLDS',640,Y2+28,F.sans(10),2.8,BONE,.55*L.ask);txt('Let it root',640,Y2+58,F.caps(20),2.4,L.askHot?'255,170,250':'255,120,246',L.ask);x.strokeStyle=`rgba(${MAG},${.7*L.ask})`;x.lineWidth=1;x.beginPath();x.moveTo(640-58-12*L.askHot,Y2+66);x.lineTo(640+58+12*L.askHot,Y2+66);x.stroke();}
        if(L.spA>.01&&L.span>0){const F1=Math.round(46*(1+.22*L.pop));x.font=F.caps(F1);x.letterSpacing='0px';const a=String(L.span),wa=x.measureText(a).width;x.font=F.ital(26);const b=L.span===1?' Span':' Spans',wb=x.measureText(b).width,xs=640-(wa+wb)/2;
          txt(a,xs,Y2+58,F.caps(F1),0,'255,120,246',L.spA,'left');txt(b,xs+wa,Y2+58,F.ital(26),0,BONE,.85*L.spA,'left');if(L.set>0){x.strokeStyle=`rgba(${EMB},${.8*L.set*L.spA})`;x.lineWidth=1.2;x.beginPath();x.moveTo(640-70*L.set,Y2+72);x.lineTo(640+70*L.set,Y2+72);x.stroke();}}}
      const ha=L.head*cl(1-pz*3)*cl(1-L.dk*3);if(ha>.01){txt(L.forced?'A CURSE IS LAID ON YOU':'A ROLL IS ASKED OF YOU',640,34,F.sans(10),2.8,BONE,.55*ha);txt('The Heart Turned',640,66,F.ital(25),0,BONE,.92*ha);}
      if(L.minBtn>.01){const a=L.minBtn,hx=1196,hy=34,col=L.minHot?'255,170,250':BONE;x.strokeStyle=`rgba(${col},${(.55+.4*L.minHot)*a})`;x.lineWidth=1.4;x.beginPath();x.moveTo(hx+12,hy-4);x.lineTo(hx+26,hy-4);x.stroke();txt('MINIMISE',hx,hy,F.sans(10),2.6,col,(.55+.4*L.minHot)*a,'right');txt('ESC',hx,hy+15,F.sans(8),2.4,BONE,.32*a,'right');}
      if(L.btn>.01){const a=L.btn,y=694,ww=22+12*L.hot;txt('Roll',640,y,F.caps(19),3,L.hot?'255,170,250':BONE,a*(.78+.22*L.hot));x.strokeStyle=`rgba(${MAG},${.75*a})`;x.lineWidth=1;x.beginPath();x.moveTo(640-42-ww,y-6);x.lineTo(640-42,y-6);x.moveTo(640+42,y-6);x.lineTo(640+42+ww,y-6);x.stroke();}
      x.restore();
    }
    const ms=(globalThis.performance?.now?.()??0)-t0;stats.frames++;stats.ms+=(ms-stats.ms)*.1;if(ms>stats.worst)stats.worst=ms;
  }
  /** Which control lies under a point of the stage: 'roll' · 'root' · 'min', or null. */
  function hit(sx,sy){
    if(L.all<.5||L.fold>0)return null;
    if(L.minBtn>.5&&sx>1100&&sx<1240&&sy>10&&sy<60)return 'min';
    if(L.btn>.5&&Math.abs(sx-640)<120&&Math.abs(sy-688)<26)return 'roll';
    if(L.ask>.5&&Math.abs(sx-640)<120&&sy>L.askY+32&&sy<L.askY+80)return 'root';
    return null;
  }
  /** Light the control under the pointer (null: none). */
  const hover=name=>{L.hot=name==='roll'?1:0;L.askHot=name==='root'?1:0;L.minHot=name==='min'?1:0;};

  /* ── the moments ── */
  /** She appears: her heart, her star, her bits, her six filaments; then the briar comes in from the edge. btn: the Roll button too. */
  async function emblemIn(btn,{forced=false}={}){
    reset();L.forced=forced;tween(14000,v=>L.creep=.38*v,E.out);tween(700,v=>L.veil=v);await wait(300);tween(600,v=>L.head=v);tween(650,v=>L.heartIn=v,E.out);tween(500,v=>L.minBtn=v);await wait(300);tween(900,v=>L.starIn=v);tween(900,v=>L.bitsOut=v,E.lin);await wait(350);
    FIL.forEach((f,i)=>later([0,1,5,2,4,3].indexOf(i)*95,()=>{tween(820,v=>f.inn=v,E.out);later(640,()=>fpluck(f,6,.7,.55));}));await wait(6*95+760);if(btn)tween(400,v=>L.btn=v);L.ringA=1;await tween(1300,v=>L.ringIn=v);K('emblem');
  }
  function crossings(){const Aa=[];for(let lap=0;lap<3;lap++)for(const f of FIL){let d=f.ang;while(d<L.th0+6)d+=360;Aa.push([d+360*lap,f]);}return Aa.sort((a,b)=>a[0]-b[0]);}
  const fwd=(deg,th)=>{let d=deg;while(d<th-1)d+=360;return d;},near=(deg,th)=>deg+360*Math.round((th-deg)/360);
  async function goTo(f,ms,nearest){const d=nearest?near(f.ang,L.th):fwd(f.ang,L.th),th1=L.th;FIL.forEach(q=>q.hit=0);await tween(ms,v=>L.th=lerp(th1,d,v),E.io);f.hit=1;L.on=f.ti;L.onPop=1;L.jab=1;L.gf=(L.gf+1)%4;}
  async function cutF(f){f.hit=0;f.drop=1;f.pl=0;f.sx=.3+.4*((f.j*.37)%1);L.jolt=1;tween(220,v=>f.ash=v);tween(780,v=>f.snap=v,E.lin);await wait(180);}
  /** The roll, as it is shown (the result is already known): once round fast, then it cuts them away with longer and longer
   * holds, feints at the one it will take, leaves two, and takes the last. About eight and a half seconds. */
  async function rollE(target){
    tween(300,v=>L.btn=Math.min(L.btn,1-v));const order=crossings().slice(0,6).map(c=>c[1]),tf=order.find(f=>f.ti===target),rival=order[(order.indexOf(tf)+3)%6];tween(5600,v=>L.tens=.72*v,E.lin);
    let d=112;for(const f of order){await goTo(f,d*.55);fpluck(f,7,.5,f.pu);await wait(d*.5);d*=1.07;}K('r_fast');
    const dw=[160,220,380,540];let k=0;
    for(const f of order){
      if(f===tf){await goTo(f,240);await tween(300,v=>f.pl=21*v,E.out);K('r_feint');await wait(330);fpluck(f,21,.9,f.pu);await wait(200);}
      else if(f===rival){await goTo(f,200);fpluck(f,8,.5,f.pu);await wait(180);}
      else{const w0=dw[k++];await goTo(f,160+w0*.15);await tween(Math.min(260,w0*.5),v=>f.pl=15*v,E.out);await wait(w0*.55);await cutF(f);if(k===2)K('r_cut');}}
    for(const [f,w0] of [[rival,300],[tf,460]]){await goTo(f,Math.min(460,w0*.62),true);fpluck(f,9,.5,f.pu);if(f===tf)K('r_duel');await wait(w0);}
    await goTo(rival,300,true);await tween(300,v=>rival.pl=22*v,E.out);tween(600,v=>L.tens=.72+.28*v);K('r_last');await wait(640);await cutF(rival);L.on=-1;L.still=1;K('r_still');await wait(380);L.still=0;
    await goTo(tf,320,true);await tween(260,v=>tf.pl=22*v,E.out);L.gf=-1;
  }
  /** Laid on her: no roll. The briar goes straight to the one. */
  async function strikeE(ti){const f=FIL.find(q=>q.ti===ti);let dg=f.ang;while(dg<L.th0+6)dg+=360;await tween(560,v=>L.th=lerp(L.th0,dg,v),E.io);f.hit=1;L.on=ti;L.onPop=1;L.jab=1;await tween(200,v=>f.pl=24*v,E.out);await wait(450);K('forced');}
  /** Laid on her: before it takes her, the one laid on her sends out tendrils, catches the other five, and draws their light into itself. */
  async function devourE(ti){
    const f=FIL.find(q=>q.ti===ti),vs=FIL.filter(q=>q!==f).sort((a,b)=>Math.abs(a.ang-f.ang)-Math.abs(b.ang-f.ang));vs.forEach((q,k)=>q.ia=Math.round(NF*(.26+.1*k)));L.fsel=f;L.e=TAB[f.ti];
    tween(900,v=>{L.dkO=v;L.dk=.62*v;},E.io);tween(1200,v=>L.dread=.7*v);tween(3200,v=>L.tens=.45*v);tween(900,v=>L.swell=.15*v);await wait(650);K('d_wake');
    vs.forEach((q,k)=>later(k*130,()=>tween(700+80*k,v=>q.lat=v,E.io)));await wait(700+80*4+130*4+220);K('d_latch');
    vs.forEach((q,k)=>later(k*330,async()=>{try{q.eat=1;q.hit=0;q.pu=.62;await tween(950,v=>{q.dr=v;q.pl=-13*q.side*Math.sin(PI*v);},E.io);q.pl=0;q.drop=1;L.gulps.push(nowS());L.jolt=.45;const s0=L.swell,b0=L.bits;tween(450,v=>L.swell=s0+.17*v);tween(500,v=>L.bits=b0*(1-.32*v));q.sx=.62;tween(700,v=>q.snap=v,E.lin);tween(450,v=>q.lat=1-v,E.in);}catch(e){if(e!==CANCELLED)throw e;}}));
    await wait(760);K('d_feed');await wait(4*330+950-760+250);K('d_fed');await wait(450);
  }
  /** It has the one: the rest go to ash, it runs down the filament into her heart, her heart turns, and she is drawn aside for the word. */
  async function takeE(ti,o={}){
    const f=FIL.find(q=>q.ti===ti),sp=o.fast?.7:1;L.fsel=f;L.e=TAB[ti];[L.RT,L.WK]=mkRT();L.hitT=[];f.hit=1;L.on=-1;L.still=0;tween(700*sp,v=>L.dread=Math.max(L.dread,v));tween(500,v=>L.tilt=f.side*.04*v,E.out);await wait(o.fast?260:620);K(o.fast?'f_held':'held');
    FIL.forEach((q,j)=>{if(q===f||q.drop)return;later((40+((j*3)%5)*75)*sp,async()=>{try{q.hit=0;q.drop=1;q.sx=.3+.4*((j*.37)%1);await tween(280*sp,v=>q.ash=v);tween(820*sp,v=>q.snap=v,E.lin);}catch(e){if(e!==CANCELLED)throw e;}});});{const b0=L.bits;tween(1100*sp,v=>L.bits=b0*(1-v));}tween(400,v=>L.btn=Math.min(L.btn,1-v));
    await wait(380*sp);fpluck(f,f.pl||20,1.4,f.pu);later(320,()=>K(o.fast?'f_snap':'snap'));{const d0=L.dk;await tween(950*sp*(1-.4*d0),v=>L.dk=lerp(d0,1,v),E.lin);}K(o.fast?'f_heart':'heart');
    tween(500,v=>L.tilt=f.side*.04*(1-v));{const t0=L.tens;tween(1400,v=>L.tens=t0*(1-v));}await tween(700,v=>L.turn=v);await wait(260);K(o.fast?'f_turn':'turn');await wait(140);
    tween(900,v=>L.ringA=1-v);{const s0=L.swell;tween(900,v=>L.swell=s0*(1-v));}later(600,()=>tween(600,v=>L.nameA=v));await tween(1250,v=>{L.pose=v;L.cx=lerp(640,PC[0],v);L.cy=lerp(CY0,PC[1],v);L.sc=lerp(SC0,PS,v);},E.io);
  }
  /** The roll of faith: the people come up on the tie, the light runs along them, slows, and stops on one; the rest fall away. */
  async function faithE(pick){
    const n=people.length,sp=n>1?Math.min(64,300/(n-1)):0;L.FB=people.map((p,i)=>({p,x:BP0[0]-(n-1-i)*sp,a:0,r:16,hit:0,dy:0}));await tween(400,v=>L.FB.forEach(b=>b.a=v));
    let d=80;const tot=n+pick;for(let st=0;st<=tot;st++){L.FB.forEach(b=>b.hit=0);L.FB[st%n].hit=1;if(st<tot){await wait(d);d*=1.24;}}await wait(320);K('faith');
    const c=L.FB[pick],x0=c.x;L.FB.forEach(b=>{if(b!==c)tween(520,v=>{b.dy=70*v*v;b.a=1-v;},E.lin);});L.tgP=c.p;await tween(520,v=>{c.x=lerp(x0,BP0[0],v);c.r=lerp(16,24,v);});L.tg=1;L.FB=null;await tween(400,v=>L.tgA=v);
  }
  /** That person comes onto the tie: by the roll of faith (pick ≥ 0 among several), or simply there. */
  async function whoE(them,pick=-1){
    if(way().fray||!them||pick<0||people.length<2){L.tgP=them??null;tween(900,v=>L.tg=v,E.out);tween(700,v=>L.tgA=v);await wait(500);}
    else{await wait(300);await faithE(pick);}
  }
  /** Out of her again: along the tie, under the word, to them. The word is cursed letter by letter as it passes. */
  async function outE(){tween(600,v=>L.ebA=v);tween(1700,v=>L.front=v,E.lin);later(900,()=>tween(1000,v=>L.mk=v));later(1000,()=>tween(700,v=>L.dA=v));await wait(1900);K('result');}
  /** "How long it holds": the button. */
  async function askE(max){L.span=0;L.max=max;L.set=0;await tween(450,v=>L.ask=v);K('ask');}
  /** She let it root: n Spans, counted out as thorns on the tie. */
  async function spansE(n,max){
    L.max=max;L.set=0;tween(260,v=>L.ask=Math.min(L.ask,1-v));L.askHot=0;L.kick=nowS();tween(300,v=>L.buds=v);L.spA=1;await wait(420);
    let d=170;for(let i=1;i<=n;i++){L.span=i;L.pop=1;L.kick=nowS();await tween(120,v=>L.cnt=i-1+v,E.out);if(i<n){await wait(d);d*=1.36;}}await wait(380);L.pop=1.3;tween(500,v=>L.buds=1-v);await tween(520,v=>L.set=v);K('span');
  }
  /** Fold all of it into a small gem at a point of the stage (the card's, the mark's). scale: how small it gets there. */
  async function foldE(at,scale,{ms=540,landed=null}={}){
    L.fT=at;L.fS=scale;const v0=L.veil,h0=L.head,b0=L.minBtn;tween(220,v=>L.minBtn=b0*(1-v));L.fA=1;tween(ms,v=>L.fold=v,E.lin);later(ms*.54,()=>tween(ms*.46,v=>L.fA=1-v));tween(ms,v=>{L.veil=v0*(1-v);L.head=h0*(1-v);});
    await wait(ms*.46);K('fold');await wait(ms*.2);try{landed?.();}catch{}await wait(ms*.48);L.all=0;
  }
  /** It steps aside to the mark once the Spans are set: slower than a minimise, and the dread goes out of the room with it. */
  async function dockE(at,scale,landed){
    L.fT=at;L.fS=scale;const d0=L.dread,b0=L.minBtn;tween(250,v=>L.minBtn=b0*(1-v));tween(900,v=>{L.fold=v;L.fA=cl(1-E.io(v)*1.4);},E.lin);tween(900,v=>L.dread=d0*(1-v));await wait(520);try{landed?.();}catch{}await tween(800,v=>{L.veil=1-v;L.head=1-v;});L.all=0;K('dock');
  }
  /** Minimised part-way through the choosing: skip to the answer. The rest go at once, the briar snaps to the one it was
   * always going to take, and that is held for a beat before it folds away. */
  async function settleE(ti){
    const tf=FIL.find(q=>q.ti===ti);{const b0=L.minBtn;tween(220,v=>L.minBtn=b0*(1-v));}L.jolt=1;L.still=0;
    FIL.forEach(q=>{if(q===tf)return;q.hit=0;q.pl=0;q.lat=0;if(!q.drop){q.drop=1;q.sx=.3+.4*((q.j*.37)%1);}const a0=q.ash,s0=q.snap;tween(200,v=>q.ash=lerp(a0,1,v));tween(520,v=>q.snap=lerp(s0,1,v),E.lin);});
    tf.drop=0;await goTo(tf,220,true);const p0=tf.pl;tween(200,v=>tf.pl=lerp(p0,14,v),E.out);await wait(400);K('settle');
  }
  /** The finished thing, as it stands once it has her (nothing moving in): heart turned, the word cursed, the tie to them. */
  function pose(ti,them,spans=0,max=4){
    reset();const f=FIL.find(q=>q.ti===ti);[L.RT,L.WK]=mkRT();
    Object.assign(L,{veil:0,head:0,heartIn:1,starIn:1,bitsOut:1,fsel:f,e:TAB[ti],dk:1,turn:1,pose:1,cx:PC[0],cy:PC[1],sc:PS,bits:0,nameA:1,front:1,ebA:1,dA:1,tg:1,tgA:1,tgP:them??null,hitT:Array(24).fill(-9),creep:.38,dread:1,all:1,mk:1,max});
    FIL.forEach(q=>{q.inn=1;if(q===f)q.hit=1;else{q.drop=1;q.ash=1;q.snap=1;}});if(spans)Object.assign(L,{span:spans,cnt:spans,spA:1,set:1});
  }
  /** Open: the small thing grows back into the whole of it. Nothing replays; it is already in her, so it arrives as it is,
   * and the only life in the landing is one shudder down the tie and through the word. */
  async function openE(ti,them,spans,max,at,scale,{forced=false}={}){
    pose(ti,them,spans,max);Object.assign(L,{forced,fold:1,fA:0,fT:at,fS:scale,dA:0,spA:0});tween(200,v=>L.fA=v);
    tween(760,v=>{L.veil=v;L.head=v;});tween(820,v=>L.fold=1-v,E.lin);later(300,()=>K('grow1'));later(500,()=>K('grow2'));later(400,()=>tween(480,v=>{L.dA=v;if(spans)L.spA=v;}));
    await wait(760);L.kick=nowS();for(let i=0;i<TAB[ti].n.length;i++)later(40+i*42,()=>{L.hitT[i]=TT;});tween(400,v=>L.minBtn=v);if(!spans)await tween(450,v=>L.ask=v);else await wait(300);K('open');
  }
  /** Go out: the whole view fades (the curse was lifted, or replaced, while it was up). */
  async function fadeE(ms=450){const v0=L.veil,a0=L.all;await tween(ms,v=>{L.veil=v0*(1-v);L.all=a0*(1-v);});L.all=0;L.veil=0;}

  reset();
  return {L,V,stats,resize,toStage,toPage,draw,hit,hover,cancel,gate,press,waiting,wait,tween,reset,
    setPeople:list=>{people=Array.isArray(list)?list:[];},get veil(){return L.veil;},get visible(){return L.all>.01&&L.veil>.01;},get posed(){return L.pose>0;},get clock(){return now;},
    emblemIn,rollE,strikeE,devourE,takeE,whoE,outE,askE,spansE,foldE,dockE,settleE,pose,openE,fadeE};
}
