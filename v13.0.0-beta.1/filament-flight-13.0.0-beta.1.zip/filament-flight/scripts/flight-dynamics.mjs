import {ease,unit,POSES} from './poses.mjs?v=13.0.0-beta.1';
import {smooth} from './motion.mjs?v=13.0.0-beta.1';
import {targetFlightProfile} from './flight-profiles.mjs?v=13.0.0-beta.1';
import {isRecall,recallFormation} from './v12/landing-recall.mjs?v=13.0.0-beta.1';

const full=()=>({growth:1,fold:0,presence:1});
/** A shared energy envelope for existing light and audio. Explicit formation
 * already has a synchronized clock; do not start another fade or timer. */
export function fieldPresence(formation) {
  if(!formation?.explicit)return 1;
  return unit(formation.presence)*Math.sqrt(unit(formation.growth))*(1-.65*unit(formation.fold));
}
export function readFormation(raw) {
  if(raw==null)return null;
  const read=value=>{
    if(!value||['growth','fold','presence'].some(k=>!Number.isFinite(value[k])||value[k]<0||value[k]>1))throw new Error('Invalid saved wing formation.');
    return Object.fromEntries(['growth','fold','presence'].map(k=>[k,value[k]]));
  };
  return {from:read(raw.from),to:read(raw.to)};
}

/** How far a takeoff or landing has played (0..1). A landing lengthened to
 * last her Flight feel descent (longer than the chosen transition time)
 * holds at its start and plays its fold and fade in the final foldMs, so
 * the wings beat her down and fold as she touches down (beta.29). */
export function transitionProgress(t,now) {
  if(!t||!(t.duration>0))return 1;
  const base=t.foldMs;
  if(t.kind==='landing'&&base>0&&base<t.duration)return unit((now-t.started-(t.duration-base))/base);
  return unit((now-t.started)/t.duration);
}

/** (12.0.0-beta.3) A landing with a recall keeps her wings out past her touch-down; everything else about the
 * landing (how far she is still flying: her hover, her bits, the flight factor) keeps the clock it always had. */
export function landingFlightProgress(t,now) {
  if(t?.kind==='landing'&&t.recall&&t.descentMs>0&&t.flightMs>0)return unit((now-t.started-(t.descentMs-t.flightMs))/t.flightMs);
  return transitionProgress(t,now);
}

/** Endpoints are saved with the flight deadline. Interruptions start from the
 * currently sampled shape; a completed sequence never issues a delayed write.
 */
export function sampleFormation(data,config,now) {
  const t=data.transition,w=t?.wings;
  const allowed=w&&config.transitions&&!config.reduced&&config.wingRenderer!=='atlas'&&
    (t.kind==='takeoff'?config.takeoffFormation:config.landingFolding);
  if(!allowed)return {...full(),explicit:false,active:false,progress:1,rigMix:0};
  const p=transitionProgress(t,now);
  // (12.0.0-beta.3) a landing style: her wings hold as they are, then the rig plays the recall (v12/landing-recall.mjs)
  // (once it has played out she is left exactly as a classic landing leaves her, so the next takeoff is the one it always was)
  if(t.kind==='landing'&&isRecall(t.recall)&&p<1){
    if(p<=0)return {...full(),explicit:true,active:true,progress:0,rigMix:0};
    return {...recallFormation(t.recall,p),explicit:true,active:true,progress:p,rigMix:1,recall:{style:t.recall,p}};
  }
  const growth=t.kind==='takeoff'?ease(p/0.88):ease((p-0.50)/0.50);
  const fold=t.kind==='takeoff'?ease(p):ease(p/0.78);
  const opacity=t.kind==='takeoff'?ease(p/0.30):ease((p-0.55)/0.45);
  const result={growth:w.from.growth+(w.to.growth-w.from.growth)*growth,
    fold:Math.min(w.from.fold,config.landingFoldStrength)+(Math.min(w.to.fold,config.landingFoldStrength)-Math.min(w.from.fold,config.landingFoldStrength))*fold,
    presence:w.from.presence+(w.to.presence-w.from.presence)*opacity};
  return {...result,explicit:true,active:p<1,progress:p,
    rigMix:unit(Math.max(1-result.growth,result.fold,1-result.presence)*10)};
}

/** Local movement history only. Observe animated mesh positions without touching
 * Foundry's coordinates, path, movement action, elevation or legacy motion math.
 */
export function trackMovement(state,{x,y,size,dt,shown=true,epoch=0,relaxation=650}) {
  const dx=x-(state.x??x),dy=y-(state.y??y),distance=Math.hypot(dx,dy);
  const reset=state.x===undefined||!shown||!Number.isFinite(dt)||dt<=0||dt>0.25||
    distance>size*1.8||distance/(Math.max(0.001,dt)*size)>30||state.inputEpoch!==epoch||state.size!==size;
  state.x=x;state.y=y;state.size=size;state.inputEpoch=epoch;
  if(reset){state.vx=state.vy=state.speed=state.turn=0;state.epoch=(state.epoch??0)+1;state.moved=false;return state;}
  const vx=dx/(size*dt),vy=dy/(size*dt),oldSpeed=state.speed??0;
  const rate=distance>size*0.0001?9:Math.log(100)/(Math.max(100,relaxation)/1000);
  const oldHeading=state.heading;
  state.vx=smooth(state.vx??0,vx,dt,rate);state.vy=smooth(state.vy??0,vy,dt,rate);
  state.speed=Math.hypot(state.vx,state.vy);
  if(state.speed<0.015){state.vx=state.vy=state.speed=0;}
  const heading=state.speed>0.05?Math.atan2(state.vy,state.vx):oldHeading;
  const turn=oldSpeed>0.15&&state.speed>0.15&&oldHeading!=null?
    Math.atan2(Math.sin(heading-oldHeading),Math.cos(heading-oldHeading))/(dt*4):0;
  state.turn=smooth(state.turn??0,Math.max(-1,Math.min(1,turn)),dt,8);
  if(Math.abs(state.turn)<0.002)state.turn=0;
  state.heading=heading;state.moved=distance>size*0.0001;
  return state;
}

export function movementVisual(data,config,raw,flightFactor,formation,visual,profile=targetFlightProfile(data.mode,config)) {
  const speed=Number.isFinite(raw?.speed)?raw.speed:0;
  const airborne=unit(flightFactor)*(1-formation.fold)*formation.growth;
  const allowed=config.movementWings&&data.movementReactions!==false&&!config.reduced&&config.wingRenderer!=='atlas';
  const amount=unit(speed/config.movementSensitivity),mode=profile.sweep;
  const sweep=allowed?unit(amount*mode)*config.movementStrength*airborne:0;
  const angle=raw?.angle??0,c=Math.cos(angle),s=Math.sin(angle);
  const vx=speed?(raw.vx??0)/speed:0,vy=speed?(raw.vy??0)/speed:0;
  const flowX=-(vx*c+vy*s),flowY=-(-vx*s+vy*c);
  const bank=allowed&&config.wingBanking?Math.max(-1,Math.min(1,-flowX*0.55+(raw?.turn??0)*0.45))*sweep:0;
  // Modes with trails (beta.29): by default Fast Flight (speed) and Glide (wingtip
  // wakes off held wings); the others have their own touches or stay clean.
  const trailMode=config.trailModes==='all'?data.mode!=='grounded':config.trailModes==='fast'?data.mode==='fast':['fast','glide'].includes(data.mode);
  const trailEnabled=data.enabled&&config.enabled&&config.wingTrails&&config.localTrails&&!config.reduced&&config.wingRenderer!=='atlas'&&trailMode;
  const base=data.trailIntensity??config.trailIntensity;
  const trailIntensity=trailEnabled?Math.min(config.trailLimit,base*profile.trail)*airborne*Math.min(1,visual.energy):0;
  return {speed,sweep,bank,flowX,flowY,moving:speed>0.05,local:true,mode:data.mode,profile,modeEchoes:config.glitchEchoes,
    modeAnimated:allowed&&sweep>0&&config.energyPulses&&['glide','surge','sentinel','wraith'].some(k=>profile.modeWeights[k]>.001),
    trailEnabled:trailEnabled&&trailIntensity>0,trailIntensity,
    // (beta.30: the beta.28 trail length and lifetime again.)
    trailLength:Math.min(config.trailLength*1.5,config.trailLength*.65*profile.length),
    trailLifetime:Math.min(2000,config.trailLifetime*.75*profile.life)};
}

const SWEEP_POSES=Object.freeze({forwardGuard:0.10,cocoon:0.04,crossed:0.04,collapsed:0,drooped:0.3,raised:0.35});
/** Pose influence is constant for one wing's geometry sample. Compute it once
 * before visiting its vertices, while retaining the direct point helper. */
export function sweepInfluence(weights,side) {
  return weights.reduce((n,w,i)=>{
    const pose=POSES[i];
    const strength=pose==='leftForwardWrap'?(side<0?0.08:1):pose==='rightForwardWrap'?(side>0?0.08:1):
      (SWEEP_POSES[pose]??1);
    return n+w*strength;
  },0);
}
export function sweepPoint(point,u,side,weights,movement,influence) {
  if(!movement?.sweep)return point;
  if(influence===undefined)influence=sweepInfluence(weights,side);
  // Fully collapsed poses have no sweep response. Avoid allocating a copy and
  // running profile/trigonometric work for every filament vertex while moving.
  if(!influence||!u)return point;
  const amount=movement.sweep*influence*u*u,rootX=side*27,rootY=-13;
  const asymmetry=1+side*movement.bank*0.15;
  const out=[...point];
  out[0]=rootX+(point[0]-rootX)*(1-0.24*amount*asymmetry)+movement.flowX*42*amount;
  out[1]=rootY+(point[1]-rootY)*(1-0.22*amount)+movement.flowY*40*amount+side*movement.bank*8*u*u*influence;
  const p=movement.profile;
  if(p){
    out[0]=rootX+(out[0]-rootX)*(1-p.narrow*.3*amount);
    out[1]+=movement.flowY*p.stretch*24*amount;
    const guard=p.guard*amount;
    out[0]=rootX+(out[0]-rootX)*(guard===0?1:Math.cos(guard*.7));
    out[2]+=guard*38;
    out[1]-=p.flare*12*amount*ease((-point[1]+40)/210);
  }
  // Wrapping poses retain their own depth crossings. Only rear spans sweep back.
  if(point[2]<0)out[2]-=25*amount;
  return out;
}

/** Clip source polylines by distance from their shoulder root, including exact
 * boundary intersections. Returning multiple spans avoids joining across gaps.
 */
export function growthPaths(points,growth=1) {
  if(growth>=1)return [points];if(growth<=0)return [];
  const paths=[];
  for(let i=1;i<points.length;i++){
    let a=points[i-1],b=points[i];const insideA=a[2]<=growth,insideB=b[2]<=growth;
    if(!insideA&&!insideB)continue;
    if(insideA!==insideB){const t=(growth-a[2])/(b[2]-a[2]),cut=a.map((v,j)=>v+t*(b[j]-v));if(insideA)b=cut;else a=cut;}
    const last=paths.at(-1);
    if(last&&last.at(-1)===a)last.push(b);else paths.push([a,b]);
  }
  return paths;
}
