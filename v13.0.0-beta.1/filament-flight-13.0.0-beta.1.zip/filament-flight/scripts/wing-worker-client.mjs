import {localPerformance} from './performance.mjs?v=13.0.0-beta.1';
/** A bounded shared off-thread painter pool: one worker on small browsers, at
 * most two on >=4 logical cores. Each live rig stays on one worker for its
 * cache. One in-flight job per worker and one latest pending job per rig avoid
 * backlogs while rotating fairly among independent tokens. */
import {getGestureStyle} from './bit-behaviour.mjs?v=13.0.0-beta.1';
import {getCoreMarkStyle,getBitOutline} from './bit-resonance.mjs?v=13.0.0-beta.1';
import {getFormationMotion} from './refined-formations.mjs?v=13.0.0-beta.1';
import {getWingMotionStyle} from './poses.mjs?v=13.0.0-beta.1';
/* beta.7: the Versions switches live in module variables, which a worker has
 * its own copy of. Every frame carries them so the worker paints the same
 * gestures, core marks and formation motion as the main thread. */
const versionStyles=()=>`${getGestureStyle()}|${getCoreMarkStyle()}|${getFormationMotion()}|${getWingMotionStyle()}|${getBitOutline()?'darker':'original'}`;
export function wingFrameInput(snapshot){
  // Worker geometry has no use for public API preferences, health, audio,
  // defensive copies of requested settings, lighting or transition history.
  // Sending only geometry inputs keeps their structured clones off this path.
  const semantic=snapshot.visual?.semanticProfile??snapshot.visual?.profile??{},response=snapshot.conditionResponse;
  return {versionStyles:versionStyles(),gems:snapshot.gems,v7:snapshot.v7,v9:snapshot.v9,poseAnimation:{weights:snapshot.poseAnimation?.weights,tipWeights:snapshot.poseAnimation?.tipWeights},
    formation:snapshot.formation,movement:snapshot.movement,structureAnimation:snapshot.structureAnimation,workingPosture:snapshot.workingPosture,
    bitActionAssignments:snapshot.bitActionAssignments,bitSequenceActive:snapshot.bitSequenceActive,lantern:snapshot.lantern,started:snapshot.started,
    ...(snapshot.lantern?.active||snapshot.lantern?.weight>0?{lightAppearance:snapshot.lightAppearance}:{}),
    bitDeployment:snapshot.bitDeployment,bitTransition:snapshot.bitTransition?{active:snapshot.bitTransition.active}:null,
    bitFormationFlow:snapshot.bitFormationFlow,bitFormationNow:snapshot.bitFormationNow,bitHomeStations:snapshot.bitHomeStations,bitHardwareAll:snapshot.bitHardwareAll,bitFormationTransition:snapshot.bitFormationTransition,bitActivity:snapshot.bitActivity,bitProjectedEffect:snapshot.bitProjectedEffect,
    bitCount:snapshot.bitCount?{values:snapshot.bitCount.values,formationWeights:snapshot.bitCount.formationWeights}:null,
    wingBitHandoff:snapshot.wingBitHandoff,compactBits:snapshot.compactBits,stabilizerDeployment:snapshot.stabilizerDeployment,
    flightProfile:snapshot.flightProfile,effective:{mode:snapshot.effective?.mode,reducedMotion:snapshot.effective?.reducedMotion,
      ...(snapshot.lantern?.active||snapshot.lantern?.weight>0?{intensity:snapshot.effective?.intensity}: {})},intentTarget:snapshot.intentTarget,
    conditionResponse:response?{bits:response.bits,levels:response.levels,collapse:{phase:response.collapse?.phase}}:undefined,
    formationGlow:snapshot.formationGlow,visual:{profile:{time:snapshot.visual?.profile?.time},semanticProfile:{damage:semantic.damage,instability:semantic.instability,energy:semantic.energy}}};
}

export class WingWorkerPool {
  constructor({makeWorker=()=>new Worker(new URL('./wing-render-worker.mjs',import.meta.url),{type:'module',name:'Filament wing painter'}),maxWorkers=1,clock=()=>Date.now(),document=globalThis.document}={}){
    this.makeWorker=makeWorker;this.maxWorkers=Math.max(1,Math.min(2,maxWorkers));
    this.slots=[];this.clients=new Map();this.pending=new Map();this.pendingTimes=new Map();this.nextId=0;this.failed=false;
    this.clock=clock;this.document=document;this.recoveries=[];this.retryAt=0;
    this.visibilityChanged=()=>this.visibility();
  }
  createSlot(){
    const worker=this.makeWorker(),slot={worker,busy:null};this.slots.push(slot);this.worker??=worker;
    worker.onmessage=event=>{if(this.slots.includes(slot))this.receive(event.data,slot);else closeWorkerFrame(event.data);};
    worker.onerror=event=>{event.preventDefault?.();if(this.slots.includes(slot))this.recover(slot,event.message??'Worker unavailable');};
    worker.onmessageerror=()=>{if(this.slots.includes(slot))this.recover(slot,'Worker frame could not be decoded');};
    return slot;
  }
  acquire(onFrame,onFailure,onBits=null,{kind='frames'}={}){
    if(this.failed||this.clock()<this.retryAt)return null;
    let slot;
    try{
      // Wing rigs (frames) spread over up to maxWorkers painters, one each
      // while they last; bit pictures only (kind 'bits') join a running painter
      // and start one only when none runs. Workers are not started per action.
      const counts=new Map(this.slots.map(s=>[s,0]));
      for(const c of this.clients.values())if(kind!=='frames'||c.kind==='frames')counts.set(c.slot,counts.get(c.slot)+1);
      const least=()=>this.slots.reduce((a,b)=>counts.get(a)<=counts.get(b)?a:b);
      if(kind!=='frames')slot=this.slots.length?least():this.createSlot();
      else{const idle=this.slots.find(s=>counts.get(s)===0);slot=idle??(this.slots.length<this.maxWorkers?this.createSlot():least());}
    }catch(error){this.retryAt=this.clock()+30000;return null;}
    const id=++this.nextId;this.clients.set(id,{onFrame,onFailure,onBits,slot,kind});
    if(!this.listening){this.document?.addEventListener?.('visibilitychange',this.visibilityChanged);this.listening=true;}
    return {submit:frame=>this.submit(id,frame),cancel:()=>this.cancel(id),release:()=>this.release(id),paintBits:jobs=>this.paintBits(id,jobs)};
  }
  submit(id,frame){
    if(this.failed||!this.clients.has(id)||this.document?.hidden)return false;
    if(this.pending.has(id))localPerformance.count('workerPendingReplacements');
    if(localPerformance.active)this.pendingTimes.set(id,{at:localPerformance.now(),captureId:localPerformance.captureId});
    else this.pendingTimes.delete(id);
    this.pending.set(id,frame);this.dispatch();return true;
  }
  /** Bit pictures (resonant bits) are painted by the same worker as their
   * rig, outside the one-frame-in-flight wing schedule: they are small, queue
   * behind any frame in progress and return as {type:'bits'}. False when they
   * cannot be sent (the caller then paints them itself). */
  paintBits(id,jobs){
    const client=this.clients.get(id);
    if(this.failed||!client?.onBits||!client.slot||!this.slots.includes(client.slot)||this.document?.hidden||!jobs?.length)return false;
    try{client.slot.worker.postMessage({type:'bits',id,jobs,versionStyles:versionStyles()});return true;}
    catch(error){return false;}
  }
  dispatch(){
    if(this.failed||this.document?.hidden)return;
    for(const [id,frame] of this.pending){
      const slot=this.clients.get(id)?.slot;if(!slot){this.pending.delete(id);this.pendingTimes.delete(id);continue;}if(slot.busy)continue;
      const timing=this.pendingTimes.get(id);this.pendingTimes.delete(id);
      const capture=localPerformance.active&&timing?.captureId===localPerformance.captureId;
      const dispatchedAt=capture?localPerformance.now():null;
      if(capture)localPerformance.observe('workerQueueWaitMs',dispatchedAt-timing.at);
      this.pending.delete(id);slot.busy={id,epoch:frame.epoch,sequence:frame.sequence,frame,...(capture?{queuedAt:timing.at,dispatchedAt,captureId:timing.captureId}:{})};
      try{
        this.watch(slot);
        slot.worker.postMessage({type:'frame',id,...frame});
      }catch(error){this.recover(slot,error.message);return;}
    }
  }
  receive(message,slot=this.slots.find(s=>s.busy?.id===message.id)){
    if(!slot||!this.slots.includes(slot)){localPerformance.count('workerResultsDiscarded');closeWorkerFrame(message);return;}
    if(message.type==='bits'){
      const client=this.clients.get(message.id);
      try{if(client?.onBits)client.onBits(message);}catch(error){console.warn('Yvaelle’s Toolbox: bit pictures could not be installed.',error);}
      finally{closeWorkerFrame(message);}
      return;
    }
    // One token's frame threw: the worker itself is healthy. Fail only that
    // client (it repaints on the main thread); onerror/timeouts still recover.
    if(message.type==='error'){
      if(slot.busy?.id===message.id){clearTimeout(slot.timeout);slot.timeout=null;slot.busy=null;}
      const client=this.clients.get(message.id);localPerformance.count('workerFrameErrors');
      if(client){this.release(message.id);client.onFailure?.(message.message);}else this.dispatch();
      return;
    }
    if(message.type!=='frame')return;
    const busy=slot.busy;
    if(!busy||busy.id!==message.id||(message.epoch!==undefined&&busy.epoch!==message.epoch)||busy.sequence!==message.sequence){localPerformance.count('workerResultsDiscarded');closeWorkerFrame(message);return;}
    // (The watchdog stays armed; it sees no busy frame and stops. See watch.)
    slot.busy=null;
    const client=this.clients.get(message.id);
    if(client&&!busy.cancelled){
      localPerformance.count('workerResultsAccepted');
      if(localPerformance.active&&busy.captureId===localPerformance.captureId){
        const finished=localPerformance.now();
        localPerformance.observe('workerResultAgeMs',finished-busy.queuedAt);
        localPerformance.observe('workerRoundTripMs',finished-busy.dispatchedAt);
      }
    }else localPerformance.count('workerResultsDiscarded');
    try{if(client&&!busy.cancelled)client.onFrame(message,busy.frame,{queuedAt:busy.queuedAt,captureId:busy.captureId});}finally{closeWorkerFrame(message);this.dispatch();}
  }
  cancel(id){
    if(this.pending.delete(id))localPerformance.count('workerPendingCancelled');this.pendingTimes.delete(id);
    const slot=this.clients.get(id)?.slot;if(slot?.busy?.id===id&&!slot.busy.cancelled){slot.busy.cancelled=true;localPerformance.count('workerInFlightCancelled');}
  }
  /** Beta.32: one watchdog per worker that moves its deadline, instead of
   * clearing and starting a 5 s timer for every frame (60 to 82 a second).
   * A frame still out 5 s after it was sent recovers the worker, as before. */
  watch(slot){
    if(!slot.busy||this.document?.hidden){clearTimeout(slot.timeout);slot.timeout=null;return;}
    slot.deadline=globalThis.performance.now()+5000;
    if(slot.timeout)return;
    const check=()=>{
      slot.timeout=null;
      if(!slot.busy||this.document?.hidden||!this.slots.includes(slot))return;
      const left=slot.deadline-globalThis.performance.now();
      if(left>0){slot.timeout=setTimeout(check,left);slot.timeout.unref?.();return;}
      this.recover(slot,'Worker did not return a frame');
    };
    slot.timeout=setTimeout(check,5000);slot.timeout.unref?.();
  }
  visibility(){
    if(this.document?.hidden){
      this.pending.clear();this.pendingTimes.clear();
      for(const slot of this.slots){clearTimeout(slot.timeout);slot.timeout=null;if(slot.busy)slot.busy.cancelled=true;}
    }else{
      for(const slot of this.slots)this.watch(slot);
      this.dispatch();
    }
  }
  /** A failed painter must not disable healthy workers or permanently penalize
   * every token. Two bounded replacements per 30 seconds recover transient
   * errors; repeated failures use the compatible path until its next retry. */
  recover(slot,message){
    if(!this.slots.includes(slot))return;
    localPerformance.count('workerRecoveries');
    const now=this.clock(),busy=slot.busy;
    clearTimeout(slot.timeout);slot.worker.terminate();slot.busy=null;
    this.slots.splice(this.slots.indexOf(slot),1);this.worker=this.slots[0]?.worker??null;
    const affected=[...this.clients.entries()].filter(([,client])=>client.slot===slot);
    this.recoveries=this.recoveries.filter(time=>now-time<30000);
    let replacement=null;
    if(this.recoveries.length<2){
      this.recoveries.push(now);
      try{replacement=this.createSlot();}catch{}
    }
    if(replacement){
      // Bit pictures queued on the old worker are gone: their bits repaint.
      for(const [id,client] of affected){client.slot=replacement;try{client.onBits?.({type:'bits',id,results:[],lost:true});}catch{}}
      if(busy&&!busy.cancelled&&!this.pending.has(busy.id)&&this.clients.has(busy.id)){
        this.pending.set(busy.id,busy.frame);
        if(busy.captureId===localPerformance.captureId)this.pendingTimes.set(busy.id,{at:busy.queuedAt,captureId:busy.captureId});
      }
    }else{
      this.retryAt=now+30000;
      for(const [id,client] of affected){this.clients.delete(id);this.pending.delete(id);this.pendingTimes.delete(id);client.onFailure?.(message);}
    }
    this.unlistenIfEmpty();this.dispatch();
  }
  unlistenIfEmpty(){
    if(this.clients.size||!this.listening)return;
    this.document?.removeEventListener?.('visibilitychange',this.visibilityChanged);this.listening=false;
  }
  release(id){
    this.cancel(id);const slot=this.clients.get(id)?.slot;this.clients.delete(id);if(!slot)return;
    if(![...this.clients.values()].some(c=>c.slot===slot)){
      clearTimeout(slot.timeout);slot.worker.terminate();slot.busy=null;this.slots.splice(this.slots.indexOf(slot),1);this.worker=this.slots[0]?.worker??null;
    }else try{slot.worker.postMessage({type:'release',id});}catch(error){this.recover(slot,error.message);}
    this.unlistenIfEmpty();
    this.dispatch();
  }
  fail(message){
    if(this.failed)return;
    this.failed=true;for(const slot of this.slots){clearTimeout(slot.timeout);slot.worker.terminate();slot.busy=null;}
    this.slots=[];this.worker=null;this.pending.clear();this.pendingTimes.clear();
    for(const client of this.clients.values())client.onFailure?.(message);
    this.clients.clear();this.unlistenIfEmpty();
  }
}
export function closeWorkerFrame(frame){for(const layer of frame.layers??[])layer.bitmap?.close?.();for(const result of frame.results??[])result?.bitmap?.close?.();}
export const wingWorkerPool=new WingWorkerPool({maxWorkers:(globalThis.navigator?.hardwareConcurrency??1)>=4?2:1});
export function supportsWingWorker(){return typeof globalThis.Worker==='function'&&typeof globalThis.OffscreenCanvas==='function';}
