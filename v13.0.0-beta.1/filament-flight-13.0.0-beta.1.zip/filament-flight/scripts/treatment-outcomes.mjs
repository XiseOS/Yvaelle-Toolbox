/** Authored result artwork for Ellie's field medicine.
 *
 * Each drawing belongs to the patient, never the moving instrument. Endings
 * complete, dismantle or interlock the actual technique rather than displaying
 * a generic success badge. All geometry is deterministic, bounded and sampled
 * from normalized progress. Reduced motion holds a readable result tableau
 * while the same smooth entry/release envelope fades it gently.
 */
import {sampleV7MedicalResult,v7MedicalResultBounds} from './v7-medical-results.mjs?v=13.0.0-beta.1';
const TAU=Math.PI*2;
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,Number.isFinite(n)?n:0));
const smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const mix=(a,b,p)=>a+(b-a)*p;
const WHITE='#fff0fc',PEARL='#ffcbe9',ICE='#badfff',GOLD='#eecaad',MAGENTA='#ff49d5';
// Critical-failure safety hardware: ember edges over ash, never the gold of a critical success.
const STOP_EDGE='#e8869c',STOP_ASH='#b8a0b3';
const bounds=Object.freeze({x:-104,y:-104,width:208,height:208});
export const MEDICAL_OUTCOMES=Object.freeze(['criticalFailure','failure','success','criticalSuccess']);
const spec=(name,family,signature,mechanism,results,extra)=>Object.freeze({name,family,signature,mechanism,results:Object.freeze(results),...extra});
export const MEDICAL_OUTCOME_STYLES=Object.freeze({
  suture:spec('Suture weave','stitch',0,'Diagonal looped seam',['Crossed needle interlock and captive broken loops','Loose stitch loops unthread in order','Stitches pull through and knots seat along the seam','A second fine seam checks every seated knot']),
  lattice:spec('Lattice reconstruction','lattice',0,'Raised reconstruction scaffold',['Disconnected tiles fold inside scaffold cells','Unsupported tiles separate and scaffold lowers','Raised cells settle into an interlocked plate','Counter-diagonal braces verify the settled plate']),
  compression:spec('Compression seal','iris',0,'Four pressure jaws',['Double jaw stops isolate a split seal','Jaws release an incomplete seal in opposing pairs','Four jaws seat a faceted pressure closure','Nested closure receives a balanced perimeter proof']),
  precision:spec('Precision instruments','optics',0,'Probe and forceps',['Probe tips park behind a captive instrument shield','Forceps open and reference pieces withdraw','Probe seats a measured oblique repair segment','A counter-angle probe verifies the completed segment']),
  microloom:spec('Microloom dressing','textile',0,'Shuttle woven dressing',['Shuttle stops and frayed yarn folds into frame channels','Weft lifts and unwinds in staggered rows','Woven film lays flat and its border is bonded','A second fine selvedge settles around the dressing']),
  vascular:spec('Perfusion channels','flow',0,'Branching infusion manifold',['Junction shutters confine separated current segments','Branch packets return into paired feed ports','Current reaches the terminal wells and closes each feed','A reverse inspection current proves every branch']),
  helix:spec('Helical traction','spiral',0,'Axial screw and collars',['Split coils are held between opposed axial stops','Screw unwinds into two separated half coils','Screw seats and opposite collars lock the axis','A counter-wound fine coil checks the seated screw']),
  splint:spec('Articulated splints','support',0,'Jointed rails and cuffs',['Joint stop plates isolate a bowed support section','Rail hinges open before supports fold away','Paired rail segments straighten and cuffs engage','An outer brace checks load along each supported joint']),
  membrane:spec('Protective membrane','canopy',0,'Six panel protective bell',['Detached facets gather behind a closed safety lip','Bell panels peel outward in alternating order','Canopy panels settle into a continuous protected edge','An inner canopy verifies the sealed panel junctions']),
  resonance:spec('Resonant alignment','pulse',0,'Opposed tuned resonators',['Resonator shutters hold broken wave lobes','Out-of-phase lobes separate toward their resonators','Opposite resonators settle into one aligned wave','A second harmonic passes between aligned resonators']),
  pulseHalo:spec('Restorative tide','pulse',1,'Rising induction bands',['Interrupted bands are captive beneath an induction lid','Bands descend into their source channels','Three induction bands settle into a coherent crest','A finer returning crest confirms the full induction field']),
  mendingVeil:spec('Mending veil','textile',1,'Suspended draped restoration veil',['Open veil corners fold behind sealed upper catches','Veil separates into pleats and rises into its supports','The draped veil gathers into a clean restored contour','Fine curved hems verify the contour without hiding the patient']),
  renewalSpiral:spec('Renewal spiral','spiral',1,'Ascending renewal channels',['Separate ascending channels are arrested in paired gates','Renewal threads descend into their divided roots','Two ascending threads meet and seat at the crown','A returning thread traces both seated renewal channels']),
  crystalCast:spec('Crystalline cast','lattice',1,'Hardlight crystal plates',['Unset plates are held in their rows','Cracked plates drift apart and dissolve','The plates fuse into one smooth shell','A glint runs over the finished cast']),
  wingSuture:spec('Wing-thread suture','stitch',2,'Wing filament whip stitches',['Loose stitches are caught at the needle','The thread slips and the seam stays open','The seam pulls closed along its length','A bright line seals the finished seam'],{angle:0}),
  threadbind:spec('Soul threads','stitch',2,'Laced filament threads',['Loose thread ends are caught at their anchors','The lacing slackens and the threads slip back to the instruments','The lacing cinches into one clean seam','A second bright seam traces the closure'],{angle:0}),
  heartline:spec('Steady heartline','pulse',2,'Diagnostic ribbon',['Discontinuous ribbon sections are capped on both ends','Separate diagnostic lobes lift out into reference slots','The ribbon resolves into a stable smooth waveform','A fine counter-wave verifies the restored rhythm']),
  capillaryBridge:spec('Restorative infusion','flow',1,'Bit-fed packets entering a short local repair',['Local transfer stops safely before the open join','Incomplete transfer separates at the repair','Infused edges settle into three joined capillary seams','A fine pass verifies the same completed capillary seams']),
  irisPatch:spec('Pressure mend','iris',1,'Paired soft pads closing a local seam',['Pressure releases into quiet stops beside the open seam','Pads lift away from an unsealed seam','Opposed pads seat a smooth local pressure closure','A measured pass checks the same sealed seam']),
  segmentedCradle:spec('Alignment brace','support',1,'Two compact grips along an oblique repair',['Grips secure the incomplete alignment and disengage safely','Supports release while the oblique repair remains open','Two grips align and support the joined local axis','A second pass checks the same supported alignment']),
  lymphaticCircuit:spec('Cleanse and flush','flow',2,'Outward impurity extraction and clean inward transfer',['A short local stop pauses the interrupted wash','Impurities withdraw from an incomplete clean surface','The washed contact settles into a smooth restored line','A clean inspection pass follows the same restored contact']),
  fibrilRepair:spec('Fiber knit','stitch',1,'Three to five stitches on a small diagonal seam',['Fine stitch ends hold quietly beside the open seam','Loose local stitches unthread and leave the seam open','Stitches draw together and seat along the repaired seam','A fine inspection pass checks the same seated stitches']),
  tissueLens:spec('Precision mend','optics',1,'A focused nib tracing a short oblique repair',['The trace stops safely at two open repair lips','Partly mended segments separate along the trace','Three traced segments join into one smooth local repair','A second focused pass verifies the same completed trace']),
  pulseReservoir:spec('Reviving cadence','pulse',3,'Measured restorative waves at one central contact',['Twin wave lobes stop quietly beside the central contact','Uneven lobes separate without completing the cadence','The measured cadence settles into a stable local wave','A finer second cadence verifies the same steady contact']),
  petalSanctuary:spec('Protective dressing','canopy',1,'A small transparent film held and smoothed by bits',['The unbonded film releases into quiet local stops','Two film halves peel away without sealing','A rounded transparent dressing lays flat and bonds locally','A fine pass checks the same bonded dressing edge'])
});

export function medicalOutcomeBounds(effect){return v7MedicalResultBounds(effect)??(MEDICAL_OUTCOME_STYLES[effect?.style]?{...bounds}:null);}

/** A small accompanying control sample for core/tools. Values are only visual
 * hints; callers retain the work pose and use gain when blending those hints.
 * At both boundaries gain is exactly zero. No timing decides a roll result. */
export function sampleMedicalOutcomeMotion(style,outcome,progress,{animated=true}={}){
  const p=clamp(progress),valid=Boolean(MEDICAL_OUTCOME_STYLES[style])&&MEDICAL_OUTCOMES.includes(outcome);
  const gain=valid&&p>0&&p<1?smooth(p/.14)*smooth((1-p)/.19):0;
  const q=animated===false?.62:smooth(p),good=outcome==='success'||outcome==='criticalSuccess';
  return {gain,closure:good?q:0,release:good?0:q,coreEnergy:good?mix(.88,outcome==='criticalSuccess'?1.3:1.06,q):mix(.8,outcome==='criticalFailure'?.22:.4,q),
    toolSpread:good?-.13*q:(outcome==='criticalFailure'?.09:.2)*q,inspection:outcome==='criticalSuccess'?smooth((q-.34)/.4):0,
    interlock:outcome==='criticalFailure'?smooth(q/.34):0};
}

/** Token-effect frame. Coordinates use the established patient-local medical
 * unit (100 = one token width); no moving-bit coordinates or aperture diamonds
 * are present. Complexity depends only on quality and technique. */
export function sampleMedicalOutcome(effect={}){
  if(v7MedicalResultBounds(effect)){
    const local=sampleV7MedicalResult(effect);
    // Legacy repairs are small and local: their verdict contour stays inside
    // the compact result envelope around the repair site.
    if(effect.v9MedicalCraft===true)addOutcomeSignature(local,effect,{radius:17,cy:6,compact:true});
    return local;
  }
  const style=effect.style,definition=MEDICAL_OUTCOME_STYLES[style],outcome=effect.outcome;
  const p=clamp(effect.progress),strength=clamp(effect.strength??1,0,2),motion=sampleMedicalOutcomeMotion(style,outcome,p,{animated:effect.animated!==false});
  const frame={effect:'token-field',id:`medical-result-${style}`,color:'#ff00ff',strength:strength*motion.gain,count:clamp(effect.emitters?.length??1,0,4),paths:[],bounds:medicalOutcomeBounds(effect),phase:'finishing',outcome,medicalOutcome:true};
  if(!definition||effect.phase!=='finishing'||!MEDICAL_OUTCOMES.includes(outcome)||!strength||!motion.gain)return frame;
  const quality=effect.detail==='low'?0:effect.detail==='high'?2:1,steps=quality===0?8:quality===2?16:12;
  const q=effect.animated===false?.62:smooth(p),good=outcome==='success'||outcome==='criticalSuccess',critical=outcome==='criticalSuccess',abort=outcome==='criticalFailure';
  const gain=motion.gain*strength,signature=definition.signature;
  const add=(points,{alpha=.76,width=.85,plane='front',closed=false,fill=0,highlight=false,tint,fillTint=tint??MAGENTA,glow=false,role='result-structure'}={})=>{
    if(points.length<2||alpha*gain<.0001)return;
    // Completed joins use a broader seated highlight. Hardware edges retain
    // their original weights, keeping the result readable without a wire cage.
    frame.paths.push({points,alpha:clamp(alpha*gain),width:highlight?Math.max(width,1.65):width,plane,closed,fill:clamp(fill*gain,0,.14),highlight,tint,fillTint,glow:glow&&quality>0,role});
  };
  const line=(a,b,o={})=>add([a,b],o);
  const curve=(fn,o={})=>{const n=o.steps??steps,points=new Array(n+1);for(let i=0;i<=n;i++)points[i]=fn(i/n);add(points,o);};
  const cubic=(a,b,c,d,o={})=>curve(u=>{const v=1-u;return [v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*c[0]+u*u*u*d[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*c[1]+u*u*u*d[1]];},o);
  const rotate=(point,a)=>[point[0]*Math.cos(a)-point[1]*Math.sin(a),point[0]*Math.sin(a)+point[1]*Math.cos(a)];
  const oval=(x,y,rx,ry,o={})=>curve(u=>[x+rx*Math.cos(u*TAU),y+ry*Math.sin(u*TAU)],{closed:true,...o});
  const petal=(a,b,c,d,o={})=>{cubic(a,b,c,d,o);cubic(d,[c[0]*.67,c[1]*.7],[b[0]*.67,b[1]*.7],a,{...o,alpha:(o.alpha??.76)*.62});};
  const plate=(x,y,w,h,o={})=>add([[x-w,y-h+3],[x-w+3,y-h],[x+w-3,y-h],[x+w,y-h+3],[x+w,y+h-3],[x+w-3,y+h],[x-w+3,y+h],[x-w,y+h-3]],{closed:true,fill:.11,tint:PEARL,...o});
  const pin=(x,y,angle=0,o={})=>add([[-2,-4],[-2,4],[2,4],[2,-4]].map(v=>{const pt=rotate(v,angle);return [x+pt[0],y+pt[1]];}),{closed:true,tint:GOLD,width:.7,...o});
  const stop=(x,y,w,h,plane='front')=>{
    // Captive stop plates belong to that technique's rail/socket, not a badge.
    add([[x-w,y-h],[x-w,y+h],[x-w+3,y+h],[x-w+3,y-h]],{tint:STOP_EDGE,fillTint:STOP_ASH,alpha:.6,plane,width:.9,closed:true,fill:.06,role:'result-interlock'});
    add([[x+w,y-h],[x+w,y+h],[x+w-3,y+h],[x+w-3,y-h]],{tint:STOP_EDGE,fillTint:STOP_ASH,alpha:.6,plane,width:.9,closed:true,fill:.06,role:'result-interlock'});
  };
  const proofAlpha=smooth((q-.25)/.34)*.72;
  // Exceptional outcomes have a late, readable verification pass. A short
  // bright stroke follows each technique's authored proof geometry; it never
  // substitutes a universal flash or badge. Reduced motion holds this pass
  // at a clear inspection point. The packet adds no line density off its path.
  const proof=(fn,o={})=>{
    curve(fn,{alpha:proofAlpha,tint:ICE,width:.65,...o,role:'result-verification'});
    const local=smooth((q-.29-(o.delay??0))/.54),packetGain=smooth((q-.28-(o.delay??0))/.13);
    if(packetGain<=.0001)return;
    const tail=Math.max(0,local-.22);
    curve(u=>fn(mix(tail,local,u)),{...o,steps:5,closed:false,fill:0,alpha:packetGain*.98,width:2,
      highlight:true,glow:true,role:'result-verification-packet'});
  };
  const proofCubic=(a,b,c,d,o={})=>proof(u=>{const v=1-u;return [v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*c[0]+u*u*u*d[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*c[1]+u*u*u*d[1]];},o);
  const proofLine=(a,b,o={})=>proof(u=>[mix(a[0],b[0],u),mix(a[1],b[1],u)],{steps:1,...o});

  // Three Restorative techniques end from their own work art instead of their
  // family's drawing: Crystalline cast's hex plates, Soul threads' crossed
  // lacing and Mending veil's two drapes.
  const own=style==='crystalCast'?'crystal':style==='threadbind'?'lacing':style==='mendingVeil'?'drape':null;
  switch(own??definition.family){
    case 'crystal':{
      const n=Math.max(1,frame.count||2),rows=3+n;
      for(let j=0;j<rows;j++){
        const y=-40+j*80/(rows-1),half=Math.sqrt(Math.max(0,1-(y/54)**2))*44,cells=3+(j%2),w=2*half/cells,r=Math.min(w,80/(rows-1))*.56;
        const local=smooth(q*1.5-j/rows*.45);
        for(let c=0;c<cells;c++){
          const side=c-(cells-1)/2,drift=good||abort?0:local*side*7,fall=good||abort?0:local*(5+j*1.5),hold=abort?local*side*1.6:0;
          const x=-half+w*(c+.5)+drift+hold,yy=y+fall,rr=good?r*(1-.12*local):r;
          const hex=[[x,yy-rr],[x+rr*.86,yy-rr*.5],[x+rr*.86,yy+rr*.5],[x,yy+rr],[x-rr*.86,yy+rr*.5],[x-rr*.86,yy-rr*.5]];
          // success: the plate seams melt into the shell; failure: they crack and fall away
          add(hex,{closed:true,alpha:good?.7*(1-local*.8):abort?.5:.7*(1-local*.55),width:.7,tint:PEARL,fill:good?.05*(1-local):.04,plane:(j+c)%3===0?'rear':'front'});
          if(!good&&!abort)line([x-rr*.45,yy-rr*.35],[x+rr*.2,yy+rr*.1],{alpha:.7*local,width:.6,tint:PEARL});
        }
        if(abort)for(const sd of [-1,1])stop(sd*(half+5),y,2.4,r*.8);
      }
      if(good){
        oval(0,0,mix(52,47,q),mix(59,54,q),{alpha:q*.85,highlight:true,width:1.15,steps:steps*2});
        oval(0,0,47,54,{alpha:q*.5,fill:.06,tint:PEARL,width:.5,steps:steps*2,plane:'rear'});
        const g=-44+88*q;line([-34,g-7],[34,g+7],{alpha:Math.sin(Math.PI*q)*.8,width:1.1,highlight:true});
        if(critical)proof(u=>[Math.cos(-Math.PI/2+u*TAU)*52,Math.sin(-Math.PI/2+u*TAU)*59],{steps:steps*2,tint:ICE,width:.7});
      }
      break;
    }
    case 'lacing':{
      const n=Math.max(1,frame.count||2),wide=30+n*4,rows=4+n,ys=Array.from({length:rows},(_,j)=>-42+j*84/(rows-1));
      for(let j=0;j<rows-1;j++){
        const local=smooth(q*1.45-j/rows*.4);
        const aw=good?mix(wide*.77,4,local):abort?wide*.8:wide*(.81+.12*local),sag=good?(1-local)*2.5:abort?4:2.5+local*13;
        const lace=(sd,u)=>[sd*aw*(1-2*u),mix(ys[j],ys[j+1],u)+Math.sin(Math.PI*u)*sag];
        for(const sd of [-1,1]){
          if(abort){curve(u=>lace(sd,u*.38),{alpha:.6,width:.7,tint:PEARL});curve(u=>lace(sd,.62+u*.38),{alpha:.6,width:.7,tint:PEARL});}
          else curve(u=>lace(sd,u),{alpha:good?.55+.35*local:.7*(1-local*.5),width:good?.9:.75,highlight:good&&local>.6,tint:PEARL});
          const a=[sd*aw,ys[j]];add([[a[0],a[1]-2.4],[a[0]+1.6,a[1]],[a[0],a[1]+2.4],[a[0]-1.6,a[1]]],{closed:true,alpha:good?.5+.4*local:.5,fill:.1,tint:good?GOLD:abort?STOP_EDGE:PEARL,width:.6});
          if(abort&&j%2===0)stop(sd*(aw+5),(ys[j]+ys[j+1])/2,2.2,4);
        }
      }
      if(good){line([0,ys[0]],[0,ys.at(-1)],{alpha:q*.85,highlight:true,width:1.1});if(critical)for(const sd of [-1,1])proofLine([sd*5,ys[0]],[sd*5,ys.at(-1)],{tint:ICE,width:.6});}
      else if(!abort)for(const sd of [-1,1])curve(u=>[sd*wide*.9-sd*u*8,ys.at(-1)+u*(10+q*14)],{alpha:.55*q,width:.6,tint:PEARL});
      break;
    }
    case 'drape':{
      const n=Math.max(1,frame.count||2),hw=39+n*2;
      for(const sd of [-1,1]){
        const plane=sd<0?'rear':'front';
        if(good){
          // the drapes gather into one contour round the patient
          const R=mix(hw+7,35,q),edge=u=>[sd*R*Math.sin(Math.PI*u)**.6,-48+96*u];
          curve(edge,{alpha:.45+.45*q,highlight:q>.5,tint:PEARL,width:1,steps:steps*2});
          for(const f of [.4,.72])curve(u=>{const e=edge(u);return [e[0]*f,e[1]];},{alpha:.38*(1-q),width:.55,tint:PEARL,plane,steps:steps*2});
        }else{
          // pleats rise into their supports; a critical failure folds the open corners behind its catches
          for(let k=0;k<3;k++){
            const local=smooth(q*1.4-k*.08),x=sd*(14+k*10+(abort?0:local*6)),bottom=abort?48-local*12:48-local*58;
            curve(u=>[x+Math.sin(u*TAU*1.5+k)*2*(abort?0:local),mix(-48,bottom,u)],{alpha:.68*(1-local*(abort?.2:.45)),width:.7,tint:PEARL,plane});
          }
          if(abort){line([sd*14,36-q*12],[sd*hw,36-q*12],{alpha:.5,width:.6,tint:PEARL});stop(sd*(hw+3),-44,2.6,5,plane);}
          else plate(sd*(hw+4),-50,6,4,{alpha:.6,tint:PEARL});
        }
      }
      if(good){
        for(const y of [-48,48])cubic([-30,y],[-12,y+(y<0?-5:6)],[12,y+(y<0?-5:6)],[30,y],{alpha:q*.75,tint:y<0?GOLD:PEARL,highlight:y>0,width:y>0?1.05:.8});
        if(critical)for(const off of [-4,4])proofCubic([-34,48+off],[-12,55+off],[12,55+off],[34,48+off],{tint:ICE,width:.65});
      }
      break;
    }
    case 'stitch':{
      // An authored angle keeps upright lacing upright; seams default to a diagonal.
      const angle=definition.angle??(signature?-.2:-.42),rows=quality===0?5:7,tr=v=>rotate(v,angle);
      const gap=good?mix(8,1,q):mix(8,abort?11:22,q);
      for(const side of [-1,1])cubic(tr([side*gap,-37]),tr([side*(gap+2),-13]),tr([side*(gap-1),13]),tr([side*gap,37]),{alpha:.38,tint:MAGENTA});
      for(let j=0;j<rows;j++){
        const y=-31+j*62/(rows-1),local=smooth(q*1.5-j*.06),pull=good?local:1-local;
        if(good){
          const bow=(1-pull)*(signature?7:12);
          cubic(tr([-gap,y-2]),tr([-gap-9,y-bow]),tr([gap+9,y+bow]),tr([gap,y+2]),{highlight:true,width:signature?.66:1.0});
          if(signature)for(const d of [-1,1])line(tr([-gap,y+d*2]),tr([gap,y-d*2]),{alpha:.5,width:.5,tint:ICE});
          pin(...tr([0,y]),angle,{alpha:.34+.66*pull});
        }else{
          for(const side of [-1,1]){
            const x=side*(gap+local*(abort?3:8));
            cubic(tr([side*gap,y]),tr([x,y-8*(1-local)]),tr([x+side*6,y+4]),tr([x+side*8,y+(j%2?1:-1)*3]),{alpha:.85-local*.32,tint:PEARL,width:signature?.65:.85});
            if(abort&&j%2===0)stop(...tr([side*19,y]),3.2,4.5);
          }
        }
      }
      if(good)cubic(tr([0,-38]),tr([-1,-12]),tr([1,12]),tr([0,38]),{alpha:q*.8,highlight:true,width:1.1});
      if(critical)for(const side of [-1,1])proofCubic(tr([side*12,-39]),tr([side*19,-8]),tr([side*19,8]),tr([side*12,39]),{tint:signature?ICE:GOLD,width:.8});
      break;
    }
    case 'textile':{
      const veil=signature===1,rows=quality===0?5:7,half=veil?35:26,angle=veil?0:-.55,tr=v=>rotate(v,angle);
      for(let i=0;i<rows;i++){
        const y=-30+i*60/(rows-1),local=smooth(q*1.45-i*.055),lift=good?(1-local)*5:local*(abort?7:21);
        const at=u=>{
          const x=mix(-half,half,u),pleat=veil?6*Math.sin(u*Math.PI)**2:1.4*Math.sin(u*TAU*3);
          return tr([x, y+pleat*(good?1-local:1+local*.35)-lift+(!good?(i%2?1:-1)*local*4:0)]);
        };
        if(abort){
          curve(u=>at(u*.4),{alpha:.65,tint:PEARL});curve(u=>at(.6+u*.4),{alpha:.65,tint:PEARL});
          if(i%2===0)for(const side of [-1,1])stop(...tr([side*(half+5),y-lift]),3.5,3.5);
        }else curve(at,{alpha:.8-local*(!good?.32:0),highlight:good,width:veil?.8:.65});
      }
      if(!veil)for(let i=0;i<(quality===0?5:7);i++){
        const x=-23+i*46/(quality===0?4:6),spread=good?1:1+q*.24;
        curve(u=>tr([x*spread+(!good?Math.sin(u*Math.PI)*q*5:0),mix(-31,31,u)-(good?0:q*9)]),{alpha:good?.38:.27,tint:MAGENTA,width:.45});
      }
      if(good){
        const halfY=veil?37:32;
        cubic(tr([-half,-halfY]),tr([-half*.6,-halfY-4]),tr([half*.6,-halfY-4]),tr([half,-halfY]),{alpha:q*.7,tint:GOLD});
        cubic(tr([-half,halfY]),tr([-half*.6,halfY+(veil?9:4)]),tr([half*.6,halfY+(veil?9:4)]),tr([half,halfY]),{alpha:q*.9,highlight:true,width:1.1});
        for(const side of [-1,1])cubic(tr([side*half,-halfY]),tr([side*(half+4),-8]),tr([side*(half+4),8]),tr([side*half,halfY]),{alpha:q*.65,tint:PEARL});
        if(critical)for(const offset of [-4,4])proofCubic(tr([-half-5,halfY+offset]),tr([-half*.6,halfY+(veil?12:6)+offset]),tr([half*.6,halfY+(veil?12:6)+offset]),tr([half+5,halfY+offset]),{tint:ICE,width:.7});
      }else{
        for(const side of [-1,1])plate(...tr([side*(half+8),-33-q*8]),veil?7:5,5,{alpha:.6,tint:GOLD});
        if(abort)line(tr([-half-6,-42]),tr([half+6,-42]),{tint:STOP_EDGE,alpha:.6,width:1});
      }
      break;
    }
    case 'support':{
      const cradle=signature===1,joints=quality===0?4:6;
      if(cradle){
        for(let j=0;j<joints;j++){
          const x=-43+j*86/(joints-1),local=smooth(q*1.4-j*.07),y=27+Math.abs(x)*.22+(good?(1-local)*7:local*(abort?7:18));
          const bend=good?(1-local)*6:local*10;
          cubic([x-6,y-bend],[x-4,y+7],[x+4,y+7],[x+6,y+bend],{width:1.25,highlight:good,alpha:.9});
          pin(x,y+5,0,{alpha:.7,tint:GOLD});
          if(abort)stop(x,y+4,6,8);
          if(critical)proofCubic([x-7,y+12],[x-4,y+18],[x+4,y+18],[x+7,y+12],{tint:ICE,width:.75,plane:'rear',delay:j*.018});
        }
        for(const side of [-1,1])cubic([side*46,-32],[side*57,-3],[side*54,30],[side*42,46],{width:.9,tint:PEARL,plane:'rear'});
      }else{
        for(const side of [-1,1]){
          const x=side*(good?mix(30,24,q):mix(30,abort?34:45,q));
          for(let j=0;j<joints-1;j++){
            const y=-39+j*78/(joints-1),next=y+78/(joints-1),bend=good?(1-q)*(j%2?3:-3):q*(j%2?5:-5);
            plate(x+bend,(y+next)/2,2.8,(next-y)/2-2,{alpha:.82,width:.8,tint:PEARL});
            pin(x+bend,y,Math.PI/2,{alpha:.9});
            if(abort)stop(x+bend,(y+next)/2,6,(next-y)/2-1);
          }
          for(const y of [-27,27])cubic([x,y],[x-side*(good?14*q:4),y-7],[x-side*(good?14*q:4),y+7],[x,y+7],{alpha:.8,tint:good?GOLD:PEARL,width:.85,plane:'rear'});
          if(critical)proofCubic([side*37,-44],[side*45,-18],[side*45,18],[side*37,44],{tint:ICE,width:.8});
        }
      }
      break;
    }
    case 'flow':{
      const lanes=quality===0?4:6;
      for(const side of [-1,1]){
        const x=side*(signature===1?37:30),y=side*(signature===2?35:39);
        plate(x,y,6,9,{tint:GOLD,width:.8});
        if(abort)stop(x,y,9,12);else line([x-4,y+4],[x+4,y+4],{alpha:.65,width:1.1,highlight:good});
      }
      for(let j=0;j<lanes;j++){
        const y=-28+j*56/(lanes-1),side=j%2?1:-1,local=smooth(q*1.5-j*.07);
        let route;
        if(signature===0)route=u=>{const x=-26+u*52;return [x,y+Math.sin(u*Math.PI)*(j%2?7:-7)];};
        else if(signature===1)route=u=>{const x=-36+u*72;return [x,y*.7+Math.sin(u*TAU*1.5+j*.7)*(4*(1-(good?q*.45:0)))];};
        else route=u=>{const x=side*(29-17*Math.sin(u*Math.PI));return [x,mix(-35,35,u)];};
        if(good){
          curve(route,{alpha:.58,width:signature===1?.65:.9,tint:PEARL});
          const end=local;
          curve(u=>route(mix(Math.max(0,end-.13),end,u)),{steps:4,width:1.5,highlight:true,glow:true,role:'result-transfer'});
          const terminal=route(1);pin(...terminal,signature===2?0:Math.PI/2,{alpha:local*.9});
          if(critical){
            // A separate return lane visibly verifies the completed transfer;
            // repainting the same route in a new colour would be too subtle.
            const verify=u=>{const at=route(1-u),off=4+Math.sin(u*Math.PI)*2;return signature===2?[at[0]-side*off,at[1]]:[at[0],at[1]+off];};
            proof(verify,{alpha:proofAlpha*.88,width:.75,tint:ICE,delay:j*.016});
            const at=verify(.52);pin(at[0],at[1],signature===2?0:Math.PI/2,{alpha:proofAlpha,tint:GOLD,width:.7});
          }
        }else{
          const edge=abort?mix(.46,.34,local):Math.max(.05,.48-local*.4);
          curve(u=>route(u*edge),{alpha:.76,width:.8,tint:PEARL});curve(u=>route(1-u*edge),{alpha:.76,width:.8,tint:PEARL});
          if(abort){for(const u of [edge,1-edge])pin(...route(u),Math.PI/2,{tint:STOP_EDGE,alpha:.65,width:.9});}
          else for(const u of [.07+.12*(1-local),.93-.12*(1-local)]){const at=route(u);line([at[0]-2,at[1]-1],[at[0]+2,at[1]+1],{highlight:true,width:1});}
        }
        if(signature===2){const at=route(.5);plate(at[0],at[1],4,6,{alpha:.6,tint:ICE,width:.55});}
      }
      if(signature===1&&good){plate(0,0,5-q*2,8-q*3,{alpha:.6+q*.4,tint:GOLD});pin(0,0,0,{alpha:smooth((q-.3)/.4)*.8,highlight:true});}
      break;
    }
    case 'iris':{
      const count=signature?6:4,seat=good?q:0,outer=signature?41:47;
      for(let i=0;i<count;i++){
        const angle=i*TAU/count+(signature?-.2:Math.PI/4),local=smooth(q*1.4-i*.04),gap=good?mix(25,signature?8:12,local):mix(25,abort?30:42,local),tr=v=>rotate(v,angle);
        const shape=signature?[[gap,-9],[gap+16,-15],[outer+8,-4],[outer+4,10],[gap+5,12]]:[[gap,-10],[gap+14,-17],[gap+23,-8],[gap+23,8],[gap+14,17],[gap,10]];
        add(shape.map(tr),{alpha:.7,width:.85,closed:true,fill:.07,tint:PEARL});
        line(tr([gap,-7]),tr([gap,7]),{alpha:.9,width:1.25,highlight:good,tint:good?undefined:GOLD});
        if(abort)add([[gap+4,-11],[gap+4,11],[gap+10,11],[gap+10,-11]].map(tr),{width:.9,tint:STOP_EDGE,alpha:.6,closed:true});
        if(critical)proofLine(tr([gap+7,-8]),tr([gap+7,8]),{tint:ICE,width:.75,delay:i*.014});
      }
      if(good){
        const r=signature?13:16,vertices=signature?6:4;
        curve(u=>[Math.cos(u*TAU)*(r-seat*3),Math.sin(u*TAU)*(r-seat*3)],{steps:vertices,closed:true,alpha:q*.9,width:1.2,highlight:true});
        if(critical){
          const at=u=>{const v=Math.min(vertices-1e-8,u*vertices),i=Math.floor(v),f=v-i,a=i*TAU/vertices,b=(i+1)*TAU/vertices;return [mix(Math.cos(a),Math.cos(b),f)*(r+7),mix(Math.sin(a),Math.sin(b),f)*(r+7)];};
          proof(at,{steps:vertices,closed:true,tint:GOLD,width:.9});
        }
      }else{
        const r=abort?12:9;add([[-r,-r],[-3,-2],[-r,r]],{alpha:.85,tint:PEARL});add([[r,-r],[3,2],[r,r]],{alpha:.85,tint:PEARL});
        if(abort)stop(0,0,17,19);
      }
      break;
    }
    case 'optics':{
      if(signature){
        for(let i=0;i<(quality===0?2:3);i++){
          const depth=(i-1)*(good?mix(17,5,q):mix(17,abort?23:32,q)),angle=(i-1)*.20,pts=[[-28,-25],[24,-31],[30,21],[-23,29]].map(v=>{const a=rotate(v,angle);return [a[0]+depth,a[1]+depth*.38];});
          add(pts,{closed:true,fill:.05,width:.9,alpha:.55,plane:i===0?'rear':'front',tint:i===1?PEARL:ICE});
          if(abort)for(const point of [pts[0],pts[2]])stop(point[0],point[1],5,7);
        }
        if(good){const x=-23+46*q;line([x,-24],[x+7,23],{highlight:true,width:1.1});if(critical){
          const y=27-54*q;proofLine([-25,y],[25,y-7],{tint:GOLD,width:.95});
          add([[-23,-17],[18,-25],[27,17],[-16,25]].map(v=>rotate(v,-.34)),{closed:true,fill:.028,alpha:proofAlpha*.65,tint:ICE,width:.7,plane:'rear'});
        }}
      }else{
        const seat=good?q:0,spread=good?0:q*(abort?8:18),tip=[-4,-4];
        add([[-46-spread,-33],[-28-spread,-30],[-12-seat*3,-12],tip],{width:1.15,highlight:good,tint:PEARL});
        const jaw=good?mix(9,2,q):mix(9,abort?5:16,q);
        for(const side of [-1,1])add([[45+spread,32],[28+spread,29],[12+side*jaw,10+side*jaw],[4+side*jaw,4+side*jaw]],{width:.9,tint:GOLD});
        if(good){cubic([-13,20],[-7,8],[2,-2],[10,-17],{width:1.2,highlight:true,alpha:q*.9});pin(-4,-4,-.65,{alpha:q});}
        else if(abort){plate(-28,-30,9,7,{width:.8,tint:STOP_EDGE,fillTint:STOP_ASH,alpha:.6,fill:.06});plate(28,29,9,7,{width:.8,tint:STOP_EDGE,fillTint:STOP_ASH,alpha:.6,fill:.06});}
        if(critical)proofCubic([-23,25],[-24,-2],[-5,-23],[21,-26],{width:.8,tint:ICE});
      }
      break;
    }
    case 'spiral':{
      const turns=signature?1.45:2.5,r=good?mix(signature?40:30,signature?32:24,q):mix(signature?40:30,abort?35:45,q),n=steps*2;
      for(let strand=0;strand<2;strand++){
        const route=u=>{const angle=u*TAU*turns+strand*Math.PI+(good?q*.55:-q*.8);return [Math.cos(angle)*r,-48+96*u,Math.sin(angle)];};
        let run=[],plane=null;
        for(let j=0;j<=n;j++){
          const u=j/n,point=route(u),next=point[2]>=0?'front':'rear';
          if(!good&&u>.41&&u<.59){if(run.length>1)add(run,{plane,tint:PEARL,width:.85});run=[];continue;}
          if(next!==plane&&run.length){run.push(point.slice(0,2));add(run,{plane,tint:strand?ICE:PEARL,width:strand?.65:1.0});run=[point.slice(0,2)];}else run.push(point.slice(0,2));plane=next;
        }
        add(run,{plane:plane??'front',tint:strand?ICE:PEARL,width:strand?.65:1.0});
      }
      for(const side of [-1,1]){
        const y=side*50;add([[-r-7,y-3],[-r-3,y+4],[r+3,y+4],[r+7,y-3]],{width:.85,tint:GOLD,plane:side<0?'rear':'front'});
        if(abort)stop(0,side*12,r+8,5,side<0?'rear':'front');
        if(good)line([-r*.65,y],[r*.65,y],{alpha:q*.8,highlight:true,width:1.1});
      }
      if(critical)proof(u=>{const angle=-u*TAU*(signature?1.4:2.5);return [Math.cos(angle)*(r+6),-48+96*u];},{tint:GOLD,width:.75});
      break;
    }
    case 'pulse':{
      if(signature===0||signature===2){
        const resonant=signature===0,span=resonant?43:53;
        for(const side of [-1,1]){
          const x=side*(span+7);plate(x,0,4,resonant?18:9,{tint:GOLD,width:.75});
          if(abort)stop(x,0,7,resonant?22:13);
        }
        const route=u=>{const x=mix(-span,span,u),wave=resonant?Math.sin(u*TAU*2)*10:Math.sin(u*TAU)*6+Math.exp(-(((u-.44)/.045)**2))*(-22)+Math.exp(-(((u-.50)/.045)**2))*14;
          return [x,wave*(good?mix(1.3,1,q):1+q*.4)+(good?0:(u<.5?-1:1)*q*9)];};
        if(good){curve(route,{highlight:true,width:1.1});if(critical)proof(u=>{const a=route(u);return [a[0],a[1]+(resonant?7:5)];},{tint:ICE,width:.8});}
        else{curve(u=>route(u*.42),{width:.95,tint:PEARL});curve(u=>route(.58+u*.42),{width:.95,tint:PEARL});if(abort){pin(...route(.42),0,{tint:STOP_EDGE,alpha:.65});pin(...route(.58),0,{tint:STOP_EDGE,alpha:.65});}}
      }else if(signature===1){
        const rows=quality===0?3:4;
        for(let j=0;j<rows;j++){
          const y=24-j*20+(good?-q*7:q*17),r=43-j*3;
          const route=u=>[mix(-r,r,u),y+9*Math.sin(u*Math.PI)];
          if(abort){curve(u=>route(u*.4),{tint:PEARL,width:1});curve(u=>route(.6+u*.4),{tint:PEARL,width:1});stop(0,y+8,11,5);}
          else curve(route,{tint:good?undefined:PEARL,highlight:good,width:1});
          if(critical)proof(u=>[mix(-r-3,r+3,u),y+5+10*Math.sin(u*Math.PI)],{tint:ICE,width:.7,plane:'rear',delay:j*.018});
        }
        for(const side of [-1,1])plate(side*47,35,6,4,{tint:GOLD});
      }else{
        for(const side of [-1,1]){
          const x=side*28,y=35;
          cubic([x-13,y-9],[x-12,y+14],[x+12,y+14],[x+13,y-9],{width:1.0,tint:PEARL});
          line([x-12,y-9],[x+12,y-9],{width:.7,tint:GOLD,plane:'rear'});
          const fillY=y+4-(good?q*12:-q*3);line([x-8,fillY],[x+8,fillY],{alpha:.7,width:1.2,highlight:good});
          const target=[side*7,-20];
          if(good)cubic([x,y-6],[x,8],[side*20,-16],target,{alpha:.45+q*.4,width:1.0,highlight:true});
          else cubic([x,y-6],[x,17],[side*(32+q*8),13],[side*39,24],{alpha:.7,width:.9,tint:PEARL});
          if(abort){
            stop(x,y-10,14,4);
            const shutter=q*9;line([x-12,y-10],[x-12+shutter,y-10],{width:.95,tint:STOP_EDGE,alpha:.6});line([x+12,y-10],[x+12-shutter,y-10],{width:.95,tint:STOP_EDGE,alpha:.6});
          }
          if(critical)proofCubic([x,y+7],[x+side*12,10],[side*28,-25],target,{width:.75,tint:ICE});
        }
        if(good)cubic([-12,-20],[-6,-24],[6,-24],[12,-20],{alpha:q*.9,highlight:true,width:1.2});
      }
      break;
    }
    case 'canopy':{
      const petals=signature===1,n=petals?4:6;
      for(let i=0;i<n;i++){
        const a=(i+.5)*TAU/n,x=Math.cos(a)*(petals?44:48),depth=Math.sin(a),plane=depth<0?'rear':'front';
        const local=smooth(q*1.45-i*.045),tip=[0,-58],edge=[x,23+depth*14],spread=good?1-local*.12:1+local*(abort?.10:.27);
        const open=good?local*.1:local*.23,top=[x*open,tip[1]+(!good?local*13:0)],end=[edge[0]*spread,edge[1]+(!good?local*6:0)];
        if(petals)petal(top,[x*1.12,-48],[x*1.18,14],end,{plane,alpha:.7,width:.95,tint:PEARL});
        else cubic(top,[x*.8,-47],[x*1.17,-2],end,{plane,alpha:.75,width:.85,tint:PEARL});
        if(good)cubic(end,[end[0]*.72,48],[end[0]*.28,48],[0,44],{plane,alpha:local*.85,width:1.0,highlight:true});
        else if(abort)stop(end[0],end[1],5,7,plane);
        if(critical)proofCubic([0,-52],[x*.74,-32],[x*.78,22],[0,39],{plane,tint:petals?ICE:GOLD,width:.7,delay:i*.014});
      }
      if(abort)add([[-45,31],[-34,42],[34,42],[45,31]],{tint:STOP_EDGE,alpha:.6,width:.95,plane:'front'});
      if(good)pin(0,44,Math.PI/2,{alpha:q,tint:GOLD});
      break;
    }
    case 'lattice':{
      const rows=quality===0?3:4,cols=rows;
      for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){
        const baseX=(i-(cols-1)/2)*17,baseY=(j-(rows-1)/2)*16,local=smooth(q*1.5-(i+j)*.045);
        const x=baseX+(good?0:Math.sign(baseX)*local*(abort?4:13)),y=baseY+(good?(1-local)*9:local*(abort?6:15));
        add([[x-7,y-6],[x+7,y-6],[x+9,y+5],[x-5,y+7]],{closed:true,fill:.045,width:.8,tint:PEARL,alpha:.8});
        if(good){line([x-6,y],[x+7,y],{alpha:local*.65,highlight:true,width:.8});if(critical)proofLine([x-5,y+5],[x+6,y-5],{tint:ICE,width:.75,delay:(i+j)*.012});}
        else if(abort){if(i===0||i===cols-1)stop(x,y,10,9);line([x-5,y-4],[x-1,y],{tint:PEARL,width:.9});line([x+2,y+1],[x+6,y+4],{tint:PEARL,width:.9});}
      }
      for(const side of [-1,1])line([side*42,-42],[side*42,43],{plane:'rear',tint:GOLD,width:.75});
      if(good)line([-37,38],[37,38],{alpha:q*.85,highlight:true,width:1.15});
      else line([-42,43+q*6],[42,43+q*6],{tint:abort?STOP_EDGE:GOLD,alpha:abort?.6:.76,width:abort?.95:.75});
      break;
    }
  }
  if(effect.v9MedicalCraft===true)addOutcomeSignature(frame,effect);
  return frame;
}

/** V10 verdict contour. Every technique keeps its own authored ending; this
 * one shared, quiet contour says which of the four results happened, using
 * Ellie's palette: a contracting magenta seal and blush on success, gold
 * glints on a critical success, a dull broken ring that drifts open on a
 * failure, and fractured ember arcs on a critical failure. It enters after
 * the technique's own result has begun and leaves with the same envelope. A
 * handful of short paths; reduced motion holds one readable tableau. */
const SEAL_GOLD='#f2d49c',EMBER='#ff6283',ASH='#b8a0b3';
function addOutcomeSignature(frame,effect,{radius=53,cx=0,cy=0,compact=false}={}){
  const outcome=effect.outcome;if(!MEDICAL_OUTCOMES.includes(outcome)||effect.phase!=='finishing')return;
  const p=clamp(effect.progress),animated=effect.animated!==false;
  const envelope=p>0&&p<1?smooth(p/.14)*smooth((1-p)/.19):0,gain=clamp(effect.strength??1,0,2)*envelope;if(!(gain>0))return;
  const quality=effect.detail==='low'?0:effect.detail==='high'?2:1,n=compact?16:quality===0?20:quality===2?40:30;
  const q=animated?smooth(p):.62,seat=animated?smooth((p-.26)/.36):1;if(seat<=0)return;
  const push=(points,{alpha,width=1,closed=false,fill=0,tint,fillTint=tint,glow=false,plane='front'})=>{
    const a=clamp(alpha*gain);if(a<.002)return;
    frame.paths.push({points,alpha:a,width:compact?width*.8:width,plane,closed,fill:clamp(fill*gain,0,.14),highlight:false,tint,fillTint,glow:glow&&quality>0,role:'result-signature'});
  };
  const arc=(r,a0,a1,steps)=>{const pts=new Array(steps+1);for(let i=0;i<=steps;i++){const a=a0+(a1-a0)*i/steps;pts[i]=[cx+Math.cos(a)*r,cy+Math.sin(a)*r];}return pts;};
  if(outcome==='success'||outcome==='criticalSuccess'){
    const critical=outcome==='criticalSuccess',r=radius*mix(1.16,1,seat);
    push(arc(r,0,TAU,n),{closed:true,alpha:(critical?.66:.56)*seat,width:critical?1.3:1.1,tint:critical?SEAL_GOLD:MAGENTA,fill:(critical?.12:.09)*seat,fillTint:MAGENTA,glow:true});
    if(critical){
      push(arc(r*.9,0,TAU,n),{closed:true,alpha:.34*seat,width:.6,tint:MAGENTA});
      const turn=animated?seat*.55:.3,size=(compact?.45:1)*(1.6+2.4*seat);
      for(let i=0;i<4;i++){const a=TAU*(i/4+1/8)+turn,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;
        push([[x,y-size*1.6],[x+size*.55,y],[x,y+size*1.6],[x-size*.55,y]],{closed:true,alpha:.92*seat,width:.7,tint:SEAL_GOLD,fill:.14,glow:true});}
    }
    return;
  }
  const abort=outcome==='criticalFailure',parts=abort?7:8,span=TAU/parts;
  for(let i=0;i<parts;i++){
    // Failure: dull segments slide open and away. Critical failure: fractured
    // ember arcs alternate inward/outward and shimmer once, then hold safe.
    const mid=(i+.5)*span+.35,open=abort?.34:.18+.22*q,a0=mid-span*(1-open)/2,a1=mid+span*(1-open)/2;
    const r=radius*(1.03+(abort?(i%2?.07:-.05)*seat:.10*q));
    // one soft brightening pass travels round the arcs, once
    const shimmer=abort&&animated?.85+.3*Math.exp(-(((p-.4-i*.03)/.07)**2)):1;
    push(arc(r,a0,a1,compact?3:5),{alpha:(abort?.78:.62*(1-.3*q))*seat*shimmer,width:abort?1.2:.95,tint:abort?EMBER:ASH,glow:true});
  }
}
