import {ID} from './config.mjs?v=13.0.0-beta.1';
import {lanternControlToken} from './lantern-controls.mjs?v=13.0.0-beta.1';

/** This optional held control borrows the existing character pin. It creates
 * only a local indicator and releases without depending on a final key event. */
export function registerV8Controls(manager){
  if(!globalThis.game?.keybindings?.register)return false;
  let held=null;
  const stop=()=>{
    const hud=held;held=null;
    hud?.locateBits?.(false);
    return !!hud;
  };
  globalThis.Hooks?.on?.('canvasTearDown',stop);
  globalThis.window?.addEventListener?.('blur',stop);
  globalThis.document?.addEventListener?.('visibilitychange',()=>{if(document.hidden)stop();});
  game.keybindings.register(ID,'locateBits',{
    name:'Locate bits (hold)',
    hint:'Briefly highlight the pinned character’s deployed instruments and their jobs. Release to clear. No key is assigned by default.',
    editable:[],uneditable:[],restricted:false,repeat:false,
    onDown:context=>{
      const service=manager.bits?.service;
      const token=lanternControlToken(context,service?.hud?.prefs);
      if(!token||held)return false;
      const hud=service?.hudController?.();
      if(!hud?.locateBits)return false;
      held=hud;
      try{hud.locateBits(true,token);return true;}
      catch(error){stop();manager.report?.(error);return false;}
    },onUp:stop
  });
  return true;
}
