import {featherLightFragment} from './wing-light-edge.mjs?v=13.0.0-beta.1';
import {lightUniformLayoutChanged,setLightShaderProgram,markLightShaderUniformsDirty,invalidateLightUniformLayout,lightShaderLayers,setLightUniform,noteLightUniformChange} from './light-shader-binding.mjs?v=13.0.0-beta.1';
import {v7RefractionFragment,setV7RefractionUniforms,releaseV7RefractionUniforms,V7_REFRACTION_UNIFORMS} from './v7-light-refraction.mjs?v=13.0.0-beta.1';

export const LIGHT_APPEARANCE_UNIFORMS=Object.freeze(['ffLightPhase','ffLightDetail','ffLightGain','ffLightDisruption','ffLightRecovery','ffLightDirection','ffLightHalfAngle','ffLightFullCircle']);
const finite=(value,fallback)=>Number.isFinite(value)?value:fallback;
const clamp=(value,min=0,max=1)=>Math.min(max,Math.max(min,value));
const sourceCode=source=>source.replace(/^\s*#define\s+SHADER_NAME[^\r\n]*(?:\r?\n|$)/gm,'');
const uncomment=source=>source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,part=>part.replace(/[^\n]/g,' '));

export function lightAppearanceUniforms(sample={}, {angle=0,width=360,strength=1}={},storage=null,values=null){
  const direction=finite(angle,0)*Math.PI/180,cone=clamp(finite(width,360),1,360);
  const vector=storage??new Float32Array(2);vector[0]=Math.cos(direction);vector[1]=Math.sin(direction);
  const output=values??{};
  output.ffLightPhase=finite(sample.phase,0);output.ffLightDetail=clamp(finite(sample.detail,0))*clamp(finite(strength,1));
  output.ffLightGain=clamp(finite(sample.gain,1),.12,1);output.ffLightDisruption=clamp(finite(sample.disruption,0));
  output.ffLightRecovery=clamp(finite(sample.recovery,0));output.ffLightDirection=vector;
  output.ffLightHalfAngle=cone*Math.PI/360;output.ffLightFullCircle=cone>=359.999?1:0;
  return output;
}

/** Native depth is adjusted before scene composition. Curved filaments only
 * modulate native coloration, so transparent/dark background fragments never
 * become an extra light overlay. There is one output and no texture/pass. */
export function lightAppearanceFragment(fragment,layer='coloration',kind='circle'){
  if(typeof fragment!=='string'||!['background','illumination','coloration'].includes(layer)||!['circle','lantern'].includes(kind))return null;
  const inspected=uncomment(fragment),mains=[...inspected.matchAll(/\bvoid\s+main\s*\(\s*(?:void\s*)?\)\s*\{/g)],outputs=[...inspected.matchAll(/\bgl_FragColor\s*=\s*([^;]+);/g)];
  if(inspected.includes('ffLightPhase')||/^\s*#\s*define\s+(?:depth|gl_FragColor)\b/m.test(inspected)||mains.length!==1||outputs.length!==1||
    ! /\bvarying\s+(?:(?:highp|mediump|lowp)\s+)?vec2\s+vUvs\s*;/.test(inspected))return null;
  const main=mains[0],output=outputs[0],bodyStart=main.index+main[0].length;
  let nesting=1,bodyEnd=bodyStart;
  for(;bodyEnd<inspected.length&&nesting;bodyEnd++){if(inspected[bodyEnd]==='{')nesting++;else if(inspected[bodyEnd]==='}')nesting--;}
  if(nesting||output.index<bodyStart||output.index>=bodyEnd||! /\bfloat\s+depth\s*=/.test(inspected.slice(bodyStart,output.index)))return null;
  const uniforms=`uniform float ffLightPhase;\nuniform float ffLightDetail;\nuniform float ffLightGain;\nuniform float ffLightDisruption;\nuniform float ffLightRecovery;\nuniform vec2 ffLightDirection;\nuniform float ffLightHalfAngle;\nuniform float ffLightFullCircle;\n`;
  // Insert at the depth declaration rather than the final output: a lantern's
  // coloration has already copied its composed result into ffLanternOutput.
  const declaration=[...inspected.slice(bodyStart,output.index).matchAll(/\bfloat\s+depth\s*=[^;]+;/g)][0];
  if(!declaration)return null;
  const gainAt=bodyStart+declaration.index+declaration[0].length;
  const gain=`\n  depth*=ffLightGain*(1.0-ffLightDetail*0.028*(0.5+0.5*sin(ffLightPhase)));\n`;
  let finalOutput=fragment.slice(output.index,output.index+output[0].length);
  if(layer==='coloration'){
    const expression=fragment.slice(inspected.indexOf('=',output.index)+1,output.index+output[0].length-1);
    const pattern=kind==='circle'?`
    float ffLightTurn=atan(ffLightPoint.y,ffLightPoint.x);
    float ffLightCurveA=0.30+0.070*sin(ffLightTurn*2.0-ffLightPhase)+0.030*sin(ffLightTurn*3.0+ffLightPhase*2.0);
    float ffLightCurveB=0.59+0.090*sin(ffLightTurn*3.0+ffLightPhase)+0.026*sin(ffLightTurn*2.0-ffLightPhase*2.0);
    float ffLightCurveC=0.78+0.040*sin(ffLightTurn*2.0-ffLightPhase*2.0);
    float ffLightThreads=exp(-pow((ffLightRadius-ffLightCurveA)/0.014,2.0))
      +0.72*exp(-pow((ffLightRadius-ffLightCurveB)/0.012,2.0))
      +0.40*exp(-pow((ffLightRadius-ffLightCurveC)/0.011,2.0));
    float ffLightFlow=0.35+0.65*pow(0.5+0.5*sin(ffLightTurn*2.0-ffLightPhase*2.0+ffLightRadius*5.0),2.0);
    float ffLightBreak=0.5+0.5*sin(ffLightTurn*5.0+ffLightPhase*3.0);
`:`
    float ffLightForward=dot(ffLightPoint,ffLightDirection);
    float ffLightSide=dot(ffLightPoint,vec2(-ffLightDirection.y,ffLightDirection.x));
    float ffLightSigned=atan(ffLightSide,ffLightForward)/max(0.0087,ffLightHalfAngle);
    float ffLightWander=0.050*sin(ffLightRadius*6.0-ffLightPhase)+0.016*sin(ffLightRadius*10.0+ffLightPhase*2.0);
    // Wider conducting filaments carry broad packets away from the token.
    // Six phase turns still take 6.5 seconds per packet, without a sharp
    // front, flicker or extra light geometry. Default beam strength remains
    // legible rather than attenuating the appearance twice.
    float ffLightThreads=exp(-pow((ffLightSigned+ffLightWander)/0.052,2.0))
      +0.80*exp(-pow((ffLightSigned-0.34+ffLightWander*0.8)/0.046,2.0))
      +0.72*exp(-pow((ffLightSigned+0.34-ffLightWander*0.7)/0.050,2.0))
      +0.40*exp(-pow((ffLightSigned-0.66+ffLightWander*0.5)/0.042,2.0))
      +0.36*exp(-pow((ffLightSigned+0.66-ffLightWander*0.6)/0.044,2.0));
    float ffLightFlow=0.18+0.82*pow(0.5+0.5*sin(ffLightRadius*13.0-ffLightPhase*6.0),2.0);
    float ffLightBreak=0.5+0.5*sin(ffLightRadius*17.0+ffLightSigned*3.0-ffLightPhase*3.0);
    ffLightThreads*=1.0-ffLightFullCircle;
`;
    finalOutput=`vec4 ffLightOutput=${expression};
  if(ffLightDetail>0.0){
    vec2 ffLightPoint=(vUvs-vec2(0.5))*2.0;
    float ffLightRadius=length(ffLightPoint);
    if(ffLightRadius>0.00001){${pattern}
      ffLightThreads*=smoothstep(0.06,0.20,ffLightRadius)*(1.0-smoothstep(0.76,0.96,ffLightRadius));
      ffLightFlow*=1.0-ffLightDisruption*0.70*smoothstep(0.42,0.78,ffLightBreak);
      ${kind==='lantern'?`float ffLightPower=sqrt(ffLightDetail);
      float ffLightFilament=ffLightThreads*ffLightFlow*ffLightPower*(0.76+0.12*ffLightRecovery);
      float ffLightRibbon=0.13*ffLightFlow*ffLightPower*smoothstep(0.08,0.24,ffLightRadius)*(1.0-smoothstep(0.70,0.96,ffLightRadius));
      float ffLightBed=0.27*ffLightPower;`:'float ffLightFilament=ffLightThreads*ffLightFlow*ffLightDetail*(0.28+0.08*ffLightRecovery);'}
      // A quiet bed leaves contrast even when the native magenta is already
      // saturated. Threads recover that small dip instead of relying solely
      // on additive brightness that would clip to the same flat color.
      ${kind==='lantern'?'ffLightOutput.rgb=min(ffLightOutput.rgb*(vec3(1.0-ffLightBed)+vec3(1.0,0.14,1.0)*(ffLightFilament+ffLightRibbon)),vec3(ffLightOutput.a));':'ffLightOutput.rgb=min(ffLightOutput.rgb*(vec3(1.0-0.085*ffLightDetail)+vec3(1.0,0.14,1.0)*ffLightFilament),vec3(ffLightOutput.a));'}
    }
  }
  gl_FragColor=ffLightOutput;`;
  }
  return fragment.slice(0,main.index)+uniforms+fragment.slice(main.index,gainAt)+gain+fragment.slice(gainAt,output.index)+finalOutput+fragment.slice(output.index+output[0].length);
}

export function setLightAppearanceUniforms(shader,sample,options={},record=null){
  if(record){record.appearanceDirection??=new Float32Array(2);record.appearanceValues??={};}
  const oldX=record?.appearanceDirection?.[0],oldY=record?.appearanceDirection?.[1];
  const values=lightAppearanceUniforms(sample,options,record?.appearanceDirection,record?.appearanceValues);
  if(oldX!==values.ffLightDirection[0]||oldY!==values.ffLightDirection[1])noteLightUniformChange(shader);
  for(const name of LIGHT_APPEARANCE_UNIFORMS){
    if(record&&!record.uniforms.has(name))record.uniforms.set(name,{exists:Object.hasOwn(shader.uniforms,name),value:shader.uniforms[name]});
    setLightUniform(shader,name,values[name]);
  }
}

/** Circular light owns a single combined edge/appearance program while the
 * edge controller retains only the shared native visibility mask. */
export class LightAppearanceShaders {
  constructor({report=null}={}){
    this.sources=new Map();this.shaders=new WeakMap();this.programs=new WeakMap();this.report=report;this.warnings=new Set();
    globalThis.Hooks?.on?.('initializePointLightSourceShaders',source=>{const entry=this.sources.get(source);if(entry&&!entry.nativeInitializing)this.update(source,entry.sample,entry.options);});
  }
  restore(shader){
    const record=this.shaders.get(shader);if(!record)return;
    if(shader.program===record.patched)setLightShaderProgram(shader,record.original,{layoutChanged:true});
    for(const [name,previous]of record.uniforms){if(previous.exists)shader.uniforms[name]=previous.value;else delete shader.uniforms[name];}
    invalidateLightUniformLayout(shader);markLightShaderUniformsDirty(shader);
    this.shaders.delete(shader);
  }
  restoreEntry(entry){for(const shader of entry.shaders)this.restore(shader);entry.shaders.clear();entry.active=false;}
  update(source,sample={},options={}){
    if(!source||typeof source!=='object')return {active:false,error:null};
    let entry=this.sources.get(source);if(!entry){entry={shaders:new Set(),sample,options,active:false,error:null};this.sources.set(source,entry);}else Object.assign(entry,{sample,options});
    const layers=lightShaderLayers(source,entry);
    for(const shader of entry.shaders)if(!layers.some(([,value])=>value.shader===shader)){this.restore(shader);entry.shaders.delete(shader);}
    entry.error=null;
    if(!sample.enabled||source.active===false||source.suppressed===true||source.hasActiveLayer===false||!layers.length){this.restoreEntry(entry);return this.status(source);}
    try{
      const changes=[],edge=clamp(finite(options.edgeAttenuation,0)),legacy=sample.legacyEnabled!==false,refraction=sample.refraction?.enabled===true&&sample.refraction.strength>0;
      for(const [layer,{shader}]of layers){
        if(!shader.uniforms||typeof shader.uniforms!=='object')throw new Error('A source shader has no supported uniform object.');
        let record=this.shaders.get(shader);
        if(record&&shader.program!==record.patched&&shader.program!==record.original){this.restore(shader);record=null;}
        if(!record){const original=shader.program;if(!original||typeof original.vertexSrc!=='string'||typeof original.fragmentSrc!=='string')throw new Error('A source shader exposes no supported native program.');record={original,patched:null,uniforms:new Map(),direction:new Float32Array(2)};}
        let programs=this.programs.get(record.original);if(!programs){programs=new Map();this.programs.set(record.original,programs);}
        const key=`${layer}:${edge>0?'edge':'native'}:${legacy?'appearance':'current'}${refraction&&layer==='coloration'?':refraction':''}`;let patched=programs.get(key);
        if(patched?.error)throw new Error(patched.error);
        if(!patched){const base=edge>0?featherLightFragment(record.original.fragmentSrc):record.original.fragmentSrc;
          let fragment=legacy?lightAppearanceFragment(base,layer,'circle'):base;
          if(refraction&&fragment)fragment=v7RefractionFragment(fragment,layer);
          if(!fragment){const error=`The ${layer} shader has an unsupported native output.`;programs.set(key,{error});throw new Error(error);}
          if(typeof globalThis.PIXI?.Program?.from!=='function')throw new Error('The native shader program factory is unavailable.');
          patched=PIXI.Program.from(sourceCode(record.original.vertexSrc),sourceCode(fragment));programs.set(key,patched);
        }
        changes.push({layer,shader,record,patched});
      }
      for(const {layer,shader,record,patched}of changes){
        const namesKey=`${legacy}:${edge>0}:${refraction&&layer==='coloration'}`;
        if(record.namesKey!==namesKey){record.namesKey=namesKey;record.ownedNames=[...(legacy?LIGHT_APPEARANCE_UNIFORMS:[]),...(edge>0?['ffWingEdgeWidth']:[]),...(refraction&&layer==='coloration'?V7_REFRACTION_UNIFORMS:[])];}
        const names=record.ownedNames;
        const layoutChanged=lightUniformLayoutChanged(shader,record,names);
        this.shaders.set(shader,record);entry.shaders.add(shader);
        if(legacy)setLightAppearanceUniforms(shader,sample,{width:360},record);
        else for(const name of LIGHT_APPEARANCE_UNIFORMS)if(record.uniforms.has(name)){
          const previous=record.uniforms.get(name);if(previous.exists)shader.uniforms[name]=previous.value;else delete shader.uniforms[name];record.uniforms.delete(name);
        }
        if(refraction&&layer==='coloration')setV7RefractionUniforms(shader,sample.refraction,sample,record);
        else releaseV7RefractionUniforms(shader,record);
        if(edge>0){if(!record.uniforms.has('ffWingEdgeWidth'))record.uniforms.set('ffWingEdgeWidth',{exists:Object.hasOwn(shader.uniforms,'ffWingEdgeWidth'),value:shader.uniforms.ffWingEdgeWidth});setLightUniform(shader,'ffWingEdgeWidth',edge*.5);}
        else if(record.uniforms.has('ffWingEdgeWidth')){const previous=record.uniforms.get('ffWingEdgeWidth');if(previous.exists)shader.uniforms.ffWingEdgeWidth=previous.value;else delete shader.uniforms.ffWingEdgeWidth;record.uniforms.delete('ffWingEdgeWidth');}
        record.patched=patched;setLightShaderProgram(shader,patched,{layoutChanged});markLightShaderUniformsDirty(shader,{changedOnly:true});
      }
      entry.active=true;
    }catch(error){this.restoreEntry(entry);entry.error=String(error?.message??error);if(!this.warnings.has(entry.error)){this.warnings.add(entry.error);try{this.report?.(new Error(`Animated light detail is unavailable; native lighting remains active. ${entry.error}`));}catch{}}}
    return this.status(source);
  }
  initializeNative(source,data,options){
    // Core may recreate its layer uniforms during initialization. Decorate once
    // after the complete native call, rather than once in its shader hook and
    // again immediately on return with the same current sample.
    const entry=this.sources.get(source);if(entry)entry.nativeInitializing=true;
    try{return source.initialize(data,options);}finally{if(entry)entry.nativeInitializing=false;}
  }
  status(source){const entry=this.sources.get(source);return {active:!!entry?.active,error:entry?.error??null};}
  release(source){const entry=this.sources.get(source);if(!entry)return;this.restoreEntry(entry);this.sources.delete(source);}
  clear(){for(const source of [...this.sources.keys()])this.release(source);}
}
