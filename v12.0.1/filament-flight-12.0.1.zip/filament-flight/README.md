# Yvaelle's Toolbox 12 (Filament Flight)

Version 12 adds four warps and the Cloak warp, three shield styles, three landing styles, cloak speeds, the Decoy, menus on the map for everything she has sent out, a quick wheel with previews on its gems, and its own sounds in two styles. Everything in it has a switch: **HUD › Settings**. See `docs/v12.0.0-release.md`.

Filament wings, Resonant Core instruments and hardlight medicine for Ellie, on Foundry VTT 14. Version 10 adds the Keepsake HUD, warps, routines, a specimen gallery, flight manoeuvres, new Medkit treatments and per-feature Versions switches. Install notes are in [START-HERE](START-HERE.md); what changed in each beta is in `docs/v10.0.0-beta.*-release.md`.

Version 11 adds her acting token (portrait and frame), wounds by damage type, thirteen invisibility looks, emotes, the nested quick wheel with its Hardlight look, healing and bit moments, and her wings reacting to walls, light and height. Everything in it has a switch: **HUD › Settings**. See `docs/v11.0.0-release.md`.

## Using the v10 features

- **Flight manoeuvres** are automatic. Take off (not just *Wings*), then move her: her wings bank into curved paths, flare forward when she stops, lag and swing round when she turns back, and rise with a slower beat when she descends or lands. To see them without moving her, use **HUD › Settings › Animation › See the manoeuvres › Show me**. They are off on the ground and with Reduced motion on. The switch for them is in the same group.
- **Routines** play around Ellie for everyone: **HUD › Effects › Routines**, the quick wheel, or `api.routines.play(token, id)`. *Mechanical iris* and *Specimen in light* need a token: if you haven't targeted exactly one, the routine asks you to click it on the canvas (Esc cancels). *Watch Out!* asks for the threat, then uses a second target or the nearest friendly token as the ally.
- **Specimens.** Play *Specimen in light*, click a token and write a short note. Two bits hold a light copy of it for everyone, then it is filed on Ellie's actor. **HUD › Effects › Specimens** lists them: *Present again* shows one to everyone, *Delete* removes it (it asks you to confirm).
- **Warp** through the quick wheel or `api.warp(token)`: pick a visible spot and she folds through space. Seam, Threaded and Flicker are the three looks.
- **Versions.** **HUD › Settings › Versions** switches each overhauled feature back to its earlier behaviour on its own.

---

# Filament Flight 9.0.1 (earlier notes)

Filament wings, Resonant Core instruments and hardlight medicine for Ellie, on Foundry VTT 14. The module includes individual instruments and split groups, wing and token-effect libraries, optional actor-condition reactions, private animation previews, custom Looks, and separate quality controls for you and other players. The existing Resonant Core design and animation are preserved.

**V9.0.1** targets repeated light-edge mask mesh construction during movement. Native wall/vision updates, light range, art and update cadence remain. Read the [moving-light patch notes](docs/v9.0.1-release.md).

**V9.0.0** follows the ranked review: scoped recovery, native patient registration, trustworthy private previews, truthful save feedback, clearer compact controls, current scan-wall certification, shared wall geometry and more useful local measurement. New optional wing gestures and signature/medical craft refine the existing canonical filaments and Resonant Core instruments. Read [START-HERE](START-HERE.md), the [v9 foundation release](docs/v9.0.0-release.md) and [current API guide](docs/v9-api.md).

The two new artwork switches can be disabled independently. Classic medical choreography, remembered diagnostic opt-out, reduced motion and personal quality/mute remain available. No new game mechanics are inferred from visual effects.

## Earlier release history

The paragraphs below describe their named historical releases. They are not the current validation index.

**V8.8.10** gives Medkit treatments an optional patient scan using the existing token-scanning artwork. **Diagnostic scan before treatment** in the Medkit animation options remembers your choice, including when you close the menu without treating. The scan uses the existing 1.6-second preparation stage and hands directly into the chosen treatment. Reimport the bundled Medkit macro to receive the switch. See `docs/v8.8.10-release.md`.

**V8.8.9** targets performance throughout the existing module: scan routes and sampling, display-frame preparation, native bit/wing/medical painting, portrait masks and light visibility. Current artwork, quality and timing are preserved. See `docs/v8.8.9-release.md` for the final measurements and verification scope.

**V8.8.8** refines existing formation handoffs, interrupted lantern fades, wing material updates and medical depth joins. It removes repeated scan, formation, wing and medical preparation and unnecessary light uniform uploads while preserving scan art, quality and animation cadence. See `docs/v8.8.8-release.md` for measured results and their limits.

**V8.8.7** gives scanning bits distinct inspection stations, substantial smooth relocations, held readings and an occasional full-body circuit around the token. See `docs/v8.8.7-release.md`.

**V8.8.5** gives deliberate examination a purposeful approach, held reading, retraction and closed turn, with physical mechanisms timed to that sequence. See `docs/v8.8.5-release.md`.

**V8.8.4** smooths instrument orientation during scans, refines close token examination, and reduces repeated work in both circular and lantern lighting. See `docs/v8.8.4-release.md`.

**V8.8.3** makes following instruments accelerate and brake smoothly as Ellie changes pace. Short-step scanning continuity, wall-aware travel and the V8.8.2 performance fixes remain. See `docs/v8.8.3-release.md`.

**V8.8.2** fixes abrupt group recalls during normal one-cell movement and reduces repeated scan, visibility and hover-preview work. Current scanning styles, quality settings and pace remain available. See `docs/v8.8.2-release.md` for the fixes and the limits of offline performance measurements.

**V8.8.1** adds private animated previews when hovering or focusing any scanning-style choice. Creature, soft area and optional geometric styles can be inspected before enabling them. See `docs/v8.8.1-release.md`.

**V8.8.0** refines everyday instrument work: edit active tasks through a local preview, pause and resume scans, finish a placed survey once, lock the lantern onto a visible subject or scene point, and apply or customize three practical light presets. Following scans withdraw their optics for rapid travel and settle back into work. Creature examinations gain deliberate movement with a **Previous movement** option. Wall-aware work and interrupted-task handoffs receive dedicated validation. See `docs/v8.8.0-release.md`.

**V8.7.0** adds genuine 2×2 four-bit scans to every soft and optional geometric area style. Full teams choose between four-cell blocks and lines where the region allows, then branch into the existing varied smaller groups. Each bit owns one native cell; geometric blocks share one exterior frame with no internal cross. Drawn areas and scans following Ellie use the same layouts. See `docs/v8.7.0-release.md`.

**V8.6.0** adds five optional geometric area styles alongside the five soft styles. Cooperating instruments share one continuous field and exterior frame across their assigned cells; internal cell edges do not become separate box dividers. **Bit tools → Scanning styles → Geometric fields** lets you enable them individually or mix them with soft fields. Geometric styles start unchecked, preserving current selections. The natural instrument movement from V8.5 remains. See `docs/v8.6.0-release.md`.

**V8.5.0** loosens cooperative area work with asymmetric instrument stations, individual curved approaches and restrained inspection motion. Area light stays centered on native grid cells while using soft, uneven acquisition shapes instead of visible cell frames. Broad openings, spatial branching, one cell per bit, five selectable styles per category, token-only examinations and player-drawn regions remain. See `docs/v8.5.0-release.md`.

**V8.4.0** opens area work with a broad coordinated team, then branches into nearby unscanned patches with varied solos, pairs, trios and full teams. Each working bit contributes one native cell; each team shares one calm field. Exposures last about eight seconds at the default pace, with quiet movement between them. Two new creature styles and two new area styles bring each category to five. **Bit tools → Scanning styles** saves individual style switches for this character; a visible pass finishes smoothly before a changed selection applies. Full-token transparency masks, player-drawn regions, medicine returns and the V8.3 movement optimizations remain. See `docs/v8.4.0-release.md`.

**V8.3.0** performs one shared occupied-space survey, then confines deep scanning to the visible token image using its native transparency. Instruments alternate full-token coded-light, crossed-laser and pulsed point-reconstruction methods. Area work alternates multi-cell swaths, range rings and sampling clusters. Players can draw and edit rectangles, ellipses and polygons in a styled local region tool, then rehearse the scan before confirming; no Scene Region permissions are needed. Movement and drag previews avoid further repeated native sprite writes, flag reads and allocations; deep scan channels share a single cached alpha composite. See `docs/v8.3.0-release.md` and `docs/v8.3.0-performance-deep-dive.md`.

**V8.2.0** aligns area scans to native square and hex grids, briefly examines visible creatures once per active scan, then returns each attending bit to its paused area duty. Direct examinations survey occupied space once before circling the portrait and scanning complementary regions. New scans default to 0.60× pace; Bit tools includes a saved new-scan pace and live per-job pace controls from 0.25× to 1.50×. Optical passes vary between coded fringes, sampled dots and contour reconstruction. Movement removes redundant native mesh writes and repeated diagnostic work while retaining the original wing geometry, quality and repaint caps. See `docs/v8.2.0-release.md`.

**V8.1.0** gives the four physical instruments purposeful area and creature examinations, an adjustable scan emanation that follows Ellie, and real parked or companion lights. A small Bit tools icon opens these jobs; a tiny guarded Undo arrow and light-adjustment chevron fit beside the existing controls. Destination commands rehearse locally as translucent thoughts before confirmation. Instruments move, settle, scan and withdraw before repositioning, with varied coverage and staggered timing. Medicine can borrow working instruments and return them to their continuing jobs; a newer explicit command wins. Weighty travel, visible-obstacle transfers and a temporary working posture have per-character settings. Original-only wings, HP/status reactions and existing medical mechanics remain. V8.1 replaces the fan-shaped scan with coded surface bands, point acquisition and contour returns. Creature examinations traverse the entire displayed token in alternating full-height and full-width passes, including wide, tall, rotated and scaled portraits. See `docs/v8.1.0-release.md` and `docs/v8-bit-tools-api.md`.

**V7.9.0** optimizes the live wing, bit, light, medical and preview paths while preserving their artwork, animation clocks, quality settings and repaint caps. It avoids repeated geometry setup, redundant mesh transforms, duplicate health reads, per-frame uniform allocations and repeated settings-search normalization. Original-only wings, all 41 status effects, V7 appearance/gesture controls and the compact Home layout remain. All bundled assets, audio and macros remain unchanged. See `docs/v7.9.0-release.md` for measured CPU results and verification scope.

**V7.8.0** keeps the **Original filament wings as the only structure**, removes the alternate-form selector and Form size box, and gives Home a more compact two-column flight layout. All 41 automatic status effects still articulate the original ribs and web. V7 appearance and animation features remain available in Settings, grouped with Appearance, Animation, Bits and Medical animations; only their extra Home shortcut is removed. Saved alternate forms load as Original without changing actor conditions or bit jobs. Existing medical animations, macros and all 418 bundled assets are preserved. See `docs/v7.8.0-release.md` and `docs/condition-animation-roster.md`.

**V7.6.0** replaces minor shape reactions with 38 complete status wing bodies: cages, shutters, crystalline fans, repaired sails, puppet spars, propulsion fins and more. Stunned keeps its graduated glitching, Unconscious keeps Reform, and Fatigued keeps familiar usable wings with weighted recovery strokes. The new states own their topology and cadence, retain live HP wear, and give the bits real support contours to follow. See `docs/v7.6.0-release.md` and `docs/condition-animation-roster.md`.

**V7.5.0** gives every relevant PF2e/SF2e condition its own fitting native wing animation. It adds 17 reaction programs, damage-type-aware persistent injury, actual SF2 effect detection, and more distinct motion for existing states. See `docs/v7.5.0-release.md` and `docs/condition-animation-roster.md`.

**V7.4.1** adds graduated Stunned reactions, grounding for Prone/Paralyzed/Stunned 3, a tiny status-reaction toggle, milder Fatigued wings, and fixes for bit placement and prone recovery. See `docs/v7.4.1-release.md`.

**V7.4.0** keeps automatic HP damage and glitch responses visible alongside selected wing artwork and actor-condition reactions. Seventeen additional PF2e conditions receive automatic wing reactions with individual switches and strength controls. See `docs/v7.4.0-release.md`.

**V7.3.0** gives 46 count-specific bit formations visibly moving routes, adds eight new projected effects, and changes the libraries to click selection followed by **Activate**. Favourites now open a selected private preview. The default core animation responds to projection work, and previews use the actual source duties. See `docs/v7.3.0-release.md` for the exact changed names.

**V7.2.0** rebuilds the eight additional Medkit techniques around the physical bits. Their cores feed short projected instruments; those instruments lay stitches, press margins, align a brace, deliver restorative packets, cleanse a contact, trace a precise repair, revive a measured rhythm, or draw a protective dressing. Material forms at the actual tool contacts, and the four result endings complete or release that same repair. Existing appearance controls and Medicine/HP behavior remain. See `docs/v7.2.0-release.md`.

**V7.1.1** strengthens the twelve rebuilt medical treatments at normal token size with translucent material faces, wider seated joins, and clearer safety interlocks. It also repairs cancelled instrument returns after a long browser suspension. All 22 treatment styles retain four result endings, and the Random and formation controls remain. See `docs/v7.1.1-release.md`.

**V7.1.0** rebuilds Suture weave, Microloom dressing, Articulated splints, Mending veil and all eight V7 field medicine treatments with distinct material bodies and purposeful toolwork. All 22 treatments gain separate 2.4-second endings for critical failure, failure, success and critical success when enhanced medicine is enabled. The Medkit's per-use **Enhanced preparation, results and release** switch retains the classic route. Random · each use and the formation icon remain available. See `docs/v7.1.0-release.md`.

**V7.0.5** adds a small formation button to the left of the nearby/next-summon slider. Click to toggle random formation on each explicit summon of retracted bits; Shift-click to toggle the existing smooth automatic formation flow around Ellie. The R and ↻ indicators show each independent mode, including while retracted. This release also bundles the updated Random Medkit macro. See `docs/v7.0.5-release.md`.

**V7.0.4** keeps the Medkit's source diamond attached to each moving bit instead of holding it in the patient's cached artwork. Its animation and the larger healing effects retain their existing paint cadence. See `docs/v7.0.4-release.md`.

**V7.0.3** reduces the crystal-light shimmer while bits move by filtering their cropped textures with mipmaps and retaining fractional placement. Artwork, animation cadence, treatment behaviour and the v7.0.2 optimizations remain. See `docs/v7.0.3-release.md`.

**V7.0.2** removes Lunar glow and chosen ensemble presence, shares completed artwork during token dragging, defers the Original wing atlas until needed, avoids identical bit repaints, and reuses medical geometry within each painted frame. Lossless asset and manifest changes preserve the artwork and sound. The remaining gemstone, filament, formation, lighting and medical additions keep independent switches. See `docs/v7.0.2-release.md`.

**V7.0.1** repaired gemstone brightness popping, interrupted action motion, cold Flow preparation and unnecessary rendering/control work. Those repairs remain. See `docs/v7.0.1-release.md` for the earlier repair scope.

**V6.6.6** repairs recovered actor state after restarts and deploys available stabilizing bits when opening grounded wings. See `docs/v6.6.6-release.md`.

**V6.6.5** adds an optional wing-style lantern wash for grounded bits without wings, retains bit health animations while projecting, and turns both lights off on deliberate bit retraction. See `docs/v6.6.5-release.md`.

**V6.6.4** adds an automatic airborne lantern state. With the wings out and Ellie in flight, the bits keep their live stabilizing positions and power a broader, blended magenta light from those positions. Aiming no longer gathers them into the ground projector formation. Grounded and bits-only lanterns retain their token-origin projection. See `docs/v6.6.4-release.md`.

**V6.6.2** introduces a new transparent filament veil for the lantern. Its authored wisps flow and deform gently through the light. Native magenta colour remains stronger in dark scenes. Advanced settings offer Filament veil, Plain magenta, and Previous pattern; the previous animation retains the corrected colour. Circular lighting, bit powering, aiming and manual light-off retraction stay intact. See `docs/v6.6.2-release.md`.

**V6.6.1** repairs magenta light after switching from circular to lantern mode, makes the home bits’ coordinated powering and slow cone flow clearer, and clears light intent when the home bits are deliberately retracted as a group. Existing circular appearance, previous-light rollback, Soft / Classic edges and reduced-motion controls remain. See `docs/v6.6.1-release.md`.

**V6.6.0** adds an animated magenta light appearance for circular and lantern lighting, optional responses to the wings’ condition and an Advanced setting to return to the current appearance. Existing lantern edge styles, light controls and bit artwork remain. See `docs/v6.6.0-release.md` and `docs/v6.6.0-lighting-api.md`.

**V6.5.10** reduces repeated runtime calculations and repainting while preserving the current artwork, motion and lighting controls. See `docs/v6.5.10-release.md`.

**V6.5.9** gives the lantern a softer light/darkness boundary by default, with the previous **Classic** appearance available in Advanced settings. One header light button now handles both modes: click for circular light, Shift-click for lantern. Starting either summons available home bits; normal-click an active light to stop it and retract them, or Shift-click to stop it and keep them out. See `docs/v6.5.9-release.md`.

**V6.5.8** adds staged lantern ignition and shutdown. Home bits gather into a count-specific cradle, keep moving and articulating while projecting, then return when the light turns off. The single magenta cone still originates at the token. See `docs/v6.5.8-release.md`.

**V6.5.7** projects one animated magenta lantern cone from the token. Available home bits animate together to generate it, with slow coordinated movement and articulated projection hardware. See `docs/v6.5.7-release.md`.

**V6.5.5** adds a mouse-aimed directional bit lantern, restrained count-specific instrument animation and optional lantern / Take off–Land keybindings. All new keys are unassigned by default. See `docs/v6.5.5-release.md`.

**V6.5.4** smooths instrument housing turns, automatic work expressions and internal core-state changes, including deployed-count changes, interrupted handoffs and long sessions. Front/back handoffs wait until the painted bit clears the token. Existing formation paths, artwork and saved settings remain. See `docs/v6.5.4-release.md` for the verified scope and reproduction limits.

**V6.5.3** repairs later automatic formation circuits and forced lane swaps during work gestures. Stabilization waves follow each instrument’s live attention, including selected targets, wing support and work episodes. See `docs/v6.5.3-release.md`.

**V6.5.2** lets each stabilization wave face its own attention target in any direction, with slow turns and continuous handoffs. See `docs/v6.5.2-release.md`.

**V6.5.1** repairs opposite-side slot assignment during automatic formation flow and adds slow, restrained intent-directed stabilization waves. See `docs/v6.5.1-release.md`.

**V6.5.0** adds Acknowledge, Beckon, Make Room, Poise, Flourish and Recalibrate; directions preserve the displayed formation's side assignments and depth. Optional gemstone depth adds faint internal facet shading and is off by default. See `docs/v6.5.0-release.md` and `docs/v6.5.0-instrument-api.md`.

**V6.4.0** adds sixteen living formation routines, Inspect / Attend / Confer / Settle directions, optional smooth formation cycling and small native hardlight tools while preserving the current Resonant Core design. Upper stabilization fields now retain their material span through flapping instead of jumping between outline edges. See `docs/v6.4.0-release.md` and `docs/v6.4.0-instrument-api.md`; all earlier release notes remain in `docs`.

## Install

1. Stop Foundry. Replace `Data/modules/filament-flight` with the `filament-flight` folder in **Filament-Flight-v9.0.1-Foundry-v14.zip**. Replace the folder rather than merging it so obsolete files are removed.
2. Restart Foundry and reload connected browsers. The HUD footer and API version should show **9.0.1**.
3. The Medkit macro is unchanged from 9.0.0. If upgrading from an earlier release, reimport **macros/Ellies-Medkit-Macro.json**, or replace the command in your existing Medkit macro with **macros/Ellies-Medkit-Macro.js**, to receive the remembered diagnostic-scan switch. Keep your working Yvaelle GM Bridge. Medicine rules and Random · each use are unchanged.
4. Open the HUD with `await game.modules.get("filament-flight").api.openHUD()` or the supplied HUD macro.

Existing schema-2 flight flags, custom positions, saved Looks and effect selections remain supported. Individual bit assignments use a separate versioned flag. The optional Validation download contains development tests, benchmarks and render checks; it is not required to run the module.

## Home and the four diamonds

Home is the central, default tab between Effects and Settings. One collapsible cycling panel moves directly between Flight & wings and each occupied bit group, with arrows and small shortcuts. The personal header combines state-aware text, subtly animated artwork, a thin HP filament, condition label and light switch. Header artwork, palette, scale, decoration, reactive text, header animation and menu motion remain customisable. Settings is the main home for detailed controls, with search, groups and favourites. Searching covers Simple and Advanced controls and hides unrelated controls and empty sections. Clear the query to return to the normal settings layout. Adjust links in Flight, Bits and Effects open only the requested settings; Back restores the previous page, bit group and scroll position. All settings opens the complete collection. Hidden controls keep their saved values, and Back does not undo changes. Number controls and sliders ignore the mouse wheel.

- **Light — while off:** click for circular light, or Shift-click for directional lantern. Both summon available home bits when needed, without opening the wings or taking off. **While either light is on:** click to stop both module lights and retract available home bits; Shift-click stops both lights and keeps the bits out. Remote assignments and treatment reservations keep their jobs. Lantern aiming appears while the lantern is active; detailed light controls stay in Settings.
- **Wings** opens or retracts the wings without taking off or landing. Opening them also summons available local bits to stabilize them; away bits and treatment reservations keep their jobs.
- **Character pin and keys:** select your character on the canvas and choose **Pin character** in the HUD, or choose their token in the HUD's control-target dropdown. The pin follows their actor when the GM places a new token on another scene, including unlinked tokens. All four optional keys in **Configure Controls → Filament Flight** require this pin and are unassigned by default: Toggle bit lantern, Aim bit lantern (hold), Take off / Land, and Summon / Retract bits. Keys act on the owned pinned character in the current scene, even when another token is selected. An absent character or ambiguous duplicate stays inactive; pin the intended copy to choose it. Follow selection disables keys until a character is pinned again.
- **Take off / Land** is one state-sensitive flight button. On a new takeoff, available retracted bits fill the preferred local count. **Land** recalls and retracts all deployed instruments; **Shift-click Land** keeps them out with their current assignments and actions. Wing folding follows its separate landing preference. Shift-click Take off behaves like normal Take off.
- **Bits — normal click:** with diamonds selected, retract only those deployed instruments; if the selected instruments are all retracted, summon that selection. With no selection, retract all deployed instruments or summon the preferred count. **Shift-click** returns selected remote instruments around Ellie, or all remote instruments when nothing is selected; local/retracted instruments stay as they are. Unselected assignments and treatment partners remain untouched. The count slider adjusts the local group and remembers the next deployment count when retracted.
- **Each tiny diamond represents the same instrument.** Left-click a retracted bit to summon it, a bit beside Ellie to retract it, or an away bit to recall it to Ellie. Its tooltip explains its current state.
- **Send selected bits:** Shift-click diamonds, or hold Left Shift and drag across them, to select them. Starting on a selected diamond paints deselection; starting on an unselected one paints selection for the whole gesture. Target one visible token, then click the small dispatch icon beside the diamonds. Selection alone moves nothing. Target changes update the control immediately; another target can receive another selected group. A successful send clears its submitted highlights. Failed sends keep the selection for retry; newer selections made while sending remain intact.
- **Quick effects** have selectable library variants; Home pins provide fast access to your preferred effects. The Effects tab retains all quick effects. New explicit bit commands take precedence over an older treatment’s return.

The shared Home carousel gives Flight and occupied bit locations the same compact heading, arrows and direct-selection shortcuts. It expands or collapses without adding a second group header. Switching groups changes the controls you are viewing; it does not move instruments. Movement and Token effect have clear current-choice cards, Browse & preview buttons and pinned favourites. Core state choices and detailed movement/energy controls remain available through focused Settings, clearly labelled for the selected group. Favourites apply directly; browsing remains local until Apply. The preview shows the selected group and actual participating count. Friendly names are shown only when appropriate; neutral and enemy recipients use anonymous labels. Group controls affect that group's formation, radius, personality, optional internal state and token effect. Attach to wings and individual custom positions are in advanced settings.

Light appearance controls are in **Advanced → Fit, light & performance → Scene illumination → Shared light appearance**. Choose Animated filaments or Current appearance, and independently control visual wing reactions. **Use previous appearance** restores the prior artwork with new reactions disabled. Soft / Classic lantern edges remain separate. **Lantern artwork** in Advanced Scene illumination selects Evolving light, Filament veil (6.6.2), Plain magenta, or Previous pattern (6.6.1). Evolving light is the default for an unset module preference; saved explicit choices remain. Its currents change independently of aiming, with a small internal response to turns. Plain magenta always disables the cone pattern. Previous pattern and Current appearance restore the earlier animation, while retaining the corrected dark-scene colour. Reduced motion holds the decorative detail still.

The small up/down collapse chevron is removed. Click the Home panel heading to expand or collapse it; keyboard activation and the left/right cycle arrows still work.

With lantern mode active, open wings use the same magenta wing wash while grounded or flying. The bits continue their normal wing stabilization and health responses; aiming steers the wash without gathering them into the token projector. Closing the wings blends into the saved grounded lantern style. Grounded bits without wings can still choose **Wing-style wash from bits** in Advanced lantern settings.

## Ellie's living portrait

Choose **Settings → Appearance → Portrait expression set**:

- **Original** keeps the existing restrained injury artwork and is the default.
- **Resolute** shows determination giving way to strain, a guarded eye and exhaustion.
- **Pained** replaces the smile with increasingly visible discomfort, winces and weary expressions.

Every set follows healthy, light, wounded, severe and critical HP bands, with a matching unconscious appearance at each band. Unconsciousness at positive HP keeps that level of injury; zero HP uses the critical unconscious portrait. The sets share the unchanged original healthy portrait and the five unconscious appearances. Their original 3:2 composition, identity, clothing and wing decoration remain. No blinking is added: an eye held shut is part of its expression. Subtle breathing and hair motion become more restrained with worsening health.

HP and set changes blend from the currently visible image, including interrupted damage, recovery and menu redraws. They follow actual HP and Unconscious even when a wing condition is selected manually. Menu interactions can prompt a restrained glance or energy response. In Appearance, independently control HP appearance, portrait motion, movement strength and interaction responses. Appearance bands use your existing HP thresholds. Custom header images keep their own artwork; clear the custom path to use the built-in sets. Reduced motion, hidden/minimized panels and disabled animation stop the motion work.

The portrait loader keeps a small cache of display-sized surfaces and releases outgoing layers after transitions. It does not load the entire portrait collection when the HUD opens. Clicking an already-active top-level tab now retains the current scroll, selection and preview instead of restarting navigation; a focused Settings view can still return to the full Settings collection.

## Formations, internal animation and energy effects

All **32 original compact routines** remain: Orbit, Drift, Weave, Patrol, Curious, Escort, Social and Vigil each have separate choreography for one, two, three and four instruments. V6 adds Atelier, Shelter, Lanterns and Relay, also with separate 1–4-bit choreography, for 48 routines. V6.4 adds Curious Companions, Quiet Exchange, Attentive Escort and Living Workshop, each with four count variants, for 64 routines; v7 adds eight further families, each with four count variants, for **96 routines total**. Personality routines add restrained inspections and exchanges, with optional passive energy gestures. Setting personality to zero keeps their behaviour composed. Formation changes, including interrupted changes and radius adjustments, blend from the displayed positions. Dispatch and return paths start where each instrument is actually visible. Stable identities occupy the appropriate count-specific formation slots.

Beside open wings, **Living stabilization** shares the workload between available instruments. Four hold their saved centres; three make small outward corrections; two patrol the upper and lower support points on opposite sides; one travels around the wings and briefly braces at each of the four points. Its energy strengthens while stabilizing. The placement map shows the actual resting wing contours and all four saved support anchors, including when fewer bits are out. Changing count does not replace these coordinates with another preset. Movement strength controls three-bit corrections and one/two-bit travel speed; disabling movement, setting its strength to zero or enabling reduced motion holds the anchors still. The Resonant Core design and close token formations retain their own animations.

**Current animation** remains the default core state. Additional choices are Action responsive, Crystal encased, Open for work, Building energy, Guarding and Settling. These augment the Resonant Core's existing housing and crystal. V6 adds Diagnostic sweep, Protective lock, Precision alignment, Resting machinery and Current conductor. These add small moving mechanisms and energy accents around the same crystal and housing. Treatment activity temporarily takes precedence and then releases the instruments.

The **32 selectable token effects** each respond to one through four assigned instruments:

| Category | Effects |
| --- | --- |
| Protective fields | Shelter bubble, Interception plates, Petal guard, Sanctuary arch, **Kinetic bracing, Grounding array**, Facet ward, Deflection fins, Light bridge |
| Restorative light | Restorative tide, Mending veil, Renewal spiral, Steady heartline, **Decontamination, Nerve calm** |
| Awareness & direction | Guiding light, Lantern crown, Survey sweep, Living compass, **Phase veil, Focus lock**, Contour scan, Sector search, Prism relay |
| Resonance & motion | Comet court, Tether weave, Resonance chime, Bloom seal, **Emergency reserve, Impulse drive**, Signal pennants, Filament loom |

Energy begins at the participating instruments: source connections and travelling currents follow their live positions and depth as they project and maintain the structure. Activation, replacement and shutdown blend instead of discarding the field instantly. These are cosmetic. A shield effect does not add an AC bonus or consume a game action. Macros can enable, configure and stop the same effects through the API.

The eight new fields give bits count-specific work sites and roles. Kinetic bracing opposes travel; Grounding array drains energy into contact shoes; Decontamination collects traces; Nerve calm regulates branching impulses; Phase veil overlays thin refractive surfaces; Focus lock aligns lenses with Ellie's visible target; Emergency reserve maintains external energy cells; Impulse drive follows the attended token's movement. Stationary or untargeted states settle naturally. These additions use the HUD library and existing effect API; Medkit treatment choices are unchanged.

Expressive responses add restrained inspections, coordinated travel and settling, triage corrections, protective bearing, interrupted alignment, measured movement, fatigue and quickened energy. They follow Ellie’s state even when her instruments are working around another token. Settings → Bit expression provides an enable switch, strength and per-situation mapping or None. Attached instruments stay near their own stations; treatment and collapse take priority, and reduced motion is respected.

## Original wing poses

The Pose control articulates the original gothic filament wings. Alternate structures, their pose libraries, the Wing form selector and Form size box are removed. Existing ordinary wing poses, wing scale and smooth interrupted pose transitions remain available. Old saved alternate structures or forms become Original when read; bit assignments and custom positions remain intact.

## Native animation library

Flight character, floating motion, wing poses, wing gestures, bit formations, core states, token effects, conditions and quick reactions can be previewed locally. Click a choice to select and preview it, then click Activate. Favourites open the matching library with that choice selected. Hover and pointer leave keep the selection; previews can be paused or replayed. Selection sends nothing to the scene and plays no audio. **Preview current look** in Home’s Flight pane combines the current wing shape, floating motion, local instruments, glow and enabled local projected effect. It opens wings only inside the preview, is read-only and leaves remote assignments in place.

The wing library now contains **75 categorized condition choices**, **21 reaction variants**, Old animations, eleven Original wing poses, plus the retained V7 wing gestures. Alternate structure and form libraries are removed. Conditions can use effects from another category while the library keeps its categories. Float style and flight-mode character remain independent controls. Stabilization glow still supports subtle core glow or more visible animated fields, with separate enable and strength controls.

## Appearance and animation settings

The V7 appearance and animation features remain active and configurable. Settings groups gemstone interiors, textured filaments and refractive light under Appearance; wing gestures, smooth wing bridges and action variation under Animation; companion formation enhancements under Bits; and enhanced treatment choreography under Medical animations. The classic/enhanced visual controls and saved per-token preferences remain supported. Home no longer has a separate **V7 appearance & animations** shortcut.

## Actor conditions and Reform recovery

Settings → Condition reactions covers **41 supported actor statuses**, with fitting filament effects on the original wing structure. Use the master switch, separate wing/bit switches, individual strength and **No extra wing animation** choices. The tiny HUD status icon toggles automatic reactions without changing the original structure. Ellie’s conditions still drive her instruments when they are deployed without wings or assigned to another token.

When the relevant HP and condition reactions are enabled, **0 HP or Unconscious** makes deployed instruments fall from their actual positions, including instruments at other tokens or in transit. Each collapse has a shared, varied fall and resting arrangement. These positions are saved in scene coordinates: moving or rotating Ellie or a recipient does not drag the fallen instruments along, and reloading does not reroll their fall. Open wings hold the broken phase of the **existing Reform animation**. Once healed and no longer Unconscious, instruments rise from those same resting points toward their current assignments while Reform resumes. Ellie stays grounded until you choose **Take off**; retracted wings stay retracted. Saved formations, custom positions and animation choices remain intact.

Unconsciousness retains visual priority. Other statuses add compatible currents, bindings, stitches, shields and refraction to the original material. Stunned remains mild at 1, stronger at 2 and motionless at 3. Paralyzed holds the body while small local crackles can continue; Fatigued keeps a broad usable span. Prone, Paralyzed and Stunned 3 retain their existing module-flight grounding. These reactions do not alter actor condition values, HP, actions, speed or healing. Reduced motion remains authoritative, and recovery never automatically takes off.

V6.1 blends the displayed condition artwork itself over a short transition when HP or a condition changes. Entering/leaving Prone and interrupted condition changes retain the visible shape, attached instruments and stabilization while the destination forms. New or removed accents fade appropriately. Existing broken/Reform recovery and reduced-motion behavior take precedence.

## Ellie's hardlight Medkit

Treatment controls remain in the Medkit dialogue, specifically the optional animation for **Keep on Keeping On → Lead by Example (2 Actions)**. The confirmed GM Bridge calls and Medicine mechanics are preserved.

Eight treatments now combine instruments with distinct patient structures:

| Treatment | Patient effect |
| --- | --- |
| Protective membrane | An enclosing energy membrane with circulating healing waves |
| Articulated splints | Segmented supports and locking hardlight plates |
| Helical traction | Depth-separated tension helices and axial support surfaces |
| Perfusion channels | Branching channels with fluid reservoirs and travelling packets |
| Compression seal | A sectional pressure enclosure with an iris closure |
| Precision instruments | Sterile working surfaces and articulated diagnostic tools |
| Suture weave | Opposing wound margins joined by individual stitches |
| Microloom dressing | A hardlight dressing woven by a moving shuttle |

Lattice reconstruction and Resonant alignment also remain available. The same animation dropdown is divided into **Original treatments** (all ten existing choices) and **Restorative bit treatments**: Restorative tide, Mending veil, Renewal spiral and Steady heartline. These are complete treatment choices, with their own scan, sustained work and outcome; there is no additional overlay selector. Instruments scan around the patient, then move between treatment-specific work stations instead of orbiting a generic centre. One lays a membrane while another seals it; a suture tool draws stitches while its partner holds the margin. The restorative treatments similarly divide wave guidance, surface weaving, inward flow and diagnostic/pulse duties. Instrument orientation, glow, contact feeds and sound accents share the operation timing. Action-responsive cores follow that work; explicitly selected core states stay respected. Patient effects remain active while treatment resolves. Success, critical success, failure and cancellation have their own endings. An abandoned action has a bounded timeout.

Treatments prefer free instruments already at the patient, then free instruments deployed at other tokens, then instruments around Ellie, and finally retracted instruments. Busy reservations still respect action priority and cancellation rules. They restore the prior assignments when finished unless a newer explicit command changes them. Remaining instruments share wing stabilization with a temporarily stronger field. Free placement keeps their saved support routes; attached placement retains its pose-following support positions.

All **119 Medkit sound files** have been rebuilt with electronic measurement sweeps, inharmonic energy modulation, articulated actuator accents and distinct hardlight materialization signatures. Treatment-specific working accents follow the same operation timing as the visual tools. This replaces the previous medical sound set; other sound families remain available. Built-in URLs carry the new version so clients fetch the replacement recordings.

**Play animation audio** can be disabled independently. Sound settings allow each technique’s volume, audible range and stage assets to be changed; the file picker assists selection. Leave an asset blank for its designed sound or enter `none` to silence a stage. Live sound is centred on the patient; the initiating user can hear their own action, and other listeners must be within range. Existing local mute and visibility rules still apply.

The Medkit dialogue also has **Preview treatment**, **Audition sound** and **Stop**. The private preview includes the real scan, work, outcome and return choreography, one-to-four instrument counts, outcome selection, pause and replay. It does not heal, spend resources, reserve instruments or dispatch actual bits. Audio auditions are local and respect the user’s mute preference. Treatment controls remain in the Medkit dialogue, outside the HUD.

## Quality, performance and compatibility

**My view** and **Other players' view** remain separate. Observer quality caps cannot override another client's lower local preference. Reduced motion and personal audio mute remain authoritative. The quality labels distinguish **Wing effect detail** from **Bit fields & treatment detail**. The optional performance diagnostic now exposes recorded stage timings and counters in a compact Capture breakdown.

V5 bounds token-field geometry and updates, reuses unchanged wing paths, compiles settled pose deformation, avoids repeated artwork comparisons, caches core/formation work and releases cancelled preview/worker resources. It retains earlier cropped textures, capped paint rates, offscreen/background suspension and movement-local transforms. No per-frame document writes are used for animation.

V6.1 reuses stabilization-search scratch memory, caches quality resolution for remote-only groups, suspends hidden-document action painting, and caches the portrait's fixed mesh calculations. The new portrait is local to the HUD and capped at 16 frames per second. New fields use bounded procedural geometry instead of extra full-token texture sequences.

See `docs/v9.0.1-release.md` and `docs/v9.0.1-validation.json` for this release's validation status and testing scope, and `docs/v9-api.md` for current macro controls. Earlier version-prefixed guides are historical; some describe retired alternate structures or removed methods. The optional Validation download contains development evidence and is not required to run the module.
