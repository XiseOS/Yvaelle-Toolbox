// Measure Yvaelle’s Toolbox performance for 15 seconds and post the result to you
// (whispered). Works the same in 9.1.0 and in v10, so the two can be compared.
// While it runs, do the thing you want to measure: fly her around with the
// lights on, turn the lantern on and off, and so on.
const api=game.modules.get('filament-flight')?.api;
if(!api?.performance){ui.notifications.error('Yvaelle’s Toolbox is not active, or this version has no performance recorder.');return;}
const seconds=15;
try{api.performance.start({duration:seconds*1000});}catch(e){ui.notifications.error(e.message);return;}
ui.notifications.info(`Measuring Yvaelle’s Toolbox for ${seconds} seconds… move her around now.`);
await new Promise(r=>setTimeout(r,seconds*1000+600));
const r=api.performance.getReport(),f=n=>(Math.round((n??0)*10)/10).toFixed(1);
const fps=r.frameMs?.median?1000/r.frameMs.median:0;
const stages=Object.entries(r.stages??{}).sort((a,b)=>(b[1].mean*b[1].samples)-(a[1].mean*a[1].samples)).slice(0,8)
  .map(([k,v])=>`<tr><td>${k}</td><td>${f(v.mean)} ms</td><td>${f(v.p95)} ms</td><td>${v.samples}</td></tr>`).join('');
const version=game.modules.get('filament-flight')?.version??'?';
const counters=Object.entries(r.counters??{}).map(([k,v])=>`${k}: ${v}`).join(' · ')||'none';
console.log('Yvaelle’s Toolbox performance report',version,r);
ChatMessage.create({whisper:[game.user.id],speaker:{alias:'Yvaelle’s Toolbox'},content:`<h3>Performance · v${version}</h3>
<p><strong>Frames:</strong> ${r.frames} · typical ${f(r.frameMs?.median)} ms (${f(fps)} fps) · slowest 5% ${f(r.frameMs?.p95)} ms · worst ${f(r.frameMs?.max)} ms</p>
<p><strong>Yvaelle’s Toolbox's own work per frame:</strong> typical ${f(r.moduleMs?.median)} ms · slowest 5% ${f(r.moduleMs?.p95)} ms</p>
<table><tr><th>Part</th><th>Average</th><th>Slowest 5%</th><th>Samples</th></tr>${stages}</table>
<p><strong>Counts:</strong> ${counters}</p>
<p style="font-size:11px">The full report is in the browser console (F12).</p>`});
