// Macro type: Script. Run Yvaelle’s Toolbox's self-check in your own game.
// Select Ellie's token (or pin her in the HUD), click this macro, tick what to
// test and press Run (or V11 only: about four minutes, every v11 feature). It puts everything back, and
// gives you a short report with a Copy button (also whispered to you in chat).
const api = game.modules.get("filament-flight")?.api;
if (!api?.selfCheck?.open) {
  ui.notifications.error("Yvaelle’s Toolbox is not active, or this version has no self-check yet: update the module.");
} else if (!canvas?.ready) {
  ui.notifications.warn("Open the scene with Ellie's token first.");
} else {
  api.selfCheck.open();
}
