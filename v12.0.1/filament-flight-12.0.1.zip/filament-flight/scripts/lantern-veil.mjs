import {ID} from './config.mjs?v=12.0.1';

export const LANTERN_VEIL_PATH=`modules/${ID}/assets/lantern/filament-veil-v662.webp`;
export const LANTERN_VEIL_COMMON_UNIFORMS=Object.freeze(['ffLanternVeilGain']);
export const LANTERN_VEIL_UNIFORMS=Object.freeze([...LANTERN_VEIL_COMMON_UNIFORMS,'ffLanternVeil','ffLanternVeilPhase','ffLanternVeilDetail','ffLanternVeilDisruption','ffLanternVeilRecovery']);
const finite=(value,fallback)=>Number.isFinite(value)?value:fallback;
const clamp=(value,min=0,max=1)=>Math.min(max,Math.max(min,value));
const TAU=Math.PI*2,PHASE_SPEED=.18;
export const LANTERN_VEIL_PERIOD=TAU/PHASE_SPEED;
const modulo=(value,period)=>(value%period+period)%period;
const uncomment=source=>source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,part=>part.replace(/[^\n]/g,' '));

/** One module-owned image and GPU texture, shared by all live adapters. The
 * image is decoded before Texture.from, so a pending/failed image is never a
 * sampler. Releasing the final adapter destroys only this owned resource. */
export class LanternVeilAssets {
  constructor({makeImage=()=>globalThis.Image?new Image():null,makeTexture=image=>globalThis.PIXI?.Texture?.from?.(image,{mipmap:globalThis.PIXI?.MIPMAP_MODES?.OFF??0,scaleMode:globalThis.PIXI?.SCALE_MODES?.LINEAR??1,wrapMode:globalThis.PIXI?.WRAP_MODES?.CLAMP??33071}),route=path=>globalThis.foundry?.utils?.getRoute?.(path)??`/${path}`}={}){
    this.makeImage=makeImage;this.makeTexture=makeTexture;this.route=route;this.leases=new Set();this.listeners=new Set();this.state='empty';this.texture=null;this.image=null;this.revision=0;
  }
  acquire(onReady){
    const lease={};this.leases.add(lease);if(onReady)this.listeners.add(onReady);this.load();let released=false;
    return ()=>{if(released)return;released=true;this.leases.delete(lease);if(onReady)this.listeners.delete(onReady);if(!this.leases.size)this.clear();};
  }
  peek(){return this.state==='ready'?this.texture:null;}
  load(){
    if(this.state!=='empty'||!this.leases.size)return;
    let image;try{image=this.makeImage();}catch{}if(!image){this.state='failed';return;}
    this.image=image;this.state='loading';
    const finish=ready=>{
      if(this.image!==image||this.state!=='loading')return;
      image.onload=image.onerror=null;
      try{
        if(!ready||!(image.naturalWidth??image.width)||!(image.naturalHeight??image.height))throw new Error('The lantern artwork image is unavailable.');
        const texture=this.makeTexture(image);this.texture=texture;
        if(!texture||texture.destroyed||texture.baseTexture?.valid===false)throw new Error('The lantern artwork texture is unavailable.');
        this.texture=texture;this.state='ready';
      }catch{try{this.texture?.destroy?.(true);}catch{}this.texture=null;this.state='failed';}
      this.revision++;
      for(const listener of [...this.listeners]){try{listener();}catch{/* An artwork failure cannot extinguish native lighting. */}}
    };
    image.onload=()=>finish(true);image.onerror=()=>finish(false);image.decoding='async';
    try{image.src=this.route(LANTERN_VEIL_PATH);}catch{finish(false);}
  }
  clear(){
    const image=this.image;this.image=null;
    if(image){image.onload=image.onerror=null;image.src='';}
    try{this.texture?.destroy?.(true);}catch{}this.texture=null;this.state='empty';this.revision++;
  }
}
export const lanternVeilAssets=new LanternVeilAssets();

export function lanternVeilUniforms(options={},texture=null){
  const effects=options.appearanceEffects??{},strength=clamp(finite(options.strength,1)),enabled=options.localEffects!==false;
  return {ffLanternVeil:texture,
    ffLanternVeilPhase:options.reduced?0:modulo(finite(options.clock,0),LANTERN_VEIL_PERIOD)*PHASE_SPEED,
    ffLanternVeilDetail:enabled?Math.sqrt(strength)*clamp(finite(effects.detail,1)):0,
    ffLanternVeilGain:clamp(finite(effects.gain,1),.12,1),
    ffLanternVeilDisruption:clamp(finite(effects.disruption,0)),ffLanternVeilRecovery:clamp(finite(effects.recovery,0))};
}

/** Layer a translucent authored veil through the existing cone. Only the
 * already-clipped native coloration is modulated; illumination and background
 * retain their native scene composition, and neither UV nor colour can extend
 * the source polygon. Two counter-deformed samples dissolve their wrap seams,
 * so this moves as wisps of energy instead of an opaque rotating decal. Image
 * columns follow the beam length; the horizontal asset strands stay longitudinal.
 * Plain mode uses only the existing reaction gain and never samples artwork. */
export function lanternVeilFragment(fragment,layer='coloration',{artwork=true}={}){
  if(typeof fragment!=='string')return null;
  const inspected=uncomment(fragment),main=/\bvoid\s+main\s*\(\s*(?:void\s*)?\)\s*\{/g.exec(inspected);
  const outputs=[...inspected.matchAll(/\bgl_FragColor\s*=\s*([^;]+);/g)];
  if(!main||outputs.length!==1||inspected.includes('uniform float ffLanternVeilGain'))return null;
  const output=outputs[0],bodyStart=main.index+main[0].length,declaration=/\bfloat\s+depth\s*=[^;]+;/g.exec(inspected.slice(bodyStart,output.index));
  if(!declaration)return null;
  const gainAt=bodyStart+declaration.index+declaration[0].length;
  const uniforms='uniform float ffLanternVeilGain;\n'+(layer==='coloration'&&artwork?'uniform sampler2D ffLanternVeil;\nuniform float ffLanternVeilPhase;\nuniform float ffLanternVeilDetail;\nuniform float ffLanternVeilDisruption;\nuniform float ffLanternVeilRecovery;\n':'');
  let finalOutput=fragment.slice(output.index,output.index+output[0].length);
  if(layer==='coloration'&&artwork)finalOutput=`vec4 ffLanternVeilOutput=${fragment.slice(inspected.indexOf('=',output.index)+1,output.index+output[0].length-1)};
  if(ffLanternVeilDetail>0.0&&ffLanternRadius>0.00001){
    float ffLanternVeilSigned=atan(ffLanternSide,ffLanternForward)/max(0.0087,ffLanternHalfAngle);
    float ffLanternVeilDrift=0.035*sin(ffLanternRadius*7.0-ffLanternVeilPhase*2.0)+0.018*sin(ffLanternVeilSigned*3.0+ffLanternVeilPhase);
    float ffLanternVeilTravel=ffLanternRadius*0.83-ffLanternVeilPhase/6.28318530718;
    vec2 ffLanternVeilUvA=vec2(fract(ffLanternVeilTravel),clamp(0.5+ffLanternVeilSigned*0.46+ffLanternVeilDrift,0.002,0.998));
    vec2 ffLanternVeilUvB=vec2(fract(ffLanternVeilTravel+0.5),clamp(0.5+ffLanternVeilSigned*0.44-ffLanternVeilDrift*0.8+0.016*sin(ffLanternRadius*11.0+ffLanternVeilPhase*3.0),0.002,0.998));
    float ffLanternVeilSeamA=smoothstep(0.0,0.16,ffLanternVeilUvA.x)*(1.0-smoothstep(0.84,1.0,ffLanternVeilUvA.x));
    float ffLanternVeilSeamB=smoothstep(0.0,0.16,ffLanternVeilUvB.x)*(1.0-smoothstep(0.84,1.0,ffLanternVeilUvB.x));
    float ffLanternVeilInkA=texture2D(ffLanternVeil,ffLanternVeilUvA).a;
    float ffLanternVeilInkB=texture2D(ffLanternVeil,ffLanternVeilUvB).a;
    float ffLanternVeilInk=(ffLanternVeilInkA*ffLanternVeilSeamA+ffLanternVeilInkB*ffLanternVeilSeamB)/max(0.0001,ffLanternVeilSeamA+ffLanternVeilSeamB);
    float ffLanternVeilWisp=pow(clamp(ffLanternVeilInk,0.0,1.0),0.42);
    float ffLanternVeilTaper=smoothstep(0.06,0.22,ffLanternRadius)*(1.0-smoothstep(0.64,0.96,ffLanternRadius));
    ffLanternVeilTaper*=1.0-smoothstep(0.74,1.0,abs(ffLanternVeilSigned));
    ffLanternVeilTaper*=1.0-ffLanternFullCircle;
    float ffLanternVeilUneven=0.5+0.5*sin(ffLanternRadius*9.0+ffLanternVeilSigned*4.0-ffLanternVeilPhase*3.0);
    ffLanternVeilWisp*=1.0-ffLanternVeilDisruption*0.65*smoothstep(0.35,0.85,ffLanternVeilUneven);
    float ffLanternVeilGlow=ffLanternVeilTaper*ffLanternVeilDetail*(ffLanternVeilWisp*(1.60+0.12*ffLanternVeilRecovery)-0.32);
    ffLanternVeilOutput.rgb=clamp(ffLanternVeilOutput.rgb*(1.0+ffLanternVeilGlow),vec3(0.0),vec3(1.0));
  }
  gl_FragColor=ffLanternVeilOutput;`;
  return fragment.slice(0,main.index)+uniforms+fragment.slice(main.index,gainAt)+'\n  depth*=ffLanternVeilGain;\n'+fragment.slice(gainAt,output.index)+finalOutput+fragment.slice(output.index+output[0].length);
}
