/** Self-check (11.0.0-test.4): the V11 part, one sub-section per v11 area.
 *
 * Each sub-section plays the v11 features through the module's own entry
 * points wherever it can, so nothing reaches PF2e or another module that is
 * not real: a synthetic damage record of each type goes to the damage
 * runtime and its hit() (what the flight feel calls as her HP drops), heals,
 * traditions, escapes and die rolls are synthetic chat messages handed to the
 * heal runtime's own noteMessage() (never to Hooks), a Hero Point,
 * Last light and the ally watch are its own moments, and the moods are
 * her damage record's conditions for a moment. Real changes are made only where
 * nothing else is honest, and each is put back exactly:
 *  - her token flags (the cloak, the emotes, the v11 switches the
 *    performance rows and the extras turn on for a moment): the run's final
 *    RESTORE rewrites every flags.filament-flight key as it was;
 *  - two or three persistent-damage conditions, her HP for fatigue and her
 *    dying value (withHp: HP, dying, and every condition or effect added or
 *    removed meanwhile);
 *  - her position (the emote precedence move, the wall-fold path);
 *  - the experimental extras' switches (client, world and token), and her
 *    journal flag on her actor if the Tapestry or the petals wrote it.
 * Timing wrappers (V11Timer) sit on the runtimes' own methods for the run and
 * are taken off exactly, including the ticker listeners they replaced.
 *
 * Every line is short: a PASS/CHECK/FAIL per item and a few numbers. */
import {ID} from './config.mjs?v=12.0.1';
import {perceptionCaller} from './performance.mjs?v=12.0.1';
import {V11_FEATURES,V11_KEYS,BUILT_IN,resolveV11,isOn,partOn,choice,writeV11} from './v11/features.mjs?v=12.0.1';
import {readDamageMessage,woundLookOf,tintForType,v11PersistFilter,WOUND_LOOKS} from './v11/damage-events.mjs?v=12.0.1';
import {persistQuarters} from './v11/damage-state.mjs?v=12.0.1';
import {bitOnTop} from './v11/heal-moments.mjs?v=12.0.1';
import {EMOTE_FLAG} from './v11/emote-runtime.mjs?v=12.0.1';
import {emoteDuration} from './v11/emote-model.mjs?v=12.0.1';
import {CLOAK_FLAG,CLOAK,DIRECTIONS,VARIANT_INDEX,veilAlpha,keepsGhost,flickerSolid,flickerAt,OWNER_VIEWS,TOKEN_GHOST,ownerViewOf} from './v11/invis.mjs?v=12.0.1';
import {CLIENT_KEY} from './v11/features.mjs?v=12.0.1';
import {boxMasks,boxDiff,frameMasks,frameSpill,heatRows,rgbText,widen} from './self-check-box.mjs?v=12.0.1';
import {LAST as CLOAK_LAST,resetLast as resetCloakLast} from './v11/cloak-filter.mjs?v=12.0.1';
import {shapeSelfTest} from './v11/token-shape.mjs?v=12.0.1';
import {createLook,copyLook,lookDelta,sampleTokenLayer} from './v11/token-layer.mjs?v=12.0.1';
import * as WM from './quick-wheel-model.mjs?v=12.0.1';
import {ORDER,sectionById} from './keepsake/settings-tree.mjs?v=12.0.1';
import {ROUTES,routeFor,pinnedSections} from './v11/migrate.mjs?v=12.0.1';
import {tabList} from './keepsake/shared.mjs?v=12.0.1';
import {keepsakeTimings,formatTimings} from './keepsake/timings.mjs?v=12.0.1';

export const V11_SCENARIOS=Object.freeze([
  ['v11setup','V11 · Setup','the v11 registry, which features are on, v10 keys still read, the new Settings tab (sections, search, Parts) timed'],
  ['v11token','V11 · Token layer','her portrait filter: on her mesh, after a refresh, each part reacting (hit, heal, fear, unconscious, emote, hidden), its cost'],
  ['v11wounds','V11 · Wounds','11 damage types and a homebrew one (synthetic hits), 3 persistent-damage conditions, low HP and dying 1–3, the moods; all put back'],
  ['v11invis','V11 · Invisibility','her Fade on and off, each look (Classic, A, B, C) and sweep direction, a flicker, what other players would see'],
  ['v11heal','V11 · Healing & bits','a Hero Point, 4 traditions, grapple escapes, die moods, the ally watch, Last light'],
  ['v11emotes','V11 · Emotes','all ten, moving and a hit interrupting, Comfort on each side'],
  ['v11wheel','V11 · Quick wheel','opens the nested wheel as its key does, looks at every ring, closes it; then fades her out and in through the wheel (More…, the last-used gem, a shortcut)'],
  ['v11world','V11 · World','wall fold along a short path, light catch, her wing shadow on tokens'],
  ['v11extras','V11 · Extras','the six experimental extras: nothing runs while off; each on for a moment and back off'],
  ['v11perf','V11 · Performance','idle, flying, flying with the world features, a Hero Point moment, an emote, a cloak sweep: ms per frame']
]);
export const V11_IDS=Object.freeze(V11_SCENARIOS.map(([id])=>id));
export const V11_HEAD=Object.freeze({v11setup:'V11 SETUP',v11token:'V11 TOKEN LAYER',v11wounds:'V11 WOUNDS',v11invis:'V11 INVISIBILITY',v11heal:'V11 HEALING & BITS',v11emotes:'V11 EMOTES',v11wheel:'V11 WHEEL',v11world:'V11 WORLD',v11extras:'V11 EXTRAS',v11perf:'V11 PERFORMANCE'});
export const V11_LIMITS=Object.freeze({v11setup:40000,v11token:45000,v11wounds:110000,v11invis:135000,v11heal:120000,v11emotes:90000,v11wheel:75000,v11world:60000,v11extras:60000,v11perf:150000});
/** The v11 token flags the RESTORE line names one by one. */
export const V11_TOKEN_FLAGS=Object.freeze(['v11','v11Cloak','v11Emote']);

const f0=n=>Number.isFinite(n)?String(Math.round(n)):'?',f1=n=>Number.isFinite(n)?(Math.round(n*10)/10).toFixed(1):'?',f2=n=>Number.isFinite(n)?(Math.round(n*100)/100).toFixed(2):'?',f3=n=>Number.isFinite(n)?(Math.round(n*1000)/1000).toFixed(3):'?';
const clock=()=>performance.now()/1000;
/** (12.0.0-beta.5) How long her cloak's sweep takes now (ms): her Cloak depth speed, 3.8 s unless she chose another. */
const sweepMs=ctx=>{try{return (ctx.manager?.v11?.invisibility?.speed?.(ctx.doc)??CLOAK.sweep)*1000;}catch{return CLOAK.sweep*1000;}};
const sameJ=(a,b)=>{try{return JSON.stringify(a)===JSON.stringify(b);}catch{return a===b;}};

/* ---------------------------------------------------------------- measuring */
/** Ticker priority each runtime adds its own tick() at (to swap a timed wrapper in and out exactly). */
const TICK_PRIO={tokenLayers:-12,invis:-9,heal:-14};
/** JS time inside the v11 runtimes' methods, per canvas frame. Wrappers are own
 * properties for the run; a wrapped tick() that is on the ticker right now is
 * swapped there too, and swapped back by restore(), so no listener is left. */
export class V11Timer{
  constructor(){this.T={};this.undo=[];this.frames=0;this.counting=null;}
  wrap(name,obj,keys,prio=null){
    if(!obj)return this;const b=this.T[name]??={ms:0,calls:0,max:0};
    for(const k of keys){
      const orig=obj[k];if(typeof orig!=='function'||orig.ffTimed)continue;const own=Object.hasOwn(obj,k);
      const w=function(...a){const t0=performance.now();try{return orig.apply(this,a);}finally{const d=performance.now()-t0;b.ms+=d;b.calls++;if(d>b.max)b.max=d;}};w.ffTimed=true;
      obj[k]=w;
      const ticker=globalThis.canvas?.app?.ticker,isTick=k==='tick'&&prio!=null;
      if(isTick&&obj.ticking&&ticker){try{ticker.remove(orig,obj);ticker.add(w,obj,prio);}catch{}}
      this.undo.push(()=>{
        const on=isTick&&!!obj.ticking&&!!ticker;
        if(on)try{ticker.remove(w,obj);}catch{}
        if(own)obj[k]=orig;else delete obj[k];
        if(on)try{ticker.add(obj.tick,obj,prio);}catch{}
      });
    }
    return this;
  }
  /** Watch a method's results (no timing): fn(result, args). */
  tap(obj,k,fn){
    if(!obj||typeof obj[k]!=='function')return this;const orig=obj[k],own=Object.hasOwn(obj,k);
    const w=function(...a){const out=orig.apply(this,a);try{fn(out,a);}catch{}return out;};if(orig.ffTimed)w.ffTimed=true;
    obj[k]=w;this.undo.push(()=>{if(obj[k]===w){if(own)obj[k]=orig;else delete obj[k];}});return this;
  }
  /** Count canvas frames from now. */
  start(){this.reset();if(this.counting)return this;const ticker=globalThis.canvas?.app?.ticker,self=this;
    const fn=()=>{self.frames++;};this.counting=fn;try{ticker?.add(fn,null,-41);}catch{}
    this.undo.push(()=>{try{ticker?.remove(fn,null);}catch{}this.counting=null;});return this;}
  reset(){for(const b of Object.values(this.T)){b.ms=0;b.calls=0;b.max=0;}this.frames=0;}
  read(){const n=Math.max(1,this.frames),by={};let tot=0,max=0;for(const [k,b] of Object.entries(this.T)){by[k]=b.ms/n;tot+=b.ms;max=Math.max(max,b.max);}
    const top=Object.entries(by).sort((a,b)=>b[1]-a[1])[0];return {perFrame:tot/n,by,top:top&&top[1]>0?top:null,frames:this.frames,max};}
  restore(){for(const fn of this.undo.splice(0).reverse())try{fn();}catch{}}
}
/** (11.0.0-test.6) What the screen really shows round her, read back from WebGL right after the canvas
 * renders (a ticker step after PIXI's render, so the frame is still in the drawing buffer). test.5's cloak
 * drew each wing layer, bit and shadow unblended: opaque black boxes over the map that the runtime's own
 * numbers never saw. start() takes the baseline (before a sweep): a grid of samples over her wings' and
 * token's bounds; watch() then counts, a frame in three, the samples that are near black now and were not
 * in the baseline (max channel ≤ 3: an unblended filter writes exact zeros; a dark map rarely does). Only her region is read (a few hundred KB a read), and only while a check runs. */
export class ScreenWatch{
  constructor(ctx,H,{wings=false}={}){this.ctx=ctx;this.H=H;this.wings=wings;this.base=null;this.rect=null;this.worst=0;this.reads=0;this.fn=null;this.n=0;this.note='';}
  /** Her pieces' bounds on screen (renderer pixels), padded, clipped to the view. */
  region(){
    const ctx=this.ctx,R=globalThis.canvas?.app?.renderer,view=R?.view;if(!R?.gl||!view){this.why='no WebGL view';return null;}
    const res=R.resolution||1,list=this.wings?[]:[ctx.token?.mesh];
    try{const r=ctx.manager?.states?.get?.(ctx.token)?.renderer;for(const [name,m] of r?.previewMeshes?.()??[])if(!this.wings||/^rig\.(?!bit)/.test(name))list.push(m);}catch{}
    let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
    for(const m of list){if(!m||m.destroyed||m.visible===false)continue;let b=null;try{b=m.getBounds?.(true);}catch{}if(!b||!(b.width>0))continue;
      x0=Math.min(x0,b.x);y0=Math.min(y0,b.y);x1=Math.max(x1,b.x+b.width);y1=Math.max(y1,b.y+b.height);}
    if(!Number.isFinite(x0)){this.why='her pieces report no bounds here';return null;}const pad=24;
    const W=view.width,Hh=view.height,X0=Math.max(0,Math.floor((x0-pad)*res)),Y0=Math.max(0,Math.floor((y0-pad)*res)),X1=Math.min(W,Math.ceil((x1+pad)*res)),Y1=Math.min(Hh,Math.ceil((y1+pad)*res));
    if(X1-X0<8||Y1-Y0<8){this.why='off screen';return null;}
    return {x:X0,y:Y0,w:X1-X0,h:Y1-Y0,H:Hh};
  }
  read(){
    const R=globalThis.canvas?.app?.renderer,gl=R?.gl,r=this.rect;if(!gl||!r)return null;
    try{R.renderTexture?.bind?.(null);}catch{}
    const buf=this.buf??=new Uint8Array(r.w*r.h*4);gl.readPixels(r.x,r.H-r.y-r.h,r.w,r.h,gl.RGBA,gl.UNSIGNED_BYTE,buf);this.reads++;
    const step=Math.max(2,Math.floor(Math.sqrt(r.w*r.h/2500))),out=[];
    for(let y=0;y<r.h;y+=step)for(let x=0;x<r.w;x+=step){const i=(y*r.w+x)*4;out.push(Math.max(buf[i],buf[i+1],buf[i+2]));}
    return out;
  }
  /** Read once after the next render: resolves with the samples (null if this canvas can't be read). */
  once(){return new Promise(res=>{const T=globalThis.canvas?.app?.ticker;if(!T)return res(null);
    const f=()=>{T.remove(f);let s=null;try{s=this.read();}catch{s=null;}res(s);};T.add(f,null,-100);});}
  async start(){
    this.why='';this.rect=this.region();if(!this.rect){this.note=this.why||(this.wings?'no wing layer on screen':'her region is off screen');return false;}
    let base=null;for(let k=0;k<3;k++){const s=await this.once();if(!s){this.note='the canvas cannot be read here';return false;}base=base?base.map((v,i)=>Math.max(v,s[i])):s;}
    const lit=base.filter(v=>v>=12).length;if(lit<base.length*.2){this.note='the canvas reads back black (no drawing buffer here)';return false;}
    this.base=base;this.worst=0;this.n=0;
    const T=globalThis.canvas.app.ticker;this.fn=()=>{if(++this.n%3)return;let s=null;try{s=this.read();}catch{return;}if(!s)return;
      let nb=0,cnt=0;for(let i=0;i<s.length;i++){if(this.base[i]<=3)continue;cnt++;if(s[i]<=3)nb++;}const fr=cnt?nb/cnt:0;if(fr>this.worst)this.worst=fr;};
    T.add(this.fn,null,-100);return true;
  }
  stop(){if(this.fn){try{globalThis.canvas?.app?.ticker?.remove(this.fn);}catch{}this.fn=null;}return this.result();}
  result(){return this.base?{ok:this.worst<.08,worst:this.worst,reads:this.reads,text:`screen round ${this.wings?'her wings':'her'}: ${this.reads} read(s), newly black at worst ${f0(this.worst*100)}%`}:{ok:true,skip:true,text:`screen round ${this.wings?'her wings':'her'}: not read (${this.note})`};}
}

/* (11.0.0-test.7) What is really drawn of her, not what the runtime asks for. test.6 reported her held wings at 0.50
 * (the veil's own number) while her rig's layers, the ones on screen, stayed at full strength: the veil reached only
 * the atlas sprite under them. So: every piece of hers in the stage tree with the alpha it is drawn at (its own alpha
 * times every parent's, 0 if anything up the tree is hidden), weighted by how much of its picture is painted (a wing
 * layer's canvas), and, where WebGL can be read, the screen itself against a frame drawn without her. */
const inkCv={c:null};
/** Mean alpha of a piece's picture (an 8×8 copy of its canvas), or null when it has no readable canvas. */
function inkOfMesh(m){
  const tex=m?.texture,src=tex?.baseTexture?.resource?.source??tex?.src;if(!src||!(src.width>1)||!(src.height>1))return null;
  const c=inkCv.c??=Object.assign(document.createElement('canvas'),{width:8,height:8}),g=c.getContext('2d',{willReadFrequently:true});
  try{g.clearRect(0,0,8,8);g.drawImage(src,0,0,src.width,src.height,0,0,8,8);const d=g.getImageData(0,0,8,8).data;let a=0;for(let i=3;i<d.length;i+=4)a+=d[i];return a/(255*64);}catch{return null;}
}
/** The alpha a display object is drawn at: its alpha times its parents' (0 if it or a parent is hidden or not renderable). */
export function drawnAlpha(o){
  if(!o||o.destroyed)return 0;let a=1,x=o,n=0;
  while(x&&n++<24){if(x.visible===false||x.renderable===false)return 0;a*=Number.isFinite(Number(x.alpha))?Number(x.alpha):1;if(x===globalThis.canvas?.stage)break;x=x.parent;}
  return Math.max(0,a);
}
const isCloakFilter=f=>!!f&&(f.block!==undefined||!!f.uniforms?.uS0);
/** Her pieces by kind (token, wing, bit, shadow, fx: anything else of hers on the primary group). */
export function herPieces(ctx){
  const out=[],seen=new Set(),add=(kind,name,m)=>{if(!m||seen.has(m))return;seen.add(m);out.push({kind,name,m});};
  add('token','token',ctx.token?.mesh);
  const r=ctx.manager?.states?.get?.(ctx.token)?.renderer;
  try{for(const [name,m] of r?.previewMeshes?.()??[])add(/^(rig|compact)\.(bit|current)/.test(name)?'bit':/^rig\.|^wings$/.test(name)?'wing':name==='shadow'?'shadow':'fx',name,m);}catch{}
  if(r?.wingShadow)add('shadow','wingShadow',r.wingShadow);
  try{for(const c of globalThis.canvas?.primary?.children??[])if(typeof c?.name==='string'&&c.name.startsWith(ctx.prefix))add('fx',c.name.slice(ctx.prefix.length),c);}catch{}
  return out;
}
/** What the stage tree draws of her now: per kind the summed drawn alpha, the strongest single drawn alpha, how
 * many pieces carry a cloak filter, her wings' drawn alpha × painted share (ink: the thread repaint paints less,
 * and a wing beat changes it too, so it is reported, not judged); her token's ghost from the token layer's own look. */
export function drawnNow(ctx){
  const by={token:0,wing:0,bit:0,shadow:0,fx:0},max={token:0,wing:0,bit:0,shadow:0,fx:0};let filtered=0,ink=0;
  for(const {kind,m} of herPieces(ctx)){const a=drawnAlpha(m);if(a>max[kind])max[kind]=a;
    if((m.filters??[]).some(isCloakFilter))filtered++;
    by[kind]+=a;if(kind==='wing')ink+=a*(inkOfMesh(m)??0);}
  // her portrait inside the token layer's filter: the share of her portrait it keeps (the frame outline aside)
  let tokenShare=null;try{const L=ctx.manager?.v11?.tokenLayers?.layerOf?.(ctx.token),u=L?.filter?.uniforms,M=u?.uMask;
    if(M&&L.filter&&(ctx.token?.mesh?.filters??[]).includes(L.filter))tokenShare=M[0]<.5?M[3]:M[0]<1.5&&M[1]>=.999?M[2]*M[3]:null;}catch{}   // (held: the portrait's ghost floor; the uniforms are what the filter draws with)
  return {by,max,filtered,tokenShare,ink};
}
/** The screen round her against a frame drawn without her (her pieces not renderable for that one frame).
 * presence = Σ|now − without| over her token's disc and, apart, over the rest of her bounds (wings, bits, shadow). */
export class ScreenPresence{
  constructor(ctx){this.ctx=ctx;this.ok=false;this.note='';}
  async start(){
    const R=globalThis.canvas?.app?.renderer,gl=R?.gl,view=R?.view;if(!gl||!view){this.note='no WebGL view';return false;}
    const res=R.resolution||1,pieces=herPieces(this.ctx);let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
    for(const {m} of pieces){if(!m||m.destroyed||m.visible===false)continue;let b=null;try{b=m.getBounds?.(true);}catch{}if(!b||!(b.width>0))continue;x0=Math.min(x0,b.x);y0=Math.min(y0,b.y);x1=Math.max(x1,b.x+b.width);y1=Math.max(y1,b.y+b.height);}
    if(!Number.isFinite(x0)){this.note='her pieces report no bounds';return false;}
    const W=view.width,Hh=view.height,X0=Math.max(0,Math.floor((x0-8)*res)),Y0=Math.max(0,Math.floor((y0-8)*res)),X1=Math.min(W,Math.ceil((x1+8)*res)),Y1=Math.min(Hh,Math.ceil((y1+8)*res));
    if(X1-X0<8||Y1-Y0<8){this.note='off screen';return false;}
    this.rect={x:X0,y:Y0,w:X1-X0,h:Y1-Y0,H:Hh};this.step=Math.max(1,Math.floor(Math.sqrt(this.rect.w*this.rect.h/12000)));
    let tb=null;try{tb=this.ctx.token?.mesh?.getBounds?.(true);}catch{}
    this.disc=tb&&tb.width>0?{x:(tb.x+tb.width/2)*res-X0,y:(tb.y+tb.height/2)*res-Y0,r:Math.min(tb.width,tb.height)/2*res}:null;
    // the frame without her: every piece of hers not renderable for one frame (put back at once)
    const off=[];for(const {m} of pieces)if(m&&!m.destroyed&&m.renderable!==false){m.renderable=false;off.push(m);}
    try{this.ref=await this.once();}finally{for(const m of off)if(!m.destroyed)m.renderable=true;}
    if(!this.ref){this.note='the canvas cannot be read here';return false;}
    await this.once();const s=await this.once();if(!s){this.note='the canvas cannot be read here';return false;}
    this.solid=this.presence(s);
    if(!(this.solid.token>0)&&!(this.solid.rest>0)){this.note='she does not show against the map here (reads back the same)';return false;}
    this.ok=true;return true;
  }
  read(){const R=globalThis.canvas?.app?.renderer,gl=R?.gl,r=this.rect;if(!gl||!r)return null;try{R.renderTexture?.bind?.(null);}catch{}
    const buf=new Uint8Array(r.w*r.h*4);gl.readPixels(r.x,r.H-r.y-r.h,r.w,r.h,gl.RGBA,gl.UNSIGNED_BYTE,buf);return buf;}
  once(){return new Promise(res=>{const T=globalThis.canvas?.app?.ticker;if(!T)return res(null);const f=()=>{T.remove(f);let s=null;try{s=this.read();}catch{s=null;}res(s);};T.add(f,null,-100);});}
  presence(buf){
    const r=this.rect,ref=this.ref,st=this.step,D=this.disc;let tok=0,rest=0;
    for(let y=0;y<r.h;y+=st)for(let x=0;x<r.w;x+=st){
      // (readPixels rows run bottom-up)
      const i=((r.h-1-y)*r.w+x)*4,d=Math.abs(buf[i]-ref[i])+Math.abs(buf[i+1]-ref[i+1])+Math.abs(buf[i+2]-ref[i+2]);
      if(D&&Math.hypot(x-D.x,y-D.y)<D.r)tok+=d;else rest+=d;}
    return {token:tok,rest};
  }
  /** Her presence now as a share of her solid presence (token disc, the rest). */
  async share(){if(!this.ok)return null;const s=await this.once();if(!s)return null;const p=this.presence(s);
    return {token:this.solid.token>0?p.token/this.solid.token:null,rest:this.solid.rest>0?p.rest/this.solid.rest:null};}
}

/** (test.9) Draw the canvas again now, inside the same tick (nothing has moved: no ticker runs in between). */
export function redrawNow(){
  const c=globalThis.canvas,app=c?.app;try{const p=c?.primary;if(p&&'renderDirty' in p)p.renderDirty=true;}catch{}
  if(typeof app?.render==='function')app.render();else app?.renderer?.render?.(c.stage??app.stage);
}
/** The stage's zoom (screen px per scene px). */
const zoomNow=()=>{const s=globalThis.canvas?.stage;return Math.abs(Number(s?.worldTransform?.a)||Number(s?.scale?.x)||1);};
/** (11.0.0-test.8, judged anew in test.9) The "box": is anything drawn round her, outside her own shape, while her
 * cloak plays? (self-check-box.mjs has both rules.) test.8 compared each read with the screen BEFORE the fade, outside
 * the silhouette she had then: on a real table she flies, so her beating wings alone failed it in every phase. Now a
 * frame in three is drawn again in the same tick with her cloak filters bypassed, without her shadow and without her:
 * outside what her own pieces draw THAT frame, the filters must add nothing. test.8's comparison is still made
 * and printed ("against the screen before the fade"), with the filters on and bypassed, but no longer judged.
 * The region is her pieces' bounds plus 40 px. */
export class BoxWatch{
  constructor(ctx,H,{keep=!!globalThis.__ffKeepFrames}={}){if(keep)globalThis.__ffBox=this;this.ctx=ctx;this.H=H;this.ok=false;this.note='';this.phase='';this.by={};this.reads=0;this.fn=null;this.n=0;this.keep=keep;this.kept={};this.newPieces=new Set();}
  once(){return new Promise(res=>{const T=globalThis.canvas?.app?.ticker;if(!T)return res(null);const f=()=>{T.remove(f);let s=null;try{s=this.read();}catch{s=null;}res(s);};T.add(f,null,-100);});}
  /** The region as a w × h grid of samples (rows top-down). */
  read(){const R=globalThis.canvas?.app?.renderer,gl=R?.gl,r=this.rect;if(!gl||!r)return null;try{R.renderTexture?.bind?.(null);}catch{}
    const buf=this.buf??=new Uint8Array(r.w*r.h*4);gl.readPixels(r.x,r.H-r.y-r.h,r.w,r.h,gl.RGBA,gl.UNSIGNED_BYTE,buf);
    const st=this.step,w=this.w,h=this.h,out=new Uint8Array(w*h*4);
    for(let y=0;y<h;y++){const sy=r.h-1-Math.min(r.h-1,y*st);for(let x=0;x<w;x++){const i=(sy*r.w+Math.min(r.w-1,x*st))*4,o=(y*w+x)*4;out[o]=buf[i];out[o+1]=buf[i+1];out[o+2]=buf[i+2];out[o+3]=255;}}
    return out;}
  /** This frame four ways (on · filters bypassed · no shadow · without her), drawn in this tick; the canvas is left as it was. */
  frames(){
    const on=this.read();if(!on)return null;
    const pieces=herPieces(this.ctx),offF=[],hid=[];let off=null,noShadow=null,bare=null;
    for(const p of pieces)if(!this.known.has(p.m))this.newPieces.add(p.name);
    try{
      for(const {m} of pieces)for(const f of m?.filters??[])if(isCloakFilter(f)&&f.enabled!==false){f.enabled=false;offF.push(f);}
      redrawNow();off=this.read();
      for(const {kind,m} of pieces)if(kind==='shadow'&&m&&!m.destroyed&&m.renderable!==false){m.renderable=false;hid.push(m);}
      if(hid.length){redrawNow();noShadow=this.read();}
      for(const {m} of pieces)if(m&&!m.destroyed&&m.renderable!==false){m.renderable=false;hid.push(m);}
      redrawNow();bare=this.read();
    }finally{for(const m of hid)if(!m.destroyed)m.renderable=true;for(const f of offF)f.enabled=true;try{redrawNow();}catch{}}
    return off&&bare?{on,off,noShadow,bare,filters:offF.length}:null;
  }
  async start(){
    const R=globalThis.canvas?.app?.renderer,gl=R?.gl,view=R?.view;if(!gl||!view){this.note='no WebGL view';return false;}
    const res=this.res=R.resolution||1,pieces=herPieces(this.ctx);let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;
    this.known=new Set(pieces.map(p=>p.m));
    for(const {m} of pieces){if(!m||m.destroyed||m.visible===false)continue;let b=null;try{b=m.getBounds?.(true);}catch{}if(!b||!(b.width>0))continue;x0=Math.min(x0,b.x);y0=Math.min(y0,b.y);x1=Math.max(x1,b.x+b.width);y1=Math.max(y1,b.y+b.height);}
    if(!Number.isFinite(x0)){this.note='her pieces report no bounds';return false;}const pad=40;
    const W=view.width,Hh=view.height,X0=Math.max(0,Math.floor((x0-pad)*res)),Y0=Math.max(0,Math.floor((y0-pad)*res)),X1=Math.min(W,Math.ceil((x1+pad)*res)),Y1=Math.min(Hh,Math.ceil((y1+pad)*res));
    if(X1-X0<16||Y1-Y0<16){this.note='off screen';return false;}
    this.rect={x:X0,y:Y0,w:X1-X0,h:Y1-Y0,H:Hh};this.step=Math.max(1,Math.floor(Math.sqrt(this.rect.w*this.rect.h/60000)));
    this.w=Math.ceil(this.rect.w/this.step);this.h=Math.ceil(this.rect.h/this.step);
    // the rim a filter may reach (1.3 scene px) and one sample of resampling, in samples
    this.zoom=zoomNow();this.rad=Math.max(1,Math.ceil((1.3*this.zoom*res+1)/this.step));
    const hide=async(list,frames)=>{const off=[],got=[];for(const m of list)if(m&&!m.destroyed&&m.renderable!==false){m.renderable=false;off.push(m);}
      try{for(let k=0;k<frames;k++){const s=await this.once();if(s)got.push(s);if(frames>1)await this.H.sleep(110);}}finally{for(const m of off)if(!m.destroyed)m.renderable=true;}return got;};
    const all=pieces.map(p=>p.m),shadows=pieces.filter(p=>p.kind==='shadow').map(p=>p.m);
    const ref=(await hide(all,1))[0];if(!ref){this.note='the canvas cannot be read here';return false;}
    let lit=0;for(let i=0;i<ref.length;i+=4)if(Math.max(ref[i],ref[i+1],ref[i+2])>=12)lit++;if(lit<ref.length/4*.2){this.note='the canvas reads back black (no drawing buffer here)';return false;}
    await this.once();
    // test.8's reference (reported, not judged): her body without her shadow over ~0.7 s, then solid
    const bodies=await hide(shadows,6);await this.once();const solid=await this.once();
    if(!bodies.length||!solid){this.note='the canvas cannot be read here';return false;}
    this.M0=boxMasks(ref,bodies,solid,this.w,this.h,Math.max(2,Math.ceil(14*res/this.step)));this.ref=ref;
    // the same frame drawn twice must read the same: if it does not, something outside the module animates per draw and nothing can be judged
    const q=await new Promise(done=>{const T=globalThis.canvas.app.ticker,f=()=>{T.remove(f);let r=null;try{const a=this.read();redrawNow();const b=this.read();r=a&&b?[a,b]:null;}catch{}done(r);};T.add(f,null,-100);});
    if(!q){this.note='the canvas cannot be drawn again here';return false;}
    let noise=0;for(let i=0;i<q[0].length;i+=4)if(Math.abs(q[0][i]-q[1][i])>10||Math.abs(q[0][i+1]-q[1][i+1])>10||Math.abs(q[0][i+2]-q[1][i+2])>10)noise++;
    this.limit=Math.max(6,Math.round(this.w*this.h*.0006));this.noise=noise;
    if(noise>this.limit){this.note=`the same frame drawn twice differs in ${noise} samples (something animates per draw): not judged`;return false;}
    // and drawing it again without her must take her off the screen: otherwise the canvas keeps a cached picture and every read would pass blindly
    const probe=await new Promise(done=>{const T=globalThis.canvas.app.ticker,f=()=>{T.remove(f);let r=null;try{r=this.frames();}catch{}done(r);};T.add(f,null,-100);});
    const seen=probe?frameMasks(probe.off,probe.bare,probe.noShadow,this.w,this.h,this.rad).rawCount:0;
    if(seen<8){this.note='drawing the frame again without her did not take her off the canvas (a cached picture): not judged';return false;}
    this.ok=true;this.blind={};const T=globalThis.canvas.app.ticker;
    this.fn=()=>{if(++this.n%3||!this.phase)return;let F=null;try{F=this.frames();}catch{return;}if(!F)return;this.reads++;
      const M=frameMasks(F.off,F.bare,F.noShadow,this.w,this.h,this.rad),sp=frameSpill(F.on,F.bare,M),
        dOn=boxDiff(F.on,this.ref,this.M0),dOff=boxDiff(F.off,this.ref,this.M0);
      const b=this.by[this.phase]??={reads:0,tot:-1,sp:null,M:null,filters:0,drift:{on:0,off:0,box:null,worst:0}};b.reads++;b.filters=Math.max(b.filters,F.filters);if(M.rawCount<8)b.blind=(b.blind??0)+1;
      if(sp.tot>b.tot){b.tot=sp.tot;b.sp=sp;b.M=M;if(this.keep)this.kept[this.phase]={...F,M,sp};}
      if(dOn.out+dOn.lit>b.drift.on||!b.drift.box){b.drift={on:dOn.out+dOn.lit,off:dOff.out+dOff.lit,box:dOn.box,worst:dOn.worst};if(this.keep)this.kept[this.phase+':drift']={...F};}};
    T.add(this.fn,null,-100);return true;
  }
  stop(){if(this.fn){try{globalThis.canvas?.app?.ticker?.remove(this.fn);}catch{}this.fn=null;}return this.result();}
  /** px (CSS) of a length in samples. */
  css(n){return Math.round(n*this.step/this.res);}
  result(){
    if(!this.ok)return {ok:true,skip:true,bad:[],lines:[],text:`box test: not run (${this.note})`};
    const bad=[],rows=[],old=[],lines=[];let any=null;
    for(const [ph,b] of Object.entries(this.by)){const sp=b.sp,over=b.tot>this.limit;if(!sp)continue;
      rows.push(`${ph} ${b.tot>0?`${sp.out} outside + ${sp.lit} on her shadow${sp.box?` (${this.css(sp.box.w)}×${this.css(sp.box.h)} px, up to ${sp.worst}/255, colour ${rgbText(sp.mean)})`:''}`:'0'}${b.filters?'':' (no filter)'}${b.blind?b.blind===b.reads?' (nothing of her was drawn in any read)':` (${b.blind} of ${b.reads} reads drew nothing of her)`:''}`);
      const d=b.drift;old.push(`${ph} ${d.on} / ${d.off}${d.box&&d.on?` (${this.css(d.box.w)}×${this.css(d.box.h)} px, up to ${d.worst}/255)`:''}`);
      if(over){bad.push(`${ph}: her cloak filters draw outside her over ${this.css(sp.box.w)}×${this.css(sp.box.h)} px (${sp.out} sample(s) over bare map, ${sp.lit} lighting her shadow, up to ${sp.worst}/255)`);if(!any||b.tot>any[1].tot)any=[ph,b];}}
    if(any){const [ph,b]=any,M=b.M;lines.push(`  where (${ph}; the region in 12×12 cells: 1-9 how full of differing samples, o her, . clean): her shape that frame ${M.bounds?`${this.css(M.bounds.w)}×${this.css(M.bounds.h)} px at ${this.css(M.bounds.x)},${this.css(M.bounds.y)}`:'none'}`);
      for(const r of heatRows(b.sp,M))lines.push(`    ${r}`);}
    const M0=this.M0;
    lines.unshift(`  against the screen before the fade (test.8's rule, not judged; samples outside the silhouette she had then, ${M0.bounds?`${this.css(M0.bounds.w)}×${this.css(M0.bounds.h)}`:'?'} px: with her filters / with them bypassed): ${old.join(' · ')||'no reads'}`);
    return {ok:!bad.length,bad,lines,text:`box test (each read draws the same frame again with her cloak filters bypassed, without her shadow and without her; outside what her own pieces draw that frame, widened ${this.css(this.rad)} px, the filters must add nothing; ${this.reads} reads, region ${this.css(this.w)}×${this.css(this.h)} px, limit ${this.limit} samples, the same frame twice ${this.noise}${this.newPieces.size?`, pieces that appeared during the cloak: ${[...this.newPieces].slice(0,6).join(', ')}`:''}): ${rows.join(' · ')||'no reads'}`};
  }
}
/** (test.8) One compact line for the next report: what the cloak filters are given and how large their rectangles are. */
export function cloakDiagnostics(ctx,inv,box){
  try{
    const R=globalThis.canvas?.app?.renderer,rec=inv.recordOf(ctx.token),Z=rec?.state?.s1?.[3]||1;let n=0,big=[0,0],area=0,pad=0,gains=new Set();
    for(const [mesh,r] of rec?.filters??[]){n++;pad=r.filter.padding??pad;gains.add(`${r.kind}:${f2(r.filter.uniforms?.uKind?.[2]??0)}`);let b=null;try{b=mesh.getBounds?.(true);}catch{}if(!b)continue;const w=b.width+2*pad,h=b.height+2*pad;area+=w*h;if(w*h>big[0]*big[1])big=[w,h];}
    const prim=globalThis.canvas?.primary,rt=prim?.renderTexture,sil=box?.M0?.bounds?`${box.css(box.M0.bounds.w)}×${box.css(box.M0.bounds.h)}`:'?';
    const GLN={0:'ZERO',1:'ONE',0x300:'SRC_COLOR',0x301:'ONE_MINUS_SRC_COLOR',0x302:'SRC_ALPHA',0x303:'ONE_MINUS_SRC_ALPHA',0x304:'DST_ALPHA',0x305:'ONE_MINUS_DST_ALPHA',0x306:'DST_COLOR',0x307:'ONE_MINUS_DST_COLOR'},
      BM=globalThis.PIXI?.BLEND_MODES??{},nameOf=v=>{const k=['NORMAL','ERASE'].find(k=>BM[k]===Number(v))??Object.keys(BM).find(k=>BM[k]===Number(v)&&!/^\d+$/.test(k));return k?`${k} (${v})`:String(v);};
    const passes=Object.entries(CLOAK_LAST.by??{}).map(([bm,r])=>`${nameOf(bm)} ×${r.n}: input ${Math.round(r.w)}×${Math.round(r.h)} (frame ${Math.round(r.fw)}×${Math.round(r.fh)}) at ×${r.res??'?'}${r.own==null?' (the filter sets none: the target’s)':r.own!==r.res?` (the filter asks ×${r.own})`:''}${r.ms?` msaa ${r.ms}`:''} clear ${r.clear}${r.gl?r.gl[0]<0?' · GL not read':` · GL ${r.gl[0]?'':'BLEND OFF '}${GLN[r.gl[1]]??r.gl[1]}/${GLN[r.gl[2]]??r.gl[2]}`:''}`);
    const normal=Number(BM.NORMAL??0),foreign=Object.keys(CLOAK_LAST.by??{}).filter(k=>Number(k)!==normal);
    return [`cloak filters: ${n} · padding ${pad} px at zoom ${f2(Z)} · largest rectangle ${Math.round(big[0])}×${Math.round(big[1])} px, all together ${Math.round(area/1000)}k px² · her silhouette ${sil} px · light gain ${[...gains].join(' ')||'-'} · backdrop not used · renderer ×${R?.resolution??'?'}${R?.multisample?` msaa ${R.multisample}`:''} · primary texture ${rt?`×${rt.resolution??rt.baseTexture?.resolution??'?'} ${rt.width}×${rt.height}${rt.framebuffer?.multisample?` msaa ${rt.framebuffer.multisample}`:''}`:'none'} · PIXI ${globalThis.PIXI?.VERSION??'?'} · Filter.defaultResolution ${globalThis.PIXI?.Filter?.defaultResolution??'unset'}`,
      `  filter passes by blend mode since the fade began: ${passes.join(' · ')||'none'}${foreign.length?` · the filter itself is built NORMAL and never changes it: a pass with ${foreign.map(nameOf).join(', ')} was asked for by Foundry or another module (a second draw of her mesh for another layer), and is left as asked`:''}`].join('\n');
  }catch(e){return `cloak filters: diagnostics failed (${e?.message??e})`;}
}

/** Every v11 runtime timed (the test.3 notes' "v11 work": the same methods the counter harness wrapped). */
function timeAll(T,V){
  T.wrap('tokenLayer',V.tokenLayers,['tick'],TICK_PRIO.tokenLayers).wrap('invis',V.invisibility,['tick','drainFor','alphaFor'],TICK_PRIO.invis)
   .wrap('damage',V.damage,['wingVisual','feel','frame','hit']).wrap('heal',V.heal,['wingVisual','feel','feelInput','busy','tick','frameFx'],TICK_PRIO.heal)
   .wrap('emote',V.emote,['feel','wing','weights','flight','visual','draw','busy']).wrap('world',V.world,['wingVisual','feel','shadowOnTokens']);
  return T;
}
/** canvas.perception.update calls while it runs; stop() puts the property back as it was. */
function perceptionCount(){
  const P=globalThis.canvas?.perception;if(!P||typeof P.update!=='function')return {n:0,stop(){return 0;}};
  const desc=Object.getOwnPropertyDescriptor(P,'update'),orig=P.update,c={n:0,ours:0,by:{}};
  // (test.15) who asked: this module, another module or system, or Foundry itself (from the call stack)
  const w=function(...a){c.n++;try{const who=perceptionCaller(`Error\n(x)\n${String(new Error().stack).split('\n').slice(2).filter(l=>!/self-check[\w-]*\.mjs/.test(l)).join('\n')}`);const k=who.source==='filament-flight'?'filament-flight':who.source==='foundry'||!who.source?`Foundry (${who.at??'?'})`:`${who.source} (${who.at??'?'})`;if(who.source==='filament-flight')c.ours++;c.by[k]=(c.by[k]??0)+1;}catch{}return orig.apply(this,a);};w.ffCounting=true;P.update=w;
  c.stop=()=>{if(P.update===w)try{if(desc)Object.defineProperty(P,'update',desc);else delete P.update;}catch{}return c.n;};return c;
}
/** Her token mesh's transform changes and canvas frames while it runs. */
function transformCount(token){
  const c={changes:0,frames:0,last:null},ticker=globalThis.canvas?.app?.ticker;
  const fn=()=>{c.frames++;const m=token.mesh,t=m?.transform,id=t?(t._localID??t._worldID):null,k=id??`${m?.x}|${m?.y}|${m?.rotation}|${m?.scale?.x}|${m?.scale?.y}`;if(c.last!==null&&k!==c.last)c.changes++;c.last=k;};
  try{ticker?.add(fn,null,-42);}catch{}c.stop=()=>{try{ticker?.remove(fn,null);}catch{}return c;};return c;
}
let inkCanvas=null;
/** How much is drawn on a 2D overlay (alpha sum of a 96×96 copy; 0 when it is released). */
function overlayInk(id='filament-flight-v11-heal'){
  const el=document.getElementById(id);if(!el||!el.width||!el.height)return 0;
  inkCanvas??=Object.assign(document.createElement('canvas'),{width:96,height:96});
  const g=inkCanvas.getContext('2d',{willReadFrequently:true});g.clearRect(0,0,96,96);
  try{g.drawImage(el,0,0,el.width,el.height,0,0,96,96);}catch{return 0;}
  const d=g.getImageData(0,0,96,96).data;let s=0;for(let i=3;i<d.length;i+=4)s+=d[i];return s/255;
}
/** Her bits as drawn: id → [dx, dy, alpha] from her token's centre (px). */
function bitOffsets(ctx){
  const m=ctx.token.mesh,out={};if(!m)return out;
  for(const c of globalThis.canvas?.primary?.children??[]){const n=c?.name;if(typeof n!=='string'||!n.startsWith(ctx.prefix)||c.destroyed)continue;
    const k=/^bit\.([^.]+)\./.exec(n.slice(ctx.prefix.length))?.[1];if(!k||c.visible===false||!(c.alpha>.05))continue;
    const o=out[k]??=[0,0,0,0];o[0]+=c.x-m.x;o[1]+=c.y-m.y;o[2]=Math.max(o[2],c.alpha);o[3]++;}
  for(const o of Object.values(out)){o[0]/=o[3];o[1]/=o[3];}
  return out;
}
/** The largest move of any bit between two bitOffsets() (squares); a bit that went or came counts as 1. */
function bitShift(a,b,grid){let m=0;for(const k of new Set([...Object.keys(a),...Object.keys(b)])){const x=a[k],y=b[k];if(!x||!y){m=Math.max(m,1);continue;}m=Math.max(m,Math.hypot(y[0]-x[0],y[1]-x[1])/grid,Math.abs(y[2]-x[2]));}return m;}
/** Which marked moment each pop fell in (a marks list from the recorder): "hero 3 · nat 1 2". */
function popsByMark(events,marks){
  const n={};for(const e of events){if(e.kind==='gap')continue;let m='start';for(const k of marks)if(k.t<=e.t)m=k.label;n[m]=(n[m]??0)+1;}
  return Object.entries(n).map(([k,v])=>`${k} ${v}`).join(' · ');
}
async function watch(H,ms,fn){const end=H.now()+ms;while(H.now()<end){await H.nextFrame();try{fn();}catch{}}}
const runtimesOf=ctx=>ctx.manager?.v11??null;
function needV11(ctx,res){const V=runtimesOf(ctx);if(!V){res.skipped='this build has no v11 runtimes';return null;}return V;}
/** The nearest other token to her (a friendly one first), or null. */
function nearestAlly(ctx,{maxSq=Infinity}={}){
  const c=ctx.token.center,disp=ctx.doc.disposition;let best=null,bd=Infinity,bf=false;
  for(const t of globalThis.canvas?.tokens?.placeables??[]){if(t===ctx.token||t.document===ctx.doc||t.destroyed||t.isPreview||!t.center||t.document?.hidden&&!game.user?.isGM)continue;
    const d=Math.hypot(t.center.x-c.x,t.center.y-c.y)/ctx.grid;if(d>maxSq)continue;const fr=t.document?.disposition===disp;
    if(fr&&!bf||fr===bf&&d<bd){best=t;bd=d;bf=fr;}}
  return best?{token:best,sq:bd,friendly:bf}:null;
}
/** A synthetic PF2e message from her (for the heal and damage runtimes' own readers only). */
const fromHer=(ctx,pf2e,extra={})=>({id:null,speaker:{token:ctx.doc.id,actor:ctx.doc.actorId??ctx.doc.actor?.id,scene:ctx.doc.parent?.id},flags:{pf2e},rolls:[],...extra});
const d20=n=>[{dice:[{faces:20,results:[{result:n,active:true}]}],total:n}];

/* ================================================================ 1. SETUP */
async function v11setup(ctx,res,H){
  const api=ctx.api,v=api?.v11,doc=ctx.doc,V=runtimesOf(ctx);
  const feats=V11_FEATURES.length,parts=V11_FEATURES.reduce((n,f)=>n+(f.parts?.length??0),0),picks=V11_FEATURES.reduce((n,f)=>n+(f.pickers?.length??0),0);
  const unbuilt=V11_FEATURES.filter(f=>!BUILT_IN[f.id]).map(f=>f.id);
  const need=['emote','emotes','features','tokenLayer','tokenShape','fade','faded','heal','invisibility','journal','recap'];
  const missing=need.filter(k=>v?.[k]==null),rts=V?Object.values(V).filter(Boolean).length:0;
  res.lines.push(`registry ${feats} features · ${parts} parts · ${picks} pickers · ${V11_KEYS.size} keys · built ${feats-unbuilt.length}/${feats} · api.v11 ${missing.length?'MISSING '+missing.join(' '):'complete'} · runtimes ${rts}/8`);
  if(missing.length||!V||unbuilt.length)H.verdict(res,'FAIL',`the v11 registry or API is incomplete${missing.length?` (api.v11 lacks ${missing.join(', ')})`:''}${!V?' (no runtimes)':''}${unbuilt.length?` (not built: ${unbuilt.join(', ')})`:''}`);
  else H.verdict(res,'PASS',`the v11 registry loads: ${feats} features, ${parts} parts`);
  const vals=resolveV11(doc),off=V11_FEATURES.filter(f=>!vals[f.id]).map(f=>f.id),on=feats-off.length;
  const partsOff=[];for(const f of V11_FEATURES)if(vals[f.id])for(const p of f.parts??[])if(p.type==='switch'&&!vals[`${f.id}.${p.id}`])partsOff.push(`${f.id}.${p.id}`);
  const changed=[...V11_KEYS].filter(([k,r])=>vals[k]!==r.def).length;
  res.lines.push(`on ${on}/${feats} · off: ${off.join(', ')||'none'}`);
  // (test.23) her cloak as this session found her and as she is now: the flag, what her actor carries, the phase
  try{const inv=V?.invisibility,R=inv?.recordOf?.(ctx.token),L=inv?.atLoad?.get(doc.id);if(inv){const ph=R?inv.evaluate(R,inv.now()):'no record';
    res.lines.push(`cloak at load: ${L?`flag ${L.flag} · carries ${L.sources} · source ${L.src} · look ${L.look}`:'not read'} · now: flag ${R?.flag?JSON.stringify(R.flag):'none'} · carries ${R?Object.entries(R.sources??{}).filter(([,x])=>x).map(([k])=>k).join('+')||'none':'-'} · phase ${ph} · clock ${Math.round(inv.now())}${inv.stats.errors?` · FRAME ERRORS ${inv.stats.errors} (${String(inv.lastError??'').split('\n')[0].slice(0,160)})`:''}`);}}catch{}
  res.lines.push(`parts off in features that are on: ${partsOff.length?partsOff.slice(0,8).join(', ')+(partsOff.length>8?` +${partsOff.length-8}`:''):'none'} · ${changed} value(s) differ from default · frame ${vals.tokenFrame} · invisible ${vals.invisSpell} · skin ${vals.invisSkin} · sweep ${vals.invisSweep} · laugh ${vals.laughStyle} · arc ${vals['nestedWheel.arcSize']} · owner view ${vals['invisLooks.ownerView']}`);
  // v10 keys: every Settings-tab row still bound to a registered, readable key
  let bound=0,read=0;const bad=[];
  for(const rec of ORDER){const it=rec.item;const keys=[];if(it.kind==='client'||it.kind==='world')keys.push(it.k);if(it.fallback)keys.push(it.fallback);if(it.cfg&&typeof it.cfg==='string')keys.push(it.cfg);
    for(const k of keys){bound++;let ok=false;try{game.settings.get(ID,k);ok=true;}catch{}if(ok)read++;else if(!bad.includes(k))bad.push(k);}}
  const routes=Object.keys(ROUTES),lost=routes.filter(id=>{const r=routeFor(id),s=r&&sectionById(r.section);return !s||(r.group&&!s.groups.some(g=>g.id===r.group));});
  const ui=H.setting('keepsakeUI');let pins=null;try{pins=pinnedSections(ui);}catch{}
  res.lines.push(`v10 keys readable ${read}/${bound}${bad.length?` (not: ${bad.slice(0,4).join(', ')})`:''} · old routes land ${routes.length-lost.length}/${routes.length} · pinned ${pins?pins.join('+')||'none':'?'} · v10 pressed list ${Array.isArray(ui?.pressedSettings)?'kept':'none saved'}`);
  if(bad.length||lost.length)H.verdict(res,'FAIL',`settings migration: ${bad.length?`${bad.length} key(s) unreadable`:''}${lost.length?` ${lost.length} old route(s) land nowhere`:''}`);
  else H.verdict(res,'PASS',`settings migration: all ${bound} v10 keys still read`);
  await settingsTab(ctx,res,H);
}
async function settingsTab(ctx,res,H){
  const ctrl=ctx.service?.hudController?.();if(!ctrl){res.lines.push('settings tab: no HUD in this build');return;}
  if(H.setting('hudEnabled')===false){res.lines.push('settings tab: skipped (the HUD is off)');return;}
  const wasOpen=!!(ctrl.opened&&ctrl.app?.rendered),tab0=ctrl.app?.tab??'home';
  res.restore(async()=>{const app=ctrl.app;try{if(app&&app.tab!==tab0)app.switchTab(tab0);}catch{}if(!wasOpen&&ctrl.opened)await ctrl.close();});
  const root=()=>ctrl.app?.element?.querySelector?.('.ks-host')?.shadowRoot??null;
  let t=H.now();if(!ctrl.opened)await ctrl.open();await H.waitUntil(()=>root()?.querySelector('.ks-root'),4000,()=>H.sleep(50));const openMs=H.now()-t;
  if(!ctrl.app?.switchTab){H.verdict(res,'FAIL','the HUD did not open');return;}
  const since=performance.now();t=H.now();ctrl.app.switchTab('settings');
  const ok=await H.waitUntil(()=>root()?.querySelector('[data-ks-settings] button.f-nav'),4000);const tabMs=H.now()-t;
  if(!ok){H.verdict(res,'FAIL','the Settings tab did not render');return;}
  const r=root(),secs=[...r.querySelectorAll('button.f-nav')],start=secs.find(b=>b.classList.contains('on'))??secs[0],times=[];
  // (test.6) click → the frame that shows it (its rAF, then the task after that frame): two whole frames counted
  // the display's own wait twice and whatever else the canvas did meanwhile
  const painted=()=>new Promise(res=>requestAnimationFrame(()=>setTimeout(res,0)));
  // (each section twice, the faster kept: a canvas frame or a GC landing on one click is not the tab's cost)
  for(let pass=0;pass<2;pass++)for(const [i,b] of secs.entries()){const t0=H.now();b.click();await painted();const ms=H.now()-t0,n=r.querySelectorAll('.f-pane .f-grp').length;
    if(!pass)times.push([b.querySelector('b')?.textContent?.trim()??b.dataset.v,ms,n]);else{times[i][1]=Math.min(times[i][1],ms);times[i][2]=Math.max(times[i][2],n);}}
  const worst=times.slice().sort((a,b)=>b[1]-a[1])[0],empty=times.filter(x=>!x[2]).map(x=>x[0]);
  // search, then Enter jumps to the first result
  const input=r.querySelector('.f-search input');let search='no search box',hits=0,jumped=false,jumpMs=0;
  if(input){const t0=H.now();input.value='wounds';input.dispatchEvent(new Event('input',{bubbles:true,composed:true}));await painted();hits=r.querySelectorAll('.f-res').length;const sMs=H.now()-t0;
    // (test.6) Enter → the row shown and flashing (test.5 counted a fixed 450 ms wait in this), then its smooth scroll
    const lt=[];let lo=null;try{lo=new PerformanceObserver(l=>{for(const e of l.getEntries())lt.push(e.duration);});lo.observe({type:'longtask'});}catch{lo=null;}
    const t1=H.now();input.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true,composed:true,cancelable:true}));
    await H.waitUntil(()=>!r.querySelector('.f-res')&&r.querySelector('.f-pane .flash'),1500,()=>painted());const jMs=H.now()-t1;await H.sleep(500);lo?.disconnect();
    const cr=r.querySelector('.f-crumbs'),crumb=[...(cr?.children??[])].map(e=>e.textContent.trim()).filter(Boolean).join(' › ')||(cr?.textContent??'').trim();jumped=!!crumb&&!r.querySelector('.f-res');
    search=`search "wounds" ${hits} results ${f0(sMs)} ms · Enter → ${crumb.slice(0,40)||'?'} ${f0(jMs)} ms (scroll: ${lo?lt.length?`long tasks ${lt.map(f0).join(', ')} ms`:'no long task':'n/a'})`;jumpMs=jMs;
    if(input.value){input.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,composed:true,cancelable:true}));await H.nextFrame();}}
  // a Parts panel opened and closed again
  let partsLine='no Parts panel';const pb=r.querySelector('.f-pane button.f-ptog[data-act=parts]');
  if(pb){const id=pb.dataset.id,t0=H.now();pb.click();await painted();const open=r.querySelector('.f-pane .f-parts.open'),n=open?open.children.length:0,pMs=H.now()-t0;
    const again=r.querySelector(`.f-pane button.f-ptog[data-act=parts][data-id="${CSS.escape(id)}"]`);if(again?.getAttribute('aria-expanded')==='true'){again.click();await H.nextFrame();}
    partsLine=`Parts ${open?`opens ${n} rows`:'did NOT open'} ${f0(pMs)} ms`;if(!open)H.verdict(res,'FAIL','a Parts panel did not open');}
  if(start?.isConnected){start.click();await H.nextFrame();}
  let tm='';try{tm=formatTimings(keepsakeTimings({since,top:4}));}catch{}
  res.lines.push(`settings tab: HUD open ${f0(openMs)} ms · tab ${f0(tabMs)} ms · ${times.length} sections, slowest ${worst?`${worst[0]} ${f0(worst[1])} ms`:'?'}${empty.length?` · EMPTY: ${empty.join(', ')}`:''} · ${search} · ${partsLine}`);
  if(tm)res.lines.push(`  timings: ${tm.slice(0,200)}`);
  if(empty.length)H.verdict(res,'FAIL',`Settings sections drew nothing: ${empty.join(', ')}`);
  if(!hits)H.verdict(res,'FAIL','the Settings search found nothing for "wounds"');else if(!jumped)H.verdict(res,'CHECK','the Settings search did not jump on Enter');
  if(worst&&worst[1]>100||tabMs>400||jumpMs>250)H.verdict(res,'CHECK',`the Settings tab is slow: tab ${f0(tabMs)} ms, ${worst?.[0]} ${f0(worst?.[1])} ms, search jump ${f0(jumpMs)} ms`);
  else if(!res.verdicts.some(x=>/Settings|Parts/.test(x)))H.verdict(res,'PASS',`the Settings tab renders: ${times.length} sections, search and Parts (slowest ${f0(worst?.[1])} ms)`);
}

/* ================================================================ 2. TOKEN LAYER */
const P0=L=>L?.parts??{};
/** (test.8, judged anew in test.9) Idle, the token layer must add nothing outside her token art's own alpha.
 * test.8 read three different frames (her token not drawn · drawn plain · drawn with the layer): her wings and bits
 * move between them, and every pixel they moved over counted as "a second ring". Now ONE frame is drawn three ways
 * in the same tick (as it is · the layer's filter bypassed · her token not drawn): where the plain token leaves that
 * frame untouched (widened one pixel for resampling), so must the layer. test.8's three-frame count is still printed.
 * → {text, lines, bad} */
async function ownAlphaCheck(ctx,H,L){
  const R=globalThis.canvas?.app?.renderer,gl=R?.gl,view=R?.view,m=ctx.token?.mesh,f=L?.filter;if(!gl||!view||!m||!f)return {text:'outside her own alpha: not read (no WebGL view)',bad:null};
  let b=null;try{b=m.getBounds?.(true);}catch{}if(!b||!(b.width>0))return {text:'outside her own alpha: not read (no bounds)',bad:null};
  const res=R.resolution||1,pad=b.width*.14,X0=Math.max(0,Math.floor((b.x-pad)*res)),Y0=Math.max(0,Math.floor((b.y-pad)*res)),X1=Math.min(view.width,Math.ceil((b.x+b.width+pad)*res)),Y1=Math.min(view.height,Math.ceil((b.y+b.height+pad)*res)),w=X1-X0,h=Y1-Y0;
  if(w<8||h<8)return {text:'outside her own alpha: not read (off screen)',bad:null};
  // rows top-down
  const read=()=>{try{R.renderTexture?.bind?.(null);const buf=new Uint8Array(w*h*4),out=new Uint8Array(w*h*4);gl.readPixels(X0,view.height-Y0-h,w,h,gl.RGBA,gl.UNSIGNED_BYTE,buf);
    for(let y=0;y<h;y++)out.set(buf.subarray((h-1-y)*w*4,(h-y)*w*4),y*w*4);return out;}catch{return null;}};
  const T=globalThis.canvas.app.ticker,after=fn=>new Promise(ok=>{const g=()=>{T.remove(g);let v=null;try{v=fn();}catch{v=null;}ok(v);};T.add(g,null,-100);});
  const dirty=()=>{try{const p=globalThis.canvas?.primary;if(p&&'renderDirty' in p)p.renderDirty=true;}catch{}};
  // test.8's rule, for the record: three frames
  let A0=null,B0=null,C0=null;
  try{m.renderable=false;dirty();A0=await after(read);m.renderable=true;f.enabled=false;dirty();B0=await after(read);}finally{m.renderable=true;f.enabled=true;dirty();}
  await after(read);C0=await after(read);
  // the same frame, three ways
  const F=await after(()=>{let on=read(),off=null,bare=null;
    try{f.enabled=false;redrawNow();off=read();m.renderable=false;redrawNow();bare=read();}finally{m.renderable=true;f.enabled=true;try{redrawNow();}catch{}}
    return on&&off&&bare?{on,off,bare}:null;});
  if(!F)return {text:'outside her own alpha: not read (the canvas cannot be read here)',bad:null};
  let lit=0;for(let i=0;i<F.bare.length;i+=4)if(Math.max(F.bare[i],F.bare[i+1],F.bare[i+2])>=12)lit++;if(lit<F.bare.length/4*.2)return {text:'outside her own alpha: not read (the canvas reads back black)',bad:null};
  const M=frameMasks(F.off,F.bare,null,w,h,Math.max(1,Math.ceil(res))),sp=frameSpill(F.on,F.bare,M);
  if(M.rawCount<8)return {text:'outside her own alpha: not read (drawing the frame again without her token did not take it off the canvas)',bad:null};
  let old='';if(A0&&B0&&C0){let outside=0,added=0,worst=0;const d=(P,Q,i)=>Math.max(Math.abs(P[i]-Q[i]),Math.abs(P[i+1]-Q[i+1]),Math.abs(P[i+2]-Q[i+2]));
    for(let i=0;i<A0.length;i+=4){if(d(A0,B0,i)>3)continue;outside++;const v=d(A0,C0,i);if(v>10){added++;if(v>worst)worst=v;}}
    old=` · test.8's rule (three frames apart, not judged): ${added} of ${outside} px${added?` (up to ${worst}/255)`:''}`;}
  const outside=M.outsideCount,bad=sp.out>24&&sp.out/Math.max(1,outside)>.004,lines=[];
  if(bad){lines.push(`  where (her token's region in 12×12 cells: 1-9 how full of changed pixels, o her token art, . clean): her art that frame ${M.bounds?`${Math.round(M.bounds.w/res)}×${Math.round(M.bounds.h/res)} px`:'none'}, her mesh ${Math.round(b.width)}×${Math.round(b.height)} px`);for(const r of heatRows(sp,M))lines.push(`    ${r}`);}
  return {text:`outside her own token art (idle; one frame drawn with the layer, with it bypassed, and without her token; ${outside} px outside her art): ${sp.out} px changed by the layer${sp.out?` (${sp.box.w}×${sp.box.h} px, up to ${sp.worst}/255, colour ${rgbText(sp.mean)})`:''}${old}`,lines,
    bad:bad?`the token layer draws outside her token art's own alpha (${sp.out} px, up to ${sp.worst}/255) in the same frame: a second ring`:null};
}
async function v11token(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const TL=V.tokenLayers,doc=ctx.doc;
  if(!isOn('tokenLayer',doc)){res.skipped='the Token layer is off for her';return;}
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1200});
  let L=TL.layerOf(ctx.token);
  if(!L){TL.sync(ctx.token);L=TL.layerOf(ctx.token);if(L)res.lines.push('(the layer was not on her token yet: synced once)');}
  if(!L?.filter){H.verdict(res,'FAIL','no token layer filter on her token');return;}
  const on=()=>!!(L.filter&&ctx.token.mesh?.filters?.includes(L.filter));
  const a0=on();
  try{ctx.token.renderFlags?.set?.({refresh:true});}catch{}await H.sleep(300);const a1=on();
  // Foundry handing her mesh a new filter list (a detection filter does): ours must go back on
  let a2=null;const m=ctx.token.mesh;
  if(a1&&m){const keep=m.filters;m.filters=keep.filter(f=>f!==L.filter);if(!m.filters.length)m.filters=null;try{ctx.token.renderFlags?.set?.({refreshState:true});}catch{}
    a2=await H.waitUntil(on,1500);if(!a2){L.keep();}}
  const fr=L.frames,rim=L.filter?.rim??null;
  // (test.8) the drawn frame is a choice (off by default): with it off the rim effects sit on her own token art's ring
  res.lines.push(`drawn frame ${P0(L).frame?'ON ('+L.variant+')':'off (her own ring)'}${P0(L).frame?'':rim?` · her ring: ${rim.fallback?'picture not readable, a plain circular band':rim.found?`found in her picture, ${f0(rim.thickness*100)}% of her radius thick`:`no ring step in her picture, ${f0(rim.thickness*100)}% used`} at radius ${f2(rim.radius)}`:' · her ring: NOT found (no mask)'}`);
  if(!P0(L).frame&&!rim)H.verdict(res,'FAIL','the drawn frame is off but her own ring was not found: rim lights, beads and the hidden outline have nowhere to go');
  res.lines.push(`filter on her mesh ${a0?'yes':'NO'} · after a refresh ${a1?'yes':'NO'} · after a new filter list ${a2==null?'-':a2?'back':'NOT back (put back)'} · frame ${L.variant} ${!fr?'(frame part off)':fr.failed?'FAILED to load':fr.ready?'loaded':'loading'} · ${L.wingless?'wingless':'wings shown'}`);
  if(!a0||!a1)H.verdict(res,'FAIL','the token layer filter is not on her token mesh');else if(a2===false)H.verdict(res,'FAIL','her token layer filter did not come back after Foundry replaced her filter list');
  if(fr?.failed)H.verdict(res,'FAIL',`the ${L.variant} frame did not load`);
  // (test.9) her token's shape profile: what was measured on her art, how she is drawn, and the detector against pictures it must get right
  try{const ts=ctx.api?.v11?.tokenShape?.(ctx.token),d=ts?.drawn,st=shapeSelfTest(),badS=st.filter(x=>!x.ok);
    res.lines.push(`her token's shape (${ts?.mode??'?'}): ${ts?.text??'not measured'}${d?` · drawn ${d.grid.w}×${d.grid.h} square(s), ${f0(d.mesh.w)}×${f0(d.mesh.h)} px of a ${f0(d.texture.w)}×${f0(d.texture.h)} picture, scale ${d.scale.x}×${d.scale.y}${d.fit?` fit ${d.fit}`:''}, anchor ${f2(d.anchor.x)},${f2(d.anchor.y)}, turned ${f0(d.rotation)}°${d.mirror.x||d.mirror.y?' mirrored':''}, ${f0(d.heightScale*100)}% with height${d.foundryRing?', Foundry’s dynamic ring on':''}`:''}${ts?.measured?` · her art ${f0(ts.art.w)}×${f0(ts.art.h)} px, centre ${f2(ts.centre.x)},${f2(ts.centre.y)}, portrait ${f0(ts.portrait*100)}% of it, border colour ${ts.border.colour.join(' ')}`:''}`);
    res.lines.push(`  the detector on ${st.length} synthetic pictures: ${st.length-badS.length}/${st.length}${badS.length?` · WRONG: ${badS.map(x=>`${x.name} → ${x.got}`).join('; ')}`:` (${st.map(x=>x.name).join(', ')})`}`);
    if(badS.length)H.verdict(res,'FAIL',`the token shape detector misreads: ${badS.map(x=>x.name).join(', ')}`);
    else H.verdict(res,'PASS',ts?.measured&&!ts.fallback?`her token's shape is measured (${ts.text}) and the detector reads all ${st.length} synthetic pictures`:`the token shape detector reads all ${st.length} synthetic pictures (her own picture could not be read here: a plain round band is used)`);
  }catch(e){res.lines.push(`her token's shape: failed (${e?.message??e})`);H.verdict(res,'FAIL','the token shape profile threw');}
  // each part reacts
  {const o=await ownAlphaCheck(ctx,H,L);res.lines.push(o.text);for(const l of o.lines??[])res.lines.push(l);if(o.bad)H.verdict(res,'FAIL',o.bad);}
  const P=L.parts,rPx=L.filter.uniforms?.uGeo?.[2]||50,T=new V11Timer();res.restore(()=>T.restore());T.wrap('tokenLayer',TL,['tick'],TICK_PRIO.tokenLayers).start();
  const base=createLook(),peakOf=async ms=>{copyLook(L.shown,base);let peak=0;await watch(H,ms,()=>{peak=Math.max(peak,lookDelta(L.shown,base,rPx));});return peak;};
  const pc0=perceptionCount(),tc0=transformCount(ctx.token);const noise=await peakOf(700);pc0.stop();tc0.stop();const quiet={perc:pc0.n/Math.max(1,tc0.frames),tr:tc0.changes/Math.max(1,tc0.frames),ms:T.read().perFrame};
  T.reset();const rec=ctx.recorder;rec.begin();const up0=TL.stats.uploads;
  const pc=perceptionCount(),tc=transformCount(ctx.token),out=[],thr=Math.max(.35,noise*1.6+.15);
  const part=async(name,id,fire,undo=null,ms=750,after=300)=>{ctx.check();if(id&&P[id]===false){out.push(`${name} off`);return;}
    copyLook(L.shown,base);let peak=0;fire();await watch(H,ms,()=>{peak=Math.max(peak,lookDelta(L.shown,base,rPx));});
    try{await undo?.();}catch{}await H.sleep(after);out.push(`${name} ${peak===Infinity?'new marks':f1(peak)}`);if(peak<thr)(ctx.v11quiet??=[]).push(name);};
  ctx.v11quiet=[];
  await part('hit','recoil',()=>TL.hit(ctx.token,{type:'fire',dir:[-1,0],sev:.7}));
  let rimLights=0;const rimWatch=()=>{rimLights=Math.max(rimLights,L.shown?.n?.rim??0);};try{globalThis.canvas?.app?.ticker?.add(rimWatch,null,-41);}catch{}
  await part('heal','heal',()=>TL.heal(ctx.token,{k:1,big:false}));
  try{globalThis.canvas?.app?.ticker?.remove(rimWatch);}catch{}
  await part('emote','emotes',()=>TL.emote(ctx.token,'bow'),()=>TL.emoteEnd(ctx.token,.2));
  await part('fear','fear',()=>{L.target.fear=.85;L.wakeUp();},()=>L.readActor(),900,500);
  await part('unconscious','ko',()=>{L.target.ko=1;L.wakeUp();},()=>L.readActor(),900,900);
  await part('hidden','hidden',()=>TL.hidden(ctx.token,true),async()=>{TL.hidden(ctx.token,false);await H.sleep(1500);},1100,200);
  pc.stop();tc.stop();const frames=rec.end(),cost=T.read();T.restore();
  const busy={perc:pc.n/Math.max(1,tc.frames),ours:pc.ours/Math.max(1,tc.frames),tr:tc.changes/Math.max(1,tc.frames)};
  res.lines.push(`reacts (look change px, still-noise ${f1(noise)}): ${out.join(' · ')} · uploads ${TL.stats.uploads-up0}`);
  res.lines.push(`cost ${f3(cost.perFrame)} ms/frame reacting (${f3(quiet.ms)} hovering) · perception ${f2(busy.perc)}/frame (before ${f2(quiet.perc)}) · her transform changes ${f2(busy.tr)}/frame (before ${f2(quiet.tr)})`);
  const flat=ctx.v11quiet;
  res.lines.push(`rim lights during the heal: ${rimLights} on ${P.frame?'the drawn frame':'her own ring'}`);
  if(P.heal!==false&&!rimLights)H.verdict(res,'FAIL',`a heal put no light on ${P.frame?'the drawn frame':'her own ring'} (frame ${P.frame?'on':'off'})`);
  if(flat.length)H.verdict(res,'FAIL',`no visible change for: ${flat.join(', ')}`);else H.verdict(res,'PASS',`every part reacts (hit, heal, emote, fear, unconscious, hidden) with the drawn frame ${P.frame?'on':'off'}`);
  // (test.15) judged on who asked. The hits, the fear and the unconscious state here are real changes to her, and PF2e, Foundry
  // and other modules refresh perception for them (more so while she is the selected token): that is theirs, and is listed.
  if(pc.n){const by=Object.entries(pc.by).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([k,n])=>`${k} ×${n}`).join(' · ');res.lines.push(`perception asked ${pc.n} time(s) while it reacted: ${by}`);}
  if(busy.ours>.005)H.verdict(res,'FAIL',`the token layer asked for perception (${pc.ours} time(s), ${f2(busy.ours)} a frame)`);
  else if(busy.tr>quiet.tr+.1)H.verdict(res,'CHECK',`her token transform changed more while the layer reacted (${f2(busy.tr)} a frame, ${f2(quiet.tr)} before)`);
  else H.verdict(res,'PASS','no extra perception and no transform changes from the layer');
  if(cost.perFrame>1)H.verdict(res,'CHECK',`the token layer costs ${f2(cost.perFrame)} ms a frame while it reacts`);
  H.popVerdicts(res,H.findPops(frames,ctx.grid));
}

/* ================================================================ 3. WOUNDS */
async function v11wounds(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const D=V.damage,doc=ctx.doc,actor=doc.actor;
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1200});
  const r=D.recordOf(ctx.token);if(!r){H.verdict(res,'FAIL','the damage runtime keeps no record for her');return;}
  const T=new V11Timer();res.restore(()=>T.restore());
  // what the wing painter is handed each frame (its v11dmg state)
  let last=null;const seen=[];T.tap(D,'wingVisual',out=>{last=out?.v11dmg??null;if(last)seen.push(last);});
  // (her wings off or folded: the same moment goes to her frame, the token layer)
  T.tap(D,'frame',out=>{if(out?.D)seen.push(out.D);});
  T.wrap('damage',D,['wingVisual','feel','frame','hit']).start();
  res.restore(()=>{for(const k of [doc.id,actor?.uuid,doc.actorId,actor?.id])if(k)D.types.delete(k);});
  // --- the 11 types, then a homebrew one
  const rec=ctx.recorder;rec.begin();
  const types=[...WOUND_LOOKS,'starfire'],row=[],miss=[],off=[];let parseOk=0;
  for(const type of types){
    ctx.check();ctx.progress(`V11 wounds: ${type}…`);
    const look=woundLookOf(type),pid='wound'+(look==='other'?'Other':look[0].toUpperCase()+look.slice(1));
    const msg={id:null,speaker:{},flags:{pf2e:{context:{type:'damage-roll',target:{token:doc.uuid,actor:actor?.uuid}}}},rolls:[{instances:[{type,total:6}],total:6}]};
    if(readDamageMessage(msg)?.type===type)parseOk++;
    D.noteMessage(msg);seen.length=0;rec.mark(type);
    D.hit(ctx.token,{dx:-1,dy:0,severity:.45});
    await H.sleep(type==='starfire'?600:1050);
    const got=seen.filter(x=>x.wound).map(x=>x.wound.look),hit=got.includes(look),q=Math.max(0,...seen.filter(x=>x.wound?.look===look).map(x=>x.wound.q));
    if(!partOn('wounds',pid,doc)){off.push(type);row.push(`${type.slice(0,5)} off`);continue;}
    if(!hit)miss.push(type);row.push(`${type.slice(0,5)} ${hit?`${f1(q)}s`:'NONE'}`);
    if(type==='starfire'){const tint=r.S.wound?.tint,t=tintForType('starfire');res.lines.push(`homebrew "starfire": look ${got.at(-1)??'none'} · tint ${tint?`hue ${t.hue} from the ${t.from}`:'NONE'}`);if(!tint||!hit)H.verdict(res,'FAIL','an unknown damage type did not fall back to the generic mark');}
  }
  // recovery after the last blow
  const t0=H.now();const back=await H.waitUntil(()=>!r.S.wound&&(!last||!last.wound),5000);const rt=(H.now()-t0)/1000;
  const wFrames=rec.end();
  res.lines.push(`wounds (seconds of wound seen in 1 s): ${row.join(' · ')}`);
  res.lines.push(`synthetic damage records parsed ${parseOk}/${types.length} · after the last blow the wing recovered ${back?`in ${f1(rt+.6)} s`:'NOT within 5 s'}${off.length?` · parts off: ${off.join(', ')}`:''}`);
  if(miss.length)H.verdict(res,'FAIL',`no wound drawn for: ${miss.join(', ')}`);else H.verdict(res,'PASS',`all ${types.length-1-off.filter(t=>t!=='starfire').length} wound types draw on her wing`);
  if(!back)H.verdict(res,'FAIL','her wing did not recover from a wound');
  const wp=H.findPops(wFrames,ctx.grid);H.popVerdicts(res,wp,{name:' (wounds)'});
  if(wp.events.some(e=>e.kind!=='gap'))res.lines.push(`pops by type: ${popsByMark(wp.events,rec.marks)}`);
  // --- persistent damage: three real conditions, then removed
  ctx.check();ctx.progress('V11 wounds: persistent damage…');
  if(!isOn('persistent',doc))res.lines.push('persistent damage: off for her');
  else await withPersistent(ctx,res,H,r,()=>last,seen);
  // --- low HP and dying (grounded: dying is drawn on her fallen pose)
  ctx.check();ctx.progress('V11 wounds: low HP and dying…');
  await dyingStages(ctx,res,H,r,seen);
  // --- moods: her damage record's conditions for a moment
  ctx.check();ctx.progress('V11 wounds: moods…');
  if(!isOn('moodWeather',doc))res.lines.push('moods: Mood weather is off for her');
  else{
    const c0={...r.cond},a0=r.afterglowAt,moods=[];
    try{
      for(const [mood,set] of [['frightened',c=>{c.frightened=1;}],['sickened',c=>{c.sickened=1;}],['doomed',c=>{c.doomed=1;}],['quickened',c=>{c.quickened=1;}],['afterglow',()=>{r.afterglowAt=clock();}]]){
        Object.assign(r.cond,{frightened:0,sickened:0,doomed:0,wounded:0,quickened:0});r.afterglowAt=-1e9;set(r.cond);D.wake(r);seen.length=0;
        await H.sleep(650);
        const part='mood'+mood[0].toUpperCase()+mood.slice(1),k=Math.max(0,...seen.filter(x=>x.mood?.to===mood).map(x=>x.mood.k));
        moods.push(!partOn('moodWeather',part,doc)?`${mood} off`:`${mood} ${r.S.mood.to===mood&&k>0?f2(k):'NONE'}`);
      }
    }finally{Object.assign(r.cond,c0);r.afterglowAt=a0;try{r.readActor();}catch{}D.wake(r);}
    res.lines.push(`moods (eased in after 0.65 s): ${moods.join(' · ')}`);
    const none=moods.filter(x=>/NONE/.test(x));if(none.length)H.verdict(res,'FAIL',`mood weather did not show: ${none.map(x=>x.split(' ')[0]).join(', ')}`);else H.verdict(res,'PASS','every mood weather state shows');
  }
  const cost=T.read();res.lines.push(`damage runtime ${f3(cost.perFrame)} ms/frame over the part (worst call ${f2(cost.max)} ms)`);
  if(cost.perFrame>1)H.verdict(res,'CHECK',`wounds cost ${f2(cost.perFrame)} ms a frame`);
}
/** Three persistent-damage conditions on her (PF2e's own condition), each claims a quarter; then removed (cleansed endings). */
async function withPersistent(ctx,res,H,r,lastOf,seen){
  const actor=ctx.doc.actor;
  if(!actor?.isOwner||typeof actor.createEmbeddedDocuments!=='function'){res.lines.push('persistent damage: skipped (her actor cannot be changed here)');return;}
  const base=(()=>{try{return game.pf2e?.ConditionManager?.getCondition?.('persistent-damage')??null;}catch{return null;}})();
  if(!base){res.lines.push('persistent damage: skipped (PF2e\'s persistent-damage condition is not available)');return;}
  const want=['fire','bleed','acid'];
  const out=await H.withHp(ctx,async()=>{
    const src=want.map(type=>{const o=base.toObject?.()??structuredClone(base);delete o._id;o.system??={};o.system.persistent={formula:'1d4',damageType:type,dc:15};return o;});
    const made=await actor.createEmbeddedDocuments('Item',src);
    seen.length=0;await H.sleep(1500);
    const quads=persistQuarters(r.S),got=want.filter(t=>quads[t]),distinct=new Set(Object.values(quads)).size;
    const drawn=new Set(seen.flatMap(x=>(x.persist??[]).map(c=>c.look)));
    const v10=ctx.manager?.states?.get?.(ctx.token)?.snapshot?.conditionResponse?.damageTypes??null,filt=v11PersistFilter(resolveV11(ctx.doc));
    const v10left=Array.isArray(v10)?v10.filter(t=>want.includes(t)):null;
    seen.length=0;await actor.deleteEmbeddedDocuments('Item',made.map(d=>d.id??d._id).filter(Boolean));
    await H.sleep(900);
    const cleansed=new Set(seen.flatMap(x=>(x.persist??[]).filter(c=>c.cq>=0).map(c=>c.look)));
    await H.sleep(1100);
    return {quads,got,distinct,drawn,v10left,filt,cleansed};
  },res);
  if(out?.skipped){res.lines.push(`persistent damage: skipped (${out.skipped})`);return;}
  const v=out?.value;if(!v){H.verdict(res,'FAIL','persistent damage: could not apply the conditions');return;}
  res.lines.push(`persistent ${want.join('+')}: quarters ${Object.entries(v.quads).map(([t,q])=>`${t} ${q}`).join(', ')||'none'} · drawn ${[...v.drawn].join(',')||'none'} · v10 art keeps ${v.v10left==null?'?':v.v10left.length?v.v10left.join(','):'none'} · cleansed endings ${[...v.cleansed].join(',')||'none'}${out.restoreNote?` · ${out.restoreNote}`:''}`);
  const bad=[];if(v.got.length<want.length)bad.push(`only ${v.got.length} of ${want.length} claimed a quarter`);else if(v.distinct<want.length)bad.push('two types share a quarter');
  if(want.some(t=>!v.drawn.has(t)))bad.push(`not drawn: ${want.filter(t=>!v.drawn.has(t)).join(', ')}`);
  if(v.v10left?.length)bad.push(`the v10 art still draws ${v.v10left.join(', ')}`);
  if(want.some(t=>!v.cleansed.has(t)))bad.push(`no cleansed ending for ${want.filter(t=>!v.cleansed.has(t)).join(', ')}`);
  if(bad.length)H.verdict(res,'FAIL',`persistent damage: ${bad.join('; ')}`);else H.verdict(res,'PASS',`persistent damage: ${want.length} types, a quarter each, the v10 art steps aside, each ends cleansed`);
}
/** Low-HP fatigue, then dying 1–3 (her real HP and dying value, all put back). Grounded, so Last light does not take her. */
async function dyingStages(ctx,res,H,r,seen){
  const actor=ctx.doc.actor;if(!H.hpPath(actor)){res.lines.push('dying: skipped (no HP on her actor)');return;}
  if(!actor.isOwner){res.lines.push('dying: skipped (you do not own her actor)');return;}
  const st0=H.call.state(ctx);
  if(st0?.airborne){await H.call.land(ctx);await H.waitUntil(()=>!H.call.state(ctx)?.airborne&&!H.call.state(ctx)?.transition?.active,7000,()=>H.sleep(100));await H.sleep(600);}
  const dyMax=Number(actor.system?.attributes?.dying?.max)||4,hadDying=actor.system?.attributes?.dying!==undefined;
  if(!hadDying)res.restore(async()=>{if(actor.system?.attributes?.dying!==undefined)try{await actor.update({'system.attributes.-=dying':null});}catch{}});
  const useConditions=typeof actor.increaseCondition==='function'&&!!game.pf2e;
  const setDying=async v=>{
    if(useConditions){const cur=Number(actor.system?.attributes?.dying?.value)||0;
      if(v>cur)for(let i=cur;i<v;i++)await actor.increaseCondition('dying');
      else if(v<cur){if(v===0)await actor.decreaseCondition('dying',{forceRemove:true});else for(let i=cur;i>v;i--)await actor.decreaseCondition('dying');}}
    else await actor.update({'system.attributes.dying.value':v});};
  const out=await H.withHp(ctx,async(a,hp)=>{
    const R={};
    // fatigue below a quarter
    seen.length=0;await a.update({'system.attributes.hp.value':Math.max(1,Math.floor((hp.max||10)*.18))});await H.sleep(1700);R.fatigue=r.f??0;
    // dying 1, 2, 3 on HP 0
    await a.update({'system.attributes.hp.value':0});
    const stage=async(v,key,ms)=>{seen.length=0;await setDying(v);await H.sleep(ms);const k=Math.max(0,...seen.filter(x=>x.dying).map(x=>x.dying[key]??0));return {level:r.S.dying.level,k};};
    R.d1=await stage(1,'huddle',1500);R.d2=await stage(2,'ember',1700);
    R.d3=dyMax>3?await stage(3,'lost',1500):null;
    seen.length=0;await setDying(0);await a.update({'system.attributes.hp.value':hp.value});await H.sleep(1400);
    R.heal=Math.max(-1,...seen.filter(x=>x.dying).map(x=>x.dying.heal??-1));
    return R;
  },res);
  if(out?.skipped){res.lines.push(`dying: skipped (${out.skipped})`);return;}
  const v=out?.value??{},P=r.parts.dyingStages??{};
  res.lines.push(`low HP fatigue ${f2(v.fatigue)} · dying 1 huddle ${f2(v.d1?.k)} · 2 embers ${f2(v.d2?.k)} · 3 ${v.d3?`bit out ${f2(v.d3.k)}`:'skipped (dying max '+dyMax+')'} · recovery ${v.heal>=0?'rekindles':'NONE'} · via ${useConditions?'PF2e conditions':'dying value'}${out.restoreNote?` · ${out.restoreNote}`:''}`);
  const bad=[];
  if(isOn('lowHpFatigue',ctx.doc)&&!(v.fatigue>.05))bad.push('no fatigue below a quarter HP');
  if(isOn('dyingStages',ctx.doc)){if(P.dying1&&!(v.d1?.k>0))bad.push('dying 1');if(P.dying2&&!(v.d2?.k>0))bad.push('dying 2');if(v.d3&&P.dying3&&!(v.d3.k>0))bad.push('dying 3');if(P.dyingRecover&&!(v.heal>=0))bad.push('recovery');}
  if(bad.length)H.verdict(res,'FAIL',`not drawn: ${bad.join(', ')}`);else H.verdict(res,'PASS','low-HP fatigue and each dying stage draw, and the light rekindles');
  if(res.hpRestore&&res.hpRestore!=='ok')H.verdict(res,'CHECK',`HP restore: ${res.hpRestore}`);
  if(st0?.airborne){await H.ensureFlying(ctx);}
}

/* ================================================================ 4. INVISIBILITY */
async function v11invis(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const inv=V.invisibility,doc=ctx.doc,api=ctx.api;
  if(!api?.v11?.fade){res.skipped='no Fade in this build';return;}
  if(!isOn('invisLooks',doc))res.lines.push('(Invisibility looks are off for her: only the portrait drain plays)');
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1200});
  const st=()=>inv.status(ctx.token)??{};if(st().phase!=='solid'){res.skipped=`she is already ${st().phase} (a cloak or invisibility is on)`;return;}
  const R=inv.recordOf(ctx.token);
  res.lines.push(`what you see of her while hidden (owner/GM, this browser): ${ownerViewOf(choice('invisLooks.ownerView',doc))} · you are ${game.user?.isGM?'the GM':doc.isOwner?'her owner':'not her owner'} · her view here: ${st().view??'?'}`);
  const T=new V11Timer();res.restore(()=>T.restore());T.wrap('invis',inv,['tick','drainFor','alphaFor'],TICK_PRIO.invis).start();
  res.restore(async()=>{if(st().flag?.on||st().phase!=='solid'){try{await api.v11.fade(false,{token:ctx.token});}catch{}await H.waitUntil(()=>st().phase==='solid',6000,()=>H.sleep(100));}});
  const rec=ctx.recorder;rec.begin();
  /** Watch the runtime until a phase (or ms): phases seen, filters in each, front path. */
  const follow=async(ms,until=null)=>{const o={ph:{},fronts:[],t0:H.now(),endedAt:null};await watch(H,ms,()=>{const s=st();(o.ph[s.phase]??=[0,0,0]);o.ph[s.phase][0]++;o.ph[s.phase][1]=Math.max(o.ph[s.phase][1],s.filters??0);o.ph[s.phase][2]=s.filters??0;if(s.phase==='sweep')o.fronts.push(s.front);if(until&&o.endedAt==null&&until(s))o.endedAt=H.now()-o.t0;});return o;};
  const mono=(a,sign)=>{let back=0;for(let i=1;i<a.length;i++)if((a[i]-a[i-1])*sign<-1e-4)back++;return a.length>3&&back<=1;};
  const synced=()=>sameJ(doc.getFlag?.(ID,CLOAK_FLAG)??null,R?.flag??null);
  // the Fade on: sweep, then held without a filter
  ctx.progress('V11 invisibility: Fade on…');
  const s0=inv.stats.sweeps,fw0=inv.stats.flagWrites;
  // (test.6) the screen itself during the sweep: test.5's filter painted black boxes the runtime never saw
  const scr=new ScreenWatch(ctx,H),scrW=new ScreenWatch(ctx,H,{wings:true});res.restore(()=>{scr.stop();scrW.stop();});await scr.start();await scrW.start();
  // (test.8) the box: nothing may be drawn round her, outside her own silhouette (her pieces blink for a few frames while the references are read)
  const box=new BoxWatch(ctx,H);res.restore(()=>{box.stop();});await box.start();resetCloakLast(2);box.phase='Fade on';let diag=null,diagLate=null;
  await api.v11.fade(true,{token:ctx.token});
  const on=await follow(sweepMs(ctx)+900,s=>{if(!diag&&s.phase==='sweep'&&s.front>-.2)diag=cloakDiagnostics(ctx,inv,box);if(diag&&s.phase==='sweep')diagLate=cloakDiagnostics(ctx,inv,box);return s.phase==='held';});const screen=scr.stop(),screenW=scrW.stop();
  box.phase='held';await watch(H,500,()=>{});box.phase='';
  const flagOk=await H.waitUntil(synced,1500),fl=st().flag;
  const look=fl?.variant??st().look,dir0=fl?.dir??choice('invisSweep',doc);
  res.lines.push(`Fade on (${look}, from the ${dir0}): ${on.ph.sweep?`sweep ${f1((on.endedAt??0)/1000)} s, ${on.ph.sweep[1]} filter(s)`:on.ph.drain?'classic drain':'NO sweep'} · held ${on.ph.held?`with ${on.ph.held[2]} filter(s) once settled`:'NEVER'} · flag ${flagOk?'synced':'NOT synced'} (on ${fl?.on} fade ${fl?.fade}, ${inv.stats.flagWrites-fw0} write) · ${f0(T.read().perFrame*1000)} µs/frame`);
  res.lines.push(`${screen.text} · ${screenW.text}`);
  const bad=[];if(!on.ph.held)bad.push('she never became held');
  for(const S of [screen,screenW])if(!S.ok)bad.push(`black on screen during the sweep (${S.text})`);if(on.ph.held?.[2])bad.push('a filter stayed on while held');if(isOn('invisLooks',doc)&&look!=='classic'&&look!=='none'&&!(on.ph.sweep?.[1]>0))bad.push('no filter during the sweep');if(!flagOk)bad.push('the cloak flag did not sync');
  // what other players would see while she is held
  ctx.progress('V11 invisibility: what others see…');
  const seeOthers=visibilityFor(ctx,res,H,inv);
  // a flicker on a synthetic hit while held
  let flick='-';
  if(isOn('invisFlicker',doc)&&R){const max=Number(doc.actor?.system?.attributes?.hp?.max)||40;box.phase='flicker';inv.hit(R,Math.max(1,Math.round(max*.15)),max);
    const f=await follow(2300,s=>s.phase==='held');const t1=H.now(),clear=await H.waitUntil(()=>st().phase==='held'&&!st().filters,2000);
    flick=f.ph.flicker?`flicker ${f.ph.flicker[1]} filter(s), then held ${f.ph.held?(clear?`0 filters ${f1((H.now()-t1)/1000+.5)} s after`:`${st().filters} filter(s) STILL`):'NO'}`:'NO flicker';
    if(!f.ph.flicker)bad.push('no flicker on a hit');if(f.ph.held&&!clear)bad.push('a filter stayed after the flicker');}
  else flick='Flicker on hit is off';
  // the Fade off
  ctx.progress('V11 invisibility: Fade off…');box.phase='Fade off';
  await api.v11.fade(false,{token:ctx.token});
  const offW=await follow(sweepMs(ctx)+900,s=>s.phase==='solid');const back=await H.waitUntil(()=>st().phase==='solid'&&!st().filters,1500);
  res.lines.push(`hit while held: ${flick} · Fade off: ${offW.ph.sweep?`sweep back ${f1((offW.endedAt??0)/1000)} s`:offW.ph.drain?'reveal':'NO sweep'} · solid ${back?'with 0 filters':'NOT (filters '+st().filters+')'} · sweeps ${inv.stats.sweeps-s0}`);
  if(!back)bad.push('she did not come back solid without a filter');
  // each look and each direction: a partial sweep out and back (the front reverses where it is)
  const dirs=['left','right','top','bottom'],rest=dirs.filter(d=>d!==dir0),pairs=[['a',rest[0]],['b',rest[1]],['c',rest[2]]],row=[];
  for(const [lk,dir] of pairs){ctx.check();ctx.progress(`V11 invisibility: look ${lk.toUpperCase()} from the ${dir}…`);
    box.phase=`${lk.toUpperCase()} ${dir}`;inv.cloak(ctx.token,true,{look:lk,sweep:dir});
    const w=await follow(1500);const S=R?.state,vi=S?.s2?.[1],da=S?.s0?.[3];
    inv.cloak(ctx.token,false,{look:lk,sweep:dir});
    const b=await follow(2600,s=>s.phase==='solid');
    const ok=!!w.ph.sweep?.[1]&&mono(w.fronts,1)&&b.endedAt!=null&&vi===VARIANT_INDEX[lk]&&Math.abs((da??99)-DIRECTIONS[dir].dirA)<1e-3;
    row.push(`${lk.toUpperCase()} ${dir} ${w.ph.sweep?`${w.ph.sweep[1]}f`:'no sweep'}${mono(w.fronts,1)?'':' front jumps'}${vi===VARIANT_INDEX[lk]?'':' wrong look'}${Math.abs((da??99)-DIRECTIONS[dir].dirA)<1e-3?'':' wrong side'} back ${b.endedAt!=null?f1(b.endedAt/1000)+'s':'NO'}`);
    if(!ok)bad.push(`look ${lk.toUpperCase()} from the ${dir}`);
    await H.waitUntil(()=>st().phase==='solid'&&!st().filters,1500);}
  // Classic: the drain, then the reveal
  ctx.progress('V11 invisibility: classic drain…');box.phase='Classic';
  // (the path read() takes when the invisible condition arrives with the Classic look: here without the condition)
  const TLs=ctx.manager?.v11?.tokenLayers,classic=on=>{if(!R)return;R.src=on?'spell':null;R.look=on?'classic':null;R.classic={mode:on?'hide':'reveal',at:inv.now()};TLs?.hidden(ctx.token,on);R.veil=on?'anim':'none';inv.wake(R);};
  let c1={ph:{}},c2={ph:{},endedAt:null};
  try{classic(true);c1=await follow(2700,s=>s.phase==='held');classic(false);c2=await follow(2700,s=>s.phase==='solid');}
  finally{if(R){if(R.src==='spell'&&R.look==='classic')classic(false);try{inv.read(R,false);}catch{}}}
  row.push(`Classic drain ${c1.ph.drain?'yes':'NO'} held ${c1.ph.held?'yes':'NO'} filters ${Math.max(0,...Object.values(c1.ph).map(x=>x[1]))} reveal ${c2.endedAt!=null?f1(c2.endedAt/1000)+'s':'NO'}`);
  if(!c1.ph.drain||c2.endedAt==null)bad.push('the classic drain');
  box.phase='';const boxR=box.stop();res.lines.push(boxR.text);for(const l of boxR.lines??[])res.lines.push(l);if(diagLate??diag)for(const l of (diagLate??diag).split('\n'))res.lines.push(l);for(const b of boxR.bad)bad.push(`box · ${b}`);
  // (test.7) what her owner or a GM sees of her while hidden: each choice, measured on what is drawn
  ctx.check();const ov=await ownerViews(ctx,res,H,inv,st,follow,bad);
  const frames=rec.end(),cost=T.read();
  res.lines.push(`looks: ${row.join(' · ')}`);
  res.lines.push(`cost ${f3(cost.perFrame)} ms/frame over the part (top ${cost.top?.[0]??'-'}, worst call ${f2(cost.max)} ms) · flag writes ${inv.stats.flagWrites-fw0}${inv.stats.errors?` · FRAME ERRORS ${inv.stats.errors} (last: ${String(inv.lastError??'').split('\n').slice(0,2).join(' | ').slice(0,220)})`:''}`);
  if(bad.length)H.verdict(res,'FAIL',`invisibility: ${bad.join('; ')}`);else H.verdict(res,'PASS',`the Fade sweeps, holds without a filter and comes back; every look and direction plays${boxR.skip?'':'; nothing is drawn outside her'}`);
  if(seeOthers)H.verdict(res,seeOthers.level,seeOthers.text);
  // (a cloak hands her wings to its filter and back by design: moves only)
  H.popVerdicts(res,H.findPops(frames,ctx.grid,{alphaKinds:false}),{name:' (moves)',exclude:e=>e.key==='token'});
}
/** (11.0.0-test.7) Faint, Gone and Threads in turn: a Fade (her skin's look) for each, held for a moment, measured on
 * what is drawn (the stage tree: each piece's drawn alpha and painted share; the screen against a frame without her
 * where WebGL can be read), then back. The choice is put back exactly as it was (this browser's v11 setting). */
async function ownerViews(ctx,res,H,inv,st,follow,bad){
  const doc=ctx.doc,api=ctx.api;let raw0;try{raw0=game.settings.get(ID,CLIENT_KEY);}catch{res.lines.push('owner view: skipped (no v11 client setting)');return null;}
  const json0=JSON.stringify(raw0??{}),mine=ownerViewOf(choice('invisLooks.ownerView',doc));
  res.restore(async()=>{try{if(JSON.stringify(game.settings.get(ID,CLIENT_KEY)??{})!==json0)await game.settings.set(ID,CLIENT_KEY,JSON.parse(json0));}catch{}});
  if(!(doc.isOwner||game.user?.isGM)){res.lines.push('owner view: skipped (you are not her owner or a GM)');return null;}
  await H.waitUntil(()=>st().phase==='solid'&&!st().filters,3000);
  const solid=drawnNow(ctx),scr=new ScreenPresence(ctx);await scr.start();
  const rows=[],out={};
  for(const v of OWNER_VIEWS){
    ctx.check();ctx.progress(`V11 invisibility: what you see of her while hidden · ${v}…`);
    try{await writeV11('invisLooks.ownerView',v,null);}catch(e){res.lines.push(`owner view ${v}: could not be set (${e.message})`);continue;}
    await H.sleep(120);
    const g0=inv.stats.ghostPaints,trace=[];let last=null;
    await api.v11.fade(true,{token:ctx.token});
    // the screen through the sweep, every few frames (the hand-over at its end must not step)
    const on=await follow(sweepMs(ctx)+700,s=>s.phase==='held');
    if(scr.ok)for(let k=0;k<3;k++){const sh=await scr.share();if(sh)trace.push(sh.rest);}
    await H.sleep(500);
    const now=drawnNow(ctx),sh=scr.ok?await scr.share():null,veilW=inv.alphaFor(ctx.token,'wings'),ghosts=inv.stats.ghostPaints-g0;
    const R=inv.recordOf(ctx.token),tokFilter=(ctx.token?.mesh?.filters??[]).some(isCloakFilter);
    const tokenGhost=now.tokenShare??(tokFilter?(R?.state?.s2?.[0]?TOKEN_GHOST:0):drawnAlpha(ctx.token?.mesh));
    const wingShare=solid.by.wing>0?now.by.wing/solid.by.wing:null,bitShare=solid.by.bit>0?now.by.bit/solid.by.bit:null,shadowShare=solid.by.shadow>0?now.by.shadow/solid.by.shadow:null;
    // the strongest drawn wing layer against what the veil asks (her solid strength × the veil)
    const wantW=solid.max.wing*veilW,gotW=now.max.wing;
    const o=out[v]={held:st().phase==='held',ghosts,wingShare,bitShare,shadowShare,tokenGhost,wingMax:gotW,wantW,screen:sh,filters:now.filtered};
    const inkShare=solid.ink>0?now.ink/solid.ink:null;
    rows.push(`${v}${v===mine?' (yours)':''}: ${o.held?'held':'NOT held'} · drawn wings ${f2(wingShare)} (strongest layer ${f2(gotW)}, the veil asks ${f2(wantW)}; painted ${f2(inkShare)}) bits ${f2(bitShare)} shadow ${f2(shadowShare)} token ${f2(tokenGhost)}${now.tokenShare==null?' (no token layer)':''}`+
      `${sh?` · on screen: wings ${f2(sh.rest)} token ${f2(sh.token)}`:''} · thread repaints ${ghosts}${now.filtered?` · ${now.filtered} cloak filter(s) left`:''}`);
    const T=sh?.token??tokenGhost,Wd=sh?.rest??wingShare;
    if(!o.held)bad.push(`owner view ${v}: she never became held`);
    if(Math.abs(gotW-wantW)>.08)bad.push(`owner view ${v}: her drawn wings are at ${f2(gotW)}, the veil asks ${f2(wantW)} (the veil does not reach the wings on screen)`);
    if(v!=='threads'&&ghosts>0)bad.push(`owner view ${v}: the thread repaint ran (${ghosts})`);
    if(v==='faint'&&Wd!=null&&T!=null&&Wd>Math.max(.03,1.5*T))bad.push(`Faint: her wings' ghost ${f2(Wd)} is over 1.5× her token's ${f2(T)}`);
    if(v==='faint'&&bitShare!=null&&T!=null&&bitShare>Math.max(.03,1.5*T))bad.push(`Faint: her bits' ghost ${f2(bitShare)} is over 1.5× her token's ${f2(T)}`);
    if(v==='gone'&&((wingShare??0)>.02||(bitShare??0)>.02||(shadowShare??0)>.02||tokenGhost>.02||(sh&&(sh.rest>.04||sh.token>.04))))bad.push(`Gone: something of her still drawn (wings ${f2(wingShare)} bits ${f2(bitShare)} token ${f2(tokenGhost)}${sh?` · screen ${f2(sh.rest)}/${f2(sh.token)}`:''})`);
    if(v==='faint'&&trace.length){const end=trace.at(-1),step=Math.max(...trace.map(x=>Math.abs(x-end)));if(step>.15)bad.push(`Faint: her wings' ghost steps ${f2(step)} where the sweep hands over`);}
    await api.v11.fade(false,{token:ctx.token});await follow(sweepMs(ctx)+700,s=>s.phase==='solid');
    await H.waitUntil(()=>st().phase==='solid'&&!st().filters,2000);
  }
  // put the choice back exactly (and say so)
  try{if(JSON.stringify(game.settings.get(ID,CLIENT_KEY)??{})!==json0)await game.settings.set(ID,CLIENT_KEY,JSON.parse(json0));}catch{}
  const back=(()=>{try{return JSON.stringify(game.settings.get(ID,CLIENT_KEY)??{})===json0;}catch{return false;}})();
  res.lines.push(`owner view (solid: drawn wings ${f2(solid.by.wing)} bits ${f2(solid.by.bit)} token ${f2(solid.tokenShare??drawnAlpha(ctx.token?.mesh))}; ${scr.ok?'the screen read against a frame without her':`screen not read: ${scr.note}`}) · Faint target ${f2(TOKEN_GHOST)} (her token's measured owner ghost)`);
  for(const r of rows)res.lines.push(`  ${r}`);
  res.lines.push(`owner view put back: ${back?mine:'NOT EXACT'}`);if(!back)bad.push('the owner view was not put back exactly');
  return out;
}
/** While she is held: what a player who does not own her would see, by the runtime's own rules for that view. */
function visibilityFor(ctx,res,H,inv){
  const s=inv.status(ctx.token);if(s?.phase!=='held'){res.lines.push(`others: not measured (she is ${s?.phase})`);return {level:'CHECK',text:'what others see was not measured (she was not held)'};}
  const kinds=['wings','bits','shadow','fx'],other=Object.fromEntries(kinds.map(k=>[k,inv.alphaFor(ctx.token,k,'other')])),own=Object.fromEntries(kinds.map(k=>[k,inv.alphaFor(ctx.token,k)]));   // (test.7: this client's own view, as its owner-view choice makes it)
  const drainO=inv.drainFor(ctx.token,game.time?.serverTime??Date.now(),'other');
  // her portrait for that player: the token layer's hidden look without the ghost
  let por=null;const L=ctx.manager?.v11?.tokenLayers?.layerOf(ctx.token);
  if(L&&L.parts?.hidden){const look=createLook(),I={...L.I,hidden:{mode:'hide',q:5,ghost:false},emote:null,hit:null,give:null,healed:null};try{sampleTokenLayer(I,L.parts,look,L.variant);por={portrait:look.mask[0]===1?look.mask[3]*(1-look.mask[1]):look.mask[3],ghost:look.mask[2],frame:look.frm[0],outline:look.frm[2]};}catch{}}
  // a flicker for that player (only with the GM's "Others glimpse the flicker")
  const glimpse=partOn('invisFlicker','invisFlickerOthers'),flickO=flickerSolid('other',flickerAt(.33,1),glimpse);
  const fxOther=veilAlpha('other',1,'fx');
  const seen=Object.entries(other).filter(([,a])=>a>.01).map(([k,a])=>`${k} ${f2(a)}`);
  if(drainO&&drainO.ghost>0)seen.push(`wing ghost ${drainO.ghost}`);
  if(por&&(por.portrait>.02||por.ghost>.02||por.frame>.02||por.outline>.02))seen.push(`portrait ${f2(Math.max(por.portrait,por.ghost))} frame ${f2(Math.max(por.frame,por.outline))}`);
  if(flickO>.01)seen.push(`a flicker ${f2(flickO)}${glimpse?' (Others glimpse is on)':''}`);
  if(fxOther>.01)seen.push(`effects ${f2(fxOther)}`);
  res.lines.push(`held, a player who does not own her: wings ${f2(other.wings)} bits ${f2(other.bits)} shadow ${f2(other.shadow)} effects ${f2(other.fx)} ghost ${drainO?.ghost??'-'} portrait ${por?f2(Math.max(por.portrait,por.ghost)):'-'} frame ${por?f2(por.frame):'-'} flicker ${f2(flickO)} · you (${s.view}) keep wings ${f2(own.wings)} bits ${f2(own.bits)} effects ${f2(own.fx)}`);
  return seen.length?{level:glimpse&&seen.length===1&&flickO>.01?'CHECK':'FAIL',text:`others would see: ${seen.join(', ')}`}:{level:'PASS',text:'others would see: nothing (her wings, bits, shadow, portrait, effects and flicker all at 0)'};
}

/* ================================================================ 5. HEALING & BITS */
async function v11heal(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const HR=V.heal,doc=ctx.doc;
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1200});
  if(!(H.call.bitState(ctx)?.allocations??[]).some(b=>b.location==='home')){await H.call.bitsOn(ctx,true);res.restore(async()=>{await H.call.bitsOn(ctx,false);await H.sleep(600);});await H.sleep(1400);}
  const r=HR.recordOf(ctx.token);if(!r){H.verdict(res,'FAIL','the heal runtime keeps no record for her');return;}
  if(r.R.moments.length){res.skipped='a heal moment is already playing on her';return;}
  const ally=nearestAlly(ctx),A=ally?.token;
  res.lines.push(`ally: ${A?`${A.document?.name??A.id} ${f1(ally.sq)} sq ${ally.friendly?'(friendly)':'(not friendly)'}`:'none on the scene (the ally watch is skipped)'}`);
  const T=new V11Timer();res.restore(()=>T.restore());
  // what each moment hands the wing painter and the flight feel
  let ops=new Set();T.tap(HR,'wingVisual',out=>{for(const o of out?.v11heal?.ops??[])ops.add(o.k);});
  T.wrap('heal',HR,['wingVisual','feel','feelInput','busy','tick','frameFx'],TICK_PRIO.heal).start();
  res.restore(()=>{const R=r.R;R.moments.length=0;r.grabbed=false;R.grabbedAt=null;try{r.readActor();}catch{}});
  const g0=r.grabbed,ga0=r.R.grabbedAt;
  const rec=ctx.recorder;rec.begin();
  // (a bit the heal overlay redraws on top hides its own mesh by design: a hand-off, not a pop)
  const onTop=[],tk=globalThis.canvas?.app?.ticker,topTick=()=>{try{if([0,1,2,3].some(i=>bitOnTop(r.R,i)))onTop.push(H.now()-rec.t0);}catch{}};
  try{tk?.add(topTick,null,-43);}catch{}res.restore(()=>{try{tk?.remove(topTick,null);}catch{}});
  // her bits at rest (and how much they wander on their own)
  let home=bitOffsets(ctx),wander=0;await watch(H,500,()=>{wander=Math.max(wander,bitShift(home,bitOffsets(ctx),ctx.grid));});
  const rows=[],never=[];
  /** Fire one moment and watch it: overlay ink, the wing ops, the bits. */
  const moment=async(name,feat,fire,{ms=1400,kinds=[],partOk=true}={})=>{
    ctx.check();ctx.progress(`V11 healing: ${name}…`);
    if(feat&&!isOn(feat,doc)||!partOk){rows.push(`${name} off`);return;}
    ops=new Set();rec.mark(name);const ink0=overlayInk(),b0=bitOffsets(ctx);let ink=0,shift=0,frame=0;const n0=HR.stats.moments;
    try{await fire();}catch(e){rows.push(`${name} ERROR ${String(e?.message??e).slice(0,40)}`);never.push(name);return;}
    const L=ctx.manager?.v11?.tokenLayers?.layerOf(ctx.token);
    await watch(H,ms,()=>{ink=Math.max(ink,overlayInk()-ink0);shift=Math.max(shift,bitShift(b0,bitOffsets(ctx),ctx.grid));if(L)frame=Math.max(frame,(L.shown?.n?.rim??0)+(L.shown?.n?.bead??0));});
    const wing=kinds.filter(k=>ops.has(k)),added=HR.stats.moments-n0;
    const drew=ink>.5||wing.length>0||shift>wander+.06;
    rows.push(`${name} ${drew?'':'NONE '}${ink>.5?`ink ${f0(ink)}`:''}${wing.length?` wing ${wing.join('+')}`:''}${shift>wander+.06?` bits ${f2(shift)}sq`:''}`.replace(/\s+/g,' ').trim());
    if(!added)rows[rows.length-1]+=' (no moment)';
    if(!drew)never.push(name);
  };
  const P=r.parts;
  await moment('hero point','heroSpent',()=>HR.add(r,{kind:'hero',at:clock()}),{kinds:['hero'],ms:2300});
  for(const trad of ['arcane','divine','occult','primal'])await moment(trad,'spellTraditions',()=>HR.noteMessage(fromHer(ctx,{casting:{tradition:trad,actions:2},origin:{type:'spell',rollOptions:[]}})),{kinds:[trad],ms:1100,partOk:!!P['sp'+trad[0].toUpperCase()+trad.slice(1)]});
  // grapple escape: only with a synthetic grabbed state (her actor is not touched)
  if(isOn('grappleEscape',doc)){r.grabbed=true;r.R.grabbedAt=clock();
    try{await moment('escape ok','grappleEscape',()=>HR.noteMessage(fromHer(ctx,{context:{outcome:'success',options:['action:escape']}})),{kinds:['strain'],ms:2200});
      await moment('escape fail','grappleEscape',()=>HR.noteMessage(fromHer(ctx,{context:{outcome:'failure',options:['action:escape']}})),{kinds:['strain'],ms:2600,partOk:P.grFail!==false});}
    finally{r.grabbed=g0;r.R.grabbedAt=ga0;try{r.readActor();}catch{}}}
  else rows.push('escape off');
  await moment('nat 20','dieMoods',()=>HR.noteMessage(fromHer(ctx,{context:{type:'skill-check'}},{rolls:d20(20)})),{ms:1800,partOk:!!P.dieNat20});
  await moment('nat 1','dieMoods',()=>HR.noteMessage(fromHer(ctx,{context:{type:'skill-check'}},{rolls:d20(1)})),{ms:2600,partOk:!!P.dieNat1});
  if(A&&ally.friendly)await moment('ally watch','allyWatch',()=>HR.add(r,{kind:'watch',at:clock(),ally:A.id,end:null}),{ms:1300});
  for(const m of r.R.moments)if(m.kind==='watch'&&m.end==null)m.end=clock();
  // Last light (a synthetic airborne knock-out, without its 30 s vigil)
  let last='-';
  {const f=ctx.manager?.states?.get?.(ctx.token)?.feelState;
    if(isOn('lastLight',doc)&&P.lastCatch&&(f?.alt??0)>1.2){ctx.progress('V11 healing: Last light…');
      rec.mark('Last light');const alt0=f.alt;let low=alt0;HR.add(r,{kind:'last',at:clock(),alt:alt0,vigil:false});
      await watch(H,11600,()=>{low=Math.min(low,ctx.manager?.states?.get?.(ctx.token)?.feelState?.alt??low);});
      const up=await H.waitUntil(()=>(ctx.manager?.states?.get?.(ctx.token)?.feelState?.alt??0)>alt0*.6,4000,()=>H.sleep(100));
      last=`Last light: lowered ${f1(alt0)} → ${f1(low)} ft, flying again ${up?'yes':'NO'}`;if(!(low<alt0*.5))never.push('Last light');if(!up)never.push('Last light (did not rise again)');}
    else last=`Last light ${isOn('lastLight',doc)?'skipped (not high enough)':'off'}`;}
  // idle: everything ends, the overlay gives its pixels back, the runtime costs nothing
  await H.waitUntil(()=>!HR.busy(ctx.token)&&!HR.ticking,6000,()=>H.sleep(100));
  const run=T.read();T.reset();await watch(H,900,()=>{});const idle=T.read();
  const frames=rec.end();
  res.lines.push(`moments: ${rows.join(' · ')}`);
  res.lines.push(`${last} · cost ${f3(run.perFrame)} ms/frame while playing (worst call ${f2(run.max)} ms) · idle ${f3(idle.perFrame)} ms/frame · overlay ${HR.ticking?'still ticking':'released'}`);
  if(never.length)H.verdict(res,'FAIL',`never drew: ${never.join(', ')}`);else H.verdict(res,'PASS','every moment and bit job draws');
  if(idle.perFrame>.02||HR.ticking)H.verdict(res,'FAIL',`the heal runtime did not return to idle (${f3(idle.perFrame)} ms a frame${HR.ticking?', overlay still ticking':''})`);
  try{tk?.remove(topTick,null);}catch{}
  const near=t=>{let lo=0,hi=onTop.length;while(lo<hi){const m=(lo+hi)>>1;if(onTop[m]<t-120)lo=m+1;else hi=m;}return lo<onTop.length&&onTop[lo]<=t+120;};
  const pops=H.findPops(frames,ctx.grid,{skip:(t,key)=>key.startsWith('bit:')&&near(t)});H.popVerdicts(res,pops);
  if(onTop.length)res.lines.push(`bits redrawn on the heal overlay for ${f1(onTop.length/Math.max(1,frames.length)*100)}% of frames (their meshes hide meanwhile by design; not counted as pops)`);
  if(pops.events.some(e=>e.kind!=='gap'))res.lines.push(`pops by moment: ${popsByMark(pops.events,rec.marks)}`);
}

/* ================================================================ 6. EMOTES */
async function v11emotes(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const E=V.emote,doc=ctx.doc,api=ctx.api;
  if(!isOn('emotes',doc)){res.skipped='Emotes are off for her';return;}
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1200});
  if(E.busy(ctx.token)){res.skipped='an emote is already playing';return;}
  const T=new V11Timer();res.restore(()=>T.restore());T.wrap('emote',E,['feel','wing','weights','flight','visual','draw','busy']).start();
  res.restore(async()=>{const rec=E.recOf(ctx.token);if(rec){E.endFor(ctx.token,'release');await H.waitUntil(()=>!E.busy(ctx.token),2500,()=>H.sleep(100));}});
  const home={x:doc.x,y:doc.y};res.restore(async()=>{if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(200);}});
  const rec=ctx.recorder;rec.begin();
  const play=async(id,opts={})=>{const t=Date.now();const out=await api.v11.emote(id,{token:ctx.token,...opts});const f=doc.getFlag?.(ID,EMOTE_FLAG),R=E.recOf(ctx.token),srv=Number(game.time?.serverTime)||Date.now();return {out,f,R,lag:srv-(f?.started??0),dt:Date.now()-t};};
  const row=[],bad=[];
  for(const id of WM.EMOTE_IDS){
    ctx.check();ctx.progress(`V11 emotes: ${id}…`);
    if(!partOn('emotes',WM.emotePart(id),doc)){row.push(`${id} off`);continue;}
    rec.mark(id);const s0=E.stats.samples,w0=E.stats.wing;let p;try{p=await play(id);}catch(e){row.push(`${id} ERROR`);bad.push(`${id}: ${String(e?.message??e).slice(0,50)}`);continue;}
    await H.sleep(1150);const R=E.recOf(ctx.token),tau0=0;
    const ok=!!p.f&&p.f.key===p.R?.flag?.key&&p.f.id===id&&Math.abs(p.lag)<3000,plays=!!R&&R.flag?.key===p.f?.key&&R.live&&R.tau>tau0+.5&&E.stats.samples>s0;
    row.push(`${id} ${ok?'':'FLAG? '}${plays?f1(R.tau)+'s':'NOT PLAYING'}${E.stats.wing>w0?'':' (no wing)'}`);
    if(!ok)bad.push(`${id}: flag not synced (lag ${f0(p.lag)} ms)`);if(!plays)bad.push(`${id} did not play`);
  }
  // the last one plays to its end and is let go
  const lastId=WM.EMOTE_IDS.filter(id=>partOn('emotes',WM.emotePart(id),doc)).at(-1);
  const ended=lastId?await H.waitUntil(()=>!E.busy(ctx.token),(emoteDuration(WM.emoteVariant(lastId,choice('laughStyle',doc)))+2)*1000,()=>H.sleep(100)):true;
  res.lines.push(`played (τ after 1.15 s): ${row.join(' · ')} · the last ends ${ended?'yes':'NO'}`);
  if(!ended)bad.push('the last emote never ended');
  // precedence: a move releases it, a hit makes it yield
  ctx.progress('V11 emotes: what interrupts them…');let prec=[];
  if(partOn('emotes','emoteBow',doc)){
    const dir=H.freeDirection(ctx,1);
    if(dir){rec.mark('move');await play('bow');await H.sleep(500);await doc.update({x:dir.to.x,y:dir.to.y});const why=await H.waitUntil(()=>E.recOf(ctx.token)?.end?.reason,1500,()=>H.sleep(30));const reason=E.recOf(ctx.token)?.end?.reason??(E.busy(ctx.token)?'none':'gone');
      await doc.update({x:home.x,y:home.y});await H.waitUntil(()=>!E.busy(ctx.token),2500,()=>H.sleep(100));prec.push(`a move: ${why?reason:'NOT interrupted'}`);if(reason!=='release')bad.push(`a move did not release the emote (${reason})`);await H.settle(ctx,{timeout:1500});}
    else prec.push('a move: skipped (no free square)');
    if(H.hpPath(doc.actor)&&doc.actor.isOwner){rec.mark('hit');await play('bow');await H.sleep(500);
      const o=await H.withHp(ctx,async(a,hp)=>{await a.update({'system.attributes.hp.value':Math.max(1,hp.value-1)});await H.waitUntil(()=>E.recOf(ctx.token)?.end,1200,()=>H.sleep(30));return E.recOf(ctx.token)?.end?.reason??(E.busy(ctx.token)?'none':'gone');},res);
      prec.push(`a hit (HP −1, restored): ${o?.value??o?.skipped}`);if(o?.value!=='yield'&&o?.value!=='stop')bad.push(`a hit did not interrupt the emote (${o?.value})`);
      await H.waitUntil(()=>!E.busy(ctx.token),2500,()=>H.sleep(100));}
  }
  // Comfort: the side it picks (her ally), then each side by hand
  let comfort='Comfort off';
  if(partOn('emotes','emoteComfort',doc)){const pick=api.v11.emotes?.comfortSide?.(ctx.token)??{side:1};const sides=[];
    for(const side of [1,-1]){rec.mark(`comfort ${side>0?'right':'left'}`);await play('comfort',{side,ally:pick.ally});await H.sleep(700);const R=E.recOf(ctx.token);sides.push(`${side>0?'right':'left'} ${R?.flag?.side===side&&Math.sign(R.F?.side??1)===Math.sign(side)?'ok':'WRONG'}`);if(!(R?.flag?.side===side))bad.push(`Comfort on the ${side>0?'right':'left'} side`);}
    E.endFor(ctx.token,'release');await H.waitUntil(()=>!E.busy(ctx.token),2500,()=>H.sleep(100));
    const ally=pick.ally?globalThis.canvas?.tokens?.get?.(pick.ally):null;
    comfort=`Comfort picks ${pick.side>0?'right':'left'}${ally?` (${ally.document?.name??ally.id} beside her)`:' (nobody beside her)'} · ${sides.join(' · ')}`;}
  const frames=rec.end(),cost=T.read();
  res.lines.push(`precedence: ${prec.join(' · ')||'-'} · ${comfort}`);
  res.lines.push(`cost ${f3(cost.perFrame)} ms/frame over the part (worst call ${f2(cost.max)} ms) · the emote flag ${doc.getFlag?.(ID,EMOTE_FLAG)?'is left for RESTORE to clear':'none'}`);
  if(bad.length)H.verdict(res,'FAIL',`emotes: ${bad.slice(0,4).join('; ')}`);else H.verdict(res,'PASS','all ten play in sync with the server clock; a move and a hit interrupt; Comfort takes either side');
  const pops=H.findPops(frames,ctx.grid);H.popVerdicts(res,pops);
  if(pops.events.some(e=>e.kind!=='gap'))res.lines.push(`pops by moment: ${popsByMark(pops.events,rec.marks)}`);
}

/* ================================================================ 7. WHEEL */
async function v11wheel(ctx,res,H){
  const qw=ctx.api?.quickWheel;if(!qw?.open||!qw.instance){res.skipped='no quick wheel in this build';return;}
  if(!isOn('nestedWheel',null)){res.skipped='the nested wheel is off (Settings › Emotes & wheel): the flat wheel is not tested here';return;}
  if(qw.instance()){res.skipped='the wheel is open';return;}
  const cfg0=structuredClone(H.setting('quickWheel')??null),ring0=structuredClone(game.user?.getFlag?.(ID,WM.MACRO_FLAG)??null);
  res.restore(()=>{try{qw.close();}catch{}});
  const tasks=[],steps=[['open',performance.now()]],at=t=>{let s='open';for(const [k,v] of steps)if(v<=t)s=k;return s;};let obs=null;try{if(PerformanceObserver.supportedEntryTypes?.includes('longtask')){obs=new PerformanceObserver(l=>{for(const e of l.getEntries()){tasks.push(e.duration);(tasks.where??=[]).push(`${f0(e.duration)} ms at ${at(e.startTime)}`);}});obs.observe({type:'longtask'});}}catch{obs=null;}
  const t0=H.now();const opened=qw.open();const w=qw.instance();const openMs=H.now()-t0;
  if(!opened||!w){obs?.disconnect();H.verdict(res,'FAIL','the quick wheel did not open (pin her or select her token)');return;}
  const shown=await H.waitUntil(()=>w.root?.classList.contains('open'),1500);const shownMs=H.now()-t0;
  const main=w.mainItems??[],cats=main.filter(i=>i.kind==='cat').map(i=>i.cat),shorts=main.filter(i=>i.kind==='short').length;
  const go=async cat=>{steps.push([cat,performance.now()]);const t=H.now();w.enter(cat);await H.nextFrame();await H.nextFrame();await H.sleep(120);return H.now()-t;};
  const back=async()=>{w.back();await H.sleep(150);};
  const times={},bad=[];let her='-',emo='-',mac='-',light='-',lane='-';
  const size=WM.arcSize(choice('nestedWheel.arcSize',null));
  if(w.doors){
    // (test.16) the doors layout: Her, Actions and Bits are each one ring of her own picks, with More… and a context lane
    const rows=[];let laneN=0,flyM=0,groundM=0;
    for(const d of Object.keys(WM.DOORS)){if(!cats.includes(d)){bad.push(`no ${WM.DOORS[d].name} door`);continue;}
      times[d]=await go(d);const items=w.subItems??[],leaves=items.filter(i=>i.kind==='leaf'&&i.ring===d),named=leaves.filter(i=>i.el?.querySelector('.lab')?.textContent).length;
      rows.push(`${d} ${leaves.length}`);laneN+=items.filter(i=>i.kind==='lane').length;
      if(!leaves.length)bad.push(`the ${WM.DOORS[d].name} ring is empty`);if(leaves.length>WM.RING_SLOTS)bad.push(`the ${WM.DOORS[d].name} ring shows more than ${WM.RING_SLOTS}`);
      if(named!==leaves.length)bad.push(`${leaves.length-named} gem(s) on the ${WM.DOORS[d].name} ring have no name`);
      if(!items.some(i=>i.kind==='more'))bad.push(`no More… on the ${WM.DOORS[d].name} ring`);
      flyM+=WM.arrangeRing(d,w.cfg.rings[d],{...w.ctx,air:true}).lane.length;groundM+=WM.arrangeRing(d,w.cfg.rings[d],{...w.ctx,air:false}).lane.length;await back();}
    const emoteGem=(w.cfg.rings?.her??[]).filter(s=>s?.action==='emote').length;
    her=`doors layout · rings ${rows.join(' ')} (of ${WM.RING_SLOTS}) · Emote gems on Her ${emoteGem}`;
    lane=`context lane ${w.ctx?.air?'flying':'grounded'} ${laneN} · model flying ${flyM} grounded ${groundM}`;
  }else if(cats.includes('her')){times.her=await go('her');const items=w.subItems??[],arcs=Object.keys(WM.ARCS).map(id=>[id,items.filter(i=>i.arc===id&&i.kind==='leaf').length]);
    her=`Her arcs ${arcs.map(([id,n])=>`${id} ${n}`).join(' ')} (of ${size})`;if(arcs.some(([,n])=>n>size))bad.push(`an arc shows more than ${size}`);if(!arcs.some(([,n])=>n>0))bad.push('Her arcs are empty');
    const fly=items.filter(i=>i.kind==='lane').length,ground=Object.keys(WM.ARCS).reduce((n,id)=>n+WM.arrangeArc(id,w.cfg.arcs[id],{...w.ctx,air:false},size).lane.length,0),flyM=Object.keys(WM.ARCS).reduce((n,id)=>n+WM.arrangeArc(id,w.cfg.arcs[id],{...w.ctx,air:true},size).lane.length,0);
    lane=`context lane ${w.ctx?.air?'flying':'grounded'} ${fly} · model flying ${flyM} grounded ${ground}`;await back();}
  else bad.push('no Her ring');
  if(cats.includes('emotes')){times.emotes=await go('emotes');const n=(w.subItems??[]).length;emo=`Emotes ${n}`;if(n!==WM.EMOTE_IDS.length)bad.push(`the Emotes ring has ${n}`);await back();}
  if(cats.includes('macros')){times.macros=await go('macros');const n=w.root?.querySelectorAll('.ffm-slot').length??0;mac=`Macros ${n} slot(s)`;await back();}
  if(cats.includes('light')){times.light=await go('light');const n=(w.subItems??[]).length;light=`Light ${n}`;if(n!==WM.LIGHT_ITEMS.length)bad.push(`the Light ring has ${n}`);await back();}
  const fade=w.info({action:'fade'}),lastEl=w.root?.querySelector('.ffn-last'),last=w.cfg?.last?`${w.cfg.last.action}${w.cfg.last.value?':'+w.cfg.last.value:''} ${lastEl?.classList.contains('has')?'shown':'NOT shown'}`:'none yet';
  if(w.cfg?.last&&!lastEl?.classList.contains('has'))bad.push('the last-used gem is not shown');
  if(fade.reason)bad.push(`Fade is disabled (${fade.reason})`);
  steps.push(['close',performance.now()]);const tc=H.now(),tcs=performance.now();qw.close();const closeCall=performance.now()-tcs;await H.sleep(500);const closeMs=H.now()-tc;obs?.disconnect();
  const gone=!document.querySelector('.ffn')&&!qw.instance();
  const cfgSame=sameJ(cfg0,H.setting('quickWheel')??null),ringSame=sameJ(ring0,game.user?.getFlag?.(ID,WM.MACRO_FLAG)??null);
  res.lines.push(`open ${f0(openMs)} ms, shown ${f0(shownMs)} ms · main: ${cats.join(', ')} + ${shorts} shortcut(s) · ${her} · ${lane}`);
  res.lines.push(`${emo} · ${mac} · ${light} · Fade ${fade.reason?`disabled: ${fade.reason}`:'enabled'} · last used ${last}`);
  res.lines.push(`rings open (ms): ${Object.entries(times).map(([k,v])=>`${k} ${f0(v)}`).join(' · ')} · close ${f0(closeMs)} (the close call itself ${f1(closeCall)} ms; the wheel fades as one layer, is hidden, then removed when idle) · long tasks ${obs?`${tasks.length}${tasks.length?` (${tasks.where.join(', ')})`:''}`:'n/a'} · closed ${gone?'yes':'NO'} · wheel config ${cfgSame?'untouched':'CHANGED'} · macro ring ${ringSame?'untouched':'CHANGED'}`);
  if(!gone)bad.push('the wheel did not close');if(!cfgSame||!ringSame)bad.push('the wheel config or macro ring changed');
  if(bad.length)H.verdict(res,'FAIL',`wheel: ${bad.join('; ')}`);else H.verdict(res,'PASS','the nested wheel opens every ring and closes untouched');
  const slow=Object.entries(times).filter(([,v])=>v>250);if(shownMs>500||slow.length||tasks.some(t=>t>100))H.verdict(res,'CHECK',`the wheel is slow: shown ${f0(shownMs)} ms${slow.length?`, ${slow.map(([k,v])=>`${k} ${f0(v)} ms`).join(', ')}`:''}`);
  if(!fade.reason)await wheelFade(ctx,res,H,qw,cfg0);
}
/** (11.0.0-test.6) Fade through the wheel itself, as she uses it: on from Her › Wings › More…, off from the
 * last-used gem, on as a shortcut gem fires it, off from More… again. The wheel acts on the pinned character;
 * each time her cloak must sweep (filters on her meshes), settle held or solid, and the screen round her and
 * her wings must show no black. The wheel's config is not written (its save is held for the run). */
async function wheelFade(ctx,res,H,qw,cfg0){
  const inv=runtimesOf(ctx)?.invisibility,api=ctx.api;if(!inv||!api?.v11?.fade){res.lines.push('Fade through the wheel: skipped (no invisibility runtime)');return;}
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1200});
  const st=()=>inv.status(ctx.token)??{};
  if(st().phase!=='solid'){res.lines.push(`Fade through the wheel: skipped (she is ${st().phase??'not tracked'})`);return;}
  res.restore(async()=>{if(st().flag?.fade||st().phase!=='solid'){try{await api.v11.fade(false,{token:ctx.token});}catch{}await H.waitUntil(()=>st().phase==='solid',6000,()=>H.sleep(100));}});
  const pinnedOk=qw.token?.()===ctx.token;
  const follow=async(ms,until)=>{const o={ph:{},endedAt:null,t0:H.now()};while(H.now()-o.t0<ms){await H.nextFrame();const s=st();(o.ph[s.phase]??=[0,0]);o.ph[s.phase][0]++;o.ph[s.phase][1]=Math.max(o.ph[s.phase][1],s.filters??0);if(o.endedAt==null&&until(s)){o.endedAt=H.now()-o.t0;break;}}return o;};
  const open=async()=>{qw.open();const w=qw.instance();if(!w)return null;w.save=()=>{};await H.waitUntil(()=>w.root?.classList.contains('open'),1500);await H.sleep(120);return w;};
  const shut=async w=>{if(w){delete w.save;}if(qw.instance())qw.close();await H.sleep(350);};
  const ways={
    more:async w=>{const door=w.doors?'actions':'her',grp=w.doors?'actions':'wings',nm=w.doors?'Actions':'Wings';w.enter(door);await H.sleep(380);const m=(w.subItems??[]).find(i=>i.kind==='more'&&i.group===grp);if(!m)return `no ${nm} › More…`;w.activate(m);await H.sleep(260);
      const chip=[...(w.root?.querySelectorAll('.ffn-chip')??[])].find(c=>c.dataset.key?.startsWith('fade:'));if(!chip)return `no Fade in ${nm} › More…`;chip.click();return null;},
    // (the wheel's save is held, so the last-used gem is set as the More… pick would have saved it)
    last:async w=>{if(!w.cfg)return 'no wheel config';w.cfg.last={action:'fade',value:null};try{w.paintLast?.();}catch{}w.fireLast();return null;},
    shortcut:async w=>{const it=(w.mainItems??[]).find(i=>i.kind==='short'&&i.slot?.action==='fade');if(it)w.activate(it);else w.fire({action:'fade',value:null},null);return null;}
  };
  const plan=[['more',true],['last',false],['shortcut',true],['more',false]],row=[],bad=[];
  for(const [way,on] of plan){
    ctx.check();ctx.progress(`V11 wheel: Fade ${on?'out':'in'} from ${way}…`);
    const scr=new ScreenWatch(ctx,H),scrW=new ScreenWatch(ctx,H,{wings:true});res.restore(()=>{scr.stop();scrW.stop();});
    if(on){await scr.start();await scrW.start();}
    const w=await open();if(!w){bad.push('the wheel did not open');break;}
    const s0=inv.stats.sweeps,why=await ways[way](w);
    if(why){await shut(w);bad.push(why);row.push(`${way} ${why}`);break;}
    const o=await follow(sweepMs(ctx)+1500,s=>s.phase===(on?'held':'solid')&&!s.filters);
    await shut(w);const a=scr.stop(),b=scrW.stop();
    // (12.0.0-beta.4) with the Classic drain as her cloak's look the Fade plays the drain, not a sweep
    const faded=!!st().flag?.fade,played=o.ph.sweep?inv.stats.sweeps>s0:!!o.ph.drain,ok=o.endedAt!=null&&played&&faded===on&&a.ok&&b.ok;
    row.push(`${on?'out':'in'} via ${way}: ${o.ph.sweep?`sweep ${o.ph.sweep[1]}f`:o.ph.drain?'classic drain':'NO sweep'} ${o.endedAt!=null?`${on?'held':'solid'} ${f1(o.endedAt/1000)}s`:'NOT settled'}${on?` · black ${a.skip?'n/a':f0(a.worst*100)+'%'}/${b.skip?'n/a':f0(b.worst*100)+'%'} wings`:''}`);
    if(!ok)bad.push(`Fade ${on?'out':'in'} via ${way}${!played?' (no sweep)':''}${o.endedAt==null?' (did not settle)':''}${faded!==on?' (flag wrong)':''}${!a.ok||!b.ok?' (black on screen)':''}`);
  }
  const cfgSame=sameJ(cfg0,H.setting('quickWheel')??null);if(!cfgSame)bad.push('the wheel config changed');
  res.lines.push(`Fade through the wheel (pinned ${pinnedOk?'her':'SOMEONE ELSE'}): ${row.join(' · ')}`);
  if(!pinnedOk)bad.push('the wheel acts on another token');
  if(bad.length)H.verdict(res,'FAIL',`Fade through the wheel: ${bad.join('; ')}`);else H.verdict(res,'PASS','Fade through the wheel (More…, the last-used gem, a shortcut) sweeps her and her wings with no black, and back');
}

/* ================================================================ 8. WORLD */
async function v11world(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const W=V.world,doc=ctx.doc;
  const on={fold:isOn('wallFold',doc),light:isOn('lightCatch',doc),shadow:isOn('wingShadowTokens',doc)};
  await H.ensureFlying(ctx);ctx.check();await H.settle(ctx,{timeout:1200});
  const prof=W.profile;W.profile=true;res.restore(()=>{W.profile=prof;});
  const T=new V11Timer();res.restore(()=>T.restore());T.wrap('world',W,['wingVisual','feel','shadowOnTokens']).start();
  const r=W.recordOf(ctx.token),g=ctx.grid,c=ctx.token.center,bad=[];
  // walls within 3 squares
  const buf=new Float64Array(4096);let walls=0;try{walls=Math.abs(W.query(c.x-3*g,c.y-3*g,c.x+3*g,c.y+3*g,buf));}catch{}
  let fold='Wall fold off';
  if(on.fold){
    if(!walls)fold='Wall fold: no walls within 3 squares (skipped)';
    else{
      let n=3,dir=null;for(;n>=1&&!dir;n--)dir=H.freeDirection(ctx,n);n++;
      if(!dir)fold=`Wall fold: ${walls} wall(s) near but no free path (skipped)`;
      else{const home={x:doc.x,y:doc.y};res.restore(async()=>{if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(200);}});
        const s0={...W.stats},rec=ctx.recorder;rec.begin();T.reset();let shows=0,peak=0,frames=0;
        const tick=()=>{frames++;const F=r?.fold;if(F?.shows){shows++;peak=Math.max(peak,F.left??0,F.right??0);}};
        const t0=H.now();const mv=H.moveLoop(ctx,dir,n,H.now()+5000);await Promise.all([mv,watch(H,5200,tick)]);const secs=(H.now()-t0)/1000;
        const fr=rec.end(),cost=T.read();const casts=(W.stats.casts-s0.casts)/secs,ms=(W.stats.foldMs-s0.foldMs)/Math.max(1,cost.frames),fs=H.frameStats(fr);
        fold=`Wall fold: ${walls} wall(s) near · ${n} sq ${dir.name} and back · folded ${shows}/${frames} frames (peak ${f2(peak)}) · ${f3(ms)} ms/frame · ${f1(casts)} casts/s · worst call ${f2(W.stats.maxMs)} ms · frames ${f1(fs.med)}/${f1(fs.p95)}/${f1(fs.max)} ms`;
        if(walls>8&&!shows)res.lines.push('  (no fold engaged: the walls near her may be outside her wing reach along this path)');
        if(ms>.5)H.verdict(res,'CHECK',`wall fold costs ${f2(ms)} ms a frame`);
        H.popVerdicts(res,H.findPops(fr,ctx.grid),{name:' along the wall path'});
        await H.settle(ctx,{timeout:1500});}
    }}
  res.lines.push(fold);
  // light catch: what lights she is near, and the shift it gives her
  let light='Light catch off';
  if(on.light){await H.sleep(300);const L=r?.light,near=L?.near?.length??0,vis=L?.visual,bins=vis?.bins?.filter(Boolean)??[];
    const col=bins[0]?.ink??bins[0]?.halo??bins[0]?.core??null;
    light=`Light catch: ${W.lightCount} light(s) on the scene, ${near} near her · ${bins.length?`tinted (${bins.length} band(s)${col?`, e.g. rgb ${[].concat(col).slice(0,3).map(x=>Math.round(x)).join(',')}`:''}${vis.flick?', flickering':''})`:'no colour shift'}`;}
  res.lines.push(light);
  // wing shadow on tokens
  let sh='Wing shadow on tokens off';
  if(on.shadow){const hits=r?.shadowCheck?.hits?.length??0,paints=W.stats.shadowPaints;sh=`Wing shadow on tokens: ${hits?`${hits} token(s) under her shadow, ${paints} paint(s) so far`:'no token under her shadow now'}`;}
  const cost=T.read();
  res.lines.push(`${sh} · world ${f3(cost.perFrame)} ms/frame`);
  if(!res.verdicts.some(v=>v.startsWith('FAIL')))H.verdict(res,'PASS',`world features ran without errors (${Object.entries(on).filter(([,v])=>v).map(([k])=>k).join(', ')||'all off'})`);
}

/* ================================================================ 9. EXTRAS */
const EXTRAS=['xTapestry','xPetals','xRecap'];
function extrasIdle(ctx){
  const V=runtimesOf(ctx),J=V?.journal,RC=V?.recapChat,ctrl=ctx.service?.hudController?.(),X=ctrl?.app?.extras??ctrl?.app?.host?.extras??null;
  return {journal:!!J?.active,journalHooks:J?.hooks?.length??0,journalTimer:J?.timer!=null&&J?.ops?.length>0,
    recapHook:!!RC?.hook,recapClass:!!document.body?.classList?.contains('ffx-recap-on'),hudHooks:X?.hooks?.length??0,tapestryTab:tabList().some(t=>t[0]==='tapestry')};
}
async function v11extras(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const doc=ctx.doc,gm=!!game.user?.isGM;
  const state=Object.fromEntries(EXTRAS.map(id=>[id,isOn(id,null)]));
  const I=extrasIdle(ctx);
  const work=[];if(!state.xTapestry&&!state.xPetals&&!state.xRecap){if(I.journal||I.journalHooks)work.push(`her journal records (${I.journalHooks} hooks)`);if(I.journalTimer)work.push('a journal timer');}
  if(!state.xRecap&&(I.recapHook||I.recapClass))work.push('the recap card hook');
  if(!state.xTapestry&&I.tapestryTab)work.push('the Tapestry tab');if(!state.xTapestry&&!state.xPetals&&I.hudHooks)work.push(`${I.hudHooks} HUD extras hooks`);
  res.lines.push(`on: ${EXTRAS.filter(k=>state[k]).join(', ')||'none'} · while off: journal ${I.journal?'RECORDING':'idle'} (${I.journalHooks} hooks) · recap hook ${I.recapHook?'ON':'none'} · HUD extras hooks ${I.hudHooks}`);
  if(work.length)H.verdict(res,'FAIL',`extras that are off still do work: ${work.join(', ')}`);else H.verdict(res,'PASS',`zero cost while off: no hooks, timers or tickers for the ${EXTRAS.filter(k=>!state[k]).length} that are off`);
  // each switched on for a moment (as it is kept: this browser, the world or her token), and off again
  const actor=doc.actor,j0=structuredClone(actor?.flags?.[ID]?.journal??null);
  const keep=[];res.restore(async()=>{for(const [k,v,d] of keep.reverse())try{await writeV11(k,v,d);}catch{}});
  const turn=async(id,on)=>{const scope=V11_KEYS.get(id).scope,d=scope==='token'?doc:null;if(scope==='gm'&&!gm)return false;const was=isOn(id,d);if(was===on)return true;keep.push([id,was,d]);await writeV11(id,on,d);await H.sleep(250);return true;};
  const ctrl=ctx.service?.hudController?.(),hudWas=!!(ctrl?.opened&&ctrl.app?.rendered),tab0=ctrl?.app?.tab??'home';
  res.restore(async()=>{if(!ctrl)return;const app=ctrl.app;try{if(app&&app.tab!==tab0)app.switchTab(tab0);}catch{}if(!hudWas&&ctrl.opened)await ctrl.close();});
  const root=()=>ctrl?.app?.element?.querySelector?.('.ks-host')?.shadowRoot??null;
  const hud=async(tab='home')=>{if(!ctrl)return null;if(!ctrl.opened)await ctrl.open();await H.waitUntil(()=>root()?.querySelector('.ks-root'),4000,()=>H.sleep(50));if(ctrl.app?.tab!==tab)ctrl.app.switchTab(tab);await H.sleep(500);return root();};
  const row=[];
  for(const id of EXTRAS){
    ctx.check();ctx.progress(`V11 extras: ${id.slice(1)}…`);
    if(state[id]){row.push(`${id.slice(1)} on already`);continue;}
    if(!(await turn(id,true))){row.push(`${id.slice(1)} skipped (the GM's)`);continue;}
    let r='?';
    try{
      if(id==='xTapestry'){const R=await hud('tapestry');r=R?.querySelector('[data-ks-tapestry] .ffx-tap-head, .ffx-tap-head')?'renders':ctrl?'NOT drawn':'no HUD';}
      else if(id==='xPetals'){const R=await hud('home');const g=()=>root()?.querySelector('g.ffx-whorl');await H.waitUntil(()=>g()?.dataset?.k,1500,()=>H.sleep(50));const G=g(),n=Number(G?.dataset?.n??0);
        r=R?G?.dataset?.k?(n?`renders (${n} petal${n===1?'':'s'})`:G.querySelector('[data-empty]')?'renders (empty: no milestone pinned yet)':'NOT drawn (whorl empty)'):G?'NOT drawn (whorl empty)':'no corner flower':'no HUD';}
      else if(id==='xRecap'){r=V.recapChat?.hook||document.body.classList.contains('ffx-recap-on')?'armed (no card posted)':'NOT armed';}
    }catch(e){r=`ERROR ${String(e?.message??e).slice(0,50)}`;}
    await turn(id,false);
    row.push(`${id.slice(1)} ${r}`);if(/NOT|ERROR/.test(r))H.verdict(res,'FAIL',`${id.slice(1)}: ${r}`);
  }
  if(ctrl&&ctrl.app&&ctrl.app.tab!==tab0)try{ctrl.app.switchTab(tab0);}catch{}
  if(!hudWas&&ctrl?.opened)await ctrl.close();
  await H.sleep(1500);
  // her journal: anything the Tapestry or the petals wrote goes back exactly
  const j1=actor?.flags?.[ID]?.journal??null;let jn='untouched';
  if(!sameJ(j0,j1)&&actor?.isOwner){try{await actor.update(j0==null?{[`flags.${ID}.-=journal`]:null}:{[`flags.${ID}.journal`]:j0});}catch{}jn=sameJ(j0,actor?.flags?.[ID]?.journal??null)?'written, put back':'written, NOT put back';}
  const I2=extrasIdle(ctx);const after=[];if(!state.xTapestry&&!state.xPetals&&!state.xRecap&&(I2.journal||I2.journalHooks))after.push('journal');if(!state.xRecap&&I2.recapHook)after.push('recap');
  res.lines.push(`switched on for a moment: ${row.join(' · ')} · her journal ${jn} · idle again ${after.length?'NO: '+after.join(', '):'yes'}`);
  if(after.length)H.verdict(res,'FAIL',`extras still running after being switched back off: ${after.join(', ')}`);
  if(/NOT put/.test(jn))H.verdict(res,'FAIL','her journal flag was not put back');
}

/* ================================================================ 10. V11 PERFORMANCE */
async function v11perf(ctx,res,H){
  const V=needV11(ctx,res);if(!V)return;const doc=ctx.doc,api=ctx.api,MS=ctx.opts.v11PerfMs??3500;
  await H.ensureFlying(ctx);ctx.check();
  if(!(H.call.bitState(ctx)?.allocations??[]).some(b=>b.location==='home')){await H.call.bitsOn(ctx,true);res.restore(async()=>{await H.call.bitsOn(ctx,false);await H.sleep(600);});await H.sleep(1400);}
  await H.settle(ctx,{timeout:1500});
  let n=4,dir=null;for(;n>=2&&!dir;n--)dir=H.freeDirection(ctx,n);n++;
  const home={x:doc.x,y:doc.y};res.restore(async()=>{if(doc.x!==home.x||doc.y!==home.y){await doc.update({x:home.x,y:home.y},{animate:false});await H.sleep(200);}});
  const T=new V11Timer();res.restore(()=>T.restore());timeAll(T,V).start();
  const rows=[];
  const row=async(name,load=null,{pre=null,post=null}={})=>{ctx.check();try{await pre?.();}catch(e){res.lines.push(`(${name}: ${String(e?.message??e).slice(0,50)})`);return;}
    T.reset();const r=await H.measureLoad(ctx,`V11 ${name}`,MS,load);r.name=name;r.v11=T.read();rows.push(r);try{await post?.();}catch{}};
  const move=dir?until=>H.moveLoop(ctx,dir,n,until):null;
  await row('idle hover');
  // flying, with the world features off, then on
  const WORLD=['wallFold','lightCatch','wingShadowTokens'],w0=Object.fromEntries(WORLD.map(k=>[k,isOn(k,doc)]));
  res.restore(async()=>{for(const k of WORLD)if(isOn(k,doc)!==w0[k])try{await writeV11(k,w0[k],doc);}catch{}});
  const setWorld=async v=>{for(const k of WORLD)if(isOn(k,doc)!==v)await writeV11(k,v,doc);await H.sleep(300);};
  if(move){await row('flying',move,{pre:()=>setWorld(false)});await row('flying+world',move,{pre:()=>setWorld(true),post:async()=>{for(const k of WORLD)if(isOn(k,doc)!==w0[k])await writeV11(k,w0[k],doc);await H.settle(ctx,{timeout:1500});}});}
  else res.lines.push('(flying rows skipped: no free line of 2+ squares)');
  const ally=nearestAlly(ctx)?.token,HR=V.heal,r=HR.recordOf(ctx.token);
  if(r&&isOn('heroSpent',doc))await row('hero moment',async()=>{HR.add(r,{kind:'hero',at:clock()});},{post:()=>H.waitUntil(()=>!HR.busy(ctx.token),6000,()=>H.sleep(100))});
  if(isOn('emotes',doc)&&api?.v11?.emote)await row('emote',async()=>{await api.v11.emote('bow',{token:ctx.token});await H.sleep(1700);await api.v11.emote('cheer',{token:ctx.token});},{post:()=>H.waitUntil(()=>!V.emote.busy(ctx.token),4000,()=>H.sleep(100))});
  const st=()=>V.invisibility.status(ctx.token)?.phase;
  if(api?.v11?.fade&&st()==='solid'){res.restore(async()=>{if(st()!=='solid'){try{await api.v11.fade(false,{token:ctx.token});}catch{}await H.waitUntil(()=>st()==='solid',6000,()=>H.sleep(100));}});
    await row('cloak sweep',async()=>{await api.v11.fade(true,{token:ctx.token});},{post:async()=>{await H.waitUntil(()=>st()==='held',3000,()=>H.sleep(100));await api.v11.fade(false,{token:ctx.token});await H.waitUntil(()=>st()==='solid',6000,()=>H.sleep(100));}});}
  T.restore();
  const base=rows[0];if(!base){res.lines.push('no rows measured');return;}
  res.lines.push('ms med/p95/max · main ms/frame med/p95 · percept/frame · v11 ms/frame (top runtime) · Δmean ms');
  for(const r of rows){const d=r===base?'base':`${r.mean-base.mean>=0?'+':''}${f1(r.mean-base.mean)}`,top=r.v11.top;
    res.lines.push(`${r.name.padEnd(13)} ${f1(r.fs.med)}/${f1(r.fs.p95)}/${f0(r.fs.max)} · ${r.main?.n?`${f1(r.main.med)}/${f1(r.main.p95)}`:'-'} · ${f2(r.percFrame)} · ${f3(r.v11.perFrame)}${top?` (${top[0]} ${f3(top[1])})`:''} · ${d}${r.err?` · ${r.err}`:''}`);}
  const items=rows.slice(1).map(r=>[r.name,Math.max(0,r.mean-base.mean),r.v11.perFrame]).sort((a,b)=>b[2]-a[2]).slice(0,5);
  res.lines.push(`costs most (v11 ms per frame, Δ frame ms): ${items.map(([k,dm,v],i)=>`${i+1}. ${k} ${f2(v)} (Δ ${f1(dm)})`).join(' · ')}`);
  const fly=rows.find(r=>r.name==='flying'),fw=rows.find(r=>r.name==='flying+world');
  // (test.12) the two rows are two separate flights: Foundry's own refreshes as she moves (about 21 a frame here) differ by a
  // percent or so between them, and more when a frame is dropped. Only a rise well past that is the world features' doing.
  if(fly&&fw){const rise=fw.percFrame-fly.percFrame,tol=Math.max(.1,fly.percFrame*.05);
    if(rise>tol*3)H.verdict(res,'FAIL',`the world features add perception: ${f2(fw.percFrame)} a frame against ${f2(fly.percFrame)}`);
    else if(rise>tol)H.verdict(res,'CHECK',`perception a little higher with the world features on: ${f2(fw.percFrame)} a frame against ${f2(fly.percFrame)} (two separate flights; run again to see if it repeats)`);}
  const heavy=rows.filter(r=>r.v11.perFrame>2);if(heavy.length)H.verdict(res,'CHECK',`v11 work over 2 ms a frame: ${heavy.map(r=>`${r.name} ${f2(r.v11.perFrame)}`).join(', ')}`);
  if(base.v11.perFrame>.2)H.verdict(res,'CHECK',`v11 idle cost ${f3(base.v11.perFrame)} ms a frame hovering`);
  if(!res.verdicts.length)H.verdict(res,'PASS',`v11 work stays small: worst ${items[0]?`${items[0][0]} ${f2(items[0][2])}`:'-'} ms a frame, idle ${f3(base.v11.perFrame)}`);
}

export const V11_RUN=Object.freeze({v11setup,v11token,v11wounds,v11invis,v11heal,v11emotes,v11wheel,v11world,v11extras,v11perf});

/* ---------------------------------------------------------------- RESTORE: what the V11 part may leave behind */
/** The v11 runtimes at rest (for the RESTORE line): nothing playing, nothing ticking that should not be. */
export function v11Residue(ctx){
  const V=runtimesOf(ctx);if(!V||!ctx.token)return [];
  const out=[];
  try{if(V.emote.busy(ctx.token))out.push('an emote');}catch{}
  try{const r=V.heal.records.get(ctx.doc.id);if(r?.R.moments.length)out.push(`${r.R.moments.length} heal moment(s)`);}catch{}
  try{const s=V.invisibility.status(ctx.token);if(s&&s.phase!=='solid'&&!s.source)out.push(`invisibility ${s.phase}`);if(s?.filters&&s.phase!=='sweep'&&s.phase!=='flicker')out.push(`${s.filters} cloak filter(s)`);}catch{}
  try{if(ctx.api?.quickWheel?.instance?.())out.push('the quick wheel');}catch{}
  return out;
}
