/** v10 beta.10 · One place that asks Foundry to refresh after a light change.
 * Lighting refreshes on every call. A vision recompute (the costly part: every
 * token's sight is redone) is asked for at most VISION_HZ times a second while
 * lights are moving; the latest change always lands once motion stops. The
 * native light sources themselves still rebuild on every frame they move.
 *
 * Beta.35: at most one request per canvas frame. Her wing light, each
 * lantern source and each parked light used to ask separately, several
 * times in the same frame; Foundry applies the flags once per frame anyway,
 * so a request whose flags were already asked for this frame is dropped. */
import {localPerformance} from './performance.mjs?v=12.0.1';
export const VISION_HZ=15;
let lastVision=-Infinity,pending=null,frame=null,asked=0;
const LIGHTING=1,VISION=2;
/** The canvas frame this call belongs to (the ticker's time of the frame). */
const frameOf=canvas=>canvas?.app?.ticker?.lastTime??null;
function ask(canvas,flags,force=false){
  const id=frameOf(canvas);
  if(id!==null&&id===frame){if(!force&&(asked&flags)===flags){localPerformance.count('perceptionCoalesced');return;}}
  else{frame=id;asked=0;}
  asked|=flags;
  canvas.perception?.update?.(flags&VISION?{refreshLighting:true,refreshVision:true}:{refreshLighting:true});
}
export function refreshAfterLight(){
  const canvas=globalThis.canvas;if(!canvas?.ready)return;
  const now=performance.now(),due=now-lastVision>=1000/VISION_HZ-1e-6;
  localPerformance.count('lightRefreshes');
  if(due){localPerformance.count('visionRecomputes');lastVision=now;if(pending){clearTimeout(pending);pending=null;}ask(canvas,LIGHTING|VISION);return;}
  ask(canvas,LIGHTING);
  if(!pending)pending=setTimeout(()=>{pending=null;lastVision=performance.now();if(globalThis.canvas?.ready)ask(globalThis.canvas,LIGHTING|VISION,true);},1000/VISION_HZ);
}
