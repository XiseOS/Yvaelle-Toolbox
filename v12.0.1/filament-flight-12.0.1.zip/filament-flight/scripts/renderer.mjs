import {localPerformance} from './performance.mjs?v=12.0.1';
import {ID} from './config.mjs?v=12.0.1';
import {wingPhase} from './wing-phase.mjs?v=12.0.1';
import {manoeuvreRotation} from './flight-manoeuvres.mjs?v=12.0.1';
import {veilAlphaOf} from './v11/invis-hooks.mjs?v=12.0.1';
import {worldRuntime} from './v11/world-runtime.mjs?v=12.0.1';
import {resolveV11} from './v11/features.mjs?v=12.0.1';
import {heightShadow} from './flight-feel.mjs?v=12.0.1';

const FRAME_COUNT=48, COLUMNS=8, FRAME_SIZE=512;
let texturesPromise,atlasPromise;

async function loadAtlas() {
  if (!atlasPromise) atlasPromise=(async()=>{
    const route=foundry.utils.getRoute(`modules/${ID}/assets/wings-atlas.webp`);
    const atlas=await PIXI.Assets.load(`${route}?v=1.0.2`);
    if (!atlas?.baseTexture?.valid) throw new Error('The wing textures could not be loaded. Check the module assets folder.');
    if (atlas.width!==4096||atlas.height!==3072) throw new Error('Unexpected wing atlas dimensions; reinstall the complete module folder.');
    return Array.from({length:FRAME_COUNT},(_,i)=>new PIXI.Texture(atlas.baseTexture,
      new PIXI.Rectangle(i%COLUMNS*FRAME_SIZE,Math.floor(i/COLUMNS)*FRAME_SIZE,FRAME_SIZE,FRAME_SIZE)));
  })();
  try {return await atlasPromise;} catch(error) {atlasPromise=undefined;throw error;}
}

/** Procedural wings need the small shared shadow, but no legacy atlas. Keep the
 * original complete bundle as the default for integrations and the atlas route.
 * A later route switch or rig failure can request the same atlas exactly once. */
export async function loadAssets({atlas=true}={}) {
  if (!texturesPromise) texturesPromise=(async()=>{
    const shadow=await PIXI.Assets.load(foundry.utils.getRoute(`modules/${ID}/assets/shadow.webp`));
    if (!shadow?.baseTexture?.valid) throw new Error('The wing textures could not be loaded. Check the module assets folder.');
    const textures={frames:null,shadow,async ensureAtlas(){
      if (!textures.frames) textures.frames=await loadAtlas();
      return textures.frames;
    }};
    return textures;
  })().catch(error=>{texturesPromise=undefined;throw error;});
  // The original route still starts its two downloads together. Await both so
  // either failure is observed without discarding an already valid shadow.
  const [textures,frames]=await Promise.all([texturesPromise,atlas?loadAtlas():null]);
  if(frames)textures.frames=frames;
  return textures;
}

/** Flight-feel shadow textures, loaded on first use (null until ready). */
let feelShadows=null,feelShadowsLoading=false,feelShadowsFailed=false;
export function feelShadowTextures(){
  if(feelShadows||feelShadowsLoading||feelShadowsFailed)return feelShadows;
  feelShadowsLoading=true;
  Promise.all(['shadow-body','shadow-wings'].map(n=>PIXI.Assets.load(foundry.utils.getRoute(`modules/${ID}/assets/flight/${n}.webp`))))
    .then(([body,wings])=>{if(body?.baseTexture?.valid&&wings?.baseTexture?.valid)feelShadows={body,wings};else feelShadowsFailed=true;})
    .catch(error=>{feelShadowsFailed=true;console.warn('Yvaelle’s Toolbox | flight shadows',error);})
    .finally(()=>{feelShadowsLoading=false;});
  return null;
}

/** One shared non-interactive, depth-free mesh class (made on first use: the
 * Foundry base class may not exist when this module is imported). */
let effectMeshBase=null,EffectMeshClass=null;
export function effectMeshClass(){
  const Native=foundry.canvas.primary.PrimarySpriteMesh;
  if(effectMeshBase!==Native){effectMeshBase=Native;EffectMeshClass=class EffectMesh extends Native {get shouldRenderDepth(){return false;}containsCanvasPoint(){return false;}};}
  return EffectMeshClass;
}

export function current(token) {
  return !!(canvas.ready && token && !token.destroyed && !token.mesh?.destroyed
    && token.document?.parent?.id === canvas.scene?.id);
}

/** Drawn exactly when Foundry draws the token: Token#visible is Foundry's own
 * cached Token#isVisible (refreshed with perception, together with its
 * detection filter). Reading isVisible here re-ran the visibility tests, and
 * cleared that filter, several times per token per frame. */
export function isShown(token, source) {
  return !!(token.visible !== false && source.visible !== false
    && source.renderable !== false && !token.detectionFilter && (!token.document.hidden || game.user.isGM));
}

/** Conservative primary-layer rectangle in screen coordinates. If a fixture or
 * alternate renderer supplies no transform, keep drawing rather than guess. */
export function isOnScreen(x,y,halfWidth,halfHeight){
  const matrix=globalThis.canvas?.primary?.worldTransform??globalThis.canvas?.stage?.worldTransform;
  const screen=globalThis.canvas?.app?.renderer?.screen;
  if(!matrix||!screen||!Number.isFinite(matrix.a)||!Number.isFinite(matrix.b)||!Number.isFinite(matrix.c)||!Number.isFinite(matrix.d)||
    !Number.isFinite(matrix.tx)||!Number.isFinite(matrix.ty)||!Number.isFinite(screen.width)||!Number.isFinite(screen.height))return true;
  const cx=matrix.a*x+matrix.c*y+matrix.tx,cy=matrix.b*x+matrix.d*y+matrix.ty;
  const rx=Math.abs(matrix.a)*halfWidth+Math.abs(matrix.c)*halfHeight,ry=Math.abs(matrix.b)*halfWidth+Math.abs(matrix.d)*halfHeight;
  const pad=64;
  return cx+rx>=-pad&&cy+ry>=-pad&&cx-rx<=screen.width+pad&&cy-ry<=screen.height+pad;
}

/** PIXI setters invalidate mesh transforms even when their value is unchanged.
 * Compare the actual mesh, so texture replacements and external scale edits
 * are still reconciled immediately. Animation and motion retain their native
 * display cadence; stationary meshes avoid redundant transform invalidation. */
export function setMeshTransform(mesh,x,y,rotation,width,height){
  if(mesh.x!==x||mesh.y!==y)mesh.position.set(x,y);
  if(rotation!==undefined&&mesh.rotation!==rotation)mesh.rotation=rotation;
  if(mesh.width!==width)mesh.width=width;
  if(mesh.height!==height)mesh.height=height;
}

export function placeBehind(sprite, source, order) {
  // Sorting runs for every mesh on every display tick. Avoid allocating a
  // temporary object and entry arrays, and dirty only genuinely changed keys.
  const elevation=source.elevation??0,sortLayer=source.sortLayer??700,
    sort=(source.sort??0)-order,zIndex=(source.zIndex??0)-order;
  let changed=false;
  if(sprite.elevation!==elevation){sprite.elevation=elevation;changed=true;}
  if(sprite.sortLayer!==sortLayer){sprite.sortLayer=sortLayer;changed=true;}
  if(sprite.sort!==sort){sprite.sort=sort;changed=true;}
  if(sprite.zIndex!==zIndex){sprite.zIndex=zIndex;changed=true;}
  if(changed)canvas.primary.sortDirty=true;
  if(source.occlusion&&sprite.occlusion)for(const key in sprite.occlusion){
    const value=source.occlusion[key];
    if(key in source.occlusion&&typeof value!=='object'&&sprite.occlusion[key]!==value)sprite.occlusion[key]=value;
  }
}

/** (v11) What the wing shadow's copies on tokens are made with. */
const SHADOW_COPY={get EffectMesh(){return effectMeshClass();},get shader(){return foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;},get Texture(){return PIXI.Texture;},placeBehind};

/** Original atlas presentation, isolated from state and document writes. */
export class AtlasRenderer {
  constructor(token, textures) {
    this.token=token; this.textures=textures; this.frame=-1;this.destroyed=false;
    const EffectMesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
    try {
      this.wings=new EffectMesh({name:`${ID}.${token.id}.wings`,texture:textures.frames?.[0]??PIXI.Texture.EMPTY},Shader);
      this.shadow=new EffectMesh({name:`${ID}.${token.id}.shadow`,texture:textures.shadow},Shader);
      for (const mesh of [this.wings,this.shadow]) {
        mesh.anchor.set(0.5); mesh.eventMode='none'; mesh.interactive=false; mesh.visible=false; mesh.alpha=0;
        canvas.primary.addChild(mesh);
      }
    } catch (error) { this.destroy(); throw error; }
  }

  ensureAtlas() {
    if(this.destroyed||this.textures.frames?.length||this.atlasPending||this.atlasFailed)return;
    if(typeof this.textures.ensureAtlas!=='function'){this.atlasFailed=true;return;}
    this.atlasPending=Promise.resolve().then(()=>this.textures.ensureAtlas()).then(()=>{
      if(!this.destroyed)this.frame=-1;
    }).catch(error=>{
      if(!this.destroyed){this.atlasFailed=true;try{this.report?.(error);}catch{/* Diagnostics cannot disable the retained shadow or create an unhandled load rejection. */}}
    }).finally(()=>{this.atlasPending=null;});
  }

  update(s, snapshot, config, now, {atlas=true,deferWingAlpha=false}={}) {
    localPerformance.recordQuality(config);if(atlas)localPerformance.recordRenderPath('wing-atlas');
    // Pose composition applies material energy and its rig crossfade after this
    // shared placement. Keep the base scalar local until that final result,
    // rather than invalidating a hidden atlas sprite twice each display tick.
    if(deferWingAlpha)this.pendingWingAlpha=this.wings.alpha;
    const token=this.token, source=s.source, size=Math.max(token.w,token.h);
    const visible=isShown(token,source)&&config.performanceComponents?.wings!==false&&isOnScreen(source.x,source.y,Math.max(size*s.opts.wingScale,size)*1.5,Math.max(size*s.opts.wingScale,size)*1.5);
    if(visible&&atlas)this.ensureAtlas();
    const wingsVisible=visible&&atlas&&!!this.textures.frames?.length,shadowVisible=visible&&s.opts.shadow;
    if(this.wings.visible!==wingsVisible)this.wings.visible=wingsVisible;
    if(this.shadow.visible!==shadowVisible)this.shadow.visible=shadowVisible;
    if(!shadowVisible&&this.wingShadow?.visible){this.wingShadow.visible=false;worldRuntime.shadowOnTokens(this.token,s,null);}
    if (!visible) return;
    const phase=wingPhase(s,snapshot,config,now);
    const frame=Math.floor(phase/(Math.PI*2)*FRAME_COUNT)%FRAME_COUNT;
    if (this.wings.visible&&frame !== this.frame) { this.wings.texture=this.textures.frames[frame]; this.frame=frame; }
    const k=s.altScale??1,angle=source.rotation+s.bank+manoeuvreRotation(s,snapshot), ox=s.opts.offsetX*size*k, oy=s.opts.offsetY*size*k;
    const c=Math.cos(angle),sn=Math.sin(angle);
    setMeshTransform(this.wings,source.x+(s.swayX??0)+ox*c-oy*sn,
      source.y+s.lift+ox*sn+oy*c,angle,size*k*s.opts.wingScale*(0.35+0.65*s.blend)*(s.feelWidth??1),size*k*s.opts.wingScale);
    const wingsAlpha=source.alpha*s.opts.opacity*s.blend*snapshot.effective.intensity*(s.feelWingAlpha??1)*veilAlphaOf(token,'wings');
    if(deferWingAlpha)this.pendingWingAlpha=wingsAlpha;else if(this.wings.alpha!==wingsAlpha)this.wings.alpha=wingsAlpha;
    placeBehind(this.wings,source,0.25);
    if(s.feel&&this.feelShadow(s,source,size,phase))return;
    if(this.wingShadow){this.wingShadow.visible=false;worldRuntime.shadowOnTokens(this.token,s,null,SHADOW_COPY);}
    if(this.textures.shadow&&this.shadow.texture!==this.textures.shadow)this.shadow.texture=this.textures.shadow;
    setMeshTransform(this.shadow,source.x,source.y+size*0.30,undefined,size*(1.03+Math.abs(s.lift)/size*0.30),size*0.42);
    const shadowAlpha=source.alpha*s.blend*0.72*veilAlphaOf(token,'shadow');if(this.shadow.alpha!==shadowAlpha)this.shadow.alpha=shadowAlpha;
    placeBehind(this.shadow,source,0.5);
  }

  /** Flight feel: the shadow stays on the ground under her (softer, wider and
   * fainter with height) and her wing silhouette opens and closes with each
   * beat. Returns false until the two textures have loaded. */
  feelShadow(s,source,size,phase){
    const t=feelShadowTextures();if(!t)return false;
    const sh=s.feel.shadow,collapse=Math.max(s.feel.collapse??0,(s.v11FoldK??0)*.85);
    if(this.shadow.texture!==t.body)this.shadow.texture=t.body;
    // (test.20) smaller and fainter with height (Settings › Flight › Shadow shrinks with height); off = wider and softer, as before
    let shrink=true;try{shrink=resolveV11(this.token.document).shadowHeight!==false;}catch{}
    const hs=heightShadow(s.feel.alt,shrink),hScale=shrink?hs.scale*(sh.gather??1):sh.scale,hAlpha=shrink?hs.alpha:sh.alpha;
    const bw=size*1.15*hScale,bh=size*.5*hScale;
    setMeshTransform(this.shadow,sh.x,sh.y,undefined,bw,bh);
    const veil=veilAlphaOf(this.token,'shadow'),a=source.alpha*s.blend*hAlpha*veil;if(this.shadow.alpha!==a)this.shadow.alpha=a;
    placeBehind(this.shadow,source,0.5);
    if(!this.wingShadow){
      const EffectMesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
      this.wingShadow=new EffectMesh({name:`${ID}.${this.token.id}.wingShadow`,texture:t.wings},Shader);
      this.wingShadow.anchor.set(.5);this.wingShadow.eventMode='none';this.wingShadow.interactive=false;canvas.primary.addChild(this.wingShadow);
    }
    const wing=size*s.opts.wingScale*(s.feelWidth??1),alt=s.feel.alt,grow=hs.wing;
    const spread=(.62+.38*(.5+.5*Math.cos(phase)))*(1-.65*collapse);
    setMeshTransform(this.wingShadow,sh.x,sh.y-size*.18,undefined,wing*spread*grow,wing*grow);
    // The wing shadow's strength is a per-token choice (Settings › Flight feel).
    const wa=source.alpha*s.blend*.26*(s.feel.wingShadow??1)*Math.max(.3,s.feel.air??1)/(1+alt/20)*hs.wingFade*veil;
    this.wingShadow.visible=this.shadow.visible&&wa>.004;if(this.wingShadow.alpha!==wa)this.wingShadow.alpha=wa;
    placeBehind(this.wingShadow,source,0.49);
    // (v11) where that shadow lies across another token, a masked copy lies on it (v11/world-runtime.mjs)
    worldRuntime.shadowOnTokens(this.token,s,this.wingShadow,SHADOW_COPY);
    return true;
  }

  destroy() {
    this.destroyed=true;worldRuntime.releaseShadows(this.token);
    for (const mesh of [this.wings,this.shadow,this.wingShadow]) if (mesh && !mesh.destroyed) {
      mesh.parent?.removeChild(mesh);
      mesh.destroy({children:true,texture:false,baseTexture:false});
    }
  }
}
