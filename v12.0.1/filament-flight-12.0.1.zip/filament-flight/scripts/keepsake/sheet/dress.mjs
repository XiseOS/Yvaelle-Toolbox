/** Keepsake sheet (v10 beta.27): PF2e's own character sheet, dressed.
 *
 * Nothing of PF2e's sheet is replaced. Its form, inputs, buttons, data-action
 * hooks, drag and drop, context menus and every tab render exactly as PF2e
 * makes them, so the sheet keeps all of PF2e's features and other modules
 * still find what they add to. After each render this file:
 *  - adds the Keepsake frame (corners, cords, title row) around the window,
 *  - gathers PF2e's header into the Keepsake header with her portrait, her
 *    heartbeat, her hero petals and the conditions on her,
 *  - groups PF2e's sidebar into panels and draws the dying and wounded
 *    tracks, rank badges in PF2e's own colours and the dying icon,
 *  - gives the tab bar its icons and the ⋯ menu,
 *  - marks the fields each tab can hide, hides the ones switched off and
 *    lets the rest re-pack (gliding into place when you switch one).
 * Switching the Keepsake sheet off undoes it on the next render. */
import {SHEET_TABS,SHEET_FIELDS,SIDE_FIELDS,fieldKey,identitySpans,shareSpans,bioSpans,dyingStage,rankLetter,portraitView,
  conditionIcon,VALUED_CONDITIONS,GOOD_CONDITIONS,PALETTE_CONDITIONS,chipTip,WIDE_BIO} from './model.mjs?v=12.0.1';
import {keepsakeOn,hiddenFields,clientSheet,saveClientSheet,portraitConfig,canEditFields} from './prefs.mjs?v=12.0.1';
import {heartbeat,heartState} from '../heartbeat.mjs?v=12.0.1';
import {ensureSprite,iconHTML,moduleRoute} from './sprite.mjs?v=12.0.1';
import {worldSky,moonPath,nytherisPetals,lilyOpen} from '../sky.mjs?v=12.0.1';
import {petalLeaving,rowSwayAngle,PETAL_MAX_MS,PETAL_HANDOVER_MS} from '../petal-fall.mjs?v=12.0.1';
import {readFlower,readSlot,arrive,traceHero} from '../petal-dom.mjs?v=12.0.1';
import {miniButtons,grips,undoChrome,busyWatch,lockButton} from './chrome.mjs?v=12.0.1';
import {markChanges,glideRows} from './motion.mjs?v=12.0.1';
import {holdDecorWhileMoving,release as releaseDecor} from '../decor-hold.mjs?v=12.0.1';
import {dressPetals} from './herbarium.mjs?v=12.0.1';

const ID='filament-flight';
const MIN={width:760,height:640},DEFAULT={width:1000,height:900};
/** Per sheet window: sizing, observers, the glide to play after the next render. */
const apps=new WeakMap();
/** Per actor: what the header showed last (so a spent petal can drift away and the portrait can cross-fade). */
const lastSeen=new Map();
const stateOf=app=>{let s=apps.get(app);if(!s){s={};apps.set(app,s);}return s;};
const el=x=>x?.[0]??x??null;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const loc=(key,fallback)=>{try{const t=game.i18n?.localize?.(key);return t&&t!==key?t:fallback;}catch{return fallback;}};

/** The tab's own label for the tab bar (PF2e's localisation where it has one). */
const TAB_LABELS={character:['PF2E.TabCharacterLabel','Character'],actions:['PF2E.TabActionsLabel','Actions'],inventory:['PF2E.TabInventoryLabel','Inventory'],
  spellcasting:['PF2E.TabSpellbookLabel','Spells'],crafting:['PF2E.TabCraftingLabel','Crafting'],proficiencies:['PF2E.TabSkillsLabel','Proficiencies'],
  feats:['PF2E.Item.Feat.Plural','Feats'],effects:['PF2E.Item.Effect.Plural','Effects'],biography:['PF2E.Biography','Biography'],pfs:['PF2E.TabPathfinderSociety','Society']};
export const tabLabel=id=>{const t=TAB_LABELS[id];return t?loc(t[0],t[1]):id;};

export function isDressed(app){return !!el(app?.element)?.classList?.contains('ffks');}

/** The render hook. Never throws: if anything goes wrong PF2e's sheet stays as it is. */
export function dressSheet(app,html,{force=false}={}){
  let root=null;
  try{
    root=el(app?.element);const form=el(html)?.closest?.('form')??el(html)?.querySelector?.('form')??root?.querySelector?.('form');
    const actor=app?.actor,st=stateOf(app);
    const usable=!!(root&&form&&actor&&form.querySelector(':scope > nav.sheet-navigation')&&form.querySelector(':scope > header.char-header'));
    if(!usable||st.standard||st.broken||!(force||keepsakeOn(actor))||(actor.limited&&!game.user?.isGM)){undress(app,root);return false;}
    void ensureSprite();
    // (while it's dressed nothing transitions: the new look lands at once; and a redraw
    // doesn't replay the tab's entrance — that's for when she picks a tab)
    root.classList.add('ffks');form.classList.add('ffks-form','ffks-still');
    // the Keepsake sidebar scrolls on its own: Foundry keeps its place across renders
    const sy=app.options?.scrollY;if(Array.isArray(sy)&&!sy.includes('aside.ffks-side'))sy.push('aside.ffks-side');
    motionClass(root);
    frame(root);
    miniButtons(root);grips(app,root,MIN);busyWatch(root);holdDecorWhileMoving(root,root,{surface:'sheet'});lock(app,root);
    size(app,root,st);
    watch(app,root,st);
    header(app,form,actor);
    sidebar(app,form,actor);
    nav(app,form,actor);
    tabs(app,form,actor);
    try{dressPetals(app,form,actor);}catch(e){console.warn('Keepsake sheet · petals',e);}   // (v11 extra) milestone petals and the herbarium
    headerTexts(form);
    applyHidden(app,{flip:st.flipNext??null});st.flipNext=null;
    form.dataset.ffksReady='true';
    // (a redraw's pictures are new elements: decoded with the paint, they never flash empty for a frame)
    for(const img of form.querySelectorAll('.sheet-content img'))img.decoding='sync';
    try{markChanges(app,root);}catch{}
    settle(root,form,app);
    return true;
  }catch(error){
    root?.classList?.remove('ffks-dressing');
    console.error('Yvaelle’s Toolbox | Keepsake sheet could not dress this sheet; PF2e\'s sheet is shown as it is.',error);
    // Show PF2e's own sheet, cleanly, until this window is closed (no retry loop).
    try{const st=stateOf(app);if(!st.broken){st.broken=true;undress(app,root);setTimeout(()=>{try{app.render?.(false);}catch{}},0);}}catch{}
    return false;
  }
}

/** The dressed look is worked out at once, while nothing transitions (so the
 * sheet doesn't fade over from PF2e's own look each time PF2e redraws it);
 * then her looping motions go on one clock, so a redraw doesn't restart them. */
function settle(root,form,app){
  // (in the next frame, before it paints: the style pass is then the frame's own, not an extra one)
  const W=root.ownerDocument.defaultView??globalThis;
  if(W.requestAnimationFrame){W.requestAnimationFrame(()=>{if(form.isConnected){try{restRow(form.querySelector('.hitpoints .hp-small'));}catch{}settleNow(root,form);try{glideRows(app,root);}catch{}}});return;}
  settleNow(root,form);
}
function settleNow(root,form){
  // One style pass: anything that started to transition from PF2e's look lands
  // at once, and the looping motions take the page's clock. (Before beta.32 a
  // dressing class was put on and taken off around a forced style pass, which
  // restyled the whole window twice per redraw.)
  const T=(root.ownerDocument.defaultView??globalThis).CSSTransition;
  for(const a of root.getAnimations?.({subtree:true})??[]){
    try{
      if(T&&a instanceof T){a.finish();continue;}
      if(a.playState!=='paused'&&a.effect?.getTiming?.().iterations===Infinity&&form.contains(a.effect?.target))a.startTime=0;
    }catch{}
  }
  root.classList.remove('ffks-dressing');
}
/** Looping motions under a node (the petals' sway, her heartbeat, the dying
 * beat) keep the page's clock: drawn again, they carry on mid-swing. */
function onBeat(node){
  for(const a of node?.getAnimations?.({subtree:true})??[]){
    try{if(a.playState!=='paused'&&a.effect?.getTiming?.().iterations===Infinity)a.startTime=0;}catch{}
  }
}

/** Back to PF2e's own look (the next render redraws the inside). */
export function undress(app,root=el(app?.element)){
  if(!root?.classList?.contains('ffks'))return;
  root.classList.remove('ffks','ffks-dressing','ffks-narrow','ffks-short','ffks-fm-off','ffks-fm-slow','ffks-fm-lively','ffks-nocol-price','ffks-nocol-bulk');
  for(const n of root.querySelectorAll(':scope > .ffks-frame, :scope > .ffks-flypetal, :scope > .ffks-flysvg'))n.remove();
  undoChrome(root);releaseDecor(root);
  const st=stateOf(app);st.ro?.disconnect();st.ro=null;
  if(st.sizedFrom&&!st.standard){try{app.setPosition?.({...st.sizedFrom});}catch{}}
  st.sized=false;st.sizedFrom=null;
}

/** Frame motion follows the Keepsake HUD's choice (Off, Slow, Normal, Lively). */
function motionClass(root){
  let fm='Normal';try{fm=(game.settings.get(ID,'keepsakeUI')??{}).fm??'Normal';}catch{}
  let reduced=false;try{reduced=!!game.settings.get(ID,'reducedMotion');}catch{}
  root.classList.toggle('ffks-fm-off',fm==='Off'||reduced);root.classList.toggle('ffks-fm-slow',fm==='Slow');root.classList.toggle('ffks-fm-lively',fm==='Lively');
}

/** Corners, cords and the little line at the foot: drawn once per window, outside PF2e's content. */
const petalTransform=p=>`rotate(${p.angle.toFixed(1)}deg) scale(${p.sx.toFixed(3)},${p.sy.toFixed(3)})`;
const skyNow=()=>{try{return worldSky();}catch{return {phase:.15,night:1,fromFull:10,hour:null,source:'error'};}};
/** The corners keep the world's time: the Nytheris opens as night comes on and
 * closes to her bud by day, the moon follows its phase, the lunar lily opens at
 * full moon. Called on every redraw and when the world's clock moves; each
 * change eases over (CSS transitions on the petals, the moon and the lily). */
export function skyCorners(root,sky=skyNow()){
  const f=root?.querySelector?.(':scope > .ffks-frame');if(!f)return;
  const key=`${sky.night.toFixed(3)}|${sky.phase.toFixed(3)}|${sky.fromFull.toFixed(2)}`;if(f.dataset.sky===key)return;f.dataset.sky=key;
  f.dataset.night=sky.night.toFixed(3);f.dataset.hour=sky.hour==null?'':Number(sky.hour).toFixed(2);
  const ps=nytherisPetals(sky.night);
  f.querySelectorAll('.ffks-corner.tl .ffks-ny use').forEach((u,k)=>{if(ps[k])u.style.transform=petalTransform(ps[k]);});
  const moon=f.querySelector('.ffks-moon');if(moon)moon.style.d=`path("${moonPath(sky.phase,91.5,37,13)}")`;
  const lily=lilyOpen(sky.fromFull),L=f.querySelector('.ffks-corner.br.part');
  if(L){L.style.opacity=(.55+.45*lily).toFixed(2);L.classList.toggle('full',lily>.5);}
}
function frame(root){
  const sky=skyNow();
  if(root.querySelector(':scope > .ffks-frame')){skyCorners(root,sky);return;}
  const petals=nytherisPetals(sky.night).map(p=>`<use href="#ffks-petal" style="transform:${petalTransform(p)}"></use>`).join('');
  const lily=lilyOpen(sky.fromFull);
  const wrap=root.ownerDocument.createElement('div');wrap.className='ffks-frame';wrap.setAttribute('aria-hidden','true');wrap.dataset.night=sky.night.toFixed(3);
  wrap.innerHTML=`<svg class="ffks-defs" width="0" height="0"><defs>
<pattern id="ffks-cord-h" width="7" height="8" patternUnits="userSpaceOnUse"><rect width="7" height="8" fill="#1a0f15"/><path d="M-1.5 7.5L5.5 .5" stroke="#bf9d63" stroke-width="2.4" stroke-linecap="round"/><path d="M2 7.5L9 .5" stroke="#eadfcf" stroke-opacity=".8" stroke-width="1.6" stroke-linecap="round"/><path d="M0 .4H7M0 7.6H7" stroke="#5a4330" stroke-width=".8"/></pattern>
<pattern id="ffks-cord-v" width="8" height="7" patternUnits="userSpaceOnUse"><rect width="8" height="7" fill="#1a0f15"/><path d="M.5 -1.5L7.5 5.5" stroke="#bf9d63" stroke-width="2.4" stroke-linecap="round"/><path d="M.5 2L7.5 9" stroke="#eadfcf" stroke-opacity=".8" stroke-width="1.6" stroke-linecap="round"/><path d="M.4 0V7M7.6 0V7" stroke="#5a4330" stroke-width=".8"/></pattern>
<g id="ffks-curls" fill="none" stroke="#c7a66c" stroke-linecap="round"><path d="M27 15.5C41 5 53 27 69 15.5C79 8.5 91 10.5 104 15.5" stroke-width="1.7"/><path d="M49 15.5c0 -6 8 -8 10 -3 1 3 -2 5 -4 3" stroke-width="1.4"/><path d="M30 26c6 4 10 10 8 16M26 30c4 6 10 10 16 8" stroke-width="1.1"/><circle cx="37" cy="37" r="1.6" fill="#c7a66c" stroke="none"/><path d="M80 12c3 -5 9 -4 9 1" stroke-width=".9"/><path d="M15.5 27C5 41 27 53 15.5 69C8.5 79 10.5 91 15.5 104" stroke-width="1.7"/><path d="M15.5 49c-6 0 -8 8 -3 10 3 1 5 -2 3 -4" stroke-width="1.4"/><path d="M12 80c-5 3 -4 9 1 9" stroke-width=".9"/><path d="M15.5 6.5L24.5 15.5 15.5 24.5 6.5 15.5Z" fill="#160c12" stroke-width="1.4"/><circle cx="15.5" cy="15.5" r="2.2" fill="#e767ce" stroke="none"/></g>
<g id="ffks-runs"><path class="ffks-run" d="M27 15.5C41 5 53 27 69 15.5C79 8.5 91 10.5 104 15.5" pathLength="100"/><path class="ffks-run" d="M15.5 27C5 41 27 53 15.5 69C8.5 79 10.5 91 15.5 104" pathLength="100" style="animation-delay:.35s"/></g>
<path id="ffks-petal" d="M0 0C-3.4 -5 -2.8 -11 0 -14.5C2.8 -11 3.4 -5 0 0Z"/>
</defs></svg>
<div class="ffks-cord h top"><svg width="100%" height="8"><rect width="100%" height="8" fill="url(#ffks-cord-h)"/></svg><span class="ffks-shine"></span></div>
<div class="ffks-cord h bottom"><svg width="100%" height="8"><rect width="100%" height="8" fill="url(#ffks-cord-h)"/></svg><span class="ffks-shine" style="animation-delay:3.5s"></span></div>
<div class="ffks-cord v left"><svg width="8" height="100%"><rect width="8" height="100%" fill="url(#ffks-cord-v)"/></svg><span class="ffks-shine v" style="animation-delay:1.7s"></span></div>
<div class="ffks-cord v right"><svg width="8" height="100%"><rect width="8" height="100%" fill="url(#ffks-cord-v)"/></svg><span class="ffks-shine v" style="animation-delay:5.2s"></span></div>
<svg class="ffks-corner tl" viewBox="0 0 130 130"><use href="#ffks-curls"/><use href="#ffks-runs"/><g transform="translate(40 40) rotate(-12)"><g class="ffks-ny" fill="#efe4d4" fill-opacity=".94" stroke="#8e2038" stroke-width=".7" transform="scale(1.05)">${petals}</g><circle r="3.2" fill="#e767ce"/></g></svg>
<svg class="ffks-corner tr" viewBox="0 0 130 130"><g transform="translate(130 0) scale(-1 1)"><use href="#ffks-curls"/><use href="#ffks-runs" style="animation-delay:2s"/></g><g class="ffks-moonlit"><path class="ffks-moon" d="${moonPath(sky.phase,91.5,37,13)}" fill="#efe4d4"/></g><circle cx="80" cy="50" r="1" fill="#efe4d4" opacity=".7"/><circle cx="106" cy="56" r=".8" fill="#efe4d4" opacity=".6"/></svg>
<svg class="ffks-corner bl" viewBox="0 0 130 130"><g transform="translate(0 130) scale(1 -1)"><use href="#ffks-curls"/><use href="#ffks-runs" style="animation-delay:3.4s"/></g></svg>
<svg class="ffks-corner bl part ffks-sway" viewBox="0 0 130 130"><g transform="translate(14 -6) scale(1.3)"><path d="M15.5 108C18 96 15 86 22 74" fill="none" stroke="#7d8f62" stroke-width="1.3" stroke-linecap="round"/><path d="M17 96c6 -4 12 -2 13 2 -6 2 -10 1 -13 -2z" fill="#6f8556"/><path d="M18 86c-6 -5 -11 -3 -12 1 6 2 9 1 12 -1z" fill="#7d9562"/><g transform="translate(22 72)"><g fill="#f2c9d8" stroke="#a3243f" stroke-width=".5"><path d="M0 0C-3 -3 -3 -7 0 -9C3 -7 3 -3 0 0Z"/><path d="M0 0C-3 -3 -3 -7 0 -9C3 -7 3 -3 0 0Z" transform="rotate(-40)"/><path d="M0 0C-3 -3 -3 -7 0 -9C3 -7 3 -3 0 0Z" transform="rotate(40)"/></g></g></g></svg>
<svg class="ffks-corner br" viewBox="0 0 130 130"><g transform="translate(130 130) scale(-1 -1)"><use href="#ffks-curls"/><use href="#ffks-runs" style="animation-delay:4.6s"/></g><path d="M114.5 114C112 106 104 100 96 98" fill="none" stroke="#7d8f62" stroke-width="1.3" stroke-linecap="round"/><path d="M106 104c-6 -6 -12 -5 -14 -2 5 3 10 4 14 2z" fill="#6f8556"/></svg>
<svg class="ffks-corner br part ffks-lily${lily>.5?' full':''}" viewBox="0 0 130 130" style="opacity:${(.55+.45*lily).toFixed(2)}"><g transform="translate(96 98) rotate(-50) scale(1.15)"><path d="M0 0C-9 -4 -10 -16 0 -24C10 -16 9 -4 0 0Z" fill="#efe6ee" fill-opacity=".92"/><path d="M0 -1C-3 -7 -3 -15 0 -22M0 -1C3 -7 3 -15 0 -22M0 -1C-6 -5 -7 -11 -6 -15M0 -1C6 -5 7 -11 6 -15" fill="none" stroke="#a3243f" stroke-width=".6"/></g></svg>
<span class="ffks-glint ffks-gemglow" style="left:30px;top:30px"></span><span class="ffks-glint ffks-twinkle" style="left:54px;top:26px"></span><span class="ffks-glint ffks-twinkle r" style="right:50px;top:26px;animation-delay:1.5s"></span><span class="ffks-glint ffks-moonglow" style="right:18px;top:17px"></span>
<span class="ffks-foot">you are more than their mirror</span>`;
  wrap.dataset.sky=`${sky.night.toFixed(3)}|${sky.phase.toFixed(3)}|${sky.fromFull.toFixed(2)}`;wrap.dataset.hour=sky.hour==null?'':Number(sky.hour).toFixed(2);
  root.append(wrap);
}

/** The title bar's lock (beta.34). */
function lock(app,root){
  lockButton(root,{locked:clientSheet().locked,onToggle:async()=>{
    const on=!clientSheet().locked,p=app.position??{};
    const patch=on?{locked:true,size:{width:Math.round(p.width),height:Math.round(p.height)},pos:{left:Math.round(p.left),top:Math.round(p.top)}}:{locked:false};
    lockButton(root,{locked:on,onToggle:root.querySelector('.ffks-lock')?.__toggle});
    try{await saveClientSheet(patch);}catch{}
  }});
}
/** The first Keepsake render of a window gives it room (her last size, or 1000×900);
 * with the size locked, her locked size and place. */
function size(app,root,st){
  if(st.sized)return;st.sized=true;
  const c=clientSheet();
  if(c.locked&&c.size){
    const W=globalThis.innerWidth??1600,H=globalThis.innerHeight??1000;
    const width=Math.max(MIN.width,Math.min(W,c.size.width)),height=Math.max(MIN.height,Math.min(H,c.size.height));
    const at=c.pos?{left:Math.max(0,Math.min(W-120,c.pos.left)),top:Math.max(0,Math.min(H-60,c.pos.top))}:{};
    st.sizedFrom={width:app.position?.width,height:app.position?.height};
    try{app.setPosition?.({width,height,...at});}catch{}
    return;
  }
  const pos=app.position??{},want=c.size??DEFAULT;
  const vw=Math.max(MIN.width,(globalThis.innerWidth??1600)-40),vh=Math.max(MIN.height,(globalThis.innerHeight??1000)-40);
  const width=Math.max(MIN.width,Math.min(vw,want.width)),height=Math.max(MIN.height,Math.min(vh,want.height));
  if(Math.abs((pos.width??0)-width)<2&&Math.abs((pos.height??0)-height)<2)return;
  st.sizedFrom={width:pos.width,height:pos.height};
  try{app.setPosition?.({width,height});}catch{}
}
/** Narrow windows (PF2e opens at 750) get the compact layout; her resizes are remembered. */
function watch(app,root,st){
  const W=root.ownerDocument.defaultView;
  const apply=(r=root.getBoundingClientRect())=>{if(r.width)root.classList.toggle('ffks-narrow',r.width<900);if(r.height)root.classList.toggle('ffks-short',r.height<800);};
  // The window element outlives PF2e's re-renders, so its narrow/short classes stay; the observer
  // (which also reports the first size, before the first paint) keeps them right. No layout read here.
  if(st.ro)return;
  if(!W?.ResizeObserver){apply();return;}
  let timer=null,last=null;
  st.ro=new W.ResizeObserver(entries=>{const box=entries[entries.length-1]?.borderBoxSize?.[0];apply(box?{width:box.inlineSize,height:box.blockSize}:undefined);
    const r=root.getBoundingClientRect(),now={width:Math.round(r.width),height:Math.round(r.height)};
    if(!root.classList.contains('ffks')||!now.width||!now.height)return;
    if(last===null){last=now;return;}
    if(Math.abs(now.width-last.width)<4&&Math.abs(now.height-last.height)<4)return;last=now;
    clearTimeout(timer);timer=setTimeout(()=>{if(root.isConnected&&root.classList.contains('ffks')&&!root.classList.contains('minimized')&&!clientSheet().locked)void saveClientSheet({size:now}).catch(()=>{});},700);
  });
  st.ro.observe(root);
}

/* ------------------------------------------------------------------ header */

/** The heartbeat's look for the classes and variables the CSS uses. */
function hbView(b){
  const cls=['ffks-hb'];if(b.still)cls.push('still');else{if(b.tone!=='steady')cls.push(b.tone);if(b.pause)cls.push('hold'+b.pause);}
  if(b.tremor>=.5)cls.push('tremor3');else if(b.tremor>=.3)cls.push('tremor2');else if(b.tremor>0)cls.push('tremor1');
  const w=b.words.length?b.words.join(', '):'steady';
  return {cls:cls.join(' '),beat:(b.period||1)+'s',echo:String(b.echo),word:w.charAt(0).toUpperCase()+w.slice(1)};
}
export function heartbeatSVG(actor,{width=176,height=26}={}){
  const s=heartState(actor),b=heartbeat(s),v=hbView(b),pct=s.max?Math.max(0,Math.min(100,Math.round((s.hp??s.max)/s.max*100))):100,d=esc(b.trace);
  return {html:`<svg class="${v.cls}" width="${width}" height="${height}" viewBox="0 0 200 22" fill="none" role="img" aria-label="Heartbeat: ${esc(v.word)}" style="--beat:${v.beat};--echo:${v.echo}">
<path class="base" d="${d}"/><path class="fillpath" d="${d}" pathLength="100" stroke-dasharray="${pct} 100" style="stroke:${b.color}"/>
${b.echo?`<path class="echo" d="${d}" pathLength="100"/>`:''}${b.bleed?`<path class="bleed" d="${d}" pathLength="100"/>`:''}${b.still?'':`<path class="pulse" d="${d}" pathLength="100"/>`}</svg>`,word:v.word,state:s,beat:b,
    // the beat's light as a glint sliding under a mask of her trace: it runs off the main thread (beta.34)
    glint:b.still?'':`<span class="ffks-hbglint ${v.cls}" aria-hidden="true" style="--beat:${v.beat};width:${width}px;height:${height}px;--m:url(&quot;${traceMask(b.trace)}&quot;)"><i></i></span>`};
}
const masks=new Map();
function traceMask(trace){
  let m=masks.get(trace);if(m)return m;
  m='data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 22"><path d="${trace}" fill="none" stroke="#fff" stroke-width="3.2" stroke-linejoin="round" stroke-linecap="round"/></svg>`);
  masks.set(trace,m);if(masks.size>40)masks.delete(masks.keys().next().value);return m;
}

function unconsciousOf(actor){
  try{return !!(actor?.hasCondition?.('unconscious')||actor?.statuses?.has?.('unconscious')||actor?.statuses?.has?.('dead'));}catch{return false;}
}
function activeConditions(actor){
  const out=new Map();
  try{
    for(const c of actor?.conditions?.active??[]){
      const slug=c?.slug??c?.system?.slug;if(!slug||out.has(slug))continue;
      const value=Number(c.value??c.system?.value?.value)||null;
      out.set(slug,{slug,name:c.name??slug,img:c.img,value,valued:VALUED_CONDITIONS.includes(slug)||!!c.system?.value?.isValued,max:Number(c.system?.value?.max)||null,id:c.id});
    }
  }catch{}
  return [...out.values()];
}

function header(app,form,actor){
  const doc=form.ownerDocument,head=form.querySelector(':scope > header.char-header');
  head.classList.add('ffks-head');
  const name=head.querySelector('h1.char-name'),dots=head.querySelector('.dots'),level=head.querySelector('.char-level .level'),xp=head.querySelector('.char-level .exp-data');
  const seen=lastSeen.get(actor.uuid)??{};
  // her portrait
  const cfg=portraitConfig(actor),hs=heartState(actor),unconscious=unconsciousOf(actor);
  // (Foundry's getRoute drops a trailing slash: route the whole path, not the folder)
  const view=cfg.sheet?portraitView(cfg,{hp:hs.hp,max:hs.max,unconscious},{actorImg:actor.img,root:'assets/hud/'})
    :{mode:'one',stage:'healthy',src:actor.img,pos:'50% 20%',zoom:1,mood:false};
  if(view.keepsake)view.src=moduleRoute(view.src);
  const prev=seen.portrait&&seen.portrait!==view.src?seen.portrait:null;
  const ptr=doc.createElement('div');
  ptr.className=`ffks-ptr mode-${view.mode} mood-${view.stage}${view.mood?'':' mood-soft'}${view.keepsake?' keepsake':''}`;
  ptr.innerHTML=`${prev?`<img class="ffks-ptr-prev" src="${esc(prev)}" alt="" style="object-position:${esc(seen.portraitPos??view.pos)}">`:''}<img class="ffks-ptr-img${prev?' arriving':''}" src="${esc(view.src)}" alt="${esc(actor.name)}" style="object-position:${esc(view.pos)};${view.zoom!==1?`transform:scale(${view.zoom});`:''}"><span class="ffks-ptr-mood"></span><span class="ffks-ptr-fade"></span>
<span class="ffks-ptr-btns"><button type="button" class="ffks-tbtn ffks-ptr-btn" data-ffks-action="portrait" ${actor.isOwner?'':'hidden'}>${iconHTML('ui-upload','s14')}<span>${esc(loc('FILAMENT.Keepsake.ChoosePortrait','Choose a portrait'))}</span></button>${form.querySelector('.image-container img[data-edit]')?`<button type="button" class="ffks-ibtn sm" data-ffks-action="actor-image" title="Her actor image (PF2e's own picker)" aria-label="Change her actor image">${iconHTML('ui-image','s12')}</button>`:''}${form.querySelector('.image-container [data-action="show-image"]')?`<button type="button" class="ffks-ibtn sm" data-ffks-action="show-image" title="Show her art" aria-label="Show her art">${iconHTML('ui-eye','s12')}</button>`:''}</span>`;
  // her name, epithet, ancestry and class, level and XP
  const id=doc.createElement('div');id.className='ffks-id';
  const eyebrow=doc.createElement('span');eyebrow.className='ffks-eyebrow';eyebrow.textContent='Little dusk';
  id.append(eyebrow);
  if(name){name.classList.add('ffks-name');id.append(name);if((actor.name??'').length>12)name.classList.add('long');}
  const row=doc.createElement('div');row.className='ffks-idrow';
  const chip=(item,ic)=>item?`<button type="button" class="ffks-idchip" data-ffks-action="open-item" data-item-id="${esc(item.id)}" title="${esc(item.name)}">${iconHTML(ic,'s14')}<span>${esc(item.name)}</span></button>`:'';
  row.innerHTML=chip(actor.ancestry,'ft-ancestry')+chip(actor.class,'ft-class');
  if(level){level.classList.add('ffks-level');level.insertAdjacentHTML('afterbegin',`<svg class="ffks-gem" viewBox="0 0 34 34" aria-hidden="true"><path d="M17 1.5L32.5 17 17 32.5 1.5 17z"/><path d="M17 6.5L27.5 17 17 27.5 6.5 17z" class="in"/></svg>`);row.append(level);}
  if(xp){xp.classList.add('ffks-xp');tag(xp,'head','xp');row.append(xp);}
  id.append(row);
  // her heartbeat, HP and hero petals
  const hb=heartbeatSVG(actor),hp=actor.system?.attributes?.hp??{};
  const hprow=doc.createElement('div');hprow.className='ffks-hprow';
  hprow.innerHTML=`<span class="ffks-hbwrap">${hb.html}${hb.glint}</span><span class="ffks-hpnum"><b>${esc(hp.value??'—')}</b><span class="max"> / ${esc(hp.max??'—')}</span>${Number(hp.temp)>0?`<span class="temp"> +${esc(hp.temp)}</span>`:''}</span><span class="ffks-hbword">${esc(hb.word)}</span>`;
  const flights=dots?(dots.classList.add('ffks-hero'),hprow.append(dots),petals(dots,actor,seen,el(app.element))):[];
  id.append(hprow);
  // the conditions on her
  const chips=doc.createElement('div');chips.className='ffks-chips';
  const conds=activeConditions(actor),few=conds.length<=3;
  chips.innerHTML=conds.map(c=>{
    const good=GOOD_CONDITIONS.includes(c.slug),known=conditionIcon(c.slug)!=='c-generic';
    return `<button type="button" class="ffks-cchip${good?' good':' bad'}${c.valued?'':' flag'}${few?' named':''}" data-ffks-action="cond" data-slug="${esc(c.slug)}" title="${esc(chipTip(c.name,c.value,c.valued,c.max))}">${known||!c.img?iconHTML(conditionIcon(c.slug),`s14${c.slug==='dying'?' '+dyingClass(actor):''}`):`<img src="${esc(c.img)}" alt="">`}<span class="nm">${esc(c.name)}</span>${c.valued&&c.value?`<span class="v">${esc(c.value)}</span>`:''}</button>`;
  }).join('')+(actor.isOwner?`<button type="button" class="ffks-ibtn sm dash" data-ffks-action="add-condition" title="Add a condition" aria-label="Add a condition">${iconHTML('ui-plus','s12')}</button>`:'');
  id.append(chips);
  portraitFallback(ptr,actor);
  head.prepend(ptr,id);
  lastSeen.set(actor.uuid,{...seen,portrait:view.src,portraitPos:view.pos,hero:Number(actor.system?.resources?.heroPoints?.value),flights});
  if(lastSeen.size>40)lastSeen.delete(lastSeen.keys().next().value);
  // the line under the header, with a petal in the middle
  if(!form.querySelector(':scope > .ffks-rule'))head.insertAdjacentHTML('afterend',`<div class="ffks-rule" aria-hidden="true"><svg viewBox="0 0 940 20" preserveAspectRatio="none"><path d="M40 10H448M492 10H900" stroke="#8a6d45" stroke-width="1"/><path d="M455 10a15 6 0 0 1 30 0" fill="none" stroke="#8a6d45"/></svg><svg class="star" viewBox="-8 -8 16 16"><g fill="#f3c1df">${[0,72,144,216,288].map(a=>`<path d="M0 0C-1.6 -2.4 -1.3 -5.4 0 -7C1.3 -5.4 1.6 -2.4 0 0Z" transform="rotate(${a})"/>`).join('')}</g><circle r="1.4" fill="#e767ce"/></svg></div>`);
  // clicks on the new pieces
  head.addEventListener('click',onHeadClick(app,actor));
  head.addEventListener('contextmenu',onHeadClick(app,actor,true));
}

/** Her portrait is never blank: an image that won't load gives way to her
 * Keepsake art, then to her actor image, then to her initial on the plum. */
function portraitFallback(ptr,actor){
  const img=ptr.querySelector('.ffks-ptr-img');if(!img)return;
  const tries=[moduleRoute('assets/hud/v611/portrait-healthy.webp'),actor?.img,'icons/svg/mystery-man.svg'].filter(Boolean);
  const next=()=>{
    const cur=img.getAttribute('src');let i=tries.indexOf(cur);
    const n=tries.slice(i+1).find(t=>t!==cur);
    if(n){img.classList.add('fallback');img.setAttribute('src',n);return;}
    img.removeEventListener('error',next);img.hidden=true;ptr.classList.add('ffks-ptr-empty');
    ptr.dataset.initial=String(actor?.name??'?').trim().charAt(0).toUpperCase();
  };
  img.addEventListener('error',next);
  // (an image that failed before the listener was on)
  if(img.complete&&img.getAttribute('src')&&!img.naturalWidth)queueMicrotask(next);
  const prev=ptr.querySelector('.ffks-ptr-prev');prev?.addEventListener('error',()=>prev.remove(),{once:true});
}

/** Before her Hero Points change (on the screen that changes them), note how
 * many she had, so the redraw that follows always knows what she spent or won,
 * even if this sheet hadn't drawn her yet (beta.33: the first spend after
 * opening could find no record and simply drop the petal). */
export function noteHeroBefore(actor,changes){
  try{
    const v=foundry?.utils?.getProperty?.(changes,'system.resources.heroPoints.value')??changes?.system?.resources?.heroPoints?.value??changes?.['system.resources.heroPoints.value'];
    if(v===undefined||!actor?.uuid)return;
    const old=Number(actor.system?.resources?.heroPoints?.value);if(!Number.isFinite(old))return;
    const seen=lastSeen.get(actor.uuid)??{};lastSeen.set(actor.uuid,{...seen,hero:old});
  }catch{}
}

/** Her Hero Points (PF2e's own pips) as petals. A new one is one of the
 * Nytheris's own petals: it comes loose from the flower in the top left
 * corner and floats down to its place, and the flower grows it back once it
 * has landed (each new point takes a petal of its own). A spent one lifts and
 * floats down to the bottom of the sheet. The falling petals are drawn in a
 * layer of their own at the window's root, so they keep falling if PF2e
 * redraws the sheet meanwhile (a new one's place stays empty until it lands).
 * Returns the flights still under way, for the next render. */
function petals(dots,actor,seen,root){
  const pips=[...dots.querySelectorAll('.pips > i')],value=Number(actor.system?.resources?.heroPoints?.value),before=seen.hero;
  pips.forEach((i,k)=>{i.classList.add('ffks-petal');i.classList.toggle('held',k<value);i.style.setProperty('--k',k);});
  const now=Date.now();
  // (flights belong to this window: a sheet closed and opened again starts afresh)
  let flights=(seen.flights??[]).filter(f=>f.end>now&&f.root===root);
  if(Number.isFinite(before)&&Number.isFinite(value)&&before!==value)traceHero({where:'sheet',from:before,to:value,did:!root?'no window':petalsStill(root)?'still (reduced motion)':'flies'});
  if(Number.isFinite(before)&&Number.isFinite(value)&&before!==value&&root&&!petalsStill(root)){
    const a=Math.min(before,value),b=Math.min(Math.max(before,value),pips.length),kind=value<before?'leaving':'arriving';
    for(let k=a;k<b;k++){
      // spent before it landed: it fades where it is (there's nothing in the row to lift);
      // a spent one still floating away when it comes back just carries on, and a new one falls
      const air=flights.find(f=>f.k===k&&f.kind==='arriving');
      if(air&&kind==='leaving'){fade(air);continue;}
      const f={kind,k,root,end:now+PETAL_MAX_MS,el:null,anim:null,flight:null};flights.push(f);
      const delay=kind==='arriving'?(k-a)*700:(b-1-k)*450;
      requestAnimationFrame(()=>fly(root,f,delay));
    }
    flights=flights.filter(f=>f.end>now);
  }
  // a petal on its way stays hidden in its place until it lands
  for(const f of flights)if(f.kind==='arriving'&&f.k<value&&pips[f.k])pips[f.k].classList.add('ffks-awaiting');
  return flights;
}
/** A new petal that won't land after all (she spent it first). */
function fade(f){
  f.end=0;f.stopped=true;
  const flight=f.flight;f.root=f.el=f.anim=f.flight=null;
  flight?.fade(PETAL_HANDOVER_MS);
}
/** Reduced motion (hers or the system's): petals simply appear and go. (Frame
 * motion Off stills the frame's own loops; a Hero Point won or spent is news,
 * so it still flies.) */
function petalsStill(root){
  let reduced=false;try{reduced=!!game.settings.get(ID,'reducedMotion');}catch{}
  return reduced||!!root.ownerDocument.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
}
const pipAt=(root,k)=>root.querySelectorAll(':scope > .window-content .ffks-head .ffks-hero .pips > i')[k]??null;
/** Its place in the row shows again (and joins the others' sway). */
function reveal(root,k){
  const pip=pipAt(root,k);if(!pip)return;
  pip.classList.remove('ffks-awaiting');void (pip.ownerDocument.defaultView??globalThis).getComputedStyle(pip).opacity;onBeat(pip);
  // (it lands with a small bloom of light)
  try{pip.animate([{filter:'drop-shadow(0 0 0 rgba(231,103,206,0)) brightness(1)'},{filter:'drop-shadow(0 0 7px rgba(231,103,206,.95)) brightness(1.35)',offset:.3},{filter:'drop-shadow(0 0 2px rgba(231,103,206,.35)) brightness(1)'}],{duration:900,easing:'ease-out'});}catch{}
}
/** One petal's flight, in the window's own layer. */
function fly(root,f,delay=0){
  if(f.stopped)return;
  const pip=pipAt(root,f.k);
  if(!pip||!root.isConnected||!root.classList.contains('ffks')){traceHero({where:'sheet',did:!pip?'no pip in the row':'window gone'});f.end=0;pip?.classList.remove('ffks-awaiting');return;}
  const R=root.getBoundingClientRect(),P=pip.getBoundingClientRect(),scale=R.width/(root.offsetWidth||R.width)||1;
  const toLayer=(x,y)=>({x:(x-R.left)/scale,y:(y-R.top)/scale});
  if(f.kind==='arriving'){
    // one of the Nytheris's petals in the top left corner comes loose
    const corner=root.querySelector(':scope > .ffks-frame .ffks-corner.tl');
    const flower=readFlower(corner,[...(corner?.querySelectorAll('use[href="#ffks-petal"]')??[])].map(u=>({el:u,shape:u})),toLayer);
    const flight=arrive({layer:root,cls:'ffks-flysvg',petals:flower,slot:readSlot(pip,pip.offsetWidth||18,pip.offsetHeight||23,toLayer),delay,
      angleAt:t=>rowSwayAngle(t+f.k*1700)});
    // (no petal left to take: it simply appears)
    if(!flight){traceHero({where:'sheet',did:`no petal on the flower (${flower.length} read)`});f.end=0;reveal(root,f.k);return;}
    f.flight=flight;f.el=flight.el;f.end=flight.end;
    flight.landed.then(()=>{if(f.stopped)return;f.end=0;f.root=f.el=f.flight=null;reveal(root,f.k);flight.handover(PETAL_HANDOVER_MS);},()=>{});
    return;
  }
  const petal=root.ownerDocument.createElement('span');petal.className='ffks-flypetal';petal.setAttribute('aria-hidden','true');
  petal.style.cssText=`left:${(P.left-R.left)/scale}px;top:${(P.top-R.top)/scale}px;width:${P.width/scale}px;height:${P.height/scale}px`;
  const spec=petalLeaving({fall:(R.bottom-P.bottom)/scale-34});
  root.append(petal);f.el=petal;
  const anim=f.anim=petal.animate(spec.keyframes,{duration:spec.duration,delay,easing:spec.easing,fill:'both'});
  f.end=Date.now()+delay+spec.duration;
  const land=()=>{f.end=0;f.root=f.el=f.anim=null;petal.remove();};
  anim.finished.then(land,land);
}

function onHeadClick(app,actor,right=false){
  return event=>{
    const t=event.target.closest?.('[data-ffks-action]');if(!t)return;
    const action=t.dataset.ffksAction;
    if(action==='portrait'){event.preventDefault();void import('./studio.mjs?v=12.0.1').then(m=>m.openPortraitStudio(actor)).catch(e=>ui.notifications?.error(e.message));return;}
    if(action==='open-item'){event.preventDefault();const item=actor.items?.get?.(t.dataset.itemId);item?.sheet?.render(true);return;}
    // PF2e's own actor image controls (their image stays in the sheet, hidden, so its picker and art popout still work)
    if(action==='actor-image'||action==='show-image'){event.preventDefault();const f=t.closest('form');
      (action==='actor-image'?f?.querySelector('.image-container img[data-edit]'):f?.querySelector('.image-container [data-action="show-image"]'))?.click();return;}
    if(action==='add-condition'){event.preventDefault();showTab(app,'effects');setTimeout(()=>el(app.element)?.querySelector('.ffks-palette')?.scrollIntoView?.({block:'center',behavior:'smooth'}),60);return;}
    if(action==='cond'){event.preventDefault();if(!actor.isOwner)return;const slug=t.dataset.slug;void stepCondition(actor,slug,right?-1:1);}
  };
}
/** Raise (or lower) a condition the way the mock-up's chips do: past its maximum it ends. */
export async function stepCondition(actor,slug,dir=1){
  try{
    const c=activeConditions(actor).find(x=>x.slug===slug);
    if(!c){if(dir>0)await actor.increaseCondition?.(slug);return;}
    if(!c.valued){await actor.decreaseCondition?.(slug,{forceRemove:true});return;}
    if(dir<0){await actor.decreaseCondition?.(slug);return;}
    if(c.max&&c.value>=c.max){await actor.decreaseCondition?.(slug,{forceRemove:true});return;}
    await actor.increaseCondition?.(slug);
  }catch(e){ui.notifications?.error?.(`Keepsake sheet: ${e?.message??e}`);}
}

/* ------------------------------------------------------------------ sidebar */

const SIDE_MARKERS=[['hp','.hitpoints'],['stamina','ol.stamina'],['ac','.armor-class'],['resources','li.special-resource'],['perception','section.perception'],
  ['initiative','section.initiative'],['saves','ul.saves'],['immunities','ol.immunities'],['weaknesses','ol.weaknesses'],['resistances','ol.resistances']];
const PANELS=[['hp','st-hp',['hp','stamina']],['defence','st-ac',['ac','saves']],['perception','st-perception',['perception','initiative']],['resources','st-resources',['resources']],['iwr','ui-lock',['immunities','weaknesses','resistances']]];
const GROUP_ICONS={hp:'st-hp',stamina:'st-hp',ac:'st-ac',saves:'st-fort',resources:'st-resources',perception:'st-perception',initiative:'st-initiative',immunities:'im-death',weaknesses:'d-crit',resistances:'st-shield'};
const PANEL_TITLES={hp:['PF2E.HitPointsHeader','Hit Points'],defence:[null,'Defence'],perception:['PF2E.PerceptionHeader','Perception'],resources:['PF2E.Actor.Resources','Resources'],iwr:[null,'Resist · Weak · Immune']};

function sidebar(app,form,actor){
  const aside=form.querySelector(':scope > aside'),bar=aside?.querySelector('.sidebar');if(!bar||bar.dataset.ffks)return;
  bar.dataset.ffks='1';aside.classList.add('ffks-side');
  const doc=form.ownerDocument;
  // PF2e's sidebar is a flat list: each <header> starts a group. Collect them.
  const groups=[];let cur=null;
  for(const node of [...bar.children]){
    if(node.localName==='header'){cur={nodes:[node],key:null};groups.push(cur);continue;}
    if(!cur){cur={nodes:[],key:null};groups.push(cur);}
    cur.nodes.push(node);
  }
  for(const g of groups){for(const [key,sel] of SIDE_MARKERS)if(g.nodes.some(n=>n.matches?.(sel)||n.querySelector?.(sel))){g.key=key;break;}}
  const byKey=new Map(groups.filter(g=>g.key).map(g=>[g.key,g]));
  const used=new Set();
  for(const [pid,ic,keys] of PANELS){
    const parts=keys.map(k=>byKey.get(k)).filter(Boolean);if(!parts.length)continue;
    const panel=doc.createElement('section');panel.className=`ffks-panel ffks-sp-${pid}`;panel.dataset.ffksPanel=pid;panel.dataset.ffksFlip=`side-${pid}`;
    panel.innerHTML=`<span class="ffks-inner"><i class="tl"></i><i class="tr"></i><i class="bl"></i><i class="br"></i></span>`;
    for(const g of parts){
      const box=doc.createElement('div');box.className=`ffks-sg ffks-sg-${g.key}`;box.dataset.ffksGroup=g.key;
      for(const n of g.nodes)box.append(n);
      // PF2e's own section heading becomes the Keepsake one (its buttons stay)
      const h=box.querySelector(':scope > header');if(h){h.classList.add('ffks-sh');h.querySelector('h2')?.insertAdjacentHTML('afterbegin',iconHTML(GROUP_ICONS[g.key]??ic,'s14'));}
      panel.append(box);used.add(g);
    }
    bar.append(panel);
  }
  // anything we don't know (other modules) stays, after the panels
  for(const g of groups)if(!used.has(g)){const box=doc.createElement('section');box.className='ffks-panel ffks-sp-other';for(const n of g.nodes)box.append(n);bar.append(box);}
  // dying and wounded: diamonds that beat with her heart, and the dying icon
  const attrs=actor.system?.attributes??{},stage=dyingClass(actor);
  for(const a of bar.querySelectorAll('a.condition-pips[data-condition]')){
    const cond=a.dataset.condition,pips=a.querySelector('.pips');if(!pips)continue;
    a.classList.add('ffks-track',`ffks-track-${cond}`);
    a.insertAdjacentHTML('afterbegin',iconHTML(cond==='dying'?'c-dying':'c-wounded',`s14 ffks-track-ic${cond==='dying'&&stage?' '+stage:''}`));
    if(cond==='dying'&&stage)pips.classList.add(stage);
    [...pips.children].forEach((i,k)=>{i.classList.add('ffks-pip');i.style.setProperty('--i',k);
      if(i.classList.contains('fa-skull'))i.classList.add('doom');else if(i.classList.contains('fa-solid'))i.classList.add('on');});
  }
  // her shield: "64 / 80 Shield HP" on one line, Broken below it
  const shield=bar.querySelector('.armor-class > .shield'),shieldMax=bar.querySelector('.armor-class > .shield-max-status:not(.disabled) .max .data-value');
  if(shield&&shieldMax){shieldMax.closest('.max')?.classList.add('ffks-moved');shieldMax.classList.add('ffks-shield-max');shield.querySelector(':scope > .data-value')?.after(shieldMax);}
  for(const li of bar.querySelectorAll('ul.saves > li[data-save]')){
    const ic={fortitude:'st-fort',reflex:'st-ref',will:'st-will'}[li.dataset.save];if(ic)li.insertAdjacentHTML('afterbegin',iconHTML(ic,'s14 ffks-save-ic'));
  }
  const hpIn=bar.querySelector('.hitpoints .current-hp input[name="system.attributes.hp.value"]');
  if(hpIn&&!hpIn.disabled&&!hpIn.readOnly){
    const step=(dir,e)=>{e.preventDefault();const n=e.shiftKey?5:e.ctrlKey||e.metaKey?10:1;hpIn.value=`${dir<0?'-':'+'}${n}`;hpIn.dispatchEvent(new Event('change',{bubbles:true}));};
    const mk=(dir)=>{const b=form.ownerDocument.createElement('button');b.type='button';b.className=`ffks-ibtn ffks-hpstep ${dir<0?'down':'up'}`;
      b.title=`${dir<0?'Lose':'Gain'} 1 HP · Shift 5 · Ctrl 10 (or type −5 or +5 in the box)`;b.setAttribute('aria-label',dir<0?'Lose hit points':'Gain hit points');
      b.innerHTML=iconHTML(dir<0?'ui-minus':'ui-plus','s12');b.addEventListener('click',e=>step(dir,e));return b;};
    const cont=hpIn.closest('.container');cont?.prepend(mk(-1));(hpIn.closest('.hp-big')?.querySelector(':scope > .max-hp')??cont)?.after(mk(1));
  }
  // rank badges: PF2e's own words become one letter in PF2e's own colours
  ranks(bar);
  // temp HP, dying, shield, senses: tags for the switches
  tag(bar.querySelector('.hitpoints .temp-hp'),'side','temp');
  tag(bar.querySelector('.hitpoints .hp-small'),'side','dying');
  restRow(bar.querySelector('.hitpoints .hp-small'));
  for(const n of bar.querySelectorAll('.armor-class .shield, .armor-class .shield-stats, .armor-class .shield-max-status'))tag(n,'side','shield');
  tag(bar.querySelector('section.perception .senses'),'side','senses');
  tag(bar.querySelector('.ffks-sg-stamina'),'side','stamina');
  tag(bar.querySelector('.ffks-sg-saves'),'side','saves');
  tag(bar.querySelector('.ffks-sg-initiative'),'side','initiative');
  tag(bar.querySelector('.ffks-sg-perception'),'side','perception');
  tag(bar.querySelector('.ffks-sp-resources'),'side','resources');
  tag(bar.querySelector('.ffks-sp-iwr'),'side','iwr');
  // an empty IWR panel says so, quietly
  const iwr=bar.querySelector('.ffks-sp-iwr');
  if(iwr&&!iwr.querySelector('li.tag')){iwr.classList.add('empty');iwr.insertAdjacentHTML('beforeend','<span class="ffks-note">Nothing special</span>');}
}
export function dyingClass(actor){
  const a=actor?.system?.attributes??{};
  return dyingStage({dying:a.dying?.value,doomed:a.doomed?.value,max:a.dying?.max});
}
/** PF2e's .pf-rank badges (and its rank selects) get a letter, coloured by PF2e's own variables. */
function ranks(scope){
  for(const r of scope.querySelectorAll('.pf-rank[data-rank]')){
    if(r.dataset.ffksLetter||r.closest('.ffks-rkwrap'))continue;const n=Number(r.dataset.rank)||0;
    if(r.localName==='select'){
      // PF2e's own select stays (clear, on top) so a click still opens it; a diamond shows through
      const wrap=r.ownerDocument.createElement('span');wrap.className='ffks-rkwrap';wrap.title=r.selectedOptions?.[0]?.textContent?.trim()??'';
      wrap.innerHTML=`<span class="ffks-rk r${n}" data-ffks-letter="${rankLetter(n)}" aria-hidden="true"></span>`;
      r.before(wrap);wrap.append(r);r.classList.add('ffks-rksel');continue;
    }
    r.dataset.ffksLetter=rankLetter(n);r.classList.add('ffks-rk',`r${n}`);
    if(!r.title)r.title=r.textContent.trim();
  }
}
/** Section headers' words in a span of their own, so they can sit on the divider line optically (beta.34). */
function headerTexts(form){
  for(const h of form.querySelectorAll('.sheet-content header:not(.ffks-keep)')){
    for(const n of [...h.childNodes])if(n.nodeType===3&&n.textContent.trim()){const s=form.ownerDocument.createElement('span');s.className='ffks-ht';s.textContent=n.textContent.trim();n.replaceWith(s);}
  }
}
/** Rest, and any button a module adds beside it (PF2e Dailies' cup...), side by side on the Wounded
 * row instead of stacked (beta.35). The same elements are moved, so their clicks still work. */
function restRow(hs){
  if(!hs?.isConnected&&!hs?.parentNode)return;
  const extra=[...hs.children].filter(c=>!c.classList.contains('ffks-track')&&!c.classList.contains('ffks-hpacts')&&c.dataset.action!=='recovery-check');
  if(!extra.length)return;
  let row=hs.querySelector(':scope > .ffks-hpacts');
  if(!row){row=hs.ownerDocument.createElement('div');row.className='ffks-hpacts';hs.append(row);}
  // (rest first, then the others in their own order)
  extra.sort((a,b)=>(b.classList.contains('rest')?1:0)-(a.classList.contains('rest')?1:0));
  for(const e of extra)e.classList.contains('rest')?row.prepend(e):row.append(e);
  // (more than two: they get a row of their own under the tracks)
  hs.classList.toggle('ffks-acts-row',row.children.length>2);
}
function tag(node,scope,key,flip=true){
  if(!node)return null;node.dataset.ffksField=fieldKey(scope,key);if(flip&&!node.dataset.ffksFlip)node.dataset.ffksFlip=`${scope}-${key}`;return node;
}

/* ------------------------------------------------------------------ tab bar */

function nav(app,form,actor){
  const bar=form.querySelector(':scope > nav.sheet-navigation');if(!bar||bar.dataset.ffks)return;bar.dataset.ffks='1';bar.classList.add('ffks-nav');
  for(const a of bar.querySelectorAll(':scope > a.item[data-tab]')){
    const t=SHEET_TABS.find(x=>x[0]===a.dataset.tab);
    a.classList.add('ffks-tabi');
    a.insertAdjacentHTML('beforeend',`${iconHTML(t?t[2]:'tab-module','ffks-tab-ic')}<span class="tl">${esc(tabLabel(a.dataset.tab))}</span><span class="thread"></span><svg class="needle" width="8" height="10" viewBox="0 0 8 10" aria-hidden="true"><path d="M4 0l4 5-4 5-4-5z"/></svg>`);
  }
  const menu=form.ownerDocument.createElement('button');menu.type='button';menu.className='ffks-ibtn ffks-menu-btn';menu.title='What her sheet shows';menu.setAttribute('aria-label','Show or hide tabs and fields');menu.setAttribute('aria-haspopup','dialog');
  menu.innerHTML=iconHTML('ui-dots','s18');
  menu.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();void import('./menu.mjs?v=12.0.1').then(m=>m.toggleSheetMenu(app,menu)).catch(e=>console.error(e));});
  bar.append(menu);
  bar.addEventListener('click',event=>{if(event.target.closest?.('a.item[data-tab]'))form.classList.remove('ffks-still');},true);
}
export function activeTab(app){
  const root=el(app?.element);return root?.querySelector('nav.sheet-navigation a.item.active')?.dataset?.tab??app?._tabs?.[0]?.active??'character';
}
export function showTab(app,tab){
  el(app?.element)?.querySelector?.('form.ffks-form')?.classList.remove('ffks-still');
  try{const t=app?._tabs?.find?.(x=>x.group==='primary'||(x._navSelector??x.navSelector)==='nav.sheet-navigation')??app?._tabs?.[0];if(t?.activate){t.activate(tab,{triggerCallback:true});return;}}catch{}
  el(app?.element)?.querySelector(`nav.sheet-navigation a.item[data-tab="${tab}"]`)?.click();
}

/* ------------------------------------------------------------------ tabs */

function tabs(app,form,actor){
  const body=form.querySelector('section.sheet-body .sheet-content')??form;
  const tab=id=>body.querySelector(`:scope > .tab[data-tab="${id}"]`);
  try{character(tab('character'),actor);}catch(e){console.warn('Keepsake sheet · character',e);}
  try{actions(tab('actions'));}catch(e){console.warn('Keepsake sheet · actions',e);}
  try{inventory(tab('inventory'));}catch(e){console.warn('Keepsake sheet · inventory',e);}
  try{spells(tab('spellcasting'));}catch(e){console.warn('Keepsake sheet · spells',e);}
  try{crafting(tab('crafting'));}catch(e){console.warn('Keepsake sheet · crafting',e);}
  try{proficiencies(tab('proficiencies'));}catch(e){console.warn('Keepsake sheet · proficiencies',e);}
  try{feats(tab('feats'));}catch(e){console.warn('Keepsake sheet · feats',e);}
  try{effects(tab('effects'),actor,app);}catch(e){console.warn('Keepsake sheet · effects',e);}
  try{biography(tab('biography'));}catch(e){console.warn('Keepsake sheet · biography',e);}
}

const DETAIL_ICONS={ancestry:'ft-ancestry',heritage:'ft-heritage',background:'ft-background',class:'ft-class',deity:'d-holy'};
const ATTR_ICONS={str:'attr-str',dex:'attr-dex',con:'attr-con',int:'attr-int',wis:'attr-wis',cha:'attr-cha'};
function character(t,actor){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  const abcd=t.querySelector('.abcd');
  if(abcd){
    abcd.classList.add('ffks-ids');
    for(const [type,ic] of Object.entries(DETAIL_ICONS)){
      const d=abcd.querySelector(`:scope > .detail.${type}`);if(!d)continue;
      d.classList.add('ffks-tile');tag(d,'character',type);
      d.insertAdjacentHTML('afterbegin',`<span class="ffks-wimg">${iconHTML(ic,'s22')}</span>`);
    }
    // her archetypes (dedications), read from her feats
    const archetypes=archetypesOf(actor);
    abcd.insertAdjacentHTML('beforeend',`<div class="detail ffks-tile ffks-archetype${archetypes?' selected':''}" data-ffks-field="character.archetype" data-ffks-flip="character-archetype"><span class="ffks-wimg">${iconHTML('ft-archetype','s22')}</span><span class="details-label">Archetypes</span><h3><span class="value">${esc(archetypes||'None yet')}</span></h3></div>`);
  }
  // (long names take two lines; the whole name is always in its tooltip)
  for(const v of t.querySelectorAll('.ffks-tile > h3 .value')){const txt=(v.textContent??'').trim(),tile=v.closest('.ffks-tile');
    tile.classList.toggle('ffks-long',txt.length>15);if(txt&&!v.title)v.title=txt;}
  tag(t.querySelector('.subsection.attributes'),'character','attributes');
  tag(t.querySelector('.subsection.speeds'),'character','speeds');
  tag(t.querySelector('.subsection.languages'),'character','languages');
  for(const li of t.querySelectorAll('.subsection.attributes li.attribute[data-attribute]')){
    // a coin: her attribute's icon and modifier inside, its name below (PF2e's key/apex marks stay)
    li.classList.add('ffks-coin');const ic=ATTR_ICONS[li.dataset.attribute],mod=li.querySelector('h3.modifier');
    if(mod){const face=li.ownerDocument.createElement('span');face.className='ffks-coinface';face.innerHTML=ic?iconHTML(ic,'s14'):'';li.prepend(face);face.append(mod);
      // (the sign set small beside the number)
      const m=/^\s*([+\-\u2212])?\s*(\d+)\s*$/.exec(mod.textContent??'');
      if(m){const n=Number(m[2]),neg=m[1]==='-'||m[1]==='\u2212';li.classList.toggle('neg',neg&&n>0);li.classList.toggle('zero',n===0);
        mod.innerHTML=`${m[1]&&n>0?`<span class="sg">${neg?'\u2212':'+'}</span>`:''}${n}`;}
      // PF2e's key and apex marks become small badges on the coin (the apex picker stays a link)
      const key=li.querySelector('h2.abbreviation > i.key');li.classList.toggle('ffks-keyattr',!!key);if(key){key.classList.add('ffks-badge','ffks-key');face.append(key);}
      const apex=li.querySelector('h2.abbreviation > i.apex')??li.querySelector('h2.abbreviation > a:has(> i.apex)');if(apex){apex.classList.add('ffks-badge','ffks-apex');face.append(apex);}}
  }
  // section heads get their icons
  for(const [sel,ic] of [['.subsection.attributes > header','attr-str'],['.subsection.speeds > header','st-speed'],['.subsection.languages > header','st-languages']]){
    const h=t.querySelector(sel);if(h&&!h.querySelector(':scope > .ffks-ic'))h.insertAdjacentHTML('afterbegin',iconHTML(ic,'s14'));
  }
  for(const s of t.querySelectorAll('.subsection.speeds .speed')){
    const label=(s.querySelector('.label')?.textContent??'').toLowerCase(),ic=/swim/.test(label)?'sp-swim':/climb/.test(label)?'sp-climb':/fly/.test(label)?'sp-fly':/burrow/.test(label)?'sp-burrow':'sp-land';
    s.classList.add('ffks-speed');s.insertAdjacentHTML('afterbegin',iconHTML(ic,'s14'));
  }
  // movement and languages share a row
  const sp=t.querySelector('.subsection.speeds'),la=t.querySelector('.subsection.languages');
  if(sp&&la&&!t.querySelector('.ffks-ml')){const ml=t.ownerDocument.createElement('div');ml.className='ffks-ml';sp.before(ml);ml.append(sp,la);}
  // her traits and size get their own row under them (as agreed)
  const traits=abcd?.querySelector(':scope > ul.traits');
  if(traits){const row=t.ownerDocument.createElement('div');row.className='ffks-traitrow';row.dataset.ffksFlip='character-traits';
    row.innerHTML=`<span class="ffks-sec-h">${iconHTML('ft-heritage','s14')}<span class="t">${esc(loc('PF2E.TraitsLabel','Traits'))}</span></span>`;
    (t.querySelector('.ffks-ml')??t.querySelector('.subsection.attributes')??abcd).after(row);row.append(traits);tag(row,'character','traits');}
  // her details: gender, age, ethnicity, nationality
  const bg=t.querySelector('.subsection.background');
  if(bg){bg.classList.add('ffks-details');
    for(const input of bg.querySelectorAll('input[name^="system.details."]')){
      const key=input.name.split('.')[2],label=input.closest('label');
      if(['gender','age','ethnicity','nationality'].includes(key)&&label){label.classList.add('ffks-dtile');tag(label,'character',key);}
    }
    if(!bg.previousElementSibling?.classList?.contains('ffks-sec-h'))bg.insertAdjacentHTML('beforebegin',`<div class="ffks-sec-h ffks-details-h" data-ffks-flip="character-details-h">${iconHTML('b-attitude','s14')}<span class="t">Details</span><span class="ffks-line"></span></div>`);
  }
}
function archetypesOf(actor){
  try{
    const feats=actor?.itemTypes?.feat??[];
    const names=feats.filter(f=>{const tr=f.system?.traits?.value??[];return tr.includes('dedication')&&tr.includes('archetype');})
      .map(f=>String(f.name).replace(/\s*Dedication\s*$/i,'').trim());
    return [...new Set(names)].join(' · ');
  }catch{return '';}
}

function actions(t){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  const enc=t.querySelector('.actions-panel[data-tab="encounter"]');if(!enc)return;
  // PF2e's roll-option toggles
  const toggles=enc.querySelector(':scope > ul.option-toggles');if(toggles){toggles.dataset.ffksFlip='actions-toggles';tag(toggles,'actions','toggles');}
  // Attacks: the header, elemental blasts and strikes
  const strikes=enc.querySelector(':scope > ol.strikes-list'),blasts=enc.querySelector(':scope > ol.elemental-blasts'),first=blasts??strikes;
  const head=first?.previousElementSibling?.localName==='header'?first.previousElementSibling:null;
  if(head){head.dataset.ffksField='actions.strikes';head.dataset.ffksFlip='actions-strikes-h';}
  if(blasts){blasts.dataset.ffksField='actions.strikes';blasts.dataset.ffksFlip='actions-blasts';}
  if(strikes){strikes.dataset.ffksField='actions.strikes';strikes.dataset.ffksFlip='actions-strikes';
    for(const n of strikes.querySelectorAll('.auxiliary-actions'))n.dataset.ffksField='actions.handling';
    for(const n of strikes.querySelectorAll('.ammo'))n.dataset.ffksField='actions.ammo';}
  // the action, reaction and free-action sections (header + list each; PF2e's ids action, reaction, free)
  const KEYS={action:'actionlist',reaction:'reactions',free:'free'},order=['actionlist','reactions','free'];
  const heads=[...enc.querySelectorAll(':scope > header')].filter(h=>h!==head&&h.nextElementSibling?.matches?.('ol.actions-list:not(.strikes-list):not(.elemental-blasts)'));
  heads.forEach((h,k)=>{
    const key=KEYS[h.querySelector('[data-action-type]')?.dataset.actionType]??order[k]??null;if(!key)return;
    h.dataset.ffksField=`actions.${key}`;h.nextElementSibling.dataset.ffksField=`actions.${key}`;h.dataset.ffksFlip=`actions-${key}-h`;h.nextElementSibling.dataset.ffksFlip=`actions-${key}`;
  });
}

function inventory(t){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  const coin=t.querySelector('.coinage');
  tag(coin?.querySelector('.currency'),'inventory','coins');
  tag(coin?.querySelector('.wealth'),'inventory','wealth');
  tag(t.querySelector('header.inventory-header'),'inventory','search');
  tag(t.querySelector('.inventory-bottom-summary .encumbrance'),'inventory','bulk');
  tag(t.querySelector('.inventory-bottom-summary .invested-total'),'inventory','invested');
  // coins as Keepsake medallions (PF2e's own counts and buttons stay)
  for(const li of t.querySelectorAll('.coinage li.denomination')){
    const unit=['pp','gp','sp','cp','credits','upb'].find(u=>li.classList.contains(u));
    if(unit)li.querySelector('.currency-image')?.insertAdjacentHTML('afterbegin',iconHTML(`coin-${unit}`,'ffks-medal'));
  }
  // empty sections
  for(const ul of t.querySelectorAll('section.inventory-list > ul.items')){
    const head=ul.previousElementSibling?.localName==='header'?ul.previousElementSibling:null;
    const key=(ul.dataset.itemTypes??'').split(',')[0]||'other';
    if(head){head.dataset.ffksFlip=`inv-h-${key}`;head.classList.add('ffks-invh');}
    ul.dataset.ffksFlip=`inv-${key}`;
    if(!ul.querySelector(':scope > li')){ul.dataset.ffksField='inventory.emptysec';if(head)head.dataset.ffksField='inventory.emptysec';}
    const ic={weapon:'sec-weapons',armor:'sec-armor',equipment:'sec-equipment',consumable:'sec-consumables',treasure:'sec-treasure',backpack:'sec-containers',ammo:'it-arrows',shield:'it-shield'}[key];
    if(head&&ic)head.querySelector('.item-name')?.insertAdjacentHTML('afterbegin',iconHTML(ic,'s14'));
  }
}

function spells(t){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  for(const n of t.querySelectorAll('section.focus-pool'))n.dataset.ffksField='spellcasting.focuspool';
  // rituals: PF2e's own sub-tab and its panel
  for(const n of t.querySelectorAll(':scope > nav.sub-nav > a[data-tab="rituals"], .spell-collections > .tab[data-tab="rituals"]'))n.dataset.ffksField='spellcasting.rituals';
  // each entry's list: its cantrips, and ranks with no spell in them (only empty slots)
  for(const list of t.querySelectorAll('ol.spell-list')){
    const groups=new Map();
    for(const li of list.children){const id=li.dataset.groupId;if(id==null)continue;if(!groups.has(id))groups.set(id,[]);groups.get(id).push(li);}
    for(const [id,rows] of groups){
      if(id==='cantrips'){for(const li of rows)li.dataset.ffksField='spellcasting.cantrips';continue;}
      if(!rows.some(li=>li.matches('li.spell')&&li.dataset.itemType!=='spell-slot'))for(const li of rows)li.dataset.ffksField='spellcasting.emptyranks';
    }
  }
  ranks(t);
}
function crafting(t){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  const opts=t.querySelector(':scope > .crafting-options');if(opts){opts.dataset.ffksFlip='crafting-options';tag(opts,'crafting','abilities');}
  tag(t.querySelector(':scope > ol.crafting-entry-list'),'crafting','abilities');
  tag(t.querySelector(':scope > section.known-formulas'),'crafting','formulas');
}
/** PF2e's skills (and Starfinder's computers and piloting) have their own icons; any other gets the lore one. */
const SKILL_ICONS=new Set(['acrobatics','arcana','athletics','crafting','deception','diplomacy','intimidation','medicine','nature','occultism','performance','religion','society','stealth','survival','thievery','computers','piloting']);
function proficiencies(t){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  // PF2e lists them as header + list pairs: skills, lores, attacks, defences, spellcasting, class DCs
  const pairs=[...t.querySelectorAll(':scope > header')].map(h=>({h,ul:h.nextElementSibling?.matches?.('ul.proficiencies-list')?h.nextElementSibling:null})).filter(p=>p.ul);
  let combat=0;
  for(const p of pairs){
    let key=null;
    if(p.ul.classList.contains('lores-list'))key='lores';
    else if(p.ul.classList.contains('combat-list'))key=combat++===0?'attacks':'defences';
    else if(p.ul.querySelector('li[data-slug="spellcasting"]'))key='spellprof';
    else if(p.ul.querySelector('a.dc'))key='classdcs';
    p.h.dataset.ffksFlip=`prof-${key??'skills'}-h`;p.ul.dataset.ffksFlip=`prof-${key??'skills'}`;
    if(key){p.h.dataset.ffksField=`proficiencies.${key}`;p.ul.dataset.ffksField=`proficiencies.${key}`;}
    else p.ul.classList.add('ffks-skills');
  }
  // a skill icon on each core skill and lore
  for(const li of t.querySelectorAll('ul.proficiencies-list > li[data-statistic]')){
    const slug=li.dataset.statistic,lore=li.dataset.itemType==='lore'||li.closest('.lores-list');
    li.classList.add('ffks-skill');
    if(!li.querySelector(':scope > .ffks-skill-ic'))li.insertAdjacentHTML('afterbegin',`<span class="ffks-skill-ic">${iconHTML(!lore&&SKILL_ICONS.has(slug)?`sk-${slug}`:'sk-lore','s18')}</span>`);
  }
  ranks(t);
}
function feats(t){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  for(const sec of t.querySelectorAll(':scope > section.feat-section[data-group-id]')){
    const id=sec.dataset.groupId;sec.dataset.ffksFlip=`feats-${id}`;sec.classList.add('ffks-fsec');
    if(id==='classfeature')sec.dataset.ffksField='feats.features';
    else if(id==='bonus')sec.dataset.ffksField='feats.bonusfeats';
  }
  for(const li of t.querySelectorAll('li.slot'))if(li.querySelector(':scope > .item-name > .item-placeholder')&&!li.dataset.itemId)li.dataset.ffksField='feats.emptyslots';
}
function effects(t,actor,app){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  // PF2e's order: (afflictions), conditions, effects, divine intercessions; found by place, so any language works
  const heads=[...t.querySelectorAll(':scope > header')].filter(h=>h.nextElementSibling?.matches?.('ol.effects-list'));
  const inter=heads.findIndex(h=>h.dataset.groupId==='intercession'),end=inter>=0?inter:heads.length;
  const keys=new Map();if(inter>=0)keys.set(heads[inter],'intercessions');
  if(end-1>=0)keys.set(heads[end-1],'effectlist');if(end-2>=0)keys.set(heads[end-2],'conditions');
  for(const h of heads){if(h.nextElementSibling.querySelector('li[data-item-type="condition"]'))keys.set(h,'conditions');}
  for(const [h,key] of keys){const list=h.nextElementSibling;
    h.dataset.ffksField=`effects.${key}`;h.dataset.ffksFlip=`effects-${key}-h`;list.dataset.ffksField=`effects.${key}`;list.dataset.ffksFlip=`effects-${key}`;}
  // the conditions' own icons, so they match the header chips
  for(const li of t.querySelectorAll('li[data-item-type="condition"]')){
    const img=li.querySelector('img.item-icon');const slug=conditionSlugOf(actor,li.dataset.itemId);
    if(slug&&img&&conditionIcon(slug)!=='c-generic'){img.insertAdjacentHTML('afterend',iconHTML(conditionIcon(slug),`ffks-cond-ic${slug==='dying'?' '+dyingClass(actor):''}`));li.classList.add('ffks-has-ic');}
  }
  // add a condition: one tile for each common condition
  if(actor.isOwner&&!t.querySelector('.ffks-palette')){
    const on=new Set(activeConditions(actor).map(c=>c.slug));
    const name=slug=>{try{return game.pf2e?.ConditionManager?.getCondition?.(slug)?.name??null;}catch{return null;}};
    const tiles=PALETTE_CONDITIONS.map(slug=>`<button type="button" class="ffks-cpt${on.has(slug)?' has':''}" data-ffks-add="${slug}" title="${on.has(slug)?'On her · click to raise or end':'Add'} ${esc(name(slug)??slug)}">${iconHTML(conditionIcon(slug),`s20${slug==='dying'&&on.has(slug)?' '+dyingClass(actor):''}`)}<span>${esc(name(slug)??slug.replace(/-/g,' '))}</span></button>`).join('');
    const condHead=t.querySelector(':scope > header[data-ffks-field="effects.conditions"]');
    const html=`<section class="ffks-palette" data-ffks-field="effects.palette" data-ffks-flip="effects-palette"><div class="ffks-sec-h sm">${iconHTML('ui-plus','s14')}<span class="t">Add a condition</span><span class="ffks-line"></span></div><div class="ffks-cpal">${tiles}</div></section>`;
    const condList=condHead?.nextElementSibling;
    (condList??t.firstElementChild)?.insertAdjacentHTML(condList?'afterend':'beforebegin',html);
    t.querySelector('.ffks-palette')?.addEventListener('click',event=>{
      const b=event.target.closest('[data-ffks-add]');if(!b)return;event.preventDefault();
      void stepCondition(actor,b.dataset.ffksAdd,1);
    });
  }
}
function conditionSlugOf(actor,id){try{return actor?.items?.get?.(id)?.slug??actor?.conditions?.get?.(id)?.slug??null;}catch{return null;}}

/** PF2e's biography fields, by their own classes. */
const BIO_FIELDS=[['appearance','.bio.appearance'],['height','label.pc_height'],['weight','label.pc_weight'],['backstory','.bio.backstory'],['birthplace','.bio.birth-place'],
  ['attitude','.bio.attitude'],['beliefs','.bio.beliefs'],['edicts','.bio.edicts'],['anathema','.bio.anathema'],['likes','.bio.likes'],['dislikes','.bio.dislikes'],
  ['catchphrases','.bio.catchphrases'],['campaign','.bio.campaign-notes'],['allies','.bio.allies'],['enemies','.bio.enemies'],['organizations','.bio.organizations, .bio.organaizations']];
const BIO_ICONS={appearance:'b-appearance',height:'b-height',weight:'b-weight',backstory:'b-backstory',birthplace:'b-birthplace',attitude:'b-attitude',beliefs:'b-beliefs',
  edicts:'b-edicts',anathema:'b-anathema',likes:'b-likes',dislikes:'b-dislikes',catchphrases:'b-quote',campaign:'b-notes',allies:'b-allies',enemies:'b-enemies',organizations:'b-orgs'};
function biography(t){
  if(!t||t.dataset.ffks)return;t.dataset.ffks='1';
  for(const [key,sel] of BIO_FIELDS){
    const node=t.querySelector(sel);if(!node)continue;
    node.classList.add('ffks-bfield');tag(node,'biography',key);
    const label=node.querySelector(':scope > .details-label, :scope > .label-add > .details-label, :scope > h4.details-label, :scope > label.details-label');
    label?.insertAdjacentHTML('afterbegin',iconHTML(BIO_ICONS[key],'s14 ffks-bic'));
    node.closest('section')?.classList.add('ffks-bsec');
  }
}

/* ------------------------------------------------------------------ hiding and re-packing */

/** Hide what's switched off, re-pack what's left, and glide it into place. */
export function applyHidden(app,{flip=null,hidden=null}={}){
  const root=el(app?.element);if(!root?.classList?.contains('ffks'))return;
  const actor=app.actor;hidden??=hiddenFields(actor);
  const before=flip===true?snapshot(root):flip;
  for(const n of root.querySelectorAll('[data-ffks-field]'))n.classList.toggle('ffks-off',!!hidden[n.dataset.ffksField]);
  // whole tabs
  let activeHidden=false;
  for(const a of root.querySelectorAll('nav.sheet-navigation a.item[data-tab]')){
    const off=a.dataset.tab!=='character'&&!!hidden[fieldKey('tab',a.dataset.tab)];a.classList.toggle('ffks-off',off);if(off&&a.classList.contains('active'))activeHidden=true;
  }
  if(activeHidden)showTab(app,'character');
  // a hidden sub-tab (Rituals) that was open: back to the spells she knows
  const sub=root.querySelector('.tab.spellcasting > nav.sub-nav > a.active.ffks-off');
  if(sub)root.querySelector('.tab.spellcasting > nav.sub-nav > a[data-tab="known-spells"]')?.click();
  // inventory columns
  root.classList.toggle('ffks-nocol-price',!!hidden['inventory.pricecol']);root.classList.toggle('ffks-nocol-bulk',!!hidden['inventory.bulkcol']);
  repack(root);
  if(before)requestAnimationFrame(()=>requestAnimationFrame(()=>glide(root,before)));
}
function visible(nodes){return nodes.filter(n=>!n.classList.contains('ffks-off'));}
function repack(root){
  const ids=root.querySelector('.tab.character .ffks-ids');
  if(ids){const tiles=visible([...ids.querySelectorAll(':scope > .ffks-tile')]);identitySpans(tiles.length).forEach((s,k)=>{tiles[k].style.setProperty('--span',s.span);tiles[k].style.setProperty('--span-n',s.spanN);});}
  const det=root.querySelector('.tab.character .ffks-details');
  if(det){const tiles=visible([...det.querySelectorAll(':scope > .ffks-dtile')]);shareSpans(tiles.length).forEach((s,k)=>{tiles[k].style.setProperty('--span',s.span);tiles[k].style.setProperty('--span-n',s.spanN);});
    det.classList.toggle('ffks-off',!tiles.length);root.querySelector('.tab.character .ffks-details-h')?.classList.toggle('ffks-off',!tiles.length);}
  const ml=root.querySelector('.tab.character .ffks-ml');
  if(ml)ml.classList.toggle('single',visible([...ml.children]).length<2);
  // biography: each of PF2e's sections re-packs on its own two columns
  for(const sec of root.querySelectorAll('.tab.biography section.ffks-bsec')){
    const fields=visible([...sec.querySelectorAll(':scope > .ffks-bfield[data-ffks-field]')]);
    bioSpans(fields.map(f=>f.dataset.ffksField.split('.')[1]),WIDE_BIO).forEach((s,k)=>fields[k].style.setProperty('--span',s.span));
    const head=sec.previousElementSibling?.localName==='header'?sec.previousElementSibling:null;
    sec.classList.toggle('ffks-off',!fields.length&&!!sec.querySelector('[data-ffks-field]'));head?.classList.toggle('ffks-off',sec.classList.contains('ffks-off'));
  }
}
/** FLIP: where each tile was, then let it glide from there to its new place. */
export function snapshot(root){
  const m=new Map();
  for(const n of root.querySelectorAll('[data-ffks-flip]')){const r=n.getBoundingClientRect();if(r.width||r.height)m.set(n.dataset.ffksFlip,{x:r.left,y:r.top,w:r.width});}
  return m;
}
function glide(root,before){
  const reduced=root.classList.contains('ffks-fm-off')||root.ownerDocument.defaultView?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
  if(reduced)return;
  for(const n of root.querySelectorAll('[data-ffks-flip]')){
    const r=n.getBoundingClientRect();if(!r.width||!n.animate)continue;
    const a=before.get(n.dataset.ffksFlip);
    if(a){const dx=a.x-r.left,dy=a.y-r.top,grew=Math.abs(a.w-r.width)>1;if(Math.abs(dx)<1&&Math.abs(dy)<1&&!grew)continue;
      n.animate([{transform:`translate(${dx}px,${dy}px)`,opacity:grew?.7:1,zIndex:3},{transform:'none',opacity:1,zIndex:3}],{duration:520,easing:'cubic-bezier(.25,.9,.3,1)'});}
    else n.animate([{opacity:0,transform:'scale(.96)'},{opacity:1,transform:'none'}],{duration:420,easing:'ease-out'});
  }
}
/** Switch fields from the ⋯ menu: hide/show, glide, and remember (here or on her actor). */
export function refreshHidden(app){const st=stateOf(app);applyHidden(app,{flip:st.flipNext??null});st.flipNext=null;}
export function prepareGlide(app){const st=stateOf(app),root=el(app?.element);if(root)st.flipNext=snapshot(root);return st.flipNext;}
export function setStandard(app,on){const st=stateOf(app);st.standard=!!on;}
/** A closed window starts afresh next time (size, failures, observers). */
export function forgetSheet(app){const st=apps.get(app);if(!st)return;st.ro?.disconnect();apps.delete(app);}
export function isStandard(app){return !!stateOf(app).standard;}
export {canEditFields};
