/** Yvaelle’s Toolbox v11 · Wounds, persistent damage, dying and mood on her wings.
 *
 * Port of the approved lab designs (lab/v11/wounds, fixes, refine) to the
 * module's own wing rig. Everything here is pure and worker-safe: it runs
 * inside frameGeometry (strand fields, cuts, offsets) and paintLayers (the
 * paletteAt colour hook and a few extra strokes), on the main thread or in
 * the wing worker, from one small serialisable state on the visual profile:
 *
 *   visual.v11dmg = {
 *     t,                                   effect clock (s)
 *     wound:{look,q,side,tint?},           the latest blow (q = s since it)
 *     persist:[{look,n,quad,q,cq,cl,on,k,ph,acc,cycleN,cq0,tint?}],
 *     dying:{ember,huddle,heal,t},         dying stages on her fallen pose
 *     mood:{from,to,k},                    mood weather
 *     alt:{side,phase},                    the struck wing's own phase (mental)
 *     px                                   art units per map pixel
 *   }
 *
 * The main thread (damage-runtime.mjs) works out the clocks; this file only
 * draws them. With no state there is no work at all (zero idle cost), and
 * palettes are cached by look and level for the life of the page. Strand
 * fields are defined in the rig's SOURCE coordinates (the right wing's rest
 * drawing, x > 0), so a wound stays on the same filaments as she beats. */
import {STRANDS,ROOT} from '../wing-rig.mjs?v=12.0.1';

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const ease=x=>{x=unit(x);return x<.5?4*x*x*x:1-(-2*x+2)**3/2;};
const easeOut=x=>{x=unit(x);return 1-(1-x)**3;};
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const env=(t,a,ain,b,bout)=>smooth((t-a)/ain)*(1-smooth((t-b)/bout));
const lerp=(a,b,k)=>a+(b-a)*k;
const mixC=(a,b,k)=>[Math.round(a[0]+(b[0]-a[0])*k),Math.round(a[1]+(b[1]-a[1])*k),Math.round(a[2]+(b[2]-a[2])*k)];
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${a<0?0:a>1?1:a})`;
const hash1=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s);};
const hash2=(x,y)=>{const s=Math.sin(x*127.1+y*311.7)*43758.5453;return s-Math.floor(s);};
function vnoise(x,y){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);
  const a=hash2(xi,yi),b=hash2(xi+1,yi),c=hash2(xi,yi+1),d=hash2(xi+1,yi+1);return lerp(lerp(a,b,u),lerp(c,d,u),v);}
const MAG=[255,0,255],MAG_CORE=[255,214,255];
const ramp=(stops,k)=>{k=unit(k);for(let i=1;i<stops.length;i++){const [a,ca]=stops[i-1],[b,cb]=stops[i];if(k<=b)return mixC(ca,cb,(k-a)/Math.max(1e-6,b-a));}return stops.at(-1)[1];};

/* ---------------- source coordinates (built once, lazily: wing-rig imports this file) ---------------- */
let SRC=null,FOF=null;const R_MAX=262;
function src(){
  if(SRC)return SRC;
  SRC=new Map(STRANDS.map(s=>[s.id,s.points.map(p=>[p[0],p[1]])]));
  FOF=new WeakMap();for(const [,S] of SRC)S.forEach((p,i)=>FOF.set(p,i/(S.length-1)));
  return SRC;
}
const fOf=sp=>FOF.get(sp)??0;
const rOf=p=>Math.hypot(p[0]-ROOT[0],p[1]-ROOT[1])/R_MAX;
/** Source point of each live point of a (possibly depth-split) strand part. */
function srcOf(s,sx){
  const S=src().get(s.id);if(!S)return null;
  if(S.length===s.points.length)return S;
  return s.points.map(p=>{const q0=p[0]*sx,q1=p[1];let best=S[0],bd=1e9;for(const a of S){const d=(a[0]-q0)**2+(a[1]-q1)**2;if(d<bd){bd=d;best=a;}}return best;});
}
const lerpPt=(a,b,k)=>a.map((v,i)=>v+((b[i]??v)-v)*k);
function pointAtF(points,f){const n=points.length-1,x=Math.max(0,Math.min(n,f*n)),i=Math.min(n-1,Math.floor(x)),k=x-i;return lerpPt(points[i],points[i+1],k);}
function sliceF(points,f0,f1){const n=points.length-1,out=[pointAtF(points,f0)];for(let i=Math.ceil(f0*n+1e-6);i<f1*n;i++)out.push(points[i]);out.push(pointAtF(points,f1));return out;}
const srcPt=(id,f)=>pointAtF(src().get(id),f);
const keysOf=side=>[side+'Rear',side+'Front'];
const depthKey=s=>s.points[0][2]>0?'Front':'Rear';
const onKey=(key,s)=>key.endsWith(depthKey(s));

/* ---------------- one frame's scratch (only while something shows) ---------------- */
/** Per-state scratch: the frame's live strands, gap ends, the in-phase wing
 * (mental) and bit stations. Keyed by the state object, so frameGeometry and
 * paintLayers of one frame share it on either thread. */
const SCRATCH=new WeakMap();
const scratchOf=D=>{let X=SCRATCH.get(D);if(!X){X={live:{left:new Map(),right:new Map()},ends:null,pends:{},sideBase:{},gems:[],ep:{},prec:null};SCRATCH.set(D,X);}return X;};
function snapshotLive(wings,X){
  for(const side of ['left','right']){const m=X.live[side];m.clear();
    for(const k of keysOf(side))for(const s of wings[k]){if(s.hardware||s.star)continue;const cur=m.get(s.id);if(!cur||cur.points.length<s.points.length)m.set(s.id,s);}}
  X.gems.length=0;
  for(const k of Object.keys(wings))for(const s of wings[k])if(s.hardware&&/^gem-/.test(s.id)&&s.points?.[0]){const p=s.points[0];X.gems.push({left:k.startsWith('left'),key:k,x:p[0],y:p[1],i:(k.startsWith('left')?0:1)+(p[1]>15?2:0)});}
}
const liveStrand=(X,side,id)=>X.live[side].get(id)??null;
/** Nearest live point to a source point (plus the source offset), on one side. */
function liveAt(X,side,sp){
  const sx=side==='left'?-1:1,S0=src();let best=null,bd=1e9,ox=0,oy=0;
  for(const [id,s] of X.live[side]){const S=S0.get(id);if(!S||S.length!==s.points.length||!/^(rib|edge|web)-/.test(id))continue;
    for(let i=0;i<S.length;i++){const d=(S[i][0]-sp[0])**2+(S[i][1]-sp[1])**2;if(d<bd){bd=d;best=s.points[i];ox=(sp[0]-S[i][0])*sx;oy=sp[1]-S[i][1];}}}
  return best?[best[0]+ox,best[1]+oy,best[2]]:[sx*sp[0],sp[1],0];
}

/** Re-cut one strand by a per-point field: v={l: palette code (0 = untouched),
 * g: gap (>0 removes the point; crossings are interpolated), d: [dx,dy] offset}. */
function remap(s,vals,ends){
  const pts=s.points.map((p,i)=>vals[i].d?[p[0]+vals[i].d[0],p[1]+vals[i].d[1],p[2]]:p);
  const out=[];let cur=null;const push=()=>{if(cur&&cur.points.length>1)out.push(cur);cur=null;};
  for(let i=0;i<pts.length;i++){
    const v=vals[i],gap=v.g>0;
    if(i>0){const u=vals[i-1],ug=u.g>0;
      if(ug!==gap){const k=u.g/(u.g-v.g),m=lerpPt(pts[i-1],pts[i],unit(k));
        if(!ug){if(cur){cur.points.push(m);push();}ends?.push({p:m,l:u.l,id:s.id});}
        else{cur={...s,points:[m],wl:v.l};ends?.push({p:m,l:v.l,id:s.id});}}}
    if(gap)continue;
    if(!cur)cur={...s,points:[],wl:v.l};
    else if(cur.wl!==v.l){cur.points.push(pts[i]);push();cur={...s,points:[],wl:v.l};}
    cur.points.push(pts[i]);
  }
  push();return out;
}
const NONE=Object.freeze({l:0,g:-1});
/** Apply a field to every lattice strand of one side. fn(src,i,s,live) -> v|null. */
function woundSide(wings,side,fn,{ends=null,only=null}={}){
  const sx=side==='left'?-1:1;
  for(const k of keysOf(side)){
    const next=[];
    for(const s of wings[k]){
      if(s.hardware||s.star||s.v11mark||(only&&!only(s.id))){next.push(s);continue;}
      const S=srcOf(s,sx);if(!S){next.push(s);continue;}
      let any=false;const vals=s.points.map((p,i)=>{const v=fn(S[i],i,s,p);if(v&&(v.l||v.g>0||v.d))any=true;return v??NONE;});
      if(!any){next.push(s);continue;}
      for(let i=0;i<vals.length;i++){const v=vals[i];if(v===NONE)continue;if(v.g==null)v.g=-1;if(v.l==null)v.l=0;}
      for(const part of remap(s,vals,ends))next.push(part);
    }
    wings[k]=next;
  }
}
/** A new strand array with each matching strand's strength scaled (never mutates the rig's cached strands). */
function scaleStrength(wings,keys,fn){
  for(const k of keys){const a=wings[k];let out=null;
    for(let i=0;i<a.length;i++){const s=a[i];if(s.hardware||s.star||s.v11mark)continue;const m=fn(s);if(m===1)continue;out??=a.slice();out[i]={...s,strength:s.strength*m};}
    if(out)wings[k]=out;}
}

/* ---------------- painters (art units, on a wing layer) ---------------- */
function current(ctx,points,width,s,tint,{bloom=1,min=1.7}={}){
  if(points.length<2||s<.01)return;
  ctx.beginPath();for(let i=0;i<points.length;i++){const p=points[i];if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);}
  const b=tint.bloom,c=tint.core;
  ctx.lineWidth=width*6.5;ctx.strokeStyle=rgba(b,.18*s*bloom);ctx.stroke();
  ctx.lineWidth=width*2.8;ctx.strokeStyle=rgba(b,.42*s);ctx.stroke();
  ctx.lineWidth=Math.max(min,width*1.35);ctx.strokeStyle=rgba(c,s);ctx.stroke();
}
function star(ctx,x,y,r,a,tint,{flat=.45,rot=0}={}){
  if(a<.01)return;
  const g=ctx.createRadialGradient(x,y,0,x,y,r*3.8);g.addColorStop(0,rgba(tint.bloom,a*.7));g.addColorStop(1,rgba(tint.bloom,0));
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r*3.8,0,TAU);ctx.fill();
  ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.fillStyle=rgba(tint.core,a);
  ctx.beginPath();ctx.moveTo(0,-r*2);ctx.lineTo(r*flat,0);ctx.lineTo(0,r*2);ctx.lineTo(-r*flat,0);ctx.closePath();ctx.fill();
  ctx.beginPath();ctx.moveTo(-r*1.3,0);ctx.lineTo(0,r*flat*.6);ctx.lineTo(r*1.3,0);ctx.lineTo(0,-r*flat*.6);ctx.closePath();ctx.fill();
  ctx.restore();
}
function ember(ctx,x,y,r,a,tint){
  if(a<.01)return;const g=ctx.createRadialGradient(x,y,0,x,y,r*4);
  g.addColorStop(0,rgba(tint.core,a));g.addColorStop(.18,rgba(tint.core,a*.8));g.addColorStop(.35,rgba(tint.bloom,a*.42));g.addColorStop(1,rgba(tint.bloom,0));
  ctx.fillStyle=g;ctx.fillRect(x-r*4,y-r*4,r*8,r*8);
}
/** A soft glow round a bit station (the lab's bit glow, drawn on the wing layer under the bit). */
function bitGlow(ctx,X,i,color,a,rad){if(a<.005)return;for(const g of X.gems)if(g.i===i){const R=rad*1.7,gr=ctx.createRadialGradient(g.x,g.y,0,g.x,g.y,R);
  gr.addColorStop(0,rgba(color,a));gr.addColorStop(.35,rgba(color,a*.35));gr.addColorStop(1,rgba(color,0));ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=gr;ctx.fillRect(g.x-R,g.y-R,R*2,R*2);ctx.restore();return;}}
function crackle(pts,amp,seed){
  if(pts.length<3)return pts;const out=[pts[0]];
  for(let i=1;i<pts.length-1;i++){const a=pts[i-1],b=pts[i+1],dx=b[0]-a[0],dy=b[1]-a[1],L=Math.hypot(dx,dy)||1,o=(hash1(seed*7.13+i*3.71)-.5)*2*amp;
    out.push([pts[i][0]-dy/L*o,pts[i][1]+dx/L*o,pts[i][2]]);}
  out.push(pts.at(-1));return out;
}
function websOn(r){const out=[];for(let j=1;j<=9;j++){if(r<9)out.push([`web-${r}-${j}`,'a',j/10]);if(r>0)out.push([`web-${r-1}-${j}`,'b',Math.min(.96,j/10+.045*Math.sin((r-1)*2.1+j*1.9))]);}return out;}
const WEBS=new Map();const websOnC=r=>{let w=WEBS.get(r);if(!w){w=websOn(r);WEBS.set(r,w);}return w;};

/* =====================================================================
 * 1. DAMAGE-TYPE WOUNDS (q = s since the blow, side = the struck wing)
 * ===================================================================== */
export const WOUND_SPAN=3.2;
const W={};
const STR_EDGE=id=>id.startsWith('edge-')?1:id.startsWith('rib-')?.85:.7;

/* ---- Fire: the struck edge glows ember-orange, embers creep, it cools ---- */
const FIRE={core:[255,222,170],bloom:[255,104,36]};
const FIRE_RAMP=[[0,MAG],[.22,[236,36,110]],[.5,[255,86,40]],[.78,[255,142,52]],[1,[255,196,112]]];
const FIRE_C=[206,-20];
const fireHeat=(sp,q,id)=>{
  if(q<0)return 0;const d=Math.hypot(sp[0]-FIRE_C[0],sp[1]-FIRE_C[1]),R=66+44*easeOut(q/1.3);
  const n=.75+.5*vnoise(sp[0]*.06,sp[1]*.06);
  const h=easeOut(q/.14)*(1-smooth(d/(R*n)))*STR_EDGE(id);
  const cool=smooth((q-1.0-.75*(1-Math.min(1,d/R)))/.85);
  return h*(1-cool);
};
const EMBERS=[['edge-2',.78,-1,.12,.04],['edge-2',.84,1,.1,.1],['edge-3',.12,1,.13,.06],['web-3-8',.6,-1,.22,.16],['web-4-7',.7,-1,.2,.22],['rib-4',.86,-1,.08,.12],['web-3-7',.75,-1,.18,.32],['edge-3',.06,1,.08,.42],['rib-3',.92,-1,.07,.3],['web-4-8',.35,1,.16,.5]];
const EMBER_TINT={core:[255,200,120],bloom:[255,90,30]};
W.fire={side:'right',
  pal:l=>{const k=l/12;const ink=ramp(FIRE_RAMP,k);return {ink,halo:mixC(MAG,[255,84,24],Math.min(1,k*1.3)),core:mixC(MAG_CORE,[255,226,170],k),glow:1+.7*k,wire:1+.6*k,edge:0,edgeColor:[255,226,170]};},
  geom(wings,X,q,side){woundSide(wings,side,(sp,i,s)=>{const h=fireHeat(sp,q,s.id);return h>.04?{l:Math.round(h*12)}:null;});},
  paint(ctx,key,X,q,side){
    if(!key.startsWith(side)||q<0||q>2.8)return;
    for(let k=0;k<EMBERS.length;k++){const [id,f0,dir,sp,born]=EMBERS[k];
      const s=liveStrand(X,side,id);if(!s||!onKey(key,s))continue;
      const age=q-born;if(age<0)continue;
      const life=1.7+.5*hash1(k);const f=f0+dir*sp*age*(1-.35*smooth(age/life));if(f<0||f>1)continue;
      const fl=.7+.3*Math.sin(age*23+k*5)*Math.sin(age*9.3+k);
      const a=smooth(age/.12)*(1-smooth((age-life+.5)/.5))*fl;
      const p=pointAtF(s.points,f),tail=sliceF(s.points,Math.min(f,f-dir*.05),Math.max(f,f-dir*.05));
      current(ctx,tail,.5,.55*a,EMBER_TINT,{bloom:.7,min:1.3});
      ember(ctx,p[0],p[1],2.8*(1-.4*smooth(age/life)),a,FIRE);
    }
    const c=liveAt(X,side,FIRE_C);star(ctx,c[0],c[1],3,bump(unit(q/.32))*.9,FIRE,{flat:.35});
  },
  bitGlow(i,left,q,side){if(left!==(side==='left'))return null;const k=env(q,0,.1,.9,1.1)*(i<2?1:.7);return k>0?[[255,120,50],.32*k,13]:null;},
};

/* ---- Cold: frost crystals grow across a few lattice panels, then melt ---- */
const ICE={core:[232,244,255],bloom:[120,166,255]};
const PANELS=[[2,3,.6,.78,.02],[3,4,.52,.7,.1],[3,4,.7,.86,.2],[4,5,.62,.8,.14],[2,3,.78,.92,.3]];
function frostFern(seed){
  const out=[];const rnd=k=>hash1(seed*31.7+k*1.37);
  const s0=.15+.2*rnd(1),t0=.1+.15*rnd(2),ang=.55+.5*rnd(3),L=.85+.2*rnd(4);
  const sp=[[s0,t0],[s0+Math.cos(ang)*L*.85,t0+Math.sin(ang)*L*.85]];
  out.push({a:sp[0],b:sp[1],t0:0,dur:.55,w:.75});
  for(let j=1;j<=6;j++){const u=j/7,p=lerpPt(sp[0],sp[1],u),len=(.32-.04*j)*(.8+.4*rnd(10+j));
    for(const sg of [1,-1]){const a2=ang+sg*1.05,e=[p[0]+Math.cos(a2)*len,p[1]+Math.sin(a2)*len];
      out.push({a:p,b:e,t0:.08+u*.42,dur:.32,w:.52});
      if(j<4){const m=lerpPt(p,e,.55),a3=a2-sg*1.05,l3=len*.45;out.push({a:m,b:[m[0]+Math.cos(a3)*l3,m[1]+Math.sin(a3)*l3],t0:.3+u*.4,dur:.25,w:.32});}}}
  return out;
}
const FERNS=PANELS.map((p,k)=>frostFern(k+1));
function panelMap(X,side,[i,j,fa,fb]){
  const A=liveStrand(X,side,`rib-${i}`),B=liveStrand(X,side,`rib-${j}`);if(!A||!B)return null;
  const a0=pointAtF(A.points,fa),a1=pointAtF(A.points,fb),b0=pointAtF(B.points,fa+.02),b1=pointAtF(B.points,fb+.02);
  return (s,t)=>lerpPt(lerpPt(a0,a1,t),lerpPt(b0,b1,t),s);
}
const COLD_C=[188,-34];
const coldField=(sp,q)=>{if(q<0)return 0;const d=Math.hypot(sp[0]-COLD_C[0],sp[1]-COLD_C[1]);return easeOut(q/.5)*(1-smooth((d-30)/50))*(1-smooth((q-1.55-.3*d/80)/.7));};
W.cold={side:'left',
  pal:l=>{const k=l/10;const ink=mixC(MAG,[150,150,255],k);return {ink,halo:mixC(MAG,[110,140,255],k),core:mixC(MAG_CORE,[226,236,255],k),glow:1-.18*k,wire:1,edge:0,edgeColor:[226,236,255]};},
  geom(wings,X,q,side){woundSide(wings,side,sp=>{const h=coldField(sp,q);return h>.05?{l:Math.round(h*10)}:null;});},
  feel(out,q){out.beatRate*=1-.22*env(q,0,.3,1.6,.6);},
  paint(ctx,key,X,q,side){
    if(!key.startsWith(side)||!key.endsWith('Rear')||q<0||q>2.8)return;
    for(let k=0;k<PANELS.length;k++){const pn=PANELS[k],M=panelMap(X,side,pn);if(!M)continue;const born=pn[4];
      const melt=smooth((q-1.45-k*.07)/.75);
      for(const br of FERNS[k]){
        const g=easeOut((q-born-br.t0)/br.dur);if(g<=0)continue;
        const len=g*(1-melt*.9);if(len<=.01)continue;
        const pts=[];for(let n=0;n<=6;n++){const u=n/6*len;pts.push(M(...lerpPt(br.a,br.b,u)));}
        if(melt>.02)ctx.setLineDash([2.2*(1-melt)+.4,1.2+5*melt]);
        current(ctx,pts,br.w,(1-melt)*.95,ICE,{bloom:.55,min:.9});
        ctx.setLineDash([]);
        if(g<1&&br.w>.5){const e=pts.at(-1);star(ctx,e[0],e[1],1.1,.8,ICE,{flat:.3});}
      }
      const mq=(q-1.6-k*.1)/.9;if(mq>0&&mq<1){const p=M(.5,lerp(.6,1.05,easeOut(mq)));ember(ctx,p[0],p[1]+mq*10,1.4,.7*bump(mq),ICE);}
    }
  },
  bitGlow(i,left,q,side){if(left!==(side==='left'))return null;const k=env(q,.1,.4,1.6,.7);return k>0?[[160,190,255],.26*k,13]:null;},
  bit(o,i,left,q,side){if(left!==(side==='left'))return;const k=env(q,.1,.4,1.6,.7);if(k>0)o.spinMul*=1-.8*k;},
};

/* ---- Electricity B · Violet crackle (the user's choice): the charge crackles
 *      through the lattice round the blow, the light stutters, it grounds at the rib tips ---- */
const STUTTER=[1,.32,.32,1,1,.55,1,1,1,.4,1];
const stutterMul=(q,at)=>{const fr=Math.floor((q-at)*30);return fr<0||fr>=STUTTER.length?1:STUTTER[fr];};
const VIO={core:[244,238,255],bloom:[158,126,255]};
const B_C=[204,-52],B_STUT=.62;
const crackR=q=>18+82*easeOut(q/.32);
const drainF=q=>smooth((q-.95)/.75);
function fieldB(sp,q){
  if(q<0)return 0;const d=Math.hypot(sp[0]-B_C[0],sp[1]-B_C[1]),R=crackR(q);
  let k=1-smooth((d-R*.7)/(R*.35));
  k*=1-smooth((drainF(q)*1.25-(rOf(sp)-.25))/.12);
  return k*(1-smooth((q-1.85)/.25));
}
const idSeed=id=>id.length*1.7+(id.charCodeAt(id.length-1)||0)*.37;
W.elecB={side:'right',
  pal:l=>{const k=l/8;return {ink:mixC(MAG,[214,186,255],k),halo:mixC(MAG,[150,120,255],k),core:mixC(MAG_CORE,[246,240,255],k),glow:1+.35*k,wire:1+.45*k,edge:0,edgeColor:[246,240,255]};},
  geom(wings,X,q,side){
    if(q<0||q>2.2)return;const fr=Math.floor(q*20);
    woundSide(wings,side,(sp,i,s)=>{const k=fieldB(sp,q);if(k<.05)return null;
      const fl=hash1(fr*5.3+idSeed(s.id))>.35?1:.45;return {l:Math.max(1,Math.round(k*fl*8))};});
    const m=stutterMul(q,B_STUT);if(m<.999)scaleStrength(wings,keysOf(side),()=>m);
  },
  feel(out,q){const k=env(q,0,.05,.9,.6);out.flex=Math.min(1,(out.flex??0)+.2*k);out.beatRate*=1-.22*k;},
  paint(ctx,key,X,q,side,wings){
    if(!key.startsWith(side)||q<0||q>2.2)return;const fr=Math.floor(q*20),stut=stutterMul(q,B_STUT);
    if(stut<.5)return;
    let n=0;const S0=src();
    for(const s of wings[key]){if(!/^(rib|web|cross|edge)-/.test(s.id)||s.points.length<4)continue;const S=S0.get(s.id);if(!S||S.length!==s.points.length)continue;
      const k=fieldB(S[S.length>>1],q);if(k<.15)continue;
      const h=hash1(fr*3.1+s.id.length*7.7+(S[0][0]+S[0][1])*.013);if(h>.5)continue;
      const f0=hash1(h*91+fr)*.6,len=.18+.3*hash1(h*37);
      const pts=crackle(sliceF(s.points,f0,Math.min(1,f0+len)),1.5,fr*13+n);
      current(ctx,pts,s.id.startsWith('rib')?.7:.5,Math.min(1,1.1*k)*stut,VIO,{bloom:.9,min:1.2});
      if(h<.22&&pts.length>3){const p=pts[pts.length>>1],a=pts[(pts.length>>1)-1],dx=p[0]-a[0],dy=p[1]-a[1],sg=h<.09?1:-1;
        const ang=Math.atan2(dy,dx)+sg*.65,l=4.5+2.5*hash1(h*7),m=[p[0]+Math.cos(ang)*l*.55+(hash1(fr+h)-.5)*1.2,p[1]+Math.sin(ang)*l*.55],e=[p[0]+Math.cos(ang-sg*.3)*l,p[1]+Math.sin(ang-sg*.3)*l];
        current(ctx,[p,m,e],.32,.9*k*stut,VIO,{bloom:.6,min:.9});}
      n++;
    }
    for(const r of [2,3,4]){const s=liveStrand(X,side,`rib-${r}`);if(!s||!onKey(key,s))continue;const S=S0.get(`rib-${r}`);
      let f0=-1,f1=-1;for(let i=0;i<S.length;i++){if(fieldB(S[i],q)>.3){if(f0<0)f0=i/(S.length-1);f1=i/(S.length-1);}}
      if(f0<0||f1-f0<.04)continue;const fl=hash1(fr*7+r)>.3?1:.5;
      current(ctx,crackle(sliceF(s.points,f0,f1),.7,fr*3+r),.6,.85*fl*stut,VIO,{bloom:1,min:1.3});}
    const c=liveAt(X,side,B_C);if(key===side+'Rear')star(ctx,c[0],c[1],2,bump(unit(q/.2))*.8,VIO,{flat:.3});
    [2,3,4].forEach((r,k2)=>{const s=liveStrand(X,side,`rib-${r}`);if(!s||!onKey(key,s))return;
      const tp=s.points.at(-1),a=bump(unit((q-1.4-k2*.12)/.5));star(ctx,tp[0],tp[1],2.3,.95*a,VIO,{flat:.3});ember(ctx,tp[0],tp[1],1.6,.8*a,VIO);});
  },
  bitGlow(i,left,q,side){if(left!==(side==='left'))return null;const k=env(q,.05,.1,1.1,.6);return k>0?[[190,170,255],.26*k,12]:null;},
  bit(o,i,left,q,side){if(left!==(side==='left'))return;const k=env(q,.05,.1,1.1,.6);if(k<=0)return;
    const fr=Math.floor(q*20);if(q<1.2)o.spin+=(hash1(fr*3+i)-.5)*.22*k;o.dim=Math.max(o.dim,(1-stutterMul(q,B_STUT))*.6);},
};
/* ---- Electricity A · Gilded current (the other picker choice) ---- */
const GOLDV={core:[255,246,222],bloom:[232,176,86]};
const A_RIBS=[[3,0],[2,.05],[4,.09]],A_RUN=.24,A_BACK=.42,A_BACKRUN=.26,A_STUT=.6;
const headA=(q,d)=>{const x=(q-d)/A_RUN;return x<0||x>1?null:1-easeOut(x);};
const headB=(q,d)=>{const x=(q-A_BACK-d)/A_BACKRUN;return x<0||x>1?null:easeOut(x)*.92;};
const passA=(f,d)=>d+A_RUN*(1-Math.cbrt(f));
W.elecA={side:'right',
  pal:l=>{const k=l/8;return {ink:mixC(MAG,[255,214,150],k),halo:mixC(MAG,[236,150,120],k),core:mixC(MAG_CORE,[255,244,222],k),glow:1+.45*k,wire:1+.5*k,edge:0,edgeColor:[255,244,222]};},
  geom(wings,X,q,side){
    if(q<0||q>2.2)return;
    woundSide(wings,side,(sp,i,s)=>{const r=+s.id.slice(4);const e=A_RIBS.find(x=>x[0]===r);if(!e)return null;const f=fOf(sp),tp=passA(f,e[1]);
      if(q<tp)return null;let k=Math.exp(-(q-tp)*2.6)*(.55+.45*smooth(f/.3));
      k=Math.max(k,.35*bump(unit((q-A_BACK-e[1])/(A_BACKRUN+.25))));k*=1-smooth((q-1.1)/.7);
      return k>.06?{l:Math.round(k*8)}:null;},{only:id=>/^rib-[234]$/.test(id)});
    const m=stutterMul(q,A_STUT);if(m<.999)scaleStrength(wings,keysOf(side),()=>m);
  },
  feel(out,q){const k=env(q,0,.03,.5,.4);out.flex=Math.min(1,(out.flex??0)+.25*k);out.beatRate*=1-.25*k;},
  paint(ctx,key,X,q,side){
    if(!key.startsWith(side)||q<0||q>2.2)return;
    const fr=Math.floor(q*30),stut=stutterMul(q,A_STUT);
    for(const [r,d] of A_RIBS){
      const s=liveStrand(X,side,`rib-${r}`);if(!s||!onKey(key,s))continue;
      {const h=headA(q,d),done=q>=d+A_RUN;const fEnd=h??(done?0:1);const age=q-d-A_RUN;const a=done?Math.exp(-Math.max(0,age)*3.2):1;
        if(fEnd<.98&&a>.03)current(ctx,crackle(sliceF(s.points,fEnd,1),.45,fr+r*5),.55,.42*a*stut,GOLDV,{bloom:.8,min:1.1});}
      for(const [h,dirTail,a,w] of [[headA(q,d),.2,1,.62],[headB(q,d),-.16,.62,.5]]){
        if(h==null)continue;const f0=Math.min(h,h+dirTail),f1=Math.max(h,h+dirTail);
        current(ctx,crackle(sliceF(s.points,Math.max(0,f0),Math.min(1,f1)),.8,fr*3+r),w*1.1,.8*a*stut,GOLDV,{bloom:1,min:1.5});
        const hp=pointAtF(s.points,h);current(ctx,crackle(sliceF(s.points,Math.max(0,h-.05),Math.min(1,h+.05)),.6,fr+r),w*1.6,a*stut,GOLDV,{bloom:1.3,min:2});
        ember(ctx,hp[0],hp[1],2.8,a*stut,GOLDV);
        for(const [wid,end,fj] of websOnC(r)){const dt=Math.abs(h-fj);if(dt>.07)continue;const ws=liveStrand(X,side,wid);if(!ws||!onKey(key,ws))continue;
          const flick=hash1(fr*1.7+fj*31+r)>.25?1:.3,len=.22+.18*hash1(fj*13+r*7+Math.floor(q*10));
          const sl=end==='a'?sliceF(ws.points,0,len):sliceF(ws.points,1-len,1);
          current(ctx,crackle(sl,1.1,fr*5+fj*17),.45,.95*a*flick*(1-dt/.06)*stut,GOLDV,{bloom:.8,min:1.1});}
      }
    }
    const tip=liveStrand(X,side,'rib-3');if(tip&&onKey(key,tip)){const p=tip.points.at(-1);star(ctx,p[0],p[1],2.2,bump(unit(q/.22))*.9,GOLDV,{flat:.3});
      const r0=tip.points[3];ember(ctx,r0[0],r0[1],2.2,.6*bump(unit((q-.14)/.28)),GOLDV);}
    if(q>.9&&q<1.9)for(const [r] of A_RIBS){const s=liveStrand(X,side,`rib-${r}`);if(!s||!onKey(key,s))continue;
      if(hash1(Math.floor(q*12)*3+r)<=.72)continue;const a=(1-smooth((q-.9)/1))*.7;
      current(ctx,crackle(sliceF(s.points,.86,.98),.6,Math.floor(q*30)+r),.35,a,GOLDV,{bloom:.5,min:.9});}
  },
  bitGlow(i,left,q,side){if(left!==(side==='left'))return null;const k=env(q,.02,.06,.75,.6);return k>0?[[240,200,120],.3*k,12]:null;},
  bit(o,i,left,q,side){if(left!==(side==='left'))return;const k=env(q,.02,.06,.75,.6);if(k<=0)return;
    const fr=Math.floor(q*30);if(q>A_STUT&&q<A_STUT+.4)o.spin+=(hash1(fr*3+i)-.5)*.35;o.dim=Math.max(o.dim,(1-stutterMul(q,A_STUT))*.6);},
};

/* ---- Acid: strands fray and corrode, then knit back together ---- */
const ACID={core:[232,255,160],bloom:[150,206,40]},KNIT={core:[255,226,240],bloom:[255,96,220]};
const ACID_C=[196,30];
const acidC=(sp,q)=>{if(q<0)return 0;const d=Math.hypot(sp[0]-ACID_C[0],sp[1]-ACID_C[1]),R=34+40*easeOut(q/.8);
  const knit=smooth((q-1.15-.6*Math.min(1,Math.hypot(sp[0]-ROOT[0],sp[1]-ROOT[1])/260))/.55);
  return easeOut(q/.25)*(1-smooth((d-R*.55)/(R*.6)))*(1-knit);};
W.acid={side:'left',
  pal:l=>{const k=l/10;const ink=ramp([[0,MAG],[.45,[206,84,150]],[.8,[176,204,60]],[1,[200,232,90]]],k);return {ink,halo:mixC(MAG,[150,190,50],k),core:mixC(MAG_CORE,[236,250,180],k),glow:1-.1*k,wire:1,edge:0,edgeColor:[236,250,180]};},
  geom(wings,X,q,side){const ends=X.ends=[];
    woundSide(wings,side,sp=>{const c=acidC(sp,q);if(c<.03)return null;
      const n=vnoise(sp[0]*.045+3,sp[1]*.045+7),g=c*(.15+n)-.72;
      const fray=c*smooth((g+.22)/.22);
      const d=fray>.01?[(vnoise(sp[0]*.2,sp[1]*.2)-.5)*5*fray,4.5*fray]:null;
      return {l:Math.round(Math.min(1,c*(.6+.6*fray))*10),g,d};},{ends});},
  paint(ctx,key,X,q,side){
    if(!key.startsWith(side)||q<0||q>2.8)return;const E=X.ends??[];
    const knitting=q>1.1;
    for(let k=0;k<E.length;k++){const p=E[k].p;if(!key.endsWith(p[2]>0?'Front':'Rear'))continue;if(hash1(k*1.7+.3)>.4)continue;
      if(!knitting)ember(ctx,p[0],p[1],1.3,.7*(.6+.4*Math.sin(q*9+k)),ACID);else ember(ctx,p[0],p[1],1.4,.8,KNIT);}
    let n=0;for(let k=0;k<E.length&&n<3;k++){if(hash1(k*3.7)<=.6)continue;const e=E[k],ph=((q*1.1+n*.37)%1),a=bump(ph)*(1-smooth((q-1.1)/.3));n++;if(a<.02)continue;
      ember(ctx,e.p[0],e.p[1]+ph*16,1.1,.6*a,ACID);}
  },
  bitGlow(i,left,q,side){if(left!==(side==='left'))return null;const k=env(q,.05,.3,1.2,.6);return k>0?[[170,210,70],.18*k,12]:null;},
  bit(o,i,left,q,side){if(left!==(side==='left'))return;const k=env(q,.05,.3,1.2,.6);if(k>0)o.tint=mixTint(o.tint,[.86,1,.62],k);},
};

/* ---- Force: one strand snaps cleanly and re-weaves ---- */
const FORCE={core:[246,238,255],bloom:[196,150,255]},WEAVE={core:[255,236,252],bloom:[255,110,232]},WEAVE_HEAD={core:[255,240,255],bloom:[255,120,236]},MEND={core:[255,232,200],bloom:[236,170,120]};
const SNAP={id:'rib-4',f:.58};
const forceGap=q=>{if(q<0)return 0;const open=.11*(1-Math.exp(-q*7)*Math.cos(q*16));return q<.95?open:open*(1-ease((q-1.7)/.28));};
const weaveK=q=>unit((q-.9)/.8);
W.force={side:'right',
  pal:l=>({ink:mixC(MAG,[255,140,240],l/6),halo:MAG,core:[255,236,255],glow:1+.2*l/6,wire:1+.4*l/6,edge:0,edgeColor:[255,236,255]}),
  geom(wings,X,q,side){
    if(q<0||q>2.3)return;const g=forceGap(q);if(g<.002)return;const sx=side==='left'?-1:1;
    const heal=bump(unit((q-1.65)/.6));
    woundSide(wings,side,(sp,i,s)=>{
      const n=s.points.length-1,f=i/n,inner=f<SNAP.f;
      const gp=inner?(SNAP.f-g*.8)-f:f-(SNAP.f+g*1.2);
      const near=inner?smooth(1-(SNAP.f-f)/.16):smooth(1-(f-SNAP.f)/.2);
      const curl=g/.11*near*near*1.4;
      const d=inner?[-sx*2*curl,-7*curl]:[sx*3*curl,6*curl+6*(g/.11)*Math.sin(Math.PI*unit((f-SNAP.f)/(1-SNAP.f)))];
      return {g:-gp,d,l:heal>.02&&Math.abs(f-SNAP.f)<.12?Math.round(heal*6):0};},{only:id=>id===SNAP.id});
  },
  paint(ctx,key,X,q,side){
    if(!key.startsWith(side)||!key.endsWith('Rear')||q<0||q>2.3)return;
    const s=liveStrand(X,side,SNAP.id);if(!s)return;const g=forceGap(q),sx=side==='left'?-1:1;
    const A=pointAtF(s.points,SNAP.f-g*.8),B=pointAtF(s.points,SNAP.f+g*1.2);
    const curl=g/.11*1.4;A[0]+=-sx*2*curl;A[1]+=-7*curl;B[0]+=sx*3*curl;B[1]+=6*curl;
    const snap=bump(unit(q/.45));star(ctx,A[0],A[1],2.8,snap,FORCE,{flat:.3});star(ctx,B[0],B[1],2.3,snap*.9,FORCE,{flat:.3});
    const run=env(q,0,.03,.12,.35);if(run>.02)current(ctx,sliceF(s.points,Math.max(0,SNAP.f-.4*easeOut(q/.3)),SNAP.f-g*.8),.6,.7*run,FORCE,{bloom:.6,min:1.2});
    const open=env(q,.1,.2,1.9,.2);ember(ctx,A[0],A[1],1.7,.9*open,FORCE);ember(ctx,B[0],B[1],1.6,.8*open,FORCE);
    const w=weaveK(q);if(w>0&&q<2.05){
      const L=Math.hypot(B[0]-A[0],B[1]-A[1])||1,nx=-(B[1]-A[1])/L,ny=(B[0]-A[0])/L,amp=Math.min(7,L*.2);
      for(const ph of [0,Math.PI]){const pts=[];const m=Math.max(2,Math.round(28*w));
        for(let k=0;k<=m;k++){const u=k/28,o=amp*Math.sin(u*TAU*1.5+ph)*Math.sin(Math.PI*u);pts.push([A[0]+(B[0]-A[0])*u+nx*o,A[1]+(B[1]-A[1])*u+ny*o]);}
        current(ctx,pts,.55,(1-smooth((q-1.75)/.3)),WEAVE,{bloom:.7,min:1.1});
        if(w<1){const h=pts.at(-1);ember(ctx,h[0],h[1],1.3,.9,WEAVE_HEAD);}}
    }
    const J=lerpPt(A,B,.5);star(ctx,J[0],J[1],2.2,bump(unit((q-1.68)/.5))*.75,MEND,{flat:.3});
  },
  bitGlow(i,left,q,side){if(left!==(side==='left'))return null;const k=bump(unit(q/.5));return k>0?[[210,180,255],.3*k,12]:null;},
};

/* ---- Mental (softened, approved): the struck wing stutters out of phase; lilac only where struck, half strength ---- */
const MIND={core:[236,220,250],bloom:[186,132,236]};
const mindK=q=>env(q,0,.1,1.75,.55);
const MIND_C=[176,-30],MIND_LEVELS=6,MIND_MAX=.5;
const mindArea=(sp,q)=>{const d=Math.hypot(sp[0]-MIND_C[0],sp[1]-MIND_C[1]),n=vnoise(sp[0]/38+q*.6,sp[1]/38)-.5;return 1-smooth((d+22*n-42)/70);};
/** The struck wing's sample-and-hold phase lag (the main thread holds the phase). */
export function mentalHold(q){const k=mindK(q);if(k<.01)return null;return {hold:Math.round(lerp(1,5,k*(.6+.4*Math.sin(q*5)))),lag:.2*k*(.6+.4*Math.sin(q*3.1))*TAU};}
W.mental={side:'left',
  pal:l=>{const k=l/MIND_LEVELS*MIND_MAX;return {ink:mixC(MAG,[206,92,255],k),halo:mixC(MAG,[170,110,240],k),core:mixC(MAG_CORE,[236,220,255],k),glow:1-.12*k,wire:1,edge:0,edgeColor:[236,220,255]};},
  geom(wings,X,q,side){const k=mindK(q);if(k<.02)return;
    woundSide(wings,side,sp=>{const l=Math.round(MIND_LEVELS*k*mindArea(sp,q));return l>0?{l}:null;});},
  paint(ctx,key,X,q,side){
    const k=mindK(q);if(k<.02||!key.startsWith(side))return;const base=X.sideBase[key];if(!base)return;
    ctx.save();ctx.lineCap='round';
    for(const s of base){if(s.hardware||s.star||!s.points)continue;if(!s.id.startsWith('edge-')&&!/^rib-(0|4|9)$/.test(s.id))continue;
      ctx.beginPath();for(let i=0;i<s.points.length;i++){const p=s.points[i];if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);}
      ctx.lineWidth=4;ctx.strokeStyle=rgba(MIND.bloom,.07*k);ctx.stroke();ctx.lineWidth=1.1;ctx.strokeStyle=rgba(MIND.core,.32*k*(.75+.25*Math.sin(q*13)));ctx.stroke();}
    ctx.restore();
  },
  bitGlow(i,left,q,side){if(left!==(side==='left'))return null;const k=mindK(q);return k>.02?[[200,150,240],.22*k,12]:null;},
  bit(o,i,left,q,side){if(left!==(side==='left'))return;const k=mindK(q);if(k<.02)return;const fr=Math.round(q*30);if(fr%4===3)o.dim=Math.max(o.dim,.25*k);},
};

/* ---- Void / spirit: the light dims from the inside out, then returns ---- */
const VOID_RIM=[206,176,255],VOID_INK=[120,62,160],VOID_FRONT={core:VOID_RIM,bloom:[120,80,200]},VOID_BACK={core:[255,206,246],bloom:[255,90,230]};
const voidFront=q=>.92*easeOut(q/.85),voidBack=q=>lerp(-.15,1.15,smooth((q-1.15)/1.25));
const voidK=(r,q,mul=1)=>q<0?0:smooth((voidFront(q)*mul-r)/.12)*(1-smooth((voidBack(q)-r)/.14));
W.void={side:'right',
  pal:l=>{const k=l/10;return {ink:mixC(MAG,VOID_INK,k),halo:mixC(MAG,[96,48,140],k),core:mixC(MAG_CORE,[150,120,190],k),glow:1-.55*k,wire:1-.2*k,edge:0,edgeColor:VOID_RIM,str:1-.26*k};},
  geom(wings,X,q,side){if(q<0||q>2.8)return;
    for(const sd of ['left','right']){const mul=sd===side?1:.45;
      woundSide(wings,sd,sp=>{const k=voidK(rOf(sp),q,mul);return k>.04?{l:Math.round(k*10)}:null;});}
    scaleStrength(wings,Object.keys(wings),s=>s.wl?1-.26*(s.wl/10):1);
  },
  paint(ctx,key,X,q,side,wings){
    if(q<0||q>2.8)return;const mul=key.startsWith(side)?1:.45;const sx=key.startsWith('left')?-1:1;
    const F=voidFront(q)*mul,B=voidBack(q);
    const rimA=(1-smooth((q-.9)/.35))*.6,retA=env(q,1.15,.2,2.3,.3)*.7;
    for(const s of wings[key]){if(s.hardware||s.star||!/^(rib|edge|web)-/.test(s.id))continue;const S=srcOf(s,sx);if(!S)continue;
      for(let j=0;j<2;j++){const front=j?B:F,a=j?retA:rimA,tint=j?VOID_BACK:VOID_FRONT;
        if(a<.02)continue;const run=[];
        for(let i=0;i<S.length;i++){const d=rOf(S[i])-front;if(d>-.035&&d<.01)run.push(s.points[i]);else if(run.length)break;}
        if(run.length>1)current(ctx,run,s.id.startsWith('web')?.3:.5,a,tint,{bloom:.6,min:1});
      }}
  },
  bitGlow(i,left,q,side){const mul=left===(side==='left')?1:.45;const back=bump(unit((voidBack(q)-.5)/.3));return back>0&&q>1.1?[[255,140,236],.3*back*mul,12]:null;},
  bit(o,i,left,q,side){const mul=left===(side==='left')?1:.45;const k=voidK(.55,q,mul);if(k>0){o.dim=Math.max(o.dim,.55*k);o.tint=mixTint(o.tint,[.72,.66,.76],k);}},
};

/* ---- Poison: a sickly pulse ---- */
const PULSES=[[0,1],[.42,.75],[1.22,.6]];
const POISON_C=[160,10];
const pulseAt=(sp,q)=>{let v=0;const d=Math.hypot(sp[0]-POISON_C[0],sp[1]-POISON_C[1]);
  for(const [at,amp] of PULSES){const front=(q-at)*170,w=26;const x=(front-d)/w;if(x>-1&&x<1.6)v=Math.max(v,amp*(x<0?1+x:1-x/1.6)*(1-smooth((d-150)/60)));}
  return Math.max(0,v);};
const sickBase=(sp,q)=>{const d=Math.hypot(sp[0]-POISON_C[0],sp[1]-POISON_C[1]);return .32*env(q,0,.3,1.9,.8)*(1-smooth((d-40)/90));};
W.poison={side:'right',
  pal:l=>{const k=l/12;const ink=ramp([[0,MAG],[.4,[214,70,170]],[.75,[184,190,74]],[1,[206,226,110]]],k);return {ink,halo:mixC(MAG,[130,160,50],k),core:mixC(MAG_CORE,[230,240,170],k),glow:1+.15*k,wire:1+.2*k,edge:0,edgeColor:[230,240,170],under:k>.3?[150,180,60,.08*k]:null};},
  geom(wings,X,q,side){if(q<0||q>3)return;woundSide(wings,side,sp=>{const v=Math.max(pulseAt(sp,q),sickBase(sp,q));return v>.04?{l:Math.round(v*12)}:null;});},
  feel(out,q){let h=0;for(const [at,amp] of PULSES)h=Math.max(h,amp*bump(unit((q-at)/.3)));out.beatRate*=1-.35*h;out.lift+=2.5*h;},
  bitGlow(i,left,q,side){const own=left===(side==='left');let h=0;for(const [at,amp] of PULSES)h=Math.max(h,amp*bump(unit((q-at-(own?.2:.35))/.35)));return h>0?[[160,190,70],.28*h,13]:null;},
  bit(o,i,left,q,side){const own=left===(side==='left');let h=0;for(const [at,amp] of PULSES)h=Math.max(h,amp*bump(unit((q-at-(own?.2:.35))/.35)));
    const base=env(q,.1,.4,1.9,.8)*(own?1:.5);const k=Math.max(base*.6,h);if(k>0)o.tint=mixTint(o.tint,[.84,1,.6],k);},
};

/* ---- Physical: slashing (a clean cut), piercing (a puncture), bludgeoning (dent and recoil) ---- */
const ROSE={core:[255,228,236],bloom:[240,120,180]},GOLD={core:[255,232,190],bloom:[214,170,96]},TORN={core:[255,180,196],bloom:[220,70,150]},THUD={core:[236,190,150],bloom:[150,60,120]};
const SLASH=[[118,-78],[236,52]];
function segDist(p,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],L2=dx*dx+dy*dy,tt=((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L2;return {d:Math.abs((p[0]-a[0])*dy-(p[1]-a[1])*dx)/Math.sqrt(L2),tt};}
const slashW=(t,q)=>{if(q<0)return 0;const open=easeOut((q-t*.12)/.08),seal=smooth((q-.75-t*.6)/.22);return 4.6*open*(1-seal);};
W.slashing={side:'right',
  pal:l=>({ink:mixC(MAG,[255,150,210],l/4),halo:MAG,core:[255,228,236],glow:1,wire:1+.3*l/4,edge:0,edgeColor:[255,228,236]}),
  geom(wings,X,q,side){if(q<0||q>1.6)return;const ends=X.ends=[];
    woundSide(wings,side,sp=>{const {d,tt}=segDist(sp,...SLASH);if(tt<-.05||tt>1.05)return null;const w=slashW(unit(tt),q)*(1-smooth((Math.abs(tt-.5)-.42)/.1));
      return w>0?{g:w-d,l:d<w+7?2:0}:null;},{ends});},
  paint(ctx,key,X,q,side){
    if(!key.startsWith(side)||!key.endsWith('Rear')||q<0||q>1.8)return;
    const A=liveAt(X,side,SLASH[0]),B=liveAt(X,side,SLASH[1]);
    const s=unit(q/.1),fade=1-smooth((q-.06)/.22);if(fade>0){const H=lerpPt(A,B,s);current(ctx,[lerpPt(A,B,Math.max(0,s-.7)),H],.5,fade,ROSE,{bloom:.8,min:1.3});}
    for(const e of X.ends??[])ember(ctx,e.p[0],e.p[1],1.5,.85*(1-smooth((q-.8)/.6)),ROSE);
    const sq=(q-.75)/.8;if(sq>0&&sq<1){const p=lerpPt(A,B,unit(sq*1.1-.05));ember(ctx,p[0],p[1],2.2,bump(sq),GOLD);}
  },
};
const PIERCE_C=[176,16];
W.piercing={side:'left',
  pal:l=>({ink:mixC(MAG,[255,160,200],l/4),halo:MAG,core:[255,228,236],glow:1,wire:1+.3*l/4,edge:0,edgeColor:[255,228,236]}),
  geom(wings,X,q,side){if(q<0||q>1.8)return;const ends=X.ends=[];const sx=side==='left'?-1:1;
    const hole=13*easeOut(q/.05)*(1-smooth((q-.65)/.8)),push=easeOut(q/.06)*(1-smooth((q-.4)/1.1));
    woundSide(wings,side,sp=>{const dx=sp[0]-PIERCE_C[0],dy=sp[1]-PIERCE_C[1],d=Math.hypot(dx,dy);if(d>70)return null;
      const k=push*(hole+9)*Math.exp(-((d/30)**2))/Math.max(d,1);
      return {g:hole-d,d:[sx*dx*k,dy*k],l:d<hole+12?2:0};},{ends});},
  paint(ctx,key,X,q,side){
    if(!key.startsWith(side)||!key.endsWith('Rear')||q<0||q>1.8)return;
    const c=liveAt(X,side,PIERCE_C);
    star(ctx,c[0],c[1],2.6,bump(unit(q/.3)),ROSE,{flat:.28,rot:.6});
    const E=X.ends??[];for(let k=0;k<E.length;k+=2)ember(ctx,E[k].p[0],E[k].p[1],1.1,.5*(1-smooth((q-.5)/.6)),TORN);
  },
};
const BLUNT_C=[196,24];
const dent=q=>q<0?0:34*Math.exp(-q*3.0)*Math.cos(q*10.5)*easeOut(q/.04);
W.bludgeoning={side:'right',
  pal:l=>({ink:mixC(MAG,[150,30,130],l/4),halo:mixC(MAG,[120,30,110],l/4),core:MAG_CORE,glow:1-.4*l/4,wire:1,edge:0,edgeColor:MAG_CORE,str:1-.3*l/4}),
  geom(wings,X,q,side){if(q<0||q>2)return;const sx=side==='left'?-1:1,D=dent(q),bruise=env(q,0,.03,.35,.6);
    woundSide(wings,side,sp=>{const dx=sp[0]-BLUNT_C[0],dy=sp[1]-BLUNT_C[1],d=Math.hypot(dx,dy);if(d>140)return null;
      const fall=Math.exp(-((d/56)**2)),rx=sp[0]-ROOT[0],ry=sp[1]-ROOT[1],rl=Math.hypot(rx,ry)||1;
      return {d:[-sx*rx/rl*D*fall,-ry/rl*D*fall*.7],l:Math.round(4*bruise*fall)};});
    scaleStrength(wings,Object.keys(wings),s=>s.wl?1-.2*s.wl/4:1);},
  paint(ctx,key,X,q,side){if(!key.startsWith(side)||!key.endsWith('Rear')||q<0||q>.5)return;const c=liveAt(X,side,BLUNT_C);
    ember(ctx,c[0]-(side==='left'?-1:1)*8,c[1],9,.28*bump(unit(q/.45)),THUD);},
};
/* ---- Other types: a soft generic mark in the type's own colour (no look of its own) ---- */
const OTHER_C=[178,0];
W.other={side:'right',
  pal:null,   // per tint (see palette)
  geom(wings,X,q,side){if(q<0||q>2.4)return;const k=env(q,0,.12,.9,1.1);if(k<.02)return;
    woundSide(wings,side,sp=>{const d=Math.hypot(sp[0]-OTHER_C[0],sp[1]-OTHER_C[1]),R=40+50*easeOut(q/.8);const v=k*(1-smooth((d-R*.5)/(R*.6)));return v>.06?{l:Math.round(v*8)}:null;});},
  paint(ctx,key,X,q,side,wings,D){if(!key.startsWith(side)||!key.endsWith('Rear')||q<0||q>1.2)return;const c=liveAt(X,side,OTHER_C),t=tintOf(D.wound?.tint);
    star(ctx,c[0],c[1],2.2,bump(unit(q/.5))*.8,t,{flat:.3});},
};

/** The look that plays for a wound (electricity by the picker). */
const woundLook=w=>w?.look==='electricity'?(w.elec==='a'?W.elecA:W.elecB):W[w?.look]??null;
/** The bit modifiers of a wound for this frame (feel side): writes into o = {spin,dim,tint,hold,spinMul}. */
export function woundBit(w,o,i,left){const L=woundLook(w);if(!L?.bit||w.q<0||w.q>WOUND_SPAN)return;L.bit(o,i,left,w.q,w.side);}
/** The feel tweaks of a wound (beat rate, flex, lift). */
export function woundFeel(w,out){const L=woundLook(w);if(L?.feel&&w.q>=0&&w.q<WOUND_SPAN)L.feel(out,w.q);}
/** The lab's default struck side of a look (when the blow comes straight on). */
export const woundSideOf=look=>(look==='electricity'?W.elecB:W[look])?.side??'right';
const mixTint=(a,b,k)=>a?[lerp(a[0],b[0],k),lerp(a[1],b[1],k),lerp(a[2],b[2],k)]:[lerp(1,b[0],k),lerp(1,b[1],k),lerp(1,b[2],k)];
const tintOf=t=>t?{core:[t[3],t[4],t[5]],bloom:[t[0],t[1],t[2]]}:{core:[255,236,246],bloom:[255,110,230]};

/* =====================================================================
 * 2. PERSISTENT DAMAGE: each type claims one wing quarter; accents take turns
 * ===================================================================== */
export const CYCLE=4.4,LEAD=1.4,CLEAN_T=1.7;
export const SLOT_OFF=Object.freeze([0,.5,.25,.75]);
export const QUADS=Object.freeze({RU:{side:'right',band:'upper'},LU:{side:'left',band:'upper'},RL:{side:'right',band:'lower'},LL:{side:'left',band:'lower'}});
const bandOfId=id=>{const m=/^(rib|web|cross|edge)-(\d+)/.exec(id);if(!m)return null;const n=+m[2];if(m[1]==='edge')return n<=2?'upper':'lower';return n<=4?'upper':'lower';};
const BANDS={upper:{ribs:[0,1,2,3,4],spine:[3,2,4],tipRib:4,highRib:0,edge:[['edge-2',.3,1]],c:[150,-78],cut:[[1,.66],[3,.7]],pierce:[148,-96],panels:[[1,2,.58,.78],[2,3,.52,.72]],dripRib:4},
  lower:{ribs:[5,6,7,8,9],spine:[7,6,8],tipRib:9,highRib:6,edge:[['edge-3',0,1],['edge-4',0,.75]],c:[148,118],cut:[[6,.64],[8,.62]],pierce:[150,108],panels:[[6,7,.55,.75],[7,8,.5,.7]],dripRib:9}};
const CLEAN_GLINT={core:[255,236,246],bloom:[255,110,230]},WARM={core:[255,232,200],bloom:[236,170,120]};
const cleanPal=l=>{const k=l/8;return {ink:mixC(MAG,[255,130,214],k),halo:mixC(MAG,[255,150,170],k),core:mixC(MAG_CORE,[255,236,214],k),glow:1+.35*k,wire:1+.35*k,edge:0,edgeColor:[255,236,214]};};
const accEnv=(ph,len=.3)=>{const x=ph/len;return x<1?(x<.25?smooth(x/.25):1-smooth((x-.25)/.75)):0;};
/** Each look's preferred quarters (in order). */
export const PERSIST_PREFER=Object.freeze({bleed:['LL','RL','LU','RU'],fire:['RU','LU','RL','LL'],poison:['RL','LL','RU','LU'],acid:['LU','RU','LL','RL'],cold:['LU','RU','LL','RL'],electricity:['RU','LU','RL','LL'],
  sonic:['RL','LL','RU','LU'],mental:['LU','RU','LL','RL'],force:['RU','LU','RL','LL'],vitality:['LU','RU','LL','RL'],void:['RL','LL','RU','LU'],spirit:['LL','RL','LU','RU'],
  slashing:['RU','LU','RL','LL'],piercing:['LU','RU','LL','RL'],bludgeoning:['RL','LL','RU','LU'],precision:['RU','LU','RL','LL'],fallback:['RU','LU','RL','LL']});
export const PERSIST_PHSHIFT=Object.freeze({bleed:.72});
const P={};
const BLEED={core:[255,200,226],bloom:[214,30,96]};
P.bleed={
  pal:l=>({ink:mixC(MAG,[226,24,104],l/6),halo:mixC(MAG,[200,20,90],l/6),core:mixC(MAG_CORE,[255,200,220],l/6),glow:1,wire:1,edge:0,edgeColor:MAG_CORE}),
  field(sp,s,c){const tp=srcPt(`rib-${c.band.dripRib}`,1),d=Math.hypot(sp[0]-tp[0],sp[1]-tp[1]);const k=c.k*(1-smooth((d-25)/70));return k>.05?{l:Math.round(k*6)}:null;},
  marks(c,X,out){const s=liveStrand(X,c.side,`rib-${c.band.dripRib}`);if(!s||c.cq>=0)return;const tip=s.points.at(-1);out.push([tip[0],tip[1]+(c.px??1.7)*36]);},
  paint(ctx,key,c,X){const s=liveStrand(X,c.side,`rib-${c.band.dripRib}`);if(!s||!onKey(key,s))return;const tip=s.points.at(-1);
    if(c.cq<0&&c.on>.3){const fr=c.ph,sw=fr<.72?smooth(fr/.72):0,ry=fr<.72?2+6*sw:2;
      current(ctx,[tip,[tip[0],tip[1]+ry]],.35,(.25+.55*sw)*c.on,BLEED,{bloom:.5,min:1});ember(ctx,tip[0],tip[1]+ry,1.3+2.6*sw,(.6+.4*sw)*c.on,BLEED);
      // the falling drop (the lab draws it on the map: a short way off her, fading before the ground)
      if(fr>=.72){const px=c.px??1.7,fall=(fr-.72)/.28,y=tip[1]+2*px+3*px+30*px*fall*fall,a=1-smooth((fall-.35)/.65);
        ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=rgba(BLEED.bloom,.4*a);ctx.lineWidth=1.3*px;ctx.beginPath();ctx.moveTo(tip[0],y-8*px*fall);ctx.lineTo(tip[0],y);ctx.stroke();
        const R=5.5*px,gr=ctx.createRadialGradient(tip[0],y,0,tip[0],y,R);gr.addColorStop(0,rgba(BLEED.core,.9*a));gr.addColorStop(.22,rgba(BLEED.bloom,.9*a*.45));gr.addColorStop(1,rgba(BLEED.bloom,0));ctx.fillStyle=gr;ctx.fillRect(tip[0]-R,y-R,R*2,R*2);ctx.restore();}}
    if(c.cq>=0&&c.cl<1){const up=1-easeOut(c.cl);ember(ctx,tip[0],tip[1]+6*up,3.2*up+.4,.9*(1-c.cl*.6),BLEED);star(ctx,tip[0],tip[1],2.6,bump(unit((c.cl-.35)/.65)),CLEAN_GLINT,{flat:.3});}},
};
function firePos(c){const path=c.band.edge,tot=path.reduce((a,[,f0,f1])=>a+(f1-f0),0),span=7,q=Math.max(0,(c.cq>=0?c.cq0:c.q)),cyc=(q/span)%2,u=cyc<1?cyc:2-cyc,dir=cyc<1?1:-1;
  let x=u*tot;for(const [id,f0,f1] of path){const l=f1-f0;if(x<=l+1e-9)return {id,f:f0+x,dir};x-=l;}const z=path.at(-1);return {id:z[0],f:z[2],dir};}
P.fire={
  pal:W.fire.pal,
  pre(c,X){X.ep[c.n]=firePos(c);},
  field(sp,s,c,i,X){const pos=X.ep[c.n];if(!pos||s.id!==pos.id)return null;const d=(fOf(sp)-pos.f)*-pos.dir;const k=c.k*(d>=-.03&&d<.32?(1-smooth((d-.02)/.3)):0)*(1+.3*c.acc);return k>.04?{l:Math.min(12,Math.round(k*10))}:null;},
  paint(ctx,key,c,X){const pos=X.ep[c.n];if(!pos)return;const s=liveStrand(X,c.side,pos.id);if(!s||!onKey(key,s))return;
    const p=pointAtF(s.points,pos.f),fl=.75+.25*Math.sin(c.t*19)*Math.sin(c.t*7.3);
    if(c.cq<0){const a=c.on*fl*(1+.35*c.acc);ember(ctx,p[0],p[1],3.4*(1+.25*c.acc),a,FIRE);star(ctx,p[0],p[1],1.3,.6*a,FIRE,{flat:.5});
      if(c.acc>.02){const f=pos.f-pos.dir*.1*easeOut(c.ph/.3);const e=pointAtF(s.points,Math.max(0,Math.min(1,f)));ember(ctx,e[0],e[1],1.6,.8*c.acc,FIRE);}}
    else{const k=(1-smooth(c.cl))*(1+.6*bump(unit(c.cl/.35)));ember(ctx,p[0],p[1],3.4*(1-.6*c.cl),k,FIRE);star(ctx,p[0],p[1],1.8,bump(unit((c.cl-.5)/.5))*.6,CLEAN_GLINT,{flat:.3});}},
};
function pulseField(sp,c,base=.22){const r=rOf(sp);
  if(c.cq<0){const front=(c.ph/.55)*1.5-.2,band=c.ph<.55?Math.max(0,1-Math.abs(r-front)/.16):0;return {lvl:Math.max(base*c.on,band*c.on),alt:false};}
  const front=c.cl*1.5-.25;if(r>front)return {lvl:base*(1-smooth(c.cl/.8)),alt:false};return {lvl:Math.max(0,1-(front-r)/.25)*(1-smooth((c.cl-.75)/.25)),alt:true};}
P.poison={pal:W.poison.pal,pal2:cleanPal,
  field(sp,s,c){const v=pulseField(sp,c);const l=Math.round(v.lvl*(v.alt?8:12));return l?{l,alt:v.alt}:null;},
  feel(out,c){if(c.cq<0)out.beatRate*=1-.1*c.acc;},
  bit(o,i,left,c){if(left!==(c.side==='left'))return;const k=c.cq<0?c.on*(.35+.65*c.acc):1-smooth(c.cl/.7);if(k>0)o.tint=mixTint(o.tint,[.86,1,.64],k);},
};
const ACID_PAL=l=>{const k=l/12;const ink=ramp([[0,MAG],[.45,[206,84,150]],[.8,[176,204,60]],[1,[200,232,90]]],k);return {ink,halo:mixC(MAG,[150,190,50],k),core:mixC(MAG_CORE,[236,250,180],k),glow:1-.1*k,wire:1,edge:0,edgeColor:[236,250,180]};};
P.acid={pal:ACID_PAL,pal2:cleanPal,ends:true,
  field(sp,s,c){const v=pulseField(sp,c,.25);const l=Math.round(v.lvl*(v.alt?8:12));
    const d=Math.hypot(sp[0]-c.band.c[0],sp[1]-c.band.c[1]),n=vnoise(sp[0]*.06+3,sp[1]*.06+7);
    const open=c.k*(.55+.45*c.acc)*(c.cq<0?1:1-smooth(c.cl/.6));const g=open*(n-.62)*(1-smooth((d-30)/40))*4-.04;
    return l||g>0?{l,alt:v.alt,g:g>0?g:-1}:null;},
  paint(ctx,key,c,X){const E=X.pends[c.n]??[];for(let k=0;k<E.length;k+=2){const e=E[k];if(!key.endsWith(e.p[2]>0?'Front':'Rear'))continue;
    ember(ctx,e.p[0],e.p[1],1.2,c.cq<0?.6*c.k*(.6+.4*c.acc):.85*bump(unit(c.cl/.6)),c.cq<0?ACID:KNIT);}},
};
const FERN2=[frostFern(11),frostFern(12)];
function panelMapQ(c,X,[i,j,fa,fb]){const A=liveStrand(X,c.side,`rib-${i}`),Bs=liveStrand(X,c.side,`rib-${j}`);if(!A||!Bs)return null;
  const a0=pointAtF(A.points,fa),a1=pointAtF(A.points,fb),b0=pointAtF(Bs.points,fa+.02),b1=pointAtF(Bs.points,fb+.02);return (s,t)=>lerpPt(lerpPt(a0,a1,t),lerpPt(b0,b1,t),s);}
P.cold={pal:W.cold.pal,
  field(sp,s,c){const cc=c.band.c,d=Math.hypot(sp[0]-cc[0],sp[1]-cc[1]+10);const k=c.k*(1-smooth((d-30)/55))*(.8+.2*c.acc);return k>.06?{l:Math.round(k*8)}:null;},
  feel(out,c){out.beatRate*=1-.06*c.k;},
  paint(ctx,key,c,X){if(!key.endsWith('Rear'))return;
    c.band.panels.forEach((pn,k)=>{const M=panelMapQ(c,X,pn);if(!M)return;const melt=c.cq<0?0:smooth((c.cl-k*.08)/.75);
      const grow=Math.min(1,c.q/1.2),hold=.62+.38*c.acc;
      for(const br of FERN2[k]){const g=easeOut((grow-br.t0*.9)/br.dur)*hold;if(g<=0)continue;const len=g*(1-melt*.9);if(len<=.01)continue;
        const pts=[];for(let n=0;n<=5;n++)pts.push(M(...lerpPt(br.a,br.b,n/5*len)));
        if(melt>.02)ctx.setLineDash([2.2*(1-melt)+.4,1.2+5*melt]);current(ctx,pts,br.w,(1-melt)*.9*c.on,ICE,{bloom:.5,min:.9});ctx.setLineDash([]);}
      if(c.acc>.02&&c.cq<0){const sp=FERN2[k][0],u=unit(c.ph/.3+k*.1);const p=M(...lerpPt(sp.a,sp.b,u*hold));star(ctx,p[0],p[1],1.4,c.acc,ICE,{flat:.3});}
      const mq=c.cq<0?-1:(c.cl-.1-k*.1)/.8;if(mq>0&&mq<1){const p=M(.5,lerp(.6,1.05,easeOut(mq)));ember(ctx,p[0],p[1]+mq*10,1.4,.7*bump(mq),ICE);}});},
  bit(o,i,left,c){if(left!==(c.side==='left'))return;o.spinMul*=1-.5*c.k;},
};
const RUN=.24,PSTUT=[1,.45,1,1,.6,1];
P.electricity={
  pal:W.elecA.pal,
  pre(c){c.qa=c.ph*CYCLE;c.rib=c.band.spine[c.cycleN%3];},
  field(sp,s,c){if(!s.id.startsWith('rib-'))return null;const r=+s.id.slice(4);const qa=c.qa;
    if(c.cq<0){if(r!==c.rib||c.on<.5)return null;const tp=RUN*(1-Math.cbrt(fOf(sp)));if(qa<tp)return null;const k=Math.exp(-(qa-tp)*2.4)*c.on;return k>.08?{l:Math.round(k*8)}:null;}
    if(r!==c.band.spine[1])return null;const f=fOf(sp),head=easeOut(c.cl/.7);const k=f<head?.7*(1-smooth((c.cl-.6)/.4)):0;return k>.06?{l:Math.round(k*8)}:null;},
  dim(c){if(c.cq>=0)return 1;const fr=Math.floor((c.qa-.5)*30);return fr<0||fr>=PSTUT.length?1:PSTUT[fr];},
  paint(ctx,key,c,X){
    if(c.cq>=0){const s=liveStrand(X,c.side,`rib-${c.band.spine[1]}`);if(!s||!onKey(key,s))return;const h=easeOut(c.cl/.7);
      if(c.cl<.75){const p=pointAtF(s.points,h);current(ctx,sliceF(s.points,Math.max(0,h-.15),h),.6,.7,GOLDV,{bloom:.8,min:1.2});ember(ctx,p[0],p[1],2.2,.9,GOLDV);}
      const tp=s.points.at(-1);star(ctx,tp[0],tp[1],2.4,bump(unit((c.cl-.62)/.38)),WARM,{flat:.3});return;}
    if(c.on<.5)return;const qa=c.qa,r=c.rib,s=liveStrand(X,c.side,`rib-${r}`);if(!s||!onKey(key,s))return;const fr=Math.floor(c.t*30),dm=P.electricity.dim(c);
    for(const [h,tl,a,w] of [[qa<RUN?1-easeOut(qa/RUN):null,.2,1,.62],[qa>.42&&qa<.68?easeOut((qa-.42)/.26)*.9:null,-.16,.6,.5]]){
      if(h==null)continue;const f0=Math.min(h,h+tl),f1=Math.max(h,h+tl);
      current(ctx,crackle(sliceF(s.points,Math.max(0,f0),Math.min(1,f1)),.8,fr*3+r),w*1.1,.8*a*dm,GOLDV,{bloom:1,min:1.5});
      const hp=pointAtF(s.points,h);current(ctx,crackle(sliceF(s.points,Math.max(0,h-.05),Math.min(1,h+.05)),.6,fr+r),w*1.6,a*dm,GOLDV,{bloom:1.3,min:2});ember(ctx,hp[0],hp[1],2.8,a*dm,GOLDV);
      for(const [wid,end,fj] of websOnC(r)){const dt=Math.abs(h-fj);if(dt>.07)continue;const ws=liveStrand(X,c.side,wid);if(!ws||!onKey(key,ws))continue;
        if(c.band.ribs.indexOf(+wid.split('-')[1])<0)continue;
        const len=.22+.18*hash1(fj*13+r*7+Math.floor(qa*10)),sl=end==='a'?sliceF(ws.points,0,len):sliceF(ws.points,1-len,1);
        current(ctx,crackle(sl,1.1,fr*5+fj*17),.45,.95*a*(hash1(fr*1.7+fj*31)>.25?1:.3)*(1-dt/.07)*dm,GOLDV,{bloom:.8,min:1.1});}}
    if(qa>1&&hash1(Math.floor(c.t*12)*3+r)>.82)current(ctx,crackle(sliceF(s.points,.84,.97),.6,fr+r),.35,.5*c.on,GOLDV,{bloom:.5,min:.9});},
  glow(i,left,c){if(left!==(c.side==='left'))return null;const k=c.cq<0?c.on*accEnv(c.ph,.18):0;return k>0?[[240,200,120],.28*k,12]:null;},
};
const sonAmp=c=>c.cq<0?c.on*(1.4+5*c.acc*Math.exp(-c.ph*4)):5*Math.exp(-c.cq*3.2)*(1-smooth(c.cl));
P.sonic={
  pal:l=>{const k=l/8;return {ink:mixC(MAG,[150,226,220],k),halo:mixC(MAG,[90,190,200],k),core:mixC(MAG_CORE,[226,252,246],k),glow:1+.25*k,wire:1+.4*k,edge:0,edgeColor:[226,252,246]};},
  field(sp,s,c,i){if(!s.id.startsWith('rib-')&&!s.id.startsWith('edge-'))return null;const f=fOf(sp),A=sonAmp(c),mode=s.id.startsWith('edge')?2:3;
    const shape=Math.sin(Math.PI*mode*f)*smooth(f/.12),osc=Math.cos(c.t*TAU*4.2+(+s.id.slice(-1))*1.3);
    const pts=s.points,a=pts[Math.max(0,i-1)],b=pts[Math.min(pts.length-1,i+1)],dx=b[0]-a[0],dy=b[1]-a[1],Ln=Math.hypot(dx,dy)||1;
    const off=A*shape*osc,lv=Math.round(Math.min(1,Math.abs(shape)*(.5+.12*A))*8*(c.cq<0?c.on:1-smooth(c.cl/.8)));
    return {l:lv,d:[-dy/Ln*off,dx/Ln*off]};},
  paint(ctx,key,c,X){if(c.cq<0||!key.endsWith('Rear'))return;const s=liveStrand(X,c.side,`rib-${c.band.spine[1]}`);if(!s)return;const p=pointAtF(s.points,.5);star(ctx,p[0],p[1],2,bump(unit((c.cl-.5)/.5))*.8,CLEAN_GLINT,{flat:.3});},
};
P.mental={
  pal:l=>{const k=l/7;return {ink:mixC(MAG,[200,130,255],k),halo:mixC(MAG,[170,110,240],k),core:mixC(MAG_CORE,[236,220,255],k),glow:1+.3*k,wire:1-.3*k,edge:0,edgeColor:[236,220,255]};},pal2:cleanPal,
  field(sp,s,c){const n=vnoise(sp[0]*.03+c.t*.22,sp[1]*.03-c.t*.15),k=c.k*(.25+.75*smooth((n-.35)/.35));
    if(c.cq>=0){const r=rOf(sp),front=c.cl*1.4-.2;if(r<front-.18)return null;if(r<front)return {l:Math.round(8*(1-(front-r)/.18)*(1-smooth((c.cl-.8)/.2))),alt:true};}
    return k>.08?{l:Math.round(k*7)}:null;},
};
/** Persistent mental: the wing hitches on its turn (the main thread holds that side's phase). */
export const persistHitch=c=>c.look==='mental'&&c.cq<0&&c.ph<.14&&c.on>.5;
const forceDepth=c=>c.cq<0?c.on*(11+10*c.acc):(11)*Math.exp(-c.cq*3.2)*Math.cos(c.cq*10);
const PRESS={core:[236,220,255],bloom:[150,110,230]};
P.force={
  pal:l=>({ink:mixC(MAG,[236,170,255],l/6),halo:mixC(MAG,[196,150,255],l/6),core:[250,236,255],glow:1+.15*l/6,wire:1+.4*l/6,edge:0,edgeColor:[250,236,255]}),
  field(sp,s,c){const cc=c.band.c,dx=sp[0]-cc[0],dy=sp[1]-cc[1],d=Math.hypot(dx,dy);if(d>110)return null;const fall=Math.exp(-((d/55)**2)),D=forceDepth(c);
    const rx=sp[0]-ROOT[0],ry=sp[1]-ROOT[1],rl=Math.hypot(rx,ry)||1;const lv=Math.round(6*Math.min(1,fall*1.4)*Math.min(1,Math.abs(D)/9)*(c.cq<0?1:1-smooth(c.cl)));
    return {l:lv,d:[-c.sx*rx/rl*D*fall,-ry/rl*D*fall*.7]};},
  paint(ctx,key,c,X){if(!key.endsWith('Rear'))return;const p=liveAt(X,c.side,c.band.c);
    if(c.cq<0){ember(ctx,p[0],p[1],9,.16*c.on+.22*c.acc,PRESS);return;}
    star(ctx,p[0],p[1],2.6,bump(unit((c.cq-.05)/.5))*.9,FORCE,{flat:.3});},
};
const VITA={core:[255,250,226],bloom:[240,200,120]};
P.vitality={
  pal:l=>{const k=l/8;return {ink:mixC(MAG,[255,226,176],k),halo:mixC(MAG,[255,200,150],k),core:mixC(MAG_CORE,[255,252,236],k),glow:1+.6*k,wire:1+.6*k,edge:0,edgeColor:[255,252,236]};},
  field(sp,s,c){const r=rOf(sp);let k;
    if(c.cq<0){const front=(c.ph/.5)*1.4-.2,sheen=c.ph<.5?Math.max(0,1-Math.abs(r-front)/.18):0;k=c.on*(.3+.7*sheen);}
    else{const back=1.15-c.cl*1.4;k=r<back?.3*(1-smooth((back-r)/.3))+.5*Math.max(0,1-Math.abs(r-back)/.15):0;k*=1-smooth((c.cl-.8)/.2);}
    return k>.06?{l:Math.round(k*8)}:null;},
  paint(ctx,key,c,X){const s=liveStrand(X,c.side,`rib-${c.band.highRib}`);if(!s||!onKey(key,s))return;const tp=s.points.at(-1);
    if(c.cq<0)ember(ctx,tp[0],tp[1],1.8,c.on*(.45+.4*Math.sin(c.t*2.1)**2),VITA);
    else{const r0=s.points[2];star(ctx,r0[0],r0[1],2.2,bump(unit((c.cl-.55)/.45))*.8,WARM,{flat:.3});}},
};
const voidR=c=>c.cq<0?c.on*(44+7*Math.sin(c.t*.9)+16*c.acc):(48)*(1-easeOut(c.cl));
P.void={
  pal:l=>{const k=l/10;return {ink:mixC(MAG,[120,62,160],k),halo:mixC(MAG,[96,48,140],k),core:mixC(MAG_CORE,[150,120,190],k),glow:1-.55*k,wire:1-.2*k,edge:0,edgeColor:VOID_RIM};},
  pal2:l=>{const k=l/8;return {ink:mixC(MAG,[214,186,255],k),halo:mixC(MAG,[160,130,240],k),core:mixC(MAG_CORE,[236,226,255],k),glow:1+.2*k,wire:1+.3*k,edge:0,edgeColor:VOID_RIM};},
  str:(l,alt)=>alt?1:1-.72*l/10,
  field(sp,s,c){const cc=c.band.c,d=Math.hypot(sp[0]-cc[0],sp[1]-cc[1]),R=voidR(c);if(R<1)return null;
    const inner=1-smooth((d-R*.72)/(R*.3)),rim=Math.max(0,1-Math.abs(d-R)/11);
    if(c.cq>=0&&rim>.2)return {l:Math.round(rim*8*(.6+.4*bump(c.cl))),alt:true};
    if(inner>.08)return {l:Math.round(inner*10)};if(rim>.2&&c.cq<0)return {l:Math.round(rim*8*c.on),alt:true};return null;},
  bit(o,i,left,c){if(left!==(c.side==='left'))return;const k=c.k*.6;if(k>0)o.tint=mixTint(o.tint,[.82,.78,.84],k);},
};
const SPIRIT={core:[236,240,255],bloom:[150,166,236]};
P.spirit={
  pal:l=>{const k=l/8;return {ink:mixC(MAG,[186,190,240],k),halo:mixC(MAG,[140,150,230],k),core:mixC(MAG_CORE,[240,242,255],k),glow:1-.2*k,wire:1-.1*k,edge:0,edgeColor:[240,242,255]};},pal2:cleanPal,
  str:(l,alt)=>alt?1:1-.35*l/8,
  field(sp,s,c){const r=rOf(sp);
    if(c.cq<0){const w=.5+.5*Math.sin(c.t*.8-r*4);const k=c.on*(.45+.35*w+.3*c.acc*smooth((r-.4)/.4));return {l:Math.round(Math.min(1,k)*8)};}
    const front=1.2-c.cl*1.5;if(r>front)return {l:Math.round(8*Math.max(0,1-(r-front)/.2)*(1-smooth((c.cl-.8)/.2))),alt:true};return {l:Math.round(6*(1-smooth(c.cl/.9)))};},
  paint(ctx,key,c,X){const e=c.band.edge.at(-1),s=liveStrand(X,c.side,e[0]);if(!s||!onKey(key,s))return;
    if(c.cq<0&&c.acc>.01){const u=easeOut(c.ph/.32),f=lerp(e[1]+.1,e[2],u);current(ctx,sliceF(s.points,Math.max(e[1],f-.18),f),.4,.8*c.acc,SPIRIT,{bloom:.7,min:1});const p=pointAtF(s.points,f);ember(ctx,p[0],p[1],1.6,.8*c.acc,SPIRIT);}
    if(c.cq>=0){const tp=pointAtF(s.points,e[2]);star(ctx,tp[0],tp[1],2.2,bump(unit(c.cl/.5))*.8,CLEAN_GLINT,{flat:.3});}},
};
const cutEnds=c=>c.band.cut.map(([r,f])=>srcPt(`rib-${r}`,f));
P.slashing={pal:W.slashing.pal,ends:true,
  field(sp,s,c){const [a,b]=cutEnds(c),ext=[lerpPt(a,b,-.12),lerpPt(a,b,1.12)];const {d,tt}=segDist(sp,...ext);if(tt<0||tt>1)return null;
    const seal=c.cq<0?0:unit(c.cl/.8*1.15-.05),w=3.4*c.on*(1-smooth((Math.abs(tt-.5)-.42)/.08))*(c.cq<0?1:(tt<seal?0:1-smooth((c.cl-.8)/.2)));
    return w>0?{g:w-d,l:d<w+6?2:0}:null;},
  paint(ctx,key,c,X){if(!key.endsWith('Rear'))return;const [a,b]=cutEnds(c),A=liveAt(X,c.side,lerpPt(a,b,-.12)),Bp=liveAt(X,c.side,lerpPt(a,b,1.12));
    for(const e of X.pends[c.n]??[])ember(ctx,e.p[0],e.p[1],1.3,.75*c.k,ROSE);
    if(c.cq<0&&c.acc>.01){const u=.45*easeOut(c.ph/.3),p=lerpPt(A,Bp,u);ember(ctx,p[0],p[1],2.1,c.acc,GOLD);}
    if(c.cq>=0&&c.cl<1){const u=unit(c.cl/.8),p=lerpPt(A,Bp,u);ember(ctx,p[0],p[1],2.2,bump(unit(c.cl/.95)),GOLD);star(ctx,p[0],p[1],2,bump(unit((c.cl-.75)/.25))*.8,WARM,{flat:.3});}},
};
P.piercing={pal:W.piercing.pal,ends:true,
  field(sp,s,c){const C=c.band.pierce,dx=sp[0]-C[0],dy=sp[1]-C[1],d=Math.hypot(dx,dy);if(d>60)return null;
    const hole=(c.cq<0?c.on*(9+3.5*c.acc):9*(1-easeOut(c.cl/.8))),push=hole/9;const k=push*(hole+7)*Math.exp(-((d/26)**2))/Math.max(d,1);
    return {g:hole-d,d:[c.sx*dx*k,dy*k],l:d<hole+10&&hole>.5?2:0};},
  paint(ctx,key,c,X){if(!key.endsWith('Rear'))return;const E=X.pends[c.n]??[];for(let k=0;k<E.length;k+=2)ember(ctx,E[k].p[0],E[k].p[1],1.1,(.4+.4*c.acc)*c.k,TORN);
    if(c.cq>=0){const p=liveAt(X,c.side,c.band.pierce);star(ctx,p[0],p[1],2,bump(unit((c.cl-.6)/.4))*.8,WARM,{flat:.3});}},
};
const dentD=c=>c.cq<0?c.on*(15+8*c.acc):15*Math.exp(-c.cq*3)*Math.cos(c.cq*10.5);
P.bludgeoning={pal:W.bludgeoning.pal,str:l=>1-.4*l/4,
  paint(ctx,key,c,X){if(!key.endsWith('Rear')||c.cq>=0)return;const p=liveAt(X,c.side,c.band.c);ember(ctx,p[0]-c.sx*8,p[1],9,.12*c.on+.2*c.acc,THUD);},
  field(sp,s,c){const C=c.band.c,dx=sp[0]-C[0],dy=sp[1]-C[1],d=Math.hypot(dx,dy);if(d>120)return null;const fall=Math.exp(-((d/50)**2)),D=dentD(c);
    const rx=sp[0]-ROOT[0],ry=sp[1]-ROOT[1],rl=Math.hypot(rx,ry)||1;const br=(c.cq<0?c.on*(.75+.25*c.acc):1-smooth(c.cl/.8));
    return {d:[-c.sx*rx/rl*D*fall,-ry/rl*D*fall*.7],l:Math.round(4*br*fall)};},
};
const PREC={core:[255,236,190],bloom:[214,170,96]};
P.precision={
  pal:l=>({ink:mixC(MAG,[236,190,140],l/4),halo:MAG,core:mixC(MAG_CORE,[255,236,190],l/4),glow:1,wire:1+.3*l/4,edge:0,edgeColor:[255,236,190]}),
  field(sp,s,c){const C=c.band.pierce,d=Math.hypot(sp[0]-C[0],sp[1]-C[1]);const k=c.k*(1-smooth((d-8)/18));return k>.1?{l:Math.round(k*4)}:null;},
  paint(ctx,key,c,X){if(!key.endsWith('Rear'))return;const p=liveAt(X,c.side,c.band.pierce);
    if(c.cq<0){const blink=.55+.25*Math.sin(c.t*1.6)+.35*c.acc;star(ctx,p[0],p[1],2.1+.8*c.acc,c.on*Math.min(1,blink),PREC,{flat:.28,rot:.3*c.acc});}
    else star(ctx,p[0],p[1],2.2*(1-.4*c.cl),bump(unit(c.cl/.7))*.9+(1-smooth(c.cl/.3))*.5,PREC,{flat:.28});},
  glow(i,left,c){const up=c.band.ribs[0]===0;if(left!==(c.side==='left')||(i<2)!==up)return null;const k=c.cq<0?c.on*accEnv(c.ph,.45):0;return k>.01?[[236,200,140],.22*k,11]:null;},
  bit(o,i,left,c){const up=c.band.ribs[0]===0;if(left!==(c.side==='left')||(i<2)!==up)return;const k=c.cq<0?c.on*accEnv(c.ph,.45):0;if(k>.01)o.spin+=.35*k*(left?1:-1);},
};
P.fallback={
  field(sp,s,c){const r=rOf(sp);let k;
    if(c.cq<0){const front=(c.ph/.6)*1.5-.25,band=c.ph<.6?Math.exp(-(((r-front)/.22)**2)):0;k=c.on*(.28+.12*Math.sin(c.t*.7)+.6*band);}
    else{const back=1.1-c.cl*1.35;k=r<back?.35:0;k*=1-smooth((c.cl-.85)/.15);}
    return k>.05?{l:Math.round(k*8)}:null;},
  paint(ctx,key,c,X){if(c.cq<0||!key.endsWith('Rear'))return;const s=liveStrand(X,c.side,`rib-${c.band.spine[1]}`);if(!s)return;const p=s.points[3];
    star(ctx,p[0],p[1],2.2,bump(unit((c.cl-.55)/.45))*.8,tintOf(c.tint),{flat:.3});},
};
const fallbackPal=t=>l=>{const k=l/8,rgb=[t[0],t[1],t[2]],core=[t[3],t[4],t[5]];return {ink:mixC(MAG,rgb,k*.85),halo:mixC(MAG,rgb,k*.6),core:mixC(MAG_CORE,core,k),glow:1+.15*k,wire:1+.15*k,edge:0,edgeColor:core};};
export const PERSIST_DRAWN=Object.freeze(Object.keys(P));

/** The persistent looks' feel and bit hooks (main thread). */
export function persistFeel(list,out){for(const c of list){const L=P[c.look];if(L?.feel){withBand(c);L.feel(out,c);}}}
export function persistBit(list,o,i,left){for(const c of list){const L=P[c.look];if(L?.bit){withBand(c);L.bit(o,i,left,c);}}}
const withBand=c=>{const Q=QUADS[c.quad];c.band=BANDS[Q.band];c.bandId=Q.band;c.side=Q.side;c.sx=Q.side==='left'?-1:1;return c;};

/* =====================================================================
 * 3. DYING IN STAGES (her fallen pose): embers, the lost bit, rekindling
 * ===================================================================== */
const dyPal=l=>{const k=Math.min(1,l/10),hot=Math.max(0,(l-10)/4);
  return {ink:mixC(mixC(MAG,[150,36,64],k),[255,120,60],hot),halo:mixC(MAG,[120,30,50],k),core:mixC(MAG_CORE,[255,180,140],k),glow:1-.7*k+.4*hot,wire:1-.3*k,edge:0,edgeColor:[255,180,140]};};

/* =====================================================================
 * 4. MOOD WEATHER: her wing colour drifts with her state
 * ===================================================================== */
export const MOODS=Object.freeze({
  normal:    {ink:[255,0,255],halo:[255,0,255],core:[255,214,255],glow:1,wire:1,edge:0,edgeColor:[255,226,250],under:null,bit:[1,0,0,1]},
  frightened:{ink:[216,40,255],halo:[178,74,252],core:[232,214,255],glow:.78,wire:.94,edge:0,edgeColor:[232,214,255],under:null,bit:[.8,-12,0,.96]},
  afterglow: {ink:[255,24,224],halo:[255,84,196],core:[255,226,206],glow:1.08,wire:1,edge:0,edgeColor:[255,226,206],under:[238,170,96,.095],bit:[1,6,.2,1.05],bitGlow:[236,176,120]},
  doomed:    {ink:[236,112,246],halo:[204,130,220],core:[244,236,250],glow:.9,wire:1,edge:0,edgeColor:[244,236,250],under:[166,154,186,.06],bit:[.5,0,0,1.04]},
  quickened: {ink:[255,16,255],halo:[255,30,255],core:[255,236,255],glow:1.05,wire:1,edge:.9,edgeColor:[255,236,252],under:null,bit:[1.05,0,0,1.1]},
  sickened:  {ink:[240,34,226],halo:[218,86,186],core:[240,236,204],glow:.96,wire:1,edge:0,edgeColor:[240,236,204],under:[158,188,84,.10],bit:[.85,-18,.14,.97]},
});
function mixMood(a,b,k){const ua=a.under??(b.under?[b.under[0],b.under[1],b.under[2],0]:null),ub=b.under??(a.under?[a.under[0],a.under[1],a.under[2],0]:null);
  return {ink:mixC(a.ink,b.ink,k),halo:mixC(a.halo,b.halo,k),core:mixC(a.core,b.core,k),edgeColor:mixC(a.edgeColor,b.edgeColor,k),glow:lerp(a.glow,b.glow,k),wire:lerp(a.wire,b.wire,k),edge:lerp(a.edge,b.edge,k),
    under:ua?[Math.round(lerp(ua[0],ub[0],k)),Math.round(lerp(ua[1],ub[1],k)),Math.round(lerp(ua[2],ub[2],k)),lerp(ua[3],ub[3],k)]:null};}
/** The mood's bit look at k (saturation, hue, sepia, brightness) as a mesh tint (rgb multipliers). */
export function moodBitTint(m){
  const A=MOODS[m.from]??MOODS.normal,B=MOODS[m.to]??MOODS.normal,K=ease(unit(m.k)*1.45-.62*.45);
  const b=[0,1,2,3].map(i=>lerp(A.bit[i],B.bit[i],K));if(Math.abs(b[0]-1)<.01&&Math.abs(b[1])<.5&&b[2]<.01&&Math.abs(b[3]-1)<.01)return null;
  // a desaturated, hue-turned, warmed bit, as a multiply (her bits are magenta-gold on a dark ground)
  const sat=b[0],hue=b[1]/360*TAU,sep=b[2],br=b[3];
  const r=br*(1-sep*.1)*(1-(1-sat)*.08),g=br*(1-(1-sat)*.18+(hue>0?.04:-.06)*Math.abs(b[1])/18+sep*.05),bl=br*(1-(1-sat)*.04-sep*.2+(hue<0?.04:0));
  return [Math.min(1,r),Math.min(1,g),Math.min(1,bl)];
}

/* =====================================================================
 * Palettes: cached by look and level for the life of the page
 * ===================================================================== */
const PAL=new Map();
function cached(key,make){let p=PAL.get(key);if(!p){p={...make(),key};PAL.set(key,p);if(PAL.size>4096)PAL.clear();}return p;}
/** Palette codes on strands (s.wl): wound 1..31 · dying 32+l · persistent ((2+n*2+alt)<<5)|l. */
const W_BASE=0,DY_BASE=32;
function palFor(D,code){
  if(code<32){const w=D.wound,L=woundLook(w);if(!L)return null;
    if(w.look==='other'){const t=w.tint??[220,200,190,250,236,230];return cached(`wo:${t.join(',')}:${code}`,()=>fallbackPal(t)(code));}
    return cached(`w:${w.look}${w.look==='electricity'?w.elec:''}:${code}`,()=>L.pal(code));}
  if(code<64)return cached(`dy:${code-DY_BASE}`,()=>dyPal(code-DY_BASE));
  const id2=(code>>5)-2,n=id2>>1,alt=id2&1,lvl=code&31;const c=D.persist?.find(x=>x.n===n);if(!c)return null;
  if(c.look==='fallback'){const t=c.tint??[220,200,190,250,236,230];return cached(`pf:${t.join(',')}:${alt}:${lvl}`,()=>alt?cleanPal(lvl):fallbackPal(t)(lvl));}
  const L=P[c.look];if(!L)return null;
  return cached(`p:${c.look}:${alt}:${lvl}`,()=>alt?(L.pal2??cleanPal)(lvl):L.pal(lvl));
}
/** Mood palette for a strand (the change seeps out from her shoulders to the tips). */
function moodPal(m,s,key){
  if(m.k>=1||m.from===m.to){if(m.to==='normal')return null;return cached(`m:${m.to}`,()=>MOODS[m.to]);}
  let r=s._v11r;if(r==null){const p=s.points[s.points.length>>1],sx=key.startsWith('left')?-1:1;r=unit(Math.hypot(p[0]-sx*27,p[1]+13)/260);try{s._v11r=r;}catch{}}
  const local=ease(unit(m.k)*1.45-r*.45),q=Math.round(local*24)/24;
  if(q<=0&&m.from==='normal')return null;if(q>=1&&m.to==='normal')return null;
  return cached(`m:${m.from}>${m.to}:${q}`,()=>mixMood(MOODS[m.from]??MOODS.normal,MOODS[m.to]??MOODS.normal,q));
}
/** The paletteAt hook (paintLayers): the strand's palette, or null for her own colours. */
export function v11PaletteAt(D,strand,key){
  if(strand.wl)return palFor(D,strand.wl);
  return D.mood?moodPal(D.mood,strand,key):null;
}

/* =====================================================================
 * The rig hooks
 * ===================================================================== */
/** Is the state showing anything? (an empty state costs nothing) */
export const v11Active=D=>!!(D&&(D.wound||D.persist?.length||D.dying||D.mood));
/** frameGeometry hook: edit the frame's strands for the state. `base` (the
 * other phase's geometry for the struck wing, mental) is optional. */
export function v11Geometry(wings,D,alt=null){
  if(!v11Active(D))return wings;
  const X=scratchOf(D);X.ends=null;for(const k in X.pends)delete X.pends[k];
  for(const k in X.sideBase)delete X.sideBase[k];
  // mental: the struck wing beats at its own (held) phase; its bits stay where they were
  if(alt)for(const k of keysOf(alt.side)){const own=wings[k];X.sideBase[k]=own;const next=[];for(const s of alt.wings[k])if(!s.hardware)next.push(s);for(const s of own)if(s.hardware)next.push(s);wings[k]=next;}
  snapshotLive(wings,X);
  const w=D.wound;
  if(w&&w.q>=0&&w.q<WOUND_SPAN){const L=woundLook(w);
    L?.geom?.(wings,X,w.q,w.side);}
  if(D.persist?.length)persistGeometry(wings,D,X);
  if(D.dying)dyingGeometry(wings,D.dying);
  // a mark that changes every frame while something moves, so the layer repaints
  // even where no strand changed (an ember walking, a crackle), and marks
  // that keep the layer's crop round what is drawn off the strands (the drop).
  const marks=[];
  for(const c of D.persist??[])P[c.look]?.marks?.(withBand(c),X,marks);
  for(const k of Object.keys(wings)){const pts=[[ROOT[0]*(k.startsWith('left')?-1:1),ROOT[1],0],[ROOT[0]*(k.startsWith('left')?-1:1),ROOT[1]+((D.tick??0)%997)*1e-6,0]];
    const arr=wings[k].slice();arr.push({id:'v11-mark',v11mark:true,width:0,strength:0,points:pts});
    for(const m of marks)if(k.startsWith(m[0]>0?'right':'left'))arr.push({id:'v11-mark',v11mark:true,width:0,strength:0,points:[[m[0],m[1],0],[m[0],m[1]+1e-3,0]]});
    wings[k]=arr;}
  return wings;
}
function persistGeometry(wings,D,X){
  const cs=D.persist;for(const c of cs){withBand(c);c.t=D.t;c.px=D.px;P[c.look]?.pre?.(c,X);}
  for(const side of ['left','right']){
    let any=false;const bands={};
    for(const c of cs){if(c.side!==side)continue;any=true;const cur=bands[c.bandId];if(!cur||c.on>cur.on)bands[c.bandId]=c;}
    if(!any)continue;
    const ends=[];
    woundSide(wings,side,(sp,i,s)=>{const c=bands[bandOfId(s.id)];if(!c)return null;const v=P[c.look]?.field?.(sp,s,c,i,X);if(!v)return null;
      const lv=Math.max(0,Math.min(31,v.l|0));return {l:lv?(((2+c.n*2+(v.alt?1:0))<<5)|lv):0,g:v.g??-1,d:v.d};},{ends,only:id=>!!bands[bandOfId(id)]});
    for(const e of ends){const c=bands[bandOfId(e.id)];if(c&&P[c.look]?.ends)(X.pends[c.n]??=[]).push(e);}
    scaleStrength(wings,keysOf(side),s=>{const c=bands[bandOfId(s.id)??''];if(!c)return 1;let m=1;
      if(s.wl>=64){const id2=(s.wl>>5)-2,cc=cs.find(x=>x.n===id2>>1);const lk=cc&&P[cc.look];if(lk?.str)m*=lk.str(s.wl&31,id2&1);}
      if(P[c.look]?.dim)m*=P[c.look].dim(c);return m;});
  }
}
function dyingGeometry(wings,Y){
  const k=Y.ember;if(k<.02)return;
  for(const side of ['left','right'])woundSide(wings,side,sp=>{const r=rOf(sp);
    const back=Y.heal>0?smooth((lerp(-.1,1.3,smooth(Y.heal/2.6))-r)/.18):0;
    const n=vnoise(sp[0]*.05+(side==='left'?9:0),sp[1]*.05+Y.t*.25);
    const e=k*(1-back),glow=Math.round(e*(10+4*smooth((n-.5)/.2)));return e>.03?{l:DY_BASE+Math.min(14,glow)}:null;});
  scaleStrength(wings,Object.keys(wings),s=>{if(!s.wl||s.wl<32||s.wl>=64)return 1;const l=s.wl-DY_BASE;return 1-.55*Math.min(1,l/10)+.3*Math.max(0,(l-10)/4);});
}
/** paintLayers hook: the extra strokes of the state on one layer (art transform set). */
export function v11Paint(ctx,key,wings,D){
  if(!v11Active(D))return;const X=SCRATCH.get(D);if(!X)return;
  const w=D.wound;
  if(w&&w.q>=0&&w.q<WOUND_SPAN){const L=woundLook(w);
    if(L?.paint)L.paint(ctx,key,X,w.q,w.side,wings,D);
    if(L?.bitGlow)for(const g of X.gems){if(g.key!==key)continue;const r=L.bitGlow(g.i,g.left,w.q,w.side);if(r)bitGlow(ctx,X,g.i,r[0],r[1],r[2]);}}
  for(const c of D.persist??[]){if(!key.startsWith(c.side)&&!P[c.look]?.glow)continue;const L=P[c.look];
    if(key.startsWith(c.side))L?.paint?.(ctx,key,c,X);
    if(L?.glow)for(const g of X.gems){if(g.key!==key)continue;const r=L.glow(g.i,g.left,c);if(r)bitGlow(ctx,X,g.i,r[0],r[1],r[2]);}}
  if(D.mood){const m=D.mood,M=MOODS[m.to],A=MOODS[m.from];const k=ease(unit(m.k)*1.45-.62*.45),bg=(A?.bitGlow?1-k:0)+(M?.bitGlow?k:0),col=M?.bitGlow??A?.bitGlow;
    if(col&&bg>.01)for(const g of X.gems)if(g.key===key)bitGlow(ctx,X,g.i,col,.2*bg,12);
    const edge=lerp(A?.edge??0,M?.edge??0,k);if(edge>.05)for(const g of X.gems)if(g.key===key)bitGlow(ctx,X,g.i,[255,200,250],.1*edge/.62,10);}
  if(D.dying){const Y=D.dying;for(const g of X.gems){if(g.key!==key)continue;
    if(g.i===LOST_BIT&&Y.lost>.1)bitGlow(ctx,X,g.i,[200,60,50],.35*Y.lost*(.7+.3*Math.sin(Y.t*2)),6);
    const hk=bump(unit((Y.heal-.8-g.i*.18)/1.6));if(hk>0)bitGlow(ctx,X,g.i,[255,150,236],.3*hk,13);
    if(Y.ok>0)bitGlow(ctx,X,g.i,[255,190,170],.26*Y.ok,12);
    if(Y.stutter&&Y.stutter.i===g.i)bitGlow(ctx,X,g.i,[255,120,90],.25*Y.stutter.k,11);}}
}
/** The bit that flickers out at Dying 3 (right upper). */
export const LOST_BIT=1;
/** The fold of her fallen wings while dying (the lab's .86, opening to .58 as she is healed). */
export const dyingFold=heal=>lerp(.86,.58,smooth((heal-.8)/2.6));
export {PAL as V11_PALETTES};
