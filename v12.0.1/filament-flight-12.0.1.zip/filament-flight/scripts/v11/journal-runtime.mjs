/** Yvaelle’s Toolbox v11 · her journal, recorded (Foundry glue for journal.mjs).
 *
 * Runs only while one of the experimental extras that reads it is on, on
 * this browser: the Memory tapestry, the milestone petals (both "Just me")
 * or the session recap (the GM's world switch). Off, it holds no hooks and no
 * timers; it only listens for the settings changing.
 *
 * One browser records for her: her player's (the first of her non-GM owners
 * who is online), else the GM's. It notes, from synced data only:
 *  - her HP, Hero Points, level and dying value (updateActor on her actor);
 *  - heals she gives: a healing roll of hers opens a short window, and the HP
 *    her allies regain in it is hers (several targets make one moment);
 *  - her criticals and natural 20s (her check messages), and a natural 20
 *    that brings an ally up from 0 (Saving Grace);
 *  - falls she survives: falling damage aimed at her, or knocked out while
 *    in the air, and back on her feet;
 *  - allies falling to 0 in a fight, and the fights she is in.
 * Changes are gathered for a moment and written as one update of only the
 * session and moment buckets that changed (flags.filament-flight.journal). */
import {isOn} from './features.mjs?v=12.0.1';
import {JOURNAL_FLAG,readJournal,ensureSession,currentSession,sampleHp,noteHeal,noteCrit,markSaved,noteHero,noteLevel,noteFall,noteDamage,noteAllyFell,noteCombat,
  detectMilestones,earn,togglePin,recapOf} from './journal.mjs?v=12.0.1';
import {readCheck,readHealing,readFall,actorNumbers,diffActor} from './journal-events.mjs?v=12.0.1';
import {forceDelete} from '../forced-delete.mjs?v=12.0.1';

const ID='filament-flight';
const HEAL_WINDOW_MS=45000,HEAL_SETTLE_MS=2500,NAT20_SAVE_MS=30000,FLUSH_MS=1200;
const herActor=()=>{
  let id=null;try{const p=game.settings.get(ID,'hudPreferences');if(p&&!p.followSelection&&typeof p.pinnedActor==='string'&&p.pinnedActor)id=p.pinnedActor;}catch{}
  id??=game.user?.character?.id??null;return id?game.actors?.get?.(id)??null:null;
};
/** Is any of the extras that read her journal on (on this browser)? */
export const journalWanted=()=>isOn('xTapestry')||isOn('xPetals')||isOn('xRecap');

/** The journal as stored: sessions and moments bucketed by session, so an update carries only what changed. */
export function toStore(J){
  const sessions={},moments={};
  for(const s of J.sessions)sessions[s.n]=s;
  for(const m of J.moments)(moments[m.s]??=[]).push(m);
  return {v:1,sessions,moments,totals:J.totals,milestones:J.milestones,pinned:J.pinned,flags:J.flags};
}
/** Stored form → the array form journal.mjs works on. */
export function fromStore(raw){
  if(!raw||typeof raw!=='object')return readJournal(null);
  const flat={...raw,sessions:Array.isArray(raw.sessions)?raw.sessions:Object.values(raw.sessions??{}),
    moments:Array.isArray(raw.moments)?raw.moments:Object.values(raw.moments??{}).flat()};
  return readJournal(flat);
}
/** The smallest update that turns stored `before` into journal J. */
export function journalUpdate(before,J){
  const after=toStore(J),base=`flags.${ID}.${JOURNAL_FLAG}`,out={},same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const b=before&&typeof before==='object'&&!Array.isArray(before.sessions)?before:null;
  if(!b){out[base]=after;return out;}
  for(const k of ['v','totals','milestones','pinned','flags'])if(!same(b[k],after[k]))out[`${base}.${k}`]=after[k];
  for(const bucket of ['sessions','moments']){
    const was=b[bucket]??{},now=after[bucket];
    for(const [n,v] of Object.entries(now))if(!same(was[n],v))out[`${base}.${bucket}.${n}`]=v;
    for(const n of Object.keys(was))if(!(n in now))forceDelete(out,`${base}.${bucket}`,n);
  }
  return out;
}
export function readActorJournal(actor){let raw=null;try{raw=actor?.getFlag?.(ID,JOURNAL_FLAG);}catch{}return fromStore(raw);}

/** A short "where and when" for a moment: the scene and her world's date. */
export function worldDate(){
  try{
    const wc=game.pf2e?.worldClock,wt=wc?.worldTime;
    if(wt?.toFormat){
      const months=globalThis.CONFIG?.PF2E?.worldClock?.Months,mk=wt.toFormat('LLLL'),loc=months?.[mk]?game.i18n.localize(months[mk]):null;
      return `${wt.day} ${loc??mk}${wc.dateTheme==='AR'||wc.dateTheme==='AD'?'':''}`;
    }
  }catch{}
  try{return new Date().toLocaleDateString(undefined,{day:'numeric',month:'short'});}catch{return '';}
}
const sceneName=()=>{try{return globalThis.canvas?.scene?.navName||globalThis.canvas?.scene?.name||'';}catch{return '';}};
const where=()=>[sceneName(),worldDate()].filter(Boolean).join(' · ');
const isAlly=(actor,her)=>{
  if(!actor||actor.id===her?.id)return false;
  if(actor.type==='character'||actor.hasPlayerOwner)return true;
  try{const t=actor.getActiveTokens?.()?.[0];return t?.document?.disposition===1;}catch{return false;}
};

export class JournalRuntime {
  constructor({airborne=()=>false,now=()=>Date.now()}={}){this.airborne=airborne;this.now=now;this.active=false;this.actor=null;this.hooks=[];this.ops=[];this.snap=new Map();this.stats={flushes:0,moments:0};}
  install(){
    const refresh=()=>this.refresh();
    try{Hooks.on('filamentFlightSettingsChanged',refresh);Hooks.once('ready',refresh);Hooks.on('updateUser',(u,c)=>{if(u?.id===game.user?.id&&'character' in (c??{}))refresh();});}catch{}
    return this;
  }
  /** Is this browser the one that records for her? */
  isRecorder(actor){
    if(!actor?.isOwner)return false;
    const users=[...(game.users??[])].filter(u=>u.active&&!u.isGM&&actor.testUserPermission?.(u,'OWNER')).sort((a,b)=>a.id<b.id?-1:1);
    if(game.user?.isGM)return users.length===0;
    return users[0]?.id===game.user?.id;
  }
  refresh(){
    let want=false,actor=null;
    try{want=journalWanted();actor=want?herActor():null;}catch{want=false;}
    const go=!!(want&&actor&&this.isRecorder(actor));
    if(go&&this.active&&actor===this.actor)return;
    this.stop();if(go)this.start(actor);
  }
  start(actor){
    this.active=true;this.actor=actor;this.snap.clear();this.heal=null;this.nat20=null;this.down=null;this.combats=new Set();
    for(const a of game.actors??[])if(a===actor||isAlly(a,actor))this.snap.set(a.id,actorNumbers(a));
    const on=(name,fn)=>{const id=Hooks.on(name,fn);this.hooks.push([name,id]);};
    on('updateActor',(a,changes)=>{if(changes?.system)this.onActor(a);});
    on('createChatMessage',m=>this.onMessage(m));
    on('combatStart',c=>this.onCombat(c));
    on('updateCombat',(c,ch)=>{if(ch?.round===1)this.onCombat(c);});
    // the first look: a session for now, her HP, and the milestones she already holds (Fifth Ring at level 5+)
    this.queue(()=>{});
  }
  stop(){
    for(const [n,id] of this.hooks)try{Hooks.off(n,id);}catch{}
    this.hooks=[];clearTimeout(this.timer);clearTimeout(this.heal?.timer);
    if(this.ops.length&&this.actor)void this.flush();
    this.active=false;this.heal=null;
  }
  /* ---------------- writing ---------------- */
  queue(op){if(!this.active)return;this.ops.push(op);clearTimeout(this.timer);this.timer=setTimeout(()=>void this.flush(),this.ops.length>20?0:FLUSH_MS);}
  async flush(){
    if(this.flushing){this.again=true;return;}
    const actor=this.actor,ops=this.ops.splice(0);if(!actor||!ops.length)return;
    this.flushing=true;
    try{
      let raw=null;try{raw=actor.getFlag(ID,JOURNAL_FLAG);}catch{}
      const J=fromStore(raw),now=this.now(),n=actorNumbers(actor);
      const sess=ensureSession(J,now,{date:worldDate(),max:n.max??0,level:n.level??0,hp:n.hp});
      sampleHp(currentSession(J),now,n.hp,n.max);
      if(n.heroMax)currentSession(J).heroMax=n.heroMax;
      const events=[];
      for(const op of ops){try{const m=op(J);if(m&&m.k)events.push(m);}catch(e){console.warn('Yvaelle’s Toolbox | journal',e);}}
      const earned=earn(J,detectMilestones(J,{level:n.level??0,closed:sess.closed}),now);
      const update=journalUpdate(raw,J);
      if(Object.keys(update).length){await actor.update(update,{filamentFlightJournal:true,render:false});this.stats.flushes++;this.stats.moments+=events.length;}
      if(events.length||earned.length||sess.began)Hooks.callAll('filamentFlightJournal',{actor,moments:events,earned,session:currentSession(J)?.n});
    }catch(e){console.error('Yvaelle’s Toolbox | the journal could not be saved',e);}
    finally{this.flushing=false;if(this.again){this.again=false;void this.flush();}}
  }
  /* ---------------- reading ---------------- */
  onActor(a){
    const her=this.actor;if(!her)return;
    const before=this.snap.get(a.id);if(!before&&a!==her&&!isAlly(a,her))return;
    const after=actorNumbers(a);this.snap.set(a.id,after);if(!before)return;
    const d=diffActor(before,after),t=this.now(),at=where(),scene=sceneName();
    if(a===her){
      if(d.hp&&d.hp.delta<0){const amount=-d.hp.delta;this.queue(J=>noteDamage(J,{amount},t));}
      else if(d.hp)this.queue(()=>null);   // (her HP is sampled at every flush)
      if(d.heroSpent)for(let i=0;i<d.heroSpent;i++)this.queue(J=>noteHero(J,{left:after.hero,at,scene},t));
      if(d.level)this.queue(J=>noteLevel(J,{level:d.level.to,hpGain:after.max!=null&&before.max!=null?after.max-before.max:0,at,scene},t));
      if(d.down){let air=false;try{air=!!this.airborne(her);}catch{}this.down={air,t};}
      if(d.recovered)this.queue(J=>{J.flags.recovered=true;return null;});
      if(d.up&&this.down){const air=this.down.air;this.down=null;this.queue(J=>noteFall(J,{kind:air?'sky':'down',hp:after.hp,at,scene},t));
        if(before.dying>0||after.dying===0)this.queue(J=>{J.flags.recovered=true;return null;});}
      return;
    }
    // an ally
    if(d.hp?.delta>0&&this.heal&&t<this.heal.until){
      const rec=this.heal.targets.get(a.id)??{id:a.id,name:a.name,amount:0,from0:false};
      rec.amount+=d.hp.delta;if(d.hp.from===0)rec.from0=true;this.heal.targets.set(a.id,rec);
      clearTimeout(this.heal.timer);this.heal.timer=setTimeout(()=>this.closeHeal(),HEAL_SETTLE_MS);
    }
    if(d.up&&this.nat20&&t-this.nat20.t<NAT20_SAVE_MS){const id=this.nat20.id,name=a.name;this.nat20.saved=name;if(id)this.queue(J=>{markSaved(J,id,name);return null;});}
    if(d.down&&game.combat?.started)this.queue(J=>{noteAllyFell(J,t);return null;});
  }
  closeHeal(){
    const h=this.heal;this.heal=null;if(!h)return;clearTimeout(h.timer);
    const targets=[...h.targets.values()].filter(x=>x.amount>0);if(!targets.length)return;
    const amount=targets.reduce((s,x)=>s+x.amount,0),nat20=!!(h.nat20||(this.nat20&&h.t-this.nat20.t<NAT20_SAVE_MS));
    const t=h.t,at=h.at,scene=h.scene;
    this.queue(J=>{const m=noteHeal(J,{amount,targets,source:h.source,actions:h.actions,crit:h.crit,nat20,at,scene},t);
      // the natural 20 that came first brought them back: that crit saved an ally
      const raised=targets.find(x=>x.from0);if(raised&&nat20&&this.nat20?.id)markSaved(J,this.nat20.id,raised.name);
      return m;});
  }
  onMessage(m){
    const her=this.actor;if(!her)return;
    const t=this.now(),mine=m?.speaker?.actor===her.id||m?.actor?.id===her.id;
    if(mine){
      const check=readCheck(m);
      if(check&&(check.crit||check.nat20)){
        const at=where(),scene=sceneName(),rec={t,id:null,label:check.label};
        if(check.nat20)this.nat20=rec;
        this.queue(J=>{const x=noteCrit(J,{label:check.label,check:check.kind,nat20:check.nat20,at,scene},t);rec.id=x.id;
          if(rec.saved)markSaved(J,x.id,rec.saved);return x;});
      }
      const heal=readHealing(m);
      if(heal){
        if(this.heal&&t<this.heal.until){this.heal.until=t+HEAL_WINDOW_MS;this.heal.total+=heal.total;}
        else{if(this.heal)this.closeHeal();this.heal={t,until:t+HEAL_WINDOW_MS,source:heal.source,actions:heal.actions,crit:heal.crit,total:heal.total,targets:new Map(),at:where(),scene:sceneName(),
          nat20:!!(this.nat20&&t-this.nat20.t<NAT20_SAVE_MS)};}
      }
    }
    const fall=readFall(m,her.id);
    if(fall){const at=where(),scene=sceneName();setTimeout(()=>{const hp=actorNumbers(her).hp;if(hp>0)this.queue(J=>noteFall(J,{ft:fall.ft,hp,at,scene},t));else this.down={air:true,t};},2000);}
  }
  onCombat(c){
    const her=this.actor;if(!her||!c||this.combats.has(c.id))return;
    if(![...(c.combatants??[])].some(x=>x.actorId===her.id||x.actor?.id===her.id))return;
    this.combats.add(c.id);const t=this.now();this.queue(J=>{noteCombat(J,t);return null;});
  }
}

/* ------------------------------------------------------------------ */
/* Edits from the HUD and her sheet                                    */
/* ------------------------------------------------------------------ */
/** Change her journal (read fresh, change, write the difference). */
export async function editJournal(actor,fn){
  if(!actor)throw new Error('Pin her in the HUD first.');
  if(!actor.isOwner)throw new Error('Only her player or the GM can change her journal.');
  let raw=null;try{raw=actor.getFlag(ID,JOURNAL_FLAG);}catch{}
  const J=fromStore(raw);const out=fn(J);
  const update=journalUpdate(raw,J);if(Object.keys(update).length)await actor.update(update,{filamentFlightJournal:true,render:false});
  Hooks.callAll('filamentFlightJournal',{actor,moments:[],earned:[],edit:true});
  return out;
}
export const pinPetal=(actor,id)=>editJournal(actor,J=>togglePin(J,id));
/** Close the session now: the next moment begins a new one. */
export const newSession=actor=>editJournal(actor,J=>{const n=actorNumbers(actor),now=Date.now();
  const r=ensureSession(J,now,{fresh:true,date:worldDate(),max:n.max??0,level:n.level??0,hp:n.hp});
  earn(J,detectMilestones(J,{level:n.level??0,closed:r.closed}),now);return r.session.n;});
export function recapFor(actor,n=null){
  const J=readActorJournal(actor),a=actorNumbers(actor);
  return recapOf(J,n,{hero:a.hero!=null?{value:a.hero,max:a.heroMax}:null,level:a.level??0,hp:{value:a.hp,max:a.max}});
}
export {herActor};
