/** Yvaelle’s Toolbox · self-check: the "box" test (11.0.0-test.8), pure.
 *
 * test.7's cloak drew outside her: the scanning front ran bright down her ground shadow, lights reached 5 px past
 * her outline, and C's shed pixels drifted over bare map. The runtime's own numbers never saw it. This compares
 * screen pixels round her with the same pixels before the fade:
 *
 *   ref        the region drawn WITHOUT her (the bare map there)
 *   body       where she (token, wings, bits, effects; not her shadow) differs from ref, over a few frames,
 *              widened by `rad` samples: her silhouette, with room for a wing beat and her hover
 *   shadow     where only her ground shadow covers the map
 *   outside    the rest of the region (inside the old filter rectangles, outside her)
 *
 * A read during the sweep or while held is then judged:
 *   outside    must still equal ref (± tol): anything else is drawn over bare map
 *   shadow     must lie between her shadow and the bare map: never brighter than ref (+ tol)
 * All arrays are RGBA bytes of the same w × h grid of samples. */
export function boxMasks(ref,bodies,solid,w,h,rad=3,tol=8){
  const n=w*h,raw=new Uint8Array(n);
  for(const b of bodies)for(let i=0;i<n;i++){if(raw[i])continue;const o=i*4;if(Math.abs(b[o]-ref[o])>tol||Math.abs(b[o+1]-ref[o+1])>tol||Math.abs(b[o+2]-ref[o+2])>tol)raw[i]=1;}
  // widen (a square of ± rad samples, two passes)
  const t=new Uint8Array(n),body=new Uint8Array(n);
  for(let y=0;y<h;y++){let run=-1e9;const row=y*w;for(let x=0;x<w;x++){if(raw[row+x])run=x;if(x-run<=rad)t[row+x]=1;}run=1e9;for(let x=w-1;x>=0;x--){if(raw[row+x])run=x;if(run-x<=rad)t[row+x]=1;}}
  for(let x=0;x<w;x++){let run=-1e9;for(let y=0;y<h;y++){if(t[y*w+x])run=y;if(y-run<=rad)body[y*w+x]=1;}run=1e9;for(let y=h-1;y>=0;y--){if(t[y*w+x])run=y;if(run-y<=rad)body[y*w+x]=1;}}
  const shadow=new Uint8Array(n);let nb=0,ns=0,x0=w,y0=h,x1=-1,y1=-1;
  for(let i=0;i<n;i++){if(body[i]){nb++;if(raw[i]){const x=i%w,y=(i/w)|0;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}continue;}
    const o=i*4;if(Math.abs(solid[o]-ref[o])>2||Math.abs(solid[o+1]-ref[o+1])>2||Math.abs(solid[o+2]-ref[o+2])>2){shadow[i]=1;ns++;}}
  return {body,shadow,w,h,bodyCount:nb,shadowCount:ns,outsideCount:n-nb-ns,bounds:x1>=0?{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1}:null};
}
/** Judge one read against the masks → {out, lit, worst, box:{x,y,w,h}|null} (counts in samples). */
export function boxDiff(cur,ref,M,tol=10){
  const {body,shadow,w,h}=M,n=w*h;let out=0,lit=0,worst=0,x0=w,y0=h,x1=-1,y1=-1;
  for(let i=0;i<n;i++){
    if(body[i])continue;const o=i*4;let d;
    if(shadow[i]){d=Math.max(cur[o]-ref[o],cur[o+1]-ref[o+1],cur[o+2]-ref[o+2]);if(d<=tol)continue;lit++;}
    else{d=Math.max(Math.abs(cur[o]-ref[o]),Math.abs(cur[o+1]-ref[o+1]),Math.abs(cur[o+2]-ref[o+2]));if(d<=tol)continue;out++;}
    if(d>worst)worst=d;const x=i%w,y=(i/w)|0;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;
  }
  return {out,lit,worst,box:x1>=0?{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1}:null};
}
/** How many samples may differ before it is a box: a few stray samples (a light flicker, a wing tip) are not. */
export const boxLimit=M=>Math.max(6,Math.round((M.outsideCount+M.shadowCount)*.0008));

/* ---------------------------------------------------------------- (11.0.0-test.9) the same frame, drawn again
 * test.8's rule above compares a read during the sweep with the screen BEFORE the fade, outside the silhouette she
 * had THEN. On a real table she flies, her wings beat and her bits orbit, so seconds later her wings are simply
 * somewhere else: about 4 % of the samples round her differed in every phase (Classic, which has no filter at all,
 * included), and all of it was her own wings. So the judged rule now never compares two moments. Each read draws
 * the SAME frame again, in the same tick, three more ways:
 *
 *   on        the frame as it is (her cloak filters running)
 *   off       the same frame with her cloak filters bypassed (her pieces as her meshes draw them)
 *   noShadow  as off, without her ground shadow
 *   bare      the same frame without any of her pieces
 *
 *   her       where off differs from bare, widened by `rad` samples: what her own pieces draw THIS frame, plus
 *             the rim the filter may reach (1.3 scene px)
 *   outside   everything else: there `on` must equal `bare`. Anything else is drawn by a filter where she is not.
 *   shadow    where only her shadow covers the map (and no other piece of hers is within `rad`): `on` may never be
 *             brighter than `bare` there.
 * The token layer's "outside her own token art" check uses the same functions (on / off = its filter bypassed / bare
 * = her token not drawn). */
const far=(a,b,o,tol)=>Math.abs(a[o]-b[o])>tol||Math.abs(a[o+1]-b[o+1])>tol||Math.abs(a[o+2]-b[o+2])>tol;
/** Widen a 0/1 mask by ± rad samples (a square, two passes). */
export function widen(raw,w,h,rad){
  const n=w*h,t=new Uint8Array(n),out=new Uint8Array(n);if(!(rad>0)){out.set(raw);return out;}
  for(let y=0;y<h;y++){let run=-1e9;const row=y*w;for(let x=0;x<w;x++){if(raw[row+x])run=x;if(x-run<=rad)t[row+x]=1;}run=1e9;for(let x=w-1;x>=0;x--){if(raw[row+x])run=x;if(run-x<=rad)t[row+x]=1;}}
  for(let x=0;x<w;x++){let run=-1e9;for(let y=0;y<h;y++){if(t[y*w+x])run=y;if(y-run<=rad)out[y*w+x]=1;}run=1e9;for(let y=h-1;y>=0;y--){if(t[y*w+x])run=y;if(run-y<=rad)out[y*w+x]=1;}}
  return out;
}
/** Her own shape in this frame → {her, shadow, w, h, rawCount, herCount, shadowCount, outsideCount, bounds}. noShadow may be null. */
export function frameMasks(off,bare,noShadow,w,h,rad=1,tol=3){
  const n=w*h,raw=new Uint8Array(n);let nr=0,x0=w,y0=h,x1=-1,y1=-1;
  for(let i=0;i<n;i++)if(far(off,bare,i*4,tol)){raw[i]=1;nr++;const x=i%w,y=(i/w)|0;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}
  const her=widen(raw,w,h,rad),shadow=new Uint8Array(n);let nh=0,ns=0;
  // only her shadow: she draws there, her other pieces do not, and none of them is within the rim (rad) either
  let near=null;if(noShadow){const body=new Uint8Array(n);for(let i=0;i<n;i++)if(far(noShadow,bare,i*4,tol))body[i]=1;near=widen(body,w,h,rad);}
  for(let i=0;i<n;i++){if(!her[i])continue;nh++;if(near&&raw[i]&&!near[i]){shadow[i]=1;ns++;}}
  return {her,shadow,w,h,rawCount:nr,herCount:nh,shadowCount:ns,outsideCount:n-nh,bounds:x1>=0?{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1}:null};
}
/** Judge the frame as it is against the same frame without her → {out, lit, tot, worst, box, mean:[r,g,b] (signed mean
 * change of the differing samples), grid (G×G counts of differing samples over the region), G}. */
export function frameSpill(on,bare,M,tol=10,G=12){
  const {her,shadow,w,h}=M,n=w*h,grid=new Uint16Array(G*G),sum=[0,0,0];let out=0,lit=0,worst=0,x0=w,y0=h,x1=-1,y1=-1;
  for(let i=0;i<n;i++){
    const o=i*4;let d;
    if(her[i]){if(!shadow[i])continue;d=Math.max(on[o]-bare[o],on[o+1]-bare[o+1],on[o+2]-bare[o+2]);if(d<=tol)continue;lit++;}
    else{d=Math.max(Math.abs(on[o]-bare[o]),Math.abs(on[o+1]-bare[o+1]),Math.abs(on[o+2]-bare[o+2]));if(d<=tol)continue;out++;}
    if(d>worst)worst=d;const x=i%w,y=(i/w)|0;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;
    sum[0]+=on[o]-bare[o];sum[1]+=on[o+1]-bare[o+1];sum[2]+=on[o+2]-bare[o+2];
    const g=Math.min(G-1,(y*G/h)|0)*G+Math.min(G-1,(x*G/w)|0);if(grid[g]<65535)grid[g]++;
  }
  const tot=out+lit;
  return {out,lit,tot,worst,box:x1>=0?{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1}:null,mean:tot?sum.map(v=>Math.round(v/tot)):[0,0,0],grid,G};
}
/** A coarse map of where the differing samples are, G rows of G characters: a digit 1-9 (how full the cell is of
 * differing samples, 9 = more than 80 %), `o` a cell that is mostly her and clean, `.` a clean cell outside her. */
export function heatRows(sp,M){
  const G=sp.G,{her,w,h}=M,cellHer=new Float32Array(G*G),cellN=new Float32Array(G*G),rows=[];
  for(let y=0;y<h;y++){const gy=Math.min(G-1,(y*G/h)|0)*G;for(let x=0;x<w;x++){const g=gy+Math.min(G-1,(x*G/w)|0);cellN[g]++;if(her[y*w+x])cellHer[g]++;}}
  for(let gy=0;gy<G;gy++){let r='';for(let gx=0;gx<G;gx++){const g=gy*G+gx,c=sp.grid[g],nn=cellN[g]||1;
    r+=c?String(Math.max(1,Math.min(9,Math.ceil(c/nn*10)))):cellHer[g]/nn>.5?'o':'.';}rows.push(r);}
  return rows;
}
/** "+12 −3 +40": a signed colour change for the report. */
export const rgbText=m=>m.map(v=>(v>0?'+':v<0?'−':'')+Math.abs(v)).join(' ');

/** (11.0.0-test.8) Whose code threw: the module or system of the innermost stack frame that sits in one
 * ("sequencer", "pf2e", "filament-flight"), or null when no frame names one. Another module that reacts to the
 * check's damage with assets the table does not have (Sequencer: "Invalid Asset jb2a…") is that module's error. */
export function originOf(stack){
  for(const line of String(stack??'').split('\n')){const m=/\/(?:modules|systems)\/([^/]+)\//.exec(line);if(m)return m[1];}
  return null;
}
/** Is a captured entry another module's (not Yvaelle’s Toolbox's)? */
export const foreignError=x=>!!x?.origin&&x.origin!=='filament-flight';
