/** Persistent visual programs for the token attended by Ellie's instruments.
 * Pure, bounded Canvas artwork: no documents, sockets, shaders or timers.
 * All coordinates use a 100-unit token diameter. These are cosmetic effects. */
import {sampleCompactFormation} from './compact-bit-formations.mjs?v=12.0.1';
import {PROJECTED_EFFECT_PROGRAMS,drawProjectedEffect,projectedEffectWorkingPoint,projectedEffectDuty} from './projected-effect-programs.mjs?v=12.0.1';
import {isExpandedProjectedEffect} from './projected-effect-expansion.mjs?v=12.0.1';
export const TOKEN_EFFECT_CATEGORIES=Object.freeze({protective:'Protective fields',restorative:'Restorative light',awareness:'Awareness & direction',expressive:'Resonance & motion'});
const program=(id,label,category,description,state)=>Object.freeze({id,label,category,description,state});
export const TOKEN_EFFECT_PROGRAMS=Object.freeze([
  program('shield','Shelter bubble','protective','A translucent enclosure catches travelling pressure waves. More instruments complete its shell.','guarding'),
  program('intercept','Interception plates','protective','Independent angular plates turn outward and catch brief impacts along the perimeter.','guarding'),
  program('petalGuard','Petal guard','protective','Long hardlight petals close and reopen around the token like a restrained mechanical flower.','guarding'),
  program('sanctuary','Sanctuary arch','protective','Fine pointed arches lift a protective canopy above the token; suspended keystones carry its weight.','guarding'),
  program('pulseHalo','Restorative tide','restorative','Soft horizontal waves rise through the token and release into expanding floor rings.','open'),
  program('mendingVeil','Mending veil','restorative','A close energy surface is gently drawn together by moving stitches and a travelling seam.','open'),
  program('renewalSpiral','Renewal spiral','restorative','Luminous helical channels lift small pulses along the token and dissolve above it.','open'),
  program('threadbind','Soul threads','restorative','Her own magenta filament threads lace across the token from anchor to anchor and draw gently tight, with a bright knot running the lacing.','open'),
  program('crystalCast','Crystalline cast','restorative','Hardlight crystal plates set over the token one row at a time, a bright setting line climbing down the cast.','open'),
  program('wingSuture','Wing-thread suture','restorative','Long filaments sweep in from her wings to a seam and a needle of light whip-stitches it closed.','open'),
  program('heartline','Steady heartline','restorative','A clean diagnostic ribbon carries a measured double heartbeat between articulated side brackets.','open'),
  program('guide','Guiding light','awareness','A small forward lantern sends successive directional chevrons into an illuminated path.','open'),
  program('lanternCrown','Lantern crown','awareness','A constellation of suspended diamond lanterns casts narrow searching cones around the token.','open'),
  program('survey','Survey sweep','awareness','An oblique radar fan turns through calibrated arcs, briefly revealing detected marks.','open'),
  program('compass','Living compass','awareness','Cardinal sighting gates drift into alignment around an asymmetrical rotating bearing.','open'),
  program('cometCourt','Comet court','expressive','Small hardlight comets exchange the foreground and background along inclined elliptical paths.','charging'),
  program('tetherWeave','Tether weave','expressive','Interlocking energy loops trade bright travelling knots around the token.','charging'),
  program('resonanceChime','Resonance chime','expressive','Suspended prongs answer one another with short vertical pulses and a quiet lower crescent.','charging'),
  program('bloomSeal','Bloom seal','expressive','An intricate floor rosette slowly opens beneath rising filaments and a hovering central jewel.','charging'),
  ...PROJECTED_EFFECT_PROGRAMS
]);
/** v10 beta: weak or near-duplicate fields move to a Legacy group at the end of
 * every list. They still render, and a saved choice keeps working. */
export const LEGACY_TOKEN_EFFECT_IDS=Object.freeze(['guide','nerveCalm','focusLock','emergencyReserve','impulseDrive','signalPennants','deflectionFins','sectorSearch','contourScan','prismRelay','lightBridge']);
export const isLegacyTokenEffect=id=>LEGACY_TOKEN_EFFECT_IDS.includes(id);
/** Current fields first, Legacy last (with a Legacy tag). */
export const orderedTokenEffects=()=>[...TOKEN_EFFECT_PROGRAMS.filter(p=>!isLegacyTokenEffect(p.id)),...TOKEN_EFFECT_PROGRAMS.filter(p=>isLegacyTokenEffect(p.id)).map(p=>({...p,legacy:true,label:`Legacy · ${p.label}`}))];
const BY_ID=new Map(TOKEN_EFFECT_PROGRAMS.map(p=>[p.id,p]));
export const TOKEN_EFFECT_IDS=Object.freeze(TOKEN_EFFECT_PROGRAMS.map(p=>p.id));
export const tokenEffectChoices=()=>TOKEN_EFFECT_PROGRAMS.map(p=>({...p}));
export const tokenEffectDefinition=id=>BY_ID.get(id)??null;
const TAU=Math.PI*2,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const finite=(v,f)=>Number.isFinite(v)?v:f;
const point=(a,r,ry=r,cx=0,cy=0)=>[cx+Math.cos(a)*r,cy+Math.sin(a)*ry];
const validColor=c=>typeof c==='string'&&/^#[\da-f]{6}$/i.test(c)?c:'#ff62df';
const smooth=v=>{v=clamp(v,0,1);return v*v*(3-2*v);};

/** An instrument has a concrete job in each field. These are the actual
 * working points, shared by the projection painter and the bit's aiming. */
export function tokenEffectWorkingPoint(id,index,count,clock=0,emitter={x:0,y:-70},options={}){
  const i=index,n=Math.max(1,count),t=clock,a=-Math.PI/2+i*TAU/n;
  switch(id){
    case 'shield': {const theta=Math.atan2(emitter.y/68,emitter.x/62);return point(theta,62,68);}
    case 'intercept': return point(a+Math.sin(t*.4+i)*.15,66,61);
    case 'petalGuard': return [Math.cos(i/n*TAU+t*.1)*47*(.75+.15*Math.sin(t*.8+i)),-25+50*(i%2)];
    case 'sanctuary': return [0,-78-i*4+Math.sin(t*.75+i)*2];
    case 'pulseHalo': {const p=(t*.26+i/(n+1))%1;return [Math.cos(a)*(42+Math.sin(p*Math.PI)*13),48-p*106];}
    case 'mendingVeil': return [n===1?0:(i/(n-1)-.5)*(54+n*10),-43+(t*.19%1)*82];
    case 'renewalSpiral': {const p=(t*.19+i/n)%1;return [Math.cos(p*TAU*1.45+i/n*TAU+t*.65)*47,-58+p*116];}
    case 'heartline': return [(i%2?1:-1)*(45+n*4),24];
    case 'crystalCast': {const rows=3+n,j=Math.floor(((t*.35)%1)*(rows+1.5))%rows;return [(i%2?1:-1)*30,-42+j*84/(rows-1)];}
    case 'wingSuture': return [(i%2?1:-1)*(70-6*n),-40+80*((t*.3)%1)];
    case 'threadbind': {const w=30+n*4,y=-40+80*(.5-.5*Math.cos(t*.55+i*Math.PI/Math.max(1,n)));return [(i%2?1:-1)*(w*(1-.42*(.45+.2*Math.sin(t*1.1)))),y];}
    case 'guide': return [0,-68-Math.sin(t*.8)*2];
    case 'lanternCrown': {const angle=(i+.5)/n*Math.PI;return [Math.cos(angle)*52,-61-Math.sin(angle)*18+Math.sin(t*.75+i)*2];}
    case 'survey': return point(t*.65-i*.12,57,28,0,28);
    case 'compass': return point(a,68,61);
    case 'cometCourt': {const angle=t*(.45+i*.035)+i/n*TAU,r=(i%2?1:-1)*.28,[x,y]=point(angle,68,26);return [x*Math.cos(r)-y*Math.sin(r),x*Math.sin(r)+y*Math.cos(r)];}
    case 'tetherWeave': {const angle=t*.7+i*TAU/n,phase=t*.16+i/n*Math.PI;return [Math.sin(angle+phase)*64,Math.sin(angle*2+phase)*34];}
    case 'resonanceChime': return [(i-(n-1)/2)*14,-58-Math.cos((i-(n-1)/2)*.6)*11];
    case 'bloomSeal': return point(i/n*TAU+t*.06,49,17,0,48);
    default:return projectedEffectWorkingPoint(id,i,n,t,options)??[0,0];
  }
}

function fieldEmitters(count,clock,options){
  // Passing [] deliberately suppresses emission; never invent instruments for
  // a group whose members have left to perform another task.
  const input=Array.isArray(options.emitters)?options.emitters:sampleCompactFormation(count,options.program??'orbit',clock,{animated:options.animated!==false,radius:options.radius??1,personality:0}).map((p,i)=>({id:`preview-${i}`,x:p.x*3.5/6,y:(p.y-15)*3.5/6,z:p.z}));
  return input.slice(0,count).filter(p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y)).map((p,i)=>({id:p.id??`emitter-${i}`,x:clamp(p.x,-2400,2400),y:clamp(p.y,-2400,2400),z:finite(p.z,1),plane:p.plane==='rear'||p.plane==='front'?p.plane:p.z<0?'rear':'front'}));
}

/** Add at most one current, one packet and one core flare per participating
 * bit. No particle history or blur; low detail omits the additional core ring. */
function addEmission(frame,clock,options){
  if(options.emission===false)return;
  const t=options.animated===false?0:clock,elapsed=options.animated===false?1200:finite(options.activationElapsed,1200);
  const charge=smooth(elapsed/360),projection=smooth((elapsed-160)/680);
  // New constructions begin at the actual contact, after the source current
  // arrives. Preserve the preceding twenty-four effects' exact activation.
  const sustain=isExpandedProjectedEffect(frame.id)?smooth((elapsed-840)/360):smooth((elapsed-260)/740);
  const fade=options.phase==='finishing'?1-smooth((finite(options.progress,0)-.45)/.55):1;
  const emitters=fieldEmitters(frame.count,t,options),gain=clamp(frame.strength,0,2)*fade;
  frame.emitters=emitters;frame.emissionTargets=[];frame.duties=[];frame.activation={charge,projection,sustain};
  // Surfaces appear after the source has gathered light. A held frame remains
  // fully readable when animation is disabled.
  for(const path of frame.paths){path.alpha*=sustain*fade;path.fill*=sustain*fade;}
  const push=(points,plane,alpha,width,extra={})=>frame.paths.push({points,plane,alpha:clamp(alpha*gain,0,1),width,closed:false,fill:0,...extra});
  for(let i=0;i<emitters.length;i++){
    const e=emitters[i],target=tokenEffectWorkingPoint(frame.id,i,emitters.length,t,e,options),dx=target[0]-e.x,dy=target[1]-e.y,len=Math.hypot(dx,dy)||1;
    const bend=Math.min(9,len*.095)*(i%2?1:-1),mid=[(e.x+target[0])*.5-dy/len*bend,(e.y+target[1])*.5+dx/len*bend];
    const at=u=>[(1-u)**2*e.x+2*(1-u)*u*mid[0]+u*u*target[0],(1-u)**2*e.y+2*(1-u)*u*mid[1]+u*u*target[1]];
    frame.emissionTargets.push({id:e.id,x:target[0],y:target[1],plane:e.plane});
    const duty=projectedEffectDuty(frame.id,i,emitters.length,t,options);if(duty)frame.duties.push({id:e.id,...duty});
    const steps=options.detail==='low'?4:7,points=new Array(steps+1);for(let j=0;j<=steps;j++)points[j]=at(j/steps*projection);
    push(points,e.plane,(.27+.075*Math.sin(t*2.2-i)**2)*charge,.62,{glow:options.detail!=='low',emitter:e.id,role:'current'});
    // A short bright packet travels *from* the housing into its work surface.
    const packet=options.animated===false?.58:(t*(.55+i*.027)+i*.29)%1;
    if(projection>.03){const start=Math.min(packet,projection),end=Math.min(start+.075,projection);push([at(start),at(end)],e.plane,.72*charge,1.2,{highlight:true,emitter:e.id,role:'packet'});}
    if(options.detail!=='low'){
      const radius=1.7+(1-sustain)*2.2+.4*Math.sin(t*2.1+i),x=e.x,y=e.y;
      push([[x,y-radius],[x+radius*.65,y],[x,y+radius],[x-radius*.65,y]],e.plane,.58*charge,.75,{closed:true,highlight:true,glow:true,emitter:e.id,role:'source'});
    }
  }
}

/** Keep distant wing-mounted instruments connected without clipping, while
 * keeping every field texture bounded by its existing pixel quality cap. */
export function fitTokenEffect(sample,extent=125){
  let reach=1;
  for(const path of sample.paths)for(const p of path.points)reach=Math.max(reach,Math.abs(p[0])+4,Math.abs(p[1])+4);
  const scale=Math.max(1,reach/extent);if(scale===1)return sample;
  return {...sample,effectScale:scale,bounds:{x:-130,y:-130,width:260,height:260},paths:sample.paths.map(p=>({...p,width:p.width/scale,glowSpread:3/scale,points:p.points.map(q=>[q[0]/scale,q[1]/scale])}))};
}

/** Geometry complexity is fixed by program and detail, never elapsed time or
 * accumulated particle history. Strength zero and invalid/zero groups do no work. */
export function sampleTokenEffect(id,count,elapsed=0,options={}){
  const definition=BY_ID.get(id),requested=clamp(Math.trunc(finite(count,0)),0,4),n=Array.isArray(options.emitters)?Math.min(requested,options.emitters.filter(p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y)).length):requested,strength=clamp(finite(options.strength,1),0,3);
  const frame={effect:'token-field',id:definition?.id??id,count:n,strength,color:validColor(options.color),paths:[],bounds:{x:-130,y:-130,width:260,height:260},state:definition?.state??'normal'};
  if(!definition||!n||!strength||options.enabled===false)return frame;
  const clock=options.animated===false?0:finite(elapsed,0)/1000,t=clock%3600,power=(.38+n*.155)*strength;
  const detail=options.detail==='low'?18:options.detail==='high'?40:28,paths=frame.paths;
  const add=(points,{plane='front',alpha=.6,width=.8,closed=false,fill=0,highlight=false,glow=false,...metadata}={})=>{
    if(points.length<2)return;
    paths.push({points,plane,alpha:clamp(alpha*power,0,1),width,closed,fill:clamp(fill*power,0,.32),highlight,glow,...metadata});
  };
  const curve=(fn,{steps=detail,...opts}={})=>{const points=new Array(steps+1);for(let i=0;i<=steps;i++)points[i]=fn(i/steps);add(points,opts);};
  const ellipse=(rx,ry,cx=0,cy=0,opts={})=>curve(u=>point(u*TAU,rx,ry,cx,cy),{closed:true,...opts});
  const splitEllipse=(rx,ry,cy=0,rotation=0,opts={})=>{
    const project=a=>{const [x,y]=point(a,rx,ry);return [x*Math.cos(rotation)-y*Math.sin(rotation),cy+x*Math.sin(rotation)+y*Math.cos(rotation)];};
    for(const side of [0,1])curve(u=>project((u+side)*Math.PI),{plane:side?'rear':'front',steps:Math.ceil(detail/2),...opts});
  };
  const diamond=(x,y,r,opts={})=>add([[x,y-r],[x+r*.55,y],[x,y+r],[x-r*.55,y]],{closed:true,...opts});
  const burst=(x,y,r=3)=>{add([[x-r,y],[x+r,y]],{alpha:.85,highlight:true});add([[x,y-r],[x,y+r]],{alpha:.85,highlight:true});};
  const sweep=(clock*.26)%1;
  switch(id){
    case 'shield': {
      ellipse(62,68,0,0,{plane:'rear',alpha:.12,fill:.045});
      // One bit sustains a visible arc; four complete a reinforced enclosure.
      for(let i=0;i<n;i++)curve(u=>point(-Math.PI/2+i*TAU/n+(u-.5)*(.7+n*.21),62,68),{alpha:.65,width:1.1,glow:true});
      for(let i=0;i<Math.min(n,3);i++){const z=((t*.23+i/3)%1)*2-1,r=Math.sqrt(Math.max(0,1-z*z));splitEllipse(61*r,13*r,z*64,0,{alpha:(1-Math.abs(z))*.5,width:.75});}
      if(n>=3)splitEllipse(63,25,0,.75,{alpha:.16});
      break;
    }
    case 'intercept': {
      for(let i=0;i<n;i++){
        const a=-Math.PI/2+i/n*TAU+Math.sin(t*.4+i)*.15,x=Math.cos(a)*66,y=Math.sin(a)*61,r=15+n*1.7;
        const transform=([px,py])=>[x+px*Math.cos(a)-py*Math.sin(a),y+px*Math.sin(a)+py*Math.cos(a)];
        const hit=Math.max(0,Math.sin(t*2.1-i*1.8))**12;
        add([[0,-r],[9,-r*.62],[13,0],[9,r*.62],[0,r],[-4,0]].map(transform),{plane:y<0?'rear':'front',closed:true,alpha:.55+hit*.4,fill:.05+hit*.13,glow:true});
        add([[-8,-r*.7],[-10,0],[-8,r*.7]].map(transform),{alpha:.25});
        if(hit>.15)curve(u=>transform([14+u*14,(u-.5)*25]),{alpha:hit*.75,highlight:true,steps:3});
      }break;
    }
    case 'petalGuard': {
      for(let i=0;i<n;i++){
        const a=i/n*TAU+t*.1,open=.75+.15*Math.sin(t*.8+i),x=Math.cos(a)*47*open;
        curve(u=>[x+Math.sin(u*Math.PI)*Math.cos(a)*25,-66+u*128],{alpha:.65,plane:Math.sin(a)<0?'rear':'front',width:1.05});
        curve(u=>[x-Math.sin(u*Math.PI)*Math.cos(a)*17,-66+u*128],{alpha:.35,plane:Math.sin(a)<0?'rear':'front'});
        diamond(x,-66,3.5,{alpha:.75,highlight:true});
      }
      splitEllipse(49,13,58,0,{alpha:.4});break;
    }
    case 'sanctuary': {
      for(let i=0;i<n;i++){
        const spread=35+i*8,top=-78-i*4,lift=Math.sin(t*.75+i)*2;
        for(const side of [-1,1])curve(u=>[side*spread*Math.sin(u*Math.PI/2),top+lift+(u**.7)*110],{plane:i%2?'front':'rear',alpha:.55-i*.06,width:.85});
        diamond(0,top+lift,3.2,{alpha:.8,highlight:true});
      }
      splitEllipse(62,13,44,0,{alpha:.32});break;
    }
    case 'pulseHalo': {
      for(let i=0;i<n+1;i++){
        const p=(t*.26+i/(n+1))%1,y=48-p*106;
        splitEllipse(42+Math.sin(p*Math.PI)*13,12,y,0,{alpha:Math.sin(p*Math.PI)*.7,width:1,glow:true});
      }
      const r=40+sweep*40;ellipse(r,r*.25,0,49,{alpha:(1-sweep)*.45});break;
    }
    case 'mendingVeil': {
      const w=27+n*5;
      add([[-w,-47],[w,-47],[w+4,43],[-w-4,43]],{plane:'rear',closed:true,alpha:.1,fill:.045});
      for(let i=0;i<n*2+1;i++){const x=(i/(n*2)-.5)*w*2;curve(u=>[x+Math.sin(u*Math.PI+t)*3,-47+u*90],{alpha:.25,steps:12});}
      const y=-43+((t*.19)%1)*82;
      add([[-w,y],[w,y]],{alpha:.72,width:1.2,highlight:true,glow:true});
      for(let i=0;i<n+2;i++){const x=-w+(i+.5)/(n+2)*w*2;add([[x-3,y-6],[x+3,y+6]],{alpha:.8});}
      break;
    }
    case 'renewalSpiral': {
      for(let i=0;i<n;i++){
        const phase=i/n*TAU+t*.65;
        // Segments follow the depth of the helix; its rear coils pass behind art.
        for(let j=0;j<8;j++)curve(u=>{const p=(j+u)/8,a=p*TAU*1.45+phase;return [Math.cos(a)*47,-58+p*116];},{plane:Math.sin((j+.5)/8*TAU*1.45+phase)<0?'rear':'front',alpha:.5,width:.85,steps:5});
        const p=(t*.19+i/n)%1,a=p*TAU*1.45+phase;diamond(Math.cos(a)*47,-58+p*116,3,{alpha:.9,highlight:true});
      }break;
    }
    case 'heartline': {
      const y=24,w=39+n*4,beat=(t*.8)%1;
      add([[-w-6,-12],[-w-10,-12],[-w-10,37],[-w-6,37]],{alpha:.6});
      add([[w+6,-12],[w+10,-12],[w+10,37],[w+6,37]],{alpha:.6});
      curve(u=>{const x=u*2*w-w,q=(u-beat+1)%1;const pulse=q<.025?(-q/.025)*17:q<.055?-17+(q-.025)/.03*39:q<.09?22-(q-.055)/.035*22:0;return [x,y+pulse];},{alpha:.85,width:1.1,highlight:true,steps:80});
      for(let i=0;i<n;i++)diamond(-w+i*(2*w/Math.max(1,n-1)),44,2.8,{alpha:.5+.25*Math.sin(t*3+i),glow:true});
      break;
    }
    case 'crystalCast': {
      // plates set row by row inside the token's outline; a setting line runs down the cast
      const rows=3+n,set=((t*.35)%1)*(rows+1.5);
      for(let j=0;j<rows;j++){const y=-42+j*84/(rows-1),half=Math.sqrt(Math.max(0,1-(y/52)**2))*46,cells=3+(j%2),w=2*half/cells,r=Math.min(w,84/(rows-1))*.55;
        for(let c=0;c<cells;c++){const x=-half+w*(c+.5),on=clamp(set-j-c/cells,0,1);
          add([[x,y-r],[x+r*.86,y-r*.5],[x+r*.86,y+r*.5],[x,y+r],[x-r*.86,y+r*.5],[x-r*.86,y-r*.5]],{closed:true,alpha:.16+.5*on,fill:.02+.08*on,width:.6+.4*on,glow:on>.6,plane:(j+c)%3===0?'rear':'front'});}}
      const sy=-42+clamp(set/rows,0,1)*84;add([[-44,sy],[44,sy]],{alpha:.55,width:.9,highlight:true,glow:true});
      break;
    }
    case 'wingSuture': {
      // filaments sweep in from both sides, as from her wings, to a seam; whip stitches run down it
      for(const s of [-1,1])for(let k=0;k<3+n;k++){const y0=-52+k*104/(2+n),sway=Math.sin(t*1.1+k+s)*4;
        curve(u=>[s*(80-u*74),y0+Math.sin(u*Math.PI)*(-14+sway)-u*y0*.3],{alpha:.32,width:.7,steps:14,plane:s<0?'rear':'front'});}
      add([[0,-44],[0,44]],{alpha:.32,width:.6});
      const stitches=4+n,run=(t*.3)%1;
      for(let j=0;j<stitches;j++){const y=-40+j*80/(stitches-1),on=clamp(run*stitches*1.2-j,0,1);if(on<=0)continue;
        add([[-7,y-5],[7,y+5]],{alpha:.75*on,width:1,highlight:true,glow:true});add([[7,y+5],[-7,y+9]],{alpha:.3*on,width:.6,plane:'rear'});}
      diamond(0,-40+run*80,3,{alpha:.95,highlight:true,glow:true});
      break;
    }
    case 'threadbind': {
      const w=30+n*4,rows=4+n,tight=.45+.2*Math.sin(t*1.1),aw=w*(1-.42*tight),ys=Array.from({length:rows},(_,j)=>-42+j*84/(rows-1));
      const lace=(j,s,u)=>[s*aw*(1-2*u),ys[j]+(ys[j+1]-ys[j])*u+Math.sin(Math.PI*u)*(1-tight)*5];
      for(const s of [-1,1]){add(ys.map(y=>[s*(aw+1.5),y]),{plane:'rear',alpha:.2,width:.5});for(const y of ys)diamond(s*aw,y,1.8,{alpha:.6,highlight:true});}
      for(let j=0;j<rows-1;j++)for(const s of [-1,1])curve(u=>lace(j,s,u),{plane:'front',alpha:s<0?.45:.62,width:s<0?.7:.9,glow:j%2===0,steps:12});
      const seg=((t*.23)%1)*(rows-1),j=Math.min(rows-2,Math.floor(seg)),k=lace(j,j%2?1:-1,seg-j);diamond(k[0],k[1],3,{alpha:.95,highlight:true,glow:true});
      for(const s of [-1,1])curve(u=>[s*aw-s*u*6,ys.at(-1)+u*12+Math.sin(t*1.3+s+u*3)*2],{alpha:.3,width:.55,steps:6});
      break;
    }
    case 'guide': {
      const tip=-68-Math.sin(t*.8)*2;diamond(0,tip,7,{alpha:.85,fill:.08,glow:true});
      for(let i=0;i<n+1;i++){const p=(t*.35+i/(n+1))%1,y=-57+p*95,w=5+p*13;add([[-w,y+7],[0,y],[w,y+7]],{alpha:Math.sin(p*Math.PI)*.65,width:.9});}
      for(const sign of [-1,1])add([[sign*22,42],[sign*34,59],[sign*42,72]],{alpha:.22});
      break;
    }
    case 'lanternCrown': {
      for(let i=0;i<n;i++){
        const a=(i+.5)/n*Math.PI,x=Math.cos(a)*52,y=-61-Math.sin(a)*18+Math.sin(t*.75+i)*2,r=4.5+n*.3;
        diamond(x,y,r,{alpha:.8,fill:.06,glow:true});
        add([[x,y+r],[x-11,-12],[x+11,-12]],{plane:'rear',closed:true,alpha:.12,fill:.025});
        add([[x,y+r+4],[x,-13]],{plane:'rear',alpha:.22});
      }
      curve(u=>point(Math.PI+u*Math.PI,57,19,0,-52),{alpha:.4});break;
    }
    case 'survey': {
      const a=t*.65;
      for(let i=1;i<=n+1;i++)splitEllipse(22+i*11,10+i*5,28,0,{alpha:.17+i*.025});
      const fan=[[0,28],...Array.from({length:11},(_,i)=>point(a-i*.035,66,32,0,28))];
      add(fan,{closed:true,alpha:.35,fill:.055,plane:Math.sin(a)<0?'rear':'front'});
      for(let i=0;i<n;i++){const angle=i/n*TAU+.3,p=point(angle,50,25,0,28),lit=(Math.cos(a-angle)+1)*.5;diamond(...p,2+lit*2,{alpha:.15+lit*.65,highlight:true});}
      break;
    }
    case 'compass': {
      for(let i=0;i<n;i++){
        const a=i/n*TAU-Math.PI/2,x=Math.cos(a)*68,y=Math.sin(a)*61;
        const basis=([u,v])=>[x+u*Math.cos(a)-v*Math.sin(a),y+u*Math.sin(a)+v*Math.cos(a)];
        add([[-4,-11],[3,-11],[7,0],[3,11],[-4,11]].map(basis),{alpha:.65});
      }
      for(let i=0;i<2;i++)curve(u=>point(t*.16+i*Math.PI+u*.7,62,55),{alpha:.4,width:1.2});
      const a=t*.4,p=point(a,49,43);add([[p[0]*.83,p[1]*.83],p,[p[0]*.97-3,p[1]*.97+3]],{alpha:.85,highlight:true});break;
    }
    case 'cometCourt': {
      for(let i=0;i<n;i++){
        const a=t*(.45+i*.035)+i/n*TAU,rotation=(i%2?1:-1)*.28;
        const orbit=a=>{const [x,y]=point(a,68,26);return [x*Math.cos(rotation)-y*Math.sin(rotation),x*Math.sin(rotation)+y*Math.cos(rotation)];};
        splitEllipse(68,26,0,rotation,{alpha:.13});
        for(let j=0;j<5;j++)curve(u=>orbit(a-(j+u)*.09),{alpha:(1-j/5)*.7,width:1.8-j*.2,plane:Math.sin(a)<0?'rear':'front',steps:3,highlight:j===0});
        diamond(...orbit(a),2.5,{alpha:.9,highlight:true,plane:Math.sin(a)<0?'rear':'front'});
      }break;
    }
    case 'tetherWeave': {
      for(let i=0;i<n;i++){
        const phase=t*.16+i/n*Math.PI;
        for(let j=0;j<4;j++)curve(u=>{const a=(j+u)/4*TAU;return [Math.sin(a+phase)*64,Math.sin(a*2+phase)*34];},{plane:j%2?'rear':'front',alpha:.42,width:.85,steps:Math.ceil(detail/4)});
        const a=t*.7+i*TAU/n;diamond(Math.sin(a+phase)*64,Math.sin(a*2+phase)*34,2.7,{alpha:.85,highlight:true});
      }break;
    }
    case 'resonanceChime': {
      for(let i=0;i<n+2;i++){
        const x=(i-(n+1)/2)*14,y=-61-Math.cos((i-(n+1)/2)*.6)*11,p=.5+.5*Math.sin(t*1.6-i*.7);
        add([[x-2,y+3],[x-2,y+17+p*8],[x+2,y+20+p*8],[x+2,y]],{alpha:.35+p*.4,glow:true});
        diamond(x,y-5,2.3,{alpha:.7,highlight:true});
      }
      for(let i=0;i<n;i++)curve(u=>point(u*Math.PI,48+i*4,12+i*3,0,47),{alpha:.3});break;
    }
    case 'bloomSeal': {
      const petals=3+n*2;
      curve(u=>{const a=u*TAU+t*.06,r=42+12*Math.cos(a*petals);return [Math.cos(a)*r,48+Math.sin(a)*r*.34];},{alpha:.55,width:.9,steps:detail*2,closed:true,glow:true});
      splitEllipse(57,20,48,0,{alpha:.25});
      for(let i=0;i<n;i++){const x=(i-(n-1)/2)*18;curve(u=>[x+Math.sin(u*Math.PI*2+t+i)*4,43-u*40],{alpha:.25,steps:12});}
      diamond(0,-2+Math.sin(t*.6)*2,5,{alpha:.75,highlight:true,fill:.03});break;
    }
  }
  drawProjectedEffect(id,{n,t,detail,options,add,curve,ellipse,splitEllipse,diamond,burst});
  addEmission(frame,t,options);
  return fitTokenEffect(frame);
}

/** Paint the requested depth plane only. Broad glow is a second bounded stroke,
 * avoiding expensive blur filters and framebuffer captures on moving tokens. */
export function paintTokenEffect(ctx,sample,{plane='front',attachedEmitters=null}={}){
  if(!sample?.paths?.length)return;
  const wanted=plane==='back'?'rear':plane;
  ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
  // Canvas style setters cross into the native renderer. Adjacent authored
  // paths often share their ink, so retain only this invocation's assignments.
  // No context state survives restore(), and path order/coverage is unchanged.
  let strokeStyle,fillStyle,alpha,width;
  for(const path of sample.paths){
    if(path.plane!==wanted||path.alpha<=0||attachedEmitters?.size&&path.role==='emitter-aperture'&&attachedEmitters.has(path.emitterId))continue;
    ctx.beginPath();for(let i=0;i<path.points.length;i++){const p=path.points[i];if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);}if(path.closed)ctx.closePath();
    const ink=path.highlight?'#fff0fc':path.tint?validColor(path.tint):sample.color;
    if(strokeStyle!==ink){ctx.strokeStyle=ink;strokeStyle=ink;}
    const fill=path.fillTint?validColor(path.fillTint):sample.color;
    if(fillStyle!==fill){ctx.fillStyle=fill;fillStyle=fill;}
    if(path.fill){
      if(alpha!==path.fill){ctx.globalAlpha=path.fill;alpha=path.fill;}ctx.fill();
    }
    if(path.glow){
      const glowAlpha=path.alpha*.13,glowWidth=path.width+(path.glowSpread??3);
      if(alpha!==glowAlpha){ctx.globalAlpha=glowAlpha;alpha=glowAlpha;}
      if(width!==glowWidth){ctx.lineWidth=glowWidth;width=glowWidth;}ctx.stroke();
    }
    if(alpha!==path.alpha){ctx.globalAlpha=path.alpha;alpha=path.alpha;}
    if(width!==path.width){ctx.lineWidth=path.width;width=path.width;}ctx.stroke();
  }
  ctx.restore();
}

/** Browser preview reuses the live painter. Optional token/bit callbacks allow
 * the HUD's actual portrait and Resonant Core painter without asset downloads. */
export function paintTokenEffectPreview(canvas,{id='shield',count=4,elapsed=0,background='#17141d',tokenColor='#302734',textColor='#f5e8f2',paintToken=null,paintBits=null,viewExtent=240,...options}={}){
  const ctx=canvas?.getContext?.('2d');if(!ctx)return null;
  const sample=sampleTokenEffect(id,count,elapsed,options),width=canvas.width,height=canvas.height,extent=Number.isFinite(viewExtent)?Math.max(240,viewExtent):240,scale=Math.min(width,height)/extent;
  ctx.clearRect(0,0,width,height);ctx.fillStyle=background;ctx.fillRect(0,0,width,height);ctx.save();ctx.translate(width/2,height/2);ctx.scale(scale,scale);
  ctx.save();ctx.scale(sample.effectScale??1,sample.effectScale??1);paintTokenEffect(ctx,sample,{plane:'rear'});ctx.restore();paintBits?.(ctx,{plane:'rear',sample});
  if(paintToken)paintToken(ctx);else{ctx.fillStyle=tokenColor;ctx.beginPath();ctx.arc(0,0,44,0,TAU);ctx.fill();ctx.strokeStyle=textColor;ctx.globalAlpha=.28;ctx.lineWidth=.7;ctx.stroke();ctx.globalAlpha=1;ctx.fillStyle=textColor;ctx.font='24px Georgia,serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('E',0,1);}
  ctx.save();ctx.scale(sample.effectScale??1,sample.effectScale??1);paintTokenEffect(ctx,sample,{plane:'front'});ctx.restore();paintBits?.(ctx,{plane:'front',sample});ctx.restore();return sample;
}

/** A field Ellie casts on herself. Parts that would cross her face move
 * behind the portrait (split exactly at the face's edge, so the rest of a
 * line stays in front), and with her wings open the field takes a paler
 * pearl ink and a slightly wider reach so it reads apart from the magenta
 * wing filaments. Pure; cached per sampled frame. */
const selfFrames=new WeakMap();
const FACE={cx:2,cy:9,rx:30,ry:30};
export function selfFieldFrame(frame,{wings=0}={}){
  if(!frame?.paths?.length)return frame;
  const w=Math.round(clamp(finite(wings,0),0,1)*8)/8;
  let byWing=selfFrames.get(frame);if(!byWing)selfFrames.set(frame,byWing=new Map());
  const hit=byWing.get(w);if(hit)return hit;
  const k=frame.effectScale??1,grow=1+.12*w,cx=FACE.cx/k,cy=FACE.cy/k,rx=FACE.rx/k,ry=FACE.ry/k;
  const inside=p=>((p[0]*grow-cx)/rx)**2+((p[1]*grow-cy)/ry)**2<1;
  const pale=w>0?mixHex('#ff85db','#ffe2f5',.75*w):null,paths=[];
  const push=(path,points,plane)=>paths.push({...path,plane,points:grow===1?points:points.map(p=>[p[0]*grow,p[1]*grow]),...(pale&&!path.highlight&&!path.tint?{tint:pale}:{}),...(grow!==1?{width:path.width*grow}:{})});
  for(const path of frame.paths){
    const pts=path.points;
    if(path.plane!=='front'||pts.length<2){push(path,pts,path.plane);continue;}
    // long straight runs are subdivided so a line crossing the face is caught even when its ends are outside
    const dense=[];for(let i=0;i<pts.length;i++){if(i){const a=pts[i-1],b=pts[i],n=Math.min(24,Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/(4/k)));for(let j=1;j<n;j++)dense.push([a[0]+(b[0]-a[0])*j/n,a[1]+(b[1]-a[1])*j/n]);}dense.push(pts[i]);}
    if(path.closed)dense.push(pts[0]);
    if(!dense.some(inside)){push(path,pts,'front');continue;}
    // a filled shape over the face goes behind as a whole; lines are split at the face edge
    if(path.closed&&path.fill>0){push(path,pts,'rear');continue;}
    let run=[dense[0]],inFace=inside(dense[0]);
    for(let i=1;i<dense.length;i++){const p=dense[i],now=inside(p);run.push(p);if(now!==inFace){if(run.length>1)push({...path,closed:false},run,inFace?'rear':'front');run=[p];inFace=now;}}
    if(run.length>1)push({...path,closed:false},run,inFace?'rear':'front');
  }
  const out={...frame,paths,selfField:true};byWing.set(w,out);return out;
}
function mixHex(a,b,q){const pa=parseInt(a.slice(1),16),pb=parseInt(b.slice(1),16),c=s=>Math.round(((pa>>s)&255)+(((pb>>s)&255)-((pa>>s)&255))*q);return '#'+[16,8,0].map(s=>c(s).toString(16).padStart(2,'0')).join('');}
