import {cubic} from './wing-art.mjs?v=12.0.1';
const unit=x=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const finite=(x,fallback=0)=>Number.isFinite(x)?x:fallback;
const BRAID_CACHE=new WeakMap();
export function v7WingRigRequired(v){
  return !!(v?.enabled&&(v.filamentTexture&&v.filamentStrength>0||v.wingMotion?.active));
}
// Preserve a pre-existing extreme pose verbatim at the canvas boundary, while
// easing only the additive displacement as it approaches the available room.
const boundedChange=(original,target,min,max)=>{
  const delta=target-original;if(!delta)return original;
  const room=Math.max(0,delta>0?max-original:original-min);
  return original+delta*room/(room+Math.abs(delta));
};
/** Health and suppression always win over optional expression. Physical
 * collapse contributes twice: material fades and additive bending subsides. */
export function v7WingAvailability(flight,visual){
  if(flight?.v7?.enabled!==true)return 0;
  const collapse=unit(Math.max(finite(visual?.collapse),finite(flight?.formation?.fold)));
  const suppression=unit(finite(visual?.suppression));
  const wings=unit(finite(flight?.structureAnimation?.weights?.[0],1));
  return (1-collapse)**2*(1-suppression*.8)*wings;
}
/** Compile the 18 expression channels once per side. Shoulder attachment is
 * exact; x is only multiplied by a positive factor, so additive gestures never
 * send a filament across the centerline or reverse left/right ownership. */
/** Fixed material-space envelopes used by a live gesture. Callers may compile
 * their permanent topology; temporary vertices keep the ordinary path below. */
export function v7WingPointCoordinates(source){
  const u=unit(finite(source[2],1)),e=smooth(u),y=source[1]+13;
  return {sourceY:source[1],sourceU:source[2],u,e,y,upper:smooth((-y-15)/180),lower:smooth((y-25)/235),middle:Math.exp(-((y/120)**2)),wave:Math.sin(Math.PI*u)};
}
export function v7WingWarp(flight,visual,side,coordinates=null){
  const availability=v7WingAvailability(flight,visual),v=flight?.v7;
  if(!availability)return null;
  const reduced=flight?.effective?.reducedMotion===true;
  const supplied=!reduced&&v.wingAnimations!==false&&Array.isArray(v.wingMotion?.channels)?v.wingMotion.channels.slice(side<0?0:9,side<0?9:18):Array(9).fill(0);
  const c=supplied.map(n=>finite(n)*availability);
  if(!c.some(n=>Math.abs(n)>1e-9))return null;
  return (result,source)=>{
    const saved=coordinates?.get(source),fixed=saved&&saved.sourceY===source[1]&&saved.sourceU===source[2]?saved:null;
    const u=fixed?.u??unit(finite(source[2],1)),e=fixed?.e??smooth(u),y=fixed?.y??source[1]+13;
    const upper=fixed?.upper??smooth((-y-15)/180),lower=fixed?.lower??smooth((y-25)/235),middle=fixed?.middle??Math.exp(-((y/120)**2));
    const wave=fixed?.wave??Math.sin(Math.PI*u),xScale=Math.max(.75,Math.min(1.25,1+c[1]*e*.17-c[2]*wave*.13));
    const targetY=result[1]-c[0]*e*34+c[3]*wave*middle*17+c[4]*e*y*.075-c[6]*lower*e*26-c[7]*upper*e*28;
    return [boundedChange(result[0],result[0]*xScale,-278,278),boundedChange(result[1],targetY,-255,286),result[2]+c[5]*wave*(y/250)*16+c[8]*e*24+c[2]*middle*e*13];
  };
}
export function v7WingRigIdentity(flight){
  const v=flight?.v7;if(v?.enabled!==true)return null;
  return flight.effective?.reducedMotion?null:v.wingMotion?.channels;
}
function braidTopology(ribs){
  let cached=BRAID_CACHE.get(ribs);if(cached)return cached;
  cached=new Map([0,4,9].map(ri=>[ri,Array.from({length:25},(_,i)=>{const u=i/24;return [...cubic(ribs[ri],u),u];})]));
  BRAID_CACHE.set(ribs,cached);return cached;
}
/** Bounded thin native strands. Fine texture follows the actual posed tangent,
 * not a sprite, so it flexes, cuts and depth-splits with the original material. */
export function v7WingMaterialPaths({flight,visual,side,phase,ribs,warp,growth=1}){
  const availability=v7WingAvailability(flight,visual),v=flight?.v7;
  if(!availability||growth<=0)return [];
  const reduced=flight.effective?.reducedMotion===true,materialStill=reduced||flight.structureAnimation?.animated===false,time=materialStill?0:finite(v.materialPhase,finite(visual?.time));
  const texture=v.filamentTexture?unit(finite(v.filamentStrength,.65))*availability:0;
  const parts=[],detail=v.wingDetail??'medium';
  if(texture>.001)for(const ri of detail==='low'?[4]:detail==='high'?[0,4,9]:[0,9]){
    const topology=braidTopology(ribs).get(ri),source=detail==='low'?topology.filter((_,i)=>i%2===0):topology;
    const mapped=source.map(warp),tension=.72+.28*Math.cos(phase+ri*.36);
    // The two braided strands share their posed tangent and aperture. Compute
    // those once without changing either strand's phase or arithmetic order.
    const coordinates=mapped.map((p,i)=>{
      const u=source[i][2],before=mapped[Math.max(0,i-1)],after=mapped[Math.min(mapped.length-1,i+1)],dx=after[0]-before[0],dy=after[1]-before[1],length=Math.hypot(dx,dy)||1;
      return {u,nx:dy/length,ny:dx/length,aperture:Math.sin(Math.PI*u)**.8};
    });
    for(const strand of [-1,1]){
      const points=mapped.map((p,i)=>{
        const {u,nx,ny,aperture}=coordinates[i],turn=u*Math.PI*11+time*.44+ri*.8+(strand<0?Math.PI:0),offset=Math.sin(turn)*(1.4+tension*.55)*aperture;
        return [p[0]-nx*offset,p[1]+ny*offset,p[2]+Math.cos(turn)*.9*aperture];
      });
      parts.push({id:`v7-braid-${ri}-${strand}`,source,points,width:.4,strength:texture*(.42+.08*tension),material:'braid'});
    }
  }
  // V9 tension stitches travel on the actual load-bearing ribs during a
  // flight impulse, deliberate wing gesture or deployment. Quiet hovering
  // gains no extra idle motion. The original ribs, curls, web and shoulder
  // roots stay exact; these short paired strands are material, not new fins.
  let gestureLoad=0;for(const channel of v.wingMotion?.channels??[])gestureLoad=Math.max(gestureLoad,Math.abs(finite(channel)));
  const impulse=unit(Math.max(finite(flight.movement?.sweep),gestureLoad*.8,growth<.999?.8:0));
  if(flight.v9?.signatureCraft===true&&texture>.001&&impulse>.001&&!materialStill&&visual?.energyPulses!==false){
    for(const ri of detail==='low'?[4]:[0,4,9]){
      const q=growth<.999?unit(growth):((time*.31+ri*.137+side*.071)%1+1)%1,head=.10+.88*q,lo=Math.max(.08,head-.15),hi=Math.min(growth,head);
      if(hi<=lo)continue;
      const source=Array.from({length:9},(_,i)=>{const u=lo+(hi-lo)*i/8;return [...cubic(ribs[ri],u),u];});
      const mapped=source.map(warp),neighbor=source.map(p=>warp([...cubic(ribs[ri===9?8:ri+1],p[2]),p[2]])),envelope=Math.sin(Math.PI*q)**2;
      for(const strand of [-1,1]){
        const points=mapped.map((p,i)=>{
          // Both sides of a pointed eyelet sit between two existing ribs;
          // they cannot become a new outer fin as the pose cups or turns.
          const fold=Math.sin(Math.PI*i/8)*(strand<0?.10:.42),b=neighbor[i];
          return p.map((n,k)=>n+(b[k]-n)*fold);
        });
        parts.push({id:`v9-tension-${ri}-${strand}`,source,points,width:.82,strength:texture*impulse*envelope*.9,highlight:.3,material:'tension-stitch'});
      }
    }
  }
  if(growth>=1)return parts;
  return parts.flatMap(part=>{
    const points=[];
    for(let i=0;i<part.points.length;i++){
      const u=part.source[i][2];
      if(u<=growth){points.push(part.points[i]);continue;}
      if(i&&part.source[i-1][2]<growth){const q=(growth-part.source[i-1][2])/(u-part.source[i-1][2]),a=part.points[i-1],b=part.points[i];points.push(a.map((n,j)=>n+(b[j]-n)*q));}
      break;
    }
    return points.length>1?[{...part,points}]:[];
  });
}
