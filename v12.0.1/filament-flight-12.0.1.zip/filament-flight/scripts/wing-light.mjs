import {localPerformance} from './performance.mjs?v=12.0.1';
import {refreshAfterLight} from './light-refresh.mjs?v=12.0.1';
import {ID,runtimeConfiguration} from './config.mjs?v=12.0.1';
import {normalizeFlag,resolveRenderState} from './state.mjs?v=12.0.1';
import {hash} from './conditions.mjs?v=12.0.1';
import {WingLightEdges} from './wing-light-edge.mjs?v=12.0.1';
import {sampleLightAppearance} from './light-appearance.mjs?v=12.0.1';
import {LightAppearanceShaders} from './light-appearance-shaders.mjs?v=12.0.1';
import {stepLightFade,lightFadeShape} from './light-model.mjs?v=12.0.1';

const clock=()=>Number(globalThis.game?.time?.serverTime)||Date.now();
const placed=(token,initializing=false)=>!!((canvas.ready||initializing)&&token&&!token.destroyed&&!token.isPreview
  &&token.document?.parent===canvas.scene&&canvas.scene?.tokens?.get(token.id)===token.document);

function nativeLightOrigin(token) {
  const doc=token.document;
  const position={};
  for(const k of ['x','y'])if(Number.isFinite(token[k]))position[k]=token[k];
  const origin=doc.getLightOrigin?.(position)??token.center??{x:doc.x+token.w/2,y:doc.y+token.h/2};
  if(!Number.isFinite(origin.x)||!Number.isFinite(origin.y))throw new Error('The wing light has no valid token position.');
  return origin;
}

export function nativeLightData(token,light,origin=nativeLightOrigin(token)) {
  const doc=token.document;
  const radius=units=>units>0?token.getLightRadius(units):0;
  const dim=radius(light.dim),bright=radius(light.bright);
  return {x:origin.x,y:origin.y,elevation:origin.elevation??doc.elevation??0,level:doc.level??null,
    dim,bright,radius:Math.max(dim,bright),angle:360,rotation:0,walls:true,vision:false,
    color:light.color,alpha:light.alpha,luminosity:light.luminosity,attenuation:light.attenuation,
    coloration:1,contrast:0,saturation:0,shadows:0,priority:0,
    animation:{...light.animation},seed:hash(doc.uuid),disabled:false,preview:false};
}

const LIGHT_FIELDS=['color','alpha','luminosity','attenuation','edgeAttenuation'];
/** Native initialization is mandatory for wall/vision correctness, but an
 * unchanged light needs neither a whole object rebuild nor JSON serialization. */
export function lightDataChanged(previous,token,light,origin) {
  if(!previous||previous.x!==origin.x||previous.y!==origin.y||
    previous.elevation!==(origin.elevation??token.document.elevation??0)||previous.level!==(token.document.level??null))return true;
  for(const key of LIGHT_FIELDS)if(previous[key]!==light[key])return true;
  for(const key of ['type','speed','intensity'])if(previous.animation[key]!==light.animation[key])return true;
  const radius=units=>units>0?token.getLightRadius(units):0;
  return previous.bright!==radius(light.bright)||previous.dim!==radius(light.dim);
}

/** One native source per light-enabled token. The core owns illumination,
 * walls, level/elevation clipping and pulse animation. We never write token.light
 * or AmbientLight documents, nor gate illumination by the observer's visibility.
 */
export class WingLights {
  constructor(manager){this.manager=manager;this.records=new Map();this.ticker=null;this.lastTick=-Infinity;this.edges=new WingLightEdges();this.edges.install();this.appearance=new LightAppearanceShaders({report:error=>this.manager.report(error)});}
  request(){refreshAfterLight();}
  snapshot(record,cfg=runtimeConfiguration(),now=clock(),{displayFrame=false}={}){
    // A native circle can be active without an artwork record (for example
    // folded wings or cosmetic effects hidden). Reuse a canonical frame only
    // when one exists; mechanical allocation sampling remains the fallback.
    const frame=this.manager.frameState?.(record.token,now,{displayFrame});if(frame)return frame;
    const rendered=this.manager.states?.get(record.token),age=now-rendered?.snapshotAt;
    // The flight ticker has already resolved these channels. Never reuse a
    // sample from before the latest flag/settings update or from a paused tab.
    if(rendered?.snapshot&&rendered.snapshotAt>record.invalidatedAt&&age>=0&&age<=100)return rendered.snapshot;
    if(record.data.lightWithBits===true&&this.manager.sampleState)return this.manager.sampleState(record.token,now);
    return resolveRenderState(record.data,cfg,now,this.manager.context(record.token.document));
  }
  sync(token,options={}){
    if(!localPerformance.active)return this.syncLighting(token,options);
    return localPerformance.measure('lighting',()=>this.syncLighting(token,options));
  }
  syncLighting(token,{force=false,initializing=false,notify=true,retry=false}={}){
    if(!token)return false;
    const cfg=runtimeConfiguration(),raw=token.document?.getFlag(ID,'flight');
    if(!placed(token,initializing)||raw==null||!cfg.effectsEnabled||!cfg.wingLight)return this.remove(token,{notify});
    let record=this.records.get(token),dirty=false;
    // Switching the light off lets a lit circle fade out on the ticker; a
    // circle that is not showing has nothing to fade.
    if(!(raw.lightEnabled??cfg.lightDefault)&&!record?.source)return this.remove(token,{notify});
    try{
      for(const other of this.records.keys())if(other!==token&&other.document.uuid===token.document.uuid)
        dirty=this.remove(other,{notify:false})||dirty;
      const data=normalizeFlag(raw,clock());
      if(!record){record={token,data,source:null,failed:null,nativeData:null,fade:{level:0,at:NaN}};this.records.set(token,record);}
      else record.data=data;
      record.invalidatedAt=clock();
      if(retry)record.failed=null;
      dirty=this.update(record,cfg,clock(),force)||dirty;
    }catch(error){dirty=this.fail(record,error)||dirty;}
    if(dirty&&notify)this.request();
    this.manageTicker();return dirty;
  }
  decorateSource(record,snapshot,cfg,now,prepared=null){
    if(!record.source)return;
    const sample=prepared??sampleLightAppearance(snapshot,cfg,now,{seed:record.token.document.uuid}),edge= snapshot.light.edgeAttenuation;
    record.appearanceActive=false;
    if(sample.enabled){
      // The combined shader owns its edge fade. The edge controller continues
      // to own only the shared native visibility mask, avoiding nested owners.
      this.edges.track(record.source,edge,{shader:false});
      const state=this.appearance.update(record.source,sample,{edgeAttenuation:this.edges.externalOwner()?0:edge});
      record.appearanceActive=state.active;
      if(state.active===false){this.appearance.release(record.source);this.edges.track(record.source,edge);this.edges.updateShaders(record.source);}
    }else{
      this.appearance.release(record.source);this.edges.track(record.source,edge);this.edges.updateShaders(record.source);
    }
  }
  update(record,cfg,now,force=false,{displayFrame=false,cosmeticOnly=false}={}){
    if(record.failed)return false;
    const snapshot=this.snapshot(record,cfg,now,{displayFrame});let light=snapshot.light;
    record.waiting=!!(light.enabled&&(snapshot.transition?.active||snapshot.requested?.lightWithBits===true&&
      (snapshot.bitTransition?.active||snapshot.bitCount?.transition?.active||snapshot.bitSequenceActive)));
    if(record.token.document.hidden)return this.releaseSource(record);
    // Warm up and fade out like the lantern instead of switching in one frame.
    const fade=record.fade??={level:0,at:NaN},on=!!light.active;
    if(on)record.lastLight=light;
    const level=stepLightFade(fade,on?1:0,now);
    if(!on&&(level<=0||!record.lastLight)){fade.level=0;record.lastLight=null;return this.releaseSource(record);}
    record.fading=level<1;
    const shape=lightFadeShape(level),lit=on?light:record.lastLight;
    if(shape.weight<1)light={...lit,alpha:lit.alpha*shape.weight,luminosity:lit.luminosity*shape.weight,bright:lit.bright*shape.reach,dim:lit.dim*shape.reach};
    else if(!on)light=lit;
    const origin=nativeLightOrigin(record.token);
    const detached=record.source&&!record.source.attached;
    if(cosmeticOnly&&!force&&!detached){this.decorateSource(record,snapshot,cfg,now);return false;}
    if(!force&&!detached&&!lightDataChanged(record.nativeData,record.token,light,origin)){this.decorateSource(record,snapshot,cfg,now);return false;}
    const data=nativeLightData(record.token,light,origin);
    if(!record.source){
      const Source=globalThis.foundry?.canvas?.sources?.PointLightSource;
      if(!Source)throw new Error('Foundry v14 PointLightSource is unavailable.');
      // An explicit independent ID avoids sharing the token's native source ID.
      const sourceId=`${ID}.light.${record.token.document.uuid}`;
      const source=new Source({object:record.token,sourceId});
      if(source.sourceId!==sourceId)throw new Error('The native light source did not retain its independent wing-light ID.');
      record.source=source;
    }
    // Establish ownership before initialization hooks recreate native layers.
    const sample=sampleLightAppearance(snapshot,cfg,now,{seed:record.token.document.uuid});
    if(!sample.enabled)this.appearance.release(record.source);
    this.edges.track(record.source,light.edgeAttenuation,{shader:!sample.enabled});
    this.appearance.initializeNative(record.source,data,{reset:force||!!detached});
    this.decorateSource(record,snapshot,cfg,now,sample);
    if(!record.source.attached)record.source.add();
    // PointLightSource owns the supplied object; retain an independent sample
    // so a native source cannot mutate the comparison for our next tick.
    record.nativeData={...data,edgeAttenuation:light.edgeAttenuation,animation:{...data.animation}};return true;
  }
  releaseSource(record){
    const source=record?.source;if(!source)return false;
    this.appearance.release(source);
    this.edges.untrack(source);
    record.source=null;record.nativeData=null;record.appearanceActive=false;record.fading=false;
    try{source.remove();}finally{source.destroy();}
    return true;
  }
  fail(record,error){
    let dirty=false;
    if(record){record.failed=String(error?.message??error);record.waiting=false;
      try{dirty=this.releaseSource(record);}catch{} }
    this.manager.report(new Error(`Wing light could not render. Flight remains available. ${error?.message??error}`));
    return dirty;
  }
  remove(token,{notify=true}={}){
    const record=this.records.get(token);if(!record)return false;
    this.records.delete(token);let dirty=false;
    try{dirty=this.releaseSource(record);}catch(error){this.manager.report(error);dirty=true;}
    if(dirty&&notify)this.request();this.manageTicker();return dirty;
  }
  manageTicker(){
    let needed=false;for(const record of this.records.values())if(!record.failed&&(record.source||record.waiting||record.fading)){needed=true;break;}
    if(needed&&!this.ticker&&canvas.ready&&canvas.app?.ticker){
      this.ticker=canvas.app.ticker;this.lastTick=-Infinity;this.ticker.add(this.tick,this,-20);
    }else if(!needed&&this.ticker){this.ticker.remove(this.tick,this);this.ticker=null;}
  }
  tick(){
    if(!localPerformance.active)return this.tickLighting();
    return localPerformance.measure('lighting',()=>this.tickLighting());
  }
  tickLighting(){
    if(!canvas.ready||globalThis.document?.hidden===true)return;
    const time=performance.now(),interval=1000/30,elapsed=time-this.lastTick;
    const cosmeticOnly=Number.isFinite(this.lastTick)&&elapsed>=0&&elapsed<interval-1e-6;
    if(!cosmeticOnly){
      // Keep the fractional budget at 60/120/144 Hz. Resetting it to every
      // accepted frame loses the remainder and can turn a 30 Hz budget into
      // uneven 20 Hz updates. A pause/clock reset starts one current sample;
      // it never replays a backlog of native geometry or perception work.
      this.lastTick=!Number.isFinite(this.lastTick)||elapsed<0||elapsed>interval*4?time:
        this.lastTick+Math.max(1,Math.floor((elapsed+1e-6)/interval))*interval;
    }
    const cfg=runtimeConfiguration(),now=clock();let dirty=false;
    for(const [token,record] of this.records){
      if(!placed(token)||!cfg.effectsEnabled||!cfg.wingLight){dirty=this.remove(token,{notify:false})||dirty;continue;}
      // Current/off and comfort opt-outs retain the original native 30 Hz
      // budget. A live appearance/reaction adds only uniform work in between.
      if(cosmeticOnly&&!record.appearanceActive)continue;
      try{dirty=this.update(record,cfg,now,false,{displayFrame:true,cosmeticOnly})||dirty;}catch(error){dirty=this.fail(record,error)||dirty;}
    }
    if(dirty)this.request();this.manageTicker();
  }
  rebuild({initializing=false,notify=true,retry=false}={}){
    if(!canvas.ready&&!initializing)return;
    let dirty=false;
    for(const token of this.records.keys())if(!placed(token,initializing))dirty=this.remove(token,{notify:false})||dirty;
    for(const token of canvas.tokens?.placeables??[])
      dirty=this.sync(token,{force:true,initializing,notify:false,retry})||dirty;
    if(dirty&&notify)this.request();this.manageTicker();
  }
  clear(){
    let dirty=false;
    for(const token of [...this.records.keys()])dirty=this.remove(token,{notify:false})||dirty;
    if(this.ticker){this.ticker.remove(this.tick,this);this.ticker=null;}
    if(dirty)this.request();
  }
  status(token){const record=this.records.get(token);return {localActive:!!record?.source?.active,error:record?.failed??null,edge:this.edges.status(record?.source),appearance:this.appearance.status(record?.source)};}
}
