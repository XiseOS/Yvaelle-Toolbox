import {sampleTreatmentOperations} from './treatment-choreography.mjs?v=12.0.1';
import {sampleTokenEffect,paintTokenEffect} from './token-effects.mjs?v=12.0.1';

/** Restorative token programs, conducted as patient-bound treatment sequences.
 * Every power feed starts at a sampled real instrument. Shapes remain active
 * until a result arrives; elapsed time never decides that healing succeeded. */
export const RESTORATIVE_TECHNIQUES=Object.freeze({
  pulseHalo:Object.freeze({name:'Restorative tide',mechanism:'Rising induction waves',period:5.4}),
  mendingVeil:Object.freeze({name:'Mending veil',mechanism:'Suspended restorative surface',period:5.8}),
  renewalSpiral:Object.freeze({name:'Renewal spiral',mechanism:'Ascending renewal channels',period:6.2}),
  heartline:Object.freeze({name:'Steady heartline',mechanism:'Synchronized diagnostic ribbon',period:5}),
  threadbind:Object.freeze({name:'Soul threads',mechanism:'Laced filament threads drawn tight',period:5.6}),
  crystalCast:Object.freeze({name:'Crystalline cast',mechanism:'Hardlight plates set row by row',period:5.2}),
  wingSuture:Object.freeze({name:'Wing-thread suture',mechanism:'Wing filaments whip-stitch a seam',period:5.8})
});
const TAU=Math.PI*2,clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const mix=(a,b,p)=>a+(b-a)*p,wrap=n=>(n%1+1)%1;
// A looping marker eases out before it wraps and back in after, so a work loop never jumps.
const ends=v=>smooth(v/.1)*(1-smooth((v-.9)/.1));
// Wing-thread suture: the needle runs down the seam for most of the loop, then lifts and glides back to the top.
const needleRun=c=>c<.84?c/.84:1-smooth((c-.84)/.16);
const countOf=e=>clamp(e.emitters?.length??0,0,4);
const widthFor=n=>27+n*5;
const threadWidth=n=>30+n*4;
// These techniques draw their own art and discard the field's paths.
const OWN_ART=new Set(['threadbind','crystalCast','wingSuture']);
export function restorativePosition(style,index,count,time){
  return RESTORATIVE_TECHNIQUES[style]?sampleTreatmentOperations(style,count,time)?.operations[index]?.position??null:null;
}

export function restorativeBounds(effect){
  if(!RESTORATIVE_TECHNIQUES[effect.style])return null;
  let left=-94,top=-88,right=94,bottom=88;
  for(const e of effect.emitters??[]){left=Math.min(left,e.x*100-7);top=Math.min(top,e.y*100-7);right=Math.max(right,e.x*100+7);bottom=Math.max(bottom,e.y*100+7);}
  return {x:left,y:top,width:right-left,height:bottom-top};
}

/** Returned paths are directly inspectable for clipping, origin alignment and
 * cost tests. There are no histories, images, filters, gradients or timers. */
export function sampleRestorativeTreatment(effect){
  const style=effect.style,spec=RESTORATIVE_TECHNIQUES[style];if(!spec)return null;
  const count=countOf(effect),animated=effect.animated!==false;
  const scan=effect.phase==='scanning',finish=effect.phase==='finishing';
  const success=finish&&['success','criticalSuccess'].includes(effect.outcome),critical=effect.outcome==='criticalSuccess';
  const p=clamp(effect.progress??0),scanP=animated?clamp(effect.scan??p):1;
  const t=animated?Math.max(0,effect.clock??0):0,k=t*TAU/spec.period;
  const entry=scan?smooth(scanP*1.45):1;
  const closure=success?(animated?smooth(p/.78):1):0;
  const release=finish&&!success?(animated?smooth(p):1):0;
  const fade=finish?1-smooth((p-.68)/.32):1;
  const strength=Math.max(0,effect.strength??1),power=(.38+count*.155)*strength;
  const detail=effect.detail??'standard',steps=detail==='low'?18:detail==='high'?36:26;
  // A zero count returns the same field shell (id, strength, colour, state) without sampling its art.
  const ownArt=OWN_ART.has(style),sampled=ownArt?{...sampleTokenEffect(style,0,0,{strength,color:'#ff85db'}),count}:sampleTokenEffect(style,count,t*1000,{strength,detail,animated,emission:false,color:'#ff85db'});
  // Established field art remains recognizable. A diagnosis first sketches it;
  // sustained treatment adds surfaces and conductors, with outcome-only closure.
  const baseGain=(scan?.16+.34*entry:1)*(1-release*.8)*(1-closure*.72)*fade;
  const paths=ownArt?[]:sampled.paths.map(path=>({...path,alpha:path.alpha*baseGain,fill:path.fill*baseGain}));
  const frame={...sampled,paths,bounds:restorativeBounds(effect),treatment:true,phase:effect.phase,emitters:[],outcome:effect.outcome??null};
  if(!count||!strength||!fade)return {...frame,paths:[]};
  const add=(points,{plane='front',alpha=.6,width=.8,fill=0,closed=false,highlight=false,glow=false,role='structure',emitterId=null}={})=>{
    if(points.length<2)return;
    paths.push({points,plane,alpha:clamp(alpha*power*fade),width,fill:clamp(fill*power*fade,0,.22),closed,highlight,glow,role,emitterId});
  };
  const curve=(fn,options={})=>{const n=options.steps??steps,points=new Array(n+1);for(let i=0;i<=n;i++)points[i]=fn(i/n);add(points,options);};
  const ellipse=(x,y,rx,ry,options={})=>curve(u=>[x+Math.cos(u*TAU)*rx,y+Math.sin(u*TAU)*ry],{closed:true,...options});
  const splitEllipse=(x,y,rx,ry,options={})=>{for(const side of [0,1])curve(u=>[x+Math.cos((u+side)*Math.PI)*rx,y+Math.sin((u+side)*Math.PI)*ry],{plane:side?'rear':'front',steps:Math.ceil(steps/2),...options});};
  const diamond=(x,y,r,options={})=>add([[x,y-r],[x+r*.65,y],[x,y+r],[x-r*.65,y]],{closed:true,...options});
  const splitCurve=(fn,options={})=>{
    // Split at interpolated z=0 intersections, preserving continuous ends.
    const count=steps*2,points=new Array(count+1);for(let i=0;i<=count;i++)points[i]=fn(i/count);let line=[points[0]],front=points[0][2]>=0;
    for(let i=1;i<points.length;i++){
      const a=points[i-1],b=points[i],next=b[2]>=0;
      if(next!==front){const q=-a[2]/(b[2]-a[2]),cross=[mix(a[0],b[0],q),mix(a[1],b[1],q),0];line.push(cross);add(line.map(p=>p.slice(0,2)),{...options,plane:front?'front':'rear'});line=[cross];front=next;}
      line.push(b);
    }
    add(line.map(p=>p.slice(0,2)),{...options,plane:front?'front':'rear'});
  };
  const currents=[];
  for(let i=0;i<count;i++){
    const e=effect.emitters[i],from=[e.x*100,e.y*100],plane=e.z>=0?'front':'rear';
    let port;
    if(style==='pulseHalo'){
      const a=Math.atan2(e.y-.26,e.x);port=[Math.cos(a)*48,43+Math.sin(a)*12];
    }else if(style==='renewalSpiral'){
      const a=i/count*TAU+t*.65+TAU*1.45;port=[Math.cos(a)*47,58];
    }else if(style==='crystalCast'){
      port=[Math.sign(e.x||1)*38,(i%2?1:-1)*14];
    }else if(style==='wingSuture'){
      port=[Math.sign(e.x||1)*10,-40+80*(animated?needleRun(wrap(t*.21)):.55)];
    }else if(style==='threadbind'){
      const w=threadWidth(count),side=Math.sign(e.x||1);port=[side*(w+5),-40+80*((i+.5)/Math.max(1,count))];
    }else if(style==='mendingVeil'){
      const w=widthFor(count);port=count===1?[-w,0]:count===3&&i===2?[0,43]:[Math.sign(e.x||1)*w,count===2?Math.sign(e.y)*25:Math.sign(e.y)*43];
    }else{
      const w=39+count*4;port=count===3&&i===2?[0,-12]:[Math.sign(e.x||1)*(w+10),count===4?(i<2?-8:33):24];
    }
    const target=e.workPoint?[e.workPoint.x*100,e.workPoint.y*100]:scan?[port[0]*(.55+.45*entry),-43+86*scanP]:port;
    const build=scan?smooth(scanP*1.6-i*.07):1;
    const q=animated?wrap(t*.37+i*.23):.52;
    const bow=(style==='renewalSpiral'?12:5)*(i%2?1:-1);
    const path=u=>[mix(from[0],target[0],u),mix(from[1],target[1],u)+Math.sin(Math.PI*u)*bow];
    const feed=.5*build*(1-release)*(1-closure*.6)*(e.activity==null?1:.55+e.activity*.65);
    curve(path,{plane,alpha:feed,width:.68,glow:true,role:'emitter-feed',emitterId:e.id??i,steps:10});
    const packet=path(q),tangent=path(Math.min(1,q+.035));
    add([packet,tangent],{plane,alpha:.96*build*(1-release)*(1-closure),width:1.7,highlight:true,glow:true,role:'energy-packet',emitterId:e.id??i});
    // A small aperture and a restrained fan show the core generating the field.
    diamond(...from,2.6+(.6+.5*Math.sin(k+i))*build,{plane,alpha:.65*build*(1-release),highlight:true,glow:true,role:'emitter-aperture',emitterId:e.id??i});
    const fan=style==='heartline'?3:6;
    add([from,[target[0]-fan,target[1]],[target[0]+fan,target[1]]],{plane,closed:true,fill:.025*build*(1-release),alpha:.12*build*(1-release),width:.4,role:'projection',emitterId:e.id??i});
    diamond(...target,2,{plane,alpha:.65*build*(1-release),highlight:true});
    frame.emitters.push({id:e.id??i,from,port:target,plane,role:e.role??null,stage:e.stage??null});currents.push(target);
  }

  if(style==='pulseHalo'){
    // Several bits drive independent induction ports; successive broad waves
    // lift from that powered basin through a translucent patient enclosure.
    const r=55,extent=62;
    curve(u=>[-r*Math.sin(u*Math.PI),-extent+u*extent*2],{plane:'rear',alpha:.21*entry,width:.7});
    curve(u=>[r*Math.sin(u*Math.PI),-extent+u*extent*2],{plane:'front',alpha:.26*entry,width:.7});
    splitEllipse(0,43,48,12,{alpha:.58*entry*(1-release),width:1,glow:true});
    for(let i=0;i<count;i++){
      const q=scan?scanP:animated?wrap(t*.2+i/count):(.3+i/count)%1,y=48-q*108,radius=43+Math.sin(Math.PI*q)*12;
      const alpha=Math.sin(q*Math.PI)*(.32+.32*entry)*(1-release)*(1-closure*.6);
      add(Array.from({length:steps+1},(_,j)=>{const a=j/steps*TAU;return [Math.cos(a)*radius,y+Math.sin(a)*10];}),{closed:true,fill:alpha*.045,alpha:alpha*.2,width:.4});
      splitEllipse(0,y,radius,10,{alpha,width:1.25,highlight:true,glow:true});
    }
    if(success){const y=animated?45-p*102:-8,radius=50*(1-closure*.2);splitEllipse(0,y,radius,12,{alpha:Math.sin(Math.PI*p)*.95+.25*(1-p),width:1.65,highlight:true,glow:true});}
    if(release)for(const s of [-1,1])curve(u=>[s*(48+release*12)*Math.sin(u*Math.PI),-51+u*100],{alpha:(1-release)*.35,width:.7});
  }
  if(style==='mendingVeil'){
    const w=widthFor(count),gap=success?12*(1-closure):12+release*18;
    // Two luminous sheets suspended from the tools close only on a real result.
    for(const s of [-1,1]){
      const pts=[[s*w,-47],[s*(gap+3),-43],[s*gap,43],[s*(w+3),43]];
      add(pts,{closed:true,fill:.038*entry*(1-release),alpha:.28*entry*(1-release),width:.75,plane:s<0?'rear':'front'});
      for(let j=0;j<4+count;j++){
        const y=-36+j*72/(3+count),breath=animated?Math.sin(k+j*.8)*1.6:0;
        curve(u=>[mix(s*w,s*gap,u),y+Math.sin(Math.PI*u)*(4+breath)],{alpha:.29*entry*(1-release),width:.55,steps:10});
      }
    }
    const sweep=scan?scanP:animated?wrap(t*.17):.56,y=-43+sweep*86;
    curve(u=>[-w+u*w*2,y+Math.sin(u*Math.PI)*3],{alpha:.77*entry*(1-release)*(scan||!animated?1:ends(sweep)),width:1.1,highlight:true,glow:true});
    for(let j=0;j<3+count;j++){
      const row=-35+j*70/(count+2),pull=success?closure:.22+(animated?.1*Math.sin(k+j):0);
      const half=gap*(1-pull*.5);
      add([[-half,row-3],[0,row+3], [half,row-3]],{alpha:.68*entry*(1-release),width:.7,highlight:true});
    }
    if(success){add([[0,-44],[0,44]],{alpha:closure*.9,width:1.4,glow:true,highlight:true});for(const y of [-44,44])diamond(0,y,3, {alpha:closure*.8,highlight:true});}
  }
  if(style==='renewalSpiral'){
    // Light channels rise from individually powered lower ports. Their broad
    // translucent ribbons are distinct from the mechanical traction treatment.
    for(let i=0;i<count;i++){
      const phase=i/count*TAU+t*.65;
      const path=u=>{const a=(1-u)*TAU*1.45+phase;return [Math.cos(a)*47,58-u*116,Math.sin(a)];};
      splitCurve(path,{alpha:.4*entry*(1-release)*(1-closure*.4),width:2.1,glow:true});
      if(detail!=='low')splitCurve(u=>{const p=path(u);return [p[0]*.9,p[1],p[2]];},{alpha:.19*entry*(1-release),width:.65});
      const q=scan?scanP:animated?wrap(t*.21+i/count):(.35+i/count)%1,at=path(q);
      diamond(at[0],at[1],3.3,{plane:at[2]>=0?'front':'rear',alpha:.92*entry*(1-release)*(scan||!animated?1:ends(q)),glow:true,highlight:true});
      if(success){const q=animated?smooth(p):.72,at=path(q);ellipse(at[0],at[1],3+2*closure,2.4,{plane:at[2]>=0?'front':'rear',alpha:(1-p)*.9,width:1.3,highlight:true,glow:true});}
    }
    splitEllipse(0,58,47,11,{alpha:.5*entry*(1-release),width:.8});
    if(success)splitEllipse(0,-58,18+closure*28,4+closure*6,{alpha:Math.sin(Math.PI*p)*.9,width:1.2,highlight:true,glow:true});
  }
  if(style==='heartline'){
    // A calm diagnostic ribbon spans powered brackets. The result locks the
    // reading into a clean signature; failure simply opens and dims the gates.
    const w=39+count*4,amp=success?1-closure*.7:1;
    add([[-w,-10],[w,-10],[w,38],[-w,38]],{closed:true,alpha:.1*entry,fill:.025*entry,plane:'rear'});
    for(const s of [-1,1]){
      const x=s*(w+10+release*10);
      add([[x-s*4,-12],[x,-12],[x,37],[x-s*4,37]],{alpha:.75*entry*(1-release),width:1.1,highlight:true,glow:true});
      for(let j=0;j<3;j++)add([[x+s*3,-5+j*8],[x+s*6,-5+j*8]],{alpha:.45*entry*(1-release),width:.6});
    }
    const beat=animated?wrap(t*.34):.48;
    curve(u=>{
      const q=(u-beat+1)%1,pulse=q<.045?-Math.sin(q/.045*Math.PI)*9:q<.11?Math.sin((q-.045)/.065*Math.PI)*14:q<.17?-Math.sin((q-.11)/.06*Math.PI)*4:0;
      return [-w+u*w*2,6+pulse*amp];
    },{alpha:.7*entry*(1-release),width:.9,highlight:true,glow:true,steps:72});
    for(let i=0;i<count;i++){
      const x=count===1?0:-w+10+i*(w*2-20)/(count-1);
      const q=animated?wrap(t*.31+i/count):.4;
      diamond(x,45,2.4+Math.sin(q*Math.PI)*.8,{alpha:.5*entry*(1-release),highlight:true});
      add([[x,-16],[x,-21-Math.sin(q*Math.PI)*4]],{alpha:.45*entry*(1-release),width:.7});
    }
    if(success){add([[-w+4,36],[w-4,36]],{alpha:closure*.85,width:1.4,highlight:true,glow:true});diamond(0,36,3,{alpha:closure*.85,highlight:true});}
  }
  if(style==='crystalCast'){
    // Plates set row by row over the wound. A real success fuses them into one
    // smooth shell with a glint; failure cracks them apart and they drift loose.
    // While working, set plates stay seated (dimmer) and the setting front
    // re-sweeps them, so the cast never empties when the loop starts again.
    const rows=3+count,span=rows+.8,cycle=scan?scanP:animated?wrap(t*.19):.6,front=success?rows+1:cycle*span,looping=!scan&&!success&&animated;
    for(let j=0;j<rows;j++){const y=-40+j*80/(rows-1),half=Math.sqrt(Math.max(0,1-(y/54)**2))*44,cells=3+(j%2),w=2*half/cells,r=Math.min(w,80/(rows-1))*.56;
      for(let c=0;c<cells;c++){const at=j+c/cells,age=wrap((front-at)/span);
        const on=looping?.34+.66*clamp(age*span)*(1-smooth((age-.55)/.45)):clamp(front-at);
        const drift=release*(c-cells/2+.5)*7,x=-half+w*(c+.5)+drift,yy=y+release*(j-rows/2)*3;
        add([[x,yy-r],[x+r*.86,yy-r*.5],[x+r*.86,yy+r*.5],[x,yy+r],[x-r*.86,yy+r*.5],[x-r*.86,yy-r*.5]],{closed:true,plane:(j+c)%3===0?'rear':'front',
          alpha:(.16+.55*on)*entry*(1-release*.55)*(1-closure*.45),fill:(.02+.07*on)*entry*(1-release),width:.55+.35*on,glow:on>.6,highlight:on>.95&&!success});
        if(release&&on>.5)add([[x-r*.5,yy-r*.3],[x+r*.25,yy+r*.45]],{alpha:.55*release,width:.5});}}
    if(!success){const y=-40+clamp(front/rows)*80,lit=looping?smooth(front/.5)*(1-smooth((front-rows)/.6)):1;add([[-46,y],[46,y]],{alpha:.6*entry*(1-release)*lit,width:1,highlight:true,glow:true});}
    if(success){splitEllipse(0,0,47,54,{alpha:.75*closure,width:1.4,highlight:true,glow:true});
      const g=-54+108*(animated?smooth(p):.6);add([[-40,g-8],[40,g+8]],{alpha:Math.sin(Math.PI*p)*.9,width:1.3,highlight:true});}
  }
  if(style==='wingSuture'){
    // Long filaments from each instrument (on her wings) feed a needle of light
    // that whip-stitches a gently curved seam. Success pulls the seam closed.
    const stitches=4+count,cycle=animated?wrap(t*.21):.55,run=success?1:scan?scanP*.3:animated?needleRun(cycle):.55,sx=y=>Math.sin((y+42)/84*Math.PI)*6*(1-closure);
    const legacy=effect.v9MedicalCraft!==true;
    if(legacy)curve(u=>[sx(-42+u*84),-42+u*84],{alpha:.42*entry*(1-closure*.4),width:.7,steps:20});
    else{
      // V10: the open seam reads as two glowing margins the stitches draw
      // together, instead of one faint hairline.
      const open=(1-closure)*(3.2+release*4);
      for(const side of [-1,1])curve(u=>{const y=-42+u*84,lip=Math.sin(u*Math.PI);return [sx(y)+side*open*lip,y];},{alpha:.62*entry*(1-closure*.5),width:.8,glow:true,steps:20});
    }
    for(let j=0;j<stitches;j++){const y=-42+j*84/(stitches-1);
      // V10 keeps stitches from the previous pass seated (dimmer) so the seam
      // never empties at once when the needle starts its next pass.
      let on=success?1:clamp(run*stitches*1.15-j);
      if(!legacy&&!success&&!scan){const age=wrap(cycle-.84*j/(stitches-1));on=.42+.58*smooth(age/.06)*(1-smooth((age-.5)/.5));}
      if(on<=0)continue;
      const half=8*(1-(success?closure:.25)*.6)+release*6,x=sx(y);
      add([[x-half,y-5],[x+half,y+5]],{alpha:.8*on*entry*(1-release*.5),width:legacy?1.05:1.2,highlight:true,glow:legacy?j%2===0:true});
      add([[x+half,y+5],[x-half,y+10]],{plane:'rear',alpha:.3*on*entry,width:.6});
      if(release)add([[x+half,y+5],[x+half+8*release,y+14]],{alpha:.4*release,width:.6});}
    const ny=-42+clamp(run)*84,nx=sx(ny);
    for(let i=0;i<count;i++){const e=effect.emitters[i],a=[e.x*100,e.y*100],side=Math.sign(a[0]||1),b=[nx+side*4,ny],c1=[a[0]+side*30,a[1]-40],c2=[b[0]+side*40,b[1]-30];
      curve(u=>{const v=1-u;return [v*v*v*a[0]+3*v*v*u*c1[0]+3*v*u*u*c2[0]+u*u*u*b[0],v*v*v*a[1]+3*v*v*u*c1[1]+3*v*u*u*c2[1]+u*u*u*b[1]];},
        {plane:e.z>=0?'front':'rear',alpha:(legacy?.45:.55)*entry*(1-release)*(1-closure*.7),width:.75,glow:true,steps:18});}
    if(!success){
      // lifted on its glide back to the top of the seam
      const lift=animated&&!scan&&cycle>.84?1-.8*Math.sin(Math.PI*(cycle-.84)/.16):1;
      if(!legacy){const back=Math.max(-42,ny-12);add([[sx(back),back],[nx,ny]],{alpha:.7*entry*(1-release)*lift,width:1.6,highlight:true,glow:true,role:'needle'});}
      diamond(nx,ny,legacy?3:3.6,{alpha:.95*entry*(1-release)*lift,highlight:true,glow:true});
    }
    if(success)add([[0,-42],[0,42]],{alpha:closure*.85,width:1.4,highlight:true,glow:true});
  }
  if(style==='threadbind'){
    // Lacing between anchor pairs; it draws tight while worked and cinches to a
    // single seam only on a real success. Failure lets the threads go slack.
    const w=threadWidth(count),rows=4+count,slack=release;
    const tight=success?.6+.4*closure:animated?.45+.2*Math.sin(k):.5,aw=w*(1-.42*tight)+slack*8;
    const ys=Array.from({length:rows},(_,j)=>-42+j*84/(rows-1));
    for(const sd of [-1,1])for(const y of ys)diamond(sd*aw,y,1.9,{alpha:.6*entry*(1-slack),highlight:true});
    for(const sd of [-1,1])add(ys.map(y=>[sd*(aw+1.5),y]),{plane:'rear',alpha:.22*entry*(1-slack),width:.5});
    const lace=(j,sd,u)=>[sd*aw*(1-2*u),mix(ys[j],ys[j+1],u)+Math.sin(Math.PI*u)*((1-tight)*5+slack*12)];
    for(let j=0;j<rows-1;j++)for(const sd of [-1,1])curve(u=>lace(j,sd,u),{plane:'front',alpha:(sd<0?.5:.7)*entry*(1-slack*.7),width:sd<0?.7:.95,glow:j%2===0,steps:12});
    const run=scan?scanP:animated?wrap(t*.23):.4,seg=run*(rows-1),j=Math.min(rows-2,Math.floor(seg)),knot=lace(j,j%2?1:-1,seg-j);
    diamond(knot[0],knot[1],3.2,{alpha:.95*entry*(1-slack)*(scan||!animated?1:ends(run)),highlight:true,glow:true});
    if(success){add([[0,ys[0]],[0,ys.at(-1)]],{alpha:closure*.9,width:1.5,highlight:true,glow:true});for(const y of [ys[0],ys.at(-1)])diamond(0,y,3,{alpha:closure*.85,highlight:true});}
    if(slack)for(const sd of [-1,1])curve(u=>[sd*aw-sd*u*10,ys.at(-1)+u*(14+slack*10)],{alpha:(1-slack)*.4,width:.6});
  }
  // A critical result adds one restrained patient-sized crest; never particles
  // accumulated over time. Unsuccessful outcomes do not use completion art.
  if(success&&critical){const a=Math.sin(Math.PI*p)*.6;splitEllipse(0,0,66,73,{alpha:a,width:.75,highlight:true});}
  return frame;
}

export function paintRestorativeTreatment(ctx,effect,{plane='front'}={}){
  const sample=sampleRestorativeTreatment(effect);if(!sample)return false;
  paintTokenEffect(ctx,sample,{plane});return true;
}
