/** Three more warp looks, drawn on the same warp layer as Seam, Threaded and
 * Flicker. Since beta.29 her wings and bits take part in each one: the warp
 * copies her exactly as the canvas shows her (warp-capture.mjs), hides the
 * real token in the same frame, and animates the copy.
 *  - Petal:  her wing filaments loosen from the tips inward into drifting
 *            petal-threads that float along a current and re-knit her at the
 *            destination, roots first; her bits ride at the head of the stream.
 *  - Shard:  the wings lock taut and light gold along their own filaments,
 *            the lattice parts along those lines, the pieces arc across and
 *            lock back together around her bits, which arrive first.
 *  - Mirror: two bits draw a gothic pane of filament ahead of her and two
 *            more draw its twin at the destination; she folds her wings and
 *            steps into one pane and out of the other, then the panes unravel
 *            back into the bits.
 * Each draw(f, P, fx, u) gets local time u (seconds from the start). Travel
 * time grows with distance, so nothing crawls at 10 ft or streaks at 50 ft. */
import {bodyPoint,captureHer,drawHer,drawPart,drawPortrait,composite,drawComposite,filamentPoints,tinted} from './warp-capture.mjs?v=12.0.1';
import {WARP_LOOKS_V12,drawWarpLookV12} from './v12/warp-looks.mjs?v=12.0.1';

const TAU=Math.PI*2,MAG=[255,0,255],HOT=[255,214,255],GOLD=[207,174,118],GOLDHI=[240,214,160],PLUM=[58,16,62];
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const ease=t=>t*t*(3-2*t),easeOut=t=>1-(1-t)**3,easeIn=t=>t*t*t,easeInOut=t=>t<.5?4*t*t*t:1-(-2*t+2)**3/2;
const backOut=t=>{const c=1.4;return 1+(c+1)*(t-1)**3+c*(t-1)**2;};
const lerp=(a,b,t)=>a+(b-a)*t;
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${clamp(a)})`;
const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};

/** Grid squares between the two ends of a warp. */
export function warpSquares(fx){const g=globalThis.canvas?.grid?.size||fx.size||100;return Math.hypot(fx.to.x-fx.from.x,fx.to.y-fx.from.y)/g;}
/** Seconds a travelling element takes: about 0.55 s across 10 ft, 1.25 s across 50 ft. */
export function travelTime(fx){return clamp(.38+.085*warpSquares(fx),.5,1.35);}

const petalTiming=fx=>{const tr=travelTime(fx),k0=1.15+tr;return {knit:k0,duration:k0+1.0,move:k0-.3};};
const mirrorTiming=fx=>{const tb=clamp(.42+.05*warpSquares(fx),.5,1.0),w0=Math.max(.95,.2+tb+.35);return {tb,w0,duration:w0+1.45+tb+.4,move:w0+.5};};
/** Total length and the moment the owner's token moves (seconds), per warp. */
export const WARP_LOOKS=Object.freeze({
  petal:{label:'Petal',duration:3.5,move:1.85,cue:'warpPetal',timing:petalTiming},
  shard:{label:'Shard',duration:3.1,move:1.35,cue:'warpShard'},
  mirror:{label:'Mirror',duration:3.7,move:1.55,cue:'warpMirror',timing:mirrorTiming},
  // (12.0.0-beta.2) Flock, Starfall, Ribbon seam, Prism: v12/warp-looks.mjs
  ...WARP_LOOKS_V12
});

const images=new Map();
function image(src){if(!src)return null;let img=images.get(src);if(!img){img=new Image();img.decoding='async';img.src=src;images.set(src,img);}return img.complete&&img.naturalWidth?img:null;}

/* ------------------------------------------------------------- shared */
function hideToken(fx,alpha){const m=fx.token?.mesh;if(!m)return;fx.baseAlpha??=m.alpha||1;m.alpha=fx.baseAlpha*clamp(alpha);}
/** Take her copy (once) and hide the real token in the same frame. */
function handoff(fx){
  if(fx.cap===undefined){fx.cap=captureHer(fx.token,image(fx.src));}
  if(fx.cap)hideToken(fx,0);
  return fx.cap;
}
/** Once her token has really arrived, hand back to it over [a,b]. Returns
 * the copy's opacity. */
function handback(fx,u,a,b){
  const t=fx.token,c=t?.center??{x:t.x+t.w/2,y:t.y+t.h/2};
  if(Math.hypot(c.x-fx.to.x,c.y-fx.to.y)>fx.size*.5)return 1;
  // the real one comes back underneath while the copy above it fades, so the
  // frozen wing pose melts into the live one
  // (the real one leads a little, so the two never add up to a brighter or a fainter her)
  if(u<a)return 1;const k=ease(seg(u,a,b));hideToken(fx,Math.min(1,k*1.6));return 1-k;
}
function glow(f,x,y,r,a,col=MAG){if(a<=.005||r<=0)return;const g=f.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,rgba(HOT,.4*a));g.addColorStop(.35,rgba(col,.22*a));g.addColorStop(1,rgba(col,0));f.fillStyle=g;f.beginPath();f.arc(x,y,r,0,TAU);f.fill();}
/** A small four-point glint: gold core, faint halo. */
function glint(f,x,y,r,a,col=GOLDHI){if(a<=.01||r<=0)return;glow(f,x,y,r*2.6,a*.55,GOLD);f.fillStyle=rgba(col,a);f.beginPath();
  f.moveTo(x,y-r*1.7);f.lineTo(x+r*.25,y-r*.25);f.lineTo(x+r*1.7,y);f.lineTo(x+r*.25,y+r*.25);f.lineTo(x,y+r*1.7);f.lineTo(x-r*.25,y+r*.25);f.lineTo(x-r*1.7,y);f.lineTo(x-r*.25,y-r*.25);f.closePath();f.fill();}
/** Stroke the current path as a glowing filament (soft sheath, line, hot core). */
function filament(f,a,w,col=MAG){if(a<=.005)return;f.strokeStyle=rgba(col,a*.28);f.lineWidth=w*3.2;f.stroke();f.strokeStyle=rgba(col,a);f.lineWidth=w;f.stroke();
  f.strokeStyle=rgba(col===GOLD?GOLDHI:HOT,a*.65);f.lineWidth=w*.4;f.stroke();}
/** Arrival: a few filament wisps curl in and settle into her (no ring). */
export function settle(f,c,D,k,px=1,seed=0){
  if(!(k>0&&k<1))return;f.save();f.globalCompositeOperation='lighter';f.lineCap='round';
  for(let i=0;i<7;i++){const a0=i/7*TAU+hash(i+seed)*.6,e=easeOut(k),r0=D*(1.15-.55*e),sweep=.55+.25*hash(i*3+seed),a=Math.sin(Math.PI*k)*.55;
    f.beginPath();for(let s=0;s<=10;s++){const q=s/10,ang=a0+q*sweep,r=r0+D*.18*q;f.lineTo(c.x+Math.cos(ang)*r,c.y+Math.sin(ang)*r*.9);}
    filament(f,a*(.6+.4*hash(i*7)),Math.max(.8,D*.01)*px,i%3?MAG:GOLD);
    glint(f,c.x+Math.cos(a0)*r0,c.y+Math.sin(a0)*r0*.9,D*.02,a*.9);}
  f.restore();
}
/* beta.28 helpers, kept for the restored Shard and the Magenta pulse arrival */
function hideTokenOld(fx,alpha){const m=fx.token?.mesh;if(!m)return;if(!image(fx.src)&&alpha<1)alpha=Math.max(alpha,.999);fx.baseAlpha??=m.alpha||1;m.alpha=fx.baseAlpha*clamp(alpha);}
function portrait(f,fx,P){const img=image(fx.src);if(!img)return null;const m=fx.token?.mesh,k=fx.pose?.k??1;
  return {img,w:(m?.width||fx.size)*P.scale*k,h:(m?.height||fx.size)*P.scale*k,rot:(m?.rotation??0)+(fx.pose?.bank??0)};}
function drawPic(f,her,alpha=1){if(!her||alpha<=.005)return;f.save();f.globalAlpha=clamp(alpha);f.rotate(her.rot);f.drawImage(her.img,-her.w/2,-her.h/2,her.w,her.h);f.restore();}
function ring(f,c,r0,r1,k,alpha,scale){if(!(k>0&&k<1))return;const r=r0+(r1-r0)*easeOut(k),fade=(1-k)**1.6,px=Math.max(.7,scale);
  f.save();f.globalCompositeOperation='lighter';
  f.strokeStyle=rgba(MAG,.22*alpha*fade);f.lineWidth=(9*(1-k)+3)*px;f.beginPath();f.arc(c.x,c.y,r,0,TAU);f.stroke();
  f.strokeStyle=rgba(HOT,.8*alpha*fade);f.lineWidth=.9*px;f.beginPath();f.arc(c.x,c.y,r*.985,0,TAU);f.stroke();f.restore();}
function glowOld(f,x,y,r,a,col=MAG){if(a<=.005||r<=0)return;const g=f.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,rgba(HOT,.55*a));g.addColorStop(.35,rgba(col,.3*a));g.addColorStop(1,rgba(col,0));f.fillStyle=g;f.beginPath();f.arc(x,y,r,0,TAU);f.fill();}
function sparkle(f,x,y,r,a){if(a<=.01)return;glowOld(f,x,y,r*3,a*.8);f.fillStyle=rgba([255,240,255],a);f.beginPath();
  f.moveTo(x,y-r*1.7);f.lineTo(x+r*.3,y-r*.3);f.lineTo(x+r*1.7,y);f.lineTo(x+r*.3,y+r*.3);f.lineTo(x,y+r*1.7);f.lineTo(x-r*.3,y+r*.3);f.lineTo(x-r*1.7,y);f.lineTo(x-r*.3,y-r*.3);f.closePath();f.fill();}
/** Settings › Warp arrival: 'pulse' (the beta.28 expanding magenta pulse, default) or 'wisps' (beta.29). */
export function arrivalStyle(){try{return game.settings.get('filament-flight','warpArrival')==='wisps'?'wisps':'pulse';}catch{return 'pulse';}}
/** The arrival of a warp-look, in the chosen style. */
function arrival(f,c,D,{ring:rg=null,wisps=null}={},px=1,seed=0){
  if(arrivalStyle()==='wisps'){if(wisps!=null)settle(f,c,D,wisps,Math.max(.7,px),seed);}
  else if(rg)ring(f,c,rg[0],rg[1],rg[2],rg[3],px);
}
/** Her copy drawn at a screen point with an extra transform. */
function atPoint(f,p,fn){f.save();f.translate(p.x,p.y);fn();f.restore();}

/* ================================ Petal ================================ */
function petalPlan(fx,cap){
  if(fx.petals)return fx.petals;
  const s=cap.size,pts=cap.wings?filamentPoints(cap,32):filamentPoints(cap,14),maxR=Math.max(s*.6,...pts.map(p=>Math.hypot(p.x,p.y)))*1.08,{knit}=petalTiming(fx);
  const list=pts.map((p,i)=>{const r=Math.hypot(p.x,p.y),q=r/maxR;
    return {x:p.x,y:p.y,rel:.25+(1-q)*.55+hash(i*5.1)*.06,arr:knit+q*.5+hash(i*2.2)*.05,size:.19+hash(i*8.7)*.07,phase:hash(i*6.1)*TAU,spin:(hash(i*9.9)-.5)*5,
      bow:(hash(i*3.9)-.5)*2,gold:hash(i*4.4)<.3,i};});
  // her portrait loosens last and is the first thing back
  for(let i=0;i<8;i++){const a=hash(i*2.7+40)*TAU,r=Math.sqrt(hash(i*1.3+40))*s*.42;
    list.push({x:Math.cos(a)*r,y:Math.sin(a)*r,rel:.78+(1-r/(s*.42))*.22,arr:knit-.3+r/(s*.42)*.22,size:.13+hash(i*8.1)*.05,phase:hash(i*6.3)*TAU,spin:(hash(i*9.3)-.5)*5,bow:(hash(i*3.1)-.5)*2,gold:hash(i*4.9)<.25,i:i+100});}
  return fx.petals={list,maxR};
}
/** Her copy kept only inside radius R (soft edge), plus a gold band where
 * the filaments are loosening or knitting. */
function maskedHer(f,fx,cap,R,scale,alpha,band){
  const comp=composite(cap,{wings:true,portrait:true,res:Math.min(2,Math.max(1,scale))});
  const tmp=fx.tmp??=document.createElement('canvas');if(tmp.width!==comp.canvas.width||tmp.height!==comp.canvas.height){tmp.width=comp.canvas.width;tmp.height=comp.canvas.height;}
  const g=tmp.getContext('2d'),cx=-comp.x0*comp.res,cy=-comp.y0*comp.res,Rp=Math.max(0,R*comp.res),fe=cap.size*.22*comp.res;
  const mask=(inner,stops)=>{g.globalCompositeOperation='destination-in';const gr=g.createRadialGradient(cx,cy,0,cx,cy,Math.max(1,Rp+fe));for(const [o,a] of stops)gr.addColorStop(clamp(o/(Rp+fe)),`rgba(0,0,0,${a})`);g.fillStyle=gr;g.fillRect(0,0,tmp.width,tmp.height);g.globalCompositeOperation='source-over';};
  g.clearRect(0,0,tmp.width,tmp.height);g.drawImage(comp.canvas,0,0);mask(0,[[0,1],[Math.max(0,Rp-fe),1],[Rp+fe,0]]);
  f.save();f.globalAlpha=clamp(alpha);f.drawImage(tmp,comp.x0*scale,comp.y0*scale,(comp.x1-comp.x0)*scale,(comp.y1-comp.y0)*scale);f.restore();
  if(band>.01&&cap.wings){const gold=cap.goldComp??=(()=>{const c=document.createElement('canvas');c.width=comp.canvas.width;c.height=comp.canvas.height;const q=c.getContext('2d');q.drawImage(composite(cap,{wings:true,portrait:false,res:comp.res}).canvas,0,0);q.globalCompositeOperation='source-in';q.fillStyle=rgba(GOLDHI,1);q.fillRect(0,0,c.width,c.height);return c;})();
    g.clearRect(0,0,tmp.width,tmp.height);g.drawImage(gold,0,0);mask(0,[[0,0],[Math.max(0,Rp-fe*1.6),0],[Rp,1],[Rp+fe,0]]);
    f.save();f.globalCompositeOperation='lighter';f.globalAlpha=clamp(band*alpha);f.drawImage(tmp,comp.x0*scale,comp.y0*scale,(comp.x1-comp.x0)*scale,(comp.y1-comp.y0)*scale);f.restore();}
}
/** One petal-thread: a slim loop of filament that turns as it drifts. */
function petalThread(f,x,y,heading,len,open,flip,a,col,px){
  if(a<=.01)return;const w=len*.15*open*flip;
  f.save();f.translate(x,y);f.rotate(heading);f.beginPath();f.moveTo(-len/2,0);f.quadraticCurveTo(0,-w,len/2,0);f.quadraticCurveTo(0,w*.85,-len/2+len*.12*(1-open),0);
  filament(f,a,Math.max(.7,len*.06)*px,col);f.restore();
}
export function drawPetal(f,P,fx,u,reduced){
  const A=P.pt(bodyPoint(fx.from,fx.pose)),B=P.pt(bodyPoint(fx.to,fx.pose)),D=fx.size*P.scale*(fx.pose?.k??1),sc=P.scale,ang=Math.atan2(B.y-A.y,B.x-A.x),L=Math.hypot(B.x-A.x,B.y-A.y),nx=-Math.sin(ang),ny=Math.cos(ang),px=Math.max(.7,sc);
  const T=petalTiming(fx),{knit,duration}=T;
  if(u<.25){// a breath: the wings lift a touch before they loosen
    f.save();f.globalCompositeOperation='lighter';glow(f,A.x,A.y,D*1.3,.3*seg(u,0,.25));f.restore();return {split:0};}
  const cap=handoff(fx);if(!cap)return {split:0};
  const {list,maxR}=petalPlan(fx,cap);
  const loosen=seg(u,.25,1.02),Rout=maxR*(1-easeIn(loosen)*.98+0)*(1-seg(u,.85,1.05)*.02);
  const back=handback(fx,u,duration-.32,duration-.08);
  // at A: what has not loosened yet (tips go first, her portrait last)
  if(loosen<1)atPoint(f,A,()=>maskedHer(f,fx,cap,maxR*(1-ease(loosen)),sc,1,Math.sin(Math.PI*loosen)*.85));
  // at B: knitting back from the centre out, roots first, then the tips
  const knitK=seg(u,knit-.3,knit+.55);
  if(knitK>0)atPoint(f,B,()=>{if(knitK>=1)drawHer(f,cap,sc,{alpha:back,bits:0});else maskedHer(f,fx,cap,maxR*ease(knitK)*1.05,sc,back,Math.sin(Math.PI*knitK)*.8);});
  // the bits: they hold at A while the wings loosen, ride the head of the stream, and land first
  cap.bitGroups.forEach((g,i)=>{const go=.78+i*.05,land=knit-.18+i*.04,k=easeInOut(seg(u,go,land));
    const sx=A.x+g.x*sc,sy=A.y+g.y*sc,ex=B.x+g.x*sc,ey=B.y+g.y*sc,bow=Math.sin(Math.PI*k)*(i%2?1:-1)*Math.min(L*.18,D*.9);
    const x=lerp(sx,ex,k)+nx*bow,y=lerp(sy,ey,k)+ny*bow-Math.sin(Math.PI*k)*D*.25;
    if(k>0&&k<1&&!reduced){const k0=easeInOut(seg(u-.05,go,land)),b0=Math.sin(Math.PI*k0)*(i%2?1:-1)*Math.min(L*.18,D*.9);
      f.save();f.globalCompositeOperation='lighter';f.lineCap='round';f.beginPath();f.moveTo(lerp(sx,ex,k0)+nx*b0,lerp(sy,ey,k0)+ny*b0-Math.sin(Math.PI*k0)*D*.25);f.lineTo(x,y);filament(f,.45,Math.max(.8,D*.012),GOLD);f.restore();}
    f.save();f.translate(x,y);for(const p of g.parts)drawPart(f,p,sc,u<land?1:back,{dx:-g.x,dy:-g.y});f.restore();
  });
  // Magenta pulse arrival (beta.28's ring) once she is whole again; the wisps style adds nothing here, as in beta.29
  arrival(f,B,D,{ring:[D*.5,D*1.6,seg(u,knit+.2,knit+.95),.55]},sc);
  if(reduced)return {split:0};
  f.save();f.globalCompositeOperation='lighter';f.lineCap='round';f.lineJoin='round';
  // a faint current of thread the petals follow
  const stream=Math.sin(Math.PI*seg(u,.55,knit+.35));
  if(stream>.01&&L>1)for(let j=0;j<3;j++){f.beginPath();for(let s=0;s<=32;s++){const q=s/32,w=Math.sin(Math.PI*q)*(D*.35*Math.sin(q*TAU*1.5+u*2.2+j*2.1)+D*.12*(j-1)),bx=lerp(A.x,B.x,q)+nx*w,by=lerp(A.y,B.y,q)+ny*w-Math.sin(Math.PI*q)*D*.25;s?f.lineTo(bx,by):f.moveTo(bx,by);}
    filament(f,.13*stream,Math.max(.6,D*.008)*px,j===1?GOLD:MAG);}
  // the petal-threads: each loosened filament is a short strand that trails
  // its own path, a slim loop at the head and a fine tail behind it
  const posAt=(p,uu)=>{const lo=seg(uu,p.rel,p.rel+.3),tr=seg(uu,p.rel+.22,p.arr),e=easeInOut(tr);
    const sx=A.x+p.x*sc,sy=A.y+p.y*sc,r=Math.hypot(p.x,p.y)||1,ox=p.x/r,oy=p.y/r;
    const lx=sx+(ox*.08*D+Math.cos(p.phase)*.04*D)*easeOut(lo),ly=sy+(oy*.06*D-.08*D)*easeOut(lo);
    const ex=B.x+p.x*sc,ey=B.y+p.y*sc,bow=p.bow*Math.min(L*.08,D*.45)*Math.sin(Math.PI*e),sway=Math.sin(e*TAU*1.5+p.phase)*D*.07*Math.sin(Math.PI*e);
    return {x:lerp(lx,ex,e)+nx*(bow+sway),y:lerp(ly,ey,e)+ny*(bow+sway)-Math.sin(Math.PI*e)*D*.22,lo,tr};};
  const tailK=clamp(2.5/Math.max(1,warpSquares(fx)),.3,1);// keep tails about the same length at any distance
  for(const p of list){
    if(u<p.rel||u>p.arr+.18)continue;
    const h=posAt(p,u),prog=(u<p.arr?1:1-seg(u,p.arr,p.arr+.18))*Math.min(1,h.lo*4),col=p.gold?GOLD:MAG;
    // the tail: where it was over the last moment, thinning out
    const n=7,span=(.16+.1*h.tr*(1-h.tr)*4)*tailK;let prev=h;
    for(let k=1;k<=n;k++){const q=posAt(p,Math.max(p.rel,u-span*k/n)),a=.55*prog*(1-k/(n+1));
      f.beginPath();f.moveTo(prev.x,prev.y);f.lineTo(q.x,q.y);f.strokeStyle=rgba(col,a);f.lineWidth=Math.max(.6,D*.009)*px*(1-k/(n+2));f.stroke();prev=q;}
    const nx2=posAt(p,u+.02),heading=Math.atan2(nx2.y-h.y,nx2.x-h.x)||0,open=Math.min(easeOut(h.lo),1-seg(h.tr,.8,1)*.85),flip=.4+.6*Math.abs(Math.cos(p.phase+u*3.2));
    petalThread(f,h.x,h.y,heading,p.size*D*.7*(1-.35*seg(h.tr,.85,1)),open,flip,.75*prog,col,px);
  }
  f.restore();
  return {split:0};
}

/* ================================ Shard ================================ */
/** Her portrait cut into convex pieces: a jittered ring of seeds clipped as
 * Voronoi cells of the unit disk (radius .5). */
function shardPlan(fx){
  if(fx.shards)return fx.shards;
  const seeds=[[0,0]];
  for(let i=0;i<6;i++){const a=i/6*TAU+hash(i*1.7)*.5,r=.2+hash(i*2.9)*.06;seeds.push([Math.cos(a)*r,Math.sin(a)*r]);}
  for(let i=0;i<9;i++){const a=i/9*TAU+.3+hash(i*3.3)*.4,r=.4+hash(i*4.1)*.06;seeds.push([Math.cos(a)*r,Math.sin(a)*r]);}
  const disk=Array.from({length:28},(_,k)=>[Math.cos(k/28*TAU)*.5,Math.sin(k/28*TAU)*.5]);
  const clip=(poly,[sx,sy],[ox,oy])=>{
    // keep the half-plane closer to seed s than to seed o
    const mx=(sx+ox)/2,my=(sy+oy)/2,dx=ox-sx,dy=oy-sy,side=p=>(p[0]-mx)*dx+(p[1]-my)*dy;
    const out=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],sa=side(a),sb=side(b);
      if(sa<=0)out.push(a);if(sa*sb<0){const t=sa/(sa-sb);out.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]);}}return out;};
  const pieces=seeds.map((s,i)=>{let poly=disk;for(let j=0;j<seeds.length;j++)if(j!==i)poly=clip(poly,s,seeds[j]);
    const cx=poly.reduce((m,p)=>m+p[0],0)/poly.length,cy=poly.reduce((m,p)=>m+p[1],0)/poly.length;
    return {poly,cx,cy,delay:hash(i*5.3)*.32+(Math.hypot(cx,cy)>.3?0:.12),arc:.5+hash(i*7.7)*.7,spin:(hash(i*9.1)-.5)*TAU*1.4,side:hash(i*2.2)>.5?1:-1};}).filter(p=>p.poly.length>2);
  return fx.shards=pieces;
}
export function drawShard(f,P,fx,u,reduced){
  const A=P.pt(bodyPoint(fx.from,fx.pose)),B=P.pt(bodyPoint(fx.to,fx.pose)),D=fx.size*P.scale*(fx.pose?.k??1),ang=Math.atan2(B.y-A.y,B.x-A.x);
  const nx=-Math.sin(ang),ny=Math.cos(ang),her=portrait(f,fx,P),pieces=shardPlan(fx);
  // beta.30: her open wings and bits no longer vanish in one frame. At the moment
  // the pieces launch (and the real token hides) a still copy of her wings and
  // bits is taken and fades out over about 0.4 s, drawing in a little toward her; at
  // the far side the real token (wings included) fades back in as before.
  if(u>=.62&&fx.wingCopy===undefined){const cap=captureHer(fx.token,null);fx.wingCopy=cap&&(cap.wings||cap.bits.length)?cap:null;}
  hideTokenOld(fx,u<.62?1:u<2.35?0:ease(seg(u,2.35,2.6)));
  const wf=seg(u,.62,1.05);
  if(fx.wingCopy&&wf<1){const k=ease(wf),pull=g=>g.scale(1-.18*k,1-.18*k);atPoint(f,A,()=>drawHer(f,fx.wingCopy,P.scale,{alpha:1-k,portrait:0,wing:pull,bit:pull}));}
  const crack=ease(seg(u,.15,.62)),apart=easeOut(seg(u,.62,.85)),seam=1-seg(u,2.25,2.9);
  const poly=(pc)=>{f.beginPath();pc.poly.forEach(([x,y],k)=>k?f.lineTo(x*D,y*D):f.moveTo(x*D,y*D));f.closePath();};
  for(const pc of pieces){
    const launch=.82+pc.delay,fly=seg(u,launch,launch+.62+pc.arc*.18),land=seg(u,launch+.62+pc.arc*.18,launch+.82+pc.arc*.18);
    let x,y,rot=0,alpha=1,scale=1;
    if(u<launch){const spread=apart*.1;x=A.x+pc.cx*D*(1+spread*3);y=A.y+pc.cy*D*(1+spread*3);rot=apart*pc.spin*.05;}
    else if(fly<1){const e=easeInOut(fly),hgt=-Math.sin(Math.PI*e)*D*(.9+pc.arc*.9);
      x=lerp(A.x+pc.cx*D*1.3,B.x+pc.cx*D*1.25,e)+nx*Math.sin(Math.PI*e)*D*.5*pc.side;y=lerp(A.y+pc.cy*D*1.3,B.y+pc.cy*D*1.25,e)+ny*Math.sin(Math.PI*e)*D*.5*pc.side+hgt;
      rot=pc.spin*e;scale=1-.25*Math.sin(Math.PI*e);
      // a falling-star tail behind it
      if(!reduced){const e0=easeInOut(Math.max(0,fly-.12)),h0=-Math.sin(Math.PI*e0)*D*(.9+pc.arc*.9);
        const x0=lerp(A.x+pc.cx*D*1.3,B.x+pc.cx*D*1.25,e0)+nx*Math.sin(Math.PI*e0)*D*.5*pc.side,y0=lerp(A.y+pc.cy*D*1.3,B.y+pc.cy*D*1.25,e0)+ny*Math.sin(Math.PI*e0)*D*.5*pc.side+h0;
        f.save();f.globalCompositeOperation='lighter';const g=f.createLinearGradient(x0,y0,x,y);g.addColorStop(0,rgba(MAG,0));g.addColorStop(1,rgba(HOT,.85));
        f.strokeStyle=g;f.lineCap='round';f.lineWidth=Math.max(1.2,D*.035);f.beginPath();f.moveTo(x0,y0);f.lineTo(x,y);f.stroke();f.restore();}}
    else{const o=1-easeOut(land);x=B.x+pc.cx*D*(1+.25*o);y=B.y+pc.cy*D*(1+.25*o);rot=pc.spin*.06*o;}
    if(u>2.6)alpha=1-ease(seg(u,2.35,2.6));
    if(alpha<=.01)continue;
    f.save();f.translate(x,y);f.rotate(rot);f.scale(scale,scale);f.translate(-pc.cx*D,-pc.cy*D);
    poly(pc);f.save();f.clip();if(her)drawPic(f,her,alpha);else{f.fillStyle=rgba([60,30,50],alpha);f.fill();}f.restore();
    // bright facet edges: the cracks while she breaks, then the seams that heal
    const edge=u<launch?crack:fly<1?1:seam;
    if(edge>.01){f.globalCompositeOperation='lighter';f.strokeStyle=rgba(HOT,.85*edge*alpha);f.lineWidth=Math.max(.8,D*.012);poly(pc);f.stroke();
      f.strokeStyle=rgba(MAG,.35*edge*alpha);f.lineWidth=Math.max(2,D*.035);f.stroke();}
    f.restore();
  }
  f.save();f.globalCompositeOperation='lighter';
  glowOld(f,A.x,A.y,D*.9,.5*crack*(1-seg(u,.85,1.2)));
  if(u>.8&&u<.95)sparkle(f,A.x,A.y,D*.08,1-seg(u,.8,.95));
  const snap=seg(u,1.85,2.3);glowOld(f,B.x,B.y,D*(.6+.5*snap),.55*Math.sin(Math.PI*seg(u,1.7,2.6)));
  if(u>2.18&&u<2.4)sparkle(f,B.x,B.y,D*.1,1-seg(u,2.18,2.4));
  arrival(f,B,D,{ring:[D*.45,D*1.5,seg(u,2.2,2.95),.65],wisps:seg(u,2.15,2.75)},P.scale,3);
  f.restore();
  return {split:0};
}

/* ================================ Mirror ================================ */
/** A pane: a pointed-oval (vesica) window of filament held between two
 * points, with a gold mullion and inner tracery; `open` bows the sides out. */
function pane(f,a,b,open,{alpha=1,sheen=0,px=1,D=100,u=0}={}){
  if(alpha<=.01)return;const mx=(a.x+b.x)/2,my=(a.y+b.y)/2,len=Math.hypot(b.x-a.x,b.y-a.y)||1,tx=(b.x-a.x)/len,ty=(b.y-a.y)/len,nx=-ty,ny=tx,w=len*.14*open;
  const side=(s,k=1)=>{f.moveTo(a.x,a.y);f.quadraticCurveTo(mx+nx*w*2*s*k,my+ny*w*2*s*k,b.x,b.y);};
  f.save();
  if(open>.02){// faint plum glass
    f.beginPath();side(1);f.quadraticCurveTo(mx-nx*w*2,my-ny*w*2,a.x,a.y);f.closePath();
    const g=f.createLinearGradient(mx+nx*w,my+ny*w,mx-nx*w,my-ny*w);g.addColorStop(0,rgba(PLUM,.5*alpha*open));g.addColorStop(.5,rgba([96,28,104],.36*alpha*open));g.addColorStop(1,rgba(PLUM,.5*alpha*open));f.fillStyle=g;f.fill();
    if(sheen>.01){f.save();f.clip();f.globalCompositeOperation='lighter';const k=(u*.9)%1,sx=lerp(a.x,b.x,k),sy=lerp(a.y,b.y,k),s=f.createRadialGradient(sx,sy,0,sx,sy,len*.35);s.addColorStop(0,rgba(HOT,.22*sheen*alpha));s.addColorStop(1,rgba(HOT,0));f.fillStyle=s;f.fillRect(mx-len,my-len,len*2,len*2);f.restore();}}
  f.globalCompositeOperation='lighter';f.lineCap='round';
  f.beginPath();side(1);filament(f,.85*alpha,Math.max(1,D*.014)*px);
  f.beginPath();side(-1);filament(f,.85*alpha,Math.max(1,D*.014)*px);
  if(open>.05){f.beginPath();side(1,.55);side(-1,.55);filament(f,.8*alpha*open,Math.max(.8,D*.009)*px,GOLD);
    f.beginPath();f.moveTo(lerp(a.x,b.x,.12),lerp(a.y,b.y,.12));f.lineTo(lerp(a.x,b.x,.88),lerp(a.y,b.y,.88));filament(f,.4*alpha*open,Math.max(.6,D*.006)*px,GOLD);
    for(const q of [.3,.7])glint(f,lerp(a.x,b.x,q),lerp(a.y,b.y,q),D*.016,.55*alpha*open);}
  f.restore();
}
export function drawMirror(f,P,fx,u,reduced){
  const A=P.pt(bodyPoint(fx.from,fx.pose)),B=P.pt(bodyPoint(fx.to,fx.pose)),D=fx.size*P.scale*(fx.pose?.k??1),sc=P.scale,ang=Math.atan2(B.y-A.y,B.x-A.x),L=Math.hypot(B.x-A.x,B.y-A.y),ux=Math.cos(ang),uy=Math.sin(ang),nx=-uy,ny=ux,px=Math.max(.7,sc);
  const T=mirrorTiming(fx),{tb,w0}=T;
  const cap=handoff(fx);if(!cap)return {split:0};
  // the panes stand across her path, just ahead of her and just short of where she arrives
  const pa=Math.min(Math.max(D*.62,L*.3),D*.95,L*.42),half=D*.8;
  const PA={x:A.x+ux*pa,y:A.y+uy*pa},PB={x:B.x-ux*pa,y:B.y-uy*pa};
  const tipsA=[{x:PA.x-nx*half,y:PA.y-ny*half},{x:PA.x+nx*half,y:PA.y+ny*half}],tipsB=[{x:PB.x-nx*half,y:PB.y-ny*half},{x:PB.x+nx*half,y:PB.y+ny*half}];
  const openA=easeOut(seg(u,.42,.82)),openB=easeOut(seg(u,.2+tb-.05,.2+tb+.33)),close=easeInOut(seg(u,w0+.95,w0+1.25)),unravel=easeInOut(seg(u,w0+1.15,w0+1.45));
  const back=handback(fx,u,T.duration-.32,T.duration-.08);
  // she walks: d runs from 0 to 2·pa; the pane planes cut her copy
  const walk=easeInOut(seg(u,w0,w0+.95)),d=walk*pa*2;
  // the wings fold in to her back while the panes are drawn, and open again on the far side
  const fold=easeInOut(seg(u,.3,.85))*(1-easeOut(seg(u,w0+.8,w0+1.25)))+(u>w0+.8?Math.sin(Math.PI*seg(u,w0+1.0,w0+1.45))*-.05:0);
  const wingFold=(g)=>{g.rotate(ang);g.scale(1-.5*fold,1-.4*fold);g.rotate(-ang);};
  const her=(c,alpha)=>atPoint(f,c,()=>drawHer(f,cap,sc,{alpha,bits:0,wing:wingFold}));
  const cut=(c,keepAhead)=>{f.beginPath();const big=D*8;f.save();f.translate(c.x,c.y);f.rotate(ang);f.rect(keepAhead?0:-big,-big,big,big*2);f.restore();f.clip();};
  if(u<w0)her(A,1);
  else if(u<w0+.95-.001||d<pa*2-.5){
    f.save();cut(PA,false);her({x:A.x+ux*d,y:A.y+uy*d},1);f.restore();
    if(d>pa-D*1.6){f.save();cut(PB,true);her({x:PB.x+ux*(d-pa),y:PB.y+uy*(d-pa)},1);f.restore();}
  }else her(B,back);
  // the panes, drawn over the cut so she passes through the glass
  const crossing=Math.sin(Math.PI*seg(d,pa-D*.5,pa+D*.5));
  // closing: the panes straighten back into a thread, which then draws back into the two bits
  const retract=(tips)=>{f.save();f.globalCompositeOperation='lighter';f.lineCap='round';const m={x:(tips[0].x+tips[1].x)/2,y:(tips[0].y+tips[1].y)/2};
    for(const t of tips){const e={x:lerp(m.x,t.x,unravel),y:lerp(m.y,t.y,unravel)};f.beginPath();f.moveTo(t.x,t.y);f.lineTo(e.x,e.y);filament(f,.85*(1-unravel*.5),Math.max(1,D*.014)*px);}f.restore();};
  if(unravel<=0){pane(f,tipsA[0],tipsA[1],openA*(1-close),{alpha:seg(u,.3,.5),sheen:crossing,px,D,u});
    pane(f,tipsB[0],tipsB[1],openB*(1-close),{alpha:seg(u,.2+tb-.15,.2+tb+.05),sheen:crossing,px,D,u});}
  else if(unravel<1){retract(tipsA);retract(tipsB);}
  // the bits: two draw each pane, then come home to her stations at the far side
  const groups=cap.bitGroups,targets=[tipsA[0],tipsA[1],tipsB[0],tipsB[1]];
  groups.forEach((g,i)=>{const toB=i>=2,go=toB?.15+(i-2)*.05:.05+i*.05,arrive=toB?.2+tb:.45+i*.04,home0=w0+(toB?1.5:1.42),home1=home0+(toB?.45:tb+.1);
    const st={x:A.x+g.x*sc,y:A.y+g.y*sc},hm={x:B.x+g.x*sc,y:B.y+g.y*sc},tip=i<4?(i%2?(toB?tipsB:tipsA)[1]:(toB?tipsB:tipsA)[0]):st;
    let x=st.x,y=st.y;const k=easeInOut(seg(u,go,arrive)),h=easeInOut(seg(u,home0,home1));
    if(u<home0){x=lerp(st.x,tip.x,k);y=lerp(st.y,tip.y,k)-Math.sin(Math.PI*k)*D*.3;}
    else{x=lerp(tip.x,hm.x,h);y=lerp(tip.y,hm.y,h)-Math.sin(Math.PI*h)*D*.3;}
    if(!reduced&&((k>0&&k<1)||(h>0&&h<1))){const kk=u<home0?k:h,from=u<home0?st:tip,to=u<home0?tip:hm,k0=Math.max(0,kk-.1);f.save();f.globalCompositeOperation='lighter';f.lineCap='round';f.beginPath();
      f.moveTo(lerp(from.x,to.x,k0),lerp(from.y,to.y,k0)-Math.sin(Math.PI*k0)*D*.3);f.lineTo(x,y);filament(f,.45,Math.max(.8,D*.011),GOLD);f.restore();}
    f.save();f.translate(x,y);for(const p of g.parts)drawPart(f,p,sc,u>=home1?back:1,{dx:-g.x,dy:-g.y});f.restore();
  });
  arrival(f,B,D,{ring:[D*.4,D*1.2,seg(u,w0+1.0,w0+1.7),.45],wisps:u>w0+1.0?seg(u,w0+1.05,w0+1.55):null},sc,7);
  return {split:0};
}

export function drawWarpLook(look,f,P,fx,u,reduced){
  if(WARP_LOOKS_V12[look])return drawWarpLookV12(look,f,P,fx,u,reduced);
  return look==='petal'?drawPetal(f,P,fx,u,reduced):look==='shard'?drawShard(f,P,fx,u,reduced):drawMirror(f,P,fx,u,reduced);
}
