/** Physical status accents on the original posed filament wing. These paths
 * carry light, bindings, repair stitches and local sparks; they never replace
 * the body, move a rib, change an outline, or alter flight/game rules.
 */
import {ribPoint,createOriginalStatusBuilder} from './status-filament-geometry.mjs?v=12.0.1';

export const PHYSICAL_ORIGINAL_EFFECT_IDS=Object.freeze(['paralyzed','petrified','restrained','immobilized','grabbed','enfeebled',
  'drained','encumbered','clumsy','slowed','quickened','fleeing','frightened','wounded','fatigued','prone']);
const unit=n=>Math.max(0,Math.min(1,Number(n)||0));
const finite=n=>Number.isFinite(n)?n:0;
const wave=(t,rate=1,offset=0)=>.5-.5*Math.cos(t*rate+offset);
const mix=(a,b,t)=>a+(b-a)*t;

export function originalPhysicalStatusAccents(side,visual,warp,ribs,growth=1){
  const m=visual?.statusFilamentEffects;
  if(!m?.active||growth<=0||typeof warp!=='function'||!ribs?.length)return [];
  // The shared sampler owns held and reduced-motion clocks. Reusing its
  // settled value avoids a flash back to frame zero when another status arrests
  // the wing; no independent wall clock or animation timer exists here.
  const t=finite(m.time);
  const groups=[],source=(rib,u)=>ribPoint(ribs,rib,unit(u));
  for(const id of PHYSICAL_ORIGINAL_EFFECT_IDS){
    const a=unit(m.strengths?.[id]);if(a<=.001)continue;
    const builder=createOriginalStatusBuilder(id,side,visual,warp,ribs,growth),out=builder.paths;
    const severity=Math.max(1,Math.min(4,Number(m.severities?.[id])||1));
    const path=(name,points,width=1.1,strength=.8,extra={})=>{
      builder.add(name,points,width,a*strength,{statusFilamentAccent:true,statusOriginalEffect:id,statusId:id,...extra});
    };
    const rail=(name,rib,lo,hi,width=1.25,strength=.82,offset=0,extra={})=>{
      path(name,Array.from({length:25},(_,i)=>{
        const u=mix(lo,hi,i/24),p=source(rib,u);p[0]+=offset*Math.sin(Math.PI*i/24);return p;
      }),width,strength,extra);
    };
    const bridge=(name,from,to,u,v=u,drop=0,width=1.1,strength=.8,extra={})=>{
      const p=source(from,u),q=source(to,v);
      path(name,Array.from({length:25},(_,i)=>{const f=i/24;return [mix(p[0],q[0],f),mix(p[1],q[1],f)+drop*Math.sin(Math.PI*f),mix(u,v,f)];}),width,strength,extra);
    };
    const angular=(name,rib,u,dx,dy,width=1.1,strength=.82,extra={})=>{
      const p=source(rib,u);
      path(name,[[p[0]-dx,p[1]-dy,u],[p[0]+dx*.55,p[1]-dy*.7,u],[p[0]+dx,p[1]+dy*.3,u],
        [p[0]+dx*.15,p[1]+dy,u],[p[0]-dx*.8,p[1]+dy*.25,u]],width,strength,extra);
    };
    switch(id){
      case 'paralyzed': {
        // A held wing can still crackle locally. Stunned 3/petrification freeze
        // this clock through the shared sampler; no rib is shaken or displaced.
        const prime=m.settleProgress==null?0:1-unit(m.settleProgress);
        for(let k=0;k<4;k++){
          const rib=[1,3,6,8][k],u=.42+k*.08+.012*Math.sin(t*2.8+k),p=source(rib,u),pulse=wave(t,4.2,-k*1.1);
          const dx=5+5*pulse,dy=8+5*wave(t,3.1,k*.7),points=[];
          for(let n=0;n<7;n++){
            const q=n/6;points.push([p[0]+(q-.5)*dx*2+(n%2?3:-2)*wave(t,4.2,k+.3),p[1]+(q-.5)*dy*2,u]);
          }
          path(`crackle-${k}`,points,1.45+.3*prime,.68+.4*pulse,{highlight:1,localSpark:true});
          if(k<2)path(`spark-fork-${k}`,[[p[0],p[1],u],[p[0]+5,p[1]-4,u],[p[0]+11+4*pulse,p[1]-3-dy*.55,u]],.95,.52+.3*pulse,{highlight:.75,localSpark:true});
        }break;
      }
      case 'petrified':
        for(let k=0;k<6;k++)angular(`facet-lock-${k}`,[0,2,4,5,7,9][k],.47+k*.045,10+k%2*4,14+k%3*3,1.05,.67,{highlight:.16});
        bridge('rigid-seam-upper',0,3,.76,.7,0,1.45,.8);
        bridge('rigid-seam-lower',6,9,.75,.77,0,1.35,.75);break;
      case 'restrained':
        for(let k=0;k<4;k++){
          const u=.37+k*.14,cinch=wave(t,1.15,-k*.65);
          bridge(`binding-band-${k}`,0,9,u,u,-12+7*cinch,1.65,.72+.16*cinch,{material:'ribbon'});
        }
        bridge('crossed-bind-a',1,8,.75,.45,12,1.4,.82);
        bridge('crossed-bind-b',1,8,.45,.75,-12,1.4,.82);break;
      case 'immobilized':
        for(let k=0;k<4;k++)bridge(`root-cuff-${k}`,k*2,Math.min(9,k*2+3),.19+k*.028,.19+k*.028,-9-2*wave(t,.8,k),1.45,.8,{material:'ribbon'});
        rail('bound-root-current-a',2,.08,.33,1.15,.48+.24*wave(t,.8),3);
        rail('bound-root-current-b',7,.08,.36,1.15,.48+.24*wave(t,.8,2),-3);break;
      case 'grabbed':
        for(let k=0;k<2;k++){
          const rib=k?7:2,pulse=wave(t,1.2,-k*1.2),u=.78+.035*pulse;
          angular(`tether-catch-${k}`,rib,u,12,14,1.35,.82);
          bridge(`taut-tether-${k}`,rib,k?4:6,u,.47,9+3*pulse,1.55,.84,{material:'ribbon'});
          rail(`elastic-return-${k}`,rib,.48,.86,1.1,.48+.18*pulse,k?5:-5);
        }break;
      case 'enfeebled':
        for(let k=0;k<3;k++){
          const yieldAmount=wave(t,.8,-k*.65);
          bridge(`yielding-support-${k}`,3+k,7+k,.66,.69,16+9*yieldAmount,1.25,.7-.12*yieldAmount);
          rail(`failing-spar-${k}`,5+k*2,.27,.88,1.2,.35+.35*wave(t,.8,-k*1.3),-3);
        }break;
      case 'drained':
        for(let k=0;k<4;k++){
          const head=.27+.62*wave(t,.46,k*1.4),strength=.78-k*.08;
          rail(`ebb-channel-${k}`,1+k*2,.12,head,1.65-k*.15,strength,3-k,{material:k===0?'ribbon':undefined});
        }
        bridge('fading-reservoir-a',4,7,.71,.72,11,1.05,.32+.19*wave(t,.46));
        bridge('fading-reservoir-b',6,9,.79,.77,13,1.05,.3+.19*wave(t,.46,1.5));break;
      case 'encumbered':
        for(let k=0;k<3;k++){
          const sway=3*Math.sin(t*.62+k*.25),rib=5+k*2,u=.75;
          bridge(`load-bearing-stay-${k}`,k,rib,.34,u,14,1.65,.84,{material:'ribbon'});
          const p=source(rib,u);
          path(`laden-brace-${k}`,[[p[0]-13+sway,p[1]-10,u],[p[0]+13+sway,p[1]-10,u],
            [p[0]+8+sway,p[1]+20,u],[p[0]-7+sway,p[1]+20,u],[p[0]-13+sway,p[1]-10,u]],1.35,.7);
        }
        bridge('shared-load-support',4,9,.57,.74,23+2*wave(t,.62),1.15,.66);break;
      case 'clumsy':
        for(let k=0;k<3;k++){
          const correction=Math.sin(t*1.35-k*1.3+(side<0?.7:0)),rib=1+k*3;
          rail(`misaligned-run-${k}`,rib,.43,.82,1.35,.74,8*correction);
          bridge(`corrective-seam-${k}`,rib,Math.min(9,rib+2),.61+.025*correction,.69,-6*correction,1.05,.66);
        }break;
      case 'slowed':
        for(let k=0;k<3;k++){
          const heldRelease=wave(t,.46,-k*.72),head=.32+.52*heldRelease,rib=1+k*3;
          rail(`weighted-lag-${k}`,rib,.14,head,1.65,.58,5+k*2,{material:'ribbon'});
          rail(`held-release-block-${k}`,rib,Math.max(.14,head-.1),head,2.15,.61+.28*heldRelease,-3);
        }
        bridge('slow-catch-band',0,9,.64,.65,8,1,.4+.15*wave(t,.46,1.1));break;
      case 'quickened':
        for(let k=0;k<3;k++){
          const rib=1+k*3,head=.25+.64*wave(t,3.4,-k*.66),returnHead=.25+.64*wave(t,3.4,-k*.66+Math.PI);
          rail(`double-charge-out-${k}`,rib,Math.max(.13,head-.18),head,1.8,.95,4,{material:'ribbon',highlight:.18});
          rail(`double-charge-return-${k}`,rib,Math.max(.13,returnHead-.16),returnHead,1.4,.68,-5);
          if(k<2){const ghost=.25+.64*wave(t-.11,3.4,-k*.66);rail(`short-afterimage-${k}`,rib,Math.max(.13,ghost-.22),ghost,1.1,.33,6);}
        }break;
      case 'fleeing':
        for(let k=0;k<3;k++){
          const rib=1+k*3,head=.27+.65*wave(t,2.35,-k*.53);
          rail(`retreating-current-${k}`,rib,Math.max(.14,head-.35),head,1.7,.8,4,{material:'ribbon'});
          rail(`windward-return-${k}`,rib,.25,.92,1.08,.3+.15*wave(t,2.35,-k*.53),-4);
        }break;
      case 'frightened':
        for(let k=0;k<3;k++)rail(`nervous-seam-${k}`,1+k*3,.38,.88,1.3,.58+.17*wave(t,7.2,k),5*Math.sin(t*7.2+k));
        bridge('protective-guard-upper',1,7,.7,.62,-14,1.6,.72+.13*wave(t,2.35),{material:'ribbon'});
        bridge('protective-guard-lower',3,8,.78,.74,13,1.45,.68+.12*wave(t,2.35,.8));break;
      case 'wounded':
        for(let k=0;k<3;k++){
          const from=1+k*3,to=Math.min(9,from+2),u=.53+k*.08,p=source(from,u),q=source(to,u+.03),tension=2+2*wave(t,.8,-k*.8);
          path(`repair-sutures-${k}`,Array.from({length:19},(_,n)=>{
            const f=n/18,zig=n===0||n===18?0:(n%2?1:-1)*(4+tension);
            return [mix(p[0],q[0],f)+zig*.35,mix(p[1],q[1],f)+zig,mix(u,u+.03,f)];
          }),1.15,.68+severity*.035,{highlight:.13});
          rail(`repair-tension-${k}`,from,.36,.8,1.28,.46+.2*wave(t,.8,-k*.8),2);
        }
        bridge('patch-support',2,8,.67,.68,7,1.5,.62,{material:'ribbon'});break;
      case 'fatigued':
        bridge('tired-support-upper',3,6,.65,.66,12+2*wave(t,.62),1.4,.64,{material:'ribbon'});
        bridge('tired-support-lower',6,9,.75,.75,15+2*wave(t,.62,.7),1.4,.61,{material:'ribbon'});
        for(let k=0;k<3;k++)rail(`shallow-recovery-${k}`,3+k*2,.43,.81,1.13,.34+.12*wave(t,.62,-k*.4),2);break;
      case 'prone':
        for(let k=0;k<3;k++)bridge(`quiet-rest-drape-${k}`,4+k,7+k,.68+k*.035,.72+k*.03,14+2*wave(t,.62,-k*.3),1.15,.53);
        rail('resting-channel-a',5,.34,.85,1.22,.3+.1*wave(t,.62),2);
        rail('resting-channel-b',8,.35,.86,1.22,.3+.1*wave(t,.62,.4),-2);break;
    }
    if(out.length)groups.push(out);
  }
  // Fair round-robin selection keeps later simultaneous statuses visible.
  // Independent single-condition views still receive their full authored art.
  const result=[];
  for(let n=0;n<8&&result.length<80;n++)for(const group of groups){if(group[n])result.push(group[n]);if(result.length>=80)break;}
  return result;
}
