/** Status energy patterns on the canonical filament wings. These paths never
 * replace ribs, change the wing outline or change an actor's rules or lights.
 * The production rig owns posing, depth splitting and HP/Reform material cuts.
 */
import {ribPoint} from './status-filament-geometry.mjs?v=12.0.1';
import {growthPaths} from './flight-dynamics.mjs?v=12.0.1';

export const ARCANE_ORIGINAL_EFFECT_IDS=Object.freeze(['controlled','cursebound','malevolence','doomed','dying','dead','persistent-damage','glitching','suppressed','untethered']);
const finite=(n,f=0)=>Number.isFinite(n)?n:f,unit=n=>Math.max(0,Math.min(1,finite(n))),TAU=Math.PI*2;
const mix=(a,b,t)=>a+(b-a)*t,cycle=(t,rate,phase=0)=>.5-.5*Math.cos(t*rate+phase);
const TYPES=new Set(['acid','bleed','bludgeoning','cold','electricity','fire','force','mental','piercing','poison','slashing','sonic','spirit','vitality','void','radiation']);
const aliases={electric:'electricity',lightning:'electricity',negative:'void',positive:'vitality'};
const samples=(n,f)=>Array.from({length:Math.min(32,n)},(_,i)=>f(i/(Math.min(32,n)-1),i));
function canonicalTypes(raw){
  const result=[];
  for(const value of Array.isArray(raw)?raw:[]){
    const rawType=typeof value==='string'?value:value?.type??value?.damageType;
    if(typeof rawType!=='string')continue;
    const key=rawType.toLowerCase(),type=aliases[key]??key;
    if(TYPES.has(type)&&!result.includes(type))result.push(type);
    if(result.length===3)break;
  }
  return result.length?result:['untyped'];
}

export function originalArcaneStatusAccents(side,visual,warp,ribs,growth=1){
  const m=visual?.statusFilamentEffects;
  if(!m?.active||growth<=0||typeof warp!=='function'||!Array.isArray(ribs)||!ribs.length)return [];
  const out=[],t=finite(m.time),motion=Math.max(0,Math.min(2,finite(m.motion,1)));
  const at=(rib,u)=>ribPoint(ribs,rib,unit(u));
  const trace=(rib,lo,hi,offset=0,roll=0)=>samples(25,q=>{
    const u=mix(lo,hi,q),p=at(rib,u),envelope=Math.sin(Math.PI*q)*Math.sin(Math.PI*u);
    p[0]+=offset*envelope*motion;p[1]+=roll*envelope*motion;return p;
  });
  const bridge=(from,to,u,drop=0,bend=0)=>{
    const a=at(from,u),b=at(to,Math.min(.98,u+.035));
    return samples(27,q=>{
      const w=Math.sin(Math.PI*q);
      return [mix(a[0],b[0],q)+bend*w*motion,mix(a[1],b[1],q)+drop*w*motion,mix(a[2],b[2],q)];
    });
  };
  const path=(id,role,source,strength,width=1,highlight=false)=>{
    if(out.length>=80||strength<=.008)return;
    if(source.some(p=>!p.every(Number.isFinite)))return;
    // Include the exact growth boundary rather than popping one sampled
    // vertex at a time as a summoned filament expands.
    for(const clipped of growthPaths(source,growth)){
      if(clipped.length<2||out.length>=80)continue;
      const points=clipped.map(p=>{
        const posed=warp(p);return posed.length>3?posed:[...posed,p[2]];
      });
      if(points.some(p=>!p.every(Number.isFinite)))continue;
      out.push({id:`actor-${id}-original-${role}`,statusId:id,source:clipped,points,width:Math.max(.3,Math.min(2.6,width)),
        strength:Math.max(0,Math.min(1.35,strength)),highlight:highlight?1:0,conditionAccent:true,statusAccent:true,
        statusFilamentAccent:true,material:'status-fx'});
    }
  };
  const packet=(id,role,rib,head,length,strength,width=1.7,offset=0,roll=0)=>
    path(id,role,trace(rib,Math.max(.08,head-length),head,offset,roll),strength,width,true);
  const value=id=>unit(m.strengths?.[id]);
  const severity=id=>Math.max(1,Math.min(4,finite(m.severities?.[id],1)));
  for(const id of ARCANE_ORIGINAL_EFFECT_IDS){
    const a=value(id);if(a<=.001)continue;
    const before=out.length;
    switch(id){
      case 'controlled':{
        const head=.24+.65*cycle(t,.93),gain=.5+.45*cycle(t,.93,.35);
        for(const [k,rib] of [0,3,6,9].entries()){
          // Identical clocks enforce a conspicuously unnatural synchronized
          // command cadence on four existing spars, without new puppet limbs.
          path(id,`command-rail-${k}`,trace(rib,0,.94),a*.38,1.12);
          packet(id,`command-charge-${k}`,rib,head,.18,a*gain,1.95);
        }break;
      }
      case 'cursebound':{
        const cinch=1+.17*(severity(id)-1),tighten=.5+.5*Math.sin(t*.47);
        for(let k=0;k<3;k++){
          const u=.38+k*.17,A=at(k,.9*u),B=at(6+k,u+.025),dx=B[0]-A[0],dy=B[1]-A[1],len=Math.hypot(dx,dy)||1;
          for(let turn=0;turn<2;turn++){
            const sign=turn===0?1:-1;
            const tatting=samples(32,q=>{
              const w=Math.sin(Math.PI*q),weft=sign*Math.sin(q*TAU*2)*(10+7*tighten)*w*motion,
                knot=Math.sin(q*TAU*4+sign*.3)*6*w*motion;
              return [mix(A[0],B[0],q)-dy/len*weft+dx/len*knot,mix(A[1],B[1],q)+dx/len*weft+dy/len*knot,mix(A[2],B[2],q)];
            });
            path(id,`ritual-tatting-${k}-${turn}`,tatting,a*Math.min(1.1,.72*cinch),turn===0?1.42:.79,turn===0);
          }
        }break;
      }
      case 'malevolence':
        for(let k=0;k<4;k++){
          const head=.23+.62*cycle(t,.61,k*.65+side*.18),reverse=.23+.62*(1-cycle(t,.61,k*.65+side*.18));
          packet(id,`intrusion-${k}`,1+k*2,head,.21,a*.82,1.7,5*Math.sin(t*.41+k),5);
          packet(id,`counterflow-${k}`,Math.min(9,2+k*2),reverse,.18,a*.62,1.17,-5*Math.sin(t*.41+k),-4);
        }break;
      case 'doomed':{
        const loss=1+.3*(severity(id)-1);
        for(let k=0;k<4;k++){
          const rib=[0,3,6,9][k],phase=t*.49+k*.53,head=.18+.67*(.5+.5*Math.cos(phase)),unthread=.12+.88*Math.max(0,Math.sin(phase));
          path(id,`faint-return-${k}`,trace(rib,.09,.84),a*.19/loss,.56);
          packet(id,`unthread-${k}`,rib,head,.24,a*(.28+.58*unthread)/Math.sqrt(loss),1.35);
        }break;
      }
      case 'dying':{
        const failure=1+.4*(severity(id)-1);
        for(let k=0;k<4;k++){
          const rib=[1,3,6,8][k],head=.16+.31*cycle(t,.37,k*.81),relay=.045+.91*Math.pow(Math.max(0,Math.sin(t*.89-k*1.17)),7);
          path(id,`failing-root-link-${k}`,trace(rib,.08,.46),a*.14/failure,.68);
          packet(id,`last-relay-${k}`,rib,head,.075,a*relay/failure,1.5);
        }break;
      }
      case 'dead':
        for(let k=0;k<4;k++){
          const rib=[0,3,6,9][k];
          path(id,`extinguished-link-${k}`,trace(rib,.08,.24),a*.075,.51);
          path(id,`still-ember-${k}`,trace(rib,.115,.145),a*.17,.82,true);
        }break;
      case 'glitching':
        for(let k=0;k<4;k++){
          const rib=[1,3,6,8][k],u=.31+k*.105,head=.27+.56*cycle(t,.79,k*.91),gain=.13+.85*cycle(t,1.43,k*1.13);
          const relay=trace(rib,u-.055,u+.065);
          for(let j=1;j<relay.length-1;j++){
            const w=Math.sin(Math.PI*j/(relay.length-1));relay[j][0]+=(j%2?2.7:-2.7)*w*motion;
          }
          path(id,`diagnostic-relay-${k}`,relay,a*gain,1.35,true);
          packet(id,`signal-packet-${k}`,rib,head,.13,a*(.38+.45*cycle(t,1.43,k*1.13)),1.64);
        }break;
      case 'suppressed':
        for(let k=0;k<4;k++){
          const phase=t*.63-k*.7,u=.29+.5*(.5+.5*Math.cos(phase)),shield=.27+.67*Math.pow(Math.max(0,Math.sin(phase)),2);
          path(id,`recoil-shield-wave-${k}`,bridge(0,9,u,-14+3*k,7*Math.sin(t*.43+k)),a*shield,1.65,true);
          path(id,`shield-feed-${k}`,trace([1,3,6,8][k],.09,u),a*.28,1.05);
        }break;
      case 'untethered':
        for(let k=0;k<4;k++){
          const rib=[0,3,6,9][k],head=.4+.43*cycle(t,.23,k*1.4+side*.24),drift=Math.sin(t*.19+k*1.7+side*.6);
          path(id,`weightless-current-${k}`,trace(rib,.14,.91,drift*4,Math.cos(t*.21+k)*4),a*.46,.89);
          packet(id,`drift-charge-${k}`,rib,head,.2,a*(.45+.31*cycle(t,.19,k*.91)),1.31,drift*3,-drift*2);
        }break;
      case 'persistent-damage':{
        const types=canonicalTypes(m.damageTypes),count=types.length===3?6:8;
        for(let k=0;k<count;k++){
          const type=types[k%types.length],rib=[1,3,5,8][Math.floor(k/2)%4],u=.41+.09*(k%3),role=`${type}-${k}`,
            head=.24+.6*cycle(t,.49,k*.61),gain=a*(.55+.31*cycle(t,.73,k*.59));
          const channel=trace(rib,.22,.89),A=at(rib,u),B=at(Math.min(9,rib+2),u+.13);
          if(type==='fire'){
            const heat=samples(30,q=>{
              const z=mix(.27,.93,q),p=at(rib,z),w=Math.sin(Math.PI*q)*Math.sin(Math.PI*z);
              p[0]+=7*Math.sin(q*TAU*1.3+t*.69+k)*w*motion;
              p[1]-=(13+7*Math.sin(q*TAU-t*.59+k))*w*motion;return p;
            });
            path(id,role,heat,gain,1.9,true);
          }else if(type==='cold'){
            const rime=samples(27,(q,j)=>{
              const w=Math.sin(Math.PI*q),fracture=(j%2?6:-6)*w;
              return [mix(A[0],B[0],q)+fracture,mix(A[1],B[1],q)+fracture*.7+2*w*Math.sin(t*.27+k),mix(A[2],B[2],q)];
            });
            path(id,role,rime,gain,1.48,true);
          }else if(type==='electricity'){
            const arc=samples(28,(q,j)=>{
              const jump=(j%2?1:-1)*(5+2*Math.sin(t*1.11+k))*Math.sin(Math.PI*q)*motion;
              return [mix(A[0],B[0],q)+jump,mix(A[1],B[1],q)+jump*.65,mix(A[2],B[2],q)];
            });
            path(id,role,arc,a*(.12+.87*cycle(t,1.41,k*.73)),1.9,true);
          }else if(type==='acid'){
            const etch=bridge(rib,Math.min(9,rib+2),u,22+8*Math.sin(t*.41+k),-4);
            for(let j=0;j<etch.length;j++)etch[j][0]+=Math.sin(j/(etch.length-1)*TAU*2+t*.37+k)*2*motion;
            path(id,role,etch,gain,1.65,true);
          }else if(type==='bleed'){
            const drain=trace(rib,.22,head,2,5);
            path(id,role,drain,gain,1.7,true);
          }else if(type==='poison'){
            for(let j=0;j<channel.length;j++){
              const q=j/(channel.length-1),w=Math.sin(Math.PI*q);
              channel[j][0]+=8*Math.sin(q*TAU*1.5+t*.43+k)*w*motion;channel[j][1]+=4*Math.sin(q*TAU-t*.37+k)*w*motion;
            }path(id,role,channel,gain,1.64,true);
          }else if(type==='mental'){
            const struggle=bridge(rib,Math.min(9,rib+2),u,9*Math.sin(t*.47+k),0);
            for(let j=0;j<struggle.length;j++)struggle[j][0]+=Math.sin(j/(struggle.length-1)*TAU*2+t*.43+k)*8*Math.sin(Math.PI*j/(struggle.length-1))*motion;
            path(id,role,struggle,gain,1.55,true);
          }else if(type==='spirit'){
            path(id,role,trace(rib,.25,.85,5*Math.sin(t*.37+k),9*Math.sin(t*.31+k)),gain,1.27,true);
          }else if(type==='sonic'){
            const sound=bridge(rib,Math.min(9,rib+2),u,0,0);
            for(let j=0;j<sound.length;j++)sound[j][1]+=Math.sin(j/(sound.length-1)*TAU*2-t*.91+k)*9*Math.sin(Math.PI*j/(sound.length-1))*motion;
            path(id,role,sound,gain,1.52,true);
          }else if(type==='void'){
            packet(id,role,rib,.22+.58*(1-cycle(t,.43,k*.67)),.23,a*.52,1.05,-2,2);
          }else if(type==='vitality'){
            packet(id,role,rib,head,.3,gain,2.15,4,-3);
          }else if(type==='radiation'){
            path(id,role,bridge(rib,Math.min(9,rib+2),u,6*Math.cos(t*.37+k),10*Math.sin(t*.41+k)),a*(.19+.79*cycle(t,.79,k*.83)),1.65,true);
          }else if(type==='force'){
            const tension=Math.sin(t*.43+k)*2*motion;
            const midpoint=[mix(A[0],B[0],.48)+4+tension,mix(A[1],B[1],.48)-7-tension*.5,mix(A[2],B[2],.48)];
            path(id,role,[A,[midpoint[0]-3,midpoint[1]+3,midpoint[2]],midpoint,[midpoint[0]+5,midpoint[1]+5,midpoint[2]],B],gain,1.8,true);
          }else if(type==='piercing'){
            const p=at(rib,u+.13),q=at(rib,u-.05);
            const flex=Math.sin(t*.39+k)*1.6*motion;
            path(id,role,[q,[mix(q[0],p[0],.5)+5+flex,mix(q[1],p[1],.5)-8-flex*.5,u+.04],p],gain,1.73,true);
          }else if(type==='slashing'){
            path(id,role,bridge(rib,Math.min(9,rib+3),u,-4+2*Math.sin(t*.37+k),-7),gain,1.92,true);
          }else if(type==='bludgeoning'){
            path(id,role,bridge(rib,Math.min(9,rib+2),u,16+4*Math.sin(t*.39+k),-6),gain,1.93,true);
          }else{
            path(id,role,trace(rib,.31,.85,4*Math.sin(t*.37+k),3*Math.sin(t*.43+k)),gain,1.35,true);
          }
        }break;
      }
    }
    if(out.length-before>8)out.splice(before+8,out.length-before-8);
  }
  return out;
}
