import {CONDITION_EFFECTS,REACTION_EFFECTS,DEFAULT_CONDITION_ART} from './effect-catalog.mjs?v=13.0.4';
import {TREATMENT_AUDIO_STAGES,TREATMENT_SOUND_DESIGNS,V7_MEDKIT_AUDIO_STYLES,treatmentAudioSlot} from './treatment-audio.mjs?v=13.0.4';
import {STRUCTURES} from './energy-structures.mjs?v=13.0.4';
import {BIT_GESTURES} from './bit-behaviour.mjs?v=13.0.4';
/** Pure, versioned sound preferences. Kept in a separate token flag so legacy
 * flight.off()/toggle() can keep clearing the original flight flag unchanged. */
export const AUDIO_VERSION=1;
export const AUDIO_CATEGORIES=Object.freeze({
  idle:{label:'Stationary hum',volume:0.24},
  movement:{label:'Movement and banking',volume:0.4},
  transitions:{label:'Takeoff and landing',volume:0.55},
  poses:{label:'Wing poses',volume:0.45},
  gems:{label:'Control gems',volume:0.25},
  conditions:{label:'Wing conditions',volume:0.3},
  reactions:{label:'Damage, healing and actions',volume:0.6},
  instruments:{label:'Bit deployment and formations',volume:0.35},
  structures:{label:'Energy structures',volume:0.35},
  treatments:{label:'Medkit hardlight treatment',volume:0.5},
  routines:{label:'Warps and routines',volume:0.5},
  flight:{label:'Flight: lift, settle, stops and wing pulses',volume:0.45}
});
const slot=(id,label,category,file,loop=false,description='',modern=false)=>[id,Object.freeze({id,label,category,file,loop,description,modern})];
const modern=(id,label,category,file,loop=false,description='')=>slot(id,label,category,file,loop,description,true);
export const MEDKIT_AUDIO_STYLES=Object.freeze(['suture','lattice','compression','precision','microloom','vascular','helix','splint','membrane','resonance','pulseHalo','mendingVeil','renewalSpiral','heartline','threadbind','crystalCast','wingSuture',...V7_MEDKIT_AUDIO_STYLES]);
const medical=(id,label,style,file,loop=false)=>{const [key,spec]=modern(id,label,'treatments',file,loop,TREATMENT_SOUND_DESIGNS[style]);return [key,V7_MEDKIT_AUDIO_STYLES.includes(style)?Object.freeze({...spec,directory:'v7-medkit'}):spec];};
// Flight feel (beta.23, redone in beta.24 in the voice of the 9.1 hum):
// wing pulses, ignition, settle, falling, unfurl, brace, shield, shatter and
// stops. Stored in assets/audio/flight.
const flightSlot=(id,label,file,description)=>{const [key,spec]=modern(id,label,'flight',file,false,description);return [key,Object.freeze({...spec,directory:'flight'})];};
export const AUDIO_SLOTS=Object.freeze(Object.fromEntries([
  slot('idle','Stationary energy hum','idle','idle-loop',true,'A quiet, breathing technological energy field.'),
  slot('movement','Movement sweep','movement','movement-loop',true,'A smooth filament slipstream that grows with visible movement.'),
  slot('fast','Fast-flight drive','movement','fast-loop',true,'A focused energy drive and tighter slipstream.'),
  slot('takeoff','Takeoff formation','transitions','takeoff',false,'Twin roots charge outward and the gems align.'),
  slot('landing','Landing retraction','transitions','landing',false,'A descending inward sweep as the filaments settle.'),
  slot('bank','Banking sweep','movement','bank',false,'A short bending tension glide during a turn.'),
  slot('gem','Gem alignment','gems','gem',false,'A restrained crystalline electronic alignment accent.'),
  ...[
    ['Neutral','Open / neutral','neutral','An opening energy field releases filament tension.'],
    ['ForwardGuard','Forward guard','forward-guard','An inward draw settles into a field lock.'],
    ['Cocoon','Cocoon','cocoon','Enclosing sweeps gather into a protected resonance.'],
    ['LeftForwardWrap','Left forward wrap','left-wrap','A filament glide travels toward the left.'],
    ['RightForwardWrap','Right forward wrap','right-wrap','A filament glide travels toward the right.'],
    ['AggressiveFlare','Aggressive flare','flare','A charged snap opens into an outward surge.'],
    ['Raised','Raised / crown','raised','Small control contacts align above the wings.'],
    ['Trailing','Trailing / back-swept','trailing','A narrow falling sweep resolves into flight.'],
    ['Collapsed','Collapsed pose','collapsed','The formation releases its remaining tension.'],
    ['Drooped','Drooped / damaged','drooped','Uneven strands lose their stable energy flow.'],
    ['Crossed','Crossed defence','crossed','Two tension glides interlock into a firm field.']
  ].map(([id,label,file,description])=>slot(`pose${id}`,label,'poses',`pose-${file}`,false,description)),
  ...['Damaged','Unstable','Glitching','Overdrive','Suppressed','Collapsed'].map(id=>slot(`condition${id}`,`${id} energy`,'conditions',`${id.toLowerCase()}-loop`,true)),
  ...[
    ['damage','Damage impact'],['critical','Critical impact'],['heal','Healing stabilization'],
    ['flare','Energy flare'],['pulse','Energy pulse'],['stutter','Filament stutter'],
    ['collapse','Collapse release'],['reform','Reform alignment']
  ].map(([id,label])=>slot(id,label,'reactions',id)),
  ...[['bitsDeploy','Release instruments','bits-deploy'],['bitsRecall','Recall instruments','bits-recall'],['bitsJoin','Additional instrument joins','bits-join'],['bitsFormation','Formation exchange','bits-formation']].map(([id,label,file])=>modern(id,label,'instruments',file)),
  ...Object.entries(BIT_GESTURES).map(([id,g])=>modern(`gesture_${id}`,`Instrument: ${g.label}`,'instruments',`gesture-${({acknowledge:'settle',beckon:'attend',makeRoom:'attend',poise:'settle',flourish:'confer',recalibrate:'inspect'})[id]??id}`,false,'A brief electronic work accent; opt in per group.')) ,
  ...['orbit','drift','weave','patrol','curious','escort','social','vigil'].map(id=>modern(`bits${id[0].toUpperCase()+id.slice(1)}`,`Close formation: ${id}`,'instruments',`bits-${id}`,true,'A restrained local instrument field; stops when the bits are recalled.')),
  ...['glide','surge','sentinel','wraith'].map(id=>modern(`mode${id[0].toUpperCase()+id.slice(1)}`,`${id[0].toUpperCase()+id.slice(1)} flight field`,'movement',`mode-${id}`,true)),
  ...STRUCTURES.map(id=>modern(`structure${id[0].toUpperCase()+id.slice(1)}`,`Form ${id}`,'structures',`structure-${id}`)),
  ...Object.values(CONDITION_EFFECTS).flat().map(e=>modern(`effect_${e.id}`,e.label,'conditions',`effect-${e.id}`,true,e.description)),
  ...Object.entries(REACTION_EFFECTS).flatMap(([kind,entries])=>entries.map(e=>modern(`reaction_${kind}_${e.id}`,`${kind}: ${e.label}`,'reactions',`reaction-${kind}-${e.id}`,false,e.description))),
  modern('warpSeam','Warp: seam','routines','warp-seam',false,'Space gathers and quickens, folds shut, and she arrives in a soft bloom.'),
  modern('warpThreaded','Warp: threaded','routines','warp-threaded',false,'The seam warp with filament draws and a spray of thread ticks.'),
  modern('warpFlicker','Warp: flicker','routines','warp-flicker',false,'The wings pull taut, the bits unthread in a scatter of glass and pull her back together.'),
  modern('routine_iris','Routine: mechanical iris','routines','routine-iris',false,'Muted blade ratchets, an opening tone and soft coded reading light.'),
  modern('routine_specimen','Routine: specimen in light','routines','routine-specimen',false,'Layers of light settle, the note is typed and the specimen folds away.'),
  modern('routine_maintenance','Routine: maintenance','routines','routine-maintenance',false,'Muted clamps, a slow seam reading, a part seated and a test tone through every bit.'),
  modern('routine_watchOut','Routine: Watch Out!','routines','routine-watchOut',false,'A snap, a dart to the ally, a gentle two-tone warning and a brace.'),
  modern('routine_searchlights','Routine: resting searchlights','routines','routine-searchlights',false,'The bit lights come up, or go down, together.'),
  modern('warpPetal','Warp: petal','routines','warp-petal',false,'She softens into drifting crystal petals and blooms back together.'),
  modern('warpShard','Warp: shard','routines','warp-shard',false,'Hairline cracks, facets streaking across and a soft snap back together.'),
  modern('warpMirror','Warp: mirror','routines','warp-mirror',false,'Two panes draw together as she steps through, then break softly behind her.'),
  modern('routine_chrysalis','Set piece: Chrysalis','routines','routine-chrysalis',false,'Filaments weave a cocoon, gather and open in a bloom of light.'),
  modern('routine_constellation','Set piece: Constellation','routines','routine-constellation',false,'A soft tone for each link of the star map, which hangs shimmering.'),
  modern('routine_bridge','Set piece: Hardlight bridge','routines','routine-bridge',false,'Panels set down in rising contacts, a hum as she crosses, folding away.'),
  ...[['medkitDepart','Treatment departure','medkit-depart'],['medkitScan','Diagnostic scan','medkit-scan'],['medkitSuccess','Treatment successful','medkit-success'],['medkitCriticalSuccess','Treatment exceptional success','medkit-critical-success'],['medkitFailure','Treatment incomplete','medkit-failure'],['medkitCriticalFailure','Treatment disengagement','medkit-critical-failure'],['medkitReturn','Instruments return','medkit-return']].map(([id,label,file])=>modern(id,label,'treatments',file)),
  ...MEDKIT_AUDIO_STYLES.map(id=>medical(`medkit_${id}`,`Treatment: ${id}`,id,`medkit-${id}`,true)),
  ...MEDKIT_AUDIO_STYLES.flatMap(style=>Object.entries(TREATMENT_AUDIO_STAGES).filter(([stage])=>stage!=='tool').map(([stage,label])=>medical(treatmentAudioSlot(style,stage),`${style}: ${label}`,style,`medkit-${style}-${stage}`)))
,
  flightSlot('flightWingbeat1','Wing pulse · soft','wingbeat-1','Her hum swells a touch with a stroke (very quiet).'),
  flightSlot('flightWingbeat2','Wing pulse · lower','wingbeat-2','The same swell, a shade lower.'),
  flightSlot('flightWingbeat3','Wing pulse · higher','wingbeat-3','The same swell, a shade higher.'),
  flightSlot('flightLiftoff','Lift','liftoff','A low hum rising under a widening shimmer as she climbs away.'),
  flightSlot('flightTouchdown','Settle','touchdown','The hum sinks and comes to rest as she touches down.'),
  flightSlot('flightImpact','Falling impact','fall-impact','A muffled low contact while her failing filaments gutter out.'),
  flightSlot('flightUnfurl','Combat unfurl','unfurl','The field opens outward: one shimmer parting into two, with a soft open chord.'),
  flightSlot('flightBrace','Brace','brace','The field flexes under a blow and holds.'),
  flightSlot('flightShield','Wing shield','shield','Her wings sweep forward and lock into facets.'),
  flightSlot('flightShieldHit','Shield ripple','shield-hit','The barrier takes a blow and shivers it away.'),
  flightSlot('flightShatter','Shatter and reform','shatter','Crystal pieces part softly, then the field draws them back together.'),
  flightSlot('flightBrake','Stop','brake','Her hum sags a little as she sheds her speed and stops (stronger for a harder stop).'),
  // (12.0.0-beta.7; since beta.10 generated recordings in two styles, see v12/sound-set.mjs) the v12 sound set (scripts/v12/sound-set.mjs): asked for only while V12 sounds is on for her
  modern('warpFlock','Warp: flock','routines','warp-flock',false,'Classics: a burst and the air rushing in after her, then the same played back as she arrives. Hardlight: a swarm of tiny shards ticking away and snapping back together.'),
  modern('warpStarfall','Warp: starfall','routines','warp-starfall',false,'Classics: a long transporter shimmer out, and another as she forms. Hardlight: a sparkling beam-out, then a rush inward that settles.'),
  modern('warpRibbon','Warp: ribbon seam','routines','warp-ribbon',false,'Classics: a portal stretching and snapping open, twice. Hardlight: a seam of energy ripping, snapping shut, and opening again where she arrives.'),
  modern('warpPrism','Warp: prism','routines','warp-prism',false,'Classics: a bright rising zip, then the same reversed into her lock. Hardlight: a phase-shift zap splitting into three pulses, then beams converging.'),
  flightSlot('flightShieldScalemail','Shield: scale mail','shield-scalemail','Classics: small plates and tiny servos locking over her. Hardlight: a cascade of scales ticking into place and a charged snap.'),
  flightSlot('flightShieldRotor','Shield: rotor','shield-rotor','Classics: a low, comforting whir rising as the shield comes up. Hardlight: a force field snapping on.'),
  flightSlot('flightShieldWingwrap','Shield: wing wrap','shield-wingwrap','Classics: her wings sweeping closed, then a soft bubble sealing. Hardlight: an energy sweep, then a force field snapping on over her.'),
  flightSlot('landingPowerdown','Landing: power down','landing-powerdown','Classics: an energy blade switching off. Hardlight: a bright hum sliding down in pitch to a small click.'),
  flightSlot('landingFoldaway','Landing: fold away','landing-foldaway','Classics: servos and plates sliding and locking, a solid latch as they stow. Hardlight: a quick run of small energy snaps collapsing.'),
  flightSlot('landingReelin','Landing: reel in','landing-reelin','Classics: a thin cable reeling in on a small motor. Hardlight: a fast descending electric zip and a soft click.'),
  modern('cloakOn','Cloak: fading','routines','cloak-on',false,'As her body is crossed. Classics: a warbling crackle of distortion with tiny glitching ticks. Hardlight: a soft phasing shimmer thinning out.'),
  modern('cloakOff','Cloak: coming back','routines','cloak-off',false,'As she comes back. Classics: distortion and crackle rippling back in and settling. Hardlight: a soft phasing shimmer fading in to a brief hum.'),
  modern('cloakOnQuick','Cloak: fading (quick)','routines','cloak-on-quick',false,'A short cloak. Classics: one eerie soft whisper. Hardlight: one quick phasing sweep.'),
  modern('cloakOffQuick','Cloak: coming back (quick)','routines','cloak-off-quick',false,'A short cloak ending. Classics: the whisper reversed. Hardlight: the quick sweep reversed.'),
  modern('decoyCast','Decoy: cast','routines','decoy-cast',false,'As her bits reach the corners. Classics: a click, and an old projector\'s warm motor hum coming up. Hardlight: soft lock clicks, a shimmer flickering on over a hum.'),
  modern('decoyAppear','Decoy: left behind','routines','decoy-appear',false,'Classics: a tiny click and a clean device sweep. Hardlight: a shimmer stuttering up over a gentle hum.'),
  modern('decoyLook','Decoy: change of look','routines','decoy-look',false,'Classics: one quick stutter of a projector\'s buzz. Hardlight: a shimmer stuttering in fragmented ticks.'),
  modern('decoyBreak','Decoy: comes apart','routines','decoy-break',false,'Classics: the projector\'s hum stuttering, sagging and cutting out with a small pop. Hardlight: a crackling digital tear and a small snap.')]));
// Keep the existing default id: old default/unspecified slots adopt the new
// pack without rewriting flags. Original files retain their previous paths.
export const AUDIO_PRESETS=Object.freeze({default:'Refined sci-fi (default)',original:'Original sound',custom:'Custom file',none:'None'});
const bool=(name,hint,value=true,scope='world')=>({name,hint,scope,config:true,type:Boolean,default:value});
const num=(name,hint,value,min,max,step,scope='world')=>({name,hint,scope,config:true,type:Number,default:value,range:{min,max,step}});
export function audioSettingDefinitions(){return {
  audioEnabled:bool('Enable animation audio','Allow opt-in wings, bits and treatment sounds. Wings and idle bits are enabled in Audio; Medkit treatment has a separate Play animation audio choice.'),
  audioVolume:num('Animation audio master volume','World volume multiplied by per-token, category and personal controls.',0.7,0,1,0.05),
  audioRadius:num('Wing audio default radius','Default outer audible distance in scene units. Category and sound overrides are available in Audio.',20,1,240,1),
  audioDistanceFade:bool('Wing audio distance fading','Fade gently toward the edge of the audible radius. Audio uses planar distance and does not trace walls.'),
  audioCrossfade:num('Wing audio crossfade','Milliseconds for loop changes and volume adjustments.',450,50,2000,50),
  audioMovementSensitivity:num('Wing audio motion sensitivity','Grid spaces per second of visible motion for a full movement layer. This is not a rules speed.',3.5,0.25,12,0.25),
  audioCooldown:num('Wing audio cue cooldown','Minimum milliseconds between repetitions of the same pose, bank or reaction cue.',450,100,5000,50),
  ...Object.fromEntries(Object.entries(AUDIO_CATEGORIES).map(([id,c])=>[`audioCategory${id[0].toUpperCase()+id.slice(1)}`,bool(`Wing audio: ${c.label.toLowerCase()}`,`Allow ${c.label.toLowerCase()} sounds. Tokens can mute and tune this category separately.`)])),
  audioMuted:bool('Mute Yvaelle’s Toolbox audio on this browser','Your personal mute, including Medkit sounds and previews. Other players are unaffected.',false,'client'),
  audioLocalVolume:num('Wing audio volume on this browser','Your personal wing-audio volume, including previews.',0.8,0,1,0.05,'client')
};}
const AUDIO_DEFAULTS=Object.freeze(Object.fromEntries(Object.entries(audioSettingDefinitions()).map(([key,entry])=>[key,entry.default])));
const own=(o,k)=>Object.hasOwn(o??{},k),plain=o=>!!o&&typeof o==='object'&&!Array.isArray(o);
const ranges={volume:[0,1],radius:[1,240],crossfadeMs:[50,2000],movementSensitivity:[0.25,12],cooldownMs:[100,5000]};
const top=new Set(['enabled','audience','localUserId','localRespectsRadius','volume','radius','distanceFade','crossfadeMs','movementSensitivity','cooldownMs','categories','slots']);
const categoryFields=new Set(['enabled','volume','radius']),slotFields=new Set([...categoryFields,'preset','src']);
const validSrc=value=>typeof value==='string'&&value.length<=2048&&!/[\u0000-\u001f]/.test(value)&&!/^\s*(?:javascript|data|file|blob):/i.test(value);
function fieldValue(key,value){
  if(value===null)return null;
  if(['enabled','distanceFade','localRespectsRadius'].includes(key)){if(typeof value!=='boolean')throw new Error(`${key} must be true or false.`);return value;}
  if(ranges[key]){const [min,max]=ranges[key];if(!Number.isFinite(value)||value<min||value>max)throw new Error(`${key} must be between ${min} and ${max}.`);return value;}
  if(key==='audience'){if(!['local','nearby'].includes(value))throw new Error('Audio audience must be local or nearby.');return value;}
  if(key==='localUserId'){if(typeof value!=='string'||!value.length||value.length>128)throw new Error('Invalid local audio user.');return value;}
  if(key==='preset'){if(!own(AUDIO_PRESETS,value))throw new Error('Choose refined sci-fi, original sound, custom audio or None.');return value;}
  if(key==='src'){if(!validSrc(value))throw new Error('Use a Foundry-served audio path or an HTTP(S) audio URL.');return value.trim();}
  throw new Error(`Unknown audio preference: ${key}.`);
}
function cleanGroup(raw,catalog,fields,strict){
  if(raw===null)return null;
  if(!plain(raw)){if(strict)throw new Error('Audio choices must be an object.');return {};}
  const out={};for(const [id,entry] of Object.entries(raw)){
    if(!own(catalog,id)){if(strict)throw new Error(`Unknown audio option: ${id}.`);continue;}
    if(entry===null){out[id]=null;continue;}
    if(!plain(entry)){if(strict)throw new Error(`Invalid audio choice for ${id}.`);continue;}
    const picked={};for(const [key,value] of Object.entries(entry)){
      if(!fields.has(key)){if(strict)throw new Error(`Unknown audio option field: ${key}.`);continue;}
      try{picked[key]=fieldValue(key,value);}catch(error){if(strict)throw error;}
    }
    if(Object.keys(picked).length)out[id]=picked;
  }return out;
}
function clean(raw,strict){
  if(!plain(raw)){if(strict)throw new Error('Audio preferences must be an object.');return {};}
  const out={};for(const [key,value] of Object.entries(raw)){
    if(!top.has(key)){if(strict)throw new Error(`Unknown audio preference: ${key}.`);continue;}
    if(key==='categories'||key==='slots'){out[key]=cleanGroup(value,key==='categories'?AUDIO_CATEGORIES:AUDIO_SLOTS,key==='categories'?categoryFields:slotFields,strict);continue;}
    try{out[key]=fieldValue(key,value);}catch(error){if(strict)throw error;}
  }return out;
}
export function validateAudioPatch(raw){return clean(raw,true);}
/** A picker audition may change only the source choice, in memory. It must
 * never enable audio, change its audience, or write a temporary preference. */
export function validateAudioPreview(options={}){
  if(!plain(options))throw new Error('Audio preview options must be an object.');
  for(const key of Object.keys(options))if(key!=='preset')throw new Error(`Unknown audio preview option: ${key}.`);
  if(!own(options,'preset'))return {};
  if(!own(AUDIO_PRESETS,options.preset))throw new Error('Choose a valid sound preset to preview.');
  return {preset:options.preset};
}
function mergeFields(base,patch){const out={...base};for(const [k,v]of Object.entries(patch??{})){if(v===null)delete out[k];else out[k]=v;}return out;}
export function normalizeAudio(raw){
  const valid=clean(raw,false),out={version:AUDIO_VERSION,enabled:false,audience:'local',localUserId:null,categories:{},slots:{}};
  for(const [key,value]of Object.entries(valid)){
    if(key==='categories'||key==='slots'){for(const [id,v]of Object.entries(value??{})){if(v!==null)out[key][id]=mergeFields({},v);}}
    else if(value!==null)out[key]=value;
  }return out;
}
export function mergeAudio(raw,patch){
  const base=normalizeAudio(raw),valid=validateAudioPatch(patch);
  for(const [key,value]of Object.entries(valid)){
    if(key==='categories'||key==='slots'){
      if(value===null){base[key]={};continue;}
      for(const [id,v]of Object.entries(value)){if(v===null)delete base[key][id];else base[key][id]=mergeFields(base[key][id],v);}
    }else if(value===null)delete base[key];else base[key]=value;
  }return normalizeAudio(base);
}
export function resolveAudio(raw,cfg={}){
  const d=normalizeAudio(raw);
  const v=k=>cfg[k]??AUDIO_DEFAULTS[k];
  const out={...d,requestedEnabled:d.enabled,enabled:d.enabled&&v('audioEnabled'),worldEnabled:v('audioEnabled'),
    volume:d.volume??1,radius:d.radius??v('audioRadius'),distanceFade:d.distanceFade??v('audioDistanceFade'),
    localRespectsRadius:d.localRespectsRadius??false,crossfadeMs:d.crossfadeMs??v('audioCrossfade'),
    movementSensitivity:d.movementSensitivity??v('audioMovementSensitivity'),cooldownMs:d.cooldownMs??v('audioCooldown'),
    worldVolume:v('audioVolume'),localMuted:v('audioMuted'),localVolume:v('audioLocalVolume'),categories:{},slots:{}};
  for(const [id,c]of Object.entries(AUDIO_CATEGORIES)){
    const p=d.categories[id]??{},gate=v(`audioCategory${id[0].toUpperCase()+id.slice(1)}`);
    out.categories[id]={...c,enabled:gate&&p.enabled!==false,worldEnabled:gate,volume:p.volume??c.volume,radius:p.radius??out.radius};
  }
  for(const [id,s]of Object.entries(AUDIO_SLOTS)){
    const p=d.slots[id]??{},c=out.categories[s.category],preset=p.preset??'default';
    const src=preset==='custom'?p.src??'':preset==='none'?'':`modules/filament-flight/assets/audio/${s.directory?`${s.directory}/`:preset==='original'&&!s.modern?'':'refined/'}${s.file}.ogg${s.category==='treatments'?s.directory?'?v=7.0.0':'?v=5.2.0':''}`;
    const enabled=out.enabled&&c.enabled&&p.enabled!==false&&!!src;
    out.slots[id]={...s,overridden:own(d.slots,id),enabled,preset,src,volume:p.volume??1,radius:p.radius??c.radius,
      gain:enabled&&!out.localMuted?out.volume*out.worldVolume*out.localVolume*c.volume*(p.volume??1):0};
  }return out;
}
export function loopOffset(started,now,duration){return Number.isFinite(duration)&&duration>0?Math.max(0,(now-started)/1000)%duration:0;}
export function distanceGain(distance,radius,fade=true){
  if(!Number.isFinite(distance)||!Number.isFinite(radius)||radius<=0||distance>=radius)return 0;
  if(!fade)return 1;
  const p=Math.max(0,Math.min(1,(distance/radius-0.15)/0.85));return 1-p*p*(3-2*p);
}
export function poseAudioSlot(pose){return `pose${String(pose??'neutral')[0].toUpperCase()}${String(pose??'neutral').slice(1)}`;}

/** A mixed visual condition uses the sound belonging to its selected artwork. */
export function conditionAudioSlot(snapshot){
  const style=snapshot?.visual?.effectStyle;
  if(style==='none')return null;
  const id=style==='animated'?DEFAULT_CONDITION_ART[snapshot?.effective?.condition??'normal']:style;
  return AUDIO_SLOTS[`effect_${id}`]?`effect_${id}`:null;
}
export function reactionAudioSlot(snapshot,entry){
  const choice=snapshot?.visual?.profile?.reactions?.find(r=>r.kind===entry.kind)?.id??snapshot?.requested?.reactionStyles?.[entry.kind];
  return AUDIO_SLOTS[`reaction_${entry.kind}_${choice}`]?`reaction_${entry.kind}_${choice}`:entry.kind;
}
