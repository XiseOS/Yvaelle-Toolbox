import {ID,runtimeConfiguration} from './config.mjs?v=13.0.4';
import {readActorConditions,actorConditionKey,actorConditionsEqual,sampleConditionResponse,makeConditionResponse,conditionRecoveryGroundsFlight,conditionFlightBlockers,conditionGroundsFlight,effectiveActorConditions,readConditionResponse} from './condition-response.mjs?v=13.0.4';
import {readHealth,healthKey,hash} from './conditions.mjs?v=13.0.4';
import {groundElevationChanges} from './flight-feel-runtime.mjs?v=13.0.4';
import {makeBitRestPoses} from './bit-collapse.mjs?v=13.0.4';
import {actionHardware,actionContext,sourceTransform,toWorld} from './bit-action-renderer.mjs?v=13.0.4';
import {sampleSequence,BIT_KEY} from './bit-sequences.mjs?v=13.0.4';

const clock=()=>Number(globalThis.game?.time?.serverTime)||Date.now();
const clone=x=>structuredClone(x);
// Compare flight intent again inside the shared command queue. A queued Take
// off/landing command must not be undone by a repair captured before it ran.
const flightIntent=raw=>JSON.stringify([raw?.airborne,raw?.mode,raw?.activation,raw?.started,raw?.transition]);
const mayGround=response=>response.enabled&&(response.wings||response.bits)&&response.config.conditions.unconscious.enabled&&response.config.conditions.unconscious.strength>0;
function groundingChanges(raw,doc=null){
  // Flight feel: a grounded flier's real elevation returns to her ground too.
  const path=`flags.${ID}.flight`,changes={...groundElevationChanges(doc),[`${path}.airborne`]:false};
  // An old takeoff must not restore its lift after the airborne flag is cleared.
  // Preserve wing opening/closing and all deployment/appearance preferences.
  if(raw?.transition)changes[`${path}.transition`]={...clone(raw.transition),fromFlight:0,toFlight:0,wingsOnly:true};
  return changes;
}
/** Actor/item hooks produce one bounded visual event. All clients may sample
 * immediately; only the elected actor writer persists its shared timestamp. */
export class ConditionResponseRuntime {
  constructor(reactions){this.reactions=reactions;this.api=reactions.api;this.manager=reactions.manager;this.actors=new Map();this.actorSources=new Map();this.tokenSources=new Map();this.health=new Map();this.observing=new Map();this.pending=new Map();this.groundingRepairs=new Map();this.restoringTokens=new Set();}
  conditions(actor){
    if(!actor?.uuid)return {};
    let cached=this.actors.get(actor.uuid);
    if(!cached){cached=readActorConditions(actor);this.actors.set(actor.uuid,cached);this.actorSources.set(actor.uuid,actor);this.health.set(actor.uuid,readHealth(actor));}
    return cached;
  }
  seed(){
    this.pending.clear();this.actors.clear();this.actorSources.clear();this.tokenSources.clear();this.health.clear();this.observing.clear();
    for(const doc of this.documents()){
      this.tokenSources.set(doc.uuid,doc.actor);
      const next=this.effective(doc,this.conditions(doc.actor)),raw=doc.getFlag(ID,'flight');
      if(raw?.conditionResponse?!actorConditionsEqual(raw.conditionResponse.to,next):Object.keys(next).length>0){
        this.update(doc,raw?.conditionResponse?.to??{},next,clock(),{restoring:true});
        continue;
      }
      // A client may have disconnected between the visual-event write and the
      // action pause write, or disabled reactions while its scene was unloaded.
      const response=sampleConditionResponse(raw??{},next,clock()),down=response.bits&&['falling','fallen'].includes(response.collapse.phase);
      if(down&&response.collapse.bits.some(id=>response.collapse.originsWorld?.[id]&&!response.collapse.restsWorld?.[id]))this.repairGround(doc,raw,response);
      if(raw?.conditionResponse?.collapse&&!raw.conditionResponse.collapse.flightGrounded&&mayGround(response))
        this.repairFlight(doc,raw,next);
      this.repairStatusFlight(doc,raw,next,response);
      const events=this.manager.bits?.records?.(doc)??[];
      const needsRepair=events.some(event=>down?event.kind!=='escort'&&event.conditionPausedAt==null:event.conditionPausedAt!=null);
      if(needsRepair&&doc.isOwner&&this.reactions.writer(doc.actor)===globalThis.game?.user?.id)
        void Promise.resolve(this.manager.bits?.conditionChanged?.(doc,{unconscious:down,response,restoring:true},clock())).catch(error=>this.manager.report(error));
    }
  }
  effective(doc,conditions,health=readHealth(doc.actor)){
    return effectiveActorConditions(doc.getFlag(ID,'flight')??{},conditions,health,runtimeConfiguration());
  }
  capture(doc,now){
    const bits=this.manager.bits.getState(doc).outBits,events=this.manager.bits.records(doc),onScene=doc.object&&doc.parent?.id===globalThis.canvas?.scene?.id;
    const token=onScene?doc.object:this.documentToken(doc),base=onScene?this.manager.bits.captureWorld(doc,bits,events,now):this.captureOffScene(doc,token,bits,events,now);
    const captured={...base,bits,persistent:true,scale:Math.max(token.w??100,token.h??100),originAngles:{},originScales:{}};
    const local=this.manager.states?.get(doc.object)?.renderer,action=this.manager.bits.renderers?.get(doc.object)?.bits;
    for(const id of bits){
      const key=BIT_KEY[id],home=[local?.compact?.bits,local?.rig?.bits];
      const p=(action?.records?.has(key)?action.placements?.get(id):null)??home.find(renderer=>renderer?.records?.has(key))?.placements?.get(id);
      if(Number.isFinite(p?.x)&&Number.isFinite(p?.y))captured.originsWorld[id]={x:p.x,y:p.y};
      captured.originAngles[id]=p?.angle??p?.angleAbsolute??((Number(doc.rotation)||0)*Math.PI/180);
      if(Number.isFinite(p?.scale))captured.originScales[id]=p.scale;
    }
    return captured;
  }
  documentToken(doc){
    if(doc?.object?.mesh&&doc.parent?.id===globalThis.canvas?.scene?.id)return doc.object;
    const grid=Number(doc?.parent?.grid?.size)||100,w=(Number(doc?.width)||1)*grid,h=(Number(doc?.height)||1)*grid;
    return {document:doc,w,h,mesh:{x:(Number(doc?.x)||0)+w/2,y:(Number(doc?.y)||0)+h/2,rotation:(Number(doc?.rotation)||0)*Math.PI/180}};
  }
  captureOffScene(doc,token,bits,events,now){
    // A GM on another scene is still the elected writer. Reconstruct the
    // current deterministic paths from document positions and shared clocks.
    const snapshot=this.manager.bits.state(doc,true),hardware=actionHardware(snapshot,now,{destination:true}),transform=sourceTransform(token,snapshot,this.manager),originsWorld={},originDepths={},samples=new Map();
    for(const id of bits){
      const event=events.find(e=>e.status!=='queued'&&e.bits.includes(id));
      if(event){
        if(!samples.has(event.id)){
          const target=event.target?doc.parent?.tokens?.get(event.target):null;
          samples.set(event.id,sampleSequence(event,now,actionContext(token,target?this.documentToken(target):null,snapshot,event,this.manager,hardware,now)));
        }
        const sample=samples.get(event.id);if(sample.positions[id])originsWorld[id]={...sample.positions[id]};originDepths[id]=sample.depths?.[id]??1;
      }
      if(!originsWorld[id]){originsWorld[id]=toWorld(hardware[id]?.points?.[0]??[0,15,1],transform);originDepths[id]=(hardware[id]?.points?.[0]?.[2]??1)>=0?1:-1;}
    }
    return {originsWorld,originDepths};
  }
  /** Upgrade old source-relative falls once, at the location already shown. */
  repairGround(doc,raw,response){
    if(!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id||!raw?.conditionResponse?.collapse)return;
    let captured;try{captured=this.capture(doc,clock());}catch(error){this.manager.report(error);return;}
    if(!captured.bits?.length)return;
    const id=raw.conditionResponse.id;
    void this.api.enqueue(doc,async()=>{
      if(!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id)return;
      const saved=doc.getFlag(ID,'flight')?.conditionResponse;if(saved?.id!==id||saved.collapse.bits.every(bit=>!saved.collapse.originsWorld?.[bit]||saved.collapse.restsWorld?.[bit]))return;
      const event=clone(saved),rests=makeBitRestPoses(event.collapse.id,captured.bits,captured);
      for(const bit of captured.bits)if(rests[bit]&&response.collapse.phase==='fallen')Object.assign(rests[bit],captured.originsWorld[bit],{angle:captured.originAngles[bit]??rests[bit].angle});
      event.collapse.restsWorld={...rests,...event.collapse.restsWorld};
      Object.assign(event.collapse.originsWorld,captured.originsWorld);
      await doc.update({[`flags.${ID}.flight.conditionResponse`]:readConditionResponse(event)});
    }).catch(error=>this.manager.report(error));
  }
  repairFlight(doc,raw,conditions){
    if(!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id)return;
    const id=raw.conditionResponse.id,intent=flightIntent(raw);
    const repairKey=`recovery|${id}|${intent}`;
    if(this.groundingRepairs.get(doc.uuid)===repairKey)return;
    this.groundingRepairs.set(doc.uuid,repairKey);
    void this.api.enqueue(doc,async()=>{
      const saved=doc.getFlag(ID,'flight');
      if(!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id||saved?.conditionResponse?.id!==id||saved.conditionResponse.collapse?.flightGrounded||
        !actorConditionsEqual(this.effective(doc,readActorConditions(doc.actor)),conditions))return;
      const event=clone(saved.conditionResponse);event.collapse.flightGrounded=true;
      // A later explicit command owns lift. Acknowledge the old collapse either
      // way, otherwise a subsequent scene load would incorrectly ground it.
      const response=sampleConditionResponse(saved,conditions,clock());
      const changes=flightIntent(saved)===intent&&mayGround(response)?groundingChanges(saved,doc):{};
      await doc.update({...changes,[`flags.${ID}.flight.conditionResponse`]:event});
    }).catch(error=>this.manager.report(error)).finally(()=>{if(this.groundingRepairs.get(doc.uuid)===repairKey)this.groundingRepairs.delete(doc.uuid);});
  }
  documents(actor){return [...(actor?this.reactions.tokens.forActor(actor):this.reactions.tokens.all())].filter(doc=>doc.getFlag(ID,'flight')!=null||doc.getFlag(ID,'bitAllocations')!=null||doc.getFlag(ID,'bitAnimations')!=null);}
  repairStatusFlight(doc,raw,conditions,response){
    const pending=raw?.conditionResponse?.grounding&&!raw.conditionResponse.grounding.flightGrounded;
    if(!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id||!raw?.conditionResponse||
      !pending&&!(conditionFlightBlockers(response).length&&(raw.airborne??raw.enabled)))return;
    const id=raw.conditionResponse.id,intent=flightIntent(raw);
    const repairKey=`status|${id}|${intent}`;
    if(this.groundingRepairs.get(doc.uuid)===repairKey)return;
    this.groundingRepairs.set(doc.uuid,repairKey);
    void this.api.enqueue(doc,async()=>{
      const saved=doc.getFlag(ID,'flight');
      if(!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id||saved?.conditionResponse?.id!==id||
        !actorConditionsEqual(this.effective(doc,readActorConditions(doc.actor)),conditions))return;
      const sampled=sampleConditionResponse(saved,conditions,clock()),event=clone(saved.conditionResponse);
      const needsGround=conditionFlightBlockers(sampled).length||event.grounding&&!event.grounding.flightGrounded&&conditionGroundsFlight(saved,sampled);
      const changed=event.grounding&&!event.grounding.flightGrounded;
      if(event.grounding)event.grounding.flightGrounded=true;
      // While a grounding status remains active, a delayed Take off never owns
      // lift. After removal, preserve any newer explicit flight command.
      const changes=needsGround&&(conditionFlightBlockers(sampled).length||flightIntent(saved)===intent)?groundingChanges(saved,doc):{};
      if(changed||Object.keys(changes).length)await doc.update({...changes,[`flags.${ID}.flight.conditionResponse`]:event});
    }).catch(error=>this.manager.report(error)).finally(()=>{if(this.groundingRepairs.get(doc.uuid)===repairKey)this.groundingRepairs.delete(doc.uuid);});
  }
  context(doc,currentHealth){
    // Rebuilt synthetic actors can retain their UUID while replacing the
    // prepared object, without an actor-condition hook. Reconcile once at that
    // handoff; ordinary rendering still samples the cached condition levels.
    // conditions() deliberately retains the previous snapshot until observe()
    // can capture its displayed pose, including when seedActor ran first.
    if(doc.actor?.uuid&&this.actorSources.has(doc.actor.uuid)&&this.actorSources.get(doc.actor.uuid)!==doc.actor){
      if(typeof this.reactions.observe==='function')this.reactions.observe(doc.actor);
      else this.observe(doc.actor);
    }
    const before=this.observing.get(doc.actor?.uuid),actorConditions=this.effective(doc,before?.conditions??this.conditions(doc.actor),before?before.health:currentHealth===undefined?readHealth(doc.actor):currentHealth),pending=this.pending.get(doc.uuid),saved=doc.getFlag(ID,'flight')?.conditionResponse;
    if(pending&&(!actorConditionsEqual(pending.to,actorConditions)||saved?.id===pending.id||saved?.started>pending.started))this.pending.delete(doc.uuid);
    if(!before&&this.tokenSources.get(doc.uuid)!==doc.actor){
      // Relinking can change the actor UUID as well. Its first context needs
      // the same bounded restoration as a scene load, including old recovery
      // acknowledgements, without waiting for another actor update or reload.
      this.tokenSources.set(doc.uuid,doc.actor);
      if(!this.pending.has(doc.uuid)&&saved){
        const raw=doc.getFlag(ID,'flight')??{};
        if(!actorConditionsEqual(saved.to,actorConditions))this.update(doc,saved.to,actorConditions,clock(),{restoring:true});
        else if(conditionRecoveryGroundsFlight(raw,sampleConditionResponse(raw,actorConditions,clock())))this.repairFlight(doc,raw,actorConditions);
      }
    }
    // Newly placed tokens do not run a full scene seed. Give an already-active
    // condition its event before removal can expose an old airborne flag.
    if(!before&&!this.pending.has(doc.uuid)&&!saved&&Object.keys(actorConditions).length&&!this.restoringTokens.has(doc.uuid)){
      this.restoringTokens.add(doc.uuid);
      try{this.update(doc,{},actorConditions,clock(),{restoring:true});}finally{this.restoringTokens.delete(doc.uuid);}
    }
    // Re-enabling status reactions is a settings edit, not an actor hook. A
    // current incapacitation must still commit its grounded state once.
    const raw=doc.getFlag(ID,'flight')??{};
    const liveBlocker=actorConditions.prone||actorConditions.paralyzed||(actorConditions.stunned??0)>=3;
    if(!before&&!this.pending.has(doc.uuid)&&(liveBlocker&&(raw.airborne??raw.enabled)||raw.conditionResponse?.grounding&&!raw.conditionResponse.grounding.flightGrounded))this.repairStatusFlight(doc,raw,actorConditions,sampleConditionResponse(raw,actorConditions,clock()));
    // Flight feel: knocked out in the air, her real elevation drops to the
    // ground as she falls (written once, by the elected writer).
    if(doc.getFlag?.(ID,'flightGround')!=null&&raw.conditionResponse&&doc.isOwner&&this.reactions.writer(doc.actor)===globalThis.game?.user?.id){
      const r=sampleConditionResponse(raw,actorConditions,clock());
      if((r.wings||r.bits)&&['falling','fallen'].includes(r.collapse?.phase))this.groundFallen(doc);
    }
    return {...(before?{health:before.health}:{}),actorConditions,conditionResponse:this.pending.get(doc.uuid)??saved??null};
  }
  groundFallen(doc){
    this.fallGrounding??=new Set();if(this.fallGrounding.has(doc.uuid))return;this.fallGrounding.add(doc.uuid);
    void this.api.enqueue(doc,async()=>{const changes=groundElevationChanges(doc);if(Object.keys(changes).length)await doc.update(changes);})
      .catch(error=>this.manager.report(error)).finally(()=>this.fallGrounding.delete(doc.uuid));
  }
  observe(actor){
    if(!actor?.uuid)return;
    const previous=this.conditions(actor),next=readActorConditions(actor),previousHealth=this.health.get(actor.uuid),nextHealth=readHealth(actor);
    // Record the new identity before capture can sample this actor recursively.
    // Keep the old condition/HP snapshot until those origins have been read.
    this.actorSources.set(actor.uuid,actor);
    if(actorConditionsEqual(previous,next)&&healthKey(previousHealth)===healthKey(nextHealth))return;
    const now=clock();
    // Capture actual displayed origins while the old actor-context remains live.
    // A fresh live HP read must not inject zero-HP collapse into that capture.
    this.observing.set(actor.uuid,{conditions:previous,health:previousHealth});
    try{for(const doc of this.documents(actor)){
      const before=this.effective(doc,previous,previousHealth),after=this.effective(doc,next,nextHealth);
      if(!actorConditionsEqual(before,after))this.update(doc,before,after,now);
    }}finally{this.observing.delete(actor.uuid);}
    this.actors.set(actor.uuid,next);this.health.set(actor.uuid,nextHealth);
    this.manager.invalidateActor?.(actor);
    for(const doc of this.documents(actor)){
      this.manager.stateSamples?.delete?.(doc);this.manager.bits?.invalidateState?.(doc);
      if(doc.parent?.id===globalThis.canvas?.scene?.id){void this.manager.sync?.(doc.object);this.manager.bits?.observe?.(doc);}
      try{globalThis.Hooks?.callAll?.('filamentFlightStateChanged',doc,this.api.getState(doc));}catch(error){this.manager.report(error);}
    }
  }
  update(doc,previous,next,now,{restoring=false}={}){
    const raw=doc.getFlag(ID,'flight')??{},prior=this.pending.get(doc.uuid)??raw.conditionResponse,intent=flightIntent(raw);
    const current=sampleConditionResponse({...raw,conditionResponse:prior},previous,now),entering=!previous?.unconscious&&!!next?.unconscious;
    let captured={};
    if(entering){
      const alreadyRestoring=this.restoringTokens.has(doc.uuid);this.restoringTokens.add(doc.uuid);
      try{captured=this.capture(doc,now);}
      catch(error){this.manager.report(error);}
      finally{if(!alreadyRestoring)this.restoringTokens.delete(doc.uuid);}
    }
    const event=makeConditionResponse({id:`condition-${hash(`${doc.uuid}|${prior?.id??'initial'}|${actorConditionKey(next)}`).toString(36)}`,now,previous,next,current,captured});
    // A first appearance restores the actor's current posture immediately.
    // Only a subsequent live condition change needs the 450 ms art blend.
    if(restoring&&!prior)event.from={...event.to};
    this.pending.set(doc.uuid,event);
    if(this.reactions.writer(doc.actor)!==globalThis.game?.user?.id||!doc.isOwner)return;
    void this.api.enqueue(doc,async()=>{
      // A newer hook or explicit module removal invalidates this queued event.
      if(this.pending.get(doc.uuid)?.id!==event.id||!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id||!actorConditionsEqual(this.effective(doc,readActorConditions(doc.actor)),next))return;
      const saved=doc.getFlag(ID,'flight');
      if(saved==null&&doc.getFlag(ID,'bitAllocations')==null&&doc.getFlag(ID,'bitAnimations')==null)return;
      const response=sampleConditionResponse({...saved,conditionResponse:event},next,now);
      const blocked=conditionFlightBlockers(response).length>0;
      const shouldGround=conditionGroundsFlight({conditionResponse:event},response)||restoring&&event.collapse&&mayGround(response);
      const persisted=clone(event),changes={};
      if(persisted.grounding)persisted.grounding.flightGrounded=true;
      if(shouldGround){
        if(persisted.collapse)persisted.collapse.flightGrounded=true;
        if(blocked||flightIntent(saved)===intent)Object.assign(changes,groundingChanges(saved,doc));
      }
      await doc.update({...changes,[`flags.${ID}.flight.conditionResponse`]:persisted});
      return true;
    }).then(async committed=>{
      // Skipped events must not pause or release work after a newer event has
      // already taken over. Writer election can also change while queued.
      if(!committed||!doc.isOwner||this.reactions.writer(doc.actor)!==globalThis.game?.user?.id||
        doc.getFlag(ID,'flight')?.conditionResponse?.id!==event.id||
        this.pending.has(doc.uuid)&&this.pending.get(doc.uuid).id!==event.id)return;
      if(this.pending.get(doc.uuid)?.id===event.id)this.pending.delete(doc.uuid);
      if(previous?.unconscious===next?.unconscious)return;
      if(!actorConditionsEqual(this.effective(doc,readActorConditions(doc.actor)),next))return;
      const response=sampleConditionResponse({...raw,conditionResponse:event},next,now);
      const unconscious=!!next.unconscious&&response.bits&&response.config.conditions.unconscious.enabled&&response.config.conditions.unconscious.strength>0;
      await this.manager.bits?.conditionChanged?.(doc,{unconscious,response,event,restoring},now);
    }).catch(error=>this.manager.report(error));
  }
  removeToken(doc){this.pending.delete(doc.uuid);this.tokenSources.delete(doc.uuid);}
  removeActor(actor){this.actors.delete(actor.uuid);this.actorSources.delete(actor.uuid);this.health.delete(actor.uuid);this.observing.delete(actor.uuid);}
}
