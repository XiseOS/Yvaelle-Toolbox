/** Yvaelle’s Toolbox v11 · Healing and the bits' jobs: the moments (pure).
 *
 * Port of the approved lab designs to the module: every moment is a pure
 * function of the seconds since it began, so it can be sampled on any client
 * from the same synced trigger (a chat message, an actor change).
 *
 *   trad      a spell tradition's response (divine, arcane, primal, occult)   (lab canvas-fx 3)
 *   hero      Hero Point spent                                                 (lab liked-fx 3)
 *   nat20/nat1  die-roll moods                                                 (lab canvas-fx 6)
 *   watch     an ally's turn: the nearest bit turns to watch them              (lab canvas-fx 1)
 *   escape    grapple escape attempt (success snaps, failure sags)             (lab fixes grapple-fx, wingless grappleFrame)
 *   last      Last light: knocked out in the air, the bits catch her           (lab refine/lastlight, with the jolt)
 *
 * The runtime (heal-runtime.mjs) owns a record per token and gives each frame
 * a context C (positions, already in map pixels). This file writes:
 *   healInput(R,input,f,C)  Last light carries her: her height is set, not flown
 *   healFeel(R,out,C)       body feel and bits (out.bits[i], plus R.deco[i] for the overlay)
 *   healWing(R,C)           the wing painter's state (heal-wing.mjs), or null
 *   paintHealOverlay(g,R,C) map-space strokes (threads, blooms, glows)
 * It allocates nothing per frame while idle; moments allocate a little while they play. */
import {PAL,SPELL_SPAN,HERO_SPAN} from './heal-wing.mjs?v=13.0.4';

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
export const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const ease=x=>{x=unit(x);return x<.5?4*x*x*x:1-(-2*x+2)**3/2;};
const easeOut=(x,p=3)=>1-(1-unit(x))**p;
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const env=(t,a,ain,b,bout)=>smooth((t-a)/ain)*(1-smooth((t-b)/bout));
const lerp=(a,b,k)=>a+(b-a)*k;
const wrapA=a=>Math.atan2(Math.sin(a),Math.cos(a));
const rgba=(c,a)=>`rgba(${c[0]|0},${c[1]|0},${c[2]|0},${a<0?0:a>1?1:a})`;
const BIT_SIDE=[[-1,-1],[1,-1],[-1,1],[1,1]];

export const SPAN=Object.freeze({trad:SPELL_SPAN+.3,hero:HERO_SPAN,nat20:2.2,nat1:3.6,escapeOk:3.9,escapeFail:3.2,last:11.2,watchOut:1.4});
/** Last light: knock-out, catch, held, lowered (lab canvas-fx 5, refine). */
const KO=0,CATCH=.78,HELD=CATCH+1.35,DOWN1=HELD+5.2,G=14,GIVE=2.0,JOLT_PX=3.2,JOLT_BACK=.32;
export const VIGIL_HOLD=30;
/** Grapple escape (lab fixes grapple-fx A). */
const GA={shoot:.28,resolve:1.25,hard:1.05,sag:1.5,fade:1.85,gone:2.9};

/* ---------------- the record ---------------- */
export function createHealRecord(){
  return {moments:[],parts:null,frameMode:false,
    deco:[0,1,2,3].map(()=>({glow:null,glowRec:{c:null,a:0,rad:14},focus:null,focusRec:{k:0,tint:null,swell:1.55,glow:1,rim:1,core:9},top:false,scale:1,alpha:1})),
    mem:{},wing:{ops:[],anim:false},opsPool:[]};
}
/** Add a moment (kind, at = local seconds, extra fields). Older moments of a kind that cannot overlap are replaced. */
export function addMoment(R,m){
  const single=m.kind==='last'||m.kind==='hero'||m.kind==='nat20'||m.kind==='nat1'||m.kind==='escape';
  if(single)R.moments=R.moments.filter(x=>x.kind!==m.kind);
  if(m.kind==='watch')for(const x of R.moments)if(x.kind==='watch'&&x.end==null)x.end=m.at;
  if(m.kind==='trad')R.moments=R.moments.filter(x=>x.kind!=='trad'||m.at-x.at<.4);
  R.moments.push(m);if(R.moments.length>12)R.moments.shift();
  return m;
}
/** How long a moment lasts (s). */
export function spanOf(m){
  switch(m.kind){
    case 'escape':return m.ok?SPAN.escapeOk:SPAN.escapeFail;
    case 'watch':return m.end==null?Infinity:m.end-m.at+SPAN.watchOut;
    case 'last':return SPAN.last+(m.vigil?VIGIL_HOLD:0);
    default:return SPAN[m.kind]??3;
  }
}
/** Drop finished moments; true while anything plays or lasts. */
export function pruneMoments(R,t){
  let n=0;for(const m of R.moments)if(t-m.at<spanOf(m))R.moments[n++]=m;R.moments.length=n;
  return n>0||(R.grabbedAt!=null&&!!R.parts?.grappleNarrow);
}
export const healBusy=(R,t)=>pruneMoments(R,t);

/* ---------------- shared bits ---------------- */
/** The spin that points a bit's tip along screen heading h. */
const aim=(C,i,h)=>wrapA(h+Math.PI/2-C.angle-(C.painted?.[i]??0));
const resetDeco=R=>{for(const d of R.deco){d.glow=null;d.focus=null;d.top=false;d.behind=false;d.scale=1;d.alpha=1;}};
function glowOn(R,i,c,a,rad=14){if(a<=.005)return;const d=R.deco[i],g=d.glowRec;if(d.glow&&d.glow.a>a)return;g.c=c;g.a=a;g.rad=rad;d.glow=g;}
function focusOn(R,i,k,tint,o=null){if(k<=.001)return;const d=R.deco[i],f=d.focusRec;if(d.focus&&d.focus.k>k)return;
  f.k=k;f.tint=tint;f.swell=o?.swell??1.55;f.glow=o?.glow??1;f.rim=o?.rim??1;f.core=o?.core??9;d.focus=f;d.scale=1+(f.swell-1)*k;}


/* ---------------- spell traditions ---------------- */
function tradFeel(m,out,s,size){
  switch(m.trad){
    case 'divine':{const e=env(s,0,.45,SPELL_SPAN-.55,.55);out.stretch=Math.max(out.stretch??0,.5*e);out.lift-=4*e*size/100;out.beatRate*=1-.3*e;break;}
    case 'arcane':{const e=env(s,0,.08,SPELL_SPAN-.3,.3);out.beatRate*=1-.7*e;out.flex*=1-e;out.widthMul*=1+.025*e;break;}
    case 'primal':{const e=env(s,0,.4,SPELL_SPAN-.5,.5);out.bank+=.025*Math.sin(s*3.2)*e;out.widthMul*=1+.03*e;out.beatRate*=1-.4*e;break;}
    case 'occult':{const e=env(s,0,.25,SPELL_SPAN-.45,.45);out.wingAlpha*=1-.18*e*(.5+.5*Math.sin(s*17));out.beatRate*=1-.5*e;break;}
  }
}
const TRAD_GLOW={divine:[214,176,112],arcane:[200,215,255],primal:[150,190,96],occult:[164,92,255]};
function tradBits(R,m,out,s,t,size){
  const k=size/100;
  for(let i=0;i<4;i++){const o=out.bits[i];
    switch(m.trad){
      case 'divine':{const e=env(s,.2,.4,SPELL_SPAN-.4,.5);glowOn(R,i,TRAD_GLOW.divine,.32*e,14);if(i<2)o.y-=4*e*k;break;}
      case 'arcane':{const e=env(s,0,.1,SPELL_SPAN-.3,.3);o.spin+=Math.PI/4*(smooth((s-.08)/.12)-smooth((s-SPELL_SPAN+.35)/.25));glowOn(R,i,TRAD_GLOW.arcane,.25*e,12);break;}
      case 'primal':{const e=env(s,.1,.4,SPELL_SPAN-.5,.5);o.y+=3*e*Math.sin(s*4+i)*k;glowOn(R,i,TRAD_GLOW.primal,.26*e,13);break;}
      case 'occult':{const e=env(s,0,.25,SPELL_SPAN-.45,.45);o.x+=Math.sin(s*13+i*2)*2.2*e*k;R.deco[i].alpha*=1-.35*e*(.5+.5*Math.sin(s*21+i));glowOn(R,i,TRAD_GLOW.occult,.22*e,13);break;}
    }
  }
}

/* ---------------- Hero Point ---------------- */
const hpIn=q=>q<0?0:smooth(q/.55)*(1-smooth((q-.78)/.42));
const hpOut=q=>q<.72?0:bump(unit((q-.72)/.8));
const hpHold=q=>env(q,.42,.16,.74,.14);
const HERO_TINT=[244,176,148];
function heroFeel(out,q,size){if(q<0||q>2)return;const g=hpIn(q),r=hpOut(q);
  out.widthMul*=1-.12*g+.07*r;out.beatRate*=(1-.78*g)*(1+1.25*r);out.lift-=(3.5*g-1.5*r)*size/100;out.flex=Math.min(1,out.flex+.25*r);out.wingAlpha*=(1-.24*g)*(1+.1*r);}
function heroBits(R,out,q,C){
  if(q<0||q>2.2)return;const g=hpIn(q),rq=q-.78,ov=rq>0?.07*Math.exp(-rq/.28)*Math.sin(rq*TAU/.7):0,pull=.32*g-ov;
  for(let i=0;i<4;i++){const o=out.bits[i],b=C.bits[i];
    // drawn in toward her heart (and back out with a small damped overshoot)
    if(b){o.x+=(C.cx-b.x0)*pull;o.y+=(C.cy+4*C.size/100-b.y0)*pull;}
    o.spin+=(BIT_SIDE[i][0]<0?1:-1)*.4*g;
    const glow=.34*g+.18*hpHold(q)+.25*hpOut(q)*(1-unit(rq/.6));
    if(glow>.01){glowOn(R,i,HERO_TINT,glow,13);focusOn(R,i,.35*g,HERO_TINT,{swell:1.25,glow:.6,rim:.8});}}
}


/* ---------------- die moods ---------------- */
function nat20Feel(out,q){out.stretch=Math.max(out.stretch??0,.25*bump(unit(q/.9)));}
function nat1Feel(out,q){const w=env(q,0,.15,1.2,.5);out.bank+=-.035*w;out.widthMul*=1-.04*w;}
const hideK=q=>env(q,.3,.3,1.0,.2)*(1-env(q,1.05,.28,1.75,.25));
function nat20Bit(R,out,q,C){
  const i=1,o=out.bits[i],u=C.u,lq=(q-.1)/1.0;
  focusOn(R,i,env(q,-.15,.35,1.05,.45),[232,190,120],{swell:1.6});
  const tr=R.mem.loop??=[];
  if(lq>0&&lq<1){const ph=TAU*ease(lq),r=.2*u;o.x+=Math.sin(ph)*r*.85;o.y+=-(1-Math.cos(ph))*r;o.spin+=ph;R.deco[i].top=true;
    const top=bump(unit((lq-.3)/.4));glowOn(R,i,[214,170,96],.35+.35*top,16);R.mem.loopTop=top;
    const b=C.bits[i];if(b){tr.push(b.x0+Math.sin(ph)*r*.85,b.y0-(1-Math.cos(ph))*r);if(tr.length>18)tr.splice(0,2);}}
  else{R.mem.loopTop=0;if(tr.length)tr.splice(0,2);}
}
function nat1Bit(R,out,q,C){
  const i=2,o=out.bits[i],N1D=3.2;if(q<-.2||q>N1D+.2)return;
  const fk=env(q,-.1,.3,N1D-.45,.5);focusOn(R,i,fk*(1-.35*hideK(q)),[196,160,240],{swell:1.6});
  if(q<0)return;
  const flinch=q<.22?Math.sin(q*58)*(1-q/.22):0;
  const inn=ease((q-.14)/.36),home=ease((q-N1D+.55)/.55),k=inn*(1-home);
  const peek=env(q,1.05,.28,1.75,.25)+.7*env(q,2.02,.2,2.28,.2);
  // in behind her left wing (her frame, token sizes), peek out past its edge, home
  const tx=lerp(-.5,-1.1,peek),ty=lerp(.26,.18,peek)+.015*Math.sin(q*3);
  const tremble=k*(1-peek)*Math.sin(q*31)*.6*C.size/100;
  o.mix=Math.max(o.mix,k);o.local=true;o.tx=tx;o.ty=ty;
  o.x+=flinch*3*C.size/100+tremble;o.y-=flinch*2*C.size/100;
  o.dim=Math.max(o.dim,.5*k*(1-peek));
  // in front (outline and all, as the lab's focus draws it) except while it hides behind her wing
  R.deco[i].behind=k>.15&&peek<.45;R.deco[i].top=!R.deco[i].behind;
  const b=C.bits[i],h=b?Math.atan2(C.cy-b.y,C.cx-b.x):0;
  o.spin=o.spin*(1-k)+k*(aim(C,i,h)*(1-peek)+aim(C,i,Math.PI+.25)*peek);
  glowOn(R,i,[180,140,236],.16+.12*k+.28*peek*k,15);
}

/* ---------------- an ally's turn ---------------- */
function watchFeel(m,out,t,C){const a=C.ally(m.ally);if(!a)return;const end=m.end??1e9,e=env(t-m.at,.1,.5,end-m.at,.6);out.bank+=.025*e*Math.sign(a.x-C.cx);}
function watchBit(R,m,out,t,C){
  const a=C.ally(m.ally);if(!a)return;
  if(m.near==null){let best=-1,bd=1e9;for(let i=0;i<4;i++){const b=C.bits[i];if(!b)continue;const d=Math.hypot(b.x0-a.x,b.y0-a.y);if(d<bd){bd=d;best=i;}}if(best<0)return;m.near=best;}
  const i=m.near,o=out.bits[i],b=C.bits[i];if(!b)return;
  const q=t-m.at,end=m.end==null?1e9:m.end-m.at,e=env(q,.15,.6,end,.7);if(e<=0)return;
  const ang=Math.atan2(a.y-b.y0,a.x-b.x0),turn=smooth((q-.25)/.5)*(1-smooth((q-end)/.55)),nod=bump(unit((q-1.0)/.5)),lean=(14+7*nod)*e*C.size/100;
  o.x+=Math.cos(ang)*lean;o.y+=Math.sin(ang)*lean;R.deco[i].top=true;
  o.spin=o.spin*(1-turn)+aim(C,i,ang)*turn;
  focusOn(R,i,e,[255,150,236]);glowOn(R,i,[255,140,236],.16*e+.22*nod,14);
  m.glint=turn*(.35+.55*nod+.12*Math.sin(q*2.4));m.ang=ang;m.nod=nod;m.e=e;
}


/* ---------------- grapple escape ---------------- */
const heave=q=>{const x=q-.3;return x<0?0:.5+.5*Math.sin(x*TAU/.62-Math.PI/2);};
function tension(m,q){let k=smooth(q/.3)*(.55+.32*heave(q));
  if(m.ok){if(q>=GA.resolve)return 0;return Math.max(k,smooth((q-.95)/.22)*1.18);}
  const hard=env(q,GA.hard,.18,GA.sag-.1,.4);k=k*(1-smooth((q-GA.hard)/.3))+1.3*hard;return k*(1-smooth((q-GA.sag)/.6));}
const gSag=(m,q)=>m.ok||m.noFail?0:smooth((q-GA.sag)/.45);
const gRelease=(m,q)=>m.ok?0:smooth((q-GA.fade)/.8);
const gAttempt=(m,q)=>m.ok?env(q,0,.3,GA.resolve,.12):env(q,0,.3,GA.sag,1.2);
const gThreadA=(m,q)=>m.ok?(q<GA.resolve?1:0):m.noFail?1-smooth((q-GA.hard)/.4):1-smooth((q-GA.fade)/1.0);
function escapeFeel(R,m,out,q,C){
  const P=R.parts,T=tension(m,q),k=gAttempt(m,q),sg=gSag(m,q),sz=C.size/100;
  if(P?.grStrain!==false&&k>0){
    out.widthMul*=1-.2*k+.05*sg;out.beatRate*=1-.4*k+.3*T*k;out.flex=Math.min(1,out.flex+.35*k);
    const g=C.ally(m.grappler);if(g){const dx=g.x-C.x,dy=g.y-C.y,d=Math.hypot(dx,dy)||1,pull=(k*(3+2*T)+2*sg)*sz;out.dx+=dx/d*pull;out.dy+=dy/d*pull+3*sg*sz;}
    out.bank+=-.04*k+.04*T*k;
  }
  if(m.ok&&q>=GA.resolve){const r=q-GA.resolve,s=Math.exp(-r*2.6)*Math.sin(r*9)*smooth(r/.05);out.widthMul*=1+.12*s;const lift=bump(unit(r/.9));out.lift-=9*lift*sz;out.beatRate*=1+.9*lift;}
}
/** Anchor on the grappler's rim for bit i (map px). */
function gAnchor(m,i,C,g){const base=Math.atan2(C.y-g.y,C.x-g.x),a=base+[-.5,.15,-.18,.48][i],r=.92*(g.r||50);return {x:g.x+Math.cos(a)*r,y:g.y+Math.sin(a)*r,a};}
/** The bits' spring home after the snap (lab: ω 7.2, ζ .27, from 1 with velocity −5). */
const SN_W=7.2,SN_Z=.27,SN_D=SN_W*Math.sqrt(1-SN_Z*SN_Z),SN_B=(-5+SN_Z*SN_W)/SN_D;
const snapSpring=r=>Math.exp(-SN_Z*SN_W*r)*(Math.cos(SN_D*r)+SN_B*Math.sin(SN_D*r));
function escapeBits(R,m,out,q,C){
  const g=C.ally(m.grappler);if(!g)return;
  const T=tension(m,q),sg=gSag(m,q),rel=gRelease(m,q),live=!m.ok||q<GA.resolve,sz=C.size/100,mem=m.last??=[null,null,null,null];
  for(let i=0;i<4;i++){const o=out.bits[i],b=C.bits[i];if(!b)continue;
    const A=gAnchor(m,i,C,g),dir=Math.atan2(b.y0-A.y,b.x0-A.x);
    const on=(live&&R.parts?.grStrain!==false?smooth((q-.1-i*.04)/.3)*(1-rel):0)*(m.noFail?1-smooth((q-GA.hard)/.4):1);let ox=0,oy=0;
    if(on>0){const tr=T*(.7+.9*T)*Math.sin(C.t*(31+i*3.7)+i)*(.6+.4*Math.sin(C.t*7+i)),lean=on*(2+7*T)*(1-sg);
      ox=(Math.cos(dir)*lean-Math.sin(dir)*tr*.6)*sz;oy=(Math.sin(dir)*lean+Math.cos(dir)*tr*.6)*sz;
      oy+=sg*(6+i%2*2)*(1-rel)*sz;ox+=sg*(C.cx-b.x0)*.1*(1-rel);
      o.spin=lerp(o.spin,aim(C,i,dir),on*(1-.65*sg));if(sg>0)o.dim=Math.max(o.dim,.3*sg*(1-rel));}
    if(m.ok&&q>=GA.resolve&&R.parts?.grSnap!==false){
      // the bits spring home with weight (a damped spring from where they strained)
      const r=q-GA.resolve,n=snapSpring(r);const L=mem[i];if(L){ox=L[0]*n;oy=L[1]*n;}
      const kick=Math.exp(-r*3)*smooth(r/.04);glowOn(R,i,[255,170,240],.4*kick,15);
    }else mem[i]=[ox,oy];
    o.x+=ox;o.y+=oy;R.deco[i].top=on>.02;
    if(R.parts?.grThreads!==false){const fk=m.ok?smooth(q/.3)*(1-smooth((q-GA.resolve-.5)/.9)):smooth(q/.3)*(1-smooth((q-GA.fade)/.9));
      focusOn(R,i,fk*(1-.3*sg),[255,150,236],{glow:.8+.6*T,core:8});if(live)glowOn(R,i,[255,120,236],(.12+.22*T*(1-sg))*(1-rel),12);}
  }
}

/* ---------------- Last light ---------------- */
function lastAlt(m,q){
  const A0=m.alt;if(q<KO)return A0;
  const caught=Math.max(1.5,A0-.5*G*CATCH*CATCH);
  if(q<CATCH)return Math.max(caught,A0-.5*G*q*q);
  const r=q-CATCH;
  if(r<.32)return caught-GIVE*Math.sin(r/.32*Math.PI/2);
  if(r<.85)return caught-GIVE+1.0*smooth((r-.32)/.53);
  if(q<HELD)return caught-GIVE+1.0+.06*Math.sin((r-.85)*14)*(1-smooth((r-.85)/.5));
  const from=caught-GIVE+1.0,k=(q-HELD)/(DOWN1-HELD);return Math.max(0,from*(1-smooth(k)));
}
const strainAt=q=>{const r=q-CATCH;return r<0?0:smooth(r/.07)*(1-.55*smooth((r-.3)/.5))*(1-smooth((r-1.05)/.6));};
function catchJolt(q){const r=q-CATCH;if(r<=0||r>=.62)return 0;
  if(r<.10)return JOLT_PX*Math.sin(r/.10*Math.PI/2);
  if(r<.34)return JOLT_PX+(-JOLT_PX*JOLT_BACK-JOLT_PX)*(1-Math.cos((r-.10)/.24*Math.PI))/2;
  return -JOLT_PX*JOLT_BACK*(1+Math.cos((r-.34)/.28*Math.PI))/2;}
const CATCH_PTS=[[-.64,.1],[.64,.1],[-.38,.6],[.38,.6]],VIGIL=[[-.74,-.22],[.74,-.22],[-.56,.52],[.56,.52]];
/** Before stepFeel: she is carried, her height set (lab input hook). */
export function healInput(R,input,f,C){
  const m=R.moments.find(x=>x.kind==='last');if(!m||!R.parts?.lastCatch)return input;
  const q=C.t-m.at;if(q>DOWN1+.2)return input;
  const a=lastAlt(m,q),a2=lastAlt(m,q+1/60);
  if(R.parts.lastLower===false&&q>HELD){return input;}
  input.altitude=a;input.airborne=q<DOWN1;input.unconscious=false;
  f.alt=a;f.altV=(a2-a)*60;f.falling=false;f.climbPrep=-1;f.climbPath=null;
  return input;
}
function lastFeel(R,m,out,q,C){
  const P=R.parts,ko=smooth((q-KO)/.25),sz=C.size/100;
  out.beatRate*=1-.97*ko;out.flex*=1-ko;out.wingAlpha*=1-.42*ko;
  const sw=bump(unit((q-CATCH)/.9));
  out.bank+=ko*(.05*Math.sin((q-KO)*1.3)*(1-smooth((q-DOWN1+.5)/.6)))-.045*sw;
  const jolt=P?.lastCatch?catchJolt(q):0;out.dy+=jolt*sz;
  const bitsK=smooth((q-KO-.05)/(CATCH-KO-.08)),strain=strainAt(q),vig=P?.lastVigil!==false?smooth((q-DOWN1-.15)/.9):0;
  const fadeV=m.vigil?1-smooth((q-DOWN1-VIGIL_HOLD+1)/1):1-smooth((q-DOWN1-.2)/.8);
  for(let i=0;i<4;i++){const o=out.bits[i],k=(q<DOWN1+.2?bitsK:1)*(P?.lastCatch?1:0)*(vig>0?fadeV:1);
    if(k<=0)continue;
    const tx=lerp(CATCH_PTS[i][0],VIGIL[i][0],vig),ty=lerp(CATCH_PTS[i][1],VIGIL[i][1],vig),sh=strain*.012*Math.sin(C.t*47+i*2.1);
    const give=(BIT_SIDE[i][1]>0?.5:.6)*jolt;
    o.mix=k;o.tx=tx-BIT_SIDE[i][0]*.035*strain+sh;o.ty=ty+.07*strain-(jolt-give)/100;o.local=true;
    o.spin=(o.spin||0)+k*(BIT_SIDE[i][0]*.5)*(1-vig)+vig*BIT_SIDE[i][0]*.2+strain*.18*Math.sin(C.t*39+i);
  }
  R.mem.lastStrain=Math.min(1,strain+.35*Math.max(0,jolt)/JOLT_PX);
}
function lastBits(R,m,out,q,C){
  const P=R.parts;if(!P?.lastCatch)return;
  const strain=strainAt(q),hold=env(q,CATCH-.05,.2,DOWN1,.8),v=P.lastVigil!==false?smooth((q-DOWN1-.3)/1):0,dive=smooth((q-KO)/.5);
  const fadeV=m.vigil?1-smooth((q-DOWN1-VIGIL_HOLD+1)/1):1-smooth((q-DOWN1-.2)/.8);
  for(let i=0;i<4;i++){const o=out.bits[i],breathe=.5+.5*Math.sin(C.t*1.6+i*1.3);
    R.deco[i].top=q>KO;
    focusOn(R,i,dive*(.75+.25*strain)*(1-.2*v)*fadeV,[232,186,112],{swell:1.45+.2*strain,glow:.8+.7*strain,rim:1+.6*strain});
    if(q>KO&&q<CATCH)glowOn(R,i,[255,140,236],.28,13);else glowOn(R,i,[214,170,96],(.22*hold+.32*strain+v*(.14+.08*breathe))*fadeV,14+5*strain);
    if(v>0){const b=C.bits[i];if(b){o.spin=o.spin*(1-v)+aim(C,i,Math.atan2(C.cy-b.y,C.cx-b.x)+Math.PI)*v;}o.y+=v*1.2*Math.sin(C.t*1.3+i*1.7)*C.size/100;}
  }
}

/* =====================================================================
 * The frame: everything above, once per frame.
 * ===================================================================== */
/** C: {t, dt, cx, cy, u, size, x, y, angle, bits:[{x,y,x0,y0}|null]×4, painted:[4], ally(id)→{x,y,r,hp}|null, frameMode, bitsShown} */
export function healFeel(R,out,C){
  const t=C.t,dt=C.dt??1/60,size=C.size??C.u;resetDeco(R);
  const P=R.parts??{};
  // grabbed, quiet: at most a very slight narrowing of her wings (off by default)
  if(R.grabbedAt!=null&&P.grappleNarrow)out.widthMul*=1-.045*smooth((t-R.grabbedAt)/.6);
  for(const m of R.moments){const q=t-m.at;
    switch(m.kind){
      case 'trad':tradFeel(m,out,q,size);if(C.bitsShown)tradBits(R,m,out,q,t,size);break;
      case 'hero':if(P.heroWings!==false)heroFeel(out,q,size);if(C.bitsShown&&P.heroBits!==false)heroBits(R,out,q,C);break;
      case 'nat20':nat20Feel(out,q);if(C.bitsShown)nat20Bit(R,out,q,C);break;
      case 'nat1':nat1Feel(out,q);if(C.bitsShown)nat1Bit(R,out,q,C);break;
      case 'watch':watchFeel(m,out,t,C);if(C.bitsShown)watchBit(R,m,out,t,C);break;
      case 'escape':escapeFeel(R,m,out,q,C);if(C.bitsShown)escapeBits(R,m,out,q,C);break;
      case 'last':lastFeel(R,m,out,q,C);if(C.bitsShown)lastBits(R,m,out,q,C);break;
    }
  }
  // a bit that is the subject of a moment is redrawn on top by the overlay (outline and all): its own mesh hides
  for(let i=0;i<4;i++){const d=R.deco[i],o=out.bits[i];o.v11scale=d.scale;o.v11alpha=bitOnTop(R,i)?0:d.alpha;}
}
/** Clear what healFeel wrote on the bits (scale/alpha) when nothing plays. */
export function clearHealBits(out){for(const o of out?.bits??[]){if(o.v11scale!==undefined)o.v11scale=1;if(o.v11alpha!==undefined)o.v11alpha=1;}}

/** The wing painter's state for this frame (heal-wing.mjs), or null when there is nothing to draw. */
export function healWing(R,C){
  const W=R.wing,P=R.parts??{},t=C.t;let n=0;
  const op=(k)=>{let o=R.opsPool[n];if(!o)o=R.opsPool[n]={};for(const key in o)delete o[key];o.k=k;W.ops[n++]=o;return o;};
  for(const m of R.moments){const s=t-m.at;
    switch(m.kind){
      case 'trad':if(s<=SPELL_SPAN+.2&&P['sp'+m.trad[0].toUpperCase()+m.trad.slice(1)]!==false){const o=op(m.trad);o.s=+s.toFixed(4);}break;
      case 'hero':if(s<=2.05&&P.heroWings!==false){const o=op('hero');o.s=+s.toFixed(4);}break;
      case 'escape':{const k=R.parts?.grStrain!==false?gAttempt(m,s):0,sg=gSag(m,s),rel=gRelease(m,s);if(k>.002||sg>.002){const o=op('strain');o.tip=+(.22*k).toFixed(3);o.fold=+(.08*k+.08*sg*(1-rel)).toFixed(3);}break;}
    }
  }
  W.ops.length=n;W.anim=n>0;
  return n?W:null;
}

/* =====================================================================
 * Map-space painting (the overlay): pure Canvas 2D in map pixels.
 * ===================================================================== */
function thread(g,pts,w,a,tint,bloom=1){
  if(pts.length<2||a<.01)return;
  g.save();g.lineCap='round';g.lineJoin='round';g.globalCompositeOperation='lighter';
  g.beginPath();for(let i=0;i<pts.length;i++){const p=pts[i];if(i)g.lineTo(p.x,p.y);else g.moveTo(p.x,p.y);}
  g.lineWidth=w*5;g.strokeStyle=rgba(tint.bloom,.10*a*bloom);g.stroke();
  g.lineWidth=w*2.2;g.strokeStyle=rgba(tint.bloom,.36*a);g.stroke();
  g.globalCompositeOperation='source-over';g.lineWidth=w;g.strokeStyle=rgba(tint.core,.95*a);g.stroke();
  g.restore();
}
function glowDot(g,x,y,r,a,tint){if(a<.01||!(r>0))return;g.save();g.globalCompositeOperation='lighter';const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(tint.core,a));gr.addColorStop(.25,rgba(tint.bloom,a*.5));gr.addColorStop(1,rgba(tint.bloom,0));g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2);g.restore();}
function glint(g,x,y,r,a,core,bloom,rot=0){if(a<.01)return;g.save();g.globalCompositeOperation='lighter';const gr=g.createRadialGradient(x,y,0,x,y,r*3.4);gr.addColorStop(0,rgba(bloom,.5*a));gr.addColorStop(1,rgba(bloom,0));g.fillStyle=gr;g.fillRect(x-r*3.4,y-r*3.4,r*6.8,r*6.8);
  g.translate(x,y);g.rotate(rot);g.fillStyle=rgba(core,a);g.beginPath();g.moveTo(0,-r*2.2);g.lineTo(r*.32,0);g.lineTo(0,r*2.2);g.lineTo(-r*.32,0);g.closePath();g.fill();
  g.beginPath();g.moveTo(-r*1.3,0);g.lineTo(0,r*.22);g.lineTo(r*1.3,0);g.lineTo(0,-r*.22);g.closePath();g.fill();g.restore();}
const GOLD=PAL.gold;

/** Her heart (wings) or the frame's drop finial (wingless). */
const heartOf=C=>C.frameMode?{x:C.cx,y:C.cy+C.R*1.04}:{x:C.cx+3*C.size/100,y:C.cy+C.u*.34};

function stroke(g,pts,w,a,tint,glow=1){
  if(pts.length<2||a<.01)return;
  g.save();g.lineCap='round';g.lineJoin='round';g.globalCompositeOperation='lighter';
  g.beginPath();for(let i=0;i<pts.length;i++){const p=pts[i];if(i)g.lineTo(p[0],p[1]);else g.moveTo(p[0],p[1]);}
  g.lineWidth=w*4.6;g.strokeStyle=rgba(tint.bloom,.10*a*glow);g.stroke();
  g.lineWidth=w*2.1;g.strokeStyle=rgba(tint.bloom,.34*a*glow);g.stroke();
  g.lineWidth=w;g.strokeStyle=rgba(tint.core,.92*a);g.stroke();g.restore();
}

/* ---------------- grapple threads ---------------- */
const TETHER={bloom:[255,70,220],core:[255,168,240]},MAGB={bloom:[255,96,236],core:[255,222,252]},GOLDG={bloom:[214,170,96],core:[255,226,164]};
function paintEscape(g,R,m,C,q){
  const gr=C.ally(m.grappler);if(!gr||R.parts?.grThreads===false)return;
  if(C.frameMode||!C.bitsShown)return paintEscapeFrame(g,R,m,C,q,gr);
  const T=tension(m,q),sg=gSag(m,q),fa=gThreadA(m,q);
  // the threads run under her token (the lab draws them beneath her): keep them off her portrait
  g.save();g.beginPath();g.rect(Math.min(C.cx,gr.x)-3*C.u-gr.r,Math.min(C.cy,gr.y)-3*C.u-gr.r,Math.abs(gr.x-C.cx)+6*C.u+2*gr.r,Math.abs(gr.y-C.cy)+6*C.u+2*gr.r);g.arc(C.cx,C.cy,C.u*.5,0,TAU,true);g.clip('evenodd');
  for(let i=0;i<4;i++){const b=C.bits[i];if(!b)continue;const A=gAnchor(m,i,C,gr),ax=A.x,ay=A.y;
    const shoot=easeOut((q-.04-i*.05)/GA.shoot);if(shoot<=0)continue;
    if(!m.ok||q<GA.resolve){
      if(fa<.01)continue;
      const reach=m.ok?shoot:shoot*(1-easeOut((q-GA.fade)/1.0));
      const L=Math.hypot(b.x-ax,b.y-ay)||1,nx=-(b.y-ay)/L,ny=(b.x-ax)/L,pts=[],hum=.5*T*Math.sin(C.t*(44+i*5)),slack=sg*(16+i*3);
      for(let j=0;j<=24;j++){const u=j/24;if(u>reach)break;const w=Math.sin(Math.PI*u);pts.push([b.x+(ax-b.x)*u+nx*hum*w*Math.sin(u*TAU),b.y+(ay-b.y)*u+ny*hum*w*Math.sin(u*TAU)+slack*w]);}
      if(pts.length>1&&reach<1){const u=reach,w=Math.sin(Math.PI*u);pts.push([b.x+(ax-b.x)*u,b.y+(ay-b.y)*u+slack*w]);}
      stroke(g,pts,.75+.35*T*(1-sg),(.42+.4*Math.min(1.2,T))*(1-.45*sg)*fa,TETHER,.7+.6*T);
      if(shoot>=1&&reach>.98)glint(g,ax,ay,1.1+.5*T,(.5+.4*T)*(1-.6*sg)*fa,GOLDG.core,GOLDG.bloom,A.a+Math.PI/4);
      if(reach<.98&&reach>.02){const p=pts[pts.length-1];glowDot(g,p[0],p[1],5,.5*fa,TETHER);}
    }else if(R.parts?.grSnap!==false){
      const r=q-GA.resolve;if(r>.7)continue;const k=easeOut(r/.45),fade=1-smooth(r/.6),brk=.55+.08*Math.sin(i*2.1);
      const half=(from,to,f0,f1,curl)=>{const pts=[];const L2=Math.hypot(to.x-from.x,to.y-from.y)||1,nx=-(to.y-from.y)/L2,ny=(to.x-from.x)/L2;for(let j=0;j<=12;j++){const u=f0+(f1-f0)*j/12,w=(u-f0)/(f1-f0||1);pts.push([from.x+(to.x-from.x)*u+nx*curl*w*w,from.y+(to.y-from.y)*u+ny*curl*w*w]);}return pts;};
      const B={x:b.x,y:b.y},Aa={x:ax,y:ay};
      stroke(g,half(B,Aa,0,brk*(1-k),9*k*(i%2?1:-1)),1.1,fade,TETHER,1.3);
      stroke(g,half(Aa,B,0,(1-brk)*(1-k),7*k*(i%2?-1:1)),1,fade*.8,TETHER,1);
      glowDot(g,lerp(b.x,ax,brk),lerp(b.y,ay,brk),6,.7*(1-smooth(r/.25)),MAGB);
    }
  }
  g.restore();
}
function gthread(g,pts,w,a,tint,bloom=1.2){thread(g,pts,w,a,tint,bloom);}
const WGA={shoot:.28,resolve:1.25,hard:1.05,sag:1.5,gone:2.9};
function paintEscapeFrame(g,R,m,C,q,gr){
  const R0=C.R,s=m.ok?smooth((q-.25)/.3)*(1-smooth((q-WGA.resolve)/.08)):smooth((q-.25)/.3)*(1+.5*smooth((q-WGA.hard)/.15))*(1-smooth((q-WGA.sag)/.6));
  const bd=Math.atan2(gr.y-C.cy,gr.x-C.cx);m.dir=bd;
  for(let j=0;j<3;j++){const a=bd+(j-1)*.78,A={x:C.cx+Math.cos(a)*(R0-1),y:C.cy+Math.sin(a)*(R0-1)};
    const ga=Math.atan2(gr.y-C.cy,gr.x-C.cx)-(j-1)*.42,Bx=gr.x-Math.cos(ga)*gr.r*.92,By=gr.y-Math.sin(ga)*gr.r*.92;
    const head=easeOut(q/WGA.shoot),tr=Math.sin(C.t*38+j*2)*1.2*s;let sag=6*(1-s)+2,u1=head,a0=1,brk=null;
    if(!m.ok){const sg=smooth((q-WGA.sag)/.9);sag+=22*sg;u1=head*(1-easeOut((q-WGA.sag-.25)/1.15));a0=1-smooth((q-WGA.gone+.7)/.7);}
    else if(q>WGA.resolve)brk=q-WGA.resolve;
    const mx=(A.x+Bx)/2,my=(A.y+By)/2+sag,pt=u=>{const k=1-u;return {x:k*k*A.x+2*k*u*mx+u*u*Bx,y:k*k*A.y+2*k*u*my+u*u*By};};
    const dx=Bx-A.x,dy=By-A.y,d=Math.hypot(dx,dy)||1,nrm=[-dy/d,dx/d];
    const run=(f0,f1,alpha,w=1,curl=0,from=0)=>{if(f1<=f0+.005)return;const pts=[];for(let i=0;i<=24;i++){const u=f0+(f1-f0)*i/24,p=pt(u),w2=Math.sin(u*Math.PI)*tr+curl*Math.sin((u-from)*9)*Math.abs(u-from);pts.push({x:p.x+nrm[0]*w2,y:p.y+nrm[1]*w2});}gthread(g,pts,w*(1+.35*s),alpha,TETHER,1.1);};
    const hard=!m.ok?smooth((q-WGA.hard)/.15)*(1-smooth((q-WGA.sag)/.4)):0;
    if(brk==null){run(0,u1,(.75+.25*s+.2*hard)*a0);if(head<1){const p=pt(head);glowDot(g,p.x,p.y,5,.8,TETHER);}}
    else{if(brk>.9)continue;const k=easeOut(brk/.38),f=1-smooth((brk-.1)/.45),B0=.55;run(0,B0*(1-k),f,1,6*k,0);run(B0+(1-B0)*k,1,f*.8,1,-5*k,1);
      const p=pt(B0);glowDot(g,p.x,p.y,7,.7*bump(unit(brk/.3)),TETHER);if(j===1)glint(g,p.x,p.y,1.4,bump(unit(brk/.35)),TETHER.core,TETHER.bloom);}
    glowDot(g,A.x,A.y,4.5,(.5+.3*s)*a0*(brk==null?1:1-smooth(brk/.5)),TETHER);
  }
}

/* ---------------- Last light: the gold support threads ---------------- */
function paintLast(g,R,m,C,q){
  if(!R.parts?.lastCatch||!C.bitsShown)return;
  const a=env(q,CATCH-.03,.1,DOWN1-.1,.6);if(a<.01)return;
  const strain=R.mem.lastStrain??strainAt(q),u=C.u;
  for(let i=0;i<4;i++){const b=C.bits[i];if(!b)continue;const dx=C.cx-b.x,dy=C.cy-b.y,d=Math.hypot(dx,dy),Rr=u*.47;if(d<Rr+3)continue;
    const ex=C.cx-dx/d*Rr,ey=C.cy-dy/d*Rr,sh=Math.sin(C.t*2.6+i*1.7)*1.6*(1-strain);
    const mid={x:(b.x+ex)/2-dy/d*sh,y:(b.y+ey)/2+dx/d*sh};
    thread(g,[{x:b.x,y:b.y},mid,{x:ex,y:ey}],1+.5*strain,(.62+.38*strain)*a,GOLD,.9+.6*strain);
    glowDot(g,ex,ey,4+3*strain,(.25+.45*strain)*a,GOLD);
  }
}

/* ---------------- small marks: the watch glint, the nat 20 wake, the Hero heart ---------------- */
function paintWatch(g,R,m,C){
  const i=m.near;if(i==null||!m.glint||m.glint<.01)return;const b=C.bits[i];if(!b)return;
  const sw=1+.55*(m.e??0),tx=b.x+Math.cos(m.ang)*6.5*sw*C.size/100,ty=b.y+Math.sin(m.ang)*6.5*sw*C.size/100,gl=m.glint;
  g.save();g.globalCompositeOperation='lighter';
  const gr=g.createRadialGradient(tx,ty,0,tx,ty,7);gr.addColorStop(0,`rgba(255,200,246,${.5*gl})`);gr.addColorStop(1,'rgba(255,120,236,0)');g.fillStyle=gr;g.fillRect(tx-7,ty-7,14,14);
  g.translate(tx,ty);g.rotate(m.ang);const r=1.5+.6*(m.nod??0);g.fillStyle=`rgba(255,222,252,${.85*gl})`;
  g.beginPath();g.moveTo(-r*1.2,0);g.lineTo(0,-r*.45);g.lineTo(r*3.2,0);g.lineTo(0,r*.45);g.closePath();g.fill();
  g.beginPath();g.moveTo(0,-r*1.5);g.lineTo(r*.3,0);g.lineTo(0,r*1.5);g.lineTo(-r*.3,0);g.closePath();g.fill();
  g.restore();
}
function paintLoop(g,R,C){
  const tr=R.mem.loop;if(!tr||tr.length<4)return;const n=tr.length/2;
  g.save();g.globalCompositeOperation='lighter';g.lineCap='round';
  for(let j=1;j<n;j++){const f=j/n;g.strokeStyle=`rgba(232,196,128,${.55*f})`;g.lineWidth=.6+1.8*f;g.beginPath();g.moveTo(tr[2*j-2],tr[2*j-1]);g.lineTo(tr[2*j],tr[2*j+1]);g.stroke();}
  const top=R.mem.loopTop??0,b=C.bits[1];
  if(top>.05&&b){const x=b.x,y=b.y-9,r=3.4*top;g.fillStyle=`rgba(255,226,164,${.9*top})`;g.beginPath();g.moveTo(x,y-r*2);g.lineTo(x+r*.35,y);g.lineTo(x,y+r*2);g.lineTo(x-r*.35,y);g.closePath();g.fill();g.beginPath();g.moveTo(x-r*1.4,y);g.lineTo(x,y+r*.3);g.lineTo(x+r*1.4,y);g.lineTo(x,y-r*.3);g.closePath();g.fill();}
  g.restore();
}
function paintHeroHeart(g,m,C,q){if(q<0||q>2)return;const k=hpHold(q)+.35*hpIn(q)*(1-smooth((q-.5)/.2));const h=heartOf(C);glowDot(g,h.x-1,h.y-C.u*.04,12+5*hpHold(q),.6*k,PAL.rosegold);}

/* ---------------- bits: the focus treatment and glows (clab drawBit) ---------------- */
const SIL=new Map();
function silhouette(src,color,make,ver=null,slot=0){
  // (test.3) one outline per bit and colour, redrawn only when that bit's picture changes (it was redrawn every frame)
  const key=color+'|'+slot;let c=SIL.get(key);if(!c){c=make?make():null;if(!c)return null;SIL.set(key,c);}
  if(ver!=null&&c._src===src&&c._ver===ver&&c.width===src.width&&c.height===src.height)return c;c._src=src;c._ver=ver;
  if(c.width!==src.width||c.height!==src.height){c.width=src.width;c.height=src.height;}
  const x=c.getContext('2d');x.globalCompositeOperation='source-over';x.clearRect(0,0,c.width,c.height);x.drawImage(src,0,0);
  x.globalCompositeOperation='source-in';x.fillStyle=color;x.fillRect(0,0,c.width,c.height);x.globalCompositeOperation='source-over';return c;
}
const OFFS=[[1,0],[-1,0],[0,1],[0,-1],[.7,.7],[-.7,.7],[.7,-.7],[-.7,-.7]];
/** One bit's decoration in front of everything (it is redrawn on top when it is the subject of a moment). */
function paintBitDeco(g,d,b,C,make){
  const F=d.focus,fk=F?unit(F.k):0,alt=C.u/100;
  if(fk>.005){
    const col=F.tint,R=(F.core??9)*alt*(.6+.4*fk),vis=b.alpha??1;
    g.save();g.globalCompositeOperation='lighter';const gr=g.createRadialGradient(b.x,b.y,0,b.x,b.y,R);
    gr.addColorStop(0,rgba(col,.5*fk*vis*(F.glow??1)));gr.addColorStop(.45,rgba(col,.16*fk*vis*(F.glow??1)));gr.addColorStop(1,rgba(col,0));
    g.fillStyle=gr;g.fillRect(b.x-R,b.y-R,R*2,R*2);g.restore();
    if(b.surface&&!d.behind&&make){const bw=b.w*d.scale;
      const sil=(color,a,grow,mode)=>{if(a<.01)return;const c2=silhouette(b.surface,color,make,b.ver??null,b.slot??0);if(!c2)return;g.save();g.globalCompositeOperation=mode;g.globalAlpha=a*(C.fxA??1);g.translate(b.x,b.y);g.rotate(b.angle);
        for(const [dx,dy] of OFFS)g.drawImage(c2,-bw*grow/2+dx*grow*.9,-bw*grow/2+dy*grow*.9,bw*grow,bw*grow);g.restore();};
      sil('rgb(22,6,20)',.55*fk*vis,1.0,'source-over');
      sil(`rgb(${col[0]},${col[1]},${col[2]})`,.42*fk*vis*(F.rim??1),1.06,'lighter');
      // the bit itself over its outline (its mesh is hidden underneath while it is drawn here)
      g.save();g.globalAlpha=Math.min(1,vis)*(C.fxA??1);g.translate(b.x,b.y);g.rotate(b.angle);g.drawImage(b.surface,-bw/2,-bw/2,bw,bw);g.restore();
    }
  }
  if(d.glow){const {c,a,rad}=d.glow,R=(rad??14)*alt;if(a>.005){g.save();g.globalCompositeOperation='lighter';const gr=g.createRadialGradient(b.x,b.y,0,b.x,b.y,R);
    gr.addColorStop(0,rgba(c,a));gr.addColorStop(.35,rgba(c,a*.35));gr.addColorStop(1,rgba(c,0));g.fillStyle=gr;g.fillRect(b.x-R,b.y-R,R*2,R*2);g.restore();}}
}
/** Which bits the overlay redraws on top (outline and all): they hide their own mesh this frame. */
export function bitOnTop(R,i){const d=R.deco[i];return !!(d.focus&&!d.behind&&d.focus.k>.005);}

/** Everything in map space for this frame. g: a 2D context in map pixels. C: as healFeel, with
 * bits[i] = {x,y,angle,w,alpha,surface} as placed this frame. make(): a scratch canvas (for outlines). */
export function paintHealOverlay(g,R,C,make=null){
  const t=C.t,parts=R.parts??{};
  for(const m of R.moments){const q=t-m.at;
    switch(m.kind){
      case 'escape':paintEscape(g,R,m,C,q);break;
      case 'last':paintLast(g,R,m,C,q);break;
      case 'hero':if(!C.frameMode&&parts.heroLight!==false)paintHeroHeart(g,m,C,q);break;
    }
  }
  if(C.bitsShown){
    for(const m of R.moments){if(m.kind==='nat20')paintLoop(g,R,C);else if(m.kind==='watch')paintWatch(g,R,m,C);}
    for(let i=0;i<4;i++){const b=C.bits[i];if(b)paintBitDeco(g,R.deco[i],b,C,make);}
  }
}
/** Does the overlay have anything to draw this frame? */
export function overlayWanted(R,C){
  for(const m of R.moments)if(m.kind==='escape'||m.kind==='last'||m.kind==='hero'||m.kind==='nat20'||m.kind==='watch')return true;
  for(const d of R.deco)if(d.glow||d.focus)return true;
  return false;
}
/** The rough box (map px) of what the overlay draws, for its canvas size: [x0,y0,x1,y1]. */
export function overlayBounds(R,C,out=[0,0,0,0]){
  let x0=C.cx-C.size*2.2,y0=C.cy-C.size*2.2,x1=C.cx+C.size*2.2,y1=C.cy+C.size*2.2;
  const grow=(x,y,r)=>{if(x-r<x0)x0=x-r;if(y-r<y0)y0=y-r;if(x+r>x1)x1=x+r;if(y+r>y1)y1=y+r;};
  for(const m of R.moments){const id=m.kind==='watch'?m.ally:m.kind==='escape'?m.grappler:null;if(id){const a=C.ally(id);if(a){grow(a.x,a.y,a.r*1.6+20);
    // the thread bows out to one side of the straight line: a quarter of the distance covers it
    const d=Math.hypot(a.x-C.cx,a.y-C.cy)*.3;grow((a.x+C.cx)/2,(a.y+C.cy)/2,d+Math.abs(a.x-C.cx)/2);grow((a.x+C.cx)/2,(a.y+C.cy)/2,d+Math.abs(a.y-C.cy)/2);}}}
  out[0]=x0;out[1]=y0;out[2]=x1;out[3]=y1;return out;
}

/* ---------------- wingless: the frame's own share (token layer Look slots) ---------------- */
/** What her frame shows for these moments (pure): writes rim arcs and beads through put(kind,...).
 * rim(col 0..1, a, ang, spread, mode) · bead(ang, col, a, r) · glow(kind, col, a). Returns true while moving. */
export function frameMoments(R,t,{rim,bead,glow,nudge=null}){
  let moving=false;const P=R.parts??{};
  for(const m of R.moments){const q=t-m.at;
    if(m.kind==='hero'&&q<2.4&&P.heroLight!==false){const g=hpIn(q),hold=hpHold(q),r=hpOut(q),cool=1-smooth((q-1.0)/.7);
      rim([.94,.59,.47],.42*g*cool,0,7,0);rim([1,.81,.69],.4*hold+.25*r*cool,-Math.PI/2,1.3,0);glow(2,[.96,.67,.55],.1*g*cool);moving=true;}
    if(m.kind==='escape'&&R.frameMode&&m.dir!=null&&nudge&&P.grStrain!==false){
      // wingless: her token pulls away from him and trembles (lab grappleFrame look)
      const s=m.ok?smooth((q-.25)/.3)*(1-smooth((q-WGA.resolve)/.08)):smooth((q-.25)/.3)*(1+.5*smooth((q-WGA.hard)/.15))*(1-smooth((q-WGA.sag)/.6)),tr=Math.sin(t*41)*Math.sin(t*23.7),ux=Math.cos(m.dir),uy=Math.sin(m.dir);
      let dx=-ux*.025*s+.006*s*tr,dy=-uy*.02*s;if(!m.ok)dy+=.03*bump(unit((q-WGA.sag)/1.6))*.5;if(m.ok&&q>WGA.resolve){const r=q-WGA.resolve;dx+=ux*.03*Math.exp(-r/.22)*Math.cos(r*TAU/.5);}
      if(Math.abs(dx)+Math.abs(dy)>1e-4){nudge(dx,dy);moving=true;}}
    if(m.kind==='escape'&&m.ok&&R.frameMode){const r=q-GA.resolve;if(r>0&&r<1){rim([.93,.63,.31],.32*bump(unit(r/.9)),-Math.PI*.75,.6,0);rim([.93,.63,.31],.32*bump(unit(r/.9)),-Math.PI*.25,.6,0);moving=true;}}
  }
  return moving;
}
