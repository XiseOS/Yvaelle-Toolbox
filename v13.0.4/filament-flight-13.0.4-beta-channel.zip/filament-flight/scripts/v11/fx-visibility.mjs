/** Yvaelle’s Toolbox v11 · What this client may see of her phase 3 effects.
 *
 * Phase 3a draws its map strokes (heal threads, the lent bit and its trail,
 * sigils, grapple threads, die moods, triage) on a screen overlay above the
 * board, which Foundry's fog of war and vision do not mask. So every one of
 * them asks here first:
 *  - tokenSeen(token): is this token drawn for this client right now? Foundry's
 *    own cached answer (Token#visible, refreshed with perception; reading
 *    isVisible would re-run the tests), never while it is only *detected* (a
 *    detection filter), and never a hidden token for a player;
 *  - pointSeen(x, y): is this map point inside this client's vision (for a lone
 *    bit away from her, the lent bit)? Without token vision (a GM, or a scene
 *    without it) everything is seen;
 *  - fxAlpha(token): her effects' share of light for this client: 0 when her
 *    token is not seen, else the invisibility veil's 'fx' share (0 for other
 *    players while she is invisible or cloaked, a faint trace for her owner's
 *    and the GM's ghost, following a drain or a sweep while it runs).
 * Each costs a few property reads (pointSeen: one visibility test). */
import {veilAlphaOf} from './invis-hooks.mjs?v=13.0.4';

export function tokenSeen(token){
  if(!token||token.destroyed)return false;
  const g=globalThis.game;
  if(token.document?.hidden&&!g?.user?.isGM)return false;
  if(token.visible===false||token.renderable===false||token.detectionFilter)return false;
  return true;
}
export function pointSeen(x,y){
  const v=globalThis.canvas?.visibility;
  if(!v||typeof v.testVisibility!=='function'||v.tokenVision===false)return true;
  try{return v.testVisibility({x,y},{tolerance:1,object:null})!==false;}catch{return true;}
}
export function fxAlpha(token){
  if(!tokenSeen(token))return 0;
  const a=veilAlphaOf(token,'fx');return a>0?Math.min(1,a):0;
}
/** A token by id, if this client sees it (else null). */
export function seenToken(id){
  if(!id)return null;const t=globalThis.canvas?.tokens?.get?.(id);return tokenSeen(t)?t:null;
}
