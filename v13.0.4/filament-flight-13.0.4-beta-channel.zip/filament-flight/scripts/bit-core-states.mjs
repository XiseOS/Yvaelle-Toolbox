/** Optional work states for the existing Resonant Core. The default is a
 * zero-offset sample, so its original articulated animation remains intact. */
import {captureScanMechanism} from './bit-scan-mechanism.mjs?v=13.0.4';

export const BIT_CORE_STATES=Object.freeze({idle:'Current animation',auto:'Action responsive',encased:'Crystal encased',open:'Open for work',charging:'Gather energy',guarding:'Guarding',settling:'Settle after work',scanning:'Diagnostic sweep',bracing:'Protective lock',aligning:'Precision alignment',resting:'Resting machinery',conducting:'Current conductor'});
const unit=n=>Math.max(0,Math.min(1,Number(n)||0));
const ease=n=>{n=unit(n);return n*n*(3-2*n);};
const REST=Object.freeze({id:'idle',amount:0,encase:0,open:0,charge:0,guard:0,settle:0,progress:0});
const WORK_STATES=Object.keys(BIT_CORE_STATES).filter(id=>!['idle','auto'].includes(id));
const STATE_CHANNELS=['encase','open','charge','guard','settle','scan','brace','align','rest','conduct'];
function activityWeights(input){
  if(!input||typeof input!=='object'||Array.isArray(input))return null;
  const weights={};let total=0;
  for(const id of WORK_STATES)if(Number.isFinite(input[id])&&input[id]>0){const value=unit(input[id]);weights[id]=value;total+=value;}
  if(!(total>0))return null;
  if(total>1)for(const id of Object.keys(weights))weights[id]/=total;
  return weights;
}
function activityChannels(input){
  if(!input||typeof input!=='object'||Array.isArray(input))return null;
  let known=false;for(const key of STATE_CHANNELS)if(Number.isFinite(input[key])){known=true;break;}if(!known)return null;
  const channels={};for(const key of STATE_CHANNELS)channels[key]=unit(input[key]);return channels;
}
/** Preserve a pure state blend when a gesture or formation is interrupted.
 * Only recognized, bounded channels survive a saved action/group capture. */
export function captureCoreActivity(activity){
  const state=activity?.state??activity?.id;if(!WORK_STATES.includes(state))return null;
  const out={state,amount:activity.amount==null?1:unit(activity.amount),progress:unit(activity.progress)},weights=activityWeights(activity.weights);
  if(weights)out.weights=weights;
  const channels=activityChannels(activity.coreChannels);if(channels)out.coreChannels=channels;
  if(Number.isFinite(activity.settleProgress))out.settleProgress=unit(activity.settleProgress);
  const examination=captureScanMechanism(activity.examination);if(examination)out.examination=examination;
  return out;
}
/** Mix mechanisms without selecting a different positive-strength state at
 * the middle of a count redistribution. Channels are relative to amount, so
 * an existing captured fade still attenuates the entire mechanism exactly. */
export function blendCoreActivities(entries=[]){
  const result={encase:0,open:0,charge:0,guard:0,settle:0,scan:0,brace:0,align:0,rest:0,conduct:0},weights={};let amount=0,progress=0,dominant=null,largest=0,examination=null,examinationGain=0,largestExamination=0;
  for(const entry of entries){
    const activity=captureCoreActivity(entry?.activity),weight=Number.isFinite(entry?.weight)?Math.max(0,entry.weight):0;if(!activity||!weight)continue;
    const gain=activity.amount*weight,state=sampleCoreState({activity});amount+=gain;progress+=activity.progress*gain;
    if(gain>largest){largest=gain;dominant=activity.state;}
    for(const key of STATE_CHANNELS)result[key]+=(state[key]??0)*weight;
    for(const [id,value]of Object.entries(activity.weights??{[activity.state]:1}))weights[id]=(weights[id]??0)+gain*value;
    if(activity.examination){const workGain=gain*activity.examination.weight;examinationGain+=workGain;
      if(workGain>largestExamination){largestExamination=workGain;examination=activity.examination;}}
  }
  if(!(amount>0))return null;
  for(const key of STATE_CHANNELS)result[key]/=amount;
  for(const id of Object.keys(weights))weights[id]/=amount;
  return {state:dominant,amount:unit(amount),progress:unit(progress/amount),weights,coreChannels:result,
    ...(examination?{examination:{...examination,weight:unit(examinationGain/amount)}}:{})};
}
function stateChannels(id,amount,progress){
  const settle=id==='settling'?amount*(1-ease(progress)):0;
  return {encase:id==='encased'?amount:0,open:id==='open'?amount:settle*.58,
    charge:id==='charging'?amount:settle*.45,guard:id==='guarding'?amount:0,settle,
    scan:id==='scanning'?amount:0,brace:id==='bracing'?amount:0,align:id==='aligning'?amount:0,
    rest:id==='resting'?amount:0,conduct:id==='conducting'?amount:0};
}

/** Runtime action state takes precedence over a chosen resting state. Callers
 * supply normalized progress; this pure sampler never owns a timer or event. */
export function sampleCoreState({selection='idle',activity=null,channels={},deployment=1,responsive=true,time=0}={}){
  if(!responsive)return REST;
  const requested=Object.hasOwn(BIT_CORE_STATES,selection)?selection:'idle';
  let id=requested,amount=1,progress=unit(activity?.progress),dynamic=false;
  if(activity&&Object.hasOwn(BIT_CORE_STATES,activity.state)&&!['idle','auto'].includes(activity.state)){
    id=activity.state;amount=activity.amount==null?1:unit(activity.amount);dynamic=true;
  }else if(requested==='auto'){
    const work=unit(channels.heal),guard=unit(channels.guard),charge=Math.max(unit(channels.pulse),unit(channels.overdrive));
    if(deployment<.92){id='encased';amount=1-ease(deployment/.92);}
    else if(work>.01){id='open';amount=work;}
    else if(guard>.08){id='guarding';amount=guard;}
    else if(charge>.04){id='charging';amount=charge;}
    else return REST;
  }
  if(id==='idle')return REST;
  // A manually selected settling state is a gentle repeating release. An
  // action's settling stage instead closes once with its actual progress.
  if(id==='settling'&&!dynamic)progress=((Number(time)||0)/5%1+1)%1;
  const examination=dynamic?captureScanMechanism(activity.examination):null,mechanism=examination?{examination}:{};
  const shapeChannels=dynamic?activityChannels(activity.coreChannels):null;
  if(shapeChannels){const result={};for(const key of STATE_CHANNELS)result[key]=shapeChannels[key]*amount;return {id,amount,progress,...result,coreChannels:shapeChannels,...(activity.weights?{weights:activityWeights(activity.weights)}:{}),...mechanism};}
  const weights=dynamic?activityWeights(activity.weights):null;
  if(weights){
    const result={encase:0,open:0,charge:0,guard:0,settle:0,scan:0,brace:0,align:0,rest:0,conduct:0},settleProgress=unit(activity.settleProgress??progress);
    for(const [state,weight]of Object.entries(weights)){
      const channels=stateChannels(state,amount*weight,state==='settling'?settleProgress:progress);
      for(const key of STATE_CHANNELS)result[key]+=channels[key];
    }
    return {id,amount,progress,...result,weights,settleProgress,...mechanism};
  }
  // A selected release repeats without re-opening an already closed core at
  // the clock wrap. Actual work releases retain their single captured sweep.
  const shapeAmount=id==='settling'&&!dynamic?amount*ease(progress/.15):amount;
  return {id,amount,progress,...stateChannels(id,shapeAmount,progress),...mechanism};
}

/** Light-weight activity override for hardware reused by action overlays. */
export function withCoreActivity(hardware,activity,options={}){
  if(!hardware)return hardware;
  const r=hardware.resonance??{},state=sampleCoreState({selection:options.selection??'idle',activity,
    channels:options.channels??{},responsive:options.responsive!==false,deployment:r.deployment??1,time:options.time??r.phase??0});
  return {...hardware,resonance:{...r,coreState:state}};
}
