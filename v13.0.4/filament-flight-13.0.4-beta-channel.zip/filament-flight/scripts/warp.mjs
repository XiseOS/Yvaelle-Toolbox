/** Warp: Ellie folds into a seam of magenta light and steps out of a rift.
 * Two looks: with her wings (they flare as space pinches) and without them.
 * Pick a destination you can see within range; every connected player sees the
 * same effect, drawn on a light layer above the map on their own screen. Only
 * the owner moves the token. Nothing here touches other documents. */
import {createOverlay} from './overlay-layer.mjs?v=13.0.4';
import {defaultWarpLook} from './v10-versions.mjs?v=13.0.4';
import {liveBitPositions} from './bit-renderer.mjs?v=13.0.4';
import {playCue} from './sound-cues.mjs?v=13.0.4';
import {WARP_LOOKS,drawWarpLook,settle as settleWisps,travelTime,arrivalStyle} from './warp-looks.mjs?v=13.0.4';
import {captureHer,drawHer,bodyPose,bodyPoint} from './warp-capture.mjs?v=13.0.4';
import {resolveV11} from './v11/features.mjs?v=13.0.4';
import {isCloak,CLOAK_QUICK} from './v11/invis.mjs?v=13.0.4';
import {soundFor,soundOn,noteAsked} from './v12/sound-set.mjs?v=13.0.4';
const ID='filament-flight';
const TAU=Math.PI*2,MAG=[255,0,255],HOT=[255,214,255],VIOLET=[150,0,220];
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const ease=t=>t*t*(3-2*t),easeOut=t=>1-(1-t)**3,easeIn=t=>t*t*t;
const lerp=(a,b,t)=>a+(b-a)*t;
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${clamp(a)})`;
const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
export const WARP_DURATION=3500,FLICKER_DURATION=4200;
const LOOKS=['seam','threaded','flicker',...Object.keys(WARP_LOOKS)];
/** (12.0.0-beta.5) The cloak warp is not one of these: nothing is drawn on the warp layer. She fades where she is in her cloak's own look, is moved while hidden, and comes back there (cloakWarp). */
export const CLOAK_WARP='cloak';

/* The effect follows the prototype's timeline; `t` below is prototype time.
 * Play time 0 is prototype 0.6 s, so the gathering starts at once. */
const OFFSET=.6,MOVE_AT=1.82;// she moves while she is a seam of light (prototype 1.72–1.95)
/** Length (ms) and token-move moment (prototype time) of each look. */
const lookDuration=look=>look==='flicker'?FLICKER_DURATION:WARP_LOOKS[look]?WARP_LOOKS[look].duration*1000:WARP_DURATION;
const lookMove=look=>look==='flicker'?3.0:WARP_LOOKS[look]?WARP_LOOKS[look].move+OFFSET:MOVE_AT;
/* beta.29: travelling elements take longer the farther she goes. Flicker's
 * flight of bits (prototype 2.2–3.05 s) is stretched or shortened to the
 * distance; Petal, Shard and Mirror time themselves (warp-looks.mjs). */
const FLICKER_TRAVEL=[2.2,3.05];
function timeline(fx){
  const look=WARP_LOOKS[fx.look];
  if(look?.timing){const T=look.timing(fx);fx.dur=T.duration*1000;fx.moveT=T.move+OFFSET;fx.remap=null;return;}
  fx.dur=lookDuration(fx.look);fx.moveT=lookMove(fx.look);fx.remap=null;
  if(fx.look==='flicker'){const [a,b]=FLICKER_TRAVEL,span=b-a,k=travelTime(fx)/span;
    fx.dur+=span*(k-1)*1000;fx.moveT=a+(fx.moveT-a)*k;fx.remap=t=>t<a?t:t<a+span*k?a+(t-a)/k:t-span*(k-1);}
}

let layer=null,ticker=null,lens=null;const active=new Set();const images=new Map();
function view(){return globalThis.canvas?.app?.view??null;}
const overlay=createOverlay('ff-warp-layer');
function ensureLayer(){const L=overlay.ensure();layer=L?.el??null;return L;}
function projector(r,dpr){
  const wt=canvas.stage.worldTransform,sx=r.width/(canvas.app.renderer.screen.width||r.width);
  return {pt:p=>{const q=wt.apply(p);return {x:q.x*sx*dpr,y:q.y*sx*dpr};},screen:p=>wt.apply(p),scale:wt.a*sx*dpr,screenScale:wt.a};
}
const tokenOf=uuid=>{try{return fromUuidSync(uuid)?.object??null;}catch{return null;}};
const centerOf=token=>token?.center??{x:token.x+token.w/2,y:token.y+token.h/2};
function art(src){if(!src)return null;let img=images.get(src);if(!img){img=new Image();img.decoding='async';img.src=src;images.set(src,img);}return img.complete&&img.naturalWidth?img:null;}

/* ---------- the space-bending lens: a GPU pinch on the map itself ---------- */
const LENS_SRC=`
varying vec2 vTextureCoord;uniform sampler2D uSampler;uniform vec4 inputSize;uniform vec4 outputFrame;
uniform vec4 lensA;uniform vec4 lensB;uniform vec4 dirA;uniform vec4 dirB;uniform vec4 rippleA;uniform vec4 rippleB;uniform vec4 opts;
vec2 pinch(vec2 p,vec4 l,vec4 o){vec2 d=p-l.xy;float r=length(d);
  if(l.z<=0.0||l.w<=0.0||r>=l.z)return p;float n=r/l.z,f=pow(1.0-n,1.6),k=1.0+l.w*f*1.8;
  float a=o.w*f*f;d=vec2(cos(a)*d.x-sin(a)*d.y,sin(a)*d.x+cos(a)*d.y);
  if(dot(o.xy,o.xy)<0.25)return l.xy+d*k;
  vec2 u=normalize(o.xy),v=vec2(-u.y,u.x);
  return l.xy+u*dot(d,u)*k+v*dot(d,v)*k*(1.0+o.z*f);}
vec2 ripple(vec2 p,vec4 w){if(w.w<=0.0||w.z<=0.0)return p;vec2 d=p-w.xy;float r=length(d);if(r<0.5)return p;
  float width=10.0+w.z*0.14;float band=exp(-pow((r-w.z)/width,2.0));return p-d/r*band*w.w*sin((r-w.z)/width*2.4);}
void main(){vec2 p0=vTextureCoord*inputSize.xy+outputFrame.xy;
  vec2 p=pinch(p0,lensA,dirA);p=pinch(p,lensB,dirB);p=ripple(p,rippleA);p=ripple(p,rippleB);
  vec2 o=p-p0;float split=clamp(length(o)*0.06,0.0,6.0)*opts.x;vec2 dir=length(o)>0.001?normalize(o):vec2(0.0);
  vec2 uv=(p-outputFrame.xy)*inputSize.zw;vec2 du=dir*split*inputSize.zw;
  vec4 c=texture2D(uSampler,uv);float r=texture2D(uSampler,uv+du).r;float b=texture2D(uSampler,uv-du).b;
  gl_FragColor=vec4(r,c.g,b,c.a);}`;
function lensFilter(){
  const PIXI=globalThis.PIXI;if(!PIXI?.Filter)return null;
  if(!lens){try{lens=new PIXI.Filter(undefined,LENS_SRC,{lensA:new Float32Array([0,0,0,0]),lensB:new Float32Array([0,0,0,0]),dirA:new Float32Array([0,0,0,0]),dirB:new Float32Array([0,0,0,0]),rippleA:new Float32Array([0,0,0,0]),rippleB:new Float32Array([0,0,0,0]),opts:new Float32Array([0,0,0,0])});lens.padding=0;}catch(e){console.warn('Yvaelle’s Toolbox | warp lens unavailable',e);lens=false;}}
  return lens||null;
}
/* beta.29: the lens bends the map only (the scene background and the tiles
 * it reaches), never other tokens, their drawings or Ellie's own meshes (she
 * is drawn on the warp layer and folds with it). "Warps bend nearby tokens"
 * puts it back on the whole primary group, as before. */
const lensTargets=new Set();
const bendTokens=()=>{try{return game.settings.get(ID,'warpBendTokens')===true;}catch{return false;}};
function lensWanted(circles){
  const group=canvas?.primary;if(!group)return [];
  if(bendTokens())return [group];
  const out=[],bg=group.background;if(bg&&!bg.destroyed)out.push(bg);
  for(const tile of canvas.tiles?.placeables??[]){const m=tile?.mesh;if(!m||m.destroyed||m===bg)continue;const d=tile.document??{};
    const x=d.x??tile.x??0,y=d.y??tile.y??0,w=d.width??tile.w??0,h=d.height??tile.h??0;
    if(circles.some(c=>c.x+c.r>x&&c.x-c.r<x+w&&c.y+c.r>y&&c.y-c.r<y+h))out.push(m);}
  return out;
}
function attachLens(obj,f,on){const list=obj.filters??[];
  if(on&&!list.includes(f))obj.filters=[...list,f];
  if(!on&&list.includes(f)){const next=list.filter(x=>x!==f);obj.filters=next.length?next:null;}}
function setLens(on,circles=[]){
  const f=lensFilter();if(!f){lensTargets.clear();return null;}
  const want=new Set(on?lensWanted(circles):[]);
  for(const o of [...lensTargets])if(!want.has(o)||o.destroyed){try{if(!o.destroyed)attachLens(o,f,false);}catch{}lensTargets.delete(o);}
  for(const o of want)if(!lensTargets.has(o)){try{attachLens(o,f,true);lensTargets.add(o);}catch{}}
  return lensTargets.size?f:null;
}

/** Play the effect (all clients). The owner also moves the token. */
export function playWarp({uuid,from,to,style='wings',look='seam',start=Date.now(),move=false}){
  const token=tokenOf(uuid);if(!token)return;
  const fx={uuid,token,from,to,style,look:LOOKS.includes(look)?look:'seam',bits:liveBitPositions(token).map(b=>({x:b.x-from.x,y:b.y-from.y})),start:performance.now()-Math.max(0,Math.min(400,Date.now()-start)),move,moved:false,
    src:token.document?.texture?.src,stars:Array.from({length:70},(_,i)=>({o:hash(i)*2-1,s:hash(i*3.3),l:.2+hash(i*7.1)*.8})),size:Math.max(token.w,token.h)||canvas.grid.size};
  // Wings out: the bend in space acts on the real Ellie, wings and bits (no stand-in copy)
  try{const st=game.modules.get(ID)?.api?.getState?.(token);fx.real=style!=='bare'&&st?.enabled===true;
    fx.span=clamp((Number(st?.options?.wingScale)||3)*.6,1.6,4.2);fx.hasWings=st?.enabled===true;}catch{fx.real=false;fx.span=1.6;}
  // beta.34: start and land where (and as big as) her flying body is drawn
  fx.pose=bodyPose(token);
  art(fx.src);timeline(fx);
  for(const old of active)if(old.uuid===uuid)finish(old);
  active.add(fx);startTicker();
  // (12.0.0-beta.7) with V12 sounds on, Flock, Starfall, Ribbon seam and Prism play their own; else the ones they borrowed
  const own=soundFor(token.document,'warps',fx.look);if(own)noteAsked(own);
  playCue(token,own??(fx.look==='flicker'?'warpFlicker':fx.look==='threaded'?'warpThreaded':WARP_LOOKS[fx.look]?.cue??'warpSeam'));
}
function startTicker(){
  if(ticker)return;
  ticker=()=>frame();
  canvas.app.ticker.add(ticker,undefined,globalThis.PIXI?.UPDATE_PRIORITY?.HIGH??25);
}
function stopTicker(){if(ticker){canvas.app?.ticker?.remove(ticker);ticker=null;}setLens(false);overlay.release();}
function finish(fx){
  active.delete(fx);
  try{if(fx.token?.mesh&&fx.baseAlpha!=null)fx.token.mesh.alpha=fx.baseAlpha;}catch{}
  // hand the token back to Foundry whole: state, mesh and position refreshed
  // (one flag at a time, so a flag a Foundry version lacks cannot drop the others)
  for(const flag of ['refreshState','refreshMesh','refreshPosition'])try{fx.token?.renderFlags?.set?.({[flag]:true});}catch{}
}
/* ---- a move during the warp ends it early (beta.34) ----
 * Moving her while a warp plays used to move a hidden token: nothing showed
 * until the warp ended, then it snapped. Now any movement of hers that is not
 * the warp's own jump ends the warp at once: the real token comes back (with
 * wings, bits and flight feel) and follows the move, the warp no longer moves
 * her, and her copy fades into where she is over about 150 ms. */
const ABORT_MS=150;
function ownWarpMove(doc,options){
  if(options?.filamentWarp)return true;
  for(const key of ['movement','_movement']){const m=options?.[key]?.[doc?.id];const w=m?.waypoints??m?.passed?.waypoints;if(Array.isArray(w)&&w.some(p=>p?.action==='displace'))return true;}
  return false;
}
function abortWarp(fx){
  if(fx.abortAt!=null)return;fx.abortAt=performance.now();fx.moved=true;// the new move wins: the warp will not move her
  try{if(fx.token?.mesh&&fx.baseAlpha!=null)fx.token.mesh.alpha=fx.baseAlpha;}catch{}
  for(const flag of ['refreshState','refreshMesh','refreshPosition'])try{fx.token?.renderFlags?.set?.({[flag]:true});}catch{}
}
function drawAbort(f,P,fx,k){
  const a=1-k*k*(3-2*k),token=fx.token,pose=bodyPose(token),c=bodyPoint(centerOf(token),pose),C=P.pt(c);
  if(fx.cap){f.translate(C.x,C.y);drawHer(f,fx.cap,P.scale,{alpha:a,shadow:0});return;}
  const img=art(fx.src);if(!img)return;const w=(token.mesh?.width||fx.size)*P.scale*pose.k,h=(token.mesh?.height||fx.size)*P.scale*pose.k;
  f.globalAlpha=a;f.translate(C.x,C.y);f.rotate((token.mesh?.rotation??0)+pose.bank);f.drawImage(img,-w/2,-h/2,w,h);
}
function onTokenMove(doc,changes,options){
  if(!active.size||!changes||!['x','y'].some(k=>Object.hasOwn(changes,k)))return;
  if(ownWarpMove(doc,options))return;
  for(const fx of active){if(fx.uuid!==doc.uuid)continue;
    // (the warp's own jump, seen on another screen or without our options, is not a new move)
    const x=changes.x??doc.x,y=changes.y??doc.y,land=fx.land??landing(fx.token,fx.to);
    if(land&&Math.abs(x-land.x)<1&&Math.abs(y-land.y)<1)continue;
    abortWarp(fx);}
}
const reducedMotion=()=>{try{return !!game.settings.get(ID,'reducedMotion');}catch{return false;}};
function frame(){try{frameInner();}catch(e){console.error('Yvaelle’s Toolbox | warp layer stopped',e);for(const fx of [...active])finish(fx);stopTicker();}}
function frameInner(){
  const L=ensureLayer();if(!L){stopTicker();return;}
  const f=L.el.getContext('2d');f.setTransform(1,0,0,1,0,0);f.clearRect(0,0,L.el.width,L.el.height);
  if(!active.size){stopTicker();return;}
  const P=projector(L.r,L.dpr),now=performance.now(),reduced=reducedMotion();
  let lensA=null,lensB=null,dirA=null,dirB=null,rippleA=null,rippleB=null,split=0;const circles=[];
  for(const fx of [...active]){
    const t=(now-fx.start)/1000+OFFSET;
    if((t-OFFSET)*1000>=fx.dur){finish(fx);continue;}
    const token=fx.token;if(!token||token.destroyed){active.delete(fx);continue;}
    // beta.34: she was moved during the warp: the real token is already back
    // and following the move; her copy fades into where she is now (~150 ms)
    if(fx.abortAt!=null){const k=(now-fx.abortAt)/ABORT_MS;if(k>=1){finish(fx);continue;}
      f.save();try{drawAbort(f,P,fx,k);}catch{}f.restore();continue;}
    if(fx.move&&!fx.moved&&t>=fx.moveT){fx.moved=true;fx.land=landing(token,fx.to);void moveToken(token,fx.to).catch(e=>ui.notifications?.error(`Warp: ${e?.message??e}`));}
    let v;try{f.save();v=draw(f,P,fx,fx.remap?fx.remap(t):t,reduced);}catch(e){f.restore();console.error('Yvaelle’s Toolbox | warp effect stopped',e);
      if(fx.move&&!fx.moved){fx.moved=true;void moveToken(token,fx.to).catch(()=>{});}finish(fx);continue;}
    f.restore();
    const reach=fx.size*(fx.span??1.6)*1.3,wave=fx.size*4.6;
    if(v.lensA||v.rippleA)circles.push({x:fx.from.x,y:fx.from.y,r:v.rippleA?wave:reach});if(v.lensB||v.rippleB)circles.push({x:fx.to.x,y:fx.to.y,r:v.rippleB?wave:reach*1.1});
    if(v.lensA)lensA=v.lensA;if(v.lensB)lensB=v.lensB;if(v.dirA)dirA=v.dirA;if(v.dirB)dirB=v.dirB;if(v.rippleA)rippleA=v.rippleA;if(v.rippleB)rippleB=v.rippleB;split=Math.max(split,v.split??0);
  }
  // the lens bends the map (and, if chosen, the tokens on it), on this screen only
  const lf=(lensA||lensB||rippleA||rippleB)&&!reduced?setLens(true,circles):setLens(false);
  if(lf){const u=lf.uniforms,put=(arr,v)=>{const z=v??{x:0,y:0,r:0,k:0};arr[0]=z.x;arr[1]=z.y;arr[2]=z.r;arr[3]=z.k;};
    put(u.lensA,lensA);put(u.lensB,lensB);const pd=(arr,v)=>{const z=v??{x:0,y:0,s:0,w:0};arr[0]=z.x;arr[1]=z.y;arr[2]=z.s;arr[3]=z.w;};if(u.dirA)pd(u.dirA,dirA);if(u.dirB)pd(u.dirB,dirB);put(u.rippleA,rippleA);put(u.rippleB,rippleB);u.opts[0]=split;}
}
/** Where the token's top-left lands for a chosen centre point (grid-snapped). */
function landing(token,to){
  let x=to.x-token.w/2,y=to.y-token.h/2;
  try{const snapped=token.getSnappedPosition?.({x,y});if(snapped){x=snapped.x;y=snapped.y;}}catch{}
  return {x,y};
}
/* beta.32: Foundry v13+ moves tokens through its movement API, which keeps
 * each token's movement (origin, history, pending waypoints) and makes the
 * next move continue from it. A bare position update with made-up options
 * left that record behind the token, so the first ordinary move after a warp
 * did not show. A warp is now Foundry's own "displace" movement (no path, no
 * animation, no walls or cost), awaited to the end; older Foundry versions
 * keep the plain non-animated update. */
async function moveToken(token,to){
  const {x,y}=landing(token,to),doc=token.document;
  const displace=globalThis.CONFIG?.Token?.movement?.actions?.displace;
  if(typeof doc.move==='function'&&displace){
    let moved=false;
    try{moved=await doc.move([{x,y,action:'displace'}],{animate:false,filamentWarp:true,method:'api',showRuler:false,constrainOptions:{ignoreWalls:true,ignoreCost:true}});}
    catch(e){console.warn('Yvaelle’s Toolbox | warp: movement API refused, using a position update',e);}
    if(moved!==false&&Math.abs((doc.x??x)-x)<1&&Math.abs((doc.y??y)-y)<1)return;
  }
  await doc.update({x,y},{animate:false,teleport:true,filamentWarp:true});
}

function draw(f,P,fx,t,reduced){
  if(fx.look==='flicker')return drawFlicker(f,P,fx,t,reduced);
  if(WARP_LOOKS[fx.look])return drawWarpLook(fx.look,f,P,fx,t-OFFSET,reduced);
  const A=P.pt(bodyPoint(fx.from,fx.pose)),B=P.pt(bodyPoint(fx.to,fx.pose)),D=fx.size*P.scale*(fx.pose?.k??1),G=D,ang=Math.atan2(B.y-A.y,B.x-A.x),L=Math.hypot(B.x-A.x,B.y-A.y);
  const wings=fx.style!=='bare',stars=fx.stars,token=fx.token;
  // --- lens: space pinches around her, then un-pinches at the destination
  const pinch=ease(seg(t,1.0,1.7))*(1-seg(t,1.7,1.9)),unp=Math.sin(Math.PI*seg(t,1.95,2.7));
  const sA=P.screen(bodyPoint(fx.from,fx.pose)),sB=P.screen(bodyPoint(fx.to,fx.pose)),gs=fx.size*P.screenScale*(fx.pose?.k??1);
  const reach=fx.real?fx.span:1.6;// the pinch reaches as far as her wings do
  const out={lensA:pinch>.01?{x:sA.x,y:sA.y,r:gs*reach,k:pinch*(fx.real?1.35:1.2)}:null,lensB:unp>.01?{x:sB.x,y:sB.y,r:gs*reach*1.15,k:unp*.9}:null};
  // shock ripples run through the map as she leaves and as she lands
  const rA=seg(t,1.72,2.5),rB=seg(t,1.98,2.95);
  const rich=fx.look==='threaded';
  if(rich&&rA>0&&rA<1)out.rippleA={x:sA.x,y:sA.y,r:gs*(.3+3.4*easeOut(rA)),k:gs*.16*(1-rA)};
  if(rich&&rB>0&&rB<1)out.rippleB={x:sB.x,y:sB.y,r:gs*(.3+4*easeOut(rB)),k:gs*.2*(1-rB)};
  // ground layer (threaded look): the threads reaching ahead and the dark core she leaves
  if(rich)under(f,P,fx,t,reduced,{A,B,D,ang,L});
  // --- her: squeezed into a streak along the travel line, then springing out of the rift
  const gone=t>=1.72&&t<1.95,atB=t>=1.95,Pp=atB?B:A;
  const sq=atB?easeOut(seg(t,1.95,2.45)):1-easeIn(seg(t,1.2,1.72));
  const pop=atB?1+.12*Math.sin(Math.PI*seg(t,2.3,2.8)):1;
  const img=art(fx.src);
  if(fx.real)return drawReal(f,P,fx,t,reduced,out,{A,B,D,G,ang,L,stars,rich});
  // beta.29: with her wings out, "Step through" copies her whole (wings and
  // bits) before the real token hides, so the wings fold and sweep through with her
  const cap=fx.hasWings&&!fx.real?(fx.cap===undefined?(fx.cap=captureHer(token,img)):fx.cap):null;
  let copyBack=1;
  if(token.mesh){fx.baseAlpha??=token.mesh.alpha||1;
    // the real token (and anything following it) hides while the drawn one squeezes
    if(cap){const c=centerOf(token),k=Math.hypot(c.x-fx.to.x,c.y-fx.to.y)<fx.size*.5?ease(seg(t,3.7,4.0)):0;copyBack=1-k;token.mesh.alpha=fx.baseAlpha*Math.min(1,k*1.6);}
    else token.mesh.alpha=img?0:fx.baseAlpha*clamp(sq*1.4);}
  // the rift at the destination: a diamond tear full of streaming stars
  // drawn before her, so she steps out of the tear instead of behind it
  const rift=Math.sin(Math.PI*seg(t,1.72,2.45))*(1-ease(seg(t,1.98,2.18)));
  if(rift>0){f.save();f.translate(B.x,B.y);f.rotate(ang);const rw=G*.32*rift,rh=G*1.1*rift;
    const edge=()=>{f.beginPath();for(let k=0;k<=24;k++){const v=k/24*2-1,j=1+.22*Math.sin(k*4.7+t*50)*(1-Math.abs(v));f.lineTo(Math.sqrt(1-v*v)*rw*j,v*rh);}for(let k=24;k>=0;k--){const v=k/24*2-1,j=1+.22*Math.sin(k*3.1+t*45)*(1-Math.abs(v));f.lineTo(-Math.sqrt(1-v*v)*rw*j,v*rh);}f.closePath();};
    edge();f.save();f.clip();const bg=f.createRadialGradient(0,0,0,0,0,rh);bg.addColorStop(0,'rgba(90,0,120,.95)');bg.addColorStop(1,'rgba(30,0,50,.9)');f.globalCompositeOperation='source-over';f.fillStyle=bg;f.fillRect(-rw*2,-rh*1.2,rw*4,rh*2.4);
    f.globalCompositeOperation='lighter';if(!reduced)for(const s2 of stars){const a=s2.o*Math.PI,p=(s2.s+t*1.6)%1,r=p*rh;f.strokeStyle=rgba(s2.l>.6?HOT:MAG,.85*p);f.lineWidth=1;f.beginPath();f.moveTo(Math.cos(a)*r*.5,Math.sin(a)*r);f.lineTo(Math.cos(a)*r*.58,Math.sin(a)*r*1.15);f.stroke();}f.restore();
    f.globalCompositeOperation='lighter';edge();f.shadowColor='rgba(255,0,255,1)';f.shadowBlur=14;f.strokeStyle=rgba(MAG,.95*rift);f.lineWidth=3;f.stroke();f.shadowBlur=0;f.strokeStyle=rgba(HOT,rift);f.lineWidth=1.2;f.stroke();f.restore();}
  if(!gone){
    const k=fx.pose?.k??1,w=(token.mesh?.width||fx.size)*P.scale*k,h=(token.mesh?.height||fx.size)*P.scale*k,rot=(token.mesh?.rotation??0)+(fx.pose?.bank??0);
    f.save();f.translate(Pp.x,Pp.y);f.rotate(ang);f.scale(lerp(2.4,1,sq)*pop,lerp(.05,1,sq)*pop);f.rotate(-ang);
    // a soft shadow stays under her while she is whole
    const sh=f.createRadialGradient(0,D*.55,0,0,D*.55,D*.72);sh.addColorStop(0,`rgba(0,0,0,${.45*sq})`);sh.addColorStop(1,'rgba(0,0,0,0)');f.fillStyle=sh;f.beginPath();f.ellipse(0,D*.55,D*.72,D*.3,0,0,TAU);f.fill();
    const rim=wings?1-sq:1-sq+.35*Math.exp(-Math.pow((t-2.2)*4,2));
    if(rim>.02){f.save();f.globalCompositeOperation='lighter';const g=f.createRadialGradient(0,0,D*.4,0,0,D*.95);g.addColorStop(0,rgba(MAG,.7*rim));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(0,0,D*.95,0,TAU);f.fill();f.restore();}
    if(cap){// the wings fold back along the travel line a beat before she squeezes, and open last with a little follow-through
      const wf=atB?easeOut(seg(t,2.0,2.7)):1-ease(seg(t,.9,1.6)),over=atB?.05*Math.sin(Math.PI*seg(t,2.45,2.95)):0;
      const wingFold=g=>{g.rotate(ang);g.translate(-(1-wf)*D*.3,0);g.scale(lerp(.6,1,wf)+over,lerp(.22,1,wf)+over);g.rotate(-ang);};
      drawHer(f,cap,P.scale,{alpha:clamp(sq*1.4)*copyBack,shadow:0,wing:wingFold,bit:wingFold});}
    else if(img){f.save();f.globalAlpha=clamp(sq*1.4);f.rotate(rot);f.drawImage(img,-w/2,-h/2,w,h);f.restore();}
    if(rim>.02&&!cap){f.save();f.globalCompositeOperation='lighter';f.strokeStyle=rgba(HOT,.9*rim);f.lineWidth=2*Math.max(.7,P.scale);f.beginPath();f.arc(0,0,D*.5,0,TAU);f.stroke();f.restore();}
    if(wings&&sq<1&&!cap?.wings){// her wings flare and fold into the seam with her
      f.save();f.globalCompositeOperation='lighter';f.shadowColor=rgba(MAG,1);f.shadowBlur=10;
      for(const side of [-1,1]){f.save();f.scale(side,1);f.strokeStyle=rgba(MAG,.75*(1-sq*.4)*clamp(sq*2));f.lineWidth=2*Math.max(.7,P.scale);
        for(let r=0;r<4;r++){f.beginPath();f.moveTo(D*.12,-D*.05);f.quadraticCurveTo(D*(.6+r*.12),-D*(.75+r*.08),D*(1-r*.1),-D*(.15-r*.18));f.stroke();}f.restore();}
      f.restore();}
    f.restore();
  }
  f.save();f.globalCompositeOperation='lighter';
  // gathering: space streams into her
  if(!reduced&&t>.8&&t<1.75){const k=seg(t,.8,1.75);for(const s of stars.slice(0,30)){const a=s.o*Math.PI,p=(k*1.5+s.s)%1,r=G*2.2*(1-p);const x=A.x+Math.cos(a)*r,y=A.y+Math.sin(a)*r;f.strokeStyle=rgba(MAG,.6*k*p);f.lineWidth=1.2;f.beginPath();f.moveTo(x,y);f.lineTo(x+(A.x-x)*.18,y+(A.y-y)*.18);f.stroke();}}
  // the jump: a seam of light through space with star-streaks along it
  if(t>1.65&&t<2.25){const k=1-Math.abs(seg(t,1.65,2.25)*2-1);
    f.save();f.translate(A.x,A.y);f.rotate(ang);
    if(!reduced)for(const s of stars){const y=s.o*D*.35*(1-s.l*.5),x0=((s.s+t*3)%1)*L,len=D*(.5+1.5*s.l);f.strokeStyle=rgba(s.l>.7?HOT:MAG,.75*k*s.l);f.lineWidth=.6+s.l;f.beginPath();f.moveTo(x0,y);f.lineTo(Math.min(L,x0+len),y);f.stroke();}
    const g=f.createLinearGradient(0,0,L,0);g.addColorStop(0,rgba(MAG,0));g.addColorStop(.5,rgba(HOT,.95*k));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.fillRect(0,-2.5,L,5);f.restore();}
  if(t>1.6&&t<1.95){const k=1-seg(t,1.6,1.95),fold=easeIn(seg(t,1.6,1.9));
    // space folds shut along the travel line: a bright lens squeezed into a seam
    f.save();f.translate(A.x,A.y);f.rotate(ang);f.scale(1+1.2*fold,Math.max(.08,1-.9*fold));
    const g=f.createRadialGradient(0,0,0,0,0,G*1.25);g.addColorStop(0,rgba(HOT,.85*k));g.addColorStop(.28,rgba(MAG,.42*k));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(0,0,G*1.25,0,TAU);f.fill();f.restore();
    f.save();f.translate(A.x,A.y);f.rotate(ang);const s2=f.createLinearGradient(-G*1.6,0,G*1.6,0);s2.addColorStop(0,rgba(MAG,0));s2.addColorStop(.5,rgba(HOT,.9*k));s2.addColorStop(1,rgba(MAG,0));f.fillStyle=s2;f.fillRect(-G*1.6,-1.2,G*3.2,2.4);f.restore();}
  // arrival: filaments settle into her
  arrive(f,B,P.scale,()=>shockwave(f,B,G*.4,G*2.6,seg(t,2.0,2.9),.8,P.scale),()=>settleWisps(f,B,D,seg(t,2.25,2.85),P.scale,2));
  // drifting motes left along the path
  if(!reduced&&t>1.9&&t<4){const k=seg(t,1.9,4);for(let i=0;i<22;i++){const p=hash(i*1.7),x=lerp(A.x,B.x,p)+Math.sin(i+t)*6,y=lerp(A.y,B.y,p)+(hash(i*2.9)-.5)*D*.38-k*D*.15,a=(1-k)*.8*hash(i*5.1);if(a<.02)continue;
    const g=f.createRadialGradient(x,y,0,x,y,3.3);g.addColorStop(0,rgba(MAG,a*.55));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(x,y,3.3,0,TAU);f.fill();
    f.fillStyle=rgba([255,240,255],a);f.beginPath();f.moveTo(x,y-1.8);f.lineTo(x+.35,y-.35);f.lineTo(x+1.8,y);f.lineTo(x+.35,y+.35);f.lineTo(x,y+1.8);f.lineTo(x-.35,y+.35);f.lineTo(x-1.8,y);f.lineTo(x-.35,y-.35);f.closePath();f.fill();}}
  f.restore();
  if(fx.look==='threaded')over(f,P,fx,t,reduced,{A,B,D,ang,L});
  out.split=fx.look==='threaded'?1:0;
  return out;
}

/** An eased, two-tone shock ring: a soft wide band with a thin hot edge.
 * Radius eases out so it slows as it spreads instead of growing linearly. */
function shockwave(f,c,r0,r1,k,alpha,scale){
  if(!(k>0&&k<1))return;const r=r0+(r1-r0)*easeOut(k),fade=(1-k)**1.6,px=Math.max(.7,scale);
  f.strokeStyle=rgba(MAG,.22*alpha*fade);f.lineWidth=(10*(1-k)+3)*px;f.beginPath();f.arc(c.x,c.y,r,0,TAU);f.stroke();
  f.strokeStyle=rgba(MAG,alpha*fade);f.lineWidth=(2.4*(1-k)+.6)*px;f.stroke();
  f.strokeStyle=rgba(HOT,.8*alpha*fade);f.lineWidth=.8*px;f.beginPath();f.arc(c.x,c.y,r*.985,0,TAU);f.stroke();
  const r2=r0+(r1-r0)*.72*easeOut(seg(k,.12,1));if(k>.12){f.strokeStyle=rgba(MAG,.35*alpha*fade);f.lineWidth=px;f.beginPath();f.arc(c.x,c.y,r2,0,TAU);f.stroke();}
}

/** Settings › Warp arrival: the beta.28 magenta pulse (default) or the beta.29 filament wisps. */
function arrive(f,B,scale,pulse,wisps){
  if(arrivalStyle()==='wisps'){wisps();return;}
  f.save();f.globalCompositeOperation='lighter';pulse();f.restore();
}

/* ---------- Flicker: the wings pull taut, the bits unthread and arrive first,
 * then pull her silhouette back together (the prototype, on the real token) */
function drawFlicker(f,P,fx,t,reduced){
  const A=P.pt(bodyPoint(fx.from,fx.pose)),B=P.pt(bodyPoint(fx.to,fx.pose)),D=fx.size*P.scale*(fx.pose?.k??1),token=fx.token,wings=fx.style!=='bare',img=art(fx.src);
  if(!fx.bits.length)fx.bits=[[-.8,-.55],[.8,-.55],[-.7,.45],[.7,.45]].map(([x,y])=>({x:x*fx.size,y:y*fx.size}));
  if(t<2.0){const live=liveBitPositions(token);if(live.length)fx.bits=live.map(b=>({x:b.x-fx.from.x,y:b.y-fx.from.y}));}
  const bitsA=fx.bits.map(b=>P.pt({x:fx.from.x+b.x,y:fx.from.y+b.y})),bitsB=fx.bits.map(b=>P.pt({x:fx.to.x+b.x,y:fx.to.y+b.y}));
  // the real token, wings and bits fade together; a drawn copy of her carries the squeeze
  const m=t<2.0?1:t<2.45?1-ease(seg(t,2.0,2.45)):t<4.3?0:ease(seg(t,4.3,4.75));
  if(token.mesh){fx.baseAlpha??=token.mesh.alpha||1;token.mesh.alpha=fx.baseAlpha*(img?m:Math.max(m,.0));}
  const k=fx.pose?.k??1,w=(token.mesh?.width||fx.size)*P.scale*k,h=(token.mesh?.height||fx.size)*P.scale*k,rot=(token.mesh?.rotation??0)+(fx.pose?.bank??0);
  const her=(p,a,sx,sy)=>{if(!img||a<=.01)return;f.save();f.translate(p.x,p.y);f.scale(sx,sy);f.rotate(rot);f.globalAlpha=clamp(a);f.drawImage(img,-w/2,-h/2,w,h);f.restore();};
  if(t>=2.0&&t<2.95){const q=easeIn(seg(t,2.45,2.9));her(A,(1-m)*(1-q),lerp(1,.12,q),lerp(1,1.25,q));}
  if(t>=3.85){const q=easeOut(seg(t,3.9,4.6));her(B,(1-m)*q,lerp(.12,1,q),lerp(1.25,1,q));}
  f.save();f.globalCompositeOperation='lighter';f.lineCap='round';
  const line=(x1,y1,x2,y2,a,wd,bend=0,dash=null,off=0)=>{if(a<=.01)return;const mx=(x1+x2)/2-(y2-y1)*bend,my=(y1+y2)/2+(x2-x1)*bend;f.save();if(dash){f.setLineDash(dash);f.lineDashOffset=off;}
    f.strokeStyle=rgba(MAG,a*.35);f.lineWidth=wd*3.5;f.beginPath();f.moveTo(x1,y1);f.quadraticCurveTo(mx,my,x2,y2);f.stroke();f.strokeStyle=rgba(MAG,a);f.lineWidth=wd;f.stroke();f.strokeStyle=rgba(HOT,a*.7);f.lineWidth=wd*.35;f.stroke();f.restore();};
  const glint=(x,y,r,a)=>{if(a<=.01)return;const g=f.createRadialGradient(x,y,0,x,y,r*3);g.addColorStop(0,rgba(MAG,a*.6));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(x,y,r*3,0,TAU);f.fill();
    f.fillStyle=rgba([255,240,255],a);f.beginPath();f.moveTo(x,y-r*1.7);f.lineTo(x+r*.3,y-r*.3);f.lineTo(x+r*1.7,y);f.lineTo(x+r*.3,y+r*.3);f.lineTo(x,y+r*1.7);f.lineTo(x-r*.3,y+r*.3);f.lineTo(x-r*1.7,y);f.lineTo(x-r*.3,y-r*.3);f.closePath();f.fill();};
  const wd=Math.max(1,D*.012);
  // wings draw taut: threads pull from her to each bit
  const taut=ease(seg(t,.8,2.0))*(1-seg(t,2.0,2.4));
  if(wings&&taut>0)bitsA.forEach((b,i)=>line(A.x,A.y,b.x,b.y,.55*taut,wd,i%2?.08:-.08));
  if(taut>0){const g=f.createRadialGradient(A.x,A.y,D*.3,A.x,A.y,D*.9);g.addColorStop(0,rgba(MAG,.35*taut));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(A.x,A.y,D*.9,0,TAU);f.fill();}
  bitsA.forEach((a,i)=>{const b=bitsB[i];
    const out=seg(t,2.0+i*.12,2.35+i*.12),travel=seg(t,2.2+i*.12,3.05+i*.1),inn=seg(t,3.0+i*.1,3.35+i*.1);
    if(out>0&&out<1)glint(a.x,a.y,D*.05*(1+out),Math.sin(Math.PI*out));
    if(out>0&&travel<1&&!reduced){const p=easeIn(travel),x=lerp(a.x,b.x,p),y=lerp(a.y,b.y,p)-Math.sin(p*Math.PI)*D*.5;glint(x,y,D*.035,.95);line(a.x,a.y,x,y,.35*(1-p),wd*.6);}
    if(inn>0){glint(b.x,b.y,D*.03*(3*(1-inn)+1),1-inn*.5);if(t<4.7)glint(b.x,b.y,D*.02,.8*(1-m)*inn);}
    if(t>3.35&&t<4.7){const k=1-seg(t,4.2,4.7);line(b.x,b.y,lerp(b.x,B.x,.7),lerp(b.y,B.y,.7),.6*k,wd,i%2?.2:-.2,[3*wd,4*wd],reduced?0:t*40);}
  });
  if(t>2.4&&t<3.3){const k=1-Math.abs(seg(t,2.4,3.3)*2-1);line(A.x,A.y,B.x,B.y,.25*k,wd*.8,.08);}
  // landing: the arrived bits weave her back. Beads run in along their threads and
  // a narrow seam of light gathers and widens where she will stand, so the half
  // second before she reappears is never empty.
  const loom=seg(t,3.25,3.9),settle=seg(t,4.25,4.7);
  if(loom>0&&settle<1){const k=ease(loom)*(1-ease(settle)),open=ease(seg(t,3.55,4.35));
    const g=f.createRadialGradient(B.x,B.y,0,B.x,B.y,D*(.4+.25*loom));g.addColorStop(0,rgba(HOT,.28*k));g.addColorStop(.5,rgba(MAG,.16*k));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(B.x,B.y,D*(.4+.25*loom),0,TAU);f.fill();
    f.save();f.translate(B.x,B.y);f.scale(lerp(.06,1,open),1);f.strokeStyle=rgba(MAG,.6*k);f.lineWidth=wd*2.4/Math.max(.06,lerp(.06,1,open));f.beginPath();f.arc(0,0,D*.5,0,TAU);f.stroke();f.restore();
    f.save();f.translate(B.x,B.y);f.scale(lerp(.06,1,open),1);f.strokeStyle=rgba(HOT,.75*k);f.lineWidth=wd*.8/Math.max(.06,lerp(.06,1,open));f.beginPath();f.arc(0,0,D*.5,0,TAU);f.stroke();f.restore();
    if(!reduced)bitsB.forEach((b,i)=>{const p=(t*1.5+i*.27)%1,a=Math.sin(Math.PI*p)*k;glint(lerp(b.x,B.x,easeIn(p)),lerp(b.y,B.y,easeIn(p)),D*.022,a);});}
  arrive(f,B,P.scale,()=>shockwave(f,B,D*.45,D*1.15,seg(t,4.22,4.8),.5,P.scale),()=>settleWisps(f,B,D,seg(t,4.2,4.75),P.scale,5));
  if(t>2.8&&t<3.1)glint(A.x,A.y,D*.06*(1-seg(t,2.8,3.1))+1,1);
  f.restore();
  return {split:0};
}

/* ---------- wings out: the real Ellie is pinched into the seam and springs back out ---------- */
function drawReal(f,P,fx,t,reduced,out,{A,B,D,G,ang,L,stars,rich}){
  const token=fx.token,sA=P.screen(bodyPoint(fx.from,fx.pose)),sB=P.screen(bodyPoint(fx.to,fx.pose)),gs=fx.size*P.screenScale*(fx.pose?.k??1),ux=Math.cos(ang),uy=Math.sin(ang);
  // leaving: space folds in around her; she, her wings and bits keep their form
  // but are drawn toward the seam, stretched along the travel line and turned a little
  const fold=easeIn(seg(t,.95,1.74))*(1-seg(t,1.74,1.8));
  // arriving: the same fold starts closed at B and opens, so she unfolds out of the seam
  const open=t>=1.95?1-easeOut(seg(t,1.95,2.7)):0;
  // the map bends with her (beta.29: gentler, and only the map unless chosen otherwise)
  out.lensA=fold>.005?{x:sA.x,y:sA.y,r:gs*fx.span,k:fold*2.6}:null;out.dirA=fold>.005?{x:ux,y:uy,s:fold*2.2,w:fold*.8}:null;
  out.lensB=open>.005?{x:sB.x,y:sB.y,r:gs*fx.span*1.1,k:open*2.6}:null;out.dirB=open>.005?{x:ux,y:uy,s:open*2.2,w:-open*.8}:null;
  // from the first moment of the fold she is a copy on this layer, so the fold
  // bends her, her wings and her bits without touching anyone else
  if(t>=.95&&fx.cap===undefined)fx.cap=captureHer(token,art(fx.src));
  const cap=fx.cap,c=centerOf(token),arrived=Math.hypot(c.x-fx.to.x,c.y-fx.to.y)<fx.size*.5;
  let copyBack=1;
  if(token.mesh){fx.baseAlpha??=token.mesh.alpha||1;
    if(cap){const k=arrived?ease(seg(t,2.55,2.85)):0;copyBack=1-k;token.mesh.alpha=fx.baseAlpha*(t<.95?1:Math.min(1,k*1.6));}
    else{// (no copy possible: the real token fades as before)
      const leave=reduced?1-ease(seg(t,1.3,1.74)):t<1.68?1:1-ease(seg(t,1.68,1.76)),back=arrived?ease(reduced?seg(t,1.98,2.5):seg(t,1.95,2.05)):0;
      token.mesh.alpha=fx.baseAlpha*(t<1.9?leave:back);}}
  if(cap){
    const leave=reduced?1-ease(seg(t,1.3,1.74)):t<1.68?1:1-ease(seg(t,1.68,1.76));
    if(t>=.95&&t<1.8&&leave>.004)foldHer(f,P,cap,A,fold,ang,leave);
    if(t>=1.95){const k=ease(reduced?seg(t,1.98,2.5):seg(t,1.95,2.05))*copyBack;if(k>.004)foldHer(f,P,cap,B,open,ang,k);}
  }
  f.save();f.globalCompositeOperation='lighter';
  // her glow tightens as space folds around her, then blooms where she steps out
  const gather=ease(seg(t,1.4,1.72))*(1-seg(t,1.72,1.8)),bloom=Math.sin(Math.PI*seg(t,1.95,2.5));
  for(const [P0,k,r] of [[A,gather,D*(1.2-.6*gather)],[B,bloom,D*(.6+.9*bloom)]]){if(k<=.01)continue;
    const g=f.createRadialGradient(P0.x,P0.y,0,P0.x,P0.y,r);g.addColorStop(0,rgba(HOT,.3*k));g.addColorStop(.45,rgba(MAG,.14*k));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(P0.x,P0.y,r,0,TAU);f.fill();}
  // gathering: space streams into her from as far as her wings reach
  if(!reduced&&t>.8&&t<1.75){const k=seg(t,.8,1.75);for(const s of stars.slice(0,36)){const a=s.o*Math.PI,p=(k*1.5+s.s)%1,r=G*fx.span*1.1*(1-p);const x=A.x+Math.cos(a)*r,y=A.y+Math.sin(a)*r;f.strokeStyle=rgba(MAG,.6*k*p);f.lineWidth=1.2;f.beginPath();f.moveTo(x,y);f.lineTo(x+(A.x-x)*.2,y+(A.y-y)*.2);f.stroke();}}
  // the jump: a seam of light through space with star-streaks along it
  if(t>1.6&&t<2.25){const k=1-Math.abs(seg(t,1.6,2.25)*2-1);
    f.save();f.translate(A.x,A.y);f.rotate(ang);
    if(!reduced)for(const s of stars){const y=s.o*D*.35*(1-s.l*.5),x0=((s.s+t*3)%1)*L,len=D*(.5+1.5*s.l);f.strokeStyle=rgba(s.l>.7?HOT:MAG,.75*k*s.l);f.lineWidth=.6+s.l;f.beginPath();f.moveTo(x0,y);f.lineTo(Math.min(L,x0+len),y);f.stroke();}
    const g=f.createLinearGradient(0,0,L,0);g.addColorStop(0,rgba(MAG,0));g.addColorStop(.5,rgba(HOT,.95*k));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.fillRect(0,-2.5,L,5);f.restore();}
  if(t>1.68&&t<1.9){const k=Math.sin(Math.PI*seg(t,1.68,1.9));const g=f.createRadialGradient(A.x,A.y,0,A.x,A.y,G*fx.span*.45);g.addColorStop(0,rgba(HOT,.9*k));g.addColorStop(.3,rgba(MAG,.5*k));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(A.x,A.y,G*fx.span*.45,0,TAU);f.fill();}
  // the rift she steps out of, sized to her wings
  const rift=Math.sin(Math.PI*seg(t,1.72,2.2))*(1-ease(seg(t,1.96,2.1)));
  if(rift>0){f.save();f.translate(B.x,B.y);f.rotate(ang);const rw=G*.22*rift,rh=G*Math.min(1.6,fx.span*.55)*rift;
    f.beginPath();for(let k=0;k<=24;k++){const v=k/24*2-1;f.lineTo(Math.sqrt(1-v*v)*rw,v*rh);}for(let k=24;k>=0;k--){const v=k/24*2-1;f.lineTo(-Math.sqrt(1-v*v)*rw,v*rh);}f.closePath();
    f.shadowColor='rgba(255,0,255,1)';f.shadowBlur=14;f.strokeStyle=rgba(MAG,.95*rift);f.lineWidth=3;f.stroke();f.shadowBlur=0;f.strokeStyle=rgba(HOT,rift);f.lineWidth=1.2;f.stroke();f.restore();}
  f.restore();
  // arrival: filaments settle into her (no ring)
  arrive(f,B,P.scale,()=>shockwave(f,B,G*fx.span*.9,G*fx.span*1.75,seg(t,2.45,3.2),.6,P.scale),()=>settleWisps(f,B,D*Math.min(1.6,fx.span*.55),seg(t,2.3,2.95),P.scale,1));
  if(rich)over(f,P,fx,t,reduced,{A,B,D,ang,L});// under() was already drawn by draw()
  out.split=rich?1:0;return out;
}
/** Her copy folded toward the seam: squeezed across the travel line, drawn
 * out along it and turned a little; the wings (farther from the fold's
 * centre) are pulled in harder, and she brightens as she becomes light. */
function foldHer(f,P,cap,C,k,ang,alpha){
  const sx=1-.45*k+.55*k**3,sy=Math.max(.04,(1-k)**1.4+.04*k),w=1-.38*k;
  const pull=g=>g.scale(w,w);
  f.save();f.translate(C.x,C.y);f.rotate(ang);f.scale(sx,sy);f.rotate(-ang);f.rotate(k*.35);
  drawHer(f,cap,P.scale,{alpha,wing:pull,bit:pull});
  if(k>.05){f.globalCompositeOperation='lighter';drawHer(f,cap,P.scale,{alpha:alpha*.5*k,shadow:0,portrait:.4,wing:pull,bit:pull});}
  f.restore();
}

/* ---------- the extra layers ---------- */
function under(f,P,fx,t,reduced,{A,B,D,ang,L}){
  // filaments: threads reach out to the destination ahead of her, pull taut, then go slack
  const reach=easeOut(seg(t,.95,1.62)),slack=seg(t,1.95,2.7),fade=1-slack;
  if(reach>0&&fade>0){
    f.save();f.globalCompositeOperation='lighter';f.lineCap='round';
    for(let i=0;i<7;i++){
      const side=(i/6-.5)*2,bow=D*(.55+.35*hash(i*4.1))*side*(1-.85*seg(t,1.55,1.75))+Math.sin(t*6+i)*D*.05*slack*3,sag=D*.4*slack*(.6+hash(i));
      const nx=-Math.sin(ang),ny=Math.cos(ang),mx=(A.x+B.x)/2+nx*bow,my=(A.y+B.y)/2+ny*bow+sag;
      const steps=28,end=Math.max(1,Math.round(steps*reach));
      const pt=k=>{const u=k/steps,v=1-u;return [v*v*A.x+2*v*u*mx+u*u*B.x,v*v*A.y+2*v*u*my+u*u*B.y];};
      for(const [w,col,a] of [[3.2,MAG,.28],[1.1,HOT,.75]]){f.strokeStyle=rgba(col,a*fade*(.55+.45*hash(i*2.2)));f.lineWidth=w*Math.max(.7,P.scale);f.beginPath();const p0=pt(0);f.moveTo(p0[0],p0[1]);for(let k=1;k<=end;k++){const q=pt(k);f.lineTo(q[0],q[1]);}f.stroke();}
      if(reach<1){const q=pt(end);const g=f.createRadialGradient(q[0],q[1],0,q[0],q[1],D*.12);g.addColorStop(0,rgba(HOT,.9));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(q[0],q[1],D*.12,0,TAU);f.fill();}
      // light running along the taut thread just before she follows it
      const run=seg(t,1.5,1.85);if(run>0&&run<1&&!reduced){const q=pt(Math.round(steps*run));const g=f.createRadialGradient(q[0],q[1],0,q[0],q[1],D*.16);g.addColorStop(0,rgba(HOT,.9));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(q[0],q[1],D*.16,0,TAU);f.fill();}
    }
    f.restore();}
  // the dark core: a moment where she was, a hole in the light with a burning rim
  const core=Math.sin(Math.PI*seg(t,1.72,2.15));
  if(core>0){f.save();const r=D*.42*core;const g=f.createRadialGradient(A.x,A.y,0,A.x,A.y,r*1.5);g.addColorStop(0,'rgba(8,0,12,.92)');g.addColorStop(.62,'rgba(20,0,30,.7)');g.addColorStop(1,'rgba(20,0,30,0)');
    f.fillStyle=g;f.beginPath();f.arc(A.x,A.y,r*1.5,0,TAU);f.fill();f.globalCompositeOperation='lighter';f.shadowColor=rgba(MAG,1);f.shadowBlur=12;f.strokeStyle=rgba(MAG,.9*core);f.lineWidth=2.4;f.beginPath();f.arc(A.x,A.y,r,0,TAU);f.stroke();f.restore();}
}
function over(f,P,fx,t,reduced,{A,B,D,ang,L}){
  f.save();f.globalCompositeOperation='lighter';
  // rays of light collapse into her the instant before she goes
  const col=seg(t,1.5,1.74);
  if(col>0&&col<1){for(let i=0;i<16;i++){const a=i/16*TAU+hash(i)*.3,r0=D*(2.6-2.3*easeIn(col)),r1=r0+D*(.5+.6*hash(i*3));
    f.strokeStyle=rgba(i%2?HOT:MAG,.7*Math.sin(Math.PI*col));f.lineWidth=1.4+hash(i*7)*1.6;f.beginPath();f.moveTo(A.x+Math.cos(a)*r0,A.y+Math.sin(a)*r0);f.lineTo(A.x+Math.cos(a)*r1,A.y+Math.sin(a)*r1);f.stroke();}}
  // afterimages of her strung along the seam
  const img=art(fx.src),ghost=Math.sin(Math.PI*seg(t,1.7,2.15));
  if(img&&ghost>0&&!reduced){const w=(fx.token.mesh?.width||fx.size)*P.scale,h=(fx.token.mesh?.height||fx.size)*P.scale;
    for(let i=1;i<=4;i++){const u=i/5,x=lerp(A.x,B.x,u),y=lerp(A.y,B.y,u),k=ghost*(1-Math.abs(u-seg(t,1.7,2.0))*1.6);if(k<=.02)continue;
      f.save();f.translate(x,y);f.rotate(ang);f.scale(1.7,.42);f.rotate(-ang);f.globalAlpha=clamp(.32*k);f.drawImage(img,-w/2,-h/2,w,h);f.globalAlpha=1;
      const g=f.createRadialGradient(0,0,0,0,0,w*.6);g.addColorStop(0,rgba(MAG,.35*k));g.addColorStop(1,rgba(MAG,0));f.fillStyle=g;f.beginPath();f.arc(0,0,w*.6,0,TAU);f.fill();f.restore();}}
  // the rift sheds glass-like shards of light as it closes
  const sh=seg(t,1.98,2.95);
  if(sh>0&&sh<1&&!reduced){for(let i=0;i<18;i++){const a=hash(i*9.1)*TAU,v=D*(.9+1.6*hash(i*2.3)),d=v*easeOut(sh),x=B.x+Math.cos(a)*d,y=B.y+Math.sin(a)*d*.9,s=D*(.05+.07*hash(i*5.7))*(1-sh*.6),rot=a+sh*(4+hash(i)*6);
    f.save();f.translate(x,y);f.rotate(rot);f.beginPath();f.moveTo(0,-s*1.6);f.lineTo(s*.55,0);f.lineTo(0,s*1.1);f.lineTo(-s*.55,0);f.closePath();
    f.fillStyle=rgba(i%3?MAG:HOT,.75*(1-sh));f.fill();f.strokeStyle=rgba(HOT,.9*(1-sh));f.lineWidth=.8;f.stroke();f.restore();}}
  f.restore();
}

/* ------------------------------------------------------------------ choosing where */
export function warpRangeFeet(){try{return Number(game.settings.get(ID,'warpRange'))||0;}catch{return 60;}}
function distanceFeet(a,b){
  try{const m=canvas.grid.measurePath([a,b]);if(Number.isFinite(m?.distance))return m.distance;}catch{}
  return Math.hypot(b.x-a.x,b.y-a.y)/canvas.grid.size*(canvas.scene?.grid?.distance??canvas.dimensions?.distance??5);
}
function visible(point){
  if(game.user?.isGM)return true;
  try{return canvas.visibility?.testVisibility?.(point,{tolerance:Math.max(4,canvas.grid.size*.2)})!==false;}catch{return true;}
}
/** Let the owner click a destination, then play the warp for everyone. */
/* (12.0.0-beta.6) onPick: the point is handed to it and no warp is played here (the Decoy places itself there); label: what the cursor's tag says. */
export function chooseWarp(token,{style='wings',look=defaultWarpLook(),onPick=null,label:tag=null}={}){
  if(!token?.document?.isOwner)throw new Error('Pin a character you own to warp.');
  if(!canvas?.ready)throw new Error('The scene is not ready.');
  if(active.size&&[...active].some(fx=>fx.uuid===token.document.uuid))return Promise.resolve(false);
  return new Promise(resolve=>{
    const L=ensureLayer();if(!L){resolve(false);return;}
    const el=L.el,doc=el.ownerDocument,range=warpRangeFeet(),from=centerOf(token),units=canvas.scene?.grid?.units||'ft';
    el.style.pointerEvents='auto';el.style.cursor='crosshair';
    let mouse=null,raf=null,done=false;
    const toWorld=e=>{const r=el.getBoundingClientRect(),sx=(canvas.app.renderer.screen.width||r.width)/r.width;return canvas.stage.worldTransform.applyInverse({x:(e.clientX-r.left)*sx,y:(e.clientY-r.top)*sx});};
    const state=p=>{const d=distanceFeet(from,p),inRange=!range||d<=range+.01,seen=visible(p);return {d,ok:inRange&&seen&&d>0.5,why:!inRange?`Beyond ${range} ${units}`:!seen?'Somewhere you can see':''};};
    const paint=()=>{raf=null;if(done)return;const L2=ensureLayer();const f=el.getContext('2d'),P=projector(L2.r,L2.dpr);f.setTransform(1,0,0,1,0,0);f.clearRect(0,0,el.width,el.height);
      const A=P.pt(from),ft=canvas.grid.size/(canvas.scene?.grid?.distance??5),R=range*ft*P.scale;
      if(range){f.save();f.setLineDash([6*L2.dpr,6*L2.dpr]);f.strokeStyle='rgba(255,0,255,.55)';f.lineWidth=1.5*L2.dpr;f.beginPath();f.arc(A.x,A.y,R,0,TAU);f.stroke();f.restore();
        const g=f.createRadialGradient(A.x,A.y,R*.6,A.x,A.y,R);g.addColorStop(0,'rgba(255,0,255,0)');g.addColorStop(1,'rgba(255,0,255,.07)');f.fillStyle=g;f.beginPath();f.arc(A.x,A.y,R,0,TAU);f.fill();}
      if(mouse){const s=state(mouse),B=P.pt(mouse),col=s.ok?'255,0,255':'226,90,90';
        f.strokeStyle=`rgba(${col},.75)`;f.lineWidth=1.5*L2.dpr;f.setLineDash([3*L2.dpr,5*L2.dpr]);f.beginPath();f.moveTo(A.x,A.y);f.lineTo(B.x,B.y);f.stroke();f.setLineDash([]);
        const r=canvas.grid.size*.5*P.scale;f.save();f.translate(B.x,B.y);f.rotate(Math.PI/4);f.strokeStyle=`rgba(${col},.95)`;f.lineWidth=2*L2.dpr;f.shadowColor=`rgba(${col},1)`;f.shadowBlur=10;f.strokeRect(-r*.7,-r*.7,r*1.4,r*1.4);f.restore();
        f.font=`600 ${12*L2.dpr}px "Keepsake Sans",system-ui,sans-serif`;f.fillStyle='rgba(20,10,16,.85)';const label=s.ok?`${tag?tag:look==='flicker'?'Flicker':look===CLOAK_WARP?'Cloak warp':WARP_LOOKS[look]?WARP_LOOKS[look].label+' warp':style==='bare'?'Step through':'Warp'} · ${Math.round(s.d)} ${units}`:s.why;const w=f.measureText(label).width+14*L2.dpr;
        f.fillRect(B.x+r+6*L2.dpr,B.y-11*L2.dpr,w,22*L2.dpr);f.fillStyle=s.ok?'#f6d2ee':'#f0a0a0';f.fillText(label,B.x+r+13*L2.dpr,B.y+4*L2.dpr);}
      f.font=`600 ${12*L2.dpr}px "Keepsake Sans",system-ui,sans-serif`;const tip=tag?`${tag}: click the spot · right-click or Esc to cancel`:'Click where she steps out · right-click or Esc to cancel',tw=f.measureText(tip).width+20*L2.dpr;f.fillStyle='rgba(20,10,16,.88)';f.fillRect(el.width/2-tw/2,16*L2.dpr,tw,26*L2.dpr);f.fillStyle='#cfae76';f.fillText(tip,el.width/2-tw/2+10*L2.dpr,33*L2.dpr);
    };
    const queue=()=>{if(!raf)raf=requestAnimationFrame(paint);};
    const end=result=>{if(done)return;done=true;el.style.pointerEvents='none';el.style.cursor='';cancelAnimationFrame(raf);el.getContext('2d').clearRect(0,0,el.width,el.height);
      el.removeEventListener('pointermove',move);el.removeEventListener('pointerdown',down);el.removeEventListener('contextmenu',ctx);el.removeEventListener('wheel',zoom);doc.removeEventListener('keydown',key,true);canvas.app.ticker.remove(queue);resolve(result);};
    const move=e=>{mouse=toWorld(e);queue();};
    const down=e=>{e.preventDefault();e.stopPropagation();if(e.button!==0){end(false);return;}const p=toWorld(e),s=state(p);if(!s.ok){ui.notifications?.warn(`Warp: ${s.why||'Choose another spot'}`);return;}end(true);if(typeof onPick==='function')void Promise.resolve().then(()=>onPick(p)).catch(e=>console.warn('Yvaelle’s Toolbox | pick',e));else void warp(token,p,{style,look});};
    const ctx=e=>{e.preventDefault();end(false);};
    // (test.18) while she chooses where to step out, the mouse wheel still zooms the map: the choosing layer sits over
    // Foundry's canvas and used to swallow the wheel. It is handed to the canvas as the same event (Foundry zooms when
    // its own canvas is the target); should that not move the view, the view is zoomed directly, about the pointer.
    const zoom=e=>{e.preventDefault();e.stopPropagation();const view=canvas.app?.view,s0=canvas.stage.scale.x;
      try{view?.dispatchEvent(new WheelEvent('wheel',{deltaX:e.deltaX,deltaY:e.deltaY,deltaMode:e.deltaMode,clientX:e.clientX,clientY:e.clientY,screenX:e.screenX,screenY:e.screenY,ctrlKey:e.ctrlKey,shiftKey:e.shiftKey,altKey:e.altKey,metaKey:e.metaKey,bubbles:true,cancelable:true}));}catch{}
      if(canvas.stage.scale.x===s0&&!e.ctrlKey&&!e.shiftKey){try{const k=e.deltaY<0?1.05:.95,lo=canvas.dimensions?.scale?.min??.1,hi=canvas.dimensions?.scale?.max??3,s1=Math.max(lo,Math.min(hi,s0*k));
        if(s1!==s0){const w=toWorld(e),c=canvas.stage.pivot;canvas.pan({x:w.x+(c.x-w.x)*s0/s1,y:w.y+(c.y-w.y)*s0/s1,scale:s1});}}catch{}}
      queue();};
    const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();end(false);}};
    el.addEventListener('pointermove',move);el.addEventListener('pointerdown',down);el.addEventListener('contextmenu',ctx);el.addEventListener('wheel',zoom,{passive:false});doc.addEventListener('keydown',key,true);
    canvas.app.ticker.add(queue);queue();
  });
}
/** Start a warp to a world point (owner only); every client plays it. */
/** (12.0.0-beta.5) The cloak warp: her cloak's look sweeps her away here, she is moved while she is hidden, and the same
 * look brings her back there. It is her synced cloak, so every client sees it (other players: nothing, then her arrival).
 * Already faded: she is simply moved, and stays faded. Returns false when she has no cloak to wear (the caller then
 * plays an ordinary warp). */
async function cloakWarp(token,to){
  const api=game.modules.get(ID)?.api,inv=api?.v11?.invisibility;if(!inv?.cloak||!inv.status)return false;
  let v;try{v=resolveV11(token.document);}catch{return false;}
  if(v.invisLooks===false)return false;
  const wait=ms=>new Promise(r=>setTimeout(r,ms)),T=CLOAK_QUICK.warp,look=isCloak(v.invisSkin)?v.invisSkin:'c',st=()=>inv.status(token)??{};
  const already=!!st().flag?.on;
  if(!already){
    if(st().phase&&st().phase!=='solid')return false;                 // (a spell's invisibility or a drain is playing: not ours to interrupt)
    if(inv.cloak(token,true,{look,T})===false)return false;
    if(!soundOn(token.document,'cloak'))playCue(token,'warpSeam');   // (beta.7: with V12 sounds on her cloak has its own, played by the cloak itself)
    await wait(T*1000+90);
  }
  // (13.0.2) whatever the move does, the cloak this warp put on comes off again
  try{await moveToken(token,to);await wait(140);}
  finally{if(!already)inv.cloak(token,false,{T});}
  return true;
}
/** (12.0.0-beta.6) How long after a warp begins she leaves the spot she stood on (ms): the moment her token is moved.
 * (The Decoy times her copy's appearance to it.) */
export function warpLeaveMs(token,to,{look=defaultWarpLook()}={}){
  try{
    if(look===CLOAK_WARP)return Math.round(CLOAK_QUICK.warp*1000);
    const fx={look,from:centerOf(token),to:{x:to.x,y:to.y},token};timeline(fx);
    const ms=(fx.moveT-OFFSET)*1000;return Number.isFinite(ms)&&ms>0?Math.round(ms):1200;
  }catch{return 1200;}
}
export async function warp(token,to,{style='wings',look=defaultWarpLook()}={}){
  const doc=token.document;if(!doc?.isOwner)throw new Error('You can only warp a character you own.');
  if(look===CLOAK_WARP){if(await cloakWarp(token,to))return true;look='seam';}
  const land=landing(token,to);to={x:land.x+token.w/2,y:land.y+token.h/2};
  const from=centerOf(token),msg={type:'warp',uuid:doc.uuid,from,to,style,look,start:Date.now()};
  game.socket?.emit(`module.${ID}`,msg);
  playWarp({...msg,move:true});
  // with the wings out they keep the form they have: the warp bends them, no reaction cue reshapes them
  if(style!=='bare'&&look==='flicker'){try{const api=game.modules.get(ID)?.api;if(api?.getState?.(token)?.enabled)await api.flare?.(token,{strength:.85});}catch{}}
  return true;
}
export function registerWarp(){
  Hooks.on('updateToken',onTokenMove);
  game.settings.register(ID,'warpBendTokens',{name:'Warps bend nearby tokens',hint:'The bend in space around a warp also bends other tokens and drawings near her, not just the map. On this screen only.',scope:'client',config:true,type:Boolean,default:false});
  game.settings.register(ID,'warpArrival',{name:'Warp arrival',hint:'How a warp lands. Magenta pulse: a soft magenta pulse spreads out where she arrives. Filament wisps: a few threads curl in and settle into her. On this screen only.',scope:'client',config:true,type:String,choices:{pulse:'Magenta pulse',wisps:'Filament wisps'},default:'pulse'});
  game.settings.register(ID,'warpRange',{name:'Warp range',hint:'How far Ellie can warp, in scene units. 0 means any visible spot.',scope:'world',config:false,type:Number,range:{min:0,max:500,step:5},default:60});
}
