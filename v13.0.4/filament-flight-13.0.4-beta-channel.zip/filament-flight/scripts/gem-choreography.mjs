import {POSES,ease,unit,mixWeights,weightsFor} from './poses.mjs?v=13.0.4';
import {sweepPoint} from './flight-dynamics.mjs?v=13.0.4';
import {sampleBitAnimation} from './bit-animation.mjs?v=13.0.4';
import {sampleBitResonance} from './bit-resonance.mjs?v=13.0.4';
import {structureBitStation} from './energy-structures.mjs?v=13.0.4';
import {sampleWingStabilization,sampleWingTransfer,wingStabilizationStations} from './wing-station-motion.mjs?v=13.0.4';
import {sampleBitIntent} from './bit-intent.mjs?v=13.0.4';
import {BIT_STATIONS} from './wing-controls.mjs?v=13.0.4';
import {COMPACT_BIT_IDS,sampleCompactStation} from './compact-bit-formations.mjs?v=13.0.4';
import {bitExpressionContext,sampleBitExpression} from './bit-expression.mjs?v=13.0.4';
import {projectedHardwareActivity} from './projected-effect-programs.mjs?v=13.0.4';
import {withCoreActivity} from './bit-core-states.mjs?v=13.0.4';
import {applyBitLanternPose,applyBitLanternHardware,bitLanternFocus,bitLanternWeight,bitLanternPoseClock,bitLanternAnimation,bitLanternHeldFlight,bitLanternTarget,bitLanternRoutes,bitLanternReturnNow,bitLanternReturnPaths,bitLanternWingFlight,applyBitLanternMountingPose} from './bit-lantern.mjs?v=13.0.4';

const TAU=2*Math.PI;
const mix=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t);
const RESONANT_NEUTRAL=[[188,-151,-24,.28],[174,199,-24,-.24]];
const ANCHORED_POSES=new Set(['forwardGuard','cocoon','wrap','crossed']);
const EMPTY_EVENTS=Object.freeze([]);
const VARIANT_CHANNELS=Object.freeze({fraying:'damage',fissures:'damage',recoil:'instability',tremor:'instability',
  phaseTears:'glitch',desync:'glitch',corona:'overdrive',circuit:'overdrive',binding:'suppression',drain:'suppression',unravelling:'collapse',remnants:'collapse',
  torsion:'instability',refraction:'glitch',convergence:'overdrive',
  scarStitch:'damage',emberFray:'damage',pendulum:'instability',interference:'instability',spectralShear:'glitch',memoryEcho:'glitch',roseEngine:'overdrive',lightningWeave:'overdrive',sealedHalo:'suppression',hush:'suppression',fallingScript:'collapse',seedRecall:'collapse'});
const CONDITION_CHANNELS=Object.freeze({damaged:'damage',unstable:'instability',glitching:'glitch',overdrive:'overdrive',suppressed:'suppression',collapsed:'collapse'});
// x is mirrored per wing; z is the token's front/back plane, never elevation.
const PLACES={
  neutral:[[230,-150,-24,.32],[214,211,-24,-.24]],
  forwardGuard:[[92,-110,29,.15],[84,116,32,-.18]],
  cocoon:[[63,-166,35,.10],[61,164,38,-.10]],
  wrap:[[87,-110,29,.20],[78,119,33,-.22]],
  aggressiveFlare:[[184,-199,-24,.52],[229,115,-24,-.62]],
  raised:[[64,-217,-15,.02],[163,-154,-18,.64]],
  trailing:[[115,63,-50,-.24],[89,213,-50,-.36]],
  collapsed:[[41,65,-20,.48],[58,122,-20,-.44]],
  drooped:[[102,102,-25,.55],[115,223,-25,-.56]],
  crossed:[[89,-61,32,.74],[83,104,36,-.74]]
};

function supportAnchors(follow,flight,time,physical){
  const cfg=flight.gems,free=cfg.placement!=='follow',anchors={};
  for(const station of COMPACT_BIT_IDS){
    const side=station.startsWith('left')?-1:1,index=station.endsWith('Lower')?1:0,defaults=BIT_STATIONS[station];
    let center=[0,0,0],angle=0,anchored=0;
    if(free){center=[100*(cfg[`${station}X`]??defaults.x),100*(cfg[`${station}Y`]??defaults.y),-24];angle=(index?-.24:.28)*side;}
    else{
      for(let i=0;i<POSES.length;i++){
        const w=follow[i];if(w<.000001)continue;let pose=POSES[i];
        if(pose==='leftForwardWrap')pose=side<0?'wrap':'neutral';
        if(pose==='rightForwardWrap')pose=side>0?'wrap':'neutral';
        const place=physical&&cfg.artwork==='resonant'&&pose==='neutral'?RESONANT_NEUTRAL[index]:PLACES[pose][index];
        for(let j=0;j<3;j++)center[j]+=w*place[j]*(j===0?side:1);angle+=w*place[3]*side;
        if(ANCHORED_POSES.has(pose))anchored+=w;
      }
      const placed=structureBitStation(center,angle,index,side,flight.structureAnimation,time);center=placed.center;angle=placed.angle;
    }
    anchors[station]={x:center[0],y:center[1],z:center[2],angle,anchored};
  }
  return anchors;
}

/** Use the resolved artwork channels: choosing None or disabling a feature also
 * stops its gem reaction. No actor/HP reads and no separate effect timelines. */
export function gemChannels(v) {
  const c={damage:v?.damage??0,instability:v?.instability??0,glitch:v?.glitch??0,
    overdrive:unit(((v?.energy??1)-1)/.4),collapse:v?.collapse??0,suppression:v?.suppression??0,
    impact:v?.flare??0,heal:v?.healing??0,pulse:v?.pulse??0};
  const variant=v?.variant;
  const field=VARIANT_CHANNELS[variant?.id];
  const semantic=variant?.amount>0?(CONDITION_CHANNELS[variant.condition]??field):field;
  if(semantic)c[semantic]=Math.max(c[semantic],variant.amount);
  for(const events of [v?.bursts,v?.reactions])for(const r of events??EMPTY_EVENTS) {
    // (11.0.0-test.5) a cue that carries no light of its own adds none (undefined here made the channel NaN)
    const amount=Number(r.envelope??r.strength)||0;
    if(['damage','critical','flare'].includes(r.kind))c.impact=Math.max(c.impact,amount*(r.kind==='critical'?1.5:1));
    if(['heal','reform'].includes(r.kind))c.heal=Math.max(c.heal,amount);
    if(r.kind==='pulse')c.pulse=Math.max(c.pulse,amount);
    if(r.kind==='stutter')c.glitch=Math.max(c.glitch,amount);
  }
  for(const key of Object.keys(c))c[key]=unit(c[key]);
  if(v?.animated===false){c.glitch=c.impact=c.heal=c.pulse=0;}
  return c;
}

/** Four deterministic controllers, sampled on the existing capped rig ticker.
 * Symbols keep their proportions; only their center, rotation and light move.
 */
export function choreographedGems(weights,phase,visual,flight,side,lanternFrame=null) {
  // The frame owner supplies one fresh object for its paired wing samples.
  // Consume shared preparation on the opposite side, so even a reused frame
  // starts a new pair without retaining the previous snapshot or projection.
  let prepared=lanternFrame?.gemPreparation;
  if(!prepared||prepared.side===side||prepared.flight!==flight||prepared.visual!==visual||prepared.weights!==weights||prepared.phase!==phase)prepared=null;
  if(prepared)delete lanternFrame.gemPreparation;
  const cfg=flight.gems,physical=cfg.appearance==='physical',classic=cfg.style==='classic',free=cfg.placement!=='follow';
  const amount=cfg.strength,animated=!classic&&cfg.animated&&visual?.animated!==false;
  // Placement and machinery have separate clocks. Classic holds the support
  // stations still while the selected physical mechanism and its energy live.
  const hardwareAnimated=cfg.animated&&visual?.animated!==false&&amount>0;
  const hardwareTime=hardwareAnimated?(visual?.time??0)*cfg.speed:0;
  const time=animated?(visual?.time??0)*cfg.speed:0,seed=(visual?.seed??0)%173/173*TAU;
  const compact=flight.compactBits===true;
  const wingLantern=bitLanternWingFlight(flight);
  const c=prepared?.c??(cfg.reactive&&!classic?gemChannels(visual):gemChannels(null));
  const hardwareChannels=prepared?.hardwareChannels??(cfg.reactive?gemChannels(visual):gemChannels(null));
  const expressionContext=prepared?prepared.expressionContext:compact?null:bitExpressionContext(flight,time);
  if(!animated){c.glitch=c.impact=c.heal=c.pulse=0;}
  if(!hardwareAnimated){hardwareChannels.glitch=hardwareChannels.impact=hardwareChannels.heal=hardwareChannels.pulse=0;}
  const outer=flight.poseAnimation?.tipWeights??weights,follow=prepared?.follow??(compact?weights:classic?weightsFor('neutral'):mixWeights(weights,outer,.75));
  const anchors=prepared?prepared.anchors:compact?null:supportAnchors(follow,flight,time,physical),stations=prepared?prepared.stations:compact?null:wingStabilizationStations(flight);
  const formation=flight.formation??{},growth=formation.growth??1,fold=formation.fold??0;
  // Capture only the ordinary choreography's phase. Explicit deployment,
  // count edits and interrupted allocation transfers retain their live
  // progress. Dedicated cradle lanes gather from this capture;
  // the native cone itself stays at the token centre.
  // The two wing sides share one call-local projection preparation. Capture
  // recursion receives no cache, and the frame owner never retains it.
  let projection=prepared?.projection;
  if(!projection){
    const heldClock=bitLanternPoseClock(flight,0,{relative:!compact});
    const heldFlight=bitLanternHeldFlight(flight);
    let heldParts=null;
    if(!compact&&!wingLantern&&bitLanternWeight(flight)>0){
      const heldVisual={...visual,time:cfg.speed?heldClock/cfg.speed:0,animated:heldFlight.gems.animated},heldInput={...heldFlight,lantern:undefined,bitFormationTransition:undefined,bitLanternCapture:true},heldFrame={};
      heldParts=[-1,1].flatMap(heldSide=>choreographedGems(weights,phase,heldVisual,heldInput,heldSide,heldFrame));
    }
    const projectionTarget=heldParts?bitLanternTarget(flight,heldParts):null;
    const projectionRoutes=heldParts?bitLanternRoutes(flight,heldParts,Array.isArray(flight.lantern?.transitionCapture)):null;
    const returnNow=wingLantern?null:bitLanternReturnNow(flight),returnTime=returnNow===null?0:(visual?.time??0)+(returnNow-flight.lantern.clock*1000)/1000;
    let returnParts=null;
    if(!compact&&returnNow!==null){
      const returnVisual={...visual,time:returnTime},returnInput={...flight,lantern:undefined,bitFormationTransition:undefined,bitLanternCapture:true},returnFrame={};
      returnParts=[-1,1].flatMap(returnSide=>choreographedGems(weights,phase,returnVisual,returnInput,returnSide,returnFrame));
    }
    const returnDestinations=returnParts?.map(p=>({station:p.station,x:p.points[0][0],y:p.points[0][1],z:p.points[0][2],angle:p.hardware.angle}));
    const returnPaths=heldParts&&returnDestinations?bitLanternReturnPaths(flight,heldParts,returnDestinations):null;
    projection={heldClock,heldFlight,heldParts,projectionTarget,projectionRoutes,returnParts,returnPaths};
  }
  if(lanternFrame&&!prepared)lanternFrame.gemPreparation={side,flight,visual,weights,phase,c,hardwareChannels,expressionContext,follow,anchors,stations,projection};
  const {heldClock,heldFlight,heldParts,projectionTarget,projectionRoutes,returnParts,returnPaths}=projection;
  const result=[];
  for(let index=0;index<2;index++) {
    let center=[0,0,0],angle=0,anchored=0;
    const station=`${side<0?'left':'right'}${index?'Lower':'Upper'}`;
    const stationIndex=COMPACT_BIT_IDS.indexOf(station),countWeight=flight.bitCount?.values?.[stationIndex]??(stationIndex<(cfg.count??4)?1:0);
    // A fully absent compact instrument has no pixels or support duty. Leave
    // its exact destination lazy until an action capture explicitly needs it;
    // sampling it here would prepare every larger hidden Flow constellation.
    if(compact&&countWeight<=0&&!flight.bitHardwareAll)continue;
    let stabilization=null,stabilizationOptions=null;
    const clock=time*.85+index*2.3+side*.8+seed;let intent={amount:0},fault=0,collapse=0;
    if(!compact){
    const anchor=anchors[station];center=[anchor.x,anchor.y,anchor.z];angle=anchor.angle;anchored=anchor.anchored;
    intent=sampleBitIntent(flight,visual,side,index,center,angle+index*Math.PI);
    if(intent.amount)angle+=intent.turn;
    const loose=(1-.65*anchored)*(1-.7*c.suppression);
    stabilizationOptions={station,anchors,stations,time,seed,size:cfg.size??1,extent:flight.structureAnimation?.artworkExtent??1,
      formationWeights:Array.isArray(flight.bitHomeStations)?null:flight.bitCount?.formationWeights,
      strength:(cfg.stationMotionStrength??.55)*loose,enabled:animated&&cfg.stationMotion!==false&&amount>0,reducedMotion:flight.effective?.reducedMotion};
    stabilization=sampleWingStabilization(stabilizationOptions);
    center=[stabilization.x,stabilization.y,stabilization.z];angle+=stabilization.angle-anchor.angle;
    // Overdrive locks the constellation into a balanced, slightly wider frame.
    if(!free)center=mix(center,[side*(cfg.artwork==='resonant'?185:205),index?180:-165,center[2]],amount*c.overdrive*(follow[0]+follow[5]));
    if(!free)center[0]+=side*amount*c.overdrive*(index?5:7);angle*=1-.9*c.overdrive;
    const broken=amount*(c.damage*.4+c.instability)*(1-.85*c.heal);
    if(!free){center[0]+=side*broken*(4+7*Math.sin(clock*1.4));center[1]+=broken*(index?13:7)*Math.sin(clock*1.2+side);}
    angle+=broken*.30*Math.sin(clock*1.1);
    // Local desynchronisation makes a brief correction and eases back; never token flashing.
    fault=0;
    if(animated&&c.glitch) {
      const event=(visual?.variant?.time??visual?.effectTime??time)*5+index*2+side;
      const step=Math.floor(event),p=event-step,jump=Math.sin(step*17.31+seed);
      if(jump>.25){
        fault=ease(p/.12)*(1-ease((p-.42)/.58));
        if(!free){center[0]+=side*amount*c.glitch*(physical?5:13)*jump*fault;center[1]+=amount*c.glitch*(physical?2.5:6)*Math.sin(step*4.7)*fault;}
      }
    }
    collapse=amount*c.collapse*(1-.9*c.heal);
    const fallen=physical?[side*(36+index*10),-23+index*34,-28]:[side*(62+index*39+9*Math.sin(clock*.5)),88+index*83+14*Math.cos(clock*.6),-18];
    if(!free){
      center=mix(center,fallen,collapse);
      center=mix(center,[side*(38+index*11),index?95:-57,-18],amount*c.suppression*.7);
    }
    angle+=collapse*side*(index?-.9:1.1);
    // Damage knocks the constellation out, healing draws it gently inward.
    const surge=amount*(c.impact*17+c.pulse*7-c.heal*7);
    if(!free){center[0]+=side*surge;center[1]+=(index?1:-1)*surge*.45;}
    angle+=side*amount*c.impact*(index?-.3:.3);
    if(!free)center=sweepPoint(center,.96,side,follow,flight.movement);
    if(!classic)angle+=amount*(flight.movement?.sweep??0)*((flight.movement?.bank??0)*.18+(flight.movement?.flowX??0)*.10);
    }
    let compactPose=null,expression=null;
    if(compact){compactPose=sampleCompactStation(station,flight,time);center=[compactPose.x,compactPose.y,compactPose.z*24];angle=compactPose.angle-index*Math.PI;intent=compactPose.intent??{amount:0};}
    else if(expressionContext){
      expression=sampleBitExpression(expressionContext,{station,point:{x:center[0],y:center[1],z:center[2]/24},attached:true,passive:false});
      if(cfg.stationMotion!==false)angle+=expression.angle;
    }
    // Takeoff leads from the two roots. Landing reels the controllers inward.
    const root=[side*27,-23+index*18,-28],formed=ease((growth-(index?.07:0))/(index?.93:1));
    const globalDeployment=unit(flight.bitDeployment??1)*unit(compact?1:flight.wingBitHandoff??1),launchDelay=compact&&flight.bitTransition?.active?stationIndex*.045:0;
    const bitDeployment=unit((globalDeployment-launchDelay)/(1-launchDelay))*unit(countWeight);
    const deployment=formed*(1-ease(fold))*unit(flight.stabilizerDeployment??1)*bitDeployment;
    center=mix(root,center,deployment);
    // A short peel-out arc makes the four pieces emerge from the two back roots.
    const launch=Math.sin(Math.PI*deployment);
    center[0]+=side*launch*(10+index*3);center[1]+=(index?1:-1)*launch*12;
    const drift=animated&&visual?.energyPulses?1+.07*amount*Math.sin(clock*1.7):1;
    // Independent bit recall follows the same shoulder-root launch path as the
    // wings, while leaving the wing formation and condition state untouched.
    // Shrink only at the end of the return so the travel remains readable.
    const visibility=ease(bitDeployment/.16),recallScale=.16+.84*ease(bitDeployment/.42);
    const strength=ease(growth/.2)*(1-.65*fold)*(1-.65*collapse)*(1-.6*c.suppression)*visibility;
    // Exterior support routes intentionally pass beyond the wing's old clamp;
    // physical bit surfaces are independently positioned and remain crisp.
    if(compact)center=[Math.max(-257,Math.min(257,center[0])),Math.max(-231,Math.min(265,center[1])),center[2]];
    let lanternPose=null;
    if(!compact&&flight.lantern){
      const base={station,x:center[0],y:center[1],z:center[2],angle:angle+index*Math.PI,intent,brightness:1};
      const held=heldParts?.find(p=>p.station===station),anchor=held?.hardware?
        {x:held.points[0][0],y:held.points[0][1],z:held.points[0][2],angle:held.hardware.angle}:base;
      const returnPart=returnParts?.find(p=>p.station===station),returnPose=returnPart?{
        x:returnPart.points[0][0],y:returnPart.points[0][1],z:returnPart.points[0][2],angle:returnPart.hardware.angle}:null;
      const posed=applyBitLanternPose(base,flight,time,{station,anchor,target:projectionTarget,routes:projectionRoutes,returnPose,returnPath:returnPaths?.get(station),deferMounting:true});
      if(posed!==base){lanternPose=posed;center=[posed.x,posed.y,posed.z];angle=posed.angle-index*Math.PI;intent=posed.intent??intent;}
    }
    // Count redistribution starts from the displayed wing station. Compact
    // formations already apply their captured transition in their own sampler.
    const transition=flight.bitFormationTransition,previous=!compact&&transition?.wingFromPoses?.find(p=>p.station===station);
    if(previous&&transition.progress<1){
      // Intercept the moving formation at this handoff's shared end time.
      // Routing toward the current moving point can change left/right or the
      // nearest exterior passage mid-transfer, producing a visible teleport.
      // This endpoint is deterministic on every client and joins the live
      // sampler exactly when the transition completes (no stored frame state).
      const target={x:center[0],y:center[1],z:center[2],angle};
      if(free&&stabilizationOptions){
        const remaining=(1-transition.progress)*(transition.duration??850)/1000;
        const interceptTime=Math.round((time+remaining*(animated?cfg.speed:0))*1e8)/1e8;
        const rawIntercept=sampleWingStabilization({...stabilizationOptions,time:interceptTime});
        const heldSupport=sampleWingStabilization({...stabilizationOptions,time:heldClock,
          enabled:!classic&&heldFlight.gems.animated&&heldFlight.gems.stationMotion!==false&&amount>0,reducedMotion:false});
        const intercept=applyBitLanternPose(rawIntercept,flight,interceptTime,{station,anchor:heldSupport,target:projectionTarget,routes:projectionRoutes,deferMounting:true}),currentSupport=applyBitLanternPose(stabilization,flight,time,{station,anchor:heldSupport,target:projectionTarget,routes:projectionRoutes,deferMounting:true});
        target.x=deployment===1?intercept.x:target.x+(intercept.x-currentSupport.x)*deployment;
        target.y=deployment===1?intercept.y:target.y+(intercept.y-currentSupport.y)*deployment;
        target.z=deployment===1?intercept.z:target.z+(intercept.z-currentSupport.z)*deployment;
        target.angle+=intercept.angle-currentSupport.angle;
      }
      const transfer=sampleWingTransfer({...previous,angle:previous.angle-index*Math.PI},target,transition.progress,{size:cfg.size??1,extent:flight.structureAnimation?.artworkExtent??1});
      center=[transfer.x,transfer.y,transfer.z];angle=transfer.angle;
    }
    const projectedWork=projectedHardwareActivity(flight,station,center,angle+index*Math.PI,hardwareTime);
    if(projectedWork)angle+=projectedWork.turn;
    const lanternFocus=!projectedWork&&bitLanternWeight(flight,station)>0?
      compactPose?.focus??lanternPose?.focus??bitLanternFocus(flight,station,center):null;
    let scale=(compact?.76:index?.64:.8)*(cfg.size??1)*recallScale*(compactPose?.scale??1);
    if(flight.bitLanternCapture){
      if((!compact||flight.lantern?.mountingTransition?.compact===true)&&flight.lantern?.mountingTransition?.progress<1){
        const shown=applyBitLanternMountingPose({station,x:center[0],y:center[1],z:center[2],angle:angle+index*Math.PI,scale:recallScale*(compactPose?.scale??1)},flight,station);
        center=[shown.x,shown.y,shown.z];angle=shown.angle-index*Math.PI;scale=(compact?.76:index?.64:.8)*(cfg.size??1)*shown.scale;
      }
      result.push({id:`gem-${index}`,station,points:[[...center,.92]],hardware:{angle:angle+index*Math.PI,scale}});continue;
    }
    if(physical) {
      // The same fault envelope dims the core and field during its corrective
      // twitch. Movement amount governs motion, not the health of the power core.
      const hc=hardwareChannels,hardwareClock=hardwareTime*.85+index*2.3+side*.8+seed;
      const stationEnergy=stabilization?.energy??1;
      const hardwareDrift=(hardwareAnimated&&visual?.energyPulses?1+.07*amount*Math.sin(hardwareClock*1.7):1)*stationEnergy*(compactPose?.expression?.energy??expression?.energy??1)*(projectedWork?.energy??1);
      let hardwareFault=fault;
      // Compact formations skip the wing-station displacement block above,
      // but their core still uses the same staggered corrective fault. This
      // response remains local to the mechanism and never moves its orbit.
      if((compact||classic)&&hardwareAnimated&&hc.glitch){
        const event=(visual?.variant?.time??visual?.effectTime??hardwareTime)*5+index*2+side;
        const step=Math.floor(event),p=event-step;
        if(Math.sin(step*17.31+seed)>.25)hardwareFault=ease(p/.12)*(1-ease((p-.42)/.58));
      }
      const power=unit((.8+.16*hc.overdrive+.16*hc.heal+.12*hc.pulse+.08*hc.impact)*hardwareDrift*
        (.28+.72*ease(deployment))*(1-.84*hc.suppression)*(1-.92*hc.collapse*(1-.9*hc.heal))*(1-.9*hc.glitch*hardwareFault));
      // A light posture owns placement, not an actor's existing mechanical
      // damage/instability correction. Its healthy channels are zero, so
      // retaining this response does not reintroduce the ordinary idle motion.
      const mechanical=cfg.mechanicalResponse&&hardwareAnimated?amount:0;
      // Each housing corrects on a staggered cycle; the metal never phases out.
      const beat=clock*.37+index*.21+side*.13,part=beat-Math.floor(beat);
      const correction=ease(part/.22)*(1-ease((part-.48)/.52));
      const repair=cfg.repairFocus&&hardwareAnimated?hc.heal:0;
      const aperture=cfg.shutters?unit(deployment*(.5+.5*hc.overdrive+.35*repair)*(1-.92*hc.suppression)*(1-hc.collapse*(1-.9*repair))):1;
      angle+=mechanical*(c.damage*.10*correction*(index?-.6:1)+c.instability*.09*Math.sin(clock*1.7+side));
      // Mount captures contain the final physical controller heading. Apply
      // their bridge after live allocation and mechanical corrections so an
      // interrupted switch cannot add those corrections to the capture twice.
      if((!compact||flight.lantern?.mountingTransition?.compact===true)&&flight.lantern?.mountingTransition?.progress<1){
        const shown=applyBitLanternMountingPose({station,x:center[0],y:center[1],z:center[2],angle:angle+index*Math.PI,scale:recallScale*(compactPose?.scale??1)},flight,station);
        center=[shown.x,shown.y,shown.z];angle=shown.angle-index*Math.PI;
        scale=(compact?.76:index?.64:.8)*(cfg.size??1)*shown.scale;
      }
      result.push({id:`gem-${index}`,strength:ease(growth/.06)*visibility*(compactPose?.brightness??1),points:[[...center,.92]],
        hardware:{intent,...(lanternFocus||compactPose?.focus||lanternPose?.focus?{focus:lanternFocus??compactPose?.focus??lanternPose.focus}:{}),...(projectedWork?.target?{workTarget:projectedWork.target}:{}),tool:compactPose?.tool??(cfg.behaviour?.enabled!==false&&['inspect','mend'].includes(intent.kind)&&intent.amount>0?{type:intent.kind==='inspect'?'lens':'probe',amount:intent.amount*.3*(cfg.behaviour?.energy??.5),progress:intent.progress??0}:null),stabilization:stabilization?{...stabilization,positionLocked:free}:null,angle:angle+index*Math.PI,scale,roll:hardwareAnimated?amount*.28*Math.sin(hardwareClock*.7):0,open:deployment,power,
          artwork:cfg.artwork??'resonant',animation:cfg.artwork==='animated'?sampleBitAnimation({flight,channels:hc,side,index,time:hardwareTime,deployment,animated:hardwareAnimated}):null,
          resonance:sampleBitResonance({flight:cfg.coreState==='auto'&&projectedWork?{...flight,bitActivity:projectedWork}:!flight.bitActivity&&stabilization?.activity?{...flight,bitActivity:stabilization.activity}:cfg.coreState==='auto'&&!flight.bitActivity&&(compactPose?.activity||expression?.activity||intent.amount>0)?{...flight,bitActivity:compactPose?.activity??expression?.activity??{state:['inspect','mend'].includes(intent.kind)?'scanning':'charging',amount:intent.amount}}:flight,channels:hc,side,index,time:hardwareTime,deployment,animated:hardwareAnimated}),glowMode:cfg.glowMode??'core',
          design:cfg.design??'original',metalHighlights:!!cfg.metalHighlights,highlightStrength:cfg.highlightStrength??.45,
          coreDepth:cfg.coreDepth===true,coreDepthStrength:cfg.coreDepthStrength??.35,
          shutters:!!cfg.shutters,aperture,suspendedCore:!!cfg.suspendedCore,
          coreAngle:cfg.suspendedCore?-.28*angle+(hardwareAnimated?amount*.055*Math.sin(hardwareClock*.7):0):0,
          desync:mechanical*hc.glitch*hardwareFault,repair,scan:repair>0?((hardwareTime*.6+index*.37+side*.19)%1+1)%1:0}});
      if((cfg.coreState??'idle')==='idle'){const work=projectedWork??compactPose?.activity??(cfg.behaviour?.enabled!==false&&['inspect','mend'].includes(intent.kind)?{state:'scanning',amount:intent.amount*.3}:null);if(work)result.at(-1).hardware=withCoreActivity(result.at(-1).hardware,work,{responsive:cfg.assetStates!==false});}
      if(!projectedWork)result.at(-1).hardware=applyBitLanternHardware(result.at(-1).hardware,flight,station,hardwareTime,{position:center,response:{
        power:(.8+.16*hc.overdrive+.16*hc.heal+.12*hc.pulse+.08*hc.impact)/.8*
          (1-.84*hc.suppression)*(1-.92*hc.collapse*(1-.9*hc.heal))*(1-.9*hc.glitch*hardwareFault),
        aperture:(.5+.5*hc.overdrive+.35*repair)/.5*(1-.92*hc.suppression)*(1-hc.collapse*(1-.9*repair)),
        charge:(1-.72*hc.suppression)*(1-.9*hc.collapse)}});
      if(!projectedWork&&!wingLantern&&cfg.artwork==='animated'&&bitLanternWeight(flight,station)>0){
        const hardware=result.at(-1).hardware,heldAnimation=sampleBitAnimation({flight,channels:hc,side,index,time:heldClock,deployment,animated:hardwareAnimated});
        hardware.animation=bitLanternAnimation(hardware.animation,heldAnimation,flight,station,hardwareTime);
      }
      continue;
    }
    if((!compact||flight.lantern?.mountingTransition?.compact===true)&&flight.lantern?.mountingTransition?.progress<1){
      const shown=applyBitLanternMountingPose({station,x:center[0],y:center[1],z:center[2],angle:angle+index*Math.PI,scale:recallScale*(compactPose?.scale??1)},flight,station);
      center=[shown.x,shown.y,shown.z];angle=shown.angle-index*Math.PI;scale=(compact?.76:index?.64:.8)*(cfg.size??1)*shown.scale;
    }
    const place=([a,b])=>[center[0]+scale*(a*Math.cos(angle)-b*Math.sin(angle)),center[1]+scale*(a*Math.sin(angle)+b*Math.cos(angle)),center[2],.92];
    const ring=Array.from({length:41},(_,i)=>place([15*Math.cos(i/40*TAU),31*Math.sin(i/40*TAU)]));
    const gem=[[0,-32],[4,-17],[10,-13],[4,-10],[0,1],[-4,-10],[-10,-13],[-4,-17],[0,-32]].map(place);
    result.push({id:`sigil-${index}`,width:.55,strength:.55*strength,points:ring},
      {id:`gem-${index}`,width:.8,strength:Math.min(1.2,(.85+.2*c.overdrive+.15*c.heal)*strength),points:gem},
      {id:`gem-core-${index}`,star:true,width:1.8,strength:Math.min(1,strength*.68*drift),points:[place([0,-13])]});
  }
  return result;
}
