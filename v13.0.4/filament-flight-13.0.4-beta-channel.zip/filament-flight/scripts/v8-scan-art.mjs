import {linkedScanBoundary} from './v86-linked-scan-geometry.mjs?v=13.0.4';
/** V8.6 multi-method robotic examination. Coded surface patterns, crossed
 * laser profiling and pulsed point reconstruction are distinct instruments.
 * Range rings and sparse sample clusters vary area work without a radial fan.
 * The same bounded, deterministic painter serves scene work and thoughts.
 * 100 painter units = the scan radius. No scene reads, timers or randomness. */
const TAU=Math.PI*2;
const clamp=n=>Math.max(0,Math.min(1,Number(n)||0));
const finite=(n,fallback)=>Number.isFinite(n)?n:fallback;
const ease=n=>{n=clamp(n);return n*n*(3-2*n);};
const lerp=(a,b,t)=>a+(b-a)*t;
const DETAIL=Object.freeze({low:{bands:5,segments:12,columns:7,rows:9,contours:3},standard:{bands:7,segments:18,columns:10,rows:13,contours:4},high:{bands:9,segments:24,columns:13,rows:17,contours:5}});
const GEOMETRIC_METHODS=Object.freeze({geometricStructuredLight:'structuredLight',geometricRadialRanging:'radialRanging',geometricSparseReconstruction:'sparseReconstruction',geometricEdgeTracing:'edgeTracing',geometricCrosshatchSurvey:'crosshatchSurvey'});
const METHODS=Object.freeze(['structuredLight','laserTriangulation','lidarReconstruction','radialRanging','sparseReconstruction','contourTomography','phaseInterferometry','edgeTracing','crosshatchSurvey',...Object.keys(GEOMETRIC_METHODS)]);
const SHARED_MEDICAL_PATTERNS=new Set(['structuredLight','lidarReconstruction','contourTomography','phaseInterferometry']);
const PALE='#ffc5f4',WHITE='#fff0fc',COOL='#b2b8ff';
const RGB=color=>/^#[\da-f]{6}$/i.test(color??'')?[1,3,5].map(i=>parseInt(color.slice(i,i+2),16)):[255,75,218];
const rgba=(rgb,a)=>`rgba(${rgb[0]},${rgb[1]},${rgb[2]},${a})`;
/** v10 beta: scans read clearly at table zoom (brighter, slightly heavier
 * lines and a resolve flash). Classic keeps the restrained v8.6 exposure. */
let scanLook='v10',LOOK_GAIN=1.7,LOOK_WIDTH=1.35;
export function setScanLook(look){scanLook=look==='classic'?'classic':'v10';LOOK_GAIN=scanLook==='v10'?1.7:1;LOOK_WIDTH=scanLook==='v10'?1.35:1;}
export const getScanLook=()=>scanLook;
function stroke(ctx,alpha,color,width,path){alpha*=LOOK_GAIN;if(!(alpha>.0001))return;ctx.globalAlpha=clamp(alpha);ctx.strokeStyle=color;ctx.lineWidth=width*LOOK_WIDTH;ctx.beginPath();path(ctx);ctx.stroke();}
function dot(ctx,x,y,size,alpha,color=PALE){alpha*=LOOK_GAIN;size*=LOOK_WIDTH;if(!(alpha>.001))return;ctx.globalAlpha=clamp(alpha);ctx.fillStyle=color;ctx.fillRect(x-size*.5,y-size*.5,size,size);}
function pathPoints(ctx,points){for(let i=0;i<points.length;i++){const p=points[i];if(i===0)ctx.moveTo(p.x,p.y);else ctx.lineTo(p.x,p.y);}}

/** Legacy geometric fields remain available to integrations. New region and
 * stage fields describe the FULL creature footprint, independent of emitter
 * position or focus. Area examination retains its chosen local work patch. */
function regionPoints(value){
  if(!Array.isArray(value))return null;
  const points=value.slice(0,64).map(p=>({x:Array.isArray(p)?p[0]:p?.x,y:Array.isArray(p)?p[1]:p?.y})).filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y));
  return points.length>=3?points:null;
}
function finiteRegion(value,polygon){
  const bounds=value&&[value.x,value.y,value.width,value.height].every(Number.isFinite)&&value.width>0&&value.height>0?value:null;
  if(bounds)return {x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height};
  if(!polygon)return null;
  const xs=polygon.map(p=>p.x),ys=polygon.map(p=>p.y),x=Math.min(...xs),y=Math.min(...ys),width=Math.max(...xs)-x,height=Math.max(...ys)-y;
  return width>0&&height>0?{x,y,width,height}:null;
}
export function scanArtworkGeometry(channel){
  const source=channel.source??{x:0,y:0},focus=channel.focus??source,dx=focus.x-source.x,dy=focus.y-source.y;
  const length=Math.max(4,Math.hypot(dx,dy)),radius=Math.max(2,Math.min(40,finite(channel.radius,20))),progress=clamp(channel.progress);
  const mode=channel.mode??(channel.targetBounds?'creatureScan':'areaScan'),creature=mode==='creatureScan';
  const polygons=Array.isArray(channel.regionPolygons)?channel.regionPolygons.slice(0,24).map(regionPoints).filter(Boolean):[];
  const polygon=regionPoints(channel.regionPolygon),region=finiteRegion(channel.regionBounds,polygons.length?polygons.flat():polygon);
  const method=METHODS.includes(channel.method)?channel.method:'structuredLight';
  const center=region?{x:region.x+region.width/2,y:region.y+region.height/2}:creature?{x:0,y:0}:focus;
  const halfWidth=region?region.width/2:creature?Math.max(2,Math.min(124,finite(channel.targetBounds?.halfWidth,53))):radius;
  const halfHeight=region?region.height/2:creature?Math.max(2,Math.min(124,finite(channel.targetBounds?.halfHeight,53))):radius*Math.max(.45,Math.min(1,finite(channel.aspect,.72)));
  const axis=channel.axis==='x'||channel.axis==='y'?channel.axis:(Math.abs(finite(channel.visitIndex,0))%2?'x':'y'),direction=channel.direction===-1?-1:1;
  const sweep=channel.static?.52:clamp((progress-.18)/.52),stage=channel.static?'sample':progress<.18?'acquire':progress<.70?'sweep':progress<.87?'sample':'resolve';
  const crossHalf=axis==='y'?halfWidth:halfHeight,scanHalf=axis==='y'?halfHeight:halfWidth;
  const bandWidth=Math.max(2.5,Math.min(10,scanHalf*.17)),sweepPosition=direction*lerp(-scanHalf-bandWidth,scanHalf+bandWidth,sweep);
  const angle=Math.atan2(dy,dx)+finite(channel.tilt,0),width=radius*finite(channel.aspect,.65),reach=length+lerp(-radius*.62,radius*.65,sweep);
  const exposureVariant=((Math.trunc(finite(channel.exposureVariant,finite(channel.visitIndex,0)))%3)+3)%3;
  const sources=Array.isArray(channel.sources)?channel.sources.slice(0,4).filter(p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y)).map(p=>({x:p.x,y:p.y,strength:clamp(finite(p.strength,1)),focus:Number.isFinite(p.focus?.x)&&Number.isFinite(p.focus?.y)?{x:p.focus.x,y:p.focus.y}:null})):[];
  return {source,focus,length,radius,progress,sweep,angle,width,reach,mode,creature,center,halfWidth,halfHeight,axis,direction,stage,crossHalf,scanHalf,bandWidth,sweepPosition,
    region,polygon,polygons,method,sources,cooperative:!!channel.cooperative||sources.length>1,scanRegionPolygon:regionPoints(channel.scanRegionPolygon),frameRotation:finite(channel.frameRotation,0),clipRadius:Math.max(0,finite(channel.clipRadius,creature?0:100)),scanStage:channel.scanStage??(creature?'close':'area'),exposureVariant,
    acquire:ease(progress/.18),resolve:ease((progress-.87)/.13),sample:ease((progress-.68)/.18),visitIndex:Math.abs(Math.trunc(finite(channel.visitIndex,0)))};
}
/** A renderer-update map shares normalized geometry between bounds and paint.
 * The caller discards it after that update; mutable previews and later clocks
 * always prepare their own geometry. No cache or native handle enters samples. */
export function scanArtworkPreparation(raw,mode,preparedArtwork=null){
  const resolvedMode=raw.mode||mode,previous=preparedArtwork?.get(raw);
  if(previous&&previous.mode===resolvedMode)return previous;
  const channel=raw.mode?raw:{...raw,mode};
  let geometry=scanArtworkGeometry(channel);
  const pattern=finiteRegion(channel.patternBounds,null);
  const patternGeometry=geometry.creature&&pattern?scanArtworkGeometry({...channel,regionBounds:pattern,regionPolygon:undefined,regionPolygons:undefined,visitIndex:finite(channel.patternSeed,geometry.visitIndex)}):null;
  if(patternGeometry)geometry={...geometry,registeredAim:registeredPatternAim(geometry,patternGeometry)};
  const prepared={mode:resolvedMode,channel,geometry,...(patternGeometry?{patternGeometry}:{})};
  preparedArtwork?.set(raw,prepared);return prepared;
}
function coordinate(g,u,v){return g.axis==='y'?{x:g.center.x+u,y:g.center.y+v}:{x:g.center.x+v,y:g.center.y+u};}
function curvature(g,u,v){
  const a=u/Math.max(1,g.crossHalf),b=v/Math.max(1,g.scanHalf),seed=g.visitIndex*.47;
  // A coherent displacement field echoes how a projected fringe deforms on
  // uneven surfaces. It is presentation only, not a claimed anatomy result.
  return (Math.sin(a*3.6+b*.85+seed)*.6+Math.sin(a*7.2-b*1.35+seed*.6)*.26)*g.scanHalf*.046*(1-.32*Math.abs(a));
}
function captured(g,v){return g.direction===1?g.sweepPosition-v:v-g.sweepPosition;}
function fieldLine(g,v,segments){
  return Array.from({length:segments+1},(_,i)=>{const u=lerp(-g.crossHalf,g.crossHalf,i/segments);return coordinate(g,u,v+curvature(g,u,v));});
}
function cornerFrame(ctx,g,strength,color){
  const {center:c,halfWidth:w,halfHeight:h}=g,entry=g.acquire,leave=1-g.resolve,len=Math.max(2.4,Math.min(w,h)*.19),gap=g.region?-Math.min(1.4,w*.06,h*.06):1.7;
  if(g.polygon){
    // Native cell vertices remain world-aligned, including staggered hexes.
    // Inset brackets follow the actual sides rather than boxing a hexagon.
    const inset=g.polygon.map(p=>({x:lerp(c.x,p.x,.955),y:lerp(c.y,p.y,.955)}));
    for(let i=0;i<inset.length;i++){
      const p=inset[i],a=inset[(i+inset.length-1)%inset.length],b=inset[(i+1)%inset.length],span=.19+.04*g.sample;
      stroke(ctx,strength*.46*entry*leave,color,.42,path=>{path.moveTo(lerp(p.x,a.x,span),lerp(p.y,a.y,span));path.lineTo(p.x,p.y);path.lineTo(lerp(p.x,b.x,span),lerp(p.y,b.y,span));});
      dot(ctx,p.x,p.y,.6,strength*.36*entry*leave,WHITE);
    }
    return;
  }
  for(const sx of [-1,1])for(const sy of [-1,1]){
    const x=c.x+sx*(w+gap),y=c.y+sy*(h+gap),fold=(1-entry)*Math.min(w,h)*.16;
    stroke(ctx,strength*(.24+.23*(1-g.sample))*entry*leave,color,.45,p=>{p.moveTo(x-sx*(len+fold),y);p.lineTo(x,y);p.lineTo(x,y-sy*(len+fold));});
    stroke(ctx,strength*.3*entry*leave,PALE,.28,p=>{p.moveTo(x-sx*.8,y-sy*.8);p.lineTo(x-sx*(len*.5),y-sy*.8);});
    dot(ctx,x-sx*len,y,.65,strength*.35*entry*leave,WHITE);
  }
  // Sparse acquisition ticks resolve the subject bounds without a bulky box.
  for(let i=0;i<5;i++){
    const t=(i+.5)/5,x=c.x+lerp(-w,w,t),y=c.y+lerp(-h,h,t),a=strength*.2*entry*leave;
    stroke(ctx,a,color,.28,p=>{p.moveTo(x,c.y-h-1.6);p.lineTo(x,c.y-h-3);p.moveTo(c.x+w+1.6,y);p.lineTo(c.x+w+3,y);});
  }
}
function projectionPattern(ctx,g,detail,strength,color,rgb,staticFrame){
  const sweepActive=staticFrame?.18:1-ease((g.progress-.68)/.12),acquire=staticFrame?1:g.acquire;
  if(sweepActive<=.001)return;
  const current=g.sweepPosition,band=g.bandWidth;
  // A thin illuminated section advances across the whole footprint. The
  // gradient is clipped to that footprint, so no triangular projector volume
  // can appear between the instrument and target.
  const a=coordinate(g,0,current-band*1.65),b=coordinate(g,0,current+band*1.65),gradient=ctx.createLinearGradient(a.x,a.y,b.x,b.y);
  gradient.addColorStop(0,rgba(rgb,0));gradient.addColorStop(.22,rgba(rgb,.055));gradient.addColorStop(.48,rgba(rgb,.17));gradient.addColorStop(.62,rgba([255,217,246],.13));gradient.addColorStop(1,rgba(rgb,0));
  ctx.globalAlpha=strength*acquire*sweepActive;ctx.fillStyle=gradient;ctx.fillRect(g.center.x-g.halfWidth,g.center.y-g.halfHeight,g.halfWidth*2,g.halfHeight*2);
  // Phase-coded fringes cover the target simultaneously at acquisition, then
  // resolve into a dense moving set of bands. Each shares the displacement
  // field; it reads as one instrument measuring a surface, not random lines.
  const variant=g.exposureVariant,fieldRows=variant===1?Math.max(5,detail.bands-1):Math.min(15,detail.bands+5);
  for(let i=0;i<fieldRows;i++){
    const base=lerp(-g.scanHalf,g.scanHalf,(i+.5)/fieldRows),deviation=g.progress<.18?0:Math.sin((g.progress-.18)*4.7+i*.13)*g.scanHalf*.013;
    const proximity=Math.exp(-(((base-current)/(band*2.8))**2)),coarse=g.stage==='acquire'?.13:.035;
    const alpha=strength*sweepActive*acquire*(coarse+proximity*(variant===1?.12:.28));
    const points=fieldLine(g,base+deviation,detail.segments);
    stroke(ctx,alpha,color,variant===2?.34:.46,path=>pathPoints(path,points));
    if(proximity>.36)stroke(ctx,alpha*.45,PALE,.23,path=>pathPoints(path,points));
  }
  for(let i=0;i<detail.bands;i++){
    if(variant===1&&i!==Math.floor(detail.bands/2))continue;
    const v=current+lerp(-band,band,i/Math.max(1,detail.bands-1)),profile=1-Math.abs((i/(detail.bands-1)-.5)*2)*.53,points=fieldLine(g,v,detail.segments);
    stroke(ctx,strength*sweepActive*acquire*profile*.58,color,.57,path=>pathPoints(path,points));
    if(i===Math.floor(detail.bands/2)){
      stroke(ctx,strength*sweepActive*.64,WHITE,.25,path=>pathPoints(path,points));
      stroke(ctx,strength*sweepActive*.16,COOL,.34,path=>pathPoints(path,points.map(p=>({x:p.x+.45,y:p.y+.45}))));
    }
    // Short encoded exposures run across two of the surface bands. These
    // micro-segments break the decorative ribbon look and convey sampling.
    if(i%3===1||variant===2&&i%3===0)for(let s=1;s<points.length-1;s+=variant===2?4:3){
      const phase=(s+i+g.visitIndex)%4;if(phase===0)continue;
      const p=points[s],q=points[s+1];stroke(ctx,strength*sweepActive*profile*.29,PALE,.82,path=>{path.moveTo(p.x,p.y);path.lineTo(q.x,q.y);});
    }
  }
  if(variant===1){
    // A coded dot exposure alternates sensor columns. The measured points
    // sit on the same surface field as the fringe pass, with one narrow
    // active row; the complete portrait remains readable underneath.
    for(let row=0;row<detail.rows;row++)for(let col=0;col<detail.columns;col++){
      const u=lerp(-g.crossHalf,g.crossHalf,(col+.5)/detail.columns),v=lerp(-g.scanHalf,g.scanHalf,(row+.5)/detail.rows);
      const active=Math.exp(-(((v-current)/(band*2.1))**2));if(active<.015)continue;
      const p=coordinate(g,u,v+curvature(g,u,v)),code=(row*7+col*11+g.visitIndex)%5;
      const a=strength*acquire*sweepActive*active*(code===0?.82:.42);
      dot(ctx,p.x,p.y,code===0?1.1:.72,a,code===0?WHITE:PALE);
      if(code===0)stroke(ctx,a*.47,color,.28,path=>{path.moveTo(p.x-1.3,p.y-.85);path.lineTo(p.x-1.3,p.y+.85);path.moveTo(p.x+1.3,p.y-.85);path.lineTo(p.x+1.3,p.y+.85);});
    }
  }
}
function pointCloud(ctx,g,detail,strength,color,staticFrame){
  const resolve=1-g.resolve,columns=detail.columns,rows=detail.rows,spacing=g.crossHalf*2/Math.max(1,columns-1),fadeWidth=Math.max(g.bandWidth*1.2,3);
  for(let row=0;row<rows;row++){
    const v=lerp(-g.scanHalf,g.scanHalf,row/Math.max(1,rows-1)),behind=captured(g,v);
    const acquired=staticFrame?.58:ease((behind+g.bandWidth*.2)/fadeWidth);if(acquired<.001)continue;
    const near=Math.exp(-((behind/Math.max(1,g.bandWidth*2.1))**2)),sample=staticFrame?.4:g.sample;
    const nextV=lerp(-g.scanHalf,g.scanHalf,Math.min(rows-1,row+1)/Math.max(1,rows-1)),nextCaptured=staticFrame?1:ease((captured(g,nextV)+g.bandWidth*.2)/fadeWidth);
    for(let col=0;col<columns;col++){
      const u=lerp(-g.crossHalf,g.crossHalf,col/Math.max(1,columns-1)),vWarp=v+curvature(g,u,v),p=coordinate(g,u,vWarp);
      const detailSignal=.5+.5*Math.sin(col*1.73+row*2.19+g.visitIndex*.61),edge=(col===0||col===columns-1||row===0||row===rows-1)?1:0;
      const a=strength*acquired*resolve*(.06+detailSignal*.09+near*.31+sample*.14+edge*.09)*(g.exposureVariant===1?1.23:1);
      dot(ctx,p.x,p.y,.44+edge*.1+near*.2,a,near>.4?WHITE:detailSignal>.7?COOL:PALE);
      // Selected neighboring samples form short reconstructed facet edges;
      // their low density leaves the original token portrait fully readable.
      const facetA=(row*3+g.visitIndex)%Math.max(1,columns-2),facetB=(facetA+Math.floor(columns/2))%Math.max(1,columns-2);
      const facet=g.exposureVariant===1?row%4===2&&col===facetA:g.exposureVariant===2?(row%2===0&&col===facetA||row%3===1&&col===facetB):(row%3===1&&col===facetA||row%4===0&&col===facetB);
      if(col<columns-1&&facet){
        const q=coordinate(g,u+spacing,v+curvature(g,u+spacing,v));
        // Facets connect real acquired neighbors. Sparse open facets avoid a
        // repeated field of decorative triangles floating between samples.
        const nextU=u+spacing*((row+col+g.visitIndex)%2),r=coordinate(g,nextU,nextV+curvature(g,nextU,nextV));
        stroke(ctx,a*(.68+.35*g.sample),PALE,.34,path=>{path.moveTo(p.x,p.y);path.lineTo(q.x,q.y);if(row<rows-1&&nextCaptured>.8){path.lineTo(r.x,r.y);if((row+col)%4===0)path.lineTo(p.x,p.y);}});
      }
      if(near>.7&&(col+row)%4===0){
        stroke(ctx,a*.6,WHITE,.28,path=>{path.moveTo(p.x-.7,p.y);path.lineTo(p.x+.7,p.y);path.moveTo(p.x,p.y-.7);path.lineTo(p.x,p.y+.7);});
      }
    }
  }
  // Reconstructed contour levels settle after the band has passed. Their
  // deformation uses the same field as projection, tying measurement to output.
  for(let i=0;i<detail.contours;i++){
    const v=lerp(-g.scanHalf,g.scanHalf,(i+1)/(detail.contours+1)),behind=captured(g,v),gain=(staticFrame?.3:ease(behind/fadeWidth)*(.15+.17*g.sample))*(g.exposureVariant===2?1.55:1);
    stroke(ctx,strength*gain*resolve,color,.34,path=>pathPoints(path,fieldLine(g,v,detail.segments)));
  }
}

// New scanners use different spatial sampling paths, not alternate colours or
// line densities. All calculations remain deterministic and bounded per tier.
function opticalAim(g){
  const q=g.sweep,seed=g.visitIndex*.77;
  if(!g.creature)return GEOMETRIC_METHODS[g.method]?geometricAreaProbe(g):naturalAreaProbe(g);
  if(g.method==='laserTriangulation')return laserCrossing(g);
  if(g.method==='contourTomography')return tomographyProbe(g);
  if(g.method==='phaseInterferometry')return phaseProbe(g);
  if(g.method==='edgeTracing')return {x:g.center.x,y:g.center.y-g.halfHeight*(1-q)};
  if(g.method==='crosshatchSurvey')return {x:g.center.x+g.halfWidth*lerp(-1,1,q),y:g.center.y+g.halfHeight*lerp(-1,1,q)};
  if(g.method==='lidarReconstruction'||g.method==='radialRanging'){
    const a=q*TAU*2.1+seed,r=.12+.83*q;return {x:g.center.x+Math.cos(a)*g.halfWidth*r,y:g.center.y+Math.sin(a)*g.halfHeight*r};
  }
  if(g.method==='sparseReconstruction'){
    const stations=sparseStations(g),p=stations[Math.min(stations.length-1,Math.floor(q*stations.length))];return {x:p.x,y:p.y};
  }
  return g.creature?coordinate(g,0,g.sweepPosition):g.focus;
}
/** Shared optical target for the physical instrument housing and its light.
 * Coordinates use the channel's local frame; caller handles world rotation. */
function registeredPatternAim(region,pattern){
  const aim=opticalAim(pattern),bounds=region.region;
  if(!bounds)return aim;
  // Each instrument reads the common exposure where it crosses that bit's
  // responsibility. A completed region holds its nearest retained return;
  // the source never keeps sweeping an unrelated local pattern clock.
  const x=pattern.method==='structuredLight'?region.center.x:aim.x;
  return {x:Math.max(bounds.x,Math.min(bounds.x+bounds.width,x)),y:Math.max(bounds.y,Math.min(bounds.y+bounds.height,aim.y))};
}
export function scanArtworkAim(channel){
  const g=scanArtworkGeometry(channel),bounds=finiteRegion(channel.patternBounds,null);
  return g.creature&&bounds?registeredPatternAim(g,scanArtworkGeometry({...channel,regionBounds:bounds,regionPolygon:undefined,regionPolygons:undefined,visitIndex:finite(channel.patternSeed,g.visitIndex)})):opticalAim(g);
}
function sourceArtworkGeometry(channel,index,g=scanArtworkGeometry(channel)){
  const source=g.sources[index];if(!source)return g;
  const polygon=g.polygons[index]??regionPoints(channel.sources?.[index]?.regionPolygon);
  return scanArtworkGeometry({...channel,source,focus:source.focus??g.focus,regionBounds:undefined,regionPolygon:polygon,regionPolygons:polygon?[polygon]:undefined,sources:undefined});
}
/** A team member's exact optical endpoint, in the channel's local frame.
 * Housing orientation uses the same assigned cell as its painted light. */
export function scanArtworkSourceAim(channel,index=0){return opticalAim(sourceArtworkGeometry(channel,index));}
function ellipsePath(ctx,x,y,w,h,start=0,end=TAU,segments=36){
  for(let i=0;i<=segments;i++){const a=lerp(start,end,i/segments),px=x+Math.cos(a)*w,py=y+Math.sin(a)*h;if(i===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}
}
function laserCrossing(g){const q=lerp(-1.48,1.48,g.sweep)*g.direction;return {x:g.center.x,y:g.center.y+g.halfHeight*q*(1-.34/.94*.45)};}
function laserPoint(g,t,sign){
  // Two oblique pencil lasers approach from opposite headings. Their scan
  // planes translate in opposite directions rather than filling a rectangle.
  const u=lerp(-1.5,1.5,t),q=lerp(-1.48,1.48,g.sweep)*g.direction;
  return {x:g.center.x+g.halfWidth*(u*.94+q*.34*sign),y:g.center.y+g.halfHeight*(q+u*.45*sign)};
}
function laserProfiling(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.8:g.acquire)*(1-g.resolve),segments=detail.segments;
  if(gain<.001)return;
  // A barely visible exposure grounds the profile in the subject image. The
  // twin crisp lines and discrete moving probe are the recognisable signal.
  const aim=opticalAim(g),glow=ctx.createRadialGradient(aim.x,aim.y,.1,aim.x,aim.y,Math.min(g.halfWidth,g.halfHeight)*.30+2);
  glow.addColorStop(0,rgba(rgb,.19));glow.addColorStop(1,rgba(rgb,0));ctx.globalAlpha=gain;ctx.fillStyle=glow;ctx.fillRect(g.center.x-g.halfWidth,g.center.y-g.halfHeight,g.halfWidth*2,g.halfHeight*2);
  for(const sign of [-1,1]){
    const points=Array.from({length:segments+1},(_,i)=>{const p=laserPoint(g,i/segments,sign);return {x:p.x,y:p.y+Math.sin(i/segments*5.1+g.visitIndex*.5)*g.halfHeight*.035};});
    stroke(ctx,gain*.13,color,2.2,p=>pathPoints(p,points));
    stroke(ctx,gain*.8,color,.72,p=>pathPoints(p,points));
    stroke(ctx,gain*.86,WHITE,.22,p=>pathPoints(p,points));
    for(let i=1;i<points.length-1;i+=3){const p=points[i];dot(ctx,p.x,p.y,.83,gain*.8,PALE);}
    // A sparse accumulated profile follows the measured path at previous
    // exposures. It never substitutes another full-field striped scan.
    for(let j=1;j<=3;j++){
      const previous={...g,sweep:Math.max(0,g.sweep-j*.085)},trace=Array.from({length:Math.floor(segments/2)+1},(_,i)=>laserPoint(previous,i/Math.floor(segments/2),sign));
      stroke(ctx,gain*(.11-j*.021)*g.acquire,color,.3,p=>pathPoints(p,trace));
    }
  }
  const cross=laserCrossing(g),r=1.8+.6*Math.sin(g.progress*12);
  stroke(ctx,gain*.88,PALE,.42,p=>{p.moveTo(cross.x-r*2,cross.y);p.lineTo(cross.x-r*.7,cross.y);p.moveTo(cross.x+r*.7,cross.y);p.lineTo(cross.x+r*2,cross.y);p.moveTo(cross.x,cross.y-r*2);p.lineTo(cross.x,cross.y-r*.7);p.moveTo(cross.x,cross.y+r*.7);p.lineTo(cross.x,cross.y+r*2);});
  dot(ctx,cross.x,cross.y,1.15,gain,WHITE);
  // Completed samples settle into short contour profiles in the final phase.
  if(g.sample>.001)for(let row=0;row<detail.contours;row++){
    const y=g.center.y+lerp(-g.halfHeight,g.halfHeight,(row+.5)/detail.contours);
    stroke(ctx,gain*g.sample*.26,color,.34,p=>{for(let i=0;i<=segments;i++){const x=g.center.x+lerp(-g.halfWidth,g.halfWidth,i/segments),yy=y+Math.cos(i/segments*TAU+row)*g.halfHeight*.055;if(i)p.lineTo(x,yy);else p.moveTo(x,yy);}});
  }
}
const LIDAR_UNIT_CACHE=new Map(),LIDAR_UNIT_CACHE_LIMIT=32;
function lidarPoints(g,count){
  const key=count+':'+g.visitIndex;
  if(LIDAR_UNIT_CACHE.has(key))return LIDAR_UNIT_CACHE.get(key);
  const points=Array.from({length:count},(_,i)=>{
    const r=Math.sqrt((i+.5)/count),a=i*2.399963229728653+g.visitIndex*.77;
    // Reusable normalized samples preserve every point and facet while token
    // movement changes only the final affine scale/translation.
    return {x:Math.cos(a)*1.42*r,y:Math.sin(a)*1.42*r,r,a};
  });
  if(LIDAR_UNIT_CACHE.size>=LIDAR_UNIT_CACHE_LIMIT)LIDAR_UNIT_CACHE.delete(LIDAR_UNIT_CACHE.keys().next().value);
  LIDAR_UNIT_CACHE.set(key,points);return points;
}
function lidarReconstruction(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.85:g.acquire)*(1-g.resolve),count=detail.columns*detail.rows,points=lidarPoints(g,count),q=staticFrame?.68:g.sweep;
  if(gain<.001)return;
  // An outward time-of-flight wave is a circle of discrete returns rather
  // than a wedge. Two thinner echoes follow the current illuminated shell.
  const wave=.08+q*1.42;
  for(let echo=0;echo<3;echo++){
    const r=wave-echo*.13;if(r<=0)continue;
    stroke(ctx,gain*(.74-echo*.23),echo?color:PALE,echo?.38:.82,p=>ellipsePath(p,g.center.x,g.center.y,g.halfWidth*r,g.halfHeight*r,0,TAU,detail.segments*2));
  }
  for(let i=0;i<points.length;i++){
    const unit=points[i],p={x:g.center.x+unit.x*g.halfWidth,y:g.center.y+unit.y*g.halfHeight},distance=unit.r*1.42,near=Math.exp(-(((distance-wave)/.105)**2)),acquired=ease((wave-distance+.08)/.15);
    if(acquired<.001&&near<.01)continue;
    const sample=.5+.5*Math.sin(i*3.71+g.visitIndex),alpha=gain*(near*.93+acquired*(.23+sample*.15+g.sample*.21));
    dot(ctx,p.x,p.y,.72+near*.98,alpha,near>.4?WHITE:sample>.7?COOL:PALE);
    if(near>.3&&i%5===0)stroke(ctx,gain*near*.55,color,.35,path=>ellipsePath(path,p.x,p.y,1.45,1.45,0,TAU,8));
    // Short nearest-ring bridges give acquired points a reconstructed surface
    // topology. Stable neighbours prevent random spaghetti or changing edges.
    if(i>9&&i%4===0&&acquired>.5){const previous=points[i-8];stroke(ctx,gain*acquired*(.18+.16*g.sample),color,.29,path=>{path.moveTo(p.x,p.y);path.lineTo(g.center.x+previous.x*g.halfWidth,g.center.y+previous.y*g.halfHeight);});}
  }
  const a=q*TAU*2.1+g.visitIndex*.77,r=.12+.83*q,tip={x:g.center.x+Math.cos(a)*g.halfWidth*r,y:g.center.y+Math.sin(a)*g.halfHeight*r};
  stroke(ctx,gain*.5,color,.5,p=>ellipsePath(p,tip.x,tip.y,2.2,2.2,0,TAU,12));dot(ctx,tip.x,tip.y,1.05,gain*.9,WHITE);
}
function radialRanging(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.85:g.acquire)*(1-g.resolve),q=staticFrame?.55:g.sweep,max=Math.hypot(g.halfWidth,g.halfHeight),cx=g.center.x,cy=g.center.y;
  if(gain<.001)return;
  // Broad repeated ranging shells can span many cells. Their clipped arcs
  // remain a coherent circular survey rather than individual boxed squares.
  for(let echo=0;echo<4;echo++){
    const r=max*(q*1.4-echo*.19);if(r<=0)continue;
    const alpha=gain*(.59-echo*.13),arcStart=g.visitIndex*.53;
    stroke(ctx,alpha,color,echo?.38:.75,p=>ellipsePath(p,cx,cy,r,r,arcStart,arcStart+TAU,detail.segments*3));
    if(echo===0)stroke(ctx,alpha*.65,WHITE,.23,p=>ellipsePath(p,cx,cy,r+.45,r+.45,arcStart+.3,arcStart+TAU-.3,detail.segments*3));
    for(let i=0;i<detail.segments;i++){
      const a=i/detail.segments*TAU+g.visitIndex*.13,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;
      dot(ctx,x,y,i%4===0?1.2:.55,alpha*(i%4===0?1:.55),i%4===0?WHITE:PALE);
      if(i%4===0)stroke(ctx,alpha*.7,color,.34,p=>{p.moveTo(cx+Math.cos(a)*(r-1.8),cy+Math.sin(a)*(r-1.8));p.lineTo(cx+Math.cos(a)*(r+1.8),cy+Math.sin(a)*(r+1.8));});
    }
  }
  // Retained returns form a sparse polar map behind the advancing pulse.
  for(let ring=1;ring<=4;ring++)for(let i=0;i<detail.columns;i++){
    const r=max*ring/4,a=i/detail.columns*TAU+ring*.31+g.visitIndex*.13,behind=q*1.4-ring/4;
    if(behind<0)continue;dot(ctx,cx+Math.cos(a)*r,cy+Math.sin(a)*r,.55,gain*(.1+.13*g.sample)*ease(behind/.1),PALE);
  }
}
function sparseStations(g){
  if(g.polygons.length)return g.polygons.map(points=>{
    const x=points.reduce((v,p)=>v+p.x,0)/points.length,y=points.reduce((v,p)=>v+p.y,0)/points.length;
    return {x,y,reach:Math.max(...points.map(p=>Math.hypot(p.x-x,p.y-y)))};
  });
  return Array.from({length:9},(_,i)=>{
    const a=i*2.399963+g.visitIndex*.77,r=.25+.56*((i*5)%9)/8;
    return {x:g.center.x+Math.cos(a)*g.halfWidth*r,y:g.center.y+Math.sin(a)*g.halfHeight*r,reach:Math.min(g.halfWidth,g.halfHeight)*(.16+.04*(i%3))+2};
  });
}
function sparseReconstruction(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.85:g.acquire)*(1-g.resolve),q=staticFrame?.6:g.sweep,stations=sparseStations(g),count=stations.length;
  if(gain<.001)return;
  // Each native cell receives a complete outward local acquisition pulse.
  // Stations then retain scattered surface samples and short local facets;
  // the broad multi-cell survey is a sequence of focused reconstructions.
  for(let i=0;i<count;i++){
    const p=stations[i],age=g.cooperative?q:q-i/count;if(age<0)continue;
    // A crew captures its assigned native cells together. A shared phase
    // replaces the old rapid succession of tiny individual point bursts.
    const phase=g.cooperative?clamp(age):clamp(age*count),active=(g.cooperative?age<1:age<1/count)?.38+.62*Math.sin(phase*Math.PI):0,acquired=ease(phase);
    const alpha=gain*(active*.95+acquired*.22),radius=p.reach*.72;
    for(let k=0;k<detail.contours+3;k++){
      const a=k/(detail.contours+3)*TAU+i*.37,x=p.x+Math.cos(a)*radius,y=p.y+Math.sin(a)*radius;
      dot(ctx,x,y,.6+active*.42,alpha,k%3===0?WHITE:PALE);
      if(k%2===0)stroke(ctx,alpha*.58,color,.38,path=>{path.moveTo(p.x,p.y);path.lineTo(x,y);});
    }
    if(active>.05){
      const r=p.reach*(.10+phase*1.18);
      stroke(ctx,gain*active*.81,color,.64,path=>ellipsePath(path,p.x,p.y,r,r,0,TAU,detail.segments*2));
      stroke(ctx,gain*active*.18,color,2.2,path=>ellipsePath(path,p.x,p.y,r,r,0,TAU,detail.segments*2));
      dot(ctx,p.x,p.y,1.25,gain*active,WHITE);
      stroke(ctx,gain*active*.6,PALE,.32,path=>{for(const sign of [-1,1]){path.moveTo(p.x+sign*(r+1.3),p.y-1.3);path.lineTo(p.x+sign*(r+1.3),p.y+1.3);}});
    }
    if(i&&acquired>.05&&!g.cooperative){const prev=stations[i-1];stroke(ctx,gain*acquired*.09,color,.28,path=>{path.moveTo(prev.x,prev.y);path.lineTo(p.x,p.y);});}
  }
}
function tomographyProbe(g){
  const v=lerp(-g.scanHalf*1.12,g.scanHalf*1.12,g.sweep)*g.direction;
  return coordinate(g,Math.sin(g.sweep*TAU+g.visitIndex*.35)*g.crossHalf*.72,v);
}
function contourTomography(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.82:g.acquire)*(1-g.resolve),q=g.sweep;
  if(gain<.001)return;
  const v=lerp(-g.scanHalf*1.12,g.scanHalf*1.12,q)*g.direction;
  const sectionHalf=Math.max(1.8,g.scanHalf*.11),half=g.crossHalf*1.16;
  // A single thin cross section passes through the complete subject. Its
  // flattened elliptical profile and trailing measured sections are distinct
  // from a projected fringe field or an expanding range pulse.
  const section=(path,center,reach,height,segments)=>{
    for(let i=0;i<=segments;i++){
      const a=i/segments*TAU,u=Math.cos(a)*reach,w=center+Math.sin(a)*height+curvature(g,Math.cos(a)*reach,center)*.55,p=coordinate(g,u,w);
      if(i)path.lineTo(p.x,p.y);else path.moveTo(p.x,p.y);
    }
  };
  const a=coordinate(g,0,v-sectionHalf*1.8),b=coordinate(g,0,v+sectionHalf*1.8),glow=ctx.createLinearGradient(a.x,a.y,b.x,b.y);
  glow.addColorStop(0,rgba(rgb,0));glow.addColorStop(.5,rgba(rgb,.13));glow.addColorStop(1,rgba(rgb,0));
  ctx.globalAlpha=gain;ctx.fillStyle=glow;ctx.fillRect(g.center.x-g.halfWidth,g.center.y-g.halfHeight,g.halfWidth*2,g.halfHeight*2);
  stroke(ctx,gain*.12,color,2.3,p=>section(p,v,half,sectionHalf,detail.segments*2));
  stroke(ctx,gain*.85,color,.63,p=>section(p,v,half,sectionHalf,detail.segments*2));
  stroke(ctx,gain*.83,WHITE,.23,p=>section(p,v,half,sectionHalf*.78,detail.segments*2));
  for(let row=0;row<detail.contours+2;row++){
    const y=lerp(-g.scanHalf,g.scanHalf,(row+.5)/(detail.contours+2)),behind=g.direction*(v-y),acquired=staticFrame?.55:ease(behind/Math.max(1,sectionHalf*2));
    if(acquired<.001)continue;
    stroke(ctx,gain*acquired*(.13+.10*g.sample),row%2?color:PALE,.31,p=>section(p,y,half*.94,sectionHalf*.52,detail.segments));
    for(const sign of [-1,1]){
      const p=coordinate(g,sign*g.crossHalf*.68,y+curvature(g,sign*g.crossHalf*.68,y)*.55);
      dot(ctx,p.x,p.y,.62,gain*acquired*.34,row%2?COOL:PALE);
    }
  }
  const probe=tomographyProbe({...g,sweep:q});
  dot(ctx,probe.x,probe.y,1.15,gain,WHITE);
  stroke(ctx,gain*.65,PALE,.34,p=>ellipsePath(p,probe.x,probe.y,2.0,2.0,0,TAU,12));
}
function phasePoint(g,u,v,phase=0){
  // Both optical phase families share a slow, coherent deformation field.
  // Their intersections stay stable rather than flickering between frames.
  return coordinate(g,u,v+Math.sin(u/Math.max(1,g.crossHalf)*3.4+phase)*g.scanHalf*.21+curvature(g,u,v));
}
function phaseProbe(g){
  const u=lerp(-g.crossHalf,g.crossHalf,g.sweep)*g.direction,v=Math.sin(g.sweep*TAU+g.visitIndex*.3)*g.scanHalf*.46;
  return phasePoint(g,u,v,g.sweep*TAU*.42);
}
function phaseInterferometry(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.85:g.acquire)*(1-g.resolve),q=g.sweep,phase=q*TAU*.42;
  if(gain<.001)return;
  const current=lerp(-g.scanHalf*1.38,g.scanHalf*1.38,q)*g.direction;
  // Slowly translating curved interference fringes resolve the silhouette
  // through phase crossings. Sparse cross-family curves give an optical
  // lattice, with none of the hard rectangular dots of structured light.
  const rows=Math.max(5,detail.contours+3);
  for(let row=0;row<rows;row++){
    const v=lerp(-g.scanHalf*1.24,g.scanHalf*1.24,(row+.5)/rows),near=Math.exp(-(((v-current)/(g.scanHalf*.43+1))**2)),captured=ease(g.direction*(current-v)/(g.scanHalf*.38+1));
    const alpha=gain*(.045+near*.51+captured*g.sample*.11),points=Array.from({length:detail.segments+1},(_,i)=>phasePoint(g,lerp(-g.crossHalf*1.12,g.crossHalf*1.12,i/detail.segments),v,phase));
    stroke(ctx,alpha,row%2?color:PALE,.44,p=>pathPoints(p,points));
    if(near>.3)stroke(ctx,alpha*.28,color,1.9,p=>pathPoints(p,points));
  }
  for(let col=0;col<detail.contours;col++){
    const u=lerp(-g.crossHalf,g.crossHalf,(col+.5)/detail.contours),points=Array.from({length:detail.segments+1},(_,i)=>{
      const v=lerp(-g.scanHalf*1.2,g.scanHalf*1.2,i/detail.segments),bend=Math.cos(v/Math.max(1,g.scanHalf)*3.8-phase)*g.crossHalf*.25;
      return phasePoint(g,u+bend,v,phase);
    });
    stroke(ctx,gain*(.08+.12*g.sample),COOL,.31,p=>pathPoints(p,points));
    for(let row=0;row<rows;row++){
      const v=lerp(-g.scanHalf*1.24,g.scanHalf*1.24,(row+.5)/rows),near=Math.exp(-(((v-current)/(g.scanHalf*.36+1))**2));
      if(near<.12)continue;
      const bend=Math.cos(v/Math.max(1,g.scanHalf)*3.8-phase)*g.crossHalf*.25,p=phasePoint(g,u+bend,v,phase);
      dot(ctx,p.x,p.y,.65+near*.48,gain*near*.82,WHITE);
      if((row+col)%3===0)stroke(ctx,gain*near*.4,color,.3,path=>ellipsePath(path,p.x,p.y,1.6,1.6,0,TAU,10));
    }
  }
  const probe=phaseProbe({...g,sweep:q});
  stroke(ctx,gain*.7,PALE,.34,p=>ellipsePath(p,probe.x,probe.y,2.5,1.7,0,TAU,16));
  dot(ctx,probe.x,probe.y,.85,gain,WHITE);
}
function edgeTracing(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.83:g.acquire)*(1-g.resolve),q=staticFrame?.5:g.sweep;
  if(gain<.001)return;
  const h=g.scanHalf*(1-q),cross=g.crossHalf;
  // Opposed contour fronts contract from the survey's two edges, crossing
  // every selected cell together. Internal cell joins receive no extra frame
  // or repeated animation: four bits read as one measuring instrument.
  for(const sign of [-1,1]){
    const v=sign*h,points=fieldLine(g,v,detail.segments),lead=coordinate(g,0,v);
    stroke(ctx,gain*.11,color,2.0,p=>pathPoints(p,points));
    stroke(ctx,gain*.83,color,.63,p=>pathPoints(p,points));
    stroke(ctx,gain*.60,WHITE,.21,p=>pathPoints(p,points));
    for(let i=0;i<detail.contours+1;i++){
      const u=lerp(-cross*.90,cross*.90,(i+.5)/(detail.contours+1)),p=coordinate(g,u,v+curvature(g,u,v));
      dot(ctx,p.x,p.y,.76,gain*.71,PALE);
      stroke(ctx,gain*.41,color,.28,path=>{path.moveTo(p.x-1.3,p.y-.8);path.lineTo(p.x-1.3,p.y+.8);});
    }
    if(q>.82)dot(ctx,lead.x,lead.y,.8,gain*(q-.82)*3,WHITE);
  }
  // Sparse measured contours persist outside the moving fronts, and the two
  // outer rails make the area boundary legible without boxing every cell.
  for(let row=0;row<detail.contours;row++){
    const v=lerp(-g.scanHalf,g.scanHalf,(row+.5)/detail.contours),acquired=ease((Math.abs(v)-h)/Math.max(1,g.scanHalf*.18));
    stroke(ctx,gain*acquired*(.12+.13*g.sample),PALE,.28,p=>pathPoints(p,fieldLine(g,v,Math.floor(detail.segments/2))));
  }
  for(const sign of [-1,1]){
    const a=coordinate(g,sign*cross,-h),b=coordinate(g,sign*cross,h);
    stroke(ctx,gain*.28,color,.37,p=>{p.moveTo(a.x,a.y);p.lineTo(b.x,b.y);});
  }
}
function crosshatchSurvey(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.83:g.acquire)*(1-g.resolve),q=staticFrame?.5:g.sweep;
  if(gain<.001)return;
  // Two oblique slit exposures move in opposite directions over the WHOLE
  // active line, leaving a few settled crosshatch samples. This is one shared
  // surface, regardless of how many bits contribute to it.
  for(const sign of [-1,1]){
    const offset=lerp(-2.15,2.15,q)*sign;
    const points=Array.from({length:detail.segments+1},(_,i)=>{
      const u=lerp(-1.18,1.18,i/detail.segments),v=u*.77*sign+offset,p=coordinate(g,u*g.crossHalf,v*g.scanHalf);
      return {x:p.x,y:p.y};
    });
    stroke(ctx,gain*.11,color,2.1,p=>pathPoints(p,points));
    stroke(ctx,gain*.80,color,.69,p=>pathPoints(p,points));
    stroke(ctx,gain*.72,PALE,.22,p=>pathPoints(p,points));
    for(let i=2;i<points.length-1;i+=4){
      const p=points[i];dot(ctx,p.x,p.y,.9,gain*.8,WHITE);
      stroke(ctx,gain*.49,color,.31,path=>{path.moveTo(p.x-1.3,p.y-1.3*sign);path.lineTo(p.x+1.3,p.y+1.3*sign);});
    }
  }
  for(let row=0;row<detail.contours;row++)for(let col=0;col<detail.contours+1;col++){
    const u=lerp(-.88,.88,(col+.5)/(detail.contours+1)),v=lerp(-.88,.88,(row+.5)/detail.contours),threshold=(Math.abs(v)+Math.abs(u)*.77)/4.3+.5,acquired=ease((q-threshold)/.16);
    if(acquired<.001)continue;
    const p=coordinate(g,u*g.crossHalf,v*g.scanHalf),a=gain*acquired*(.18+.14*g.sample);
    dot(ctx,p.x,p.y,.63,a,PALE);
    if((row+col)%3===0)stroke(ctx,a*.75,COOL,.27,path=>{path.moveTo(p.x-1.4,p.y-1.4);path.lineTo(p.x+1.4,p.y+1.4);path.moveTo(p.x+1.4,p.y-1.4);path.lineTo(p.x-1.4,p.y+1.4);});
  }
}
// Native geometry remains the invisible ownership boundary. The illuminated
// work itself follows an uneven, softly tapering interior rather than drawing
// that boundary or filling a clipped rectangular backplate.
function areaPatches(g){
  const shapes=g.polygons.length?g.polygons:g.polygon?[g.polygon]:null;
  if(!shapes)return [{x:g.center.x,y:g.center.y,hx:g.halfWidth,hy:g.halfHeight,seed:g.visitIndex*.59}];
  return shapes.map((points,i)=>{
    const xs=points.map(p=>p.x),ys=points.map(p=>p.y),x=Math.min(...xs),y=Math.min(...ys),w=Math.max(...xs)-x,h=Math.max(...ys)-y;
    return {x:x+w/2,y:y+h/2,hx:Math.max(.5,w/2),hy:Math.max(.5,h/2),seed:g.visitIndex*.59+(x+w/2)*.037+(y+h/2)*.029};
  });
}
function naturalPointNodes(p){
  return Array.from({length:9},(_,i)=>{
    const a=i*2.399963+p.seed,r=Math.sqrt((i+.55)/9)*(.76+.06*Math.sin(i*1.31+p.seed));
    return {x:p.x+Math.cos(a)*p.hx*r,y:p.y+Math.sin(a)*p.hy*r};
  });
}
function naturalAreaProbe(g,patch=areaPatches(g)[0]){
  const p=patch,q=g.sweep,seed=p.seed;
  if(g.method==='sparseReconstruction'){
    // Primary nodes do not depend on quality. The metal housing, connector,
    // and illuminated measuring point follow this same smooth route.
    const nodes=naturalPointNodes(p),front=q*(nodes.length-1),i=Math.min(nodes.length-1,Math.floor(front)),a=nodes[i],b=nodes[Math.min(nodes.length-1,i+1)],t=ease(front-i);
    return {x:lerp(a.x,b.x,t),y:lerp(a.y,b.y,t)};
  }
  let u=0,v=0;
  if(g.method==='radialRanging'){
    const a=seed+.19+q*Math.PI*.77,r=.10+.73*q;u=Math.cos(a)*r;v=Math.sin(a)*r;
  }else if(g.method==='edgeTracing'){
    const a=seed+q*TAU*.87,r=.13+(1-q)*.70;u=Math.cos(a)*r;v=Math.sin(a)*r*.87;
  }else if(g.method==='crosshatchSurvey'){
    u=lerp(-.73,.73,q);v=lerp(-.64,.64,q)+Math.sin(u*4.1+seed)*.10;
  }else{
    u=Math.sin(seed+q*1.7)*.18;v=g.direction*lerp(-.82,.82,q)+Math.sin(u*4.1+g.visitIndex*.47)*.12;
  }
  const r=Math.hypot(u,v),fit=r>.86?.86/r:1;u*=fit;v*=fit;
  return g.axis==='y'?{x:p.x+u*p.hx,y:p.y+v*p.hy}:{x:p.x+v*p.hx,y:p.y+u*p.hy};
}
function patchSignal(p,x,y){
  const u=(x-p.x)/p.hx,v=(y-p.y)/p.hy,a=Math.atan2(v,u),r=Math.hypot(u,v);
  const edge=.94+.065*Math.sin(a*3+p.seed)+.045*Math.cos(a*5-p.seed*.73);
  // The natural footprint falls to zero BEFORE most straight native edges.
  // Its low-level tails may meet neighbors, without exposing a cell outline.
  return ease((edge-r)/.39);
}
function areaSignal(patches,x,y){let signal=0;for(const patch of patches)signal=Math.max(signal,patchSignal(patch,x,y));return signal;}
function areaStroke(ctx,points,patches,alpha,color,width,soft=true){
  const span=Math.max(1,points.length-1),count=Math.min(8,Math.max(4,Math.ceil(points.length/5))),buckets=Array.from({length:count},()=>[]);
  for(let i=1;i<points.length;i++){
    const a=points[i-1],b=points[i],t=(i-.5)/span,signal=areaSignal(patches,(a.x+b.x)/2,(a.y+b.y)/2),taper=Math.pow(Math.sin(Math.PI*t),.55),gain=alpha*signal*taper;
    if(gain<.002)continue;
    buckets[Math.min(count-1,Math.floor(signal*taper*count))].push(a,b);
  }
  // Batch disconnected equal-exposure fragments. Feathering changes opacity,
  // never the native clip, and needs at most sixteen strokes per whole curve
  // instead of a separate draw call for every tiny line segment.
  for(let i=0;i<count;i++){
    const segments=buckets[i];if(!segments.length)continue;const gain=alpha*(i+.5)/count;
    const path=p=>{for(let j=0;j<segments.length;j+=2){p.moveTo(segments[j].x,segments[j].y);p.lineTo(segments[j+1].x,segments[j+1].y);}};
    if(soft)stroke(ctx,gain*.11,color,width*3.8,path);
    stroke(ctx,gain,color,width*(.74+.26*Math.sqrt((i+.5)/count)),path);
  }
}
function areaGlow(ctx,patches,g,strength,rgb){
  const gain=strength*g.acquire*(1-g.resolve),q=g.sweep;
  for(const p of patches){
    // Overlapping unequal elliptical lobes make a quiet asymmetric patch;
    // no filled polygon, cell-sized rectangle, or offscreen mask is needed.
    for(let lobe=0;lobe<2;lobe++){
      const a=p.seed+lobe*2.1,cx=p.x+Math.sin(a+q*.7)*p.hx*.12,cy=p.y+Math.cos(a*.7-q*.6)*p.hy*.13;
      ctx.save();ctx.translate(cx,cy);ctx.scale(p.hx*(lobe?.66:.88),p.hy*(lobe?.82:.74));
      const glow=ctx.createRadialGradient(0,0,.02,0,0,1);glow.addColorStop(0,rgba(rgb,lobe?.035:.055));glow.addColorStop(.43,rgba(rgb,.020));glow.addColorStop(.76,rgba(rgb,.005));glow.addColorStop(1,rgba(rgb,0));
      ctx.globalAlpha=gain;ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,0,1,0,TAU);ctx.fill();ctx.restore();
    }
  }
}
function unevenAreaLine(g,v,segments,slant=0){
  return Array.from({length:segments+1},(_,i)=>{
    const u=lerp(-g.crossHalf*1.05,g.crossHalf*1.05,i/segments),t=u/Math.max(1,g.crossHalf);
    const bend=Math.sin(t*4.1+g.visitIndex*.47+v*.016)*g.scanHalf*.12+Math.sin(t*8.7-g.visitIndex*.33)*g.scanHalf*.029;
    return coordinate(g,u,v+bend+slant*t*g.scanHalf);
  });
}
function naturalStructuredLight(ctx,g,detail,patches,gain,color){
  const current=g.sweepPosition*.82,band=Math.max(1,g.bandWidth*.68);
  for(let row=-1;row<=1;row++){
    const points=unevenAreaLine(g,current+row*band,detail.segments),alpha=gain*(row?.37:.77);
    areaStroke(ctx,points,patches,alpha,row?color:PALE,row?.42:.64);
  }
  // Measured fragments accumulate in scattered rows, without a rigid raster.
  for(let row=0;row<detail.contours;row++){
    const v=lerp(-g.scanHalf*.78,g.scanHalf*.78,(row+.5)/detail.contours),acquired=ease(g.direction*(current-v)/Math.max(1,g.bandWidth*2));
    areaStroke(ctx,unevenAreaLine(g,v,Math.max(8,detail.segments-4)),patches,gain*acquired*(.08+.13*g.sample),color,.27,false);
  }
  for(const p of patches)for(let i=0;i<detail.columns;i++){
    const u=Math.sin(i*2.399963+p.seed)*Math.sqrt((i+.6)/detail.columns)*p.hx*.82,v=Math.cos(i*2.399963+p.seed)*Math.sqrt((i+.6)/detail.columns)*p.hy*.77,x=p.x+u,y=p.y+v;
    const scan=g.axis==='y'?y-g.center.y:x-g.center.x,near=Math.exp(-(((scan-current)/Math.max(2,g.bandWidth*1.8))**2)),signal=areaSignal(patches,x,y);
    dot(ctx,x,y,.55+near*.34,gain*signal*(.10+near*.60),near>.4?WHITE:PALE);
  }
}
function naturalRangeSurvey(ctx,g,detail,patches,gain,color){
  const wave=.08+g.sweep*1.42,seed=g.visitIndex*.49;
  for(let echo=0;echo<3;echo++){
    const radius=wave-echo*.19;if(radius<=0)continue;
    // Each echo is a broken, gently uneven iso-range arc. The shared contour
    // traverses the team's entire union, fading inside each native cell.
    for(let arc=0;arc<2;arc++){
      const start=seed+arc*Math.PI+.19,end=start+Math.PI*.77,points=Array.from({length:detail.segments+1},(_,i)=>{
        const a=lerp(start,end,i/detail.segments),r=radius*(1+.045*Math.sin(a*3+seed)+.025*Math.cos(a*7-seed));
        return {x:g.center.x+Math.cos(a)*g.halfWidth*r,y:g.center.y+Math.sin(a)*g.halfHeight*r};
      });
      areaStroke(ctx,points,patches,gain*(.70-echo*.21),echo?color:PALE,echo?.37:.63);
    }
  }
  for(const p of patches)for(let i=0;i<detail.columns;i++){
    const a=i*2.399963+p.seed,r=Math.sqrt((i+.5)/detail.columns)*.83,x=p.x+Math.cos(a)*p.hx*r,y=p.y+Math.sin(a)*p.hy*r,global=Math.hypot((x-g.center.x)/g.halfWidth,(y-g.center.y)/g.halfHeight),age=wave-global;
    if(age<0)continue;dot(ctx,x,y,.55,gain*patchSignal(p,x,y)*ease(age/.16)*(.12+.16*g.sample),PALE);
  }
}
function naturalPointSurvey(ctx,g,detail,patches,gain,color){
  for(const p of patches){
    const points=naturalPointNodes(p),count=points.length,front=g.sweep*(count-1);
    for(let i=0;i<count;i++){
      const node=points[i],age=front-i,active=Math.exp(-((age/.92)**2)),acquired=ease(age/1.4),signal=patchSignal(p,node.x,node.y),alpha=gain*signal*(active*.82+acquired*(.21+.19*g.sample));
      dot(ctx,node.x,node.y,.60+active*.62,alpha,active>.4?WHITE:PALE);
      if(i&&acquired>.05){const previous=points[Math.max(0,i-2)],mid={x:lerp(previous.x,node.x,.5),y:lerp(previous.y,node.y,.5)+Math.sin(i+p.seed)*p.hy*.07};areaStroke(ctx,[previous,mid,node],patches,alpha*.45,color,.31,false);}
      if(active>.08){
        const reach=Math.min(p.hx,p.hy)*(.10+.09*(1-active)),start=p.seed+i*.8,arc=Array.from({length:9},(_,j)=>{const a=start+j/8*Math.PI*1.36;return {x:node.x+Math.cos(a)*reach,y:node.y+Math.sin(a)*reach*.74};});
        areaStroke(ctx,arc,patches,gain*active*.55,PALE,.42);
      }
    }
  }
}
function naturalContourSurvey(ctx,g,detail,patches,gain,color){
  const seed=g.visitIndex*.47;
  for(let contour=0;contour<3;contour++){
    const radius=.13+(1-g.sweep)*.94+contour*.18,phase=seed+contour*.67,points=Array.from({length:detail.segments*2+1},(_,i)=>{
      const a=lerp(phase,phase+TAU*.87,i/(detail.segments*2)),r=radius*(1+.085*Math.sin(a*3+seed)+.045*Math.cos(a*5-seed));
      return {x:g.center.x+Math.cos(a)*g.halfWidth*r,y:g.center.y+Math.sin(a)*g.halfHeight*r*.87};
    });
    areaStroke(ctx,points,patches,gain*(contour?.19:.77),contour?color:PALE,contour?.32:.62);
  }
  for(const p of patches){
    const a=g.sweep*TAU*.64+p.seed,r=.16+(1-g.sweep)*.66,x=p.x+Math.cos(a)*p.hx*r,y=p.y+Math.sin(a)*p.hy*r*.80;
    dot(ctx,x,y,.9,gain*patchSignal(p,x,y)*.77,WHITE);
  }
}
function naturalCrosshatchSurvey(ctx,g,detail,patches,gain,color){
  for(const sign of [-1,1]){
    const offset=lerp(-1.8,1.8,g.sweep)*sign,points=unevenAreaLine(g,offset*g.scanHalf,detail.segments,.72*sign);
    areaStroke(ctx,points,patches,gain*.79,sign===1?PALE:color,.63);
  }
  for(const p of patches)for(let i=0;i<detail.contours+2;i++){
    const a=i*2.399963+p.seed,r=Math.sqrt((i+.5)/(detail.contours+2))*.74,x=p.x+Math.cos(a)*p.hx*r,y=p.y+Math.sin(a)*p.hy*r,age=g.sweep-(i+.5)/(detail.contours+2)*.65-.18;
    if(age<0)continue;const alpha=gain*patchSignal(p,x,y)*ease(age/.20)*(.16+.18*g.sample),span=Math.min(p.hx,p.hy)*.12;
    areaStroke(ctx,[{x:x-span,y:y-span*.64},{x:x+span,y:y+span*.64}],patches,alpha,PALE,.30,false);
    if(i%2===0)areaStroke(ctx,[{x:x-span*.70,y:y+span*.78},{x:x+span*.70,y:y-span*.78}],patches,alpha*.67,COOL,.27,false);
  }
}
function naturalAreaArtwork(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.83:g.acquire)*(1-g.resolve);if(gain<.001)return;
  const patches=areaPatches(g);areaGlow(ctx,patches,g,strength,rgb);
  if(g.method==='radialRanging')naturalRangeSurvey(ctx,g,detail,patches,gain,color);
  else if(g.method==='sparseReconstruction')naturalPointSurvey(ctx,g,detail,patches,gain,color);
  else if(g.method==='edgeTracing')naturalContourSurvey(ctx,g,detail,patches,gain,color);
  else if(g.method==='crosshatchSurvey')naturalCrosshatchSurvey(ctx,g,detail,patches,gain,color);
  else naturalStructuredLight(ctx,g,detail,patches,gain,color);
  // The shared wide exposure and each instrument's localized probe are
  // complementary. A connector always terminates on a visible measuring point
  // rather than a dark, unrelated position left over from an older method.
  for(const patch of patches){
    const probe=naturalAreaProbe(g,patch),signal=patchSignal(patch,probe.x,probe.y),a=gain*(.28+.72*signal);
    dot(ctx,probe.x,probe.y,.77,a*.83,WHITE);
    stroke(ctx,a*.42,color,.28,p=>ellipsePath(p,probe.x,probe.y,1.27,1.04,.21+patch.seed,Math.PI*1.70+patch.seed,10));
  }
}
function geometricAreaProbe(g){
  const method=GEOMETRIC_METHODS[g.method],q=g.sweep;
  if(method==='sparseReconstruction')return naturalAreaProbe({...g,method:'sparseReconstruction'},{x:g.center.x,y:g.center.y,hx:g.halfWidth,hy:g.halfHeight,seed:g.visitIndex*.59+g.center.x*.037+g.center.y*.029});
  if(method==='radialRanging'){
    const a=q*TAU*1.28+g.visitIndex*.39,r=.12+.73*q;
    return {x:g.center.x+Math.cos(a)*g.halfWidth*r,y:g.center.y+Math.sin(a)*g.halfHeight*r};
  }
  if(method==='edgeTracing')return coordinate(g,0,-g.scanHalf*(1-q)*.90);
  if(method==='crosshatchSurvey')return {x:g.center.x+lerp(-.82,.82,q)*g.halfWidth,y:g.center.y+lerp(-.82,.82,q)*g.halfHeight};
  return coordinate(g,0,Math.max(-g.scanHalf*.92,Math.min(g.scanHalf*.92,g.sweepPosition)));
}
function geometricBoundary(g){
  if(g.linkedBoundary)return g.linkedBoundary;
  const polygons=g.polygons.length?g.polygons:g.polygon?[g.polygon]:[[{x:g.center.x-g.halfWidth,y:g.center.y-g.halfHeight},{x:g.center.x+g.halfWidth,y:g.center.y-g.halfHeight},{x:g.center.x+g.halfWidth,y:g.center.y+g.halfHeight},{x:g.center.x-g.halfWidth,y:g.center.y+g.halfHeight}]];
  return g.linkedBoundary=linkedScanBoundary(polygons);
}
function linkedPerimeter(ctx,g,gain,color){
  const boundary=geometricBoundary(g);if(!boundary.edges.length)return;
  // Only exterior topology is stroked. Collinear former cell joins have been
  // removed; neither a native internal edge nor a per-cell corner is painted.
  stroke(ctx,gain*.30,color,.62,path=>{for(const loop of boundary.loops)pathPoints(path,loop);});
  const total=boundary.perimeter,at=((g.sweep*.83+g.visitIndex*.173)%1)*total,span=Math.min(9,total*.065);
  let cursor=0;
  for(const edge of boundary.edges){
    for(const start of [at,at-total]){
      const from=Math.max(0,start-cursor),to=Math.min(edge.length,start+span-cursor);
      if(to>from&&edge.length>0)stroke(ctx,gain*.67,PALE,.48,path=>{path.moveTo(lerp(edge.a.x,edge.b.x,from/edge.length),lerp(edge.a.y,edge.b.y,from/edge.length));path.lineTo(lerp(edge.a.x,edge.b.x,to/edge.length),lerp(edge.a.y,edge.b.y,to/edge.length));});
    }
    cursor+=edge.length;
  }
}
function geometricPointSurvey(ctx,g,detail,gain,color){
  // A single shared instrument lattice spans the WHOLE union. Its origin,
  // density and exposure phase never restart at an individual native cell.
  const cols=detail.columns,rows=detail.rows,dy=g.scanHalf*2/Math.max(1,rows-1),dx=g.crossHalf*2/Math.max(1,cols-1),front=lerp(-g.scanHalf*1.08,g.scanHalf*1.08,g.sweep)*g.direction;
  for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
    const u=lerp(-g.crossHalf,g.crossHalf,col/Math.max(1,cols-1)),v=lerp(-g.scanHalf,g.scanHalf,row/Math.max(1,rows-1)),behind=g.direction*(front-v),near=Math.exp(-((behind/Math.max(2,g.bandWidth*1.9))**2)),acquired=ease((behind+g.bandWidth*.3)/Math.max(2,g.bandWidth*1.9));
    if(near<.01&&acquired<.01)continue;const p=coordinate(g,u,v),alpha=gain*(near*.79+acquired*(.17+.19*g.sample));
    dot(ctx,p.x,p.y,.58+near*.58,alpha,near>.40?WHITE:(row+col)%3?PALE:COOL);
    if(col<cols-1&&acquired>.5&&(row*3+col+g.visitIndex)%4===0){const q=coordinate(g,u+dx,v);stroke(ctx,alpha*.42,color,.32,path=>{path.moveTo(p.x,p.y);path.lineTo(q.x,q.y);});}
    if(row<rows-1&&acquired>.5&&(col*3+row+g.visitIndex)%7===0){const q=coordinate(g,u,v+dy);stroke(ctx,alpha*.30,PALE,.27,path=>{path.moveTo(p.x,p.y);path.lineTo(q.x,q.y);});}
    if(near>.64&&(row+col)%5===0)stroke(ctx,alpha*.53,color,.29,path=>ellipsePath(path,p.x,p.y,1.40,1.40,0,TAU,10));
  }
}
function geometricContourSurvey(ctx,g,detail,gain,color){
  const half=g.scanHalf*(1-g.sweep);
  for(const sign of [-1,1]){
    const points=fieldLine(g,sign*half,detail.segments);
    stroke(ctx,gain*.13,color,2.0,path=>pathPoints(path,points));
    stroke(ctx,gain*.82,color,.63,path=>pathPoints(path,points));
    stroke(ctx,gain*.59,WHITE,.21,path=>pathPoints(path,points));
  }
  for(let row=0;row<detail.contours;row++){
    const v=lerp(-g.scanHalf,g.scanHalf,(row+.5)/detail.contours),acquired=ease((Math.abs(v)-half)/Math.max(1,g.scanHalf*.18));
    stroke(ctx,gain*acquired*(.12+.13*g.sample),PALE,.28,path=>pathPoints(path,fieldLine(g,v,Math.floor(detail.segments/2))));
  }
}
function geometricAreaArtwork(ctx,g,detail,strength,color,rgb,staticFrame){
  const gain=strength*(staticFrame?.83:g.acquire)*(1-g.resolve);if(gain<.001)return;
  const field={...g,method:GEOMETRIC_METHODS[g.method]};
  if(field.method==='structuredLight'){projectionPattern(ctx,field,detail,strength,color,rgb,staticFrame);pointCloud(ctx,field,detail,strength,color,staticFrame);}
  else if(field.method==='radialRanging')radialRanging(ctx,field,detail,strength,color,rgb,staticFrame);
  else if(field.method==='sparseReconstruction')geometricPointSurvey(ctx,field,detail,gain,color);
  else if(field.method==='edgeTracing')geometricContourSurvey(ctx,field,detail,gain,color);
  else crosshatchSurvey(ctx,field,detail,strength,color,rgb,staticFrame);
  linkedPerimeter(ctx,g,gain,color);
  // A team shares one global exposure. Its real instruments retain small
  // local probes, never separate local scan surfaces or cell-sized frames.
  for(const instrument of g.instruments??[g]){
    const probe=geometricAreaProbe(instrument);dot(ctx,probe.x,probe.y,.86,gain*.85,WHITE);
    stroke(ctx,gain*.43,color,.29,path=>ellipsePath(path,probe.x,probe.y,1.35,1.12,.2,TAU*.88,10));
  }
}
function surfaceArtwork(ctx,g,detail,strength,color,rgb,staticFrame){
  if(!g.creature){if(GEOMETRIC_METHODS[g.method])geometricAreaArtwork(ctx,g,detail,strength,color,rgb,staticFrame);else naturalAreaArtwork(ctx,g,detail,strength,color,rgb,staticFrame);return;}
  if(g.method==='laserTriangulation')laserProfiling(ctx,g,detail,strength,color,rgb,staticFrame);
  else if(g.method==='lidarReconstruction')lidarReconstruction(ctx,g,detail,strength,color,rgb,staticFrame);
  else if(g.method==='radialRanging')radialRanging(ctx,g,detail,strength,color,rgb,staticFrame);
  else if(g.method==='sparseReconstruction')sparseReconstruction(ctx,g,detail,strength,color,rgb,staticFrame);
  else if(g.method==='contourTomography')contourTomography(ctx,g,detail,strength,color,rgb,staticFrame);
  else if(g.method==='phaseInterferometry')phaseInterferometry(ctx,g,detail,strength,color,rgb,staticFrame);
  else if(g.method==='edgeTracing')edgeTracing(ctx,g,detail,strength,color,rgb,staticFrame);
  else if(g.method==='crosshatchSurvey')crosshatchSurvey(ctx,g,detail,strength,color,rgb,staticFrame);
  else{projectionPattern(ctx,g,detail,strength,color,rgb,staticFrame);pointCloud(ctx,g,detail,strength,color,staticFrame);}
}
function resolveFlash(ctx,g,strength,color){
  // A crisp bracket frame and a single bright pass mark the moment a reading completes.
  const f=g.sample*(1-g.resolve);if(!(f>.01))return;
  const x0=g.center.x-g.halfWidth,y0=g.center.y-g.halfHeight,w=g.halfWidth*2,h=g.halfHeight*2,c=Math.min(w,h)*.16;
  // The frame follows the region's own outline (hex cells, ellipses, drawn
  // polygons); only a plain rectangle keeps the four corner brackets.
  const loops=GEOMETRIC_METHODS[g.method]&&!g.creature?geometricBoundary(g).loops:g.polygons.length?g.polygons:g.polygon?[g.polygon]:[];
  const first=loops[0]?.length===5&&Math.hypot(loops[0][4].x-loops[0][0].x,loops[0][4].y-loops[0][0].y)<1e-3?loops[0].slice(0,4):loops[0];
  const rectangle=!loops.length||loops.length===1&&first.length===4&&first.every(({x,y})=>(Math.abs(x-x0)<1e-3||Math.abs(x-x0-w)<1e-3)&&(Math.abs(y-y0)<1e-3||Math.abs(y-y0-h)<1e-3));
  if(rectangle)stroke(ctx,strength*f*.5,WHITE,.5,p=>{for(const [x,y,sx,sy] of [[x0,y0,1,1],[x0+w,y0,-1,1],[x0,y0+h,1,-1],[x0+w,y0+h,-1,-1]]){p.moveTo(x+sx*c,y);p.lineTo(x,y);p.lineTo(x,y+sy*c);}});
  else stroke(ctx,strength*f*.42,WHITE,.7,p=>{for(const loop of loops){pathPoints(p,loop);p.closePath();}});
  const q=ease((g.progress-.68)/.19),y=y0+h*q;stroke(ctx,strength*f*.45,color,1.1,p=>{p.moveTo(x0,y);p.lineTo(x0+w,y);});
}
function regionClip(ctx,g){
  ctx.beginPath();
  if(GEOMETRIC_METHODS[g.method]&&!g.creature){for(const loop of geometricBoundary(g).loops){pathPoints(ctx,loop);ctx.closePath();}}
  else if(g.polygons.length){for(const polygon of g.polygons){pathPoints(ctx,polygon);ctx.closePath();}}
  else if(g.polygon){pathPoints(ctx,g.polygon);ctx.closePath();}
  else ctx.rect(g.center.x-g.halfWidth,g.center.y-g.halfHeight,g.halfWidth*2,g.halfHeight*2);
  ctx.clip();
}
function completeRectPartition(regions,bounds){
  const epsilon=Math.max(1,bounds.width*bounds.height)*1e-10;
  let area=0;
  for(let i=0;i<regions.length;i++){
    const a=regions[i];
    if(a.x<bounds.x-1e-8||a.y<bounds.y-1e-8||a.x+a.width>bounds.x+bounds.width+1e-8||a.y+a.height>bounds.y+bounds.height+1e-8)return false;
    area+=a.width*a.height;
    for(let j=0;j<i;j++){
      const b=regions[j],overlap=Math.max(0,Math.min(a.x+a.width,b.x+b.width)-Math.max(a.x,b.x))*Math.max(0,Math.min(a.y+a.height,b.y+b.height)-Math.max(a.y,b.y));
      if(overlap>epsilon)return false;
    }
  }
  return Math.abs(area-bounds.width*bounds.height)<=epsilon;
}
function sourceInstrument(ctx,g,strength,rgb,color){
  const target=g.registeredAim??opticalAim(g),sx=g.source.x,sy=g.source.y;
  const angle=Math.atan2(target.y-sy,target.x-sx);
  ctx.save();ctx.translate(sx,sy);ctx.rotate(angle);
  const glow=ctx.createRadialGradient(2.2,0,.1,2.2,0,3.9);glow.addColorStop(0,rgba([255,234,251],.53));glow.addColorStop(.24,rgba(rgb,.28));glow.addColorStop(1,rgba(rgb,0));
  ctx.fillStyle=glow;ctx.globalAlpha=strength*(.55+.25*g.acquire)*(1-g.resolve);ctx.fillRect(-1.7,-3.9,7.8,7.8);
  for(const sign of [-1,1])stroke(ctx,strength*.52*(1-g.resolve),PALE,.37,p=>{p.moveTo(.6,sign*1.6);p.lineTo(2,sign*2);p.lineTo(3.6,sign*1.25);});
  stroke(ctx,strength*.43*(1-g.resolve),color,.33,p=>{p.moveTo(3.3,-.8);p.lineTo(3.3,.8);});ctx.restore();
  // One restrained optical path grounds the projected work in the real metal
  // source. Return packets travel along it; there is no source-to-edge fan.
  const dx=target.x-sx,dy=target.y-sy,d=Math.hypot(dx,dy);
  if(d<4)return;
  const ux=dx/d,uy=dy/d,start={x:sx+ux*4,y:sy+uy*4},end={x:target.x-ux*2,y:target.y-uy*2};
  stroke(ctx,strength*.07*(1-g.resolve),color,.22,p=>{p.moveTo(start.x,start.y);p.lineTo(end.x,end.y);});
  for(let i=0;i<2;i++){
    const q=((g.progress*2.3+i*.48)%1+1)%1,returnQ=g.stage==='sample'||g.stage==='resolve'?1-q:q;
    const x=lerp(start.x,end.x,returnQ),y=lerp(start.y,end.y,returnQ),a=strength*(.24+.28*g.sample)*(1-g.resolve);
    stroke(ctx,a,PALE,.42,p=>{p.moveTo(x-ux*.8,y-uy*.8);p.lineTo(x+ux*.8,y+uy*.8);});
  }
}

/** Pure painter. Bounded detail tiers cap fringe and dot exposures, point
 * returns and reconstructed contours; at most four instruments, 24 native cell
 * boundaries, and 64 vertices per boundary. */
export function paintScanArtwork(ctx,effect,{plane='front',thought=false,quality=null,tokenMask=undefined,preparedArtwork=null}={}){
  if(!effect||effect.effect!=='v8-scan')return;
  const detail=DETAIL[quality??effect.detail]??DETAIL.standard,color=effect.color??'#ff4bda',rgb=RGB(color),deepSurfaces=[];let sharedDeepSurfaces;
  ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
  for(const raw of (effect.channels??[]).slice(0,4)){
    if((raw.plane??'front')!==plane)continue;
    const prepared=scanArtworkPreparation(raw,effect.mode,preparedArtwork),channel=prepared.channel,g=prepared.geometry,strength=clamp(channel.strength)*(thought?.62:1);
    if(strength<.002)continue;
    ctx.save();
    if(g.frameRotation)ctx.rotate(g.frameRotation);
    if(g.clipRadius>0){ctx.beginPath();ctx.arc(0,0,g.clipRadius,0,TAU);ctx.clip();}
    if(g.scanRegionPolygon){ctx.beginPath();pathPoints(ctx,g.scanRegionPolygon);ctx.closePath();ctx.clip();}
    if(g.sources.length){
      // One shared survey surface, with restrained light paths from each real
      // bit to its own native cell. No duplicate four-layer field or frame.
      if(GEOMETRIC_METHODS[g.method])g.instruments=[];
      for(let i=0;i<g.sources.length;i++){
        const local=sourceArtworkGeometry(channel,i,g);
        if(g.instruments)g.instruments.push(local);
        sourceInstrument(ctx,local,strength*.82*g.sources[i].strength,rgb,color);
      }
    }else sourceInstrument(ctx,g,strength,rgb,color);
    const deep=g.creature&&g.scanStage==='close';
    const drawSurface=surface=>{
      surface.save();regionClip(surface,g);
      // Deep acquisition and returns belong to the token image itself. A
      // rectangular registration frame would still suggest a square scan.
      if(g.creature&&!deep&&g.region)cornerFrame(surface,g,strength,color);
      surfaceArtwork(surface,prepared.patternGeometry??g,detail,strength,color,rgb,!!channel.static);
      if(scanLook==='v10')resolveFlash(surface,g,strength,color);
      surface.restore();
      if(g.creature&&!deep&&!g.region)cornerFrame(surface,g,strength,color);
    };
    const shared=deep&&channel.patternGroup==='medical-diagnostic'&&prepared.patternGeometry&&g.region&&!g.polygon&&!g.polygons.length&&!g.scanRegionPolygon&&!g.clipRadius&&SHARED_MEDICAL_PATTERNS.has(g.method);
    if(deep&&(tokenMask!==undefined||shared)){
      if(tokenMask===undefined||tokenMask&&typeof tokenMask.paint==='function'){
        if(shared){
          const field=prepared.patternGeometry,key=JSON.stringify([field.region,field.method,field.progress,field.axis,field.direction,field.visitIndex,field.exposureVariant,field.frameRotation,!!channel.static,strength]);
          let group=(sharedDeepSurfaces??=new Map()).get(key);
          if(group)group.regions.push(g.region);
          else{
            const regions=[g.region];group={regions};sharedDeepSurfaces.set(key,group);
            deepSurfaces.push({g,drawSurface(surface){
              // One exposure through the union removes antialiased seams and
              // repeated pattern raster work. Regions still own distinct
              // responsibility and every real source retains its own ray.
              surface.save();surface.beginPath();
              // Native antialiasing can leave a tiny T-junction seam even in
              // an exact tiling. Collapse only a proved complete partition;
              // a missing/overlapping region may never acquire its neighbor.
              const clips=completeRectPartition(regions,field.region)?[field.region]:regions;
              for(const r of clips)surface.rect(r.x,r.y,r.width,r.height);surface.clip();
              surfaceArtwork(surface,field,detail,strength,color,rgb,!!channel.static);surface.restore();
            }});
          }
        }else deepSurfaces.push({g,drawSurface});
      }
    }else drawSurface(ctx);
    ctx.restore();
  }
  if(deepSurfaces.length){
    // Every instrument in an effect attends the same native token. Compose all
    // viewpoints first, then apply the shared alpha exactly once. This keeps
    // the original drawing density while avoiding four clears/masks/copies.
    const baseRotation=deepSurfaces[0].g.frameRotation;
    ctx.save();if(baseRotation)ctx.rotate(baseRotation);
    const paintDeep=surface=>{
      for(const {g,drawSurface} of deepSurfaces){
        surface.save();
        if(g.frameRotation!==baseRotation)surface.rotate(g.frameRotation-baseRotation);
        if(g.clipRadius>0){surface.beginPath();surface.arc(0,0,g.clipRadius,0,TAU);surface.clip();}
        if(g.scanRegionPolygon){surface.beginPath();pathPoints(surface,g.scanRegionPolygon);surface.closePath();surface.clip();}
        drawSurface(surface);surface.restore();
      }
    };
    if(tokenMask===undefined)paintDeep(ctx);else tokenMask.paint(ctx,paintDeep,{frameRotation:baseRotation});
    ctx.restore();
  }
  if(effect.medicalLock&&plane==='front')paintMedicalLock(ctx,effect.medicalLock,color);
  ctx.restore();
}
/** Diagnostic lock-on: once the reading has passed, four quiet corner
 * brackets settle onto the portrait and hold while the treatment art fades
 * in, so the patient is never left bare between scan and work. */
function paintMedicalLock(ctx,lock,color){
  const a=clamp(lock.amount);if(a<.004)return;
  const settle=1+.08*(1-clamp(lock.settle??1)),hw=lock.width/2*settle,hh=lock.height/2*settle,arm=Math.min(hw,hh)*.32;
  ctx.save();if(lock.angle)ctx.rotate(lock.angle);ctx.translate(lock.x,lock.y);ctx.strokeStyle=color;ctx.lineCap='round';ctx.lineJoin='round';
  for(const [sx,sy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){
    ctx.beginPath();ctx.moveTo(sx*hw,sy*(hh-arm));ctx.lineTo(sx*hw,sy*hh);ctx.lineTo(sx*(hw-arm),sy*hh);
    ctx.globalAlpha=a*.16;ctx.lineWidth=3.2;ctx.stroke();ctx.globalAlpha=a*.7;ctx.lineWidth=.9;ctx.stroke();
  }
  // a small centre reticle breathes once as the reading locks
  const r=3.2*settle;ctx.globalAlpha=a*.55;ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(0,-r);ctx.lineTo(r*.7,0);ctx.lineTo(0,r);ctx.lineTo(-r*.7,0);ctx.closePath();ctx.stroke();
  ctx.restore();
}
