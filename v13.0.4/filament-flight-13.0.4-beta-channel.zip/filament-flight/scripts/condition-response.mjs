/** Actor-condition reactions preserve PF2e rules, allocations and saved
 * appearance. Optional grounding changes only module flight intent. */
import {CONDITION_EFFECTS,conditionEffectCategory} from './effect-catalog.mjs?v=13.0.4';
import {reformationOf} from './reaction-art.mjs?v=13.0.4';
import {makeBitRestPoses,readBitRestPoses,sampleBitRest} from './bit-collapse.mjs?v=13.0.4';
import {readActorCondition,composeHPArtwork,ZERO_HP_LOOKS,profileFor,mixProfiles} from './conditions.mjs?v=13.0.4';
import {NEW_ACTOR_WING_RESPONSES,sampleActorWingMotion,actorConditionStunAmount,actorConditionMotionArrest} from './condition-wing-motion.mjs?v=13.0.4';
import {COMPLETE_CONDITION_RESPONSES,sampleCompleteConditionMotion} from './complete-condition-art.mjs?v=13.0.4';
import {sampleStatusFilamentEffects,STATUS_FILAMENT_EFFECT_LABELS,STATUS_FILAMENT_EFFECT_DESCRIPTIONS} from './status-filament-effects.mjs?v=13.0.4';
import {sampleStatusFlightCharacter} from './status-flight-character.mjs?v=13.0.4';

export const ACTOR_CONDITION_LABELS=Object.freeze({unconscious:'Unconscious',stunned:'Stunned',prone:'Prone',frightened:'Frightened',fatigued:'Fatigued',slowed:'Slowed',quickened:'Quickened',
  ...Object.fromEntries(Object.keys(NEW_ACTOR_WING_RESPONSES).map(id=>[id,id[0].toUpperCase()+id.slice(1)])),
  ...Object.fromEntries(Object.entries(COMPLETE_CONDITION_RESPONSES).map(([id,entry])=>[id,entry.conditionLabel??id[0].toUpperCase()+id.slice(1)])),
  'persistent-damage':'Persistent damage','off-guard':'Off-guard'});
const ORIGINAL_RESPONSE_ART={
  unconscious:{label:'Broken Reform',description:'The lattice falls silent, holds its broken phase and rebuilds without automatically taking off.'},
  stunned:{label:'Interrupted cadence',description:'Lost actions interrupt sequential relays: a mild catch at one, deep disruption at two and complete stillness at three.'},
  prone:{label:'Resting drape',description:'A groundward drape settles around the roots with shallow breathing and no full flap.'},
  frightened:{label:'Protective quiver',description:'The guard contracts protectively with fast nervous tremors along individual ribs.'},
  fatigued:{label:'Recovery breath',description:'Broad usable wings breathe slowly through gentle restorative loops without collapsing their span.'},
  slowed:{label:'Lagging echoes',description:'Delayed rib echoes hold and release out of phase as the lattice loses tempo.'},
  quickened:{label:'Routed rush',description:'Accelerated currents travel through successive ribs and return in a controlled energetic cadence.'}
};
export const WING_RESPONSE_LABELS=Object.freeze({...Object.fromEntries(Object.entries({...ORIGINAL_RESPONSE_ART,...NEW_ACTOR_WING_RESPONSES,...COMPLETE_CONDITION_RESPONSES}).map(([id,entry])=>[id,entry.label])),...STATUS_FILAMENT_EFFECT_LABELS});
export const ACTOR_CONDITION_DESCRIPTIONS=Object.freeze({...Object.fromEntries(Object.entries({...ORIGINAL_RESPONSE_ART,...NEW_ACTOR_WING_RESPONSES,...COMPLETE_CONDITION_RESPONSES}).map(([id,entry])=>[id,`${entry.label}: ${entry.description}`])),
  ...Object.fromEntries(Object.entries(STATUS_FILAMENT_EFFECT_DESCRIPTIONS).map(([id,description])=>[id,`${STATUS_FILAMENT_EFFECT_LABELS[id]}: ${description}`]))});
export const ACTOR_CONDITION_IDS=Object.freeze(Object.keys(ACTOR_CONDITION_LABELS));
export const CONDITION_RESPONSE_DEFAULTS=Object.freeze({enabled:true,wings:true,bits:true,
  conditions:Object.freeze(Object.fromEntries(ACTOR_CONDITION_IDS.map(id=>[id,Object.freeze({enabled:true,strength:id==='unconscious'?1:.6,style:'default'})])))});
// broken: the Reform progress where the unravel has reached her shoulders (beta.29: .24).
export const CONDITION_RESPONSE_TIMING=Object.freeze({change:450,fall:950,recover:2000,broken:.24});
const ZERO_LEVELS=Object.freeze(Object.fromEntries(ACTOR_CONDITION_IDS.map(id=>[id,0]))),NO_CONDITIONS=Object.freeze({});
// Condition art reads the world config with authored artwork off. Configs are
// replaced, never edited, so one derived copy per config object suffices.
const conditionConfigs=new WeakMap();
function conditionConfigFor(config){
  let derived=conditionConfigs.get(config);
  if(!derived){derived={...config,conditionAuthoredArtwork:false};conditionConfigs.set(config,derived);}
  return derived;
}
const BIT_IDS=['leftUpper','rightUpper','leftLower','rightLower'];
const unit=x=>Math.min(1,Math.max(0,Number(x)||0));
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const plain=x=>x&&typeof x==='object'&&!Array.isArray(x);
const clone=x=>structuredClone(x);
// Normalization already validates complete render preferences. Read them live:
// a valid nested edit must not be hidden by a WeakMap's object identity. Sparse
// document/API inputs still pass through the public validator at the boundary.
const validatedSettings=new WeakSet();
function cachedSettings(raw){if(!plain(raw))return CONDITION_RESPONSE_DEFAULTS;return validatedSettings.has(raw)?raw:conditionReactionSettings(raw);}
const mix=(a,b,t)=>a+(b-a)*t;
const profileKeys=['damage','instability','glitch','energy','collapse'];

export function conditionReactionPatch(raw){
  if(!plain(raw))throw new Error('Condition reactions must be an object.');
  const out={};
  for(const [key,value] of Object.entries(raw)){
    if(['enabled','wings','bits'].includes(key)){if(typeof value!=='boolean')throw new Error(`${key} must be true or false.`);out[key]=value;}
    else if(key==='conditions'){
      if(!plain(value))throw new Error('Condition choices must be an object.');out.conditions={};
      for(const [id,choice] of Object.entries(value)){
        if(!ACTOR_CONDITION_IDS.includes(id)||!plain(choice))throw new Error(`Unknown condition reaction: ${id}.`);
        const entry={};
        for(const [field,v] of Object.entries(choice)){
          if(field==='enabled'){if(typeof v!=='boolean')throw new Error('Condition enabled must be true or false.');}
          else if(field==='strength'){if(!finite(v)||v<0||v>1)throw new Error('Condition strength must be between zero and one.');}
          else if(field==='style'){
            if(!['default','none'].includes(v)&&!conditionEffectCategory(v))throw new Error('Choose an existing wing condition animation.');
            if(id==='unconscious'&&v!=='default')throw new Error('Unconscious wings use the existing Reform animation; disable the reaction to opt out.');
          } else throw new Error(`Unknown condition reaction field: ${field}.`);
          entry[field]=v;
        }
        out.conditions[id]=entry;
      }
    } else throw new Error(`Unknown condition reaction setting: ${key}.`);
  }
  return out;
}
export function conditionReactionSettings(raw={}){
  const patch=conditionReactionPatch(raw??{});
  const conditions={};
  for(const id of ACTOR_CONDITION_IDS){const base=CONDITION_RESPONSE_DEFAULTS.conditions[id],choice=patch.conditions?.[id];
    conditions[id]={enabled:choice?.enabled??base.enabled,strength:choice?.strength??base.strength,style:choice?.style??base.style};}
  const out={...CONDITION_RESPONSE_DEFAULTS,...patch,conditions};validatedSettings.add(out);return out;
}
export function mergeConditionReactions(before,patch){
  const base=conditionReactionSettings(before),next=conditionReactionPatch(patch);
  return conditionReactionSettings({...base,...next,conditions:Object.fromEntries(ACTOR_CONDITION_IDS.map(id=>[id,{...base.conditions[id],...next.conditions?.[id]}]))});
}

/** Share the effective condition reader with HP, so an obsolete status icon
 * cannot disagree with the system's current recovered state. */
export function readActorConditions(actor){
  const out={};
  for(const id of ACTOR_CONDITION_IDS){
    let {active,condition}=readActorCondition(actor,id);
    if(id==='dead')active=!!actor?.statuses?.has?.('dead');
    if(!active&&['glitching','suppressed','untethered'].includes(id)){
      condition=starfinderConditionEffect(actor,id);active=!!condition||actor?.rollOptions?.all?.[`self:condition:${id}`]===true;
    }
    if(!active&&id==='off-guard')({active,condition}=readActorCondition(actor,'flat-footed'));
    if(active)out[id]=Math.max(1,Math.min(4,Number(condition?.value??condition?.system?.value?.value??condition?.badge?.value??condition?.system?.badge?.value)||1));
  }
  if(out['persistent-damage']){
    const types=readPersistentDamageTypes(actor);
    if(types.length)out.damageTypes=types;
  }
  return out;
}
const SF_EFFECT_IDS={suppressed:'enA7BxAjBb7ns1iF',glitching:'6A2QDy8wRGCVQsSd',untethered:'z1ucw4CLwLqHoAp3'};
function starfinderConditionEffect(actor,id){
  const effects=actor?.itemTypes?.effect??actor?.items?.contents??(Array.isArray(actor?.items)?actor.items:[]);
  return effects.find(item=>item?.type==='effect'&&item.isExpired!==true&&item.isSuppressed!==true&&item.system?.disabled!==true&&item.system?.active!==false&&item.system?.expired!==true&&
    ([id,`effect-${id}`].includes(item.slug??item.system?.slug)||[item._stats?.compendiumSource,item.flags?.core?.sourceId,item.sourceId].some(source=>source===`Compendium.sf2e.conditions.Item.${SF_EFFECT_IDS[id]}`)))??null;
}
export const DAMAGE_TYPES=Object.freeze(['acid','bleed','cold','electricity','fire','force','mental','poison','sonic','spirit','vitality','void','bludgeoning','piercing','slashing','radiation','untyped']);
const DAMAGE_ALIASES={positive:'vitality',negative:'void'};
// v11: an unknown (homebrew) persistent type passes through as a plain slug,
// so the v11 fallback look can show it; the v10 art still draws only the
// types it knows (it maps the rest to its own generic look).
const DAMAGE_SLUG=/^[a-z][a-z0-9-]{0,39}$/;
export const damageTypeSlug=value=>{const v=typeof value==='string'?value.toLowerCase().trim():'';return DAMAGE_SLUG.test(v)?(DAMAGE_ALIASES[v]??v):'';};
const damageTypes=raw=>{
  const out=[];if(!Array.isArray(raw))return out;
  for(const value of raw){const type=damageTypeSlug(value);if(type&&!out.includes(type))out.push(type);if(out.length>=16)break;}
  return out.sort();
};
export function readPersistentDamageTypes(actor){
  let entries,specific=false;
  try{if(typeof actor?.conditions?.bySlug==='function'){entries=actor.conditions.bySlug('persistent-damage',{active:true});specific=true;}}catch{/* Older/generic actors use prepared items. */}
  if(entries==null)try{if(typeof actor?.getCondition==='function'){const found=actor.getCondition('persistent-damage',{all:true});if(found){entries=Array.isArray(found)?found:[found];specific=true;}}}catch{/* Fall back to prepared items. */}
  entries=entries??actor?.itemTypes?.condition??actor?.items?.contents??(Array.isArray(actor?.items)?actor.items:[]);
  return damageTypes(entries.filter(item=>item?.active!==false&&item?.isExpired!==true&&item?.isSuppressed!==true&&
    (specific||(item.slug??item.system?.slug)==='persistent-damage')).map(item=>item.system?.persistent?.damageType??item.system?.persistent?.type??item.damageType));
}
export const actorConditionKey=conditions=>ACTOR_CONDITION_IDS.map(id=>`${id}:${conditions?.[id]??0}`).join('|')+`|damage:${damageTypes(conditions?.damageTypes).join(',')}`;
/** The frame sampler needs equality, not two complete serialized hook keys.
 * Preserve the key's coercion for generic actor values and normalized aliases. */
export function actorConditionsEqual(a,b){
  for(const id of ACTOR_CONDITION_IDS){const x=a?.[id]??0,y=b?.[id]??0;if(x!==y&&String(x)!==String(y))return false;}
  if(!a?.damageTypes?.length&&!b?.damageTypes?.length)return true;
  const x=damageTypes(a?.damageTypes),y=damageTypes(b?.damageTypes);
  return x.length===y.length&&x.every((type,index)=>type===y[index]);
}
/** Health reactions belong to the deployed instruments too, not just wings. */
export function reactionVisualActive(flight,allocations,animations){
  const events=Array.isArray(animations)?animations:animations?.events;
  return !!(flight?.enabled||flight?.bitsDeployed||Object.values(allocations?.bits??{}).some(bit=>bit?.location&&bit.location!=='retracted')||Array.isArray(events)&&events.some(event=>event?.status!=='finished'));
}
/** Zero HP behaves as loss of power even before PF2e adds Unconscious. Actual
 * unconsciousness remains authoritative after healing, until that condition
 * is removed. Explicit HP/reaction opt-outs remain independent. */
export function effectiveActorConditions(data={},conditions={},health=null,config={}){
  if((conditions.dying||conditions.dead)&&!conditions.unconscious)conditions={...conditions,unconscious:1};
  const down=health?.value===0||health?.unconscious&&config.unconsciousCollapse!==false;
  return down&&data.autoHP!==false&&config.hpReactions!==false&&config.zeroHPBehavior!=='ignore'&&!conditions.unconscious?{...conditions,unconscious:1}:conditions;
}
export function readConditionResponse(raw){
  if(raw==null)return null;
  if(!plain(raw)||typeof raw.id!=='string'||!/^[\w-]{1,64}$/.test(raw.id)||!finite(raw.started))throw new Error('Invalid condition reaction event.');
  const out={id:raw.id,started:raw.started,from:{},to:{}};
  if(raw.motionHeld!=null){if(!finite(raw.motionHeld))throw new Error('Invalid held condition clock.');out.motionHeld=raw.motionHeld;}
  for(const field of ['from','to']){
    if(!plain(raw[field]))throw new Error('Invalid condition reaction levels.');
    for(const id of ACTOR_CONDITION_IDS){const v=raw[field][id]??0;if(!finite(v)||v<0||v>4)throw new Error('Invalid condition severity.');out[field][id]=v;}
    if(raw[field].damageTypes!=null){
      if(!Array.isArray(raw[field].damageTypes)||raw[field].damageTypes.some(type=>!damageTypeSlug(type)))throw new Error('Invalid persistent damage types.');
      if(raw[field].damageTypes.length)out[field].damageTypes=damageTypes(raw[field].damageTypes);
    }
  }
  if(raw.collapse!=null){
    const c=raw.collapse;
    if(!plain(c)||typeof c.id!=='string'||!finite(c.started)||!['falling','recovering'].includes(c.phase)||!finite(c.from)||c.from<0||c.from>1)throw new Error('Invalid collapse reaction.');
    const bits=Array.isArray(c.bits)?c.bits.filter(id=>BIT_IDS.includes(id)):[];
    out.collapse={id:c.id,started:c.started,phase:c.phase,from:c.from,reformFrom:finite(c.reformFrom)?unit(c.reformFrom):c.phase==='falling'?0:CONDITION_RESPONSE_TIMING.broken,flightGrounded:c.flightGrounded===true,bits:[...new Set(bits)],originsWorld:{},originDepths:{},restsWorld:readBitRestPoses(c.restsWorld,bits)};
    for(const id of bits){const p=c.originsWorld?.[id];if(p&&finite(p.x)&&finite(p.y))out.collapse.originsWorld[id]={x:p.x,y:p.y};out.collapse.originDepths[id]=c.originDepths?.[id]===-1?-1:1;}
  }
  if(raw.grounding!=null){
    const g=raw.grounding;
    if(!plain(g)||!Array.isArray(g.reasons)||g.reasons.some(id=>!['prone','paralyzed','stunned'].includes(id))||typeof g.flightGrounded!=='boolean')throw new Error('Invalid condition grounding event.');
    out.grounding={reasons:[...new Set(g.reasons)],flightGrounded:g.flightGrounded};
  }
  return out;
}

const pendingEdges=new Map();
/** One saved (or locally pending) fall/rebuild, sampled in its own direction. */
function sampleCollapse(event,falling,now,reduced){
  const duration=falling?CONDITION_RESPONSE_TIMING.fall:CONDITION_RESPONSE_TIMING.recover;
  const p=reduced?1:unit((now-event.started)/duration);
  return {...event,phase:falling?(p<1?'falling':'fallen'):(p<1?'recovering':'awake'),mix:mix(event.from,falling?1:0,smooth(p)),progress:p,
    reformProgress:mix(event.reformFrom??(falling?0:CONDITION_RESPONSE_TIMING.broken),falling?CONDITION_RESPONSE_TIMING.broken:1,smooth(p))};
}
/** Input levels remain actual condition values until normalized by each user's
 * intensity controls. No per-frame condition-item scan or token update. */
export function sampleConditionResponse(data={},actorConditions={},now=0,{reduced=false,health=null,config:world={}}={}){
  actorConditions=effectiveActorConditions(data,actorConditions,health,world);
  const config=cachedSettings(data.conditionReactions),event=data.conditionResponse;
  const eventMatches=event&&actorConditionsEqual(event.to,actorConditions);
  const fade=eventMatches&&!reduced?smooth((now-event.started)/CONDITION_RESPONSE_TIMING.change):1;
  const empty=(!eventMatches||fade===1)&&Object.keys(actorConditions).length===0;
  // Nothing writes these maps after sampling: the empty case shares one frozen set.
  const rawLevels=empty?ZERO_LEVELS:{},levels=empty?ZERO_LEVELS:{},targetStrengths=empty?ZERO_LEVELS:{},active=[];
  // Allocate each condition channel once. Roster order and arithmetic remain
  // identical to the separate passes, including the active-entry priority.
  if(!empty)for(const id of ACTOR_CONDITION_IDS){
    const choice=config.conditions[id],enabled=config.enabled&&choice.enabled;
    const raw=eventMatches?mix(event.from?.[id]??0,event.to?.[id]??0,fade):actorConditions?.[id]??0;
    const strength=enabled?unit(raw)*choice.strength:0;
    rawLevels[id]=raw;levels[id]=strength;targetStrengths[id]=enabled?unit(actorConditions[id])*choice.strength:0;
    if(strength>.001)active.push({id,label:ACTOR_CONDITION_LABELS[id],value:raw,strength,style:choice.style});
  }
  const saved=event?.collapse,mayCollapse=config.enabled&&config.conditions.unconscious.enabled&&config.conditions.unconscious.strength>0;
  let collapse={id:null,phase:'awake',mix:0,progress:1,reformProgress:1,started:0,bits:[],originsWorld:{},originDepths:{}};
  if(mayCollapse&&(saved||actorConditions?.unconscious)){
    const falling=!!actorConditions.unconscious;
    if(saved&&falling===(saved.phase==='falling'))collapse=sampleCollapse(saved,falling,now,reduced);
    else if(reduced)collapse=saved?{...saved,phase:falling?'fallen':'awake',mix:falling?1:0,progress:1,reformProgress:falling?CONDITION_RESPONSE_TIMING.broken:1}:
      {...collapse,phase:'fallen',mix:1,reformProgress:CONDITION_RESPONSE_TIMING.broken};
    else{
      // Beta.29: HP reaches every client before the reaction event does (or
      // the event never comes after a disconnect). Instead of snapping to the
      // other end, play the same fall/rebuild from the moment this client
      // first saw the change; the saved event then continues it in place.
      const key=`${data.started??0}|${saved?.id??'none'}|${falling?1:0}`;
      let started=pendingEdges.get(key);
      if(started===undefined||started>now){started=now;pendingEdges.set(key,now);if(pendingEdges.size>64)pendingEdges.delete(pendingEdges.keys().next().value);}
      const origin=saved?sampleCollapse(saved,saved.phase==='falling',started,false):null;
      collapse=sampleCollapse({...(saved??collapse),id:saved?.id??'pending',started,phase:falling?'falling':'recovering',
        from:origin?origin.mix:0,reformFrom:origin?origin.reformProgress:0},falling,now,false);
    }
  }
  const primary=collapse.phase!=='awake'?'unconscious':active[0]?.id??null;
  return {enabled:config.enabled,wings:config.enabled&&config.wings,bits:config.enabled&&config.bits,active,primary,
    label:collapse.phase==='recovering'?'Recovering':primary?`Responding to ${ACTOR_CONDITION_LABELS[primary]}`:'No condition reaction',
    levels,rawLevels,targetLevels:empty?NO_CONDITIONS:{...actorConditions},targetStrengths,
    fxTime:Math.max(0,(now-(data.started??0))/1000),damageTypes:damageTypes(actorConditions?.damageTypes),motionHeld:event?.motionHeld??null,grounding:event?.grounding??null,collapse,reduced,config};
}

/** v11 (11.0.0-test.2): the v10 persistent-damage art steps aside, type by
 * type, wherever v11 persistent damage draws that type (its feature and the
 * type's part on for her token), so the two never play together. `shows` is
 * damage-events.mjs v11PersistFilter(values): null leaves the response alone.
 * Edits the freshly sampled response in place (its maps are its own). */
const PD='persistent-damage';
export function withoutV11Persistent(response,shows){
  if(!shows||!response||!(response.rawLevels?.[PD]>0))return response;
  const types=response.damageTypes??[];if(!types.length)return response;
  const keep=types.filter(t=>!shows(t));if(keep.length===types.length)return response;
  response.damageTypes=keep;
  if(response.targetLevels?.damageTypes)response.targetLevels=keep.length?{...response.targetLevels,damageTypes:keep}:(({[PD]:_,damageTypes:__,...rest})=>rest)(response.targetLevels);
  if(!keep.length){
    response.levels[PD]=0;response.rawLevels[PD]=0;response.targetStrengths[PD]=0;
    response.active=response.active.filter(a=>a.id!==PD);
    if(response.primary===PD){response.primary=response.active[0]?.id??null;response.label=response.primary?`Responding to ${ACTOR_CONDITION_LABELS[response.primary]}`:'No condition reaction';}
  }
  return response;
}

export function makeConditionResponse({id,now,previous,next,current,captured={}}){
  const was=!!previous?.unconscious,is=!!next?.unconscious;
  let collapse=current?.collapse?.id?clone(current.collapse):null;
  if(was!==is){collapse={id,started:now,phase:is?'falling':'recovering',from:current?.collapse?.mix??(was?1:0),reformFrom:is&&current?.collapse?.phase==='awake'?0:current?.collapse?.reformProgress??(was?CONDITION_RESPONSE_TIMING.broken:0),flightGrounded:false,
    bits:[...(captured.bits??current?.collapse?.bits??[])],originsWorld:clone(captured.originsWorld??current?.collapse?.originsWorld??{}),originDepths:clone(captured.originDepths??current?.collapse?.originDepths??{}),
    restsWorld:is&&captured.persistent?makeBitRestPoses(id,captured.bits??[],captured):clone(current?.collapse?.restsWorld??{})};}
  // Stored collapse phase is a direction, not the sampled settled-state name.
  if(collapse)collapse.phase=is?'falling':'recovering';
  const blockers=conditions=>['prone','paralyzed','stunned'].filter(key=>key==='stunned'?(conditions?.[key]??0)>=3:(conditions?.[key]??0)>0);
  const priorBlockers=blockers(previous),nextBlockers=blockers(next);
  let grounding=current?.grounding?clone(current.grounding):null;
  // A new incapacitation owns its own grounding acknowledgment. Removing a
  // status cannot erase an uncommitted grounding before the writer catches up.
  if(nextBlockers.some(key=>!priorBlockers.includes(key)))grounding={reasons:nextBlockers,flightGrounded:false};
  const held=conditions=>(conditions?.stunned??0)>=3||(conditions?.paralyzed??0)>0||(conditions?.petrified??0)>0;
  const motionHeld=held(next)?held(previous)&&finite(current?.motionHeld)?current.motionHeld:now+CONDITION_RESPONSE_TIMING.change:null;
  return readConditionResponse({id,started:now,from:{...(current?.rawLevels??previous??{}),...(previous?.damageTypes?{damageTypes:previous.damageTypes}:{})},to:next??{},collapse,grounding,motionHeld});
}

/** Current condition values own flight permission immediately; art intensity
 * may still blend for 450 ms. Saved appearance and actor rules are untouched. */
const groundingReactionEnabled=(response,id)=>!!(response?.enabled&&(response.wings||response.bits)&&
  response.config.conditions[id].enabled&&response.config.conditions[id].strength>0&&response.config.conditions[id].style!=='none');
export function conditionFlightBlockers(response){
  const levels=response?.targetLevels??response?.rawLevels??{};
  return ['prone','paralyzed','stunned'].filter(id=>groundingReactionEnabled(response,id)&&(id==='stunned'?(levels[id]??0)>=3:(levels[id]??0)>0));
}
export function conditionGroundsFlight(data,response){
  if(conditionFlightBlockers(response).length)return true;
  const pending=data?.conditionResponse?.grounding;
  return !!(pending&&!pending.flightGrounded&&pending.reasons.some(id=>groundingReactionEnabled(response,id)))||conditionRecoveryGroundsFlight(data,response);
}

/** A recovery is not a Take off command. Until the elected writer clears the
 * saved airborne flag, all observers suppress its old lift. The acknowledgement
 * survives subsequent conditions so an explicit later Take off remains valid. */
export function conditionRecoveryGroundsFlight(data,response){
  const saved=data?.conditionResponse?.collapse;
  return !!(saved&&!saved.flightGrounded&&response?.enabled&&(response.wings||response.bits)&&
    response.config.conditions.unconscious.enabled&&response.config.conditions.unconscious.strength>0&&
    ['recovering','awake'].includes(response.collapse.phase));
}

/** Existing Reform owns every broken/rebuilding lattice span. The only new
 * behavior is its clock: hold its broken phase, then continue that same cue. */
export function conditionReform(response,data={},config={}){
  if(!response?.wings||response.collapse.phase==='awake')return null;
  const selected=data.reactionStyles?.reform??config.reactionEffect_reform;
  const id=['rethread','weave','recall'].includes(selected)?selected:'rethread';
  const cue={id,kind:'reform',progress:response.collapse.reformProgress,strength:1,amount:1,envelope:1};
  return {cue,reformation:reformationOf([cue],[])};
}

const defaultWingStyles={stunned:'phaseTears'};
/** Beta.29: the Unconscious reaction wears the chosen "Wings at zero HP" look.
 * Falling (0.95 s) eases every channel from the wing she has now (a critical
 * wing breaks further; nothing heals first) to the chosen look. Recovering
 * (2 s) keeps the resting look ahead of a rethread front that runs out from
 * her shoulders: behind it the light is back and a folded wing unfurls root
 * first; ahead of it the wing is still at rest, so no ghost wing appears. */
function zeroHPLook(visual,response,look,reform,config,terminal=0){
  const c=response.collapse,down=unit(c.mix),recovering=c.phase==='recovering',q=recovering?unit(c.progress):1;
  // A fall starts from her critical-HP wing (what she shows as HP runs out;
  // the 550 ms effect handoff blends from whatever is really on screen).
  const base=recovering?visual.semanticProfile??visual.profile:mixProfiles(profileFor('normal'),profileFor('glitching'),config.hpReactionIntensity??1),live=visual.profile;
  const channel=key=>mix(base[key]??(key==='energy'?1:0),look[key],down);
  const out={damage:config.filamentBreaks===false?0:channel('damage'),instability:config.filamentInstability===false?0:channel('instability'),
    glitch:config.filamentGlitches===false||response.reduced?0:Math.min(config.glitchLimit??1,channel('glitch')),energy:channel('energy'),
    variant:null,reactions:[],bursts:[],reformation:null,overdrive:0,suppression:0,flare:0,pulse:0,geometryFlare:0,geometryPulse:0,healing:0,conditionResponse:response};
  out.sag=config.filamentInstability===false?0:out.damage*.7;
  const rest=look.opacity*(1-terminal*.85);
  let fold=channel('collapse'),foldTip=fold,opacity=mix(live.renderOpacity??Math.min(1,live.energy??1),rest,down);
  if(recovering&&!response.reduced){
    // Root opens first, the tips last: the wing unfurls behind the front.
    const from=base.collapse??0;
    fold=mix(from,look.collapse,1-smooth(q/.42));foldTip=mix(from,look.collapse,1-smooth((q-.12)/.68));
    opacity=mix(rest,live.renderOpacity??1,smooth(q/.14));
    const reformation=reform.reformation;
    if(reformation&&opacity>.001){
      out.reformation={...reformation,hide:unit(1-rest/opacity),lift:0};
      out.bursts=[reform.cue];
    }
  }
  out.collapse=fold;if(foldTip!==fold)out.collapseTip=foldTip;
  out.renderOpacity=opacity;
  out.dynamic=!response.reduced&&(c.phase!=='fallen'||out.glitch>0||out.instability>0||out.damage>0&&visual.profile.sparks);
  return out;
}
/** Authored conditions own their selected artwork. Automatic HP wear composes
 * with an actor response instead of taking its place. Dedicated PF2e lattice
 * articulation accompanies any saved look; Unconscious Reform retains priority.
 */
function applyWingConditionLegacy(visual,response,data,config){
  if(!response?.wings)return visual;
  const p={...visual.profile},result={...visual,profile:p};
  const reform=conditionReform(response,data,config);
  const conditionConfig=conditionConfigFor(config);
  let complete=null;
  if(reform){
    complete=sampleCompleteConditionMotion(response,p,conditionConfig);
    if(complete)p.completeConditionMotion=complete;
    const look=ZERO_HP_LOOKS[config.zeroHPBehavior];
    // Keep Reform's broken lattice, while extinguishing its bright rebuilding
    // currents as Dead settles. A dying relay can still struggle through it.
    const terminal=1-(1-(response.levels?.dead??complete?.extinguished??0))**3;
    const terminalGain=1-terminal*.98*(response.collapse.progress??1);
    if(look)Object.assign(p,zeroHPLook(visual,response,look,reform,config,terminal));
    else{
      // "Keep critical look" with a real Unconscious condition: Broken Reform.
      // Beta.29: it breaks down from the wing on screen (no healed first frame).
      const c=response.collapse,from=c.phase==='recovering'?0:1-unit(c.mix),base=visual.semanticProfile??visual.profile;
      for(const key of profileKeys)p[key]=key==='energy'?1:(base[key]??0)*from;
      Object.assign(p,{reformation:reform.reformation,bursts:[reform.cue],reactions:[],variant:null,renderOpacity:1,
        sag:0,overdrive:0,suppression:0,flare:0,pulse:0,geometryFlare:0,geometryPulse:0,
        dynamic:!response.reduced&&response.collapse.phase!=='fallen',conditionResponse:response});
    }
    if(response.collapse.phase==='recovering'&&(response.targetStrengths?.prone??0)>.001&&response.config.conditions.prone.style==='default')p.variant=visual.profile.variant;
    if(terminalGain<1&&p.bursts?.length)p.bursts=[{...p.bursts[0],amount:terminalGain,strength:terminalGain}];
    // An unconscious actor may still be prone after waking. Rebuild the
    // existing resting lattice immediately, rather than recovering a full flap
    // and only then applying the already-present prone posture.
    const recoveringMotion=sampleActorWingMotion(response,p,conditionConfig);
    if(recoveringMotion){
      p.actorConditionMotion=recoveringMotion;
      const strength=recoveringMotion.strengths.prone??0,prone=response.config.conditions.prone;
      p.sag=strength*.25;
      const normalChoice=data.effectStyles?.normal??data.effectStyle??config.conditionEffect_normal;
      const ownsArtwork=data.conditionSource!=='auto'&&data.condition!=='normal'||normalChoice!=null&&normalChoice!=='default';
      const style=prone.style==='default'?defaultWingStyles.prone:prone.style,category=conditionEffectCategory(style);
      const entry=CONDITION_EFFECTS[category]?.find(e=>e.id===style);
      if(strength>0&&!ownsArtwork&&style&&category&&config.enhancedConditions!==false&&(!entry?.gate||config[entry.gate]!==false)){
        p.variant={id:style,condition:category,activeCondition:visual.condition,amount:strength,time:p.time,frequency:1};
        p.variantMotion=config.conditionMotionStrength??1;
        p.gates={breaks:config.filamentBreaks,instability:config.filamentInstability,glitches:config.filamentGlitches,
          sparks:config.conditionSparks,echoes:config.glitchEchoes,arcs:config.overdriveArcs,displacement:config.glitchDisplacement,glitchLimit:config.glitchLimit};
      }
    }
    if(complete&&!p.actorConditionMotion)p.actorConditionMotion={active:true,animated:complete.animated,strengths:complete.strengths??{},fitting:[],fold:0,sag:0,retreat:0,focus:0,facet:0,roll:0,sway:0,elastic:0,scatter:0,reverse:0,surge:0,quiet:0};
    if(complete){p.dynamic=p.dynamic||complete.animated;p.energy=(p.energy??1)*(1-(complete.quiet??0));}
    result.rigMix=1;result.condition='collapsed';result.incapacitated=response.collapse.phase!=='recovering';
    result.overrideActive=true;return result;
  }
  if(config.visualConditions===false)return visual;
  const entries=response.active.filter(x=>x.id!=='unconscious'),chosen=entries.find(x=>x.style!=='none');
  if(!chosen)return visual;
  const style=chosen.style==='default'?defaultWingStyles[chosen.id]:chosen.style;
  const category=conditionEffectCategory(style),entry=CONDITION_EFFECTS[category]?.find(e=>e.id===style);
  const gate=!entry?.gate||config[entry.gate]!==false;
  const normalChoice=data.effectStyles?.normal??data.effectStyle??config.conditionEffect_normal;
  const ownsArtwork=visual.overrideActive||data.conditionSource!=='auto'&&visual.condition!=='normal'||
    normalChoice!=null&&normalChoice!=='default';
  let actorVariant=false;
  if(!ownsArtwork&&style&&category&&gate&&config.enhancedConditions!==false){
    const strength=chosen.id==='stunned'?actorConditionStunAmount(response):chosen.id==='fatigued'&&chosen.style==='default'?chosen.strength*.4:chosen.strength;
    p.variant={id:style,condition:category,activeCondition:visual.condition,amount:strength,time:p.time,frequency:1};
    p.variantMotion=config.conditionMotionStrength??1;p.dynamic=!response.reduced;
    p.gates??={breaks:config.filamentBreaks,instability:config.filamentInstability,glitches:config.filamentGlitches,
      sparks:config.conditionSparks,echoes:config.glitchEchoes,arcs:config.overdriveArcs,displacement:config.glitchDisplacement,glitchLimit:config.glitchLimit};
    result.rigMix=Math.max(result.rigMix??0,chosen.strength);
    actorVariant=true;
  }
  const l=Object.fromEntries(entries.filter(x=>x.style!=='none').map(x=>[x.id,x.strength]));
  if(config.filamentInstability!==false){
    p.sag=Math.max(p.sag??0,(l.fatigued??0)*.1+(l.prone??0)*.25);
    // Keep fear readable even when the selected wing art has priority. This
    // is a sub-pixel quiver at ordinary token scale, not a second art layer.
    if(!response.reduced)p.instability=Math.max(p.instability??0,(l.frightened??0)*.04);
    result.rigMix=Math.max(result.rigMix??0,Math.min(1,Math.max(p.sag,p.instability??0)*6));
    p.dynamic=p.dynamic||!response.reduced&&(p.sag>0||p.instability>0);
  }
  p.conditionResponse=response;
  const arrest=actorConditionMotionArrest(response);
  if(arrest>=.999&&!response.reduced){
    // Hold the settled reaction's existing clock. Artwork's animated flag is
    // retained because its helpers use false to reset to frame zero.
    const held=response.motionHeld??data.conditionResponse?.motionHeld??(data.conditionResponse?.started??data.started??0)+CONDITION_RESPONSE_TIMING.change;
    const time=Math.min(p.time??Infinity,Math.max(0,(held-(data.started??0))/1000)),ratio=p.time>0?(p.effectTime??p.time)/p.time:config.conditionAnimationSpeed??1;
    const variantRatio=p.time>0?(p.variant?.time??p.time)/p.time:config.conditionAnimationSpeed??1;
    p.time=time;p.effectTime=time*ratio;p.conditionFrozenTime=p.effectTime;p.conditionMotionFrozen=true;
    if(p.variant)p.variant={...p.variant,time:time*variantRatio};
  }
  p.actorConditionMotion=sampleActorWingMotion(response,p,conditionConfig);
  complete=sampleCompleteConditionMotion(response,p,conditionConfig);
  if(complete)p.completeConditionMotion=complete;
  else delete p.completeConditionMotion;
  if(complete&&!p.actorConditionMotion)p.actorConditionMotion={active:true,animated:complete.animated,strengths:complete.strengths??{},fitting:[],fold:0,sag:0,retreat:0,focus:0,facet:0,roll:0,sway:0,elastic:0,scatter:0,reverse:0,surge:0,quiet:0};
  if(complete){result.rigMix=Math.max(result.rigMix??0,...Object.values(complete.strengths??{}));p.dynamic=p.dynamic||complete.animated;p.energy=(p.energy??1)*(1-(complete.quiet??0));}
  if(p.actorConditionMotion){
    // Worker frames carry the compact visual profile separately from flight.
    // Five bounded material values keep actor seams identical in either path.
    p.actorConditionMotion.hp=visual.hpOverlayProfile?Object.fromEntries(profileKeys.map(key=>[key,visual.hpOverlayProfile[key]])):null;
    p.actorConditionMotion.gates={breaks:config.filamentBreaks!==false,instability:config.filamentInstability!==false,
      glitches:config.filamentGlitches!==false,glitchLimit:config.glitchLimit??1};
    // Numeric HP already dims the shared painter for composed/original art.
    // Only a primary named HP treatment needs a separate seam brightness mask.
    p.actorConditionMotion.hpDim=p.variant&&!visual.hpComposed&&!actorVariant&&visual.hpOverlayProfile?Math.min(1,visual.hpOverlayProfile.energy):1;
    result.rigMix=Math.max(result.rigMix??0,...Object.values(p.actorConditionMotion.strengths));
    p.dynamic=p.dynamic||p.actorConditionMotion.animated;
    // Visual depletion is multiplicative, so both PF2e exhaustion and injury
    // remain visible without resetting the chosen artwork's own energy.
    p.energy=(p.energy??1)*(1-p.actorConditionMotion.quiet);
  }
  const composed=actorVariant?composeHPArtwork(result,config):result;
  if(p.conditionMotionFrozen)composed.profile.dynamic=false;
  return composed;
}

/** Automatic conditions animate the original filament wing material.
 * Existing Reform and real actor rules retain their established priority. */
export function applyWingCondition(visual,response,data,config){
  // Awake wings without a reaction keep the existing profile verbatim. There
  // is no condition material to copy or complete-motion program to sample.
  if(!response?.wings||response.active?.length===0&&response.collapse.phase==='awake')return visual;
  const result=applyWingConditionLegacy(visual,response,data,config);
  if(!response?.wings||!response.active?.length&&response.collapse.phase==='awake')return result;
  // The legacy pass already made (and owns) a fresh profile unless it returned the input.
  const p=result.profile!==visual.profile?result.profile:{...result.profile};
  const character=sampleStatusFlightCharacter(response,p,config);
  const effects=sampleStatusFilamentEffects(response,p,config);
  if(character?.active)p.statusFlightCharacter=character;
  if(effects?.active)p.statusFilamentEffects=effects;
  // Keep the familiar lattice and its shallow weight/tempo changes. New
  // filament effects carry the status identity rather than folding new bodies.
  if(p.actorConditionMotion){
    const m={...p.actorConditionMotion};
    m.fitting=(m.fitting??[]).filter(id=>id==='stunned');
    m.fold=Math.min(.055,m.fold??0);m.sag=Math.min(16,m.sag??0);
    m.focus=(m.focus??0)*.15;m.facet=0;m.retreat=(m.retreat??0)*.25;
    p.actorConditionMotion=m;
  }
  if(p.completeConditionMotion)p.completeConditionMotion={...p.completeConditionMotion,fitting:[]};
  delete p.statusWingState;
  if(effects?.animated)p.dynamic=true;
  return {...result,profile:p,rigMix:effects?.active?1:result.rigMix};
}

/** A bounded correction around each assigned station; falling overrides the
 * station only while unconscious. Points are world positions in world mode;
 * local mode uses a 100-unit token diameter with source at its local centre. */
export function applyBitCondition(point,response,{id,index=0,now=0,scale=100,source={x:0,y:0},world=true,positionLocked=false}={}){
  const out={...point,angleDelta:0,glowMultiplier:1,conditionMotion:1};
  if(!response?.bits)return out;
  const c=response.collapse,l=response.levels,t=now/1000,k=scale/100;
  if(c.phase!=='awake'&&(c.bits.length===0||c.bits.includes(id))){
    const resting=world?sampleBitRest(point,c,id,now,{reduced:response.reduced}):null;
    if(resting)return {...out,...resting};
    const rank=BIT_IDS.indexOf(id)>=0?BIT_IDS.indexOf(id):index;
    const ground={x:source.x+[-38,35,-20,19][rank]*k,y:source.y+[48,47,61,59][rank]*k};
    const from=world?(c.originsWorld?.[id]??point):point;
    const falling=c.phase!=='recovering',amount=c.mix;
    out.x=mix(falling?from.x:point.x,ground.x,amount);
    out.y=mix(falling?from.y:point.y,ground.y,amount);
    if(falling&&c.phase==='falling'&&!response.reduced)out.y-=Math.sin(Math.PI*c.progress)*8*k;
    out.z=mix(point.z??1,1,amount);
    out.angleDelta=([-1.08,.96,-.72,.78][rank]+(falling&&!response.reduced?Math.sin(Math.PI*c.progress)*1.3:0))*amount;
    out.glowMultiplier=1-.98*amount;out.conditionMotion=1-amount;
    out.conditionGround=amount;return out;
  }
  if(response.reduced)return out;
  const a=id=>response.active?.some(entry=>entry.id===id&&entry.style!=='none')?l[id]??0:0;
  const frightened=a('frightened'),stunned=actorConditionStunAmount(response),arrest=actorConditionMotionArrest({...response,wings:response.bits}),heavy=Math.max(a('fatigued')*.65,a('slowed')),prone=a('prone'),quick=a('quickened');
  // Free wing support owns its exact anchor/route. Conditions still articulate
  // and dim the mechanism; collapse above retains its actual falling/rest pose.
  if(!positionLocked){
    out.x+=(Math.sin(t*7.7+index*1.7)*.7+Math.sin(t*3.2+index)) * frightened*k*(1-arrest);
    out.y+=(Math.sin(t*6.3+index*2.2)*.7*frightened*(1-arrest)+heavy*3+prone*5)*k;
  }
  out.angleDelta=(Math.sin(t*1.6+index)*.045*frightened+Math.sin(t*.7+index)*.025*heavy)*(1-arrest);
  out.glowMultiplier=Math.max(.08,1-stunned*.75-heavy*.22+quick*.12*(.5+.5*Math.sin(t*4-index))*(1-arrest));
  out.conditionMotion=Math.max(0,(1-stunned*.9-heavy*.35+quick*.15)*(1-arrest));
  return out;
}
