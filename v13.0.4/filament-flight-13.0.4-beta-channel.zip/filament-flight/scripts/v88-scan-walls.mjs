/** Cached wall guards for continuous instrument work. Native V14 movement and
 * sight backends remain authoritative for doors, direction, elevation and
 * levels. Solvers run only when a work visit/anchor changes, never on a sample.
 * No hidden wall coordinates or ids leave this module. */
import {sceneBitRouteAdapter,sceneWallsNear} from './v8-scene-routing.mjs?v=13.0.4';
import {planBitRoute,compileBitRoute,sampleWeightedTransit} from './v8-motion.mjs?v=13.0.4';
import {scanPointInPolygon,scanPolygonBounds} from './v82-scene-scan-context.mjs?v=13.0.4';
import {scanArtworkAim} from './v8-scan-art.mjs?v=13.0.4';
import {stepScanRouteSpeed} from './v88-scan-locomotion.mjs?v=13.0.4';
import {scanPortraitGeometryKey} from './v83-token-scan-mask.mjs?v=13.0.4';

const contexts=new WeakMap(),rosters=new WeakMap(),revisions=new WeakMap(),visibilityRevisions=new WeakMap();
const finitePoint=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
const copy=p=>({x:p.x,y:p.y});
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const keyPoint=p=>`${p?.x},${p?.y}`;
const bounded=(map,key,value,limit)=>{if(map.size>=limit)map.delete(map.keys().next().value);map.set(key,value);return value;};
export const SCAN_WALL_LIMITS=Object.freeze({routes:256,visits:256,beams:2048,stations:9,inspection:16,probes:64,visibility:1024});
/** Sight refreshes arrive every frame while any vision source animates. A
 * plain refresh re-checks cached points at most this often (frame time). */
export const SCAN_VISIBILITY_RECHECK_MS=200,SCAN_FAILED_RETRY_MS=250;
/** Short, user-facing reasons a bit is waiting, by guard code. */
export const SCAN_WALL_REASONS=Object.freeze({sight:'can’t see the whole square',route:'no clear path',footprint:'square too complex',unavailable:'wall checks unavailable',invalid:'invalid scan geometry',moving:'creature moving'});

/** Close instruments travel around the visible portrait as well as native
 * movement walls. This local convex rectangle is supplied by the same public
 * portrait geometry used for the scan mask; it contains no hidden scene data.
 * Euclidean clearance retains rounded-corner stations that a larger square
 * bounding box would incorrectly refuse. */
function portraitObstacle(polygon,clearance=0){
  if(!Array.isArray(polygon)||polygon.length!==4||!polygon.every(finitePoint))return null;
  const center={x:polygon.reduce((n,p)=>n+p.x,0)/4,y:polygon.reduce((n,p)=>n+p.y,0)/4};
  const width=distance(polygon[0],polygon[1]),height=distance(polygon[0],polygon[3]);if(width<.001||height<.001)return null;
  const u={x:(polygon[1].x-polygon[0].x)/width,y:(polygon[1].y-polygon[0].y)/width},v={x:(polygon[3].x-polygon[0].x)/height,y:(polygon[3].y-polygon[0].y)/height};
  if(Math.abs(u.x*v.x+u.y*v.y)>.001)return null;
  const local=p=>({x:(p.x-center.x)*u.x+(p.y-center.y)*u.y,y:(p.x-center.x)*v.x+(p.y-center.y)*v.y}),hx=width/2,hy=height/2,pad=Math.max(.5,Math.min(1000,Number(clearance)||0));
  const pointDistance=p=>{const q=local(p);return Math.hypot(Math.max(0,Math.abs(q.x)-hx),Math.max(0,Math.abs(q.y)-hy));};
  const pointSegment=(p,a,b)=>{const dx=b.x-a.x,dy=b.y-a.y,t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1)));return Math.hypot(p.x-a.x-dx*t,p.y-a.y-dy*t);};
  const segmentDistance=(a,b)=>{
    const p=local(a),q=local(b);let low=0,high=1;
    for(const [start,end,half]of [[p.x,q.x,hx],[p.y,q.y,hy]]){
      const d=end-start;
      if(Math.abs(d)<1e-10){if(Math.abs(start)>half){low=1;high=0;break;}}
      else {const x=(-half-start)/d,y=(half-start)/d;low=Math.max(low,Math.min(x,y));high=Math.min(high,Math.max(x,y));}
    }
    if(low<=high&&high>=0&&low<=1)return 0;
    let minimum=Math.min(pointDistance(a),pointDistance(b));
    for(const corner of polygon)minimum=Math.min(minimum,pointSegment(corner,a,b));
    return minimum;
  };
  const permits=(a,b,departure=null)=>{
    if(segmentDistance(a,b)>=pad-1e-6)return true;
    if(!departure||distance(a,departure)>.001||pointDistance(b)<pad-1e-6)return false;
    const p=local(a),q=local(b),nx=p.x-Math.max(-hx,Math.min(hx,p.x)),ny=p.y-Math.max(-hy,Math.min(hy,p.y));
    // A bit may emerge from Ellie's own portrait. An already exterior bit
    // must head outward immediately, rather than crossing it on the way out.
    return !nx&&!ny||nx*(q.x-p.x)+ny*(q.y-p.y)>=-1e-7;
  };
  const waypoints=polygon.map(p=>{const q=local(p),x=Math.sign(q.x)*(hx+pad+.5),y=Math.sign(q.y)*(hy+pad+.5);return {x:center.x+u.x*x+v.x*y,y:center.y+u.y*x+v.y*y};});
  return {permits,pointDistance,waypoints,pad};
}

/** Wall hooks invalidate by scene, not per rendered token or sight refresh.
 * An out-of-view scene edit cannot invalidate the active scene's work. */
export function invalidateScanWalls(document,canvas=globalThis.canvas){
  if(!canvas||typeof canvas!=='object')return;
  const scene=document?.documentName==='Scene'?document:document?.parent;
  if(scene?.id&&canvas.scene?.id&&scene.id!==canvas.scene.id)return;
  revisions.set(canvas,(revisions.get(canvas)??0)+1);contexts.delete(canvas);rosters.delete(canvas);
}

/** Drop one deleted source without evicting any other user's checked work.
 * Weak ownership also releases a source when its native document is collected. */
export function releaseScanWallSource(source,canvas=globalThis.canvas){
  const doc=source?.document??source?.object?.document??source;
  if(doc&&typeof doc==='object')contexts.get(canvas)?.delete(doc);
}

/** Vision and lighting refreshes invalidate only exact point visibility. They
 * must not discard checked wall routes while the source walks. */
export function invalidateScanWallVisibility(canvas=globalThis.canvas){
  if(canvas&&typeof canvas==='object')visibilityRevisions.set(canvas,(visibilityRevisions.get(canvas)??0)+1);
}

function wallEntry(wall,level){
  const doc=wall?.document??wall;
  // Keep even open doors. Native backends, not duplicate door logic, decide
  // whether each channel actually blocks.
  if(!doc||!(doc.move>0||doc.sight>0))return null;
  const c=wall.coords??doc.c;
  if(!Array.isArray(c)||c.length!==4||!c.every(Number.isFinite))return null;
  if(level?.id&&doc.levels?.size>0&&typeof doc.levels.has==='function'&&!doc.levels.has(level.id))return null;
  const a={x:c[0],y:c[1]},b={x:c[2],y:c[3]};
  return {a,b,sight:doc.sight>0,bounds:{x:Math.min(a.x,b.x),y:Math.min(a.y,b.y),width:Math.abs(a.x-b.x),height:Math.abs(a.y-b.y)}};
}
const overlaps=(a,b)=>a.x<=b.x+b.width&&a.x+a.width>=b.x&&a.y<=b.y+b.height&&a.y+a.height>=b.y;
/** Revision-owned roster: an uncapped count of walls that block movement or
 * sight, and a per-cell lookup (native quadtree, else a bounds-filtered walk).
 * Native testCollision needs no roster; only interior sight probes use it. */
function wallRoster(canvas){
  const walls=canvas.walls?.placeables??canvas.scene?.walls?.contents??[],level=canvas.level,entries=new WeakMap();let count=0;
  for(const wall of walls){const entry=wallEntry(wall,level);if(!entry)continue;count++;if(wall&&typeof wall==='object')entries.set(wall,entry);}
  const near=b=>{
    const out=[];
    for(const wall of sceneWallsNear(canvas,b)){
      let entry=wall&&typeof wall==='object'?entries.get(wall):undefined;
      if(entry===undefined){entry=wallEntry(wall,level);if(wall&&typeof wall==='object')entries.set(wall,entry);}
      if(entry&&overlaps(entry.bounds,b))out.push(entry);
    }
    return out;
  };
  return {count,near};
}
function wallInteriorProbes(wall,polygon){
  // A dangling wall may sit wholly inside a cell while all corner rays miss
  // it. Find its actual portion inside this polygon and query both sides using
  // the native sight backend. Coordinates are never returned to the renderer.
  const ts=[0,1],a=wall.a,b=wall.b,dx=b.x-a.x,dy=b.y-a.y;
  for(let i=0;i<polygon.length;i++){
    const c=polygon[i],d=polygon[(i+1)%polygon.length],ex=d.x-c.x,ey=d.y-c.y,den=dx*ey-dy*ex;
    if(Math.abs(den)<1e-9)continue;
    const t=((c.x-a.x)*ey-(c.y-a.y)*ex)/den,u=((c.x-a.x)*dy-(c.y-a.y)*dx)/den;
    if(t>0&&t<1&&u>=0&&u<=1)ts.push(t);
  }
  ts.sort((x,y)=>x-y);const probes=[],length=Math.hypot(dx,dy)||1;
  for(let i=1;i<ts.length;i++){
    const t=(ts[i-1]+ts[i])/2,p={x:a.x+dx*t,y:a.y+dy*t};if(!scanPointInPolygon(p,polygon))continue;
    for(const side of [-1,1]){const q={x:p.x-dy/length*.05*side,y:p.y+dx/length*.05*side};if(scanPointInPolygon(q,polygon))probes.push(q);}
  }
  return probes;
}
function cellTargets(cell,focus,probes,roster){
  const polygons=cell?.cells?.length?cell.cells.map(c=>c.polygon).filter(p=>p?.length>=3):cell?.polygon?.length>=3?[cell.polygon]:[];
  const targets=[focus,...probes].filter(finitePoint).map(copy);
  for(const polygon of polygons){
    const bounds=scanPolygonBounds(polygon),center=finitePoint(cell?.center)?cell.center:{x:bounds.x+bounds.width/2,y:bounds.y+bounds.height/2};
    for(let i=0;i<polygon.length;i++){
      const p=polygon[i],q=polygon[(i+1)%polygon.length];
      // Native cells adjoining a wall may finish at its boundary. A tiny
      // inward inset avoids treating that shared boundary as unseen interior.
      targets.push({x:p.x+(center.x-p.x)*1e-7,y:p.y+(center.y-p.y)*1e-7});
      targets.push({x:(p.x+q.x)/2+(center.x-(p.x+q.x)/2)*1e-7,y:(p.y+q.y)/2+(center.y-(p.y+q.y)/2)*1e-7});
    }
    for(const wall of roster.near(bounds))if(wall.sight)targets.push(...wallInteriorProbes(wall,polygon));
  }
  // Corrupt inputs cannot turn one work pass into an unbounded query. Refuse
  // rather than silently discard part of a supplied optical footprint.
  return targets.length>SCAN_WALL_LIMITS.probes?null:targets;
}

/** Return null for disabled/wall-free scenes; otherwise a revision-owned
 * guard. Its visit/route calls belong in itinerary compilation. currentWork()
 * reuses a full footprint until vision refreshes and checks moving body points
 * exactly. Public visible()/beam() calls retain immediate query semantics. */
export function sceneScanWallContext({source,canvas=globalThis.canvas,user=globalThis.game?.user,enabled=true,
  moveBackend=globalThis.CONFIG?.Canvas?.polygonBackends?.move??globalThis.foundry?.canvas?.geometry?.ClockwiseSweepPolygon,
  sightBackend=globalThis.CONFIG?.Canvas?.polygonBackends?.sight??globalThis.foundry?.canvas?.geometry?.ClockwiseSweepPolygon}={}){
  if(enabled===false||!canvas||typeof canvas!=='object'||!canvas.ready)return null;
  const doc=source?.document??source?.object?.document??source??{},token=source?.object??source;
  const geometryStamp=`${canvas.scene?.id??''}:${canvas.level?.id??''}:${revisions.get(canvas)??0}`;
  const stamp=`${geometryStamp}:${doc.id??token?.id??''}:${doc.elevation??0}:${user?.id??''}:${!!user?.isGM}:${doc.parent?.id??''}`;
  const wallObjects=canvas.walls?.placeables??canvas.scene?.walls?.contents;
  let shared=rosters.get(canvas);
  if(!shared||shared.stamp!==geometryStamp||shared.scene!==canvas.scene||shared.objects!==wallObjects){
    // Immutable scene/level geometry is shared. Authority, routes and point
    // visibility below remain owned by one native source and viewer context.
    shared={stamp:geometryStamp,scene:canvas.scene,objects:wallObjects,roster:wallRoster(canvas)};rosters.set(canvas,shared);contexts.delete(canvas);
  }
  let owners=contexts.get(canvas);if(!owners)contexts.set(canvas,owners=new WeakMap());
  // Native documents/tokens are stable weak owners. Deleting a source releases
  // its contexts without an ever-growing scene-wide list or a cyclic FIFO cliff.
  const owner=doc&&typeof doc==='object'?doc:token;
  let cache=owners.get(owner);if(!cache)owners.set(owner,cache=new Map());
  const cached=cache.get(stamp);if(cached&&cached.move===moveBackend&&cached.sight===sightBackend)return cached.value;
  const roster=shared.roster;
  if(!roster.count){bounded(cache,stamp,{move:moveBackend,sight:sightBackend,value:null},8);return null;}
  const routeCache=new Map(),visitCache=new Map(),beamCache=new Map(),visibilityCache=new Map(),workVisibility=new WeakMap();let routes=0,sightChecks=0,workChecks=0,routeMoveChecks=0,visibilityChecks=0,visibilityHits=0,viewRevision=-1,viewGeneration=0,viewObject,viewTest,viewBounds,frameNow=NaN,viewAt=-Infinity;
  const elevation=Number.isFinite(doc.elevation)?doc.elevation:0,level=canvas.level;
  const elevated=p=>({x:p.x,y:p.y,elevation});
  let adapter=null;
  try{adapter=sceneBitRouteAdapter({source,canvas,user,backend:moveBackend});}catch{/* Unavailable native movement fails closed. */}
  const sceneMatches=!doc.parent?.id||!canvas.scene?.id||doc.parent.id===canvas.scene.id;
  // Native collision backends take any wall count; availability never depends
  // on how many wall placeables a scene has.
  const available=!!adapter&&typeof sightBackend?.testCollision==='function'&&sceneMatches;
  const visible=p=>{
    if(!finitePoint(p)||!sceneMatches)return false;
    if(canvas.dimensions?.sceneRect?.contains&&canvas.dimensions.sceneRect.contains(p.x,p.y)!==true)return false;
    if(user?.isGM)return true;
    try{visibilityChecks++;return canvas.visibility?.testVisibility?.(elevated(p),{tolerance:0,object:null})===true;}catch{return false;}
  };
  const visibilityEpoch=()=>{
    const revision=visibilityRevisions.get(canvas)??0,object=canvas.visibility,test=object?.testVisibility,bounds=canvas.dimensions?.sceneRect;
    if(viewRevision!==revision||viewObject!==object||viewTest!==test||viewBounds!==bounds){
      // A plain sight refresh re-checks at most once per SCAN_VISIBILITY_RECHECK_MS
      // of guarded frame time. A replaced visibility object, test or scene
      // rectangle, a first epoch, an unclocked caller or a clock that went
      // backwards (a local rehearsal sharing this context) applies immediately.
      const refreshOnly=viewGeneration>0&&viewObject===object&&viewTest===test&&viewBounds===bounds;
      if(!refreshOnly||!Number.isFinite(frameNow)||frameNow<viewAt||frameNow-viewAt>=SCAN_VISIBILITY_RECHECK_MS){
        visibilityCache.clear();viewRevision=revision;viewObject=object;viewTest=test;viewBounds=bounds;viewGeneration++;viewAt=Number.isFinite(frameNow)?frameNow:-Infinity;
      }
    }
    return viewGeneration;
  };
  // Moving body points are keyed to whole pixels; fixed footprint targets keep
  // their exact keys (they repeat exactly every frame of a visit).
  const cachedVisible=(p,rounded=false)=>{
    visibilityEpoch();
    if(!finitePoint(p)||!sceneMatches)return false;
    if(viewBounds?.contains&&viewBounds.contains(p.x,p.y)!==true)return false;
    const key=rounded?`~${Math.round(p.x)},${Math.round(p.y)}`:keyPoint(p);
    if(visibilityCache.has(key)){visibilityHits++;return visibilityCache.get(key);}
    return bounded(visibilityCache,key,visible(p),SCAN_WALL_LIMITS.visibility);
  };
  const sightClear=(from,to)=>{
    const key=`${keyPoint(from)}>${keyPoint(to)}`;
    if(beamCache.has(key))return beamCache.get(key);
    sightChecks++;let clear=false;
    try{clear=sightBackend.testCollision(elevated(from),elevated(to),{type:'sight',mode:'any',tMax:1-1e-8,...(level?{level}:{})})===false;}catch{/* Fail closed. */}
    return bounded(beamCache,key,clear,SCAN_WALL_LIMITS.beams);
  };
  const beam=(from,to)=>available&&visible(from)&&visible(to)&&sightClear(from,to);
  const route=(from,to,{approach=[],portraitPolygon,portraitClearance}={})=>{
    if(!available||!finitePoint(from)||!finitePoint(to)||!visible(from)||!visible(to))return null;
    const authored=Array.isArray(approach)&&approach.length<=SCAN_WALL_LIMITS.inspection&&approach.every(finitePoint)?approach:[],obstacle=portraitObstacle(portraitPolygon,portraitClearance);
    if(portraitPolygon&&!obstacle)return null;
    const key=`${keyPoint(from)}>${keyPoint(to)}:${obstacle?JSON.stringify([portraitPolygon,obstacle.pad,authored]):''}`,epoch=visibilityEpoch(),cached=routeCache.get(key);
    // Intermediate visibility can refuse an otherwise reachable corridor.
    // Retry only that negative result after sight changes; a positive checked
    // path remains geometry-owned and currentWork still gates live exposure.
    if(cached&&(cached.value||cached.visibilityRevision===epoch))return cached.value;routes++;
    // The existing adapter retains candidate corners for one submitted route.
    // Give each new route its own adapter so a later cell never inherits an
    // unrelated first route's bounded candidate list.
    const planner=sceneBitRouteAdapter({source,canvas,user,backend:moveBackend});
    const departure=obstacle&&obstacle.pointDistance(from)<obstacle.pad?from:null;
    const blocked=(a,b)=>planner.blocked(a,b)!==false||!!(obstacle&&!obstacle.permits(a,b,departure));
    let planned;
    // Keep the authored exterior route when its real departure still meets
    // the saved start. Every segment and any short connector is independently
    // checked against native walls and the visible portrait's clearance.
    if(authored.length>1&&distance(authored.at(-1),to)<.01&&distance(from,authored[0])<=Math.max(3,(obstacle?.pad??12)*.75)){
      const points=[from,...authored.filter((p,i)=>i||distance(p,from)>.001)];
      const clear=(a,b)=>{
        if(blocked(a,b)!==false)return false;
        for(let n=1;n<7;n++)if(!visible({x:a.x+(b.x-a.x)*n/7,y:a.y+(b.y-a.y)*n/7}))return false;
        return true;
      };
      if(points.every((p,i)=>visible(p)&&(!i||clear(points[i-1],p))))planned={points,blocked:false};
    }
    planned??=planBitRoute(from,to,{blocked,visible,maxCandidates:0,maxChecks:1});
    if(planned.blocked)planned=planBitRoute(from,to,{blocked,visible,waypoints:[...(obstacle?.waypoints??[]),...planner.collectWaypoints(from,to)],maxCandidates:18,maxChecks:160,maxDetour:3});
    const result=planned.blocked?null:{...compileBitRoute(planned.points,{blocked,visible,rounding:planner.clearance}),sceneId:canvas.scene?.id??null};
    routeMoveChecks+=planner.nativeChecks;
    bounded(routeCache,key,{value:result,visibilityRevision:epoch},SCAN_WALL_LIMITS.routes);return result;
  };
  const visit=({from,to,focus,cell,probes=[],inspection=[],approach=[],portraitPolygon,portraitClearance,allowAlternates=true}={})=>{
    if(!finitePoint(from)||!finitePoint(to)||!finitePoint(focus))return {available:false,reason:'Invalid scan work geometry.',code:'invalid'};
    const obstacle=portraitObstacle(portraitPolygon,portraitClearance);
    if(portraitPolygon&&!obstacle)return {available:false,reason:'Invalid portrait route geometry.',code:'invalid'};
    approach=Array.isArray(approach)&&approach.length<=SCAN_WALL_LIMITS.inspection&&approach.every(finitePoint)?approach:[];
    const polygons=cell?.cells?.length?cell.cells.map(c=>c.polygon):[cell?.polygon];
    const key=JSON.stringify([keyPoint(from),keyPoint(to),keyPoint(focus),cell?.id,polygons,probes,inspection,approach,portraitPolygon,portraitClearance,allowAlternates]);
    visibilityEpoch();
    // A failed visit may become reachable when the viewer gains sight. Safe
    // geometry survives a view refresh; failed view-dependent work is retried
    // after a (coalesced) sight change.
    const prior=visitCache.get(key);
    if(prior&&(prior.available||prior.visibilityRevision===viewGeneration))return prior;
    workChecks++;
    const fail=(reason,code)=>bounded(visitCache,key,{available:false,reason,code,station:copy(from),route:null,inspectionSafe:false,visibilityRevision:viewGeneration},SCAN_WALL_LIMITS.visits);
    if(!available)return fail('Native wall checks are unavailable.','unavailable');
    const targets=cellTargets(cell,focus,probes,roster);if(!targets)return fail('The scan footprint needs too many optical checks.','footprint');
    // One visit asks the same body points repeatedly (stations, inspection
    // vertices and their rounded bends). Answer each exact point once.
    const opticalSeen=new Map();
    const optical=p=>{const k=keyPoint(p);let shown=opticalSeen.get(k);if(shown===undefined){shown=cachedVisible(p)&&targets.every(target=>cachedVisible(target)&&sightClear(p,target));opticalSeen.set(k,shown);}return shown;};
    const candidates=[to];
    if(allowAlternates&&cell?.polygon?.length>=3){
      const bounds=cell.bounds??scanPolygonBounds(cell.polygon),center=cell.center??focus;
      for(const [x,y]of [[0,0],[-.2,0],[.2,0],[0,-.2],[0,.2],[-.16,-.16],[.16,-.16],[-.16,.16]]){
        const p={x:center.x+bounds.width*x,y:center.y+bounds.height*y};if(scanPointInPolygon(p,cell.polygon))candidates.push(p);
      }
    }
    let station,path,seen=false;
    for(const candidate of candidates.slice(0,SCAN_WALL_LIMITS.stations)){
      if(!optical(candidate))continue;seen=true;const planned=route(from,candidate,{approach,portraitPolygon,portraitClearance});if(!planned)continue;station=candidate;path=planned;break;
    }
    if(!station)return fail(seen?'No clear route reaches a station that can see the complete scan footprint.':'No reachable station can see the complete scan footprint.',seen?'route':'sight');
    const body=inspection.filter(finitePoint),same=distance(station,to)<1e-7;
    const inspectionBlocked=(a,b)=>adapter.blocked(a,b)!==false||!!(obstacle&&!obstacle.permits(a,b));
    const inspectionSafe=same&&body.length===inspection.length&&body.length<=SCAN_WALL_LIMITS.inspection&&body.every((p,i)=>optical(p)&&inspectionBlocked(i?body[i-1]:station,p)===false);
    // A long inspection circuit must not brake at every polygon vertex.
    // Compile rounded bends here, once, through the same native movement
    // checks. Every vertex above already passed the complete-footprint sight
    // test; a bend lies within 18% of its shorter leg of that vertex, so it
    // needs viewer visibility only (live exposure still gates each position).
    const inspectionRoute=inspectionSafe&&body.length>1?compileBitRoute(body,{blocked:inspectionBlocked,visible:p=>cachedVisible(p),rounding:12}):null;
    const result={available:true,station:copy(station),route:path,inspectionSafe,inspectionRoute,reason:null,code:null};
    workVisibility.set(result,{targets,station,revision:-1,shown:false});
    return bounded(visitCache,key,result,SCAN_WALL_LIMITS.visits);
  };
  const currentWork=(checked,position)=>{
    const epoch=visibilityEpoch(),work=workVisibility.get(checked);
    if(!work)return false;
    if(work.revision!==epoch){work.shown=cachedVisible(work.station)&&work.targets.every(target=>cachedVisible(target));work.revision=epoch;}
    return work.shown&&cachedVisible(position,true);
  };
  // guardScanSample supplies its frame clock so sight refreshes coalesce in
  // frame time. Public callers that never set it keep immediate semantics.
  const clock=now=>{if(Number.isFinite(now))frameNow=now;};
  const context={revision:stamp,available,visible,beam,route,visit,currentWork,clock,get visibilityRevision(){return visibilityEpoch();},get stats(){return {routes,sightChecks,workChecks,visibilityChecks,visibilityHits,visibilityRevision:visibilityEpoch(),nativeMoveChecks:(adapter?.nativeChecks??0)+routeMoveChecks,routeCache:routeCache.size,visitCache:visitCache.size,beamCache:beamCache.size,visibilityCache:visibilityCache.size};}};
  bounded(cache,stamp,{move:moveBackend,sight:sightBackend,value:context},8);return context;
}

const unit=n=>Math.max(0,Math.min(1,Number(n)||0));
const ease=n=>{n=unit(n);return n*n*(3-2*n);};
const turn=(a,b,q)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*q;
const boundsOf=points=>points.length?scanPolygonBounds(points):{x:0,y:0,width:0,height:0};
const bodyPolygons=cell=>cell?.cells?.length?cell.cells.map(c=>c.polygon).filter(p=>p?.length>=3):cell?.polygon?.length>=3?[cell.polygon]:[];
const movingPhases=new Set(['travel','moving','rejoining','relocating','resettling']);
// A tiny, explicitly checked geometric envelope absorbs ordinary visual sway.
// Checking current vertices against it is arithmetic only; it never queries a
// native wall backend. Larger motion closes optics until a settled recapture.
function expandFootprint(polygon,pad){
  const area=polygon.reduce((n,p,i)=>{const q=polygon[(i+1)%polygon.length];return n+p.x*q.y-q.x*p.y;},0),sign=Math.sign(area)||1;
  return polygon.map((p,i)=>{
    const a=polygon[(i+polygon.length-1)%polygon.length],b=polygon[(i+1)%polygon.length],la=distance(a,p)||1,lb=distance(p,b)||1;
    const n={x:sign*(p.y-a.y)/la,y:-sign*(p.x-a.x)/la},m={x:sign*(b.y-p.y)/lb,y:-sign*(b.x-p.x)/lb},den=1+n.x*m.x+n.y*m.y;
    return den>1e-6?{x:p.x+pad*(n.x+m.x)/den,y:p.y+pad*(n.y+m.y)/den}:copy(p);
  });
}
function footprintContained(polygons,envelopes){
  return polygons.length===envelopes?.length&&polygons.every((polygon,i)=>polygon.every(point=>scanPointInPolygon(point,envelopes[i])));
}
function footprintMoved(a,b,tolerance=.1){
  return !a||a.length!==b.length||a.some((polygon,i)=>polygon.length!==b[i]?.length||polygon.some((point,j)=>distance(point,b[i][j])>tolerance));
}
function footprintCell(cell,polygons){
  if(!cell||!polygons.length)return cell;
  return {...cell,polygon:polygons[0],bounds:boundsOf(polygons.flat()),...(cell.cells?.length?{cells:cell.cells.map((c,i)=>({...c,polygon:polygons[i],bounds:boundsOf(polygons[i])}))}:{})};
}

function pursuitBends(route,size){
  const bends=[];
  for(let i=1;i<(route?.points?.length??0)-1;i++){
    const a=route.points[i-1],b=route.points[i],c=route.points[i+1],ab=distance(a,b),bc=distance(b,c),cos=((b.x-a.x)*(c.x-b.x)+(b.y-a.y)*(c.y-b.y))/(ab*bc||1);
    if(cos>.99999)continue;
    const hard=route.corners?.includes(i),radius=Math.min(ab,bc)/(2*Math.sqrt(Math.max(1e-8,(1-Math.max(-1,Math.min(1,cos)))/2)));
    bends.push({at:route.lengths[i],speed:hard?0:Math.sqrt(Math.max(1,size)*18*radius)});
  }
  return bends;
}
function pursuitRoutePoint(route,traversed){
  let lo=1,hi=route.points.length-1;
  while(lo<hi){const mid=(lo+hi)>>1;if(route.lengths[mid]<traversed)lo=mid+1;else hi=mid;}
  const a=route.points[lo-1],b=route.points[lo],span=route.lengths[lo]-route.lengths[lo-1],q=unit(span?(traversed-route.lengths[lo-1])/span:1);
  return {x:a.x+(b.x-a.x)*q,y:a.y+(b.y-a.y)*q,heading:Math.atan2(b.y-a.y,b.x-a.x)};
}
function worldFrame(sample,context){
  const center=sample.effectCenter??context.target??context.source??{x:0,y:0},scale=(context.size??100)*(sample.effectScale??1)/100,angle=sample.effectRotation??0,c=Math.cos(angle),s=Math.sin(angle);
  return {world:p=>({x:center.x+(p.x*c-p.y*s)*scale,y:center.y+(p.x*s+p.y*c)*scale}),local:p=>({x:((p.x-center.x)*c+(p.y-center.y)*s)/scale,y:(-(p.x-center.x)*s+(p.y-center.y)*c)/scale})};
}
function rememberedWork(record){
  return {key:record.key,visit:record.visit,cells:record.cells,min:record.min,max:record.max,valid:record.valid};
}
/** A held instrument stays closed: 'wallWaiting' when it cannot work, else
 * 'moving'. Keep the authored closed transfer pose instead of falling back to
 * idle-clock spin. An interrupted open phase stays mechanically closed until
 * the checked route and optical footprint are available again. */
function closeInstrument(sample,id,waiting,progress){
  sample.phases[id]={...(sample.phases[id]??{}),phase:waiting?'wallWaiting':'moving',progress:waiting?0:progress};
  const examination=sample.coreStates?.[id]?.examination;
  sample.coreStates??={};sample.coreStates[id]={state:waiting?'settling':'encased',amount:waiting?.15:.3,progress:0,
    ...(examination?{examination:!waiting&&['acquire','turn'].includes(examination.phase)?{...examination}:{...examination,phase:'acquire',progress:0}}:{})};
  if(sample.tools)delete sample.tools[id];if(sample.glows?.[id])sample.glows[id]={...sample.glows[id],strength:waiting?.3:.4};
}
function completionSeen(completion,records){
  const cells=completion.gridCellIds??[completion.gridCellId??completion.id];
  return records.some(r=>r.valid&&r.min<=.2&&r.max>=.78&&String(r.visit)===String(completion.visitIndex)&&cells.every(id=>r.cells.includes(id)));
}

/** Render-local controller, called before encounters consume completedCells.
 * Choreography supplies scanWallWork: static world stations/full native cells,
 * a bounded inspection polyline, and the existing approach/exposure progress.
 * Cached checked targets stay fixed for a native-cell visit as Ellie moves;
 * frame sampling interpolates these saved paths without any collision query.
 * Pass previous state from the same event. The function never mutates it, so
 * read-only command captures can safely inspect the current physical result. */
export function guardScanSample(sample,event,context,now,previous,{readOnly=false}={}){
  const walls=context.scanWalls,work=sample.scanWallWork??{},ids=Object.keys(sample.positions??{}),state={now,records:{},history:{},positions:{},headings:{},speeds:{},velocities:{},teleportAt:previous?.teleportAt};
  if(sample.state?.phase==='paused'){
    // Pausing an attended child captures its actual physical pose, which can
    // differ from the parent's last area station. Keep that command capture
    // exactly; a later resume plans afresh from it instead of snapping back.
    sample.effects=[];sample.completedCells={};sample.focuses=[];sample.encounterSurfaces=[];sample.scanWorking=0;sample.scanComplete=false;
    for(const id of ids){state.positions[id]=copy(sample.positions[id]);state.headings[id]=(sample.rotations?.[id]??0)+(context.transform?.angle??0)+(context.orientations?.[id]??0);state.history[id]=[...(previous?.history?.[id]??[])];state.speeds[id]=0;state.velocities[id]={x:0,y:0};}
    return {sample,state};
  }
  if(!walls||event.status==='returning'||event.utility?.mode==='parkLight'){
    state.positions=Object.fromEntries(ids.map(id=>[id,copy(sample.positions[id])]));return {sample,state};
  }
  walls.clock?.(now);
  const allowed=new Set(),pending=[],held=new Set(),reasons={},refused=[];let solved=0;
  for(const [index,id]of ids.entries()){
    const desired=sample.positions[id],old=previous?.records?.[id],history=[...(previous?.history?.[id]??[])];let input=work[id];
    if(!input){
      // Unknown geometry (including a withdrawn or paused duty) cannot acquire
      // a new optical surface. Preserve the last actual body without solving.
      const position=previous?.positions?.[id]??desired;sample.positions[id]=copy(position);state.positions[id]=copy(position);state.history[id]=history;held.add(id);continue;
    }
    const locomotion=sample.scanRelocating&&context.scanLocomotion;
    // Begin the checked return to work as soon as the owner stops hurrying.
    // The remaining closed-shell fade overlaps that approach, rather than
    // holding a checkpoint for its full decay then adding a second journey.
    const rapid=locomotion&&(locomotion.teleported||now-locomotion.lastRapid<220)?locomotion:null,teleported=rapid?.teleported&&previous?.teleportAt!==now;
    if(rapid){
      // During a hurry the instruments close and follow nearby checkpoints,
      // not an ever-receding examination station. Capture one destination per
      // spatial owner cell; fractional movement never invokes a solver.
      const size=Math.max(1,context.size??100),source=rapid.source??context.source,direction=rapid.direction??0,c=Math.cos(direction),s=Math.sin(direction),lateral=(index-(ids.length-1)/2)*size*.24,back=size*(.3+(index%2)*.13);
      const followingStation={x:source.x-c*back-s*lateral,y:source.y-s*back+c*lateral};
      // Check one forward route per owner cell. The body follows only the
      // checked prefix up to its moving owner-relative station, avoiding the
      // old stop at every stationary checkpoint without per-frame solving.
      const station={x:followingStation.x+c*size*2.25,y:followingStation.y+s*size*2.25};
      input={...input,key:`following:${Math.floor(source.x/size)}:${Math.floor(source.y/size)}:${Math.round(direction/(Math.PI/4))}`,station,focus:station,followingStation,followingDirection:direction,cell:null,inspection:[station],phase:'relocating',initialTravel:false};
      if(teleported)state.teleportAt=now;
    }
    const key=`${walls.revision}:${input.key}:${event.utilityReentries?.[id]?.at??''}`;
    let record=old?{...old,station:copy(old.station),focus:copy(old.focus),lastTarget:copy(old.lastTarget??old.focus)}:null;
    // A moving portrait is not an anchored work surface. Withdraw during its
    // motion and capture one new geometry after it has remained still, rather
    // than running a native route solver for each fractional token movement.
    const portrait=event.utility?.mode==='creatureScan',portraitKey=portrait?scanPortraitGeometryKey(context.targetScan?.portrait):null;
    const polygons=portrait?bodyPolygons(input.cell):[],geometryChanged=!!(record&&portrait&&(record.portraitKey!==portraitKey||(record.certifiedPolygons?!footprintContained(polygons,record.certifiedPolygons):footprintMoved(record.polygons,polygons))));
    let changing=false;
    if(record&&portrait&&distance(input.focus,record.lastTarget)>.1){record.lastTarget=copy(input.focus);record.changedAt=now;changing=true;}
    if(geometryChanged&&(record.lastPortraitKey!==portraitKey||footprintMoved(record.lastPolygons,polygons))){
      record.lastPortraitKey=portraitKey;record.lastPolygons=polygons.map(p=>p.map(copy));record.changedAt=now;changing=true;
    }
    if(record&&portrait&&now-(record.changedAt??-Infinity)<180)changing=true;
    const recapture=record&&portrait&&!changing&&(geometryChanged||distance(input.focus,record.focus)>.1);
    const previousVelocity=previous?.velocities?.[id]??{x:0,y:0},previousSpeed=previous?.speeds?.[id]??Math.hypot(previousVelocity.x,previousVelocity.y);
    const reversing=!!(rapid&&record?.rapid&&previousSpeed>(context.size??100)*.15&&Math.cos((record.followingDirection??rapid.direction)-rapid.direction)<.25);
    const stoppingDistance=previousSpeed*previousSpeed/(Math.max(1,context.size??100)*72)+previousSpeed*Math.max(0,Math.min(100,now-(previous?.now??now)))/1000;
    const shortReplacement=!!(!rapid&&record?.pursued&&record.key!==key&&previousSpeed>(context.size??100)*.15&&distance(previous?.positions?.[id]??record.station,input.station??desired)<stoppingDistance);
    if(shortReplacement)record.brakingForReplacement=true;
    const braking=reversing||!!(!rapid&&locomotion&&record?.rapid&&previousSpeed>(context.size??100)*.15)||!!(record?.brakingForReplacement&&previousSpeed>(context.size??100)*.15);
    // Brake on the existing verified route before taking an opposing route.
    // Reversing a scalar route speed in one frame would still snap velocity.
    // A refused visit is retried after a sight change, at most once per
    // SCAN_FAILED_RETRY_MS of frame time.
    const retry=!!record&&!record.available&&record.visibilityRevision!==walls.visibilityRevision&&!(now>=record.started&&now-record.started<SCAN_FAILED_RETRY_MS);
    const solve=(!record||record.key!==key||recapture||teleported||retry)&&(!braking||teleported);
    // At most one settled bit plans a new checked visit per guarded frame. A
    // cooperative team switching cells together spreads its solves over a few
    // frames; a waiting colleague stays closed in place (travelling, not
    // pending), so no cell is reported refused for that short wait.
    if(solve&&record&&!rapid&&solved>=1&&previousSpeed<=(context.size??100)*.15){
      const position=previous?.positions?.[id]??record.station,heading=previous?.headings?.[id];
      sample.positions[id]=copy(position);state.positions[id]=copy(position);state.records[id]=record;state.history[id]=history;state.velocities[id]={x:0,y:0};state.speeds[id]=0;
      if(Number.isFinite(heading))sample.rotations[id]=heading-(context.transform?.angle??0)-(context.orientations?.[id]??0);
      closeInstrument(sample,id,false,unit(input.progress));held.add(id);
      const completion=sample.completedCells?.[id];
      if(completion&&!completionSeen(completion,[...history,rememberedWork(record)]))delete sample.completedCells[id];
      continue;
    }
    if(solve){
      solved++;
      if(record){history.push(rememberedWork(record));if(history.length>16)history.shift();}
      // A client may first observe an already-running visit. Its template
      // `from` is an itinerary station, not proof the physical instrument ever
      // crossed a currently closed door. Start at the captured real departure.
      const from=teleported?copy(rapid.source??context.source):previous?.positions?.[id]??event.originsWorld?.[id]??context.origins?.[id]??input.from??desired;
      let certifiedPolygons=portrait&&portraitKey!==null?polygons.map(p=>expandFootprint(p,Math.max(.5,Math.min(3,(context.size??100)*.02)))):null;
      const request={from,to:input.station??desired,focus:input.focus??input.station??desired,cell:certifiedPolygons?footprintCell(input.cell,certifiedPolygons):input.cell,probes:input.probes??[],inspection:input.inspection??[],approach:input.approach??[],portraitPolygon:input.portraitPolygon,portraitClearance:input.portraitClearance,allowAlternates:!portrait};
      let checked=walls.visit(request);
      if(!checked.available&&certifiedPolygons?.length){
        // Slack is an optional cache allowance, never extra responsibility a
        // visible patient must satisfy. Near a wall the exact current frame
        // may still be safe. Certify only that frame; later sway escaping it
        // closes optics and follows the same settled recheck path.
        checked=walls.visit({...request,cell:input.cell});
        certifiedPolygons=checked.available?polygons.map(p=>p.map(copy)):null;
      }
      // Short sight must not strand visible instruments merely because the
      // longer anticipatory corridor ends beyond the viewer's vision.
      if(!checked.available&&rapid&&input.followingStation)for(const ahead of [1,0]){
        const p={x:input.followingStation.x+Math.cos(rapid.direction)*(context.size??100)*ahead,y:input.followingStation.y+Math.sin(rapid.direction)*(context.size??100)*ahead};
        checked=walls.visit({from,to:p,focus:p,cell:null,inspection:[p]});if(checked.available)break;
      }
      const phase=input.phase??sample.phases?.[id]?.phase,isMoving=movingPhases.has(phase)||input.initialTravel;
      const hasPrior=!!previous?.positions?.[id],progress=unit(input.routeProgress??input.progress);
      record={key,...(portrait?{portraitKey,lastPortraitKey:portraitKey,lastPolygons:polygons.map(p=>p.map(copy)),certifiedPolygons}:{}),visit:input.visitIndex??String(input.key??'').split(':')[1],cells:input.cell?.cells?.map(c=>c.id)??[input.cell?.id].filter(Boolean),
        available:checked.available,reason:checked.reason,code:checked.code??(checked.available?null:'sight'),attempt:String(input.key??''),checked,visibilityRevision:walls.visibilityRevision,station:copy(checked.station??from),focus:copy(input.focus??input.station??desired),lastTarget:copy(input.focus??input.station??desired),
        route:checked.route,inspectionSafe:checked.inspectionSafe,inspection:checked.inspectionRoute??(checked.inspectionSafe&&input.inspection?.length>1?compileBitRoute(input.inspection):null),
        polygons:bodyPolygons(input.cell).map(p=>p.map(copy)),started:now,duration:Math.max(260,Math.min(2200,350+(checked.route?.length??0)*2)),
        // A return can receive a fresh checked destination after its authored
        // animation clock has ended. That physical leg needs its elapsed route
        // clock; rebasing from progress 1 would hold (1-1)/(1-1) at zero forever.
        captureProgress:isMoving&&hasPrior?progress:0,clocked:isMoving&&!rapid&&progress<1-1e-7,pursued:!!locomotion,rapid:!!rapid,followingDirection:input.followingDirection,bends:pursuitBends(checked.route,context.size??100),traversed:0,min:Infinity,max:0,valid:true,hadPrior:hasPrior,
        fromHeading:previous?.headings?.[id]??(sample.rotations?.[id]??0)+(context.transform?.angle??0)+(context.orientations?.[id]??0)};
    }
    state.records[id]=record;state.history[id]=history;
    const phase=input.phase??sample.phases?.[id]?.phase,isMoving=movingPhases.has(phase)||input.initialTravel;
    let arrived=record.available&&!changing,position=record.station;
    if(record.available&&record.route){
      let q;
      if(record.pursued){
        const elapsed=Math.max(0,Math.min(100,now-(previous?.now??now))),direction=record.followingDirection??0;
        const remaining=record.rapid&&input.followingStation&&!braking?Math.max(0,record.route.length-((record.station.x-input.followingStation.x)*Math.cos(direction)+(record.station.y-input.followingStation.y)*Math.sin(direction))):record.route.length;
        const goal=Math.max(0,Math.min(record.route.length,remaining)),brake=(context.size??100)*36;
        let maxSpeed=Infinity,stop=record.route.length;
        for(const bend of record.bends??[])if(bend.at>record.traversed+.25){maxSpeed=Math.min(maxSpeed,Math.sqrt(bend.speed*bend.speed+2*brake*(bend.at-record.traversed)));if(!bend.speed){stop=bend.at;break;}}
        const speed=stepScanRouteSpeed(teleported?0:previousSpeed,{distance:goal-record.traversed,availableDistance:stop-record.traversed,sourceSpeed:rapid&&!braking?(context.scanLocomotion?.paceSpeed??0):0,dt:elapsed,size:context.size,maxSpeed,braking});
        record.traversed=Math.min(stop,record.traversed+speed.travel);
        if(stop-record.traversed<(context.size??100)*.001&&speed.speed<5){record.traversed=stop;speed.speed=0;}
        state.speeds[id]=speed.speed;q=unit(record.traversed/Math.max(.001,record.route.length));
      }else if(record.clocked&&isMoving)q=unit((unit(input.routeProgress??input.progress)-record.captureProgress)/(1-record.captureProgress||1));
      else if(record.clocked)q=1;
      else q=record.hadPrior?unit((now-record.started)/record.duration):1;
      const route=record.route;position=record.pursued?pursuitRoutePoint(route,record.traversed):sampleWeightedTransit(route.points[0],route.points.at(-1),q,{route,size:context.size,reduced:context.snapshot?.effective?.reducedMotion,enabled:context.snapshot?.v8Motion?.weightedTravel!==false});
      if(!arrived||q<1){
        const tangent=(position.heading??Math.atan2(record.station.y-position.y,record.station.x-position.x))+Math.PI/2,aim=Math.atan2(record.focus.y-record.station.y,record.focus.x-record.station.x)+Math.PI/2;
        // A tiny transfer can reverse its sampled tangent while moving only
        // a fraction of a pixel. Its examination bearing is meaningful; that
        // near-zero travel derivative is not a reason to flip the housing.
        const heading=route.length<(context.size??100)*.2?turn(record.fromHeading,aim,ease(q)):turn(turn(record.fromHeading,tangent,ease(q/.2)),aim,ease((q-.72)/.28));
        sample.rotations[id]=heading-(context.transform?.angle??0)-(context.orientations?.[id]??0);
      }
      arrived&&=q>=1-1e-7;
      if(arrived&&!rapid&&record.inspection&&!context.snapshot?.effective?.reducedMotion&&['scanning','closing','settling','complete'].includes(phase)){
        const route=record.inspection;
        if(record.pursued){
          // Work kept its shared clock during pursuit. Join the checked small
          // inspection path from its start instead of jumping to that clock's
          // already-advanced point the instant the approach arrives.
          const speed=stepScanRouteSpeed(record.inspectionSpeed??0,{distance:unit(input.inspectionProgress)*route.length-(record.inspectionTraversed??0),availableDistance:route.length-(record.inspectionTraversed??0),dt:Math.max(0,now-(previous?.now??now)),size:context.size,maxSpeed:(context.size??100)*.8,braking});
          record.inspectionTraversed=Math.min(route.length,(record.inspectionTraversed??0)+speed.travel);record.inspectionSpeed=speed.speed;
          position=pursuitRoutePoint(route,record.inspectionTraversed);state.speeds[id]=speed.speed;
        }else position=sampleWeightedTransit(route.points[0],route.points.at(-1),unit(input.inspectionProgress),{route,enabled:false,reduced:true});
      }
    }
    if(!record.available)position=previous?.positions?.[id]??record.station;
    // Withdraw optics at the actual inspection point. Returning to the saved
    // station here would visibly jump a body partway through its small circuit;
    // the settled recapture below will plan from this held physical departure.
    if(changing)position=previous?.positions?.[id]??position;
    sample.positions[id]=copy(position);state.positions[id]=copy(position);
    const elapsed=now-(previous?.now??now),priorPosition=previous?.positions?.[id];
    state.velocities[id]=priorPosition&&elapsed>0?{x:(position.x-priorPosition.x)*1000/elapsed,y:(position.y-priorPosition.y)*1000/elapsed}:previous?.velocities?.[id]??{x:0,y:0};
    state.speeds[id]??=Math.hypot(state.velocities[id].x,state.velocities[id].y);
    const shown=arrived&&record.key===key&&!sample.scanRelocating&&(walls.currentWork?walls.currentWork(record.checked,position):walls.visible(position)&&walls.visible(record.focus));
    if(shown&&!isMoving){allowed.add(id);if(phase==='scanning'){record.min=Math.min(record.min,unit(input.progress));record.max=Math.max(record.max,unit(input.progress));}}
    else{
      if(phase==='scanning')record.valid=false;
      const waiting=!record.available||changing||!shown&&arrived&&!sample.scanRelocating;
      closeInstrument(sample,id,waiting,unit(input.progress));
      held.add(id);
      if(waiting){
        pending.push(id);reasons[id]=changing?'moving':record.available?'sight':record.code??'sight';
        // Cells this visit could not see or reach, per attempt, so a single
        // survey can finish without cells this viewer can never cover.
        if(record.cells?.length&&!changing)refused.push({id,cells:[...record.cells],attempt:record.attempt??String(input.key??''),code:reasons[id]});
      }
    }
    const basis=(context.transform?.angle??0)+(context.orientations?.[id]??0),heading=Math.atan2(record.focus.y-position.y,record.focus.x-position.x)+Math.PI/2;
    if(!isMoving&&Number.isFinite(heading))sample.rotations[id]=heading-basis;
    const completion=sample.completedCells?.[id];
    if(completion&&!completionSeen(completion,[...history,rememberedWork(record)]))delete sample.completedCells[id];
  }
  // Keep the exact field contributed by each permitted actual instrument.
  // Team unions are rebuilt from those polygons, retaining seamless exteriors.
  sample.effects=(sample.effects??[]).flatMap(effect=>{
    if(effect.effect!=='v8-scan')return [effect];
    const channels=(effect.channels??[]).flatMap(channel=>{
      const frame=worldFrame({...sample,effectRotation:(sample.effectRotation??0)+(channel.frameRotation??0)},context);
      if(channel.sources?.length){
        const sources=channel.sources.filter(source=>allowed.has(source.id)).map(source=>{
          const record=state.records[source.id],point=frame.local(sample.positions[source.id]),polygons=record.polygons.map(p=>p.map(frame.local));
          return {...source,...point,focus:frame.local(record.focus),...(polygons.length?{regionPolygon:polygons[0],regionBounds:boundsOf(polygons.flat())}:{})};
        });
        if(!sources.length)return [];
        const polygons=sources.map(source=>source.regionPolygon).filter(p=>p?.length>=3),points=polygons.flat(),first=sources[0];
        for(const source of sources){
          const aim=scanArtworkAim({...channel,source:{x:source.x,y:source.y},focus:source.focus,sources:undefined,cooperative:false,regionPolygon:source.regionPolygon,regionPolygons:source.regionPolygon?[source.regionPolygon]:[],regionBounds:source.regionBounds}),target=frame.world(aim),position=sample.positions[source.id];
          sample.rotations[source.id]=Math.atan2(target.y-position.y,target.x-position.x)+Math.PI/2-(context.transform?.angle??0)-(context.orientations?.[source.id]??0);
        }
        return [{...channel,sources,source:{x:first.x,y:first.y},cellCount:sources.length,cooperative:sources.length>1,gridCellIds:sources.map(source=>source.gridCellId).filter(Boolean),...(polygons.length?{regionPolygon:polygons[0],regionPolygons:polygons,regionBounds:boundsOf(points)}:{})}];
      }
      if(!allowed.has(channel.id))return [];
      const next={...channel,source:frame.local(sample.positions[channel.id])},aim=scanArtworkAim(next),target=frame.world(aim),position=sample.positions[channel.id];
      sample.rotations[channel.id]=Math.atan2(target.y-position.y,target.x-position.x)+Math.PI/2-(context.transform?.angle??0)-(context.orientations?.[channel.id]??0);
      return [next];
    });
    return channels.length?[{...effect,channels}]:[];
  });
  sample.focuses=(sample.focuses??[]).filter(focus=>allowed.has(focus.station));
  sample.scanWallStatus={pending:[...pending],travelling:[...held].filter(id=>!pending.includes(id)),reasons,refused,reason:pending.length?reasons[pending[0]]:null};
  // The latest guarded status rides on the returned state, so a HUD can read
  // "2 bits waiting · can’t see the whole square" without sampling again.
  state.status={pending:[...pending],reason:sample.scanWallStatus.reason,refused};
  sample.scanWorking=ids.filter(id=>allowed.has(id)&&(work[id]?.phase??sample.phases?.[id]?.phase)==='scanning').length/Math.max(1,ids.length);
  if(held.size){sample.scanComplete=false;if(pending.length===ids.length)sample.state={phase:'wallWaiting',progress:0};}
  for(const id of ids)state.headings[id]=(sample.rotations?.[id]??0)+(context.transform?.angle??0)+(context.orientations?.[id]??0);
  return {sample,state};
}
