/** (13.0.2) Treat Wounds immunity is everyone's.
 *
 * A creature that has been treated with Treat Wounds cannot be treated again, by anyone, until its immunity ends. The
 * Medkit already refuses for Ellie; this is the same refusal for everybody else's Treat Wounds. When a player's Treat
 * Wounds check is about to be posted and the creature it is aimed at carries a Treat Wounds immunity (the Medkit's, the
 * system's, or one made by hand), the check is not posted and that player is told how long is left.
 *
 *   - It can only know the patient when one is targeted (the check's own target, or the roller's targeted token). With
 *     nothing targeted it has nothing to refuse, and does nothing.
 *   - The GM is never stopped, only told: the GM is the one who may decide otherwise (and can delete the effect).
 *   - The Medkit's own check is left alone (it has already refused, or is about to set the immunity itself).
 *   - A world setting turns it off: Treat Wounds immunity applies to everyone (Configure Settings › Yvaelle's Toolbox).
 *
 * Nothing here changes a sheet: it only declines to post a roll. */
import {ID} from './config.mjs?v=13.0.4';
import {treatWoundsImmunity,formatRemaining,medkitBusy} from './medkit-engine.mjs?v=13.0.4';

export const GUARD_SETTING='treatWoundsGuard';
const on=()=>{try{return game.settings.get(ID,GUARD_SETTING)!==false;}catch{return true;}};
/** Is this chat message a Treat Wounds check? (PF2e marks a check's roll options on the message.) */
export function isTreatWoundsCheck(message){
  const context=message?.flags?.pf2e?.context;if(!context)return false;
  const options=Array.isArray(context.options)?context.options:[];
  return options.includes('action:treat-wounds')||context.action==='treat-wounds'||(Array.isArray(context.domains)&&context.domains.includes('treat-wounds'));
}
/** The actors this check is aimed at: its own target if it has one, else the roller's targeted tokens. */
export function treatWoundsPatients(message,targets){
  const out=[],add=actor=>{if(actor&&!out.includes(actor))out.push(actor);};
  try{const t=message?.flags?.pf2e?.context?.target,ref=typeof t==='string'?t:t?.actor??null;if(typeof ref==='string'&&typeof fromUuidSync==='function')add(fromUuidSync(ref));}catch{}
  if(!out.length)try{for(const token of targets??[])add(token?.actor);}catch{}
  return out;
}
/** What the guard would say about this message: null to let it through, or {block, text}. Pure but for what it is given. */
export function treatWoundsVerdict(message,{targets=[],isGM=false,busy=false,enabled=true}={}){
  if(!enabled||busy||!isTreatWoundsCheck(message))return null;
  const immune=treatWoundsPatients(message,targets).map(actor=>({actor,effect:treatWoundsImmunity(actor)})).filter(entry=>entry.effect);
  if(!immune.length)return null;
  const names=immune.map(({actor,effect})=>{const left=Number(effect?.remainingDuration?.remaining);return `${actor.name} (${Number.isFinite(left)?formatRemaining(left)+' left':'still running'})`;}).join(', ');
  return isGM?{block:false,text:`Treat Wounds: ${names} already immune to Treat Wounds. As GM you are not stopped.`}
    :{block:true,text:`Treat Wounds was not rolled: ${names} already immune to Treat Wounds, whoever treats them.`};
}
let installed=false;
export function installTreatWoundsGuard(){
  if(installed)return;installed=true;
  Hooks.on('preCreateChatMessage',message=>{
    try{const verdict=treatWoundsVerdict(message,{targets:[...(game.user?.targets??[])],isGM:!!game.user?.isGM,busy:medkitBusy(),enabled:on()});
      if(!verdict)return;ui.notifications?.warn?.(verdict.text);if(verdict.block)return false;}
    catch(error){console.warn("Yvaelle's Toolbox | Treat Wounds guard",error);}
  });
}
Hooks.once('init',()=>{try{game.settings.register(ID,GUARD_SETTING,{name:'Treat Wounds immunity applies to everyone',
  hint:"A creature treated with Treat Wounds (by Ellie's Medkit or anyone) cannot be treated again until the immunity ends: another player's Treat Wounds check against a targeted, still-immune creature is not posted, and they are told how long is left. The GM is told, never stopped.",
  scope:'world',config:true,type:Boolean,default:true});}catch(error){console.warn("Yvaelle's Toolbox | Treat Wounds guard setting",error);}});
