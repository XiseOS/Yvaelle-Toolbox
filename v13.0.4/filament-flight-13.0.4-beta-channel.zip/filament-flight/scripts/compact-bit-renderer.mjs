import {localPerformance} from './performance.mjs?v=13.0.4';
import {v7SemanticGems} from './v7-artwork-identity.mjs?v=13.0.4';
import {BitRenderer,bitDetailForScale} from './bit-renderer.mjs?v=13.0.4';
import {bitAssets} from './bit-assets.mjs?v=13.0.4';
import {choreographedGems} from './gem-choreography.mjs?v=13.0.4';
import {isShown,isOnScreen} from './renderer.mjs?v=13.0.4';
import {sampleCompactCurrents,compactGeometryPlacement} from './compact-bit-formations.mjs?v=13.0.4';
import {CompactCurrents} from './compact-currents.mjs?v=13.0.4';
import {bitRestVisible} from './bit-collapse.mjs?v=13.0.4';
import {updateBitWaveDirection,retainBitWaveDirections,acquireBitWaveDirections,BIT_WAVE_STATIONS} from './bit-wave-direction.mjs?v=13.0.4';
import {compactSolidBounds,compactSolidOutline,compactDepthFront} from './compact-depth.mjs?v=13.0.4';
export {compactSolidBounds,compactDepthFront} from './compact-depth.mjs?v=13.0.4';
import {frozenLanternArtwork,lanternArtworkIdentity} from './runtime-activity.mjs?v=13.0.4';
import {BitPictureLease} from './bit-picture-lease.mjs?v=13.0.4';
import {veilAlphaOf} from './v11/invis-hooks.mjs?v=13.0.4';

const unit=n=>Math.max(0,Math.min(1,n));
const ease=n=>{n=unit(n);return n*n*(3-2*n);};
/** Handoff is a reversible function of wing presence, never a queued timeline.
 * Both routes meet hidden behind the token, avoiding overlapping copies. */
export function compactWingHandoff(snapshot,stateBlend=snapshot.bitWingBlend){
  const t=snapshot.transition,wanted=snapshot.bitsDeployed||snapshot.bitTransition?.active&&snapshot.bitDeployment>0;
  const explicit=!!(t?.active&&Math.abs((t.fromBlend??1)-(t.toBlend??1))>.00001&&wanted);
  const legacy=!!(!t?.active&&wanted&&Number.isFinite(stateBlend)&&Math.abs(stateBlend-(snapshot.enabled?1:0))>.002);
  if(!explicit&&!legacy)return {active:false,compact:snapshot.compactBits?1:0,wing:1};
  const blend=unit(legacy?stateBlend:snapshot.rendering?.blend??1);
  return {active:true,compact:1-ease(blend/.45),wing:ease((blend-.45)/.55)};
}
export function compactBitTransform(source,token,snapshot,motion=null){
  const follow=snapshot.rendering?.flightActive||snapshot.rendering?.wingsActive||compactWingHandoff(snapshot,motion?.blend).active?motion:null;
  const size=(Math.max(token.w??0,token.h??0)||100)*(follow?.altScale??1),angle=(source.rotation??0)+(follow?.bank??0),c=Math.cos(angle),s=Math.sin(angle);
  const x=(snapshot.options?.offsetX??0)*size,y=(snapshot.options?.offsetY??0)*size;
  return {x:source.x+(follow?.swayX??0)+x*c-y*s,y:source.y+(follow?.lift??0)+x*s+y*c,width:size*3.5,height:size*3.5,angle,presence:1};
}
/** No wing contours, model, trails, shadows, light or worker are involved. */
export function compactBitGeometry(snapshot,now,{waveState=null,retainOwnedWaves=false}={}){
  const flight={...snapshot,compactBits:true,formation:{growth:1,fold:0,presence:1},stabilizerDeployment:1,
    gems:{...snapshot.gems,style:'choreographed',appearance:'physical'}};
  const visual={...snapshot.visual?.profile,time:now/1000,animated:snapshot.gems.animated};
  const hidden=new Set(snapshot.bitActionAssignments?.hidden??[]),bits=new Map(),frame={};
  const weights=snapshot.poseAnimation?.weights??[1,0,0,0,0,0,0,0,0,0,0];
  for(const side of [-1,1])for(const part of choreographedGems(weights,0,visual,flight,side,frame)){
    if(!part.hardware)continue;
    const station=`${side<0?'left':'right'}${part.id==='gem-0'?'Upper':'Lower'}`;
    if(hidden.has(station)||part.strength<=.00001)continue;
    const wave=flight.gems.glow&&flight.gems.glowMode==='field'?updateBitWaveDirection(waveState,station,{position:part.points[0],intent:part.hardware.intent,focus:part.hardware.focus,target:flight.intentTarget??part.hardware.workTarget,now,
      animated:flight.gems.animated,reduced:!!snapshot.effective?.reducedMotion}):{direction:[0,-1]};
    part.hardware.glow=flight.gems.glow?{direction:wave.direction,strength:flight.gems.glowStrength??.4}:null;
    const id=`${side<0?'left':'right'}-${part.id}`,front=part.points[0][2]>=0?1:0;
    bits.set(id,{id,station,left:side<0,part,front:front*part.strength,rear:(1-front)*part.strength});
  }
  retainBitWaveDirections(waveState,retainOwnedWaves?BIT_WAVE_STATIONS:[...bits.values()].map(bit=>bit.station));return bits;
}

/** Compact companions share exact existing physical artwork with wing bits. */
export class CompactBitRenderer {
  constructor(token){this.token=token;this.bits=new BitRenderer(token);this.pictures=new BitPictureLease(this.bits);this.releaseAssets=bitAssets.acquire();this.baseBits=new Map();this.depths=new Map();const waves=acquireBitWaveDirections(token);this.waveState=waves.memory;this.releaseWaves=waves.release;}
  update(s,snapshot,cfg,now){
    localPerformance.recordQuality(cfg);localPerformance.recordRenderPath('compact-main-thread');
    this.bits.conditionContext={response:snapshot.conditionResponse,now};
    const source=s.source??this.token.mesh,transform=compactBitTransform(source,this.token,snapshot,s),size=Math.max(this.token.w,this.token.h);
    // All four instruments can be assigned elsewhere. Those assignments own
    // their travel; do not repeatedly build an empty home constellation.
    if(Array.isArray(snapshot.bitHomeStations)&&snapshot.bitHomeStations.length===0){this.hide();return false;}
    const visible=cfg.enabled!==false&&cfg.performanceComponents?.bits!==false&&snapshot.bitDeployment>.00001&&source.alpha>0&&(snapshot.options.opacity??.95)>0&&isShown(this.token,source)&&
      (isOnScreen(transform.x,transform.y,size*1.4*(snapshot.gems.soloRadius??1),size*1.4*(snapshot.gems.soloRadius??1))||bitRestVisible(snapshot,isOnScreen));
    if(!visible){this.hide();return false;}
    const deploying=snapshot.bitDeployment<.999||snapshot.bitTransition?.active||snapshot.bitCount?.transition?.active;
    const moving=snapshot.lantern?.active&&!frozenLanternArtwork(snapshot)||snapshot.conditionResponse?.collapse.phase==='falling'||snapshot.conditionResponse?.collapse.phase==='recovering'||snapshot.bitSequenceActive||snapshot.bitTransition?.active||snapshot.bitCount?.transition?.active||snapshot.bitFormationTransition?.progress<1||snapshot.transition?.active||compactWingHandoff(snapshot,s.blend).active;
    const active=moving||!!snapshot.gems.animated;
    // An idle animated formation repaints its machinery at up to 24 Hz (it
    // stepped visibly at 12); any other reason keeps the normal artwork rate.
    // Travel stays display-rate.
    const fullRate=Math.min(30,cfg.rigFPS??24),idle=active&&!moving,fullSlot=Math.floor(now/(1000/fullRate));
    const slot=idle?`idle:${Math.floor(now/(1000/Math.min(24,fullRate)))}`:fullSlot;
    const assignmentKey=`${snapshot.bitHomeStations?.join('|')??''}:${snapshot.bitActionAssignments?.hidden?.join('|')??''}`;
    // A frozen arrangement only needs its (costly) identity at artwork slots.
    const geometryKey=active?null:slot===this.slot&&this.geometryKey!=null?this.geometryKey:JSON.stringify([v7SemanticGems(snapshot.gems),snapshot.v9,snapshot.bitDeployment,snapshot.bitCount?.values,snapshot.bitCount?.formationWeights,snapshot.bitActionAssignments,snapshot.bitHomeStations,snapshot.bitFormationTransition,snapshot.bitFormationFlow,snapshot.bitGesturePreview,snapshot.bitActivity,snapshot.bitProjectedEffect,snapshot.conditionResponse?.collapse.phase,snapshot.conditionResponse?.levels,snapshot.poseAnimation?.weights,snapshot.poseAnimation?.tipWeights,snapshot.intentTarget,{...snapshot.visual?.profile,time:0,effectTime:0,...(snapshot.visual?.profile?.variant?{variant:{...snapshot.visual.profile.variant,time:0}}:{})},lanternArtworkIdentity(snapshot),cfg.performanceComponents?.fields,...(snapshot.lantern?.active?[snapshot.lightAppearance,snapshot.effective?.intensity]:[])]);
    const bridge=snapshot.lantern?.mountingTransition,mountingKey=`${snapshot.lantern?.mounting??''}|${bridge?.started??''}|${bridge?.to??''}`;
    let sampleArtwork=this.lanternMountingKey!==mountingKey||!this.baseBits.size||assignmentKey!==this.assignmentKey||active&&slot!==this.slot||!active&&this.geometryKey!==geometryKey;
    this.assignmentKey=assignmentKey;this.lanternMountingKey=mountingKey;
    // Live heading and size at display rate. Between artwork frames the mesh
    // carries their difference from the painted texture (see placements).
    const flight=active?{...snapshot,compactBits:true,formation:{growth:1,fold:0,presence:1},stabilizerDeployment:1}:null;
    const time=snapshot.gems.animated?now/1000*(snapshot.gems.speed??1):0,live=new Map();
    const place=station=>{let p=live.get(station);if(!p){p=compactGeometryPlacement(station,flight,time);live.set(station,p);}return p;};
    if(!sampleArtwork&&active){
      for(const bit of this.baseBits.values()){
        const p=place(bit.station);
        bit.part.points[0]=[...p.center,.92];bit.part.strength=p.strength;bit.part.hardware.intent=p.intent;
      }
      // Idle 12 Hz holds only while the painted heading/size stay within a
      // hair of the live one; a quickly turning formation keeps full rate.
      if(idle&&fullSlot!==this.fullSlot)for(const [id,bit] of this.baseBits){
        const painted=this.bits.paintedHardware(id),p=live.get(bit.station);if(!painted||!p)continue;
        if(Math.abs(Math.atan2(Math.sin(p.angle-painted.angle),Math.cos(p.angle-painted.angle)))>.035||Math.abs(p.scale/painted.scale-1)>.02){sampleArtwork=true;break;}
      }
    }
    this.fullSlot=fullSlot;
    const bits=sampleArtwork?compactBitGeometry(snapshot,now,{waveState:this.waveState,retainOwnedWaves:true}):this.baseBits,placements={},c=Math.cos(transform.angle),sn=Math.sin(transform.angle);
    if(sampleArtwork&&active)for(const bit of bits.values()){
      const p=place(bit.station);bit.paintAngle=p.angle;bit.paintScale=p.scale;
      // Deploy/recall grows the housing every frame: size its surface once
      // for the full body instead of reallocating it on each artwork frame.
      if(deploying)bit.surfaceScale=.76*(snapshot.gems.size??1);
    }
    this.geometryKey=geometryKey;this.depths??=new Map();
    this.baseBits=bits;
    // (11.0.0-test.7) her invisibility veil reaches the compact bits too (they kept full strength while she was held)
    const veil=veilAlphaOf(this.token,'bits');
    for(const [id,bit] of bits){
      const [cx,cy,z]=bit.part.points[0],x=cx/600*transform.width,y=(cy-15)/600*transform.height;
      const previous=this.depths.get(id);
      if(previous!==undefined&&previous!==(z>=0))bit.depthBounds??=compactSolidBounds(bit.part.hardware,this.depthOutline(bit,now));
      const front=compactDepthFront(bit.part.points[0],previous,{halfWidth:this.token.w/transform.width*300,halfHeight:this.token.h/transform.height*300,bounds:bit.depthBounds});this.depths.set(id,front);
      placements[id]={x:transform.x+x*c-y*sn,y:transform.y+x*sn+y*c,angle:transform.angle,
        scale:transform.width/600,alpha:source.alpha*(snapshot.options.opacity??.95)*bit.part.strength*veil,
        front};
      if(cfg.performanceComponents?.fields===false)bit.part.hardware.glow=null;
    }
    const ids=[...bits.keys()].join('|');
    const expressive=snapshot.gems.expressionEnabled!==false&&(snapshot.gems.expressionStrength??.45)>0;
    const idleWeight=1-(snapshot.lantern?.weight??0);
    const passive=idleWeight>.0001&&!(snapshot.conditionResponse?.bits&&snapshot.conditionResponse.collapse.mix>.01)&&cfg.performanceComponents?.fields!==false&&!cfg.reduced&&snapshot.gems.glow&&snapshot.gems.passiveEffects!==false&&snapshot.gems.animated&&(snapshot.gems.personality>0||expressive)&&snapshot.bitDeployment>.999;
    if(!passive)this.currents?.hide();
    // Texture density follows the displayed size (zoom × device pixels).
    const world=globalThis.canvas?.primary?.worldTransform??globalThis.canvas?.stage?.worldTransform,zoom=world?Math.max(Math.hypot(world.a??1,world.b??0),Math.hypot(world.c??0,world.d??1)):1;
    const detail=bitDetailForScale(transform.width/600,cfg.bitQuality,zoom*(globalThis.canvas?.app?.renderer?.resolution??1)),paintOptions={scale:transform.width/600,budget:2,offload:this.pictures.offload(cfg,now)};
    // A stationary, frozen arrangement keeps its pixels. Travel and position
    // still run at display rate, regardless of the artwork frame cap.
    if(sampleArtwork||slot!==this.slot||ids!==this.ids||cfg.bitQuality!==this.quality||detail!==this.detail){
      const appearance=JSON.stringify([active?snapshot.gems:v7SemanticGems(snapshot.gems),snapshot.v9,cfg.bitQuality,cfg.performanceComponents?.fields,bitAssets.revision,snapshot.bitProjectedEffect]);
      // At most two changed bits upload per frame; the rest follow on the
      // next display frames of the same artwork round (see BitFrames).
      if(active||sampleArtwork||ids!==this.ids||appearance!==this.appearance||detail!==this.detail){this.round=(this.round??0)+1;this.bits.paint(bits,cfg.bitQuality,now,{...paintOptions,round:this.round});}
      if(passive){
        const poses=[...bits.values()].map(bit=>({station:bit.station,x:bit.part.points[0][0],y:bit.part.points[0][1],z:bit.part.points[0][2]/24,intent:bit.part.hardware.intent}));
        const paths=sampleCompactCurrents(poses,{strength:Math.min(1,snapshot.gems.glowStrength??.4)});
        if(paths.length)this.currents??=new CompactCurrents(this.token);
        this.currents?.paint(paths,cfg.bitQuality,now);
      }
      this.slot=slot;this.ids=ids;this.appearance=appearance;this.quality=cfg.bitQuality;this.detail=detail;
    }else if(this.bits.pendingPaint)this.bits.paint(bits,cfg.bitQuality,now,{...paintOptions,round:this.round});
    // Carry the live size (deploy/recall growth) and, where no owner-frame
    // field fan is painted, the live heading between artwork frames.
    if(active)for(const [id,bit] of bits){
      const painted=this.bits.paintedHardware(id),p=live.get(bit.station)??place(bit.station);if(!painted||!p)continue;
      const ratio=p.scale/painted.scale;if(Number.isFinite(ratio)&&ratio>0)placements[id].scale*=ratio;
      const h=bit.part.hardware,fan=h.glowMode==='field'&&h.glow&&(h.glow.strength??0)>0;
      if(!fan&&Number.isFinite(p.angle-painted.angle))placements[id].angle+=p.angle-painted.angle;
    }
    for(const id of this.depths.keys())if(!bits.has(id))this.depths.delete(id);
    this.bits.placeWorld(placements,source,cfg);if(passive)this.currents?.place(transform,source,source.alpha*(snapshot.options.opacity??.95)*idleWeight*veil,cfg);return true;
  }
  /** Depth holds need the solid outline on each artwork sample while a bit
   * crosses the token plane; its shape changes slowly, so reuse it briefly. */
  depthOutline(bit,now){
    this.depthOutlines??=new Map();let entry=this.depthOutlines.get(bit.station);
    if(!entry||now<entry.at||now-entry.at>250){entry={at:now,outline:compactSolidOutline(bit.part.hardware)};this.depthOutlines.set(bit.station,entry);}
    return entry.outline;
  }
  hide(){this.bits.hide();this.currents?.hide();this.depths?.clear();this.depthOutlines?.clear();}
  destroy(){this.pictures.destroy();this.bits.destroy();this.currents?.destroy();this.currents=null;this.releaseAssets?.();this.releaseAssets=null;this.baseBits.clear();this.depths?.clear();this.releaseWaves?.();this.releaseWaves=null;}
}
