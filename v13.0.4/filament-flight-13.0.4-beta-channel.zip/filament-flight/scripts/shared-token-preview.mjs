import {ID} from './config.mjs?v=13.0.4';
import {isShown,placeBehind,setMeshTransform} from './renderer.mjs?v=13.0.4';

// One subclass for every drag ghost, created on first use (Foundry's canvas
// classes are not needed merely to import this module).
let PreviewMesh=null;
const previewMeshClass=()=>PreviewMesh??=class PreviewMesh extends foundry.canvas.primary.PrimarySpriteMesh{get shouldRenderDepth(){return false;}containsCanvasPoint(){return false;}};

/** A drag ghost is another view of the placed token's completed artwork.
 * It owns only meshes: no canvases, textures, sampling, workers or timers.
 * The placed renderer remains the sole owner of every shared texture. */
export class SharedTokenPreviewRenderer {
  constructor(token,getSourceState){this.token=token;this.getSourceState=getSourceState;this.sharedPreview=true;this.records=new Map();}
  makeMesh(key,source){
    const Mesh=previewMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
    const mesh=new Mesh({name:`${ID}.${this.token.id}.drag.${key}`,texture:source.texture},Shader);
    mesh.eventMode='none';mesh.interactive=false;mesh.visible=false;mesh.alpha=0;canvas.primary.addChild(mesh);
    return mesh;
  }
  release(record){const mesh=record.mesh;if(mesh&&!mesh.destroyed){mesh.parent?.removeChild(mesh);mesh.destroy({children:true,texture:false,baseTexture:false});}}
  update(state){
    if(this.destroyed)return false;
    const owner=this.getSourceState(),source=owner?.source,preview=state.source??this.token.mesh;
    if(!source||!preview||!owner.renderer?.previewMeshes){this.suspend();return false;}
    const shown=isShown(this.token,preview)&&isShown(owner.token,source)&&preview.alpha>0;
    const angle=(preview.rotation??0)-(source.rotation??0),c=Math.cos(angle),sn=Math.sin(angle);
    const scale=Math.max(this.token.w,this.token.h)/Math.max(owner.token.w,owner.token.h);
    const opacity=source.alpha>0?preview.alpha/source.alpha:0,seen=(this.seen??0)+1;this.seen=seen;
    for(const [key,painted]of owner.renderer.previewMeshes()){
      if(!painted||painted.destroyed||!painted.texture||painted.texture.destroyed||painted.texture.baseTexture?.destroyed)continue;
      let record=this.records.get(key);
      if(!record){record={mesh:this.makeMesh(key,painted)};this.records.set(key,record);}
      record.seen=seen;const mesh=record.mesh;
      // Worker installations, atlas frame changes and quality rebuilds replace
      // the reference atomically. Never resize or destroy a borrowed texture.
      if(mesh.texture!==painted.texture)mesh.texture=painted.texture;
      const anchorX=painted.anchor?.x??.5,anchorY=painted.anchor?.y??.5;
      if(mesh.anchor.x!==anchorX||mesh.anchor.y!==anchorY)mesh.anchor.set(anchorX,anchorY);
      const x=(painted.x-source.x)*scale,y=(painted.y-source.y)*scale;
      setMeshTransform(mesh,preview.x+x*c-y*sn,preview.y+x*sn+y*c,(painted.rotation??0)+angle,painted.width*scale,painted.height*scale);
      const alpha=(painted.alpha??1)*opacity,tint=painted.tint??0xffffff;
      if(mesh.alpha!==alpha)mesh.alpha=alpha;if(mesh.tint!==tint)mesh.tint=tint;
      const visible=shown&&painted.visible!==false&&painted.renderable!==false&&alpha>0;
      if(mesh.visible!==visible)mesh.visible=visible;
      placeBehind(mesh,preview,(source.sort??0)-(painted.sort??0));
    }
    for(const [key,record]of this.records)if(record.seen!==seen){this.release(record);this.records.delete(key);}
    return true;
  }
  suspend(){for(const {mesh}of this.records.values())if(mesh.visible!==false)mesh.visible=false;}
  resetTrails(){}
  destroy(){this.destroyed=true;for(const record of this.records.values())this.release(record);this.records.clear();this.getSourceState=null;}
}
