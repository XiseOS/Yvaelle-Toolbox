import {sampleV7MedicalSite} from './v7-medical-work.mjs?v=13.0.4';

/** V9 art direction for the existing medical mechanisms. These are bounded,
 * patient-local material accents, never another task, rules effect or source.
 * The legacy Enhanced and Classic paths remain available through one opt-out.
 * A missing v9 flag deliberately preserves recorded pre-v9 fixtures. */
const clamp=n=>Math.max(0,Math.min(1,Number(n)||0));
const smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const mix=(a,b,q)=>a+(b-a)*q;
const PEARL='#ffe4f8',PINK='#ff62cf',ICE='#c3e5ff';

export const medicalCraftEnabled=context=>(context?.snapshot?.v9?.medicalCraft??context?.cfg?.v9MedicalCraft)===true;

/** Working contacts keep their established material weights. Only long feeds,
 * secondary tools and their packets step back; the primary work is not dimmed.
 * The result beat starts with gain 1, so the first finishing frame is exact. */
export function medicalFeedEmphasis(effect,index=0){
  if(effect?.v9MedicalCraft!==true)return 1;
  const result=effect.phase==='finishing'||Number.isFinite(effect.v9ResultProgress)?smooth((effect.v9ResultProgress??effect.progress??0)/.30):0;
  const support=index>=2?(index===2?.70:.57):1;
  return support*(1-result*(index===0?.56:.73));
}

const feedRoles=new Set(['emitter-feed','core-tool-stem','energy-packet','inspection-fan']);
export function refineMedicalFrame(frame,effect){
  if(!frame||effect?.v9MedicalCraft!==true)return frame;
  const ids=(effect.emitters??[]).map(e=>e.id),ending=frame.medicalOutcome===true;
  const paths=frame.paths.map(path=>{
    const index=ids.indexOf(path.emitterId);
    if(!ending&&feedRoles.has(path.role)&&index>=0){
      const gain=medicalFeedEmphasis(effect,index);
      return {...path,alpha:path.alpha*gain,fill:(path.fill??0)*gain};
    }
    // Keep the local result at the same repair. A seated trace has a clear
    // material edge; critical proof has a short travelling leading edge.
    if(ending&&effect.style==='tissueLens'&&path.role==='result-seated-trace')return {...path,width:1.55};
    if(ending&&effect.style==='tissueLens'&&path.role==='result-verification-packet')return {...path,width:2.05};
    return path;
  });
  return {...frame,paths,v9MedicalCraft:true};
}

/** Two focused prototypes: a nib's narrow travelling focal lamella and a
 * membrane's coherent bonding front. Each is driven by the existing work clock
 * and disappears with that same mechanism. No generic badge, aura or flash. */
export function sampleMedicalCraft(effect={}){
  if(effect.v9MedicalCraft!==true||!['tissueLens','membrane'].includes(effect.style))return null;
  const count=Math.max(1,Math.min(4,effect.emitters?.length||1));
  const scanning=effect.phase==='scanning',finishing=effect.phase==='finishing';
  const p=clamp(effect.progress),entry=scanning?smooth((effect.scan??p)/.82):1;
  const release=finishing?1-smooth(p/.72):1;
  const strength=Math.max(0,Math.min(2,effect.strength??1))*entry*release;
  const frame={effect:'token-field',id:'v9-medical-'+effect.style,color:'#ff00ff',count,strength,paths:[],v9MedicalCraft:true};
  if(!(strength>0)||effect.phase==='travel'||effect.phase==='returning')return frame;
  const quality=effect.detail==='low'?0:effect.detail==='high'?2:1,steps=[8,12,16][quality];
  const add=(points,{alpha=.6,width=.7,plane='front',tint=PEARL,closed=false,fill=0,role='v9-medical-material'}={})=>{
    if(points.length<2||alpha*strength<.0001)return;
    frame.paths.push({points,alpha:clamp(alpha*strength),width,plane,tint,fillTint:tint,closed,fill:Math.min(.08,fill*strength),role,glow:false});
  };
  const curve=(fn,options)=>add(Array.from({length:steps+1},(_,i)=>fn(i/steps)),options);
  if(effect.style==='tissueLens'){
    const t=effect.animated===false?0:Math.max(0,Number(effect.clock)||0),site=sampleV7MedicalSite('tissueLens',count,t);
    const u=site.cursor,tangent=site.tangent(u),length=Math.hypot(tangent.x,tangent.y)||1;
    const normal={x:-tangent.y/length,y:tangent.x/length};
    // A tiny lens-shaped reflection is tangent to the actual deposited line.
    // It follows the writing nib instead of circling an unrelated local point.
    const half=.052,start=Math.max(0,u-half),end=Math.min(1,u+half);
    const edge=(sign)=>Array.from({length:steps+1},(_,i)=>{
      const q=i/steps,at=site.trace(mix(start,end,q)),bow=Math.sin(Math.PI*q)*1.6;
      return [at.x*100+normal.x*bow*sign,at.y*100+normal.y*bow*sign];
    });
    add([...edge(-1),...edge(1).reverse()],{alpha:.40,fill:.045,width:.65,tint:ICE,closed:true,role:'v9-focused-lamella'});
    const at=site.trace(u);
    add([[at.x*100-normal.x*1.55,at.y*100-normal.y*1.55],[at.x*100+normal.x*1.55,at.y*100+normal.y*1.55]],{alpha:.78,width:1.2,role:'v9-active-focus'});
    frame.bounds={x:-18,y:-14,width:36,height:41};
  }else{
    const t=effect.animated===false?1.3:Math.max(0,Number(effect.clock)||0);
    const cycle=(t/5.2)%1,phase=scanning?clamp(effect.scan??p):cycle;
    const y=-47+84*phase,radius=48,half=Math.sqrt(Math.max(0,1-((y+3)/53)**2))*radius;
    const front=u=>[-half+2*half*u,y+Math.sin(Math.PI*u)*8];
    // A narrow, translucent strip on the existing bonding front reads as a
    // material face. It is one shared front, not one full field per bit.
    const a=Array.from({length:steps+1},(_,i)=>front(i/steps));
    // the front fades out at the hem and back in at the crown, so the loop never jumps
    const edge=Math.max(0,Math.min(1,phase/.08,(1-phase)/.1)),turn=scanning||effect.animated===false?1:edge*edge*(3-2*edge);
    add(a.concat([...a].reverse().map(([x,y])=>[x,y+1.65])),{alpha:.23*turn,fill:.035,width:.45,tint:ICE,closed:true,role:'v9-membrane-bonding-face'});
    curve(front,{alpha:.42*turn,width:1.10,role:'v9-membrane-bonding-edge'});
    // Pearl reaches each panel's boundary in sequence along the shared front.
    // The smaller pair are construction witnesses, not extra source apertures.
    if(quality>0)for(const fraction of [.27,.73]){
      const at=front(fraction),n=1.4;
      add([[at[0]-n,at[1]],[at[0],at[1]+.75],[at[0]+n,at[1]]],{alpha:.54*turn,width:.8,tint:PINK,role:'v9-bonded-panel-witness'});
    }
    frame.bounds={x:-53,y:-52,width:106,height:99};
  }
  return frame;
}
