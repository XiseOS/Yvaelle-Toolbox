/** Render-local area discoveries. Only the attending physical instrument pauses;
 * no token flags, timers, hidden-token hints, or shared job mutations. */
import {sampleBitTool,creatureEncounterDuration} from './v8-scan-choreography.mjs?v=13.0.4';
import {scanSpeed,rebaseScanClock,pauseScanBit,resumedScanOffset} from './v82-scan-clock.mjs?v=13.0.4';
import {scanCellIntersectsToken,scanTokenVisible} from './v82-scene-scan-context.mjs?v=13.0.4';
import {sampleWeightedTransit} from './v8-motion.mjs?v=13.0.4';
import {sampleCoreState} from './bit-core-states.mjs?v=13.0.4';
import {DEFAULT_SCAN_METHODS} from './v84-scan-methods.mjs?v=13.0.4';

export const SCAN_ENCOUNTER_JOB_LIMIT=32,SCAN_ENCOUNTER_TOKEN_LIMIT=512;
/** A wall-guard refusal never strands a diverted bit: an examination blocked
 * this long (or running past its expected end plus the grace) returns, and a
 * return leg still refused this long rejoins its parent work anyway. */
export const SCAN_ENCOUNTER_BLOCKED_MS=2000,SCAN_ENCOUNTER_OVERRUN_MS=1500,SCAN_ENCOUNTER_RETURN_BLOCKED_MS=2000;
const point=p=>({x:p.x,y:p.y});
const smooth=n=>{n=Math.max(0,Math.min(1,n));return n*n*(3-2*n);};
const mixAngle=(a,b,t)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a))*t;
const speedOf=event=>scanSpeed(event.scanClock?.speed??event.utility?.scanSpeed);
const sameScanMethods=(a,b)=>a===b||Object.keys(DEFAULT_SCAN_METHODS).every(group=>{const aa=a?.[group]??DEFAULT_SCAN_METHODS[group],bb=b?.[group]??DEFAULT_SCAN_METHODS[group];return aa.length===bb.length&&aa.every((method,i)=>method===bb[i]);});
const keyOf=(event,scene)=>`${scene?.id??''}:${event.id}:${event.utilityRevision??0}`;
const fields=['positions','rotations','depths','glows','coreStates','tools','phases','scanPurpose'];

function localEvent(event,job){
  const offsets={...event.scanOffsets},pauses={...event.scanPausedAt},elapsed={...event.scanPausedElapsed};
  for(const [id,offset] of job.offsets)offsets[id]=Math.max(0,event.scanOffsets?.[id]??0)+offset;
  for(const [id,pause] of job.pauses){pauses[id]=pause;elapsed[id]=pause.elapsed;}
  return {...event,scanOffsets:offsets,scanPausedAt:pauses,scanPausedElapsed:elapsed};
}
function stripInstrument(sample,id){
  for(const effect of sample.effects??[])if(effect.effect==='v8-scan')effect.channels=effect.channels.flatMap(channel=>{
    if(channel.id===id)return [];
    if(!channel.sources?.some(source=>source.id===id))return [channel];
    const sources=channel.sources.filter(source=>source.id!==id);if(!sources.length)return [];
    const polygons=sources.map(source=>source.regionPolygon).filter(Boolean),points=polygons.flat(),xs=points.map(p=>p.x),ys=points.map(p=>p.y),x=Math.min(...xs),y=Math.min(...ys);
    return [{...channel,sources,source:{x:sources[0].x,y:sources[0].y},cellCount:sources.length,cooperative:sources.length>1,regionPolygons:polygons,regionPolygon:polygons[0],gridCellIds:sources.map(source=>source.gridCellId),regionBounds:{x,y,width:Math.max(...xs)-x,height:Math.max(...ys)-y}}];
  });
  sample.effects=sample.effects.filter(effect=>effect.effect!=='v8-scan'||effect.channels.length);
  for(const name of ['intents','focuses'])sample[name]=(sample[name]??[]).filter(entry=>entry.station!==id);
}
function replaceInstrument(sample,child,id,{optics=false}={}){
  stripInstrument(sample,id);
  for(const name of fields){sample[name]??={};if(child[name]?.[id]!==undefined)sample[name][id]=child[name][id];else delete sample[name][id];}
  for(const name of ['intents','focuses'])sample[name].push(...(child[name]??[]).filter(entry=>entry.station===id));
  if(optics&&child.effects?.some(effect=>effect.effect==='v8-scan'&&effect.mode==='areaScan'&&effect.channels.some(channel=>channel.sources))){
    // Returning instruments rejoin the CURRENT team pass, which may regroup
    // every source. Install its one shared set atomically instead of adding a
    // duplicated area channel for only the arriving instrument.
    sample.effects=sample.effects.filter(effect=>effect.effect!=='v8-scan'||effect.mode!=='areaScan');
    sample.effects.push(...child.effects.filter(effect=>effect.effect==='v8-scan'&&effect.mode==='areaScan'));
  }
  if(optics)for(const effect of child.effects??[]){
    if(effect.mode==='areaScan'&&effect.channels.some(channel=>channel.sources))continue;
    const channels=effect.effect==='v8-scan'?effect.channels.filter(channel=>channel.id===id):[];if(!channels.length)continue;
    const present=sample.effects.find(entry=>entry.effect==='v8-scan'&&entry.mode===effect.mode);if(present)present.channels.push(...channels);else sample.effects.push({...effect,channels});
  }
}
function beginReturn(diversion,child,now){
  if(diversion.returning)return;
  const id=diversion.id;diversion.returning={at:now,duration:720,from:point(child.positions[id]),rotation:child.rotations[id]??0,depth:child.depths?.[id]??.8};
}
function cancelDiversion(event,job,id,now){
  const effective=localEvent(event,job),saved=event.scanPausedAt?.[id],at=typeof saved==='number'?saved:saved?.at;
  const until=Number.isFinite(at)?Math.min(now,at):Math.min(now,event.utilityReentries?.[id]?.at??now);
  job.offsets.set(id,Math.max(0,resumedScanOffset(effective,until,id)-Math.max(0,event.scanOffsets?.[id]??0)));job.pauses.delete(id);job.diversions.delete(id);
}

export class ScanEncounterController {
  constructor(){this.jobs=new Map();}
  clear(){this.jobs.clear();}
  retain(events,scene,now=Number(globalThis.game?.time?.serverTime)||0){
    const active=new Set(events.filter(event=>event.kind==='utility'&&event.utility?.mode==='areaScan'&&event.status!=='returning').map(event=>keyOf(event,scene)));
    for(const key of this.jobs.keys())if(!active.has(key))this.jobs.delete(key);
    for(const event of events){
      const job=this.jobs.get(keyOf(event,scene));if(!job)continue;
      for(const [id] of job.diversions)if(event.yieldedBits?.includes(id))cancelDiversion(event,job,id,now);
    }
  }
  /** contextForTarget supplies the same portrait pose and occupied geometry as
   * an explicit creature scan. tokens are CURRENT visible scene placeables. */
  sample(event,now,context,{tokens=[],source,scene=globalThis.canvas?.scene,user=globalThis.game?.user,grid=globalThis.canvas?.grid,contextForTarget,guardSample,readOnly=false}={}){
    if(readOnly){const fork=new ScanEncounterController();fork.jobs=structuredClone(this.jobs);return fork.sample(event,now,context,{tokens,source,scene,user,grid,contextForTarget,guardSample});}
    if(event.utility?.mode!=='areaScan'||event.status==='returning')return sampleBitTool(event,now,context);
    const key=keyOf(event,scene);let job=this.jobs.get(key);
    if(!job){
      if(this.jobs.size>=SCAN_ENCOUNTER_JOB_LIMIT)this.jobs.delete(this.jobs.keys().next().value);
      job={offsets:new Map(),pauses:new Map(),completed:new Map(),handled:new Set(),diversions:new Map(),now,started:event.started??0};this.jobs.set(key,job);
    }
    // A scrub or clock reset cannot reuse a discovery from the future.
    if(now<job.now){this.jobs.delete(key);return this.sample(event,now,context,{tokens,source,scene,user,grid,contextForTarget,guardSample});}
    const resumeShift=Math.max(0,(event.started??0)-(job.started??event.started??0));
    if(resumeShift){
      for(const diversion of job.diversions.values()){
        diversion.event={...diversion.event,started:(diversion.event.started??0)+resumeShift,...(diversion.event.scanClock?{scanClock:{...diversion.event.scanClock,at:diversion.event.scanClock.at+resumeShift}}:{})};
        diversion.deadline+=resumeShift;if(diversion.blockedSince!=null)diversion.blockedSince+=resumeShift;
        if(diversion.returning)diversion.returning={...diversion.returning,at:diversion.returning.at+resumeShift,...(diversion.returning.pendingSince!=null?{pendingSince:diversion.returning.pendingSince+resumeShift}:{})};
      }
      delete job.taskPausedAt;
    }
    job.started=event.started??0;
    job.now=now;const clockNow=Math.min(now,event.conditionPausedAt??Infinity,event.taskPausedAt??Infinity),visibleOptions={source,scene,user,grid};
    const sampleTool=(tool,toolContext)=>{const result=sampleBitTool(tool,clockNow,toolContext);return typeof guardSample==='function'?guardSample(result,tool,toolContext,clockNow):result;};
    if(event.taskPausedAt!=null){job.taskPausedAt??=event.taskPausedAt;return sampleTool(event,context);}
    let effective=localEvent(event,job),sample;
    const ids=new Set(event.bits??[]),stations=new Set([...(event.formationBits??event.bits??[]),...(event.yieldedBits??[])]);
    for(const [id,diversion] of job.diversions)if(!ids.has(id)||event.yieldedBits?.includes(id)||event.utilityReentries?.[id]?.at>diversion.event.started)cancelDiversion(event,job,id,clockNow);
    for(const map of [job.offsets,job.pauses,job.completed,job.diversions])for(const id of map.keys())if(!stations.has(id))map.delete(id);
    effective=localEvent(event,job);sample=sampleTool(effective,context);sample.encounterSurfaces=[];sample.depthTargets={};
    if(typeof contextForTarget!=='function')return sample;
    // Check only when a completed-cell ordinal advances. Geometry/visibility
    // of every candidate is evaluated after that cell's actual optical pass.
    let diverted=false;
    for(const id of event.bits??[]){
      const cell=sample.completedCells?.[id];if(!cell||job.diversions.has(id)||cell.ordinal<=(job.completed.get(id)??-1))continue;
      if(['travel','waiting','rejoining'].includes(sample.phases?.[id]?.phase)||event.conditionPausedAt!=null){
        // Medicine reentry can sample a virtual pass that was never projected.
        // Baseline it so it cannot reveal a creature after physical arrival.
        job.completed.set(id,cell.ordinal);continue;
      }
      job.completed.set(id,cell.ordinal);
      if(job.handled.size>=SCAN_ENCOUNTER_TOKEN_LIMIT||context.snapshot?.effective?.reducedMotion)continue;
      const target=tokens.find(token=>!job.handled.has(token.id??token.document?.id)&&scanCellIntersectsToken(cell,token,visibleOptions));
      if(!target)continue;
      const targetId=target.id??target.document?.id,position=sample.positions[id];if(!position||!targetId)continue;
      const childContext=contextForTarget(target),speed=speedOf(event),travelDuration=Math.min(1150,600+Math.hypot(childContext.target.x-position.x,childContext.target.y-position.y)*.35);
      const child={id:`${event.id}:encounter:${id}`,kind:'utility',status:'running',target:targetId,bits:[id],formationBits:[id],started:clockNow,travelDuration,
        originsWorld:{[id]:point(position)},originRotations:{[id]:sample.rotations[id]??0},
        utility:{mode:'creatureScan',oneShot:true,brief:true,seed:`${event.utility?.seed??event.id}:${targetId}`,scanSpeed:speed,weighty:event.utility?.weighty,detail:event.utility?.detail,scanMethods:event.utility?.scanMethods,
          examinationMovement:context.snapshot?.v8Motion?.examinationMovement??'deliberate'}};
      job.handled.add(targetId);job.pauses.set(id,pauseScanBit(effective,clockNow,id));
      let deadline=Infinity;try{deadline=clockNow+creatureEncounterDuration(child,childContext)+SCAN_ENCOUNTER_OVERRUN_MS;}catch{/* The blocked timer still applies. */}
      job.diversions.set(id,{id,targetId,event:child,deadline,last:sampleTool(child,childContext)});
      effective=localEvent(event,job);diverted=true;
    }
    // Re-sample the exact paused clock before replacing bodies, only when a
    // bit was diverted this frame: existing pauses were already applied to the
    // first sample. Colleagues use their unchanged clocks throughout.
    if(diverted){sample=sampleTool(effective,context);sample.encounterSurfaces=[];sample.depthTargets={};}
    const targets=job.diversions.size?new Map(tokens.map(token=>[token.id??token.document?.id,token])):null;
    for(const [id,diversion] of job.diversions){
      const target=targets.get(diversion.targetId),visible=scanTokenVisible(target,visibleOptions);
      let childContext,child=diversion.last;
      if(visible&&!diversion.returning){
        childContext=contextForTarget(target);
        if(!sameScanMethods(event.utility?.scanMethods,diversion.event.utility.scanMethods)){
          child=sampleTool(diversion.event,childContext);
          const phase=child?.phases?.[id],hold=phase?.scanVisit&&['scanning','settling','closing'].includes(phase.phase)?{[id]:{visit:phase.scanVisit,method:phase.method}}:undefined;
          diversion.event={...diversion.event,utility:{...diversion.event.utility,scanMethods:event.utility?.scanMethods},scanMethodHold:hold};
        }
        const speed=speedOf(event);if(speed!==speedOf(diversion.event)){
          diversion.event={...diversion.event,scanClock:rebaseScanClock(diversion.event,clockNow,speed),utility:{...diversion.event.utility,scanSpeed:speed}};
          // A slower pace extends the safety deadline; it never shortens it.
          try{diversion.deadline=Math.max(diversion.deadline,clockNow+creatureEncounterDuration(diversion.event,childContext)+SCAN_ENCOUNTER_OVERRUN_MS);}catch{/* Keep the old deadline. */}
        }
        child=sampleTool(diversion.event,childContext);diversion.last=child;
        // The wall guard keeps a refused examination closed and incomplete.
        // Return after it stays refused for a moment, or once the examination
        // overruns its own expected lifetime; never wait forever.
        // A creature that is merely moving is waited for until the deadline.
        const blocked=child.scanWallStatus?.pending?.includes(id)===true&&child.scanWallStatus.reasons?.[id]!=='moving';
        if(blocked)diversion.blockedSince??=clockNow;else diversion.blockedSince=null;
        if(child.scanComplete||blocked&&clockNow-diversion.blockedSince>=SCAN_ENCOUNTER_BLOCKED_MS||clockNow>=diversion.deadline)beginReturn(diversion,child,clockNow);
      }else if(!diversion.returning)beginReturn(diversion,child,clockNow);
      if(diversion.returning){
        const returning=diversion.returning,q=Math.max(0,Math.min(1,(clockNow-returning.at)/returning.duration));
        const checkedReturn=typeof guardSample==='function'&&context.scanWalls;
        const resume=()=>{
          const resumed=resumedScanOffset(effective,clockNow,id),base=Math.max(0,event.scanOffsets?.[id]??0);
          job.offsets.set(id,Math.max(0,resumed-base));job.pauses.delete(id);job.diversions.delete(id);
          effective=localEvent(event,job);const resumedSample=sampleTool(effective,context);replaceInstrument(sample,resumedSample,id,{optics:true});
        };
        if(q>=1&&!checkedReturn){resume();continue;}
        const paused=sample.positions[id],transit=sampleWeightedTransit(returning.from,paused,q,{size:context.size,duration:returning.duration,index:(event.bits??[]).indexOf(id),enabled:context.snapshot?.v8Motion?.weightedTravel??event.utility?.weighty!==false,reduced:context.snapshot?.effective?.reducedMotion,
          fromRotation:returning.rotation,toRotation:sample.rotations[id]??0});
        stripInstrument(sample,id);sample.positions[id]={x:transit.x,y:transit.y};sample.rotations[id]=transit.rotation??mixAngle(returning.rotation,sample.rotations[id]??0,smooth(q));
        sample.depths[id]=returning.depth+((sample.depths[id]??.8)-returning.depth)*smooth(q);sample.phases[id]={phase:'rejoining',progress:q};
        const gain=smooth((q-.78)/.22),targetCore=sample.coreStates[id],targetChannels=sampleCoreState({activity:targetCore}),coreChannels={};
        for(const channel of ['encase','open','charge','guard','settle','scan','brace','align','rest','conduct'])coreChannels[channel]=(targetChannels[channel]??0)*gain;
        coreChannels.encase+=.24*Math.sin(Math.PI*q)*(1-gain);sample.coreStates[id]={state:targetCore?.state??'settling',amount:1,progress:targetCore?.progress,coreChannels};
        if(sample.tools[id])sample.tools[id]={...sample.tools[id],amount:sample.tools[id].amount*gain};
        sample.glows[id]={...(sample.glows[id]??{}),strength:.45+((sample.glows[id]?.strength??.45)-.45)*gain,mode:'core'};
        if(checkedReturn){
          const returningSample={effects:[],intents:[],focuses:[],completedCells:{},state:{phase:'rejoining',progress:q},scanComplete:false,scanWorking:0,
            ...Object.fromEntries(fields.map(field=>[field,{[id]:sample[field]?.[id]}])),
            scanWallWork:{[id]:{key:`encounter-return:${returning.at}`,from:returning.from,station:paused,focus:paused,inspection:[paused],inspectionPosition:sample.positions[id],inspectionProgress:0,phase:'rejoining',progress:q,initialTravel:true}}};
          // This is a new physical leg departing from the examined portrait,
          // not the child's original departure from its parent area station.
          // The wall guard trusts a captured event origin before a template
          // path's `from`, so give this leg its actual captured departure.
          const returnEvent={...diversion.event,id:`${diversion.event.id}:return`,originsWorld:{[id]:point(returning.from)},originRotations:{[id]:returning.rotation}};
          const checked=guardSample(returningSample,returnEvent,context,clockNow);replaceInstrument(sample,checked,id);
          // A finished animation clock is not proof the physical instrument
          // crossed its checked route. Keep a blocked return closed and pending
          // until its actual body reaches the parent's paused work station.
          const position=checked.positions?.[id],pending=checked.scanWallStatus?.pending?.includes(id)===true;
          if(pending)returning.pendingSince??=clockNow;else returning.pendingSince=null;
          // A return refused this long (an unseen or unreachable work station)
          // rejoins the parent anyway; its own wall guard then holds the bit.
          if(q>=1&&!pending&&position&&Math.hypot(position.x-paused.x,position.y-paused.y)<.05||pending&&clockNow-returning.pendingSince>=SCAN_ENCOUNTER_RETURN_BLOCKED_MS)resume();
        }
        continue;
      }
      replaceInstrument(sample,child,id);sample.depthTargets[id]=target;
      sample.encounterSurfaces.push({event:diversion.event,sample:child,context:childContext,target});
    }
    return sample;
  }
}
