/** Portable cosmetic looks include light artwork and visual reactions.
 * Power, flight mode, HP, light distances and audio are excluded. */
import {validateStatePatch} from './state.mjs?v=13.0.4';
import {readSavedStructurePoses} from './structure-poses.mjs?v=13.0.4';
import {V7_DEFAULTS,LEGACY_V7_ASPECT_FIELDS,normalizeV7Preferences,validateV7Patch} from './v7-ensemble.mjs?v=13.0.4';
export const V7_LOOK_FIELDS=Object.freeze([...Object.keys(V7_DEFAULTS),'mode']);
// Old saved looks remain importable after the two cosmetic aspect controls are
// removed. Discard their known legacy fields, along with running wing events;
// every other unknown or operational key must still fail validation.
const V7_DISCARDED_LOOK_FIELDS=Object.freeze([...LEGACY_V7_ASPECT_FIELDS,'wingGesture']);
export const LOOK_FIELDS=Object.freeze(['options','pose','structurePoses','gemMotion','poseMotion','effectStyle','effectStyles','reactionStyles','effectTuning','reactionTuning','intensity','trailIntensity','movementReactions','lightAppearance','lightVisualReactions','lanternArtwork','lanternGroundStyle','v7']);
const REMOVED_LOOK_FIELDS=Object.freeze(['wingForm','structure']);

/** Portable appearance stores targets and overrides, never a running event.
 * Null remains inheritance; a partial look leaves unmentioned fields alone. */
export function normalizeV7Look(input){
  if(input==null)return null;
  if(typeof input!=='object'||Array.isArray(input))throw new Error('V7 looks contain cosmetic preferences only.');
  if(Object.keys(input).some(key=>!V7_LOOK_FIELDS.includes(key)&&!V7_DISCARDED_LOOK_FIELDS.includes(key)))throw new Error('V7 looks contain cosmetic preferences only.');
  return structuredClone(validateV7Patch(Object.fromEntries(Object.entries(input).filter(([key])=>V7_LOOK_FIELDS.includes(key)))));
}
export function captureV7Look(input){
  const preferences=normalizeV7Preferences(input);
  if(!preferences)return null;
  const appearance=Object.fromEntries(V7_LOOK_FIELDS.map(key=>[key,structuredClone(preferences[key])]));
  // This canonical null also covers inherited fields left behind by a smooth
  // Undo transition. Temporary clocks never alter the saved-look fingerprint.
  return V7_LOOK_FIELDS.every(key=>appearance[key]===null)?null:appearance;
}
export function v7LookPatch(input){
  return input===null?Object.fromEntries(V7_LOOK_FIELDS.map(key=>[key,null])):normalizeV7Look(input);
}
export function normalizeLook(input){
  if(!input||typeof input!=='object'||Array.isArray(input)||input.version!==1)throw new Error('Unsupported saved look.');
  if(Object.keys(input).some(k=>k!=='version'&&!LOOK_FIELDS.includes(k)&&!REMOVED_LOOK_FIELDS.includes(k)))throw new Error('Looks contain cosmetic preferences only.');
  const patch=Object.fromEntries(Object.entries(input).filter(([k])=>k!=='version'&&!REMOVED_LOOK_FIELDS.includes(k)));
  if(Object.hasOwn(patch,'structurePoses'))patch.structurePoses=readSavedStructurePoses(patch.structurePoses);
  const {lanternGroundStyle,v7,...state}=patch;
  const statePatch={...state,...(Object.hasOwn(patch,'lanternGroundStyle')?{lantern:{groundStyle:lanternGroundStyle}}:{})};
  const validated=Object.keys(statePatch).length?validateStatePatch(statePatch):{};
  delete validated.lantern;
  return {version:1,...validated,...(Object.hasOwn(patch,'lanternGroundStyle')?{lanternGroundStyle:lanternGroundStyle??'projector'}:{}),...(Object.hasOwn(patch,'v7')?{v7:normalizeV7Look(v7)}:{})};
}
const look=(name,description,fields)=>({name,description,look:{version:1,...fields}});
export const LOOK_PRESETS=Object.freeze([
 {id:'ellie',...look("Ellie's filaments",'Elegant silver assemblies, woven magenta support and unhurried suspended motion.',{
  options:{floatStyle:'breath',floatSpeed:.85,floatSway:.03,bobHeight:.035,hoverHeight:.2,wingSpeed:.8},pose:'neutral',
  gemMotion:{enabled:true,appearance:'physical',artwork:'resonant',design:'vanes',program:'poised',fieldStyle:'weave',glow:true,glowMode:'field',glowStrength:.45,animated:true,strength:.7,size:1},
  effectStyle:'animated',effectStyles:{normal:'harmonics'},reactionStyles:{flare:'ignition',critical:'overload',pulse:'resonance',stutter:'phaseSlip',reform:'rethread'}})},
 {id:'guardian',...look('Veilguard','Poised defensive filaments supported by small interlocking energy arcs.',{
  options:{floatStyle:'still',wingSpeed:.65},pose:'forwardGuard',gemMotion:{enabled:true,appearance:'physical',artwork:'resonant',design:'shielded',program:'seraph',fieldStyle:'aegis',glow:true,glowMode:'field',glowStrength:.5,animated:true,strength:.65},
  effectStyle:'animated',effectStyles:{normal:'starlit'},reactionStyles:{pulse:'resonance',reform:'rethread'}})},
 {id:'veil',...look('Phase silk','Slender needles, drifting float and a quietly phased filament web.',{
  options:{floatStyle:'drift',floatSpeed:.7,bobHeight:.035,floatSway:.04,wingSpeed:.65},pose:'trailing',gemMotion:{enabled:true,appearance:'physical',artwork:'resonant',design:'spine',program:'orbital',fieldStyle:'contour',glow:true,glowMode:'field',glowStrength:.35,animated:true,strength:.8},
  effectStyle:'animated',effectStyles:{normal:'harmonics',glitching:'refraction'},reactionStyles:{stutter:'phaseSlip',pulse:'orbit'}})},
 {id:'comet',...look('Starfall','A swept lance shape with articulate orbital cores and bright contour currents.',{
  options:{floatStyle:'orbit',floatSpeed:.8,bobHeight:.035,floatSway:.025,wingSpeed:1.1},pose:'aggressiveFlare',gemMotion:{enabled:true,appearance:'physical',artwork:'resonant',design:'vanes',program:'orbital',fieldStyle:'contour',glow:true,glowMode:'field',glowStrength:.55,animated:true,strength:.9},
  effectStyle:'animated',effectStyles:{overdrive:'convergence'},reactionStyles:{flare:'crown',critical:'overload',pulse:'resonance'}})},
]);
export function lookFingerprint(look){
  const stable=value=>value&&typeof value==='object'&&!Array.isArray(value)?Object.fromEntries(Object.keys(value).sort().map(k=>[k,stable(value[k])])):Array.isArray(value)?value.map(stable):value;
  return JSON.stringify(stable(look));
}
