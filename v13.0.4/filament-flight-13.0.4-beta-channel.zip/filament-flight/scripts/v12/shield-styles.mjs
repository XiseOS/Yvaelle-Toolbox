/** Shield styles (12.0.0-beta.2): other looks for her wing shield. The weave
 * (flight-fx.mjs, paintShield) stays the default; each style here is another
 * painter for the same shield surface and the same moments (raised, struck,
 * lowered), chosen in Settings › Flight › Her and the world › Shield styles.
 *  - Scale mail: plates of hardlight cascade down her, each flipping into
 *    place behind a line of light, cut exactly to her shape (her wings as
 *    they are drawn this moment, and a dome over her token; with her wings
 *    away, the dome alone). A blow sends them spinning outward and leaves
 *    them hot where it landed.
 *  - Rotor: her four bits leave their stations and spin up into a disc of
 *    light between her and the blow; a blow staggers it.
 *  - Wing wrap: her wings sweep round and fold about her like arms, crossing
 *    below her; glass fills between the strands and plates zip on. Her bits
 *    clasp it top, bottom and sides.
 * All light is her magenta (#ff00ff) and shades of it. Nothing here runs,
 * allocates or paints while her shield is down. */
import {ID} from '../config.mjs?v=13.0.4';
import {resolveV11} from '../v11/features.mjs?v=13.0.4';

export const SHIELD_STYLES=Object.freeze(['weave','scalemail','rotor','wingwrap']);
/** The rotor, in token sizes from her body: how far ahead its hub stands, its radius and how edge-on it is seen. */
export const ROTOR=Object.freeze({hub:.94,rad:.89,tilt:.42});
const WRAP_BITS=[[0,-.68],[0,.86],[-.74,.06],[.74,.06]],WRAP_BITS_MEAN=.075;
const TAU=Math.PI*2,DEG=Math.PI/180,MAG='255,0,255',DEEP='216,0,216',PALE='255,156,255';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const sm=t=>{t=clamp(t);return t*t*(3-2*t);},easeOut=t=>1-(1-clamp(t))**3,easeIn=t=>clamp(t)**3,bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const lerp=(a,b,t)=>a+(b-a)*t;
const h1=(a,b=0)=>{const s=Math.sin(a*127.1+b*311.7)*43758.5453;return s-Math.floor(s);};

export function shieldStyleOf(doc){try{const v=resolveV11(doc);return v.shieldStyles!==false&&SHIELD_STYLES.includes(v.shieldStyle)?v.shieldStyle:'weave';}catch{return 'weave';}}
/** Styles painted upright on her (not turned to face the blow). */
export const uprightStyle=style=>style==='scalemail'||style==='wingwrap';
/** Half the shield surface's side, in units of sh.r (the weave's is SHIELD_REACH). */
export const styleReach=style=>uprightStyle(style)?1.78:null;
/** Styles that move every frame while they are up. */
export const liveStyle=style=>style==='rotor';

/** The flight feel's part (called each frame the feel runs): the rotor takes
 * her bits, the wrap hides her real wings while its own copy of them is
 * folded about her. `angle`: where the shield faces, on the map. */
export function shieldStyleFeel(doc,s,out,dt,angle=-Math.PI/2){
  const style=s.shieldStyle=shieldStyleOf(doc),a=out.shield??0;
  if(style==='weave'||!(a>.004)){if(s.rotorPhase)s.rotorPhase=0;if(s.shieldRide)s.shieldRide=null;return style;}
  // (12.0.0-beta.7) how far each bit has joined the shield: 1 from the start for a bit that was free when it rose (as it
  // always was); a bit that was busy then (a gesture ending, a brace, a shot) eases in over a fifth of a second once it
  // is free, where it used to appear on the shield in one frame.
  const busy=o=>!o||(o.mix??0)>.05||(o.imix??0)>.01,ride=s.shieldRide??=[0,1,2,3].map(i=>busy(out.bits?.[i])?0:1);
  const join=i=>{ride[i]=Math.min(1,ride[i]+Math.min(.05,dt||0)*5);return sm(ride[i]);};
  if(style==='rotor'){
    const sp=sm(seg(a,.15,1));s.rotorPhase=(s.rotorPhase??0)+Math.min(.05,dt||0)*(4+16*sp);
    const m=sm(seg(a,.04,.6)),rad=ROTOR.rad*sm(seg(a,.3,1)),ux=Math.cos(angle),uy=Math.sin(angle),bx=s.shieldBias?.x??0,by=s.shieldBias?.y??0;
    for(let i=0;i<4;i++){const o=out.bits?.[i];if(busy(o)){ride[i]=0;continue;}// (a bit braced, taking a shot or busy with a gesture keeps its job)
      const q=s.rotorPhase+i*TAU/4,cq=Math.cos(q)*rad*ROTOR.tilt,sq=Math.sin(q)*rad;
      o.mix=m*join(i);o.local=false;o.tx=(ROTOR.hub+cq)*ux-sq*uy-bx;o.ty=(ROTOR.hub+cq)*uy+sq*ux-by;}
  }else if(style==='wingwrap'){
    out.wingAlpha=(out.wingAlpha??1)*(1-clamp(a/.012));
    const m=sm(seg(a,.3,.9)),P=WRAP_BITS,bx=s.shieldBias?.x??0,by=s.shieldBias?.y??0;
    for(let i=0;i<4;i++){const o=out.bits?.[i];if(busy(o)){ride[i]=0;continue;}o.mix=m*join(i);o.local=false;o.tx=P[i][0]-bx;o.ty=P[i][1]-by;}
  }
  return style;
}

/** Her bits are placed from her wings' centre, the shield from her body: measure how far the four stand from where
 * the style wants them and take that out of their targets over the next few frames (s.shieldBias, token sizes). */
export function trimShieldBits(s,bits,body,angle,U,amount){
  const st=s.shieldStyle;if(!(amount>.004)||st!=='rotor'&&st!=='wingwrap'){if(s.shieldBias)s.shieldBias=null;return;}
  if(!(amount>.9)||!Array.isArray(bits)||bits.length!==4||!(U>0))return;let mx=0,my=0;for(const b of bits){mx+=b.x/4;my+=b.y/4;}
  const ex=st==='rotor'?body.x+Math.cos(angle)*ROTOR.hub*U:body.x,ey=st==='rotor'?body.y+Math.sin(angle)*ROTOR.hub*U:body.y+WRAP_BITS_MEAN*U,rx=(mx-ex)/U,ry=(my-ey)/U;
  if(Math.hypot(rx,ry)<.6){const b=s.shieldBias??={x:0,y:0};b.x+=rx*.25;b.y+=ry*.25;}
}
/** Where her bits are really turning (the middle of the four), if they ride the rotor: within reach of where its hub should stand. */
export function rotorHub(bits,body,angle,size){
  if(!Array.isArray(bits)||bits.length!==4||!(size>0))return null;let x=0,y=0;for(const b of bits){x+=b.x/4;y+=b.y/4;}
  const ex=body.x+Math.cos(angle)*ROTOR.hub*size,ey=body.y+Math.sin(angle)*ROTOR.hub*size;return Math.hypot(x-ex,y-ey)<size*.45?{x,y}:null;
}

/* ------------------------------------------------------------- shared */
const mk=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;};
/** How long she has been raising it (9 when it was already up), and lowering it (-1 while it is up). */
function clocks(sh){const t=sh.time??0;return {up:sh.upAt==null?9:t-sh.upAt,down:sh.want===false?t-(sh.downAt??t):-1,t};}
/** The hardest recent blow: its strength now (1 → 0) and its age, and the direction it came from. */
function blow(sh,turn=0){let k=0,age=-1,ang=0;for(const h of sh.hits??[]){const e=Math.exp(-h.age*4.5)*(h.strength??1);if(e>k||age<0){k=e;age=h.age;ang=h.angle-turn;}}return {k,age,ang};}
const SKIP=/\.(trails|drag|flightfx|action|sprite|wingshield)(\.|$)|\.bit\.|shadow$/i;
/** Her wing layers as the canvas holds them this moment (their own 2D pictures and where each sits). */
function wingLayers(sh){
  const now=globalThis.performance?.now?.()??0;if(sh.layers&&now-sh.layersAt<250)return sh.layers;
  const out=[],token=sh.token,prefix=`${ID}.${token?.id??token?.document?.id}.`;
  for(const mesh of globalThis.canvas?.primary?.children??[]){const name=mesh?.name;if(typeof name!=='string'||!name.startsWith(prefix)||SKIP.test(name)||mesh.destroyed||mesh.visible===false)continue;
    const tex=mesh.texture,src=tex?.baseTexture?.resource?.source??tex?.baseTexture?.resource?.bitmap;if(!src||!(src.width>1))continue;out.push({mesh,src,tex});}
  sh.layers=out;sh.layersAt=now;return out;
}
/** Draw her wings upright into `g`, centred at (c,c), k surface pixels a world pixel. */
function drawWings(g,sh,c,k,alpha=1){
  let n=0;for(const {mesh,src,tex} of wingLayers(sh)){if(mesh.destroyed)continue;const fr=tex.frame??{x:0,y:0,width:src.width,height:src.height},sx=Math.sign(mesh.scale?.x??1)||1,sy=Math.sign(mesh.scale?.y??1)||1,w=Math.abs(mesh.width)*k,h=Math.abs(mesh.height)*k;
    g.save();g.globalAlpha=alpha;g.translate(c+(mesh.x-sh.x)*k,c+(mesh.y-sh.y)*k);g.rotate(mesh.rotation||0);g.scale(sx,sy);
    try{g.drawImage(src,fr.x,fr.y,fr.width,fr.height,-(mesh.anchor?.x??.5)*w,-(mesh.anchor?.y??.5)*h,w,h);n++;}catch{}g.restore();}
  return n;
}

/* ================================ Rotor ================================ */
function paintRotor(ctx,sh,half,k){
  const a=clamp(sh.amount),c=half*k,U=sh.r/1.2*k,B=blow(sh,sh.angle??0),sp=sm(seg(a,.15,1)),rad=ROTOR.rad*U*sm(seg(a,.3,1)),ph=sh.phase??0;
  const tilt=ROTOR.tilt+B.k*.25*Math.sin(B.age*40),px=U/147,ca=Math.cos(sh.angle??0),sa=Math.sin(sh.angle??0);
  // the disc stands where her bits are turning; when none ride it (her wings away), it carries four blades of its own
  let hx=c+ROTOR.hub*U-B.k*.1*U,hy=c;const ride=sh.hub&&a>.6;if(ride){const dx=(sh.hub.x-sh.x)*k,dy=(sh.hub.y-sh.y)*k;hx=c+dx*ca+dy*sa-B.k*.1*U;hy=c-dx*sa+dy*ca;}
  ctx.save();ctx.lineCap='round';ctx.translate(0,hy-c);
  if(sp>.2&&rad>1){ctx.save();ctx.translate(hx,c);ctx.scale(tilt,1);
    const g=ctx.createRadialGradient(0,0,6*px,0,0,rad+10*px);g.addColorStop(0,'rgba(255,200,255,.05)');g.addColorStop(.75,`rgba(${MAG},${(.26+.4*B.k).toFixed(3)})`);g.addColorStop(1,`rgba(${DEEP},0)`);
    ctx.globalAlpha=sp;ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,rad+10*px,0,TAU);ctx.fill();
    for(let i=0;i<4;i++){const a0=ph+i*TAU/4,col=i%2?DEEP:MAG;for(let j=0;j<10;j++){const q0=a0-j*.11*sp,q1=a0-(j+1)*.11*sp,al=(.9-j*.08)*sp,w=(4.6-j*.35)*1.6*px;
        ctx.beginPath();ctx.arc(0,0,rad,q1,q0);ctx.strokeStyle=`rgba(${col},${(al*.25).toFixed(3)})`;ctx.lineWidth=w*2.6;ctx.stroke();ctx.strokeStyle=`rgba(${col},${al.toFixed(3)})`;ctx.lineWidth=w;ctx.stroke();}}
    ctx.restore();}
  if(!ride&&rad>1)for(let i=0;i<4;i++){const q=ph+i*TAU/4,x=hx+Math.cos(q)*rad*tilt,y=c+Math.sin(q)*rad,r=9*px;ctx.save();ctx.translate(x,y);ctx.rotate(q);ctx.beginPath();ctx.moveTo(0,-r*1.5);ctx.lineTo(r,0);ctx.lineTo(0,r*1.5);ctx.lineTo(-r,0);ctx.closePath();
    ctx.fillStyle=`rgba(${MAG},${.35*sp})`;ctx.fill();ctx.strokeStyle=`rgba(255,200,255,${sp})`;ctx.lineWidth=Math.max(1,2*px);ctx.stroke();ctx.restore();}
  if(a>.05){const g=ctx.createRadialGradient(hx,c,0,hx,c,14*px);g.addColorStop(0,`rgba(255,200,255,${a})`);g.addColorStop(.4,`rgba(${MAG},${.6*a})`);g.addColorStop(1,`rgba(${MAG},0)`);ctx.fillStyle=g;ctx.beginPath();ctx.arc(hx,c,14*px,0,TAU);ctx.fill();}
  ctx.restore();
}

/* ================================ Scale mail ================================ */
let SCALE=null;
function scaleSprites(){
  if(SCALE)return SCALE;const path=(x,w,h)=>{x.beginPath();x.moveTo(-w,-h*.6);x.lineTo(w,-h*.6);x.lineTo(w,h*.3);x.lineTo(0,h);x.lineTo(-w,h*.3);x.closePath();};
  const make=f=>{const c=mk(32,40),x=c.getContext('2d');x.translate(16,20);f(x);return c;};
  return SCALE={
    dark:make(x=>{path(x,13,17);const g=x.createLinearGradient(0,-10,0,17);g.addColorStop(0,'rgba(30,0,36,0)');g.addColorStop(1,'rgba(30,0,36,.62)');x.fillStyle=g;x.fill();}),
    light:make(x=>{path(x,13,17);const g=x.createLinearGradient(0,-10,0,17);g.addColorStop(0,`rgba(${MAG},0)`);g.addColorStop(1,`rgba(${MAG},.2)`);x.fillStyle=g;x.fill();
      x.beginPath();x.moveTo(13,-3);x.lineTo(13,5.1);x.lineTo(0,17);x.lineTo(-13,5.1);x.lineTo(-13,-3);x.strokeStyle=`rgba(${MAG},.95)`;x.lineWidth=1.6;x.lineJoin='miter';x.stroke();
      x.beginPath();x.moveTo(-12,-9.6);x.lineTo(12,-9.6);x.strokeStyle=`rgba(${PALE},.4)`;x.lineWidth=1;x.stroke();x.beginPath();x.moveTo(0,-6);x.lineTo(0,13);x.strokeStyle=`rgba(${MAG},.3)`;x.stroke();x.fillStyle=`rgba(${PALE},.85)`;x.fillRect(-1.5,9.5,3,3);}),
    hot:make(x=>{path(x,13,17);x.fillStyle='rgba(255,120,255,.4)';x.fill();x.strokeStyle='rgba(255,180,255,.95)';x.lineWidth=1.6;x.stroke();})};
}
/** The field of scales for a surface of `side` px whose token is RD px in radius: flat over her wings, over a dome on her token. */
function scaleField(side,RD){
  const c=side/2,u=RD/83,out=[];
  for(let row=0,fy=-c*1.15;fy<=c*1.15;fy+=16.5*u,row++)for(let fx=-c*1.15+(row&1?12*u:0);fx<=c*1.15;fx+=24*u){const rf=Math.hypot(fx,fy)+.001,dome=rf<1.35*RD,q=rf/(1.35*RD)*Math.PI/2,r2=dome?RD*Math.sin(q):rf-.35*RD,x=fx/rf*r2,y=fy/rf*r2;
    if(Math.abs(x)>c-8*u||Math.abs(y)>c-8*u)continue;out.push({x,y,fs:(dome?lerp(1,Math.cos(q),.5):1)*u,dome,order:clamp((y+c*.8)/(c*1.75))+h1(fx,fy)*.05,i:out.length});}
  out.sort((a,b)=>b.y-a.y);return out;
}
function paintScaleMail(ctx,sh,half,k){
  const side=Math.round(half*2*k),c=side/2,RD=sh.r/2.4*k*1.06,{up,down,t}=clocks(sh),S=scaleSprites();
  if(down>.95)return;
  const st=sh.mail&&sh.mail.side===side&&Math.abs(sh.mail.RD-RD)<.5?sh.mail:(sh.mail={side,RD,field:scaleField(side,RD),mask:mk(Math.max(8,side>>2),Math.max(8,side>>2)),maskAt:-1,cells:null,still:null});
  // her shape this moment: her wings as drawn, thickened a little, and the dome over her token (rebuilt about ten times a second)
  const now=globalThis.performance?.now?.()??0;
  if(now-st.maskAt>100||st.maskAt<0){st.maskAt=now;const m=st.mask,g=m.getContext('2d',{willReadFrequently:true}),ms=m.width,q=ms/side;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,ms,ms);
    let wings=0;for(const [ox,oy] of [[0,0],[1.2,0],[-1.2,0],[0,1.2],[0,-1.2]]){g.save();g.translate(ox,oy);wings=drawWings(g,sh,c*q,k*q);g.restore();}
    g.fillStyle='#000';g.beginPath();g.arc(c*q,c*q,RD*q,0,TAU);g.fill();
    const had=st.wings;st.wings=wings>0;
    if(!st.cells||had!==st.wings||now-(st.cellsAt??-1e9)>700){st.cellsAt=now;let d=null;try{d=g.getImageData(0,0,ms,ms).data;}catch{}
      st.cells=st.field.filter(cell=>{if(cell.dome)return true;if(!st.wings||!d)return false;const px=Math.round((c+cell.x)*q),py=Math.round((c+cell.y)*q);return px>=0&&py>=0&&px<ms&&py<ms&&d[(py*ms+px)*4+3]>18;});st.still=null;}}
  const cells=st.cells??[],hits=(sh.hits??[]).filter(h=>h.age<.9),settled=up>1.15&&down<0&&!hits.length,band=((t*.33)%1)*side*2.4-side*1.2,gl=cell=>Math.exp(-(((cell.x+cell.y-band)/(26*RD/83))**2));
  ctx.save();ctx.setTransform(1,0,0,1,0,0);
  if(settled){
    // nothing is moving: the plates are one picture, and only the glint crossing them is drawn
    if(!st.still){st.still=mk(side,side);const g=st.still.getContext('2d');for(const pass of [S.dark,S.light])for(const cell of cells){g.setTransform(cell.fs,0,0,cell.fs,c+cell.x,c+cell.y);g.globalAlpha=pass===S.dark?1:.9;g.drawImage(pass,-16,-20);}}
    ctx.drawImage(st.still,0,0);
    for(const cell of cells){const hot=gl(cell)*.45;if(hot<.03)continue;ctx.setTransform(cell.fs,0,0,cell.fs,c+cell.x,c+cell.y);ctx.globalAlpha=hot;ctx.drawImage(S.hot,-16,-20);}
  }else{
    const list=[];
    for(const cell of cells){const x1=(up-cell.order*.75)/.26;if(x1<=0)continue;const x2=down<0?-1:(down-(1-cell.order)*.55)/.24;if(x2>=1)continue;let fa=x1<1?(1-easeOut(x1))*Math.PI:0;if(x2>0)fa=easeIn(x2)*Math.PI;
      let px=0,py=0,heat=0;for(const h of hits){const hx=Math.cos(h.angle)*RD*1.25,hy=Math.sin(h.angle)*RD*1.25,dx=cell.x-hx,dy=cell.y-hy,dist=Math.hypot(dx,dy)+.01,th=dist/(520*RD/83),x3=(h.age-th)/.36;
        if(h.age>th){if(x3<1)fa+=TAU*easeOut(x3);const push=7*RD/83*Math.exp(-(h.age-th)*6)*(h.strength??1);px+=dx/dist*push;py+=dy/dist*push;heat=Math.max(heat,Math.exp(-(h.age-th)*1.9)*Math.exp(-dist/(64*RD/83))*.8);}}
      const sy=Math.cos(fa);list.push(cell,c+cell.x+px,c+cell.y+py,sy,(1-Math.abs(sy))**5,Math.min(1,gl(cell)*.45+heat*1.1));}
    for(let i=0;i<list.length;i+=6){const cell=list[i],sy=list[i+3];ctx.setTransform(cell.fs,0,0,cell.fs*Math.max(.05,Math.abs(sy)),list[i+1],list[i+2]);ctx.globalAlpha=sy<0?.5:1;ctx.drawImage(S.dark,-16,-20);}
    for(let i=0;i<list.length;i+=6){const cell=list[i],x=list[i+1],y=list[i+2],sy=list[i+3],flash=list[i+4],hot=list[i+5];ctx.setTransform(cell.fs,0,0,cell.fs*Math.max(.05,Math.abs(sy)),x,y);ctx.globalAlpha=sy<0?.45:.9;ctx.drawImage(S.light,-16,-20);
      if(hot>.02){ctx.globalAlpha=hot;ctx.drawImage(S.hot,-16,-20);}
      if(flash>.04){ctx.setTransform(cell.fs,0,0,cell.fs,x,y);ctx.globalAlpha=flash;ctx.fillStyle=`rgb(${PALE})`;ctx.fillRect(-13,-1,26,2);}}
    // the line of light the plates follow down her (and back up as they go)
    ctx.setTransform(1,0,0,1,0,0);const f1=up/.75,f2=down<0?-1:1-down/.55;
    for(const [f,dn] of [[f1,1],[f2,-1]])if(f>0&&f<1){const yy=c-c*.8+f*c*1.75;ctx.globalAlpha=.9;ctx.fillStyle=`rgb(${PALE})`;ctx.fillRect(0,yy,side,Math.max(1.5,2.4*RD/83));ctx.globalAlpha=.22;ctx.fillStyle=`rgb(${MAG})`;ctx.fillRect(0,yy-(dn>0?16*RD/83:0),side,16*RD/83);}
  }
  ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='destination-in';ctx.imageSmoothingEnabled=true;ctx.drawImage(st.mask,0,0,side,side);
  ctx.restore();
}

/* ================================ Wing wrap ================================ */
/** How far closed, tt seconds after she raised it: sweeps shut, squeezes a touch too tight, settles. */
function closeAt(tt){const x=(tt-.3)/.5;return x<=0?0:(1-Math.exp(-4.2*x)*Math.cos(5*x))*sm(seg(x,0,.3));}
function paintWingWrap(ctx,sh,half,k){
  const side=Math.round(half*2*k),c=side/2,U=sh.r/1.2*k,R0=U*.527,u=U/184,{up,down,t}=clocks(sh),B=blow(sh);
  const st=sh.wrap&&sh.wrap.side===side?sh.wrap:(sh.wrap={side,comp:mk(side,side),arcAt:-1,arc:[[],[]],hex:[[],[]]});
  const g=st.comp.getContext('2d',{willReadFrequently:true});g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,side,side);const wings=drawWings(g,sh,c,k);
  if(!wings)return;
  // the wing's shape in turns round her (read when she starts to raise it, and again if it was never read)
  if(st.arcAt!==(sh.upAt??-2)||!st.arc[0].length&&!st.arc[1].length){st.arcAt=sh.upAt??-2;let d=null;try{d=g.getImageData(0,0,side,side).data;}catch{}
    for(const sd of [-1,1]){const si=sd<0?0:1,raw=[];
      for(let dg=-80;dg<=70;dg+=5){const D=dg*DEG;let rin=0,rout=0;if(d)for(let r=R0+2;r<c-2;r+=3){const x=Math.round(c+sd*Math.cos(D)*r),y=Math.round(c-Math.sin(D)*r);let a=0;for(let j=-1;j<=1;j++)for(let i=-1;i<=1;i++)a=Math.max(a,d[((y+j*2)*side+x+i*2)*4+3]||0);if(a>50){if(!rin)rin=r;rout=r;}}raw.push({D,rin:rin||R0,rout:rout||R0});}
      const arc=[];raw.forEach((a,i)=>{let ro=0,ri=0,n=0;for(let j=-1;j<=1;j++){const b=raw[i+j];if(b){ro+=b.rout;ri+=b.rin;n++;}}if(ro/n>R0+8*u)arc.push({D:a.D,rin:Math.max(R0,ri/n-2*u),rout:ro/n+3*u});});st.arc[si]=arc;
      const hex=[],r=14*u,at=D=>{let b=null;for(const a of arc)if(!b||Math.abs(a.D-D)<Math.abs(b.D-D))b=a;return b&&Math.abs(b.D-D)<5*DEG?b:null;};let n=0;
      for(let j=0;j<9;j++){const rc=R0+15*u+j*21*u,dD=Math.sqrt(3)*r/rc;for(let D=-80*DEG+(j&1?dD/2:0);D<70*DEG;D+=dD){const a=at(D);if(a&&rc>a.rin+5*u&&rc<a.rout-7*u)hex.push({rc,D,r,i:n++});}}st.hex[si]=hex;}}
  const lower=down<0?1:1-sm(seg(down,0,.8)),ant=bump(seg(up,0,.5))+(down>0?bump(seg(down,.55,1.2))*.5:0);
  const Wp=(sd,rho,D)=>{const lag=.13*Math.abs(D)/1.2+.05*clamp((rho-R0)/(130*u)),cl=closeAt(up-lag)*lower,D2=D*(D>0?1+cl*.58:1+cl*.9)*(1-ant*.08);
    let r=lerp(rho,R0*.6+(rho-R0)*.5,cl);r+=cl*30*u*sm(seg(Math.abs(D2)/DEG,62,115));r*=1+ant*.07-B.k*.05*(1+Math.sin(B.age*34))+.012*cl*Math.sin(t*2.2);r+=2.2*u*cl*Math.sin(D*6-t*2.6);
    return [c+sd*Math.cos(D2)*r,c-Math.sin(D2)*r+cl*7*u,cl];};
  const c0=Math.min(1,closeAt(up)*lower),T=Math.floor(t*40);
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.lineJoin='round';ctx.lineCap='round';
  for(const si of [1,0]){const sd=si?1:-1,A=st.arc[si];if(A.length<2)continue;const out=A.map(a=>Wp(sd,a.rout,a.D)),inn=A.map(a=>Wp(sd,a.rin,a.D));
    const path=()=>{ctx.beginPath();out.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));for(let i=inn.length-1;i>=0;i--)ctx.lineTo(inn[i][0],inn[i][1]);ctx.closePath();};
    if(c0>.02){// dark glass between her strands, darker toward her, and the shadow it throws on her
      path();const gr=ctx.createRadialGradient(c,c+8*u,R0*.55,c,c+8*u,R0*1.5);gr.addColorStop(0,'rgba(34,0,40,.7)');gr.addColorStop(.55,'rgba(84,0,92,.52)');gr.addColorStop(1,'rgba(190,0,196,.3)');
      ctx.save();ctx.globalAlpha=sm(c0);ctx.shadowColor=`rgba(0,0,0,${.45*c0})`;ctx.shadowBlur=9*u;ctx.shadowOffsetY=6*u;ctx.fillStyle=gr;ctx.fill();ctx.restore();}
    // her own wing, bent: a fan of small pieces of her picture, each moved to where the wrap puts it
    const NR=4;for(let i=0;i<A.length-1;i++)for(let j=0;j<NR;j++){const a=A[i],b=A[i+1],ra0=lerp(a.rin-3*u,a.rout,j/NR),ra1=lerp(a.rin-3*u,a.rout,(j+1)/NR),rb0=lerp(b.rin-3*u,b.rout,j/NR),rb1=lerp(b.rin-3*u,b.rout,(j+1)/NR);
      const s0=[c+sd*Math.cos(a.D)*ra0,c-Math.sin(a.D)*ra0],s1=[c+sd*Math.cos(a.D)*ra1,c-Math.sin(a.D)*ra1],s2=[c+sd*Math.cos(b.D)*rb1,c-Math.sin(b.D)*rb1],s3=[c+sd*Math.cos(b.D)*rb0,c-Math.sin(b.D)*rb0];
      const d0=Wp(sd,ra0,a.D),d1=Wp(sd,ra1,a.D),d2=Wp(sd,rb1,b.D),d3=Wp(sd,rb0,b.D);tri(ctx,st.comp,s0,s1,s2,d0,d1,d2);tri(ctx,st.comp,s0,s2,s3,d0,d2,d3);}
    if(c0>.05){ctx.beginPath();out.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));ctx.strokeStyle=`rgba(${PALE},${Math.min(1,.55*c0+.4*B.k)})`;ctx.lineWidth=Math.max(1,1.6*u);ctx.stroke();
      ctx.beginPath();inn.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));ctx.strokeStyle=`rgba(${MAG},${.5*c0})`;ctx.lineWidth=Math.max(1,1.2*u);ctx.stroke();
      // plates zip on from the bottom of each wing to the top once it has closed, and flicker out as she lowers it
      ctx.lineJoin='miter';ctx.lineWidth=Math.max(1,1.3*u);
      for(const hc of st.hex[si]){const f=(hc.D/DEG+80)/150,tp=.95+f*.6;if(up<tp||down>.12)continue;let vis=(up<tp+.12||down>0)?(h1(hc.i+si*50,T)>.45?1:.2):1;
        const ctr=Wp(sd,hc.rc,hc.D),hx=c+Math.cos(B.ang)*R0*1.2,hy=c+Math.sin(B.ang)*R0*1.2,n=Math.floor(Math.hypot(ctr[0]-hx,ctr[1]-hy)/(24*u)),ph=B.age*15-n,hit=B.age>=0&&B.age<.9&&ph>0?Math.max(0,1-ph/2.4)*Math.exp(-B.age*1.2):0;
        if(B.age>=0&&B.age<.5&&h1(hc.i+77,T)<.3*(1-B.age/.5))vis*=.15;
        ctx.beginPath();for(let v=0;v<6;v++){const an=Math.PI/6+v*Math.PI/3,q=Wp(sd,hc.rc+Math.sin(an)*hc.r*.93,hc.D+Math.cos(an)*hc.r*.93/hc.rc);v?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]);}ctx.closePath();
        ctx.fillStyle=`rgba(${hit>.3?PALE:MAG},${((.07+.32*hit)*vis).toFixed(3)})`;ctx.fill();ctx.strokeStyle=`rgba(${hit>.35?PALE:MAG},${(Math.min(1,.6+.5*hit)*vis).toFixed(3)})`;ctx.stroke();}
      ctx.lineJoin='round';
      // a point of light runs up each outer edge, laying the plates
      const ride=seg(up,.95,1.55);if(ride>0&&ride<1){const q=out[Math.min(out.length-1,Math.floor(ride*(out.length-1)))],gr=ctx.createRadialGradient(q[0],q[1],0,q[0],q[1],14*u);gr.addColorStop(0,'rgba(255,208,255,.95)');gr.addColorStop(1,`rgba(${MAG},0)`);ctx.fillStyle=gr;ctx.beginPath();ctx.arc(q[0],q[1],14*u,0,TAU);ctx.fill();}}
  }
  ctx.restore();
}
/** One small triangle of `img` (s0,s1,s2) drawn where the wrap puts it (d0,d1,d2). */
function tri(ctx,img,s0,s1,s2,d0,d1,d2){
  const x0=s0[0],y0=s0[1],x1=s1[0],y1=s1[1],x2=s2[0],y2=s2[1],u0=d0[0],v0=d0[1],u1=d1[0],v1=d1[1],u2=d2[0],v2=d2[1],den=x0*(y1-y2)+x1*(y2-y0)+x2*(y0-y1);if(Math.abs(den)<1e-6)return;
  const a=(u0*(y1-y2)+u1*(y2-y0)+u2*(y0-y1))/den,cc=(u0*(x2-x1)+u1*(x0-x2)+u2*(x1-x0))/den,e=(u0*(x1*y2-x2*y1)+u1*(x2*y0-x0*y2)+u2*(x0*y1-x1*y0))/den;
  const b=(v0*(y1-y2)+v1*(y2-y0)+v2*(y0-y1))/den,dd=(v0*(x2-x1)+v1*(x0-x2)+v2*(x1-x0))/den,ff=(v0*(x1*y2-x2*y1)+v1*(x2*y0-x0*y2)+v2*(x0*y1-x1*y0))/den;
  const cx=(u0+u1+u2)/3,cy=(v0+v1+v2)/3;ctx.save();ctx.beginPath();
  for(const [uu,vv] of [d0,d1,d2]){const L=Math.hypot(uu-cx,vv-cy)+.001;ctx.lineTo(uu+(uu-cx)/L*.6,vv+(vv-cy)/L*.6);}
  ctx.closePath();ctx.clip();ctx.transform(a,b,cc,dd,e,ff);ctx.drawImage(img,0,0);ctx.restore();
}

/** Paint the style `sh.style` (not the weave) onto the shield surface: a square of half-side `half` world px at k px each. */
export function paintShieldStyle(ctx,sh,half,k){
  if(!(sh.amount>.004))return;
  if(sh.style==='rotor')return paintRotor(ctx,sh,half,k);
  if(sh.style==='scalemail')return paintScaleMail(ctx,sh,half,k);
  if(sh.style==='wingwrap')return paintWingWrap(ctx,sh,half,k);
}
