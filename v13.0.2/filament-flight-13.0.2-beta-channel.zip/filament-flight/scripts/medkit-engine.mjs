/** Ellie's Medkit engine: the Battle Medicine / Treat Wounds / Keep on Keeping On! rules,
 * animations, relay writes and chat, without any dialog. The Medkit window
 * (keepsake/medkit-window.mjs) and any other view call the same two functions:
 *
 *   medkitContext({healer, patients}) -> Context
 *   runMedkitPlan(plan, {context?, onProgress?, choose?, notify?}) -> Promise<Result>
 *
 * Context (plain data plus a few helper functions):
 *   {ok:true, single, needsGM,
 *    healer:{token, actor, uuid, name, nameHtml, img, rank, level, chaMod, directiveBonus},
 *    modes:[{id:'battleMedicine'|'directiveOne'|'leadByExample'|'treatWounds', label, available, reason|null,
 *            reasonCode:null|'single'|'self'|'range', needsConfirm:text|null}],
 *    dcOptions:[{rank, label, dc, baseHeal, medicHeal, text}], defaultRank,
 *    medic:{has, cooldown:{remaining, text}|null, bypassAvailable, maxBypass:0|1, cooldownText, bonusByRank:{rank:hp}},
 *    patients:[{id, token, actor, uuid, name, nameHtml, img, hp, maxHp, hpPct, owned, needsGM, distance,
 *               conditions:[slug], immune:{status:'none'|'immune'|'unlabeled', effectId, remaining, text, until}}],
 *    maxPatients:4,
 *    animation:{available, previewAvailable, enabled, options, freeBits:[station], v7:{medkit, variation},
 *               catalog:[{id, label, description, group:'random'|'original'|'restorative'|'legacy', enabled}],
 *               groups:[[groupLabel, [[id,label]]]], details:{id:text}, soundStages:{stage:label},
 *               normalize(value), normalizeAudio(value), resolve(options)},
 *    preferences:{animation:boolean, options, together:boolean, chatCards:boolean (Keepsake chat cards; default off)},
 *    savePreference(key:'animation'|'options'|'together', value) -> Promise<boolean>}
 *   or {ok:false, error:{level:'warn'|'error', message}}.
 *
 * Plan:
 *   {mode:'battleMedicine'|'directiveOne'|'leadByExample'|'treatWounds', rank:1-4, together:true|false,
 *    riskySurgery?:boolean (Treat Wounds, with the feat),
 *    patients?:[patientId] (default: every context patient, in order),
 *    unlabeledFromHealer?:[patientId] (unlabeled immunities the user says are Yvaelle's),
 *    medicBypassFor?:patientId|null, animation?:{enabled:boolean, options}}
 *   Treat Wounds has its own immunity (1 hour; 10 minutes with Continual
 *   Recovery), which Medic Dedication cannot bypass. patients[].immunities
 *   holds both; patients[].immune is the Battle Medicine one.
 *   With several patients only Battle Medicine and Treat Wounds are available. Up to four are
 *   treated (lowest HP % first); immune patients are skipped unless the one
 *   Medic Dedication bypass is spent on them.
 *
 * Progress events, passed to onProgress({type, ...}):
 *   start {patients:[id], skipped:[{id, reason:'immune'|'limit', text}]}
 *   animation {patient, bits:[station]}      rolling {patients:[id], reroll:null|'hero'|'free'}
 *   rolled {patients:[id], total, degree, outcome}
 *   medicBypass {patient, cooldown}          immunity {patient, status:'created'|'retained'|'removeFailed', text}
 *   healing {patient, amount}                harm {patient, amount}
 *   directive {patient, bonus}               done {result}          error {message}
 * choose({type:'reroll', patients, names, degree, failureText, heroPoints}) -> 'hero'|'free'|'continue'
 * (default 'continue'); notify(level, message) defaults to ui.notifications.
 *
 * Result:
 *   {ok, cancelled, error|null, mode, together, rank, dc,
 *    rolls:[{patients:[id], total, degree, outcome, reroll:null|'hero'|'free'}],
 *    patients:[{id, name, status:'treated'|'immune'|'limit', outcome|null, check|null, healing, harm,
 *               immunity:{status, text}|null, directive, medicBypass, bits:[station], text|null}],
 *    medicBypass:{patient, cooldown}|null}
 */
import {medkitRequest} from './medkit-relay.mjs?v=13.0.2';
import {keepsakeCard,estimateAfter,hpSnapshot} from './medkit-cards.mjs?v=13.0.2';
import {classicTreatmentStyle} from './v7-medical-work.mjs?v=13.0.2';

const FLAG_SCOPE='world',FLAG_KEY='yvaelleSmartBattleMedicine',HEALER_NAME='Yvaelle';
const DAY_SECONDS=86400,TEN_MINUTES_SECONDS=600,MAX_PATIENTS=4;
// Ellie's Medkit effect icons (v10 beta.16), shipped with the module.
const ICON_DIR='modules/filament-flight/assets/medkit';
const ICONS=Object.freeze({battleMedicine:`${ICON_DIR}/battle-medicine-immunity.webp`,leadByExample:`${ICON_DIR}/lead-by-example-immunity.webp`,
  treatWounds:`${ICON_DIR}/treat-wounds-immunity.webp`,directive:`${ICON_DIR}/keep-on-keeping-on.webp`,medicBypass:`${ICON_DIR}/medic-bypass-used.webp`});
const MEDIC_BYPASS_ICON=ICONS.medicBypass,DIRECTIVE_PENDING_ICON=ICONS.directive;
const COOLDOWN_NAME='Medic Dedication - Immunity Bypass Used';
/** The two Medicine actions the Medkit performs. Treat Wounds is the
 * 10-minute, out-of-combat one (Shift on Battle Medicine in the window). */
export const MEDKIT_ACTIONS=Object.freeze({
  battleMedicine:Object.freeze({key:'battleMedicine',name:'Battle Medicine',slug:'battle-medicine',kind:'battle-medicine-immunity',immunityName:'Battle Medicine Immunity - Yvaelle',
    pattern:/battle medicine.*immun/i,traits:['healing','manipulate','skill'],durationText:'1 day',duration:{value:1,unit:'days',seconds:86400}}),
  treatWounds:Object.freeze({key:'treatWounds',name:'Treat Wounds',slug:'treat-wounds',kind:'treat-wounds-immunity',immunityName:'Treat Wounds Immunity',universal:true,
    pattern:/treat\s*wounds.*immun|immun.*treat\s*wounds/i,traits:['exploration','healing','manipulate'],durationText:'1 hour',duration:{value:1,unit:'hours',seconds:3600}})
});
const OUTCOMES=['criticalFailure','failure','success','criticalSuccess'];
const OUTCOME_LABELS={criticalFailure:'Critical failure',failure:'Failure',success:'Success',criticalSuccess:'Critical success'};
const PREFERENCE_KEYS={animation:'ellieMedkitBitAnimation',options:'ellieMedkitBitAnimationOptions',together:'ellieMedkitTogether',chatCards:'ellieMedkitKeepsakeCards'};
const SINGLE_DIRECTIVE='Keep on Keeping On! directs a single ally; target one creature to use it.';
const RELEVANT_CONDITIONS=new Set(['dying','wounded','doomed','unconscious','drained','persistent-damage']);
export const MEDKIT_MAX_PATIENTS=MAX_PATIENTS;
/** (13.0.2) How many Treat Wounds reaches at once: one, or with Ward Medic two (expert), four (master), eight (legendary).
 * rank: her Medicine proficiency, 1 trained to 4 legendary. (Battle Medicine keeps the table's own limit of four.) */
export const treatWoundsPatients=(rank,wardMedic)=>!wardMedic?1:rank>=4?8:rank>=3?4:rank>=2?2:1;
export const ORIGINAL_BIT_STYLES=[["suture","Suture weave"],["lattice","Lattice reconstruction"],["compression","Compression seal"],["precision","Precision instruments"],["microloom","Microloom dressing"],["vascular","Perfusion channels"],["helix","Helical traction"],["splint","Articulated splints"],["membrane","Protective membrane"],["resonance","Resonant alignment"]];
export const RESTORATIVE_BIT_STYLES=[["pulseHalo","Restorative tide"],["mendingVeil","Mending veil"],["renewalSpiral","Renewal spiral"],["heartline","Steady heartline"],["threadbind","Soul threads"],["crystalCast","Crystalline cast"],["wingSuture","Wing-thread suture"]];
export const V7_BIT_STYLES=[["capillaryBridge","Restorative infusion"],["irisPatch","Pressure mend"],["segmentedCradle","Alignment brace"],["lymphaticCircuit","Cleanse and flush"],["fibrilRepair","Fiber knit"],["tissueLens","Precision mend"],["pulseReservoir","Reviving cadence"],["petalSanctuary","Protective dressing"]];
export const BIT_STYLE_DETAILS=Object.freeze({"suture":"Bevelled hardlight margins support a diagonal seam. Needle holders follow the working contacts while bowed stitch loops are individually tensioned.","lattice":"Interlocking ribs reconstruct a temporary supporting lattice while a diagnostic rung follows the patient.","compression":"Independent hardlight petals form a pressure enclosure around a focused seal, then close only when treatment succeeds.","precision":"A sterile work surface supports two distinct instruments. Focused contact glows follow their measurements and treatment.","microloom":"A dimensional loom suspends a curved woven dressing. Its eye-shaped shuttle draws thread from a side bobbin through alternating over-and-under crossings.","vascular":"Paired reservoirs feed a branching perfusion circuit. Fluid packets pass through opening gates into active terminal wells.","helix":"Opposing collars establish an axis. Broad helical ribbons rotate through front and rear depth while carrying energy along the patient.","splint":"Paired hinged braces carry broad bevelled pressure pads, inset rails and pivot caps. Depth-separated support bands wrap around the patient while alignment is monitored.","membrane":"A diagnostic wave maps the patient. A translucent enclosure maintains circulating repair waves until the result closes or releases it.","resonance":"Paired instruments maintain a standing diagnostic field and align it into a stable line only on successful treatment.","pulseHalo":"The bits aim their emitters toward the patient and release restorative waves through a maintained field. A successful treatment gathers the final wave inward.","mendingVeil":"Two lofted translucent sheets carry folded hems and curved contours. A luminous bonding front follows the draped surface while the centre stays open.","renewalSpiral":"The bits establish opposing projection points and drive ascending currents around the patient. The spiral resolves into a gentle restoration pulse on success.","heartline":"The instruments maintain a measured diagnostic line around the patient, feeding each restorative pulse from their cores before settling with the treatment result.",
  crystalCast:"The bits set hardlight crystal plates over the wound one row at a time while a bright setting line runs down the cast. A success fuses the plates into one smooth shell; a failure cracks them apart.",
  wingSuture:"Long filaments drawn from her wings feed a needle of light that whip-stitches a curved seam. The bits hold the margins and guide the thread; a success pulls the seam closed.",
  threadbind:"Her magenta filament threads lace across the wound from anchor to anchor. The bits carry the thread ends side to side, and a bright knot runs the lacing as it draws tight; a success cinches it into one clean seam.",
  capillaryBridge:"The bits charge and aim their apertures, then feed restorative droplets through short hardlight braids into a compact repair contact. Other bits regulate and verify the flow.",
  irisPatch:"Two bit-projected contact pads bring small repair margins together and press a soft local patch into place. Extra bits hold the edge while the working pair seals it.",
  segmentedCradle:"The bits grip and align a compact repair region with short luminous tools. A supported local strip seats between their actual working contacts.",
  lymphaticCircuit:"One bit draws spent flecks from the treatment contact into its aperture while another washes the same area and returns a clean restorative pulse.",
  fibrilRepair:"The bits guide and tension a few fine projected stitches across a small seam. Their needle tips follow the actual contacts; support bits hold the margins.",
  tissueLens:"A focused bit-projected nib traces a narrow local repair. Its partner steadies the contact while additional bits inspect the same treated region.",
  pulseReservoir:"The apertures charge before delivering measured restorative fronts. The bits press and release in a coordinated cadence around one compact contact.",
  petalSanctuary:"The bits draw, hold and smooth a small transparent dressing over the repair. Working contacts seat its curved edge while extra bits support the corners.",
  random:"Chooses one available treatment style each time you treat or preview. The chosen style stays the same throughout that animation. Random sound settings override that style's saved sound settings."});
export const BIT_SOUND_STAGES=Object.freeze({depart:"Deploy",scan:"Scan",tool:"Treatment",success:"Success",criticalSuccess:"Exceptional success",failure:"Incomplete treatment",criticalFailure:"Disengage",return:"Return"});

export const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const effectItems=actor=>actor.itemTypes?.effect??actor.items.filter(item=>item.type==='effect');
const customData=effect=>effect.flags?.[FLAG_SCOPE]?.[FLAG_KEY]??null;
const active=effect=>effect&&!effect.isExpired&&!(effect.remainingDuration?.expired??false);
const remainingSeconds=effect=>{const value=Number(effect?.remainingDuration?.remaining);return Number.isFinite(value)?value:Infinity;};
export function formatRemaining(seconds){
  if(!Number.isFinite(seconds))return 'an unknown duration';
  const unit=(n,word)=>`${n} ${word}${n===1?'':'s'}`;
  if(seconds>=86400)return unit(Math.ceil(seconds/86400),'day');
  if(seconds>=3600)return unit(Math.ceil(seconds/3600),'hour');
  if(seconds>=60)return unit(Math.ceil(seconds/60),'minute');
  return `${Math.max(1,Math.ceil(seconds))} seconds`;
}
const tokenId=token=>token?.id??token?.document?.id??null;
const tokenName=token=>String(token?.name??token?.document?.name??token?.actor?.name??'Patient');

/** (13.0.2) Any Treat Wounds immunity on an actor, whoever treated them: the Medkit's own (from any healer), or any effect
 * named or slugged as one (the system's, another module's, one made by hand). Null when there is none. */
export function treatWoundsImmunity(actor){
  try{const act=MEDKIT_ACTIONS.treatWounds;return effectItems(actor).filter(active).find(effect=>customData(effect)?.kind===act.kind||act.pattern.test(String(effect.name??''))||/treat-wounds-immun/.test(String(effect.slug??effect.system?.slug??'')))??null;}catch{return null;}
}
/** Yvaelle's immunity on one patient: tagged, by origin, or unlabeled. Treat Wounds is not hers alone: a creature treated
 * by anyone cannot be treated again by anyone until it ends, so any Treat Wounds immunity found there counts (13.0.2). */
function findImmunity(patient,healer,act=MEDKIT_ACTIONS.battleMedicine){
  if(act.universal)return {effect:treatWoundsImmunity(patient),generic:null};
  const effects=effectItems(patient).filter(active);
  const tagged=effects.find(effect=>{const data=customData(effect);return data?.kind===act.kind&&data?.healerActorUuid===healer.uuid;});
  if(tagged)return {effect:tagged,generic:null};
  const named=effect=>act.pattern.test(String(effect.name??''));
  const byOrigin=effects.find(effect=>named(effect)&&effect.system?.context?.origin?.actor===healer.uuid);
  if(byOrigin)return {effect:byOrigin,generic:null};
  return {effect:null,generic:effects.find(effect=>named(effect)&&!effect.system?.context?.origin?.actor)??null};
}
const findMedicCooldown=healer=>effectItems(healer).find(effect=>active(effect)&&(customData(effect)?.kind==='medic-bypass-cooldown'||effect.name===COOLDOWN_NAME));
/** Where a token stands now: its document's position, so a move counts as
 * soon as it is made, not when the movement animation ends. */
const standingCenter=token=>{
  // (x and y only: Foundry v14's centre point carries the token's elevation, and the
  // ruler players see measures across the map, so her flying height doesn't add feet)
  try{const c=token?.document?.getCenterPoint?.();if(Number.isFinite(c?.x)&&Number.isFinite(c?.y))return {x:c.x,y:c.y};}catch{}
  const c=token?.center;return c?{x:c.x,y:c.y}:c;
};
const distanceBetween=(a,b)=>{
  try{
    if(globalThis.canvas?.grid?.measurePath){const from=standingCenter(a),to=standingCenter(b);if(from&&to)return canvas.grid.measurePath([from,to]).distance;}
    if(typeof a.distanceTo==='function')return a.distanceTo(b);
  }catch(error){console.warn('Yvaelle Smart Medicine | Distance check failed',error);}
  return null;
};

/** The party's Medkit immunities at a glance (the window's Party view).
 * Party: the PF2e party's members, else the player characters. Read only. */
export function partyImmunities(healerToken){
  const healer=healerToken?.actor;if(!healer)return [];
  let actors=[];
  try{actors=[...(game.actors?.party?.members??[])];}catch{}
  if(!actors.length)actors=(game.actors?.contents??[...(game.actors??[])]).filter(actor=>actor.type==='character'&&actor.hasPlayerOwner);
  if(!actors.some(actor=>actor===healer))actors.unshift(healer);
  const describe=found=>{const effect=found.effect??found.generic;if(!effect)return {status:'none',text:null};
    const remaining=remainingSeconds(effect);return {status:found.effect?'immune':'unlabeled',remaining,text:formatRemaining(remaining)};};
  return actors.map(actor=>{
    const token=globalThis.canvas?.tokens?.placeables?.find(t=>t.actor===actor||t.document?.actorId===actor.id&&t.document?.actorLink)??null;
    return {id:actor.id,uuid:actor.uuid,name:String(token?.name??actor.name),img:token?.document?.texture?.src||actor.prototypeToken?.texture?.src||actor.img||null,actor,token,
      battleMedicine:describe(findImmunity(actor,healer,MEDKIT_ACTIONS.battleMedicine)),treatWounds:describe(findImmunity(actor,healer,MEDKIT_ACTIONS.treatWounds))};
  });
}

/** Preference queue shared by every Medkit view in this client. */
let preferenceWrite=Promise.resolve(),preferenceFailureNotified=false;
const samePreference=(current,next)=>next&&typeof next==='object'&&!Array.isArray(next)
  ?!!current&&typeof current==='object'&&Object.keys(next).every(key=>samePreference(current[key],next[key]))
  :Object.is(current,next);

function animationSetup(healerToken){
  const moduleApi=game.modules?.get('filament-flight')?.api,bitApi=moduleApi?.bits;
  let v7Medkit=false,v7Variation=false;
  try{
    if(Number(String(moduleApi?.version??'0').split('.')[0])>=7){
      let appearance;try{appearance=moduleApi.getState?.(healerToken)?.v7;}catch{}
      let enabled=appearance?.enabled,medkit=appearance?.medkit,variants=appearance?.transitionVariants;
      if(enabled==null)try{enabled=game.settings?.get('filament-flight','v7Enabled');}catch{}
      if(medkit==null)try{medkit=game.settings?.get('filament-flight','v7Medkit');}catch{}
      if(variants==null)try{variants=game.settings?.get('filament-flight','v7TransitionVariants');}catch{}
      v7Medkit=enabled!==false&&medkit!==false;v7Variation=v7Medkit&&variants!==false;
    }
  }catch(error){console.warn("Ellie's Medkit | Could not read animation preferences",error);}
  const groups=[['Original treatments',ORIGINAL_BIT_STYLES],['Restorative bit treatments',RESTORATIVE_BIT_STYLES],...(v7Medkit?[['Legacy · compact treatments',V7_BIT_STYLES]]:[])];
  const styles=groups.flatMap(([,list])=>list),known=style=>style==='random'||styles.some(([id])=>id===style);
  const normalizeAudio=(value={})=>{
    const number=(input,fallback,min,max)=>input!==''&&input!=null&&Number.isFinite(Number(input))?Math.max(min,Math.min(max,Number(input))):fallback;
    const sounds={};
    for(const stage of Object.keys(BIT_SOUND_STAGES)){const src=value?.sounds?.[stage];if(typeof src==='string'&&src.length<=2048&&!/[\u0000-\u001f]/.test(src)&&!/^\s*(?:javascript|data|file|blob):/i.test(src)&&src.trim())sounds[stage]=src.trim();}
    return {volume:number(value?.volume,1,0,1),radius:number(value?.radius,20,1,240),sounds};
  };
  // With the newer treatments off, a saved compact style is shown as its
  // classic fallback and is kept on save unless the user picks another.
  const normalize=(value={})=>{
    const bounded=(input,fallback,min,max)=>{if(input===''||input==null)return fallback;const n=Number(input);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):fallback;};
    const audioProfiles={};
    for(const [style] of [['random','Random'],...styles])if(value?.audioProfiles?.[style]){const profile=normalizeAudio(value.audioProfiles[style]);if(profile.volume!==1||profile.radius!==20||Object.keys(profile.sounds).length)audioProfiles[style]=profile;}
    const count=['number','string'].includes(typeof value?.bits)?Number(value.bits):NaN;
    return {style:known(value?.style)?value.style:typeof value?.style==='string'&&known(classicTreatmentStyle(value.style))?classicTreatmentStyle(value.style):'suture',
      bits:[1,2,3,4].includes(count)?count:2,intensity:bounded(value?.intensity,1,.25,2),scale:bounded(value?.scale,1,.5,1.75),
      detail:['low','standard','high'].includes(value?.detail)?value.detail:'standard',audio:value?.audio===true,diagnosticScan:value?.diagnosticScan!==false,
      ...(v7Medkit?{enhanced:value?.enhanced!==false,variation:v7Variation&&value?.variation!==false}:{}),
      ...(Object.keys(audioProfiles).length?{audioProfiles}:{})};
  };
  const resolve=options=>{
    const {audioProfiles,...animation}=options,random=animation.style==='random';
    if(random){const pool=styles.filter(([id])=>!V7_BIT_STYLES.some(([v7])=>v7===id));animation.style=pool[Math.floor(Math.random()*pool.length)]?.[0]??'suture';}
    const audioSettings=(random?audioProfiles?.random:null)??audioProfiles?.[animation.style];
    return {...animation,...(audioSettings?{audioSettings}:{})};
  };
  let enabled=true,options=normalize(),together=true,chatCards=false,savedUnknownStyle=null;
  try{
    enabled=game.user.getFlag?.('world',PREFERENCE_KEYS.animation)!==false;
    const saved=game.user.getFlag?.('world',PREFERENCE_KEYS.options);
    if(typeof saved?.style==='string'&&!known(saved.style))savedUnknownStyle=saved.style;
    options=normalize(saved);
    together=game.user.getFlag?.('world',PREFERENCE_KEYS.together)!==false;
    chatCards=game.user.getFlag?.('world',PREFERENCE_KEYS.chatCards)===true;
  }catch(error){console.warn("Ellie's Medkit | Could not read animation preferences",error);}
  const savePreference=(name,value)=>{
    const key=PREFERENCE_KEYS[name]??name;
    if(key===PREFERENCE_KEYS.options&&savedUnknownStyle&&value?.style===normalize({style:savedUnknownStyle}).style)value={...value,style:savedUnknownStyle};
    preferenceWrite=preferenceWrite.then(async()=>{
      if(typeof game.user.setFlag!=='function')throw new Error('User preference storage is unavailable.');
      // setFlag merges objects, so an unchanged subset needs no User update.
      if(!samePreference(game.user.getFlag?.('world',key),value))await game.user.setFlag('world',key,value);
      preferenceFailureNotified=false;return true;
    }).catch(error=>{
      console.warn("Ellie's Medkit | Could not save animation preference",error);
      if(!preferenceFailureNotified)ui.notifications.warn('Animation preferences were not remembered. Your current treatment choices still apply; retry from the menu to save them.');
      preferenceFailureNotified=true;return false;
    });
    return preferenceWrite;
  };
  let freeBits=['leftUpper','rightUpper','leftLower','rightLower'];
  try{const state=bitApi?.getState?.(healerToken);if(Array.isArray(state?.allocations))freeBits=state.allocations.filter(bit=>bit.actionKind!=='treatment').map(bit=>bit.id);}catch{}
  const groupOf=id=>ORIGINAL_BIT_STYLES.some(([s])=>s===id)?'original':RESTORATIVE_BIT_STYLES.some(([s])=>s===id)?'restorative':'legacy';
  const catalog=[{id:'random',label:'Random · each use',description:BIT_STYLE_DETAILS.random,group:'random',enabled:true},
    ...[...ORIGINAL_BIT_STYLES,...RESTORATIVE_BIT_STYLES,...V7_BIT_STYLES].map(([id,label])=>({id,label,description:BIT_STYLE_DETAILS[id]??'',group:groupOf(id),enabled:styles.some(([s])=>s===id)}))];
  return {moduleApi,bitApi,savePreference,preferences:{animation:enabled,options,together,chatCards},
    animation:{available:typeof bitApi?.treat==='function',previewAvailable:typeof moduleApi?.previewTreatment==='function',enabled,options,freeBits,
      v7:{medkit:v7Medkit,variation:v7Variation},catalog,groups,details:BIT_STYLE_DETAILS,soundStages:BIT_SOUND_STAGES,normalize,normalizeAudio,resolve}};
}

/** Everything a Medkit view needs before acting. No writes. */
export function medkitContext({healer:healerToken,patients:patientTokens=[]}={}){
  const fail=(level,message)=>({ok:false,error:{level,message}});
  const tokens=[...new Set(patientTokens)].filter(Boolean);
  if(!healerToken)return fail('warn','Select exactly one healer token.');
  if(!tokens.length)return fail('warn','Target exactly one creature.');
  const healer=healerToken.actor;
  if(!healer||tokens.some(token=>!token.actor))return fail('error','Could not find the healer or target actor.');
  if(!healer.isOwner)return fail('error','You do not have permission to update the healer.');
  const needsGM=!game.user.isGM&&tokens.some(token=>!token.actor.isOwner);
  if(needsGM&&!game.users.activeGM)return fail('error','A GM must be connected so Yvaelle can affect a token you do not own.');
  const allItems=healer.items?.contents??[...healer.items],feats=healer.itemTypes?.feat??allItems.filter(item=>item.type==='feat');
  const battleMedicine=feats.find(item=>item.slug==='battle-medicine'||/^battle medicine$/i.test(item.name));
  const medicDedication=feats.find(item=>item.slug==='medic-dedication'||/^medic dedication$/i.test(item.name));
  const directiveItem=allItems.find(item=>item.slug==='keep-on-keeping-on'||/keep on keeping on/i.test(item.name));
  const featBy=(slug,name)=>feats.find(item=>item.slug===slug||name.test(item.name??''));
  const riskySurgery=featBy('risky-surgery',/^risky surgery$/i),continualRecovery=featBy('continual-recovery',/^continual recovery$/i),wardMedic=featBy('ward-medic',/^ward medic$/i);
  if(!battleMedicine)return fail('error','The selected healer does not appear to have Battle Medicine.');
  const medicine=healer.getStatistic?.('medicine')??healer.skills?.medicine;
  if(!medicine)return fail('error',"Could not find the healer's Medicine statistic.");
  const rank=Number(medicine.rank??0);
  if(rank<1)return fail('error','The healer must be trained in Medicine.');
  const level=Number(healer.level??healer.system?.details?.level?.value??0),chaMod=Number(healer.abilities?.cha?.mod??healer.system?.abilities?.cha?.mod??0);
  const directiveBonus=chaMod+Math.floor(level/2);
  const pwol=!!game.pf2e?.settings?.variants?.pwol?.enabled,dcByRank=pwol?[null,15,20,25,30]:[null,15,20,30,40];
  const tiers=[[1,'Trained',0,0],[2,'Expert',10,5],[3,'Master',30,10],[4,'Legendary',50,15]].map(([r,label,baseHeal,medicHeal])=>({rank:r,label,dc:dcByRank[r],baseHeal,medicHeal}));
  const dcOptions=tiers.filter(tier=>rank>=tier.rank).map(tier=>{
    const extras=[tier.baseHeal?`+${tier.baseHeal} healing`:null,medicDedication&&tier.medicHeal?`+${tier.medicHeal} Medic`:null].filter(Boolean).join(', ');
    return {...tier,text:`${tier.label} - DC ${tier.dc}${extras?` (${extras})`:''}`};
  });
  const cooldown=findMedicCooldown(healer);
  const medic={has:!!medicDedication,cooldown:cooldown?{remaining:remainingSeconds(cooldown),text:formatRemaining(remainingSeconds(cooldown))}:null,
    bypassAvailable:!!medicDedication&&!cooldown,maxBypass:medicDedication&&!cooldown?1:0,cooldownText:rank>=3?'1 hour':'1 day',
    bonusByRank:medicDedication?Object.fromEntries(tiers.map(tier=>[tier.rank,tier.medicHeal])):{}};
  const now=Number(game.time?.worldTime);
  const immunityOf=(found)=>{const effect=found.effect??found.generic,remaining=effect?remainingSeconds(effect):null;
    return effect?{status:found.effect?'immune':'unlabeled',effectId:effect.id,remaining,text:formatRemaining(remaining),until:Number.isFinite(now)&&Number.isFinite(remaining)?now+remaining:null}
      :{status:'none',effectId:null,remaining:0,text:null,until:null};};
  const patients=tokens.map((token,index)=>{
    const actor=token.actor,found=findImmunity(actor,healer),foundTW=findImmunity(actor,healer,MEDKIT_ACTIONS.treatWounds);
    const hp=actor.system?.attributes?.hp,value=Number(hp?.value),max=Number(hp?.max),name=tokenName(token);
    const conditions=(actor.itemTypes?.condition??[]).map(condition=>condition.slug).filter(slug=>RELEVANT_CONDITIONS.has(slug));
    return {id:tokenId(token)??`patient-${index}`,index,token,actor,uuid:actor.uuid,name,nameHtml:escapeHTML(name),
      img:token.document?.texture?.src||actor.img||null,hp:Number.isFinite(value)?value:null,maxHp:Number.isFinite(max)?max:null,
      hpPct:Number.isFinite(value)&&max>0?value/max:1,owned:!!actor.isOwner,needsGM:!actor.isOwner&&!game.user.isGM,
      distance:distanceBetween(healerToken,token),conditions,
      immune:immunityOf(found),immunities:{battleMedicine:immunityOf(found),treatWounds:immunityOf(foundTW)},
      _immunity:found,_immunities:{battleMedicine:found,treatWounds:foundTW}};
  });
  const single=patients.length===1,first=patients[0];
  const reasonCode=!single?'single':healer===first.actor?'self':Number.isFinite(first.distance)&&first.distance>30?'range':null;
  const directiveReason={single:SINGLE_DIRECTIVE,self:'Keep on Keeping On! targets an ally, so Yvaelle cannot target herself.',range:`Your target is ${Math.round(first.distance)} ft away. Keep on Keeping On! has a range of 30 feet.`}[reasonCode]??null;
  const directive=(id,label)=>({id,label,available:!reasonCode,reason:directiveReason,reasonCode,needsConfirm:directiveItem?null:'Keep on Keeping On! could not be found on Yvaelle\'s actor.'});
  const setup=animationSetup(healerToken);
  const name=String(healerToken.name??healer.name??HEALER_NAME);
  return {ok:true,single,needsGM,maxPatients:MAX_PATIENTS,
    healer:{token:healerToken,actor:healer,uuid:healer.uuid,name,nameHtml:escapeHTML(name),img:healerToken.document?.texture?.src||healer.prototypeToken?.texture?.src||healer.img||battleMedicine.img||'icons/svg/regen.svg',rank,level,chaMod,directiveBonus},
    modes:[{id:'battleMedicine',label:'Battle Medicine',available:true,reason:null,reasonCode:null,needsConfirm:null},directive('directiveOne','Keep on Keeping On! (1 Action)'),directive('leadByExample','Lead by Example (2 Actions)'),
      {id:'treatWounds',label:'Treat Wounds',available:true,reason:null,reasonCode:null,needsConfirm:null}],
    treatWounds:{riskySurgery:!!riskySurgery,continualRecovery:!!continualRecovery,wardMedic:!!wardMedic,immunityText:continualRecovery?'10 minutes':'1 hour',maxPatients:treatWoundsPatients(rank,!!wardMedic)},
    dcOptions,defaultRank:dcOptions[0]?.rank??1,medic,patients,animation:setup.animation,preferences:setup.preferences,savePreference:setup.savePreference,
    _internal:{healerToken,healer,battleMedicine,medicDedication,directiveItem,riskySurgery,continualRecovery,medicine,tiers,moduleApi:setup.moduleApi,bitApi:setup.bitApi}};
}

/** Even split of the free bits: 4 over 2 → 2+2, over 3 → 2+1+1. */
export function splitBits(free,count){
  const out=Array.from({length:count},()=>[]);let next=0;
  for(let i=0;i<count;i++){const share=Math.floor(free.length/count)+(i<free.length%count?1:0);out[i]=free.slice(next,next+share);next+=share;}
  return out;
}

/** Execute a plan. Never throws; failures resolve with ok:false and an error. */
/** (13.0.2) True while the Medkit itself is treating on this page (its own Treat Wounds roll is not one for the guard to stop). */
let medkitRunning=0;
export const medkitBusy=()=>medkitRunning>0;
export async function runMedkitPlan(plan={},hooks={}){
  let dyingBefore=null;try{dyingBefore=readDying(plan.patients);}catch{}
  medkitRunning++;
  try{const result=await runPlan(plan,hooks);try{celebrate(plan,hooks,result,dyingBefore);}catch(error){console.warn("Ellie's Medkit | Chrysalis",error);}return result;}
  catch(error){
    console.error("Ellie's Medkit | Treatment failed",error);
    const message=String(error?.message??error),result={ok:false,cancelled:false,error:message,mode:plan.mode??'battleMedicine',together:plan.together!==false,rank:null,dc:null,rolls:[],patients:[],medicBypass:null};
    try{(hooks.notify??((level,text)=>ui.notifications[level](text)))('error',message);hooks.onProgress?.({type:'error',message});hooks.onProgress?.({type:'done',result});}catch{}
    return result;
  }
  finally{medkitRunning=Math.max(0,medkitRunning-1);}
}
async function runPlan(plan,hooks){
  const context=hooks.context??medkitContext({healer:plan.healer,patients:plan.patients});
  const emit=(type,data={})=>{try{hooks.onProgress?.({type,...data});}catch(error){console.warn("Ellie's Medkit | Progress listener failed",error);}};
  const notify=hooks.notify??((level,message)=>ui.notifications[level](message));
  const choose=hooks.choose??(async()=>'continue');
  const result={ok:false,cancelled:false,error:null,mode:plan.mode??'battleMedicine',together:plan.together!==false,rank:null,dc:null,rolls:[],patients:[],medicBypass:null};
  const finish=()=>{emit('done',{result});return result;};
  const stop=(level,message)=>{if(message){notify(level,message);result.error=message;emit('error',{message});}return finish();};
  if(!context?.ok)return stop(context?.error?.level??'error',context?.error?.message??'The Medkit could not start.');
  const {healerToken,healer,battleMedicine,medicDedication,directiveItem,riskySurgery,continualRecovery,medicine,tiers,bitApi}=context._internal;
  const mode=result.mode,usingLeadByExample=mode==='leadByExample',usingOneActionDirective=mode==='directiveOne',usingTreatWounds=mode==='treatWounds';
  const act=usingTreatWounds?MEDKIT_ACTIONS.treatWounds:MEDKIT_ACTIONS.battleMedicine,actItem=usingTreatWounds?null:battleMedicine;
  const risky=usingTreatWounds&&!!riskySurgery&&plan.riskySurgery===true;
  const modeInfo=context.modes.find(entry=>entry.id===mode);
  if(!modeInfo)return stop('error',`Unknown Medkit mode: ${mode}.`);
  if(!modeInfo.available)return stop('warn',modeInfo.reason);
  const wanted=plan.patients?.length?plan.patients.map(entry=>typeof entry==='string'?entry:tokenId(entry)):context.patients.map(p=>p.id);
  const chosen=context.patients.filter(p=>wanted.includes(p.id)).sort((a,b)=>wanted.indexOf(a.id)-wanted.indexOf(b.id));
  if(!chosen.length)return stop('warn','Target exactly one creature.');
  const single=chosen.length===1,together=single||plan.together!==false;result.together=together;
  const speaker=ChatMessage.getSpeaker({actor:healer,token:healerToken.document});
  // Keepsake chat cards: optional, the regular PF2e cards unless turned on.
  const themed=(plan.chatCards??context.preferences?.chatCards)===true;
  const patientImg=patient=>patient.token?.document?.texture?.src||patient.img||patient.actor?.img||null;

  // Writes: owned documents directly, others through the GM relay.
  const callGM=async payload=>{
    try{return await medkitRequest(payload.action,{...payload,healerUuid:healer.uuid});}
    catch(error){console.error('Yvaelle’s Toolbox | Medkit GM relay failed',error);throw new Error(`The GM could not update the target: ${error?.message??error}`);}
  };
  const deleteActorItems=async(actor,ids)=>{
    const cleanIds=[...new Set((ids??[]).filter(Boolean))];if(!cleanIds.length)return 0;
    if(actor.isOwner||game.user.isGM){await actor.deleteEmbeddedDocuments('Item',cleanIds);return cleanIds.length;}
    // The relay removes only this healer's Medkit effects and reports how many.
    return Number(await callGM({action:'deleteItems',actorUuid:actor.uuid,ids:cleanIds}))||0;
  };
  const createEffect=async(actor,source)=>{
    if(actor.isOwner||game.user.isGM){const created=await actor.createEmbeddedDocuments('Item',[source]);return created?.[0]??null;}
    return await callGM({action:'createEffect',actorUuid:actor.uuid,source});
  };
  const cleanExpiredEffects=async actor=>{const ids=effectItems(actor).filter(effect=>customData(effect)&&!active(effect)).map(effect=>effect.id);if(ids.length)await deleteActorItems(actor,ids);};
  const makeEffectSource=({name,img,description,duration,flag,target=null,originItem=null,roll=null})=>({name,type:'effect',img:img||DIRECTIVE_PENDING_ICON,
    system:{description:{value:description},duration:{value:duration.value,unit:duration.unit,expiry:'turn-start',sustained:false},level:{value:Math.max(1,context.healer.level)},rules:[],start:{value:0,initiative:null},tokenIcon:{show:true},traits:{value:[]},fromSpell:false,
      context:{origin:{actor:healer.uuid,token:healerToken.document?.uuid??null,item:originItem?.uuid??null,spellcasting:null,rollOptions:[]},
        target:target?{actor:target.actor.uuid,token:target.document?.uuid??null}:null,
        roll:roll?{total:Number(roll.total??0),degreeOfSuccess:Number(roll.degreeOfSuccess??0)}:null}},
    flags:{[FLAG_SCOPE]:{[FLAG_KEY]:flag}}});
  const directiveBonus=context.healer.directiveBonus;
  const findPendingDirective=patient=>effectItems(patient.actor).filter(effect=>active(effect)&&customData(effect)?.kind==='keep-on-keeping-on-pending'&&customData(effect)?.healerActorUuid===healer.uuid);
  const applyPendingDirective=async(patient,{roll=null,fromFailedBattleMedicine=false}={})=>{
    const oldPending=findPendingDirective(patient).map(effect=>effect.id);if(oldPending.length)await deleteActorItems(patient.actor,oldPending);
    await createEffect(patient.actor,makeEffectSource({name:`Keep on Keeping On! - Next Healing +${directiveBonus}`,img:DIRECTIVE_PENDING_ICON,
      description:`<p>Until the start of <strong>Yvaelle's next turn</strong>, increase the next healing you receive by <strong>${directiveBonus}</strong>.</p>${fromFailedBattleMedicine?'<p>Battle Medicine did not restore HP, so the Directive\'s healing increase was not consumed.</p>':'<p>This bonus is consumed by the next healing you receive.</p>'}<p><em>Remove this effect after the next healing is received.</em></p>`,
      duration:{value:1,unit:'rounds'},target:patient.token,originItem:directiveItem,roll,flag:{kind:'keep-on-keeping-on-pending',healerActorUuid:healer.uuid,healerName:HEALER_NAME,bonus:directiveBonus}}));
    emit('directive',{patient:patient.id,bonus:directiveBonus});
  };

  // 1-action directive: a single ally only (enforced by the mode check).
  if(usingOneActionDirective){
    const patient=chosen[0];
    await cleanExpiredEffects(healer);await cleanExpiredEffects(patient.actor);
    await applyPendingDirective(patient);
    if(themed)await ChatMessage.create({speaker,content:keepsakeCard({kicker:'Directive · 1 action',title:'Keep on Keeping On!',icon:ICONS.directive,tone:'rose',
      patients:[{name:patient.name,img:patientImg(patient),estimate:estimateAfter(patient.actor,0),text:`+${directiveBonus} to the next healing`}],
      footer:["Until the start of Yvaelle's next turn"]})});
    else await ChatMessage.create({speaker,content:`<div class="pf2e chat-card"><header class="card-header flexrow"><h3>Keep on Keeping On!</h3></header><div class="card-content"><p>Yvaelle uses <strong>Keep on Keeping On!</strong>.</p><p>The target increases the <strong>next healing</strong> they receive by <strong>${directiveBonus}</strong>.</p><p><small>This lasts until the start of Yvaelle's next turn.</small></p></div></div>`});
    notify('info',`Keep on Keeping On! applied: +${directiveBonus} to the target's next healing.`);
    result.ok=true;result.patients.push({id:patient.id,name:patient.name,status:'treated',outcome:null,check:null,healing:0,harm:0,immunity:null,directive:true,medicBypass:false,bits:[],text:null});
    return finish();
  }

  const tier=tiers.find(entry=>entry.rank===Number(plan.rank));
  if(!tier||tier.rank>context.healer.rank)return stop('error','Invalid Medicine DC.');
  result.rank=tier.rank;result.dc=tier.dc;
  const modeName=usingLeadByExample?'Keep on Keeping On! - Lead by Example':act.name;
  const shortImmunity=usingLeadByExample||usingTreatWounds&&!!continualRecovery;
  const immunityDurationText=shortImmunity?'10 minutes':act.durationText;
  const newImmunityDuration=shortImmunity?{value:10,unit:'minutes',seconds:TEN_MINUTES_SECONDS}:act.duration;

  // Existing immunity and the Medic Dedication bypass (one per cooldown).
  const unlabeled=new Set(plan.unlabeledFromHealer??[]);
  // Medic Dedication only reaches past Battle Medicine immunity.
  let bypassFor=context.medic.bypassAvailable&&!usingTreatWounds?plan.medicBypassFor??null:null;
  const work=[],skipped=[];
  for(const patient of chosen){
    const found=patient._immunities?.[act.key]??patient._immunity;
    const existing=found.effect??(unlabeled.has(patient.id)?found.generic:null);
    const entry={patient,existing,bypass:false,bits:[],handle:null};
    if(existing){
      if(single){
        if(usingTreatWounds)return stop('warn',`Your target is already immune to Treat Wounds for ${formatRemaining(remainingSeconds(existing))}, whoever treats them.`);
        if(!medicDedication)return stop('warn',"Your target is already immune to Yvaelle's Battle Medicine.");
        if(context.medic.cooldown)return stop('warn',`Your target is already immune to Yvaelle's Battle Medicine, and Medic Dedication's immunity bypass is still unavailable for about ${context.medic.cooldown.text}.`);
        if(bypassFor!==patient.id){result.cancelled=true;return finish();}
      }
      if(bypassFor===patient.id){entry.bypass=true;bypassFor=null;}
      else{skipped.push({patient,reason:'immune',text:`immune for ${formatRemaining(remainingSeconds(existing))}`});continue;}
    }
    work.push(entry);
  }
  // Up to the limit, lowest HP % first; the rest are listed, not treated. (13.0.2: Treat Wounds by the rules: one patient,
  // or Ward Medic's two, four or eight.)
  const limit=usingTreatWounds?Math.max(1,Number(context.treatWounds?.maxPatients)||1):MAX_PATIENTS;
  if(!single)work.sort((a,b)=>a.patient.hpPct-b.patient.hpPct||a.patient.index-b.patient.index);
  for(const entry of work.splice(limit))skipped.push({patient:entry.patient,reason:'limit',text:usingTreatWounds?(limit===1?(context.treatWounds?.wardMedic?'Ward Medic reaches one patient until she is an expert':'Treat Wounds treats one patient without Ward Medic'):`over Ward Medic's ${limit}-patient limit`):`over the ${MAX_PATIENTS}-patient limit`});
  const describeSkip=entry=>({id:entry.patient.id,name:entry.patient.name,status:entry.reason,outcome:null,check:null,healing:0,harm:0,immunity:null,directive:false,medicBypass:false,bits:[],text:entry.text});
  for(const entry of work)entry.hp0=hpSnapshot(entry.patient.actor);
  emit('start',{patients:work.map(entry=>entry.patient.id),skipped:skipped.map(entry=>({id:entry.patient.id,reason:entry.reason,text:entry.text}))});
  if(!work.length){result.patients=skipped.map(describeSkip);return stop('warn',skipped.some(entry=>entry.reason==='limit')&&!skipped.some(entry=>entry.reason==='immune')?'None of the targeted patients can be treated.':`None of the targeted patients can be treated: each is already immune to ${usingTreatWounds?'':"Yvaelle's "}${act.name}.`);}

  // Optional animation. Single target: Lead by Example only, as before.
  // Several patients: Battle Medicine shares the free bits between them.
  const animationWarning=error=>console.warn("Ellie's Medkit | Optional bit animation unavailable",error);
  let animationClosed=false;
  const visualCall=async operation=>{
    let timer;
    try{return await Promise.race([Promise.resolve().then(operation),new Promise((resolve,reject)=>{timer=setTimeout(()=>reject(new Error('Bit animation response timed out')),4000);})]);}
    catch(error){animationWarning(error);return null;}finally{clearTimeout(timer);}
  };
  const cancelBits=async(entry,reason)=>{const handle=entry.handle;entry.handle=null;if(handle)await visualCall(()=>handle.cancel(reason));};
  const finishBits=entry=>{
    const handle=entry.handle;if(!handle)return;entry.handle=null;
    // finish() resolves after the animated return; hand it off without waiting.
    void Promise.resolve().then(()=>handle.finish({outcome:entry.outcome})).catch(error=>{animationWarning(error);void visualCall(()=>handle.cancel('medkit-finish-failed'));});
  };
  // Treat Wounds takes ten minutes: the bits always have time to work.
  const animate=plan.animation?.enabled&&context.animation.available&&(usingTreatWounds||(single?usingLeadByExample:mode==='battleMedicine'));
  if(animate){
    const resolved=context.animation.resolve(context.animation.normalize(plan.animation.options??context.animation.options));
    const shares=single?[null]:splitBits(context.animation.freeBits,work.length);
    for(const [index,entry] of work.entries()){
      if(shares[index]&&!shares[index].length)continue;
      const started=await visualCall(async()=>{
        const handle=await bitApi.treat(healerToken,entry.patient.token,{...resolved,...(shares[index]?{bits:shares[index]}:{}),priority:100,conflict:'queue',timeout:120000,travelDuration:900,returnDuration:800});
        if(animationClosed){if(handle)void visualCall(()=>handle.cancel('medkit-startup-timeout'));return false;}
        entry.handle=handle;
        if(!handle||typeof handle.finish!=='function'||typeof handle.cancel!=='function')throw new Error('Yvaelle’s Toolbox returned an invalid treatment handle');
        Promise.resolve(handle.done).catch(animationWarning);
        return true;
      });
      if(!started)await cancelBits(entry,'medkit-startup-unavailable');
      else{entry.bits=shares[index]??[];emit('animation',{patient:entry.patient.id,bits:entry.bits});}
    }
  }

  try{
    const extraRollOptions=[`action:${act.slug}`,...(usingLeadByExample?['action:keep-on-keeping-on','lead-by-example']:[]),...(risky?['risky-surgery']:[])];
    const Modifier=globalThis.game?.pf2e?.Modifier;
    const riskyModifiers=()=>risky&&Modifier?[new Modifier({slug:'risky-surgery',label:'Risky Surgery',modifier:2,type:'circumstance'})]:[];
    const rollCheck=async({rerollType=null,quiet=false}={})=>{
      let callbackRoll=null;const rollOptions=[...extraRollOptions];
      if(rerollType){rollOptions.push('check:reroll');if(rerollType==='hero')rollOptions.push('check:reroll:hero-points');}
      const title=rerollType==='hero'?`${modeName} - Hero Point Reroll`:rerollType==='free'?`${modeName} - Reroll`:modeName;
      const args={token:healerToken.document,dc:{value:tier.dc,visible:true},action:act.slug,slug:act.slug,title,
        extraRollOptions:rollOptions,traits:act.traits,skipDialog:!!rerollType||quiet,callback:roll=>{callbackRoll=roll;}};
      if(actItem)args.item=actItem;const modifiers=riskyModifiers();if(modifiers.length)args.modifiers=modifiers;
      return (await medicine.roll(args))??callbackRoll;
    };
    // Risky Surgery: a success becomes a critical success.
    const getDegree=roll=>{const d=Number(roll?.degreeOfSuccess??roll?.options?.degreeOfSuccess);return risky&&d===2?3:d;};
    // Together: one check for everyone. Separately: one check each; only the
    // first shows the check dialog, the rest reuse the standard modifiers.
    const groups=together?[{entries:work}]:work.map(entry=>({entries:[entry]}));
    for(const [index,group] of groups.entries()){
      const ids=group.entries.map(entry=>entry.patient.id);emit('rolling',{patients:ids,reroll:null});
      group.roll=await rollCheck({quiet:index>0});
      if(!group.roll){result.cancelled=true;return finish();}
      group.degree=getDegree(group.roll);
    }
    await cleanExpiredEffects(healer);for(const entry of work)await cleanExpiredEffects(entry.patient.actor);
    for(const group of groups){
      const ids=group.entries.map(entry=>entry.patient.id),names=group.entries.map(entry=>entry.patient.name);
      if(![0,1,2,3].includes(group.degree)){console.error('Yvaelle Smart Medicine | Could not determine degree',group.roll);return stop('error','Could not determine the Medicine check result.');}
      group.reroll=null;
      if(group.degree<=1){
        const heroValue=()=>Number(healer.getResource?.('hero-points')?.value??healer.system?.resources?.heroPoints?.value??0);
        const choice=await choose({type:'reroll',patients:ids,names,degree:group.degree,failureText:group.degree===0?'Critical Failure':'Failure',heroPoints:heroValue()})??'continue';
        if(choice==='hero'){
          const current=heroValue();
          if(current<=0)notify('warn','Yvaelle no longer has a Hero Point available. The original failure will continue.');
          else{
            await healer.updateResource('hero-points',current-1);
            let rerolled=null;emit('rolling',{patients:ids,reroll:'hero'});
            try{rerolled=await rollCheck({rerollType:'hero'});}
            catch(error){await healer.updateResource('hero-points',current);console.error('Yvaelle Smart Medicine | Hero Point reroll failed',error);return stop('error','The Hero Point reroll failed. The Hero Point was refunded.');}
            if(!rerolled){await healer.updateResource('hero-points',current);return stop('error','The Hero Point reroll did not produce a roll. The Hero Point was refunded.');}
            group.roll=rerolled;group.degree=getDegree(rerolled);group.reroll='hero';
            notify('info',`Yvaelle spent 1 Hero Point and rerolled ${act.name}.`);
          }
        }else if(choice==='free'){
          emit('rolling',{patients:ids,reroll:'free'});
          const rerolled=await rollCheck({rerollType:'free'});
          if(!rerolled)return stop('error','The reroll did not produce a result.');
          group.roll=rerolled;group.degree=getDegree(rerolled);group.reroll='free';
          notify('info',`${act.name} was rerolled without spending a Hero Point.`);
        }
      }
      if(![0,1,2,3].includes(group.degree)){console.error('Yvaelle Smart Medicine | Invalid final degree',group.roll);return stop('error','Could not determine the final Medicine result.');}
      group.outcome=OUTCOMES[group.degree];
      for(const entry of group.entries){entry.group=group;entry.outcome=group.outcome;}
      result.rolls.push({patients:ids,total:Number(group.roll.total??0),degree:group.degree,outcome:group.outcome,reroll:group.reroll});
      emit('rolled',{patients:ids,total:Number(group.roll.total??0),degree:group.degree,outcome:group.outcome});
    }

    if(usingLeadByExample)for(const entry of work){const old=findPendingDirective(entry.patient).map(effect=>effect.id);if(old.length)await deleteActorItems(entry.patient.actor,old);}

    const bypassEntry=work.find(entry=>entry.bypass);
    if(bypassEntry){
      const cooldownDuration=context.healer.rank>=3?{value:1,unit:'hours'}:{value:1,unit:'days'};
      await createEffect(healer,makeEffectSource({name:COOLDOWN_NAME,img:MEDIC_BYPASS_ICON,
        description:'<p><strong>Medic Dedication immunity bypass has been used.</strong></p><p>Yvaelle cannot use Medic Dedication to ignore Battle Medicine immunity again until this effect expires.</p>',
        duration:cooldownDuration,originItem:medicDedication,roll:bypassEntry.group.roll,flag:{kind:'medic-bypass-cooldown',healerActorUuid:healer.uuid}}));
      result.medicBypass={patient:bypassEntry.patient.id,cooldown:context.medic.cooldownText};
      emit('medicBypass',result.medicBypass);
    }

    // Each patient's own immunity, retaining a longer existing one. (13.0.2) What it will be is settled here, for the cards;
    // it is WRITTEN by commitImmunity: at once where nothing is healed (a failure still spends the treatment), and only
    // after the healing has landed on a success, so that a patient whose HP could not be changed is not left immune.
    for(const entry of work){
      const {existing}=entry,oldRemaining=existing?remainingSeconds(existing):0;
      entry.immunityNote=`${immunityDurationText} immunity applied.`;entry.immunity={status:'created',text:entry.immunityNote};entry.keepExisting=false;entry.immunityDone=false;
      if(existing&&oldRemaining>newImmunityDuration.seconds){
        entry.immunityNote=`Existing longer immunity retained (${formatRemaining(oldRemaining)} remaining).`;entry.immunity={status:'retained',text:entry.immunityNote};entry.keepExisting=true;}
    }
    const commitImmunity=async entry=>{
      if(entry.immunityDone)return;entry.immunityDone=true;const {patient,existing}=entry;
      if(!entry.keepExisting){
        if(existing){
          try{
            const removed=await deleteActorItems(patient.actor,[existing.id]);
            // The GM relay only removes Medkit-tagged effects from this healer.
            if(!removed){notify('warn',single?`The target's existing ${act.name} immunity could not be removed for you. Ask the GM to delete it.`:`${patient.name}'s existing ${act.name} immunity could not be removed for you. Ask the GM to delete it.`);entry.immunity.status='removeFailed';}
          }catch(error){console.warn('Yvaelle Smart Medicine | Could not remove existing immunity',error);}
        }
        await createEffect(patient.actor,makeEffectSource({name:act.immunityName,img:usingTreatWounds?ICONS.treatWounds:usingLeadByExample?ICONS.leadByExample:ICONS.battleMedicine,
          description:usingTreatWounds?`<p><strong>You are temporarily immune to Treat Wounds, whoever treats you.</strong></p><p>Treated by ${escapeHTML(HEALER_NAME)}.</p><p><strong>Duration:</strong> ${immunityDurationText}</p>`
            :`<p><strong>You are temporarily immune to Yvaelle's ${act.name}.</strong></p><p><strong>Duration:</strong> ${immunityDurationText}</p>${usingLeadByExample?'<p>This immunity was created by <strong>Keep on Keeping On! - Lead by Example</strong>.</p>':''}`,
          duration:{value:newImmunityDuration.value,unit:newImmunityDuration.unit},target:patient.token,originItem:usingLeadByExample?directiveItem??battleMedicine:actItem,roll:entry.group.roll,
          flag:{kind:act.kind,healerActorUuid:healer.uuid,healerName:HEALER_NAME,mode:usingLeadByExample?'directive':'regular'}}));
      }
      emit('immunity',{patient:patient.id,status:entry.immunity.status,text:entry.immunity.text});
    };
    /** The healing could not be written: the patient is as they were, and is not made immune, so the treatment can be given again. */
    const notApplied=(entry,error,amount)=>{const why=String(error?.message??error);entry.immunityNote='No immunity set: the healing was not applied.';entry.immunity={status:'none',text:entry.immunityNote};entry.immunityDone=true;
      emit('immunity',{patient:entry.patient.id,status:'none',text:entry.immunityNote});return `${amount} HP of healing could not be applied (${why}). No immunity was set: apply it by hand, or treat again.`;};
    /** (13.0.2) A successful Treat Wounds ends the Wounded condition. Battle Medicine does not. */
    const clearWounded=async(entry)=>{
      if(!usingTreatWounds)return;const actor=entry.patient.actor;
      try{const has=typeof actor.hasCondition==='function'?actor.hasCondition('wounded'):!!actor.itemTypes?.condition?.some(c=>c.slug==='wounded');if(!has)return;
        if(actor.isOwner||game.user.isGM)await actor.decreaseCondition('wounded',{forceRemove:true});
        else await callGM({action:'removeWounded',actorUuid:actor.uuid,medicineAction:act.slug,outcome:entry.outcome});
        entry.woundedCleared=true;emit('wounded',{patient:entry.patient.id});}
      catch(error){console.warn("Ellie's Medkit | Wounded could not be removed",error);notify('warn',`${entry.patient.name} is still Wounded: the condition could not be removed for you. Remove it by hand.`);}
    };
    for(const entry of work)if(!(entry.group.degree>=2))await commitImmunity(entry);

    const DamageRoll=CONFIG.Dice.rolls.find(RollClass=>RollClass.name==='DamageRoll');
    if(!DamageRoll)return stop('error',"Could not find PF2e's DamageRoll class. The Medicine roll was made, but HP could not be changed automatically and no immunity was set for a success.");
    const applicationRollOptions=new Set([`action:${act.slug}`,`origin:action:slug:${act.slug}`,...act.traits.map(trait=>`origin:action:trait:${trait}`),'item:trait:healing',...(usingLeadByExample?['action:keep-on-keeping-on','lead-by-example']:[])]);
    const applyDamage=async(patient,{damage,outcome,final=false,surgery=false})=>{
      const item=surgery?riskySurgery:actItem;
      if(patient.actor.isOwner||game.user.isGM){
        const application={damage,token:patient.token.document,rollOptions:applicationRollOptions,outcome};if(item)application.item=item;if(final)application.final=true;
        await patient.actor.applyDamage(application);return;
      }
      await callGM({action:'applyDamage',actorUuid:patient.actor.uuid,tokenUuid:patient.token.document.uuid,itemUuid:item?.uuid??null,medicineAction:act.slug,surgery,damage,rollOptions:[...applicationRollOptions],outcome,final});
    };
    const medicBonus=medicDedication?tier.medicHeal:0,envoyBonus=usingLeadByExample?directiveBonus:0;
    const breakdown=dice=>[`${act.name}: ${dice}d8`,tier.baseHeal?`${tier.label} DC: +${tier.baseHeal}`:null,medicBonus?`Medic Dedication: +${medicBonus}`:null,usingLeadByExample&&envoyBonus?`Keep on Keeping On!: +${envoyBonus}`:null].filter(Boolean);
    const rolls=[];
    // Risky Surgery: 1d8 slashing to each patient before the healing.
    if(risky){
      const surgery=await new DamageRoll('1d8[slashing]').evaluate();rolls.push(surgery);
      await surgery.toMessage({speaker,flavor:themed?keepsakeCard({kicker:'Treat Wounds',title:'Risky Surgery',icon:ICONS.treatWounds,tone:'gold',lines:[`${single?'The patient takes':'Each patient takes'} 1d8 slashing damage before Treat Wounds heals: +2 to the check, and a success becomes a critical success.`]}):`<strong>Risky Surgery</strong><br>${single?'The patient takes':'Each patient takes'} 1d8 slashing damage before Treat Wounds heals.`,flags:{[game.system.id]:{suppressDamageButtons:true}}});
      for(const entry of work){
        try{await applyDamage(entry.patient,{damage:Number(surgery.total),outcome:entry.outcome,surgery:true});entry.surgery=Number(surgery.total);emit('harm',{patient:entry.patient.id,amount:entry.surgery,surgery:true});}
        catch(error){notify('error',`${entry.patient.name}: ${error?.message??error}`);}
      }
    }
    // Healing and harm are rolled once per check: shared in Together, per patient Separately.
    for(const group of groups){
      if(group.degree>=2){
        const dice=group.degree===3?4:2,flat=tier.baseHeal+medicBonus+envoyBonus;
        group.healing=await new DamageRoll(flat!==0?`(${dice}d8 + ${flat})[healing]`:`${dice}d8[healing]`).evaluate();group.breakdown=breakdown(dice);rolls.push(group.healing);
      }else if(group.degree===0){group.harm=await new DamageRoll('1d8').evaluate();rolls.push(group.harm);}
    }
    const systemFlags={[game.system.id]:{suppressDamageButtons:true}};
    const modeIcon=usingTreatWounds?ICONS.treatWounds:usingLeadByExample?ICONS.leadByExample:ICONS.battleMedicine,tone=usingTreatWounds?'gold':'magenta';
    const kicker=usingTreatWounds?'10 minutes · Medicine':usingLeadByExample?'2 actions · directive':'1 action · Medicine';
    const checkOf=group=>({total:Number(group.roll.total??0),dc:tier.dc,outcome:group.outcome});
    if(single){
      const entry=work[0],group=entry.group,patient=entry.patient;
      result.patients.push(entry.result={id:patient.id,name:patient.name,status:'treated',outcome:entry.outcome,check:Number(group.roll.total??0),healing:0,harm:0,immunity:entry.immunity,directive:false,medicBypass:entry.bypass,bits:entry.bits,text:null});
      if(group.degree>=2){
        const amount=Number(group.healing.total);
        try{await applyDamage(patient,{damage:-amount,outcome:entry.outcome});}
        catch(error){const text=notApplied(entry,error,amount);entry.result.text=text;entry.result.immunity=entry.immunity;await cancelBits(entry,'medkit-heal-failed');return stop('error',`${patient.name}: ${text}`);}
        entry.result.healing=amount;emit('healing',{patient:patient.id,amount});await commitImmunity(entry);await clearWounded(entry);
        await group.healing.toMessage({speaker,flavor:themed?keepsakeCard({kicker,title:modeName,icon:modeIcon,tone,check:checkOf(group),
            patients:[{name:patient.name,img:patientImg(patient),amount,estimate:estimateAfter(patient.actor,amount-(entry.surgery??0),entry.hp0)}],
            footer:[group.breakdown.join(' · '),entry.woundedCleared?'No longer Wounded':null,entry.immunityNote,bypassEntry?'Medic Dedication bypass spent':null]})
          :`<strong>${modeName}</strong><br>Yvaelle treats her target.<br><br>${group.breakdown.join('<br>')}<br><br><small>${entry.woundedCleared?'No longer Wounded. ':''}${entry.immunityNote}</small>`,flags:systemFlags});
        // Only close the treatment after HP application and the final outcome.
        finishBits(entry);
        notify('info',`Your target was healed for ${group.healing.total}.`);
        result.ok=true;return finish();
      }
      if(usingLeadByExample){await applyPendingDirective(patient,{roll:group.roll,fromFailedBattleMedicine:true});entry.result.directive=true;}
      if(group.degree===0){
        const amount=Number(group.harm.total);
        await group.harm.toMessage({speaker,flavor:themed?keepsakeCard({kicker,title:`${act.name} · critical failure`,icon:modeIcon,tone:'worse',check:checkOf(group),
            patients:[{name:patient.name,img:patientImg(patient),harm:amount,estimate:estimateAfter(patient.actor,-amount-(entry.surgery??0),entry.hp0)}],
            lines:usingLeadByExample?[`<b>Keep on Keeping On!</b> +${directiveBonus} to the target's next healing until the start of Yvaelle's next turn.`]:[],footer:['Your target takes 1d8 damage',entry.immunityNote]})
          :`<strong>${act.name} - Critical Failure</strong><br>Your target takes 1d8 damage.<br><br><small>${entry.immunityNote}</small>`,flags:systemFlags});
        await applyDamage(patient,{damage:amount,outcome:entry.outcome,final:true});entry.result.harm=amount;emit('harm',{patient:patient.id,amount});
      }
      if(themed&&group.degree===1)await ChatMessage.create({speaker,content:keepsakeCard({kicker,title:modeName,icon:modeIcon,tone,check:checkOf(group),
          patients:[{name:patient.name,img:patientImg(patient),estimate:estimateAfter(patient.actor,-(entry.surgery??0),entry.hp0),text:'No healing'}],
          lines:usingLeadByExample?[`<b>Keep on Keeping On!</b> +${directiveBonus} to the target's next healing until the start of Yvaelle's next turn.`]:[],
          footer:[entry.immunityNote,bypassEntry?'Medic Dedication bypass spent':null]})});
      else if(!themed)await ChatMessage.create({speaker,content:`<div class="pf2e chat-card"><header class="card-header flexrow"><h3>${modeName}</h3></header><div class="card-content"><p>Your target received no healing from ${act.name}.</p>${usingLeadByExample?`<p><strong>Keep on Keeping On!:</strong> +${directiveBonus} to the target's next healing until the start of Yvaelle's next turn.</p>`:''}<p><strong>${act.name} Immunity:</strong> ${entry.immunityNote}</p>${bypassEntry?'<p><strong>Medic Dedication:</strong> Immunity bypass spent.</p>':''}</div></div>`});
      finishBits(entry);result.ok=true;return finish();
    }

    // Several patients: apply each in turn, then one combined chat card.
    for(const entry of work){
      const {patient,group}=entry;
      entry.result={id:patient.id,name:patient.name,status:'treated',outcome:entry.outcome,check:Number(group.roll.total??0),healing:0,harm:0,immunity:entry.immunity,directive:false,medicBypass:entry.bypass,bits:entry.bits,text:null};
      try{
        if(group.degree>=2){const amount=Number(group.healing.total);
          try{await applyDamage(patient,{damage:-amount,outcome:entry.outcome});}catch(error){throw new Error(notApplied(entry,error,amount));}
          entry.result.healing=amount;emit('healing',{patient:patient.id,amount});await commitImmunity(entry);await clearWounded(entry);}
        else if(group.degree===0){const amount=Number(group.harm.total);await applyDamage(patient,{damage:amount,outcome:entry.outcome,final:true});entry.result.harm=amount;emit('harm',{patient:patient.id,amount});}
      }catch(error){entry.result.text=String(error?.message??error);entry.result.immunity=entry.immunity;notify('error',`${patient.name}: ${entry.result.text}`);emit('error',{patient:patient.id,message:entry.result.text});}
      finishBits(entry);
    }
    result.patients=[...work.map(entry=>entry.result),...skipped.map(describeSkip)];
    const row=entry=>{
      const r=entry.result,outcome=OUTCOME_LABELS[r.outcome]??'';
      const effect=r.text?`Not applied: ${escapeHTML(r.text)}`:r.healing?`Healed <strong>${r.healing}</strong>${entry.woundedCleared?', no longer Wounded':''}`:r.harm?`Takes <strong>${r.harm}</strong> damage`:'No healing';
      return `<li><strong>${entry.patient.nameHtml}</strong> — ${outcome}${together?'':` (check ${r.check})`}: ${effect}.${entry.bypass?' Medic Dedication bypass spent.':''}<br><small>${escapeHTML(entry.immunityNote)}${r.immunity?.status==='removeFailed'?' The previous immunity could not be removed.':''}</small></li>`;
    };
    const firstGroup=groups[0],notes=[];
    if(together){notes.push(`One Medicine check for everyone: <strong>${Number(firstGroup.roll.total??0)}</strong> vs DC ${tier.dc} (${OUTCOME_LABELS[firstGroup.outcome]}).`);if(firstGroup.healing)notes.push(`Healing rolled once and applied to each patient: ${firstGroup.breakdown.join(', ')}.`);}
    else{notes.push(`One Medicine check per patient vs DC ${tier.dc}.`);const healed=groups.find(group=>group.breakdown);if(healed)notes.push(`Healing per patient: ${healed.breakdown.join(', ').replace(/\d+d8/,'2d8 (4d8 on a critical success)')}.`);}
    const skippedHtml=skipped.length?`<p><strong>Not treated:</strong> ${skipped.map(entry=>`${entry.patient.nameHtml} (${escapeHTML(entry.text)})`).join(', ')}.</p>`:'';
    if(themed){
      const firstGroup=groups[0],healed=groups.find(group=>group.breakdown);
      const lines=[];if(!together)lines.push(`One Medicine check per patient vs DC ${tier.dc}.`);
      await ChatMessage.create({speaker,rolls,flags:systemFlags,content:keepsakeCard({kicker:`${kicker} · ${work.length} patients`,title:modeName,icon:modeIcon,tone,
        check:together?checkOf(firstGroup):null,lines,
        patients:[...work.map(entry=>{const r=entry.result;return {name:entry.patient.name,img:patientImg(entry.patient),outcome:together?null:r.outcome,amount:r.healing,harm:r.harm,
            estimate:r.text?null:estimateAfter(entry.patient.actor,(r.healing||0)-(r.harm||0)-(entry.surgery??0),entry.hp0),
            text:[r.text?`Not applied: ${r.text}`:null,!together?`check ${r.check}`:null,entry.bypass?'Medic Dedication':null].filter(Boolean).join(' · ')};}),
          ...skipped.map(entry=>({name:entry.patient.name,img:patientImg(entry.patient),text:`Not treated · ${entry.text}`}))],
        footer:[healed?(together?healed.breakdown.join(' · '):healed.breakdown.join(' · ').replace(/\d+d8/,'2d8 (4d8 critical)')):null,`${immunityDurationText} immunity`]})});
    }else await ChatMessage.create({speaker,rolls,flags:systemFlags,content:`<div class="pf2e chat-card ellie-medkit-card"><header class="card-header flexrow"><h3>${modeName} · ${work.length} patients</h3></header><div class="card-content">${notes.map(note=>`<p>${note}</p>`).join('')}<ul>${work.map(row).join('')}</ul>${skippedHtml}</div></div>`});
    const healedCount=work.filter(entry=>entry.result.healing).length;
    notify('info',`${act.name}: ${healedCount} of ${work.length} patients healed${skipped.length?`, ${skipped.length} not treated`:''}.`);
    result.ok=true;return finish();
  }finally{
    // Covers cancelled rolls, invalid results, refunds and failed writes.
    animationClosed=true;
    for(const entry of work)await cancelBits(entry,'medkit-interrupted');
  }
}

/* Chrysalis (v10 beta.24): a critical heal, or bringing someone back from
 * dying, plays the Chrysalis set piece on that patient for everyone. */
function dyingOf(actor){try{const v=Number(actor?.system?.attributes?.dying?.value);if(v>0)return v;
  const c=actor?.items?.find?.(i=>i.type==='condition'&&i.slug==='dying');return c?Number(c.system?.value?.value)||1:0;}catch{return 0;}}
// Patient ids are token ids (or UUIDs from older callers).
function patientDoc(id){try{const t=globalThis.canvas?.tokens?.get?.(id);if(t)return t.document;const d=globalThis.fromUuidSync?.(id);return d?.document??d??null;}catch{return null;}}
function readDying(ids=[]){const out=new Map();for(const id of ids??[]){const doc=patientDoc(id);if(doc)out.set(id,dyingOf(doc.actor));}return out;}
function celebrate(plan,hooks,result,before){
  if(!result?.ok)return;
  const healer=hooks.context?._internal?.healerToken??null;if(!healer?.document?.isOwner)return;
  const feel=healer.document.getFlag?.('filament-flight','flightFeel');if(feel?.autoChrysalis===false)return;
  const treated=(result.patients??[]).filter(p=>p.status==='treated');if(!treated.length)return;
  // Healing at 0 HP lifts Dying a moment later (the system applies it); look then.
  setTimeout(()=>{
    const revived=treated.find(p=>(before?.get(p.id)??0)>0&&dyingOf(patientDoc(p.id)?.actor)<=0);
    const critical=treated.find(p=>p.outcome==='criticalSuccess'&&(p.healing??0)>0);
    const pick=revived??critical;if(!pick)return;
    const target=patientDoc(pick.id)?.object;if(!target)return;
    void import('./routines.mjs?v=13.0.2').then(m=>m.startRoutine(healer,'chrysalis',{target})).catch(error=>console.warn("Ellie's Medkit | Chrysalis",error));
  },700);
}
