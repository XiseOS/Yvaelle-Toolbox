/** Dedicated actor-condition artwork, authored in the existing wing material
 * coordinates. Sampling is once per frame; geometry has fixed shoulder roots.
 * These functions never change actor rules, lights, visibility or bit stations.
 */
import {cubic} from './wing-art.mjs?v=13.0.2';

const TAU=Math.PI*2;
const finite=(n,fallback=0)=>Number.isFinite(n)?n:fallback;
const unit=n=>Math.min(1,Math.max(0,finite(Number(n))));
const smooth=n=>{n=unit(n);return n*n*(3-2*n);};
const frac=n=>n-Math.floor(n);
const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));

export const COMPLETE_CONDITION_RESPONSES=Object.freeze({
  controlled:{label:'Puppet spars',description:'A tightly pinched triangular lattice hangs on three taut puppet spars, lifting in a measured borrowed cadence.'},
  doomed:{label:'Terminal knots',description:'Outer filaments unspool shoulderward into terminal knots while the remaining lace gathers inward.'},
  dying:{label:'Last relays',description:'Sparse staged relay pulses struggle through the already collapsed lattice; they never reopen or lift the wings.'},
  dead:{label:'Extinguished lattice',description:'The last terminal seams unthread into a quiet shoulder ember, leaving extinguished channels in the already broken lattice.'},
  wounded:{label:'Repair sutures',description:'Broad cross-rib repair sutures replace damaged web sections, tensioning in sequence while retaining a usable silhouette.'},
  cursebound:{label:'Ritual ratchet',description:'Interlocking ritual ties repeatedly cinch inward and slowly release, with a restrained magenta knot at each crossing.'},
  malevolence:{label:'Haunted currents',description:'An intrusive current twists the upper and lower lattice in opposing directions, tracing three lingering haunted folds through its spars.'},
  'off-guard':{label:'Open guard',description:'One upper guard draws open into an asymmetric gap while a shallow latch filament tries to close its exposed seam.'},
  concealed:{label:'Passing veil',description:'A soft travelling veil crosses the outer web in broad bowed bands while the wing itself remains legible.'},
  invisible:{label:'Fine recession',description:'Coherent fine return strands recede inward through a narrow translucent lattice; the owner retains a readable wing silhouette.'},
  hidden:{label:'Close concealment',description:'Compact folded guard seams rest close to the shoulders with occasional tiny inward settling movements.'},
  undetected:{label:'Shadow lace',description:'Slack low-set lace gathers inward, carrying a slow shoulderward current through shadow-fine filaments.'},
  unnoticed:{label:'Dormant signal',description:'Hairfine near-root channels hold a dormant, quiet signal with one tiny measured charge and a tightly gathered outer lattice.'},
  'persistent-damage':{label:'Sustained injury',description:'Damage-aware currents scar the lattice: heat tongues, angular rime, arcing relays, acid channels, draining beads or a fitting typed filament treatment.'},
  glitching:{label:'Interrupted signal',description:'Short relay bands drop their signal and reconnect sequentially along the wing; the shoulder connection always remains intact.'},
  suppressed:{label:'Protective recoil',description:'The outer ribs fold into a narrow shoulderward protective mantle, held by three bowed braces that retain the root connection.'},
  untethered:{label:'Weightless drift',description:'The two lattices drift slowly out of phase in depth and softly fan their tips while their shoulder roots remain fixed.'}
});
export const COMPLETE_CONDITION_IDS=Object.freeze(Object.keys(COMPLETE_CONDITION_RESPONSES));
const IDS=new Set(COMPLETE_CONDITION_IDS);
const COLLAPSED_ART=new Set(['dying','dead','doomed','wounded','cursebound','malevolence','persistent-damage']);
const DAMAGED_TYPES=new Set(['acid','bleed','bludgeoning','cold','electricity','fire','force','mental','piercing','poison','slashing','sonic','spirit','vitality','void','radiation']);
const aliases=Object.freeze({electric:'electricity',electrical:'electricity',lightning:'electricity',physical:'bludgeoning',positive:'vitality',negative:'void'});
export function completeDamageTypes(raw=[]){
  const types=[];
  for(const value of Array.isArray(raw)?raw:[]){
    const rawType=typeof value==='string'?value:value?.type??value?.damageType;
    if(typeof rawType!=='string')continue;
    const key=rawType.toLowerCase().trim(),type=aliases[key]??key;
    if(DAMAGED_TYPES.has(type)&&!types.includes(type))types.push(type);
    if(types.length>=3)break;
  }
  return types.length?types:['untyped'];
}

/** Compact serializable state is shared by the main thread and render worker.
 * A chosen custom animation retains its artwork; native articulation still
 * accompanies it. Default choices add their own small material topology.
 */
export function sampleCompleteConditionMotion(response,visual={},config={}){
  if(!response?.wings||response.enabled===false||config.visualConditions===false)return null;
  const collapsed=response.collapse?.phase&&response.collapse.phase!=='awake';
  const entries=(response.active??[]).filter(entry=>IDS.has(entry.id)&&entry.style!=='none'&&
    response.config?.conditions?.[entry.id]?.enabled!==false&&(!collapsed||COLLAPSED_ART.has(entry.id)));
  if(!entries.length)return null;
  const strengths={};
  for(const entry of entries){
    const value=response.levels?.[entry.id]??entry.strength??0;
    strengths[entry.id]=unit(value*(1+.12*Math.min(3,Math.max(0,(response.rawLevels?.[entry.id]??entry.value??1)-1))));
  }
  const positive=entries.filter(entry=>strengths[entry.id]>.001);
  if(!positive.length)return null;
  const arrested=visual.conditionMotionFrozen||visual.actorConditionMotion?.arrest>=.999;
  const deadSettled=positive.every(entry=>entry.id==='dead')&&unit(response.collapse?.progress??1)>=1;
  const animated=!deadSettled&&!response.reduced&&visual.animated!==false&&!arrested;
  const time=finite(visual.conditionFrozenTime,animated?finite(visual.effectTime,finite(visual.time)):0);
  const motion=config.filamentInstability===false?0:clamp(finite(config.conditionMotionStrength,1),0,2);
  const authored=config.conditionAuthoredArtwork!==false&&config.enhancedConditions!==false;
  const defaultIds=new Set(positive.filter(entry=>entry.style==='default'||entry.style==null).map(entry=>entry.id));
  const artScale=authored?1:.28;
  const a=id=>(strengths[id]??0)*(defaultIds.has(id)?artScale:.28);
  // The breath/pulse envelope is slow, continuous and deterministic. Repeated
  // ratchets have a long release instead of a visual snap at the cycle seam.
  const doom=.5-.5*Math.cos(time*.13*TAU),ratchet=frac(time*.18);
  const ratchetHold=ratchet<.24?smooth(ratchet/.24):1-smooth((ratchet-.24)/.76);
  const damageTypes=completeDamageTypes(response.damageTypes);
  const damage=a('persistent-damage'),typeGain=damage/Math.sqrt(damageTypes.length);
  const has=type=>damageTypes.includes(type)?typeGain:0;
  return {active:true,animated,deadSettled,time,motion,strengths,authored,artScale,collapsed:!!collapsed,
    fitting:config.enhancedConditions===false?[]:positive.filter(entry=>entry.style==='default'||entry.style==null).map(entry=>entry.id),
    damageTypes,
    puppet:a('controlled')*(.68+.16*Math.sin(time*1.16)),puppetTug:a('controlled')*Math.sin(time*1.16+.6),
    terminal:a('doomed')*(.66+.25*smooth(doom)),unravel:doom,
    lastRelay:a('dying')*(.12+.88*Math.pow(Math.max(0,Math.sin(time*.92)),8)),
    extinguished:a('dead'),deathFade:1-unit(response.collapse?.progress??1),
    sutures:a('wounded')*(.35+.65*Math.pow(Math.max(0,Math.sin(time*.61)),8)),
    ratchet:a('cursebound')*(.42+.58*ratchetHold),reservoir:a('malevolence')*(.7+.3*Math.sin(time*.47)),
    guard:a('off-guard')*(.72+.12*Math.sin(time*.78)),veil:a('concealed')*Math.sin(time*.57),
    recession:a('invisible')*(.64+.08*Math.sin(time*.37)),settle:a('hidden')*(.9+.1*Math.sin(time*.23)),
    slack:a('undetected')*(.85+.08*Math.sin(time*.31)),dormant:a('unnoticed')*(.96+.04*Math.sin(time*.19)),
    dropout:a('glitching')*(.5+.5*Math.sin(time*2.1)),recoil:a('suppressed')*(.72+.15*Math.sin(time*.87)),
    drift:a('untethered'),
    heat:has('fire')*Math.sin(time*1.55),rime:has('cold'),arc:has('electricity')*Math.sin(time*2.8),
    etch:has('acid')*Math.sin(time*.73),drain:has('bleed')*(.5+.5*Math.sin(time*.64)),
    impact:(has('bludgeoning')+has('piercing')+has('slashing'))*Math.sin(time*.83),
    poison:has('poison')*Math.sin(time*.59),sonic:has('sonic')*Math.sin(time*1.67),
    damageBend:has('untyped')*(.5+.5*Math.sin(time*.73)),
    focus:(has('mental')+has('force'))*Math.sin(time*.81),soul:(has('spirit')+has('vitality')+has('void')+has('radiation'))*Math.sin(time*.51),
    quiet:Math.min(.8,.16*a('invisible')+.14*a('undetected')+.24*a('unnoticed')+.12*a('dying')+.75*a('dead'))};
}

/** This deformation composes after the existing posed lattice. No root drift
 * or wing reattachment is possible: u<=.08 returns the input object unchanged.
 * Combined bends are capped once, rather than multiplying every condition.
 */
export function completeConditionWarp(side,visual){
  const m=visual?.completeConditionMotion;if(!m?.active)return null;
  const rx=side*27,ry=-13,t=m.time,move=m.motion;
  const driftX=m.drift*25*Math.sin(t*.31+side*.9),driftY=m.drift*33*Math.sin(t*.27+side*1.1),driftZ=m.drift*7*Math.sin(t*.23+side*.7);
  return (point,source)=>{
    const u=unit(source?.[2]??point[3]??1);if(u<=.08)return point;
    const w=smooth((u-.08)/.92),bell=4*w*(1-w),dx=point[0]-rx,dy=point[1]-ry;
    const sy=finite(source?.[1],dy),lower=unit(sy/220),upper=unit(-sy/210);
    const skew=side===1?1:-.38;
    let x=0,y=0,z=0;
    // Borrowed cadence pulls spars up as a taut mechanism; controlled ribs do
    // not droop like grabbing or share the restrained/snared choreography.
    x-=dx*m.puppet*.38*w;x+=side*m.puppet*8*bell;
    y-=m.puppet*35*w*(.4+upper*.6);y+=m.puppetTug*7*bell*lower;
    x-=dx*m.terminal*.31*w;y+=m.terminal*29*w*(.2+lower*.8);
    x+=side*m.sutures*7*bell*(lower-upper);y-=m.sutures*6*bell;
    x-=dx*m.ratchet*.48*w;y+=m.ratchet*18*w*(lower-upper);
    x+=side*m.reservoir*17*w*(upper-lower);
    y+=m.reservoir*34*w*(upper-lower)*side;
    x+=side*m.guard*15*w*upper*skew;y-=m.guard*11*w*upper*skew;
    x+=side*m.veil*3*bell;y+=m.veil*2*w*(lower-upper);
    x-=dx*(m.recession*.18+m.settle*.21+m.slack*.15+m.dormant*.28)*w;
    y+=m.settle*7*w*upper+m.slack*13*w*(.3+lower*.7)+m.dormant*3*bell;
    x+=side*m.dropout*2.4*bell*(lower-upper);y+=m.dropout*1.3*w*upper;
    x-=dx*m.recoil*.61*w;y-=dy*m.recoil*.34*w;y+=m.recoil*34*w;
    // Independent phase and unequal depth gives weightlessness without moving
    // either shoulder or allocating/repositioning any controller bits.
    x+=side*driftX*w*(.3+.7*lower);y+=driftY*w*(.3+.7*upper);z+=driftZ*w;
    x+=side*(m.heat*3*upper+m.arc*1.4*bell+m.etch*1.5*lower+m.impact*2*bell+m.focus*1.8*upper+m.soul*1.6*lower);
    y+=m.heat*(-5*w*upper)+m.rime*3*w*lower+m.drain*4*w*lower+m.poison*2.6*bell+m.sonic*2.5*w*(lower-upper);
    x+=side*m.damageBend*1.3*bell;y+=m.damageBend*2*w*lower;
    // Last relays deform only the tiny already resting span. They never stretch
    // a dying/unconscious lattice into a flying silhouette.
    y+=m.lastRelay*1.4*bell;
    x-=dx*m.extinguished*.025*w;y+=m.extinguished*2*w;
    // Default actor art can own a recognizable silhouette. A user-authored
    // look receives only the small accompanied version sampled above.
    x=clamp(x*move,-90,90);y=clamp(y*move,-70,70);z=clamp(z*move,-7,7);
    const out=[...point];out[0]=clamp(point[0]+x,-278,278);out[1]=clamp(point[1]+y,-255,286);
    // Do not cross the token's depth plane due to an optional status treatment.
    if(Number.isFinite(point[2]))out[2]=point[2]<0?Math.min(-.001,point[2]+z):point[2]>0?Math.max(.001,point[2]+z):0;
    return out;
  };
}

/** A bounded native strand budget: at most three paths per condition and forty
 * per call. One long shaped path carries each material treatment rather than
 * many particles, nested loops, additional textures or screen-space effects.
 */
export function completeConditionAccents(side,visual,warp,ribs,growth=1){
  const m=visual?.completeConditionMotion;
  if(!m?.active||growth<=0||!m.fitting?.length)return [];
  const out=[],t=m.time;
  const source=(rib,u)=>[...cubic(ribs[clamp(rib,0,ribs.length-1)],u),u];
  const path=(id,points,strength,width=.7)=>{
    const visible=points.filter(p=>p.every(Number.isFinite)&&(p[2]??1)<=growth+.000001);
    if(out.length>=40||visible.length<2||strength<=.012)return;
    const posed=visible.map(p=>warp(p));
    if(posed.some(p=>!p.every(Number.isFinite)))return;
    out.push({id:`actor-${id}`,points:posed,strength:clamp(strength,.012,1.2),width,conditionAccent:true});
  };
  const rail=(rib,lo,hi,offset=0,wiggle=0)=>Array.from({length:17},(_,i)=>{
    const q=i/16,u=lo+(hi-lo)*q,p=source(rib,u),w=Math.sin(Math.PI*q);
    p[0]+=(offset+wiggle*Math.sin(q*TAU))*w;return p;
  });
  const bridge=(from,to,u,drop=0,sideBend=0)=>{
    const a=source(from,u),b=source(to,u);
    return Array.from({length:17},(_,i)=>{const q=i/16,bend=Math.sin(Math.PI*q);return [a[0]+(b[0]-a[0])*q+sideBend*bend,a[1]+(b[1]-a[1])*q+drop*bend,u];});
  };
  const knot=(rib,u,rx,ry,turns=1,tilt=0)=>{
    const p=source(rib,u);return Array.from({length:25},(_,i)=>{
      const q=i/24*TAU*turns,r=turns===1?1:1-.35*i/24;
      return [p[0]+r*rx*Math.cos(q)+tilt*Math.sin(q),p[1]+r*ry*Math.sin(q),u];
    });
  };
  const pulse=(phase,rate=1)=>.18+.82*Math.pow(Math.max(0,Math.sin(t*rate+phase)),4);
  const cycle=(rate,phase=0)=>.5-.5*Math.cos((t*rate+phase)*TAU);
  for(const id of m.fitting){
    const a=(m.strengths[id]??0)*(m.artScale??1),s=.9*a,before=out.length;
    switch(id){
      case 'controlled':
        for(let k=0;k<3;k++){
          const rib=1+k*3,end=source(rib,.93),base=source(Math.max(0,rib-1),.13),pull=1.2*Math.sin(t*1.16+k*.45)*m.motion;
          path(`${id}-puppet-${k}`,Array.from({length:17},(_,i)=>{const q=i/16;return [base[0]+(end[0]-base[0])*q+Math.sin(Math.PI*q)*pull,base[1]+(end[1]-base[1])*q,.13+.8*q];}),s,1.55);
        }break;
      case 'doomed':
        for(let k=0;k<3;k++){
          const life=cycle(.13,k*.21),u=.87-.36*life,p=source(1+k*3,u),q=source(1+k*3,Math.max(.13,u-.24)),turn=TAU*(1.4+.2*Math.sin(t*.37));
          const thread=Array.from({length:29},(_,j)=>{const n=j/28,r=(1-n)*12;return [q[0]+(p[0]-q[0])*n+r*Math.sin(n*turn),q[1]+(p[1]-q[1])*n+r*Math.cos(n*turn),q[2]+(u-q[2])*n];});
          path(`${id}-terminal-${k}`,thread,s*(.65+.3*Math.sin(Math.PI*life)),1.08);
        }break;
      case 'dying':
        for(let k=0;k<3;k++){
          const p=cycle(.12,-k*.17),u=.13+.48*p,gain=s*(.12+.88*Math.pow(Math.max(0,Math.sin(Math.PI*p)),7));
          path(`${id}-last-relay-${k}`,rail(2+k*3,Math.max(.1,u-.085),u),gain,.48);
        }break;
      case 'dead':{
        const end=.16+.24*m.deathFade;
        path(`${id}-terminal-upper`,rail(1,.09,end,-1),s*(.07+.35*m.deathFade),.32);
        path(`${id}-terminal-lower`,rail(8,.09,end,-1),s*(.06+.29*m.deathFade),.3);
        path(`${id}-shoulder-ember`,rail(4,.085,.135),s*.09,.36);break;
      }
      case 'wounded':
        for(let k=0;k<3;k++){
          const u=.49+k*.15,a0=source(k,u-.05),b=source(Math.min(9,4+k*2),u+.04),tension=.7+.3*pulse(k*1.7,.61);
          path(`${id}-suture-${k}`,Array.from({length:21},(_,i)=>{const q=i/20;return [a0[0]+(b[0]-a0[0])*q+(i%2?6:-6)*tension,a0[1]+(b[1]-a0[1])*q,a0[2]+(b[2]-a0[2])*q];}),s,1.25);
        }break;
      case 'cursebound':
        for(let k=0;k<3;k++){
          const u=.42+k*.18,p=bridge(k,8-k,u,(-1)**k*(15-8*m.ratchet),10*Math.sin(t*.37));
          // Crossings alternate over/under in source space. The ties ratchet
          // together, rather than emitting generic orbiting spell circles.
          for(let j=0;j<p.length;j++)p[j][0]+=Math.sin(j/16*TAU*3)*7*(.4+m.ratchet);
          path(`${id}-ritual-tie-${k}`,p,s*(.75+.25*m.ratchet),1.45);
        }break;
      case 'malevolence':{
        for(let k=0;k<3;k++){
          const rib=1+k*3,p=rail(rib,.18,.93,(k===1?-1:1)*(10+5*Math.sin(t*.47+k)),9*Math.sin(t*.47+side+k));
          for(let j=0;j<p.length;j++)p[j][1]+=Math.sin(j/16*Math.PI)*15*Math.sin(t*.47+side+k);
          path(`${id}-haunted-fold-${k}`,p,s*(.72+.2*Math.sin(t*.47+k)),1.15);
        }break;
      }
      case 'off-guard':{
        const open=side===1?1:.35;
        path(`${id}-open-latch`,bridge(0,3,.7,-3,open*8),s*.78,.83);
        path(`${id}-unseated-seam`,rail(1,.49,.78,5*open+2*Math.sin(t*.78)),s*.62,.66);
        path(`${id}-guard-return`,rail(3,.26,.58,-3*open),s*.5,.62);break;
      }
      case 'concealed':
        for(let k=0;k<3;k++){
          const u=.5+.13*k+.065*Math.sin(t*.57-k*.8);
          path(`${id}-veil-${k}`,bridge(0,9,u,7+3*k,7*Math.sin(t*.57+k*.5)),s*(.29+.07*k),1.35-k*.19);
        }break;
      case 'invisible':
        for(let k=0;k<3;k++){
          const life=cycle(.11,k*.27),u=.8-.45*life;
          path(`${id}-recession-${k}`,rail(1+k*3,Math.max(.12,u-.15),u,-2),s*(.34+.12*Math.sin(Math.PI*life)),.42);
        }break;
      case 'hidden':
        path(`${id}-near-guard-upper`,bridge(0,4,.32,2,1),s*.49,.51);
        path(`${id}-near-guard-lower`,bridge(4,9,.29,3,-1),s*.44,.47);
        path(`${id}-settling-seam`,rail(4,.14,.38,1.1*Math.sin(t*.23)),s*.36,.42);break;
      case 'undetected':
        path(`${id}-slack-lace-upper`,bridge(0,4,.54,11,2),s*.37,.47);
        path(`${id}-slack-lace-lower`,bridge(4,9,.56,17,-3),s*.31,.4);
        path(`${id}-shadow-return`,rail(6,.13,.66,-3,2*Math.sin(t*.31)),s*.41,.49);break;
      case 'unnoticed':{
        const u=.15+.12*cycle(.07);
        path(`${id}-dormant-root`,rail(2,.09,.28,-.6),s*.25,.32);
        path(`${id}-dormant-channel`,rail(7,.1,.25,.6),s*.21,.3);
        path(`${id}-root-charge`,rail(4,Math.max(.09,u-.05),u),s*(.15+.15*pulse(0,.19)),.41);break;
      }
      case 'glitching':
        for(let k=0;k<3;k++){
          const u=.36+k*.17,gain=s*(.2+.8*smooth(.5+.5*Math.sin(t*2.1-k*1.1))),p=rail(1+k*3,u-.065,u+.055);
          for(let j=0;j<p.length;j++)p[j][0]+=(j>5&&j<11?2.8:0)*Math.sin(t*2.1-k)*m.motion;
          path(`${id}-relay-band-${k}`,p,gain,.91);
        }break;
      case 'suppressed':
        for(let k=0;k<3;k++)path(`${id}-recoil-brace-${k}`,bridge(k*3,Math.min(9,k*3+3),.48+k*.115,-12-9*m.recoil,-4),s,1.55);break;
      case 'untethered':
        for(let k=0;k<3;k++)path(`${id}-floating-seam-${k}`,rail(1+k*3,.2,.94,14*Math.sin(t*.27+side+k),8*Math.sin(t*.31+k)),s*(.7+.2*Math.sin(t*.23+k)),1.1);break;
      case 'persistent-damage':
        for(let k=0;k<3;k++){
          const type=m.damageTypes[k%m.damageTypes.length],rib=1+k*3,phase=cycle(.21,k*.29),u=.28+.55*phase;
          let points,width=.75,gain=s*.78;
          if(type==='fire'){
            points=rail(rib,.33,.87,3,3);
            for(let j=0;j<points.length;j++)points[j][1]-=Math.sin(j/16*Math.PI)*7*Math.sin(t*1.55-j*.33)*m.motion;
            width=.95;
          }else if(type==='cold'){
            const rimeU=.52+k*.09+.018*Math.sin(t*.29+k),p=source(rib,rimeU),length=3.5+.35*Math.sin(t*.29+k);
            points=Array.from({length:13},(_,j)=>[p[0]+(j%2?4:-3)+(j-6)*.5,p[1]+(j-6)*length,rimeU]);width=.63;
          }else if(type==='electricity'){
            points=bridge(rib,Math.min(9,rib+2),.49+k*.085,0);
            for(let j=1;j<points.length-1;j++)points[j][0]+=(-1)**j*(2+1.5*Math.sin(t*2.8+k))*m.motion;
            gain*=.46+.54*pulse(k*1.3,2.8);width=1.04;
          }else if(type==='acid'){
            const p=source(rib,.44+k*.12);points=Array.from({length:25},(_,j)=>{const q=j/24*TAU;return [p[0]+(4+1.2*Math.sin(t*.73+k))*Math.cos(q),p[1]+8*Math.sin(q)+2*Math.sin(q*3),.44+k*.12];});width=.55;
          }else if(type==='bleed'){
            // A draining teardrop advances toward the lower surviving rib.
            const p=source(rib,u);points=Array.from({length:21},(_,j)=>{const q=j/20*TAU;return [p[0]+3*Math.sin(q)*Math.sin(q/2),p[1]-4*Math.cos(q)+5*Math.sin(q/2),u];});gain*=.35+.65*Math.sin(Math.PI*phase);width=.85;
          }else if(type==='bludgeoning'){
            points=bridge(Math.max(0,rib-1),Math.min(9,rib+1),.55+k*.075,6+4*Math.sin(t*.83+k));width=.9;
          }else if(type==='piercing'){
            const p=source(rib,.54+k*.085);points=[[p[0]-5,p[1]-8,p[2]],[p[0]+2,p[1]+1,p[2]],[p[0]-3,p[1]+9,p[2]]];width=.9;
          }else if(type==='slashing'){
            points=bridge(Math.max(0,rib-1),Math.min(9,rib+2),.59+k*.065,-1,5);width=.78;
          }else if(type==='poison'){
            points=rail(rib,.32,.86,2,5*Math.sin(t*.59+k));width=.83;gain*=.7+.3*pulse(k,.59);
          }else if(type==='sonic'){
            points=bridge(rib,Math.min(9,rib+2),.55+k*.07,2);
            for(let j=0;j<points.length;j++)points[j][1]+=3*Math.sin(j/16*TAU*2+t*1.67)*m.motion;width=.69;
          }else if(type==='force'){
            const p=source(rib,.6+k*.045);points=[[p[0],p[1]-7,p[2]],[p[0]+6,p[1]-3,p[2]],[p[0]+4,p[1]+5,p[2]],[p[0]-4,p[1]+5,p[2]],[p[0]-6,p[1]-3,p[2]],[p[0],p[1]-7,p[2]]];width=.8;
          }else if(type==='mental'){
            points=knot(rib,.51+k*.06,8,4,1,4*Math.sin(t*.81+k));width=.56;
          }else if(type==='void'){
            points=rail(rib,.13,.78-.45*phase,-3,-2);gain*=.48+.32*Math.sin(Math.PI*phase);width=.46;
          }else if(type==='vitality'){
            points=rail(rib,.2+.42*phase,.85,3,1.5);gain*=.55+.25*Math.sin(Math.PI*phase);width=.71;
          }else if(type==='spirit'){
            points=knot(rib,.51+k*.07,6,10,2,2*Math.sin(t*.51+k));width=.52;
          }else if(type==='radiation'){
            points=bridge(rib,Math.min(9,rib+2),.48+k*.09,3,4*Math.sin(t*.51+k));width=.67;gain*=.6+.35*pulse(k,.51);
          }else{
            points=rail(rib,.39,.78,-2,2*Math.sin(t*.73+k));width=.67;
          }
          path(`${id}-${type}-${k}`,points,gain,width);
        }break;
    }
    // The condition's authored budget is independent of how many other
    // conditions are active; protect it against future accidental expansion.
    if(out.length-before>3)out.splice(before+3,out.length-before-3);
  }
  return out;
}

/** Fine material masks complement the posed body rather than using opacity on
 * the whole token. Root-adjacent spans remain connected and opaque enough to
 * read. At most three contiguous spans are returned per input path.
 */
export function completeConditionMaterialPaths(strand,points,side,visual){
  const m=visual?.completeConditionMotion;
  if(!m?.active||m.authored===false||!m.fitting?.length||strand.conditionAccent||strand.hardware||/^(gem|sigil)-/.test(strand.id)||points.length<2)return null;
  const fitting=m.fitting;
  const a=id=>fitting.includes(id)?m.strengths[id]??0:0;
  const invisible=a('invisible'),undetected=a('undetected'),unnoticed=a('unnoticed'),dying=a('dying'),dead=a('dead'),glitch=a('glitching');
  const controlled=a('controlled'),doomed=a('doomed'),wounded=a('wounded'),curse=a('cursebound'),haunted=a('malevolence'),suppressed=a('suppressed'),untethered=a('untethered');
  if(!(invisible||undetected||unnoticed||dying||dead||glitch||controlled||doomed||wounded||curse||haunted||suppressed||untethered))return null;
  const isWeb=/^(web|cross)/.test(strand.id),isEdge=strand.id.startsWith('edge'),rib=Number(strand.id.split('-')[1])||0;
  const seam=Number(strand.id.split('-')[2])||0;
  // Characteristic condition art owns the default lattice instead of hiding
  // tiny authored ties in a dense unchanged web. Reduced old lace remains
  // connected, and all new seams still share the standard HP cutter.
  let ownership=1;
  if(isWeb){
    ownership*=Math.max(.05,1-controlled*.95-doomed*.9-curse*.95-haunted*.91-suppressed*.9-untethered*.82);
    // Wounded explicitly replaces the middle web with broad stitched bands;
    // the uninjured root and outer tip weave remain as its support scaffold.
    ownership*=1-wounded*(seam>=4&&seam<=7?.93:.47);
  }else if(isEdge){
    ownership*=Math.max(.12,1-controlled*.32-doomed*.48-curse*.24-haunted*.27-suppressed*.33-untethered*.22);
  }else if(strand.id.startsWith('rib-')){
    ownership*=Math.max(.2,1-controlled*(rib%3===1?.1:.46)-doomed*.3-curse*.25-haunted*(rib%3===1?.08:.48)-untethered*.3);
  }
  const recession=Math.max(.3,1-invisible*(isWeb?.54:.26)-undetected*(isWeb?.42:.18)-unnoticed*(isWeb?.64:.36));
  const last=.12+.28*pulseValue(m.time*.92-rib*.39);
  const death=1-dying*(isWeb?.84:isEdge?.76:1-last);
  const terminal=1-(1-dead)**3;
  const base=(strand.strength??1)*recession*death*(1-terminal*.98)*ownership;
  if(!glitch)return [{...strand,points,strength:base,width:(strand.width??1)*(1-.22*invisible-.3*unnoticed)}];
  // Source-local relay stations hold their endpoints while a continuous
  // phase-offset signal dims each one in sequence. No marching hard threshold
  // changes which material vertices belong to a band between adjacent frames.
  const lo=.34+(rib%3)*.095,hi=lo+.13;
  const gain=1-glitch*(.55+.4*pulseValue(m.time*2.1-rib*.43));
  const out=[];let run=null;
  for(let i=1;i<points.length;i++){
    const p=points[i-1],q=points[i],u=((p[3]??1)+(q[3]??1))/2,inside=u>=lo&&u<=hi;
    const strength=base*(inside?gain:1),tag=inside?'signal-drop':'signal-connected';
    if(run?.tag===tag&&run.points.at(-1)===p)run.points.push(q);
    else {run={...strand,points:[p,q],strength,tag};out.push(run);}
  }
  return out;
}
const pulseValue=n=>Math.pow(Math.max(0,Math.sin(n)),4);
