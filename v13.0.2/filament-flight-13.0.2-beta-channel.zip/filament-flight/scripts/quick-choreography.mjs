/** Short, readable lattice gestures. Pulse changes the wing's tension; Stutter
 * briefly loses local registration. Neither impersonates a sustained condition. */
import {ease,unit} from './poses.mjs?v=13.0.2';
import {cubic} from './wing-art.mjs?v=13.0.2';
import {fitEffectPoint} from './condition-art.mjs?v=13.0.2';

export const QUICK_REACTION_IDS=Object.freeze(['resonance','heartbeat','orbit','phaseSlip','skip','static']);
export const isQuickReaction=b=>QUICK_REACTION_IDS.includes(b.id)&&['pulse','stutter'].includes(b.kind);
const TAU=Math.PI*2,root=u=>ease((u-.1)/.34);
const live=q=>q>0&&q<1;
const bell=q=>live(q)?Math.sin(Math.PI*q)**2:0;
const packet=(u,head,width)=>Math.exp(-(((u-head)/width)**2));
const cache=new WeakMap();
const beats=[[.04,.31,1],[.53,.34,.84]];

/** Clocked once per side and frame. Cue duration stretches the whole gesture;
 * intensity continuously scales displacement, never the chance it is visible. */
export function quickParameters(v,side){
  if(!v?.animated)return [];
  let saved=cache.get(v);if(!saved){saved=new Map();cache.set(v,saved);}
  if(saved.has(side))return saved.get(side);
  const out=[...(v.bursts??[]),...(v.reactions??[])].filter(isQuickReaction).map(b=>{
    const q=b.progress,k=Math.min(1.5,b.amount??b.strength),out={...b,q,k,side,source:b};
    if(b.kind==='pulse'){
      out.gather=bell(q/.25);
      out.release=bell((q-.19)/.52);
      out.head=.07+.9*ease((q-.19)/.57);
      out.returnHead=.97-.9*ease((q-.72)/.28);
      out.returnGain=bell((q-.72)/.28)*.43;
      out.beats=beats.map(([start,duration,gain])=>({q:(q-start)/duration,gain}));
      out.beatRadial=out.beats.reduce((n,beat)=>n+beat.gain*(-.105*bell(beat.q/.37)+.13*bell((beat.q-.22)/.78)),0);
      out.beatVertical=out.beats.reduce((n,beat)=>n+beat.gain*.038*bell((beat.q-.22)/.78),0);
      out.life=Math.sin(Math.PI*q);
      out.orbit=q*9;out.orbitU=.59+.17*Math.sin(q*TAU);
    } else {
      const step=Math.min(2,Math.floor(q*3)),local=q*3-step;
      // A rapid capture, a genuinely held offset, and a quiet re-registration.
      // The long plateau survives low texture FPS; no single-frame flash.
      const hold=ease((local-.055)/.07)*(1-ease((local-.62)/.17));
      out.step=step;out.hold=hold;out.gain=hold*k*Math.min(1,v.gates?.glitchLimit??1);
      out.sign=(step%2?1:-1)*side;
      out.bands=step===0?[-104,98]:step===1?[-34,164]:[-157,39];
    }
    return out;
  });
  saved.set(side,out);return out;
}

export function quickPoint(point,u,side,parameters,motion=1){
  if(!motion)return point;
  const p=[...point],r=root(u),x=p[0]-side*27,y=p[1]+13;
  for(const b of parameters){
    if(b.kind!=='pulse')continue;
    let radial=0,vertical=0;
    if(b.id==='resonance'){
      radial=-.16*b.gather+.09*b.release+.075*packet(u,b.head,.18)*b.release;
      vertical=-.065*b.gather+.043*b.release;
    } else if(b.id==='heartbeat'){
      radial=b.beatRadial;vertical=b.beatVertical;
    } else if(b.id==='orbit'){
      // The travelling lens bends a local fan of strands, never the entire wing.
      const angle=Math.atan2(y,Math.abs(x)+1),target=-1.18+2.4*b.q;
      const lens=packet(angle,target,.35)*packet(u,b.orbitU,.26)*b.life;
      radial=.18*lens;vertical=.09*lens;
    }
    p[0]+=x*radial*b.k*r*motion;p[1]+=y*vertical*b.k*r*motion;
  }
  return p;
}

/** Return a held local displacement for one lattice segment. The screen-space
 * band keeps neighbouring filaments aligned as one interrupted piece. */
export function stutterSegment(b,a,c,u,rank,web){
  const r=root(u);if(b.gain<=.001||u<=.18)return null;
  const y=(a[1]+c[1])/2;
  let active=false,factor=1,tag='';
  if(b.id==='phaseSlip'){
    const index=Math.abs(y-b.bands[0])<29?0:Math.abs(y-b.bands[1])<29?1:-1;
    active=index>=0;factor=index===0?1:-.7;tag=`band-${index}`;
  } else if(b.id==='skip'){
    const sector=Math.floor(u*7),chosen=2+(b.step+(b.side<0?1:0))%4;
    active=sector===chosen||sector===chosen+1;tag=`sector-${sector}`;
    factor=b.step===1?-.75:1;
  } else {
    const band=Math.floor((y+270)/26);
    active=(band+b.step*2)%4===0&&(web||rank%2===b.step%2);
    factor=(rank%2?-.7:1)*.65;tag=`static-${band}`;
  }
  if(!active)return null;
  const amount=b.gain*r;
  return {dx:b.sign*22*amount*factor,dy:(b.step-1)*3*amount,
    gain:amount,fade:1-(b.id==='static'?.48:.3)*amount,
    skip:web&&(rank+b.step)%5===0&&amount>.18,
    tag:`${b.id}-${b.step}-${tag}`};
}

export function quickAccents(side,v,warp,ribs,growth,parameters){
  const out=[];let tint='base';
  const at=(i,u)=>warp([...cubic(ribs[Math.max(0,Math.min(9,i))],u),u]);
  const line=(id,points,width,strength)=>{
    const gain=Math.round(Math.max(0,Math.min(1.4,strength))*20)/20;
    if(gain<.05||points.length<2||points.some(p=>(p[3]??1)>growth+.000001))return;
    out.push({id,points:points.map(fitEffectPoint),width,strength:gain,highlight:true,tint});
  };
  const current=(id,i,u,gain,reverse=false)=>{
    if(u<=0||u>growth)return;
    const points=Array.from({length:13},(_,j)=>at(i,unit(u+(reverse?1:-1)*.19*j/12)));
    for(let j=0;j<3;j++)line(`${id}-${j}`,points.slice(j*4,j*4+5),[1.5,1,.5][j],gain*[1,.55,.2][j]);
  };
  const crest=(id,u,gain)=>{
    if(u<=0||u>growth)return;
    // Three separated curved panels avoid a solid cross-wing flash ring.
    for(const [j,start] of [0,3,6].entries()){
      const points=[];
      for(let i=start;i<start+2;i++){
        const a=at(i,u),b=at(i+1,u);
        for(let n=0;n<6;n++){
          const f=n/5,p=a.map((x,k)=>x+(b[k]-x)*f);
          p[0]+=side*Math.sin(Math.PI*f)*2.5;p[1]-=Math.sin(Math.PI*f)*2.5;points.push(p);
        }
      }
      line(`${id}-crest-${j}`,points,1.15,gain);
    }
  };
  for(const b of parameters){
    const id=`${b.id}-${b.kind}`,q=b.q,k=b.k;tint=b.kind==='stutter'?'violet':'base';
    if(b.id==='resonance'){
      if(b.gather>0)for(const i of [0,3,6,9])current(`${id}-gather-${i}`,i,.63-.48*ease(q/.25),b.gather*k*.85,true);
      if(b.release>0){
        for(const i of [0,2,4,6,8,9])current(`${id}-${i}`,i,b.head,k*b.release*1.12);
        crest(id,b.head,k*b.release*.9);
      }
      if(b.returnGain>0)for(const i of [1,4,7])current(`${id}-return-${i}`,i,b.returnHead,k*b.returnGain,true);
    } else if(b.id==='heartbeat'){
      for(const [j,beat] of b.beats.entries())if(live(beat.q)){
        const u=.07+.9*ease(beat.q),gain=k*beat.gain*Math.sin(Math.PI*beat.q);
        crest(`${id}-${j}`,u,gain);
        for(const i of [0,4,9])current(`${id}-${j}-${i}`,i,u,gain);
      }
    } else if(b.id==='orbit'){
      for(const [j,n] of [b.orbit,9-b.orbit].entries()){
        const ri=Math.min(8,Math.floor(n)),f=n-ri,u=j?1.2-b.orbitU:b.orbitU;
        const a=at(ri,u),c=at(ri+1,u),p=a.map((x,i)=>x+(c[i]-x)*f),gain=k*Math.sin(Math.PI*q)*(j?.65:1);
        const points=Array.from({length:19},(_,i)=>{const angle=i/18*TAU;return [p[0]+Math.cos(angle)*6,p[1]+Math.sin(angle)*3,p[2],u];});
        line(`${id}-lens-${j}`,points,1.15,gain);
        current(`${id}-wake-${j}`,ri,u,gain);
      }
    } else if(b.kind==='stutter'&&b.gain>0&&v.gates?.glitches!==false){
      // Short paired registration ticks keep stutter visibly different from a
      // charge travelling down the ribs. No pulse/flare currents are reused.
      for(const i of [0,3,6,9]){
        const u=.35+.12*((i+b.step)%4),p=at(i,u);
        const s=stutterSegment(b,p,p,u,i,false);if(!s)continue;
        const dx=s.dx*(v.reactionMotion??1)*(v.gates?.displacement??1);
        const start=[p[0]+dx,p[1]+s.dy,p[2],u];
        line(`${id}-register-${i}`,[start,[start[0]+side*5,start[1],p[2],u]],.85,s.gain*.75);
      }
    }
  }
  return out;
}

/** v10 reaction light. Each cue kind gets a short, distinct light signature on
 * the existing glow strokes (width and a gentle tint), so a reaction still reads
 * when the fine currents are a pixel wide at token size. Pure numbers per frame;
 * no geometry, no extra strokes, nothing allocated in the vertex loops. */
export const REACTION_TINTS=Object.freeze({
  base:Object.freeze({core:[255,222,252],bloom:[255,96,236]}),
  hot:Object.freeze({core:[255,250,255],bloom:[255,150,250]}),
  rose:Object.freeze({core:[255,238,240],bloom:[255,136,196]}),
  gold:Object.freeze({core:[255,242,212],bloom:[214,176,112]}),
  violet:Object.freeze({core:[236,220,255],bloom:[164,92,255]})
});
export const REACTION_KIND_TINT=Object.freeze({damage:'base',critical:'hot',heal:'gold',flare:'rose',pulse:'base',stutter:'violet',reform:'gold'});
const hit=(q,attack,release)=>ease(q/attack)*(1-ease((q-attack)/release));
const NO_LIGHT=Object.freeze({glow:0,tint:null,mix:0});
export function reactionLight(visual){
  if(!visual?.animated)return NO_LIGHT;
  const lists=[visual.bursts,visual.reactions];
  let glow=0,tint=null,mix=0;
  for(const list of lists)if(list?.length)for(const b of list){
    const q=b.progress,k=Math.min(1.2,b.amount??b.strength??0);
    if(!(q>0&&q<1)||!(k>0))continue;
    let g=0,m=0;
    switch(b.kind){
      case 'damage':g=.62*hit(q,.035,.4)-.16*bell((q-.22)/.6);m=.25*hit(q,.035,.3);break;
      case 'critical':g=.95*hit(q,.03,.22)+.75*hit(q-.3,.05,.45);m=.6*Math.max(hit(q,.03,.3),hit(q-.3,.05,.45));break;
      case 'flare':g=.85*ease(q/.32)*(1-ease((q-.32)/.62));m=.45*ease(q/.32)*(1-ease((q-.4)/.55));break;
      case 'heal':g=.5*bell(q);m=.7*bell(q);break;
      case 'reform':g=.55*bell((q-.4)/.55);m=.6*bell((q-.3)/.65);break;
      case 'pulse':
        if(b.id==='heartbeat')g=.5*bell(q/.33)+.42*bell((q-.5)/.33);
        else if(b.id==='orbit')g=.28*Math.sin(Math.PI*q);
        else g=-.28*bell(q/.25)+.62*bell((q-.19)/.55);
        m=.2*Math.max(0,g);break;
      case 'stutter':{
        // Each held slip dims the lattice a little; the release snaps back.
        const local=q*3-Math.min(2,Math.floor(q*3)),hold=ease((local-.055)/.07)*(1-ease((local-.62)/.17));
        g=-.38*hold;m=.45*hold;break;}
    }
    glow+=g*k;
    if(m*k>mix){mix=m*k;tint=REACTION_KIND_TINT[b.kind]??'base';}
  }
  return glow||mix?{glow:Math.max(-.45,Math.min(1.25,glow)),tint,mix:Math.min(.75,mix)}:NO_LIGHT;
}
