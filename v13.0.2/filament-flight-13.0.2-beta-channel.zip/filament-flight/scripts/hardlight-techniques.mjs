import {V7_MEDKIT_TECHNIQUES,v7MedkitBounds,paintV7MedkitTreatment} from './hardlight-v7-medkit.mjs?v=13.0.2';
import {sampleTreatmentOperations,treatmentScanOperation} from './treatment-choreography.mjs?v=13.0.2';
import {paintTreatmentSurface,SURFACE_BOUNDS} from './hardlight-surfaces.mjs?v=13.0.2';
import {RESTORATIVE_TECHNIQUES,restorativeBounds,paintRestorativeTreatment} from './hardlight-restorative.mjs?v=13.0.2';
import {REFINED_MEDKIT_STYLES,refinedMedkitBounds} from './hardlight-refined-medkit.mjs?v=13.0.2';
import {medicalOutcomeBounds} from './treatment-outcomes.mjs?v=13.0.2';
import {medicalFeedEmphasis} from './v9-medical-craft.mjs?v=13.0.2';
/** Eight independent instruments of hardlight medicine. All geometry is expressed
 * in patient-token units (100 = one diameter), with bounded work and no raster
 * assets, gradients, filters, random histories, or completion inferred from time. */
export const TECHNIQUES=Object.freeze({
  membrane:Object.freeze({name:'Protective membrane',mechanism:'Faceted canopy',period:5.2}),
  splint:Object.freeze({name:'Articulated splints',mechanism:'Hinged support rails',period:4.8}),
  helix:Object.freeze({name:'Helical traction',mechanism:'Axial screw and collars',period:5.6}),
  vascular:Object.freeze({name:'Perfusion channels',mechanism:'Branching infusion manifold',period:4.2}),
  compression:Object.freeze({name:'Compression seal',mechanism:'Four-jaw pressure iris',period:4.6}),
  precision:Object.freeze({name:'Precision instruments',mechanism:'Probe and field forceps',period:5.4}),
  suture:Object.freeze({name:'Suture weave',mechanism:'Needles and knotted seam',period:4.9}),
  microloom:Object.freeze({name:'Microloom dressing',mechanism:'Shuttle-woven diamond film',period:5.8}),
  ...RESTORATIVE_TECHNIQUES,
  ...V7_MEDKIT_TECHNIQUES
});
const TAU=Math.PI*2,clamp=n=>Math.max(0,Math.min(1,n)),smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const mix=(a,b,p)=>a+(b-a)*p,wrap=n=>(n%1+1)%1;
const WHITE='#fff7ef',PEARL='#ffe0f3',PINK='#ff78d2',GOLD='#efc897',ICE='#bce7ff';
const xy=(x,y,angle)=>[x*Math.cos(angle)-y*Math.sin(angle),x*Math.sin(angle)+y*Math.cos(angle)];
const rotator=angle=>{const c=Math.cos(angle),s=Math.sin(angle);return (x,y)=>[x*c-y*s,x*s+y*c];};
const bezier=(a,b,c,d,q)=>{const r=1-q;return [r*r*r*a[0]+3*r*r*q*b[0]+3*r*q*q*c[0]+q*q*q*d[0],r*r*r*a[1]+3*r*r*q*b[1]+3*r*q*q*c[1]+q*q*q*d[1]];};

/** Keep the front and rear halves of a single instrument joined at the token
 * plane. Dropping a straddling segment leaves a moving gap at every turn of
 * the traction screw. Both halves now terminate at the same interpolated z=0
 * point; authored samples and their depth assignment remain untouched. */
export function splitTreatmentDepthPath(points){
  if(!points.length)return [];
  const paths=[];let front=points[0][2]>=0,run=[points[0].slice(0,2)];
  for(let i=1;i<points.length;i++){
    const a=points[i-1],b=points[i],next=b[2]>=0;
    if(next!==front){
      const q=-a[2]/(b[2]-a[2]),cross=[mix(a[0],b[0],q),mix(a[1],b[1],q)];
      run.push(cross);paths.push({plane:front?'front':'rear',points:run});
      run=[cross];front=next;
    }
    run.push(b.slice(0,2));
  }
  paths.push({plane:front?'front':'rear',points:run});return paths;
}

/** These are the positions of the real, existing resonant housings. Unlike the
 * old shared orbit they describe each tool's job; tiny motion preserves poise. */
export function techniquePosition(style,i,count,t){
  return sampleTreatmentOperations(style,count,t)?.operations[i]?.position??null;
}
export function techniqueScanPosition(style,i,count,t){
  return sampleTreatmentOperations(style,count,0)?treatmentScanOperation(style,i,count,t/1.6).position:null;
}

/** Conservative explicit envelope for the renderer; emitters may be remote on
 * entry, but effect drawing starts after arrival. Includes glow stroke padding. */
export function techniqueBounds(effect){
  const base=baseTechniqueBounds(effect);
  // Reserve the ending envelope before resolution begins. A result should
  // never force a texture resize or clip outside the cached working viewport.
  const ending=effect.v7Medkit?medicalOutcomeBounds(effect):null;
  if(!ending)return base;
  if(!base){
    // Lattice and resonance use the original direct painter. Preserve its
    // conservative viewport and include remote feeds and orbital echoes.
    let radius=110;
    for(const e of effect.emitters??[])for(const p of [e,e.workPoint].filter(Boolean))radius=Math.max(radius,Math.hypot(p.x,p.y)*100+12);
    const x=Math.min(-radius,ending.x),y=Math.min(-radius,ending.y);
    return {x,y,width:Math.max(radius,ending.x+ending.width)-x,height:Math.max(radius,ending.y+ending.height)-y};
  }
  const x=Math.min(base.x,ending.x),y=Math.min(base.y,ending.y);
  return {x,y,width:Math.max(base.x+base.width,ending.x+ending.width)-x,height:Math.max(base.y+base.height,ending.y+ending.height)-y};
}
function baseTechniqueBounds(effect){
  if(effect.v7Medkit&&REFINED_MEDKIT_STYLES.includes(effect.style))return refinedMedkitBounds(effect);
  if(V7_MEDKIT_TECHNIQUES[effect.style])return v7MedkitBounds(effect);
  if(RESTORATIVE_TECHNIQUES[effect.style])return restorativeBounds(effect);
  const e=SURFACE_BOUNDS[effect.style];if(!e)return null;
  let left=-e[0],right=e[0],top=-e[1],bottom=e[1];
  for(const emitter of effect.emitters??[]){left=Math.min(left,emitter.x*100-5);right=Math.max(right,emitter.x*100+5);top=Math.min(top,emitter.y*100-5);bottom=Math.max(bottom,emitter.y*100+5);}
  return {x:left-4,y:top-4,width:right-left+8,height:bottom-top+8};
}

export function paintTechnique(ctx,effect,{plane='front'}={}){
  if(paintV7MedkitTreatment(ctx,effect,{plane}))return true;
  if(paintRestorativeTreatment(ctx,effect,{plane}))return true;
  const spec=TECHNIQUES[effect.style];if(!spec)return false;
  paintTreatmentSurface(ctx,effect,{plane});
  const front=plane!=='rear',quality=effect.detail==='low'?0:effect.detail==='high'?2:1;
  const scan=effect.phase==='scanning',finish=effect.phase==='finishing',p=clamp(effect.progress??0),t=Math.max(0,effect.clock??0);
  const success=finish&&['success','criticalSuccess'].includes(effect.outcome),critical=success&&effect.outcome==='criticalSuccess';
  const closure=success?smooth(p/.76):0,release=finish&&!success?smooth(p):0;
  const fade=finish?1-smooth((p-.78)/.22):1;
  const alpha=Math.max(0,effect.strength??1)*fade,entry=scan?smooth((effect.scan??p)*2):1;
  const q=wrap(t/spec.period),k=q*TAU,scanP=clamp(effect.scan??p);
  const stage=entry*(1-release),beat=.65+.35*Math.sin(k)**2,em=effect.emitters??[];
  const ink=(a,c=PINK,w=.65)=>{ctx.globalAlpha=clamp(a*alpha);ctx.strokeStyle=c;ctx.fillStyle=c;ctx.lineWidth=w;};
  const halo=width=>{if(quality>0&&width>=.7){const a=ctx.globalAlpha;ctx.globalAlpha=a*.14;ctx.lineWidth=width*4;ctx.stroke();ctx.globalAlpha=a;ctx.lineWidth=width;}ctx.stroke();};
  const path=(points,a=.7,w=.65,c=PINK,fill=0,close=false)=>{if(points.length<2||a*alpha<.002)return;ink(a,c,w);ctx.beginPath();for(let i=0;i<points.length;i++)i?ctx.lineTo(...points[i]):ctx.moveTo(...points[i]);if(close)ctx.closePath();if(fill){const old=ctx.globalAlpha;ctx.globalAlpha*=fill;ctx.fill();ctx.globalAlpha=old;}halo(w);};
  const line=(a,b,o=.7,w=.65,c=PINK)=>path([a,b],o,w,c);
  const dot=(x,y,r=1,o=.85,c=WHITE)=>{if(o*alpha<.002)return;ink(o,c);ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();};
  const ellipse=(x,y,rx,ry,angle=0,o=.6,w=.65,c=PINK,start=0,end=TAU)=>{if(o*alpha<.002||rx<=0||ry<=0)return;ink(o,c,w);ctx.beginPath();ctx.ellipse(x,y,rx,ry,angle,start,end);halo(w);};
  const curve=(a,b,c,d,o=.7,w=.65,color=PINK)=>{if(o*alpha<.002)return;ink(o,color,w);ctx.beginPath();ctx.moveTo(...a);ctx.bezierCurveTo(...b,...c,...d);halo(w);};
  const beam=(index,point,o=.5,operation=false)=>{const e=em[index];if(!e||(e.z>=0)!==front||e.workPoint&&!operation)return;if(e.workPoint)point=[e.workPoint.x*100,e.workPoint.y*100];o*=(e.activity==null?1:.55+e.activity*.65)*medicalFeedEmphasis(effect,index);const from=[e.x*100,e.y*100];line(from,point,o*.25,2,PEARL);line(from,point,o,.5,PEARL);if(quality>0){const v=wrap(t*.55+index*.5),at=[mix(from[0],point[0],v),mix(from[1],point[1],v)];dot(...at,.85,o*Math.sin(Math.PI*v),WHITE);}};
  const mark=(x,y,r=2,o=.7,c=GOLD)=>path([[x,y-r],[x+r,y],[x,y+r],[x-r,y]],o,.55,c,0,true);
  const splitCurve=(points,o,w,c)=>{
    if(effect.v7Medkit){for(const run of splitTreatmentDepthPath(points))if((run.plane==='front')===front)path(run.points,o,w,c);return;}
    // The established opt-out retains its exact original patient artwork.
    let run=[];for(const point of points){if((point[2]>=0)===front)run.push(point.slice(0,2));else if(run.length){path(run,o,w,c);run=[];}}if(run.length)path(run,o,w,c);
  };
  ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
  // Small emitter contact marks link effects to the preserved physical housing.
  for(let i=0;i<em.length;i++){
    const e=em[i];if((e.z>=0)!==front)continue;
    dot(e.x*100,e.y*100,.8,.7*entry,PEARL);
    if(e.workPoint){
      beam(i,null,.66*stage,true);
      const wp=e.workPoint,x=wp.x*100,y=wp.y*100;
      ellipse(x,y,2.6+1.2*(e.activity??.5),1.5,Math.atan2(y-e.y*100,x-e.x*100),.65*stage,.7,WHITE);
      if(quality>0&&e.stage==='check')mark(x,y,4,.48*stage,ICE);
    }
  }

  if(effect.style==='membrane'){
    // A six-panel glass bell is assembled around the patient. Its projected
    // ribs occupy real depth planes; no filled disc obscures the token.
    const spread=scan?smooth(scanP):1,radius=48*spread*(1-.10*closure+.10*release),height=57*spread*(1-.16*release);
    for(let i=0;i<6;i++){
      const a=i*TAU/6+Math.PI/6,visible=(Math.sin(a)>=0)===front;if(!visible)continue;
      const x=Math.cos(a)*radius,z=Math.sin(a),edge=[x,17+z*12],tip=[0,-height];
      curve(tip,[x*.82,-height+10],[x*1.28,-12],edge,(.35+Math.abs(z)*.28)*entry,.82,PEARL);
      const next=(i+1)*TAU/6+Math.PI/6,nx=Math.cos(next)*radius,nz=Math.sin(next);
      if((nz>=0)===front){
        curve(edge,[x*.78,43],[nx*.78,43],[nx,17+nz*12],.56*entry,.72,PINK);
        if(front){path([tip,[x*.75,-28],edge,[nx,17+nz*12],[nx*.75,-28]],.20*entry,.45,ICE,.35,true);}
      }
      if(!scan&&quality>0&&!effect.v9MedicalCraft){const sweep=wrap(q+i/6),y=-height+78*sweep,wide=Math.sin(Math.PI*sweep*.9);line([x*wide*.88,y],[x*wide,y+1.8],.55*Math.sin(Math.PI*sweep)*stage,.65,WHITE);}
    }
    if(front){
      const y=scan?-48+90*scanP:-47+84*q,half=Math.sqrt(Math.max(0,1-((y+3)/53)**2))*radius;
      if(!effect.v9MedicalCraft)curve([-half,y],[-half*.4,y+8],[half*.4,y+8],[half,y],(scan?.85:.48*smooth(q/.08)*(1-smooth((q-.9)/.1)))*entry,.85,WHITE);
      mark(0,-height,3,.8*entry);path([[-9,43],[0,49],[9,43]],.6*stage,.65,GOLD);
      if(closure){curve([0,-53],[-4,-19],[4,11],[0,39],closure,1.15,WHITE);for(const s of [-1,1])curve([0,-53],[s*47,-23],[s*44,29],[0,41],closure*.72,.8,GOLD);}
      if(critical)for(const s of [-1,1])curve([0,-57],[s*57,-25],[s*54,33],[0,49],Math.sin(Math.PI*p)*.7,.7,ICE);
    }
    beam(0,[-35,-21],.6*entry);beam(1,[35,-21],.6*entry);
  }

  if(effect.style==='splint'){
    // Independent solid rails unfold at seven visible hinges. Their long
    // engineering silhouette stays distinct from the radial pressure iris.
    const align=(scan?smooth(scanP)*.45:success?.55+.45*closure:.55+.035*Math.sin(k))*(1-release);
    for(const s of [-1,1]){
      const rail=[[-42,s*(24+11*(1-align))],[-25,s*(32-5*align)],[-7,s*(29-8*align)],[13,s*(30-8*align)],[32,s*(25+4*(1-align))],[43,s*23]];
      if(front){
        for(let j=0;j<rail.length-1;j++){
          const [y,x]=rail[j],[ny,nx]=rail[j+1],build=scan?smooth(scanP*2-j*.16):stage;
          path([[x-2.4,y+2.6],[x+2.4,y+2.6],[nx+2.4,ny-2.6],[nx-2.4,ny-2.6]],.78*build,.8,PEARL,.17,true);
          if(quality>0)line([x,y+5],[nx,ny-5],.45*build,.5,GOLD);
        }
        for(const [y,x] of rail){ellipse(x,y,2.8,2.8,0,.8*entry,.65,GOLD);dot(x,y,.7,.8*entry);}
        const pointer=-35+70*(.5-.5*Math.cos(k));path([[s*41,pointer-4],[s*36,pointer],[s*41,pointer+4]],.75*stage,.8,WHITE);
        if(scan)line([s*42,-43],[s*42,-43+86*scanP],.75*entry,.8,ICE);
        if(closure)for(const y of [-28,27]){path([[s*23,y-3],[s*15,y],[s*23,y+3]],closure,.9,GOLD);mark(s*23,y,4,closure,WHITE);}
      }else for(const y of [-28,27])curve([s*24,y],[s*48,y-12],[s*54,y+12],[s*25,y+8],.36*entry,.8,PINK);
    }
    if(front){
      if(quality>0)for(const y of [-35,-18,0,18,35])line([-17,y],[17,y],.13*stage,.45,ICE);
      if(critical)for(const s of [-1,1])path([[s*32,-47],[s*40,-47],[s*44,-39]],Math.sin(Math.PI*p)*.85,.9,GOLD);
    }
    beam(0,[-31,24],.6*entry);beam(1,[31,24],.6*entry);
  }

  if(effect.style==='helix'){
    // One coherent three-turn screw is seen both in front of and behind the
    // portrait. The floating axial collars pull in opposite directions.
    const radius=scan?29*smooth(scanP):29-5*closure+4*release,extent=48+5*(1-closure),segments=quality===0?30:48;
    for(let ribbon=0;ribbon<2;ribbon++){
      const points=[];for(let j=0;j<=segments;j++){
        const u=j/segments,a=u*TAU*(2.5-.7*release)+t/spec.period*TAU*.65+ribbon*.2,y=-extent+u*extent*2;
        points.push([Math.cos(a)*radius,y,Math.sin(a)]);
      }
      splitCurve(points,(ribbon?.3:.85)*entry,ribbon?.5:1,ribbon?ICE:PEARL);
    }
    for(const s of [-1,1]){
      const y=s*extent,start=front?0:Math.PI,end=front?Math.PI:TAU;
      ellipse(0,y,radius+8,9,0,.8*entry,.85,GOLD,start,end);
      ellipse(0,y-s*5,radius+3,7,0,.5*entry,.6,PINK,start,end);
      if(front){path([[-6,y+s*11],[0,y+s*16],[6,y+s*11]],.75*entry,.8,WHITE);if(closure)line([-radius,y],[radius,y],closure,.95,WHITE);}
    }
    if(front){
      if(scan){const y=-48+96*scanP;line([-36,y],[36,y],.75*entry,.7,ICE);mark(0,y,3,entry,WHITE);}
      else if(quality>0)for(let j=0;j<5;j++)mark(0,-36+j*18,1.3,.27*stage,ICE);
      if(closure)line([0,-47],[0,47],closure,.85,WHITE);
      if(critical)for(const s of [-1,1])path([[s*8,-59],[s*12,-59],[s*12,59],[s*8,59]],Math.sin(Math.PI*p)*.65,.55,ICE);
    }
    beam(0,[0,-extent],.6*entry);beam(1,[0,extent],.6*entry);
  }

  if(effect.style==='vascular'){
    // Two ports feed a branching circuit, rather than a generic tree painted
    // once. Moving packets split at junctions and collect in terminal wells.
    const branches=quality===0?4:6;
    if(!front){
      curve([-44,-38],[-64,-13],[-58,28],[-40,39],.3*entry,.8,ICE);
      curve([40,-39],[58,-28],[64,13],[44,38],.3*entry,.8,PINK);
    }else{
      const trunk=[[-24,35],[-25,7],[25,-7],[24,-35]];
      curve(...trunk,.8*entry,1.25,PEARL);
      for(let j=0;j<branches;j++){
        const u=(j+1)/(branches+1),base=bezier(...trunk,u),s=j%2?1:-1,end=[mix(s*(36-j%2*3),base[0],release*.6),base[1]-s*14*(1-release*.6)];
        const a=base,b=[base[0]+s*15,base[1]],c=[end[0]-s*9,end[1]],d=end,growth=scan?smooth(scanP*1.75-j*.10):stage;
        curve(a,b,c,d,.62*growth,.75,j%2?PINK:ICE);
        if(quality>0){const fork=bezier(a,b,c,d,.62);curve(fork,[fork[0]+s*4,fork[1]-7],[end[0]+s*4,end[1]-7],[end[0]+s*6,end[1]-10],.32*growth,.5,PEARL);}
        ellipse(...end,3.5,3.5,0,.5*growth,.65,GOLD);mark(...base,1.7,.6*growth,GOLD);
        const v=wrap(t/spec.period*1.6-j*.15),at=bezier(a,b,c,d,v);dot(...at,1.6,.92*growth*smooth(v/.12)*(1-smooth((v-.86)/.14)),WHITE);
        if(closure){dot(...end,1.3,closure,WHITE);ellipse(...end,5.8,5.8,0,closure*.5,.65,ICE);}
      }
      for(const s of [-1,1]){
        const x=s*24,y=-s*35;
        path([[x-6,y-8],[x+6,y-8],[x+6,y+8],[x-6,y+8]],.75*entry,.75,PEARL,.13,true);
        for(let n=0;n<3;n++)line([x-3,y-4+n*4],[x+3,y-4+n*4],.6*entry,.6,s<0?ICE:GOLD);
      }
      if(scan){const at=bezier(...trunk,scanP);ellipse(...at,6,3,-.7,.8*entry,.8,WHITE);}
      if(critical){curve(...trunk,Math.sin(Math.PI*p)*.8,2,GOLD);}
    }
    beam(0,[-24,35],.62*entry);beam(1,[24,-35],.62*entry);
  }

  if(effect.style==='compression'){
    // Four bevelled jaws close over a small off-center seal. The surrounding
    // pressure spokes change length; there is no repeated full-token pulse.
    const press=scan?smooth(scanP)*.3:success?.48+.52*closure:.48+.055*Math.sin(k)-release*.36,gap=27-13*press;
    for(let i=0;i<4;i++){
      const angle=i*Math.PI/2+Math.PI/4;if(!front)continue;const rotate=rotator(angle);
      const pts=[[gap,-10],[gap+15,-17],[gap+26,-9],[gap+26,9],[gap+15,17],[gap,10]].map(([x,y])=>rotate(x,y));
      path(pts,.75*entry,.9,PEARL,.11,true);
      path([[gap+7,-9],[gap+15,-12],[gap+20,-6],[gap+20,6],[gap+15,12],[gap+7,9]].map(([x,y])=>rotate(x,y)),.5*entry,.55,GOLD);
      line(rotate(gap,-7),rotate(gap,7),.92*entry,1.2,WHITE);
      for(let j=0;j<(quality===0?2:4);j++){
        const r=gap+4+j*4,on=.3+.45*smooth(press*4-j*.28);line(rotate(r,-2),rotate(r,2),on*entry,.6,PINK);
      }
    }
    if(!front)for(const s of [-1,1])curve([s*39,-42],[s*67,-23],[s*67,23],[s*39,42],.3*entry,.85,PINK);
    if(front){
      const r=gap*.7;path([[-r,0],[0,-r],[r,0],[0,r]],.65*entry,.8,PINK,.045,true);
      if(scan){for(const s of [-1,1])path([[s*43,-5],[s*(43-21*scanP),0],[s*43,5]],.65*entry,.7,ICE);}
      else{
        const r2=3+5*(1-closure);mark(0,0,r2,.85*stage,WHITE);
        for(const s of [-1,1])line([s*(r+4),0],[s*(r+10),0],.7*stage,.75,GOLD);
      }
      if(closure){path([[-8,0],[-2,6],[10,-8]],closure,.95,WHITE);path([[-15,0],[0,-15],[15,0],[0,15]],closure,.9,GOLD,0,true);}
      if(critical)path([[-21,0],[0,-21],[21,0],[0,21]],Math.sin(Math.PI*p)*.8,.8,ICE,0,true);
    }
    beam(0,[-37,-20],.58*entry);beam(1,[37,20],.58*entry);
  }

  if(effect.style==='precision'){
    // An upper microprobe and a lower field forceps perform alternating jobs.
    // Tool tips change geometry; a small oblique tile tracks their measurement.
    const tip=[-3+5*Math.sin(k),-2+13*Math.sin(k)],probe=[[-43,-30],[-27,-29],[tip[0]-7,tip[1]-8],tip];
    const held=[tip[0]+12,tip[1]+7],jaw=scan?6:3.5+1.8*Math.sin(k)+release*4;
    if(front){
      path(probe,.9*entry,1.1,PEARL);ellipse(-27,-29,3.2,3.2,0,.85*entry,.7,GOLD);
      const normal=xy(0,3,-.65);path([[tip[0]-normal[0],tip[1]-normal[1]],tip,[tip[0]+normal[0],tip[1]+normal[1]]],.95*entry,.7,WHITE);
      path([[43,29],[30,28],[held[0]+10,held[1]+8],held],.85*entry,1.1,GOLD);
      for(const s of [-1,1])path([[held[0]+9,held[1]+6],[held[0]+s*jaw,held[1]+s*jaw],[held[0]-6+s*jaw*.65,held[1]-5+s*jaw*.65]],.85*entry,.7,WHITE);
      ellipse(30,28,3,3,0,.75*entry,.7,PEARL);
      line(tip,held,.3*stage,.5,ICE);dot(...tip,1.3,.85*entry,WHITE);
      const tile=[[-13,-47],[17,-40],[17,-23],[-13,-30]];path(tile,.48*entry,.55,ICE,.1,true);
      if(quality>0)for(let j=0;j<3;j++){const y=-40+j*4;line([-9,y],[10-j*4,y+4],.45*entry,.5,ICE);}
      const scanRadius=scan?12-7*scanP:5;
      ellipse(...tip,scanRadius,scanRadius*.55,-.65,.8*entry,.65,PEARL);
      if(!scan){curve([-13,18],[-8,7],[0,2],[8,-15],.4*stage,.6,PINK);if(quality>0)for(let j=0;j<3;j++)dot(tip[0]-j*2,tip[1]+j*3,.65,stage*.45);}
      if(closure){curve([-13,18],[-8,7],[0,2],[8,-15],closure,1.15,WHITE);path([[22,-31],[25,-27],[32,-35]],closure,.85,GOLD);}
      if(critical)for(const s of [-1,1])curve([s*19,-19],[s*25,-6],[s*25,6],[s*19,19],Math.sin(Math.PI*p)*.65,.75,ICE);
    }else{
      path([[-48,-39],[-54,-25],[-48,-10]],.33*entry,.8,PINK);path([[48,12],[54,27],[48,40]],.33*entry,.8,GOLD);
    }
    beam(0,[-43,-30],.64*entry);beam(1,[43,29],.64*entry);
  }

  if(effect.style==='suture'){
    // A diagonal seam, visible needle arcs and staggered knots. Each loop is
    // tensioned independently; the final draw-through occurs only on outcome.
    const angle=-.42,gap=success?6*(1-closure):6+.7*Math.sin(k)+release*5,rows=quality===0?5:7;
    const tr=rotator(angle);
    if(front){
      for(const s of [-1,1])curve(tr(s*gap,-34),tr(s*(gap+2),-12),tr(s*(gap-1),12),tr(s*gap,34),.54*entry,.8,PINK);
      for(let j=0;j<rows;j++){
        const y=-28+j*56/(rows-1),built=scan?smooth(scanP*1.7-j*.12):1,pull=success?closure:.38+.22*(.5-.5*Math.cos(TAU*(t/spec.period*1.5-j*.10)));
        const bow=8*(1-pull+release*.7),a=tr(-gap,y-2),b=tr(-gap-9,y-bow),c=tr(gap+9,y+bow),d=tr(gap,y+2);
        curve(a,b,c,d,.83*built*(1-release),.83,PEARL);
        if(quality>0){dot(...a,.8,.7*built,GOLD);dot(...d,.8,.7*built,GOLD);}
        if(closure)mark(...tr(0,y),1.4,closure,WHITE);
      }
      const y=-26+52*q;
      for(const s of [-1,1]){
        const needle=tr(s*(gap+10),s*y),a=angle+s*.65;
        ellipse(...needle,7,3.2,a,.85*entry,.95,GOLD,.15,Math.PI*1.55);
        curve(needle,tr(s*(gap+17),s*y+15),tr(s*(gap+4),s*y+9),tr(s*gap,s*y),.72*entry,.55,WHITE);
      }
      if(scan){line(tr(-17,y),tr(17,y),.65*entry,.8,ICE);}
      if(closure)curve(tr(0,-35),tr(-1,-10),tr(1,10),tr(0,35),closure,1,WHITE);
      if(critical)for(const s of [-1,1])curve(tr(s*11,-34),tr(s*20,-8),tr(s*20,8),tr(s*11,34),Math.sin(Math.PI*p)*.7,.65,GOLD);
    }else for(const s of [-1,1])curve(tr(s*23,-38),tr(s*47,-18),tr(s*47,18),tr(s*23,38),.22*entry,.6,PINK);
    beam(0,tr(-gap-10,-26+52*q),.6*entry);beam(1,tr(gap+10,26-52*q),.6*entry);
  }

  if(effect.style==='microloom'){
    // An oblique loom is an actual planar woven dressing, with alternating
    // over/under passes and a moving shuttle; not another vertical seam.
    const angle=-.55,rows=quality===0?5:8,cols=quality===0?5:8,spread=scan?smooth(scanP):1,half=26*spread;
    const tr=rotator(angle);
    if(front){
      const frame=[tr(-half-4,-half-3),tr(half+4,-half-3),tr(half+4,half+3),tr(-half-4,half+3)];
      path(frame,.64*entry,.9,GOLD,.045,true);
      for(let i=0;i<cols;i++){
        const x=-half+(i+.5)*half*2/cols;
        line(tr(x,-half),tr(x,half),.4*entry,.5,PINK);
        if(quality>0){dot(...tr(x,-half-3),.8,.8*entry,GOLD);dot(...tr(x,half+3),.8,.8*entry,GOLD);}
      }
      for(let j=0;j<rows;j++){
        const y=-half+(j+.5)*half*2/rows,growth=scan?smooth(scanP*2-j*.13):1;
        const points=[];for(let i=0;i<=cols*2;i++)points.push(tr(-half+i*half/cols,y+((i+j)%2?.8:-.8)*(1-closure)));
        path(points,.72*growth*(1-release),.65,PEARL);
      }
      const shuttleY=-half+2*half*q,shuttleX=Math.sin(k*3)*half;
      path([tr(shuttleX-6,shuttleY),tr(shuttleX,shuttleY-3),tr(shuttleX+6,shuttleY),tr(shuttleX,shuttleY+3)],.93*entry,.85,WHITE,.18,true);
      if(!scan)line(tr(-half,shuttleY),tr(shuttleX,shuttleY),.8*stage,.8,ICE);
      if(closure){path(frame,closure,1,WHITE,0,true);for(const corner of frame)mark(...corner,2.5,closure,GOLD);}
      if(critical)path([tr(-half-8,-half-7),tr(half+8,-half-7),tr(half+8,half+7),tr(-half-8,half+7)],Math.sin(Math.PI*p)*.65,.7,ICE,0,true);
    }else{
      for(const s of [-1,1])curve(tr(s*37,-33),tr(s*49,-16),tr(s*49,16),tr(s*37,33),.32*entry,.75,PINK);
    }
    beam(0,tr(-half,-half),.6*entry);beam(1,tr(half,half),.6*entry);
  }
  // An unsuccessful or interrupted procedure releases its own instrument shape
  // above. It never draws a closure, completion tick, knot or resolved seal.
  ctx.restore();return true;
}
