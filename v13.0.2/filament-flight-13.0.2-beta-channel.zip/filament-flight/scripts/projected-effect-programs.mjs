import {EXPANDED_PROJECTED_EFFECT_PROGRAMS,expandedProjectedEffectPoint,expandedProjectedEffectDuty,drawExpandedProjectedEffect} from './projected-effect-expansion.mjs?v=13.0.2';
/** V6.1 working fields. Pure geometry; bounded by four instruments and fixed
 * samples. Motion/focus contain directions only, never token names or IDs. */
const TAU=Math.PI*2;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const unit=n=>clamp(Number.isFinite(n)?n:0,0,1);
const ease=n=>{n=unit(n);return n*n*(3-2*n);};
const frac=n=>((n%1)+1)%1;
const point=(a,r,ry=r,cx=0,cy=0)=>[cx+Math.cos(a)*r,cy+Math.sin(a)*ry];
const definition=(id,label,category,description,state,jobs)=>Object.freeze({id,label,category,description,state,jobs:Object.freeze(jobs)});
export const PROJECTED_EFFECT_PROGRAMS=Object.freeze([
  definition('kineticBracing','Kinetic bracing','protective','Directional tension braces oppose movement, holding articulated support points rather than enclosing the token.','bracing',['Counterweight','Opposing anchors','Keystone and braces','Paired crossbraces']),
  definition('groundingArray','Grounding array','protective','Branching discharge paths carry erratic energy down into grounded contact shoes and settle after each release.','conducting',['Single drain','Alternating drains','Collector and drains','Balanced grounding grid']),
  definition('decontamination','Decontamination','restorative','Close cleaning heads isolate traces on the surface, draw them into collection cells, and quietly neutralise them.','scanning',['Sweep and collect','Cleaner and collector','Paired cleaners and filter','Two independent cleaning teams']),
  definition('nerveCalm','Nerve calm','restorative','Small contact pads resolve irregular branching signals into calm coordinated impulses without a heartbeat monitor.','aligning',['Sequential contacts','Bilateral contacts','Upper and lower coordination','Four-point regulation']),
  definition('phaseVeil','Phase veil','awareness','Offset refraction shutters soften the silhouette in sections, turning and overlapping as their bits maintain the veil.','aligning',['Travelling shutter','Counterpoised shutters','Three-facet veil','Layered refraction cloak']),
  definition('focusLock','Focus lock','awareness','Aperture lenses converge toward your currently visible target; without a visible target they hold a resting optical alignment.','aligning',['Sighting lens','Stereo alignment','Range and alignment','Four-lens convergence']),
  definition('emergencyReserve','Emergency reserve','expressive','A compact external cell bank gathers energy, stores it in separate chambers and feeds measured support pulses to the token.','charging',['One reserve cell','Charge and delivery','Collector, store and feed','Redundant twin reserves']),
  definition('impulseDrive','Impulse drive','expressive','Compact vector nozzles release directional exhaust while the attended token moves, returning to a small idle charge when still.','conducting',['Central impulse','Balanced vector pair','Vector triangle','Four-corner drive']),
  ...EXPANDED_PROJECTED_EFFECT_PROGRAMS
]);
export const PROJECTED_EFFECT_IDS=Object.freeze(PROJECTED_EFFECT_PROGRAMS.map(p=>p.id));
const IDS=new Set(PROJECTED_EFFECT_IDS),BY_ID=new Map(PROJECTED_EFFECT_PROGRAMS.map(p=>[p.id,p]));
export const isProjectedEffect=id=>IDS.has(id);

export function projectedEffectDirections(options={}){
  const direction=(raw,fallback)=>{
    const x=Number.isFinite(raw?.x)?raw.x:0,y=Number.isFinite(raw?.y)?raw.y:0,l=Math.hypot(x,y);
    return l>.0001?[x/l,y/l]:fallback;
  };
  return {motion:direction(options.motion,[0,-1]),amount:unit(options.motion?.amount),focus:direction(options.focus,[0,-1]),hasFocus:!!options.focus&&Number.isFinite(options.focus.x)&&Number.isFinite(options.focus.y)&&Math.hypot(options.focus.x,options.focus.y)>.0001};
}
// Shared work-site coordinates make the visible currents, the tools' aiming,
// and their geometric surfaces agree. Group size changes the actual job layout.
export function projectedEffectWorkingPoint(id,i,n,t,options={}){
  const {motion:[mx,my],focus:[fx,fy]}=projectedEffectDirections(options),a=-Math.PI/2+i*TAU/n;
  switch(id){
    case 'kineticBracing':{const phase=n===1?Math.sin(t*.22)*.2:(i-(n-1)/2)*(.65+1/n),angle=Math.atan2(my,mx)+Math.PI+phase;return point(angle,43,46);}
    case 'groundingArray':return [n===1?0:(i/(n-1)-.5)*91,49+Math.sin(i*1.7)*3];
    case 'decontamination':{const p=frac(t*.10+i/n),side=n===1?Math.cos(t*.36):i%2?-1:1;return [side*(28+5*Math.sin(p*TAU)), -36+p*70];}
    case 'nerveCalm':return n===1?[0,-11+13*Math.sin(t*.42)]:point(a,26,31,0,3);
    case 'phaseVeil':return point(a+t*.13,38,41);
    case 'focusLock':{const spread=(i-(n-1)/2)*(n>2?15:24);return [fx*53-fy*spread,fy*53+fx*spread];}
    case 'emergencyReserve':return [61+(i%2)*9,-31+Math.floor(i/2)*25];
    case 'impulseDrive':{const spread=(i-(n-1)/2)*(n===2?29:21);return [-mx*43-my*spread,-my*43+mx*spread];}
    default:return expandedProjectedEffectPoint(id,i,n,t,options);
  }
}

/** Per-bit duties share a slow phase rather than independent random flashes.
 * Used by both physical core activity and the projection's source light. */
export function projectedEffectDuty(id,index,count,t,options={}){
  if(!IDS.has(id))return null;
  const expanded=expandedProjectedEffectDuty(id,index,count,t);if(expanded)return expanded;
  const cycle=frac(t/7.5+index/Math.max(1,count)),work=.5-.5*Math.cos(cycle*TAU),motion=projectedEffectDirections(options).amount;
  const states={kineticBracing:'bracing',groundingArray:'conducting',decontamination:index%2&&count>1?'charging':'scanning',nerveCalm:'aligning',phaseVeil:'aligning',focusLock:'aligning',emergencyReserve:index%2?'conducting':'charging',impulseDrive:'conducting'};
  return {state:states[id],amount:.62+.3*work,energy:id==='impulseDrive'?.72+motion*.65:.86+.24*work,role:BY_ID.get(id).jobs[Math.max(0,Math.min(3,count-1))]};
}

export function drawProjectedEffect(id,{n,t,detail,options,add,curve,ellipse,splitEllipse,diamond}){
  if(!IDS.has(id))return false;
  if(drawExpandedProjectedEffect(id,{n,t,detail,options,add,curve,ellipse,splitEllipse,diamond}))return true;
  const d=projectedEffectDirections(options),low=options.detail==='low',steps=low?8:14;
  const at=i=>projectedEffectWorkingPoint(id,i,n,t,options);
  const path=(points,opts={})=>add(points,{...opts,work:opts.work??'working-surface'});
  const local=(p,c,angle)=>[c[0]+p[0]*Math.cos(angle)-p[1]*Math.sin(angle),c[1]+p[0]*Math.sin(angle)+p[1]*Math.cos(angle)];
  switch(id){
    case 'kineticBracing':{
      const force=.2+.8*d.amount,angle=Math.atan2(d.motion[1],d.motion[0]);
      for(let i=0;i<n;i++){
        const c=at(i),out=[c[0]*1.55,c[1]*1.45],across=[-Math.sin(angle)*8,Math.cos(angle)*8],hinge=[(c[0]+out[0])*.5-d.motion[0]*force*4,(c[1]+out[1])*.5-d.motion[1]*force*4];
        path([[c[0]+across[0],c[1]+across[1]],c,[c[0]-across[0],c[1]-across[1]]],{alpha:.85,width:1.2,highlight:true});
        path([c,hinge,out],{alpha:.65,width:1.1,glow:true,work:'tension-brace'});
        path([[out[0]-across[0],out[1]-across[1]],[out[0]+across[0],out[1]+across[1]]],{alpha:.62,width:1.4});
        const coil=Array.from({length:7},(_,j)=>{const u=j/6;return [c[0]+(out[0]-c[0])*u+across[0]*.18*Math.sin(j*Math.PI/2+t*.8),c[1]+(out[1]-c[1])*u+across[1]*.18*Math.sin(j*Math.PI/2+t*.8)];});
        path(coil,{alpha:.2+.35*force,width:.6});
        diamond(...hinge,2.4,{alpha:.8,highlight:true});
      }
      if(n>=3){const a=at(0),b=at(n-1);path([a,[0,9],b],{alpha:.23,width:.6,work:'load-sharing'});}break;
    }
    case 'groundingArray':{
      for(let i=0;i<n;i++){
        const c=at(i),phase=frac(t*.27+i/n),activity=.22+.78*Math.sin(phase*Math.PI)**4,top=[c[0]*.63,-35-i%2*9];
        const spine=Array.from({length:7},(_,j)=>[top[0]+(c[0]-top[0])*j/6+Math.sin(j*2.73+i+t*1.9)*3.5*activity,top[1]+(c[1]-top[1])*j/6]);
        path(spine,{alpha:.56*activity,width:1.0,glow:true,work:'discharge'});
        for(const side of [-1,1])path([spine[2],[spine[2][0]+side*8,spine[2][1]+8],[spine[4][0]+side*12,spine[4][1]+5],c],{alpha:.42*activity,width:.65});
        path([[c[0]-9,c[1]-2],[c[0]-5,c[1]+3],[c[0]+5,c[1]+3],[c[0]+9,c[1]-2]],{alpha:.8,width:1.1,highlight:true,work:'ground-shoe'});
        for(let row=0;row<2;row++)path([[c[0]-5+row*2,c[1]+6+row*3],[c[0]+5-row*2,c[1]+6+row*3]],{alpha:.55-row*.1,width:.75});
        const p=phase,idx=Math.floor(p*5),a=spine[idx],b=spine[idx+1];path([a,b],{alpha:.85*activity,width:1.15,highlight:true});
      }break;
    }
    case 'decontamination':{
      for(let i=0;i<n;i++){
        const c=at(i),side=c[0]<0?-1:1,cell=[side*60,-25+i*14],phase=frac(t*.32+i*.27),collect=ease(phase),p=[c[0]+(cell[0]-c[0])*collect,c[1]+(cell[1]-c[1])*collect];
        // A small moving cleaning shoe with a leading edge, not a full-token
        // medical lattice or a radar fan. Collection cells sit off the skin.
        path([[c[0]-6,c[1]-7],[c[0]+6,c[1]-7],[c[0]+6,c[1]+7],[c[0]-6,c[1]+7]],{closed:true,alpha:.48,fill:.07});
        path([[c[0]-7,c[1]-5],[c[0]+7,c[1]-5]],{alpha:.82,width:1.3,highlight:true,work:'cleaning-edge'});
        curve(u=>[c[0]+(cell[0]-c[0])*u,c[1]+(cell[1]-c[1])*u-Math.sin(u*Math.PI)*6],{steps:6,alpha:.16,width:.45});
        diamond(...p,1.1+Math.sin(phase*Math.PI)*1.3,{alpha:.95*Math.sin(phase*Math.PI),highlight:true,work:'captured-trace'});
        path([[cell[0]-5,cell[1]-6],[cell[0]+5,cell[1]-6],[cell[0]+6,cell[1]+4],[cell[0],cell[1]+7],[cell[0]-6,cell[1]+4]],{closed:true,alpha:.62,fill:.065,work:'collection-cell'});
        if(!low)path([[cell[0]-2,cell[1]+2],[cell[0]+2,cell[1]-2]],{alpha:.3+.4*ease((phase-.65)/.35),highlight:true});
      }break;
    }
    case 'nerveCalm':{
      const settle=.5-.5*Math.cos(t*.31),irregular=.25+.75*(1-settle);
      for(let i=0;i<n;i++){
        const c=at(i),side=c[0]<0?-1:1,end=[c[0]*.27,c[1]*.35],a=Math.atan2(end[1]-c[1],end[0]-c[0]);
        path([[-4,-2],[-4,2],[4,2],[4,-2]].map(p=>local(p,c,a)),{closed:true,alpha:.65,fill:.10,highlight:true,work:'contact-pad'});
        const nerve=Array.from({length:steps+1},(_,j)=>{const u=j/steps,w=Math.sin(u*Math.PI);return [c[0]+(end[0]-c[0])*u,c[1]+(end[1]-c[1])*u+w*(Math.sin(u*18+t*3+i)*2.5*irregular)];});
        path(nerve,{alpha:.72,width:.9,glow:true,work:'regulated-signal'});
        const mid=nerve[Math.floor(steps*.55)];path([mid,[mid[0]+side*5,mid[1]-9],[mid[0]+side*10,mid[1]-13]],{alpha:.3,width:.6});
        const q=frac(t*.3+i/n),j=Math.min(steps-1,Math.floor(q*steps));path([nerve[j],nerve[j+1]],{alpha:.8,width:1.2,highlight:true});
        if(n>1&&i<n-1){const next=at(i+1);curve(u=>[c[0]+(next[0]-c[0])*u,c[1]+(next[1]-c[1])*u+Math.sin(u*Math.PI)*4],{steps:6,alpha:.10+settle*.09,width:.5});}
      }break;
    }
    case 'phaseVeil':{
      for(let i=0;i<n;i++){
        const a=-Math.PI/2+i*TAU/n+t*.13,c=at(i),plane=n===1||i%2===0?'front':'rear',breath=.5+.5*Math.sin(t*.48+i*1.3),length=40+n*3;
        // Thin, curved refractive sheets overlap the silhouette. Their sheared
        // echoes and travelling edge ripple read as displaced light, not armor.
        const rail=(u,offset=0)=>{
          const tangent=(u-.5)*length*2,wave=Math.sin(u*Math.PI*2+t*.55+i)*3+Math.sin(u*Math.PI)*5;
          return [c[0]+Math.cos(a)*(offset+wave)+Math.sin(a)*tangent,c[1]+Math.sin(a)*(offset+wave)-Math.cos(a)*tangent];
        };
        const samples=low?10:18,edge=Array.from({length:samples+1},(_,j)=>rail(j/samples,-5)),other=Array.from({length:samples+1},(_,j)=>rail(1-j/samples,5+Math.sin(j/samples*Math.PI)*3));
        path([...edge,...other],{plane,closed:true,alpha:.25+breath*.12,fill:.035+breath*.024,width:.55,work:'refraction-surface'});
        curve(u=>rail(u,-5),{plane,steps:samples,alpha:.65,width:.9,highlight:true});
        curve(u=>{const p=rail(u,8+breath*2);return [p[0]+2*Math.sin(a),p[1]-2*Math.cos(a)];},{plane,steps:samples,alpha:.27,width:.65,work:'offset-refraction'});
        curve(u=>{const p=rail(u,-10);return [p[0]-3*Math.sin(a),p[1]+3*Math.cos(a)];},{plane,steps:samples,alpha:.19,width:.65,tint:'#b6b9f5',work:'chromatic-echo'});
        const q=frac(t*.16+i/n),ripple=Array.from({length:7},(_,j)=>rail(q+(j-3)*.012,-5+Math.sin(j/6*Math.PI)*6));
        path(ripple,{plane,alpha:Math.sin(q*Math.PI)*.85,width:1.05,highlight:true,work:'refraction-ripple'});
      }break;
    }
    case 'focusLock':{
      const [fx,fy]=d.focus,angle=Math.atan2(fy,fx),convergence=[fx*101,fy*101],alive=.5+.5*Math.sin(t*.7);
      for(let i=0;i<n;i++){
        const c=at(i),r=7+(i%2)*1.3,plane=c[1]<0?'rear':'front';
        // Polygonal optical aperture and inset blades, distinct from compass
        // bearings. Beams converge locally and never reveal a hidden target.
        const lens=Array.from({length:7},(_,j)=>local([Math.cos(j/6*TAU)*r*.48,Math.sin(j/6*TAU)*r],c,angle));
        path(lens,{plane,closed:true,alpha:.72,fill:.045,width:.85,work:'optical-aperture'});
        path([local([0,-r*.57],c,angle),local([0,r*.57],c,angle)],{plane,alpha:.6,highlight:true});
        if(d.hasFocus)path([c,[convergence[0]-fy*(n===1?0:(i-(n-1)/2)*1.4),convergence[1]+fx*(n===1?0:(i-(n-1)/2)*1.4)]],{alpha:.18+alive*.12,width:.55,work:'converging-sightline'});
        else path([local([3,-3],c,angle),local([8,0],c,angle),local([3,3],c,angle)],{alpha:.20+alive*.10,width:.55,work:'resting-aperture'});
      }
      if(d.hasFocus){for(const side of [-1,1])path([[-5,side*8],[-1,side*8],[2,side*5]].map(p=>local(p,convergence,angle)),{alpha:.7,width:.8,highlight:true,work:'focus-gate'});}break;
    }
    case 'emergencyReserve':{
      const cycle=frac(t/8.5),fill=cycle<.35?ease(cycle/.35):cycle<.72?1:1-ease((cycle-.72)/.28);
      for(let i=0;i<n;i++){
        const c=at(i),charging=clamp(fill*(1.1-i*.06),0,1);
        path([[c[0]-4,c[1]-10],[c[0]+4,c[1]-10],[c[0]+6,c[1]-6],[c[0]+6,c[1]+7],[c[0]+3,c[1]+11],[c[0]-4,c[1]+11]],{closed:true,alpha:.63,fill:.028,width:.8,work:'reserve-chamber'});
        const y=c[1]+8-charging*15;path([[c[0]-2,y],[c[0]+3,y],[c[0]+3,c[1]+8],[c[0]-2,c[1]+8]],{closed:true,alpha:.12+charging*.35,fill:.05+charging*.11,width:.6,glow:true,work:'stored-energy'});
        const end=[32,8+i*5],q=frac(t*.28+i*.23),gain=cycle>.32?.5*Math.sin(q*Math.PI):.06;
        curve(u=>[c[0]+(end[0]-c[0])*u,c[1]+(end[1]-c[1])*u+Math.sin(u*Math.PI)*8],{steps:8,alpha:.14,width:.55});
        diamond(c[0]+(end[0]-c[0])*q,c[1]+(end[1]-c[1])*q+Math.sin(q*Math.PI)*8,1.7,{alpha:gain,highlight:true,work:'reserve-delivery'});
      }
      path([[56,-46],[57,-49],[76,-49],[78,-45]],{alpha:.5,width:.65});break;
    }
    case 'impulseDrive':{
      const angle=Math.atan2(d.motion[1],d.motion[0]),thrust=d.amount;
      for(let i=0;i<n;i++){
        const c=at(i),q=.5+.5*Math.sin(t*2.2+i*1.7),length=3+thrust*(24+q*8),spread=2+thrust*4;
        path([[3,-6],[-4,-6],[-7,0],[-4,6],[3,6]].map(p=>local(p,c,angle)),{alpha:.62,width:.9,fill:.035,work:'vector-nozzle'});
        path([[-5,-spread],[-8-length,0],[-5,spread],[-8,0]].map(p=>local(p,c,angle)),{closed:true,alpha:.18+thrust*.5,fill:.025+thrust*.11,width:.65,glow:true,work:'directional-exhaust'});
        path([[-6,0],[-10-length*.67,0]].map(p=>local(p,c,angle)),{alpha:.28+thrust*.55,width:.8,highlight:true});
        if(!low&&thrust>.02)for(let j=0;j<2;j++){const dist=9+frac(t*.6+i*.21+j*.5)*length;path([[-dist,-spread*.65],[-dist-2,0],[-dist,spread*.65]].map(p=>local(p,c,angle)),{alpha:thrust*.22,width:.5});}
      }break;
    }
  }
  return true;
}

/** Home hardware uses the same working points as the field. Only orientation
 * and internal state change; custom stations and attached wing areas stay put. */
export function projectedHardwareActivity(flight,station,center,angle,time=0){
  const effect=flight?.bitProjectedEffect,stations=flight?.bitHomeStations??[];
  if(!effect||!IDS.has(effect.id)||effect.enabled===false||effect.strength===0||flight.bitHardwareAll||flight.bitActionAssignments?.hidden?.includes(station)||
    flight.conditionResponse?.bits&&flight.conditionResponse.collapse?.phase!=='awake')return null;
  const i=stations.indexOf(station);if(i<0)return null;
  const n=stations.length,t=flight.effective?.reducedMotion||flight.gems?.animated===false?0:(effect.clock??time)%3600;
  const target=projectedEffectWorkingPoint(effect.id,i,n,t,effect),c=Math.cos(effect.angle??0),s=Math.sin(effect.angle??0),sx=effect.scaleX??600/3.5/100,sy=effect.scaleY??sx;
  const x=(target[0]*c+target[1]*s)*sx+(effect.originX??0),y=(-target[0]*s+target[1]*c)*sy+(effect.originY??15),aim=Math.atan2(y-center[1],x-center[0])+Math.PI/2;
  const gain=flight.effective?.reducedMotion?1:ease(((effect.elapsed??1200)-160)/680),delta=Math.atan2(Math.sin(aim-angle),Math.cos(aim-angle));
  return {...projectedEffectDuty(effect.id,i,n,t,effect),target:[x,y,center[2]??0],turn:delta*gain*.8};
}
