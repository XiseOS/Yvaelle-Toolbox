/** Beta.35: the Keepsake's ambient loops hold still while tokens move.
 *
 * The HUD and the Keepsake sheet carry about twenty endless decorative
 * loops (the cord shine, the corner runs and gem glows, twinkles, the moon,
 * the lily, drifting petals, the portrait's breathing, the heartbeat line).
 * Many of them animate SVG strokes, filters and backgrounds, which the
 * browser restyles and repaints on the main thread on every display frame:
 * with the HUD or the sheet open that added about 3.5 ms to each frame
 * while she moved. While any token is moving on the canvas (and for a
 * moment after, while her flight settles) those endless loops now hold
 * where they are and carry on from there afterwards; nothing else in the
 * window is touched (opening, swapping, a hero petal's flight and every
 * transition still play). Open but idle, the window then costs no frame
 * work at all.
 *
 * Holding uses playbackRate 0, so the loops' own CSS play state (asleep,
 * Frame motion Off, paused classes) stays in charge. The corner runs and gem
 * glows drawn through <use> are reached through the inherited --ks-decor
 * property (keepsake.css).
 *
 * Beta.40: Keep playing (keep-playing.mjs). The loops of the groups chosen
 * there for this window's surface (her sheet or the HUD) are not held, and
 * a window can be held without movement too (the HUD while it is partly
 * covered: holdDecorNow), its kept loops still playing. */
import {keepsAnimation,keptOn} from './keep-playing.mjs?v=13.0.2';
const roots=new Map();// element → {root, held: Map<Animation, rate>, surface, now: held without movement, on: holding}
const probes=new Set();
export const DECOR_RELEASE_MS=900;
const POLL_MS=100;
let timer=null,hooked=false,holding=false,lastBusy=-Infinity;
const now=()=>globalThis.performance?.now?.()??Date.now();

/** Another busy signal (the flight module: her body still settling). */
export function addDecorProbe(fn){if(typeof fn==='function')probes.add(fn);return ()=>probes.delete(fn);}

/** Any token animating its movement on the canvas, or a probe says so. */
export function canvasMoving(){
  const c=globalThis.canvas;
  if(c?.ready)for(const t of c.tokens?.placeables??[]){const a=t?.animationContexts;if(a&&a.size>0)return true;}
  for(const p of probes){try{if(p())return true;}catch{}}
  return false;
}

/** Hold `element`'s endless loops (searched in `root`, its shadow root or
 * itself) while tokens move. Returns a function that lets it go. */
export function holdDecorWhileMoving(element,root=element.shadowRoot??element,{surface=null}={}){
  if(!element)return ()=>{};
  if(!roots.has(element))roots.set(element,{root,held:new Map(),surface,now:false,on:false});
  else{const rec=roots.get(element);rec.root=root;if(surface)rec.surface=surface;}
  const rec=roots.get(element);
  if(holding||rec.now){rec.on=true;apply(element,rec,true);}
  start();
  return ()=>release(element);
}
/** (beta.40) Hold `element`'s loops now, moving or not (its kept loops play on); false lets them go
 * unless tokens are moving. For a window that is partly covered. */
export function holdDecorNow(element,on){
  const rec=roots.get(element);if(!rec||rec.now===!!on)return;
  rec.now=!!on;const want=holding||rec.now;
  if(want!==rec.on){rec.on=want;apply(element,rec,want);}
}
export function release(element){
  const rec=roots.get(element);if(!rec)return;
  apply(element,rec,false);roots.delete(element);
  if(!roots.size)stop();
}

function animations(root){
  try{return root instanceof globalThis.ShadowRoot?root.getAnimations():root.getAnimations({subtree:true});}catch{return [];}
}
function apply(element,rec,on){
  if(on){
    const view=element.ownerDocument?.defaultView??null,kept=rec.surface?keptOn(rec.surface,view):null;
    // (the corner runs and gem glows behind <use> are held through --ks-decor: not while the corners are kept)
    try{if(kept?.corners)element.style?.removeProperty?.('--ks-decor');else element.style?.setProperty?.('--ks-decor','paused');}catch{}
    // (a group switched on while held goes on from where it stood)
    rec.kept=0;
    if(kept?.selector)for(const [a,rate] of rec.held)if(keepsAnimation(rec.surface,a,view)){try{if(a.playbackRate===0)a.playbackRate=rate||1;}catch{}rec.held.delete(a);}
    for(const a of animations(rec.root)){
      if(rec.held.has(a)||a.playbackRate===0)continue;
      let timing;try{timing=a.effect?.getTiming?.();}catch{continue;}
      if(timing?.iterations!==Infinity)continue;
      if(kept?.selector&&keepsAnimation(rec.surface,a,view)){rec.kept++;continue;}
      rec.held.set(a,a.playbackRate);try{a.playbackRate=0;}catch{rec.held.delete(a);}
    }
  }else{
    try{element.style?.removeProperty?.('--ks-decor');}catch{}
    for(const [a,rate] of rec.held)try{if(a.playbackRate===0)a.playbackRate=rate||1;}catch{}
    rec.held.clear();rec.kept=0;
  }
}
function tick(){
  for(const [element] of roots)if(!element.isConnected)release(element);
  if(!roots.size)return;
  const t=now();
  if(canvasMoving())lastBusy=t;
  const busy=t-lastBusy<DECOR_RELEASE_MS;
  holding=busy;
  // (while holding, loops that started meanwhile, after a redraw, hold too)
  for(const [element,rec] of roots){const want=busy||rec.now;
    if(want){rec.on=true;apply(element,rec,true);}
    else if(rec.on){rec.on=false;apply(element,rec,false);}}
}
/** A token starting to move holds the loops at once, not on the next poll. */
function poke(doc,changes){
  if(!roots.size||!changes||!('x' in changes||'y' in changes||'elevation' in changes||'_movement' in changes))return;
  lastBusy=now();if(!holding)tick();
}
function start(){
  if(!hooked&&globalThis.Hooks?.on){hooked=true;globalThis.Hooks.on('updateToken',poke);}
  if(timer===null)timer=setInterval(tick,POLL_MS);
}
function stop(){if(timer!==null){clearInterval(timer);timer=null;}holding=false;}
/** For tests and the self-check. */
export function decorHoldState(){return {roots:roots.size,holding,held:[...roots.values()].reduce((n,r)=>n+r.held.size,0),
  kept:[...roots.values()].reduce((n,r)=>n+(r.on?r.kept??0:0),0),heldNow:[...roots.values()].filter(r=>r.now).length};}
