/** Keepsake sheet (v10 beta.27): wiring. Off by default.
 * HUD › Settings › Her character sheet (or the ⋯ on her sheet) switches it
 * to Just me or Everyone. Only her sheet changes; every other sheet stays
 * PF2e's own, and a button in her sheet's title bar shows PF2e's own sheet
 * for a moment (on your screen only). */
import {registerSheetSettings,keepsakeOn,herActor,setSheetMode,sheetMode,portraitConfig} from './prefs.mjs?v=13.0.2';
import {noteHeroBefore,skyCorners,dressSheet,isDressed,refreshHidden,setStandard,isStandard,showTab,forgetSheet} from './dress.mjs?v=13.0.2';
import {redrawMenu,closeMenu} from './menu.mjs?v=13.0.2';
import {loadSprite} from './sprite.mjs?v=13.0.2';

import {miniButtons} from './chrome.mjs?v=13.0.2';
import {quickSummaries} from './motion.mjs?v=13.0.2';
import {heroTrace} from '../petal-dom.mjs?v=13.0.2';
import {installClickFx} from '../click-fx.mjs?v=13.0.2';
import {playOpen,forgetOpen,installOpenFx} from '../hud-open-fx.mjs?v=13.0.2';
import {dressPetals,syncHerbariumHooks} from './herbarium.mjs?v=13.0.2';
const ID='filament-flight';
const el=x=>x?.[0]??x??null;
/** The title bar's swap button: [icon, label, tooltip] for each way it can go. */
const SWAP={standard:['fa-solid fa-table-list','Standard','Show PF2e’s own sheet (just here, until you close it)'],keepsake:['fa-solid fa-feather-pointed','Keepsake','Her Keepsake sheet']};
/** Foundry draws the title bar once, so the swap button is relabelled after each render. */
function relabel(app){
  const b=el(app?.element)?.querySelector?.(':scope > .window-header .ffks-swap');if(!b)return;
  const [icon,label,tip]=isDressed(app)?SWAP.standard:SWAP.keepsake;
  if(b.dataset.ffksLabel===label)return;b.dataset.ffksLabel=label;
  b.innerHTML=`<i class="${icon}"></i>${label}`;b.dataset.tooltip=tip;b.setAttribute('aria-label',label);
  // (dressed: it is a mini icon like the rest)
  delete b.dataset.ffksMini;b.classList.remove('ffks-mini','ffks-mini-core');if(isDressed(app))miniButtons(el(app.element));
}
/** Every open PF2e character sheet. */
export function openSheets(){
  const out=[];
  for(const app of Object.values(globalThis.ui?.windows??{}))if(app?.actor?.type==='character'&&typeof app.render==='function'&&el(app.element)?.querySelector?.('form'))out.push(app);
  for(const app of foundry?.applications?.instances?.values?.()??[])if(app?.actor?.type==='character'&&!out.includes(app)&&el(app.element)?.querySelector?.('form'))out.push(app);
  return out;
}
/** After a change to who sees it or what it shows: re-render where the look
 * changes, otherwise just hide, show and glide. */
export function refreshSheets({restyle=false}={}){
  for(const app of openSheets()){
    const want=keepsakeOn(app.actor)&&!isStandard(app),has=isDressed(app);
    if(want!==has||(has&&restyle)){closeMenu(app);app.render(false);continue;}
    if(has){refreshHidden(app);redrawMenu(app);}
  }
}

export function installKeepsakeSheet(){
  registerSheetSettings(()=>refreshSheets());
  // every click on her sheet (and the HUD) answers with a glint: one listener on the document
  try{installClickFx(globalThis.document);}catch{}
  // (12.1.0-beta.1) the HUD's opening scan, however the HUD is opened; her sheet plays it from the render hook below
  try{installOpenFx();}catch{}
  // PF2e's character sheet (PF2e and SF2e): dress it after every render.
  const onRender=(app,html)=>{
    if(app?.actor?.type!=='character')return;
    dressSheet(app,html);
    relabel(app);
    if(isDressed(app)){redrawMenu(app);
      // (12.1.0-beta.1) her Keepsake sheet opens as the HUD does: the Hardlight scan, once, as it opens (not on later renders)
      playOpen(app,el(app.element));}
  };
  Hooks.on('renderCharacterSheetPF2e',onRender);
  Hooks.on('preUpdateActor',(actor,changes)=>noteHeroBefore(actor,changes));
  // the corners keep the world's time while the sheet is open
  Hooks.on('updateWorldTime',()=>{for(const app of openSheets())if(isDressed(app))skyCorners(el(app.element));});
  Hooks.on('closeCharacterSheetPF2e',app=>{closeMenu(app);setStandard(app,false);forgetSheet(app);forgetOpen(app);});
  // (Her portrait or "Everyone" changing on another screen updates her actor,
  // and PF2e re-renders her sheet for it, so the render hook above dresses it.)
  // The HUD's pinned character decides whose sheet "Just me" dresses; frame motion follows the HUD.
  Hooks.on('clientSettingChanged',key=>{if(key===`${ID}.hudPreferences`||key===`${ID}.keepsakeUI`||key===`${ID}.reducedMotion`)refreshSheets({restyle:key!==`${ID}.hudPreferences`});});
  // Title bar: "Standard sheet" (just here, until it closes) / "Keepsake".
  Hooks.on('getActorSheetHeaderButtons',(app,buttons)=>{
    if(app?.actor?.type!=='character'||!app.actor.isOwner&&!keepsakeOn(app.actor))return;
    if(!keepsakeOn(app.actor)&&app.actor.id!==herActor()?.id)return;
    const on=keepsakeOn(app.actor)&&!isStandard(app);
    buttons.unshift({label:on?'Standard':'Keepsake',class:'ffks-swap',icon:on?SWAP.standard[0]:SWAP.keepsake[0],
      onclick:async()=>{
        if(keepsakeOn(app.actor)){setStandard(app,!isStandard(app));app.render(false);return;}
        try{await setSheetMode('me',app.actor);ui.notifications?.info?.('Keepsake sheet · just you. HUD › Settings › Her character sheet shows it to everyone.');}catch(e){ui.notifications?.error?.(e?.message??String(e));}
      }});
  });
  Hooks.once('ready',()=>{void loadSprite();try{quickSummaries();}catch{}});
  // (v11 extra) milestone petals: her journal changes redraw the herbarium in place; the hook exists only while they are on
  const petals=actor=>{for(const app of openSheets())if(isDressed(app)&&(!actor||app.actor===actor)){const f=el(app.element)?.querySelector('form');try{dressPetals(app,f,app.actor);}catch{}}};
  const syncPetals=()=>{syncHerbariumHooks(petals);petals(null);};
  Hooks.once('ready',syncPetals);Hooks.on('filamentFlightSettingsChanged',syncPetals);
  return {
    /** The last Hero Point changes the HUD and the sheet saw, and what each did (for the self-check). */
    heroTrace:()=>heroTrace.slice(),
    /** Off / Just me / Everyone for her (the HUD's pinned character). */
    mode:(actor)=>sheetMode(actor),
    setMode:(mode,actor)=>setSheetMode(mode,actor),
    /** Open her sheet (in whichever look applies). */
    open:(actor=herActor(),tab)=>{if(!actor)throw new Error('Pin her in the HUD first.');const s=actor.sheet;void Promise.resolve(s.render(true)).then(()=>{if(tab)setTimeout(()=>showTab(s,tab),50);});return s;},
    /** Her portrait studio. */
    studio:async(actor=herActor())=>{const m=await import('./studio.mjs?v=13.0.2');return m.openPortraitStudio(actor);},
    portrait:(actor=herActor())=>portraitConfig(actor)
  };
}
