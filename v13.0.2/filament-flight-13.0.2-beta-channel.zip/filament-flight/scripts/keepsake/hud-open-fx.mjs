/** Yvaelle’s Toolbox v11 · the HUD opening (test.11) · (12.1.0-beta.1) however it is opened, and her Keepsake sheet too.
 *
 * "Hardlight scan": a magenta edge crosses the HUD from left to right and leaves
 * it behind, the same language as her cloak's scan. Two Web Animations for about
 * half a second (the window's clip and one 5 px bar), then nothing is left: no
 * class, no listener, no element. Reduced motion, or the choice "No animation"
 * (Settings › Emotes & wheel › Nested wheel › Parts › Opening the HUD and her sheet), skips it.
 * One rule for both windows (installOpenFx): a window plays it as it opens, once, and not again while it stays open. */
import {ID} from '../config.mjs?v=13.0.2';
import {resolveV11} from '../v11/features.mjs?v=13.0.2';
export const HUD_OPEN_MS=520;
const EASE='cubic-bezier(.3,.1,.2,1)';
/** Play it on the HUD's window element. Returns {clip, bar, stop}, or null when it does not play.
 * (test.17) The bar follows the window itself, frame by frame: Foundry places the window after it renders, so where
 * the window stood at that moment is not where it opens (the bar used to run on the left while the HUD opened on the
 * right). Its place along the window is the clip animation's own progress, so the edge and the bar cannot part. */
export function hudOpenScan(el,{reduced=false,doc=el?.ownerDocument??globalThis.document}={}){
  if(!el||reduced||typeof el.animate!=='function'||!doc?.body)return null;
  const view=doc.defaultView??globalThis,raf=view.requestAnimationFrame?.bind(view);if(!raf)return null;
  let z=101;try{z=(parseInt(view.getComputedStyle(el).zIndex,10)||100)+1;}catch{}
  const clip=el.animate([{clipPath:'inset(0 100% 0 0)'},{clipPath:'inset(0 0 0 0)'}],{duration:HUD_OPEN_MS,easing:EASE});
  const bar=doc.createElement('div');bar.className='ff-hud-open-scan';bar.setAttribute('aria-hidden','true');
  bar.style.cssText=`position:fixed;left:0;top:0;width:5px;height:0;z-index:${z};pointer-events:none;border-radius:3px;opacity:0;`
    +'background:linear-gradient(180deg,#f3d79c,#e767ce 30%,#e767ce 70%,#f3d79c);box-shadow:0 0 14px 3px rgba(231,103,206,.6),-14px 0 26px 4px rgba(231,103,206,.18);will-change:transform,opacity';
  doc.body.append(bar);
  let done=false;const stop=()=>{if(done)return;done=true;bar.remove();};
  const place=()=>{
    if(done)return;
    let p=null;try{p=clip.effect?.getComputedTiming?.().progress;}catch{}
    if(p==null||clip.playState==='finished'||clip.playState==='idle'){stop();return;}
    const r=el.getBoundingClientRect();
    if(r.width>0&&r.height>0){bar.style.height=`${r.height}px`;bar.style.transform=`translate(${(r.left-3+r.width*p).toFixed(1)}px,${r.top.toFixed(1)}px)`;
      bar.style.opacity=String(Math.max(0,Math.min(1,p/.08,(1-p)/.1)));}
    raf(place);
  };
  place();clip.finished.then(stop,stop);
  return {clip,bar,stop};
}

/** Should an opening window play the scan here? Her choice (a client one), and neither kind of reduced motion. */
export function openFxWanted({view=globalThis}={}){
  try{if(globalThis.game?.settings?.get(ID,'reducedMotion')||globalThis.canvas?.photosensitiveMode)return false;}catch{}
  try{if(view.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches)return false;}catch{}
  let style='scan';try{style=resolveV11(null)?.['nestedWheel.hudOpen']??'scan';}catch{}
  return style==='scan';
}
const shown=new WeakSet();
/** A window rendered: the first render since it opened plays the scan; later renders of the open window do not. */
export function playOpen(app,element,opts){
  if(!app||!element||shown.has(app))return null;shown.add(app);
  if(!openFxWanted(opts))return null;
  try{return hudOpenScan(element,opts);}catch{return null;}
}
/** A window closed: its next opening plays again. */
export function forgetOpen(app){if(app)shown.delete(app);}
/** The HUD, however it is opened (the wheel, its macro, a key, the token HUD button). Her sheet joins from keepsake/sheet/index.mjs. */
export const HUD_APP_ID='filament-flight-hud';
export function installOpenFx(H=globalThis.Hooks){
  if(!H?.on)return false;
  H.on('renderApplicationV2',app=>{if(app?.id===HUD_APP_ID)playOpen(app,app.element);});
  H.on('closeApplicationV2',app=>{if(app?.id===HUD_APP_ID)forgetOpen(app);});
  return true;
}
