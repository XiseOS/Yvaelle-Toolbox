/** Yvaelle’s Toolbox v11 · her wings and the world: the pure maths.
 *
 * Four features (each its own switch in features.mjs, read by world-runtime.mjs):
 *  - Wall fold: each wing folds just enough to clear the walls near it, both in
 *    corridors and doorways; folding is brisk (tips first), reopening slow
 *    (roots first). The decision is ray casts from her centre against the
 *    walls near her, cached per position (a fifth of a square) and the answer
 *    per position and heading, so a frame where nothing moved costs nothing.
 *  - Light catch: the colour of the lights near her, sampled on a coarse grid
 *    over her wing frame and quantised, so a repaint only happens on a real step.
 *  - Wing shadow on tokens: which tokens her wing shadow lies across (only
 *    re-checked when she or a token moves).
 *
 * No Foundry or DOM globals: node tests and the worker can import it. */
import {ENVELOPE,ENVELOPE_BINS,ENVELOPE_LEVELS} from './wing-envelope.mjs?v=13.0.2';

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const lerp=(a,b,k)=>a+(b-a)*k;

/* =====================================================================
 * Wall fold
 * ===================================================================== */
export const RAYS=ENVELOPE_BINS;        // 48 directions, 7.5° apart
export const FOLD_LEVELS=ENVELOPE_LEVELS;  // 0 … 20
/** Position step of the ray cache, in grid squares (20 px on a 100 px grid). */
export const CELL=.2;
/** Heading step of the decision cache (same as the rays: 7.5°). */
export const HEADING_STEPS=RAYS;
/** A little room between a wingtip and the stone (the lab's 1.07). */
export const FOLD_MARGIN=1.07;
/** How far ahead (seconds) she looks, and how much each look counts (the lab's). */
export const LOOK_AHEAD=Object.freeze([[.18,1],[.36,.85]]);

/** Precomputed per wing: each level's (bin, reach) pairs, nonzero bins only. */
const SIDES=['left','right'].map(k=>ENVELOPE[k].map(row=>{const bins=[],reach=[];row.forEach((r,b)=>{if(r>0){bins.push(b);reach.push(r);}});return {bins:Int16Array.from(bins),reach:Float32Array.from(reach)};}));
const COS=new Float64Array(RAYS),SIN=new Float64Array(RAYS);
for(let i=0;i<RAYS;i++){COS[i]=Math.cos(i/RAYS*TAU);SIN[i]=Math.sin(i/RAYS*TAU);}
/** The furthest any wing reaches when open (art units). */
export const ENVELOPE_MAX=Math.max(...ENVELOPE.left[0],...ENVELOPE.right[0]);

/** Segment p→q (as p + t·(q−p), t in [0,1]) against wall a→b: the t of the crossing, or Infinity. */
function hitT(px,py,dx,dy,ax,ay,bx,by){
  const ex=bx-ax,ey=by-ay,den=dx*ey-dy*ex;if(den>-1e-12&&den<1e-12)return Infinity;
  const fx=ax-px,fy=ay-py,t=(fx*ey-fy*ex)/den,u=(fx*dy-fy*dx)/den;
  return t>=0&&t<=1&&u>=0&&u<=1?t:Infinity;
}
/** Cast the 48 rays of length `reach` (px) from (x,y) against `walls` (flat
 * [ax,ay,bx,by,…], `count` walls). Fills `out` with the distance to the first
 * wall in each direction (reach when clear). Returns how many rays hit.
 * Each wall is only tested against the few rays inside the angle it spans
 * (a traced map's walls are short), not all 48. */
export function castRays(x,y,reach,walls,count,out){
  for(let i=0;i<RAYS;i++)out[i]=1;
  const K=RAYS/TAU;
  for(let w=0,o=0;w<count;w++,o+=4){
    const ax=walls[o],ay=walls[o+1],bx=walls[o+2],by=walls[o+3];
    let a0=Math.atan2(ay-y,ax-x)*K,a1=Math.atan2(by-y,bx-x)*K,d=a1-a0;
    // the shorter way round
    if(d>RAYS/2)a1-=RAYS;else if(d<-RAYS/2)a1+=RAYS;
    let lo=Math.ceil(Math.min(a0,a1)-1e-9),hi=Math.floor(Math.max(a0,a1)+1e-9);
    if(hi-lo>=RAYS/2){lo=0;hi=RAYS-1;}      // a wall through her centre
    for(let k=lo;k<=hi;k++){const i=((k%RAYS)+RAYS)%RAYS;const h=hitT(x,y,COS[i]*reach,SIN[i]*reach,ax,ay,bx,by);if(h<out[i])out[i]=h;}
  }
  let hits=0;for(let i=0;i<RAYS;i++){if(out[i]<1)hits++;out[i]*=reach;}
  return hits;
}
/** The smallest fold (0…1, steps of 1/20) that keeps one wing clear, given the
 * ray distances `dist` (px), the wing frame's angle and its size in px
 * (sx = width/600, sy = height/600). side: -1 left, 1 right. */
export function foldFor(dist,side,angle,sx,sy,margin=FOLD_MARGIN){
  const table=SIDES[side<0?0:1],ca=Math.cos(angle),sa=Math.sin(angle);
  for(let l=0;l<FOLD_LEVELS;l++){
    const {bins,reach}=table[l];let ok=true;
    for(let j=0;j<bins.length;j++){
      // that wing's furthest point in this direction, on the map
      const b=bins[j],r=reach[j]*margin,lx=COS[b]*r*sx,ly=SIN[b]*r*sy,wx=lx*ca-ly*sa,wy=lx*sa+ly*ca;
      const d=Math.hypot(wx,wy);if(d<1)continue;
      let a=Math.atan2(wy,wx)/TAU*RAYS;a=((a%RAYS)+RAYS)%RAYS;
      // the nearer of the two rays either side of it
      const i0=Math.floor(a)%RAYS,i1=(i0+1)%RAYS,clear=dist[i0]<dist[i1]?dist[i0]:dist[i1];
      if(d>clear){ok=false;break;}
    }
    if(ok)return l/(FOLD_LEVELS-1);
  }
  return 1;
}
/** A critically-damped-ish spring (one per wing root and tip): {x,v}. Brisk in, slow out. */
export function springFold(s,target,dt,closingW,closingZ,openingW,openingZ){
  const closing=target>s.x,w=closing?closingW:openingW,z=closing?closingZ:openingZ;
  // sub-steps keep a long frame stable
  let left=Math.min(dt,.25);
  while(left>1e-6){const h=left>1/60?1/60:left;left-=h;s.v+=(w*w*(target-s.x)-2*z*w*s.v)*h;s.x+=s.v*h;}
  return s.x;
}
/** One wing's fold springs: the root and the tip (tips lead in, trail out). */
export function stepWing(root,tip,f,dt){
  springFold(root,f,dt,7.5,.92,2.3,.7);
  springFold(tip,Math.min(1,f*1.12),dt,10.5,.9,1.75,.8);
}
/** The rig's fold for one wing from its springs: [collapse, collapseTip], quantised
 * to 1/40 (the painter's caches stay stable; the eye cannot see the step). */
export function foldPair(root,tip,out=[0,0]){
  const r=unit(root.x),t=unit(Math.max(tip.x,root.x*.92));
  out[0]=Math.round(r*40)/40;out[1]=Math.round(t*40)/40;return out;
}
/** A cell's key: a small integer (no boxed numbers in the maps). Cells wrap every 8192 (164 km on a 100 px grid). */
const ckey=(cx,cy)=>((cx&8191)<<13)|(cy&8191);
const headingStep=angle=>(((Math.round(angle/TAU*HEADING_STEPS)%HEADING_STEPS)+HEADING_STEPS)%HEADING_STEPS)|0;
const sizeStep=(sx,sy)=>Math.min(255,Math.round(Math.max(sx,sy)*600/8))|0;

/** The fold decisions for one token: a ray cache per position, an answer cache
 * per position + heading + wing size, a small budget of new ray casts a frame,
 * and the four springs. Walls come from `query(x0,y0,x1,y1,out)` → count
 * (flat [ax,ay,bx,by,…] into out, a reusable Float64Array). */
export class WallFold{
  constructor({budget=2,maxCells=4096}={}){
    // cell → its rays (Float32Array, with .reach, .clear and .ans: heading·256+size → answer)
    this.rays=new Map();this.budget=budget;this.maxCells=maxCells;this.spent=0;
    this.L={x:0,v:0};this.Lt={x:0,v:0};this.R={x:0,v:0};this.Rt={x:0,v:0};
    this.target=[0,0];this.pair=[[0,0],[0,0]];this.walls=new Float64Array(64*4);this.stats={casts:0,decisions:0,hits:0,misses:0};
    this.lastKey=[NaN,NaN,NaN];this.at=NaN;this.sx=.5;this.sy=.5;this.dt=.016;this.velX=0;this.velY=0;this.px=NaN;this.py=NaN;
  }
  /** Forget everything (walls or doors changed, a new scene). */
  clear(){this.rays.clear();this.lastKey.fill(NaN);}
  /** How many answers are cached (all cells). */
  get answerCount(){let n=0;for(const d of this.rays.values())n+=d.ans.size;return n;}
  /** The ray distances at a cell, cast now if the frame's budget allows (else null). */
  raysAt(cx,cy,grid,reach,query){
    const key=ckey(cx,cy);let d=this.rays.get(key);
    if(d&&d.reach>=reach)return d;
    if(this.spent>=this.budget)return null;this.spent++;
    const x=cx*grid*CELL,y=cy*grid*CELL;
    let n=query(x-reach,y-reach,x+reach,y+reach,this.walls);
    if(n<0){this.walls=new Float64Array(-n*4+64);n=query(x-reach,y-reach,x+reach,y+reach,this.walls);}
    if(this.rays.size>=this.maxCells)this.rays.clear();
    d=new Float32Array(RAYS);d.reach=reach;d.ans=new Map();d.clear=n===0||castRays(x,y,reach,this.walls,n,d)===0;
    if(n===0)d.fill(reach);
    this.rays.set(key,d);this.stats.casts++;return d;
  }
  /** Both wings' required fold at (x,y) for the frame angle and size, or null (not cast yet). */
  decide(x,y,angle,sx,sy,grid,query,out){
    const cs=grid*CELL;
    return this.decideCell(Math.round(x/cs)|0,Math.round(y/cs)|0,headingStep(angle),sizeStep(sx,sy),sy/Math.max(1e-6,sx),grid,query,out);
  }
  /** The same on whole numbers (cell, heading step, size step): small integers
   * pass between functions without being boxed, so a cached answer allocates nothing. */
  decideCell(cx,cy,h,sq,ratio,grid,query,out){
    const reach=Math.ceil(sq*8/600*ENVELOPE_MAX*FOLD_MARGIN+4),cell=this.rays.get(ckey(cx,cy)),ak=(h*256+sq)|0;
    if(cell&&cell.reach>=reach){const hit=cell.ans.get(ak);if(hit!==undefined){this.stats.hits++;out[0]=(hit>>5)/20;out[1]=(hit&31)/20;return out;}}
    const d=cell&&cell.reach>=reach?cell:this.raysAt(cx,cy,grid,reach,query);if(!d)return null;
    this.stats.misses++;this.stats.decisions++;
    const qa=h/HEADING_STEPS*TAU,qs=sq*8/600;
    const l=d.clear?0:foldFor(d,-1,qa,qs,qs*ratio),r=d.clear?0:foldFor(d,1,qa,qs,qs*ratio);
    d.ans.set(ak,Math.round(l*20)*32+Math.round(r*20));
    out[0]=l;out[1]=r;return out;
  }
  /** One frame from her wing transform T ({x,y,angle,width,height}, px), the time
   * now (ms) and her token's own position. Values already held in objects pass
   * without being boxed again, so a still frame allocates nothing. */
  stepFrame(T,grid,now,query,reduced,gx,gy){
    // (sizes and dt go through fields, not arguments: a fresh number passed to a call is boxed)
    this.dt=Number.isFinite(this.at)?Math.max(0,Math.min(250,now-this.at))/1000:0;this.at=now;this.sx=T.width/600;this.sy=T.height/600;
    return this.core(T.x,T.y,T.angle,grid,query,reduced,gx,gy);
  }
  /** One frame: where her wing frame is (x,y,angle, px per art unit sx,sy),
   * the grid size, dt (s); gx,gy: her token's own position (for her velocity).
   * Returns true while the fold shows. */
  step(x,y,angle,sx,sy,grid,dt,query,reduced=false,gx=x,gy=y){
    this.sx=sx;this.sy=sy;this.dt=dt;return this.core(x,y,angle,grid,query,reduced,gx,gy);
  }
  core(x,y,angle,grid,query,reduced,gx,gy){
    const sx=this.sx,sy=this.sy,dt=this.dt;
    this.spent=0;
    // her velocity (for the look ahead), from where her token is (gx,gy: her hover bob is not travel)
    if(Number.isFinite(this.px)&&dt>0){const k=1-Math.exp(-dt*10),vx=(gx-this.px)/dt,vy=(gy-this.py)/dt;
      if(Math.abs(vx)<5000&&Math.abs(vy)<5000){this.velX+=(vx-this.velX)*k;this.velY+=(vy-this.velY)*k;}
      if(Math.abs(this.velX)<1e-3)this.velX=0;if(Math.abs(this.velY)<1e-3)this.velY=0;}
    this.px=gx;this.py=gy;
    const moving=Math.abs(this.velX)+Math.abs(this.velY)>grid*.05;
    // Nothing moved since the last decision: the target stands.
    const cs=grid*CELL,k0=Math.round(x/cs)*7919+Math.round(y/cs),k1=Math.round(angle/TAU*HEADING_STEPS),k2=Math.round(Math.max(sx,sy)*75);
    if(!(moving||k0!==this.lastKey[0]||k1!==this.lastKey[1]||k2!==this.lastKey[2])){/* same place, same heading */}
    else{
      const t=this.target,o=this.scratch??=[.5,.5],h=headingStep(angle),sq=sizeStep(sx,sy),ratio=sy/Math.max(1e-6,sx);
      const now=this.decideCell(Math.round(x/cs)|0,Math.round(y/cs)|0,h,sq,ratio,grid,query,o);let complete=!!now;
      let l=now?o[0]:t[0],r=now?o[1]:t[1];
      if(moving)for(let i=0;i<LOOK_AHEAD.length;i++){const la=LOOK_AHEAD[i][0],w=LOOK_AHEAD[i][1];
        const f=this.decideCell(Math.round((x+this.velX*la)/cs)|0,Math.round((y+this.velY*la)/cs)|0,h,sq,ratio,grid,query,o);
        if(!f){complete=false;continue;}l=Math.max(l,f[0]*w);r=Math.max(r,f[1]*w);}
      t[0]=l;t[1]=r;
      // a decision still waiting for its rays is taken again next frame
      if(complete&&!moving){this.lastKey[0]=k0;this.lastKey[1]=k1;this.lastKey[2]=k2;}else this.lastKey[0]=NaN;
    }
    if(reduced){this.L.x=this.Lt.x=this.target[0];this.R.x=this.Rt.x=this.target[1];this.L.v=this.Lt.v=this.R.v=this.Rt.v=0;}
    else if(this.active){stepWing(this.L,this.Lt,this.target[0],dt);stepWing(this.R,this.Rt,this.target[1],dt);}
    foldPair(this.L,this.Lt,this.pair[0]);foldPair(this.R,this.Rt,this.pair[1]);
    return this.shows;
  }
  /** Anything to spring toward, or still springing? */
  get active(){const s=this;return s.target[0]>0||s.target[1]>0||Math.abs(s.L.x)+Math.abs(s.Lt.x)+Math.abs(s.R.x)+Math.abs(s.Rt.x)>1e-3||Math.abs(s.L.v)+Math.abs(s.Lt.v)+Math.abs(s.R.v)+Math.abs(s.Rt.v)>1e-3;}
  /** Does the fold show this frame? */
  get shows(){const p=this.pair;return p[0][0]>0||p[0][1]>0||p[1][0]>0||p[1][1]>0;}
  /** How folded each wing is (0 open … 1), and how fast it is opening (for the feel). */
  get left(){return unit(this.L.x);} get right(){return unit(this.R.x);}
  get opening(){return Math.max(0,-(this.L.v+this.R.v)/2);}
}
/** The flight feel while her wings are held in (the lab's): fewer, shallower
 * beats, a slight roll away from the wall she gives room to, and a heavier
 * first stroke as they reopen. `mem` keeps the reopening weight. */
export function foldFeel(out,left,right,opening,dt,mem){
  const avg=(left+right)/2;
  out.beatRate*=lerp(1,.62,avg);
  out.bank+=(left-right)*.075;
  const k=1-Math.exp(-dt*2.5);mem.openK=lerp(mem.openK??0,unit(opening*1.4),k);
  if(mem.openK>.002)out.flex=Math.max(out.flex??0,.55*mem.openK);
  return mem.openK>.002||avg>0;
}
/** A wall document → is it solid for her wings? (open doors and walls that
 * do not block movement are not). Plain values: c [x0,y0,x1,y1], move, door, ds. */
export function wallBlocksWings(d){
  if(!d)return false;
  if(d.move===0)return false;                // no movement restriction (ethereal)
  if(d.door>0&&d.ds===1)return false;        // an open door
  return true;
}

/* =====================================================================
 * Light catch
 * ===================================================================== */
/** Her wing frame, cut into a coarse grid (art units, her centre at (0,15)). */
export const LIGHT_COLS=8,LIGHT_ROWS=3,LIGHT_BINS=LIGHT_COLS*LIGHT_ROWS;
const COL_W=600/LIGHT_COLS,ROW_H=600/LIGHT_ROWS;
/** The bin of a point in art units. */
export function lightBinOf(x,y){
  let c=Math.floor((x+300)/COL_W),r=Math.floor((y+285)/ROW_H);
  c=c<0?0:c>=LIGHT_COLS?LIGHT_COLS-1:c;r=r<0?0:r>=LIGHT_ROWS?LIGHT_ROWS-1:r;return r*LIGHT_COLS+c;
}
/** Each bin's centre in art units (x, y). */
export const LIGHT_BIN_ART=Float32Array.from({length:LIGHT_BINS*2},(_,i)=>{const b=i>>1,c=b%LIGHT_COLS,r=(b/LIGHT_COLS)|0;return i&1?-285+(r+.5)*ROW_H:-300+(c+.5)*COL_W;});
/** How much of the light reaches her at most (her magenta stays underneath). */
export const LIGHT_MAX=.8;
/** Strength steps (the lab's 1/18) and colour steps (per channel: 16 levels, 0…255). */
export const LIGHT_K_STEPS=18,LIGHT_RGB_STEP=17;
const MAG_INK=[255,0,255],MAG_HALO=[255,0,255],MAG_CORE=[255,214,255];
const WHITE=[255,255,255];
/** A light's reach (px, where its pull has fallen to 1/e) from its dim and bright radii. */
export const lightReach=(dim,bright=0)=>Math.max(.74*dim,bright*1.05);
/** Quantise one bin's caught light: weight w (0…), colour sum (r,g,b)·w, animated share. Returns a key
 * number (0 = nothing) and fills `out` = [k, r, g, b, flicker]. */
export function quantiseLight(w,r,g,b,anim,dark,out){
  const k=Math.round(Math.min(1,w)*LIGHT_MAX*dark*LIGHT_K_STEPS)/LIGHT_K_STEPS;
  if(k<=0){out[0]=0;return 0;}
  const q=v=>Math.min(15,Math.round(v/w/LIGHT_RGB_STEP))*LIGHT_RGB_STEP;   // 16 levels a channel, 0…255
  out[0]=k;out[1]=q(r);out[2]=q(g);out[3]=q(b);out[4]=Math.round(unit(anim/w)*4)/4;
  return 1+Math.round(k*LIGHT_K_STEPS)+((out[1]/LIGHT_RGB_STEP)*256+(out[2]/LIGHT_RGB_STEP)*16+out[3]/LIGHT_RGB_STEP)*32+out[4]*4*32*4096;
}
const mix=(a,b,k)=>[0,1,2].map(i=>Math.round(a[i]+(b[i]-a[i])*k));
/** The palette (the rig's v11 palette shape: ink, halo, core, glow, wire, edge, under)
 * for strength k and colour rgb (the lab's light palette: the wire leans toward
 * the light, the halo takes it, the pale core takes its pale). Cached. */
const PALS=new Map();
export function lightPalette(k,r,g,b){
  const key=`lc:${k}:${r},${g},${b}`;let p=PALS.get(key);if(p)return p;
  const col=[r,g,b],pale=mix(col,WHITE,.62);
  p={key,k,rgb:[r,g,b],ink:mix(MAG_INK,mix(col,MAG_INK,.42),k*.9),halo:mix(MAG_HALO,col,k),core:mix(MAG_CORE,pale,Math.min(1,k*1.3)),
    glow:1+.12*k,wire:1,edge:0,under:[...col,.075*k]};
  if(PALS.size>2048)PALS.clear();PALS.set(key,p);return p;
}
/** A flame's flicker (the lab's torch): a multiplier around 1, at time t (s). */
export const flicker=t=>1+.07*Math.sin(t*7.3)+.05*Math.sin(t*11.9+1.3)+.04*Math.sin(t*17.1+.4);
/** Sample the lights for every bin of her wing frame. lights: [{x,y,reach,r,g,b,w,anim}],
 * frame: {x,y,angle,sx,sy} (px per art unit), dark (0…1, how much a light shows).
 * Fills keys (Float64Array LIGHT_BINS) and vals (Float32Array LIGHT_BINS·5). Returns the number of lit bins. */
export function sampleLight(lights,count,frame,dark,keys,vals){
  const ca=Math.cos(frame.angle),sa=Math.sin(frame.angle),o=[0,0,0,0,0];let lit=0;
  for(let b=0;b<LIGHT_BINS;b++){
    const ax=LIGHT_BIN_ART[b*2]*frame.sx,ay=(LIGHT_BIN_ART[b*2+1]-15)*frame.sy,x=frame.x+ax*ca-ay*sa,y=frame.y+ax*sa+ay*ca;
    let w=0,r=0,g=0,bl=0,an=0;
    for(let i=0;i<count;i++){const L=lights[i],dx=x-L.x,dy=y-L.y,q=(dx*dx+dy*dy)/(L.reach*L.reach);if(q>9)continue;
      const f=Math.exp(-q)*L.w;w+=f;r+=L.r*f;g+=L.g*f;bl+=L.b*f;an+=L.anim*f;}
    const key=w>1e-4?quantiseLight(w,r,g,bl,an,dark,o):0;keys[b]=key;
    for(let j=0;j<5;j++)vals[b*5+j]=key?o[j]:0;if(key)lit++;
  }
  return lit;
}

/* =====================================================================
 * Wing shadow on tokens
 * ===================================================================== */
/** Does her wing shadow (rect cx,cy,w,h) lie across a token (rect x,y,w,h)? How much (0…1 of the token's width). */
export function shadowOverlap(cx,cy,w,h,tx,ty,tw,th){
  // the shadow picture's dark part is roughly the middle 80 % of its box
  const hw=w*.4,hh=h*.4,ox=Math.min(cx+hw,tx+tw)-Math.max(cx-hw,tx),oy=Math.min(cy+hh,ty+th)-Math.max(cy-hh,ty);
  return ox>0&&oy>0?Math.min(1,ox/tw)*Math.min(1,oy/th):0;
}
/** On a standing figure (~5 ft) the shadow lands a little nearer her and crisper:
 * shift (toward her body, as a share of her rise) and scale for a figure of `h` ft under her at `alt` ft. */
export function shadowOnFigure(alt,h=5){
  const a=Math.max(h+1,alt),k=h/a;
  // (her floor shadow is kept faint for busy maps; on a figure right under her it reads darker, as the lab's .68)
  return {toward:k,scale:(1+(a-h)/80)/(1+a/80),alpha:5,max:.68};
}
