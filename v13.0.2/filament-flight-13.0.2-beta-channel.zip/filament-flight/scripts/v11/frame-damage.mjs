/** Yvaelle’s Toolbox v11 · Wingless: wounds, persistent damage, dying and mood on her FRAME (pure).
 *
 * When her wings are off (Wingless mode, or wings not shown) the same moment
 * plays on her token layer instead (lab/v11/wingless, wl-frame.mjs and its
 * token-layer). Everything is written into the token layer's own Look slots
 * after it has been sampled: rim arcs (added light or the type's colour on
 * the gold), beads riding the rim (embers, drops, glints), vignettes, the
 * portrait tint, saturation and brightness, tarnish. So it costs no extra
 * pass, no texture and no allocation: the one filter on her token draws it.
 *
 * Angles are screen angles (0 = right, +π/2 = down); the frame's landmarks:
 * crown −π/2, shoulder pins −3π/4 and −π/4, the heart (drop finial) +π/2. */
import {SLOTS} from './token-layer.mjs?v=13.0.2';
import {CYCLE} from './wing-damage.mjs?v=13.0.2';

const TAU=Math.PI*2;
const unit=x=>x<0?0:x>1?1:x;
const smooth=x=>{x=unit(x);return x*x*(3-2*x);};
const easeOut=(x,p=3)=>1-(1-unit(x))**p;
const ease=x=>{x=unit(x);return x<.5?4*x*x*x:1-(-2*x+2)**3/2;};
const bump=x=>x<=0||x>=1?0:Math.sin(Math.PI*x);
const env=(t,a,i,b,o)=>smooth((t-a)/i)*(1-smooth((t-b)/o));
const hash1=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s);};
const angDiff=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
const c255=a=>a.map(v=>v/255);
const A_PINL=-Math.PI*.75,A_PINR=-Math.PI*.25,A_HEART=Math.PI/2;

/* colours (0..1) */
const ROSE=c255([255,226,236]),GOLD=c255([255,226,164]),FIRE=c255([255,150,70]),FIRE_CORE=c255([255,226,170]),ICE=c255([130,165,255]),ICE_CORE=c255([226,236,255]),ACID=c255([200,236,90]),SICK=c255([190,210,100]);
const FORCE=c255([170,120,255]),MIND=c255([206,160,255]),VOID=c255([70,34,110]),VIO=c255([196,176,255]),VIO_CORE=c255([236,226,255]),PIERCE=c255([255,214,214]),BRUISE=c255([110,40,96]);
const MAGC=c255([255,150,236]),WARM=c255([236,140,72]),DUSK=c255([14,6,18]),COLDRIM=c255([150,120,220]),OK_BEAD=c255([255,200,150]),BLEED=c255([235,70,140]);

/* slot writers (the token layer's layout: see token-layer.mjs createLook) */
const CK={glow:'glowC',vig:'vigC',rim:'rimC',bead:'beadC',shade:'shadeC'};
function put(L,k,a,b,c,d,col,ca=0){const i=L.n[k];if(i>=SLOTS[k])return false;const o=i*4,A=L[k],C=L[CK[k]];A[o]=a;A[o+1]=b;A[o+2]=c;A[o+3]=d;C[o]=col[0];C[o+1]=col[1];C[o+2]=col[2];C[o+3]=ca;L.n[k]=i+1;return true;}
const rim=(L,col,a,ang,spread,mode=0)=>a>.004&&put(L,'rim',ang,spread,a,mode,col);
const bead=(L,ang,col,a,r)=>a>.01&&put(L,'bead',ang,a,r,0,col);
const vig=(L,ang,col,a,op,ring=0)=>a>.004&&put(L,'vig',ang,a,op,ring,col);
const glow=(L,kind,col,a)=>a>.004&&put(L,'glow',kind,0,0,0,col,a);

/** The struck side's angle on the frame. */
const fromOf=side=>side==='left'?Math.PI+.15:-.15;
const STUTTER=[1,.32,.32,1,1,.55,1,1,1,.4,1],B_STUT=.62;
export const elecStutter=q=>{const fr=Math.floor((q-B_STUT)*30);return fr<0||fr>=STUTTER.length?1:STUTTER[fr];};

/** A wound's mark on the frame (the token layer's own recoil, tint and flush come with hit()). */
function wound(L,w){
  const q=w.q,from=fromOf(w.side);if(q<0||q>3)return false;
  switch(w.look){
  case 'slashing':{const a=bump(unit(q/.5))**.5*(1-smooth((q-.25)/.6));rim(L,ROSE,.9*a,from,.55);
    const s=unit((q-1.3)/.5);if(s>0&&s<1){bead(L,from-.275+.55*easeOut(s),GOLD,.9*bump(s),.07);rim(L,GOLD,.5*bump(s)**.5,from-.275+.275*easeOut(s),.55*easeOut(s));}break;}
  case 'piercing':{const a=bump(unit(q/.35))**.6*(1-smooth((q-.2)/.7));bead(L,from,PIERCE,a,.06);break;}
  case 'bludgeoning':{const a=unit(q/.06)*(1-smooth((q-.25)/.9));rim(L,BRUISE,.8*a,from,.84,1);break;}
  case 'fire':{const on=unit(q/.1)*(1-smooth((q-1.2)/.6)),a=from+.28*easeOut((q-.15)/1.4)*(Math.cos(from)<0?1:-1),fl=.75+.25*Math.sin(q*19)*Math.sin(q*7.3);
    rim(L,FIRE,.55*on,(from+a)/2,Math.abs(a-from)+.3);bead(L,a,FIRE_CORE,.85*on*fl,.07);break;}
  case 'cold':{const sp=.95*easeOut(q/.7),a=1-smooth((q-1.1)/1.1);if(a>.01){rim(L,ICE,.45*a,from,sp*2+.2,1);rim(L,ICE,.32*a,from,sp*1.6+.2);bead(L,from+sp,ICE_CORE,.5*a,.04);bead(L,from-sp,ICE_CORE,.5*a,.04);}break;}
  case 'acid':{const dir=Math.sign(angDiff(A_HEART,from))||1,k=easeOut((q-.1)/1.6,2),a=from+dir*Math.abs(angDiff(A_HEART,from))*.82*k,on=unit(q/.12)*(1-smooth((q-1.4)/.6));
    bead(L,a,ACID,.9*on,.07);rim(L,ACID,.45*on,a-dir*.25,.5);break;}
  case 'poison':{const a=env(q,.05,.3,1.2,1.0);rim(L,SICK,.42*a,from,1.6);rim(L,SICK,.3*a,from,1.6,1);
    const pu=unit((q-.3)/1.0);if(pu>0&&pu<1){bead(L,from+.85*pu,SICK,.7*bump(pu),.06);bead(L,from-.85*pu,SICK,.7*bump(pu),.06);}break;}
  case 'force':{const a=bump(unit(q/.55));rim(L,FORCE,.32*a,0,7);rim(L,FORCE,.4*a,0,7,1);L.tok[2]*=1-.025*bump(unit(q/.45));break;}
  case 'mental':{const a=(q<.75?(Math.floor(q*30)%6<4?1:.3):0)*bump(unit(q/.75));L.por[0]+=.064*Math.sin(q*9)*a;rim(L,MIND,.35*a,from,1.2);
    L.tint[0]=MIND[0];L.tint[1]=MIND[1];L.tint[2]=MIND[2];L.tint[3]=Math.max(L.tint[3],.12*a);break;}
  case 'void':{const sp=1.2*easeOut(q/.6),a=1-smooth((q-.9)/1.3);rim(L,VOID,.85*a,from,sp*2,1);vig(L,from,VOID,.3*a,1);L.col[2]*=1-.18*bump(unit(q/1.6));break;}
  case 'electricity':{const st=elecStutter(q);L.col[1]*=.78+.22*st;L.col[2]*=.8+.2*st;
    // the charge crackles round the band: short arcs re-rolled 20×/s inside the spreading field, then it grounds at the pins and the heart
    if(st>=.5&&q<2.1){const fr=Math.floor(q*20),H=.22+1.45*easeOut(q/.32),drain=smooth((q-.95)/.7),fade=1-smooth((q-1.85)/.25);
      rim(L,VIO,.5*fade*(1-.5*drain)*(hash1(fr*5.3)>.35?1:.6),from,Math.min(3.4,2*H));
      for(let n=0;n<3;n++){const h=hash1(fr*3.1+n*7.7);if(h>.7)continue;const a=from+(hash1(h*91+n)-.5)*2*Math.min(1.8,H);const len=.12+.22*hash1(h*37);
        rim(L,n%2?VIO_CORE:VIO,(.75+.25*hash1(h*5))*fade*(1-.5*drain),a,len);}}
    const g=[A_PINL,A_PINR,A_HEART];for(let j=0;j<2;j++){const s=bump(unit((q-1.45-j*.1)/.5));bead(L,g[(Math.floor(q*3)+j)%3],VIO_CORE,.95*s,.06);}
    if(q<.4)bead(L,from,VIO_CORE,bump(unit(q/.2))*.85,.06);
    break;}
  default:{const t=w.tint?[w.tint[0]/255,w.tint[1]/255,w.tint[2]/255]:MAGC,a=env(q,0,.12,.9,1.1);rim(L,t,.5*a,from,1.2);rim(L,t,.4*a,from,1.2,1);}
  }
  return true;
}
/** The persistent look's colour on the frame. */
const PTINT={bleed:[214,40,110],fire:[255,130,50],poison:[160,190,64],acid:[176,212,70],cold:[150,180,255],electricity:[240,200,120],sonic:[110,210,206],mental:[190,130,250],force:[200,170,255],
  vitality:[255,232,170],void:[96,48,140],spirit:[170,180,240],slashing:[245,140,180],piercing:[245,170,170],bludgeoning:[130,50,110],precision:[236,200,140]};
const QANG={RU:-Math.PI/4,LU:-Math.PI*.75,RL:Math.PI/4,LL:Math.PI*.75};
const PT=new Map();const ptint=c=>{const key=c.look==='fallback'?c.tint?.join(','):c.look;let v=PT.get(key);if(!v){v=c255(c.look==='fallback'?(c.tint?c.tint.slice(0,3):[220,200,190]):PTINT[c.look]??[220,200,190]);PT.set(key,v);}return v;};
function persist(L,c){
  const ang=QANG[c.quad],col=ptint(c),k=c.k;
  // the quarter of the band takes the type's colour (hue on the gold), with a soft light on top, and a breath of it in her portrait
  rim(L,col,.7*k,ang,1.25,1);rim(L,col,(.22+.25*c.acc)*k,ang,1.1);vig(L,ang,col,.2*k*(1+.6*c.acc),0);
  if(c.look==='bleed'){const lo=ang+Math.sign(angDiff(A_HEART,ang))*.34;if(c.cq<0){const fr=c.ph,sw=fr<.72?smooth(fr/.72):0;bead(L,lo,BLEED,(.6+.4*sw)*c.on,.05+.03*sw);}
    else bead(L,lo,BLEED,.9*(1-c.cl*.6)*(1-easeOut(c.cl)),.05);}
  else if(c.look==='fire'){const span=6,q=Math.max(0,c.cq>=0?c.cq0:c.q),cyc=(q/span)%2,u=cyc<1?cyc:2-cyc,a=ang-.62+1.24*ease(u),fl=.75+.25*Math.sin(c.t*19)*Math.sin(c.t*7.3);
    bead(L,a,FIRE_CORE,c.cq<0?.9*c.on*fl*(1+.35*c.acc):(1-smooth(c.cl))*(1+.6*bump(unit(c.cl/.35))),.07);}
  else if(c.acc>.02&&c.cq<0){const u=unit(c.ph/.3);bead(L,ang-.62+1.24*ease(u),col,.8*c.acc*bump(u)**.5,.05);}
  if(c.cq>=0)bead(L,ang,MAGC,bump(unit((c.cl-.35)/.65))*.8,.05);
}
/** Dying 1..3 (continuous lv): dimmer and greyer per stage, the frame dulls; checks; healed. */
function dying(L,Y,lv,ko=0){
  const k=lv/3;
  // (the token layer's own unconscious dimming stands aside: the stages set the depth)
  if(ko>0){L.col[0]/=Math.max(.05,1-.7*ko);L.col[1]/=Math.max(.05,1-.34*ko);L.col[2]/=Math.max(.05,1-.3*ko);}
  L.col[0]*=1-.72*k**.8;L.col[1]*=1-.42*k**.9;L.col[2]*=1-.36*k;L.frm[1]=Math.max(L.frm[1],.92*smooth(lv/2.2));L.por[1]+=.014*k;L.por[3]*=1-.012*k;
  vig(L,0,DUSK,.5*k,1,1);
  for(let i=0;i<L.n.glow;i++)L.glowC[i*4+3]*=1-.85*k;for(let i=0;i<L.n.rim;i++)L.rim[i*4+2]*=1-.8*k;
  if(Y.stutter){const s=Y.stutter;L.col[1]*=s.hold?.82:1;rim(L,COLDRIM,.22*s.k,-Math.PI/2,7);L.col[2]*=1-.12*s.k;}
  if(Y.ok>0){L.col[1]*=1+.08*Y.ok;rim(L,WARM,.3*Y.ok,0,7);}
}
const MT={normal:{mul:[255,255,255],mulA:0,glow:[255,200,150],glowA:0,rim:[255,150,236],rimA:0,sat:1,bright:1,vig:0},
  frightened:{mul:[150,140,255],mulA:.2,glow:[0,0,0],glowA:0,rim:[178,74,252],rimA:.16,sat:.82,bright:.95,vig:.24},
  afterglow:{mul:[255,236,210],mulA:.04,glow:[255,186,120],glowA:.16,rim:[236,150,90],rimA:.3,sat:1.05,bright:1.03,vig:0},
  doomed:{mul:[204,198,230],mulA:.2,glow:[200,190,230],glowA:.04,rim:[186,164,230],rimA:.18,sat:.55,bright:.97,vig:.1},
  quickened:{mul:[255,255,255],mulA:0,glow:[255,150,240],glowA:.05,rim:[255,160,236],rimA:.32,sat:1.08,bright:1.05,vig:0},
  sickened:{mul:[196,214,120],mulA:.22,glow:[170,200,90],glowA:.03,rim:[170,200,90],rimA:.14,sat:.88,bright:.98,vig:.06}};
const MTC=Object.fromEntries(Object.entries(MT).map(([k,m])=>[k,{...m,mul:c255(m.mul),glow:c255(m.glow),rim:c255(m.rim)}]));
const VIG_C=c255([20,10,40]),TMP=[0,0,0],TMP2=[0,0,0],TMP3=[0,0,0];
const lerp=(a,b,k)=>a+(b-a)*k;
function mood(L,M){
  const A=MTC[M.from]??MTC.normal,B=MTC[M.to]??MTC.normal,k=ease(M.k);
  const mulA=lerp(A.mulA,B.mulA,k);if(mulA>.004&&L.tint[3]<mulA){for(let i=0;i<3;i++)L.tint[i]=lerp(A.mul[i],B.mul[i],k);L.tint[3]=mulA;}
  L.col[0]*=lerp(A.sat,B.sat,k);L.col[1]*=lerp(A.bright,B.bright,k);
  for(let i=0;i<3;i++){TMP[i]=lerp(A.rim[i],B.rim[i],k);TMP2[i]=lerp(A.glow[i],B.glow[i],k);}
  rim(L,TMP,lerp(A.rimA,B.rimA,k),0,7);vig(L,0,VIG_C,lerp(A.vig,B.vig,k),1,1);glow(L,2,TMP2,lerp(A.glowA,B.glowA,k));
}
/** Write the moment into a sampled Look (after sampleTokenLayer). parts: tokenLayer parts.
 * Returns true while something on it moves. Allocates nothing. */
export function applyFrameDamage(L,F,parts,ko=0){
  if(!F?.D)return false;const D=F.D;let moving=false;
  if(D.mood&&parts.woundTint!==false){mood(L,D.mood);moving||=D.mood.k<1;}
  // (test.8) with the drawn frame off the same marks go on her own token art's ring (the filter draws rims and beads there)
  if(D.persist?.length)for(const c of D.persist){persist(L,c);moving=true;}
  if(D.wound)moving=wound(L,D.wound)||moving;
  if(D.dying&&parts.ko!==false){const Y=D.dying;dying(L,Y,Math.max(0,Math.min(3,Y.lv??0)),ko);moving=true;}
  return moving;
}
/** (11.0.0-test.2) While her portrait is hidden (the classic drain, or a held cloak's veil), the rim
 * light and beads the damage wrote from slot r0/b0 on fade with her frame: the frame's own alpha, or a
 * faint share of the owner's ghost outline; nothing for others. (The shader adds rims and beads on top
 * of the frame, so without this an ember would ride the rim of a token nobody can see.) */
export function veilFrameDamage(L,r0,b0){
  const f=L.frm,vis=f[3]>=0?Math.min(1,f[3]):Math.min(1,Math.max(0,f[0])+Math.max(0,f[2])*.35);
  if(vis>=.999)return;
  for(let i=r0;i<L.n.rim;i++)L.rim[i*4+2]*=vis;
  for(let i=b0;i<L.n.bead;i++)L.bead[i*4+1]*=vis;
}
export {CYCLE as FRAME_CYCLE};
