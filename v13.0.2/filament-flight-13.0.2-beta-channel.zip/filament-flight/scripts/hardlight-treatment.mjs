import {V7_MEDKIT_TECHNIQUES,isV7Treatment,classicTreatmentStyle,treatmentTransitionVariant,sampleTreatmentTransit,sampleV7MedkitTreatment} from './hardlight-v7-medkit.mjs?v=13.0.2';
import {sampleTreatmentOperations} from './treatment-choreography.mjs?v=13.0.2';
import {paintTechnique} from './hardlight-techniques.mjs?v=13.0.2';
import {normalizeTreatmentAudio,validTreatmentAudio} from './treatment-audio.mjs?v=13.0.2';
import {RESTORATIVE_TECHNIQUES,sampleRestorativeTreatment} from './hardlight-restorative.mjs?v=13.0.2';
import {transitionTreatmentCore} from './treatment-core-motion.mjs?v=13.0.2';
import {paintTokenEffect} from './token-effects.mjs?v=13.0.2';
import {REFINED_MEDKIT_STYLES,sampleRefinedMedkitTreatment} from './hardlight-refined-medkit.mjs?v=13.0.2';
import {sampleMedicalOutcome} from './treatment-outcomes.mjs?v=13.0.2';
import {sampleMedicalDiagnostic} from './medical-diagnostic-scan.mjs?v=13.0.2';
import {medicalCraftEnabled,refineMedicalFrame,sampleMedicalCraft} from './v9-medical-craft.mjs?v=13.0.2';
/** Bounded, deterministic Battle Medicine artwork. World transforms are sampled
 * at display rate; the compact two-plane light canvas paints at a capped rate. */
export const TREATMENT_LABELS=Object.freeze({suture:'Suture weave',lattice:'Lattice reconstruction',compression:'Compression seal',precision:'Precision instruments',
  microloom:'Microloom dressing',vascular:'Perfusion channels',helix:'Helical traction',splint:'Articulated splints',membrane:'Protective membrane',resonance:'Resonant alignment',
  ...Object.fromEntries(Object.entries(RESTORATIVE_TECHNIQUES).map(([id,spec])=>[id,spec.name])),
  ...Object.fromEntries(Object.entries(V7_MEDKIT_TECHNIQUES).map(([id,spec])=>[id,spec.name]))});
export const TREATMENT_CATEGORIES=Object.freeze({original:Object.freeze(Object.keys(TREATMENT_LABELS).filter(id=>!RESTORATIVE_TECHNIQUES[id]&&!V7_MEDKIT_TECHNIQUES[id])),restorative:Object.freeze(Object.keys(RESTORATIVE_TECHNIQUES)),v7:Object.freeze(Object.keys(V7_MEDKIT_TECHNIQUES))});
export const TREATMENT_STYLES=Object.freeze(Object.keys(TREATMENT_LABELS));
/** v10 beta: the compact v7 treatments read alike at token size; they are listed last as Legacy. */
export const LEGACY_TREATMENT_IDS=Object.freeze(Object.keys(V7_MEDKIT_TECHNIQUES));
export const CLASSIC_TREATMENT_STYLES=Object.freeze(TREATMENT_STYLES.filter(id=>!isV7Treatment(id)));
/** Menus may hide new techniques while saved/macro calls retain a safe classic fallback. */
export function treatmentStylesFor({v7Enabled=true,v7Medkit=true,medkit=true,enabled=true}={}){return v7Enabled&&v7Medkit&&medkit&&enabled?[...TREATMENT_STYLES]:[...CLASSIC_TREATMENT_STYLES];}
export function treatmentUpgradeEnabled(context={},style){if(style?.enhanced===false)return false;const id=typeof style==='object'?style.style:style,v7=context.snapshot?.v7??context.v7,cfg=context.cfg??{};return v7?.enabled!==false&&v7?.medkit!==false&&cfg.v7Enabled!==false&&cfg.v7Medkit!==false&&(v7?.medkit===true||cfg.v7Medkit===true||isV7Treatment(id));}
export const TREATMENT_DETAILS=Object.freeze(['low','standard','high']);
export const TREATMENT_TIMING=Object.freeze({scan:1600,minimumAttempt:2000,outcome:2400,classicOutcome:1200});
const TAU=Math.PI*2,clamp=n=>Math.max(0,Math.min(1,n)),smooth=n=>{n=clamp(n);return n*n*(3-2*n);};
const mix=(a,b,p)=>a+(b-a)*p,wrap=n=>(n%1+1)%1;
const bounded=(value,fallback,min,max,name)=>{value??=fallback;if(!Number.isFinite(value)||value<min||value>max)throw new Error(`Treatment ${name} must be ${min}–${max}.`);return value;};
export function treatmentOptions(input={}){
  const style=input.style??'suture',detail=input.detail??'standard';
  if(!TREATMENT_STYLES.includes(style))throw new Error(`Unknown treatment style; use ${TREATMENT_STYLES.join(', ')}.`);
  if(!TREATMENT_DETAILS.includes(detail))throw new Error('Treatment detail must be low, standard or high.');
  for(const name of ['enhanced','variation','diagnosticScan'])if(input[name]!==undefined&&typeof input[name]!=='boolean')throw new Error(`Treatment ${name} must be true or false.`);
  if(input.audio!==undefined&&typeof input.audio!=='boolean')throw new Error('Treatment audio must be true or false.');
  return {style,intensity:bounded(input.intensity,1,.25,2,'intensity'),scale:bounded(input.scale,1,.5,1.75,'scale'),detail,audio:input.audio===true,diagnosticScan:input.diagnosticScan!==false,
    ...(input.audioSettings===undefined?{}:{audioSettings:normalizeTreatmentAudio(input.audioSettings)}),...(input.enhanced===undefined?{}:{enhanced:input.enhanced}),...(input.variation===undefined?{}:{variation:input.variation})};
}
export function validTreatment(value){
  return value===undefined||value&&typeof value==='object'&&!Array.isArray(value)&&TREATMENT_STYLES.includes(value.style)&&TREATMENT_DETAILS.includes(value.detail)&&
    (value.enhanced===undefined||typeof value.enhanced==='boolean')&&(value.variation===undefined||typeof value.variation==='boolean')&&(value.diagnosticScan===undefined||typeof value.diagnosticScan==='boolean')&&
    (value.audio===undefined||typeof value.audio==='boolean')&&validTreatmentAudio(value.audioSettings)&&Number.isFinite(value.intensity)&&value.intensity>=.25&&value.intensity<=2&&Number.isFinite(value.scale)&&value.scale>=.5&&value.scale<=1.75;
}
/** A compact patient-local release capture; never persist Canvas paths, image
 * objects or arbitrary caller data in an action flag. It exists for 280ms at
 * most and is removed by owner maintenance after that bounded release. */
export const TREATMENT_RELEASE_MS=280;
const RELEASE_KEYS=new Set(['style','detail','clock','scan','strength','scale','animated','phase','progress','outcome','emitters','v9MedicalCraft']);
const EMITTER_KEYS=new Set(['id','x','y','z','workPoint','role','stage','activity']);
const RELEASE_STATIONS=new Set(['leftUpper','rightUpper','leftLower','rightLower']);
const RELEASE_STAGES=new Set(['approach','work','transfer','check','reposition','scan','seal','release']);
const localPoint=value=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).every(k=>['x','y','z'].includes(k))&&['x','y','z'].every(k=>Number.isFinite(value[k])&&Math.abs(value[k])<=2.4);
export function validTreatmentRelease(value,bits){
  if(value===undefined)return true;
  return !!value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).every(k=>RELEASE_KEYS.has(k))&&
    TREATMENT_STYLES.includes(value.style)&&TREATMENT_DETAILS.includes(value.detail)&&['scanning','treating','finishing'].includes(value.phase)&&
    Number.isFinite(value.clock)&&value.clock>=0&&value.clock<=620&&Number.isFinite(value.scan)&&value.scan>=0&&value.scan<=1&&
    Number.isFinite(value.progress)&&value.progress>=0&&value.progress<=1&&Number.isFinite(value.strength)&&value.strength>=0&&value.strength<=2&&
    Number.isFinite(value.scale)&&value.scale>=.5&&value.scale<=1.75&&typeof value.animated==='boolean'&&(value.v9MedicalCraft===undefined||typeof value.v9MedicalCraft==='boolean')&&
    (value.outcome===null||['success','criticalSuccess','failure','criticalFailure'].includes(value.outcome))&&
    Array.isArray(value.emitters)&&value.emitters.length>0&&value.emitters.length<=4&&new Set(value.emitters.map(e=>e.id)).size===value.emitters.length&&
    value.emitters.every(e=>e&&typeof e==='object'&&!Array.isArray(e)&&Object.keys(e).every(k=>EMITTER_KEYS.has(k))&&RELEASE_STATIONS.has(e.id)&&(!bits||bits.includes(e.id))&&
      ['x','y','z'].every(k=>Number.isFinite(e[k])&&Math.abs(e[k])<=2.4)&&localPoint(e.workPoint)&&typeof e.role==='string'&&e.role.length<=64&&RELEASE_STAGES.has(e.stage)&&Number.isFinite(e.activity)&&e.activity>=0&&e.activity<=1);
}
export function captureTreatmentRelease(sample){
  const effect=sample?.effects?.find(e=>e.effect==='hardlight'&&e.v7Medkit&&e.strength>0);if(!effect)return undefined;
  const capture={style:effect.style,detail:effect.detail,clock:effect.clock,scan:effect.scan,strength:effect.strength,scale:effect.scale,animated:effect.animated!==false,phase:effect.phase,progress:effect.progress,outcome:effect.outcome??null,
    emitters:effect.emitters.map(({id,x,y,z,workPoint,role,stage,activity})=>({id,x,y,z,workPoint:{...workPoint},role,stage,activity})),...(effect.v9MedicalCraft===true?{v9MedicalCraft:true}:{})};
  return validTreatmentRelease(capture)?capture:undefined;
}
export function sampleTreatmentRelease(event,now,context){
  const capture=event.returnTreatment;if(!capture||!validTreatmentRelease(capture,event.bits)||!treatmentUpgradeEnabled(context,event.treatment)||event.reason==='target-deleted')return null;
  const response=context.snapshot?.conditionResponse;if(response?.bits&&response.collapse?.phase!=='awake')return null;
  const age=Math.max(0,now-event.returnAt),duration=Math.min(TREATMENT_RELEASE_MS,event.returnDuration??TREATMENT_RELEASE_MS);if(!(duration>0)||age>=duration)return null;
  const gain=1-smooth(age/duration);return {...capture,effect:'hardlight',v7Medkit:true,retiring:true,strength:capture.strength*gain};
}
export const treatmentFinishTime=(event,now)=>Math.max(now,event.started+event.travelDuration+(event.treatment?TREATMENT_TIMING.scan+TREATMENT_TIMING.minimumAttempt:0));
export const treatmentOutcomeDuration=event=>event.treatment?(event.treatment.enhanced===false?TREATMENT_TIMING.classicOutcome:TREATMENT_TIMING.outcome):650;
export function treatmentPhase(event,now){
  const age=Math.max(0,now-event.started),arrival=age-event.travelDuration;
  if(event.finishAt!=null&&now>=event.finishAt)return {phase:'finishing',progress:smooth((now-event.finishAt)/treatmentOutcomeDuration(event))};
  if(arrival<0)return {phase:'travel',progress:smooth(age/Math.max(1,event.travelDuration))};
  if(arrival<TREATMENT_TIMING.scan)return {phase:'scanning',progress:clamp(arrival/TREATMENT_TIMING.scan)};
  return {phase:'treating',progress:wrap((arrival-TREATMENT_TIMING.scan)/3600)};
}
/** Real bit poses, work contacts and internal states share one operation clock.
 * The original resonant artwork is retained; only its supported state changes. */
export function sampleTreatment(event,now,context,state,base){
  const enabled=treatmentUpgradeEnabled(context,event.treatment),spec=enabled?event.treatment:{...event.treatment,style:classicTreatmentStyle(event.treatment.style)},arrival=Math.max(0,now-event.started-event.travelDuration);
  const v9MedicalCraft=enabled&&medicalCraftEnabled(context);
  const animated=context.snapshot?.effective?.reducedMotion!==true;
  const finishing=state.phase==='finishing',finishElapsed=finishing?Math.max(0,now-event.finishAt)/1000:0;
  // Brake the existing operation clock instead of freezing a moving instrument
  // on the result edge. Integrating a smooth rate keeps its incoming velocity.
  const brake=clamp(finishElapsed/.24),coast=enabled&&animated?.24*(brake-brake**3+.5*brake**4)*1000:0;
  const motionTime=finishing?Math.max(0,event.finishAt-event.started-event.travelDuration)+coast:arrival;
  const workTime=animated?Math.max(0,motionTime-TREATMENT_TIMING.scan)/1000:0;
  const variants=context.snapshot?.v7?.transitionVariants!==false&&context.cfg?.v7TransitionVariants!==false;
  const variant=treatmentTransitionVariant(event,variants);let operations=sampleTreatmentOperations(spec.style,event.bits.length,workTime,{phase:state.phase,progress:state.progress,v7:enabled,variant,stations:event.bits,
    scanProgress:Math.min(1,motionTime/TREATMENT_TIMING.scan),reducedMotion:!animated,outcome:event.outcome,finishElapsed});
  // Missing properties belong to already-running older events and deliberately
  // keep their exact preparation. Only newly normalized true opts into optics.
  const diagnostic=spec.diagnosticScan===true&&['travel','scanning'].includes(state.phase)?sampleMedicalDiagnostic({...event,treatment:spec},context,operations,clamp(motionTime/TREATMENT_TIMING.scan),{v7:enabled,variant,animated,v9MedicalCraft}):null;
  if(diagnostic)operations=diagnostic.operations;
  const worldSize=(context.targetSize??context.size)*spec.scale,depths={},emitters=[];
  base.coreStates??={};if(enabled||diagnostic)base.tools??={};
  for(let i=0;i<event.bits.length;i++){
    const id=event.bits[i],op=operations.operations[i],local=op.position;
    const target={x:context.target.x+local.x*worldSize,y:context.target.y+local.y*worldSize};
    const p=state.phase==='travel'?state.progress:1,origin=base.positions[id];
    base.positions[id]=enabled?sampleTreatmentTransit(origin,target,state.phase==='travel'?clamp((now-event.started)/Math.max(1,event.travelDuration)):1,
      {index:i,size:context.size,reduced:!animated,variant,progressIsLinear:true,duration:event.travelDuration,fromVelocity:event.originVelocities?.[id],sideBoundary:context.target.x}):
      {x:mix(origin.x,target.x,p),y:mix(origin.y,target.y,p)-(animated?Math.sin(Math.PI*p)*context.size*.44:0)};
    const aimPoint={x:context.target.x+op.workPoint.x*worldSize,y:context.target.y+op.workPoint.y*worldSize};
    const aim=Math.atan2(aimPoint.y-base.positions[id].y,aimPoint.x-base.positions[id].x)+Math.PI/2;
    const raw=aim-(context.transform?.angle??0)-(context.orientations?.[id]??0);
    const start=enabled?(event.originRotations?.[id]??0):0,turn=Math.atan2(Math.sin(raw-start),Math.cos(raw-start));
    base.rotations[id]=start+turn*smooth(p*1.5);
    base.glows[id]={strength:(1.05+op.activity*.55)*spec.intensity,color:'#ff87e4',mode:'core'};
    base.coreStates[id]=op.core;if((enabled||diagnostic)&&op.tool)base.tools[id]=op.tool;
    if(enabled&&state.phase==='travel'){
      const handoff=smooth(p/.38),oldTool=event.originTools?.[id],oldCore=event.originCoreStates?.[id];
      if(oldTool?.amount>0)base.tools[id]={...oldTool,amount:oldTool.amount*(1-handoff)};
      const coreAge=clamp((now-event.started)/Math.max(1,event.travelDuration)),coreDuration=Math.max(.001,event.travelDuration*.36/1000);
      if(oldCore&&coreAge<.36)base.coreStates[id]=transitionTreatmentCore(oldCore,{state:'charging',amount:0,progress:p},coreAge/.36,
        {velocity:event.originCoreVelocities?.[id],duration:coreDuration});
      else base.coreStates[id]={state:'charging',amount:.4*smooth((p-.30)/.45),progress:p};
    }
    depths[id]=state.phase==='travel'?(enabled?mix(event.originDepths?.[id]??-1,local.z,p):null):local.z;
    emitters.push({id,x:local.x,y:local.y,z:local.z,workPoint:op.workPoint,role:op.role,stage:op.stage,activity:op.activity});
  }
  if(state.phase!=='travel')base.effects.push({effect:'hardlight',style:spec.style,detail:spec.detail,strength:spec.intensity*(diagnostic?diagnostic.handoff:1),scale:spec.scale,
    phase:state.phase,progress:state.progress,scan:animated?clamp(arrival/TREATMENT_TIMING.scan):1,clock:workTime,emitters,outcome:event.outcome??null,animated,
    operationCycle:operations.cycle,operationPeriod:operations.period,...(enabled?{v7Medkit:true,transitionVariant:variant}: {}),...(v9MedicalCraft?{v9MedicalCraft:true}:{}),...(diagnostic?{phase:'treating',progress:0,scan:1}: {})});
  if(state.phase==='scanning'&&diagnostic?.effect)base.effects.push(diagnostic.effect);
  return {...base,depths,effectScale:worldSize/context.size,state};
}

/** Local preview of the exact live sequence. This calls no APIs or game writes;
 * UI owns its clock and painting. Pass result/outcome only for a result preview. */
export function sampleTreatmentPreview(style,count,elapsed,{detail='standard',intensity=1,scale=1,reducedMotion=false,outcome=null,finishAt=null,v7Enabled,v7Medkit,v7TransitionVariants=true,v9MedicalCraft=false,enhanced,variation,diagnosticScan=false,id='medical-preview'}={}){
  const ids=['leftUpper','rightUpper','leftLower','rightLower'].slice(0,Math.max(1,Math.min(4,Math.round(count)||1)));
  const event={id,started:0,travelDuration:800,bits:ids,treatment:treatmentOptions({style,detail,intensity,scale,enhanced:v7Enabled===false||v7Medkit===false?false:enhanced,variation,diagnosticScan}),outcome,...(finishAt==null?{}:{finishAt})};
  const context={size:100,targetSize:100,target:{x:0,y:0},cfg:{v7TransitionVariants,v9MedicalCraft},snapshot:{effective:{reducedMotion},...(v7Medkit===undefined&&v7Enabled===undefined?{}:{v7:{enabled:v7Enabled!==false,medkit:v7Medkit,transitionVariants:v7TransitionVariants}})}};
  const base={positions:Object.fromEntries(ids.map((id,i)=>[id,{x:-135-i*7,y:30+i*12}])),effects:[],glows:{},rotations:{}};
  return sampleTreatment(event,Math.max(0,elapsed),context,treatmentPhase(event,elapsed),base);
}

const BRIGHT='#fff0fb',PALE='#ffd5f3',EDGE='#ff74d8';
/** One paint-update preparation can serve both depth planes. It owns no cache,
 * and callers discard it at the end of that update, including mutable previews.
 * The scan bridge retains its two original authored layers in the same order. */
export function prepareHardlightArtwork(effect){
  if(effect.v7Medkit&&effect.phase==='scanning'&&!effect.phaseBridge&&(effect.scan??0)>.72){
    const q=smooth(((effect.scan??0)-.72)/.28),layers=[];
    if(q<1)layers.push(prepareHardlightArtwork({...effect,phaseBridge:true,strength:effect.strength*(1-q)}));
    if(q>0)layers.push(prepareHardlightArtwork({...effect,phaseBridge:true,phase:'treating',progress:0,scan:1,clock:0,strength:effect.strength*q}));
    return {layers};
  }
  const normalized=effect.animated===false?{...effect,clock:0,scan:1}:effect;
  // Older mechanisms have their own result glyphs, some visible on the first
  // result frame. Hand their working surface smoothly to the shared ending
  // instead, keeping the same braked clock and actual instrument contacts.
  const sharedHandover=normalized.v7Medkit&&normalized.phase==='finishing'&&!REFINED_MEDKIT_STYLES.includes(normalized.style)&&!isV7Treatment(normalized.style);
  let baseEffect=normalized;
  if(sharedHandover){
    const working=sampleTreatmentOperations(normalized.style,normalized.emitters.length,normalized.clock,{v7:true,stations:normalized.emitters.map(e=>e.id),reducedMotion:normalized.animated===false});
    baseEffect={...normalized,phase:'treating',progress:0,strength:normalized.strength*(1-smooth(normalized.progress/.72)),...(normalized.v9MedicalCraft?{v9ResultProgress:normalized.progress}:{}),
      emitters:normalized.emitters.map((e,i)=>({...e,stage:working.operations[i].stage}))};
  }
  const frame=baseEffect.v7Medkit&&REFINED_MEDKIT_STYLES.includes(baseEffect.style)?sampleRefinedMedkitTreatment(baseEffect):isV7Treatment(baseEffect.style)?sampleV7MedkitTreatment(baseEffect):
    Object.hasOwn(RESTORATIVE_TECHNIQUES,baseEffect.style)?sampleRestorativeTreatment(baseEffect):null;
  const ending=normalized.v7Medkit&&normalized.phase==='finishing'&&normalized.progress>0&&normalized.progress<1?sampleMedicalOutcome(normalized):null;
  const craft=sampleMedicalCraft(baseEffect);
  // The retained artwork path keeps its original prepared-object contract as
  // well as its pixels. Only an actual V9 material layer extends that shape.
  return {effect:baseEffect,frame:refineMedicalFrame(frame,baseEffect),ending:refineMedicalFrame(ending,normalized),...(craft?{craft}:{})};
}
/** Paint one depth plane; coordinates are target-token units (100px = one
 * diameter). No blur filter, per-frame gradient allocation or unbounded trail. */
export function paintHardlight(ctx,effect,{plane='front',prepared=null,attachedEmitters=null}={}){
  if(!prepared)prepared=prepareHardlightArtwork(effect);
  if(prepared){
    if(prepared.layers)for(const layer of prepared.layers)paintHardlight(ctx,layer.effect,{plane,prepared:layer,attachedEmitters});
    else {
      if(prepared.frame)paintTokenEffect(ctx,prepared.frame,{plane,attachedEmitters});
      else paintHardlightBase(ctx,prepared.effect,{plane});
      if(prepared.craft)paintTokenEffect(ctx,prepared.craft,{plane});
      if(prepared.ending)paintTokenEffect(ctx,prepared.ending,{plane});
    }
    return;
  }
}
function paintHardlightBase(ctx,effect,{plane='front'}={}){
  // Assembly and work are separate authored surfaces. Blend their final
  // diagnostic frames so a complete canopy/patch never drops out or changes
  // shape on the scan-to-work edge. The disabled route keeps the old painter.
  if(effect.v7Medkit&&effect.phase==='scanning'&&!effect.phaseBridge&&(effect.scan??0)>.72){
    const q=smooth(((effect.scan??0)-.72)/.28);
    if(q<1)paintHardlight(ctx,{...effect,phaseBridge:true,strength:effect.strength*(1-q)},{plane});
    if(q>0)paintHardlight(ctx,{...effect,phaseBridge:true,phase:'treating',progress:0,scan:1,clock:0,strength:effect.strength*q},{plane});
    return;
  }
  if(effect.animated===false)effect={...effect,clock:0,scan:1};
  if(paintTechnique(ctx,effect,{plane}))return;
  const front=plane!=='rear',quality=effect.detail==='low'?0:effect.detail==='high'?2:1;
  const gain=effect.strength,phase=effect.phase,p=effect.progress,t=effect.clock;
  const finish=phase==='finishing',success=['success','criticalSuccess'].includes(effect.outcome);
  const fade=finish?1-smooth((p-.65)/.35):1,build=phase==='scanning'?smooth(effect.scan*1.8):1;
  const alpha=fade*gain,scan=phase==='scanning',cycle=wrap(t/3.6),motion=TAU*cycle;
  const ink=(a,color=EDGE,width=.62)=>{ctx.globalAlpha=clamp(a*alpha);ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineWidth=width;};
  const stroke=(points,a=.7,width=.62,color=EDGE,close=false,fill=0)=>{
    if(points.length<2||a*alpha<=.002)return;ink(a,color,width);ctx.beginPath();
    points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));if(close)ctx.closePath();
    if(fill){const before=ctx.globalAlpha;ctx.globalAlpha=before*fill;ctx.fill();ctx.globalAlpha=before;}
    if(width>=.7&&quality>0){const before=ctx.globalAlpha;ctx.globalAlpha=before*.16;ctx.lineWidth=width*4;ctx.stroke();ctx.globalAlpha=before;ctx.lineWidth=width;}ctx.stroke();
  };
  const line=(a,b,opacity=.7,width=.62,color=EDGE)=>stroke([a,b],opacity,width,color);
  const dot=(x,y,r=1,a=.9,color=PALE)=>{ink(a,color);ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();};
  const ellipse=(x,y,rx,ry,rotation,start=0,end=TAU,a=.5,width=.6,color=EDGE)=>{ink(a,color,width);ctx.beginPath();ctx.ellipse(x,y,rx,ry,rotation,start,end);if(width>=.7&&quality>0){const before=ctx.globalAlpha;ctx.globalAlpha=before*.14;ctx.lineWidth=width*3.5;ctx.stroke();ctx.globalAlpha=before;ctx.lineWidth=width;}ctx.stroke();};
  const curve=(a,b,c,d,opacity=.75,width=.65,color=EDGE)=>{ink(opacity,color,width);ctx.beginPath();ctx.moveTo(...a);ctx.bezierCurveTo(...b,...c,...d);if(width>=.65&&quality>0){const before=ctx.globalAlpha;ctx.globalAlpha=before*.15;ctx.lineWidth=width*3.8;ctx.stroke();ctx.globalAlpha=before;ctx.lineWidth=width;}ctx.stroke();};
  const beam=(emitter,point,opacity=.48)=>{
    if(emitter.workPoint)point=[emitter.workPoint.x*100,emitter.workPoint.y*100];
    opacity*=emitter.activity==null?1:.55+emitter.activity*.65;
    const from=[emitter.x*100,emitter.y*100];line(from,point,opacity*.3,2.2);line(from,point,opacity,.55,PALE);
    const pulse=wrap(t*.7+emitter.x),x=mix(from[0],point[0],pulse),y=mix(from[1],point[1],pulse);dot(x,y,.85,opacity*.9*Math.sin(Math.PI*pulse));
  };
  ctx.save();ctx.lineCap='round';ctx.lineJoin='round';
  // Thin bounded orbital echoes give the space depth, without a complete ring
  // hiding the token. Emitters only draw on the same plane as their own bit.
  for(let i=0;i<effect.emitters.length;i++){
    const e=effect.emitters[i],visible=(e.z>=0)===front;if(!visible)continue;
    const ex=e.x*100,ey=e.y*100,theta=Math.atan2(ey,ex),r=Math.hypot(ex,ey);
    if(quality>0)ellipse(0,-4,r,r*.61,i%2?.27:-.27,theta-.34,theta+.05,.22*build,.52);
    dot(ex,ey,1.35,.8,BRIGHT);
    if(!scan&&e.workPoint){beam(e,null,.62*build);dot(e.workPoint.x*100,e.workPoint.y*100,1.35,.8*build,BRIGHT);}
    if(scan){
      const sweep=-35+70*effect.scan,span=20+10*Math.sin(effect.scan*Math.PI),a=[-span,sweep],b=[span,sweep];
      stroke([[ex,ey],a,b],.36*build,.45,EDGE,true,.11);
      line(a,b,.75*build,.8,BRIGHT);beam(e,[i%2?span:-span,sweep],.58*build);
      if(quality>0)for(let j=-2;j<=2;j++)line([j*8,sweep-2],[j*8,sweep+2],.5*build,.4,PALE);
    }
  }
  if(!front){
    if(!scan&&effect.style==='lattice')for(let j=0;j<3+quality;j++)ellipse(0,(j-1-quality/2)*12,31,12,.12,Math.PI,TAU,.22,.5);
    ctx.restore();return;
  }
  // Diagnostic reticle locks around a subtle, abstract treatment area; no
  // anatomy or injury location is inferred from the token artwork.
  const focus=scan?smooth((effect.scan-.45)/.55):1;
  if(scan){
    for(const s of [-1,1]){
      stroke([[s*28,-29],[s*35,-29],[s*35,-19]],.55*focus,.65,PALE);
      stroke([[s*28,29],[s*35,29],[s*35,19]],.55*focus,.65,PALE);
    }
    const rows=quality===0?3:5;
    for(let j=0;j<rows;j++){
      const y=(j-(rows-1)/2)*12,on=smooth((effect.scan-j*.12)/.25);
      ellipse(0,y,25-Math.abs(y)*.18,5,.1,0,TAU,.33*on,.42);
      if(quality>0){dot(33,y,.65,.6*on);line([38,y],[43+j%2*3,y],.3*on,.45);}
    }
    ctx.restore();return;
  }
  const closure=finish&&success?smooth(p/.7):0,workFade=finish&&!success?1-smooth(p):1;
  const stage=(effect.v7Medkit?1:smooth(t/.9))*workFade;
  // These two established procedures intentionally retain their original art.
  if(effect.style==='lattice'){
    const n=quality===0?4:6,compression=1-.25*closure;
    for(let j=0;j<n;j++){
      const y=(j-(n-1)/2)*11,buildRib=effect.v7Medkit?1:smooth(t/.9-j*.14),rx=(31-Math.abs(y)*.2)*compression;
      ellipse(0,y,rx,9*compression,.14,0,Math.PI,.82*buildRib*workFade,.8,PALE);
      if(j<n-1)for(const s of [-1,1])stroke([[s*rx,y],[s*rx*.55,y+6],[-s*(rx-2),y+11]],.43*buildRib*workFade,.47);
    }
    for(const s of [-1,1])curve([s*17,-31],[s*38,-12],[s*38,12],[s*17,31],.62*stage,.75);
    const rung=-28+56*(.5-.5*Math.cos(motion));ellipse(0,rung,31-Math.abs(rung)*.2,8,.14,0,TAU,.7*stage,.9,BRIGHT);
    for(let i=0;i<effect.emitters.length;i++)if(!effect.emitters[i].workPoint)beam(effect.emitters[i],[(i%2?1:-1)*24,rung],.57*stage);
    if(quality>0)for(let j=0;j<3;j++)dot((j-1)*13,5*Math.sin(motion+j),.8,.6*stage);
  }
  if(effect.style==='resonance'){
    const amplitude=(1-closure)*(8+3*Math.sin(motion*.5)),lines=quality===0?3:5;
    for(const s of [-1,1]){
      stroke([[s*41,11],[s*34,11],[s*31,6],[s*31,-8]],.8*stage,.9,PALE);
      stroke([[s*41,-11],[s*34,-11],[s*31,-6],[s*31,8]],.8*stage,.9,PALE);
      dot(s*41,0,1.2,.8*stage,BRIGHT);
    }
    for(let j=0;j<lines;j++){
      const y=(j-(lines-1)/2)*10,points=[],n=quality===0?16:24;
      for(let k=0;k<=n;k++){
        const u=k/n,x=-29+58*u,v=y+Math.sin(u*Math.PI*3)*Math.sin(motion+j*.35)*amplitude;
        points.push([x,v]);
      }
      stroke(points,(j===Math.floor(lines/2)?.85:.4)*stage,j===Math.floor(lines/2)?.85:.5,j===Math.floor(lines/2)?BRIGHT:EDGE);
    }
    for(const x of [-29,-9.6667,9.6667,29])dot(x,0,1.1,.7*stage,PALE);
    effect.emitters.forEach((e,i)=>{if(!e.workPoint)beam(e,[(i%2?1:-1)*41,0],.6*stage);});
    if(closure>0)line([-29,0],[29,0],closure,1.2,BRIGHT);
  }
  if(finish){
    if(success){
      // A narrow travelling seal replaces the generic radial flash.
      const y=-32+p*64,width=effect.style==='compression'?14:22;
      curve([-width,y],[-width*.4,y+3],[width*.4,y+3],[width,y],Math.sin(Math.PI*p)*.9,1.05,BRIGHT);
      if(effect.outcome==='criticalSuccess'&&quality>0)for(const s of [-1,1])curve([s*5,-30],[s*34,-12],[s*34,12],[s*5,30],Math.sin(Math.PI*p)*.7,.65,PALE);
    }else{
      // Incomplete, safe disengagement; failure never draws a completed seal.
      for(const s of [-1,1])stroke([[s*(11+p*9),-21],[s*(15+p*9),-21],[s*(15+p*9),-14]],(1-p)*.5,.55,'#e9b5d5');
    }
  }
  ctx.restore();
}

/** Canvas-only under-glow. Treatment hardlight is thin pale line work; on a
 * light map it washes out at token size. After the treatment surface is
 * painted, a soft dark-plum copy of its own silhouette is laid beneath it
 * (destination-over), so every line gains a faint shadowed edge. On a dark
 * map that plum shadow is nearly invisible, so the look there barely moves.
 * One reused scratch canvas; no per-frame allocation. */
let underlayScratch=null;
export function underlayHardlightSurface(surface,ctx,resolution){
  const w=surface?.width|0,h=surface?.height|0;if(!ctx||w<2||h<2)return;
  const doc=globalThis.document;if(!doc)return;
  const scratch=underlayScratch??=doc.createElement('canvas');if(scratch.width!==w||scratch.height!==h){scratch.width=w;scratch.height=h;}
  const s=scratch.getContext('2d');if(!s)return;
  s.save();s.setTransform(1,0,0,1,0,0);s.globalCompositeOperation='copy';s.globalAlpha=1;s.drawImage(surface,0,0);
  // cube the coverage (destination-in with itself, twice): lines keep their edge, faint fills drop out,
  // so the patient under a translucent panel is not darkened
  s.globalCompositeOperation='destination-in';s.drawImage(scratch,0,0);s.drawImage(scratch,0,0);
  s.globalCompositeOperation='source-in';s.fillStyle='#2a0b25';s.fillRect(0,0,w,h);s.restore();
  // about 1.3 patient units of spread: px per unit = resolution/280
  const spread=Math.max(.8,Math.min(6,1.3*(resolution||280)/280));
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalCompositeOperation='destination-over';
  if('filter' in ctx){ctx.filter=`blur(${(spread*.55).toFixed(2)}px)`;ctx.globalAlpha=1;ctx.drawImage(scratch,0,0);ctx.drawImage(scratch,0,0);ctx.drawImage(scratch,0,0);ctx.filter=`blur(${(spread*1.6).toFixed(2)}px)`;ctx.globalAlpha=.7;ctx.drawImage(scratch,0,0);}
  else{ctx.globalAlpha=.3;for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]])ctx.drawImage(scratch,dx*spread*.7,dy*spread*.7);}
  ctx.restore();
}
