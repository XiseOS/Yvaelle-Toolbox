import {motion, installMotion} from './motion.mjs?v=13.0.2';
import {tokenShape} from './v11/token-shape.mjs?v=13.0.2';
import {TokenLayers} from './v11/token-layer-runtime.mjs?v=13.0.2';
import {damageRuntime} from './v11/damage-runtime.mjs?v=13.0.2';
import {healRuntime} from './v11/heal-runtime.mjs?v=13.0.2';
import {worldRuntime} from './v11/world-runtime.mjs?v=13.0.2';
import {v11PersistFilter} from './v11/damage-events.mjs?v=13.0.2';
import {InvisRuntime} from './v11/invis-runtime.mjs?v=13.0.2';
import {isOn as v11IsOn,partOn as v11PartOn,choice as v11Choice,resolveV11} from './v11/features.mjs?v=13.0.2';
import {installV11Emotes} from './v11/emotes.mjs?v=13.0.2';
import {emoteRuntime,EMOTE_FLAG} from './v11/emote-runtime.mjs?v=13.0.2';
import {JournalRuntime,readActorJournal,recapFor,pinPetal,newSession,herActor as journalActor} from './v11/journal-runtime.mjs?v=13.0.2';
import {RecapChat,postRecap,saveShareImage} from './v11/recap.mjs?v=13.0.2';
import {pinnedCharacter} from './quick-wheel.mjs?v=13.0.2';
import {forceDelete,deleteKey,isDeletion,deletes} from './forced-delete.mjs?v=13.0.2';
import {setCueSink} from './sound-cues.mjs?v=13.0.2';
import {ID, registerSettings, configuration,runtimeConfiguration,invalidateConfiguration} from './config.mjs?v=13.0.2';
import {normalizeFlag, resolveRenderState} from './state.mjs?v=13.0.2';
import {loadAssets, current, isShown} from './renderer.mjs?v=13.0.2';
import {PoseRenderer} from './pose-renderer.mjs?v=13.0.2';
import {FlightAPI, serverTime} from './api.mjs?v=13.0.2';
import {healthContext} from './conditions.mjs?v=13.0.2';
import {Reactions} from './reactions.mjs?v=13.0.2';
import {trackMovement} from './flight-dynamics.mjs?v=13.0.2';
import {WingLights} from './wing-light.mjs?v=13.0.2';
import {resolveBitLight} from './light-model.mjs?v=13.0.2';
import {LanternRuntime} from './lantern-runtime.mjs?v=13.0.2';
import {registerLanternControls} from './lantern-controls.mjs?v=13.0.2';
import {WingAudio,BitActionAudio} from './audio-runtime.mjs?v=13.0.2';
import {qualityConfiguration} from './quality.mjs?v=13.0.2';
import {bitAssets} from './bit-assets.mjs?v=13.0.2';
import {BitIntentTargets} from './bit-intent.mjs?v=13.0.2';
import {localPerformance} from './performance.mjs?v=13.0.2';
import {invalidateTrailVisibility} from './trails.mjs?v=13.0.2';
import {runFlightFeel,installFlightFeelHooks} from './flight-feel-runtime.mjs?v=13.0.2';
import {FlightFxRenderer} from './flight-fx-renderer.mjs?v=13.0.2';
import {placeOverlays,restoreOverlays,bodyOffset} from './token-overlays.mjs?v=13.0.2';
import {addDecorProbe} from './keepsake/decor-hold.mjs?v=13.0.2';
import {runtimeVisible,dormantSampleDue,frozenFrameUnchanged} from './runtime-activity.mjs?v=13.0.2';
import {cancelCompactFlowPreparation} from './compact-bit-formations.mjs?v=13.0.2';
import {SharedTokenPreviewRenderer} from './shared-token-preview.mjs?v=13.0.2';
import {ParkedBitLights} from './v8-parked-lights.mjs?v=13.0.2';
import {parkedLightEmitters} from './v8-parked-provider.mjs?v=13.0.2';
import {applyWorkingPosture,clearWorkingPosture} from './v8-motion.mjs?v=13.0.2';
import {registerV8Controls} from './v8-controls.mjs?v=13.0.2';
import {invalidateScanWalls,invalidateScanWallVisibility,releaseScanWallSource} from './v88-scan-walls.mjs?v=13.0.2';
import {scanTokenVisible} from './v82-scene-scan-context.mjs?v=13.0.2';
import {installMedkitRelay} from './medkit-relay.mjs?v=13.0.2';
import {installTreatWoundsGuard} from './medkit-guard.mjs?v=13.0.2';
import {setLiveIntent,clearLiveIntent} from './bit-intent.mjs?v=13.0.2';
import {registerV10Features} from './v10-features.mjs?v=13.0.2';
import {playWarp,warp as warpTo,chooseWarp,warpLeaveMs} from './warp.mjs?v=13.0.2';
import {DecoyRuntime} from './v12/decoy-runtime.mjs?v=13.0.2';
import {FieldMenus,registerFieldMenuKey} from './v12/field-menus.mjs?v=13.0.2';
import {CurseRuntime} from './v13/curse-runtime.mjs?v=13.0.2';
import {HEAD_EXTRAS} from './keepsake/sheet/dress.mjs?v=13.0.2';
import {setBodyPoseSource} from './warp-capture.mjs?v=13.0.2';
import {playRoutine} from './routines.mjs?v=13.0.2';
import {recoverInterruptedCheck} from './self-check.mjs?v=13.0.2';
import {sampleTokenManoeuvre} from './flight-manoeuvres.mjs?v=13.0.2';
export {ID,isShown};
const NO_WORK_EVENTS=Object.freeze([]);
const UNSAMPLED_FLIGHT=Symbol('unsampled flight');

function onlyAudioChanges(changes) {
  const path=`flags.${ID}.audio`;
  const check=(key,value)=>key===path||key.startsWith(`${path}.`)||key===`flags.${ID}.-=audio`||(key===`flags.${ID}`&&deletes(value,'audio'))||
    (['flags',`flags.${ID}`].includes(key)&&value&&typeof value==='object'&&
      Object.keys(value).length>0&&Object.entries(value).every(([child,v])=>check(`${key}.${child}`,v)));
  return Object.keys(changes).length>0&&Object.entries(changes).every(([key,value])=>check(key,value));
}

/** (v11) Only her saved emote changed: the emote runtime plays it; nothing else needs to resync. */
function onlyEmoteChanges(changes){
  const keys=Object.keys(changes??{}).filter(k=>k!=='_id'&&k!=='_stats');if(!keys.length)return false;
  return keys.every(k=>{if(k===`flags.${ID}.${EMOTE_FLAG}`||k.startsWith(`flags.${ID}.${EMOTE_FLAG}.`))return true;
    const v=k==='flags'?changes.flags?.[ID]:k===`flags.${ID}`?changes[k]:null;
    if(k==='flags'&&Object.keys(changes.flags??{}).length!==1)return false;
    return !!v&&typeof v==='object'&&Object.keys(v).length>0&&Object.keys(v).every(c=>c===EMOTE_FLAG);});
}

// Existing rigs already follow animated mesh positions each display frame;
// their light/audio controllers sample positions on their own bounded ticks.
// Keep every other document edit on the full synchronization path.
const MOVEMENT_FIELDS=new Set(['x','y','rotation','elevation','_movement']);
const TEXTURE_FLIP_FIELDS=new Set(['scaleX','scaleY']);
function onlyMovementChanges(changes) {
  const keys=Object.keys(changes);
  return keys.length>0&&keys.every(key=>{
    if(MOVEMENT_FIELDS.has(key)||key.startsWith('_movement.'))return true;
    if(key==='texture.scaleX'||key==='texture.scaleY')return typeof changes[key]==='number'&&Number.isFinite(changes[key]);
    if(key!=='texture'||!changes.texture||typeof changes.texture!=='object'||Array.isArray(changes.texture))return false;
    const fields=Object.keys(changes.texture);
    return fields.length>0&&fields.every(field=>TEXTURE_FLIP_FIELDS.has(field)&&typeof changes.texture[field]==='number'&&Number.isFinite(changes.texture[field]));
  });
}

/** Foundry accepts dotted, nested and explicit deletion updates. Allocation
 * lifecycles must be notified when their enclosing flag namespace is removed,
 * too, so an already rendered remote action cannot survive its source flag. */
export function bitFlagsChanged(changes) {
  const fields=['bitAnimations','bitAllocations'];
  const inspect=(object,prefix='')=>Object.entries(object??{}).some(([key,value])=>{
    const path=prefix?`${prefix}.${key}`:key;
    if(path==='-=flags'||path===`flags.-=${ID}`)return true;
    if((path==='flags'||path===`flags.${ID}`)&&isDeletion(value))return true;
    if((path==='flags'||path===`flags.${ID}`)&&value==null)return true;
    return fields.some(field=>path===`flags.${ID}.${field}`||path.startsWith(`flags.${ID}.${field}.`)||path===`flags.${ID}.-=${field}`)
      ||value&&typeof value==='object'&&!Array.isArray(value)&&inspect(value,path);
  });
  return inspect(changes);
}

function resumePlayback(records,doc,field,observed=false,restoring=false,raw=UNSAMPLED_FLIGHT,now) {
  const t=(raw===UNSAMPLED_FLIGHT?doc.getFlag(ID,'flight'):raw)?.[field];
  if(!t){records.delete(doc);return true;}
  let playback=records.get(doc);
  if(!playback||playback.id!==t.id){
    playback={id:t.id,live:observed,settled:false};records.set(doc,playback);
  }
  // Another observer can read state before the updateToken listener runs.
  if(observed&&!playback.settled)playback.live=true;
  // Restoration and completion are final for this event ID. A repeated full
  // flag payload or a clock correction must not revive its previous shape.
  if((restoring&&!playback.live)||(now??serverTime())>=t.started+t.duration)playback.settled=true;
  return playback.live&&!playback.settled;
}

/** Flight feel (beta.29): the wings sweep with her body's own motion, so they
 * stay swept while she carries on past a stop and ease as she settles. */
function feelMovement(s){
  const f=s?.feelState;if(!f||f.sleeping||!s.feel||!Number.isFinite(f.bvx)||!Number.isFinite(f.bvy))return null;
  const speed=Math.hypot(f.bvx,f.bvy);return {vx:f.bvx,vy:f.bvy,speed:speed<.015?0:speed};
}

export class FlightManager {
  constructor({load=loadAssets,makeRenderer=(...args)=>new PoseRenderer(...args),bindMotion=installMotion}={}) {
    this.states=new Map(); this.pending=new Map(); this.epoch=0;
    this.stateSamples=new WeakMap();
    this.completedSyncs=new WeakMap();
    this.workingTokens=new WeakSet();
    this.ticker=null; this.lastTick=0; this.reported=new Set(); this.load=load;this.makeRenderer=makeRenderer;this.bindMotion=bindMotion;
    this.lights=new WingLights(this);
    this.lantern=new LanternRuntime(this);
    this.parkedLights=new ParkedBitLights(this,{emitters:(token,snapshot,now)=>parkedLightEmitters(this,token,snapshot,now)});
    this.transitions=new WeakMap(); this.poseTransitions=new WeakMap();this.modeTransitions=new WeakMap();this.bitTransitions=new WeakMap();this.bitCountTransitions=new WeakMap();this.structureTransitions=new WeakMap();this.structurePoseTransitions=new WeakMap();
    this.conditionTransitions=new WeakMap(); this.hpTransitions=new WeakMap(); this.entrances=new WeakSet();
  }

  report(error) {
    console.error(`${ID} |`,error);
    const message=String(error?.message??error);
    if (!this.reported.has(message)) {
      this.reported.add(message); ui.notifications.error(`Yvaelle’s Toolbox: ${message}`);
    }
  }
  // Startup restores the saved destination, not a previous session's flight
  // animation. A newly received transition retains its live synchronized phase
  // through renderer refreshes and settings changes on this browser.
  resumeTransition(doc, observed=false,raw=UNSAMPLED_FLIGHT,now) {
    return resumePlayback(this.transitions,doc,'transition',observed,false,raw,now);
  }

  resumeBitCountTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {return resumePlayback(this.bitCountTransitions,doc,'bitCountTransition',observed,false,raw,now);}
  resumeBitTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {return resumePlayback(this.bitTransitions,doc,'bitTransition',observed,false,raw,now);}
  resumeStructureTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {return resumePlayback(this.structureTransitions,doc,'structureTransition',observed,false,raw,now);}
  resumeStructurePoseTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {return resumePlayback(this.structurePoseTransitions,doc,'structurePoseTransition',observed,false,raw,now);}
  resumeModeTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {return resumePlayback(this.modeTransitions,doc,'modeTransition',observed,false,raw,now);}

  resumePoseTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {
    return resumePlayback(this.poseTransitions,doc,'poseTransition',observed,false,raw,now);
  }

  resumeConditionTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {
    return resumePlayback(this.conditionTransitions,doc,'conditionTransition',observed,false,raw,now);
  }

  resumeHPTransition(doc,observed=false,raw=UNSAMPLED_FLIGHT,now) {
    return resumePlayback(this.hpTransitions,doc,'hpTransition',observed,false,raw,now);
  }

  restorePlayback(doc) {
    const raw=doc.getFlag(ID,'flight')??null;
    // Lock only transitions first seen as saved data. Live updates are observed
    // before sync, including when another listener reads the API first.
    for(const [records,field] of [[this.transitions,'transition'],[this.poseTransitions,'poseTransition'],
      [this.conditionTransitions,'conditionTransition'],[this.hpTransitions,'hpTransition'],[this.modeTransitions,'modeTransition'],[this.bitTransitions,'bitTransition'],[this.bitCountTransitions,'bitCountTransition'],[this.structureTransitions,'structureTransition'],[this.structurePoseTransitions,'structurePoseTransition']])
      resumePlayback(records,doc,field,false,true,raw);
  }

  observeUpdate(doc,changes,movementOnly=onlyMovementChanges(changes)) {
    if(!movementOnly){this.stateSamples.delete(doc);this.bits?.invalidateState?.(doc);}
    const rendered=this.states.get(doc.object);
    if(rendered)rendered.renderRevision=(rendered.renderRevision??0)+1;
    if(movementOnly)return;
    const path=`flags.${ID}.flight`;
    let bitCountTransitionChanged=false,structureTransitionChanged=false,structurePoseTransitionChanged=false,bitTransitionChanged=false,modeTransitionChanged=false,transitionChanged=false,poseTransitionChanged=false,conditionTransitionChanged=false,hpTransitionChanged=false,activationChanged=false;
    for(const [key,value] of Object.entries(changes)) {
      const flag=key==='flags'?value?.[ID]?.flight:key===`flags.${ID}`?value?.flight:key===path?value:null;
      const edited=field=>key===`${path}.${field}`||key.startsWith(`${path}.${field}.`)||
        (flag!=null&&Object.hasOwn(flag,field));
      modeTransitionChanged ||= edited('modeTransition');
      structureTransitionChanged ||= edited('structureTransition');
      structurePoseTransitionChanged ||= edited('structurePoseTransition');
      bitTransitionChanged ||= edited('bitTransition');
      bitCountTransitionChanged ||= edited('bitCountTransition');
      transitionChanged ||= edited('transition');
      poseTransitionChanged ||= edited('poseTransition');
      conditionTransitionChanged ||= edited('conditionTransition');
      hpTransitionChanged ||= edited('hpTransition');
      activationChanged ||= ['enabled','activation','started'].some(edited);
    }
    if(bitTransitionChanged)this.resumeBitTransition(doc,true);
    if(bitCountTransitionChanged)this.resumeBitCountTransition(doc,true);
    if(structureTransitionChanged)this.resumeStructureTransition(doc,true);
    if(structurePoseTransitionChanged)this.resumeStructurePoseTransition(doc,true);
    if(modeTransitionChanged)this.resumeModeTransition(doc,true);
    if(transitionChanged)this.resumeTransition(doc,true);
    if(poseTransitionChanged)this.resumePoseTransition(doc,true);
    if(conditionTransitionChanged)this.resumeConditionTransition(doc,true);
    if(hpTransitionChanged)this.resumeHPTransition(doc,true);
    const raw=doc.getFlag(ID,'flight');
    if(!raw?.enabled)this.entrances.delete(doc);
    else if(activationChanged)this.entrances.add(doc);
  }

  /** Per frame: health comes from the reactions' hook-maintained cache and one
   * clock sample serves every playback check. */
  context(doc,now=serverTime()) {
    const health=this.reactions?.context(doc,now)??healthContext(doc),s=this.states.get(doc.object),raw=doc.getFlag(ID,'flight')??null,V11=resolveV11(doc);
    return {...health,resumeBitCountTransition:this.resumeBitCountTransition(doc,false,raw,now),resumeStructureTransition:this.resumeStructureTransition(doc,false,raw,now),resumeStructurePoseTransition:this.resumeStructurePoseTransition(doc,false,raw,now),resumeBitTransition:this.resumeBitTransition(doc,false,raw,now),resumeModeTransition:this.resumeModeTransition(doc,false,raw,now),resumeFlightTransition:this.resumeTransition(doc,false,raw,now),resumePoseTransition:this.resumePoseTransition(doc,false,raw,now),
      resumeConditionTransition:this.resumeConditionTransition(doc,false,raw,now),
      resumeHPTransition:!!health.hpTransition||this.resumeHPTransition(doc,false,raw,now),
      movement:s?.kinematics?{...s.kinematics,...feelMovement(s),angle:s.source.rotation+s.bank+(s.manoeuvre?.active?s.manoeuvre.bank+s.manoeuvre.lagRotation:0)}:null,manoeuvre:s?.manoeuvre??null,
      // v11: the persistent types v11 draws on her (the v10 persistent art steps aside for them)
      v11Persist:v11PersistFilter(V11),
      // (12.1.0-beta.1) Wingless mode puts her wings away for good (state.mjs)
      wingless:V11.wingless===true};
  }

  invalidateActor(actor) {
    if(!actor?.uuid)return;
    for(const state of this.states.values())if(state.token.document.actor?.uuid===actor.uuid)
      state.renderRevision=(state.renderRevision??0)+1;
  }

  renderState(doc,data,cfg,now) {
    const snapshot=resolveRenderState(data,cfg,now,this.context(doc,now));
    const prepared=this.bits?.prepareSnapshot(doc,snapshot,now)??snapshot;
    const events=prepared.bitReservationEvents??this.bits?.records?.(doc,false)??[];
    let worked=prepared;
    // Ordinary movement has no diagnostic job. Avoid target lookups, copied
    // escorts, preference/config clones and the posture sampler on that path.
    // A token with a previous working envelope still samples its full release.
    const working=events.length?events.filter(event=>event.status!=='queued'&&event.status!=='returning'&&event.status!=='finished'&&event.conditionPausedAt==null&&(event.kind==='treatment'||event.utility?.mode==='areaScan'||event.utility?.mode==='creatureScan')):NO_WORK_EVENTS;
    if(doc.object&&(working.length||this.workingTokens.has(doc.object))){
      const pref=prepared.v8Motion?.workingPosture??doc.getFlag(ID,'v8Tools')?.workingPosture;
      const motionCfg=typeof pref==='boolean'&&pref!==cfg.v8WorkingPosture?{v8WorkingPosture:pref,reduced:cfg.reduced,enabled:cfg.enabled,wingRenderer:cfg.wingRenderer}:cfg;
      const workEvents=working.flatMap(event=>{
        const target=event.target?globalThis.canvas?.tokens?.get?.(event.target):null;
        if(event.target&&!scanTokenVisible(target))return [];
        const center=target?.center;return [center?{...event,targetCenter:center}:event];
      });
      worked=applyWorkingPosture(prepared,{events:workEvents,now,token:doc.object,source:doc.object?.center},motionCfg);
      if(worked.workingPosture?.amount>0||workEvents.length&&motionCfg.v8WorkingPosture!==false&&!motionCfg.reduced&&motionCfg.enabled!==false)this.workingTokens.add(doc.object);else this.workingTokens.delete(doc.object);
    }
    const lit=resolveBitLight(worked,cfg),decorated=this.lantern?.decorate(doc.object,lit,now)??lit;
    return this.bits?.retainPreparation?.(prepared,decorated)??decorated;
  }

  frameInputs(state,cfg,now,values=[]) {
    const token=state.token,doc=token.document,source=token.mesh;
    // These identities protect native-light consumers against same-frame edits.
    // Reuse the private storage; its values are compared, never exposed as a
    // public state object. Moving a token needs no new identity array each tick.
    values[0]=cfg;values[1]=state.data;values[2]=state.renderRevision;values[3]=this.bits?.preparationRevision?.(doc);
    values[4]=doc.getFlag(ID,'flight');values[5]=doc.getFlag(ID,'bitAllocations');values[6]=doc.getFlag(ID,'bitAnimations');
    values[7]=doc.getFlag(ID,'v8Tools');values[8]=doc.actor;values[9]=doc.hidden;values[10]=source;
    values[11]=token.x;values[12]=token.y;values[13]=token.w;values[14]=token.h;values[15]=source?.x;values[16]=source?.y;
    values[17]=source?.rotation;values[18]=source?.elevation;
    const lantern=this.lantern?.frameInputs?.(token,now,values[4]);let length=19;
    for(const value of lantern??NO_WORK_EVENTS)values[length++]=value;
    values.length=length;return values;
  }

  rememberFrame(state,cfg,now) {
    const ticker=globalThis.canvas?.app?.ticker,frame=ticker?.lastTime;
    const sample=state.frameSample??={inputs:[]};
    sample.snapshot=state.snapshot;sample.now=now;sample.ticker=ticker;sample.frame=Number.isFinite(frame)?frame:null;
    this.frameInputs(state,cfg,now,sample.inputs);
  }

  /** Only native lighting may borrow the canonical display-frame sample.
   * Public state reads remain freshly resolved. Without a ticker timestamp,
   * require the exact server-clock sample; never accept an age window. */
  frameState(token,now,{displayFrame=false}={}) {
    const state=this.states.get(token),sample=state?.frameSample;if(!sample||now<sample.now||globalThis.document?.hidden===true)return null;
    const ticker=globalThis.canvas?.app?.ticker,sameFrame=displayFrame&&sample.frame!==null&&sample.ticker===ticker&&sample.frame===ticker?.lastTime;
    if(!sameFrame&&sample.now!==now)return null;
    const inputs=this.frameInputs(state,runtimeConfiguration(),now,state.frameCompare??=[]);
    return inputs.length===sample.inputs.length&&inputs.every((value,index)=>value===sample.inputs[index])?sample.snapshot:null;
  }

  sampleState(token,now=serverTime()) {
    const doc=token?.document??token;if(!doc?.getFlag)return null;
    const raw=doc.getFlag(ID,'flight');let cached=this.stateSamples.get(doc);
    if(!cached||cached.raw!==raw){cached={raw,data:normalizeFlag(raw,now)};this.stateSamples.set(doc,cached);}
    return this.renderState(doc,cached.data,runtimeConfiguration(),now);
  }

  async preload() {
    // The shared loader deduplicates and caches textures. Start before drawing
    // the scene; a failed warm-up is retried and reported by normal token sync.
    try {if(configuration().enabled)await this.load({atlas:false});} catch {}
  }

  previewOriginal(token){
    if(!token?.isPreview||token.document?.parent!==canvas.scene)return null;
    const doc=canvas.scene?.tokens?.get(token.document.id),placed=doc?.object;
    const valid=candidate=>!!(candidate&&!candidate.isPreview&&current(candidate)&&candidate.mesh&&
      candidate.document===doc&&candidate.document.parent===canvas.scene&&candidate.document.id===token.document.id&&(!placed||candidate===placed));
    return valid(token._original)?token._original:valid(placed)?placed:null;
  }
  previewSource(token){
    const original=this.previewOriginal(token),state=this.states.get(original);
    return state?.renderer?.previewMeshes&&!state.renderer.sharedPreview?state:null;
  }
  updateSharedPreview(state,owner,config,now,{draw=true}={}){
    if(state.source!==state.token.mesh){state.unbind?.();state.source=state.token.mesh;state.unbind=this.bindMotion(state.source,state);}
    // Copy existing sampled motion. The preview neither advances the beat nor
    // samples allocation/condition/lighting channels for a second time.
    for(const key of ['data','opts','snapshot','snapshotAt','on','blend','lift','bank','pitch','swayX','motionBlend','flightFactor','altScale','squashX','squashY','feelWidth','feelHeight','feelFlex','feelRate','feelWingAlpha','feelShield','feel'])state[key]=owner[key];
    state.previewOf=owner.token;
    return draw?state.renderer.update(state,owner.snapshot,config,now):true;
  }
  createSharedPreview(token,owner,{draw=true}={}){
    const previous=this.states.get(token);
    if(previous?.renderer.sharedPreview){this.updateSharedPreview(previous,owner,runtimeConfiguration(),serverTime(),{draw});return previous;}
    this.pending.delete(token);previous?.unbind?.();previous?.renderer.destroy();previous?.feelFxRenderer?.destroy();
    const state={token,source:token.mesh,kinematics:{},movementEpoch:0,previewOf:owner.token};
    try{
      state.renderer=new SharedTokenPreviewRenderer(token,()=>this.previewSource(token));
      state.unbind=this.bindMotion(state.source,state);
      this.updateSharedPreview(state,owner,runtimeConfiguration(),serverTime(),{draw});
      this.states.set(token,state);this.startTicker();canvas.primary.sortDirty=true;canvas.primary.renderDirty=true;
      return state;
    }catch(error){state.unbind?.();state.renderer?.destroy();this.states.delete(token);throw error;}
  }

  async sync(token) {
    const active=current(token);
    if(active&&token.isPreview&&runtimeConfiguration().enabled){
      const owner=this.previewSource(token);
      if(owner){try{this.createSharedPreview(token,owner);return;}catch(error){this.report(error);}}
      else if(this.states.get(token)?.renderer.sharedPreview)this.remove(token);
      const original=this.previewOriginal(token);
      // A drag clone can retain old flags after its placed token retracts.
      // Do not revive that obsolete look just because its renderer is gone.
      if(original){const destination=this.states.get(original)?.snapshot??this.sampleState(original);if(destination?.rendering.active===false){this.remove(token);return;}}
    }
    if(active)this.restorePlayback(token.document);
    this.audio?.sync(token);this.treatmentAudio?.sync(token);
    if (!active) return;
    this.lights.sync(token);
    this.lantern.sync(token);
    this.reactions?.seedActor(token.document.actor);
    try {
      // The cached runtime configuration (invalidated by every settings change):
      // a scene of tokens syncing must not re-read ~200 settings each.
      const baseCfg=runtimeConfiguration();
      if (!baseCfg.enabled) { this.remove(token); return; }
      const raw=token.document.getFlag(ID,'flight'), now=serverTime();
      const data=normalizeFlag(raw,now),cfg=qualityConfiguration(baseCfg,data),snapshot=this.renderState(token.document,data,cfg,now);
      const s=this.states.get(token);
      if (s) {
        // A legacy OFF keeps the last look while its original easing fades out.
        s.data=raw==null?{...s.data,enabled:false,airborne:false,bitsDeployed:false,transition:null,bitTransition:null,bitCountTransition:null,modeTransition:null}:data;
        s.snapshot=snapshot;s.snapshotAt=now;
        this.entrances.delete(token.document);
        this.acknowledgeSync(token);
        return;
      }
      if (!snapshot.rendering.active || this.pending.has(token)) return;
      const epoch=this.epoch, ticket={}; this.pending.set(token,ticket);
      try {
        const textures=await this.load({atlas:snapshot.rendering.renderer==='atlas'});
        if (epoch!==this.epoch || this.pending.get(token)!==ticket || !current(token) || !runtimeConfiguration().enabled) return;
        const latest=normalizeFlag(token.document.getFlag(ID,'flight'),serverTime());
        if (!this.renderState(token.document,latest,runtimeConfiguration(),serverTime()).rendering.active || this.states.has(token)) return;
        this.create(token,textures,latest);
      } catch (error) {
        if (epoch===this.epoch && this.pending.get(token)===ticket) { this.remove(token); this.report(error); }
      } finally { if (this.pending.get(token)===ticket) this.pending.delete(token); }
    } catch (error) { this.remove(token); this.report(error); }
  }

  syncAcknowledgment(doc){return this.completedSyncs.get(doc);}
  acknowledgeSync(token){
    const state=this.states.get(token);if(!state||token.isPreview)return;
    this.completedSyncs.set(token.document,{token,state,inputs:this.frameInputs(state,runtimeConfiguration(),serverTime(),[])});
  }
  lightSyncCompleted(doc,previous){
    const record=this.completedSyncs.get(doc),token=doc.object,state=this.states.get(token);
    // A real updateToken sync must have completed after this command began.
    // Compare the same live identities used by native-frame borrowing, rather
    // than relying on a time window or assuming every host emits the hook.
    if(!record||record===previous||record.token!==token||record.state!==state||!current(token))return false;
    const inputs=this.frameInputs(state,runtimeConfiguration(),serverTime(),record.compare??=[]);
    return inputs.length===record.inputs.length&&inputs.every((value,index)=>value===record.inputs[index]);
  }

  create(token,textures,data) {
    const source=token.mesh;
    if (!source) throw new Error('This token has no drawable mesh yet. Try toggling again.');
    const cfg=qualityConfiguration(runtimeConfiguration(),data),now=serverTime(),snapshot=this.renderState(token.document,data,cfg,now);
    const restoring=!this.entrances.has(token.document);
    const s={token,source,data,opts:snapshot.options,snapshot,snapshotAt:now,
      on:true,blend:0,lift:0,bank:0,pitch:0,kinematics:{},movementEpoch:0};
    try {
      s.renderer=this.makeRenderer(token,textures,e=>this.report(e),this.bits);
      s.unbind=this.bindMotion(source,s);
      if(restoring) {
        // Apply the restored state before the first visible frame. Explicit
        // toggles still enter with their original easing; live timed changes
        // use their sampled progress rather than replaying from zero.
        motion(s,{x:source.x,y:source.y,size:Math.max(token.w,token.h),dt:0,time:(now-snapshot.started)/1000,
          on:snapshot.rendering.wingsActive,reduced:cfg.reduced,forceBlend:snapshot.rendering.blend,
          flightFactor:snapshot.rendering.flightFactor,flightActive:snapshot.rendering.flightActive,profile:snapshot.flightProfile,movementEpoch:s.kinematics.epoch,allowHover:cfg.hover,
          allowBank:cfg.banking,allowPitch:cfg.pitching,transitions:cfg.transitions});
        if(runtimeVisible(s,cfg))s.renderer.update(s,snapshot,cfg,now);
        else {s.dormant=true;s.renderer.suspend?.();}
      }
      this.states.set(token,s); this.entrances.delete(token.document);
      this.startTicker(); canvas.primary.sortDirty=true; canvas.primary.renderDirty=true;
    } catch (error) { s.unbind?.(); s.renderer?.destroy(); throw error; }
  }

  startTicker() {
    if (this.ticker) return;
    this.ticker=canvas.app.ticker; this.lastTick=performance.now();
    this.ticker.add(this.tick,this,-10);
  }

  stopTicker() { this.ticker?.remove(this.tick,this); this.ticker=null; }

  tick() {
    if (!canvas.ready) return;
    const baseCfg=runtimeConfiguration();
    if (!baseCfg.enabled) { this.clear(); return; }
    const now=performance.now(), dt=(now-this.lastTick)/1000; this.lastTick=now;
    const synced=serverTime();let renderChanged=false;const previews=[];
    for (const [token,s] of this.states) {
      const cfg=qualityConfiguration(baseCfg,s.data);
      try {
        if (!current(token)||!token.mesh) { this.remove(token); continue; }
        if(token.isPreview){
          const owner=this.previewSource(token);
          if(owner){
            if(!s.renderer.sharedPreview)this.createSharedPreview(token,owner,{draw:false});
            previews.push(token);continue;
          }
          if(s.renderer.sharedPreview){this.remove(token);void this.sync(token);continue;}
        }
        if (token.mesh!==s.source) {
          s.unbind?.(); s.source=token.mesh; s.unbind=this.bindMotion(s.source,s);
          s.lastX=undefined; s.lastY=undefined;
          s.movementEpoch++;
        }
        // An animated climb/descent is continuous movement; only a jump of more
        // than two grid units starts a new epoch (trail break, motion reset).
        const elevation=s.source.elevation;
        if(s.trailElevation!==elevation){
          if(!Number.isFinite(s.trailElevation)||!Number.isFinite(elevation)||Math.abs(elevation-s.trailElevation)>2*(canvas.scene?.grid?.distance??canvas.dimensions?.distance??5))s.movementEpoch++;
          s.trailElevation=elevation;
        }
        const shown=runtimeVisible(s,cfg);
        if(!shown){
          if(!s.dormant){
            s.dormant=true;s.frozenInputs=null;s.movementEpoch++;s.feelFxRenderer?.hide();s.feelFx?.clear();
            trackMovement(s.kinematics,{x:s.source.x,y:s.source.y,size:canvas.grid?.size??Math.max(token.w,token.h),dt:0,
              shown:false,epoch:s.movementEpoch,relaxation:cfg.movementRelaxation});
            s.renderer.suspend?.();renderChanged=true;
          }
          // A background tab has no pixels to maintain. All deadlines remain
          // server-clock values, so resuming never replays a hidden interval.
          if(globalThis.document?.hidden===true||!dormantSampleDue(s,synced,cfg))continue;
          const snapshot=this.renderState(token.document,s.data,cfg,synced);
          s.snapshot=snapshot;s.snapshotAt=synced;s.opts=snapshot.options;s.on=snapshot.rendering.active;
          this.rememberFrame(s,baseCfg,synced);
          s.dormantSampleAt=synced;s.dormantData=s.data;s.dormantConfig=cfg;
          if(!s.on)this.remove(token);
          continue;
        }
        const resumed=!!s.dormant;
        if(resumed){s.dormant=false;s.movementEpoch++;s.lastX=undefined;s.lastY=undefined;s.manoeuvreReset=true;}
        if(frozenFrameUnchanged(s,cfg,synced))continue;
        trackMovement(s.kinematics,{x:s.source.x,y:s.source.y,size:canvas.grid?.size??Math.max(token.w,token.h),dt,
          shown:isShown(token,s.source),epoch:s.movementEpoch,relaxation:cfg.movementRelaxation});
        sampleTokenManoeuvre(s,token,cfg,dt);
        const stateStarted=localPerformance.active?localPerformance.beginStage():null;
        const snapshot=this.renderState(token.document,s.data,cfg,synced);
        if(stateStarted!==null)localPerformance.endStage('state',stateStarted);
        s.snapshot=snapshot;s.snapshotAt=synced;
        s.opts=snapshot.options; s.on=snapshot.rendering.active;
        const size=Math.max(token.w,token.h);
        motion(s,{x:s.source.x,y:s.source.y,size,dt,time:(synced-snapshot.started)/1000,
          on:snapshot.rendering.wingsActive,reduced:cfg.reduced,forceBlend:resumed?snapshot.rendering.blend:snapshot.rendering.forceBlend,
          flightFactor:snapshot.rendering.flightFactor,flightActive:snapshot.rendering.flightActive,profile:snapshot.flightProfile,movementEpoch:s.kinematics.epoch,allowHover:cfg.hover,
          allowBank:cfg.banking,allowPitch:cfg.pitching,transitions:cfg.transitions});
        // Flight feel keeps her until a landing descent has finished.
        if (!s.on && s.blend<0.002 && !(s.feelState&&!s.feelState.sleeping&&(s.feelState.alt>.05||s.feelState.air>.02||s.feelFx?.active||Math.abs(s.feelState.squash)>.002||Math.abs(s.feelState.squashV)>.02||Math.abs(s.feelState.kick)>.002||Math.abs(s.feelState.dip)>.002||Math.abs(s.feelState.lean)>.002))) { this.remove(token); continue; }
        // Flight feel (beta.23): weight, momentum, height, effects and wingbeat sounds.
        let feelOn=false;
        try{feelOn=runFlightFeel(s,token,snapshot,{size,dt,now:synced,cfg,audio:this.audio});}catch(error){this.report(error);}
        const renderStarted=localPerformance.active?localPerformance.beginStage():null;
        try{s.renderer.update(s,snapshot,cfg,synced);this.rememberFrame(s,baseCfg,synced);renderChanged=true;}
        finally{if(renderStarted!==null)localPerformance.endStage('render',renderStarted);}
        // Her elevation tooltip, nameplate, bars and status icons follow her visible body (beta.32).
        try{placeOverlays(token,bodyOffset(s,token));}catch(error){this.report(error);}
        if(feelOn){
          try{
            if(s.feelFx?.active)(s.feelFxRenderer??=new FlightFxRenderer(token)).update(s,s.source,cfg,synced);else s.feelFxRenderer?.hide();
          }catch(error){s.feelFxRenderer?.destroy();s.feelFxRenderer=null;this.report(error);}
        }else s.feelFxRenderer?.hide();
      } catch (error) { this.remove(token); this.report(error); }
    }
    // Finish every real renderer first. A source can be recreated after its
    // ghost in Map order; painting may replace/destroy its old texture. Copying
    // only now guarantees that the ghost receives the completed current frame.
    for(const token of previews){
      const owner=this.previewSource(token),state=this.states.get(token);
      if(!state)continue;
      try{
        if(!current(token)||!token.mesh){this.remove(token);continue;}
        if(!owner){this.remove(token);void this.sync(token);continue;}
        this.updateSharedPreview(state,owner,qualityConfiguration(baseCfg,owner.data),synced);renderChanged=true;
      }catch(error){this.remove(token);this.report(error);}
    }
    if(renderChanged)canvas.primary.renderDirty=true;
    // (v11) her flight moves her token layer (bank, pitch, wing light): wake it for this frame's tokens
    try{tokenLayers.flightTick(this.states);}catch{}
    if(!this.states.size)this.stopTicker();
  }

  remove(token) {
    clearWorkingPosture(token);
    if(this.completedSyncs.get(token.document)?.token===token)this.completedSyncs.delete(token.document);
    this.workingTokens.delete(token);
    this.pending.delete(token);
    const s=this.states.get(token); if (!s) return;
    this.states.delete(token); s.unbind?.(); s.renderer.destroy(); s.feelFxRenderer?.destroy();
    try{restoreOverlays(token);}catch{}
    if (!token.destroyed) token.renderFlags?.set({refreshMesh:true});
    if (!this.states.size) this.stopTicker();
    if (canvas.primary) canvas.primary.renderDirty=true;
  }

  clear() {
    this.parkedLights?.clear();
    cancelCompactFlowPreparation();
    this.epoch++; this.pending.clear();
    this.stateSamples=new WeakMap();
    this.completedSyncs=new WeakMap();
    this.workingTokens=new WeakSet();
    for (const token of [...this.states.keys()]) this.remove(token);
    this.stopTicker();
  }

  rebuild() {
    const previews=[...this.states.keys(),...this.pending.keys()].filter(token=>token.isPreview);
    bitAssets.retry();
    this.clear();
    if (!canvas.ready) return;
    this.audio?.rebuild();this.treatmentAudio?.rebuild();
    this.lights.rebuild({retry:true});
    this.lantern.rebuild({retry:true});
    this.bits?.rebuild();
    const draws=(canvas.tokens?.placeables??[]).map(token=>this.sync(token));
    if(previews.length)void Promise.allSettled(draws).then(()=>{for(const token of previews)if(current(token))void this.sync(token);});
  }

  async refreshToken(doc) {
    bitAssets.retry();
    if(doc.parent.id===canvas.scene?.id){this.lights.sync(doc.object,{force:true,retry:true});this.lantern.sync(doc.object,{retry:true});}
    const previews=[];
    for (const token of [...this.states.keys(),...this.pending.keys()]) if (token.document.uuid===doc.uuid){if(token.isPreview)previews.push(token);this.remove(token);}
    if (doc.parent.id===canvas.scene?.id){await this.sync(doc.object);await Promise.all(previews.filter(current).map(token=>this.sync(token)));}
  }

  settingsChanged(key) {
    invalidateConfiguration();
    if(key?.startsWith('v8')){Hooks.callAll('filamentFlightSettingsChanged');return;}
    // (beta.40) Keep playing is read by the Keepsake windows' loop holding only
    if(key?.startsWith('keepPlaying')){Hooks.callAll('filamentFlightSettingsChanged');return;}
    // (v11) the v11 switches are read where they are used (v11/features.mjs caches them until this hook)
    if(key==='v11Client'||key==='v11World'){Hooks.callAll('filamentFlightSettingsChanged');return;}
    // These two v9 switches alter only sampled artwork. Existing render and
    // worker inputs include their refreshed snapshot values; audio, native
    // illumination, reactions and ownership have no dependency on them.
    if(['v9SignatureCraft','v9MedicalCraft'].includes(key)){Hooks.callAll('filamentFlightSettingsChanged');return;}
    // V7 preferences are sampled from the refreshed configuration on the next
    // render/lighting tick. They do not change native source geometry, actor
    // reactions, allocations or renderer ownership. Frame caches compare the
    // configuration identity, so old samples cannot survive this invalidation.
    if(key?.startsWith('v7')){
      if(key==='v7Enabled'||key==='v7Medkit')this.treatmentAudio?.settingsChanged();
      Hooks.callAll('filamentFlightSettingsChanged');return;
    }
    // Bit quality is sampled by the active renderers on their next capped
    // frame. A local texture preference never needs a light/HP/flight rebuild.
    if(['bitQuality','rigQuality','rigFPS','poseFPS','renderWorker','localQuality','localTrails','flightManoeuvres','wingFollowThrough','effectLibrary','formationLibrary','bitSendOutStyle'].includes(key)){Hooks.callAll('filamentFlightSettingsChanged');return;}
    this.audio?.settingsChanged();this.treatmentAudio?.settingsChanged();
    // Audio settings never require texture, lighting or reaction rebuilds.
    if(key?.startsWith('audio')){Hooks.callAll('filamentFlightSettingsChanged');return;}
    this.reactions?.configure();
    if (!canvas.ready) return;
    this.lights.rebuild({retry:true});
    this.lantern.rebuild({retry:true});
    if (!configuration().enabled) this.clear();
    else for (const token of canvas.tokens?.placeables??[]) void this.sync(token);
    Hooks.callAll('filamentFlightSettingsChanged');
  }
}

export const manager=new FlightManager();
// beta.34: warps read where her flying body is drawn (lift, sway, height scale, bank)
setBodyPoseSource(token=>manager.states.get(token));
// (v11) her token's portrait and frame (v11/token-layer-runtime.mjs)
export const tokenLayers=new TokenLayers({getState:token=>manager.states.get(token),enabled:()=>runtimeConfiguration().enabled,reduced:()=>runtimeConfiguration().reduced,current});
tokenLayers.install();
// (v11) wounds, persistent damage, dying stages, low-HP fatigue and mood weather (v11/damage-runtime.mjs)
damageRuntime.install({tokenLayers});
// (v11 phase 3a) healing and the bits' jobs (v11/heal-runtime.mjs)
healRuntime.install({getState:token=>manager.states.get(token),tokenLayers,pinned:()=>pinnedCharacter()});
// (v11) her wings and the world: wall fold, light catch, wing shadow on tokens, flying in formation (v11/world-runtime.mjs)
worldRuntime.install({getState:token=>manager.states.get(token)});
// (v11) invisibility: the classic drain and the tech cloak (v11/invis-runtime.mjs)
export const invisibility=new InvisRuntime({manager,tokenLayers,now:serverTime,reduced:()=>runtimeConfiguration().reduced,current});
invisibility.install();
// (v11) emotes: the saved emote on her token, played on every client (v11/emote-runtime.mjs)
emoteRuntime.install({tokenLayers,reduced:()=>runtimeConfiguration().reduced,emote:(id,o)=>game.modules.get(ID).api?.v11?.emote?.(id,o),
  partOn:doc=>v11IsOn('emotes',doc)&&v11PartOn('emotes','emoteChat',doc)});
// (v11 experimental extras, phase 3d) her journal (Tapestry, petals, recap) and the recap card's chat side:
// each holds no hooks or timers until its switch is on
export const journal=new JournalRuntime({airborne:token=>{const t=token?.getActiveTokens?.()?.[0]??token;const s=t&&manager.states.get(t);return (s?.feelState?.air??0)>.3;}}).install();
const recapChat=new RecapChat().install();
// (11.0.0-test.4) the self-check's V11 part reads these runtimes (and only reads, or plays its synthetic moments through their own entry points)
manager.v11=Object.freeze({tokenLayers,invisibility,journal,recapChat,damage:damageRuntime,heal:healRuntime,world:worldRuntime,emote:emoteRuntime});
export const service=new FlightAPI(manager);
export const reactions=new Reactions(service,manager);
// (12.0.0-beta.6) the Decoy: a copy of her standing at a spot, drawn on every client from one synced flag (v12/decoy-runtime.mjs)
export const decoy=new DecoyRuntime({manager,now:serverTime,bits:()=>service.bits,warp:(token,point,options)=>warpTo(token,point,options),warpLeave:(token,point,options)=>warpLeaveMs(token,point,options)});
decoy.install();
// (12.0.0-beta.13) menus on the map under her decoy and her bits' jobs, while a key is held (v12/field-menus.mjs)
export const fieldMenus=new FieldMenus().install();
manager.v12=Object.freeze({decoy,fieldMenus});
// (13.0.0-beta.1) The Heart Turned: a curse the GM lays on her from a wheel round the pointer; she and the GM alone see it (v13/curse-runtime.mjs)
export const curse=new CurseRuntime({pinned:()=>pinnedCharacter()}).install();
manager.v13=Object.freeze({curse});
// (13.0.0-beta.2) …and her Keepsake sheet shows it among the conditions on her
HEAD_EXTRAS.add((actor,doc)=>curse.sheetChip(actor,doc));
manager.reactions=reactions;
// (beta.35) The Keepsake's endless loops hold still while one of our tokens is still travelling (decor-hold.mjs).
addDecorProbe(()=>{for(const s of manager.states.values())if((s.kinematics?.speed??0)>.05)return true;return false;});
manager.audio=new WingAudio(manager,{configuration:runtimeConfiguration,now:serverTime,getState:token=>manager.sampleState(token)});
setCueSink(manager.audio);
manager.treatmentAudio=new BitActionAudio(manager,{configuration:runtimeConfiguration,now:serverTime});
// v10: attention is shared live over the module socket unless the world asks
// for the 9.x behaviour of saving it on the token.
const attentionLive=()=>{try{return game.settings.get(ID,'attentionSync')!=='flag';}catch{return true;}};
manager.intentTargets=new BitIntentTargets({publish:(doc,value)=>{
  if(!attentionLive())return service.enqueue(doc,()=>doc.setFlag(ID,'intentTarget',value));
  setLiveIntent(doc.uuid,value);{const state=doc.object&&manager.states.get(doc.object);if(state){state.renderRevision=(state.renderRevision??0)+1;state.frozenInputs=null;}}game.socket?.emit(`module.${ID}`,{type:'intent',uuid:doc.uuid,value});
  if(doc.getFlag(ID,'intentTarget'))void service.enqueue(doc,()=>doc.unsetFlag(ID,'intentTarget'));
  return Promise.resolve();
}});

Hooks.once('init',()=>{
  registerSettings(key=>manager.settingsChanged(key));
  const v10=registerV10Features(manager,()=>game.modules.get(ID).api,()=>service.hudController());
  const tl=tokenLayers,emotes=installV11Emotes({getAPI:()=>game.modules.get(ID).api,tokenLayers:tl,pinned:pinnedCharacter}),v11=Object.freeze({
    // (phase 2c) the emote entry point the quick wheel's Emotes ring calls (v11/emotes.mjs)
    emote:(...a)=>emotes.emote(...a),emotes:Object.freeze({list:emotes.list,comfortSide:emotes.comfortSide,
      playing:t=>{const r=emoteRuntime.recOf(t?.object??t);return r?{id:r.flag.id,variant:r.flag.variant,tau:+r.tau.toFixed(3),side:r.flag.side,ending:r.end?.reason??null}:null;},
      stats:()=>({...emoteRuntime.stats,active:emoteRuntime.active.size})}),
    features:Object.freeze({isOn:v11IsOn,partOn:v11PartOn,choice:v11Choice,resolve:resolveV11}),
    tokenLayer:Object.freeze({hit:(t,o)=>tl.hit(t,o),heal:(t,o)=>tl.heal(t,o),give:(t,o)=>tl.give(t,o),emote:(t,n,l)=>tl.emote(t,n,l),hidden:(t,on)=>tl.hidden(t,on),cloak:(t,on,o)=>tl.cloak(t,on,o),light:(t,o)=>tl.light(t,o),
      sync:t=>t?tl.sync(t):tl.syncAll(),stats:()=>({...tl.stats,layers:tl.layers.size,ticking:tl.ticking})}),
    // (test.9) her token's shape profile: her art's measured shape, edge and border, and how she is drawn (v11/token-shape.mjs)
    tokenShape:(t=pinnedCharacter())=>{const token=t?.object??t,L=tl.layerOf?.(token);return tokenShape(token,L?.fit??null,manager.states?.get?.(token)??null);},
    // the manual Fade (the quick wheel): fade(on, {token}) → Promise<boolean>; fade(on) or fade(token, on) too; on left out toggles
    fade:(a,b)=>invisibility.fade(a,b),faded:t=>invisibility.faded(t),
    heal:Object.freeze({stats:()=>({...healRuntime.stats,records:healRuntime.records.size,ticking:healRuntime.ticking})}),
    invisibility:Object.freeze({fade:(a,b)=>invisibility.fade(a,b),faded:t=>invisibility.faded(t),cloak:(t,on,o)=>invisibility.cloak(t,on,o),status:t=>invisibility.status(t),
      stats:()=>({...invisibility.stats,records:invisibility.records.size,ticking:invisibility.ticking})}),
    // (phase 3d) the experimental extras: her journal and the recap card
    journal:Object.freeze({read:(actor=journalActor())=>readActorJournal(actor),recap:(actor=journalActor(),n=null)=>recapFor(actor,n),pin:(id,actor=journalActor())=>pinPetal(actor,id),
      newSession:(actor=journalActor())=>newSession(actor),stats:()=>({...journal.stats,active:journal.active,recording:journal.actor?.name??null})}),
    recap:Object.freeze({post:(actor=journalActor(),n=null)=>postRecap(actor,{n,recapFor,pinned:readActorJournal(actor).pinned}),
      image:(actor=journalActor(),n=null)=>{const r=recapFor(actor,n);if(!r)throw new Error('Nothing is woven yet.');return saveShareImage({...r,sessionName:r.name,name:actor?.name,pinned:readActorJournal(actor).pinned});}})});
  // (12.0.0-beta.6) the Decoy: place(token, {kind:'warp'|'cast', point, look}) · setLook(token, look?) · dismiss(token, {why}) · strike(token) · active(token) · status(token)
  // choose(token, kind): let her owner click the spot (the warp's own picker), then place it there
  const decoyAPI=Object.freeze({place:(t,o)=>decoy.place(t,o),setLook:(t,l)=>decoy.setLook(t,l),dismiss:(t,o)=>decoy.dismiss(t,o),strike:t=>decoy.dismiss(t,{why:'blow'}),active:t=>decoy.active(t),status:t=>decoy.status(t),
    choose:(t,kind='cast',o={})=>{const token=t?.object??t;return chooseWarp(token,{style:'wings',label:kind==='warp'?'Decoy warp':'Cast a decoy',onPick:point=>decoy.place(token,{...o,kind,point}).catch(e=>ui.notifications?.warn(`Decoy: ${e?.message??e}`))});},
    stats:()=>({...decoy.stats,decoys:decoy.records.size,ticking:decoy.ticking})});
  // (12.0.0-beta.13) fieldMenus.show(on) · shown() · list(): the menus on the map (held key: Alt, or the module's own)
  const fieldMenusAPI=Object.freeze({show:(on=true)=>fieldMenus.show(on),shown:()=>fieldMenus.shown(),list:()=>fieldMenus.collect(),act:(key,act)=>fieldMenus.act(key,act),stats:()=>({...fieldMenus.stats})});
  // (13.0.0-beta.1) curse.open() (the GM's wheel) · lay(state, {toward, die}) · ask({toward, die}) · lift() · burn() · state() · status()
  // (13.0.0-beta.2) curse.edit() (the states' editor) · watch(on) · errors() · show()
  game.modules.get(ID).api=Object.freeze({...service.publicAPI(),...v10,v11,decoy:decoyAPI,fieldMenus:fieldMenusAPI,curse:curse.api()});
  manager.lantern.api=game.modules.get(ID).api;
  registerLanternControls(manager,manager.lantern.api);
  registerV8Controls(manager);
  registerFieldMenuKey(fieldMenus);
  curse.register();
});
Hooks.once('setup',()=>{void manager.preload();});
Hooks.on('canvasInit',()=>{void manager.preload();});
// Both public visibility hooks invalidate exact historical trail-point tests.
for(const hook of ['sightRefresh','visibilityRefresh','initializeVisionSources','canvasTearDown'])Hooks.on(hook,()=>{invalidateTrailVisibility();invalidateScanWallVisibility();});
// Foundry re-places a token's tooltip, nameplate and bars when it refreshes them:
// put her overlays back on her visible body straight away (beta.32).
Hooks.on('refreshToken',token=>{const s=manager.states.get(token);if(s)try{placeOverlays(token,bodyOffset(s,token));}catch{}});
// Geometry/door edits invalidate compiled work, while ordinary sight refresh
// during token movement leaves its checked physical routes cached.
for(const hook of ['createWall','updateWall','deleteWall'])Hooks.on(hook,document=>invalidateScanWalls(document));
for(const hook of ['canvasReady','canvasTearDown'])Hooks.on(hook,()=>invalidateScanWalls());
/** beta.7: warp and routine messages only play for a token the sender owns.
 * Foundry passes the sender's user id with every module message; a remote
 * warp never moves anything (only the owner's own client moves the token). */
function effectMessage(message,senderId,points=true){
  const doc=(()=>{try{return fromUuidSync(message.uuid);}catch{return null;}})();
  if(!doc||doc.documentName!=='Token'||doc.parent?.id!==canvas?.scene?.id)return null;
  const sender=senderId==null?null:game.users?.get?.(senderId);
  if(senderId!=null&&(!sender||!(sender.isGM||doc.testUserPermission?.(sender,'OWNER'))))return null;
  const pt=p=>Number.isFinite(p?.x)&&Number.isFinite(p?.y)?{x:+p.x,y:+p.y}:null;
  const out={uuid:doc.uuid,start:Number.isFinite(+message.start)?+message.start:Date.now()};
  if(points){out.from=pt(message.from);out.to=pt(message.to);if(!out.from||!out.to)return null;}
  return out;
}
Hooks.once('ready',()=>{installMedkitRelay();installTreatWoundsGuard();installFlightFeelHooks();game.socket?.on(`module.${ID}`,(message,senderId)=>{if(message?.type==='warp'&&typeof message.uuid==='string'){const m=effectMessage(message,senderId);if(m)playWarp({uuid:m.uuid,from:m.from,to:m.to,style:message.style==='bare'?'bare':'wings',look:message.look,start:m.start,move:false});return;}if(message?.type==='routine'&&typeof message.uuid==='string'&&typeof message.id==='string'){const m=effectMessage(message,senderId,false);if(m)playRoutine({id:message.id,uuid:m.uuid,opts:message.opts&&typeof message.opts==='object'?message.opts:{},start:m.start});return;}if(message?.type==='intent'&&typeof message.uuid==='string'){setLiveIntent(message.uuid,message.value);const doc=fromUuidSync(message.uuid);const state=doc?.object&&manager.states.get(doc.object);if(state){state.renderRevision=(state.renderRevision??0)+1;state.frozenInputs=null;}}});reactions.seed();manager.settingsChanged();manager.intentTargets.start();manager.lantern.start();
  // (10.0.1) a self-check cut off by a reload while it had the Toolbox’s visuals off here: put them back
  void recoverInterruptedCheck().catch(()=>{});});
Hooks.on('canvasReady',()=>{reactions.seed();manager.intentTargets.start();});
Hooks.on('preUpdateActor',actor=>reactions.seedActor(actor));
Hooks.on('updateActor',(actor,changes,options,userId)=>reactions.observe(actor,changes,options,userId));
Hooks.on('updateActorDelta',(delta,changes,options,userId)=>{reactions.indexToken(delta.parent);reactions.observe(delta.parent?.actor,changes,options,userId);});
Hooks.on('createToken',doc=>{reactions.indexToken(doc);reactions.seedActor(doc.actor);});
Hooks.on('createScene',scene=>reactions.tokens.addScene(scene));
Hooks.on('deleteScene',scene=>reactions.tokens.removeScene(scene));
for(const hook of ['preCreateItem','preUpdateItem','preDeleteItem','preCreateActiveEffect','preUpdateActiveEffect','preDeleteActiveEffect'])Hooks.on(hook,document=>reactions.seedActor(document.parent));
for(const hook of ['createItem','updateItem','deleteItem','createActiveEffect','updateActiveEffect','deleteActiveEffect']) {
  Hooks.on(hook,(document,...args)=>reactions.observe(document.parent,{},args.at(-2)??{},args.at(-1)));
}
Hooks.on('deleteActor',actor=>{reactions.health.delete(actor.uuid);reactions.latest.delete(actor.uuid);reactions.responses.removeActor(actor);});
Hooks.on('canvasReady',()=>manager.rebuild());
Hooks.on('initializeLightSources',()=>{manager.lights.rebuild({initializing:true,notify:false});manager.lantern.rebuild({initializing:true,notify:false});for(const token of canvas.tokens?.placeables??[])manager.parkedLights.sync(token,{initializing:true,notify:false});});
Hooks.on('canvasTearDown',()=>{clearLiveIntent();localPerformance.stop();manager.intentTargets.stop();manager.lantern.clear();manager.bits.clear();manager.audio.clear();manager.treatmentAudio.clear();manager.lights.clear();manager.clear();});
Hooks.on('drawToken',token=>{void manager.sync(token);if(!token.isPreview)manager.bits.observe(token.document);});
/** beta.32: a jump that Foundry's movement API made (a warp's "displace") counts as a teleport too. */
const displaced=(doc,options)=>{for(const key of ['movement','_movement']){const m=options?.[key]?.[doc?.id];const w=m?.waypoints??m?.passed?.waypoints;if(Array.isArray(w)&&w.some(p=>p?.action==='displace'))return true;}return false;};
Hooks.on('updateToken',(doc,changes={},options={})=>{
  if(!options.filamentWarp&&displaced(doc,options))options={...options,animate:false,filamentWarp:true};
  // (v11) a saved emote alone: the emote runtime's own hook plays it (no resync, no state change)
  if(onlyEmoteChanges(changes))return;
  const existing=doc.parent?.id===canvas.scene?.id?manager.states.get(doc.object):null;
  // Flight feel settings, shield and recorded ground redraw even a frozen frame.
  const feelFlags=changes?.flags?.[ID];
  if(existing&&feelFlags&&['flightFeel','wingShield','flightGround','-=flightGround','-=wingShield','-=flightFeel','v11','-=v11'].some(k=>Object.hasOwn(feelFlags,k))){existing.renderRevision=(existing.renderRevision??0)+1;existing.frozenInputs=null;}
  if(existing&&onlyMovementChanges(changes)){
    // The live ticker follows Foundry's animated portrait. A position/facing
    // packet changes neither actor membership nor saved flight commands.
    manager.observeUpdate(doc,changes,true);
    const moving=['x','y','elevation'].some(k=>Object.hasOwn(changes,k))||Object.hasOwn(changes,'_movement');
    // An elevation edit alone is ordinary movement; the ticker breaks the epoch on a real jump.
    if(moving&&(options.animate===false||options.teleport===true)){existing.movementEpoch++;existing.renderer.resetTrails?.();}
    if(options.animate===false||options.teleport===true||options.filamentWarp)existing.manoeuvreReset=true;
    return;
  }
  reactions.indexToken(doc);
  const bitsChanged=bitFlagsChanged(changes);
  if(bitsChanged){
    const state=manager.states.get(doc.object);if(state){state.frozenInputs=null;state.dormantSampleAt=-Infinity;}
    manager.stateSamples.delete(doc);manager.bits.invalidateState(doc);
    manager.bits.observe(doc);manager.treatmentAudio.sync(doc.object);
  }
  if(onlyAudioChanges(changes)){
    if(doc.parent?.id===canvas.scene?.id){manager.audio.sync(doc.object);manager.treatmentAudio.sync(doc.object);}
    Hooks.callAll('filamentFlightAudioChanged',doc);
    return;
  }
  manager.observeUpdate(doc,changes);
  const moving=['x','y','elevation'].some(k=>Object.hasOwn(changes,k))||Object.hasOwn(changes,'_movement');
  if(moving&&(options.animate===false||options.teleport===true)) {
    const s=manager.states.get(doc.object);if(s){s.movementEpoch++;s.renderer.resetTrails?.();if(options.animate===false||options.teleport===true||options.filamentWarp)s.manoeuvreReset=true;}
  }
  if(doc.parent?.id===canvas.scene?.id&&manager.states.has(doc.object)&&onlyMovementChanges(changes))return;
  if (doc.parent?.id===canvas.scene?.id) {
    void manager.sync(doc.object);
    for (const token of manager.states.keys()) if (token.document.id===doc.id&&token!==doc.object) void manager.sync(token);
  }
  if (bitsChanged||changes.flags?.[ID] || Object.keys(changes).some(k=>k===`flags.${ID}`||k.startsWith(`flags.${ID}.`))) {
    try { Hooks.callAll('filamentFlightStateChanged',doc,service.getState(doc)); }
    catch(error) { manager.report(error); }
  }
});
Hooks.on('destroyToken',token=>{manager.bits.removeToken(token);manager.audio.remove(token);manager.treatmentAudio.remove(token);manager.lights.remove(token);manager.lantern.remove(token);manager.parkedLights.remove(token);manager.remove(token);});
Hooks.on('deleteToken',doc=>{
  releaseScanWallSource(doc);
  manager.parkedLights.remove(doc.object);
  manager.bits.deleteToken(doc);
  manager.audio.remove(doc.object);manager.treatmentAudio.remove(doc.object);
  for(const token of manager.lights.records.keys())if(token.document===doc)manager.lights.remove(token);
  for(const token of manager.lantern.records.keys())if(token.document===doc)manager.lantern.remove(token);
  reactions.removeToken(doc);
  for (const token of [...manager.states.keys(),...manager.pending.keys()])
    if (token.document.id===doc.id&&token.document.parent?.id===doc.parent?.id) manager.remove(token);
});
