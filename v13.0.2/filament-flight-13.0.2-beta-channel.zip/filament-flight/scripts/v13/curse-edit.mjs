/** Yvaelle’s Toolbox v13 · The Heart Turned: the states' editor (13.0.0-beta.2). The GM's only.
 *
 * Six rows, one for each state in the table's order. In each the GM may change its name, the word after "You are made
 * to", and what it says. A field left empty goes back to the table's own; Reset does the same for a whole row, "Reset
 * all to the table" for all six. The six themselves, their order (the d6) and their colours stay: her six filaments are
 * those six.
 *
 * Saved, the edits are kept for the world and show everywhere at once: on the wheel, in her view, on the card and the
 * mark, in the chat line, on a curse already laid too. Nothing is saved until Save is pressed; Cancel and Escape drop
 * what was typed.
 *
 * Opened from the bar under the wheel (Edit the states) or api.curse.edit(). Nothing exists while it is closed.
 *   host.edits() → the world's edits now ({key: {n, w, d}})      host.save(edits) → Promise of true when kept */
import {CURSE_STATES,STATE_LIMITS,stateEdits,CURSE_TITLE} from './curse-model.mjs?v=13.0.2';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export class CurseEditor{
  constructor({host,doc=globalThis.document,win=globalThis.window}={}){this.host=host;this.doc=doc;this.win=win;this.root=null;this.listeners=null;this.stats={opened:0,saved:0};}
  get open(){return !!this.root;}
  toggle(){if(this.root){this.close();return false;}this.show();return true;}
  show(){
    if(this.root)return;const d=this.doc;this.stats.opened++;let now={};try{now=stateEdits(this.host.edits?.()??{});}catch{}
    const root=d.createElement('div');root.className='ff-cu-edit';root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-label',`${CURSE_TITLE}: the six states`);
    const row=(e,i)=>{const v=now[e.k]??{};return `<div class="ff-cu-row" data-k="${e.k}" style="--ffcu-ac:rgb(${e.acc})"><div class="ff-cu-num">${i+1}</div>`
      +`<div class="ff-cu-line"><input type="text" class="ff-cu-in-n" data-f="n" maxlength="${STATE_LIMITS.n}" value="${esc(v.n??e.n)}" placeholder="${esc(e.n)}" aria-label="State ${i+1}: its name" spellcheck="false" autocomplete="off">`
      +`<span class="ff-cu-made">made to</span><input type="text" class="ff-cu-in-w" data-f="w" maxlength="${STATE_LIMITS.w}" value="${esc(v.w??e.w)}" placeholder="${esc(e.w)}" aria-label="State ${i+1}: the word after “You are made to”" spellcheck="false" autocomplete="off">`
      +`<button type="button" class="ff-cu-back" data-act="back" title="This state as the table has it">Reset</button></div>`
      +`<textarea class="ff-cu-in-d" data-f="d" rows="2" maxlength="${STATE_LIMITS.d}" placeholder="${esc(e.d)}" aria-label="State ${i+1}: what it says">${esc(v.d??e.d)}</textarea></div>`;};
    root.innerHTML=`<div class="ff-cu-pane"><div class="ff-cu-eh"><div class="ff-cu-k">${esc(CURSE_TITLE)}</div><div class="ff-cu-t">The six states</div>`
      +'<div class="ff-cu-hint">Each one’s name, the word after “You are made to”, and what it says. Their order and colours stay: her six filaments are these six.</div></div>'
      +`<div class="ff-cu-rows">${CURSE_STATES.map(row).join('')}</div>`
      +'<div class="ff-cu-ef"><button type="button" data-act="all" title="All six as the table has them">Reset all to the table</button><span class="ff-cu-sp">Shown everywhere at once, on a curse already laid too.</span><button type="button" data-act="cancel">Cancel</button><button type="button" class="ff-cu-save" data-act="save">Save</button></div></div>';
    d.body.appendChild(root);this.root=root;
    const mark=()=>{for(const r of root.querySelectorAll('.ff-cu-row')){const e=CURSE_STATES.find(s=>s.k===r.dataset.k);let ch=false;for(const f of r.querySelectorAll('[data-f]')){const v=f.value.replace(/\s+/g,' ').trim();if(v&&v!==e[f.dataset.f])ch=true;}r.classList.toggle('ff-cu-changed',ch);}};
    const grow=t=>{t.style.height='auto';t.style.height=Math.max(42,t.scrollHeight+2)+'px';};
    for(const t of root.querySelectorAll('textarea'))grow(t);mark();
    root.addEventListener('input',ev=>{if(ev.target.matches?.('textarea'))grow(ev.target);mark();});
    root.addEventListener('click',ev=>{const b=ev.target.closest?.('button');if(!b)return;ev.preventDefault();const act=b.dataset.act;
      if(act==='cancel')this.close();else if(act==='save')void this.save();
      else if(act==='back'||act==='all'){for(const r of act==='all'?root.querySelectorAll('.ff-cu-row'):[b.closest('.ff-cu-row')]){const e=CURSE_STATES.find(s=>s.k===r.dataset.k);for(const f of r.querySelectorAll('[data-f]')){f.value=e[f.dataset.f];if(f.matches('textarea'))grow(f);}}mark();}});
    // what is typed here is not Foundry's to act on; Escape drops it
    const quiet=ev=>ev.stopPropagation();root.addEventListener('keydown',quiet);root.addEventListener('keyup',quiet);root.addEventListener('keypress',quiet);
    root.addEventListener('pointerdown',quiet);root.addEventListener('contextmenu',ev=>{if(!ev.target.matches?.('input,textarea'))ev.preventDefault();ev.stopPropagation();});root.addEventListener('wheel',quiet,{passive:true});
    const key=ev=>{if(ev.key!=='Escape')return;ev.preventDefault();ev.stopPropagation();ev.stopImmediatePropagation?.();this.close();};
    this.win.addEventListener('keydown',key,true);this.listeners=()=>this.win.removeEventListener('keydown',key,true);
    void root.offsetWidth;root.classList.add('ff-cu-on');try{root.querySelector('input')?.focus({preventScroll:true});}catch{}
  }
  /** What the fields hold now, as edits ({key: {n, w, d}}; only what differs from the table is kept by the model). */
  read(){
    const out={};if(!this.root)return out;
    for(const r of this.root.querySelectorAll('.ff-cu-row')){const o={};for(const f of r.querySelectorAll('[data-f]'))o[f.dataset.f]=f.value;out[r.dataset.k]=o;}
    return stateEdits(out);
  }
  async save(){
    if(!this.root)return false;const edits=this.read();let ok=false;try{ok=await this.host.save?.(edits);}catch{ok=false;}
    if(ok!==false){this.stats.saved++;this.close();return true;}
    const sp=this.root?.querySelector('.ff-cu-ef .ff-cu-sp');if(sp){sp.textContent='It could not be saved (only the GM can).';sp.style.color='#ff9ab8';}return false;
  }
  close(){const root=this.root;if(!root)return;this.root=null;this.listeners?.();this.listeners=null;root.classList.remove('ff-cu-on');this.win.setTimeout(()=>root.remove(),280);}
}
