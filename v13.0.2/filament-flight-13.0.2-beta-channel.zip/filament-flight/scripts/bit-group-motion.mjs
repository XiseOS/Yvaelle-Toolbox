import {sampleCompactTransition} from './compact-bit-formations.mjs?v=13.0.2';
import {applyCompactExpression} from './bit-expression.mjs?v=13.0.2';
/** One sampler for home previews, remote formations and return destinations.
 * Station identities and captured poses survive count changes and interruptions. */
export function sampleGroupFormation(stations,group={},cfg={},now=0,owner=null,{lanternHome=false}={}){
  const count=Array.isArray(stations)?stations.length:stations;if(!count)return [];
  const ids=Array.isArray(stations)?stations:null,t=group.transition;
  const poses=sampleCompactTransition(count,group.program??cfg.soloProgram,now/1000*(cfg.speed??1),{
    radius:group.radius??cfg.soloRadius,strength:cfg.strength,animated:cfg.animated,v7:cfg.v7??owner?.v7,
    personality:group.effect?.enabled?0:group.personality??cfg.personality,passiveEffects:group.effect?.enabled?false:group.passive!==false,behaviour:group.effect?.enabled?{enabled:false}:group.behaviour??cfg.behaviour,
    flow:group.flow,now,lanternFlight:lanternHome?owner:null,duration:(t?.duration??850)/1000,clockRate:cfg.animated===false?0:cfg.speed??1,fromVelocities:t?.fromVelocities,
    fromProgram:t?.fromProgram,progress:t?.duration>0?(now-t.started)/t.duration:1,
    fromPoses:t?.fromPoses,fromCount:t?.fromCount??count,fromStations:t?.fromStations,toStations:ids});
  // An occupied recipient supplies placement only; reactions remain the
  // instrument owner's state. Active token fields have their own choreography.
  return owner&&!group.effect?.enabled?applyCompactExpression(poses,{...owner,gems:cfg,bitActivity:null,bitSequenceActive:false,bitHardwareAll:false},now/1000*(cfg.speed??1),t?.fromPoses?(now-t.started)/Math.max(1,t.duration):1):poses;
}
const smooth=n=>{n=Math.max(0,Math.min(1,n));return n*n*(3-2*n);};
/** Merge at most one retiring field with the current field, normalized to one
 * viewport. No extra textures or animation clocks; emitters remain live. */
export function blendGroupFields(current,retiring,progress=1){
  const fade=1-smooth(progress);if(!retiring||fade<=.00001)return current;
  const scale=Math.max(current?.effectScale??1,retiring.effectScale??1),paths=[];
  for(const [frame,gain] of [[retiring,fade],[current,1]])if(frame){
    const ratio=(frame.effectScale??1)/scale;
    for(const path of frame.paths??[])paths.push({...path,alpha:path.alpha*gain,fill:(path.fill??0)*gain,width:path.width*ratio,
      glowSpread:(path.glowSpread??3)*ratio,points:path.points.map(p=>[p[0]*ratio,p[1]*ratio,...p.slice(2)])});
  }
  return {...(current??retiring),paths,effectScale:scale,bounds:{x:-130,y:-130,width:260,height:260},
    emissionTargets:current?.emissionTargets??[],activation:current?.activation??{charge:0,projection:0,sustain:0},releasing:fade>0};
}

/** Complementary transit lanes for the four instruments. A brief staging beat
 * separates departures; all endpoints remain exact and elapsed time bounded. */
export function sampleInstrumentTransit(from,to,progress,{index=0,size=100,arc=.2,reduced=false}={}){
  const p=Math.max(0,Math.min(1,progress));if(p===0)return {...from};if(p===1)return {...to};
  const delay=reduced?0:.025+(index%4)*.012,q=reduced?p:smooth((p-delay)/(1-delay));
  const dx=to.x-from.x,dy=to.y-from.y,distance=Math.hypot(dx,dy),bend=reduced?0:Math.min(size*.28,distance*.15)*[-1,1,-.55,.55][index%4];
  const envelope=reduced?0:Math.sin(Math.PI*q),nx=distance>0?-dy/distance:0,ny=distance>0?dx/distance:0;
  return {x:from.x+dx*q+nx*bend*envelope,y:from.y+dy*q+ny*bend*envelope-envelope*arc*size};
}
