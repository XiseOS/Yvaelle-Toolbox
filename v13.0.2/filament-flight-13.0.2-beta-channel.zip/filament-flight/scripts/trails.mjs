import {ID} from './config.mjs?v=13.0.2';
import {ease,getWingMotionStyle} from './poses.mjs?v=13.0.2';
import {wingAnchors,ART_SIZE} from './wing-rig.mjs?v=13.0.2';
import {isShown,placeBehind,isOnScreen,effectMeshClass} from './renderer.mjs?v=13.0.2';
import {wingPhase} from './wing-phase.mjs?v=13.0.2';
import {localPerformance} from './performance.mjs?v=13.0.2';
import {manoeuvreRotation,manoeuvreWidth} from './flight-manoeuvres.mjs?v=13.0.2';

let visibilityRevision=0;
export function invalidateTrailVisibility(){visibilityRevision++;}
const VISIBILITY_REFRESH_MS=200,IDLE_RELEASE_MS=5000;

/** Match a trail's screen footprint, not the full wing artwork's resolution.
 * Compact/folded trails otherwise rasterize tiny strokes into a fixed 512px
 * surface. Buckets plus delayed shrinking prevent allocation churn on turns. */
export function trailResolution(extent,quality='medium',scale=1,resolution=1){
  const profile={low:{density:1,max:384},medium:{density:1.5,max:512},high:{density:2,max:768}}[quality]??{density:1.5,max:512};
  const wanted=Math.max(128,extent*Math.max(.05,scale)*Math.min(2,Math.max(1,resolution))*profile.density);
  return [128,192,256,384,512,768].find(size=>size>=wanted||size>=profile.max)??profile.max;
}
export function settledTrailResolution(record,wanted,now){
  if(!record.size||wanted>record.size){record.pendingSize=null;return wanted;}
  if(wanted===record.size){record.pendingSize=null;return record.size;}
  let pending=record.pendingSize;
  if(!pending||wanted!==pending.size||now<pending.started)pending=record.pendingSize={size:wanted,started:now};
  if(now-pending.started<1000)return record.size;
  record.pendingSize=null;return wanted;
}

function screenDensity(){
  const matrix=canvas.primary?.worldTransform??canvas.stage?.worldTransform;
  return matrix?Math.max(Math.hypot(matrix.a,matrix.b),Math.hypot(matrix.c,matrix.d)):Math.abs(canvas.stage?.scale?.x??1);
}

/** Historical trail points do not move. Reuse their subdivision geometry,
 * and reuse visibility only until Foundry refreshes its vision/lighting state.
 * Weak keys release expired trail records without an ever-growing point map. */
export class TrailSampleCache {
  constructor(){this.geometry=new WeakMap();this.visibility=new WeakMap();this.revision=-1;this.resetAt=-Infinity;}
  /** A moving vision source refreshes sight every frame (as does a climbing
   * token's elevation): re-test historical points at most every 200 ms then.
   * A new view or scene resets at once. */
  begin(visibility,elevation,scene,now=0){
    const fresh=this.revision===-1||this.view!==visibility||this.scene!==scene;
    if(!fresh&&this.revision===visibilityRevision&&this.elevation===elevation)return;
    if(!fresh&&now>=this.resetAt&&now-this.resetAt<VISIBILITY_REFRESH_MS)return;
    this.visibility=new WeakMap();this.revision=visibilityRevision;this.view=visibility;this.elevation=elevation;this.scene=scene;this.resetAt=now;
  }
  segments(a,b,spacing){
    let from=this.geometry.get(a);if(!from){from=new WeakMap();this.geometry.set(a,from);}
    let record=from.get(b);
    if(!record||record.spacing!==spacing){record={spacing,segments:subdivide(a,b,spacing)};from.set(b,record);}
    return record.segments;
  }
  shown(point,test){
    let result=this.visibility.get(point);
    if(result===undefined){result=!!test(point);this.visibility.set(point,result);}
    return result;
  }
  clear(){this.geometry=new WeakMap();this.visibility=new WeakMap();this.revision=-1;this.resetAt=-Infinity;}
}

function subdivide(a,b,spacing){
  const length=Math.hypot(b.x-a.x,b.y-a.y);
  if(length<.25)return [];
  const count=Math.max(1,Math.ceil(length/spacing));if(count>64)return [];
  const result=[];let p=a;
  for(let j=0;j<count;j++){
    const f=(j+.5)/count,end=(j+1)/count;
    const q=j===count-1?b:{x:a.x+(b.x-a.x)*end,y:a.y+(b.y-a.y)*end};
    result.push({a:p,b:q,mid:{x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f},fraction:f});p=q;
  }
  return result;
}

export function wingTransform(s,snapshot) {
  // Flight feel scales the wings with her height and widens them for a stretch.
  const k=s.altScale??1,size=Math.max(s.token.w,s.token.h)*k,source=s.source,angle=source.rotation+s.bank+manoeuvreRotation(s,snapshot);
  const ox=s.opts.offsetX*size,oy=s.opts.offsetY*size;
  const formed=snapshot.formation?.explicit&&(snapshot.formation.growth<1||snapshot.formation.fold>0||!!snapshot.formation.recall);
  return {x:source.x+(s.swayX??0)+ox*Math.cos(angle)-oy*Math.sin(angle),y:source.y+s.lift+ox*Math.sin(angle)+oy*Math.cos(angle),angle,
    width:size*s.opts.wingScale*(formed?1:0.35+0.65*s.blend)*manoeuvreWidth(s,snapshot)*(s.feelWidth??1),height:size*s.opts.wingScale*(s.feelHeight??1),
    presence:snapshot.formation?.explicit&&snapshot.formation.rigMix>0?snapshot.formation.presence:s.blend,
    // (size: her token size as drawn, for bits sent out a distance in token sizes)
    bitOffsets:s.feel?.bits??null,bitSpread:s.feel?.bitSpread??1,size};
}
export function worldAnchors(s,snapshot,config,now) {
  const transform=wingTransform(s,snapshot),c=Math.cos(transform.angle),sn=Math.sin(transform.angle);
  const phase=wingPhase(s,snapshot,config,now);
  return wingAnchors(snapshot.poseAnimation.weights,phase,snapshot.visual.profile,snapshot).map(([x,y])=>{
    x*=transform.width/ART_SIZE;y=(y-15)*transform.height/ART_SIZE;
    return {x:transform.x+x*c-y*sn,y:transform.y+x*sn+y*c};
  });
}

export class TrailBuffer {
  constructor(){this.records=[];this.epoch=null;}
  clear(){this.records=[];this.epoch=null;}
  update({center,anchors,visibility=null,now,epoch,emit,lifetime,length}) {
    if(this.epoch!==epoch){this.clear();this.epoch=epoch;}
    this.records=this.records.filter(r=>now-r.time<lifetime&&now>=r.time);
    const last=this.records.at(-1);
    if(emit&&(!last||Math.hypot(center.x-last.center.x,center.y-last.center.y)>0.5))
      this.records.push({center:{...center},anchors:anchors.map(p=>({...p})),visibility:visibility?[...visibility]:null,time:now});
    let distance=0,previous=center,start=this.records.length;
    for(let i=this.records.length-1;i>=0;i--){const r=this.records[i];distance+=Math.hypot(r.center.x-previous.x,r.center.y-previous.y);if(distance>length)break;start=i;previous=r.center;}
    this.records=this.records.slice(Math.max(start,this.records.length-48));
    return this.records;
  }
}

/** Subdivide before testing visibility and never connect across failed samples.
 * The callback is supplied by Foundry at render time, or by the offline preview.
 */
export function trailSegments(records,current,now,lifetime,test=null,spacing=12,sampleCache=null) {
  if(!records.length)return [];
  const result=[],cache=test&&!sampleCache?new Map():null;
  const visible=!test?null:sampleCache?p=>sampleCache.shown(p,test):p=>{
    const k=`${p.x}:${p.y}`;if(!cache.has(k))cache.set(k,!!test(p));return cache.get(k);
  };
  const head={anchors:current,time:Math.min(now,records.at(-1).time)};
  for(let rib=0;rib<current.length;rib++)for(let i=0;i<records.length;i++){
    const newer=i===0?head:records[records.length-i],older=records[records.length-i-1];
    if(newer.visibility?.[rib]===false||older.visibility?.[rib]===false)continue;
    const a=newer.anchors[rib],b=older.anchors[rib];if(!a||!b)continue;
    if(1-ease((now-newer.time)/lifetime)<=.005)continue;
    const segments=sampleCache?sampleCache.segments(a,b,spacing):subdivide(a,b,spacing);
    for(const segment of segments){
      const time=newer.time+(older.time-newer.time)*segment.fraction;
      const alpha=(1-ease((now-time)/lifetime))*(0.65+0.35*(rib%3===1));
      if(alpha<=.005||visible&&(!visible(segment.a)||!visible(segment.b)||!visible(segment.mid)))continue;
      result.push({a:segment.a,b:segment.b,alpha,rib});
    }
  }
  return result;
}

const TRAIL_STROKES=[[7,0.06],[2.7,0.18],[1,0.7]],TAPERED_STROKES=[[6,0.09],[2.4,0.26],[1,0.85]];
export function paintTrails(ctx,segments,bounds,size,width=0.8) {
  ctx.clearRect(0,0,size,size);if(!segments.length)return;
  ctx.save();ctx.scale(size/bounds.size,size/bounds.size);ctx.translate(-bounds.x,-bounds.y);
  ctx.lineCap='round';ctx.lineJoin='round';
  const groups=new Map();
  for(const line of segments){const alpha=Math.round(line.alpha*12)/12;if(!groups.has(alpha))groups.set(alpha,[]);groups.get(alpha).push(line);}
  const tapered=getWingMotionStyle()!=='classic';
  for(const [alpha,lines] of groups){
    ctx.beginPath();for(const {a,b} of lines){ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);}
    // v10: the wake tapers with age (alpha groups already follow age, so the
    // taper costs nothing) and keeps a pale hot core near the wing tips.
    const w=tapered?width*(0.6+1.6*alpha):width;
    for(const [scale,gain] of tapered?TAPERED_STROKES:TRAIL_STROKES){ctx.strokeStyle=`rgba(255,0,255,${Math.min(1,alpha*gain)})`;ctx.lineWidth=w*scale;ctx.stroke();}
    if(tapered&&alpha>.4){ctx.strokeStyle=`rgba(255,214,255,${(alpha-.4)*1.1})`;ctx.lineWidth=w*.45;ctx.stroke();}
  }
  ctx.restore();
}

export class TrailRenderer {
  constructor(token){this.token=token;this.buffer=new TrailBuffer();this.sampleCache=new TrailSampleCache();this.mesh=null;this.painted=false;this.idleSince=null;}
  create(size) {
    try{
      this.size=size;this.surface=document.createElement('canvas');this.surface.width=this.surface.height=size;
      this.context=this.surface.getContext('2d');if(!this.context)throw new Error('A 2D canvas is needed for flight trails.');
      this.texture=PIXI.Texture.from(this.surface,{mipmap:PIXI.MIPMAP_MODES?.OFF??0});
      const TrailMesh=effectMeshClass(),Shader=foundry.canvas.rendering.shaders.PrimaryBaseSamplerShader;
      this.mesh=new TrailMesh({name:`${ID}.${this.token.id}.trails`,texture:this.texture},Shader);
      this.mesh.anchor.set(0.5);this.mesh.eventMode='none';this.mesh.interactive=false;this.mesh.visible=false;this.mesh.rotation=0;
      canvas.primary.addChild(this.mesh);
    }catch(error){this.release();throw error;}
  }
  update(s,snapshot,config,now) {
    const token=this.token,source=s.source,m=snapshot.movement;
    const shown=isShown(token,source)&&source.alpha>0&&s.opts.opacity>0&&snapshot.effective.intensity>0;
    if(!shown||!snapshot.rendering.active||!m.trailEnabled||config.trailQuality==='off'||config.performanceComponents?.trails===false){this.clear();this.idle();return;}
    const cell=canvas.grid?.size??Math.max(token.w,token.h);
    const maximumExtent=Math.max(token.w,token.h)*(s.opts.wingScale*1.5+Math.abs(s.opts.offsetX??0)+Math.abs(s.opts.offsetY??0))+m.trailLength*cell;
    if(!isOnScreen(source.x,source.y,maximumExtent,maximumExtent)){this.clear();this.idle();return;}
    if(this.buffer.epoch!==s.kinematics.epoch){this.clear();this.buffer.epoch=s.kinematics.epoch;}
    // Once the final wisp has expired, idle wings need no trail geometry or
    // visibility probes. Existing records still take the normal fading path.
    const moving=!!(s.kinematics.moved&&m.moving);
    if(!this.buffer.records.length&&!moving){this.hide();this.idle();return;}
    this.idleSince=null;
    // Display frames only re-place what the last paint showed: a trail whose
    // samples all failed the vision test stays hidden until a paint shows it.
    if(this.mesh){if(this.mesh.visible!==this.painted)this.mesh.visible=this.painted;if(this.painted){this.mesh.alpha=source.alpha*s.opts.opacity*snapshot.effective.intensity*m.trailIntensity*wingTransform(s,snapshot).presence;placeBehind(this.mesh,source,0.4);}}
    // The head follows wings that move every display frame: while travelling
    // repaint at the transition rate (display rate measured ~2.4 ms per paint
    // plus an upload, too heavy per token); a fading wake keeps the texture rate.
    const fps=config.rigFPS;
    const slot=Math.floor(now/(1000/fps));if(slot===this.slot)return;this.slot=slot;
    const anchors=worldAnchors(s,snapshot,config,now);
    const center={x:source.x,y:source.y};
    const elevation=source.elevation??token.document.elevation??0;
    this.sampleCache.begin(canvas.visibility,elevation,canvas.scene,now);
    const test=game.user.isGM?null:p=>{
      localPerformance.count('trailVisibilityTests');
      return !!canvas.visibility?.testVisibility?.({x:p.x,y:p.y,elevation},{tolerance:0,object:null});
    };
    const records=this.buffer.update({center,anchors,visibility:test?anchors.map(test):null,now,epoch:s.kinematics.epoch,
      emit:s.kinematics.moved&&m.moving,lifetime:m.trailLifetime,length:m.trailLength*cell});
    const segments=trailSegments(records,anchors,now,m.trailLifetime,test,Math.max(4,cell*0.12),this.sampleCache);
    if(!segments.length){this.hide();return;}
    let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    for(const {a,b} of segments){minX=Math.min(minX,a.x,b.x);maxX=Math.max(maxX,a.x,b.x);minY=Math.min(minY,a.y,b.y);maxY=Math.max(maxY,a.y,b.y);}
    const extent=Math.max(maxX-minX,maxY-minY,cell*0.5)+cell*0.16;
    const bounds={x:(minX+maxX-extent)/2,y:(minY+maxY-extent)/2,size:extent};
    const wanted=trailResolution(extent,config.trailQuality??config.rigQuality,screenDensity(),canvas.app?.renderer?.resolution??1);
    const size=settledTrailResolution(this,wanted,now);
    if(!this.mesh)this.create(size);
    else if(this.size!==size){
      this.surface.width=this.surface.height=this.size=size;
      this.texture.baseTexture.resource?.resize?.(size,size);
      this.texture.baseTexture.setRealSize?.(size,size);
    }
    paintTrails(this.context,segments,bounds,size,cell*0.008);
    this.texture.baseTexture.update();localPerformance.count('textureUploads');localPerformance.count('uploadPixels',size*size);
    this.mesh.position.set(bounds.x+extent/2,bounds.y+extent/2);this.mesh.width=this.mesh.height=extent;
    this.painted=true;this.mesh.visible=true;this.mesh.alpha=source.alpha*s.opts.opacity*snapshot.effective.intensity*m.trailIntensity*wingTransform(s,snapshot).presence;
    placeBehind(this.mesh,source,0.4);
  }
  hide(){this.painted=false;if(this.mesh&&this.mesh.visible!==false)this.mesh.visible=false;}
  /** Stop-and-go travel reuses the canvas, texture and mesh; they are freed
   * once the trail has stayed empty for five seconds. */
  idle(){
    const t=globalThis.performance?.now?.()??Date.now();this.idleSince??=t;
    if(this.mesh&&t-this.idleSince>=IDLE_RELEASE_MS)this.release();
  }
  release(){
    if(this.mesh&&!this.mesh.destroyed){this.mesh.parent?.removeChild(this.mesh);this.mesh.destroy({children:true,texture:false,baseTexture:false});}
    this.texture?.destroy(true);if(this.surface)this.surface.width=this.surface.height=1;
    this.mesh=this.texture=this.surface=this.context=null;this.size=null;this.pendingSize=null;this.painted=false;
  }
  clear(){this.buffer.clear();this.sampleCache.clear();this.slot=undefined;this.hide();}
  destroy(){this.clear();this.release();this.idleSince=null;}
}
