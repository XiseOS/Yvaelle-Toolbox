/** Mode-specific currents follow the sampled wing, including pose/condition and
 * deployment. A bounded path set uses the existing wing textures; no emitters,
 * timers or scene writes are added when a token moves. */
import {cubic} from './wing-art.mjs?v=13.0.2';
import {unit} from './poses.mjs?v=13.0.2';
import {fitEffectPoint} from './condition-art.mjs?v=13.0.2';
const frac=n=>n-Math.floor(n);

export function movementAccents(side,visual,warp,ribs,growth=1,movement){
  if(!movement?.modeAnimated||!visual?.animated||!visual.energyPulses||growth<=.12)return [];
  const out=[],weights=movement.profile?.modeWeights??{},time=visual.time??0;
  const gain=unit(movement.sweep)*Math.min(1,visual.energy??1)*(1-unit(visual.collapse??0));
  if(gain<=.002)return out;
  const at=(i,u)=>warp([...cubic(ribs[i],u),u]);
  const line=(id,points,width,strength,echo=false)=>{
    if(strength<=.008||points.length<2)return;
    out.push({id:`mode-${id}`,points:points.map(fitEffectPoint),width,
      strength:Math.min(1.2,strength),highlight:!echo,echo});
  };
  const current=(id,i,head,length,width,strength)=>{
    const lo=Math.max(.12,head-length),hi=Math.min(growth,head);
    if(hi<=lo)return;
    // Two soft segments taper behind the current, keeping the head readable.
    for(let section=0;section<2;section++){
      const start=lo+(hi-lo)*section/2,end=lo+(hi-lo)*(section+1)/2;
      line(`${id}-${section}`,Array.from({length:7},(_,j)=>at(i,start+(end-start)*j/6)),width*(section?.9:.5),strength*(section?1:.35));
    }
  };
  if(weights.glide>.001)for(const i of [0,3,6,9]){
    const q=frac(time*.22+i*.193+side*.07),head=.16+q*.88;
    current(`glide-${i}`,i,head,.3,.68,gain*weights.glide*.43*Math.sin(Math.PI*q));
  }
  if(weights.surge>.001)for(const i of [0,1,3,5,7,9]){
    const q=frac(time*1.35-i*.14+side*.06),head=.1+q*1.12;
    current(`surge-${i}`,i,head,.25,1.03,gain*weights.surge*.85*Math.sin(Math.PI*q));
  }
  if(weights.sentinel>.001)for(let band=0;band<3;band++){
    const q=frac(time*.3+band/3+side*.08),u=.48+.24*q;
    if(u>growth)continue;
    const first=band%2?1:0,last=band%2?8:9;
    const points=[];
    for(let i=first;i<last;i++)for(let j=0;j<4;j++){
      const a=at(i,u),b=at(i+1,u),t=j/4,p=a.map((v,k)=>v+(b[k]-v)*t);
      p[0]+=side*2*Math.sin(Math.PI*t);points.push(p);
    }
    points.push(at(last,u));
    line(`sentinel-brace-${band}`,points,.7,gain*weights.sentinel*.57*Math.sin(Math.PI*q));
  }
  if(weights.wraith>.001&&movement.modeEchoes!==false)for(const i of [0,4,9])for(let layer=0;layer<2;layer++){
    const q=frac(time*.48+layer*.5+i*.13),offset=(4+14*q)*gain;
    const points=Array.from({length:15},(_,j)=>{
      const u=.25+(Math.min(growth,1)-.25)*j/14,p=at(i,Math.max(.12,u)),root=u*u;
      return [p[0]+movement.flowX*offset*root,p[1]+movement.flowY*offset*root,p[2],u];
    });
    if(growth>.25)line(`wraith-${i}-${layer}`,points,.7,gain*weights.wraith*.42*Math.sin(Math.PI*q),true);
  }
  return out;
}
