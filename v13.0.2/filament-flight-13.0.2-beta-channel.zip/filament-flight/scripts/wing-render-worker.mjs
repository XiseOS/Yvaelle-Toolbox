import {frameGeometry,paintLayers,LAYER_NAMES} from './wing-rig.mjs?v=13.0.2';
import {layerGlow,stableLayerViewport,sameLayerPixels} from './render-regions.mjs?v=13.0.2';
import {setGestureStyle} from './bit-behaviour.mjs?v=13.0.2';
import {setCoreMarkStyle,setBitOutline,paintResonantBit} from './bit-resonance.mjs?v=13.0.2';
import {setFormationMotion} from './refined-formations.mjs?v=13.0.2';
import {blendWingGeometry} from './wing-effect-transition.mjs?v=13.0.2';
import {setWingMotionStyle} from './poses.mjs?v=13.0.2';
let appliedStyles='';
/** Settings › Versions arrive with each frame (the worker has its own copy of
 * the module variables); a change drops every cached geometry. */
function applyStyles(styles){
  if(typeof styles!=='string'||styles===appliedStyles)return;
  const [g,c,f,w,o]=styles.split('|');setGestureStyle(g);setCoreMarkStyle(c);setFormationMotion(f);setWingMotionStyle(w);setBitOutline(o==='darker');
  appliedStyles=styles;for(const record of records.values())record.geometryCache={};
}

const records=new Map();
/** Resonant bit pictures, painted exactly as the main thread paints them
 * (BitFrames: the 112-unit square scaled to the bit's density, centred). One
 * reusable canvas per surface size; transferring its picture clears it. */
const BIT_DRAW_SIZE=112,bitSurfaces=new Map();
function paintBitJobs(message){
  applyStyles(message.versionStyles);
  const results=[],transfer=[];
  for(const job of message.jobs??[]){
    const base={id:job.id,serial:job.serial,ticket:job.ticket};
    try{
      const size=job.surfaceSize,density=job.qualitySize;
      let surface=bitSurfaces.get(size);
      if(!surface){surface=new OffscreenCanvas(size,size);bitSurfaces.set(size,surface);}
      const f=surface.getContext('2d');if(!f)throw new Error('Offscreen Canvas2D unavailable');
      f.imageSmoothingEnabled=true;f.imageSmoothingQuality='high';
      f.clearRect(0,0,size,size);f.save();
      f.translate(size/2,size/2);f.scale(density/BIT_DRAW_SIZE,density/BIT_DRAW_SIZE);
      let painted=false;
      try{painted=paintResonantBit(f,job.part);}
      catch(error){bitSurfaces.delete(size);throw error;}// its drawing state may be left part-way: never reuse it
      finally{f.restore();}
      if(!painted)throw new Error('Not a resonant bit');
      const bitmap=surface.transferToImageBitmap();
      results.push({...base,surfaceSize:size,qualitySize:density,painted:job.painted,bitmap});transfer.push(bitmap);
    }catch(error){results.push({...base,error:error?.message??String(error)});}
  }
  self.postMessage({type:'bits',id:message.id,results},transfer);
}
self.onmessage=event=>{
  const message=event.data;
  if(message.type==='release'){records.delete(message.id);return;}
  if(message.type==='bits'){paintBitJobs(message);return;}
  if(message.type!=='frame')return;
  const {id,epoch,sequence,size,weights,phase,visual,flight,components,now=0,settled=true,handoff=null}=message;
  try{
    applyStyles(flight?.versionStyles);
    let record=records.get(id);
    // An effect handoff starts with a semantic (epoch) change: keep what is on screen.
    if(!record||record.size!==size||record.epoch!==epoch){record={size,epoch,layers:{},contexts:{},viewports:{},displayed:record?.displayed??null,handoffFrom:record?.handoffFrom??null,handoffStarted:record?.handoffStarted??null};records.set(id,record);}
    const started=performance.now(),bits=new Map();
    let geometry=frameGeometry(weights,phase,visual,flight,record.geometryCache??={});
    if(!handoff){record.handoffFrom=null;record.handoffStarted=null;}
    else if(handoff.started!==record.handoffStarted){record.handoffStarted=handoff.started;record.handoffFrom=record.displayed;}
    if(handoff&&record.handoffFrom)geometry=blendWingGeometry(record.handoffFrom,geometry,handoff.progress);
    record.displayed=geometry;
    const layered={};
    for(const key of LAYER_NAMES){
      const remaining=[],left=key.startsWith('left'),depth=key.endsWith('Front')?'front':'rear';
      for(let part of geometry[key]){
        if(!part.hardware){if((components?.fields!==false||!(/^(support-|intent-exchange)/.test(part.id)))&&(components?.bits!==false||!(/^(gem|sigil)-/.test(part.id))))remaining.push(part);continue;}
        if(components?.fields===false&&part.hardware.glow!=null)part={...part,hardware:{...part.hardware,glow:null}};
        const bitId=`${left?'left':'right'}-${part.id}`;
        let bit=bits.get(bitId);if(!bit){bit={id:bitId,left,part,front:0,rear:0};bits.set(bitId,bit);}
        bit[depth]+=part.strength;
      }
      layered[key]=remaining;
    }
    geometry=layered;
    const paint=handoff?.paint?{...visual,...handoff.paint}:visual;
    const geometryMs=performance.now()-started,glow=layerGlow(paint),changed=[];
    if(components?.wings!==false)for(const key of LAYER_NAMES){
      let layer=record.layers[key];
      if(!layer){const surface=new OffscreenCanvas(1,1),context=surface.getContext('2d');if(!context)throw new Error('Offscreen Canvas2D unavailable');layer=record.layers[key]={surface,context};record.contexts[key]=context;}
      const parts=geometry[key],hasContent=parts.length>0;
      const viewport=stableLayerViewport(parts,size,glow,layer,now,settled,flight.structureAnimation?.artworkExtent??1);
      if(layer.hasContent===undefined||layer.hasContent!==hasContent||viewport!==layer.viewport||hasContent&&(layer.glow!==glow||!sameLayerPixels(layer.parts,parts))){
        if(!layer.viewport||viewport.width!==layer.viewport.width||viewport.height!==layer.viewport.height){layer.surface.width=viewport.width;layer.surface.height=viewport.height;}
        layer.viewport=viewport;record.viewports[key]=viewport;changed.push(key);
      }
      layer.parts=parts;layer.glow=glow;layer.hasContent=hasContent;
    }
    const paintStarted=performance.now();
    paintLayers(record.contexts,geometry,size,paint,undefined,record.viewports,changed);
    const layers=changed.map(key=>{const layer=record.layers[key];return {key,viewport:layer.viewport,hasContent:layer.hasContent,bitmap:layer.surface.transferToImageBitmap()};});
    // transferToImageBitmap clears its surface. Unchanged layers retain their
    // already displayed main-thread textures; the next change repaints fully.
    self.postMessage({type:'frame',id,epoch,sequence,layers,bits:[...bits],cropPending:Object.values(record.layers).some(layer=>layer.cropPending),geometryMs,paintMs:performance.now()-paintStarted},layers.map(layer=>layer.bitmap));
  }catch(error){self.postMessage({type:'error',id,message:error?.message??String(error)});}
};
