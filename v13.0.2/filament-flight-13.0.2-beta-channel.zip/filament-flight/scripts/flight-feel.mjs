/** Flight feel (v10 beta.23; rebuilt in beta.24 on the classic look).
 *
 * The classic hover is the base: she floats in her chosen style and tilts
 * slightly toward the way she moves. On top of it, every motion has a cause
 * and a visible effect, so she feels like she has weight and flies with
 * purpose. Motion only: nothing here draws particles or glows.
 *
 *   cause                        effect
 *   setting off                  the tilt builds into the move (a spring, not a
 *                                snap); her body trails a touch; wings speed up
 *   cruising a while             the wings ease into a slower, held glide
 *   stopping                     she drifts a touch past, the tilt swings back
 *                                through upright and settles; one strong wing
 *                                stroke catches her; then her hover resumes
 *   taking off                   a small gathering dip, quick strokes as she
 *                                climbs to her real height, slowing as she arrives
 *   climbing / descending        harder strokes / wings eased, a slower beat
 *   landing                      wings slow as she sinks, quick braking strokes
 *                                in the last few feet, a soft settle at the ground
 *   combat starting              the wings flare wide and beat hard for a moment
 *   a hit / a miss (PF2e)        knocked back and flinching / a quick sidestep
 *   a ranged miss (beta.26)      a bit darts into the line of fire and takes the shot
 *   a hit (beta.26)              the light is knocked out of the wing facing the
 *                                blow and flows back in from her root
 *   a saving throw (beta.26)     the bits brace her (Reflex tight, Fortitude on the
 *                                wing bones, Will a crown) and let go by the result
 *   knocked out in the air       the wings fail and she falls
 *   long rests                   now and then a stretch, a shake, a glance
 *
 * The flight mode sets the character of all this (flight-character.mjs):
 * how far she leans, how springy the settle is, how fast her wings beat.
 * Her height, shrinking with height and the ground shadow are as in beta.23.
 *
 * Pure and local: no document writes, timers or PIXI. The game renderer and
 * the preview recorder call the same functions, so previews show the real
 * motion. Everything here is cosmetic and never moves the TokenDocument. */
import {FLIGHT_CHARACTERS,sampleHoverWings} from './flight-character.mjs?v=13.0.2';

const TAU=Math.PI*2;
const clamp=(v,a,b)=>v<a?a:v>b?b:v,unit=v=>clamp(v,0,1),lerp=(a,b,t)=>a+(b-a)*t;
const approach=(c,t,dt,rate)=>c+(t-c)*(1-Math.exp(-rate*dt));
const bump=t=>t<=0||t>=1?0:Math.sin(Math.PI*t);
const envelope=(t,attack,release)=>t<=0||t>=1?0:Math.min(1,t/attack,(1-t)/release);
const smooth=t=>{t=unit(t);return t*t*(3-2*t);};
const easeOut=t=>1-(1-unit(t))**3,easeInOut=t=>{t=unit(t);return t<.5?4*t*t*t:1-(-2*t+2)**3/2;};

export const FEEL_WEIGHTS=Object.freeze({light:0,normal:.5,heavy:1});
export const FEEL_SCALES=Object.freeze({off:0,subtle:.5,normal:1,dramatic:1.4});
export const ALTITUDE_PRESETS=Object.freeze({low:5,cruise:15,high:30});
/** Afterimages (a toggle): off, or a style of fading copies of her. */
export const AFTERIMAGE_STYLES=Object.freeze({
  off:{label:'Off'},
  echo:{label:'Echo',hint:'Crystal copies of her and her wings fall behind as she moves, then rush back into her when she stops.'},
  trail:{label:'Trail',hint:'A dense, short smear of light behind her, like motion blur.'},
  phase:{label:'Phase',hint:'A few slow copies linger and drift back along her path, then fold back into her when she stops.'}
});
/** How strong the shadow of her wings is on the ground. */
export const WING_SHADOWS=Object.freeze({off:0,faint:.5,normal:1,strong:1.6});
/** What a ranged attack that misses her looks like (melee misses always sidestep). */
export const MISS_REACTIONS=Object.freeze({
  intercept:{label:'Intercept',hint:'The bit on that side darts into the line of fire and the shot glances off it.'},
  sidestep:{label:'Sidestep',hint:'A quick sidestep across the line of the attack, as for a melee miss.'}
});
// beta.32: her height comes from her token's elevation, which the player sets;
// takeoffElevation (off by default) brings back takeoff writing it (the old "Real height").
export const FEEL_DEFAULTS=Object.freeze({weight:'normal',scale:'normal',altitude:15,takeoffElevation:false,heightByMode:true,autoShield:true,autoChrysalis:true,lifeline:true,
  afterimages:'off',lastAfterimages:'echo',wingShadow:'normal',missReaction:'intercept',bruise:true,braceSaves:true,idleGestures:'all',landToGround:true,
  // beta.35: combat moments, each its own switch, and one strength for them all.
  combatFx:true,combatStrength:1,combatHits:true,combatShatter:true,combatShield:true,combatShots:true,combatSaves:true,combatDodge:true,combatLanding:true});
export const COMBAT_STRENGTH=Object.freeze({min:.25,max:1.5});
export const ALTITUDE_LIMIT=120;

/** Saved per token (flags.filament-flight.flightFeel) so every viewer agrees. */
export function normalizeFeel(raw){
  const out={...FEEL_DEFAULTS};
  if(raw&&typeof raw==='object'){
    if(Object.hasOwn(FEEL_WEIGHTS,raw.weight))out.weight=raw.weight;
    if(Object.hasOwn(FEEL_SCALES,raw.scale))out.scale=raw.scale;
    if(Number.isFinite(Number(raw.altitude)))out.altitude=clamp(Math.round(Number(raw.altitude)),0,ALTITUDE_LIMIT);
    for(const k of ['takeoffElevation','heightByMode','autoShield','autoChrysalis','lifeline','bruise','braceSaves','landToGround','combatFx','combatHits','combatShatter','combatShield','combatShots','combatSaves','combatDodge','combatLanding'])if(typeof raw[k]==='boolean')out[k]=raw[k];
    if(Object.hasOwn(AFTERIMAGE_STYLES,raw.afterimages))out.afterimages=raw.afterimages;
    if(Object.hasOwn(AFTERIMAGE_STYLES,raw.lastAfterimages)&&raw.lastAfterimages!=='off')out.lastAfterimages=raw.lastAfterimages;
    if(Object.hasOwn(WING_SHADOWS,raw.wingShadow))out.wingShadow=raw.wingShadow;
    if(Object.hasOwn(MISS_REACTIONS,raw.missReaction))out.missReaction=raw.missReaction;
    if(['all','calm','off'].includes(raw.idleGestures))out.idleGestures=raw.idleGestures;
    if(Number.isFinite(Number(raw.combatStrength)))out.combatStrength=clamp(Math.round(Number(raw.combatStrength)*100)/100,COMBAT_STRENGTH.min,COMBAT_STRENGTH.max);
  }
  return out;
}

/* ---- bits that leave their stations for a moment (beta.26) ----
 * The feel's bits are indexed like the stations: 0 left upper, 1 right upper,
 * 2 left lower, 3 right lower. A bit target is in token sizes from her body
 * centre, either in her own frame (local: it turns with her) or on the map. */
const BIT_SIDE=[[-1,-1],[1,-1],[-1,1],[1,1]];
/** Saving throws: where each bit braces her (her frame, token sizes) and how far it turns. */
const BRACE_FORMS=Object.freeze({
  // Reflex: the bits snap in tight around her.
  reflex:BIT_SIDE.map(([x,y])=>({x:x*.44,y:y*.44,spin:x*y*-.5})),
  // Fortitude: they lock onto her wing bones, part way along each wing.
  fortitude:BIT_SIDE.map(([x,y])=>({x:x*(y<0?.77:.7),y:y<0?-.6:.62,spin:0})),
  // Will: they gather in a crown above her head, turned outward.
  will:[-150,-30,-117,-63].map(d=>{const a=d*Math.PI/180;return {x:Math.cos(a)*.8,y:Math.sin(a)*.8-.08,spin:(a+Math.PI/2)*.55};})
});
export const SAVE_KINDS=Object.freeze(['reflex','fortitude','will']);
const BRACE_RELEASE=1.15,SCRATCH={};
/** How far the bits still hold on `t` seconds into a save: 1 until they let
 * go, then by the result (a success springs them a touch past their stations
 * and back, so it can dip below 0). */
function braceLetGo(t,outcome){
  const r=t-BRACE_RELEASE;
  if(r<=0)return 1;
  // A success springs them home (a touch past their stations and back).
  if(outcome==='success')return 1-clamp(1-Math.exp(-r*6)*Math.cos(r*10),0,1.15);
  // A critical success lets go cleanly (each bit glints).
  if(outcome==='criticalSuccess')return 1-easeOut((r-.1)/.45);
  // A failure holds on (the wings sag) and lets go slowly; a critical failure longer.
  const hold=outcome==='criticalFailure'?.95:.7,len=outcome==='criticalFailure'?1.6:1.3;
  return 1-smooth((r-hold)/len);
}
/** How braced the bits are `t` seconds into a save (0..1, a success springs
 * a little past their stations) and the moment they let go. */
export function braceAmount(t,outcome){return easeOut(t/.35)*braceLetGo(t,outcome);}
const braceLength=outcome=>BRACE_RELEASE+(outcome==='failure'?2.1:outcome==='criticalFailure'?2.7:1.3);
/** Bit i of a brace now: its target (her frame, token sizes; Fortitude's
 * follow the size of her wings), how far it is there (mix) and its turn
 * (spin). A brace that began while the bits were still out for another save
 * moves them on from where they were. Writes into `o`. */
function braceBit(b,i,o){
  const p=BRACE_FORMS[b.kind][i],k=b.kind==='fortitude'?b.wing:1,e=easeOut(b.t/.35),from=b.from?.[i];
  let tx=p.x*k,ty=p.y*k,turn=p.spin*(b.kind==='reflex'?b.side:1),mix=e;
  if(from){tx=lerp(from.tx,tx,e);ty=lerp(from.ty,ty,e);turn=lerp(from.turn,turn,e);mix=lerp(from.mix,1,e);}
  o.tx=tx;o.ty=ty;o.turn=turn;o.mix=mix*braceLetGo(b.t,b.outcome);o.spin=turn*o.mix;
  return o;
}
/** An intercept `t` seconds in: how far the bit is out at the line of fire
 * (mix: reach, then stay as it comes home), how far the shot knocks it back
 * (token sizes) and how it spins. The shot lands at INTERCEPT_HIT. Writes
 * into `out` (reused every frame). */
export const INTERCEPT_HIT=.3,INTERCEPT_LENGTH=1.7;
export function interceptAmount(t,out={}){
  const reach=easeOut(t/.24),home=easeInOut((t-.85)/.75),a=t-INTERCEPT_HIT,stay=1-home;
  out.reach=reach;out.stay=stay;out.mix=reach*stay;
  out.knock=a>0?Math.exp(-a*5)*Math.sin(Math.min(Math.PI,a*9))*.22*stay:0;
  out.spin=a>0?Math.exp(-a*2.4)*Math.sin(a*21)*1.4*stay:0;
  return out;
}
/** The bit taking shot `c` now: its target on the map (token sizes from her
 * body), how far it is there and its spin. One that was still out for an
 * earlier shot sets off from where it was. Writes into `o` (itx, ity, imix,
 * ispin: on top of any brace, see feelBitPlacement). */
function interceptBit(c,o){
  const a=interceptAmount(c.t,SCRATCH),from=c.from;
  let tx=c.tx+c.dirX*a.knock,ty=c.ty+c.dirY*a.knock,mix=a.mix,spin=a.spin;
  if(from){tx=lerp(from.tx,tx,a.reach);ty=lerp(from.ty,ty,a.reach);mix=lerp(from.mix,1,a.reach)*a.stay;spin=lerp(from.spin,spin,a.reach);}
  o.itx=tx;o.ity=ty;o.imix=mix;o.ispin=spin;
  return o;
}
/** The light knocked out of a wing by a hit, `age` seconds after it: the
 * spot's size (in wing-frame widths), how dark it is, how far it has moved
 * out (shift: it closes from her root, its far edge staying put) and the
 * bright front of the light flowing back in. Writes into `out`. */
export function bruiseAmount(age,severity,out={}){
  const sev=unit(severity),R=.2+.18*sev,dur=2.2+1.6*sev;
  out.r=R*easeOut(age/.12)*(1-smooth((age-.5)/dur));
  out.shift=age>.12?R-out.r:0;
  out.amount=.7+.25*sev;
  out.front=age>.5?.9*(1-smooth((age-.05-dur)/.45)):0;
  out.done=age>.5+dur;
  return out;
}

/** How long (s) her landing descent takes from `alt` feet with `weight`
 * (0 light … 1 heavy): the same controlled descent stepFeel flies. The
 * landing's wing fold is timed to finish as she touches down (beta.29). */
export function landingDescentTime(alt,weight=.5){
  const w=unit(weight),down=lerp(10,6.5,w),limit=lerp(24,14,w),dt=1/60;
  let a=Math.max(0,Number(alt)||0),v=0,t=0;
  while(a>0&&t<8){
    let want=clamp(-a*lerp(2,1.3,w),-down,lerp(13,7.5,w));
    want=a<3.5?clamp(want,-lerp(3,2.2,w),-1.3):Math.min(want,-1.3);
    v+=clamp(want-v,-limit*dt,limit*dt);a+=v*dt;t+=dt;
  }
  return t;
}

/** Her visual size at `alt` feet above the ground she took off from: about
 * 90% at 5 ft, 76% at 15 ft and 66% at 30 ft, never below 45%. */
export function altitudeScale(alt,strength=1){
  const shrink=.4*(1-Math.exp(-Math.max(0,alt)/16));
  return clamp(1-shrink*strength,.45,1);
}
/** (11.0.0-test.20) Her ground shadow by height. `shrink` (Settings › Flight › Shadow shrinks with height, on by default):
 * the higher she is, the smaller and fainter it lies. Off: as before test.20, wider and softer with height.
 * Returns the body shadow's size and strength and the wing shadow's size and extra fade. */
export function heightShadow(alt,shrink=true){
  const a=Math.max(0,alt||0);
  if(!shrink)return {scale:1+a/55,alpha:.8/(1+a/30),wing:1+a/80,wingFade:1};
  const k=.4+.6/(1+a/30);
  return {scale:k,alpha:.8/(1+a/18),wing:k,wingFade:1/(1+a/45)};
}
/** How far (in token sizes) she rises up the screen away from her shadow:
 * about 0.17 at 5 ft, 0.44 at 15 ft, 0.74 at 30 ft, 1.09 at 60 ft and 1.33 at
 * 120 ft (so a change of height is a clear rise or fall). */
export function altitudeRise(alt,strength=1){
  return 1.4*(1-Math.exp(-Math.max(0,alt)/40))*Math.min(1.2,.35+.65*strength);
}

/* ---- idle gestures (beta.35: twelve, eight of them new) ----
 * [name, seconds, in Calm, uses her bits]. One gesture at most in each
 * IDLE_WINDOW seconds, the same on every screen. The bits hold her up: when
 * one leaves its station the others slide toward the gap and spread a touch,
 * and she lists toward the weak side, sinks a little and beats harder until
 * it is back (idleBalance below). */
const IDLE=Object.freeze([
  ['stretch',2.8,true,false],['shake',1.25,false,false],['glance',2.4,true,false],['settle',2.1,true,false],
  // A bit drifts off to look at something below her wing, then comes home.
  ['wander',5.6,true,true],
  // An upper bit circles her once, over her head, and she follows it.
  ['orbit',4.6,true,true],
  // A lower bit settles in front of her, as if in her hands, for a moment.
  ['cradle',5.2,true,true],
  // A bit dozes off (dims and sags) and she dips with it; it jolts awake.
  ['doze',5.4,false,true],
  // Two bits of a row trade stations in crossing arcs, then trade back.
  ['swap',4.8,true,true],
  // All four draw in close round her and she turns one slow lazy loop.
  ['ring',5.6,true,true],
  // A long, yawning spread of the wings, held, then folded in and eased out.
  ['yawn',3.8,true,false]
  // (11.0.0-test.21: 'polish', an upper bit working over the lower bit on its side, was taken out)
]);
const IDLE_CALM=Object.freeze(IDLE.filter(g=>g[2])),IDLE_WINDOW=40;
const idleList=set=>set==='calm'?IDLE_CALM:IDLE;
/** Whether a gesture moves her bits (it is skipped while they are busy). */
export const IDLE_BIT_GESTURES=Object.freeze(IDLE.filter(g=>g[3]).map(g=>g[0]));
/** Every gesture: {name, duration, calm, bits}. */
export const IDLE_GESTURES=Object.freeze(IDLE.map(([name,duration,calm,bits])=>Object.freeze({name,duration,calm,bits})));
function hash(text){let h=2166136261;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
const idleStart=(n,h)=>n*IDLE_WINDOW+8+(h%997)/997*22;
/** The same small gesture at the same moment on every screen: one chance in
 * each 40-second window, chosen from the token id and the shared clock
 * (from the Calm set when `set` is 'calm'). */
export function idleGesture(key,time,set='all'){
  const list=idleList(set),n=Math.floor(time/IDLE_WINDOW),h=hash(`${key}|${n}`),start=idleStart(n,h);
  const [type,duration]=list[(h>>>12)%list.length],p=(time-start)/duration;
  return p>=0&&p<1?{type,p,side:(h>>>20)%2?1:-1,bit:(h>>>24)&3,id:start,duration}:null;
}
/** idleGesture for a feel state: the same moments, worked out once per
 * window and returned in one reused object (it runs every frame). */
function idleGestureOf(f,time,set){
  const n=Math.floor(time/IDLE_WINDOW);
  if(f.idleN!==n||f.idleKey!==f.key||f.idleSet!==set){
    const list=idleList(set),h=hash(`${f.key}|${n}`),[type,duration]=list[(h>>>12)%list.length];
    f.idleN=n;f.idleKey=f.key;f.idleSet=set;f.idleStart=idleStart(n,h);f.idleType=type;f.idleDuration=duration;f.idleSide=(h>>>20)%2?1:-1;f.idleBit=(h>>>24)&3;
  }
  const p=(time-f.idleStart)/f.idleDuration;
  if(!(p>=0&&p<1))return null;
  const g=f.idleSample??={type:'',p:0,side:1,bit:0,id:0,duration:1};
  g.type=f.idleType;g.p=p;g.side=f.idleSide;g.bit=f.idleBit;g.id=f.idleStart;g.duration=f.idleDuration;return g;
}
const IDLE_CALM_NAMES=new Set(IDLE_CALM.map(g=>g[0])),IDLE_SIMPLE=new Set(['stretch','shake','glance','settle']);
const IDLE_DURATION=Object.fromEntries(IDLE.map(g=>[g[0],g[1]])),IDLE_USES_BITS=Object.fromEntries(IDLE.map(g=>[g[0],g[3]]));
// Bit stations in the wing picture (as the rig draws them: x, y in its 600
// units), for gestures that send a bit to another station.
const STATION_PTS=[[-188,-151],[188,-151],[-174,199],[174,199]];
// Moments that end an idle gesture at once (it fades out quickly).
const IDLE_BREAKS=new Set(['hit','shieldHit','dodge','intercept','brace','unfurl','takeoff','land','fall','shatter']);
const hold=(p,a,r)=>smooth(p/a)*smooth((1-p)/r);
/** One frame of an idle gesture: fills f.idleBits (per bit: away, the share
 * of its weight it no longer carries; mix/tx/ty, a target in her frame in
 * token sizes; spin; dim; ox/oy, an extra offset) and f.idleBody (bank, lift
 * and dx in token sizes, rate and width multipliers, wing lift). `k` fades
 * the whole gesture; ws is her wing size (token sizes), wm the wing width. */
function idleMotion(f,gesture,k,ws,wm,dt){
  const B=f.idleBits,Y=f.idleBody,p=gesture.p,q=p*(gesture.duration??IDLE_DURATION[gesture.type]??3),side=gesture.side||1;
  for(const o of B){o.away=0;o.mix=0;o.tx=0;o.ty=0;o.spin=0;o.dim=0;o.ox=0;o.oy=0;}
  Y.bank=0;Y.lift=0;Y.dx=0;Y.rate=1;Y.width=1;Y.raise=0;Y.balanced=false;
  const sx=i=>STATION_PTS[i][0]/600*ws*wm,sy=i=>(STATION_PTS[i][1]-15)/600*ws;
  const bit=(gesture.bit??0)&3;
  switch(gesture.type){
    case 'wander':{
      // A lower bit drifts out past her wingtip and down, turns this way and
      // that as it looks something over, and comes home.
      const i=2|(bit&1),o=B[i],x=BIT_SIDE[i][0],e=hold(p,.24,.26);
      o.mix=e*k;o.away=e*k;
      o.tx=sx(i)+x*.62+.07*Math.sin(q*2.1);o.ty=sy(i)+.52+.05*Math.sin(q*3.3+1);
      o.spin=(x*.35+.45*Math.sin(q*1.7))*e*k;
      // She glances down at it.
      Y.bank=.05*x*e*k;Y.dx=.025*x*e*k;
      break;
    }
    case 'orbit':{
      // An upper bit swings round her once, over her head first, turning as
      // it goes; she follows it with a turn of her head.
      const i=bit&1,o=B[i],x=BIT_SIDE[i][0],dir=-x,e=hold(p,.14,.16),R=.82,cy=-.12;
      const a0=Math.atan2(sy(i)-cy,sx(i)),a=a0+dir*TAU*easeInOut((p-.1)/.8);
      o.mix=e*k;o.away=e*k;o.tx=Math.cos(a)*R;o.ty=cy+Math.sin(a)*R;o.spin=(a-a0)*k;
      Y.bank=.06*o.tx/R*e*k;Y.dx=.03*o.tx/R*e*k;
      break;
    }
    case 'cradle':{
      // A lower bit comes in and rests just below her, as if in her hands
      // (clear of her token, so it is not hidden), rocking gently; she leans over it.
      const i=2|(bit&1),o=B[i],x=BIT_SIDE[i][0],e=hold(p,.26,.26);
      o.mix=e*k;o.away=e*k;o.tx=x*.24;o.ty=.64+.018*Math.sin(q*2.4);o.spin=(-x*.4+.08*Math.sin(q*1.9))*e*k;
      Y.bank=.04*x*e*k;Y.lift=.018*e*k;
      break;
    }
    case 'doze':{
      // A bit nods off: it dims, sags and tips outward, and its share of her
      // weight goes with it. It jolts awake, springs back past its station
      // and settles; she catches herself with one strong stroke.
      // (11.0.1) a lower bit only: an upper bit that sagged came down onto the bit below it and bounced there as it woke
      const i=2|(bit&1),o=B[i],x=BIT_SIDE[i][0],J=.6,r=(p-J)*(gesture.duration??5.4);
      const sag=p<J?smooth(p/.56):Math.exp(-r*4.2)*Math.cos(r*11),end=smooth((1-p)/.08);
      o.oy=.2*sag*k*end;o.ox=x*.05*sag*k*end;
      o.spin=(x*.4*sag+(p>=J?Math.exp(-r*7)*Math.sin(r*34)*.35:0))*k*end;
      o.dim=(p<J?.55*smooth(p/.45):.55*Math.exp(-r*10))*k;
      o.away=.75*Math.max(0,sag)*k*end;
      if(p>=J&&!f.idleJolt&&k>.5){f.idleJolt=true;f.catch=Math.max(f.catch,.55);f.kickV-=x*.5;}
      break;
    }
    case 'swap':{
      // Two bits of a row trade stations in crossing arcs (one outside, one
      // inside), hold a breath and trade back; she rocks to keep level.
      const i=bit&2?2:0,j=i+1,u=easeInOut((p-.08)/.34)-easeInOut((p-.56)/.34),e=hold(p,.07,.07),arc=Math.sin(Math.PI*u),row=i?1:-1;
      for(let n=0;n<2;n++){
        const a=n?j:i,b=n?i:j,o=B[a];o.mix=e*k;o.away=arc*k;
        o.tx=lerp(sx(a),sx(b),u);o.ty=lerp(sy(a),sy(b),u)+row*arc*(n?-.26:.42);
        o.spin=Math.PI*u*(n?-1:1)*k;
      }
      Y.bank=.05*Math.sin(TAU*u)*side*k;
      break;
    }
    case 'ring':{
      // All four draw in close round her (balanced: she floats easier) and
      // the ring turns a quarter while she makes one slow, lazy loop.
      const e=hold(p,.2,.22),turn=side*Math.PI/2*easeInOut((p-.12)/.76),R=.7;
      for(let i=0;i<4;i++){const o=B[i],a=Math.atan2(sy(i),sx(i))+turn;o.mix=e*k;o.tx=Math.cos(a)*R;o.ty=Math.sin(a)*R;o.spin=turn*k;}
      const c=TAU*smooth((p-.1)/.8);
      Y.dx=.05*Math.sin(c)*side*e*k;Y.lift=-.05*(1-Math.cos(c))*e*k;Y.bank=.1*Math.sin(c)*side*e*k;
      Y.rate=1-.22*e*k;Y.balanced=true;
      break;
    }
    case 'yawn':{
      // The wings spread wide and lift, beat slowly while held, fold in
      // briefly and ease back out; her bits ride along on them.
      const spread=hold(p,.4,.42);
      Y.width=1+(.24*smooth(p/.4)-.38*smooth((p-.58)/.16)+.14*smooth((p-.76)/.22))*k;
      Y.raise=.9*spread*k;Y.rate=1-.45*spread*k;Y.lift=(-.035*spread+.03*bump(unit((p-.56)/.36)))*k;
      break;
    }
  }
  idleBalance(f,dt);
}
/** The balancing act: where the missing support is (a spring, so the
 * others catch it with a small wobble) and what it does to the rest. */
function idleBalance(f,dt){
  const B=f.idleBits,Y=f.idleBody;let gx=0,gy=0,ga=0;
  if(!Y.balanced)for(let i=0;i<4;i++){const a=B[i].away;gx+=a*BIT_SIDE[i][0];gy+=a*BIT_SIDE[i][1];ga+=a;}
  const om=6.5,ze=.45,n=f.idleBal;
  if(dt>0){
    n.vx+=(om*om*(gx-n.x)-2*ze*om*n.vx)*dt;n.x+=n.vx*dt;
    n.vy+=(om*om*(gy-n.y)-2*ze*om*n.vy)*dt;n.y+=n.vy*dt;
    n.va+=(om*om*(ga-n.a)-2*ze*om*n.va)*dt;n.a+=n.va*dt;
  }
  // The bits still on station slide toward the gap and widen their stance.
  for(let i=0;i<4;i++){const o=B[i],stay=1-unit(B[i].away);o.ox+=stay*(.17*n.x+.05*n.a*BIT_SIDE[i][0]);o.oy+=stay*(.13*n.y+.04*n.a*BIT_SIDE[i][1]);}
  // She lists toward the weak side, sinks a little and works harder.
  Y.bank+=.075*n.x;Y.lift+=.03*Math.max(0,n.a)+.01*n.y;Y.rate*=1+.3*Math.max(0,n.a);Y.flex=.3*Math.max(0,n.a);
}

export function createFeel(key=''){
  return {key,init:false,epoch:null,
    tx:0,ty:0,vx:0,vy:0,ax:0,ay:0,bodyInit:false,bx:0,by:0,bvx:0,bvy:0,thx:0,thy:0,bax:0,bay:0,
    lean:0,leanV:0,pitch:0,travel:0,travelLeft:0,mom:0,inMove:false,climbPrep:-1,climbPath:null,goalSeen:0,kick:0,kickV:0,air:0,airborne:false,alt:0,altV:0,prep:-1,falling:false,
    dip:0,dipV:0,peak:0,moving:false,dirX:0,dirY:0,still:1,rate:1,catch:0,cruise:0,glide:0,
    squash:0,squashV:0,width:1,widthV:0,idleGate:0,shatter:-1,
    lastTurns:null,hitId:undefined,combatId:undefined,dodgeId:undefined,saveId:undefined,
    intercepts:[],brace:null,bruises:[],
    idleBits:[0,1,2,3].map(()=>({away:0,mix:0,tx:0,ty:0,spin:0,dim:0,ox:0,oy:0})),idleBody:{bank:0,lift:0,dx:0,rate:1,width:1,raise:0,flex:0,balanced:false},idleBal:{x:0,y:0,a:0,vx:0,vy:0,va:0},idleHold:0,idleId:null,idleAbort:false,idleJolt:false,idleBitsOff:0,
    bits:[0,1,2,3].map(()=>({x:0,y:0,vx:0,vy:0})),events:[],out:emptyOut()};
}
function emptyOut(){
  return {dx:0,dy:0,lift:0,bank:0,pitch:0,squashX:1,squashY:1,scale:1,rise:0,alt:0,beatRate:1,flex:0,glide:0,widthMul:1,effort:0,
    shadow:{x:0,y:0,scale:1,alpha:.72},bits:[0,1,2,3].map(()=>({x:0,y:0,mix:0,tx:0,ty:0,local:true,spin:0,turn:0,imix:0,itx:0,ity:0,ispin:0,ox:0,oy:0,dim:0})),bitSpread:1,speed:0,hoverGate:1,still:1,air:0,wingAlpha:1,shield:0,
    bruise:[]};
}
/** True while a bit is out of its station or a wing is still bruised. */
export function feelBusy(f){return !!(f&&(f.intercepts?.length||f.brace||f.bruises?.length));}

/**
 * Advance one frame. Input (all optional except x, y, size):
 *  x,y,size       true token centre and size (px), dt (s), time (shared clock, s)
 *  weight         0 light … 1 heavy;  scale: shrink strength (0 off … 1.4 dramatic)
 *  airborne       flying now (after the takeoff command, false from landing)
 *  altitude       target height in feet above the ground she took off from
 *  phase, turns   current wing phase (rad) and its loop position (0..1)
 *  tilt           maximum lean (rad);  bank: the flight profile's bank share
 *  reduced        reduced motion;  unconscious: a flier falls;  epoch: teleports
 *  hit            {id, dx, dy, severity}: knocked away along (dx,dy)
 *  dodge          {id, dx, dy, ranged, from}: an attack from (dx,dy) missed her
 *                 (from: the attacker's centre on the map, when known)
 *  save           {id, kind: reflex|fortitude|will, outcome, reroll}: she rolled a saving throw
 *  intercept      a ranged miss is taken by a bit (default) · false: she sidesteps
 *  bitsDrawn      which bits are drawn at their stations and can fly out (bit
 *                 mask, 1 left upper … 8 right lower; default all four)
 *  bruise, brace  bruised light on a hit, bits bracing for saves (default on)
 *  rotation       her token's rotation (rad);  wingScale: wing width in token sizes
 *  combat         an id that changes when combat starts;  target {x,y}
 *  dest           {x,y}: where her token is headed (its document position);
 *                 sets how far this move goes, and paces a height change on the way
 *  character      the flight mode's character (blendCharacter), default Fly
 *  hover, floatTime  the floating style (her hover) and its clock (s)
 * Returns f.out; f.events lists this frame's moments (takeoff, liftoff, stroke,
 * stop, touchdown, fall, impact, unfurl, hit, dodge, intercept, brace,
 * interceptHit, braceRelease, shield...) for sound and effects. out.bits
 * carries bits that leave their stations (braced: {mix, tx, ty, local, spin};
 * taking a shot, on top: {imix, itx, ity, ispin}) and out.bruise the spots
 * where a hit knocked the light out of her wings (in her frame).
 */
const SHATTER_FRAME_S=.034;
export function stepFeel(f,input){
  // Low frame rates: run the physics in short steps along the token's path,
  // so speeds, springs and falls keep real time. A long hitch is a reset.
  const raw=Number.isFinite(input.dt)?input.dt:0;
  f.events.length=0;f.shatterBudget=SHATTER_FRAME_S;
  if(raw>.25&&f.init){f.tx=input.x;f.ty=input.y;f.vx=f.vy=f.ax=f.ay=0;}
  // A jump of most of a token in one frame (a warp, an unanimated move) is
  // not flight: her whole body goes with the token, without a swing.
  else if(f.init&&Number.isFinite(input.x)&&Number.isFinite(input.y)&&Math.hypot(input.x-f.tx,input.y-f.ty)>(input.size??100)*.9){
    f.tx=input.x;f.ty=input.y;f.vx=f.vy=f.ax=f.ay=0;f.bodyInit=false;f.lastX=input.x;f.lastY=input.y;f.prevPx=f.prevPy=undefined;}
  if(raw<=.034||!f.init||raw>.25)return stepOnce(f,input,Math.min(raw,.05));
  const n=Math.min(8,Math.ceil(raw/.025)),x0=f.tx,y0=f.ty,sub={...input},events=[];
  for(let i=1;i<=n;i++){
    sub.x=x0+(input.x-x0)*i/n;sub.y=y0+(input.y-y0)*i/n;sub.time=(input.time??0)-raw*(n-i)/n;
    stepOnce(f,sub,raw/n);events.push(...f.events);f.events.length=0;
  }
  f.events.push(...events);return f.out;
}
function stepOnce(f,input,dt){
  const {x,y,size=100,time=0,reduced=false,airborne=false,unconscious=false,target=null}=input;
  const c=input.character??FLIGHT_CHARACTERS.fly;
  const w=unit(input.weight??.5),strength=clamp(input.scale??1,0,1.4);
  const tilt=Number.isFinite(input.tilt)?input.tilt:12*Math.PI/180,bankShare=Number.isFinite(input.bank)?input.bank:1;
  const epoch=input.epoch??0,goalAlt=Math.max(0,Number(input.altitude)||0);
  if(!f.init||f.epoch!==epoch){
    // A teleport, scene change or resumed tab is not travel: no momentum.
    f.tx=x;f.ty=y;f.vx=f.vy=f.ax=f.ay=0;f.bodyInit=false;f.kick=f.kickV=0;f.peak=0;f.moving=false;
    for(const b of f.bits)b.x=b.y=b.vx=b.vy=0;
    // A token already flying when this screen first sees it starts at its
    // height; one that has only just taken off climbs from the ground.
    if(!f.init){const up=airborne&&!input.fresh;f.airborne=up;f.air=up?1:0;f.alt=up?goalAlt:0;f.goalSeen=f.alt;f.hitId=input.hit?.id;f.dodgeId=input.dodge?.id;f.saveId=input.save?.id;f.combatId=input.combat;}
    f.init=true;f.epoch=epoch;
  }
  // The true token's velocity (token sizes/s) and acceleration (sizes/s²).
  if(dt>0){
    const nvx=approach(f.vx,(x-f.tx)/size/dt,dt,16),nvy=approach(f.vy,(y-f.ty)/size/dt,dt,16);
    f.ax=clamp(approach(f.ax,(nvx-f.vx)/dt,dt,12),-90,90);f.ay=clamp(approach(f.ay,(nvy-f.vy)/dt,dt,12),-90,90);
    f.vx=nvx;f.vy=nvy;
  }
  f.tx=x;f.ty=y;
  const speed=Math.hypot(f.vx,f.vy);
  // How far she still has to go (to where her token is headed), in token
  // sizes. A new destination is a new move. Once the token has sat still for
  // a moment, any small gap between where it is drawn and where it is saved
  // (hex grids, large tokens) counts as being there.
  const dest=input.dest,hasDest=dest&&Number.isFinite(dest.x)&&Number.isFinite(dest.y);
  const left=hasDest?Math.hypot(dest.x-x,dest.y-y)/size:0;
  if(hasDest&&(f.destX===undefined||Math.hypot(dest.x-f.destX,dest.y-f.destY)>size*.05)){f.destX=dest.x;f.destY=dest.y;f.staleLeft=0;f.restT=0;}
  f.restT=speed<.15?(f.restT??0)+dt:0;
  if(f.restT>.35)f.staleLeft=left;else if(speed>.3)f.staleLeft=0;
  f.travelLeft=Math.max(0,left-(f.staleLeft??0));

  /* ---- takeoff and landing ---- */
  // Takeoff: a short gathering dip while the wings start to work, then the climb.
  if(airborne&&!f.airborne){
    f.events.push({type:'takeoff'});f.falling=false;
    if(f.alt<.5&&!reduced)f.prep=0;
  }
  if(!airborne&&f.airborne&&!f.falling)f.events.push({type:'land'});
  f.airborne=airborne;
  const prepTime=lerp(.28,.42,w);let gather=0;
  if(f.prep>=0){
    f.prep+=dt;const p=f.prep/prepTime;gather=bump(unit(p));
    if(p>=1){f.prep=-1;gather=0;f.altV=Math.max(f.altV,lerp(3,2,w));f.events.push({type:'liftoff',strength:1});}
  }
  const flying=airborne&&!unconscious&&f.prep<0;
  // The wings carry her until she is down: a controlled descent is still flight.
  const carried=flying||(!airborne&&!unconscious&&!f.falling&&f.alt>.05&&f.aloft);
  f.air=approach(f.air,carried?1:0,dt,carried?2.6:4.5);

  if(f.alt>.3)f.aloft=true;
  const goal=flying?goalAlt:0;
  if(unconscious&&f.alt>.4&&!f.falling&&!reduced){f.falling=true;f.events.push({type:'fall'});}
  if(f.falling||reduced||goal===0)f.climbPath=null;
  if(f.falling){
    f.altV-=34*dt;f.alt+=f.altV*dt;
    if(f.alt<=0){
      const s=unit(-f.altV/26);f.events.push({type:'impact',strength:s});
      f.squashV+=lerp(1.6,2.6,w)*(.4+.6*s);f.alt=0;f.altV=0;f.falling=false;f.aloft=false;
    }
  }else if(reduced){f.alt=goal;f.altV=0;}
  else{
    const up=lerp(13,7.5,w),down=lerp(10,6.5,w),limit=lerp(24,14,w);
    if(goal===0&&f.alt>0){
      // Landing: a controlled descent that slows over the last few feet.
      let want=clamp((goal-f.alt)*lerp(2,1.3,w),-down,up);
      want=f.alt<3.5?clamp(want,-lerp(3,2.2,w),-1.3):Math.min(want,-1.3);
      f.altV+=clamp(want-f.altV,-limit*dt,limit*dt);
    }else if(f.climbPath||(f.travelLeft>.4&&Math.abs(goal-f.alt)>.3)){
      // A move that also changes her height (elevation set while dragging):
      // her height follows the path, so she climbs or sinks along the way and
      // arrives at both together (eased in and out over the move).
      // A new move (further to go than this path expected) starts a new path
      // from where she is; a height that changes along the way (set again, or
      // eased by the game) just moves the end of it.
      let cp=f.climbPath;
      if(cp&&f.travelLeft>cp.total*(1-cp.prog)+.5)cp=null;
      if(!cp)cp=f.climbPath={from:f.alt,to:goal,total:Math.max(f.travelLeft,.5),prog:0};
      cp.to=goal;
      cp.prog=Math.max(cp.prog,unit(1-f.travelLeft/cp.total));
      const q=cp.prog,e=q*q*(3-2*q),target=cp.from+(cp.to-cp.from)*e;
      // Her height is tied to the path itself (eased at both ends), so it can
      // neither lag nor swing past: a quick dash up ends as cleanly as it starts.
      if(dt>0)f.altV=clamp((target-f.alt)/dt,-120,120);
      // Done once she has arrived at the new height.
      if((f.travelLeft<.05||speed<.1)&&cp.prog>.97&&Math.abs(f.alt-goal)<.35&&Math.abs(f.altV)<1.5)f.climbPath=null;
      // (If her token comes to rest anywhere else, she goes the rest of the way.)
      cp.rest=speed<.1?(cp.rest??0)+dt:0;
      if((speed<.1&&f.travelLeft<.05)||cp.rest>.5)cp.prog=Math.min(1,cp.prog+dt/.5);
    }else{
      // A change of height in place: a short gathering (she dips as her
      // wings lift), a climb or a sink that builds up, and a small swing past
      // her new height before she settles at it.
      if(goal>f.goalSeen+2.5&&f.alt>.5&&f.prep<0&&!reduced)f.climbPrep=0;
      let gate=1;
      if(f.climbPrep>=0){f.climbPrep+=dt;const p=f.climbPrep/lerp(.24,.34,w);gather=Math.max(gather,bump(unit(p))*.8);gate=p<.8?0:1;if(p>=1)f.climbPrep=-1;}
      const om=lerp(2.5,1.8,w),ze=.68;
      const acc=clamp((om*om*(goal-f.alt)-2*ze*om*f.altV)*gate,-limit,limit);
      f.altV=clamp(f.altV+acc*dt,-down,up);
    }
    f.goalSeen=goal;
    f.alt+=f.altV*dt;
    if(f.alt<=0){
      if(f.aloft&&goal===0){f.aloft=false;const s=unit(-f.altV/7);f.events.push({type:'touchdown',strength:.45+.55*s});f.dipV+=lerp(.5,.85,w)*(.5+.5*s);}
      f.alt=0;f.altV=Math.max(0,f.altV);
    }
  }

  /* ---- shield, combat, hits, misses ---- */
  if(f.shieldSeen===undefined){f.shieldSeen=true;f.shield=input.shield?1:0;}
  const shieldWas=f.shield;
  f.shield=approach(shieldWas,input.shield?1:0,dt,input.shield?5:3.5);
  if(input.shield&&shieldWas<.02&&!reduced)f.events.push({type:'shieldUp'});
  if(reduced)f.shield=input.shield?1:0;

  if(input.combat!==undefined&&input.combat!==f.combatId){
    const fresh=input.combat!=null;f.combatId=input.combat;
    if(fresh&&(f.air>.1||airborne||input.wings)&&!reduced){
      // Combat: the wings flare wide and beat hard.
      f.events.push({type:'unfurl'});f.catch=Math.max(f.catch,1);f.widthV+=2.6;
    }
  }
  const hit=input.hit;
  if(hit&&hit.id!==f.hitId){
    f.hitId=hit.id;
    if(!reduced&&(f.air>.1||airborne||f.shield>.5)){
      const len=Math.hypot(hit.dx??0,hit.dy??0)||1,sev=unit(hit.severity??.5),ux=(hit.dx??0)/len,uy=(hit.dy??0)/len;
      const guard=f.shield>.5,push=lerp(6,3.8,w)*size*(.35+.65*sev)*(hit.dx||hit.dy?1:0)*(guard?.3:1);
      f.bvx=(f.bvx??0)+ux*push/size;f.bvy=(f.bvy??0)+uy*push/size;f.shove=guard?.5:1;
      f.kickV+=(Math.abs(ux)>.15?Math.sign(ux):hash(String(hit.id))%2?1:-1)*lerp(3.2,2.2,w)*(.4+.6*sev)*(guard?.4:1);
      // She flinches: wings pull in and then beat hard to recover.
      f.widthV-=(guard?.6:1.8)*(.4+.6*sev);f.catch=Math.max(f.catch,.5+.5*sev);f.squashV+=.8*sev*(guard?.3:1);
      f.events.push({type:guard?'shieldHit':'hit',strength:sev,dx:ux,dy:uy});
      if(sev>=.6&&!guard){f.shatter=0;f.events.push({type:'shatter',strength:sev});}
      // Bruised light: the wing facing the blow loses its light where it was
      // struck (toward whoever is acting), and it flows back in from her root.
      // The spot is fixed in her own frame at the moment of the blow, so it
      // stays where it struck as she turns and banks.
      if(!guard&&input.bruise!==false){
        const r=(input.rotation??0)+(f.out.bank??0),c=Math.cos(r),s=Math.sin(r);
        let lx=-ux*c-uy*s,ly=ux*s-uy*c;
        if(!(hit.dx||hit.dy)){lx=hash(String(hit.id))%2?1:-1;ly=0;}
        f.bruises.push({age:0,lx,ly,severity:sev});if(f.bruises.length>3)f.bruises.shift();
      }
    }
  }
  const dodge=input.dodge;
  if(dodge&&dodge.id!==f.dodgeId){
    f.dodgeId=dodge.id;
    if(!reduced&&(f.air>.3||airborne)){
      const len=Math.hypot(dodge.dx??0,dodge.dy??0)||1,ux=(dodge.dx??0)/len,uy=(dodge.dy??0)/len,side=hash(String(dodge.id))%2?1:-1;
      // (How far away the attacker is, in token sizes, when it is known.)
      const range=len>1?len/size:null;
      // A ranged miss: a bit on that side darts into the line of fire and takes
      // the shot. Only a bit drawn at its station can, and only with room: a
      // shot from point blank (closer than a token and a half) is sidestepped.
      let bit=-1,reach=.55*(input.wingScale??3.5);
      if(dodge.ranged&&input.intercept!==false&&!(range!==null&&range<1.5)){
        const r=(input.rotation??0)+(f.out.bank??0),c=Math.cos(r),s=Math.sin(r),lx=-ux*c-uy*s,ly=ux*s-uy*c;
        const drawn=Number.isFinite(input.bitsDrawn)?input.bitsDrawn:15,first=(lx<0?0:1)+(ly>.05?2:0),second=first^2;
        bit=drawn&(1<<first)?first:drawn&(1<<second)?second:-1;
        // Never more than about halfway to the attacker (her bits shrink with her height).
        if(range!==null)reach=Math.min(reach,.55*range/(f.out.scale||1));
      }
      if(bit>=0){
        // She barely moves (a small flinch away from it). A bit still out for
        // an earlier shot sets off from where it is.
        const old=f.intercepts.find(c=>c.bit===bit),was=old?interceptBit(old,{}):null;
        if(old)f.intercepts.splice(f.intercepts.indexOf(old),1);
        f.intercepts.push({t:0,bit,tx:-ux*reach,ty:-uy*reach,dirX:ux,dirY:uy,from:was&&{tx:was.itx,ty:was.ity,mix:was.imix,spin:was.ispin}});
        f.events.push({type:'intercept',bit,dx:ux,dy:uy,reach,from:dodge.from??null,glance:side,hit:INTERCEPT_HIT});
        f.kickV+=(Math.abs(ux)>.15?Math.sign(ux):side)*lerp(.9,.6,w);f.catch=Math.max(f.catch,.35);
      }else{
        // A miss: a quick sidestep across the line of the attack, then back.
        const px=-uy*side,py=ux*side,push=lerp(6.5,4.5,w)*size;
        f.events.push({type:'dodge',dx:px,dy:py});
        f.bvx=(f.bvx??0)+px*push/size;f.bvy=(f.bvy??0)+py*push/size;f.shove=1;f.kickV+=(Math.abs(px)>.15?Math.sign(px):side)*lerp(2.6,1.8,w);f.catch=Math.max(f.catch,.6);
      }
    }
  }
  // A saving throw (PF2e): the bits brace her for it, and let go by the result.
  const save=input.save;
  if(save&&save.id!==f.saveId){
    f.saveId=save.id;
    const was=f.brace,outcome=save.outcome??'success';
    // A reroll (a Hero Point) before they let go: only the result changes.
    if(was&&save.reroll&&!was.released&&was.kind===save.kind)was.outcome=outcome;
    else if(!reduced&&input.brace!==false&&SAVE_KINDS.includes(save.kind)&&(f.air>.3||airborne)){
      const side=hash(String(save.id))%2?1:-1;
      // (Another save while they are still braced: they move on from where they are.)
      f.brace={t:0,kind:save.kind,outcome,side,released:false,wing:clamp((input.wingScale??3.5)/3.5,.5,2.2),
        from:was?[0,1,2,3].map(i=>braceBit(was,i,{})):null};
      f.events.push({type:'brace',kind:save.kind,outcome});
      if(save.kind==='reflex'){
        // She slips aside, the wings pulled in tight and beating hard.
        const r=input.rotation??0,px=Math.cos(r)*side,py=Math.sin(r)*side,push=lerp(4,2.8,w)*size;
        f.bvx=(f.bvx??0)+px*push/size;f.bvy=(f.bvy??0)+py*push/size;f.shove=Math.max(f.shove??0,.8);f.widthV-=1.5;f.catch=Math.max(f.catch,.7);f.kickV+=side*lerp(1.8,1.2,w);
      }else if(save.kind==='will')f.catch=Math.max(f.catch,.2);
    }
  }
  if(reduced){f.intercepts.length=0;f.brace=null;f.bruises.length=0;}
  // (In place: nothing new is made each frame while they run.)
  let alive=0;
  for(const c of f.intercepts){
    const was=c.t;c.t+=dt;
    // The shot lands on the bit now (its sound is this moment, not the dart's launch).
    if(was<INTERCEPT_HIT&&c.t>=INTERCEPT_HIT)f.events.push({type:'interceptHit',bit:c.bit});
    if(c.t<INTERCEPT_LENGTH)f.intercepts[alive++]=c;
  }
  f.intercepts.length=alive;alive=0;
  for(const b of f.bruises){b.age+=dt;if(!bruiseAmount(b.age,b.severity,SCRATCH).done)f.bruises[alive++]=b;}
  f.bruises.length=alive;
  let braceHold=0,braceSag=0,braceRise=0;
  if(f.brace){
    const b=f.brace;b.t+=dt;
    const k=braceAmount(b.t,b.outcome),r=b.t-BRACE_RELEASE;
    if(r>=0&&!b.released){
      b.released=true;
      // (Where the bits are as they let go, on the map, for a critical success's glints.)
      const rot=(input.rotation??0)+f.lean,rc=Math.cos(rot),rs=Math.sin(rot),sc=b.kind==='fortitude'?b.wing:1;
      f.events.push({type:'braceRelease',kind:b.kind,outcome:b.outcome,points:BRACE_FORMS[b.kind].map(p=>[(p.x*rc-p.y*rs)*sc,(p.x*rs+p.y*rc)*sc])});
      if(b.outcome==='failure'||b.outcome==='criticalFailure'){
        // It got through: the wings sag and she sinks a little before she recovers.
        const heavy=b.outcome==='criticalFailure'?1.35:1;f.widthV-=1.3*heavy;f.dipV+=.35*heavy;
      }else f.catch=Math.max(f.catch,.45);
    }
    if(b.kind==='fortitude')braceHold=r<0?unit(b.t/.35):0;
    if(b.kind==='will')braceRise=k;
    if((b.outcome==='failure'||b.outcome==='criticalFailure')&&r>=0)braceSag=bump(unit(r/(b.outcome==='criticalFailure'?2.2:1.8)));
    if(b.t>=braceLength(b.outcome))f.brace=null;
  }

  /* ---- momentum: her body has mass ---- */
  // Her picture is a body with momentum that follows the token (in token
  // sizes and sizes/s): a smooth spring-and-damper on its position and speed.
  // It builds speed as she sets off (falling a little behind), carries her on
  // past a stop in one smooth swing and brings her back, and takes corners and
  // reversals in rounded arcs. Never a wobble: the flight mode sets how lively
  // (omega) and how much she swings past (zeta); her weight makes her slower.
  // She stays within her tether of the real token.
  const px=x/size,py=y/size;
  // How long this move is (squares travelled so far plus what is left to her
  // destination): a step of a tile or so is placed gently, a long flight
  // carries real momentum.
  // (Measured in grid squares.)
  const sq=input.grid>0?size/input.grid:1;
  if(dt>0){
    const step=Math.hypot(x-(f.lastX??x),y-(f.lastY??y))/size;f.lastX=x;f.lastY=y;
    const atRest=speed<.15&&f.travelLeft<.05;
    if(atRest&&!f.inMove){f.travel=0;}
    else{
      if(!f.inMove){
        f.inMove=true;f.travel=0;
        // Setting off (beta.29): the mode's leap ahead (Surge bursts, Fast is
        // quick off the mark), only for a move long enough to carry momentum.
        const D0=f.travelLeft*sq,k0=smooth((D0-1.2)/4.8);
        if(hasDest&&k0>.05&&f.air>.5&&!reduced&&f.travelLeft>.3){
          const ux=(dest.x-x)/size,uy=(dest.y-y)/size,ul=Math.hypot(ux,uy)||1;
          f.burstX=ux/ul;f.burstY=uy/ul;f.burstT=0;f.burstK=k0;
          if(c.burst>0||c.burstFx>0)f.events.push({type:'burst',dx:f.burstX,dy:f.burstY,strength:k0});
          if(c.burstFx>0)f.catch=Math.max(f.catch,.9*k0);
        }
      }
      if(step<1.5)f.travel+=step;
    }
    if(atRest&&f.inMove&&Math.hypot(f.bvx??0,f.bvy??0)<.1)f.inMove=false;
    const D=(f.travel+f.travelLeft)*sq;
    f.mom=f.inMove?Math.max(f.mom??0,smooth((D-1.2)/4.8)):approach(f.mom??0,0,dt,1.5);
  }
  if(!f.bodyInit||f.air<.02||reduced){f.bx=px;f.by=py;f.bvx=f.vx;f.bvy=f.vy;f.bax=f.bay=0;f.bodyInit=true;}
  else if(dt>0){
    // A short step follows her token closely and settles without swinging
    // past; the longer the move, the more of the mode's momentum shows.
    // (With no momentum it is a plain smooth lag, which can never pass the
    // token: k .5 and zeta 1 make it first order. With momentum she matches
    // the token's speed and carries it on past a stop.)
    // Just after a hit or a dodge she moves with the mode's own swing for a
    // moment, so the shove reads and she flies back.
    const sh=f.shove??0,m=Math.max(f.mom,sh);
    // (beta.29) Setting off and stopping are separate: the mode can start
    // quickly and still slide far (Fast), or brake harder than it starts
    // (Sentinel). The token slowing or at rest counts as stopping.
    const along=speed>.05?(f.ax*f.vx+f.ay*f.vy)/speed:0;
    f.stopW=approach(f.stopW??1,speed<.4||along<-2.5?1:0,dt,14);
    const omegaMode=lerp(c.omega,c.omegaStop??c.omega,f.stopW);
    const om=omegaMode*lerp(1.15,.85,w)*lerp(1.8,1,m),ze=lerp(lerp(1,c.zeta,f.mom),Math.max(c.zeta,.8),sh),kv=lerp(.5,1,f.mom)*lerp(c.kvGo??1,1,sh);
    const R=c.tether*lerp(.9,1.15,w),p0x=f.prevPx??px,p0y=f.prevPy??py;
    // Where the mode wants her relative to the token: a leap ahead as she
    // sets off (eased in, then let go) and a sinuous drift across her path.
    let gx=0,gy=0;
    if(f.burstT!==undefined&&f.burstT<1.6){
      f.burstT+=dt;const e=(1-Math.exp(-f.burstT/.06))*Math.exp(-f.burstT/.32)*(c.burst??0)*f.burstK*lerp(1.15,.8,w);
      gx+=f.burstX*e;gy+=f.burstY*e;
    }
    if(c.weave>0&&speed>.2){
      f.weaveT=(f.weaveT??0)+dt;
      const k=c.weave*unit(speed/2.5)*f.mom*Math.sin(f.weaveT*TAU/1.15),ul=speed||1;
      gx+=-f.vy/ul*k;gy+=f.vx/ul*k;
    }else f.weaveT=0;
    f.goalX=approach(f.goalX??0,gx,dt,30);f.goalY=approach(f.goalY??0,gy,dt,30);
    // Small fixed substeps, so she moves the same at 30 or 144 frames a second.
    const n=Math.min(12,Math.max(1,Math.ceil(dt*240))),h=dt/n;let ax=0,ay=0;
    for(let i=1;i<=n;i++){
      const tx=p0x+(px-p0x)*i/n+f.goalX,ty=p0y+(py-p0y)*i/n+f.goalY;
      const ex=tx-f.bx,ey=ty-f.by,evx=kv*f.vx-f.bvx,evy=kv*f.vy-f.bvy;
      ax=om*om*ex+2*ze*om*evx;ay=om*om*ey+2*ze*om*evy;
      // The tether, felt softly: near its end a gentle extra pull brings her round.
      const d=Math.hypot(ex,ey);
      if(d>R*.75){const u=(d-R*.75)/(R*.25),k=40*u*u;ax+=ex/d*k;ay+=ey/d*k;}
      f.bvx+=ax*h;f.bvy+=ay*h;f.bx+=f.bvx*h;f.by+=f.bvy*h;
    }
    f.shove=approach(sh,0,dt,1.4);
    // What the eye reads as her push (lean, wingbeats, bits): the same
    // acceleration, softened a touch so an abrupt start or stop is a push,
    // not a jolt.
    const e=1-Math.exp(-dt/.08);f.bax+=(ax-f.bax)*e;f.bay+=(ay-f.bay)*e;
    // A hard limit only as a safety net (the token jumped).
    const d2=Math.hypot(f.bx-px,f.by-py);if(d2>R*1.5){const k=R*1.5/d2;f.bx=px+(f.bx-px)*k;f.by=py+(f.by-py)*k;}
  }
  f.prevPx=px;f.prevPy=py;
  f.thx=f.bax;f.thy=f.bay;
  const bspeed=Math.hypot(f.bvx,f.bvy),effort=unit(Math.hypot(f.bax,f.bay)/22);

  /* ---- travel: setting off, cruising, stopping ---- */
  f.peak=Math.max(bspeed,f.peak-dt*1.2);
  if(bspeed>.9){f.moving=true;f.dirX=f.bvx/bspeed;f.dirY=f.bvy/bspeed;}
  f.sinceStop=(f.sinceStop??9)+dt;
  // The far point of a slide past the stop (beta.29): the token has stopped and
  // her body turns back toward it. A springy mode meets it with a braking flare.
  if(speed>1.5){f.leadX=f.vx/speed;f.leadY=f.vy/speed;f.overArmed=true;}
  {
    const along=f.bvx*(f.leadX??0)+f.bvy*(f.leadY??0);
    if(f.overArmed&&speed<1&&(f.prevAlong??0)>0&&along<=0){
      f.overArmed=false;const ahead=(f.bx-px)*f.leadX+(f.by-py)*f.leadY;
      if(ahead>.12&&f.air>.5&&!f.falling&&!reduced)f.events.push({type:'overshoot',dx:f.leadX,dy:f.leadY,dist:ahead});
    }
    f.prevAlong=along;
  }
  if(f.moving&&bspeed<.3&&speed<.3){
    f.moving=false;
    const k=unit((f.peak-.6)/4.2)*lerp(.15,1,f.mom);
    // (A springy stop that swings back through counts once.)
    if(k>.04&&f.air>.5&&!f.falling&&!reduced&&f.sinceStop>.7){
      f.sinceStop=0;
      // Come to rest: her weight settles.
      f.events.push({type:'stop',strength:k,dx:f.dirX,dy:f.dirY,speed:f.peak});
      f.dipV+=c.dip*k*.9;
    }
  }
  const cruising=f.air>.9&&bspeed>1.1&&effort<.35&&Math.abs(f.altV)<2&&!f.falling;
  f.cruise=cruising?f.cruise+dt:0;
  const glideAfter=c.glideAfter??1.2;
  f.glide=approach(f.glide,f.cruise>glideAfter&&!reduced?c.glide:0,dt,f.cruise>glideAfter?1.2:6);
  // Her hover holds while she is still, fades as she sets off and comes back
  // gently once she has come to rest.
  f.still=approach(f.still,bspeed<.2&&speed<.2&&!f.falling?1:0,dt,bspeed<.2?1.4:6);

  // Her bits stay with her wings: the whole of her (body, wings and bits)
  // carries the momentum together, nothing swings on its own.
  for(const b of f.bits)b.x=b.y=b.vx=b.vy=0;

  /* ---- the lean ---- */
  // As before, a slight tilt toward the way she moves (sideways travel),
  // now carried by her body: it leans in harder as she pushes off, holds a
  // gentle lean while she flies, eases back upright as she slows and tips
  // back while she swings past a stop and returns. Up and down the map she
  // leans forward or back instead. The mode's classic share still applies.
  const leanMul=c.leanMul??1;
  let leanGoal=Math.tanh(f.bvx/4+f.bax/14*lerp(.25,1,f.mom))*1.1*tilt*bankShare*f.air*leanMul;
  if(target&&f.air>.5){const dx=target.x-x,dy=target.y-y;if(Math.hypot(dx,dy)>size*.7)leanGoal+=clamp(dx/(size*5),-1,1)*.06*(1-unit(bspeed/1.5))*f.air;}
  if(reduced)leanGoal=0;
  if(dt>0){
    const om=lerp(7.5,5.8,w),ze=.92;
    f.leanV+=(om*om*(leanGoal-f.lean)-2*ze*om*f.leanV)*dt;f.lean+=f.leanV*dt;
    f.lean=clamp(f.lean,-1.5*tilt*Math.max(1,leanMul),1.5*tilt*Math.max(1,leanMul));
    f.pitch=approach(f.pitch??0,reduced?0:Math.tanh(f.bvy/4+f.bay/14*lerp(.25,1,f.mom))*.06*f.air,dt,8);
    f.kickV+=(-90*f.kick-2*.45*9.5*f.kickV)*dt;f.kick+=f.kickV*dt;
  }
  if(reduced)f.lean=f.leanV=f.pitch=0;

  /* ---- idle life ---- */
  const hovering=f.air>.95&&speed<.25&&!f.falling&&Math.abs(f.altV)<1&&!reduced;
  f.idleGate=reduced?0:approach(f.idleGate,hovering?1:0,dt,hovering?1.5:6);
  // (beta.35) Idle gestures: all, the Calm set (nothing vigorous) or none.
  const idleSet=input.idleGestures??'all';
  let gesture=f.idleGate>.01&&idleSet!=='off'?(input.idle!==undefined?input.idle:idleGestureOf(f,time,idleSet)):null;
  if(gesture&&idleSet==='calm'&&!IDLE_CALM_NAMES.has(gesture.type))gesture=null;
  // Bits that are busy elsewhere (Medkit, a send-out, retracted) or not all
  // drawn at their stations for a moment: no gesture uses them.
  const drawn=Number.isFinite(input.bitsDrawn)?input.bitsDrawn:15;
  f.idleBitsOff=drawn===15?0:f.idleBitsOff+dt;
  // (12.0.0-beta.7) nor while a shield style holds them (Rotor, Wing wrap): a gesture beginning then pulled a bit off
  // the rotor in one frame (it showed as a bit jumping up to three squares)
  const bitsFree=f.idleBitsOff<.25&&!f.brace&&!f.intercepts.length&&!input.shieldBits;
  if(gesture){
    const id=gesture.id??gesture.type;
    // A gesture plays from its start or not at all, and any moment that
    // needs her (a hit, a miss, a save, setting off) ends it: it fades out
    // quickly and does not come back.
    if(id!==f.idleId){f.idleId=id;f.idleJolt=false;f.idleAbort=gesture.p>.12||f.idleGate<.8||(IDLE_USES_BITS[gesture.type]&&!bitsFree);f.idleHold=f.idleAbort?0:1;}
    if(!f.idleAbort&&(f.idleGate<.6||f.brace||f.intercepts.length||(IDLE_USES_BITS[gesture.type]&&!bitsFree)))f.idleAbort=true;
    if(!f.idleAbort)for(const e of f.events)if(IDLE_BREAKS.has(e.type)){f.idleAbort=true;break;}
    f.idleHold=f.idleAbort?approach(f.idleHold,0,dt,9):1;
    if(f.idleAbort&&f.idleHold<.004)gesture=null;
  }else f.idleId=null;
  let stretch=0,shake=0,glance=0,settle=0;
  const idleK=gesture?f.idleGate*f.idleHold:0;
  if(gesture){
    const g=idleK;
    if(gesture.type==='stretch')stretch=envelope(gesture.p,.28,.32)*g;
    else if(gesture.type==='shake')shake=envelope(gesture.p,.12,.22)*g;
    else if(gesture.type==='glance')glance=envelope(gesture.p,.3,.3)*g*gesture.side;
    else if(gesture.type==='settle')settle=bump(gesture.p)*g;
    else idleMotion(f,gesture,g,input.wingScale??3.5,f.width,dt);
  }
  const idleMoving=!!gesture&&IDLE_DURATION[gesture.type]!==undefined&&!IDLE_SIMPLE.has(gesture.type);
  // (The balance springs settle back to rest after a gesture.)
  if(!idleMoving){const Y=f.idleBody;Y.bank=Y.lift=Y.dx=Y.raise=Y.flex=0;Y.rate=Y.width=1;Y.balanced=false;for(const o of f.idleBits){o.away=o.mix=o.spin=o.dim=o.ox=o.oy=0;}
    const n=f.idleBal;if(n.a||n.x||n.y||n.va||n.vx||n.vy){if(reduced){n.x=n.y=n.a=n.vx=n.vy=n.va=0;}else idleBalance(f,dt);if(Math.abs(n.a)+Math.abs(n.x)+Math.abs(n.y)+Math.abs(n.va)+Math.abs(n.vx)+Math.abs(n.vy)<1e-4)n.x=n.y=n.a=n.vx=n.vy=n.va=0;}}
  const idle=f.idleBody;
  // (Bracing for a Fortitude save: the wings hold rigid and tremble.)
  // (Glide sways slowly side to side while she holds.)
  const swayRest=(c.sway??0)*f.still*f.air*Math.sin(time*TAU/4.4);
  let bank=f.lean+f.kick*.11+glance*.11+idle.bank+swayRest+(shake?Math.sin(time*46)*.035*shake:0)+(braceHold?Math.sin(time*52)*.014*braceHold:0);
  if(f.falling)bank+=Math.sin(time*6.5)*.16+.12;

  /* ---- springs: squash (impacts), dip (weight settling), wing width ---- */
  if(dt>0){
    f.squashV+=(-260*f.squash-2*.35*16*f.squashV)*dt;f.squash+=f.squashV*dt;f.squash=clamp(f.squash,-.15,.18);
    const od=lerp(8,5.5,w),zd=clamp(c.zeta*.8,.3,.9);
    f.dipV+=(-od*od*f.dip-2*zd*od*f.dipV)*dt;f.dip+=f.dipV*dt;f.dip=clamp(f.dip,-.2,.25);
    const widthGoal=(1+.13*stretch)*idle.width;
    f.widthV+=(-150*(f.width-widthGoal)-2*.4*12*f.widthV)*dt;f.width+=f.widthV*dt;f.width=clamp(f.width,.7,1.35);
    f.catch=Math.max(0,f.catch-dt*1.4);
  }

  // Shatter and reform: the wings fade while their splinters fly, then return.
  let wingAlpha=1;
  // (beta.40) Its fade-out is steep (to 15% in 138 ms): a frame the page stalls in (the HP update that set it off
  // lands in one) must not carry the fade through in one go, a visible blink. At most 34 ms of it a displayed frame.
  if(f.shatter>=0&&!reduced){const out=f.shatter<.12*1.15,step=out?Math.min(dt,f.shatterBudget??dt):dt;if(out)f.shatterBudget=Math.max(0,(f.shatterBudget??dt)-step);
    f.shatter+=step;const p=f.shatter/1.15;
    // (beta.30: the beta.28 shatter timing again.)
    wingAlpha=p<.12?1-.85*p/.12:p<.48?.15:p<1?.15+.85*smooth((p-.48)/.48):1;if(p>=1)f.shatter=-1;}
  else f.shatter=-1;

  /* ---- wingbeats: the effort behind every motion ---- */
  const hw=input.hover?sampleHoverWings(input.hover,input.floatTime??time,f.hoverWings??={}):null,hold=f.still*f.air;
  const climb=unit(f.altV/8),sink=unit(-f.altV/8);
  const flareLow=goal===0&&f.alt>0&&f.alt<3.5&&!f.falling?.55:0;
  let rateGoal=c.beat*lerp(1.08,.9,w)*(1+.8*effort*(1-.5*f.glide)+.15*unit(bspeed/4)+.75*climb-.3*sink+.9*f.catch+flareLow+(f.prep>=0?.6:0))*(1-.45*f.glide);
  if(hw)rateGoal*=lerp(1,hw.rate,hold);
  rateGoal*=(1+2.3*shake)*(1-.8*braceHold)*(1-.35*braceRise)*idle.rate;
  f.rate=approach(f.rate,rateGoal,dt,3.2);
  let rate=lerp(1,f.rate,Math.max(f.air,f.prep>=0?1:0));
  if(f.falling)rate=.25;if(reduced)rate=1;
  // Surge at rest (beta.29): every few seconds she gathers (the wings lift),
  // then releases in one hard stroke and a small lift.
  let pulseRaise=0,pulseLift=0;
  if((c.pulse??0)>0&&!reduced&&f.air>.95&&f.still>.6){
    f.pulseT=(f.pulseT??0)+dt;const q=(f.pulseT%3.4)/3.4,was=((f.pulseT-dt)%3.4)/3.4;
    pulseRaise=c.pulse*.6*bump(unit(q/.3))*f.still;
    if(was<.24&&q>=.24){f.catch=Math.max(f.catch,.9*c.pulse);}
    pulseLift=c.pulse*bump(unit((q-.24)/.4))*f.still;
  }else f.pulseT=0;
  // Held wings (beta.29, Glide): the wings finish their stroke, stop wide open
  // and hold there, then give a single beat now and then. Open is the top of
  // the stroke (phase 0), where the wings are still anyway, so they ease to
  // a stop and away again without a jolt. Work (a climb, a catch, combat, a
  // brace) beats normally.
  // (Gliding holds through the push of a move too: the momentum carries her.)
  const calm=f.air>.95&&!f.falling&&f.prep<0&&Math.abs(f.altV)<1.2&&f.catch<.15&&!shake&&!braceHold&&!f.brace&&!reduced;
  const travelling=bspeed>.9;
  const holdGoal=!calm?0:travelling?(c.hold??0):(f.still>.5?(c.holdRest??0):lerp(c.holdRest??0,0,unit((bspeed-.3)/.6)));
  f.hold=approach(f.hold??0,holdGoal,dt,holdGoal>(f.hold??0)?2:6);
  let holdMul=1;
  if(f.hold>.3&&Number.isFinite(input.turns)){
    const t=input.turns,every=travelling?(c.holdEvery??2.4):(c.holdEveryRest??1.8);
    f.holdClock=(f.holdClock??0)+dt;
    // (A released beat runs once round: past the bottom of the stroke and back to the top.)
    if(f.holdRelease===1&&t>.3&&t<.7)f.holdRelease=2;
    // (It ends coming up to the top again, so the wings ease to a stop there.)
    if(f.holdRelease===2&&t>.8){f.holdRelease=0;f.holdClock=0;}
    if(!f.holdRelease&&f.holdClock>every)f.holdRelease=1;
    // (Parked: just past the top of the stroke. Coming up to it: slowing.)
    const parked=t<.05||t>.995,near=t>.84?smooth((1-t)/.16):1;
    holdMul=f.holdRelease?1:parked?0:lerp(1,Math.max(.12,near),unit((f.hold-.3)/.4));
  }else{f.holdRelease=0;f.holdClock=0;}
  f.holdMul=approach(f.holdMul??1,holdMul,dt,holdMul>(f.holdMul??1)?7:16);
  rate*=f.holdMul;
  if(Number.isFinite(input.turns)){
    if(f.lastTurns!==null&&input.turns<f.lastTurns-.5&&f.air>.3&&!f.falling)
      f.events.push({type:'stroke',strength:unit((f.rate/c.beat-.95)/.9)});
    f.lastTurns=input.turns;
  }

  // Height: rise up the screen, shrink, and leave the shadow on the ground.
  const rise=altitudeRise(f.alt,strength)*size,scale=strength>0?altitudeScale(f.alt,strength):1;
  const out=f.out;
  // Where her body is, relative to the token (eased in as she takes to the air).
  out.dx=(f.bx-px)*size*f.air+glance*size*.04+idle.dx*size;out.dy=(f.by-py)*size*f.air;
  out.lift=-rise-pulseLift*size*.05+gather*size*.035+f.dip*size*.16+settle*size*.05-stretch*size*.035-braceRise*size*.045+braceSag*size*.03+idle.lift*size;
  out.bank=bank;out.squashY=1-f.squash;out.squashX=1+f.squash*.45;
  out.scale=scale;out.rise=rise;out.alt=f.alt;out.beatRate=rate;out.glide=f.glide;out.speed=bspeed;out.pitch=f.pitch??0;
  out.effort=unit((f.rate/c.beat-.9)/1.1);
  out.flex=reduced?0:unit(out.effort*1.1+w*.1+shake*.5+idle.flex)*f.air;
  // (Held wide while she glides; Wraith's wings phase faintly while she travels.)
  const travelGate=unit(bspeed/2)*f.air;
  // Wraith: thin, translucent wings that phase (more while she travels).
  if((c.alpha??1)<1)wingAlpha*=lerp(1,c.alpha,f.air);
  if((c.phase??0)>0&&!reduced)wingAlpha*=1-c.phase*(travelGate*(.16+.07*Math.sin(time*7.3))+(1-travelGate)*f.air*.07*(.5+.5*Math.sin(time*2.6)));
  // Her wing silhouette for the mode, at rest and travelling (blended as she settles).
  const restK=smooth(f.still),silW=lerp(c.moveW??1,c.restW??1,restK),silH=lerp(c.moveH??1,c.restH??1,restK);
  out.heightMul=lerp(1,silH,f.air);out.modeRaise=f.air*(lerp(c.moveRaise??0,c.restRaise??0,restK)+pulseRaise);
  out.modeFlare=f.air*lerp(c.moveFlare??0,c.restFlare??0,restK)*(1-pulseRaise);
  out.widthMul=f.width*(hw?lerp(1,hw.width,hold):1)*(1+.14*smooth((f.hold??0)*1.4-.3))*lerp(1,silW,f.air);out.wingAlpha=wingAlpha;out.shield=f.shield;
  out.shadow.x=x+out.dx;out.shadow.y=y+out.dy+size*.30;
  out.shadow.gather=1+gather*.04;out.shadow.scale=(1+f.alt/55)*out.shadow.gather;out.shadow.alpha=.8/(1+f.alt/30);   // (the renderer applies heightShadow when shrinking is on)
  // Sentinel posts her bits a little wider while she holds her ground.
  out.bitSpread=reduced?1:lerp(1,c.post??1,f.still*f.air);
  out.hoverGate=airborne?f.air:1;out.still=f.still;out.air=f.air;
  // For the wing manoeuvres: the wings lift while she gathers and stretches.
  out.gather=gather;out.stretch=Math.max(stretch,idle.raise);
  for(let i=0;i<4;i++){const o=out.bits[i],d=f.idleBits[i];o.x=f.bits[i].x;o.y=f.bits[i].y;o.imix=0;o.itx=o.ity=0;o.ispin=0;o.local=true;
    // An idle gesture's bits (beta.35): out to a target in her frame, or
    // shifted from their stations to keep her balanced, dimmed while dozing.
    o.mix=d.mix;o.tx=d.tx;o.ty=d.ty;o.spin=o.turn=d.spin;o.ox=d.ox;o.oy=d.oy;o.dim=d.dim;}
  // Bits out of their stations: braced for a save (in her frame) and, on
  // top of that, one taking a shot on the line of fire (on the map), so a
  // shot taken while braced leaves from the brace and returns to it.
  if(f.brace)for(let i=0;i<4;i++)braceBit(f.brace,i,out.bits[i]);
  for(const c of f.intercepts)interceptBit(c,out.bits[c.bit]);
  // Bruised light, for the wing painter: spots in her frame (from her body,
  // in wing-frame widths). The records are reused frame to frame.
  out.bruise.length=0;
  const spots=f.bruiseOut??=[];
  for(const b of f.bruises){
    const a=bruiseAmount(b.age,b.severity,SCRATCH);if(!(a.r>.003||a.front>.01))continue;
    const o=spots[out.bruise.length]??={};
    o.lx=b.lx;o.ly=b.ly;o.reach=.3+a.shift;o.r=a.r;o.amount=a.amount;o.front=a.front;out.bruise.push(o);
  }
  return out;
}

/** Fold one frame of flight feel into the motion state the renderers read
 * (after motion()). The classic float path is kept, faded while she travels
 * (she is flying, not bobbing) and brought back as she settles; the spring
 * lean replaces the plain movement tilt; scale, squash, wingbeat rate, flex
 * and wing width ride along for the wings, bits, shadow and token transform.
 * The forward/back lean (pitch) follows the push of her wings up or down the map. */
export function composeFeel(s,out,size,{allowHover=true,allowBank=true,allowPitch=true}={}){
  const mb=s.motionBlend??s.blend??1,ff=s.flightFactor??0,still=out.still??1;
  if(allowHover){
    // motion() put -(height + float)·size into lift: give back the share of
    // the float that travel has faded.
    s.lift=((s.lift??0)+(s.floatY??0)*size*mb*ff*(1-still))*out.hoverGate+out.lift+out.dy;
    s.swayX=(s.swayX??0)*still*out.hoverGate+out.dx;
  }else{s.lift=(s.lift??0)-out.rise;s.swayX=s.swayX??0;}
  if(allowBank)s.bank=(s.idleBank??0)*mb*ff*still+out.bank;
  if(allowPitch)s.pitch=(s.idlePitch??0)*ff*still+(out.pitch??0);
  s.altScale=out.scale;s.squashX=out.squashX;s.squashY=out.squashY;
  s.feelRate=out.beatRate;s.feelFlex=out.flex;s.feelWidth=out.widthMul;s.feelHeight=out.heightMul??1;s.feelWingAlpha=out.wingAlpha;s.feelShield=out.shield;s.feel=out;
  return s;
}
/** Clear everything composeFeel added (feel switched off mid-flight). */
export function clearFeel(s){
  for(const key of ['altScale','squashX','squashY','feelRate','feelFlex','feelWidth','feelHeight','feelGlow','feelWingAlpha','feelShield','feelPose','feel'])delete s[key];
}
