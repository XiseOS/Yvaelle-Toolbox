import {DEFAULTS, LIMITS, FLOAT_STYLES, options} from './motion.mjs?v=13.0.2';
import {effectSettingDefinitions} from './effect-catalog.mjs?v=13.0.2';
import {audioSettingDefinitions} from './audio-model.mjs?v=13.0.2';
import {BIT_INTENT_STYLES} from './bit-intent.mjs?v=13.0.2';
import {BIT_CORE_STATES} from './bit-core-states.mjs?v=13.0.2';
import {localPerformance} from './performance.mjs?v=13.0.2';
import {qualityProfile} from './quality.mjs?v=13.0.2';
import {v7SettingDefinitions} from './v7-ensemble.mjs?v=13.0.2';
import {ESSENTIAL_SETTINGS,settingsPanelClass} from './settings-panel.mjs?v=13.0.2';
import {keepSettingDefinitions} from './keepsake/keep-playing.mjs?v=13.0.2';
import {v11SettingDefinitions} from './v11/features.mjs?v=13.0.2';

export const ID = 'filament-flight';
export const VERSION = '13.0.2';
export const SCHEMA_VERSION = 2;
export const LIGHT_APPEARANCES = Object.freeze({animated:'Animated filaments',current:'Legacy animation'});
export const LANTERN_GROUND_STYLES = Object.freeze({projector:'Token projector',stabilizers:'Wing-style wash from bits'});
export const LANTERN_ARTWORKS = Object.freeze({flow:'Evolving light',veil:'Filament veil',plain:'Plain magenta',prior:'Previous pattern'});

const bool = (name, hint, scope='world', value=true) => ({name, hint, scope, config:true, type:Boolean, default:value});
const number = (name, hint, value, min, max, step) => ({name, hint, scope:'world', config:true, type:Number, default:value, range:{min,max,step}});

export const SETTINGS = {
  ...v7SettingDefinitions(),
  ...audioSettingDefinitions(),
  ...effectSettingDefinitions(),
  // (beta.40) Keep playing: which of the sheet's and the HUD's loops go on while tokens move (keepsake/keep-playing.mjs)
  ...keepSettingDefinitions(),
  // (v11) the v11 feature switches kept on this browser and in the world (v11/features.mjs; her token's are flags)
  ...v11SettingDefinitions(),
  v9SignatureCraft: bool('V9 signature craft', 'Add restrained filament accents, articulated metal reflections and two optional manual wing gestures to the existing wings and Resonant Cores. Disable to retain the earlier artwork; saved poses, formations and conditions remain authoritative.'),
  v9MedicalCraft: bool('V9 medical craft', 'Use complementary diagnostic patterns, focused support and technique-specific result details in Enhanced treatment. Disable to retain the earlier Enhanced artwork. Classic treatment and the optional diagnostic scan remain separate choices.'),
  wingLightStyle:{name:'Wing light style (this browser)',hint:'Soul light draws the same filaments as layered magenta light with tapering ribs, travelling energy and twinkles; conditions change its heat. It costs more to draw than Original.',scope:'client',config:true,type:String,default:'original',choices:{original:'Original',soul:'Soul light (v10)'}},
  wingFollowThrough:bool('Wing follow-through (this browser)','The tips trail the shoulders so each wingbeat rolls outward along the wing, with a firmer push than recovery.','client',false),
  attentionSync:{name:'Bit attention sharing',hint:'Live sends the bits\' attention target to other players without saving it on the token. Saved (9.x) writes it onto the token each time you target or select something.',scope:'world',config:true,type:String,default:'live',choices:{live:'Live (not saved)',flag:'Saved on the token (9.x)'}},
  effectLibrary:{name:'Wing effect library',hint:'Featured lists the eighteen condition effects that stay clearly distinct at token size. All shows every variant. Saved choices always keep working.',scope:'client',config:true,type:String,default:'featured',choices:{featured:'Featured (v10)',all:'All variants'}},
  formationLibrary:{name:'Formation library',hint:'Curated lists the distinct v10 formations first, with near-duplicates moved to a Legacy group at the end, and uses only distinct shapes for random summons. Classic shows only the pre-refined families. All also lets Legacy shapes appear in random summons. Saved formations always keep working.',scope:'client',config:true,type:String,default:'refined',choices:{refined:'Curated (v10)',all:'All, including Legacy in random summons',classic:'Classic (pre-refined families)'}},
  bitSendOutStyle:{name:'Bit send-out style',hint:'How the bits travel when you send them to a task (Medkit treatments, fields, scans, parked lights) and when they come home. Classic always uses the usual flight. Mixed mostly uses it, sometimes one of the alternatives, never the same one twice in a row. Or pick one: Seam warp (they slip into a thin seam beside her and step out at the task), Thread relay (she throws a filament line and they ride it), Sling (they swing around her and are released) or Formation flight (a dart, a crossing pair, a triangle or a diamond, by how many go). Only changes what this browser shows.',scope:'client',config:true,type:String,default:'mixed',choices:{classic:'Classic',mixed:'Mixed (mostly classic)',warp:'Seam warp',thread:'Thread relay',sling:'Sling',flight:'Formation flight'}},
  localQuality:{name:'My view quality',hint:'Independent personal rendering profile. Other-player caps apply only to their effects.',scope:'client',config:false,type:Object,default:{preset:'inherit'}},
  hudEnabled: bool('Enable flight control HUD', 'Allow the module control window to open from openHUD() or toggleHUD(). Existing flight macros work independently of the HUD.'),
  effectsEnabled: bool('Show flight effects', 'Turn all Yvaelle’s Toolbox visuals and wing lighting on or off. Saved token states are retained.'),
  localEffects: bool('Show effects on this browser', 'Hide flight visuals on this browser without changing other players or saved states. Real wing-light illumination remains active.', 'client'),
  reducedMotion: bool('Reduced motion', 'Show a fixed wing pose and hover on this browser; disable wingbeats, bobbing, banking and pose blending. Wing light becomes steady.', 'client', false),
  wingRenderer: {name:'Wing renderer', hint:'Automatic uses the filament rig for physical stabilizers, poses and gem controls. Energy gems with Classic placement can use the original atlas. Original atlas preserves its baked energy gems without clearing saved choices.', scope:'world', config:true, type:String, default:'auto', choices:{auto:'Automatic',rig:'Filament rig for all poses',atlas:'Original atlas (compatibility)'}},
  advancedPoses: bool('Wing poses', 'Allow the saved wing pose to change wing geometry. Disable to show the neutral pose.'),
  foregroundWings: bool('Wings in front of the token', 'Allow wrapping strands to cross in front of the character. Disable to draw all strands behind the token.'),
  foregroundOpacity: number('Foreground strand opacity', 'Visibility of strands crossing the character. Lower values keep the portrait easier to see.', 0.7, 0, 1, 0.05),
  poseStrength: number('Pose strength', 'Amount of wing deformation. Zero shows neutral wings while retaining the saved pose.', 1, 0, 1, 0.05),
  poseTransitions: bool('Smooth pose changes', 'Blend between poses. Reduced motion also disables pose blending on that browser.'),
  poseDuration: number('Pose transition duration', 'Default milliseconds for setPose and the entrance/return of temporary poses.', 650, 0, 10000, 50),
  poseTransitionStyle: {name:'Pose transition style',hint:'Flow eases acceleration and carries interrupted motion into the next pose. Classic keeps the earlier blend. Tokens can choose their own style in the HUD (Settings › Everything › Detailed tuning › Wing poses).',scope:'world',config:true,type:String,default:'flow',choices:{flow:'Flow',classic:'Classic blend'}},
  poseFollowThrough: number('Pose follow-through', 'In Flow transitions the outer filaments follow the roots with a soft delay. Zero moves the whole wing together. Adjustable per token in the HUD (Settings › Everything › Detailed tuning › Wing poses).', 0.6, 0, 1, 0.05),
  controlGems: bool('Show stabilizers / control gems', 'Show four independent floating stabilizers. Choose physical hardware or energy in the HUD (Detailed tuning › Bits & stabilization). Requires Automatic or Filament rig; the original atlas has baked-in energy gems.'),
  gemPlacement: {name:'Default bit placement',hint:'Free positions keep each bit at its chosen station independently of wing poses. Follow wings uses the earlier pose choreography.',scope:'world',config:true,type:String,default:'free',choices:{free:'Free positions',follow:'Follow wings'}},
  bitTransitions: bool('Animate bit deployment','Retract bits into the token and deploy them again without changing the wings. Reduced motion uses an immediate change.'),
  v8WeightedTravel: bool('Weighty bit travel', 'Give dispatched instruments controlled acceleration, a gentle lean through turns and smooth braking. Disable to retain the earlier travel animation. Reduced motion omits the extra movement.', 'world', true),
  v8ObstacleRoutes: bool('Route bits around visible obstacles', 'Plan a short physical route when a command is confirmed. Uses only visible scene information and reports a blocked route without moving the bits. Route planning never runs in the animation loop.', 'world', false),
  v8WorkingPosture: bool('Steady posture while examining and treating', 'Gently steady floating motion and draw the wing nearest the work back. Your selected original pose remains saved; a newer pose command and incapacitating conditions take precedence.', 'world', true),
  bitTransitionDuration: number('Bit deployment duration','Milliseconds for a bit-only show or hide animation.',650,0,3000,50),
  gemAppearance: {name:'Stabilizer appearance',hint:'Small physical bits emit energy that stabilizes the wing shape, or use energy gems. Both float freely. Tokens can override this in the HUD (Detailed tuning › Bits & stabilization).',scope:'world',config:true,type:String,default:'physical',choices:{physical:'Physical stabilizer bits',energy:'Energy gems'}},
  gemDesign: {name:'Physical bit design',hint:'Small suspended stabilizers that shape the wing field with energy. Each token can choose its design in the HUD (Detailed tuning › Bits & stabilization).',scope:'world',config:true,type:String,default:'vanes',choices:{vanes:'Prism spindle',shielded:'Aegis lens',spine:'Filament needle'}},
  gemArtwork: {name:'Bit artwork',hint:'Resonant cores use smooth independent animation with elegant metal shells and energy stabilization. Retired frame artwork is automatically upgraded; a lightweight vector fallback remains available.',scope:'world',config:true,type:String,default:'resonant',choices:{resonant:'Resonant cores',vector:'Vector fallback'}},
  gemGlowMode: {name:'Stabilizing glow style',hint:'Core lights the bit itself. Field animates a small energy support around the nearest wing contour. Both follow the stabilizer and respect its glow switch.',scope:'world',config:true,type:String,default:'field',choices:{core:'Core glow',field:'Core and stabilization field'}},
  gemProgram: {name:'Stabilizer animation program',hint:'Distinct articulated motion for the floating stabilizer assemblies. Each token can choose its own program.',scope:'world',config:true,type:String,default:'poised',choices:{poised:'Poised',orbital:'Orbital',seraph:'Seraph'}},
  gemCoreState: {name:'Resonant Core state',hint:'Preserve the current animation, respond to assigned work, or choose an optional housing and energy state. Individual groups can override this.',scope:'world',config:true,type:String,default:'idle',choices:BIT_CORE_STATES},
  gemCoreDepth: bool('Gemstone internal depth', 'Optional faint reflections and darker recesses inside the existing gemstone facets. Does not change its shape, housing, base colours or emitted light. Off preserves the original artwork exactly. Each token can override this in the HUD (Detailed tuning › Bits & stabilization).', 'world', false),
  gemCoreDepthStrength: number('Gemstone internal depth strength', 'Amount of subtle shading inside Resonant Core gemstones. Zero preserves the original artwork; this does not change core glow or the metal housing.', .35, 0, 1, .05),
  bitPassiveEffects: {name:'Passive bit energy gestures',hint:'Allow restrained scan lines and small energy exchanges within personality formations. Active effects remain separately controlled.',scope:'world',config:true,type:Boolean,default:true},
  gemFieldStyle: {name:'Stabilization field animation',hint:'Animated energy that supports the nearby wing contour. Core-only glow omits the field.',scope:'world',config:true,type:String,default:'contour',choices:{contour:'Contour currents',weave:'Energy weave',aegis:'Aegis arcs'}},
  modeTransitionDuration: number('Flight-mode blend duration','Milliseconds for movement behavior to settle into a new flight mode.',650,0,3000,50),
  gemAnimatedAssets: {...bool('Retired frame artwork compatibility', 'Saved setting retained for old macros. Resonant Core animation is independent.'),config:false},
  gemAssetStates: bool('Bit animation states', 'Change the actual hardware frames for movement, defensive poses, damage, glitching, overdrive, suppression, collapse, recovery and deployment. Disable to keep the idle hardware sequence. Adjustable per token in the HUD (Detailed tuning › Bits & stabilization).'),
  gemMetalHighlights: bool('Metallic highlights', 'Subtle reflections move across metal faces as the bits turn. Disable globally here or per token in the HUD (Detailed tuning › Bits & stabilization). Energy gems are unchanged.'),
  gemHighlightStrength: number('Metallic highlight strength', 'Strength of reflected highlights on the physical housing. Zero hides them. Adjustable per token in the HUD (Detailed tuning › Bits & stabilization).', .45, 0, 1, .05),
  gemShutters: bool('Mechanical core shutters', 'Small plates open with deployment and energy load, then close during suppression or collapse. Disable for an unobstructed core. Adjustable in the HUD (Detailed tuning › Bits & stabilization).'),
  gemSuspendedCore: bool('Suspended inner core', 'Show a separate core cradle inside the housing. It counter-rotates subtly when stabilizer animation is enabled. Adjustable in the HUD (Detailed tuning › Bits & stabilization).'),
  gemMechanicalResponse: bool('Mechanical condition reactions', 'Physical bits make distinct corrections for damage and instability; glitching can misalign the projected core. Respects animation and effect-response switches. Adjustable in the HUD (Detailed tuning › Bits & stabilization).'),
  gemRepairFocus: bool('Stabilizer repair focus', 'During healing or reform, inner cores aim toward the nearby wing contour and scan locally. Respects reaction, animation and glow switches. No connecting beams. Adjustable in the HUD (Detailed tuning › Bits & stabilization).'),
  gemSize: number('Stabilizer size', 'Size of the four floating bits or energy gems. Their support positions stay the same. Adjustable per token in the HUD (Detailed tuning › Bits & stabilization).', 1, 0.5, 1.5, 0.05),
  gemAnimation: bool('Animate stabilizers', 'Play hardware animation frames, internal core motion, idle drift and condition accents. Disable to hold a still frame while following the token, deployment and chosen pose. Adjustable per token in the HUD (Detailed tuning › Bits & stabilization).'),
  gemStabilizingGlow: bool('Stabilizing glow', 'Emit a subtle animated light from each physical bit. Choose Core glow or Core and subtle field in the HUD (Detailed tuning › Bits & stabilization). Disable globally here or per token. Energy gems and real scene lighting are independent.'),
  gemGlowStrength: number('Stabilizing glow strength', 'Strength of emitted core light and the optional wing-facing field. Zero hides the emitted glow; the coloured jewel remains. Adjustable per token in the HUD (Detailed tuning › Bits & stabilization).', 0.4, 0, 1, 0.05),
  bitPersonality: number('Compact bit personality', 'Independent pauses, inspections and acknowledgements. Zero keeps the selected formation composed.', .35, 0, 1, .05),
  bitExpressionEnabled: bool('Expressive bit reactions', 'Let deployed instruments respond to movement, health and enabled conditions, including when the wings are closed. Each token can tune or disable individual responses.'),
  bitExpressionStrength: number('Bit expression strength', 'Amount of situational formation, posture and energy response. Low values keep the instruments composed. Existing formation and core-state choices are preserved.', .45, 0, 1, .05),
  bitIntent: {name:'Bit attention and intent',hint:'Sparse glances, damage inspections and exchanged energy packets. Composed keeps gestures rare. Macro choreography takes priority.',scope:'world',config:true,type:String,default:'composed',choices:BIT_INTENT_STYLES},
  gemChoreography: bool('Control-gem choreography', 'Let gems anchor guards, frame raised wings, trail in flight and respond to wing effects. Disable to enforce the classic gem placement.'),
  gemMotionStrength: number('Gem movement amount', 'Extra drift, effect reactions and formation movement. Pose-specific gem positions remain at zero. Adjustable per token in the HUD (Detailed tuning › Bits & stabilization).', 0.75, 0, 1, 0.05),
  gemAnimationSpeed: number('Stabilizer animation speed', 'Speed of asset playback, idle drift and condition choreography. Does not change pose or reaction deadlines.', 1, 0.25, 2, 0.05),
  gemConditionResponse: bool('Bits respond to visual conditions', 'Deployed bits respond to damage, instability, overdrive and recovery, including with the wings closed. Respects manual overrides, animation switches and enabled reactions.'),
  gemTethers: {...bool('Gem guide filaments (retired)', 'Legacy setting retained for compatibility. Stabilizers and energy gems now float without strings.', 'world', false),config:false},
  temporaryPoses: bool('Temporary poses', 'Allow poseFor overrides. Their deadlines still expire while this setting is off.'),
  rigQuality: {name:'Filament detail on this browser', hint:'Texture detail for posed wings. Higher values use more graphics memory and upload bandwidth.', scope:'client', config:true, type:String, default:'medium', choices:{low:'Low (384)',medium:'Medium (512)',high:'High (768)'}},
  bitQuality: {name:'Bit detail on this browser',hint:'Independent detail for physical bits. Resonant cores render natively at 128, 256 or 512 pixels. Lower choices reduce memory and texture uploads without changing wing detail or other players.',scope:'client',config:true,type:String,default:'high',choices:{low:'Low',medium:'Standard',high:'High'}},
  rigFPS: {...number('Wing animation frame rate on this browser', 'How often the wing, field and treatment art is redrawn. 60 redraws on every screen frame (smoothest). On a slower computer try 30: each picture is then held for exactly two screen frames, so the wingbeat stays steady instead of stuttering. Token movement always runs at full rate.', 60, 12, 60, 1), scope:'client'},
  renderWorker: bool('Paint wings off the main thread','Draw filament textures in a bounded background worker while token movement stays on the canvas ticker. Falls back automatically when unavailable. Turn off for compatibility troubleshooting.','client'),
  poseFPS: {...number('Pose transition frame rate on this browser', 'While changing pose, use at least this redraw rate. Normal wingbeats return to the ordinary frame-rate setting when the blend finishes. Lower this for slower computers.', 60, 12, 60, 1),scope:'client'},
  visualConditions: bool('Visual wing conditions', 'Allow damaged, unstable, glitching, overdrive, suppressed and collapsed appearances.'),
  enhancedConditions: bool('Detailed animated wing effects', 'Allow the animated treatment, including per-token style choices in the Effects tab. Disable to enforce the original subtle effects for all tokens.'),
  conditionMotionStrength: number('Condition movement strength', 'Amount of extra flutter, distortion, flare and contraction. Does not change the saved wing pose or token movement.', 1, 0, 1, 0.05),
  conditionAnimationSpeed: number('Condition animation speed', 'Speed of filament distortions and energy circulation. Independent of wingbeat speed and saved cue durations.', 1, 0.25, 2, 0.05),
  glitchDisplacement: number('Glitch displacement', 'Amount that short horizontal sections jump out of alignment before reforming. Glitch intensity controls how often this happens.', 1, 0, 1, 0.05),
  glitchEchoes: bool('Filament phase echoes', 'Show short-lived displaced copies of corrupted sections and the thin wake in Wraith flight. Glitch echoes require filament glitching and detailed effects.'),
  conditionSparks: bool('Frayed ends and condition sparks', 'Add loose threads, small sparks and falling fragments to damaged or collapsing wings. Reduced motion disables these moving accents.'),
  overdriveArcs: bool('Overdrive energy arcs', 'Send bright filaments around the wing ribs during overdrive. Requires energy pulses.'),
  reactionWaves: bool('Travelling reaction waves', 'Send a visible wave through the wing structure for flare, pulse, healing and reform. Requires energy pulses.'),
  wingLight: bool('Enable wing light', 'Allow the HUD and API to emit real magenta scene lighting from a token. Existing token lights are preserved.'),
  lightDefault: bool('Wing light on by default', 'Automatically light active wings unless that token has explicitly switched its wing light off.', 'world', false),
  lightRequiresWings: bool('Light only while wings are active', 'Pause the saved light when the wings are off. Disable to allow a separately toggled light without activating flight.'),
  lightBright: number('Wing light: bright radius', 'Default bright-light distance in scene units (feet on a standard PF2e scene). Override per token in the HUD (Detailed tuning › Fit, light & performance). Zero gives dim light only.', 5, 0, 120, 1),
  lightDim: number('Wing light: dim radius', 'Default total dim-light distance in scene units, not an extra distance beyond bright. Override per token in the HUD (Detailed tuning › Fit, light & performance). The larger radius sets the outer boundary.', 15, 0, 120, 1),
  lightAlpha: number('Wing light: magenta tint', 'Strength of the #ff00ff colour. Lower values keep map details easier to read. Zero removes the colour tint, but still illuminates.', 0.28, 0, 1, 0.01),
  lightLuminosity: number('Wing light: brightness', 'Brightness of the illumination. The HUD light-strength slider scales this per token.', 0.5, 0.1, 1, 0.05),
  lightAttenuation: number('Wing light: soft edges', 'Feather the light toward its edge. Higher values give a softer pool of magenta light.', 0.75, 0, 1, 0.05),
  lightEdgeFeather: bool('Wing light: feather darkness boundary', 'Fade the outer light and current-visibility edge inside the existing radius. Keeps walls, detection and explored fog unchanged. Uses the native visibility drawing when supported; an active Vision Edge Attenuation module takes priority.'),
  lightEdgeStrength: number('Wing light: darkness edge softness', 'Width of the outer fade. At 1, the last half of the radius fades; 0 retains the native edge. This never extends the light radius. Requires Feather darkness boundary.', 0.65, 0, 1, 0.05),
  lightAnimation: {name:'Wing light: animation',hint:'A slow native light pulse or steady light. Reduced motion always uses steady illumination on that browser.',scope:'world',config:true,type:String,default:'pulse',choices:{pulse:'Soft pulse',none:'Steady light'}},
  lightSpeed: number('Wing light: pulse speed', 'Speed of the soft pulse. Zero uses steady light. Independent of wingbeat speed.', 1, 0, 5, 0.25),
  lightAnimationIntensity: number('Wing light: pulse depth', 'Amount of pulsing. Zero uses steady light; low values give gentle breathing.', 2, 0, 5, 0.25),
  lightConditionResponse: bool('Wing light follows condition', 'Dim suppressed/collapsed wings and brighten overdrive. Uses smooth condition energy, not rapid glitch flashes. Light distances stay fixed.', 'world', false),
  lightAppearance: {name:'Light appearance',hint:'Animated filaments keep circular light currents and enable the chosen lantern artwork. Legacy animation restores earlier animation and patterns; Plain magenta stays plain. Every lantern artwork retains corrected magenta in dark scenes. Tokens can override this in the HUD (Settings › Everything › Scene illumination); edge softness remains independent.',scope:'world',config:true,type:String,default:'animated',choices:LIGHT_APPEARANCES},
  lanternArtwork: {name:'Lantern artwork',hint:'Evolving light uses soft magenta currents that form and dissolve independently of aiming, with a small response to turns. Filament veil keeps the earlier flowing translucent textures; Previous pattern keeps the original artwork. Plain magenta removes the decorative pattern, including with Legacy animation. Reduced motion holds the detail still. Every choice retains corrected dark-scene magenta. Applies only to lantern light; Legacy animation otherwise uses the previous pattern and keeps your artwork choice saved. Tokens can override this in the HUD (Settings › Everything › Scene illumination).',scope:'world',config:true,type:String,default:'flow',choices:LANTERN_ARTWORKS},
  lightVisualReactions: bool('Light appearance follows wing reactions', 'Let both lights show restrained visual disruption, fading and recovery from the same HP and condition response as the wings. Does not alter light distance or direction. Disable independently of light appearance and lantern artwork.'),
  temporaryConditions: bool('Temporary wing conditions', 'Allow conditionFor() and temporary overdrive. Saved deadlines still expire when disabled.'),
  hpReactions: bool('Automatic HP reactions', 'Derive visual health from the actor for active wings or deployed bits. A token can opt out through setHPReactions().'),
  hpModerate: number('Moderate damage threshold (%)', 'At or below this HP percentage, occasional filament flickers begin.', 70, 1, 99, 1),
  hpLow: number('Low HP threshold (%)', 'Broken strands and uneven pulses. This cutoff is capped at the moderate threshold.', 35, 1, 99, 1),
  hpCritical: number('Critical HP threshold (%)', 'Severe phasing and instability. This cutoff is capped at the low threshold.', 15, 1, 99, 1),
  hpReactionIntensity: number('HP reaction intensity', 'Scale automatic damage, instability and glitching above zero HP. The zero-HP response is controlled separately.', 1, 0, 1, 0.05),
  zeroHPBehavior: {name:'Wings at zero HP',hint:'Cosmetic response at zero HP. This does not change any PF2e rules or conditions.',scope:'world',config:true,type:String,default:'collapse',choices:{collapse:'Fold and fade',fragment:'Fragment',fade:'Fade almost completely',ignore:'Keep the critical-HP appearance'}},
  unconsciousCollapse: bool('React to unconsciousness', 'Use the zero-HP wing response when the actor is unconscious or dead, even with positive HP.'),
  collapseLowersToken: bool('Lower the image when wings collapse', 'Ease the cosmetic hover toward the ground while wings are fully collapsed. Saved flight mode and actual elevation are retained.'),
  filamentBreaks: bool('Missing and broken filaments', 'Allow damaged conditions to remove portions of strands.'),
  filamentInstability: bool('Uneven filament movement', 'Allow asymmetric sag and motion in unhealthy wings.'),
  filamentGlitches: bool('Filament glitching', 'Allow local sections to phase out and reform. Reduced motion uses a static damaged shape instead.'),
  glitchLimit: number('Maximum glitch intensity', 'Cap glitching for every token, including explicit API requests.', 1, 0, 1, 0.05),
  energyPulses: bool('Energy pulses and travelling light', 'Allow changing filament brightness and travelling glints. Reduced motion disables these changes.'),
  transientEffects: bool('Temporary wing effects', 'Allow flare, pulse, stutter and automatic damage/healing cues. Saved deadlines still expire when disabled.'),
  damageFlares: bool('Flare on damage', 'React after HP or temporary HP is lost. Fully absorbed damage does not trigger a flare.'),
  healingPulses: bool('Brighten on healing', 'Brighten and stabilize wings when actual HP increases. Gaining temporary HP does not count as healing.'),
  criticalReactions: bool('Stronger critical-hit reactions', 'Use verified applied-damage context when available. Manual flare({critical:true}) also respects this setting.'),
  reactionStrength: number('Damage/healing effect strength', 'Scale temporary visual reactions.', 1, 0, 2, 0.05),
  conditionDuration: number('Condition transition duration', 'Milliseconds for manual condition changes and temporary condition entrance/return.', 650, 0, 10000, 50),
  hpRecoveryDuration: number('HP stabilization duration', 'Milliseconds for automatic wing health to settle after HP or consciousness changes.', 1200, 0, 10000, 50),
  damageDuration: number('Damage flare duration', 'Milliseconds for damage reactions.', 900, 0, 10000, 50),
  healingDuration: number('Healing pulse duration', 'Milliseconds for healing reactions.', 1400, 0, 10000, 50),
  movementWings: bool('Wings react to movement', 'Sweep the filaments opposite the token’s visible movement. The saved pose remains independent.'),
  movementStrength: number('Movement wing sweep', 'Strength of backward stretching; guard and cocoon poses resist the sweep.', 0.75, 0, 1, 0.05),
  wingBanking: bool('Asymmetric wing banking', 'Let left and right wings respond differently to sideways motion and turns.'),
  flightManoeuvres: bool('Flight manoeuvres', 'While she is airborne, the wings react to how she moves on this screen: they flare forward when she brakes to a stop (each flight mode brakes in its own way) and rise with a slower beat as she descends or lands. With Flight feel Classic they also bank into curving paths and lag and swing through when she pivots or reverses. Purely visual; off under reduced motion.', 'client'),
  movementSensitivity: number('Full sweep speed', 'Grid spaces per second of visible token animation for full wing sweep. Lower values react sooner; this is not a rules speed.', 3.5, 0.5, 12, 0.25),
  movementRelaxation: number('Idle wing relaxation', 'Approximate milliseconds to settle after movement stops.', 650, 100, 2000, 50),
  fastSweepMultiplier: number('Fast-flight sweep multiplier', 'Fast mode stretches the wings farther at the same visible movement speed.', 1.65, 1, 3, 0.05),
  wingTrails: bool('Movement filament trails', 'Leave short-lived magenta wisps from the wing tips during flight (in the modes chosen below).'),
  localTrails: bool('Show trails on this browser', 'Disable trails locally without changing other viewers.', 'client'),
  trailModes: {name:'Modes with trails',hint:'Which flight modes leave wingtip trails while she moves. Fast Flight and Glide suit them best: speed, and long wakes off held wings. The other modes have touches of their own.',scope:'world',config:true,type:String,default:'flight',choices:{flight:'Fast Flight and Glide',fast:'Fast Flight only',all:'All airborne modes'}},
  trailIntensity: number('Default trail intensity', 'Base opacity of the moving filaments; per-token API values can override it.', 0.5, 0, 1, 0.05),
  trailLimit: number('Maximum trail intensity', 'World cap, including fast-flight multipliers and macro overrides.', 1, 0, 1, 0.05),
  fastTrailMultiplier: number('Fast-flight trail multiplier', 'Increase trail strength in Fast Flight. Fast trails also use the full lifetime and length limits.', 1.8, 1, 3, 0.1),
  trailLength: number('Maximum trail length', 'Maximum distance behind the token in grid spaces. Ordinary flight uses 65% of this limit.', 2.5, 0.25, 6, 0.25),
  trailLifetime: number('Maximum trail lifetime', 'Milliseconds before old trail sections disappear. Ordinary flight uses 75% of this limit.', 650, 100, 1600, 50),
  takeoffFormation: bool('Form wings during takeoff', 'takeoff() grows filaments outward from the shoulder roots. Legacy toggle() keeps its original entrance.'),
  landingFolding: bool('Fold wings during landing', 'land() folds the wings inward, then retracts and fades them. Legacy off() retains its original exit.'),
  landingFoldStrength: number('Landing fold amount', 'How tightly the landing sequence folds the wings. Zero retains an open shape while retracting.', 1, 0, 1, 0.05),
  formationGlow: bool('Light along forming filaments', 'Small glints follow the growing filament ends. Energy-pulse and reduced-motion controls also apply.'),
  wingbeats: bool('Animate wingbeats', 'Turn the wing animation on or off.'),
  hover: bool('Visual hover', 'Lift the token image above its actual square. This does not change elevation.'),
  bobbing: bool('Hover bobbing', 'Allow gentle up and down motion. Sideways floating remains independently adjustable.'),
  banking: bool('Movement banking', 'Allow left and right lean during animated movement.'),
  pitching: bool('Movement pitch', 'Allow subtle vertical squash during north/south movement.'),
  shadows: bool('Ground shadows', 'Allow the module to draw its soft shadow.'),
  transitions: bool('Flight and condition transitions', 'Allow smooth flight appearance/disappearance and changes in wing condition. Disable to switch immediately.'),
  wingScale: number('Default wing size', 'Relative to token size. Explicit token overrides take precedence.', DEFAULTS.wingScale, 1, 7, 0.1),
  hoverHeight: number('Default hover height', 'Visual lift in token sizes, not feet of elevation.', DEFAULTS.hoverHeight, 0, 1, 0.01),
  bobHeight: number('Default bobbing amount', 'Up/down motion in token sizes. Zero disables it.', DEFAULTS.bobHeight, 0, 0.3, 0.005),
  floatStyle: {name:'Default floating style',hint:'Cosmetic motion of the token and attached wings. This never changes position, elevation, speed or game rules.',scope:'world',config:true,type:String,default:DEFAULTS.floatStyle,choices:FLOAT_STYLES},
  modeIdleStrength: number('Flight-mode stationary motion','Distinct stationary movement and posture for each flight mode. Zero uses only the selected floating style. Still and Reduced motion remain still.',1,0,2,0.05),
  floatSpeed: number('Default floating speed','Speed of the selected floating animation, independently of wingbeats.',DEFAULTS.floatSpeed,0.25,2,0.05),
  floatSway: number('Default floating sway','Horizontal drift for Astral drift and Resonant orbit, in token sizes.',DEFAULTS.floatSway,0,0.15,0.005),
  tiltDegrees: number('Default maximum bank', 'Maximum movement lean in degrees. Zero disables it.', DEFAULTS.tiltDegrees, 0, 35, 1),
  wingSpeed: number('Default wingbeat speed', '1 is the original speed.', DEFAULTS.wingSpeed, 0.2, 3, 0.1),
  opacity: number('Default wing opacity', 'Maximum opacity before the token opacity and intensity are applied.', DEFAULTS.opacity, 0, 1, 0.05),
  offsetX: number('Default horizontal wing offset', 'Move the shoulder attachment in token sizes.', DEFAULTS.offsetX, -2, 2, 0.05),
  offsetY: number('Default vertical wing offset', 'Move the shoulder attachment in token sizes.', DEFAULTS.offsetY, -2, 2, 0.05),
  shadow: bool('Default token shadow', 'Default shadow preference. Ground shadows can disable shadows for every token.'),
  intensityLimit: number('Maximum wing intensity', 'Limit wing intensity for all tokens, including macro overrides.', 1, 0, 1, 0.05),
  fastWingSpeed: number('Fast-flight wingbeat multiplier', 'Extra wingbeat speed in the fast visual mode. This does not move the token.', 1.5, 1, 3, 0.1),
  transitionDuration: number('API takeoff/landing duration', 'Milliseconds for takeoff() and land(). The old toggle retains its original easing.', 750, 0, 10000, 50)
};

export function registerSettings(onChange) {
  invalidateConfiguration();
  registeredSettings=game.settings;
  // v10: Foundry's own list shows only the main switches; everything stays in
  // the "All settings" window. Choose "Full list" to get the 9.x layout back.
  game.settings.register(ID,'settingsList',{name:'Settings list',hint:'Compact shows only the main switches here and keeps every other option in the All settings window. Full list shows every option here, as in 9.x. Reload after changing.',
    scope:'world',config:true,type:String,default:'compact',choices:{compact:'Compact (v10)',full:'Full list (9.x)'},requiresReload:true});
  let compact=true;try{compact=game.settings.get(ID,'settingsList')!=='full';}catch{}
  for (const [key, setting] of Object.entries(SETTINGS)) {
    const shown=setting.config!==false&&(!compact||ESSENTIAL_SETTINGS.includes(key));
    game.settings.register(ID, key, {...setting, config:shown, onChange:() => {invalidateConfiguration();onChange(key);}});
  }
  const Panel=settingsPanelClass(ID,SETTINGS);
  if(Panel)game.settings.registerMenu(ID,'allSettings',{name:'All Yvaelle’s Toolbox settings',label:'Open all settings',hint:'Every option, grouped and searchable. World options can be changed by a GM.',icon:'fas fa-sliders',type:Panel,restricted:false});
  game.settings.register(ID,'hudPreferences',{name:'Flight HUD preferences',scope:'client',config:false,type:Object,default:{version:1}});
  game.settings.register(ID,'lookPresets',{name:'Personal flight looks',scope:'client',config:false,type:Object,default:{}});
}

let registeredSettings=null,cachedConfiguration=null,cachedPhotosensitive=null,cachedComponents=null;
export function invalidateConfiguration(){cachedConfiguration=null;}
/** Registered settings have reliable change notifications. Preserve uncached
 * reads for previews/tests and API callers; animation loops reuse one snapshot. */
export function runtimeConfiguration(){
  const photosensitive=!!globalThis.canvas?.photosensitiveMode,components=localPerformance.components;
  if(!cachedConfiguration||game.settings!==registeredSettings||cachedPhotosensitive!==photosensitive||cachedComponents!==components){
    cachedConfiguration=configuration();cachedPhotosensitive=photosensitive;cachedComponents=components;
    if(localPerformance.isolated)cachedConfiguration={...cachedConfiguration,performanceComponents:components};
  }
  return cachedConfiguration;
}

export function configuration() {
  const values = {};
  for (const [key, entry] of Object.entries(SETTINGS)) {
    let value;
    try { value = game.settings.get(ID, key); } catch { value = entry.default; }
    if (entry.type === Boolean) value = typeof value === 'boolean' ? value : entry.default;
    else if (entry.type === String) value = Object.hasOwn(entry.choices, value) ? value : entry.default;
    else if(entry.type===Object)value=qualityProfile(value,{strict:false});
    else value = Number.isFinite(value) ? Math.max(entry.range.min, Math.min(entry.range.max, value)) : entry.default;
    values[key] = value;
  }
  return {
    ...values,
    enabled:values.effectsEnabled && values.localEffects,
    reduced:values.reducedMotion || !!globalThis.canvas?.photosensitiveMode,
    hpThresholds:{moderate:values.hpModerate/100,low:Math.min(values.hpModerate,values.hpLow)/100,
      critical:Math.min(values.hpModerate,values.hpLow,values.hpCritical)/100},
    defaults:options(values)
  };
}

export function optionPatch(input, {strict=true, allowNull=false}={}) {
  if (strict && (!input || typeof input !== 'object' || Array.isArray(input))) throw new Error('Options must be an object.');
  const out = {};
  if (strict) for (const key of Object.keys(input)) {
    if (!Object.hasOwn(DEFAULTS, key)) throw new Error(`Unknown flight option: ${key}.`);
  }
  for (const key of Object.keys(DEFAULTS)) {
    if (!input || !Object.hasOwn(Object(input), key)) continue;
    const value = input[key];
    if (allowNull && value === null) { out[key] = null; continue; }
    if (key === 'floatStyle') {
      if(typeof value==='string'&&Object.hasOwn(FLOAT_STYLES,value))out[key]=value;
      else if(strict)throw new Error(`Unknown floating style: ${value}.`);
    } else if (key === 'shadow') {
      if (typeof value === 'boolean') out[key] = value;
      else if (strict) throw new Error('shadow must be true or false.');
    } else if (typeof value === 'number' && Number.isFinite(value)) {
      const [lo, hi] = LIMITS[key]; out[key] = Math.max(lo, Math.min(hi, value));
    } else if (strict) throw new Error(`${key} must be a finite number.`);
  }
  return out;
}
